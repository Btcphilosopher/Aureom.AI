package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.components.AccessibilityDialog
import com.example.ui.components.MetroBottomBar
import com.example.ui.components.MetroTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MetroOSTheme
import com.example.viewmodel.MetroViewModel
import com.example.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {
    private val viewModel: MetroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MetroOSTheme {
                var showAccessibilityDialog by remember { mutableStateOf(false) }
                val currentTab by viewModel.currentTab.collectAsState()
                val selectedStation by viewModel.selectedStation.collectAsState()
                val realTimeTrains by viewModel.realTimeTrains.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        MetroTopBar(
                            onAccessibilityClick = { showAccessibilityDialog = true }
                        )
                    },
                    bottomBar = {
                        MetroBottomBar(
                            currentTab = currentTab,
                            onTabSelected = { tab -> viewModel.selectTab(tab) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            NavigationTab.LIVE_MAP -> {
                                LiveMapScreen(
                                    viewModel = viewModel,
                                    stations = viewModel.stations,
                                    trains = realTimeTrains,
                                    selectedStation = selectedStation,
                                    onStationSelect = { st -> viewModel.selectStation(st) }
                                )
                            }
                            NavigationTab.JOURNEY_PLANNER -> {
                                JourneyPlannerScreen(viewModel = viewModel)
                            }
                            NavigationTab.PLATFORM_TWIN -> {
                                PlatformTwinScreen(viewModel = viewModel)
                            }
                            NavigationTab.DISRUPTION_AI -> {
                                DisruptionEngineScreen(viewModel = viewModel)
                            }
                            NavigationTab.TERMINAL_CONTROL -> {
                                BloombergControlScreen(viewModel = viewModel)
                            }
                            NavigationTab.AI_ASSISTANT -> {
                                AiAssistantScreen(viewModel = viewModel)
                            }
                            NavigationTab.EXPLORE_NYC -> {
                                ExploreNycScreen(viewModel = viewModel)
                            }
                        }

                        if (showAccessibilityDialog) {
                            AccessibilityDialog(
                                viewModel = viewModel,
                                onDismiss = { showAccessibilityDialog = false }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveMapScreen(
    viewModel: MetroViewModel,
    stations: List<com.example.model.SubwayStation>,
    trains: List<com.example.model.RealtimeTrain>,
    selectedStation: com.example.model.SubwayStation?,
    onStationSelect: (com.example.model.SubwayStation) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        com.example.ui.components.SubwayMapCanvas(
            stations = stations,
            trains = trains,
            selectedStation = selectedStation,
            onStationSelect = onStationSelect
        )
    }
}
