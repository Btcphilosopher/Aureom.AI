package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val borough: String,
    val lineCodes: String, // Comma separated e.g. "LINE_123,LINE_456"
    val latitude: Double,
    val longitude: Double,
    val isAccessible: Boolean,
    val crowdingDensity: String,
    val escalatorsWorking: Int,
    val escalatorsTotal: Int,
    val elevatorsWorking: Int,
    val elevatorsTotal: Int,
    val exitFront: String,
    val exitMiddle: String,
    val exitRear: String,
    val nearbyCoffee: String,
    val nearbyFood: String,
    val nearbyPolice: String,
    val quietCarRecommended: Int
)

@Entity(tableName = "saved_routes")
data class SavedRouteEntity(
    @PrimaryKey val id: String,
    val originId: String,
    val destinationId: String,
    val originName: String,
    val destinationName: String,
    val totalMinutes: Int,
    val transferCount: Int,
    val filterType: String,
    val savedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val lineCode: String,
    val title: String,
    val summary: String,
    val severity: String,
    val failureProbability: Int,
    val causeType: String,
    val estimatedResolution: String
)
