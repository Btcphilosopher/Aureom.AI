package com.example.model

import androidx.compose.ui.graphics.Color

enum class SubwayLine(
    val code: String,
    val nameTitle: String,
    val color: Color,
    val textColor: Color = Color.White,
    val category: String = "Subway"
) {
    LINE_123("1-2-3", "Seventh Avenue Express / Local", Color(0xFFEE352E)),
    LINE_456("4-5-6", "Lexington Avenue Express / Local", Color(0xFF00933C)),
    LINE_7("7", "Flushing Local / Express", Color(0xFFB933AD)),
    LINE_ACE("A-C-E", "Eighth Avenue Express / Local", Color(0xFF0039A6)),
    LINE_BDFM("B-D-F-M", "Sixth Avenue Express / Local", Color(0xFFFF6319)),
    LINE_G("G", "Brooklyn-Queens Crosstown", Color(0xFF6CBE45)),
    LINE_JZ("J-Z", "Nassau Street Express / Local", Color(0xFF996633)),
    LINE_L("L", "14th Street-Canarsie Local", Color(0xFFA7A9AC), Color.Black),
    LINE_NQRW("N-Q-R-W", "Broadway Express / Local", Color(0xFFFCCC0A), Color.Black),
    LINE_S("S", "Shuttle (42nd St / Franklin / Rockaway)", Color(0xFF808183)),
    LINE_SIR("SIR", "Staten Island Railway", Color(0xFF0039A6)),
    PATH("PATH", "Port Authority Trans-Hudson", Color(0xFF00A8E8), category = "PATH"),
    LIRR("LIRR", "Long Island Rail Road", Color(0xFF0039A6), category = "Commuter Rail"),
    METRO_NORTH("MNR", "Metro-North Railroad", Color(0xFF0039A6), category = "Commuter Rail"),
    AIRTRAIN("JFK", "AirTrain JFK / Newark", Color(0xFF00B4D8), Color.Black, category = "Airport")
}

data class SubwayStation(
    val id: String,
    val name: String,
    val borough: String,
    val lines: List<SubwayLine>,
    val latitude: Double,
    val longitude: Double,
    val isAccessible: Boolean = true,
    val platformCrowdingDensity: CrowdingLevel = CrowdingLevel.LOW,
    val escalatorsWorking: Int = 4,
    val escalatorsTotal: Int = 4,
    val elevatorsWorking: Int = 2,
    val elevatorsTotal: Int = 2,
    val bestCarriageExitFront: String = "Exit to 8th Ave & 34th St",
    val bestCarriageExitMiddle: String = "Transfer to 1,2,3 / A,C,E",
    val bestCarriageExitRear: String = "Exit to 7th Ave & Amtrak",
    val nearbyCoffee: String = "Joe Coffee (Upper Level)",
    val nearbyFood: String = "Shake Shack / Union Square Cafe",
    val nearbyPolice: String = "MTA Transit District 1",
    val quietCarRecommended: Int = 3 // carriage number 1-8
)

enum class CrowdingLevel(val label: String, val color: Color) {
    LOW("Low Crowding (15-30%)", Color(0xFF10B981)),
    MODERATE("Moderate (45-65%)", Color(0xFFF59E0B)),
    HIGH("High Density (75-90%)", Color(0xFFEF4444)),
    CRITICAL("Severe Overcrowding", Color(0xFF991B1B))
}

data class RealtimeTrain(
    val trainId: String,
    val line: SubwayLine,
    val destination: String,
    val currentStationId: String,
    val nextStationId: String,
    val progress: Float, // 0.0 to 1.0 between stations
    val speedMph: Int,
    val occupancyPercentage: Int,
    val delayMinutes: Int,
    val signalStatus: String = "NORMAL (CBTC)",
    val maintenanceFlag: Boolean = false,
    val headwayMinutes: Int = 4,
    val predictedCongestionNextStation: Int = 35
)

enum class RouteFilterOption(val label: String, val description: String) {
    FASTEST("Fastest Route", "Minimizes overall travel time"),
    LEAST_WALKING("Least Walking", "Minimizes transfer distances and stairs"),
    FEWEST_TRANSFERS("Fewest Transfers", "Direct or single-line preference"),
    ACCESSIBLE("Wheelchair Accessible", "Elevator-only accessible platforms"),
    QUIETEST("Quietest Carriage", "Avoids high-noise cars and busy stations"),
    RAIN_FRIENDLY("Rain / Cover Friendly", "Maximizes underground walkway connections"),
    LATE_NIGHT_SAFE("Late Night Optimized", "Well-lit platforms and safety priority")
}

data class RouteLeg(
    val line: SubwayLine,
    val boardStation: SubwayStation,
    val alightStation: SubwayStation,
    val intermediateStopsCount: Int,
    val estimatedMinutes: Int,
    val recommendedCarriage: String, // e.g. "Car 3 or 4"
    val platformExit: String,
    val crowdStatus: CrowdingLevel
)

data class JourneyRoute(
    val id: String,
    val origin: SubwayStation,
    val destination: SubwayStation,
    val totalMinutes: Int,
    val totalWalkingMeters: Int,
    val transferCount: Int,
    val legs: List<RouteLeg>,
    val carbonSavedKg: Double,
    val isAccessible: Boolean,
    val filterType: RouteFilterOption,
    val quietCarRecommended: Int = 2
)

data class DisruptionAlert(
    val id: String,
    val line: SubwayLine,
    val title: String,
    val summary: String,
    val severity: AlertSeverity,
    val failureProbabilityPercent: Int, // ML XGBoost prediction
    val causeType: String, // e.g., "Signal Delays", "Track Maintenance", "Water Inflow"
    val estimatedResolutionTime: String
)

enum class AlertSeverity(val label: String, val color: Color) {
    INFO("Service Advisory", Color(0xFF3B82F6)),
    WARNING("Minor Delays", Color(0xFFF59E0B)),
    CRITICAL("Severe Disruption", Color(0xFFEF4444))
}

data class EnergyDashboardData(
    val networkPowerKw: Double = 142500.0,
    val regenerativeBrakingKwSaved: Double = 38200.0,
    val dailyPassengerKm: Long = 18450000L,
    val carbonSavingsTons: Double = 1240.5,
    val peakDemandLevelPercent: Int = 78,
    val trainEfficiencyRating: String = "A+ (Optimal CBTC)"
)

data class Attraction(
    val name: String,
    val category: String,
    val nearestStationId: String,
    val nearestStationName: String,
    val walkingMinutes: Int,
    val description: String
)
