package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroBentoAccent
import com.example.ui.theme.MetroBentoAccentText
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.MetroViewModel
import kotlinx.coroutines.launch

@Composable
fun AiAssistantScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.chatMessages.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val suggestedPrompts = listOf(
        "When should I leave for JFK?",
        "Quiet carriage on 4 train?",
        "Find coffee near Fulton Center",
        "Fastest route avoiding Times Square"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
    ) {
        // Title Bar (Bento style)
        Surface(
            color = MetroSurface,
            border = BorderStroke(1.dp, MetroCardBorder),
            shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF00E5FF))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("METRO_OS AI ASSISTANT", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Powered by Gemini 3.5 • Real-time Subway Intelligence", color = MetroTextSecondary, fontSize = 11.sp)
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(msg = msg)
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF00E5FF),
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Metro AI is computing route physics...", color = Color(0xFF00E5FF), fontSize = 12.sp)
                    }
                }
            }
        }

        // Suggested Prompt Chips (Bento Pills)
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(suggestedPrompts) { prompt ->
                SuggestionChip(
                    onClick = {
                        viewModel.sendChatMessage(prompt)
                        coroutineScope.launch {
                            listState.animateScrollToItem(messages.size)
                        }
                    },
                    label = { Text(prompt, fontSize = 11.sp) },
                    shape = RoundedCornerShape(20.dp),
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = MetroSurface,
                        labelColor = Color.White
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        borderColor = MetroCardBorder,
                        enabled = true
                    ),
                    modifier = Modifier.testTag("ai_prompt_chip_${prompt.take(10)}")
                )
            }
        }

        // Input Field Bar (Bento Pill)
        Surface(
            color = MetroSurface,
            border = BorderStroke(1.dp, MetroCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(28.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask Metro AI...", fontSize = 14.sp, color = MetroTextSecondary) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_input_text_field")
                )
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.sendChatMessage(inputText)
                            inputText = ""
                            coroutineScope.launch {
                                listState.animateScrollToItem(messages.size)
                            }
                        }
                    },
                    modifier = Modifier.testTag("ai_send_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF00E5FF))
                }
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.sender == "USER"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) MetroBentoAccent else MetroSurface,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 18.dp
            ),
            border = BorderStroke(
                1.dp,
                if (isUser) MetroBentoAccent else MetroCardBorder
            ),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (isUser) "YOU" else "METRO_OS AI",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUser) MetroBentoAccentText else Color(0xFFFCCC0A)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.text,
                    fontSize = 13.sp,
                    color = if (isUser) MetroBentoAccentText else Color.White
                )
            }
        }
    }
}

