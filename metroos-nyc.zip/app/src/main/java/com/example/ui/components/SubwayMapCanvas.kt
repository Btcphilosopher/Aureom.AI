package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RealtimeTrain
import com.example.model.SubwayLine
import com.example.model.SubwayStation

@Composable
fun SubwayMapCanvas(
    stations: List<SubwayStation>,
    trains: List<RealtimeTrain>,
    selectedStation: SubwayStation?,
    onStationSelect: (SubwayStation) -> Unit,
    modifier: Modifier = Modifier
) {
    var zoomLevel by remember { mutableFloatStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var activeCategoryFilter by remember { mutableStateOf("ALL") }

    // Pulsing animation for real-time trains
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseRadius"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1113))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("subway_live_map_canvas")
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()

                        val nearest = stations.minByOrNull { st ->
                            val pt = getStationCanvasPoint(st, canvasWidth, canvasHeight, panOffset, zoomLevel)
                            (pt - tapOffset).getDistance()
                        }
                        nearest?.let { st ->
                            val pt = getStationCanvasPoint(st, canvasWidth, canvasHeight, panOffset, zoomLevel)
                            if ((pt - tapOffset).getDistance() < 60f * zoomLevel) {
                                onStationSelect(st)
                            }
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // Draw Cybernetic Grid Lines
            val gridStep = 40f * zoomLevel
            var x = (panOffset.x % gridStep)
            while (x < width) {
                drawLine(
                    color = Color(0xFF1E232A),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
                x += gridStep
            }
            var y = (panOffset.y % gridStep)
            while (y < height) {
                drawLine(
                    color = Color(0xFF1E232A),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
                y += gridStep
            }

            // Draw East River / Hudson River Outlines
            val riverPath = Path().apply {
                val startX = width * 0.45f + panOffset.x
                moveTo(startX, 0f)
                cubicTo(
                    startX + 30f * zoomLevel, height * 0.3f,
                    startX - 50f * zoomLevel, height * 0.7f,
                    startX + 20f * zoomLevel, height
                )
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF142436),
                style = Stroke(width = 32f * zoomLevel, cap = StrokeCap.Round)
            )

            // Draw Subway Line Routes
            val lineGroups = listOf(
                SubwayLine.LINE_456, SubwayLine.LINE_7, SubwayLine.LINE_123,
                SubwayLine.LINE_ACE, SubwayLine.LINE_BDFM, SubwayLine.LINE_NQRW,
                SubwayLine.LINE_L, SubwayLine.PATH, SubwayLine.AIRTRAIN
            )

            lineGroups.forEach { line ->
                val lineStations = stations.filter { s -> s.lines.contains(line) }
                if (lineStations.size >= 2) {
                    val path = Path()
                    val firstPt = getStationCanvasPoint(lineStations.first(), width, height, panOffset, zoomLevel)
                    path.moveTo(firstPt.x, firstPt.y)

                    for (i in 1 until lineStations.size) {
                        val pt = getStationCanvasPoint(lineStations[i], width, height, panOffset, zoomLevel)
                        path.lineTo(pt.x, pt.y)
                    }

                    drawPath(
                        path = path,
                        color = line.color.copy(alpha = 0.85f),
                        style = Stroke(width = 6f * zoomLevel, cap = StrokeCap.Round)
                    )
                }
            }

            // Draw Station Nodes
            stations.forEach { st ->
                val pt = getStationCanvasPoint(st, width, height, panOffset, zoomLevel)
                val isSelected = selectedStation?.id == st.id

                if (isSelected) {
                    drawCircle(
                        color = Color(0xFFD1E4FF).copy(alpha = 0.4f),
                        radius = 18f * zoomLevel,
                        center = pt
                    )
                }

                drawCircle(
                    color = if (isSelected) Color(0xFFD1E4FF) else Color.White,
                    radius = if (isSelected) 8f * zoomLevel else 6f * zoomLevel,
                    center = pt
                )
                drawCircle(
                    color = Color(0xFF0F1113),
                    radius = if (isSelected) 4f * zoomLevel else 3f * zoomLevel,
                    center = pt
                )
            }

            // Draw Real-time Animated Trains
            trains.forEach { train ->
                val currSt = stations.find { it.id == train.currentStationId }
                val nextSt = stations.find { it.id == train.nextStationId }

                if (currSt != null && nextSt != null) {
                    val p1 = getStationCanvasPoint(currSt, width, height, panOffset, zoomLevel)
                    val p2 = getStationCanvasPoint(nextSt, width, height, panOffset, zoomLevel)

                    val trainX = p1.x + (p2.x - p1.x) * train.progress
                    val trainY = p1.y + (p2.y - p1.y) * train.progress
                    val trainPt = Offset(trainX, trainY)

                    drawCircle(
                        color = train.line.color.copy(alpha = 0.4f),
                        radius = pulseRadius * zoomLevel,
                        center = trainPt
                    )
                    drawCircle(
                        color = train.line.color,
                        radius = 5f * zoomLevel,
                        center = trainPt
                    )
                }
            }
        }

        // Top Filter Bar (Bento Pill Chips)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL", "SUBWAY", "PATH", "LIRR", "AIRTRAIN").forEach { filter ->
                val selected = activeCategoryFilter == filter
                FilterChip(
                    selected = selected,
                    onClick = { activeCategoryFilter = filter },
                    label = { Text(filter, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    shape = RoundedCornerShape(16.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD1E4FF),
                        selectedLabelColor = Color(0xFF001D36),
                        containerColor = Color(0xFF1C1F22).copy(alpha = 0.95f),
                        labelColor = Color(0xFF909194)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = Color(0xFF2D3035),
                        selectedBorderColor = Color(0xFFD1E4FF),
                        enabled = true,
                        selected = selected
                    ),
                    modifier = Modifier.testTag("filter_chip_$filter")
                )
            }
        }

        // Zoom Controls
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { zoomLevel = (zoomLevel * 1.25f).coerceAtMost(2.5f) },
                containerColor = Color(0xFF1C1F22),
                contentColor = Color(0xFFD1E4FF),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .size(42.dp)
                    .testTag("zoom_in_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }
            FloatingActionButton(
                onClick = { zoomLevel = (zoomLevel * 0.8f).coerceAtLeast(0.6f) },
                containerColor = Color(0xFF1C1F22),
                contentColor = Color(0xFFD1E4FF),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .size(42.dp)
                    .testTag("zoom_out_button")
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }
            FloatingActionButton(
                onClick = {
                    zoomLevel = 1.0f
                    panOffset = Offset.Zero
                },
                containerColor = Color(0xFF1C1F22),
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .size(42.dp)
                    .testTag("recenter_button")
            ) {
                Icon(Icons.Default.Navigation, contentDescription = "Recenter")
            }
        }

        // Live Status Indicator (Bento Pill)
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 60.dp, end = 12.dp),
            color = Color(0xFF1C1F22).copy(alpha = 0.95f),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, Color(0xFF2D3035))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF4ADE80))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${trains.size} TRAINS LIVE",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun getStationCanvasPoint(
    st: SubwayStation,
    width: Float,
    height: Float,
    pan: Offset,
    zoom: Float
): Offset {
    val minLat = 40.6800
    val maxLat = 40.7700
    val minLng = -74.0150
    val maxLng = -73.8000

    val normX = ((st.longitude - minLng) / (maxLng - minLng)).toFloat()
    val normY = (1.0f - ((st.latitude - minLat) / (maxLat - minLat))).toFloat()

    val baseX = width * 0.15f + normX * width * 0.7f
    val baseY = height * 0.15f + normY * height * 0.7f

    val centerX = width / 2f
    val centerY = height / 2f

    val zoomedX = centerX + (baseX - centerX) * zoom + pan.x
    val zoomedY = centerY + (baseY - centerY) * zoom + pan.y

    return Offset(zoomedX, zoomedY)
}
