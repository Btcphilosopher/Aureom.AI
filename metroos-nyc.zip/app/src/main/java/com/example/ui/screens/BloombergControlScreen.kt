package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroGreen
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.MetroViewModel

@Composable
fun BloombergControlScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val energy by viewModel.energyMetrics.collectAsState()
    val trains by viewModel.realTimeTrains.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "BLOOMBERG TERMINAL - CONTROL CENTER",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "MTA Network OS • Infrastructure Health • Energy & Fleet Analytics",
                    color = MetroTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Executive KPI Gauges (Bento 2-Col Grid)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiCard(
                    title = "NETWORK POWER",
                    value = "${(energy.networkPowerKw / 1000).toInt()} MW",
                    subtitle = "Peak Load: ${energy.peakDemandLevelPercent}%",
                    icon = Icons.Default.Bolt,
                    color = Color(0xFFFCCC0A),
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "ACTIVE FLEET",
                    value = "${trains.size} CARS",
                    subtitle = "100% CBTC Synced",
                    icon = Icons.Default.Train,
                    color = Color(0xFF00E5FF),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Energy & Sustainability Bento Card
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SUSTAINABILITY & REGENERATIVE BRAKING",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("REGENERATIVE POWER RECOVERED", fontSize = 10.sp, color = MetroTextSecondary)
                            Text("${energy.regenerativeBrakingKwSaved} kW", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MetroGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("DAILY PASSENGER KM", fontSize = 10.sp, color = MetroTextSecondary)
                            Text("${energy.dailyPassengerKm / 1000000}M km", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MetroCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Efficiency Rating: ${energy.trainEfficiencyRating}", fontSize = 11.sp, color = Color(0xFF00E5FF))
                        Text("CO₂ Saved: ${energy.carbonSavingsTons} Tons/day", fontSize = 11.sp, color = MetroGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // GTFS-Realtime Data Stream Monitor Bento Card
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("GTFS-RT DATA FEED STREAM", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Latency < 450ms", color = MetroGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val feedLogs = listOf(
                        "FEED_01: Subway Line 4,5,6 position payload synced [24 updates/sec]",
                        "FEED_02: Signal CBTC interlocking #402 status: NORMAL",
                        "FEED_03: Station Platform Crowding Sensor GCT-42: LOW (28%)",
                        "FEED_04: LIRR Atlantic Terminal dispatch sync OK"
                    )

                    feedLogs.forEach { log ->
                        Text(
                            text = "> $log",
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = MetroTextSecondary,
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MetroSurface,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MetroCardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontSize = 10.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium)
        }
    }
}

