package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.MetroViewModel

@Composable
fun AccessibilityDialog(
    viewModel: MetroViewModel,
    onDismiss: () -> Unit
) {
    val acc by viewModel.accessibility.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111827),
        titleContentColor = Color(0xFF00E5FF),
        shape = RoundedCornerShape(16.dp),
        title = {
            Text(
                text = "ACCESSIBILITY & DISPLAY",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                AccessibilitySwitchRow(
                    label = "High Contrast Mode",
                    subtitle = "Enhance border contrast and black canvas density",
                    checked = acc.highContrast,
                    onCheckedChange = { viewModel.toggleHighContrast() },
                    tag = "acc_high_contrast"
                )
                AccessibilitySwitchRow(
                    label = "Large Text Scale",
                    subtitle = "Increase font sizes across all terminal screens",
                    checked = acc.largeText,
                    onCheckedChange = { viewModel.toggleLargeText() },
                    tag = "acc_large_text"
                )
                AccessibilitySwitchRow(
                    label = "Wheelchair Accessible Only",
                    subtitle = "Restrict route options to elevator stations",
                    checked = acc.wheelchairOnly,
                    onCheckedChange = { viewModel.toggleWheelchairOnly() },
                    tag = "acc_wheelchair"
                )
                AccessibilitySwitchRow(
                    label = "Colorblind Badge Mode",
                    subtitle = "Display text patterns on line badges",
                    checked = acc.colorblindMode,
                    onCheckedChange = { viewModel.toggleColorblindMode() },
                    tag = "acc_colorblind"
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("acc_close_button")
            ) {
                Text("DONE", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun AccessibilitySwitchRow(
    label: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF9CA3AF), fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color(0xFF00E5FF)
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}
