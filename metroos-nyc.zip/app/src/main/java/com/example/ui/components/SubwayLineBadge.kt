package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SubwayLine

@Composable
fun SubwayLineBadge(
    line: SubwayLine,
    size: Dp = 28.dp,
    modifier: Modifier = Modifier
) {
    if (line.code.length <= 3 && !line.code.contains("-")) {
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(line.color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = line.code,
                color = line.textColor,
                fontSize = (size.value * 0.48).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    } else {
        Box(
            modifier = modifier
                .height(size)
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(size / 3))
                .background(line.color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = line.code,
                color = line.textColor,
                fontSize = (size.value * 0.42).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}
