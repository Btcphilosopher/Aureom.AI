package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyRoute
import com.example.model.RouteFilterOption
import com.example.model.SubwayStation
import com.example.ui.components.SubwayLineBadge
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroBentoAccent
import com.example.ui.theme.MetroBentoAccentBadge
import com.example.ui.theme.MetroBentoAccentText
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroGreen
import com.example.ui.theme.MetroRed
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyPlannerScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val origin by viewModel.originStation.collectAsState()
    val destination by viewModel.destinationStation.collectAsState()
    val filter by viewModel.selectedFilter.collectAsState()
    val routes by viewModel.journeyRoutes.collectAsState()
    val savedRoutes by viewModel.savedRoutes.collectAsState()

    var showOriginMenu by remember { mutableStateOf(false) }
    var showDestMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Bento Hero Header Card
        item {
            Surface(
                color = MetroBentoAccent,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "SMART ROUTE",
                                color = MetroBentoAccentBadge,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "To ${destination.name}",
                                color = MetroBentoAccentText,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MetroBentoAccentBadge)
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Board rear carriage • Saves ~3m transfer walking",
                        color = MetroBentoAccentText.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val topRoute = routes.firstOrNull()
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.White.copy(alpha = 0.4f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${topRoute?.totalMinutes ?: 18} min",
                                color = MetroBentoAccentText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.White.copy(alpha = 0.4f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${topRoute?.transferCount ?: 0} Transfers",
                                color = MetroBentoAccentText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Origin & Destination Selector Bento Card
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Origin Box
                    Box {
                        OutlinedButton(
                            onClick = { showOriginMenu = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, MetroCardBorder),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_selector_button")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.TripOrigin, contentDescription = null, tint = MetroGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("ORIGIN", fontSize = 10.sp, color = MetroTextSecondary)
                                    Text(origin.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MetroTextSecondary)
                            }
                        }
                        DropdownMenu(
                            expanded = showOriginMenu,
                            onDismissRequest = { showOriginMenu = false }
                        ) {
                            viewModel.stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.setOrigin(station)
                                        showOriginMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Swap Button
                    IconButton(
                        onClick = { viewModel.swapOriginDestination() },
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(vertical = 4.dp)
                            .testTag("swap_stations_button")
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Swap Origin and Destination", tint = MetroBentoAccentText)
                    }

                    // Destination Box
                    Box {
                        OutlinedButton(
                            onClick = { showDestMenu = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, MetroCardBorder),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_selector_button")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = MetroRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("DESTINATION", fontSize = 10.sp, color = MetroTextSecondary)
                                    Text(destination.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MetroTextSecondary)
                            }
                        }
                        DropdownMenu(
                            expanded = showDestMenu,
                            onDismissRequest = { showDestMenu = false }
                        ) {
                            viewModel.stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.setDestination(station)
                                        showDestMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Optimization Preference Chips
        item {
            Column {
                Text(
                    text = "OPTIMIZATION CRITERIA",
                    color = MetroTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(RouteFilterOption.values()) { opt ->
                        val selected = filter == opt
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.setFilter(opt) },
                            label = { Text(opt.label, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            shape = RoundedCornerShape(16.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MetroBentoAccent,
                                selectedLabelColor = MetroBentoAccentText,
                                containerColor = MetroSurface,
                                labelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = MetroCardBorder,
                                selectedBorderColor = MetroBentoAccent,
                                enabled = true,
                                selected = selected
                            ),
                            modifier = Modifier.testTag("filter_opt_${opt.name}")
                        )
                    }
                }
            }
        }

        // Recommended Routes Header
        item {
            Text(
                text = "RECOMMENDED ITINERARIES (${routes.size})",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        // Journey Route Cards
        items(routes) { route ->
            RouteCard(
                route = route,
                onSave = { viewModel.saveRoute(route) }
            )
        }

        // Saved Routes Section
        if (savedRoutes.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Text(
                        text = "SAVED ROUTES (${savedRoutes.size})",
                        color = Color(0xFFFCCC0A),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    savedRoutes.forEach { saved ->
                        Surface(
                            color = MetroSurface,
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, MetroCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${saved.originName} ➔ ${saved.destinationName}",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${saved.totalMinutes} mins • ${saved.transferCount} transfers • ${saved.filterType}",
                                        color = MetroTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.deleteSavedRoute(saved.id) },
                                    modifier = Modifier.testTag("delete_saved_route_${saved.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Saved Route", tint = MetroRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RouteCard(
    route: JourneyRoute,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MetroSurface,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MetroCardBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("route_card_${route.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header: Duration & Carbon Saved
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${route.totalMinutes} MIN",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• ${route.transferCount} Transfers",
                        color = MetroTextSecondary,
                        fontSize = 13.sp
                    )
                }

                IconButton(
                    onClick = onSave,
                    modifier = Modifier.testTag("save_route_button_${route.id}")
                ) {
                    Icon(Icons.Default.BookmarkBorder, contentDescription = "Save Route", tint = Color(0xFFFCCC0A))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Legs
            route.legs.forEachIndexed { idx, leg ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SubwayLineBadge(line = leg.line, size = 26.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${leg.boardStation.name} to ${leg.alightStation.name}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${leg.intermediateStopsCount} stops • ${leg.estimatedMinutes} mins • ${leg.recommendedCarriage}",
                            color = MetroTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                if (idx < route.legs.size - 1) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(16.dp)
                                .background(MetroCardBorder)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("Transfer at ${leg.alightStation.name}", fontSize = 10.sp, color = Color(0xFFFCCC0A))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MetroCardBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Platform Intelligence Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MetroGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${route.totalWalkingMeters}m walking", color = MetroGreen, fontSize = 11.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Co2, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${route.carbonSavedKg} kg CO₂ saved", color = Color(0xFF00E5FF), fontSize = 11.sp)
                }
            }
        }
    }
}

