package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SubwayStation
import com.example.ui.components.SubwayLineBadge
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroBentoAccent
import com.example.ui.theme.MetroBentoAccentText
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroGreen
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.MetroViewModel

@Composable
fun PlatformTwinScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val selectedStation by viewModel.selectedStation.collectAsState()
    var showMenu by remember { mutableStateOf(false) }

    val station = selectedStation ?: viewModel.stations.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "STATION DIGITAL TWIN",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Platform geometry, carriage exit alignment & station health",
                    color = MetroTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Station Selector Dropdown Bento Card
        item {
            Box {
                OutlinedButton(
                    onClick = { showMenu = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, MetroCardBorder),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("digital_twin_station_select")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Subway, contentDescription = null, tint = Color(0xFF00E5FF))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("SELECT DIGITAL TWIN STATION", fontSize = 10.sp, color = MetroTextSecondary)
                            Text(station.name, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MetroTextSecondary)
                    }
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    viewModel.stations.forEach { st ->
                        DropdownMenuItem(
                            text = { Text(st.name) },
                            onClick = {
                                viewModel.selectStation(st)
                                showMenu = false
                            }
                        )
                    }
                }
            }
        }

        // Lines Badges
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("SERVICED LINES: ", fontSize = 11.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
                station.lines.forEach { line ->
                    SubwayLineBadge(line = line, size = 24.dp)
                }
            }
        }

        // Platform Carriage Exit Alignment Geometry Diagram
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "PLATFORM CARRIAGE ALIGNMENT",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Train carriages layout representation (1 to 8 cars)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        (1..8).forEach { carNum ->
                            val isQuiet = carNum == station.quietCarRecommended
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isQuiet) MetroGreen else Color(0xFF2D3035)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "C$carNum",
                                    color = if (isQuiet) Color.Black else Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Exits Info
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExitInfoRow(label = "FRONT CARS (1-3)", info = station.bestCarriageExitFront, color = MetroGreen)
                        ExitInfoRow(label = "MIDDLE CARS (4-5)", info = station.bestCarriageExitMiddle, color = Color(0xFFFCCC0A))
                        ExitInfoRow(label = "REAR CARS (6-8)", info = station.bestCarriageExitRear, color = Color(0xFF00E5FF))
                    }
                }
            }
        }

        // Escalators & Elevators Live Health Gauges (Bento 2-Col Grid)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Escalators Card
                Surface(
                    color = MetroSurface,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, MetroCardBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Stairs, contentDescription = null, tint = MetroGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ESCALATORS", fontSize = 10.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${station.escalatorsWorking}/${station.escalatorsTotal}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text("100% Operational", fontSize = 11.sp, color = MetroGreen, fontWeight = FontWeight.Medium)
                    }
                }

                // Elevators Card
                Surface(
                    color = MetroSurface,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, MetroCardBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Elevator, contentDescription = null, tint = Color(0xFF00E5FF))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ELEVATORS", fontSize = 10.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${station.elevatorsWorking}/${station.elevatorsTotal}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text("ADA Accessible", fontSize = 11.sp, color = Color(0xFF00E5FF), fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // Platform Crowding Density & Amenities
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("LOCAL PLATFORM AMENITIES", fontSize = 12.sp, color = Color(0xFFFCCC0A), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    AmenityRow(icon = Icons.Default.Coffee, label = "Coffee & Beverage", value = station.nearbyCoffee)
                    Spacer(modifier = Modifier.height(8.dp))
                    AmenityRow(icon = Icons.Default.Fastfood, label = "Food Concourse", value = station.nearbyFood)
                    Spacer(modifier = Modifier.height(8.dp))
                    AmenityRow(icon = Icons.Default.LocalPolice, label = "MTA / NYPD Precinct", value = station.nearbyPolice)
                }
            }
        }
    }
}

@Composable
fun ExitInfoRow(label: String, info: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(label, fontSize = 10.sp, color = MetroTextSecondary, fontWeight = FontWeight.Bold)
            Text(info, fontSize = 12.sp, color = Color.White)
        }
    }
}

@Composable
fun AmenityRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(label, fontSize = 10.sp, color = MetroTextSecondary)
            Text(value, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

