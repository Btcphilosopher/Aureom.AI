package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MetroBackground = Color(0xFF0F1113)
val MetroSurface = Color(0xFF1C1F22)
val MetroSurfaceVariant = Color(0xFF1A1C1E)
val MetroCardBorder = Color(0xFF2D3035)

val MetroBentoAccent = Color(0xFFD1E4FF)
val MetroBentoAccentText = Color(0xFF001D36)
val MetroBentoAccentBadge = Color(0xFF003366)
val MetroMtaBlue = Color(0xFF0039A6)

val MetroCyan = Color(0xFF00E5FF)
val MetroAmber = Color(0xFFFCCC0A)
val MetroRed = Color(0xFFEE352E)
val MetroGreen = Color(0xFF4ADE80)
val MetroPurple = Color(0xFFB933AD)

val MetroTextPrimary = Color(0xFFE2E2E6)
val MetroTextSecondary = Color(0xFF909194)
val MetroTextMuted = Color(0xFF5F6267)

