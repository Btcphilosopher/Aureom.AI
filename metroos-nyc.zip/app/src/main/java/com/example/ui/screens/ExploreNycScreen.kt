package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroBentoAccent
import com.example.ui.theme.MetroBentoAccentText
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroGreen
import com.example.ui.theme.MetroRed
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.MetroViewModel

@Composable
fun ExploreNycScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val attractions = viewModel.repository.attractions
    var rideCount by remember { mutableIntStateOf(12) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "TOURIST & LOCAL DISCOVERY",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Landmarks, walking connections & OMNY travel pass ROI calculator",
                    color = MetroTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Hero Image Banner Bento Card
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Image(
                        painter = painterResource(id = R.drawable.img_subway_terminal_hero_1785689068969),
                        contentDescription = "MetroOS NYC Map Banner",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("NYC SUBWAY DIGITAL MAP OS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("472 Stations • 27 Subway Lines • Full Offline Map Engine Included", color = MetroTextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        // OMNY Travel Pass ROI Calculator Bento Card
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFFFCCC0A))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("OMNY vs UNLIMITED METROCARD CALCULATOR", color = Color(0xFFFCCC0A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Estimated weekly rides: $rideCount", color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = rideCount.toFloat(),
                        onValueChange = { rideCount = it.toInt() },
                        valueRange = 1f..30f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFCCC0A),
                            activeTrackColor = Color(0xFFFCCC0A),
                            inactiveTrackColor = MetroCardBorder
                        ),
                        modifier = Modifier.testTag("omny_rides_slider")
                    )

                    val singleFareTotal = rideCount * 2.90
                    val omnyCap = 34.00 // OMNY 7-day cap threshold

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Standard Pay-Per-Ride", fontSize = 10.sp, color = MetroTextSecondary)
                            Text("$${String.format("%.2f", singleFareTotal)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("OMNY 7-Day Fare Cap", fontSize = 10.sp, color = MetroTextSecondary)
                            Text("$${String.format("%.2f", kotlin.math.min(singleFareTotal, omnyCap))}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MetroGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (singleFareTotal >= 34.00) "💡 Recommendation: OMNY automatically caps fares at $34.00 after 12 rides!" else "💡 Recommendation: Pay-per-ride is cheaper for under 12 rides.",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Top Attractions Header
        item {
            Text(
                text = "FEATURED NYC DESTINATIONS",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(attractions) { attraction ->
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("attraction_card_${attraction.name.take(6)}")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = MetroRed, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(attraction.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${attraction.category} • ${attraction.description}", color = MetroTextSecondary, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MetroGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${attraction.walkingMinutes} min walk from ${attraction.nearestStationName}", color = MetroGreen, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

