package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DisruptionAlert
import com.example.ui.components.SubwayLineBadge
import com.example.ui.theme.MetroBackground
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroGreen
import com.example.ui.theme.MetroRed
import com.example.ui.theme.MetroSurface
import com.example.ui.theme.MetroTextMuted
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.MetroViewModel

@Composable
fun DisruptionEngineScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val alerts by viewModel.alerts.collectAsState()
    val trains by viewModel.realTimeTrains.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MetroBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AI DISRUPTION ENGINE",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Machine learning predictive analytics (XGBoost/LSTM) for signal failure & delays",
                    color = MetroTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Predictive Failure Models Overview (Bento Card)
        item {
            Surface(
                color = MetroSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MetroCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "ML NETWORK HEALTH METRICS",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PredictiveMetric(label = "Signal Failure Risk", value = "4.2%", color = MetroGreen)
                        PredictiveMetric(label = "Flooding Risk", value = "0.8%", color = MetroGreen)
                        PredictiveMetric(label = "Power Outage Risk", value = "1.5%", color = MetroGreen)
                    }
                }
            }
        }

        // Active Alerts Header
        item {
            Text(
                text = "ACTIVE SERVICE ALERTS & ML ADVISORIES (${alerts.size})",
                color = Color(0xFFFCCC0A),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(alerts) { alert ->
            DisruptionAlertCard(alert = alert)
        }

        // Live Headway Monitored Trains
        item {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Text(
                    text = "LIVE HEADWAY & SIGNAL MONITOR (${trains.take(6).size} TRAINS)",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                trains.take(6).forEach { train ->
                    Surface(
                        color = MetroSurface,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MetroCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SubwayLineBadge(line = train.line, size = 24.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Train ${train.trainId}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(train.signalStatus, color = if (train.delayMinutes > 0) Color(0xFFFCCC0A) else MetroGreen, fontSize = 10.sp)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${train.speedMph} MPH", color = Color(0xFF00E5FF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Occupancy: ${train.occupancyPercentage}%", color = MetroTextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PredictiveMetric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        Spacer(modifier = Modifier.height(2.dp))
        Text(label, fontSize = 10.sp, color = MetroTextSecondary)
    }
}

@Composable
fun DisruptionAlertCard(alert: DisruptionAlert) {
    Surface(
        color = MetroSurface,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, alert.severity.color.copy(alpha = 0.8f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("disruption_alert_${alert.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SubwayLineBadge(line = alert.line, size = 26.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = alert.title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(alert.summary, color = MetroTextSecondary, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ML Failure Risk: ${alert.failureProbabilityPercent}%",
                    color = alert.severity.color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Est. Resolution: ${alert.estimatedResolutionTime}",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.sp
                )
            }
        }
    }
}

