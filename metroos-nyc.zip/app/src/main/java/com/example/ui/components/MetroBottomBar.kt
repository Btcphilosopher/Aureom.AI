package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MetroBentoAccent
import com.example.ui.theme.MetroBentoAccentText
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroSurfaceVariant
import com.example.ui.theme.MetroTextSecondary
import com.example.viewmodel.NavigationTab

@Composable
fun MetroBottomBar(
    currentTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MetroSurfaceVariant,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        border = BorderStroke(1.dp, MetroCardBorder),
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            tonalElevation = 0.dp
        ) {
            NavigationTab.values().forEach { tab ->
                val isSelected = currentTab == tab
                val icon = when (tab) {
                    NavigationTab.LIVE_MAP -> Icons.Default.Map
                    NavigationTab.JOURNEY_PLANNER -> Icons.Default.Directions
                    NavigationTab.PLATFORM_TWIN -> Icons.Default.Layers
                    NavigationTab.DISRUPTION_AI -> Icons.Default.Warning
                    NavigationTab.TERMINAL_CONTROL -> Icons.Default.Analytics
                    NavigationTab.AI_ASSISTANT -> Icons.Default.SmartToy
                    NavigationTab.EXPLORE_NYC -> Icons.Default.Explore
                }

                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onTabSelected(tab) },
                    icon = {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) MetroBentoAccentText else MetroTextSecondary
                        )
                    },
                    label = {
                        Text(
                            text = tab.title,
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else MetroTextSecondary
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MetroBentoAccent
                    ),
                    modifier = Modifier.testTag("nav_tab_${tab.name}")
                )
            }
        }
    }
}

