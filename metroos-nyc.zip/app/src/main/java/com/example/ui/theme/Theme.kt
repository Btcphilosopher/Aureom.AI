package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MetroDarkColorScheme = darkColorScheme(
    primary = MetroMtaBlue,
    onPrimary = Color.White,
    primaryContainer = MetroBentoAccent,
    onPrimaryContainer = MetroBentoAccentText,
    secondary = MetroCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF1C2A3A),
    onSecondaryContainer = MetroCyan,
    background = MetroBackground,
    onBackground = MetroTextPrimary,
    surface = MetroSurface,
    onSurface = MetroTextPrimary,
    surfaceVariant = MetroSurfaceVariant,
    onSurfaceVariant = MetroTextSecondary,
    outline = MetroCardBorder,
    error = MetroRed,
    onError = Color.White
)

@Composable
fun MetroOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MetroDarkColorScheme,
        typography = Typography,
        content = content
    )
}
