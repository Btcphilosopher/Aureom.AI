package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SubwayRepository
import com.example.db.SavedRouteEntity
import com.example.model.*
import com.example.service.GeminiTransitService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class NavigationTab(val title: String, val iconName: String) {
    LIVE_MAP("Live Map", "map"),
    JOURNEY_PLANNER("AI Planner", "directions"),
    PLATFORM_TWIN("Digital Twin", "layers"),
    DISRUPTION_AI("Disruptions", "warning"),
    TERMINAL_CONTROL("Bloomberg OS", "analytics"),
    AI_ASSISTANT("Metro AI", "smart_toy"),
    EXPLORE_NYC("NYC Guide", "explore")
}

data class ChatMessage(
    val id: String,
    val sender: String, // "USER" or "METRO_AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AccessibilitySettings(
    val highContrast: Boolean = false,
    val largeText: Boolean = false,
    val wheelchairOnly: Boolean = false,
    val colorblindMode: Boolean = false
)

class MetroViewModel(application: Application) : AndroidViewModel(application) {
    val repository = SubwayRepository(application.applicationContext)
    private val geminiService = GeminiTransitService()

    private val _currentTab = MutableStateFlow(NavigationTab.LIVE_MAP)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    val stations: List<SubwayStation> = repository.stations

    private val _selectedStation = MutableStateFlow<SubwayStation?>(repository.stations.first())
    val selectedStation: StateFlow<SubwayStation?> = _selectedStation.asStateFlow()

    val realTimeTrains: StateFlow<List<RealtimeTrain>> = repository.trainsFlow
    val alerts: StateFlow<List<DisruptionAlert>> = repository.alertsFlow
    val savedRoutes: StateFlow<List<SavedRouteEntity>> = repository.savedRoutesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Journey Planner State
    private val _originStation = MutableStateFlow<SubwayStation>(repository.stations[0]) // Grand Central
    val originStation: StateFlow<SubwayStation> = _originStation.asStateFlow()

    private val _destinationStation = MutableStateFlow<SubwayStation>(repository.stations[1]) // Times Sq
    val destinationStation: StateFlow<SubwayStation> = _destinationStation.asStateFlow()

    private val _selectedFilter = MutableStateFlow(RouteFilterOption.FASTEST)
    val selectedFilter: StateFlow<RouteFilterOption> = _selectedFilter.asStateFlow()

    private val _journeyRoutes = MutableStateFlow<List<JourneyRoute>>(emptyList())
    val journeyRoutes: StateFlow<List<JourneyRoute>> = _journeyRoutes.asStateFlow()

    // Energy metrics
    val energyMetrics = MutableStateFlow(EnergyDashboardData())

    // AI Chat Messages
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                "1", "METRO_AI",
                "👋 Welcome to **MetroOS New York**. I'm your AI Transit Navigator. Ask me anything about routes, quiet carriages, coffee spots near platforms, or real-time MTA line updates!"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Accessibility settings
    private val _accessibility = MutableStateFlow(AccessibilitySettings())
    val accessibility: StateFlow<AccessibilitySettings> = _accessibility.asStateFlow()

    init {
        calculateRoutes()
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun selectStation(station: SubwayStation) {
        _selectedStation.value = station
    }

    fun setOrigin(station: SubwayStation) {
        _originStation.value = station
        calculateRoutes()
    }

    fun setDestination(station: SubwayStation) {
        _destinationStation.value = station
        calculateRoutes()
    }

    fun setFilter(filter: RouteFilterOption) {
        _selectedFilter.value = filter
        calculateRoutes()
    }

    fun swapOriginDestination() {
        val temp = _originStation.value
        _originStation.value = _destinationStation.value
        _destinationStation.value = temp
        calculateRoutes()
    }

    private fun calculateRoutes() {
        _journeyRoutes.value = repository.findJourneyRoutes(
            _originStation.value,
            _destinationStation.value,
            _selectedFilter.value
        )
    }

    fun saveRoute(route: JourneyRoute) {
        viewModelScope.launch {
            repository.saveRoute(route)
        }
    }

    fun deleteSavedRoute(id: String) {
        viewModelScope.launch {
            repository.deleteSavedRoute(id)
        }
    }

    fun sendChatMessage(queryText: String) {
        if (queryText.isBlank()) return
        val userMsg = ChatMessage(System.currentTimeMillis().toString(), "USER", queryText)
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch {
            val contextInfo = "Selected Origin: ${originStation.value.name}, Destination: ${destinationStation.value.name}. Active Trains: ${realTimeTrains.value.size}. Active Alerts: ${alerts.value.size}."
            val replyText = geminiService.queryTransitAssistant(queryText, contextInfo)
            val aiMsg = ChatMessage((System.currentTimeMillis() + 1).toString(), "METRO_AI", replyText)
            _chatMessages.value = _chatMessages.value + aiMsg
            _isAiThinking.value = false
        }
    }

    fun toggleHighContrast() {
        _accessibility.value = _accessibility.value.copy(highContrast = !_accessibility.value.highContrast)
    }

    fun toggleLargeText() {
        _accessibility.value = _accessibility.value.copy(largeText = !_accessibility.value.largeText)
    }

    fun toggleWheelchairOnly() {
        _accessibility.value = _accessibility.value.copy(wheelchairOnly = !_accessibility.value.wheelchairOnly)
        if (_accessibility.value.wheelchairOnly) {
            setFilter(RouteFilterOption.ACCESSIBLE)
        }
    }

    fun toggleColorblindMode() {
        _accessibility.value = _accessibility.value.copy(colorblindMode = !_accessibility.value.colorblindMode)
    }
}
