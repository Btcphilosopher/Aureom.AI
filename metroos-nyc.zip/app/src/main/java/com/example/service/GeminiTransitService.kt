package com.example.service

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class GeminiTransitService {
    private val apiKey: String = BuildConfig.GEMINI_API_KEY

    suspend fun queryTransitAssistant(userQuery: String, contextInfo: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "YOUR_GEMINI_API_KEY") {
            return@withContext generateOfflineAiResponse(userQuery)
        }

        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000

            val promptText = """
                You are MetroOS AI, the expert transit navigation intelligence system for the New York City Subway network.
                User Context: $contextInfo
                User Prompt: $userQuery

                Provide a concise, crisp, helpful, Bloomberg Terminal style answer with bullet points or bold station/line names where relevant.
            """.trimIndent()

            val requestBody = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", promptText)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)
            }

            OutputStreamWriter(conn.outputStream, "UTF-8").use { writer ->
                writer.write(requestBody.toString())
                writer.flush()
            }

            if (conn.responseCode == 200) {
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonResp = JSONObject(responseText)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", generateOfflineAiResponse(userQuery))
                    }
                }
            }
            return@withContext generateOfflineAiResponse(userQuery)
        } catch (e: Exception) {
            return@withContext generateOfflineAiResponse(userQuery)
        }
    }

    private fun generateOfflineAiResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("jfk") || q.contains("airport") -> {
                "✈️ **JFK Airport Route Recommendation**:\n- Take the **E train** or **LIRR** to Jamaica Station / Sutphin Blvd.\n- Transfer to the **JFK AirTrain** (Elevated Concourse, Car 2 aligned).\n- Total Travel Time: **38 mins** from Midtown. Carbon saved: 4.2 kg CO₂."
            }
            q.contains("quiet") || q.contains("car") || q.contains("carriage") -> {
                "🤫 **Quiet Carriage Advisory**:\n- On 4-5-6 trains, **Car 3** experiences 40% less noise and lower crowding density.\n- On 7 train, **Car 2** is recommended for quiet transit."
            }
            q.contains("coffee") || q.contains("food") -> {
                "☕ **Platform Coffee Recommendations**:\n- **Grand Central**: Irving Farm Coffee (Vanderbilt Hall Passage).\n- **Fulton St**: Black Fox Coffee (Dey St Concourse).\n- **Penn Station**: Stumptown Coffee (Moynihan Hall)."
            }
            else -> {
                "🚇 **MetroOS Intelligence Route Update**:\n- Network Status: **Normal CBTC Signal Synchronization** across 27 MTA subway lines.\n- Minimal walking transfer recommended via **Grand Central 42 St** or **Fulton Center**."
            }
        }
    }
}
