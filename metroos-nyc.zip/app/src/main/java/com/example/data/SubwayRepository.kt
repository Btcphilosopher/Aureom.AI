package com.example.data

import android.content.Context
import com.example.db.AlertEntity
import com.example.db.MetroDatabase
import com.example.db.SavedRouteEntity
import com.example.db.StationEntity
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class SubwayRepository(context: Context) {
    private val db = MetroDatabase.getDatabase(context)
    private val dao = db.metroDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // Pre-populated NYC Stations
    val stations = listOf(
        SubwayStation(
            id = "ST_GCT",
            name = "Grand Central - 42 St",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_456, SubwayLine.LINE_7, SubwayLine.LINE_S, SubwayLine.METRO_NORTH),
            latitude = 40.7527,
            longitude = -73.9772,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.HIGH,
            escalatorsWorking = 8, escalatorsTotal = 8,
            elevatorsWorking = 4, elevatorsTotal = 4,
            bestCarriageExitFront = "Exit 42nd St & Park Ave / Vanderbilt",
            bestCarriageExitMiddle = "Shuttle Passage to 7 Train / Metro-North",
            bestCarriageExitRear = "Lexington Ave & 43rd St Exit",
            nearbyCoffee = "Irving Farm (Vanderbilt Hall)",
            nearbyFood = "Grand Central Oyster Bar & Food Concourse",
            nearbyPolice = "MTA Police Station (Main Concourse)",
            quietCarRecommended = 3
        ),
        SubwayStation(
            id = "ST_TSQ",
            name = "Times Square - 42 St",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_123, SubwayLine.LINE_7, SubwayLine.LINE_ACE, SubwayLine.LINE_NQRW, SubwayLine.LINE_S, SubwayLine.PATH),
            latitude = 40.7580,
            longitude = -73.9855,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.CRITICAL,
            escalatorsWorking = 10, escalatorsTotal = 12,
            elevatorsWorking = 5, elevatorsTotal = 6,
            bestCarriageExitFront = "Exit 42nd St & Broadway (Ballroom Entrance)",
            bestCarriageExitMiddle = "Underground Passage to Port Authority A/C/E",
            bestCarriageExitRear = "Exit 40th St & 7th Ave",
            nearbyCoffee = "Blue Bottle Coffee (42nd St)",
            nearbyFood = "Junior's Cheesecake / Carmine's",
            nearbyPolice = "NYPD Substation (Times Square)",
            quietCarRecommended = 2
        ),
        SubwayStation(
            id = "ST_PENN",
            name = "34 St - Penn Station",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_123, SubwayLine.LINE_ACE, SubwayLine.LIRR, SubwayLine.PATH, SubwayLine.LINE_BDFM),
            latitude = 40.7506,
            longitude = -73.9935,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.HIGH,
            escalatorsWorking = 14, escalatorsTotal = 14,
            elevatorsWorking = 6, elevatorsTotal = 6,
            bestCarriageExitFront = "Moynihan Train Hall Entrance (8th Ave)",
            bestCarriageExitMiddle = "Penn Station Concourse (NJ Transit / Amtrak)",
            bestCarriageExitRear = "7th Ave & 33rd St Exit",
            nearbyCoffee = "Stumptown Coffee / Birch Coffee",
            nearbyFood = "Moynihan Food Hall / Shake Shack",
            nearbyPolice = "Amtrak / MTA Police Command",
            quietCarRecommended = 4
        ),
        SubwayStation(
            id = "ST_W4ST",
            name = "West 4th St - Wash Sq",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_ACE, SubwayLine.LINE_BDFM),
            latitude = 40.7323,
            longitude = -74.0004,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.MODERATE,
            escalatorsWorking = 6, escalatorsTotal = 6,
            elevatorsWorking = 2, elevatorsTotal = 2,
            bestCarriageExitFront = "Exit 6th Ave & 8th St",
            bestCarriageExitMiddle = "Direct Upper/Lower Cross-Platform Transfer",
            bestCarriageExitRear = "Exit Washington Square Park",
            nearbyCoffee = "Joe Coffee (W 4th St)",
            nearbyFood = "Mamoun's Falafel / Minetta Tavern",
            nearbyPolice = "NYPD 6th Precinct",
            quietCarRecommended = 5
        ),
        SubwayStation(
            id = "ST_UNION",
            name = "14 St - Union Square",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_456, SubwayLine.LINE_L, SubwayLine.LINE_NQRW),
            latitude = 40.7357,
            longitude = -73.9906,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.HIGH,
            escalatorsWorking = 6, escalatorsTotal = 8,
            elevatorsWorking = 3, elevatorsTotal = 3,
            bestCarriageExitFront = "Union Square East & 15th St",
            bestCarriageExitMiddle = "L Line Cross-Mezzanine Transfer",
            bestCarriageExitRear = "14th St & Broadway Exit",
            nearbyCoffee = "Everyman Espresso",
            nearbyFood = "Union Square Greenmarket / Daily Provisions",
            nearbyPolice = "MTA Transit District 4",
            quietCarRecommended = 1
        ),
        SubwayStation(
            id = "ST_FULTON",
            name = "Fulton St Center",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_123, SubwayLine.LINE_456, SubwayLine.LINE_ACE, SubwayLine.LINE_JZ, SubwayLine.PATH),
            latitude = 40.7104,
            longitude = -74.0092,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.MODERATE,
            escalatorsWorking = 16, escalatorsTotal = 16,
            elevatorsWorking = 8, elevatorsTotal = 8,
            bestCarriageExitFront = "Fulton Center Oculus Atrium",
            bestCarriageExitMiddle = "PATH / World Trade Center Concourse",
            bestCarriageExitRear = "Dey St Underground Pass",
            nearbyCoffee = "Black Fox Coffee / Matto",
            nearbyFood = "Eataly NYC Downtown / Shake Shack",
            nearbyPolice = "NYPD 1st Precinct",
            quietCarRecommended = 3
        ),
        SubwayStation(
            id = "ST_COLUMBUS",
            name = "59 St - Columbus Circle",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_123, SubwayLine.LINE_ACE, SubwayLine.LINE_BDFM),
            latitude = 40.7683,
            longitude = -73.9819,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.MODERATE,
            escalatorsWorking = 8, escalatorsTotal = 8,
            elevatorsWorking = 4, elevatorsTotal = 4,
            bestCarriageExitFront = "Central Park South Exit",
            bestCarriageExitMiddle = "Turnstyle Underground Market",
            bestCarriageExitRear = "58th St & 8th Ave",
            nearbyCoffee = "Birch Coffee / Blue Bottle",
            nearbyFood = "Turnstyle Underground Food Hall",
            nearbyPolice = "NYPD Central Park Precinct",
            quietCarRecommended = 4
        ),
        SubwayStation(
            id = "ST_HUDSON",
            name = "34 St - Hudson Yards",
            borough = "Manhattan",
            lines = listOf(SubwayLine.LINE_7),
            latitude = 40.7550,
            longitude = -74.0022,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.LOW,
            escalatorsWorking = 12, escalatorsTotal = 12,
            elevatorsWorking = 4, elevatorsTotal = 4,
            bestCarriageExitFront = "Hudson Park & Boulevard Exit",
            bestCarriageExitMiddle = "High Line Direct Connection",
            bestCarriageExitRear = "The Vessel / Shops at Hudson Yards",
            nearbyCoffee = "Bluestone Lane Hudson Yards",
            nearbyFood = "Mercado Little Spain / Peak",
            nearbyPolice = "NYPD 10th Precinct",
            quietCarRecommended = 2
        ),
        SubwayStation(
            id = "ST_ATLANTIC",
            name = "Atlantic Av - Barclays Ctr",
            borough = "Brooklyn",
            lines = listOf(SubwayLine.LINE_123, SubwayLine.LINE_456, SubwayLine.LINE_BDFM, SubwayLine.LINE_NQRW, SubwayLine.LIRR),
            latitude = 40.6840,
            longitude = -73.9780,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.HIGH,
            escalatorsWorking = 10, escalatorsTotal = 10,
            elevatorsWorking = 5, elevatorsTotal = 5,
            bestCarriageExitFront = "Barclays Center Arena Plaza Exit",
            bestCarriageExitMiddle = "LIRR Atlantic Terminal Connection",
            bestCarriageExitRear = "Flatbush Ave & Hanson Place",
            nearbyCoffee = "Devoción Specialty Coffee",
            nearbyFood = "Shake Shack / Target Food Hall",
            nearbyPolice = "MTA Transit District 32",
            quietCarRecommended = 3
        ),
        SubwayStation(
            id = "ST_JFK_AIRTRAIN",
            name = "Jamaica Center / Sutphin Blvd (JFK)",
            borough = "Queens",
            lines = listOf(SubwayLine.LINE_ACE, SubwayLine.LINE_JZ, SubwayLine.AIRTRAIN, SubwayLine.LIRR),
            latitude = 40.7005,
            longitude = -73.8078,
            isAccessible = true,
            platformCrowdingDensity = CrowdingLevel.LOW,
            escalatorsWorking = 8, escalatorsTotal = 8,
            elevatorsWorking = 4, elevatorsTotal = 4,
            bestCarriageExitFront = "AirTrain JFK Skybridge Terminal",
            bestCarriageExitMiddle = "LIRR Jamaica Hub Direct Pass",
            bestCarriageExitRear = "Archer Ave & 148th St Exit",
            nearbyCoffee = "Dunkin' / Starbucks AirTrain Level",
            nearbyFood = "Jamaica Food Market",
            nearbyPolice = "Port Authority Police JFK",
            quietCarRecommended = 6
        )
    )

    // Initial Disruptions
    val initialAlerts = listOf(
        DisruptionAlert(
            id = "ALT_01",
            line = SubwayLine.LINE_7,
            title = "CBTC Signal Optimization in Progress",
            summary = "Express 7 trains running with 3-minute headway delay near Hunters Point Av due to signal calibration.",
            severity = AlertSeverity.WARNING,
            failureProbabilityPercent = 78,
            causeType = "Signal Calibration",
            estimatedResolutionTime = "25 mins"
        ),
        DisruptionAlert(
            id = "ALT_02",
            line = SubwayLine.LINE_456,
            title = "Peak Demand Capacity Balancing",
            summary = "Lexington Av Line trains running at max frequency. Minor platform crowding at 42 St.",
            severity = AlertSeverity.INFO,
            failureProbabilityPercent = 14,
            causeType = "High Passenger Flow",
            estimatedResolutionTime = "Ongoing Peak"
        ),
        DisruptionAlert(
            id = "ALT_03",
            line = SubwayLine.LINE_L,
            title = "Water Inflow Prevention Sensors Active",
            summary = "Trackbed drainage pumps operating smoothly under 14th St Tunnel.",
            severity = AlertSeverity.INFO,
            failureProbabilityPercent = 5,
            causeType = "Weather Monitoring",
            estimatedResolutionTime = "Normal Operation"
        )
    )

    // Real-time train updates state
    private val _trainsFlow = MutableStateFlow<List<RealtimeTrain>>(emptyList())
    val trainsFlow: StateFlow<List<RealtimeTrain>> = _trainsFlow.asStateFlow()

    private val _alertsFlow = MutableStateFlow<List<DisruptionAlert>>(initialAlerts)
    val alertsFlow: StateFlow<List<DisruptionAlert>> = _alertsFlow.asStateFlow()

    val savedRoutesFlow: Flow<List<SavedRouteEntity>> = dao.getSavedRoutes()

    init {
        // Initialize room db with station entities
        scope.launch {
            dao.insertStations(stations.map { s ->
                StationEntity(
                    id = s.id,
                    name = s.name,
                    borough = s.borough,
                    lineCodes = s.lines.joinToString(",") { it.name },
                    latitude = s.latitude,
                    longitude = s.longitude,
                    isAccessible = s.isAccessible,
                    crowdingDensity = s.platformCrowdingDensity.name,
                    escalatorsWorking = s.escalatorsWorking,
                    escalatorsTotal = s.escalatorsTotal,
                    elevatorsWorking = s.elevatorsWorking,
                    elevatorsTotal = s.elevatorsTotal,
                    exitFront = s.bestCarriageExitFront,
                    exitMiddle = s.bestCarriageExitMiddle,
                    exitRear = s.bestCarriageExitRear,
                    nearbyCoffee = s.nearbyCoffee,
                    nearbyFood = s.nearbyFood,
                    nearbyPolice = s.nearbyPolice,
                    quietCarRecommended = s.quietCarRecommended
                )
            })
            dao.insertAlerts(initialAlerts.map { a ->
                AlertEntity(
                    id = a.id,
                    lineCode = a.line.name,
                    title = a.title,
                    summary = a.summary,
                    severity = a.severity.name,
                    failureProbability = a.failureProbabilityPercent,
                    causeType = a.causeType,
                    estimatedResolution = a.estimatedResolutionTime
                )
            })
        }

        // Start real-time train positioning engine loop
        scope.launch {
            var tick = 0
            while (true) {
                tick++
                val generatedTrains = mutableListOf<RealtimeTrain>()
                stations.forEachIndexed { idx, station ->
                    val nextStation = stations[(idx + 1) % stations.size]
                    station.lines.take(2).forEachIndexed { lineIdx, line ->
                        val trainId = "TR_${line.code}_${idx}_$lineIdx"
                        val progress = ((tick * 0.15 + idx * 0.25) % 1.0).toFloat()
                        val speed = (28..48).random()
                        val occupancy = (20..85).random()
                        val delayMin = if (line == SubwayLine.LINE_7) 3 else (0..1).random()

                        generatedTrains.add(
                            RealtimeTrain(
                                trainId = trainId,
                                line = line,
                                destination = if (idx % 2 == 0) "Uptown / Bronx" else "Downtown / Brooklyn",
                                currentStationId = station.id,
                                nextStationId = nextStation.id,
                                progress = progress,
                                speedMph = speed,
                                occupancyPercentage = occupancy,
                                delayMinutes = delayMin,
                                signalStatus = if (delayMin > 2) "HOLD (CBTC SIGNAL)" else "PROCEED 40MPH",
                                maintenanceFlag = line == SubwayLine.LINE_7,
                                headwayMinutes = 3,
                                predictedCongestionNextStation = (occupancy * 0.9).roundToInt()
                            )
                        )
                    }
                }
                _trainsFlow.value = generatedTrains
                delay(1500)
            }
        }
    }

    // AI Multi-criteria Journey Routing Engine
    fun findJourneyRoutes(
        origin: SubwayStation,
        destination: SubwayStation,
        filter: RouteFilterOption
    ): List<JourneyRoute> {
        val baseMinutes = estimateTravelMinutes(origin, destination)
        val directLines = origin.lines.intersect(destination.lines.toSet())

        val routes = mutableListOf<JourneyRoute>()

        if (directLines.isNotEmpty()) {
            val bestLine = directLines.first()
            routes.add(
                JourneyRoute(
                    id = "ROUTE_DIRECT_${filter.name}",
                    origin = origin,
                    destination = destination,
                    totalMinutes = baseMinutes,
                    totalWalkingMeters = 120,
                    transferCount = 0,
                    legs = listOf(
                        RouteLeg(
                            line = bestLine,
                            boardStation = origin,
                            alightStation = destination,
                            intermediateStopsCount = abs(stations.indexOf(origin) - stations.indexOf(destination)).coerceAtLeast(1),
                            estimatedMinutes = baseMinutes,
                            recommendedCarriage = "Car ${origin.quietCarRecommended} (Quiet & Exit Aligned)",
                            platformExit = origin.bestCarriageExitFront,
                            crowdStatus = origin.platformCrowdingDensity
                        )
                    ),
                    carbonSavedKg = 1.45,
                    isAccessible = origin.isAccessible && destination.isAccessible,
                    filterType = filter,
                    quietCarRecommended = origin.quietCarRecommended
                )
            )
        }

        // Add 1-transfer route option
        val transferStation = stations.find { s ->
            s.id != origin.id && s.id != destination.id &&
            s.lines.intersect(origin.lines.toSet()).isNotEmpty() &&
            s.lines.intersect(destination.lines.toSet()).isNotEmpty()
        } ?: stations[1]

        val line1 = origin.lines.intersect(transferStation.lines.toSet()).firstOrNull() ?: origin.lines.first()
        val line2 = destination.lines.intersect(transferStation.lines.toSet()).firstOrNull() ?: destination.lines.first()
        val leg1Minutes = estimateTravelMinutes(origin, transferStation)
        val leg2Minutes = estimateTravelMinutes(transferStation, destination)

        routes.add(
            JourneyRoute(
                id = "ROUTE_TRANSFER_${filter.name}",
                origin = origin,
                destination = destination,
                totalMinutes = leg1Minutes + leg2Minutes + 3,
                totalWalkingMeters = 240,
                transferCount = 1,
                legs = listOf(
                    RouteLeg(
                        line = line1,
                        boardStation = origin,
                        alightStation = transferStation,
                        intermediateStopsCount = 2,
                        estimatedMinutes = leg1Minutes,
                        recommendedCarriage = "Car 3 (Mezzanine Transfer)",
                        platformExit = transferStation.bestCarriageExitMiddle,
                        crowdStatus = CrowdingLevel.LOW
                    ),
                    RouteLeg(
                        line = line2,
                        boardStation = transferStation,
                        alightStation = destination,
                        intermediateStopsCount = 3,
                        estimatedMinutes = leg2Minutes,
                        recommendedCarriage = "Car 4 (Exit Aligned)",
                        platformExit = destination.bestCarriageExitFront,
                        crowdStatus = CrowdingLevel.MODERATE
                    )
                ),
                carbonSavedKg = 1.82,
                isAccessible = origin.isAccessible && transferStation.isAccessible && destination.isAccessible,
                filterType = filter,
                quietCarRecommended = 3
            )
        )

        // Apply filtering preferences
        return when (filter) {
            RouteFilterOption.FASTEST -> routes.sortedBy { it.totalMinutes }
            RouteFilterOption.FEWEST_TRANSFERS -> routes.sortedBy { it.transferCount }
            RouteFilterOption.LEAST_WALKING -> routes.sortedBy { it.totalWalkingMeters }
            RouteFilterOption.ACCESSIBLE -> routes.filter { it.isAccessible }
            RouteFilterOption.QUIETEST -> routes.sortedBy { it.transferCount + it.totalMinutes }
            RouteFilterOption.RAIN_FRIENDLY -> routes
            RouteFilterOption.LATE_NIGHT_SAFE -> routes.sortedBy { it.totalWalkingMeters }
        }
    }

    private fun estimateTravelMinutes(s1: SubwayStation, s2: SubwayStation): Int {
        val dist = kotlin.math.sqrt(
            Math.pow((s1.latitude - s2.latitude) * 111, 2.0) +
            Math.pow((s1.longitude - s2.longitude) * 85, 2.0)
        )
        return (dist * 2.8).roundToInt().coerceAtLeast(3)
    }

    suspend fun saveRoute(route: JourneyRoute) {
        dao.insertSavedRoute(
            SavedRouteEntity(
                id = route.id,
                originId = route.origin.id,
                destinationId = route.destination.id,
                originName = route.origin.name,
                destinationName = route.destination.name,
                totalMinutes = route.totalMinutes,
                transferCount = route.transferCount,
                filterType = route.filterType.name
            )
        )
    }

    suspend fun deleteSavedRoute(id: String) {
        dao.deleteSavedRoute(id)
    }

    // Top NYC Attractions
    val attractions = listOf(
        Attraction("Empire State Building", "Observation Deck", "ST_PENN", "34 St - Penn Station", 5, "World iconic 102-story landmark at 34th & 5th Ave."),
        Attraction("Central Park South", "Park & Nature", "ST_COLUMBUS", "59 St - Columbus Circle", 2, "843 acres of green parkland, lakes, and walking paths."),
        Attraction("Times Square Broadway", "Theater & Entertainment", "ST_TSQ", "Times Square - 42 St", 1, "Neon crossroads of the world and Broadway theater district."),
        Attraction("Grand Central Terminal", "Architecture & Dining", "ST_GCT", "Grand Central - 42 St", 0, "Beaux-Arts main concourse with celestial ceiling and Oyster Bar."),
        Attraction("The High Line & Vessel", "Modern Park & Art", "ST_HUDSON", "34 St - Hudson Yards", 3, "Elevated linear park built on historic freight rail track."),
        Attraction("One World Observatory", "Landmark", "ST_FULTON", "Fulton St Center", 4, "Panoramic view from Freedom Tower at World Trade Center."),
        Attraction("Barclays Center", "Sports & Concerts", "ST_ATLANTIC", "Atlantic Av - Barclays Ctr", 1, "Home arena for Brooklyn Nets and world tour concerts.")
    )
}
