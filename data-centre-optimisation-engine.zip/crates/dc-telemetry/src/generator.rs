use chrono::Utc;
use dc_core::telemetry::TelemetrySample;
use rand::Rng;

pub struct SyntheticTelemetryGenerator {
    base_it_load_kw: f64,
    base_ambient_temp_c: f64,
}

impl SyntheticTelemetryGenerator {
    pub fn new(base_it_load_kw: f64, base_ambient_temp_c: f64) -> Self {
        Self {
            base_it_load_kw,
            base_ambient_temp_c,
        }
    }

    pub fn generate_tick(&self, step: usize) -> Vec<TelemetrySample> {
        let mut rng = rand::thread_rng();
        let now = Utc::now();
        let mut samples = Vec::new();

        // Diurnal ambient temperature curve
        let hour_angle = ((step % 24) as f64 / 24.0) * std::f64::consts::PI * 2.0;
        let ambient = self.base_ambient_temp_c + 6.0 * hour_angle.sin() + rng.gen_range(-0.5..0.5);

        samples.push(TelemetrySample {
            timestamp: now,
            sensor_id: "WEATHER-AMB-01".into(),
            asset_id: "FACILITY-WEATHER-STATION".into(),
            metric_name: "ambient_dry_bulb_temperature".into(),
            value: ambient,
            unit: "°C".into(),
        });

        // IT Power with compute burst variations
        let it_variation = rng.gen_range(-150.0..250.0);
        let it_kw = self.base_it_load_kw + it_variation;

        samples.push(TelemetrySample {
            timestamp: now,
            sensor_id: "PDU-MAIN-01-KW".into(),
            asset_id: "PDU-ROW-01".into(),
            metric_name: "active_it_power".into(),
            value: it_kw,
            unit: "kW".into(),
        });

        // GPU Junction Temperatures
        for i in 1..=8 {
            let gpu_temp = 58.0 + (it_kw / self.base_it_load_kw) * 16.0 + rng.gen_range(-1.2..1.2);
            samples.push(TelemetrySample {
                timestamp: now,
                sensor_id: format!("SENS-GPU-H100-{:02}", i),
                asset_id: format!("GPU-NODE-{:02}", i),
                metric_name: "junction_temperature".into(),
                value: gpu_temp,
                unit: "°C".into(),
            });
        }

        samples
    }
}
