pub struct ExponentialMovingAverage {
    alpha: f64,
    current_val: Option<f64>,
}

impl ExponentialMovingAverage {
    pub fn new(alpha: f64) -> Self {
        Self {
            alpha: alpha.clamp(0.01, 0.99),
            current_val: None,
        }
    }

    pub fn update(&mut self, sample: f64) -> f64 {
        match self.current_val {
            Some(prev) => {
                let smoothed = self.alpha * sample + (1.0 - self.alpha) * prev;
                self.current_val = Some(smoothed);
                smoothed
            }
            None => {
                self.current_val = Some(sample);
                sample
            }
        }
    }
}
