use dc_core::types::*;
use dc_optimizer::objectives::{OptimizationConstraints, OptimizationWeights};
use dc_optimizer::solver::solve_master_optimization;
use dc_twin::graph::DataCentreTwinState;
use dc_twin::state::{evaluate_twin_snapshot, TwinRuntimeContext};

#[tokio::main]
async fn main() {
    env_logger::init();
    println!("============================================================");
    println!(" DATA CENTRE DIGITAL TWIN & REAL-TIME OPTIMISATION ENGINE   ");
    println!(" Rust Core Architecture: dc-core | dc-power | dc-cooling   ");
    println!("                          dc-compute | dc-twin | dc-opt     ");
    println!("============================================================");

    let twin = DataCentreTwinState {
        site_id: "SITE-EU-WEST-01".to_string(),
        name: "Hyperscale AI Supercomputing Facility Alpha".to_string(),
        tier: FacilityTier::Tier3,
        contracted_power_mw: 45.0,
        peak_power_limit_mw: 48.0,
        cooling_design_mw: 12.0,
        total_floor_area_sqm: 14500.0,
        rooms: vec![],
        ups_systems: vec![],
        battery_storage: vec![],
        backup_generators: vec![],
        chillers: vec![],
        cdu_loops: vec![],
    };

    let ctx = TwinRuntimeContext {
        current_time_epoch_s: 1723795200,
        spot_price_usd_per_mwh: 185.40,
        ambient_temp_c: 29.8,
        ambient_humidity_pct: 54.0,
        grid_carbon_g_co2_kwh: 245.0,
    };

    let snapshot = evaluate_twin_snapshot(&twin, &ctx);
    println!("[TELEMETRY SNAPSHOT]");
    println!("  Total Facility Power : {:.2} MW", snapshot.total_facility_power_mw);
    println!("  IT Load              : {:.2} MW", snapshot.it_power_mw);
    println!("  Instantaneous PUE    : {:.3}", snapshot.instantaneous_pue);
    println!("  Spot Price           : ${:.2}/MWh", snapshot.spot_electricity_price_per_mwh);
    println!("  Active Bottleneck    : {}", snapshot.active_bottleneck);

    let weights = OptimizationWeights::default();
    let constraints = OptimizationConstraints::default();
    let mut workloads = vec![];

    let plan = solve_master_optimization(&twin, &mut workloads, &ctx, &weights, &constraints);
    println!("\n[OPTIMISATION PLAN]");
    println!("  Mode                 : {}", plan.execution_mode);
    println!("  Recommended Grid MW  : {:.2} MW", plan.recommended_grid_mw);
    println!("  BESS Peak-Shaving    : {:.2} kW", plan.bess_action_kw);
    println!("  Hourly Cost Savings  : ${:.2}/hr", plan.hourly_savings_usd);
    println!("  Projected PUE        : {:.3}", plan.pue_projected);
    println!("  Margin Improvement   : +{:.1}%", plan.margin_improvement_pct);
}
