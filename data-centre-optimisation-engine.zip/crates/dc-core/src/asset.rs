use crate::types::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AssetLocation {
    pub site_id: String,
    pub building_id: String,
    pub room_id: String,
    pub row_id: Option<String>,
    pub rack_id: Option<String>,
    pub rack_unit_start: Option<u32>,
    pub rack_unit_end: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GpuSpec {
    pub gpu_id: String,
    pub model: String,
    pub architecture: String,
    pub vram_gb: u32,
    pub tdp_watts: f64,
    pub max_junction_temp_c: f64,
    pub interconnect_bandwidth_gbps: f64,
    pub current_utilization_pct: f64,
    pub current_temp_c: f64,
    pub current_power_watts: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CpuSpec {
    pub cpu_id: String,
    pub model: String,
    pub cores: u32,
    pub threads: u32,
    pub tdp_watts: f64,
    pub current_utilization_pct: f64,
    pub current_temp_c: f64,
    pub current_power_watts: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerAsset {
    pub asset_id: String,
    pub hostname: String,
    pub form_factor_u: u32,
    pub location: AssetLocation,
    pub cpus: Vec<CpuSpec>,
    pub gpus: Vec<GpuSpec>,
    pub memory_gb: u32,
    pub storage_tb: f64,
    pub network_bandwidth_gbps: f64,
    pub cooling_type: CoolingTopology,
    pub state: OperatingState,
    pub power_draw_kw: f64,
    pub inlet_temp_c: f64,
    pub exhaust_temp_c: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RackAsset {
    pub rack_id: String,
    pub row_id: String,
    pub room_id: String,
    pub max_kw_capacity: f64,
    pub current_kw_load: f64,
    pub max_units: u32,
    pub used_units: u32,
    pub cooling_topology: CoolingTopology,
    pub inlet_air_temp_c: f64,
    pub exhaust_air_temp_c: f64,
    pub coolant_supply_temp_c: Option<f64>,
    pub coolant_return_temp_c: Option<f64>,
    pub liquid_flow_lpm: Option<f64>,
    pub servers: Vec<ServerAsset>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UpsAsset {
    pub asset_id: String,
    pub capacity_kva: f64,
    pub active_load_kw: f64,
    pub efficiency_pct: f64,
    pub redundancy_mode: String,
    pub battery_soc_pct: f64,
    pub battery_runtime_minutes: f64,
    pub state: OperatingState,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatteryEnergyStorage {
    pub asset_id: String,
    pub total_capacity_kwh: f64,
    pub current_soc_pct: f64,
    pub max_charge_kw: f64,
    pub max_discharge_kw: f64,
    pub current_power_kw: f64, // positive = discharging, negative = charging
    pub round_trip_efficiency: f64,
    pub health_soh_pct: f64,
    pub cycles_completed: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneratorAsset {
    pub asset_id: String,
    pub capacity_kw: f64,
    pub fuel_type: String,
    pub fuel_remaining_liters: f64,
    pub fuel_burn_rate_l_per_hr: f64,
    pub startup_latency_seconds: u32,
    pub is_running: bool,
    pub power_output_kw: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChillerAsset {
    pub asset_id: String,
    pub rated_cooling_kw: f64,
    pub current_cooling_kw: f64,
    pub electrical_power_kw: f64,
    pub coefficient_of_performance: f64,
    pub chilled_water_supply_temp_c: f64,
    pub chilled_water_return_temp_c: f64,
    pub condenser_water_supply_temp_c: f64,
    pub compressor_speed_pct: f64,
    pub state: OperatingState,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LiquidCoolingLoop {
    pub loop_id: String,
    pub cdu_id: String,
    pub cooling_capacity_kw: f64,
    pub current_heat_rejection_kw: f64,
    pub supply_temp_c: f64,
    pub return_temp_c: f64,
    pub flow_rate_lpm: f64,
    pub pressure_differential_bar: f64,
    pub pump_power_kw: f64,
    pub heat_recovery_active: bool,
    pub heat_recovered_kw: f64,
}
