use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum FacilityTier {
    Tier1,
    Tier2,
    Tier3,
    Tier4,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CoolingTopology {
    DirectExpansionAir,
    ChilledWaterCRAH,
    DirectToChipLiquid,
    ImmersionTwoPhase,
    HybridAirLiquid,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum OperatingState {
    Nominal,
    Degraded,
    Maintenance,
    Standby,
    Emergency,
    Offline,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum WorkloadPriority {
    CriticalSLA = 1,
    HighPriority = 2,
    BatchStandard = 3,
    OpportunisticFlexible = 4,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum WorkloadCategory {
    AITraining,
    AIInference,
    HighPerformanceComputing,
    CloudEnterprise,
    RealtimeDatabase,
    BatchAnalytics,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PowerLimits {
    pub max_contracted_mw: f64,
    pub peak_allowable_mw: f64,
    pub min_base_load_mw: f64,
    pub battery_max_discharge_mw: f64,
    pub generator_emergency_mw: f64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ThermalLimits {
    pub max_rack_inlet_temp_c: f64,
    pub max_gpu_junction_temp_c: f64,
    pub max_cpu_die_temp_c: f64,
    pub max_coolant_supply_temp_c: f64,
    pub target_cold_aisle_temp_c: f64,
}
