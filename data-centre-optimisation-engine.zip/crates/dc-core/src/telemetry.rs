use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetrySample {
    pub timestamp: DateTime<Utc>,
    pub sensor_id: String,
    pub asset_id: String,
    pub metric_name: String,
    pub value: f64,
    pub unit: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FacilityTelemetrySnapshot {
    pub timestamp: DateTime<Utc>,
    pub grid_power_mw: f64,
    pub it_power_mw: f64,
    pub cooling_power_mw: f64,
    pub auxiliary_power_mw: f64,
    pub total_facility_power_mw: f64,
    pub instantaneous_pue: f64,
    pub it_capacity_headroom_mw: f64,
    pub cooling_capacity_headroom_mw: f64,
    
    pub spot_electricity_price_per_mwh: f64,
    pub grid_carbon_intensity_g_co2_per_kwh: f64,
    pub ambient_outside_temp_c: f64,
    pub ambient_relative_humidity_pct: f64,
    pub wet_bulb_temp_c: f64,
    
    pub total_gpu_count: u32,
    pub active_gpus: u32,
    pub average_gpu_utilization_pct: f64,
    pub total_tflops_delivered: f64,
    
    pub bess_soc_pct: f64,
    pub bess_power_kw: f64,
    pub generator_power_kw: f64,
    
    pub district_heat_recovered_mw: f64,
    pub hourly_energy_cost_usd: f64,
    pub hourly_gross_revenue_usd: f64,
    pub hourly_net_margin_usd: f64,
    
    pub active_bottleneck: String,
    pub thermal_risk_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnomalyAlert {
    pub alert_id: String,
    pub timestamp: DateTime<Utc>,
    pub asset_id: String,
    pub severity: String, // "Info", "Warning", "Critical"
    pub title: String,
    pub description: String,
    pub observed_value: f64,
    pub baseline_expected: f64,
    pub unit: String,
    pub economic_impact_usd_hr: f64,
    pub recommended_action: String,
}
