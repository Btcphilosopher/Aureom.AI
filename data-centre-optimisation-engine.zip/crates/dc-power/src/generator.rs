use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneratorDispatch {
    pub is_dispatched: bool,
    pub power_output_kw: f64,
    pub fuel_consumed_liters: f64,
    pub fuel_cost_usd: f64,
    pub carbon_emitted_kg: f64,
}

pub fn dispatch_generator(
    requested_kw: f64,
    rated_capacity_kw: f64,
    fuel_remaining_l: f64,
    fuel_price_usd_per_l: f64,
    hours: f64,
) -> GeneratorDispatch {
    if requested_kw <= 0.0 || fuel_remaining_l <= 10.0 {
        return GeneratorDispatch {
            is_dispatched: false,
            power_output_kw: 0.0,
            fuel_consumed_liters: 0.0,
            fuel_cost_usd: 0.0,
            carbon_emitted_kg: 0.0,
        };
    }

    let actual_kw = requested_kw.min(rated_capacity_kw);
    // Typical diesel gen-set burns ~0.27 L per kWh produced
    let specific_fuel_consumption = 0.27; // L/kWh
    let total_kwh = actual_kw * hours;
    let fuel_needed_l = total_kwh * specific_fuel_consumption;
    
    let fuel_burned_l = fuel_needed_l.min(fuel_remaining_l);
    let effective_kwh = fuel_burned_l / specific_fuel_consumption;
    let actual_power_kw = effective_kwh / hours;
    
    let fuel_cost_usd = fuel_burned_l * fuel_price_usd_per_l;
    // 2.68 kg CO2 per liter diesel
    let carbon_emitted_kg = fuel_burned_l * 2.68;

    GeneratorDispatch {
        is_dispatched: true,
        power_output_kw: actual_power_kw,
        fuel_consumed_liters: fuel_burned_l,
        fuel_cost_usd,
        carbon_emitted_kg,
    }
}
