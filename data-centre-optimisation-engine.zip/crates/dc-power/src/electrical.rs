use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubstationFeed {
    pub feed_id: String,
    pub voltage_kv: f64,
    pub rated_capacity_mva: f64,
    pub power_factor: f64,
    pub current_mw: f64,
    pub max_import_mw: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PowerFlowResult {
    pub grid_import_mw: f64,
    pub transformer_losses_mw: f64,
    pub ups_losses_mw: f64,
    pub it_load_mw: f64,
    pub cooling_load_mw: f64,
    pub auxiliary_load_mw: f64,
    pub bess_net_mw: f64, // positive = discharging into DC, negative = charging
    pub generator_output_mw: f64,
    pub total_facility_mw: f64,
    pub unserved_energy_mwh: f64,
    pub power_headroom_mw: f64,
}

pub fn calculate_power_flow(
    it_load_kw: f64,
    cooling_load_kw: f64,
    auxiliary_kw: f64,
    ups_efficiency_curve: fn(load_pct: f64) -> f64,
    bess_discharge_kw: f64,
    generator_kw: f64,
    grid_limit_kw: f64,
) -> PowerFlowResult {
    let it_mw = it_load_kw / 1000.0;
    let cooling_mw = cooling_load_kw / 1000.0;
    let aux_mw = auxiliary_kw / 1000.0;
    
    // UPS losses on IT + critical cooling
    let load_pct = (it_load_kw / 40000.0).clamp(0.05, 1.0);
    let ups_eff = ups_efficiency_curve(load_pct);
    let ups_input_mw = it_mw / ups_eff;
    let ups_losses_mw = ups_input_mw - it_mw;
    
    let transformer_loss_factor = 0.015; // 1.5% MV/LV step-down loss
    let total_demand_mw = ups_input_mw + cooling_mw + aux_mw;
    let transformer_losses_mw = total_demand_mw * transformer_loss_factor;
    
    let net_facility_demand_mw = total_demand_mw + transformer_losses_mw;
    let local_generation_mw = (bess_discharge_kw + generator_kw) / 1000.0;
    
    let required_grid_mw = (net_facility_demand_mw - local_generation_mw).max(0.0);
    let grid_limit_mw = grid_limit_kw / 1000.0;
    
    let (grid_import_mw, unserved_energy_mwh) = if required_grid_mw > grid_limit_mw {
        (grid_limit_mw, required_grid_mw - grid_limit_mw)
    } else {
        (required_grid_mw, 0.0)
    };
    
    let power_headroom_mw = (grid_limit_mw - grid_import_mw).max(0.0);
    
    PowerFlowResult {
        grid_import_mw,
        transformer_losses_mw,
        ups_losses_mw,
        it_load_mw: it_mw,
        cooling_load_mw: cooling_mw,
        auxiliary_load_mw: aux_mw,
        bess_net_mw: bess_discharge_kw / 1000.0,
        generator_output_mw: generator_kw / 1000.0,
        total_facility_mw: net_facility_demand_mw,
        unserved_energy_mwh,
        power_headroom_mw,
    }
}
