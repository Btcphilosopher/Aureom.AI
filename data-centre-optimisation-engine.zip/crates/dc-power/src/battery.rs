use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum BatteryDispatchMode {
    PeakShaving,
    Arbitrage,
    FrequencyRegulation,
    BackupPreserve,
    Idle,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatteryStateTransition {
    pub initial_soc_pct: f64,
    pub final_soc_pct: f64,
    pub power_flow_kw: f64,
    pub energy_throughput_kwh: f64,
    pub thermal_generation_kw: f64,
    pub degradation_cost_usd: f64,
}

pub fn update_bess_soc(
    current_soc_pct: f64,
    capacity_kwh: f64,
    power_kw: f64, // positive = discharge, negative = charge
    duration_hours: f64,
    one_way_efficiency: f64,
    min_reserve_soc_pct: f64,
) -> BatteryStateTransition {
    let mut actual_power_kw = power_kw;
    let initial_soc = current_soc_pct.clamp(0.0, 100.0);
    
    // Check discharge limit
    if actual_power_kw > 0.0 {
        let max_discharge_energy = ((initial_soc - min_reserve_soc_pct) / 100.0) * capacity_kwh * one_way_efficiency;
        let requested_energy = actual_power_kw * duration_hours;
        if requested_energy > max_discharge_energy {
            actual_power_kw = (max_discharge_energy / duration_hours).max(0.0);
        }
    }
    // Check charge limit
    else if actual_power_kw < 0.0 {
        let max_charge_energy = ((100.0 - initial_soc) / 100.0) * capacity_kwh / one_way_efficiency;
        let requested_energy = (-actual_power_kw) * duration_hours;
        if requested_energy > max_charge_energy {
            actual_power_kw = -(max_charge_energy / duration_hours);
        }
    }

    let delta_energy_stored = if actual_power_kw > 0.0 {
        // Discharging: battery loses energy divided by discharge efficiency
        -(actual_power_kw * duration_hours) / one_way_efficiency
    } else {
        // Charging: battery gains energy multiplied by charge efficiency
        (-actual_power_kw * duration_hours) * one_way_efficiency
    };

    let delta_soc = (delta_energy_stored / capacity_kwh) * 100.0;
    let final_soc_pct = (initial_soc + delta_soc).clamp(min_reserve_soc_pct, 100.0);
    let energy_throughput_kwh = actual_power_kw.abs() * duration_hours;
    
    // Battery degradation cost ~$0.04 per kWh cycled
    let degradation_cost_usd = energy_throughput_kwh * 0.042;
    let thermal_generation_kw = actual_power_kw.abs() * (1.0 - one_way_efficiency);

    BatteryStateTransition {
        initial_soc_pct: initial_soc,
        final_soc_pct,
        power_flow_kw: actual_power_kw,
        energy_throughput_kwh,
        thermal_generation_kw,
        degradation_cost_usd,
    }
}
