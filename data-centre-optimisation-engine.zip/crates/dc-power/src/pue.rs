use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EfficiencyMetrics {
    pub pue: f64,
    pub dcie_pct: f64, // Data Centre Infrastructure Efficiency = 1/PUE * 100
    pub wue_l_per_kwh: f64, // Water Usage Effectiveness
    pub cue_kg_per_kwh: f64, // Carbon Usage Effectiveness
    pub energy_per_gpu_hour_kwh: f64,
    pub energy_per_tflops_hour_kwh: f64,
}

pub fn calculate_efficiency_metrics(
    total_facility_energy_kwh: f64,
    it_equipment_energy_kwh: f64,
    water_consumption_liters: f64,
    total_carbon_emissions_kg: f64,
    active_gpu_hours: f64,
    total_tflops_delivered: f64,
) -> EfficiencyMetrics {
    let safe_it_energy = it_equipment_energy_kwh.max(0.001);
    let pue = (total_facility_energy_kwh / safe_it_energy).max(1.0);
    let dcie_pct = (1.0 / pue) * 100.0;
    let wue_l_per_kwh = water_consumption_liters / safe_it_energy;
    let cue_kg_per_kwh = total_carbon_emissions_kg / safe_it_energy;
    
    let energy_per_gpu_hour = if active_gpu_hours > 0.0 {
        total_facility_energy_kwh / active_gpu_hours
    } else {
        0.0
    };

    let energy_per_tflops = if total_tflops_delivered > 0.0 {
        total_facility_energy_kwh / total_tflops_delivered
    } else {
        0.0
    };

    EfficiencyMetrics {
        pue,
        dcie_pct,
        wue_l_per_kwh,
        cue_kg_per_kwh,
        energy_per_gpu_hour_kwh: energy_per_gpu_hour,
        energy_per_tflops_hour_kwh: energy_per_tflops,
    }
}
