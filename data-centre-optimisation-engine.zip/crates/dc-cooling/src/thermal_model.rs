use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermalZoneState {
    pub zone_id: String,
    pub ambient_temp_c: f64,
    pub cold_aisle_temp_c: f64,
    pub hot_aisle_temp_c: f64,
    pub airflow_cfm: f64,
    pub heat_dissipated_kw: f64,
    pub thermal_headroom_c: f64,
    pub is_contained: bool, // Cold or Hot aisle containment
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RackThermalProfile {
    pub rack_id: String,
    pub it_power_kw: f64,
    pub inlet_temp_c: f64,
    pub exhaust_temp_c: f64,
    pub delta_t_c: f64,
    pub chip_max_junction_temp_c: f64,
    pub liquid_coolant_fraction: f64, // 0.0 (air only) to 0.85 (hybrid direct-to-chip)
    pub thermal_excursion_risk: f64,  // 0.0 to 1.0
}

/// Thermodynamic heat transfer: Q = m_dot * Cp * delta_T
/// For Air: Delta_T = Q_kw / (1.08 * CFM / 1000.0)
pub fn calculate_rack_thermal(
    it_power_kw: f64,
    inlet_air_temp_c: f64,
    airflow_cfm: f64,
    liquid_cooling_kw: f64,
    max_allowable_junction_c: f64,
) -> RackThermalProfile {
    let air_heat_kw = (it_power_kw - liquid_cooling_kw).max(0.0);
    let safe_cfm = airflow_cfm.max(100.0);
    
    // Sensible heat formula in imperial/metric conversion: Delta_T (°C) approx = (3.16 * Q_kW) / (Airflow_m3_s)
    let delta_t = (air_heat_kw * 1.8) / (safe_cfm / 1000.0);
    let exhaust_temp_c = inlet_air_temp_c + delta_t;
    
    // Die junction estimate: T_j = T_inlet + (R_theta_jc + R_theta_cs + R_theta_sa) * P_chip
    let r_thermal = 0.035; // °C / Watt
    let chip_temp = if liquid_cooling_kw > 0.0 {
        // Direct-to-chip with cold plates runs much cooler (typically 50-65°C)
        35.0 + (it_power_kw * 1000.0 * 0.015) / 8.0
    } else {
        inlet_air_temp_c + (it_power_kw * 1000.0 * r_thermal) / 8.0
    };
    
    let liquid_fraction = if it_power_kw > 0.0 {
        (liquid_cooling_kw / it_power_kw).clamp(0.0, 1.0)
    } else {
        0.0
    };

    let headroom = max_allowable_junction_c - chip_temp;
    let thermal_excursion_risk = if headroom < 5.0 {
        1.0
    } else if headroom < 15.0 {
        (15.0 - headroom) / 10.0
    } else {
        0.0
    };

    RackThermalProfile {
        rack_id: "rack".to_string(),
        it_power_kw,
        inlet_temp_c: inlet_air_temp_c,
        exhaust_temp_c,
        delta_t_c: delta_t,
        chip_max_junction_temp_c: chip_temp,
        liquid_coolant_fraction: liquid_fraction,
        thermal_excursion_risk,
    }
}
