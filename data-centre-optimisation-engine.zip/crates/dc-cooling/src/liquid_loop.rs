use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LiquidLoopTelemetry {
    pub cdu_id: String,
    pub heat_removed_kw: f64,
    pub supply_temp_c: f64,
    pub return_temp_c: f64,
    pub delta_t_c: f64,
    pub flow_rate_lpm: f64,
    pub pump_speed_pct: f64,
    pub pump_power_kw: f64,
    pub pressure_drop_bar: f64,
}

/// Liquid cooling loop physics: Q = m_dot * Cp * Delta_T
/// For Water/Glycol (Cp ~ 3.9 kJ/kg*K, density ~ 1.05 kg/L)
/// Q (kW) = Flow (LPM) / 60 * 1.05 * 3.9 * Delta_T = Flow (LPM) * Delta_T * 0.06825
pub fn calculate_liquid_loop(
    it_liquid_heat_kw: f64,
    supply_temp_c: f64,
    pump_speed_pct: f64,
    rated_cdu_flow_lpm: f64,
) -> LiquidLoopTelemetry {
    let effective_flow_lpm = rated_cdu_flow_lpm * (pump_speed_pct / 100.0).clamp(0.15, 1.0);
    
    // Delta_T = Q_kw / (Flow_LPM * 0.06825)
    let delta_t_c = if effective_flow_lpm > 0.1 {
        (it_liquid_heat_kw / (effective_flow_lpm * 0.06825)).clamp(1.0, 35.0)
    } else {
        35.0
    };
    
    let return_temp_c = supply_temp_c + delta_t_c;
    
    // Affinity law for pump power: P ~ N^3
    let pump_power_kw = 12.5 * (pump_speed_pct / 100.0).powi(3);
    // Pressure drop ~ Flow^2
    let pressure_drop_bar = 1.2 * (pump_speed_pct / 100.0).powi(2);

    LiquidLoopTelemetry {
        cdu_id: "CDU-AI-HALL-1".to_string(),
        heat_removed_kw: it_liquid_heat_kw,
        supply_temp_c,
        return_temp_c,
        delta_t_c,
        flow_rate_lpm: effective_flow_lpm,
        pump_speed_pct,
        pump_power_kw,
        pressure_drop_bar,
    }
}
