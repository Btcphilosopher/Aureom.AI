use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HeatRecoveryEconomics {
    pub gross_thermal_power_mw: f64,
    pub recoverable_thermal_power_mw: f64,
    pub supply_water_temp_c: f64,
    pub heat_pump_booster_power_mw: f64,
    pub net_delivered_thermal_mw: f64,
    pub thermal_offtake_price_usd_per_mwh_th: f64,
    pub hourly_thermal_revenue_usd: f64,
    pub booster_electricity_cost_usd: f64,
    pub net_hourly_profit_usd: f64,
    pub co2_offset_tonnes_per_hour: f64,
}

pub fn calculate_heat_recovery(
    waste_heat_kw: f64,
    return_water_temp_c: f64,
    district_target_temp_c: f64,
    thermal_sale_price_usd_mwh: f64,
    electricity_price_usd_mwh: f64,
) -> HeatRecoveryEconomics {
    let gross_mw = waste_heat_kw / 1000.0;
    
    // Liquid cooling at 55-60°C return water has ~85% heat recovery viability
    let recovery_efficiency = if return_water_temp_c >= 50.0 {
        0.88
    } else if return_water_temp_c >= 40.0 {
        0.65
    } else {
        0.25 // Low-grade air heat requires heavy heat pump lift
    };

    let recoverable_mw = gross_mw * recovery_efficiency;
    
    // If district heating network requires 75°C, booster heat pump is required
    let (booster_power_mw, net_delivered_mw) = if district_target_temp_c > return_water_temp_c {
        let temp_lift = district_target_temp_c - return_water_temp_c;
        let cop_hp = (320.0 / temp_lift).clamp(3.0, 7.5);
        let hp_elec = recoverable_mw / cop_hp;
        (hp_elec, recoverable_mw + hp_elec)
    } else {
        (0.0, recoverable_mw)
    };

    let hourly_revenue = net_delivered_mw * thermal_sale_price_usd_mwh;
    let booster_cost = booster_power_mw * electricity_price_usd_mwh;
    let net_profit = hourly_revenue - booster_cost;
    
    // Displacing natural gas boiler (approx 0.202 tonnes CO2/MWh_thermal)
    let co2_offset_tonnes = net_delivered_mw * 0.202;

    HeatRecoveryEconomics {
        gross_thermal_power_mw: gross_mw,
        recoverable_thermal_power_mw: recoverable_mw,
        supply_water_temp_c: district_target_temp_c,
        heat_pump_booster_power_mw: booster_power_mw,
        net_delivered_thermal_mw: net_delivered_mw,
        thermal_offtake_price_usd_per_mwh_th: thermal_sale_price_usd_mwh,
        hourly_thermal_revenue_usd: hourly_revenue,
        booster_electricity_cost_usd: booster_cost,
        net_hourly_profit_usd: net_profit,
        co2_offset_tonnes_per_hour: co2_offset_tonnes,
    }
}
