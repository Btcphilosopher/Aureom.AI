use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChillerOperatingPoint {
    pub chiller_id: String,
    pub cooling_load_kw: f64,
    pub cop: f64,
    pub electrical_power_kw: f64,
    pub chilled_water_supply_temp_c: f64,
    pub ambient_wet_bulb_temp_c: f64,
    pub economizer_active: bool,
    pub waterside_economizer_fraction: f64,
}

/// Dynamic Chiller COP Model based on Carnot efficiency and lift
/// COP_actual = eta_carnot * (T_evap_K / (T_cond_K - T_evap_K))
pub fn calculate_chiller_performance(
    cooling_load_kw: f64,
    chw_supply_temp_c: f64,
    ambient_wet_bulb_temp_c: f64,
    rated_capacity_kw: f64,
) -> ChillerOperatingPoint {
    let t_evap_k = chw_supply_temp_c + 273.15;
    // Condenser water temperature typically 3°C above wet bulb
    let t_cond_c = (ambient_wet_bulb_temp_c + 3.5).max(18.0);
    let t_cond_k = t_cond_c + 273.15;
    
    let lift_k = (t_cond_k - t_evap_k).max(4.0);
    let cop_carnot = t_evap_k / lift_k;
    let isentropic_efficiency = 0.58; // Typical centrifugal VFD chiller
    let base_cop = (cop_carnot * isentropic_efficiency).clamp(3.2, 8.5);
    
    // Check for waterside economizer (free cooling)
    let (economizer_active, econ_fraction, effective_cop) = if ambient_wet_bulb_temp_c <= (chw_supply_temp_c - 2.0) {
        // Full free cooling possible via plate heat exchanger
        (true, 1.0, 24.0) // Only pumping/fan energy
    } else if ambient_wet_bulb_temp_c <= (chw_supply_temp_c + 2.0) {
        // Partial economization
        let frac = (chw_supply_temp_c + 2.0 - ambient_wet_bulb_temp_c) / 4.0;
        (true, frac, base_cop * (1.0 + frac * 1.5))
    } else {
        (false, 0.0, base_cop)
    };
    
    let electrical_power_kw = cooling_load_kw / effective_cop;

    ChillerOperatingPoint {
        chiller_id: "CHILLER-MAIN".to_string(),
        cooling_load_kw,
        cop: effective_cop,
        electrical_power_kw,
        chilled_water_supply_temp_c: chw_supply_temp_c,
        ambient_wet_bulb_temp_c,
        economizer_active,
        waterside_economizer_fraction: econ_fraction,
    }
}
