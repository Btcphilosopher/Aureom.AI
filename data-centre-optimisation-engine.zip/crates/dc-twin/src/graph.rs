use dc_core::asset::*;
use dc_core::types::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataCentreTwinState {
    pub site_id: String,
    pub name: String,
    pub tier: FacilityTier,
    pub contracted_power_mw: f64,
    pub peak_power_limit_mw: f64,
    pub cooling_design_mw: f64,
    pub total_floor_area_sqm: f64,
    
    pub rooms: Vec<RoomTwin>,
    pub ups_systems: Vec<UpsAsset>,
    pub battery_storage: Vec<BatteryEnergyStorage>,
    pub backup_generators: Vec<GeneratorAsset>,
    pub chillers: Vec<ChillerAsset>,
    pub cdu_loops: Vec<LiquidCoolingLoop>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomTwin {
    pub room_id: String,
    pub name: String,
    pub room_type: String, // "High-Density AI Supercomputing", "General Enterprise Cloud"
    pub cooling_topology: CoolingTopology,
    pub max_capacity_kw: f64,
    pub current_load_kw: f64,
    pub target_temp_c: f64,
    pub current_temp_c: f64,
    pub humidity_pct: f64,
    pub rows: Vec<RowTwin>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RowTwin {
    pub row_id: String,
    pub name: String,
    pub containment_type: String, // "Cold Aisle", "Hot Aisle", "None"
    pub racks: Vec<RackAsset>,
}
