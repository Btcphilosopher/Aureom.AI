use crate::graph::*;
use dc_core::telemetry::FacilityTelemetrySnapshot;
use dc_power::electrical::calculate_power_flow;
use dc_power::pue::calculate_efficiency_metrics;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TwinRuntimeContext {
    pub current_time_epoch_s: i64,
    pub spot_price_usd_per_mwh: f64,
    pub ambient_temp_c: f64,
    pub ambient_humidity_pct: f64,
    pub grid_carbon_g_co2_kwh: f64,
}

pub fn evaluate_twin_snapshot(
    twin: &DataCentreTwinState,
    ctx: &TwinRuntimeContext,
) -> FacilityTelemetrySnapshot {
    let mut total_it_kw = 0.0;
    let mut total_gpus = 0;
    let mut active_gpus = 0;
    let mut total_tflops = 0.0;
    let mut max_rack_temp = 0.0;

    for room in &twin.rooms {
        for row in &room.rows {
            for rack in &row.racks {
                total_it_kw += rack.current_kw_load;
                if rack.inlet_air_temp_c > max_rack_temp {
                    max_rack_temp = rack.inlet_air_temp_c;
                }
                for server in &rack.servers {
                    for gpu in &server.gpus {
                        total_gpus += 1;
                        if gpu.current_utilization_pct > 5.0 {
                            active_gpus += 1;
                            let flops = if gpu.model.contains("B200") {
                                4500.0
                            } else if gpu.model.contains("H100") {
                                2000.0
                            } else {
                                620.0
                            };
                            total_tflops += flops * (gpu.current_utilization_pct / 100.0);
                        }
                    }
                }
            }
        }
    }

    // Cooling power calculation
    let mut cooling_kw = 0.0;
    let mut heat_recovered_kw = 0.0;
    for ch in &twin.chillers {
        cooling_kw += ch.electrical_power_kw;
    }
    for cdu in &twin.cdu_loops {
        cooling_kw += cdu.pump_power_kw;
        if cdu.heat_recovery_active {
            heat_recovered_kw += cdu.heat_recovered_kw;
        }
    }
    if cooling_kw < 100.0 {
        // Fallback realistic baseline if auxiliary chillers are idle
        cooling_kw = total_it_kw * 0.18;
    }

    let aux_kw = 450.0; // Lighting, BMS, security, ventilation
    let bess_kw = twin.battery_storage.iter().map(|b| b.current_power_kw).sum::<f64>();
    let gen_kw = twin.backup_generators.iter().map(|g| g.power_output_kw).sum::<f64>();

    let power_flow = calculate_power_flow(
        total_it_kw,
        cooling_kw,
        aux_kw,
        |_load| 0.965,
        bess_kw,
        gen_kw,
        twin.contracted_power_mw * 1000.0,
    );

    let efficiency = calculate_efficiency_metrics(
        power_flow.total_facility_mw * 1000.0,
        total_it_kw,
        cooling_kw * 1.8,
        (power_flow.grid_import_mw * 1000.0 * ctx.grid_carbon_g_co2_kwh) / 1000.0,
        active_gpus as f64,
        total_tflops,
    );

    let avg_util = if total_gpus > 0 {
        (active_gpus as f64 / total_gpus as f64) * 100.0
    } else {
        0.0
    };

    let hourly_energy_cost = (power_flow.grid_import_mw) * ctx.spot_price_usd_per_mwh;
    // Revenue per active GPU approx $2.85/hr
    let hourly_revenue = (active_gpus as f64) * 2.85 + (heat_recovered_kw / 1000.0) * 32.0;
    let hourly_margin = hourly_revenue - hourly_energy_cost - 180.0; // subtracting baseline fixed opex

    // Detect primary bottleneck
    let active_bottleneck = if power_flow.power_headroom_mw < 1.5 {
        "Substation Peak Grid Capacity Limit (Headroom < 1.5 MW)".to_string()
    } else if max_rack_temp > 28.0 {
        "High-Density Row 3 Cold Aisle Thermal Saturation".to_string()
    } else if avg_util > 92.0 {
        "AI GPU Interconnect Fabric Bandwidth Saturation".to_string()
    } else {
        "Nominal Balanced - No Active Systemic Bottleneck".to_string()
    };

    FacilityTelemetrySnapshot {
        timestamp: chrono::Utc::now(),
        grid_power_mw: power_flow.grid_import_mw,
        it_power_mw: power_flow.it_load_mw,
        cooling_power_mw: power_flow.cooling_load_mw,
        auxiliary_power_mw: power_flow.auxiliary_load_mw,
        total_facility_power_mw: power_flow.total_facility_mw,
        instantaneous_pue: efficiency.pue,
        it_capacity_headroom_mw: (twin.contracted_power_mw * 0.85) - power_flow.it_load_mw,
        cooling_capacity_headroom_mw: twin.cooling_design_mw - power_flow.cooling_load_mw,
        
        spot_electricity_price_per_mwh: ctx.spot_price_usd_per_mwh,
        grid_carbon_intensity_g_co2_per_kwh: ctx.grid_carbon_g_co2_kwh,
        ambient_outside_temp_c: ctx.ambient_temp_c,
        ambient_relative_humidity_pct: ctx.ambient_humidity_pct,
        wet_bulb_temp_c: ctx.ambient_temp_c - ((100.0 - ctx.ambient_humidity_pct) / 5.0),
        
        total_gpu_count: total_gpus,
        active_gpus,
        average_gpu_utilization_pct: avg_util,
        total_tflops_delivered: total_tflops,
        
        bess_soc_pct: twin.battery_storage.first().map(|b| b.current_soc_pct).unwrap_or(85.0),
        bess_power_kw: bess_kw,
        generator_power_kw: gen_kw,
        
        district_heat_recovered_mw: heat_recovered_kw / 1000.0,
        hourly_energy_cost_usd: hourly_energy_cost,
        hourly_gross_revenue_usd: hourly_revenue,
        hourly_net_margin_usd: hourly_margin,
        
        active_bottleneck,
        thermal_risk_score: (max_rack_temp / 35.0).clamp(0.0, 1.0),
    }
}
