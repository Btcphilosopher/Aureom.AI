use dc_core::telemetry::AnomalyAlert;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnomalyDetectorConfig {
    pub temperature_z_threshold: f64,
    pub power_spike_pct_threshold: f64,
    pub cop_degradation_threshold: f64,
}

impl Default for AnomalyDetectorConfig {
    fn default() -> Self {
        Self {
            temperature_z_threshold: 2.8,
            power_spike_pct_threshold: 25.0,
            cop_degradation_threshold: 18.0,
        }
    }
}

pub fn check_facility_anomalies(
    rack_inlet_temps: &[(String, f64)],
    chiller_cops: &[(String, f64, f64)], // (id, actual_cop, expected_cop)
) -> Vec<AnomalyAlert> {
    let mut alerts = Vec::new();

    for (rack_id, temp) in rack_inlet_temps {
        if *temp > 29.5 {
            alerts.push(AnomalyAlert {
                alert_id: format!("ANOM-TEMP-{}", rack_id),
                timestamp: chrono::Utc::now(),
                asset_id: rack_id.clone(),
                severity: if *temp > 33.0 { "Critical".into() } else { "Warning".into() },
                title: "Server Rack Inlet Thermal Excursion".into(),
                description: format!("Inlet air temperature at {} reached {:.1}°C exceeding ASHRAE TC9.9 recommended A1 envelope (18-27°C)", rack_id, temp),
                observed_value: *temp,
                baseline_expected: 24.0,
                unit: "°C".into(),
                economic_impact_usd_hr: 340.0,
                recommended_action: "Increase CRAH fan variable speed or verify cold aisle containment seals.".into(),
            });
        }
    }

    for (chiller_id, actual_cop, expected_cop) in chiller_cops {
        let drop_pct = ((expected_cop - actual_cop) / expected_cop) * 100.0;
        if drop_pct > 15.0 {
            alerts.push(AnomalyAlert {
                alert_id: format!("ANOM-COP-{}", chiller_id),
                timestamp: chrono::Utc::now(),
                asset_id: chiller_id.clone(),
                severity: "Warning".into(),
                title: "Chiller Thermodynamic COP Degradation".into(),
                description: format!("Chiller {} operating at COP {:.2} (expected {:.2}, -{:.1}% drop). Potential condenser fouling or refrigerant undercharge.", chiller_id, actual_cop, expected_cop, drop_pct),
                observed_value: *actual_cop,
                baseline_expected: *expected_cop,
                unit: "COP".into(),
                economic_impact_usd_hr: 185.0,
                recommended_action: "Schedule tube brush cleaning and inspect condenser water approach temperature.".into(),
            });
        }
    }

    alerts
}
