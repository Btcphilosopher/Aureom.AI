use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GpuNodeGroup {
    pub group_id: String,
    pub gpu_model: String, // "NVIDIA H100 SXM5", "NVIDIA B200", "NVIDIA A100"
    pub total_gpus: u32,
    pub allocated_gpus: u32,
    pub total_vram_gb: u32,
    pub interconnect_type: String, // "NVLink-4 900GB/s", "NVLink-5 1.8TB/s", "PCIe-Gen5"
    pub tdp_watts_per_gpu: f64,
    pub avg_power_draw_watts: f64,
    pub avg_temp_c: f64,
    pub throttling_events_count: u32,
    pub is_liquid_cooled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterSummary {
    pub total_gpus: u32,
    pub active_gpus: u32,
    pub utilization_pct: f64,
    pub total_it_power_kw: f64,
    pub total_flops_petaflops: f64,
    pub gross_gpu_hourly_revenue_usd: f64,
}

pub fn summarize_cluster(groups: &[GpuNodeGroup]) -> ClusterSummary {
    let mut total_g = 0;
    let mut active_g = 0;
    let mut total_power_w = 0.0;
    let mut total_pflops = 0.0;
    let mut total_rev = 0.0;

    for g in groups {
        total_g += g.total_gpus;
        active_g += g.allocated_gpus;
        total_power_w += (g.allocated_gpus as f64) * g.avg_power_draw_watts;
        
        // Approx BF16 Tensor Core PFLOPS per GPU
        let flops_per_gpu = if g.gpu_model.contains("B200") {
            4.5
        } else if g.gpu_model.contains("H100") {
            2.0
        } else {
            0.62
        };
        total_pflops += (g.allocated_gpus as f64) * flops_per_gpu;
        
        // Revenue per GPU-hr approx: H100 ~$2.80, B200 ~$4.50, A100 ~$1.40
        let rev_rate = if g.gpu_model.contains("B200") {
            4.60
        } else if g.gpu_model.contains("H100") {
            2.90
        } else {
            1.45
        };
        total_rev += (g.allocated_gpus as f64) * rev_rate;
    }

    let util = if total_g > 0 {
        (active_g as f64 / total_g as f64) * 100.0
    } else {
        0.0
    };

    ClusterSummary {
        total_gpus: total_g,
        active_gpus: active_g,
        utilization_pct: util,
        total_it_power_kw: total_power_w / 1000.0,
        total_flops_petaflops: total_pflops,
        gross_gpu_hourly_revenue_usd: total_rev,
    }
}
