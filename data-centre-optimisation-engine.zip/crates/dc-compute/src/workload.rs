use chrono::{DateTime, Utc};
use dc_core::types::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkloadJob {
    pub job_id: String,
    pub name: String,
    pub category: WorkloadCategory,
    pub priority: WorkloadPriority,
    pub required_gpus: u32,
    pub required_vram_gb: u32,
    pub required_cpus: u32,
    pub estimated_duration_hours: f64,
    pub deadline: DateTime<Utc>,
    pub max_acceptable_latency_ms: f64,
    pub is_preemptible: bool,
    pub revenue_rate_usd_per_gpu_hr: f64,
    pub sla_penalty_usd_per_hr: f64,
    pub power_scaling_factor: f64, // Multiplier on TDP (0.4 to 1.0)
    pub current_status: JobStatus,
    pub allocated_servers: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum JobStatus {
    Queued,
    Running,
    PausedFlexible,
    Completed,
    FailedThermal,
}
