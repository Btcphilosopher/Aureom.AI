use crate::workload::*;
use dc_core::types::WorkloadPriority;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchedulingDecision {
    pub job_id: String,
    pub action: SchedulingAction,
    pub reason: String,
    pub power_impact_kw: f64,
    pub cost_impact_usd: f64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SchedulingAction {
    DispatchNow,
    ShiftToOffPeak,
    ThrottlePower,
    PreemptForSLA,
    RejectInsufficientCapacity,
}

pub fn schedule_workloads(
    queue: &mut [WorkloadJob],
    available_gpus: u32,
    available_power_kw: f64,
    spot_price_usd_mwh: f64,
    is_power_constrained: bool,
) -> Vec<SchedulingDecision> {
    let mut decisions = Vec::new();
    let mut remaining_gpus = available_gpus;
    let mut remaining_power = available_power_kw;

    // Sort queue by Priority (Critical first), then Revenue Rate descending
    queue.sort_by(|a, b| {
        let p_a = a.priority as u8;
        let p_b = b.priority as u8;
        p_a.cmp(&p_b).then_with(|| {
            b.revenue_rate_usd_per_gpu_hr
                .partial_cmp(&a.revenue_rate_usd_per_gpu_hr)
                .unwrap()
        })
    });

    for job in queue.iter_mut() {
        let req_power_kw = (job.required_gpus as f64) * 0.700 * job.power_scaling_factor;

        // If high power price (> $180/MWh) and job is flexible batch, shift to off-peak
        if spot_price_usd_mwh > 180.0 && job.priority == WorkloadPriority::OpportunisticFlexible {
            job.current_status = JobStatus::PausedFlexible;
            decisions.push(SchedulingDecision {
                job_id: job.job_id.clone(),
                action: SchedulingAction::ShiftToOffPeak,
                reason: format!("High grid price (${:.1}/MWh); deferred to off-peak window", spot_price_usd_mwh),
                power_impact_kw: -req_power_kw,
                cost_impact_usd: -(req_power_kw / 1000.0) * spot_price_usd_mwh,
            });
            continue;
        }

        if remaining_gpus >= job.required_gpus && remaining_power >= req_power_kw {
            remaining_gpus -= job.required_gpus;
            remaining_power -= req_power_kw;
            job.current_status = JobStatus::Running;
            decisions.push(SchedulingDecision {
                job_id: job.job_id.clone(),
                action: SchedulingAction::DispatchNow,
                reason: "Resources available and thermal/power bounds satisfied".to_string(),
                power_impact_kw: req_power_kw,
                cost_impact_usd: (req_power_kw / 1000.0) * spot_price_usd_mwh,
            });
        } else if is_power_constrained && job.priority != WorkloadPriority::CriticalSLA {
            job.current_status = JobStatus::Queued;
            decisions.push(SchedulingDecision {
                job_id: job.job_id.clone(),
                action: SchedulingAction::ThrottlePower,
                reason: "Power capacity headroom reached; non-critical workload held".to_string(),
                power_impact_kw: 0.0,
                cost_impact_usd: 0.0,
            });
        } else {
            job.current_status = JobStatus::Queued;
            decisions.push(SchedulingDecision {
                job_id: job.job_id.clone(),
                action: SchedulingAction::RejectInsufficientCapacity,
                reason: "Insufficient free GPUs in target interconnect fabric".to_string(),
                power_impact_kw: 0.0,
                cost_impact_usd: 0.0,
            });
        }
    }

    decisions
}
