use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkloadShiftResult {
    pub shifted_mwh: f64,
    pub original_cost_usd: f64,
    pub shifted_cost_usd: f64,
    pub cost_savings_usd: f64,
    pub average_price_differential_usd_mwh: f64,
    pub peak_mw_reduction: f64,
}

pub fn evaluate_24h_workload_shifting(
    hourly_prices: &[f64; 24],
    hourly_base_demand_mw: &[f64; 24],
    flexible_fraction: f64,
) -> WorkloadShiftResult {
    let mut original_cost = 0.0;
    let mut total_flexible_mwh = 0.0;

    for (h, price) in hourly_prices.iter().enumerate() {
        let load = hourly_base_demand_mw[h];
        original_cost += load * price;
        total_flexible_mwh += load * flexible_fraction;
    }

    // Find the 6 cheapest hours in the 24h curve
    let mut price_indices: Vec<(usize, f64)> = hourly_prices
        .iter()
        .copied()
        .enumerate()
        .collect();
    price_indices.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    let cheapest_hours: Vec<usize> = price_indices.iter().take(6).map(|(idx, _)| *idx).collect();
    let expensive_hours: Vec<usize> = price_indices.iter().rev().take(6).map(|(idx, _)| *idx).collect();

    let mut shifted_loads = *hourly_base_demand_mw;
    let shift_amount_per_peak_hour = total_flexible_mwh / 6.0;

    for &h in &expensive_hours {
        shifted_loads[h] = (shifted_loads[h] - shift_amount_per_peak_hour).max(hourly_base_demand_mw[h] * (1.0 - flexible_fraction));
    }
    for &h in &cheapest_hours {
        shifted_loads[h] += shift_amount_per_peak_hour;
    }

    let mut shifted_cost = 0.0;
    for (h, price) in hourly_prices.iter().enumerate() {
        shifted_cost += shifted_loads[h] * price;
    }

    let max_orig = hourly_base_demand_mw.iter().cloned().fold(0.0, f64::max);
    let max_shifted = shifted_loads.iter().cloned().fold(0.0, f64::max);

    WorkloadShiftResult {
        shifted_mwh: total_flexible_mwh,
        original_cost_usd: original_cost,
        shifted_cost_usd: shifted_cost,
        cost_savings_usd: original_cost - shifted_cost,
        average_price_differential_usd_mwh: (original_cost - shifted_cost) / total_flexible_mwh.max(0.01),
        peak_mw_reduction: (max_orig - max_shifted).max(0.0),
    }
}
