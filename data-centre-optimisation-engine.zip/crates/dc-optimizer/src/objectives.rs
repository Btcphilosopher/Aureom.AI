use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizationWeights {
    pub weight_compute_throughput: f64, // 0.0 to 1.0
    pub weight_energy_cost_min: f64,     // 0.0 to 1.0
    pub weight_carbon_reduction: f64,    // 0.0 to 1.0
    pub weight_thermal_safety: f64,      // 0.0 to 1.0
    pub weight_battery_preservation: f64,// 0.0 to 1.0
}

impl Default for OptimizationWeights {
    fn default() -> Self {
        Self {
            weight_compute_throughput: 0.40,
            weight_energy_cost_min: 0.30,
            weight_carbon_reduction: 0.15,
            weight_thermal_safety: 0.10,
            weight_battery_preservation: 0.05,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizationConstraints {
    pub max_grid_power_mw: f64,
    pub max_gpu_junction_temp_c: f64,
    pub min_bess_soc_reserve_pct: f64,
    pub max_chiller_delta_t_c: f64,
    pub strict_sla_deadline_enforcement: bool,
    pub allow_workload_deferral: bool,
    pub enable_district_heat_export: bool,
}

impl Default for OptimizationConstraints {
    fn default() -> Self {
        Self {
            max_grid_power_mw: 42.0,
            max_gpu_junction_temp_c: 78.0,
            min_bess_soc_reserve_pct: 20.0,
            max_chiller_delta_t_c: 6.5,
            strict_sla_deadline_enforcement: true,
            allow_workload_deferral: true,
            enable_district_heat_export: true,
        }
    }
}
