use crate::objectives::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizationPlan {
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub execution_mode: String,
    
    // Power & Grid actions
    pub recommended_grid_mw: f64,
    pub bess_action_kw: f64, // >0 discharge, <0 charge
    pub generator_dispatch_kw: f64,
    pub peak_shaving_mw_unlocked: f64,
    
    // Cooling actions
    pub chiller_setpoint_c: f64,
    pub cdu_pump_speed_pct: f64,
    pub economizer_engagement_pct: f64,
    pub heat_recovery_mw: f64,
    
    // Compute & GPU scheduling
    pub scheduled_jobs_count: u32,
    pub deferred_jobs_count: u32,
    pub active_gpus_allocated: u32,
    pub total_pflops_achieved: f64,
    
    // Financial & Efficiency outcomes
    pub baseline_hourly_cost_usd: f64,
    pub optimized_hourly_cost_usd: f64,
    pub hourly_savings_usd: f64,
    pub pue_projected: f64,
    pub carbon_saved_kg_hr: f64,
    pub margin_improvement_pct: f64,
}
