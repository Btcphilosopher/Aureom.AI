# ==============================================================================
# DATA CENTRE OPTIMISATION ENGINE - R DC EXPANSION & ECONOMIC VALUATION
# File: r-engine/economics.R
# ==============================================================================

#' Evaluate Modular Data Centre Capacity Expansions (1MW to 100MW)
#' Calculates CapEx, OpEx, NPV, IRR, Payback, and Levelized Cost of Compute
evaluate_dc_expansion <- function(
  expansion_mw_options = c(1, 5, 10, 50, 100),
  wacc = 0.085, # 8.5% cost of capital
  discount_years = 10,
  power_capex_per_mw = 4200000,      # $4.2M / MW for Substation + UPS + Generators
  cooling_capex_per_mw = 3100000,    # $3.1M / MW for Liquid CDUs + Chillers + Towers
  civil_capex_per_mw = 1800000,      # $1.8M / MW for Shell, White Space, Fire Suppression
  compute_capex_per_mw = 14500000,   # $14.5M / MW for H100/B200 GPU Servers & 800G Fabric
  grid_power_price_usd_mwh = 78.0,
  gpu_rev_per_hour = 2.85,
  pue_target = 1.14
) {
  results <- list()
  
  for (mw in expansion_mw_options) {
    # 1. CapEx Breakdown
    total_power_capex <- mw * power_capex_per_mw
    total_cooling_capex <- mw * cooling_capex_per_mw
    total_civil_capex <- mw * civil_capex_per_mw
    total_compute_capex <- mw * compute_capex_per_mw
    total_capex <- total_power_capex + total_cooling_capex + total_civil_capex + total_compute_capex
    
    # 2. Annual Operating Calculations
    active_gpus <- (mw * 1000) / 0.700 # ~700W per GPU system share
    annual_gpu_hours <- active_gpus * 8760 * 0.92 # 92% SLA utilization
    annual_revenue <- annual_gpu_hours * gpu_rev_per_hour
    
    annual_energy_mwh <- mw * pue_target * 8760
    annual_energy_cost <- annual_energy_mwh * grid_power_price_usd_mwh
    annual_maintenance_opex <- total_capex * 0.035 # 3.5% maintenance/staff
    total_annual_opex <- annual_energy_cost + annual_maintenance_opex
    
    annual_net_cashflow <- annual_revenue - total_annual_opex
    
    # 3. Discounted Cash Flow NPV Calculation
    discount_factors <- (1 + wacc) ^ (1:discount_years)
    pv_cashflows <- sum(annual_net_cashflow / discount_factors)
    npv <- pv_cashflows - total_capex
    
    # 4. Simple Payback Period & Estimated IRR
    payback_years <- total_capex / annual_net_cashflow
    # Approximation of IRR via Newton root or standard DCF
    irr_estimate <- (annual_net_cashflow / total_capex) * 1.05 - (1 / discount_years)
    
    results[[paste0(mw, "MW")]] <- list(
      expansion_mw = mw,
      active_gpus_added = round(active_gpus),
      capex_breakdown_usd = list(
        power_infrastructure = total_power_capex,
        cooling_infrastructure = total_cooling_capex,
        civil_and_building = total_civil_capex,
        it_and_gpu_hardware = total_compute_capex,
        total_capex = total_capex
      ),
      annual_metrics_usd = list(
        gross_revenue = round(annual_revenue, 2),
        energy_cost = round(annual_energy_cost, 2),
        maintenance_opex = round(annual_maintenance_opex, 2),
        net_operating_cashflow = round(annual_net_cashflow, 2)
      ),
      financial_valuation = list(
        npv_10_year_usd = round(npv, 2),
        irr_pct = round(irr_estimate * 100, 2),
        payback_years = round(payback_years, 2),
        cost_per_gpu_hour_usd = round(total_annual_opex / annual_gpu_hours, 3)
      )
    )
  }
  
  return(results)
}
