# ==============================================================================
# DATA CENTRE OPTIMISATION ENGINE - R MONTE CARLO PROBABILISTIC SIMULATOR
# File: r-engine/monte_carlo.R
# ==============================================================================

#' Run High-Throughput Monte Carlo Risk Simulation
#' @param n_runs Number of stochastic iterations (default 10,000)
#' @param base_it_mw Nominal IT compute capacity in MW
#' @param price_mean Mean grid price $/MWh
#' @param price_sd Grid price volatility standard deviation
#' @param temp_mean Ambient temperature mean °C
#' @param chiller_failure_prob Annual chiller outage probability
run_monte_carlo_simulation <- function(
  n_runs = 10000,
  base_it_mw = 35.0,
  price_mean = 85.0,
  price_sd = 28.0,
  temp_mean = 28.0,
  chiller_failure_prob = 0.035
) {
  set.seed(42) # Reproducible seed
  
  # 1. Stochastic Price Sampling (Log-Normal with occasional extreme spikes)
  log_mean <- log(price_mean^2 / sqrt(price_sd^2 + price_mean^2))
  log_sd <- sqrt(log(1 + (price_sd^2 / price_mean^2)))
  prices <- rlnorm(n_runs, meanlog = log_mean, sdlog = log_sd)
  
  # Inject 2% probability of market squeeze spike (> $350/MWh)
  spike_mask <- runif(n_runs) < 0.025
  prices[spike_mask] <- prices[spike_mask] + runif(sum(spike_mask), 250, 650)
  
  # 2. Stochastic Ambient Temperature (Truncated Normal)
  temps <- rnorm(n_runs, mean = temp_mean, sd = 5.2)
  
  # 3. Dynamic PUE based on ambient temperature and chiller efficiency
  pue <- 1.11 + 0.0038 * pmax(temps - 15.0, 0) + 0.00015 * (temps - 15.0)^2
  
  # 4. Equipment Failures (Bernoulli)
  cooling_failures <- runif(n_runs) < (chiller_failure_prob / 365)
  it_throttling <- ifelse(cooling_failures, 0.40, 1.0) # 40% derate if chiller trips
  
  effective_it_mw <- base_it_mw * it_throttling * runif(n_runs, 0.92, 1.02)
  facility_mw <- effective_it_mw * pue
  
  # 5. Financial & Risk Distributions (Daily Basis)
  daily_energy_cost <- facility_mw * prices * 24
  daily_gpu_revenue <- (effective_it_mw / 0.000700) * 2.85 * 24
  daily_gross_margin <- daily_gpu_revenue - daily_energy_cost - (18500) # fixed daily opex
  
  # Quantiles helper
  calc_quantiles <- function(vec) {
    q <- quantile(vec, probs = c(0.10, 0.50, 0.90))
    list(P10 = round(as.numeric(q[1]), 2),
         P50 = round(as.numeric(q[2]), 2),
         P90 = round(as.numeric(q[3]), 2),
         Mean = round(mean(vec), 2),
         StdDev = round(sd(vec), 2))
  }
  
  results <- list(
    simulations_count = n_runs,
    energy_cost_usd_daily = calc_quantiles(daily_energy_cost),
    revenue_usd_daily = calc_quantiles(daily_gpu_revenue),
    gross_margin_usd_daily = calc_quantiles(daily_gross_margin),
    pue_distribution = calc_quantiles(pue),
    thermal_excursion_probability_pct = round(mean(temps > 38.0) * 100, 2),
    unplanned_derate_probability_pct = round(mean(cooling_failures) * 100, 2),
    value_at_risk_95_pct_usd = round(as.numeric(quantile(daily_energy_cost, 0.95)), 2)
  )
  
  return(results)
}
