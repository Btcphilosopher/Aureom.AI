# ==============================================================================
# DATA CENTRE OPTIMISATION ENGINE - RUST <-> R INTERFACE & JSON IPC BRIDGE
# File: r-engine/interface.R
# ==============================================================================

source("r-engine/forecasting.R")
source("r-engine/monte_carlo.R")
source("r-engine/economics.R")

#' Process incoming JSON telemetry snapshot from Rust Digital Twin
#' and produce statistical risk boundaries and dispatch forecasts
process_rust_twin_payload <- function(json_payload_str) {
  if (is.null(json_payload_str) || nchar(json_payload_str) == 0) {
    stop("Empty Rust twin payload received")
  }
  
  twin_data <- jsonlite::fromJSON(json_payload_str)
  
  # Run R analytics suite
  price_fc <- forecast_electricity_prices(horizon_hours = 24, scenario = "BASE")
  workload_fc <- forecast_workload_demand(current_active_gpus = twin_data$active_gpus, horizon_hours = 24)
  mc_risk <- run_monte_carlo_simulation(n_runs = 5000, base_it_mw = twin_data$it_power_mw)
  
  response <- list(
    status = "SUCCESS",
    timestamp = as.character(Sys.time()),
    facility_id = twin_data$site_id,
    forecast_24h = list(
      electricity_prices = price_fc,
      workload_demand = workload_fc
    ),
    monte_carlo_risk = mc_risk,
    recommended_bess_arbitrage_hours = c(2, 3, 4, 14, 15) # hours to charge/discharge
  )
  
  return(jsonlite::toJSON(response, auto_unbox = TRUE, pretty = TRUE))
}
