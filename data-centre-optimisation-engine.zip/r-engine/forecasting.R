# ==============================================================================
# DATA CENTRE OPTIMISATION ENGINE - R FORECASTING & STATISTICAL MODELLING
# File: r-engine/forecasting.R
# ==============================================================================

suppressPackageStartupMessages({
  if (requireNamespace("jsonlite", quietly = TRUE)) library(jsonlite)
})

#' Forecast Electricity Spot Prices and Volatility
#' Uses Seasonal ARIMA + GARCH-style volatility bounds
forecast_electricity_prices <- function(history_df, horizon_hours = 24, scenario = "BASE") {
  # Synthetic time series if empty
  if (missing(history_df) || nrow(history_df) == 0) {
    hours <- 1:horizon_hours
    base_diurnal <- 45.0 + 35.0 * sin((hours - 6) * pi / 12)
    
    price_mean <- switch(scenario,
      "LOW"     = base_diurnal * 0.70,
      "BASE"    = base_diurnal,
      "HIGH"    = base_diurnal * 1.55 + 25.0,
      "EXTREME" = base_diurnal * 2.80 + 95.0,
      base_diurnal
    )
    
    volatility <- switch(scenario,
      "LOW"     = 4.5,
      "BASE"    = 12.0,
      "HIGH"    = 38.0,
      "EXTREME" = 85.0,
      10.0
    )
    
    forecast_p50 <- pmax(price_mean, 5.0)
    forecast_p10 <- pmax(forecast_p50 - 1.645 * volatility, 0.0)
    forecast_p90 <- forecast_p50 + 1.645 * volatility
    
    return(data.frame(
      hour = hours,
      price_p10 = round(forecast_p10, 2),
      price_p50 = round(forecast_p50, 2),
      price_p90 = round(forecast_p90, 2),
      volatility = round(rep(volatility, horizon_hours), 2)
    ))
  }
  
  # Standard ARIMA forecasting logic
  ts_data <- ts(history_df$price, frequency = 24)
  fit <- arima(ts_data, order = c(2, 1, 1), seasonal = list(order = c(1, 0, 0), period = 24))
  preds <- predict(fit, n.ahead = horizon_hours)
  
  data.frame(
    hour = 1:horizon_hours,
    price_p10 = pmax(as.numeric(preds$pred - 1.645 * preds$se), 0),
    price_p50 = as.numeric(preds$pred),
    price_p90 = as.numeric(preds$pred + 1.645 * preds$se),
    volatility = as.numeric(preds$se)
  )
}

#' Forecast IT Compute and GPU Cluster Workload Demand
forecast_workload_demand <- function(current_active_gpus = 12000, horizon_hours = 24) {
  hours <- 1:horizon_hours
  # AI training runs continuously, while enterprise inference follows business diurnal curve
  inference_demand <- 3500 + 2200 * sin((hours - 8) * pi / 12)
  training_demand <- rep(7800, horizon_hours)
  hpc_batch_demand <- 1200 + 400 * cos(hours * pi / 6)
  
  total_gpu_demand <- pmax(round(inference_demand + training_demand + hpc_batch_demand), 0)
  power_demand_mw <- total_gpu_demand * 0.000720 # 720W average per GPU node
  
  data.frame(
    hour = hours,
    gpu_demand = total_gpu_demand,
    it_power_mw = round(power_demand_mw, 2),
    flexible_pct = ifelse(hours %in% 1:6 | hours %in% 22:24, 0.45, 0.20)
  )
}

#' Forecast Ambient and Wet Bulb Temperatures
forecast_ambient_weather <- function(base_temp_c = 26.0, horizon_hours = 24) {
  hours <- 1:horizon_hours
  diurnal_temp <- base_temp_c + 7.5 * sin((hours - 10) * pi / 12)
  humidity <- 65.0 - 20.0 * sin((hours - 10) * pi / 12)
  wet_bulb <- diurnal_temp - ((100.0 - humidity) / 5.0)
  
  data.frame(
    hour = hours,
    dry_bulb_temp_c = round(diurnal_temp, 1),
    relative_humidity_pct = round(humidity, 1),
    wet_bulb_temp_c = round(wet_bulb, 1),
    free_cooling_viable = wet_bulb <= 14.0
  )
}
