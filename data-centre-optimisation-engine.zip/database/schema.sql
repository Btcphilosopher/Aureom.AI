-- ==============================================================================
-- DATA CENTRE OPTIMISATION ENGINE - RELATIONAL DATABASE SCHEMA (PostgreSQL / SQL)
-- Comprehensive Schema for Digital Twin, Telemetry, Power, Cooling & Analytics
-- ==============================================================================

-- 1. Facility & Spatial Hierarchy
CREATE TABLE IF NOT EXISTS sites (
    site_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    country_code VARCHAR(3) NOT NULL,
    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),
    contracted_power_mw NUMERIC(8,3) NOT NULL,
    peak_power_limit_mw NUMERIC(8,3) NOT NULL,
    tier_rating VARCHAR(16) DEFAULT 'Tier3',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS buildings (
    building_id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(site_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    total_area_sqm NUMERIC(10,2) NOT NULL,
    white_space_area_sqm NUMERIC(10,2) NOT NULL,
    max_cooling_mw NUMERIC(8,3) NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id VARCHAR(64) PRIMARY KEY,
    building_id VARCHAR(64) REFERENCES buildings(building_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    room_type VARCHAR(64) NOT NULL, -- 'AI_SUPERCOMPUTING', 'ENTERPRISE_CLOUD', 'ELECTRICAL_UPS', 'CHILLER_PLANT'
    cooling_topology VARCHAR(64) NOT NULL, -- 'DIRECT_TO_CHIP', 'CHILLED_WATER_CRAH', 'HYBRID'
    design_kw_capacity NUMERIC(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS rows (
    row_id VARCHAR(64) PRIMARY KEY,
    room_id VARCHAR(64) REFERENCES rooms(room_id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    containment_type VARCHAR(32) DEFAULT 'COLD_AISLE',
    max_rack_slots INT NOT NULL
);

CREATE TABLE IF NOT EXISTS racks (
    rack_id VARCHAR(64) PRIMARY KEY,
    row_id VARCHAR(64) REFERENCES rows(row_id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    max_kw_rating NUMERIC(8,2) NOT NULL,
    total_u_height INT DEFAULT 48,
    cooling_mode VARCHAR(32) NOT NULL, -- 'LIQUID_DIRECT', 'AIR_CRAH', 'REAR_DOOR_HX'
    inlet_temp_target_c NUMERIC(4,2) DEFAULT 22.0
);

-- 2. Compute Hardware Assets
CREATE TABLE IF NOT EXISTS servers (
    server_id VARCHAR(64) PRIMARY KEY,
    rack_id VARCHAR(64) REFERENCES racks(rack_id) ON DELETE CASCADE,
    hostname VARCHAR(255) NOT NULL,
    u_position_start INT NOT NULL,
    u_position_end INT NOT NULL,
    form_factor_u INT NOT NULL,
    psu_rated_watts NUMERIC(8,2) NOT NULL,
    cooling_interface VARCHAR(32) DEFAULT 'COLD_PLATE_LIQUID',
    operating_state VARCHAR(32) DEFAULT 'NOMINAL',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gpus (
    gpu_id VARCHAR(64) PRIMARY KEY,
    server_id VARCHAR(64) REFERENCES servers(server_id) ON DELETE CASCADE,
    model VARCHAR(128) NOT NULL, -- 'NVIDIA H100 SXM5', 'NVIDIA B200', 'NVIDIA A100 80GB'
    architecture VARCHAR(64) NOT NULL, -- 'Hopper', 'Blackwell', 'Ampere'
    vram_gb INT NOT NULL,
    tdp_watts NUMERIC(6,2) NOT NULL,
    max_junction_temp_c NUMERIC(4,1) DEFAULT 80.0,
    interconnect_bandwidth_gbps NUMERIC(8,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS cpus (
    cpu_id VARCHAR(64) PRIMARY KEY,
    server_id VARCHAR(64) REFERENCES servers(server_id) ON DELETE CASCADE,
    model VARCHAR(128) NOT NULL,
    cores INT NOT NULL,
    threads INT NOT NULL,
    tdp_watts NUMERIC(6,2) NOT NULL
);

-- 3. Power Infrastructure Assets
CREATE TABLE IF NOT EXISTS substations (
    substation_id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(site_id) ON DELETE CASCADE,
    primary_voltage_kv NUMERIC(6,2) NOT NULL,
    secondary_voltage_kv NUMERIC(6,2) NOT NULL,
    transformer_capacity_mva NUMERIC(8,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS ups_systems (
    ups_id VARCHAR(64) PRIMARY KEY,
    room_id VARCHAR(64) REFERENCES rooms(room_id) ON DELETE CASCADE,
    capacity_kva NUMERIC(8,2) NOT NULL,
    topology VARCHAR(32) DEFAULT 'DOUBLE_CONVERSION_ONLINE',
    redundancy_config VARCHAR(16) DEFAULT '2N',
    efficiency_curve_json JSONB
);

CREATE TABLE IF NOT EXISTS battery_storage (
    bess_id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(site_id) ON DELETE CASCADE,
    chemistry VARCHAR(32) DEFAULT 'LFP',
    capacity_kwh NUMERIC(10,2) NOT NULL,
    max_charge_discharge_kw NUMERIC(8,2) NOT NULL,
    round_trip_efficiency NUMERIC(4,3) DEFAULT 0.895,
    min_reserve_soc_pct NUMERIC(4,1) DEFAULT 20.0
);

CREATE TABLE IF NOT EXISTS generators (
    generator_id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(site_id) ON DELETE CASCADE,
    capacity_kw NUMERIC(8,2) NOT NULL,
    fuel_type VARCHAR(32) DEFAULT 'DIESEL_HVO',
    fuel_capacity_liters NUMERIC(10,2) NOT NULL,
    fuel_consumption_rate_lph NUMERIC(8,2) NOT NULL
);

-- 4. Cooling Infrastructure Assets
CREATE TABLE IF NOT EXISTS chillers (
    chiller_id VARCHAR(64) PRIMARY KEY,
    building_id VARCHAR(64) REFERENCES buildings(building_id) ON DELETE CASCADE,
    chiller_type VARCHAR(64) NOT NULL, -- 'CENTRIFUGAL_WATER_COOLED', 'MAGNETIC_BEARING_VFD'
    rated_cooling_kw NUMERIC(10,2) NOT NULL,
    nominal_cop NUMERIC(4,2) DEFAULT 6.4,
    has_waterside_economizer BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS cdu_liquid_loops (
    cdu_id VARCHAR(64) PRIMARY KEY,
    room_id VARCHAR(64) REFERENCES rooms(room_id) ON DELETE CASCADE,
    cooling_capacity_kw NUMERIC(10,2) NOT NULL,
    max_flow_rate_lpm NUMERIC(8,2) NOT NULL,
    secondary_fluid_type VARCHAR(64) DEFAULT 'PG25_WATER_GLYCOL',
    heat_recovery_connection BOOLEAN DEFAULT TRUE
);

-- 5. Sensors and High-Throughput Time-Series Telemetry
CREATE TABLE IF NOT EXISTS sensors (
    sensor_id VARCHAR(64) PRIMARY KEY,
    asset_id VARCHAR(64) NOT NULL,
    metric_type VARCHAR(64) NOT NULL, -- 'TEMPERATURE', 'POWER_KW', 'FLOW_LPM', 'PRESSURE_BAR', 'VIBRATION'
    unit VARCHAR(16) NOT NULL,
    sampling_frequency_hz INT DEFAULT 1,
    min_threshold NUMERIC(10,3),
    max_threshold NUMERIC(10,3)
);

CREATE TABLE IF NOT EXISTS telemetry_samples (
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id),
    metric_name VARCHAR(64) NOT NULL,
    value NUMERIC(12,4) NOT NULL,
    PRIMARY KEY (sensor_id, timestamp)
);

-- 6. Workloads, Optimization Runs and Audit Logs
CREATE TABLE IF NOT EXISTS workloads (
    job_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL, -- 'AI_TRAINING', 'AI_INFERENCE', 'HPC_SIMULATION', 'CLOUD'
    priority_level INT DEFAULT 3,
    required_gpus INT NOT NULL,
    deadline TIMESTAMP WITH TIME ZONE NOT NULL,
    is_preemptible BOOLEAN DEFAULT FALSE,
    revenue_rate_usd_gpu_hr NUMERIC(6,2) NOT NULL,
    status VARCHAR(32) DEFAULT 'QUEUED'
);

CREATE TABLE IF NOT EXISTS optimization_runs (
    run_id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    solver_algorithm VARCHAR(64) NOT NULL,
    baseline_power_mw NUMERIC(8,3) NOT NULL,
    optimized_power_mw NUMERIC(8,3) NOT NULL,
    pue_achieved NUMERIC(4,3) NOT NULL,
    hourly_cost_savings_usd NUMERIC(10,2) NOT NULL,
    bess_dispatched_kw NUMERIC(8,2) NOT NULL,
    shifted_jobs_count INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS anomaly_alerts (
    alert_id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    asset_id VARCHAR(64) NOT NULL,
    severity VARCHAR(16) NOT NULL,
    metric_name VARCHAR(64) NOT NULL,
    observed_value NUMERIC(10,2) NOT NULL,
    baseline_value NUMERIC(10,2) NOT NULL,
    root_cause_diagnosis TEXT NOT NULL,
    economic_impact_usd_hr NUMERIC(8,2)
);

CREATE TABLE IF NOT EXISTS dc_expansion_scenarios (
    scenario_id VARCHAR(64) PRIMARY KEY,
    expansion_tier_mw INT NOT NULL,
    total_capex_usd NUMERIC(14,2) NOT NULL,
    projected_annual_revenue_usd NUMERIC(14,2) NOT NULL,
    projected_annual_opex_usd NUMERIC(14,2) NOT NULL,
    npv_10yr_usd NUMERIC(14,2) NOT NULL,
    irr_pct NUMERIC(5,2) NOT NULL,
    payback_years NUMERIC(4,2) NOT NULL
);

-- Indexing for real-time telemetry queries
CREATE INDEX IF NOT EXISTS idx_telemetry_time ON telemetry_samples(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_servers_rack ON servers(rack_id);
CREATE INDEX IF NOT EXISTS idx_gpus_server ON gpus(server_id);
CREATE INDEX IF NOT EXISTS idx_workloads_status ON workloads(status);
