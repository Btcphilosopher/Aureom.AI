import { MonteCarloSummary } from '../types';

export function runMonteCarloRiskSimulation(
  runsCount: number = 2000,
  baseItMw: number = 30.5,
  priceMean: number = 88.0,
  priceVolatility: number = 32.0,
  tempMean: number = 27.5
): MonteCarloSummary {
  const dailyCosts: number[] = [];
  const dailyRevs: number[] = [];
  const dailyMargins: number[] = [];
  const pues: number[] = [];
  let thermalExcursionCount = 0;
  let derateCount = 0;

  for (let i = 0; i < runsCount; i++) {
    // 1. Stochastic Price (Box-Muller transform for normal, exponentiated for log-normal)
    const u1 = Math.max(Math.random(), 1e-7);
    const u2 = Math.max(Math.random(), 1e-7);
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    
    let price = Math.max(priceMean + z0 * priceVolatility, 8.0);
    // 2.5% market squeeze spike chance
    if (Math.random() < 0.025) {
      price += 250 + Math.random() * 350;
    }

    // 2. Ambient Temp
    const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);
    const temp = tempMean + z1 * 4.8;
    if (temp > 37.0) thermalExcursionCount++;

    // 3. Dynamic PUE based on weather
    const pue = 1.11 + Math.max(temp - 15, 0) * 0.0035 + (temp > 30 ? 0.04 : 0);
    pues.push(pue);

    // 4. Random minor chiller trip (1.5% daily probability)
    const hasDerate = Math.random() < 0.015;
    if (hasDerate) derateCount++;
    const derateFactor = hasDerate ? 0.65 : 1.0;

    const effectiveItMw = baseItMw * derateFactor * (0.94 + Math.random() * 0.08);
    const facilityMw = effectiveItMw * pue;

    const dailyCost = facilityMw * price * 24;
    const activeGpus = (effectiveItMw * 1000) / 0.700;
    const dailyRev = activeGpus * 2.95 * 24;
    const dailyMargin = dailyRev - dailyCost - 18500; // Subtracting fixed opex

    dailyCosts.push(dailyCost);
    dailyRevs.push(dailyRev);
    dailyMargins.push(dailyMargin);
  }

  dailyCosts.sort((a, b) => a - b);
  dailyRevs.sort((a, b) => a - b);
  dailyMargins.sort((a, b) => a - b);
  pues.sort((a, b) => a - b);

  const getQuantiles = (arr: number[]) => {
    const p10Idx = Math.floor(arr.length * 0.1);
    const p50Idx = Math.floor(arr.length * 0.5);
    const p90Idx = Math.floor(arr.length * 0.9);
    const sum = arr.reduce((a, b) => a + b, 0);
    const mean = sum / arr.length;
    const variance = arr.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / arr.length;
    return {
      p10: Math.round(arr[p10Idx]),
      p50: Math.round(arr[p50Idx]),
      p90: Math.round(arr[p90Idx]),
      mean: Math.round(mean),
      stdDev: Math.round(Math.sqrt(variance)),
    };
  };

  const minCost = dailyCosts[0];
  const maxCost = dailyCosts[dailyCosts.length - 1];
  const binCount = 12;
  const binWidth = (maxCost - minCost) / binCount;
  const distributionHistogram: Array<{ binLabel: string; count: number; costRange: number }> = [];

  for (let b = 0; b < binCount; b++) {
    const binStart = minCost + b * binWidth;
    const binEnd = binStart + binWidth;
    const count = dailyCosts.filter((c) => c >= binStart && (b === binCount - 1 ? c <= binEnd : c < binEnd)).length;
    distributionHistogram.push({
      binLabel: `$${Math.round(binStart / 1000)}k - $${Math.round(binEnd / 1000)}k`,
      count,
      costRange: Math.round((binStart + binEnd) / 2),
    });
  }

  const var95Idx = Math.floor(dailyCosts.length * 0.95);

  return {
    simulationsCount: runsCount,
    dailyEnergyCost: getQuantiles(dailyCosts),
    dailyRevenue: getQuantiles(dailyRevs),
    dailyNetMargin: getQuantiles(dailyMargins),
    pueDistribution: {
      p10: Number(pues[Math.floor(pues.length * 0.1)].toFixed(3)),
      p50: Number(pues[Math.floor(pues.length * 0.5)].toFixed(3)),
      p90: Number(pues[Math.floor(pues.length * 0.9)].toFixed(3)),
    },
    thermalExcursionProbabilityPct: Number(((thermalExcursionCount / runsCount) * 100).toFixed(2)),
    unplannedDerateProbabilityPct: Number(((derateCount / runsCount) * 100).toFixed(2)),
    valueAtRisk95PctUsd: Math.round(dailyCosts[var95Idx]),
    distributionHistogram,
  };
}
