import { DcExpansionOption } from '../types';

export function calculateDcExpansions(
  wacc: number = 0.085,
  gridPriceMwh: number = 78.0,
  gpuRevPerHour: number = 2.85,
  targetPue: number = 1.13
): DcExpansionOption[] {
  const tiers = [1, 5, 10, 50, 100];
  const powerCapexPerMw = 4200000;
  const coolingCapexPerMw = 3100000;
  const civilCapexPerMw = 1800000;
  const computeCapexPerMw = 14500000;
  const discountYears = 10;

  return tiers.map((mw) => {
    const powerCapex = mw * powerCapexPerMw;
    const coolingCapex = mw * coolingCapexPerMw;
    const civilCapex = mw * civilCapexPerMw;
    const computeCapex = mw * computeCapexPerMw;
    const totalCapex = powerCapex + coolingCapex + civilCapex + computeCapex;

    const activeGpus = Math.round((mw * 1000) / 0.700);
    const annualGpuHours = activeGpus * 8760 * 0.92;
    const annualRevenue = annualGpuHours * gpuRevPerHour;

    const annualEnergyMwh = mw * targetPue * 8760;
    const annualEnergyCost = annualEnergyMwh * gridPriceMwh;
    const annualMaintenanceOpex = totalCapex * 0.035;
    const totalAnnualOpex = annualEnergyCost + annualMaintenanceOpex;

    const annualNetCashflow = annualRevenue - totalAnnualOpex;

    let pvCashflows = 0;
    for (let yr = 1; yr <= discountYears; yr++) {
      pvCashflows += annualNetCashflow / Math.pow(1 + wacc, yr);
    }
    const npv = pvCashflows - totalCapex;
    const payback = totalCapex / annualNetCashflow;
    const irrEstimate = (annualNetCashflow / totalCapex) * 1.05 - 1 / discountYears;

    return {
      expansionMw: mw,
      activeGpusAdded: activeGpus,
      capexBreakdownUsd: {
        powerInfrastructure: powerCapex,
        coolingInfrastructure: coolingCapex,
        civilAndBuilding: civilCapex,
        itAndGpuHardware: computeCapex,
        totalCapex,
      },
      annualMetricsUsd: {
        grossRevenue: Math.round(annualRevenue),
        energyCost: Math.round(annualEnergyCost),
        maintenanceOpex: Math.round(annualMaintenanceOpex),
        netOperatingCashflow: Math.round(annualNetCashflow),
      },
      financialValuation: {
        npv10YearUsd: Math.round(npv),
        irrPct: Number((irrEstimate * 100).toFixed(1)),
        paybackYears: Number(payback.toFixed(1)),
        costPerGpuHourUsd: Number((totalAnnualOpex / annualGpuHours).toFixed(3)),
      },
    };
  });
}
