import {
  DataCentreTwinState,
  FacilityTier,
  RoomTwin,
  RowTwin,
  RackAsset,
  ServerAsset,
  TelemetrySnapshot,
  WorkloadJob,
  AnomalyAlert,
} from '../types';

export function createInitialTwin(): DataCentreTwinState {
  // Room 1: AI Supercomputing Hall (Direct-to-Chip Liquid Cooling + Cold Aisle Containment)
  const aiRows: RowTwin[] = [];
  for (let r = 1; r <= 4; r++) {
    const racks: RackAsset[] = [];
    for (let k = 1; k <= 6; k++) {
      const rackId = `RACK-AI-R${r}-0${k}`;
      const servers: ServerAsset[] = [];
      
      // 8x 4U High-Density GPU Nodes per Rack (32U used out of 48U)
      for (let s = 1; s <= 8; s++) {
        const uStart = (s - 1) * 4 + 1;
        const isB200 = r === 1 && k <= 3;
        const gpuModel = isB200 ? 'NVIDIA B200 SXM6' : 'NVIDIA H100 SXM5';
        const arch = isB200 ? 'Blackwell' : 'Hopper';
        const vram = isB200 ? 192 : 80;
        const tdpGpu = isB200 ? 1000 : 700;

        servers.push({
          assetId: `SRV-AI-${r}${k}-${s}`,
          hostname: `ai-node-${r}${k}-${s}.dc-alpha.net`,
          formFactorU: 4,
          uStart,
          uEnd: uStart + 3,
          cpus: [
            {
              cpuId: `CPU-${r}${k}-${s}-01`,
              model: 'Intel Xeon Platinum 8592+ (64C/128T)',
              cores: 64,
              threads: 128,
              tdpWatts: 350,
              currentUtilizationPct: 68 + Math.random() * 20,
              currentTempC: 46 + Math.random() * 5,
              currentPowerWatts: 260 + Math.random() * 40,
            },
            {
              cpuId: `CPU-${r}${k}-${s}-02`,
              model: 'Intel Xeon Platinum 8592+ (64C/128T)',
              cores: 64,
              threads: 128,
              tdpWatts: 350,
              currentUtilizationPct: 65 + Math.random() * 20,
              currentTempC: 45 + Math.random() * 5,
              currentPowerWatts: 255 + Math.random() * 40,
            },
          ],
          gpus: Array.from({ length: 8 }).map((_, gIdx) => ({
            gpuId: `GPU-${r}${k}-${s}-${gIdx + 1}`,
            model: gpuModel,
            architecture: arch,
            vramGb: vram,
            tdpWatts: tdpGpu,
            maxJunctionTempC: 82,
            interconnectGbps: 900,
            currentUtilizationPct: 82 + Math.random() * 16,
            currentTempC: 56 + Math.random() * 8,
            currentPowerWatts: tdpGpu * (0.85 + Math.random() * 0.12),
          })),
          memoryGb: 2048,
          storageTb: 30.72,
          networkGbps: 3200,
          coolingType: 'DirectToChipLiquid',
          state: 'Nominal',
          powerDrawKw: (tdpGpu * 8 * 0.88 + 700) / 1000,
          inletTempC: 21.5 + Math.random() * 1.5,
          exhaustTempC: 38.0 + Math.random() * 3.0,
        });
      }

      const rackPowerKw = servers.reduce((sum, s) => sum + s.powerDrawKw, 0);

      racks.push({
        rackId,
        rowId: `ROW-AI-0${r}`,
        name: `AI Density Rack R${r}-0${k}`,
        maxKwCapacity: 65.0,
        currentKwLoad: rackPowerKw,
        maxUnits: 48,
        usedUnits: 32,
        coolingTopology: 'DirectToChipLiquid',
        inletAirTempC: 22.0 + Math.random() * 1.8,
        exhaustAirTempC: 39.5 + Math.random() * 2.5,
        coolantSupplyTempC: 32.5,
        coolantReturnTempC: 58.2 + Math.random() * 2.0,
        liquidFlowLpm: 48.5 + Math.random() * 3.0,
        servers,
      });
    }

    aiRows.push({
      rowId: `ROW-AI-0${r}`,
      name: `AI Supercomputing Row 0${r}`,
      containmentType: 'Cold Aisle',
      racks,
    });
  }

  // Room 2: Enterprise Cloud & Accelerated Database Hall (CRAH Air Cooled)
  const cloudRows: RowTwin[] = [];
  for (let r = 1; r <= 3; r++) {
    const racks: RackAsset[] = [];
    for (let k = 1; k <= 6; k++) {
      const rackId = `RACK-CLOUD-R${r}-0${k}`;
      const servers: ServerAsset[] = [];
      
      // 16x 2U Standard Cloud Compute Nodes per Rack (32U used)
      for (let s = 1; s <= 16; s++) {
        const uStart = (s - 1) * 2 + 1;
        servers.push({
          assetId: `SRV-CLD-${r}${k}-${s}`,
          hostname: `cld-node-${r}${k}-${s}.dc-alpha.net`,
          formFactorU: 2,
          uStart,
          uEnd: uStart + 1,
          cpus: [
            {
              cpuId: `CPU-CLD-${r}${k}-${s}-01`,
              model: 'AMD EPYC 9654 (96C/192T)',
              cores: 96,
              threads: 192,
              tdpWatts: 360,
              currentUtilizationPct: 54 + Math.random() * 25,
              currentTempC: 52 + Math.random() * 6,
              currentPowerWatts: 220 + Math.random() * 60,
            },
          ],
          gpus: s % 4 === 0 ? [
            {
              gpuId: `GPU-A100-${r}${k}-${s}-1`,
              model: 'NVIDIA A100 PCIe 80GB',
              architecture: 'Ampere',
              vramGb: 80,
              tdpWatts: 300,
              maxJunctionTempC: 84,
              interconnectGbps: 64,
              currentUtilizationPct: 62 + Math.random() * 20,
              currentTempC: 64 + Math.random() * 6,
              currentPowerWatts: 210 + Math.random() * 40,
            }
          ] : [],
          memoryGb: 768,
          storageTb: 15.36,
          networkGbps: 100,
          coolingType: 'ChilledWaterCRAH',
          state: 'Nominal',
          powerDrawKw: 0.68 + Math.random() * 0.25,
          inletTempC: 22.8 + Math.random() * 1.2,
          exhaustTempC: 36.2 + Math.random() * 2.0,
        });
      }

      const rackPowerKw = servers.reduce((sum, s) => sum + s.powerDrawKw, 0);

      racks.push({
        rackId,
        rowId: `ROW-CLD-0${r}`,
        name: `Enterprise Cloud Rack R${r}-0${k}`,
        maxKwCapacity: 20.0,
        currentKwLoad: rackPowerKw,
        maxUnits: 48,
        usedUnits: 32,
        coolingTopology: 'ChilledWaterCRAH',
        inletAirTempC: 23.1 + Math.random() * 1.5,
        exhaustAirTempC: 35.8 + Math.random() * 2.0,
        servers,
      });
    }

    cloudRows.push({
      rowId: `ROW-CLD-0${r}`,
      name: `Enterprise Cloud Row 0${r}`,
      containmentType: 'Hot Aisle',
      racks,
    });
  }

  const aiRoomPower = aiRows.reduce((sum, r) => sum + r.racks.reduce((rs, rk) => rs + rk.currentKwLoad, 0), 0);
  const cloudRoomPower = cloudRows.reduce((sum, r) => sum + r.racks.reduce((rs, rk) => rs + rk.currentKwLoad, 0), 0);

  const rooms: RoomTwin[] = [
    {
      roomId: 'ROOM-AI-HALL-A',
      name: 'Data Hall 1: AI Supercomputing Cluster',
      roomType: 'AI Supercomputing',
      coolingTopology: 'DirectToChipLiquid',
      maxCapacityKw: 25000,
      currentLoadKw: aiRoomPower,
      targetTempC: 22.0,
      currentTempC: 22.8,
      humidityPct: 48.5,
      rows: aiRows,
    },
    {
      roomId: 'ROOM-CLOUD-HALL-B',
      name: 'Data Hall 2: Enterprise Cloud & DB',
      roomType: 'Enterprise Cloud',
      coolingTopology: 'ChilledWaterCRAH',
      maxCapacityKw: 10000,
      currentLoadKw: cloudRoomPower,
      targetTempC: 23.0,
      currentTempC: 23.6,
      humidityPct: 50.2,
      rows: cloudRows,
    },
  ];

  return {
    siteId: 'SITE-EU-WEST-01',
    name: 'Helios Hyperscale & AI Supercomputing Campus Alpha',
    location: 'Frankfurt Metro, Germany',
    tier: 'Tier3' as FacilityTier,
    contractedPowerMw: 45.0,
    peakPowerLimitMw: 48.5,
    coolingDesignMw: 14.0,
    totalFloorAreaSqm: 18500,
    rooms,
    upsSystems: [
      {
        assetId: 'UPS-2N-SYSTEM-A',
        capacityKva: 24000,
        activeLoadKw: 18200,
        efficiencyPct: 96.8,
        redundancyMode: '2N Distributed Dual-Bus',
        batterySocPct: 99.4,
        batteryRuntimeMinutes: 18.5,
        state: 'Nominal',
      },
      {
        assetId: 'UPS-2N-SYSTEM-B',
        capacityKva: 24000,
        activeLoadKw: 18200,
        efficiencyPct: 96.8,
        redundancyMode: '2N Distributed Dual-Bus',
        batterySocPct: 99.4,
        batteryRuntimeMinutes: 18.5,
        state: 'Nominal',
      },
    ],
    batteryStorage: [
      {
        assetId: 'BESS-GRID-STORAGE-10MW',
        totalCapacityKwh: 20000, // 20 MWh LFP battery
        currentSocPct: 78.5,
        maxChargeKw: 6000,
        maxDischargeKw: 6000,
        currentPowerKw: 0, // Idle by default
        roundTripEfficiency: 0.895,
        healthSohPct: 98.2,
        cyclesCompleted: 248,
      },
    ],
    backupGenerators: [
      {
        assetId: 'GEN-SET-DIESEL-01',
        capacityKw: 3500,
        fuelType: 'Hydrotreated Vegetable Oil (HVO)',
        fuelRemainingLiters: 45000,
        fuelBurnRateLPerHr: 820,
        startupLatencySeconds: 9,
        isRunning: false,
        powerOutputKw: 0,
      },
      {
        assetId: 'GEN-SET-DIESEL-02',
        capacityKw: 3500,
        fuelType: 'Hydrotreated Vegetable Oil (HVO)',
        fuelRemainingLiters: 45000,
        fuelBurnRateLPerHr: 820,
        startupLatencySeconds: 9,
        isRunning: false,
        powerOutputKw: 0,
      },
      {
        assetId: 'GEN-SET-DIESEL-03',
        capacityKw: 3500,
        fuelType: 'Hydrotreated Vegetable Oil (HVO)',
        fuelRemainingLiters: 42000,
        fuelBurnRateLPerHr: 820,
        startupLatencySeconds: 9,
        isRunning: false,
        powerOutputKw: 0,
      },
    ],
    chillers: [
      {
        assetId: 'CHILLER-CENTRIFUGAL-01',
        ratedCoolingKw: 6000,
        currentCoolingKw: 4200,
        electricalPowerKw: 677,
        cop: 6.2,
        chilledWaterSupplyTempC: 12.0,
        chilledWaterReturnTempC: 18.5,
        condenserWaterSupplyTempC: 28.0,
        compressorSpeedPct: 74,
        state: 'Nominal',
      },
      {
        assetId: 'CHILLER-CENTRIFUGAL-02',
        ratedCoolingKw: 6000,
        currentCoolingKw: 4100,
        electricalPowerKw: 661,
        cop: 6.2,
        chilledWaterSupplyTempC: 12.0,
        chilledWaterReturnTempC: 18.5,
        condenserWaterSupplyTempC: 28.0,
        compressorSpeedPct: 72,
        state: 'Nominal',
      },
    ],
    cduLoops: [
      {
        loopId: 'CDU-LOOP-AI-PRIMARY',
        cduId: 'CDU-RITTAL-1200KW-01',
        coolingCapacityKw: 12000,
        currentHeatRejectionKw: 9800,
        supplyTempC: 32.0,
        returnTempC: 56.5,
        flowRateLpm: 680,
        pressureDropBar: 1.45,
        pumpPowerKw: 34.5,
        heatRecoveryActive: true,
        heatRecoveredKw: 7200,
      },
    ],
  };
}

export function createInitialWorkloadQueue(): WorkloadJob[] {
  return [
    {
      jobId: 'JOB-AI-TR-01',
      name: 'Llama-3 70B MoE Continual Pretraining (Epoch 14)',
      category: 'AITraining',
      priority: 2,
      requiredGpus: 1024,
      requiredVramGb: 80,
      requiredCpus: 256,
      estimatedDurationHours: 48,
      deadlineHoursRemaining: 72,
      maxAcceptableLatencyMs: 50,
      isPreemptible: true,
      revenueRateUsdPerGpuHr: 3.20,
      powerScalingFactor: 0.96,
      currentStatus: 'Running',
    },
    {
      jobId: 'JOB-AI-INF-02',
      name: 'High-Throughput Realtime RAG Embeddings & LLM API',
      category: 'AIInference',
      priority: 1, // Critical SLA
      requiredGpus: 512,
      requiredVramGb: 80,
      requiredCpus: 128,
      estimatedDurationHours: 240,
      deadlineHoursRemaining: 240,
      maxAcceptableLatencyMs: 15,
      isPreemptible: false,
      revenueRateUsdPerGpuHr: 4.80,
      powerScalingFactor: 0.82,
      currentStatus: 'Running',
    },
    {
      jobId: 'JOB-HPC-SIM-03',
      name: 'European Medium-Range Weather ECMWF Ensemble',
      category: 'HighPerformanceComputing',
      priority: 2,
      requiredGpus: 256,
      requiredVramGb: 80,
      requiredCpus: 512,
      estimatedDurationHours: 12,
      deadlineHoursRemaining: 18,
      maxAcceptableLatencyMs: 100,
      isPreemptible: false,
      revenueRateUsdPerGpuHr: 2.65,
      powerScalingFactor: 0.90,
      currentStatus: 'Running',
    },
    {
      jobId: 'JOB-AI-BATCH-04',
      name: 'Synthetic Video Diffusion GenAI Batch Render',
      category: 'AITraining',
      priority: 4, // Flexible Opportunistic
      requiredGpus: 384,
      requiredVramGb: 80,
      requiredCpus: 96,
      estimatedDurationHours: 16,
      deadlineHoursRemaining: 36,
      maxAcceptableLatencyMs: 500,
      isPreemptible: true,
      revenueRateUsdPerGpuHr: 2.10,
      powerScalingFactor: 0.92,
      currentStatus: 'Running',
    },
    {
      jobId: 'JOB-DB-CLD-05',
      name: 'Global Financial Ledger Real-time Postgres Shards',
      category: 'RealtimeDatabase',
      priority: 1,
      requiredGpus: 0,
      requiredVramGb: 0,
      requiredCpus: 384,
      estimatedDurationHours: 720,
      deadlineHoursRemaining: 720,
      maxAcceptableLatencyMs: 5,
      isPreemptible: false,
      revenueRateUsdPerGpuHr: 1.80,
      powerScalingFactor: 0.70,
      currentStatus: 'Running',
    },
  ];
}

export function computeTelemetrySnapshot(
  twin: DataCentreTwinState,
  spotPriceMwh: number,
  ambientTempC: number,
  gridCarbonGCo2Kwh: number,
  bessDischargeKw: number = 0,
  activeBottleneckOverride?: string
): TelemetrySnapshot {
  let totalItKw = 0;
  let totalGpus = 0;
  let activeGpus = 0;
  let totalTflops = 0;
  let maxRackTemp = 20;

  twin.rooms.forEach((room) => {
    room.rows.forEach((row) => {
      row.racks.forEach((rack) => {
        totalItKw += rack.currentKwLoad;
        if (rack.inletAirTempC > maxRackTemp) {
          maxRackTemp = rack.inletAirTempC;
        }
        rack.servers.forEach((server) => {
          server.gpus.forEach((gpu) => {
            totalGpus++;
            if (gpu.currentUtilizationPct > 10) {
              activeGpus++;
              const flops = gpu.model.includes('B200') ? 4500 : gpu.model.includes('H100') ? 2000 : 620;
              totalTflops += flops * (gpu.currentUtilizationPct / 100);
            }
          });
        });
      });
    });
  });

  const itPowerMw = totalItKw / 1000;
  
  // Cooling Power: Direct-to-Chip CDU pumps (approx 3% of IT) + Chillers (COP ~ 6.0) + Auxiliary air CRAHs
  const chillerKw = twin.chillers.reduce((sum, c) => sum + c.electricalPowerKw, 0);
  const cduPumpKw = twin.cduLoops.reduce((sum, c) => sum + c.pumpPowerKw, 0);
  const coolingPowerMw = (chillerKw + cduPumpKw + totalItKw * 0.04) / 1000;
  const auxPowerMw = 0.45; // Lighting, BMS, sub-panels

  const upsLossesMw = itPowerMw * (1 - 0.968);
  const transformerLossesMw = (itPowerMw + coolingPowerMw + auxPowerMw) * 0.015;
  
  const grossDemandMw = itPowerMw + coolingPowerMw + auxPowerMw + upsLossesMw + transformerLossesMw;
  const bessMw = bessDischargeKw / 1000;
  const gridImportMw = Math.max(grossDemandMw - bessMw, 0);
  
  const instantaneousPue = grossDemandMw / Math.max(itPowerMw, 0.01);
  const itHeadroomMw = twin.contractedPowerMw * 0.85 - itPowerMw;
  const coolingHeadroomMw = twin.coolingDesignMw - coolingPowerMw;

  const humidity = 52.0;
  const wetBulb = ambientTempC - (100 - humidity) / 5.0;

  const heatRecoveredMw = twin.cduLoops.reduce(
    (sum, c) => sum + (c.heatRecoveryActive ? c.heatRecoveredKw / 1000 : 0),
    0
  );

  const hourlyEnergyCost = gridImportMw * spotPriceMwh;
  // Compute revenue: ~$3.10 average per active GPU hour
  const hourlyGrossRevenue = activeGpus * 3.10 + heatRecoveredMw * 32.0;
  const hourlyNetMargin = hourlyGrossRevenue - hourlyEnergyCost - 220.0;

  const avgGpuUtil = totalGpus > 0 ? (activeGpus / totalGpus) * 100 : 0;

  let activeBottleneck = activeBottleneckOverride || 'Nominal - Balanced Capacity Across Domains';
  if (!activeBottleneckOverride) {
    if (itHeadroomMw < 2.0) {
      activeBottleneck = 'Grid Substation 45MW Interconnection Headroom';
    } else if (maxRackTemp > 28.5) {
      activeBottleneck = 'High-Density AI Row 03 Hot-Spot Thermal Limit';
    } else if (avgGpuUtil > 90.0) {
      activeBottleneck = 'GPU Interconnect NVLink Fabric Availability';
    }
  }

  const bess = twin.batteryStorage[0];

  return {
    timestamp: new Date().toISOString(),
    gridPowerMw: Number(gridImportMw.toFixed(3)),
    itPowerMw: Number(itPowerMw.toFixed(3)),
    coolingPowerMw: Number(coolingPowerMw.toFixed(3)),
    auxiliaryPowerMw: Number(auxPowerMw.toFixed(3)),
    totalFacilityPowerMw: Number(grossDemandMw.toFixed(3)),
    instantaneousPue: Number(instantaneousPue.toFixed(3)),
    itCapacityHeadroomMw: Number(itHeadroomMw.toFixed(2)),
    coolingCapacityHeadroomMw: Number(coolingHeadroomMw.toFixed(2)),
    spotElectricityPricePerMwh: Number(spotPriceMwh.toFixed(2)),
    gridCarbonIntensityGCo2PerKwh: Number(gridCarbonGCo2Kwh.toFixed(1)),
    ambientOutsideTempC: Number(ambientTempC.toFixed(1)),
    ambientRelativeHumidityPct: Number(humidity.toFixed(1)),
    wetBulbTempC: Number(wetBulb.toFixed(1)),
    totalGpuCount: totalGpus,
    activeGpus,
    averageGpuUtilizationPct: Number(avgGpuUtil.toFixed(1)),
    totalTflopsDelivered: Number(totalTflops.toFixed(0)),
    bessSocPct: bess ? Number(bess.currentSocPct.toFixed(1)) : 80.0,
    bessPowerKw: bessDischargeKw,
    generatorPowerKw: 0,
    districtHeatRecoveredMw: Number(heatRecoveredMw.toFixed(2)),
    hourlyEnergyCostUsd: Number(hourlyEnergyCost.toFixed(2)),
    hourlyGrossRevenueUsd: Number(hourlyGrossRevenue.toFixed(2)),
    hourlyNetMarginUsd: Number(hourlyNetMargin.toFixed(2)),
    activeBottleneck,
    thermalRiskScore: Number(((maxRackTemp - 18) / 15).toFixed(2)),
  };
}

export function calculateSnapshot(
  twin: DataCentreTwinState,
  scenario?: {
    spotPriceModifier: number;
    ambientTempC: number;
    gridCarbonIntensity: number;
  }
): TelemetrySnapshot {
  const spotPrice = scenario ? scenario.spotPriceModifier : 75.0;
  const ambient = scenario ? scenario.ambientTempC : 22.0;
  const carbon = scenario ? scenario.gridCarbonIntensity : 180.0;
  const bessKw = twin.batteryStorage[0]?.currentPowerKw || 0;
  return computeTelemetrySnapshot(twin, spotPrice, ambient, carbon, bessKw);
}

export function detectAnomalies(twin: DataCentreTwinState): AnomalyAlert[] {
  const alerts: AnomalyAlert[] = [];

  twin.rooms.forEach((room) => {
    room.rows.forEach((row) => {
      row.racks.forEach((rack) => {
        if (rack.inletAirTempC > 27.5) {
          alerts.push({
            alertId: `ANOM-RACK-${rack.rackId}`,
            timestamp: new Date().toISOString(),
            assetId: rack.rackId,
            severity: rack.inletAirTempC > 31 ? 'Critical' : 'Warning',
            title: `Thermal Excursion at ${rack.name}`,
            description: `Inlet air reached ${rack.inletAirTempC.toFixed(1)}°C (ASHRAE A1 upper boundary 27°C). Risk of GPU clock throttling.`,
            observedValue: Number(rack.inletAirTempC.toFixed(1)),
            baselineExpected: 22.0,
            unit: '°C',
            economicImpactUsdHr: 280,
            recommendedAction: 'Increase CRAH supply fan static pressure or inspect containment brush strips.',
          });
        }
      });
    });
  });

  twin.chillers.forEach((chiller) => {
    if (chiller.cop < 5.4) {
      alerts.push({
        alertId: `ANOM-CHILLER-${chiller.assetId}`,
        timestamp: new Date().toISOString(),
        assetId: chiller.assetId,
        severity: 'Warning',
        title: `Chiller Efficiency Degradation (${chiller.assetId})`,
        description: `Operating COP at ${chiller.cop.toFixed(2)} vs nominal 6.20 (-13% thermodynamic drop).`,
        observedValue: Number(chiller.cop.toFixed(2)),
        baselineExpected: 6.2,
        unit: 'COP',
        economicImpactUsdHr: 160,
        recommendedAction: 'Verify condenser water delta-T and check for heat exchanger biofouling.',
      });
    }
  });

  return alerts;
}
