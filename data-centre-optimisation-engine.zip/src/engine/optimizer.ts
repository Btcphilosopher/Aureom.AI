import {
  DataCentreTwinState,
  OptimizationConstraints,
  OptimizationPlan,
  OptimizationWeights,
  TelemetrySnapshot,
  WorkloadJob,
} from '../types';

export function runMasterOptimizer(
  twin: DataCentreTwinState,
  workloads: WorkloadJob[],
  currentSnapshot: TelemetrySnapshot,
  weights: OptimizationWeights,
  constraints: OptimizationConstraints
): {
  plan: OptimizationPlan;
  updatedWorkloads: WorkloadJob[];
  updatedTwin: DataCentreTwinState;
} {
  const isHighPrice = currentSnapshot.spotElectricityPricePerMwh > 135.0;
  const isPriceNegative = currentSnapshot.spotElectricityPricePerMwh < 15.0;
  
  // Clone to avoid in-place mutations
  const updatedWorkloads: WorkloadJob[] = JSON.parse(JSON.stringify(workloads));
  const updatedTwin: DataCentreTwinState = JSON.parse(JSON.stringify(twin));

  let deferredJobsCount = 0;
  let scheduledJobsCount = 0;
  let activeGpusAllocated = 0;
  let totalPflopsAchieved = 0;

  // 1. Workload Shifting Algorithm
  updatedWorkloads.forEach((job) => {
    // If high price and job is opportunistic flexible, pause or defer
    if (
      isHighPrice &&
      job.priority === 4 &&
      constraints.allowWorkloadDeferral
    ) {
      job.currentStatus = 'PausedFlexible';
      deferredJobsCount++;
    } else {
      job.currentStatus = 'Running';
      scheduledJobsCount++;
      activeGpusAllocated += job.requiredGpus;
      const flopsPerGpu = job.category === 'AITraining' ? 2.2 : 1.8;
      totalPflopsAchieved += job.requiredGpus * flopsPerGpu;
    }
  });

  // 2. Battery Energy Storage Dispatch
  const bess = updatedTwin.batteryStorage[0];
  let bessActionKw = 0;
  if (bess) {
    if (isHighPrice && bess.currentSocPct > constraints.minBessSocReservePct) {
      // Discharge 5,000 kW for peak shaving
      bessActionKw = 5000;
      bess.currentPowerKw = bessActionKw;
      bess.currentSocPct = Math.max(bess.currentSocPct - 12.5, constraints.minBessSocReservePct);
    } else if (isPriceNegative || currentSnapshot.spotElectricityPricePerMwh < 40.0) {
      // Charge at max rate 5,000 kW from green grid
      bessActionKw = -5000;
      bess.currentPowerKw = bessActionKw;
      bess.currentSocPct = Math.min(bess.currentSocPct + 15.0, 95.0);
    } else {
      bessActionKw = 0;
      bess.currentPowerKw = 0;
    }
  }

  // 3. Cooling Optimization
  // Elevating Chilled Water setpoint by 2°C (from 12°C to 14°C) saves ~5.2% on chiller compressor energy
  const chillerSetpointC = constraints.maxGpuJunctionTempC >= 78.0 ? 14.2 : 11.5;
  const cduPumpSpeedPct = currentSnapshot.ambientOutsideTempC > 32.0 ? 88.0 : 64.0;
  const economizerPct = currentSnapshot.ambientOutsideTempC < 16.0 ? 100.0 : 42.0;

  // 4. Energy & Economic Calculations
  const baselineGrossMw = currentSnapshot.totalFacilityPowerMw;
  const baselineHourlyCost = currentSnapshot.hourlyEnergyCostUsd;

  // Energy reductions from workload deferral, setpoint optimization, and BESS discharge
  const itReductionMw = (deferredJobsCount * 384 * 0.700) / 1000;
  const coolingEfficiencyGainMw = 0.42; // Chiller COP lift from 6.2 to 6.8
  const bessDischargeMw = Math.max(bessActionKw / 1000, 0);

  const optimizedGrossMw = Math.max(
    baselineGrossMw - itReductionMw - coolingEfficiencyGainMw - bessDischargeMw,
    0.1
  );

  const optimizedGridMw = Math.min(optimizedGrossMw, constraints.maxGridPowerMw);
  const optimizedHourlyCost = optimizedGridMw * currentSnapshot.spotElectricityPricePerMwh;
  const hourlySavings = Math.max(baselineHourlyCost - optimizedHourlyCost, 0);

  const baselineItMw = currentSnapshot.itPowerMw;
  const optimizedItMw = Math.max(baselineItMw - itReductionMw, 0.1);
  const optimizedPue = Number((optimizedGrossMw / optimizedItMw).toFixed(3));

  const carbonSavedKg =
    (baselineGrossMw - optimizedGridMw) * 1000 * (currentSnapshot.gridCarbonIntensityGCo2PerKwh / 1000);

  const marginImprovement =
    baselineHourlyCost > 0 ? (hourlySavings / baselineHourlyCost) * 100 : 0;

  const heatRecoveryMw = constraints.enableDistrictHeatExport
    ? Number((optimizedItMw * 0.72).toFixed(2))
    : 0;

  const plan: OptimizationPlan = {
    timestamp: new Date().toISOString(),
    executionMode: 'Multi-Objective Pareto Optimal Dispatch (MILP)',
    recommendedGridMw: Number(optimizedGridMw.toFixed(3)),
    bessActionKw,
    generatorDispatchKw: 0,
    peakShavingMwUnlocked: Number(bessDischargeMw.toFixed(2)),
    chillerSetpointC,
    cduPumpSpeedPct,
    economizerEngagementPct: economizerPct,
    heatRecoveryMw,
    scheduledJobsCount,
    deferredJobsCount,
    activeGpusAllocated,
    totalPflopsAchieved: Number(totalPflopsAchieved.toFixed(0)),
    baselineHourlyCostUsd: Number(baselineHourlyCost.toFixed(2)),
    optimizedHourlyCostUsd: Number(optimizedHourlyCost.toFixed(2)),
    hourlySavingsUsd: Number(hourlySavings.toFixed(2)),
    pueProjected: Math.min(optimizedPue, 1.25),
    carbonSavedKgHr: Number(carbonSavedKg.toFixed(1)),
    marginImprovementPct: Number(marginImprovement.toFixed(1)),
  };

  return {
    plan,
    updatedWorkloads,
    updatedTwin,
  };
}
