import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Layers,
  Zap,
  Flame,
  Cpu,
  Building,
  CheckCircle2,
  PieChart,
  ArrowUpRight,
} from 'lucide-react';
import { DcExpansionOption } from '../types';

interface Props {
  options: DcExpansionOption[];
}

export const CapacityPlanningView: React.FC<Props> = ({ options }) => {
  const [selectedMw, setSelectedMw] = useState<number>(options[2]?.expansionMw || 10);
  const selectedOption = options.find((o) => o.expansionMw === selectedMw) || options[0];

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-[#F27D26]" />
            <span>Capacity Planning & Modular Data Centre Expansion Economics</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            10-Year DCF NPV &bull; Internal Rate of Return (IRR) &bull; Levelized Cost of Compute ($/GPU-hr)
          </p>
        </div>
        <div className="flex items-center space-x-1 font-mono">
          {options.map((opt) => (
            <button
              key={opt.expansionMw}
              id={`btn-mw-${opt.expansionMw}`}
              onClick={() => setSelectedMw(opt.expansionMw)}
              className={`px-3 py-1 border border-[#141414] text-xs transition-all font-bold ${
                selectedMw === opt.expansionMw
                  ? 'bg-[#F27D26] text-black'
                  : 'bg-white text-[#141414] hover:bg-[#F9F8F6]'
              }`}
            >
              +{opt.expansionMw} MW
            </button>
          ))}
        </div>
      </div>

      {/* Selected Expansion Module Deep-Dive */}
      {selectedOption && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono">
          {/* Left: Financial Returns & Summary (5 cols) */}
          <div className="lg:col-span-5 border-main bg-white p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[#141414] pb-2">
              <div>
                <div className="text-sm font-bold text-[#141414] uppercase font-serif">
                  +{selectedOption.expansionMw} MW Modular Hall
                </div>
                <div className="text-[10px] text-[#F27D26] mt-0.5">
                  +{selectedOption.activeGpusAdded.toLocaleString()} AI GPUs Added
                </div>
              </div>
              <span className="label bg-[#F0EFED] border border-[#141414] px-1.5 py-0.5">
                WACC: 8.5%
              </span>
            </div>

            {/* Big 3 Financial Metric Tiles */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="border-main p-2 bg-[#F9F8F6]">
                <div className="label">10-Yr NPV</div>
                <div className="data-value text-sm text-[#16A34A] mt-0.5">
                  +${(selectedOption.financialValuation.npv10YearUsd / 1000000).toFixed(1)}M
                </div>
              </div>

              <div className="border-main p-2 bg-[#F9F8F6]">
                <div className="label">IRR</div>
                <div className="data-value text-sm text-[#F27D26] mt-0.5">
                  {selectedOption.financialValuation.irrPct}%
                </div>
              </div>

              <div className="border-main p-2 bg-[#F9F8F6]">
                <div className="label">Payback</div>
                <div className="data-value text-sm text-[#141414] mt-0.5">
                  {selectedOption.financialValuation.paybackPeriodYears.toFixed(1)} yrs
                </div>
              </div>
            </div>

            {/* Annual Cashflow Statement */}
            <div className="border-main p-3 bg-[#F9F8F6] space-y-2 text-xs">
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Annual Gross Compute Revenue:</span>
                <span className="font-bold text-[#16A34A]">+${(selectedOption.annualMetricsUsd.grossRevenue / 1000000).toFixed(2)}M / yr</span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Annual Grid Electricity Cost:</span>
                <span className="font-bold text-[#F27D26]">-${(selectedOption.annualMetricsUsd.energyCost / 1000000).toFixed(2)}M / yr</span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Maintenance &amp; Spares Opex:</span>
                <span className="font-bold">-${(selectedOption.annualMetricsUsd.maintenanceOpex / 1000000).toFixed(2)}M / yr</span>
              </div>
              <div className="flex justify-between pt-1 text-[#16A34A] font-bold">
                <span>Net Annual Free Cashflow:</span>
                <span>+${(selectedOption.annualMetricsUsd.netOperatingCashflow / 1000000).toFixed(2)}M / yr</span>
              </div>
            </div>

            <div className="border-main p-2.5 bg-white text-[11px]">
              <div className="label mb-1">Levelized Cost of Compute (LCC)</div>
              <div className="flex justify-between items-baseline">
                <span className="text-xl data-value text-[#141414]">
                  ${selectedOption.financialValuation.levelizedCostPerGpuHour.toFixed(3)}
                </span>
                <span className="text-[10px] opacity-70">per GPU-hour (Total TCO)</span>
              </div>
            </div>
          </div>

          {/* Right: Capex Breakdown & Comparison Table (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Capex Allocation Bar & Breakdown */}
            <div className="border-main bg-white p-4 space-y-3">
              <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
                <span className="col-header">Total Initial Capital Expenditure (Capex)</span>
                <span className="data-value text-[#141414]">
                  ${(selectedOption.capexBreakdownUsd.totalCapex / 1000000).toFixed(2)}M Total
                </span>
              </div>

              {/* Segmented Capex Bar */}
              <div className="h-4 border border-black flex">
                <div
                  className="h-full bg-[#141414]"
                  style={{
                    width: `${(selectedOption.capexBreakdownUsd.itAndGpuHardware / selectedOption.capexBreakdownUsd.totalCapex) * 100}%`,
                  }}
                  title="IT & GPU Hardware"
                ></div>
                <div
                  className="h-full bg-[#F27D26]"
                  style={{
                    width: `${(selectedOption.capexBreakdownUsd.powerInfrastructure / selectedOption.capexBreakdownUsd.totalCapex) * 100}%`,
                  }}
                  title="Power Infrastructure"
                ></div>
                <div
                  className="h-full bg-[#2563EB]"
                  style={{
                    width: `${(selectedOption.capexBreakdownUsd.coolingInfrastructure / selectedOption.capexBreakdownUsd.totalCapex) * 100}%`,
                  }}
                  title="Cooling Systems"
                ></div>
                <div
                  className="h-full bg-zinc-400"
                  style={{
                    width: `${(selectedOption.capexBreakdownUsd.civilAndBuilding / selectedOption.capexBreakdownUsd.totalCapex) * 100}%`,
                  }}
                  title="Civil & Shell"
                ></div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                <div className="border-main p-2 bg-[#F9F8F6]">
                  <div className="flex items-center space-x-1 mb-1">
                    <span className="w-2 h-2 bg-[#141414] border border-black"></span>
                    <span className="label">GPU Hardware</span>
                  </div>
                  <div className="data-value text-xs">${(selectedOption.capexBreakdownUsd.itAndGpuHardware / 1000000).toFixed(1)}M</div>
                </div>

                <div className="border-main p-2 bg-[#F9F8F6]">
                  <div className="flex items-center space-x-1 mb-1">
                    <span className="w-2 h-2 bg-[#F27D26] border border-black"></span>
                    <span className="label">Power &amp; UPS</span>
                  </div>
                  <div className="data-value text-xs">${(selectedOption.capexBreakdownUsd.powerInfrastructure / 1000000).toFixed(1)}M</div>
                </div>

                <div className="border-main p-2 bg-[#F9F8F6]">
                  <div className="flex items-center space-x-1 mb-1">
                    <span className="w-2 h-2 bg-[#2563EB] border border-black"></span>
                    <span className="label">CDU &amp; Liquid</span>
                  </div>
                  <div className="data-value text-xs">${(selectedOption.capexBreakdownUsd.coolingInfrastructure / 1000000).toFixed(1)}M</div>
                </div>

                <div className="border-main p-2 bg-[#F9F8F6]">
                  <div className="flex items-center space-x-1 mb-1">
                    <span className="w-2 h-2 bg-zinc-400 border border-black"></span>
                    <span className="label">Civil &amp; Shell</span>
                  </div>
                  <div className="data-value text-xs">${(selectedOption.capexBreakdownUsd.civilAndBuilding / 1000000).toFixed(1)}M</div>
                </div>
              </div>
            </div>

            {/* Modular Comparison Across All Tiers */}
            <div className="border-main bg-white">
              <div className="border-b bg-[#F0EFED] px-3 py-2">
                <h3 className="col-header">Modular Expansion Comparison Matrix [1MW - 100MW]</h3>
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-[#F0EFED] border-b border-[#141414]">
                  <tr className="text-[10px] font-bold uppercase">
                    <th className="p-2 border-r border-[#141414]">Capacity</th>
                    <th className="p-2 border-r border-[#141414]">GPUs</th>
                    <th className="p-2 border-r border-[#141414]">Total Capex</th>
                    <th className="p-2 border-r border-[#141414]">10-Yr NPV</th>
                    <th className="p-2">IRR</th>
                  </tr>
                </thead>
                <tbody>
                  {options.map((opt) => (
                    <tr
                      key={opt.expansionMw}
                      className={`border-b border-[#141414]/30 hover:bg-[#F9F8F6] ${
                        selectedMw === opt.expansionMw ? 'bg-[#F27D26]/10 font-bold' : ''
                      }`}
                    >
                      <td className="p-2 border-r border-[#141414]">+{opt.expansionMw} MW</td>
                      <td className="p-2 border-r border-[#141414]">{opt.activeGpusAdded.toLocaleString()}</td>
                      <td className="p-2 border-r border-[#141414]">${(opt.capexBreakdownUsd.totalCapex / 1000000).toFixed(1)}M</td>
                      <td className="p-2 border-r border-[#141414] text-[#16A34A]">+${(opt.financialValuation.npv10YearUsd / 1000000).toFixed(1)}M</td>
                      <td className="p-2 text-[#F27D26]">{opt.financialValuation.irrPct}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
