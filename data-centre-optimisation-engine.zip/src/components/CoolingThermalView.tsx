import React from 'react';
import {
  Flame,
  Droplets,
  Wind,
  Activity,
  Thermometer,
  Zap,
  DollarSign,
  TrendingDown,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { DataCentreTwinState, TelemetrySnapshot } from '../types';

interface Props {
  twin: DataCentreTwinState;
  snapshot: TelemetrySnapshot | null;
}

export const CoolingThermalView: React.FC<Props> = ({ twin, snapshot }) => {
  const cdu = twin.cduLoops[0];
  const chiller1 = twin.chillers[0];
  const chiller2 = twin.chillers[1];

  const ambientTemp = snapshot?.ambientOutsideTempC || 22.0;
  const wetBulb = snapshot?.wetBulbTempC || 16.0;
  const isFreeCoolingViable = wetBulb <= 14.5;
  const heatRecoveredMw = snapshot?.districtHeatRecoveredMw || 7.2;

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Header Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <Flame className="w-4 h-4 text-[#F27D26]" />
            <span>Thermodynamic Cooling Loops & Waste Heat Harvesting Engine</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            Hybrid Direct-to-Chip Cold Plates (PG25) &bull; 12MW CDUs &bull; Centrifugal Chillers &bull; District Heating Export
          </p>
        </div>
        <div className="flex items-center space-x-2 font-mono">
          <span className="px-2.5 py-1 bg-white border border-[#141414]">
            Wet Bulb: <strong>{wetBulb}°C</strong>
          </span>
          <span
            className={`px-2.5 py-1 border font-bold ${
              isFreeCoolingViable
                ? 'bg-[#22C55E]/20 border-[#22C55E] text-[#16A34A]'
                : 'bg-white border-[#141414] text-[#141414]'
            }`}
          >
            {isFreeCoolingViable ? 'Economizer: ACTIVE' : 'Mechanical Lift: REQUIRED'}
          </span>
        </div>
      </div>

      {/* Main Thermodynamic Cycle 3-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Column 1: Direct-to-Chip Liquid Cooling & CDU Loop */}
        <div className="border-main bg-white p-4 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-[#141414] pb-2">
            <div className="flex items-center space-x-2 font-bold text-[#141414]">
              <Droplets className="w-4 h-4 text-[#2563EB]" />
              <span className="col-header opacity-100">Direct-to-Chip CDU Loop</span>
            </div>
            <span className="label bg-[#F0EFED] border border-[#141414] px-1.5 py-0.5">Primary AI Loop</span>
          </div>

          <div className="space-y-2">
            <div className="border-main p-2.5 bg-[#F9F8F6] space-y-1">
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Coolant Supply Temp:</span>
                <span className="font-bold text-[#2563EB]">32.0°C</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Coolant Return Temp:</span>
                <span className="font-bold text-[#F27D26]">46.5°C</span>
              </div>
              <div className="flex justify-between text-xs border-t border-[#141414]/20 pt-1">
                <span className="opacity-70">Thermal Delta-T (ΔT):</span>
                <span className="font-bold">14.5 K</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="border-main p-2 bg-white">
                <div className="label">Total Liquid Flow</div>
                <div className="data-value text-xs">{cdu?.coolantFlowLpm || 420} LPM</div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">CDU Pump Power</div>
                <div className="data-value text-xs">28.4 kW</div>
              </div>
            </div>

            <div className="border-main p-2 bg-[#F0EFED] text-[11px] space-y-1">
              <div className="font-bold">Fluid Thermodynamics (Q = ṁ·Cp·ΔT):</div>
              <p className="text-[10px] opacity-70">
                25% Propylene Glycol / Water solution removing 85% of GPU heat directly at the silicon junction.
              </p>
            </div>
          </div>
        </div>

        {/* Column 2: Central Chiller Plant & CRAH Air Loops */}
        <div className="border-main bg-white p-4 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-[#141414] pb-2">
            <div className="flex items-center space-x-2 font-bold text-[#141414]">
              <Wind className="w-4 h-4 text-[#16A34A]" />
              <span className="col-header opacity-100">Central Chiller Plant</span>
            </div>
            <span className="label bg-[#F0EFED] border border-[#141414] px-1.5 py-0.5">COP: 6.20</span>
          </div>

          <div className="space-y-2">
            <div className="border-main p-2.5 bg-[#F9F8F6] space-y-1">
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Chiller 1 (Magnetic Bearing):</span>
                <span className="font-bold text-[#16A34A]">Online (COP 6.2)</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Chiller 2 (Magnetic Bearing):</span>
                <span className="font-bold text-[#16A34A]">Online (COP 6.1)</span>
              </div>
              <div className="flex justify-between text-xs border-t border-[#141414]/20 pt-1">
                <span className="opacity-70">Total Cooling Plant Draw:</span>
                <span className="font-bold text-[#F27D26]">{snapshot?.coolingPowerMw.toFixed(2)} MW</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="border-main p-2 bg-white">
                <div className="label">Evaporator Supply</div>
                <div className="data-value text-xs">7.2°C</div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">Condenser Return</div>
                <div className="data-value text-xs">28.5°C</div>
              </div>
            </div>

            <div className="border-main p-2 bg-[#F0EFED] text-[11px] space-y-1">
              <div className="font-bold">Waterside Economization:</div>
              <p className="text-[10px] opacity-70">
                Plate-and-frame heat exchangers bypass chillers when wet-bulb temperature drops below 14.5°C.
              </p>
            </div>
          </div>
        </div>

        {/* Column 3: District Heating Export & Revenue */}
        <div className="border-main bg-white p-4 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-[#141414] pb-2">
            <div className="flex items-center space-x-2 font-bold text-[#141414]">
              <Flame className="w-4 h-4 text-[#F27D26]" />
              <span className="col-header opacity-100">District Heating Export</span>
            </div>
            <span className="label bg-[#F27D26]/20 border border-[#F27D26] text-[#F27D26] px-1.5 py-0.5 font-bold">
              Active Export
            </span>
          </div>

          <div className="space-y-2">
            <div className="border-main p-2.5 bg-[#F9F8F6] space-y-1">
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Thermal Heat Harvested:</span>
                <span className="font-bold text-[#F27D26]">{heatRecoveredMw.toFixed(1)} MWth</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="opacity-70">Export Supply Temperature:</span>
                <span className="font-bold">62.0°C</span>
              </div>
              <div className="flex justify-between text-xs border-t border-[#141414]/20 pt-1">
                <span className="opacity-70">Thermal Revenue Tariff:</span>
                <span className="font-bold text-[#16A34A]">$28.50 / MWhth</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="border-main p-2 bg-white">
                <div className="label">Hourly Thermal Revenue</div>
                <div className="data-value text-xs text-[#16A34A]">
                  +${Math.round(heatRecoveredMw * 28.5).toLocaleString()}/hr
                </div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">Municipal Heat Sink</div>
                <div className="data-value text-xs truncate">4,200 Homes</div>
              </div>
            </div>

            <div className="border-main p-2 bg-[#F0EFED] text-[11px] space-y-1">
              <div className="font-bold">Carbon Offset Impact:</div>
              <p className="text-[10px] opacity-70">
                Displaces natural gas boilers in municipal network, saving ~12,400 tonnes CO2e annually.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
