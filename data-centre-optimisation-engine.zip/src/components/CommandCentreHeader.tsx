import React from 'react';
import {
  Activity,
  Zap,
  Flame,
  Cpu,
  TrendingUp,
  AlertTriangle,
  BatteryCharging,
  DollarSign,
  ShieldCheck,
  Layers,
  Thermometer,
} from 'lucide-react';
import { TelemetrySnapshot, ScenarioDefinition } from '../types';
import { PRESET_SCENARIOS } from '../engine/scenarios';

interface Props {
  snapshot: TelemetrySnapshot | null;
  activeScenarioId: string;
  onSelectScenario: (id: string) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  anomalyCount: number;
}

export const CommandCentreHeader: React.FC<Props> = ({
  snapshot,
  activeScenarioId,
  onSelectScenario,
  activeTab,
  onSelectTab,
  anomalyCount,
}) => {
  const currentScenario = PRESET_SCENARIOS.find((s) => s.id === activeScenarioId) || PRESET_SCENARIOS[0];

  const navTabs = [
    { id: 'command', label: 'Real-Time Telemetry', icon: Activity },
    { id: 'digital-twin', label: 'Site Hierarchy [Twin]', icon: Layers },
    { id: 'power', label: 'Electrical Single-Line', icon: Zap },
    { id: 'cooling', label: 'Thermodynamics & Cooling', icon: Flame },
    { id: 'compute', label: 'GPU Cluster Scheduler', icon: Cpu },
    { id: 'optimizer', label: 'Pareto Solver [Rust]', icon: ShieldCheck },
    { id: 'monte-carlo', label: 'R Monte Carlo & Risk', icon: TrendingUp },
    { id: 'expansion', label: 'Capacity Expansion Economics', icon: DollarSign },
    { id: 'codebase', label: 'Codebase Engine [Rust+R]', icon: Layers },
  ];

  return (
    <header className="bg-[#F0EFED] border-b border-[#141414] text-[#141414] sticky top-0 z-40">
      {/* Top Banner: Facility Identity & High-Level Telemetry */}
      <div className="px-4 sm:px-6 py-3 border-b border-[#141414] flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="status-dot bg-active"></span>
            <h1 className="text-xl font-bold tracking-tight font-serif text-[#141414]">
              OPTIMA_ENG.RUST_V4.2
            </h1>
            <span className="px-2 py-0.5 border border-[#141414] bg-white text-[10px] font-mono font-bold uppercase tracking-wider">
              Rust + R Digital Twin
            </span>
          </div>
          <p className="label mt-0.5 text-[#141414]/70">
            Helios Hyperscale AI Supercomputing Facility Alpha &bull; 45 MW &bull; Tier III &bull; Direct-to-Chip
          </p>
        </div>

        {/* Scenario Selector & Alerts */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-white border border-[#141414] px-2.5 py-1">
            <span className="label mr-2">Scenario:</span>
            <select
              id="scenario-select"
              value={activeScenarioId}
              onChange={(e) => onSelectScenario(e.target.value)}
              className="bg-[#F0EFED] text-[#141414] text-xs font-mono font-bold px-2 py-1 border border-[#141414] focus:outline-none"
            >
              {PRESET_SCENARIOS.map((scen) => (
                <option key={scen.id} value={scen.id}>
                  {scen.name} [{scen.badge}]
                </option>
              ))}
            </select>
          </div>

          {anomalyCount > 0 ? (
            <div className="flex items-center px-2.5 py-1 bg-[#EF4444] text-white border border-[#141414] text-xs font-mono font-bold">
              <span className="status-dot bg-white mr-1.5 animate-ping"></span>
              <span>{anomalyCount} ALERTS</span>
            </div>
          ) : (
            <div className="flex items-center px-2.5 py-1 bg-white text-[#22C55E] border border-[#141414] text-xs font-mono font-bold">
              <span className="status-dot bg-active mr-1.5"></span>
              <span>NOMINAL</span>
            </div>
          )}
        </div>
      </div>

      {/* Global Key Real-Time Tickers Data Grid */}
      {snapshot && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 border-b border-[#141414] bg-white text-xs">
          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>Total Power</span>
              <Zap className="w-3 h-3 text-[#141414]/50" />
            </div>
            <div className="data-value text-[#141414] text-base mt-0.5">
              {snapshot.totalFacilityPowerMw.toFixed(2)} <span className="text-[10px] font-normal opacity-70">MW</span>
            </div>
            <div className="text-[10px] font-mono opacity-70">
              IT: {snapshot.itPowerMw.toFixed(1)} MW
            </div>
          </div>

          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0 bg-[#F9F8F6]">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>PUE (Real-time)</span>
              <ShieldCheck className="w-3 h-3 text-[#22C55E]" />
            </div>
            <div className={`data-value text-base mt-0.5 ${snapshot.instantaneousPue <= 1.15 ? 'text-[#16A34A]' : 'text-[#F27D26]'}`}>
              {snapshot.instantaneousPue.toFixed(3)}
            </div>
            <div className="text-[10px] font-mono opacity-70">
              Cool: {snapshot.coolingPowerMw.toFixed(2)} MW
            </div>
          </div>

          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>GPU Cluster</span>
              <Cpu className="w-3 h-3 text-[#141414]/50" />
            </div>
            <div className="data-value text-[#141414] text-base mt-0.5">
              {snapshot.activeGpus.toLocaleString()} <span className="text-[10px] font-normal opacity-70">GPUs</span>
            </div>
            <div className="text-[10px] font-mono opacity-70">
              {snapshot.averageGpuUtilizationPct}% Utilized
            </div>
          </div>

          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0 bg-[#F9F8F6]">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>Spot Tariff</span>
              <DollarSign className="w-3 h-3 text-[#F27D26]" />
            </div>
            <div className={`data-value text-base mt-0.5 ${snapshot.spotElectricityPricePerMwh > 150 ? 'text-[#EF4444]' : 'text-[#F27D26]'}`}>
              ${snapshot.spotElectricityPricePerMwh.toFixed(1)} <span className="text-[10px] font-normal opacity-70">/MWh</span>
            </div>
            <div className="text-[10px] font-mono opacity-70">
              ${(snapshot.hourlyEnergyCostUsd).toFixed(0)}/hr
            </div>
          </div>

          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>Net Margin / h</span>
              <TrendingUp className="w-3 h-3 text-[#22C55E]" />
            </div>
            <div className="data-value text-[#16A34A] text-base mt-0.5">
              +${Math.round(snapshot.hourlyNetMarginUsd).toLocaleString()}
            </div>
            <div className="text-[10px] font-mono opacity-70">
              Operating Cashflow
            </div>
          </div>

          <div className="p-3 border-r border-[#141414] border-b lg:border-b-0 bg-[#F9F8F6]">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>BESS SOC</span>
              <BatteryCharging className="w-3 h-3 text-[#2563EB]" />
            </div>
            <div className="data-value text-[#2563EB] text-base mt-0.5">
              {snapshot.bessSocPct.toFixed(1)}%
            </div>
            <div className="text-[10px] font-mono opacity-70 truncate">
              {snapshot.bessPowerKw > 0 ? `Discharging ${(snapshot.bessPowerKw / 1000).toFixed(1)}MW` : snapshot.bessPowerKw < 0 ? `Charging ${(-snapshot.bessPowerKw / 1000).toFixed(1)}MW` : 'Standby'}
            </div>
          </div>

          <div className="p-3 border-r border-[#141414]">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>Weather</span>
              <Thermometer className="w-3 h-3 text-[#141414]/50" />
            </div>
            <div className="data-value text-[#141414] text-base mt-0.5">
              {snapshot.ambientOutsideTempC}°C
            </div>
            <div className="text-[10px] font-mono opacity-70">
              Wet Bulb: {snapshot.wetBulbTempC}°C
            </div>
          </div>

          <div className="p-3 bg-[#F9F8F6]">
            <div className="label text-[#141414]/70 flex items-center justify-between">
              <span>Heat Harvest</span>
              <Flame className="w-3 h-3 text-[#F27D26]" />
            </div>
            <div className="data-value text-[#F27D26] text-base mt-0.5">
              {snapshot.districtHeatRecoveredMw.toFixed(1)} <span className="text-[10px] font-normal opacity-70">MWth</span>
            </div>
            <div className="text-[10px] font-mono opacity-70">
              District Heating
            </div>
          </div>
        </div>
      )}

      {/* Bottleneck Status Bar */}
      {snapshot && (
        <div className="px-4 py-2 bg-[#F0EFED] border-b border-[#141414] flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs font-mono">
          <div className="flex items-center space-x-2">
            <span className="label text-[#141414]/70">Active Bottleneck:</span>
            <span className="font-bold text-[#141414]">{snapshot.activeBottleneck}</span>
          </div>
          <div className="flex items-center space-x-4 text-[11px] opacity-80 mt-1 sm:mt-0">
            <span>Power Headroom: <strong className="font-mono">{snapshot.itCapacityHeadroomMw.toFixed(1)} MW</strong></span>
            <span>|</span>
            <span>Cooling Headroom: <strong className="font-mono">{snapshot.coolingCapacityHeadroomMw.toFixed(1)} MW</strong></span>
          </div>
        </div>
      )}

      {/* Navigation Tabs (Technical Grid style) */}
      <nav className="flex overflow-x-auto bg-[#E4E3E0] p-1.5 gap-1.5 border-b border-[#141414] scrollbar-thin">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono transition-all whitespace-nowrap border border-[#141414] ${
                isActive
                  ? 'bg-[#141414] text-[#E4E3E0] font-bold shadow-none'
                  : 'bg-white hover:bg-[#F0EFED] text-[#141414]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#F27D26]' : 'text-[#141414]/70'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
