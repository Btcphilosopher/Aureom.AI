import React, { useState, useEffect } from 'react';
import {
  Layers,
  FileCode,
  Check,
  Copy,
  Folder,
  Code2,
  Terminal,
  Database,
  Cpu,
  Zap,
  Flame,
  ShieldCheck,
} from 'lucide-react';

interface Props {
  sourceFiles: Record<string, string>;
}

export const CodebaseInspectorView: React.FC<Props> = ({ sourceFiles }) => {
  const fileKeys = Object.keys(sourceFiles);
  const [selectedFile, setSelectedFile] = useState<string>(fileKeys[0] || 'crates/dc-optimizer/src/solver.rs');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!sourceFiles[selectedFile] && fileKeys.length > 0) {
      setSelectedFile(fileKeys[0]);
    }
  }, [sourceFiles, selectedFile, fileKeys]);

  const handleCopy = () => {
    if (sourceFiles[selectedFile]) {
      navigator.clipboard.writeText(sourceFiles[selectedFile]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getLanguageTag = (fileName: string) => {
    if (fileName.endsWith('.rs')) return 'Rust';
    if (fileName.endsWith('.R')) return 'R';
    if (fileName.endsWith('.sql')) return 'SQL';
    if (fileName.endsWith('.toml')) return 'TOML';
    return 'Text';
  };

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner: Architecture Overview */}
      <div className="border-main bg-[#F0EFED] p-3 space-y-3">
        <div className="flex items-center justify-between border-b border-[#141414] pb-2">
          <div className="flex items-center space-x-2">
            <Code2 className="w-4 h-4 text-[#141414]" />
            <h2 className="text-sm font-bold text-[#141414] uppercase font-serif">
              Rust + R Multi-Crate Architecture &amp; Production Codebase
            </h2>
          </div>
          <span className="label bg-white border border-[#141414] px-2 py-0.5 font-mono">
            Modular Workspace (8 Crates + 4 R Scripts + SQL DDL)
          </span>
        </div>

        {/* 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono">
          <div className="border-main p-2.5 bg-white space-y-1">
            <div className="flex items-center space-x-1.5 font-bold text-[#141414]">
              <Cpu className="w-3.5 h-3.5" />
              <span>RUST ENGINE (Physics &amp; MILP)</span>
            </div>
            <p className="text-[10px] text-[#141414]/70">
              Low-latency simulation of thermal laws (Q=ṁCpΔT), electrical line losses, and mixed-integer Pareto optimization.
            </p>
          </div>

          <div className="border-main p-2.5 bg-white space-y-1">
            <div className="flex items-center space-x-1.5 font-bold text-[#16A34A]">
              <Terminal className="w-3.5 h-3.5" />
              <span>R ANALYTICS (Statistics &amp; Risk)</span>
            </div>
            <p className="text-[10px] text-[#141414]/70">
              ARIMA spot tariff forecasting, stochastic log-normal Monte Carlo risk simulations (P10/P50/P90), and 10-year DCF NPV.
            </p>
          </div>

          <div className="border-main p-2.5 bg-white space-y-1">
            <div className="flex items-center space-x-1.5 font-bold text-[#2563EB]">
              <Database className="w-3.5 h-3.5" />
              <span>SQL DDL (Relational Schema)</span>
            </div>
            <p className="text-[10px] text-[#141414]/70">
              Production schema covering Sites, Rooms, Racks, Servers, GPUs, Chillers, CDUs, BESS, and Telemetry ring buffers.
            </p>
          </div>
        </div>
      </div>

      {/* Code Inspector: File Browser on Left, Code Viewer on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono">
        {/* Left: Workspace Tree (4 cols) */}
        <div className="lg:col-span-4 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center space-x-2">
            <Folder className="w-3.5 h-3.5 text-[#141414]" />
            <span className="col-header">Workspace Source Files</span>
          </div>

          <div className="p-2 space-y-1 max-h-[520px] overflow-y-auto pr-1">
            {fileKeys.map((filePath) => {
              const isSelected = selectedFile === filePath;
              const lang = getLanguageTag(filePath);

              return (
                <button
                  key={filePath}
                  id={`file-btn-${filePath.replace(/[^a-zA-Z0-9]/g, '-')}`}
                  onClick={() => setSelectedFile(filePath)}
                  className={`w-full text-left p-1.5 border transition-all flex items-center justify-between text-xs ${
                    isSelected
                      ? 'bg-[#141414] text-white border-black font-bold'
                      : 'bg-white border-[#141414]/30 text-[#141414] hover:bg-[#F9F8F6]'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 truncate">
                    <FileCode className="w-3.5 h-3.5 flex-shrink-0 opacity-70" />
                    <span className="truncate">{filePath}</span>
                  </div>
                  <span
                    className={`text-[9px] px-1 py-0.2 border ${
                      isSelected
                        ? 'bg-zinc-800 text-white border-zinc-700'
                        : 'bg-[#F0EFED] text-[#141414] border-[#141414]/40'
                    }`}
                  >
                    {lang}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileCode className="w-3.5 h-3.5 text-[#141414]" />
              <span className="font-bold text-xs">{selectedFile}</span>
            </div>
            <button
              id="btn-copy-code"
              onClick={handleCopy}
              className="px-2.5 py-0.5 bg-white hover:bg-[#F9F8F6] text-[#141414] border border-[#141414] flex items-center space-x-1 text-[11px] font-bold transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-[#16A34A]" />
                  <span className="text-[#16A34A]">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          <div className="p-3">
            <pre className="p-3 bg-[#141414] text-[#E4E3E0] border border-black overflow-x-auto text-[11px] leading-relaxed max-h-[480px] overflow-y-auto font-mono">
              <code>{sourceFiles[selectedFile] || '// Select a file to inspect code'}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
