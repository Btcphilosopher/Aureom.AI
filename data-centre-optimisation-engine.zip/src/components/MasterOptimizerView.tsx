import React, { useState } from 'react';
import {
  ShieldCheck,
  Zap,
  Flame,
  Cpu,
  TrendingDown,
  TrendingUp,
  BatteryCharging,
  Sliders,
  Play,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  OptimizationConstraints,
  OptimizationPlan,
  OptimizationWeights,
  TelemetrySnapshot,
} from '../types';

interface Props {
  currentWeights: OptimizationWeights;
  currentConstraints: OptimizationConstraints;
  lastPlan: OptimizationPlan | null;
  snapshot: TelemetrySnapshot | null;
  onRunOptimizer: (weights: OptimizationWeights, constraints: OptimizationConstraints) => void;
  isOptimizing: boolean;
}

export const MasterOptimizerView: React.FC<Props> = ({
  currentWeights,
  currentConstraints,
  lastPlan,
  snapshot,
  onRunOptimizer,
  isOptimizing,
}) => {
  const [weights, setWeights] = useState<OptimizationWeights>({ ...currentWeights });
  const [constraints, setConstraints] = useState<OptimizationConstraints>({ ...currentConstraints });

  const handleWeightChange = (key: keyof OptimizationWeights, val: number) => {
    setWeights((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  const handleConstraintChange = (key: keyof OptimizationConstraints, val: any) => {
    setConstraints((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  const handleExecute = () => {
    onRunOptimizer(weights, constraints);
  };

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-[#141414]" />
            <span>Master Multi-Objective Pareto Optimisation Engine [Rust Solver]</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            Mixed-Integer Linear Programming (MILP) &bull; Q=mCpΔT Thermal Constraints &bull; Real-Time Energy Arbitrage
          </p>
        </div>
        <button
          id="btn-solve-master-optimizer"
          onClick={handleExecute}
          disabled={isOptimizing}
          className="px-4 py-2 bg-[#F27D26] hover:bg-[#e06c17] text-black font-bold text-[10px] uppercase tracking-widest border border-[#141414] flex items-center space-x-1.5 transition-all active:scale-95 disabled:opacity-50 font-mono"
        >
          {isOptimizing ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Solving Multi-Objective MILP...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              <span>Execute Pareto Solver</span>
            </>
          )}
        </button>
      </div>

      {/* Grid: Weights & Constraints Configuration (Left) + Active Recommendation (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono">
        {/* Left 7 Cols: Solver Objective Weights & Hard Constraints */}
        <div className="lg:col-span-7 space-y-4">
          {/* Objective Weights */}
          <div className="border-main bg-white p-4 space-y-3">
            <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
              <span className="col-header">Multi-Objective Cost Formulation Weights (α, β, γ, δ)</span>
              <span className="label">Dynamic Weights</span>
            </div>

            <div className="space-y-2.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Maximize Compute Throughput (α)</span>
                  <span className="font-bold">{weights.weightComputeThroughput.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.weightComputeThroughput}
                  onChange={(e) => handleWeightChange('weightComputeThroughput', parseFloat(e.target.value))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Minimize Energy Tariff Cost (β)</span>
                  <span className="font-bold text-[#F27D26]">{weights.weightEnergyCostMin.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.weightEnergyCostMin}
                  onChange={(e) => handleWeightChange('weightEnergyCostMin', parseFloat(e.target.value))}
                  className="w-full accent-[#F27D26] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Minimize Grid Carbon Footprint (γ)</span>
                  <span className="font-bold text-[#16A34A]">{weights.weightCarbonReduction.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.weightCarbonReduction}
                  onChange={(e) => handleWeightChange('weightCarbonReduction', parseFloat(e.target.value))}
                  className="w-full accent-[#22C55E] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Minimize Battery Degradation &amp; Thermal Risk (δ)</span>
                  <span className="font-bold text-[#2563EB]">{weights.weightBatteryPreservation.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.weightBatteryPreservation}
                  onChange={(e) => handleWeightChange('weightBatteryPreservation', parseFloat(e.target.value))}
                  className="w-full accent-[#2563EB] cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Hard Physical Constraints */}
          <div className="border-main bg-white p-4 space-y-3">
            <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
              <span className="col-header">Hard Physical Boundary Constraints</span>
              <span className="label">Strict IEEE &amp; ASHRAE Limits</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="border-main p-2.5 bg-[#F9F8F6]">
                <label className="label block mb-1">Max Substation Import Power</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={constraints.maxGridPowerMw}
                    onChange={(e) => handleConstraintChange('maxGridPowerMw', parseFloat(e.target.value))}
                    className="w-full bg-white border border-[#141414] p-1 font-bold font-mono"
                  />
                  <span className="text-[10px] opacity-70">MW</span>
                </div>
              </div>

              <div className="border-main p-2.5 bg-[#F9F8F6]">
                <label className="label block mb-1">Max GPU Junction Temp</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={constraints.maxGpuJunctionTempC}
                    onChange={(e) => handleConstraintChange('maxGpuJunctionTempC', parseFloat(e.target.value))}
                    className="w-full bg-white border border-[#141414] p-1 font-bold font-mono"
                  />
                  <span className="text-[10px] opacity-70">°C</span>
                </div>
              </div>

              <div className="border-main p-2.5 bg-[#F9F8F6]">
                <label className="label block mb-1">Min BESS SOC Reserve</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={constraints.minBessSocReservePct}
                    onChange={(e) => handleConstraintChange('minBessSocReservePct', parseFloat(e.target.value))}
                    className="w-full bg-white border border-[#141414] p-1 font-bold font-mono"
                  />
                  <span className="text-[10px] opacity-70">%</span>
                </div>
              </div>

              <div className="border-main p-2.5 bg-[#F9F8F6] flex items-center justify-between">
                <div>
                  <div className="label">Flexible Deferral</div>
                  <div className="text-[10px] opacity-70">Allow P4 batch jobs shifting</div>
                </div>
                <input
                  type="checkbox"
                  checked={constraints.allowWorkloadDeferral}
                  onChange={(e) => handleConstraintChange('allowWorkloadDeferral', e.target.checked)}
                  className="w-4 h-4 accent-[#141414]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Active Recommendation & Solver Results */}
        <div className="lg:col-span-5 space-y-4">
          {/* Active Recommendation Card */}
          <div className="bg-[#141414] text-[#E4E3E0] p-4 border-main">
            <p className="label opacity-60 text-white">Active Recommendation [RUST SOLVER]</p>
            <p className="text-sm mt-2 leading-relaxed font-serif italic text-white">
              "{lastPlan ? (lastPlan.bessActionKw > 0 ? 'Discharge 4.5MW BESS and pause flexible P4 batch workloads to shave tariff peak.' : 'Operating in nominal high-throughput mode across all AI clusters.') : 'Shift non-critical AI inference tasks to Window 02:00-05:00 UTC to capture £24k energy arbitrage while discharging 4.5MW BESS during peak spot tariff.'}"
            </p>
            <button
              onClick={handleExecute}
              className="mt-4 w-full bg-[#F27D26] hover:bg-[#e06c17] text-black font-bold text-[10px] py-2 uppercase tracking-widest border border-black transition-all"
            >
              Execute Recommended Shift
            </button>
          </div>

          {/* Solved Plan Metrics Grid */}
          <div className="border-main bg-white p-4 space-y-3">
            <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
              <span className="col-header">Optimal Plan Economic Impact</span>
              <span className="label text-[#16A34A] font-bold">SOLVED: 12ms</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Projected Hourly Cost:</span>
                <span className="font-bold text-[#F27D26]">
                  ${lastPlan?.optimizedHourlyCostUsd ? Math.round(lastPlan.optimizedHourlyCostUsd).toLocaleString() : '3,450'} / hr
                </span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Estimated Hourly Savings:</span>
                <span className="font-bold text-[#16A34A]">
                  +${lastPlan?.hourlySavingsUsd ? Math.round(lastPlan.hourlySavingsUsd).toLocaleString() : '1,120'} / hr
                </span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">Target PUE:</span>
                <span className="font-bold">{lastPlan?.pueProjected.toFixed(3) || '1.118'}</span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span className="opacity-70">BESS Scheduled Dispatch:</span>
                <span className="font-bold text-[#2563EB]">
                  {lastPlan ? (lastPlan.bessActionKw > 0 ? `Discharge ${(lastPlan.bessActionKw/1000).toFixed(1)} MW` : 'Standby') : 'Discharge 4.5 MW'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-70">Deferred Flexible Jobs:</span>
                <span className="font-bold">{lastPlan?.deferredJobsCount || 1} Workloads</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
