import React, { useState } from 'react';
import {
  Zap,
  BatteryCharging,
  Flame,
  ArrowDown,
  ArrowRight,
  ShieldCheck,
  Power,
  RefreshCw,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import { DataCentreTwinState, TelemetrySnapshot } from '../types';

interface Props {
  twin: DataCentreTwinState;
  snapshot: TelemetrySnapshot | null;
  onDispatchBess: (powerKw: number) => void;
}

export const PowerTopologyView: React.FC<Props> = ({ twin, snapshot, onDispatchBess }) => {
  const [targetBessKw, setTargetBessKw] = useState<number>(0);
  const [dispatchStatus, setDispatchStatus] = useState<string | null>(null);

  const handleApplyDispatch = (kw: number) => {
    setTargetBessKw(kw);
    onDispatchBess(kw);
    setDispatchStatus(
      `BESS Dispatched: ${
        kw > 0
          ? `Discharging +${(kw / 1000).toFixed(1)} MW`
          : kw < 0
          ? `Charging ${(-kw / 1000).toFixed(1)} MW`
          : 'Idle / Standby'
      }`
    );
    setTimeout(() => setDispatchStatus(null), 3000);
  };

  const bess = twin.batteryStorage[0];
  const gridMw = snapshot?.gridPowerMw || 35.0;
  const itMw = snapshot?.itPowerMw || 28.5;
  const coolingMw = snapshot?.coolingPowerMw || 4.2;
  const auxMw = snapshot?.auxiliaryPowerMw || 0.45;
  const lossesMw = (snapshot?.totalFacilityPowerMw || 34.0) - (itMw + coolingMw + auxMw);

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Title Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <Zap className="w-4 h-4 text-[#F27D26]" />
            <span>Electrical Single-Line Diagram & Power Topology [2N Redundant]</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            110kV/33kV Dual-Feed Substation &bull; 2N Static UPS &bull; 20 MWh Grid BESS Peak Shaving
          </p>
        </div>
        <div className="flex items-center space-x-2 font-mono">
          <span className="px-2.5 py-1 bg-white border border-[#141414]">
            Contracted: <strong>{twin.contractedPowerMw} MW</strong>
          </span>
          <span className="px-2.5 py-1 bg-[#22C55E]/20 border border-[#22C55E] text-[#16A34A] font-bold">
            Grid Compliance: 100%
          </span>
        </div>
      </div>

      {/* Interactive Single-Line Diagram */}
      <div className="border-main bg-white p-4 space-y-6">
        {/* Tier 1: Utility Grid & Substation */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2 border-main bg-[#F9F8F6] p-3">
            <div className="flex items-center justify-between font-mono text-xs mb-2 border-b border-[#141414]/20 pb-1.5">
              <div className="flex items-center space-x-2">
                <span className="status-dot bg-active"></span>
                <span className="font-bold text-[#141414]">110kV Primary Utility Feed (National Grid Substation)</span>
              </div>
              <span className="label bg-white border border-[#141414] px-1.5 py-0.5">Dual 60 MVA Feed</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
              <div className="border-main p-2 bg-white">
                <div className="label">Grid Import</div>
                <div className="data-value text-[#141414]">{gridMw.toFixed(2)} MW</div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">Frequency / PF</div>
                <div className="data-value text-[#141414]">50.00 Hz / 0.99</div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">Carbon Intensity</div>
                <div className="data-value text-[#141414]">
                  {snapshot?.gridCarbonIntensityGCo2PerKwh || 180} <span className="text-[9px] font-normal">g/kWh</span>
                </div>
              </div>
              <div className="border-main p-2 bg-white">
                <div className="label">Headroom Limit</div>
                <div className="data-value text-[#16A34A]">
                  {(twin.contractedPowerMw - gridMw).toFixed(1)} MW
                </div>
              </div>
            </div>
          </div>

          {/* Tier 1 Backup Generators */}
          <div className="border-main bg-white p-3 font-mono">
            <div className="flex items-center justify-between border-b border-[#141414]/20 pb-1.5 mb-2">
              <span className="font-bold text-[#141414]">Diesel Gen-Sets (N+1)</span>
              <span className="label bg-[#F0EFED] border border-[#141414] px-1.5 py-0.5">Standby</span>
            </div>
            <div className="text-[11px] space-y-1 text-[#141414]/80">
              <div className="flex justify-between">
                <span>Total Installed:</span>
                <span className="font-bold">6x 3.5 MVA (21 MVA)</span>
              </div>
              <div className="flex justify-between">
                <span>Fuel Autonomy:</span>
                <span>72 Hours Full Load</span>
              </div>
              <div className="flex justify-between">
                <span>Warm Block Heater:</span>
                <span className="text-[#16A34A] font-bold">42°C (10s Start)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tier 2: 2N Redundant UPS & Busbar Distribution */}
        <div className="border-main bg-[#F0EFED] p-3 space-y-3">
          <div className="flex items-center justify-between">
            <span className="col-header">2N Distributed Redundancy UPS & Distribution Bus</span>
            <span className="label font-mono">Static Bypass: Operational</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono">
            {/* Bus A */}
            <div className="border-main bg-white p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-[#141414]/20 pb-1">
                <div className="flex items-center space-x-2">
                  <span className="status-dot bg-active"></span>
                  <span className="font-bold">PRIMARY BUS 'A' (11kV / 400V)</span>
                </div>
                <span className="text-[10px] text-[#16A34A] font-bold">96.8% Eff</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-center text-[10px]">
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">Active Load</div>
                  <div className="data-value text-xs">{(snapshot?.totalFacilityPowerMw ? snapshot.totalFacilityPowerMw * 0.51 : 17.5).toFixed(2)} MW</div>
                </div>
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">UPS Status</div>
                  <div className="font-bold text-xs text-[#16A34A]">Online VFI</div>
                </div>
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">Battery Health</div>
                  <div className="font-bold text-xs">99.8% SOH</div>
                </div>
              </div>
            </div>

            {/* Bus B */}
            <div className="border-main bg-white p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-[#141414]/20 pb-1">
                <div className="flex items-center space-x-2">
                  <span className="status-dot bg-active"></span>
                  <span className="font-bold">SECONDARY BUS 'B' (11kV / 400V)</span>
                </div>
                <span className="text-[10px] text-[#16A34A] font-bold">96.7% Eff</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-center text-[10px]">
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">Active Load</div>
                  <div className="data-value text-xs">{(snapshot?.totalFacilityPowerMw ? snapshot.totalFacilityPowerMw * 0.49 : 16.5).toFixed(2)} MW</div>
                </div>
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">UPS Status</div>
                  <div className="font-bold text-xs text-[#16A34A]">Online VFI</div>
                </div>
                <div className="border-main p-1.5 bg-[#F9F8F6]">
                  <div className="label">Battery Health</div>
                  <div className="font-bold text-xs">99.6% SOH</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tier 3: Battery Energy Storage System (BESS) 20 MWh Panel */}
        <div className="border-main bg-white p-4 space-y-3 font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-[#141414]/20 pb-2">
            <div className="flex items-center space-x-2">
              <BatteryCharging className="w-4 h-4 text-[#2563EB]" />
              <span className="font-bold text-sm text-[#141414]">20 MWh Grid BESS Peak Shaving & Arbitrage Dispatcher</span>
            </div>
            {dispatchStatus && (
              <span className="px-2 py-0.5 bg-[#F27D26] text-black font-bold text-[10px] border border-[#141414]">
                {dispatchStatus}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="border-main p-3 bg-[#F9F8F6]">
              <div className="label">Battery State of Charge</div>
              <div className="text-2xl data-value text-[#2563EB] mt-1">{snapshot?.bessSocPct.toFixed(1)}%</div>
              <div className="mt-2 h-1.5 w-full bg-[#141414]/10">
                <div
                  className="h-full bg-[#2563EB]"
                  style={{ width: `${snapshot?.bessSocPct || 80}%` }}
                ></div>
              </div>
            </div>

            <div className="border-main p-3 bg-[#F9F8F6]">
              <div className="label">Instantaneous Power</div>
              <div className="text-2xl data-value text-[#141414] mt-1">
                {snapshot?.bessPowerKw ? (snapshot.bessPowerKw / 1000).toFixed(1) : '0.0'} MW
              </div>
              <div className="text-[10px] opacity-70 mt-1">
                {snapshot?.bessPowerKw && snapshot.bessPowerKw > 0
                  ? 'Discharging to shave grid peak'
                  : snapshot?.bessPowerKw && snapshot.bessPowerKw < 0
                  ? 'Charging from off-peak grid'
                  : 'Floating on DC bus'}
              </div>
            </div>

            <div className="border-main p-3 bg-[#F9F8F6]">
              <div className="label">Round-Trip Efficiency</div>
              <div className="text-2xl data-value text-[#16A34A] mt-1">91.4%</div>
              <div className="text-[10px] opacity-70 mt-1">LFP Chemistry &bull; 6,000 Cycles</div>
            </div>

            {/* Quick Dispatch Action Controls */}
            <div className="border-main p-3 bg-white space-y-1.5">
              <div className="label">Manual Dispatch Override</div>
              <div className="grid grid-cols-2 gap-1 text-[10px]">
                <button
                  id="btn-bess-discharge-max"
                  onClick={() => handleApplyDispatch(5000)}
                  className="p-1.5 bg-[#F27D26] hover:bg-[#e06c17] text-black font-bold border border-[#141414] text-center"
                >
                  Discharge 5MW
                </button>
                <button
                  id="btn-bess-charge-fast"
                  onClick={() => handleApplyDispatch(-4000)}
                  className="p-1.5 bg-[#2563EB] hover:bg-blue-700 text-white font-bold border border-[#141414] text-center"
                >
                  Charge 4MW
                </button>
                <button
                  id="btn-bess-idle"
                  onClick={() => handleApplyDispatch(0)}
                  className="p-1.5 bg-white hover:bg-[#F0EFED] text-[#141414] font-bold border border-[#141414] col-span-2 text-center"
                >
                  Return to Auto Arbitrage
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
