import React, { useState } from 'react';
import {
  TrendingUp,
  Activity,
  Sliders,
  RefreshCw,
  AlertTriangle,
  DollarSign,
  ShieldAlert,
  BarChart2,
  PieChart,
} from 'lucide-react';
import { MonteCarloSummary } from '../types';

interface Props {
  summary: MonteCarloSummary | null;
  onRunSimulation: (params: {
    runsCount: number;
    priceMean: number;
    priceVolatility: number;
    tempMean: number;
  }) => void;
  isRunning: boolean;
}

export const MonteCarloView: React.FC<Props> = ({ summary, onRunSimulation, isRunning }) => {
  const [runsCount, setRunsCount] = useState<number>(2000);
  const [priceMean, setPriceMean] = useState<number>(88.0);
  const [priceVolatility, setPriceVolatility] = useState<number>(32.0);
  const [tempMean, setTempMean] = useState<number>(27.5);

  const handleExecute = () => {
    onRunSimulation({
      runsCount,
      priceMean,
      priceVolatility,
      tempMean,
    });
  };

  const histogram = summary?.distributionHistogram || [];
  const maxBinCount = histogram.length > 0 ? Math.max(...histogram.map((b) => b.count), 1) : 100;

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-[#16A34A]" />
            <span>R Statistical Engine & Monte Carlo Probabilistic Risk Studio</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            Log-Normal Spot Tariff Squeeze &bull; Weather Excursions &bull; 95% Value at Risk (VaR)
          </p>
        </div>
        <button
          id="btn-run-monte-carlo"
          onClick={handleExecute}
          disabled={isRunning}
          className="px-4 py-2 bg-[#F27D26] hover:bg-[#e06c17] text-black font-bold text-[10px] uppercase tracking-widest border border-[#141414] flex items-center space-x-1.5 transition-all active:scale-95 disabled:opacity-50 font-mono"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Simulating {runsCount} Paths...</span>
            </>
          ) : (
            <>
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Run {runsCount} Monte Carlo Paths</span>
            </>
          )}
        </button>
      </div>

      {/* Grid: Simulation Parameters & Risk Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono">
        {/* Left Column: Interactive Simulation Sliders & Percentiles (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Sliders Box */}
          <div className="border-main bg-white p-4 space-y-3">
            <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
              <span className="col-header">Stochastic Variable Distributions [R Interface]</span>
              <span className="label">Sample Size: N={runsCount}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Spot Price Mean ($/MWh)</span>
                  <span className="font-bold text-[#F27D26]">${priceMean}</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="200"
                  step="5"
                  value={priceMean}
                  onChange={(e) => setPriceMean(parseFloat(e.target.value))}
                  className="w-full accent-[#F27D26] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Price Volatility (σ)</span>
                  <span className="font-bold">{priceVolatility}%</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  step="5"
                  value={priceVolatility}
                  onChange={(e) => setPriceVolatility(parseFloat(e.target.value))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Ambient Temp Mean (°C)</span>
                  <span className="font-bold">{tempMean}°C</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="42"
                  step="0.5"
                  value={tempMean}
                  onChange={(e) => setTempMean(parseFloat(e.target.value))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Monte Carlo Iterations</span>
                  <span className="font-bold">{runsCount}</span>
                </div>
                <input
                  type="range"
                  min="500"
                  max="5000"
                  step="500"
                  value={runsCount}
                  onChange={(e) => setRunsCount(parseInt(e.target.value, 10))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Histogram Visualization */}
          <div className="border-main bg-white p-4 space-y-3">
            <div className="border-b border-[#141414] pb-2 flex items-center justify-between">
              <span className="col-header">Daily Operating Cost Distribution ($/Day)</span>
              <span className="label text-[#16A34A] font-bold">Log-Normal Fitted</span>
            </div>

            <div className="h-40 bg-[#F9F8F6] border border-[#141414]/30 p-2 flex items-end justify-between gap-1">
              {histogram.map((bin, idx) => {
                const heightPct = (bin.count / maxBinCount) * 100;
                const isVaRTail = idx >= histogram.length - 2;

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full group relative">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 bg-[#141414] text-white text-[9px] px-2 py-0.5 pointer-events-none z-20 whitespace-nowrap border border-black font-mono">
                      {bin.binLabel}: {bin.count} runs
                    </div>
                    <div
                      className={`w-full border border-black ${isVaRTail ? 'bg-[#EF4444]' : 'bg-[#141414]'}`}
                      style={{ height: `${Math.max(heightPct, 4)}%` }}
                    ></div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between text-[10px] text-[#141414]/70 pt-1">
              <span>P10 Favorable (Low Cost)</span>
              <span>P50 Median</span>
              <span>P90 Tail (Price Shock Squeeze)</span>
            </div>
          </div>
        </div>

        {/* Right Column: Key Statistical Risk Metrics (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Risk Card matching Design HTML structure */}
          <div className="border-main p-4 bg-white space-y-3">
            <p className="label text-[#141414]/70">Monte Carlo Risk Bounds (P90 Confidence)</p>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span>Price Spike Stress Impact:</span>
                <span className="data-value text-[#F27D26]">
                  ${summary ? Math.round(summary.dailyEnergyCost.p90 - summary.dailyEnergyCost.p50).toLocaleString() : '142,000'}
                </span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span>Thermal Ceiling Excursion Risk:</span>
                <span className="data-value text-[#EF4444]">{summary?.thermalExcursionProbabilityPct || 2.4}%</span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span>Unplanned Derate Risk:</span>
                <span className="data-value text-[#141414]">{summary?.unplannedDerateProbabilityPct || 1.5}%</span>
              </div>
              <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                <span>95% Value at Risk (1-Day VaR):</span>
                <span className="data-value text-[#EF4444]">
                  ${summary ? Math.round(summary.valueAtRisk95PctUsd).toLocaleString() : '46,200'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>P50 Expected Daily Net Margin:</span>
                <span className="data-value text-[#16A34A]">
                  +${summary ? Math.round(summary.dailyNetMargin.p50).toLocaleString() : '682,000'}
                </span>
              </div>
            </div>
          </div>

          {/* Quantile Breakdown Grid */}
          <div className="border-main bg-white">
            <div className="border-b bg-[#F0EFED] px-3 py-2">
              <h3 className="col-header">Quantile Percentile Summary ($/Day)</h3>
            </div>
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-[#F0EFED] border-b border-[#141414]">
                <tr className="text-[10px] font-bold uppercase">
                  <th className="p-2 border-r border-[#141414]">Quantile</th>
                  <th className="p-2 border-r border-[#141414]">Daily Cost</th>
                  <th className="p-2">Net Margin</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[#141414]/30 hover:bg-[#F9F8F6]">
                  <td className="p-2 border-r border-[#141414] font-bold text-[#EF4444]">P10 (Downside)</td>
                  <td className="p-2 border-r border-[#141414]">
                    ${summary ? Math.round(summary.dailyEnergyCost.p90).toLocaleString() : '112,400'}
                  </td>
                  <td className="p-2 font-bold text-[#EF4444]">
                    +${summary ? Math.round(summary.dailyNetMargin.p10).toLocaleString() : '524,000'}
                  </td>
                </tr>
                <tr className="border-b border-[#141414]/30 hover:bg-[#F9F8F6]">
                  <td className="p-2 border-r border-[#141414] font-bold">P50 (Median)</td>
                  <td className="p-2 border-r border-[#141414]">
                    ${summary ? Math.round(summary.dailyEnergyCost.p50).toLocaleString() : '78,200'}
                  </td>
                  <td className="p-2 font-bold text-[#16A34A]">
                    +${summary ? Math.round(summary.dailyNetMargin.p50).toLocaleString() : '682,000'}
                  </td>
                </tr>
                <tr className="hover:bg-[#F9F8F6]">
                  <td className="p-2 border-r border-[#141414] font-bold text-[#16A34A]">P90 (Upside)</td>
                  <td className="p-2 border-r border-[#141414]">
                    ${summary ? Math.round(summary.dailyEnergyCost.p10).toLocaleString() : '58,400'}
                  </td>
                  <td className="p-2 font-bold text-[#16A34A]">
                    +${summary ? Math.round(summary.dailyNetMargin.p90).toLocaleString() : '794,000'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
