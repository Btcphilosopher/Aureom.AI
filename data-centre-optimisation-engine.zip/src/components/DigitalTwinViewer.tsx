import React, { useState } from 'react';
import {
  Layers,
  ChevronRight,
  Server,
  Cpu,
  Flame,
  Thermometer,
  Zap,
  Activity,
  Droplets,
  HardDrive,
  Info,
} from 'lucide-react';
import { DataCentreTwinState, RoomTwin, RowTwin, RackAsset, ServerAsset } from '../types';

interface Props {
  twin: DataCentreTwinState;
}

export const DigitalTwinViewer: React.FC<Props> = ({ twin }) => {
  const [selectedRoomId, setSelectedRoomId] = useState<string>(twin.rooms[0]?.roomId || '');
  const [selectedRowId, setSelectedRowId] = useState<string>(twin.rooms[0]?.rows[0]?.rowId || '');
  const [selectedRackId, setSelectedRackId] = useState<string>(twin.rooms[0]?.rows[0]?.racks[0]?.rackId || '');
  const [selectedServer, setSelectedServer] = useState<ServerAsset | null>(
    twin.rooms[0]?.rows[0]?.racks[0]?.servers[0] || null
  );

  const selectedRoom = twin.rooms.find((r) => r.roomId === selectedRoomId) || twin.rooms[0];
  const selectedRow = selectedRoom?.rows.find((r) => r.rowId === selectedRowId) || selectedRoom?.rows[0];
  const selectedRack = selectedRow?.racks.find((r) => r.rackId === selectedRackId) || selectedRow?.racks[0];

  const getTempColor = (temp: number) => {
    if (temp < 23) return 'text-[#16A34A] bg-[#22C55E]/10 border-[#22C55E]';
    if (temp < 27) return 'text-[#2563EB] bg-[#2563EB]/10 border-[#2563EB]';
    if (temp < 30) return 'text-[#F27D26] bg-[#F27D26]/10 border-[#F27D26]';
    return 'text-[#EF4444] bg-[#EF4444]/10 border-[#EF4444]';
  };

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Breadcrumb Hierarchy Navigation */}
      <div className="border-main bg-[#F0EFED] p-2 flex flex-wrap items-center gap-2 text-xs font-mono text-[#141414]">
        <span className="label text-[#141414]/70">Site:</span>
        <span className="px-2 py-0.5 bg-white border border-[#141414] font-bold">
          {twin.name}
        </span>
        <ChevronRight className="w-3.5 h-3.5 opacity-50" />

        <span className="label text-[#141414]/70">Hall:</span>
        <div className="flex space-x-1">
          {twin.rooms.map((room) => (
            <button
              key={room.roomId}
              id={`btn-room-${room.roomId}`}
              onClick={() => {
                setSelectedRoomId(room.roomId);
                setSelectedRowId(room.rows[0]?.rowId || '');
                setSelectedRackId(room.rows[0]?.racks[0]?.rackId || '');
                setSelectedServer(room.rows[0]?.racks[0]?.servers[0] || null);
              }}
              className={`px-2 py-0.5 border border-[#141414] text-xs transition-colors ${
                selectedRoomId === room.roomId
                  ? 'bg-[#141414] text-white font-bold'
                  : 'bg-white text-[#141414] hover:bg-[#F9F8F6]'
              }`}
            >
              {room.name.split(':')[0]}
            </button>
          ))}
        </div>
        <ChevronRight className="w-3.5 h-3.5 opacity-50" />

        <span className="label text-[#141414]/70">Row:</span>
        <div className="flex space-x-1">
          {selectedRoom?.rows.map((row) => (
            <button
              key={row.rowId}
              id={`btn-row-${row.rowId}`}
              onClick={() => {
                setSelectedRowId(row.rowId);
                setSelectedRackId(row.racks[0]?.rackId || '');
                setSelectedServer(row.racks[0]?.servers[0] || null);
              }}
              className={`px-2 py-0.5 border border-[#141414] text-xs transition-colors ${
                selectedRowId === row.rowId
                  ? 'bg-[#F27D26] text-black font-bold'
                  : 'bg-white text-[#141414] hover:bg-[#F9F8F6]'
              }`}
            >
              {row.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Digital Twin Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Site Hierarchy & Thermal Map (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="border-main bg-white">
            <div className="border-b bg-[#F0EFED] px-3 py-2">
              <h3 className="col-header">Site Hierarchy [Digital Twin Tree]</h3>
            </div>
            <div className="p-3 space-y-3 font-mono">
              <div className="border-main p-2.5 bg-[#F9F8F6] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#141414]">HYPERSCALE_LON_01</span>
                  <span className="label text-[9px] bg-white border border-[#141414] px-1 py-0.5">Active Twin</span>
                </div>
                <div className="space-y-1.5 text-xs text-[#141414]/80">
                  <div className="flex items-center gap-2">
                    <span className="status-dot bg-active"></span>
                    <span className="font-medium">Building 01 (Critical AI Hall)</span>
                  </div>
                  <div className="ml-4 text-[10px] text-[#141414]/60">Rows: 4 &bull; Racks: 24 (Direct Liquid Cooling)</div>

                  <div className="flex items-center gap-2">
                    <span className="status-dot bg-active"></span>
                    <span className="font-medium">Building 02 (Enterprise Cloud)</span>
                  </div>
                  <div className="ml-4 text-[10px] text-[#141414]/60">Rows: 2 &bull; Racks: 8 (CRAH Aisle Contained)</div>

                  <div className="flex items-center gap-2">
                    <span className="status-dot bg-[#2563EB]"></span>
                    <span className="font-medium">Central Chiller Plant</span>
                  </div>
                  <div className="ml-4 text-[10px] text-[#141414]/60">2x 2,500 kW Centrifugal Chillers (COP 6.2)</div>
                </div>
              </div>

              {/* Thermal Map Color Scale */}
              <div className="border-main p-2.5 bg-white">
                <p className="label mb-1">Thermal Gradient Scale (°C)</p>
                <div className="grid grid-cols-5 gap-1 text-center text-[9px] font-bold font-mono">
                  <div className="p-1 bg-blue-200 border border-[#141414] text-black">&lt;22°</div>
                  <div className="p-1 bg-green-300 border border-[#141414] text-black">22-24°</div>
                  <div className="p-1 bg-yellow-300 border border-[#141414] text-black">25-27°</div>
                  <div className="p-1 bg-orange-400 border border-[#141414] text-black">28-30°</div>
                  <div className="p-1 bg-red-400 border border-[#141414] text-white">&gt;30°</div>
                </div>
              </div>

              {/* Active Row Rack List */}
              <div className="space-y-1">
                <p className="label text-[#141414]/70">Racks in {selectedRow?.name}:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {selectedRow?.racks.map((rack) => {
                    const isSelected = selectedRackId === rack.rackId;
                    return (
                      <button
                        key={rack.rackId}
                        id={`btn-rack-${rack.rackId}`}
                        onClick={() => {
                          setSelectedRackId(rack.rackId);
                          setSelectedServer(rack.servers[0] || null);
                        }}
                        className={`p-2 text-left border transition-all ${
                          isSelected
                            ? 'bg-[#141414] text-white border-black font-bold'
                            : 'bg-white hover:bg-[#F0EFED] border-[#141414] text-[#141414]'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <span>{rack.name}</span>
                          <span
                            className={`text-[9px] px-1 py-0.2 border ${
                              rack.inletAirTempC > 27
                                ? 'bg-[#EF4444] text-white border-black'
                                : 'bg-[#22C55E]/20 text-[#141414] border-[#141414]'
                            }`}
                          >
                            {rack.inletAirTempC.toFixed(1)}°C
                          </span>
                        </div>
                        <div className="text-[10px] opacity-70 mt-1">
                          {rack.currentKwLoad.toFixed(1)} / {rack.maxKwCapacity} kW
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Rack Elevation & Server Slot Visualizer (4 cols) */}
        <div className="lg:col-span-4 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <h3 className="col-header">Rack Elevation [{selectedRack?.name}]</h3>
            <span className="label font-mono text-[#141414]">
              {selectedRack?.currentKwLoad.toFixed(1)} kW / {selectedRack?.maxKwCapacity} kW
            </span>
          </div>

          <div className="p-3 space-y-3 font-mono">
            {/* Rack Header Metrics */}
            <div className="grid grid-cols-3 gap-1.5 text-center text-[10px]">
              <div className="border-main p-1.5 bg-[#F9F8F6]">
                <div className="label">Inlet Temp</div>
                <div className="data-value text-xs">{selectedRack?.inletAirTempC.toFixed(1)}°C</div>
              </div>
              <div className="border-main p-1.5 bg-[#F9F8F6]">
                <div className="label">Exhaust Temp</div>
                <div className="data-value text-xs text-[#F27D26]">{selectedRack?.exhaustAirTempC.toFixed(1)}°C</div>
              </div>
              <div className="border-main p-1.5 bg-[#F9F8F6]">
                <div className="label">Cooling</div>
                <div className="font-bold text-[10px] truncate text-[#2563EB]">{selectedRack?.coolingTopology}</div>
              </div>
            </div>

            {/* 42U / 48U Server Slots List */}
            <div className="border-main bg-[#141414] p-1.5 space-y-1 max-h-[460px] overflow-y-auto">
              {selectedRack?.servers.map((srv) => {
                const isSelected = selectedServer?.assetId === srv.assetId;
                const maxGpuTemp = Math.max(...(srv.gpus.map((g) => g.currentTempC) || [45]));
                const totalGpus = srv.gpus.length;

                return (
                  <button
                    key={srv.assetId}
                    id={`srv-slot-${srv.assetId}`}
                    onClick={() => setSelectedServer(srv)}
                    className={`w-full text-left p-2 border transition-all flex items-center justify-between font-mono ${
                      isSelected
                        ? 'bg-white text-black border-black font-bold'
                        : 'bg-[#141414] hover:bg-[#202020] text-white border-zinc-800'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <div className={`px-1.5 py-0.5 text-[9px] border ${isSelected ? 'bg-[#141414] text-white border-black' : 'bg-zinc-800 text-white border-zinc-700'}`}>
                        {srv.uStart}U-{srv.uEnd}U
                      </div>
                      <div>
                        <div className="text-[11px] font-bold truncate">{srv.hostname}</div>
                        <div className="text-[9px] opacity-70">
                          {totalGpus > 0 ? `${totalGpus}x GPUs (${srv.gpus[0]?.model.split(' ')[1] || 'GPU'})` : '2x Xeon Platinum'}
                        </div>
                      </div>
                    </div>

                    <div className="text-right text-[10px]">
                      <div className="font-bold text-[#F27D26]">{srv.powerDrawKw.toFixed(1)} kW</div>
                      <div className={maxGpuTemp > 80 ? 'text-[#EF4444] font-bold' : 'text-[#00FF00]'}>
                        {maxGpuTemp.toFixed(0)}°C
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Selected Node Deep Telemetry (4 cols) */}
        <div className="lg:col-span-4 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <h3 className="col-header">Node Telemetry Inspector</h3>
            <span className="label font-mono text-[#141414]">{selectedServer?.hostname || 'No Node Selected'}</span>
          </div>

          <div className="p-3 space-y-3 font-mono">
            {selectedServer ? (
              <>
                {/* Node Summary Spec */}
                <div className="border-main p-2.5 bg-[#F9F8F6] space-y-1 text-[11px]">
                  <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                    <span className="opacity-70">Asset ID:</span>
                    <span className="font-bold">{selectedServer.assetId}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                    <span className="opacity-70">Form Factor:</span>
                    <span>{selectedServer.formFactorU}U Rackmount</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/20 pb-1">
                    <span className="opacity-70">Total Power Draw:</span>
                    <span className="font-bold text-[#F27D26]">{selectedServer.powerDrawKw.toFixed(2)} kW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-70">Inlet / Exhaust:</span>
                    <span>{selectedServer.inletTempC.toFixed(1)}°C / {selectedServer.exhaustTempC.toFixed(1)}°C</span>
                  </div>
                </div>

                {/* GPU Sockets Grid */}
                {selectedServer.gpus.length > 0 && (
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="label">GPU Sockets ({selectedServer.gpus.length}x NVLink):</span>
                      <span className="text-[10px] text-[#2563EB] font-bold">Liquid Cooled</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {selectedServer.gpus.map((gpu) => (
                        <div key={gpu.gpuId} className="border-main p-2 bg-white">
                          <div className="flex justify-between text-[10px] font-bold">
                            <span>{gpu.gpuId.split('-').slice(-2).join('-')}</span>
                            <span className={gpu.currentTempC > 80 ? 'text-[#EF4444]' : 'text-[#16A34A]'}>
                              {gpu.currentTempC.toFixed(0)}°C
                            </span>
                          </div>
                          <div className="mt-1.5 h-1 w-full bg-[#141414]/10">
                            <div
                              className="h-full bg-[#141414]"
                              style={{ width: `${gpu.currentUtilizationPct}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between text-[9px] opacity-70 mt-1">
                            <span>{gpu.currentUtilizationPct.toFixed(0)}% Load</span>
                            <span>{gpu.currentPowerWatts}W</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* CPU Sockets */}
                <div className="space-y-1.5">
                  <span className="label">CPU Sockets:</span>
                  <div className="space-y-1">
                    {selectedServer.cpus.map((cpu) => (
                      <div key={cpu.cpuId} className="border-main p-2 bg-[#F9F8F6] text-[10px]">
                        <div className="flex justify-between font-bold">
                          <span>{cpu.model.split(' ')[0]} {cpu.model.split(' ')[1]}</span>
                          <span>{cpu.currentTempC.toFixed(1)}°C</span>
                        </div>
                        <div className="flex justify-between opacity-70 mt-0.5">
                          <span>{cpu.cores} Cores / {cpu.threads} Threads</span>
                          <span>{cpu.currentUtilizationPct.toFixed(1)}% ({cpu.currentPowerWatts.toFixed(0)}W)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="p-8 text-center text-[#141414]/60">Select a server to view details</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
