import React from 'react';
import {
  Activity,
  Zap,
  Flame,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Sparkles,
  Cpu,
  Droplets,
  ArrowRight,
} from 'lucide-react';
import { TelemetrySnapshot, AnomalyAlert } from '../types';

interface Props {
  snapshot: TelemetrySnapshot | null;
  history: TelemetrySnapshot[];
  alerts: AnomalyAlert[];
  onNavigateToTab: (tab: string) => void;
  onRunQuickOptimize: () => void;
  isOptimizing: boolean;
}

export const RealTimeTelemetryView: React.FC<Props> = ({
  snapshot,
  history,
  alerts,
  onNavigateToTab,
  onRunQuickOptimize,
  isOptimizing,
}) => {
  if (!snapshot) {
    return (
      <div className="p-12 text-center text-[#141414] font-mono text-xs">
        Loading real-time telemetry stream from Digital Twin...
      </div>
    );
  }

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner: Section Header & Actions */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="status-dot bg-active animate-pulse"></span>
            <h2 className="text-sm font-bold text-[#141414] tracking-tight uppercase font-serif">
              Real-Time Telemetry & Operations [Rust Engine]
            </h2>
          </div>
          <p className="label text-[#141414]/70 mt-0.5">
            Streaming telemetry at 2.5s intervals &bull; 100% Traceable Physics &bull; Real-Time Energy Arbitrage
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            id="btn-quick-optimize"
            onClick={onRunQuickOptimize}
            disabled={isOptimizing}
            className="px-3 py-1.5 bg-[#F27D26] hover:bg-[#e06c17] text-black font-bold text-[10px] uppercase tracking-widest border border-[#141414] flex items-center space-x-1.5 transition-all active:scale-95 disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isOptimizing ? 'SOLVING MILP...' : 'EXECUTE PARETO SOLVER'}</span>
          </button>
        </div>
      </div>

      {/* Primary 2-Card Metrics (Dark High-Contrast + Off-White) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="border-main p-4 bg-[#141414] text-white">
          <p className="label text-white/60">GPU Compute Throughput</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl data-value text-white">
              {((snapshot.totalTflopsDelivered || 22000000) / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 })}
            </span>
            <span className="text-[10px] font-mono text-white/60">TFLOPS/s</span>
          </div>
          <div className="mt-3 h-1.5 w-full bg-white/20">
            <div
              className="h-full bg-[#00FF00]"
              style={{ width: `${Math.min(snapshot.averageGpuUtilizationPct, 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-white/60 mt-1">
            <span>Cluster Load</span>
            <span className="text-[#00FF00] font-bold">{snapshot.averageGpuUtilizationPct}%</span>
          </div>
        </div>

        <div className="border-main p-4 bg-white">
          <p className="label text-[#141414]/70">Cooling COP (Efficiency)</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl data-value text-[#141414]">
              {(snapshot.itPowerMw / Math.max(snapshot.coolingPowerMw, 0.1)).toFixed(2)}
            </span>
            <span className="text-[10px] font-mono text-[#141414]/60">COP factor</span>
          </div>
          <div className="mt-3 h-1.5 w-full bg-[#141414]/10">
            <div
              className="h-full bg-[#2563EB]"
              style={{ width: `${Math.min((snapshot.itPowerMw / Math.max(snapshot.coolingPowerMw, 0.1)) * 14, 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-[#141414]/60 mt-1">
            <span>Waterside COP</span>
            <span className="text-[#2563EB] font-bold">5.85</span>
          </div>
        </div>

        <div className="border-main p-4 bg-[#F9F8F6]">
          <p className="label text-[#141414]/70">Instantaneous Power</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl data-value text-[#141414]">{snapshot.totalFacilityPowerMw}</span>
            <span className="text-[10px] font-mono text-[#141414]/60">MW total</span>
          </div>
          <div className="mt-2 text-[10px] font-mono space-y-0.5 text-[#141414]/80">
            <div className="flex justify-between">
              <span>IT Compute:</span>
              <span className="font-bold">{snapshot.itPowerMw} MW</span>
            </div>
            <div className="flex justify-between">
              <span>Cooling Plant:</span>
              <span className="font-bold">{snapshot.coolingPowerMw} MW</span>
            </div>
          </div>
        </div>

        <div className="border-main p-4 bg-white">
          <p className="label text-[#141414]/70">Hourly Energy Cost</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl data-value text-[#F27D26]">
              ${snapshot.hourlyEnergyCostUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
            <span className="text-[10px] font-mono text-[#141414]/60">/ hr</span>
          </div>
          <div className="mt-2 text-[10px] font-mono space-y-0.5 text-[#141414]/80">
            <div className="flex justify-between">
              <span>Spot Tariff:</span>
              <span className="font-bold text-[#F27D26]">${snapshot.spotElectricityPricePerMwh}/MWh</span>
            </div>
            <div className="flex justify-between">
              <span>Net Margin:</span>
              <span className="font-bold text-[#16A34A]">+${Math.round(snapshot.hourlyNetMarginUsd).toLocaleString()}/hr</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Time-Series Visualizers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Real-Time Power Breakdown Stream (7 Cols) */}
        <div className="lg:col-span-7 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <h3 className="col-header">Power Demand Stream [MW] (Last 30 Ticks)</h3>
            <span className="label font-mono text-[#141414]">Facility Total: {snapshot.totalFacilityPowerMw} MW</span>
          </div>

          <div className="p-3 space-y-2">
            <div className="h-36 bg-[#F9F8F6] border border-[#141414]/30 p-2 flex items-end space-x-1">
              {history.map((snap, idx) => {
                const maxScaleMw = 48.0;
                const itHeight = (snap.itPowerMw / maxScaleMw) * 100;
                const coolHeight = (snap.coolingPowerMw / maxScaleMw) * 100;

                return (
                  <div key={idx} className="flex-1 flex flex-col justify-end h-full group relative">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 left-1/2 -translate-x-1/2 bg-[#141414] text-white text-[9px] px-2 py-0.5 pointer-events-none z-20 whitespace-nowrap border border-black font-mono">
                      Tot: {snap.totalFacilityPowerMw}MW | IT: {snap.itPowerMw}MW | Cool: {snap.coolingPowerMw}MW
                    </div>
                    <div
                      className="w-full bg-[#2563EB]"
                      style={{ height: `${coolHeight}%` }}
                      title={`Cooling: ${snap.coolingPowerMw} MW`}
                    ></div>
                    <div
                      className="w-full bg-[#141414]"
                      style={{ height: `${itHeight}%` }}
                      title={`IT: ${snap.itPowerMw} MW`}
                    ></div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between items-center text-[10px] font-mono text-[#141414]/70 pt-1">
              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 bg-[#141414] border border-black"></span>
                  <span>IT Compute Load</span>
                </span>
                <span className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 bg-[#2563EB]"></span>
                  <span>Cooling Plant</span>
                </span>
              </div>
              <span className="text-[#141414] font-bold">Tick Rate: 2.5s</span>
            </div>
          </div>
        </div>

        {/* Right: Tariff & PUE Stream (5 Cols) */}
        <div className="lg:col-span-5 border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <h3 className="col-header">Electricity Spot Tariff ($/MWh)</h3>
            <span className="label font-mono text-[#16A34A]">PUE: {snapshot.instantaneousPue}</span>
          </div>

          <div className="p-3 space-y-2">
            <div className="h-36 bg-[#F9F8F6] border border-[#141414]/30 p-2 flex items-end space-x-1">
              {history.map((snap, idx) => {
                const maxPrice = 500;
                const priceHeight = (snap.spotElectricityPricePerMwh / maxPrice) * 100;
                const isSpike = snap.spotElectricityPricePerMwh > 140;

                return (
                  <div key={idx} className="flex-1 flex flex-col justify-end h-full group relative">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 left-1/2 -translate-x-1/2 bg-[#141414] text-white text-[9px] px-2 py-0.5 pointer-events-none z-20 whitespace-nowrap border border-black font-mono">
                      ${snap.spotElectricityPricePerMwh}/MWh | PUE: {snap.instantaneousPue}
                    </div>
                    <div
                      className={`w-full ${isSpike ? 'bg-[#EF4444]' : 'bg-[#F27D26]'}`}
                      style={{ height: `${Math.max(priceHeight, 8)}%` }}
                    ></div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between items-center text-[10px] font-mono text-[#141414]/70 pt-1">
              <span>Market Tariff Curve</span>
              <span className="text-[#F27D26] font-bold">
                Current: ${snapshot.spotElectricityPricePerMwh}/MWh
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Data Grid Table: Live Asset Telemetry */}
      <div className="border-main bg-white">
        <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
          <h3 className="col-header">Real-Time Asset Telemetry Grid [Ring Buffer]</h3>
          <span className="label text-[#141414]">Live Polling: 8 Nodes Active</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-[#F0EFED] border-b border-[#141414]">
              <tr className="text-[10px] font-bold uppercase tracking-wider font-mono">
                <th className="p-2 border-r border-[#141414]">Asset ID</th>
                <th className="p-2 border-r border-[#141414]">Subsystem</th>
                <th className="p-2 border-r border-[#141414]">Load / Flow</th>
                <th className="p-2 border-r border-[#141414]">Temperature</th>
                <th className="p-2 border-r border-[#141414]">Power</th>
                <th className="p-2">Operating State</th>
              </tr>
            </thead>
            <tbody className="text-xs font-mono">
              <tr className="border-b border-[#141414]/40 hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">GPU-H100-R1-01</td>
                <td className="p-2 border-r border-[#141414]">AI Cluster Hall A</td>
                <td className="p-2 border-r border-[#141414]">94.2% Utilization</td>
                <td className="p-2 border-r border-[#141414]">78.4°C</td>
                <td className="p-2 border-r border-[#141414]">5.6 kW</td>
                <td className="p-2 text-[#16A34A] font-bold">OPTIMAL</td>
              </tr>
              <tr className="border-b border-[#141414]/40 hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">GPU-B200-R1-02</td>
                <td className="p-2 border-r border-[#141414]">AI Cluster Hall A</td>
                <td className="p-2 border-r border-[#141414]">98.5% (FP8 GEMM)</td>
                <td className="p-2 border-r border-[#141414] text-[#F27D26] font-bold">81.2°C</td>
                <td className="p-2 border-r border-[#141414]">8.0 kW</td>
                <td className="p-2 text-[#F27D26] font-bold">HEAVY LOAD</td>
              </tr>
              <tr className="border-b border-[#141414]/40 hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">CDU-PRIMARY-01</td>
                <td className="p-2 border-r border-[#141414]">Liquid Distribution</td>
                <td className="p-2 border-r border-[#141414]">420 LPM (Water-Glycol)</td>
                <td className="p-2 border-r border-[#141414]">32.0°C / 46.5°C</td>
                <td className="p-2 border-r border-[#141414]">28.4 kW</td>
                <td className="p-2 text-[#16A34A] font-bold">STEADY</td>
              </tr>
              <tr className="border-b border-[#141414]/40 hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">CHILLER-MAG-01</td>
                <td className="p-2 border-r border-[#141414]">Central Plant</td>
                <td className="p-2 border-r border-[#141414]">62.0% VFD Speed</td>
                <td className="p-2 border-r border-[#141414]">7.2°C Evap</td>
                <td className="p-2 border-r border-[#141414]">1.85 MW</td>
                <td className="p-2 text-[#16A34A] font-bold">NOMINAL (COP 6.2)</td>
              </tr>
              <tr className="border-b border-[#141414]/40 hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">BESS-LFP-BANK</td>
                <td className="p-2 border-r border-[#141414]">Energy Storage</td>
                <td className="p-2 border-r border-[#141414]">{snapshot.bessSocPct}% SOC</td>
                <td className="p-2 border-r border-[#141414]">22.4°C</td>
                <td className="p-2 border-r border-[#141414]">
                  {snapshot.bessPowerKw > 0 ? `+${(snapshot.bessPowerKw/1000).toFixed(1)} MW (Discharge)` : '0.0 kW (Idle)'}
                </td>
                <td className="p-2 text-[#2563EB] font-bold">
                  {snapshot.bessPowerKw > 0 ? 'PEAK SHAVING' : 'READY'}
                </td>
              </tr>
              <tr className="hover:bg-[#F9F8F6]">
                <td className="p-2 border-r border-[#141414] font-bold">HEAT-EX-DISTRICT</td>
                <td className="p-2 border-r border-[#141414]">Thermal Export</td>
                <td className="p-2 border-r border-[#141414]">185 m³/h</td>
                <td className="p-2 border-r border-[#141414]">62.0°C Return</td>
                <td className="p-2 border-r border-[#141414] text-[#F27D26] font-bold">{snapshot.districtHeatRecoveredMw} MWth</td>
                <td className="p-2 text-[#16A34A] font-bold">EXPORTING</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Anomaly Alerts & Active Deviations */}
      <div className="border-main bg-white">
        <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-2 font-bold text-[#141414] uppercase font-serif">
            <AlertTriangle className="w-4 h-4 text-[#F27D26]" />
            <span className="col-header opacity-100">Thermal Excursions & Digital Twin Anomaly Diagnostics</span>
          </div>
          <span className="label text-[#141414] font-mono">{alerts.length} Active Incidents</span>
        </div>

        <div className="p-3">
          {alerts.length > 0 ? (
            <div className="space-y-2">
              {alerts.map((alert) => (
                <div
                  key={alert.alertId}
                  className={`p-3 border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 ${
                    alert.severity === 'Critical'
                      ? 'bg-[#EF4444]/10 border-[#EF4444] text-[#141414]'
                      : 'bg-[#F27D26]/10 border-[#F27D26] text-[#141414]'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="font-bold flex items-center space-x-2 font-mono">
                      <span>{alert.title}</span>
                      <span className="text-[10px] px-1.5 py-0.2 border border-[#141414] bg-white">
                        {alert.assetId}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#141414]/80">{alert.description}</p>
                    <p className="text-[10px] font-mono text-[#141414]/70">
                      Recommended Action: <strong className="text-[#141414] underline">{alert.recommendedAction}</strong>
                    </p>
                  </div>

                  <div className="text-right flex-shrink-0 font-mono">
                    <div className="text-xs font-bold text-[#EF4444]">
                      -${alert.economicImpactUsdHr}/hr
                    </div>
                    <div className="text-[10px] text-[#141414]/60">Economic Penalty</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 bg-[#F9F8F6] border border-[#141414]/30 text-center text-[#141414]">
              <ShieldCheck className="w-6 h-6 text-[#16A34A] mx-auto mb-1" />
              <div className="font-bold font-serif text-sm">All Physical Subsystems Operating Nominally</div>
              <p className="text-[11px] text-[#141414]/70 mt-0.5 font-mono">
                Temperatures, pressures, flow rates, and electrical voltages are well within ASHRAE TC9.9 &amp; IEEE boundaries.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
