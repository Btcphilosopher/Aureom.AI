import React, { useState } from 'react';
import {
  Cpu,
  Clock,
  Zap,
  TrendingDown,
  Layers,
  CheckCircle,
  PauseCircle,
  PlayCircle,
  DollarSign,
  BarChart3,
  Calendar,
} from 'lucide-react';
import { WorkloadJob, TelemetrySnapshot } from '../types';

interface Props {
  workloads: WorkloadJob[];
  snapshot: TelemetrySnapshot | null;
}

export const ComputeSchedulerView: React.FC<Props> = ({ workloads, snapshot }) => {
  const [activeTab, setActiveTab] = useState<'queue' | 'shifting'>('queue');

  // Synthetic 24-Hour Price & Load Data for visual workload shifting
  const hourlyData = [
    { hour: '00:00', price: 38, baseLoad: 28.5, shiftedLoad: 32.5, carbon: 95 },
    { hour: '02:00', price: 29, baseLoad: 28.0, shiftedLoad: 34.0, carbon: 70 },
    { hour: '04:00', price: 32, baseLoad: 27.8, shiftedLoad: 33.5, carbon: 80 },
    { hour: '06:00', price: 65, baseLoad: 29.0, shiftedLoad: 29.0, carbon: 140 },
    { hour: '08:00', price: 110, baseLoad: 31.5, shiftedLoad: 30.0, carbon: 220 },
    { hour: '10:00', price: 145, baseLoad: 33.0, shiftedLoad: 27.5, carbon: 260 },
    { hour: '12:00', price: 120, baseLoad: 32.5, shiftedLoad: 28.0, carbon: 210 },
    { hour: '14:00', price: 95, baseLoad: 31.0, shiftedLoad: 29.5, carbon: 180 },
    { hour: '16:00', price: 165, baseLoad: 34.0, shiftedLoad: 26.0, carbon: 310 },
    { hour: '18:00', price: 195, baseLoad: 34.5, shiftedLoad: 25.5, carbon: 340 },
    { hour: '20:00', price: 140, baseLoad: 32.0, shiftedLoad: 28.0, carbon: 250 },
    { hour: '22:00', price: 72, baseLoad: 29.5, shiftedLoad: 31.0, carbon: 130 },
  ];

  const totalGpus = snapshot?.totalGpuCount || 12288;
  const activeGpus = snapshot?.activeGpus || 11450;
  const totalPflops = ((snapshot?.totalTflopsDelivered || 22000000) / 1000).toFixed(0);

  return (
    <div className="space-y-4 font-sans text-xs">
      {/* Top Banner */}
      <div className="border-main bg-[#F0EFED] p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#141414] uppercase font-serif flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-[#141414]" />
            <span>GPU Cluster Capacity & Dynamic Workload Scheduler</span>
          </h2>
          <p className="label text-[#141414]/70 mt-0.5">
            12,288 GPUs &bull; NVLink 900GB/s Fabric &bull; Spot Price Arbitrage Workload Shifting
          </p>
        </div>
        <div className="flex space-x-1 font-mono">
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-3 py-1 text-xs border border-[#141414] transition-all ${
              activeTab === 'queue' ? 'bg-[#141414] text-white font-bold' : 'bg-white text-[#141414] hover:bg-[#F9F8F6]'
            }`}
          >
            Active Job Queue
          </button>
          <button
            onClick={() => setActiveTab('shifting')}
            className={`px-3 py-1 text-xs border border-[#141414] transition-all ${
              activeTab === 'shifting' ? 'bg-[#F27D26] text-black font-bold' : 'bg-white text-[#141414] hover:bg-[#F9F8F6]'
            }`}
          >
            24h Workload Shifting
          </button>
        </div>
      </div>

      {/* GPU Fleet Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono">
        <div className="border-main p-3 bg-white">
          <div className="label">Total GPU Nodes</div>
          <div className="data-value text-xl text-[#141414] mt-1">{totalGpus.toLocaleString()} GPUs</div>
          <div className="text-[10px] opacity-70 mt-0.5">1,536x 8-GPU Chassis</div>
        </div>

        <div className="border-main p-3 bg-[#141414] text-white">
          <div className="label text-white/60">Active Utilization</div>
          <div className="data-value text-xl text-[#00FF00] mt-1">
            {snapshot?.averageGpuUtilizationPct || 92.4}%
          </div>
          <div className="text-[10px] text-white/60 mt-0.5">{activeGpus.toLocaleString()} GPUs Running Jobs</div>
        </div>

        <div className="border-main p-3 bg-white">
          <div className="label">Delivered Compute</div>
          <div className="data-value text-xl text-[#141414] mt-1">{totalPflops} TFLOPS</div>
          <div className="text-[10px] opacity-70 mt-0.5">FP8 Tensor Core Throughput</div>
        </div>

        <div className="border-main p-3 bg-[#F9F8F6]">
          <div className="label">Hourly Compute Revenue</div>
          <div className="data-value text-xl text-[#16A34A] mt-1">
            +${Math.round(activeGpus * 2.85).toLocaleString()}/hr
          </div>
          <div className="text-[10px] opacity-70 mt-0.5">Blended GPU-hour Contract Rate</div>
        </div>
      </div>

      {/* Main Content: Queue or Shifting Matrix */}
      {activeTab === 'queue' ? (
        <div className="border-main bg-white">
          <div className="border-b bg-[#F0EFED] px-3 py-2 flex items-center justify-between">
            <h3 className="col-header">Cluster Workload Dispatch Queue [SLA & Thermal Priority]</h3>
            <span className="label font-mono text-[#141414]">{workloads.length} Active Jobs Scheduled</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead className="bg-[#F0EFED] border-b border-[#141414]">
                <tr className="text-[10px] font-bold uppercase tracking-wider">
                  <th className="p-2 border-r border-[#141414]">Job ID / Name</th>
                  <th className="p-2 border-r border-[#141414]">Category</th>
                  <th className="p-2 border-r border-[#141414]">Priority</th>
                  <th className="p-2 border-r border-[#141414]">GPUs Allocated</th>
                  <th className="p-2 border-r border-[#141414]">Deadline / SLA</th>
                  <th className="p-2 border-r border-[#141414]">Status</th>
                  <th className="p-2">Value ($/hr)</th>
                </tr>
              </thead>
              <tbody>
                {workloads.map((job) => {
                  const isFlexible = job.priority === 4;
                  const isPaused = job.currentStatus === 'PausedFlexible';

                  return (
                    <tr key={job.jobId} className="border-b border-[#141414]/30 hover:bg-[#F9F8F6]">
                      <td className="p-2 border-r border-[#141414] font-bold">
                        <div>{job.name}</div>
                        <div className="text-[9px] opacity-60">{job.jobId}</div>
                      </td>
                      <td className="p-2 border-r border-[#141414]">
                        <span className="px-1.5 py-0.5 border border-[#141414] text-[10px] bg-white">
                          {job.category}
                        </span>
                      </td>
                      <td className="p-2 border-r border-[#141414]">
                        <span
                          className={`px-1.5 py-0.5 text-[10px] font-bold border ${
                            job.priority === 1
                              ? 'bg-[#EF4444] text-white border-black'
                              : job.priority === 2
                              ? 'bg-[#F27D26] text-black border-black'
                              : 'bg-[#F0EFED] text-[#141414] border-[#141414]'
                          }`}
                        >
                          P{job.priority} {job.priority === 1 ? '(Critical SLA)' : isFlexible ? '(Flexible)' : ''}
                        </span>
                      </td>
                      <td className="p-2 border-r border-[#141414] font-bold">
                        {job.requiredGpus.toLocaleString()} GPUs
                      </td>
                      <td className="p-2 border-r border-[#141414] text-[11px] opacity-80">
                        {job.deadlineHoursRemaining}h remaining
                      </td>
                      <td className="p-2 border-r border-[#141414]">
                        <span
                          className={`px-2 py-0.5 text-[10px] font-bold border ${
                            isPaused
                              ? 'bg-[#F27D26]/20 border-[#F27D26] text-[#F27D26]'
                              : 'bg-[#22C55E]/20 border-[#22C55E] text-[#16A34A]'
                          }`}
                        >
                          {job.currentStatus}
                        </span>
                      </td>
                      <td className="p-2 font-bold text-[#16A34A]">
                        +${Math.round(job.requiredGpus * job.revenueRateUsdPerGpuHr).toLocaleString()}/hr
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* 24-Hour Shifting Matrix */
        <div className="border-main bg-white p-4 space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-[#141414] pb-2">
            <h3 className="col-header">24-Hour Spot Tariff Arbitrage & Load Shifting Simulation</h3>
            <span className="label bg-[#F27D26] text-black font-bold px-2 py-0.5 border border-black">
              Arbitrage Capture: +$24,500 / Day
            </span>
          </div>

          <div className="h-44 bg-[#F9F8F6] border border-[#141414]/30 p-3 flex items-end justify-between gap-1">
            {hourlyData.map((d, i) => {
              const isPeak = d.price > 120;
              return (
                <div key={i} className="flex-1 flex flex-col items-center justify-end h-full group relative">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-10 bg-[#141414] text-white text-[9px] px-2 py-1 pointer-events-none z-20 whitespace-nowrap border border-black">
                    {d.hour} | Spot: ${d.price}/MWh | Shifted: {d.shiftedLoad}MW (Base: {d.baseLoad}MW)
                  </div>
                  {/* Shifted bar */}
                  <div
                    className={`w-full border border-black ${isPeak ? 'bg-[#F27D26]' : 'bg-[#141414]'}`}
                    style={{ height: `${(d.shiftedLoad / 40) * 100}%` }}
                  ></div>
                  <span className="text-[9px] opacity-70 mt-1">{d.hour}</span>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between items-center text-[11px] text-[#141414]/80 border-t border-[#141414]/20 pt-2">
            <div className="flex items-center space-x-4">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 bg-[#141414] border border-black"></span>
                <span>Off-Peak Accelerated Compute (34MW)</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 bg-[#F27D26] border border-black"></span>
                <span>Peak Throttled / Deferred Compute (25.5MW)</span>
              </span>
            </div>
            <span className="font-bold text-[#16A34A]">Energy Cost Reduction: -18.4%</span>
          </div>
        </div>
      )}
    </div>
  );
};
