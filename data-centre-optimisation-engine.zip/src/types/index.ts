export type FacilityTier = 'Tier1' | 'Tier2' | 'Tier3' | 'Tier4';

export type CoolingTopology =
  | 'DirectExpansionAir'
  | 'ChilledWaterCRAH'
  | 'DirectToChipLiquid'
  | 'ImmersionTwoPhase'
  | 'HybridAirLiquid';

export type OperatingState =
  | 'Nominal'
  | 'Degraded'
  | 'Maintenance'
  | 'Standby'
  | 'Emergency'
  | 'Offline';

export type WorkloadPriority = 1 | 2 | 3 | 4; // 1=Critical SLA, 2=High, 3=Standard, 4=Flexible Opportunistic

export type WorkloadCategory =
  | 'AITraining'
  | 'AIInference'
  | 'HighPerformanceComputing'
  | 'CloudEnterprise'
  | 'RealtimeDatabase'
  | 'BatchAnalytics';

export interface GpuSpec {
  gpuId: string;
  model: string;
  architecture: string;
  vramGb: number;
  tdpWatts: number;
  maxJunctionTempC: number;
  interconnectGbps: number;
  currentUtilizationPct: number;
  currentTempC: number;
  currentPowerWatts: number;
}

export interface CpuSpec {
  cpuId: string;
  model: string;
  cores: number;
  threads: number;
  tdpWatts: number;
  currentUtilizationPct: number;
  currentTempC: number;
  currentPowerWatts: number;
}

export interface ServerAsset {
  assetId: string;
  hostname: string;
  formFactorU: number;
  uStart: number;
  uEnd: number;
  cpus: CpuSpec[];
  gpus: GpuSpec[];
  memoryGb: number;
  storageTb: number;
  networkGbps: number;
  coolingType: CoolingTopology;
  state: OperatingState;
  powerDrawKw: number;
  inletTempC: number;
  exhaustTempC: number;
}

export interface RackAsset {
  rackId: string;
  rowId: string;
  name: string;
  maxKwCapacity: number;
  currentKwLoad: number;
  maxUnits: number;
  usedUnits: number;
  coolingTopology: CoolingTopology;
  inletAirTempC: number;
  exhaustAirTempC: number;
  coolantSupplyTempC?: number;
  coolantReturnTempC?: number;
  liquidFlowLpm?: number;
  servers: ServerAsset[];
}

export interface RowTwin {
  rowId: string;
  name: string;
  containmentType: 'Cold Aisle' | 'Hot Aisle' | 'Uncontained';
  racks: RackAsset[];
}

export interface RoomTwin {
  roomId: string;
  name: string;
  roomType: 'AI Supercomputing' | 'Enterprise Cloud' | 'UPS / Electrical' | 'Central Chiller Plant';
  coolingTopology: CoolingTopology;
  maxCapacityKw: number;
  currentLoadKw: number;
  targetTempC: number;
  currentTempC: number;
  humidityPct: number;
  rows: RowTwin[];
}

export interface UpsAsset {
  assetId: string;
  capacityKva: number;
  activeLoadKw: number;
  efficiencyPct: number;
  redundancyMode: string;
  batterySocPct: number;
  batteryRuntimeMinutes: number;
  state: OperatingState;
}

export interface BatteryEnergyStorage {
  assetId: string;
  totalCapacityKwh: number;
  currentSocPct: number;
  maxChargeKw: number;
  maxDischargeKw: number;
  currentPowerKw: number; // positive = discharging, negative = charging
  roundTripEfficiency: number;
  healthSohPct: number;
  cyclesCompleted: number;
}

export interface GeneratorAsset {
  assetId: string;
  capacityKw: number;
  fuelType: string;
  fuelRemainingLiters: number;
  fuelBurnRateLPerHr: number;
  startupLatencySeconds: number;
  isRunning: boolean;
  powerOutputKw: number;
}

export interface ChillerAsset {
  assetId: string;
  ratedCoolingKw: number;
  currentCoolingKw: number;
  electricalPowerKw: number;
  cop: number;
  chilledWaterSupplyTempC: number;
  chilledWaterReturnTempC: number;
  condenserWaterSupplyTempC: number;
  compressorSpeedPct: number;
  state: OperatingState;
}

export interface LiquidCoolingLoop {
  loopId: string;
  cduId: string;
  coolingCapacityKw: number;
  currentHeatRejectionKw: number;
  supplyTempC: number;
  returnTempC: number;
  flowRateLpm: number;
  pressureDropBar: number;
  pumpPowerKw: number;
  heatRecoveryActive: boolean;
  heatRecoveredKw: number;
}

export interface DataCentreTwinState {
  siteId: string;
  name: string;
  location: string;
  tier: FacilityTier;
  contractedPowerMw: number;
  peakPowerLimitMw: number;
  coolingDesignMw: number;
  totalFloorAreaSqm: number;
  rooms: RoomTwin[];
  upsSystems: UpsAsset[];
  batteryStorage: BatteryEnergyStorage[];
  backupGenerators: GeneratorAsset[];
  chillers: ChillerAsset[];
  cduLoops: LiquidCoolingLoop[];
}

export interface TelemetrySnapshot {
  timestamp: string;
  gridPowerMw: number;
  itPowerMw: number;
  coolingPowerMw: number;
  auxiliaryPowerMw: number;
  totalFacilityPowerMw: number;
  instantaneousPue: number;
  itCapacityHeadroomMw: number;
  coolingCapacityHeadroomMw: number;
  
  spotElectricityPricePerMwh: number;
  gridCarbonIntensityGCo2PerKwh: number;
  ambientOutsideTempC: number;
  ambientRelativeHumidityPct: number;
  wetBulbTempC: number;
  
  totalGpuCount: number;
  activeGpus: number;
  averageGpuUtilizationPct: number;
  totalTflopsDelivered: number;
  
  bessSocPct: number;
  bessPowerKw: number;
  generatorPowerKw: number;
  
  districtHeatRecoveredMw: number;
  hourlyEnergyCostUsd: number;
  hourlyGrossRevenueUsd: number;
  hourlyNetMarginUsd: number;
  
  activeBottleneck: string;
  thermalRiskScore: number;
}

export interface WorkloadJob {
  jobId: string;
  name: string;
  category: WorkloadCategory;
  priority: WorkloadPriority;
  requiredGpus: number;
  requiredVramGb: number;
  requiredCpus: number;
  estimatedDurationHours: number;
  deadlineHoursRemaining: number;
  maxAcceptableLatencyMs: number;
  isPreemptible: boolean;
  revenueRateUsdPerGpuHr: number;
  powerScalingFactor: number;
  currentStatus: 'Running' | 'Queued' | 'PausedFlexible' | 'Completed';
}

export interface OptimizationWeights {
  weightComputeThroughput: number;
  weightEnergyCostMin: number;
  weightCarbonReduction: number;
  weightThermalSafety: number;
  weightBatteryPreservation: number;
}

export interface OptimizationConstraints {
  maxGridPowerMw: number;
  maxGpuJunctionTempC: number;
  minBessSocReservePct: number;
  maxChillerDeltaTC: number;
  strictSlaDeadlineEnforcement: boolean;
  allowWorkloadDeferral: boolean;
  enableDistrictHeatExport: boolean;
}

export interface OptimizationPlan {
  timestamp: string;
  executionMode: string;
  recommendedGridMw: number;
  bessActionKw: number;
  generatorDispatchKw: number;
  peakShavingMwUnlocked: number;
  chillerSetpointC: number;
  cduPumpSpeedPct: number;
  economizerEngagementPct: number;
  heatRecoveryMw: number;
  scheduledJobsCount: number;
  deferredJobsCount: number;
  activeGpusAllocated: number;
  totalPflopsAchieved: number;
  baselineHourlyCostUsd: number;
  optimizedHourlyCostUsd: number;
  hourlySavingsUsd: number;
  pueProjected: number;
  carbonSavedKgHr: number;
  marginImprovementPct: number;
}

export interface AnomalyAlert {
  alertId: string;
  timestamp: string;
  assetId: string;
  severity: 'Info' | 'Warning' | 'Critical';
  title: string;
  description: string;
  observedValue: number;
  baselineExpected: number;
  unit: string;
  economicImpactUsdHr: number;
  recommendedAction: string;
}

export interface MonteCarloSummary {
  simulationsCount: number;
  dailyEnergyCost: { p10: number; p50: number; p90: number; mean: number; stdDev: number };
  dailyRevenue: { p10: number; p50: number; p90: number; mean: number; stdDev: number };
  dailyNetMargin: { p10: number; p50: number; p90: number; mean: number; stdDev: number };
  pueDistribution: { p10: number; p50: number; p90: number };
  thermalExcursionProbabilityPct: number;
  unplannedDerateProbabilityPct: number;
  valueAtRisk95PctUsd: number;
  distributionHistogram: Array<{ binLabel: string; count: number; costRange: number }>;
}

export interface DcExpansionOption {
  expansionMw: number;
  activeGpusAdded: number;
  capexBreakdownUsd: {
    powerInfrastructure: number;
    coolingInfrastructure: number;
    civilAndBuilding: number;
    itAndGpuHardware: number;
    totalCapex: number;
  };
  annualMetricsUsd: {
    grossRevenue: number;
    energyCost: number;
    maintenanceOpex: number;
    netOperatingCashflow: number;
  };
  financialValuation: {
    npv10YearUsd: number;
    irrPct: number;
    paybackYears: number;
    costPerGpuHourUsd: number;
  };
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  badge: string;
  spotPriceModifier: number;
  ambientTempC: number;
  gridCarbonIntensity: number;
  workloadPressureMultiplier: number;
  coolingCapacityMultiplier: number;
  gridCurtailmentMw?: number;
}
