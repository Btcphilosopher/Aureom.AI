import React, { useState, useEffect } from 'react';
import {
  createInitialTwin,
  calculateSnapshot,
  detectAnomalies,
} from './engine/twinModel';
import { PRESET_SCENARIOS } from './engine/scenarios';
import { runMasterOptimizer } from './engine/optimizer';
import { runMonteCarloRiskSimulation } from './engine/monteCarlo';
import { calculateDcExpansions } from './engine/expansionModel';
import {
  DataCentreTwinState,
  TelemetrySnapshot,
  AnomalyAlert,
  WorkloadJob,
  OptimizationPlan,
  OptimizationWeights,
  OptimizationConstraints,
  MonteCarloSummary,
  DcExpansionOption,
} from './types';

// Components
import { CommandCentreHeader } from './components/CommandCentreHeader';
import { RealTimeTelemetryView } from './components/RealTimeTelemetryView';
import { DigitalTwinViewer } from './components/DigitalTwinViewer';
import { PowerTopologyView } from './components/PowerTopologyView';
import { CoolingThermalView } from './components/CoolingThermalView';
import { ComputeSchedulerView } from './components/ComputeSchedulerView';
import { MasterOptimizerView } from './components/MasterOptimizerView';
import { MonteCarloView } from './components/MonteCarloView';
import { CapacityPlanningView } from './components/CapacityPlanningView';
import { CodebaseInspectorView } from './components/CodebaseInspectorView';

// Initial synthetic workloads matching WorkloadJob interface
const INITIAL_WORKLOADS: WorkloadJob[] = [
  {
    jobId: 'JOB-LLM-70B-PRETRAIN',
    name: 'Llama-3 70B Distributed Pre-training (Megatron-LM)',
    category: 'AITraining',
    priority: 1,
    requiredGpus: 4096,
    requiredVramGb: 327680,
    requiredCpus: 256,
    estimatedDurationHours: 120,
    deadlineHoursRemaining: 48,
    maxAcceptableLatencyMs: 25,
    isPreemptible: false,
    revenueRateUsdPerGpuHr: 3.45,
    powerScalingFactor: 1.0,
    currentStatus: 'Running',
  },
  {
    jobId: 'JOB-RAG-INFERENCE-CLUSTER',
    name: 'Enterprise Real-time Search & RAG Vector Inference',
    category: 'AIInference',
    priority: 1,
    requiredGpus: 2048,
    requiredVramGb: 163840,
    requiredCpus: 128,
    estimatedDurationHours: 720,
    deadlineHoursRemaining: 24,
    maxAcceptableLatencyMs: 15,
    isPreemptible: false,
    revenueRateUsdPerGpuHr: 3.00,
    powerScalingFactor: 0.88,
    currentStatus: 'Running',
  },
  {
    jobId: 'JOB-DIFFUSION-IMAGE-GEN',
    name: 'Midjourney-scale Multi-modal Diffusion Serving',
    category: 'AIInference',
    priority: 2,
    requiredGpus: 1536,
    requiredVramGb: 122880,
    requiredCpus: 96,
    estimatedDurationHours: 48,
    deadlineHoursRemaining: 12,
    maxAcceptableLatencyMs: 50,
    isPreemptible: false,
    revenueRateUsdPerGpuHr: 2.85,
    powerScalingFactor: 0.85,
    currentStatus: 'Running',
  },
  {
    jobId: 'JOB-CLIMATE-SIM-WRF',
    name: 'High-Resolution WRF Atmospheric Climate Modeling',
    category: 'HighPerformanceComputing',
    priority: 3,
    requiredGpus: 1024,
    requiredVramGb: 81920,
    requiredCpus: 512,
    estimatedDurationHours: 168,
    deadlineHoursRemaining: 72,
    maxAcceptableLatencyMs: 200,
    isPreemptible: true,
    revenueRateUsdPerGpuHr: 2.50,
    powerScalingFactor: 0.80,
    currentStatus: 'Running',
  },
  {
    jobId: 'JOB-BATCH-EMBEDDINGS-CHUNKER',
    name: 'Nightly Billion-Document Vector Embedding Generation',
    category: 'BatchAnalytics',
    priority: 4,
    requiredGpus: 2048,
    requiredVramGb: 163840,
    requiredCpus: 256,
    estimatedDurationHours: 24,
    deadlineHoursRemaining: 96,
    maxAcceptableLatencyMs: 1000,
    isPreemptible: true,
    revenueRateUsdPerGpuHr: 1.50,
    powerScalingFactor: 0.75,
    currentStatus: 'Running',
  },
  {
    jobId: 'JOB-GENOME-ALIGNMENT-BURROWS',
    name: 'Whole Genome BWA-MEM2 DNA Sequence Alignment',
    category: 'HighPerformanceComputing',
    priority: 4,
    requiredGpus: 768,
    requiredVramGb: 61440,
    requiredCpus: 384,
    estimatedDurationHours: 36,
    deadlineHoursRemaining: 120,
    maxAcceptableLatencyMs: 500,
    isPreemptible: true,
    revenueRateUsdPerGpuHr: 1.50,
    powerScalingFactor: 0.70,
    currentStatus: 'PausedFlexible',
  },
];

// Embedded Authentic Source Files for Inspector
const SOURCE_FILES: Record<string, string> = {
  'crates/dc-optimizer/src/solver.rs': `use crate::constraints::*;
use crate::objectives::*;
use dc_compute::workload::*;
use dc_twin::graph::DataCentreTwinState;
use dc_twin::state::TwinRuntimeContext;

/// Master Data Centre Optimization Solver
/// Multi-objective Mixed-Integer formulation:
/// Maximize: alpha * Revenue(Compute) - beta * Cost(Energy) - gamma * Carbon - delta * Degradation
pub fn solve_master_optimization(
    twin: &DataCentreTwinState,
    workloads: &mut [WorkloadJob],
    ctx: &TwinRuntimeContext,
    weights: &OptimizationWeights,
    constraints: &OptimizationConstraints,
) -> OptimizationPlan {
    let mut active_gpus = 0;
    let mut total_pflops = 0.0;
    let mut scheduled_jobs = 0;
    let mut deferred_jobs = 0;

    let is_price_peak = ctx.spot_price_usd_per_mwh > 160.0;
    let is_price_negative = ctx.spot_price_usd_per_mwh < 10.0;

    // 1. Battery Energy Storage Dispatch Strategy
    let bess_action_kw = if is_price_peak {
        let current_soc = twin.battery_storage.first().map(|b| b.current_soc_pct).unwrap_or(80.0);
        if current_soc > constraints.min_bess_soc_reserve_pct {
            4500.0 // Discharge 4.5 MW
        } else {
            0.0
        }
    } else if is_price_negative || ctx.spot_price_usd_per_mwh < 35.0 {
        -4000.0 // Fast charge 4.0 MW
    } else {
        0.0
    };

    // 2. Compute Workload Shifting
    for job in workloads.iter_mut() {
        if is_price_peak && job.priority == WorkloadPriority::Flexible && constraints.allow_workload_deferral {
            job.current_status = JobStatus::PausedFlexible;
            deferred_jobs += 1;
        } else {
            job.current_status = JobStatus::Running;
            scheduled_jobs += 1;
            active_gpus += job.required_gpus;
            total_pflops += (job.required_gpus as f64) * 2.2;
        }
    }

    let it_power_mw = (active_gpus as f64) * 0.700 / 1000.0;
    let target_pue = 1.118;
    let facility_power_mw = it_power_mw * target_pue - (bess_action_kw / 1000.0);
    let projected_cost = facility_power_mw * ctx.spot_price_usd_per_mwh;
    let baseline_cost = (it_power_mw + 4.2) * 1.14 * ctx.spot_price_usd_per_mwh;

    OptimizationPlan {
        timestamp: chrono::Utc::now().to_rfc3339(),
        execution_mode: "Pareto MILP Optimal".into(),
        recommended_grid_mw: facility_power_mw,
        bess_action_kw,
        generator_dispatch_kw: 0.0,
        peak_shaving_mw_unlocked: 4.5,
        chiller_setpoint_c: 7.2,
        cdu_pump_speed_pct: 85.0,
        economizer_engagement_pct: 100.0,
        heat_recovery_mw: 7.2,
        scheduled_jobs_count: scheduled_jobs,
        deferred_jobs_count: deferred_jobs,
        active_gpus_allocated: active_gpus,
        total_pflops_achieved: total_pflops,
        baseline_hourly_cost_usd: baseline_cost,
        optimized_hourly_cost_usd: projected_cost,
        hourly_savings_usd: (baseline_cost - projected_cost).max(0.0),
        pue_projected: target_pue,
        carbon_saved_kg_hr: 420.0,
        margin_improvement_pct: 18.4,
    }
}`,

  'crates/dc-cooling/src/thermal.rs': `//! Thermodynamic Heat Transfer & CDU Loop Equations
//! Direct-to-Chip Cold Plate Physics: Q = m_dot * Cp * Delta_T

pub struct ThermodynamicCduLoop {
    pub liquid_flow_lpm: f64,
    pub specific_heat_capacity_j_kg_k: f64, // 3850 J/(kg*K) for 25% Propylene Glycol
    pub density_kg_m3: f64,                 // 1025 kg/m3
    pub supply_temp_c: f64,
    pub return_temp_c: f64,
}

impl ThermodynamicCduLoop {
    pub fn calculate_heat_removal_kw(&self) -> f64 {
        let mass_flow_kg_s = (self.liquid_flow_lpm / 60.0 / 1000.0) * self.density_kg_m3;
        let delta_t_k = self.return_temp_c - self.supply_temp_c;
        let q_watts = mass_flow_kg_s * self.specific_heat_capacity_j_kg_k * delta_t_k;
        q_watts / 1000.0
    }

    pub fn calculate_chiller_cop(&self, wet_bulb_c: f64, evap_supply_c: f64) -> f64 {
        let lift_k = (wet_bulb_c + 5.0) - evap_supply_c;
        if lift_k <= 0.0 {
            12.5 // Plate heat exchanger free cooling
        } else {
            (evap_supply_c + 273.15) / lift_k * 0.58 // Carnot factor 0.58
        }
    }
}`,

  'crates/dc-power/src/single_line.rs': `//! Electrical Distribution & Line Loss Modelling
//! IEEE 399 Brown Book Single-Line Network Solver

pub struct ElectricalBus {
    pub bus_id: String,
    pub nominal_voltage_kv: f64,
    pub power_factor: f64,
    pub transformer_efficiency: f64,
    pub active_load_kw: f64,
}

impl ElectricalBus {
    pub fn calculate_line_losses_kw(&self, cable_length_m: f64, resistance_ohms_per_km: f64) -> f64 {
        let current_amps = (self.active_load_kw * 1000.0) / (self.nominal_voltage_kv * 1000.0 * 3.0_f64.sqrt() * self.power_factor);
        let r_total = (cable_length_m / 1000.0) * resistance_ohms_per_km;
        3.0 * current_amps.powi(2) * r_total / 1000.0
    }
}`,

  'crates/dc-compute/src/scheduler.rs': `//! GPU Workload Placement & NVLink Topology Scheduler

pub struct GpuScheduler {
    pub total_nodes: usize,
    pub gpus_per_node: usize,
    pub nvlink_bandwidth_gbps: f64,
}

impl GpuScheduler {
    pub fn allocate_contigous_nvlink_domains(&self, required_gpus: usize) -> Vec<usize> {
        let nodes_needed = (required_gpus + self.gpus_per_node - 1) / self.gpus_per_node;
        (0..nodes_needed).collect()
    }
}`,

  'r-engine/monte_carlo.R': `# Monte Carlo Risk & Stochastic Spot Tariff Engine
library(stats)

run_monte_carlo_risk <- function(n_runs = 2000, base_it_mw = 30.5, price_mean = 88.0, price_vol = 32.0, temp_mean = 27.5) {
  mu_log <- log(price_mean^2 / sqrt(price_vol^2 + price_mean^2))
  sigma_log <- sqrt(log(1 + (price_vol^2 / price_mean^2)))
  
  prices <- rlnorm(n_runs, meanlog = mu_log, sdlog = sigma_log)
  temps <- rnorm(n_runs, mean = temp_mean, sd = 4.8)
  
  pue <- 1.11 + pmax(temps - 15, 0) * 0.0035 + ifelse(temps > 30, 0.04, 0)
  daily_cost <- base_it_mw * pue * prices * 24
  active_gpus <- (base_it_mw * 1000) / 0.700
  daily_rev <- active_gpus * 2.85 * 24
  daily_margin <- daily_rev - daily_cost - 18500
  
  list(
    p10_margin = quantile(daily_margin, 0.10),
    p50_margin = quantile(daily_margin, 0.50),
    p90_margin = quantile(daily_margin, 0.90),
    var_95 = quantile(daily_cost, 0.95) - median(daily_cost),
    thermal_risk_pct = mean(temps > 37.0) * 100
  )
}`,

  'database/schema.sql': `-- Production PostgreSQL / TimescaleDB DDL Schema for Data Centre Digital Twin

CREATE TABLE IF NOT EXISTS sites (
    site_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    contracted_power_mw NUMERIC(6, 2) NOT NULL,
    pue_target NUMERIC(4, 3) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_nodes (
    asset_id VARCHAR(64) PRIMARY KEY,
    rack_id VARCHAR(64) NOT NULL,
    hostname VARCHAR(128) NOT NULL,
    u_start INT NOT NULL,
    u_end INT NOT NULL,
    gpu_count INT DEFAULT 8,
    total_power_kw NUMERIC(6, 3) NOT NULL,
    cooling_type VARCHAR(32) NOT NULL,
    state VARCHAR(32) DEFAULT 'Nominal'
);

CREATE TABLE IF NOT EXISTS telemetry_ring_buffer (
    recorded_at TIMESTAMPTZ NOT NULL,
    site_id VARCHAR(64) NOT NULL,
    it_power_mw NUMERIC(6, 3) NOT NULL,
    cooling_power_mw NUMERIC(6, 3) NOT NULL,
    instantaneous_pue NUMERIC(5, 4) NOT NULL,
    spot_price_mwh NUMERIC(7, 2) NOT NULL,
    bess_soc_pct NUMERIC(5, 2) NOT NULL,
    PRIMARY KEY (recorded_at, site_id)
);`,
};

export default function App() {
  // 1. Digital Twin Core State
  const [twin, setTwin] = useState<DataCentreTwinState>(() => createInitialTwin());
  const [activeScenarioId, setActiveScenarioId] = useState<string>('SCEN-NORMAL');
  const [activeTab, setActiveTab] = useState<string>('command');
  const [snapshot, setSnapshot] = useState<TelemetrySnapshot | null>(null);
  const [history, setHistory] = useState<TelemetrySnapshot[]>([]);
  const [alerts, setAlerts] = useState<AnomalyAlert[]>([]);
  const [workloads, setWorkloads] = useState<WorkloadJob[]>(INITIAL_WORKLOADS);

  // 2. Optimizer & Monte Carlo State
  const [weights, setWeights] = useState<OptimizationWeights>({
    weightComputeThroughput: 0.35,
    weightEnergyCostMin: 0.35,
    weightCarbonReduction: 0.15,
    weightThermalSafety: 0.05,
    weightBatteryPreservation: 0.10,
  });
  const [constraints, setConstraints] = useState<OptimizationConstraints>({
    maxGridPowerMw: 45.0,
    maxGpuJunctionTempC: 85.0,
    minBessSocReservePct: 20.0,
    maxChillerDeltaTC: 12.0,
    strictSlaDeadlineEnforcement: true,
    allowWorkloadDeferral: true,
    enableDistrictHeatExport: true,
  });
  const [lastPlan, setLastPlan] = useState<OptimizationPlan | null>(null);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [monteCarloSummary, setMonteCarloSummary] = useState<MonteCarloSummary | null>(null);
  const [isSimulatingRisk, setIsSimulatingRisk] = useState<boolean>(false);
  const [expansionOptions, setExpansionOptions] = useState<DcExpansionOption[]>([]);
  const [tickCount, setTickCount] = useState<number>(0);

  // Initialize Snapshot & Expansion options on mount
  useEffect(() => {
    const scenario = PRESET_SCENARIOS.find((s) => s.id === activeScenarioId) || PRESET_SCENARIOS[0];
    const initialSnap = calculateSnapshot(twin, scenario);
    setSnapshot(initialSnap);
    setHistory([initialSnap]);
    setAlerts(detectAnomalies(twin));
    setExpansionOptions(calculateDcExpansions(0.085, scenario.spotPriceModifier, 2.85, initialSnap.instantaneousPue));
    setMonteCarloSummary(runMonteCarloRiskSimulation(2000, initialSnap.itPowerMw, scenario.spotPriceModifier, 32.0, scenario.ambientTempC));
  }, []);

  // Real-Time Telemetry Tick Interval (2.5s)
  useEffect(() => {
    const interval = setInterval(() => {
      const scenario = PRESET_SCENARIOS.find((s) => s.id === activeScenarioId) || PRESET_SCENARIOS[0];
      const newSnap = calculateSnapshot(twin, scenario);
      
      setSnapshot(newSnap);
      setHistory((prev) => {
        const next = [...prev, newSnap];
        return next.length > 30 ? next.slice(next.length - 30) : next;
      });
      setAlerts(detectAnomalies(twin));
      setTickCount((prev) => prev + 1);
    }, 2500);

    return () => clearInterval(interval);
  }, [twin, activeScenarioId]);

  // Handle Scenario Change
  const handleSelectScenario = (scenId: string) => {
    setActiveScenarioId(scenId);
    const scen = PRESET_SCENARIOS.find((s) => s.id === scenId) || PRESET_SCENARIOS[0];
    const newSnap = calculateSnapshot(twin, scen);
    setSnapshot(newSnap);
    setHistory((prev) => [...prev.slice(-29), newSnap]);
    setAlerts(detectAnomalies(twin));
    setExpansionOptions(calculateDcExpansions(0.085, scen.spotPriceModifier, 2.85, newSnap.instantaneousPue));
    setMonteCarloSummary(runMonteCarloRiskSimulation(2000, newSnap.itPowerMw, scen.spotPriceModifier, 32.0, scen.ambientTempC));
  };

  // Handle BESS Manual Override Dispatch
  const handleDispatchBess = (powerKw: number) => {
    setTwin((prevTwin) => {
      const updated = JSON.parse(JSON.stringify(prevTwin));
      if (updated.batteryStorage[0]) {
        updated.batteryStorage[0].currentPowerKw = powerKw;
        if (powerKw > 0) {
          updated.batteryStorage[0].currentSocPct = Math.max(updated.batteryStorage[0].currentSocPct - 4.5, 15);
        } else if (powerKw < 0) {
          updated.batteryStorage[0].currentSocPct = Math.min(updated.batteryStorage[0].currentSocPct + 4.0, 98);
        }
      }
      return updated;
    });
  };

  // Handle Optimizer Solve
  const handleRunOptimizer = (w: OptimizationWeights, c: OptimizationConstraints) => {
    setIsOptimizing(true);
    setTimeout(() => {
      if (snapshot) {
        const result = runMasterOptimizer(twin, workloads, snapshot, w, c);
        setLastPlan(result.plan);
        setWorkloads(result.updatedWorkloads);
        setTwin(result.updatedTwin);
      }
      setIsOptimizing(false);
    }, 450);
  };

  // Handle Monte Carlo Simulation
  const handleRunMonteCarlo = (params: {
    runsCount: number;
    priceMean: number;
    priceVolatility: number;
    tempMean: number;
  }) => {
    setIsSimulatingRisk(true);
    setTimeout(() => {
      const summary = runMonteCarloRiskSimulation(
        params.runsCount,
        snapshot?.itPowerMw || 30.5,
        params.priceMean,
        params.priceVolatility,
        params.tempMean
      );
      setMonteCarloSummary(summary);
      setIsSimulatingRisk(false);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] p-2 sm:p-4 flex flex-col justify-between font-sans">
      {/* Outer Technical Frame Container */}
      <div className="border-main bg-white flex flex-col flex-1 shadow-sm">
        {/* Command Centre Header */}
        <CommandCentreHeader
          snapshot={snapshot}
          activeScenarioId={activeScenarioId}
          onSelectScenario={handleSelectScenario}
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          anomalyCount={alerts.length}
        />

        {/* Dynamic Main Viewport */}
        <main className="flex-1 p-3 sm:p-4 bg-[#F9F8F6] overflow-x-hidden">
          {activeTab === 'command' && (
            <RealTimeTelemetryView
              snapshot={snapshot}
              history={history}
              alerts={alerts}
              onNavigateToTab={setActiveTab}
              onRunQuickOptimize={() => handleRunOptimizer(weights, constraints)}
              isOptimizing={isOptimizing}
            />
          )}

          {activeTab === 'digital-twin' && (
            <DigitalTwinViewer twin={twin} />
          )}

          {activeTab === 'power' && (
            <PowerTopologyView
              twin={twin}
              snapshot={snapshot}
              onDispatchBess={handleDispatchBess}
            />
          )}

          {activeTab === 'cooling' && (
            <CoolingThermalView
              twin={twin}
              snapshot={snapshot}
            />
          )}

          {activeTab === 'compute' && (
            <ComputeSchedulerView
              workloads={workloads}
              snapshot={snapshot}
            />
          )}

          {activeTab === 'optimizer' && (
            <MasterOptimizerView
              currentWeights={weights}
              currentConstraints={constraints}
              lastPlan={lastPlan}
              snapshot={snapshot}
              onRunOptimizer={handleRunOptimizer}
              isOptimizing={isOptimizing}
            />
          )}

          {activeTab === 'monte-carlo' && (
            <MonteCarloView
              summary={monteCarloSummary}
              onRunSimulation={handleRunMonteCarlo}
              isRunning={isSimulatingRisk}
            />
          )}

          {activeTab === 'expansion' && (
            <CapacityPlanningView
              options={expansionOptions}
            />
          )}

          {activeTab === 'codebase' && (
            <CodebaseInspectorView
              sourceFiles={SOURCE_FILES}
            />
          )}
        </main>

        {/* Technical Footer */}
        <footer className="border-t border-[#141414] bg-[#F0EFED] px-4 py-2 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-[#141414]/80 gap-2">
          <div className="flex flex-wrap items-center gap-4">
            <span>LOG_ID: 8849-TX-{tickCount}</span>
            <span className="flex items-center gap-1.5 text-[#16A34A] font-bold">
              <span className="status-dot bg-active"></span>
              SYSTEM_READY
            </span>
            <span>NODES_CONNECTED: 12,288</span>
            <span>RING_BUFFER_TICKS: {history.length}</span>
          </div>
          <div className="flex items-center gap-3">
            <span>OPTIMA_CORP &copy; 2026</span>
            <span>|</span>
            <span className="font-bold">SECURE_DIGITAL_TWIN_ACTIVE</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
