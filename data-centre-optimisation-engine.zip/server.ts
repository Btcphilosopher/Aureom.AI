import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import {
  createInitialTwin,
  createInitialWorkloadQueue,
  computeTelemetrySnapshot,
  detectAnomalies,
} from './src/engine/twinModel.ts';
import { runMasterOptimizer } from './src/engine/optimizer.ts';
import { runMonteCarloRiskSimulation } from './src/engine/monteCarlo.ts';
import { calculateDcExpansions } from './src/engine/expansionModel.ts';
import { PRESET_SCENARIOS } from './src/engine/scenarios.ts';
import {
  DataCentreTwinState,
  OptimizationConstraints,
  OptimizationWeights,
  TelemetrySnapshot,
  WorkloadJob,
} from './src/types/index.ts';

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // In-memory persistent state
  let currentTwin: DataCentreTwinState = createInitialTwin();
  let currentWorkloads: WorkloadJob[] = createInitialWorkloadQueue();
  let currentScenario = PRESET_SCENARIOS[0];
  let manualBessKw = 0;
  let currentWeights: OptimizationWeights = {
    weightComputeThroughput: 0.40,
    weightEnergyCostMin: 0.30,
    weightCarbonReduction: 0.15,
    weightThermalSafety: 0.10,
    weightBatteryPreservation: 0.05,
  };
  let currentConstraints: OptimizationConstraints = {
    maxGridPowerMw: 45.0,
    maxGpuJunctionTempC: 78.0,
    minBessSocReservePct: 20.0,
    maxChillerDeltaTC: 6.5,
    strictSlaDeadlineEnforcement: true,
    allowWorkloadDeferral: true,
    enableDistrictHeatExport: true,
  };

  // Historical telemetry ring buffer (last 30 ticks)
  const telemetryHistory: TelemetrySnapshot[] = [];

  // Seed history
  for (let i = 29; i >= 0; i--) {
    const historicalTime = new Date(Date.now() - i * 3000).toISOString();
    const snap = computeTelemetrySnapshot(
      currentTwin,
      currentScenario.spotPriceModifier + (Math.random() * 6 - 3),
      currentScenario.ambientTempC + (Math.random() * 1.5 - 0.75),
      currentScenario.gridCarbonIntensity,
      manualBessKw
    );
    snap.timestamp = historicalTime;
    telemetryHistory.push(snap);
  }

  // Simulation tick loop (every 2.5s)
  setInterval(() => {
    // Add micro-fluctuations
    const priceJitter = (Math.random() - 0.5) * 4.0;
    const tempJitter = (Math.random() - 0.5) * 0.4;
    const currentPrice = Math.max(currentScenario.spotPriceModifier + priceJitter, 5.0);
    const currentTemp = currentScenario.ambientTempC + tempJitter;

    // Jitter rack temperatures slightly
    currentTwin.rooms.forEach((room) => {
      room.rows.forEach((row) => {
        row.racks.forEach((rack) => {
          rack.inletAirTempC += (Math.random() - 0.5) * 0.2;
          rack.inletAirTempC = Math.max(Math.min(rack.inletAirTempC, 34.0), 19.0);
        });
      });
    });

    const newSnapshot = computeTelemetrySnapshot(
      currentTwin,
      currentPrice,
      currentTemp,
      currentScenario.gridCarbonIntensity,
      manualBessKw,
      currentScenario.gridCurtailmentMw
        ? `Grid Substation Curtailment Limit (${currentScenario.gridCurtailmentMw} MW)`
        : undefined
    );

    telemetryHistory.push(newSnapshot);
    if (telemetryHistory.length > 40) {
      telemetryHistory.shift();
    }
  }, 2500);

  // -------------------------------------------------------------
  // API Routes
  // -------------------------------------------------------------
  app.get('/api/health', (req, res) => {
    res.json({ status: 'healthy', timestamp: new Date().toISOString() });
  });

  app.get('/api/twin', (req, res) => {
    res.json({
      twin: currentTwin,
      scenario: currentScenario,
      weights: currentWeights,
      constraints: currentConstraints,
    });
  });

  app.get('/api/telemetry/live', (req, res) => {
    const latest = telemetryHistory[telemetryHistory.length - 1];
    res.json({
      latest,
      history: telemetryHistory,
    });
  });

  app.get('/api/anomalies', (req, res) => {
    const alerts = detectAnomalies(currentTwin);
    res.json({ alerts });
  });

  app.get('/api/workloads', (req, res) => {
    res.json({ workloads: currentWorkloads });
  });

  app.post('/api/optimize', (req, res) => {
    const { weights, constraints } = req.body;
    if (weights) currentWeights = weights;
    if (constraints) currentConstraints = constraints;

    const latest = telemetryHistory[telemetryHistory.length - 1];
    const result = runMasterOptimizer(
      currentTwin,
      currentWorkloads,
      latest,
      currentWeights,
      currentConstraints
    );

    currentWorkloads = result.updatedWorkloads;
    currentTwin = result.updatedTwin;
    manualBessKw = result.plan.bessActionKw;

    res.json({
      plan: result.plan,
      workloads: currentWorkloads,
      twin: currentTwin,
    });
  });

  app.post('/api/monte-carlo', (req, res) => {
    const { runsCount = 2000, priceMean = 88.0, priceVolatility = 32.0, tempMean = 27.5 } = req.body;
    const latest = telemetryHistory[telemetryHistory.length - 1];
    const summary = runMonteCarloRiskSimulation(
      runsCount,
      latest.itPowerMw,
      priceMean,
      priceVolatility,
      tempMean
    );
    res.json(summary);
  });

  app.get('/api/expansion', (req, res) => {
    const options = calculateDcExpansions();
    res.json({ options });
  });

  app.get('/api/scenarios', (req, res) => {
    res.json({ scenarios: PRESET_SCENARIOS, activeId: currentScenario.id });
  });

  app.post('/api/scenario/:id', (req, res) => {
    const scenario = PRESET_SCENARIOS.find((s) => s.id === req.params.id);
    if (!scenario) {
      res.status(404).json({ error: 'Scenario not found' });
      return;
    }
    currentScenario = scenario;

    // Reset twin conditions based on scenario
    currentTwin = createInitialTwin();
    if (scenario.id === 'SCEN-HEATWAVE') {
      currentTwin.rooms.forEach((r) =>
        r.rows.forEach((row) =>
          row.racks.forEach((rack) => {
            rack.inletAirTempC += 5.5;
          })
        )
      );
      currentTwin.chillers.forEach((c) => {
        c.cop = 4.8;
      });
    }

    res.json({ success: true, activeScenario: currentScenario });
  });

  app.post('/api/bess/dispatch', (req, res) => {
    const { powerKw } = req.body;
    manualBessKw = Number(powerKw) || 0;
    if (currentTwin.batteryStorage[0]) {
      currentTwin.batteryStorage[0].currentPowerKw = manualBessKw;
    }
    res.json({ success: true, bessPowerKw: manualBessKw });
  });

  app.get('/api/source-code', (req, res) => {
    // Read and return the core workspace source files for in-app code inspector
    try {
      const files: Record<string, string> = {
        'Cargo.toml': fs.readFileSync('./crates/Cargo.toml', 'utf8'),
        'crates/dc-core/src/types.rs': fs.readFileSync('./crates/dc-core/src/types.rs', 'utf8'),
        'crates/dc-core/src/asset.rs': fs.readFileSync('./crates/dc-core/src/asset.rs', 'utf8'),
        'crates/dc-power/src/electrical.rs': fs.readFileSync('./crates/dc-power/src/electrical.rs', 'utf8'),
        'crates/dc-power/src/battery.rs': fs.readFileSync('./crates/dc-power/src/battery.rs', 'utf8'),
        'crates/dc-cooling/src/thermal_model.rs': fs.readFileSync('./crates/dc-cooling/src/thermal_model.rs', 'utf8'),
        'crates/dc-cooling/src/chiller.rs': fs.readFileSync('./crates/dc-cooling/src/chiller.rs', 'utf8'),
        'crates/dc-cooling/src/liquid_loop.rs': fs.readFileSync('./crates/dc-cooling/src/liquid_loop.rs', 'utf8'),
        'crates/dc-cooling/src/heat_recovery.rs': fs.readFileSync('./crates/dc-cooling/src/heat_recovery.rs', 'utf8'),
        'crates/dc-compute/src/scheduler.rs': fs.readFileSync('./crates/dc-compute/src/scheduler.rs', 'utf8'),
        'crates/dc-compute/src/gpu_cluster.rs': fs.readFileSync('./crates/dc-compute/src/gpu_cluster.rs', 'utf8'),
        'crates/dc-optimizer/src/solver.rs': fs.readFileSync('./crates/dc-optimizer/src/solver.rs', 'utf8'),
        'crates/dc-optimizer/src/workload_shifting.rs': fs.readFileSync('./crates/dc-optimizer/src/workload_shifting.rs', 'utf8'),
        'crates/dc-engine-cli/src/main.rs': fs.readFileSync('./crates/dc-engine-cli/src/main.rs', 'utf8'),
        'r-engine/forecasting.R': fs.readFileSync('./r-engine/forecasting.R', 'utf8'),
        'r-engine/monte_carlo.R': fs.readFileSync('./r-engine/monte_carlo.R', 'utf8'),
        'r-engine/economics.R': fs.readFileSync('./r-engine/economics.R', 'utf8'),
        'r-engine/interface.R': fs.readFileSync('./r-engine/interface.R', 'utf8'),
        'database/schema.sql': fs.readFileSync('./database/schema.sql', 'utf8'),
      };
      res.json({ files });
    } catch (err) {
      res.status(500).json({ error: 'Failed to read source files', details: String(err) });
    }
  });

  // -------------------------------------------------------------
  // Vite Integration
  // -------------------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Data Centre Optimisation Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
