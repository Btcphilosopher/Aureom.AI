/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capability, SystemModule, MetricSummary, TechnologyItem } from "./types";

export const CAPABILITIES: Capability[] = [
  {
    id: "ai-eng",
    title: "AI Software Engineering Systems",
    area: "AI Systems",
    description: "Sovereign code generation agents engineered specifically for transaction safety. We design autonomous agent swarms that write, test, and audit transaction-level financial code prior to execution.",
    details: [
      "Rigorous static verification & invariant checks",
      "Dynamic multi-agent unit test synthesis",
      "Automatic legacy system migration adapters",
      "Formal verification outputs for compliance compliance"
    ]
  },
  {
    id: "fin-infra",
    title: "Fintech Infrastructure Platforms",
    area: "Fintech Infrastructure",
    description: "Enterprise-grade core banking and trading rails engineered for 99.999% uptime. Optimized structures for zero-allocation memory pools, real-time double-entry ledgers, and atomic multi-entity settlements.",
    details: [
      "Sub-millisecond ledger replication over Raft consensus",
      "Multi-currency liquidity routing topologies",
      "Sovereign ISO 20022 messaging compatibility",
      "Atomic transactional guarantees under state partition"
    ]
  },
  {
    id: "risk-model",
    title: "Stochastic Danger & Risk Engines",
    area: "Risk Engines",
    description: "High-dimensional simulation systems operating in real-time. Compute dynamic Margin, Value-at-Risk (VaR), and extreme stress-scenarios instantly on live market conditions.",
    details: [
      "Vectorized parallel stochastic calculus solvers",
      "Dynamic correlation matrix updates with AI adjustment",
      "Synthetic shock generator simulating historical crises",
      "Automated liquidity defense triggers"
    ]
  },
  {
    id: "data-pipe",
    title: "Event-Driven Data Structures",
    area: "Fintech Infrastructure",
    description: "Low-overhead stream ingestion networks built for volatile order-books. Processes multiple parallel feeds of raw UDP multicast ticks with absolute order consistency.",
    details: [
      "Zero-copy serialization with flatbuffers / SBE",
      "Stateful time-series interpolation engines",
      "Anomaly isolation using local embedding pipelines",
      "Comprehensive telemetry tracking & diagnostic logs"
    ]
  }
];

export const SYSTEM_MODULES: SystemModule[] = [
  {
    id: "pricer-module",
    name: "Aureom Asset Pricer (AAP-4)",
    tagline: "Ultra-low latency derivatives and dynamic spread computation module.",
    description: "A secure pricing daemon configured to generate deterministic fair-value curves. Built with C++ optimization wrappers and accessible via highly optimized gRPC bindings.",
    status: "Optimized",
    throughput: "850k requests / sec",
    latency: "< 12 microseconds",
    metrics: [
      { label: "Execution Precision", value: "99.9997%" },
      { label: "Memory Overhead", value: "14.2 MB" },
      { label: "Jitter Standard Dev.", value: "0.4 μs" }
    ],
    configSnippet: `# AAP-4 Deployable Specification File
system_module:
  id: "pricing_mesh_aap4_01"
  runtime: "native-aot-v2"
  concurrency_model: "lock-free-ring"
  precision: "fp64_high_bounds"

parameters:
  volatility_surface:
    source: "aureom.feed.live"
    smoothing_factor: 0.125
  pricing_models:
    - code: "BLACK_SCHOLES_MERTON"
      jit_compiled: true
    - code: "MONTE_CARLO_LSV"
      paths: 100000

network:
  interface: "dpdk-eth0"
  binding: "0.0.0.0:8040"
  transport: "h2-grpc"`
  },
  {
    id: "risk-module",
    name: "Aureom Risk Evaluator (ARE-7)",
    tagline: "Dynamic margin calculator and collateral liquidation router.",
    description: "Evaluates margin requirements under historical shock overlays. Features real-time liquidation trigger queues and atomic collateral-call interfaces.",
    status: "Operational",
    throughput: "300k evaluations / sec",
    latency: "< 45 microseconds",
    metrics: [
      { label: "Simulated Scenarios", value: "12,000/eval" },
      { label: "Disaster Recovery", value: "Multi-Region" },
      { label: "Failsafe Outage Ring", value: "< 2ms Response" }
    ],
    configSnippet: `# ARE-7 Risk Controller Manifest
system_module:
  id: "danger_engine_are7_04"
  runtime: "vector-gpu-bound"
  device_class: "tensor-affinity"

parameters:
  margin_limits:
    maintenance_ratio: 0.08
    liquidation_ratio: 0.05
  stress_factors:
    rate_shocks: [-200, -100, 0, +100, +200]
    equity_shocks: [-0.30, -0.15, 0, +0.15]
  solver:
    engine: "finite-difference-cuda"
    tolerance: 1e-8

endpoints:
  ingest: "ipc:///tmp/are_raw.sock"
  triggers: "grpc://internal-alert-mesh"`
  },
  {
    id: "router-module",
    name: "Market Tick Ingest (AMT-1)",
    tagline: "Binary protocol parser and internal order-book replicator.",
    description: "Zero-copy ingest daemon supporting direct connection to exchange tick protocols with automated sequence gap repair capabilities.",
    status: "Optimized",
    throughput: "4.2M ticks / sec",
    latency: "< 3 microseconds",
    metrics: [
      { label: "SBE Decoding Rate", value: "100%" },
      { label: "Dropped Packets", value: "0" },
      { label: "Ring Buffer Capacity", value: "2^24 slots" }
    ],
    configSnippet: `# AMT-1 Protocol Parser Template
system_module:
  id: "tick_ingest_amt1_prod"
  runtime: "rust-tokio-bare"

protocol:
  standard: "nasdaq-itch-5.0"
  compression: "none"
  gap_fill:
    auto_retry: true
    retransmit_host: "itch-replay.aureom.net"

buffers:
  ring_capacity: 16777216
  numa_node: 1
  pre_allocate: true`
  }
];

export const TECHNOLOGIES: TechnologyItem[] = [
  {
    name: "Event-Driven IPC Mesh",
    category: "Distributed Networks",
    description: "Low-latency message passing framework acting as the neural bridge between our AI agents and the core pricing systems, utilizing Aeron and DPDK transport.",
    latencyProfile: "800ns raw latency"
  },
  {
    name: "Deterministic Kotlin Runtime",
    category: "Quant Computing & Runtimes",
    description: "A modified, GC-optimized Kotlin execution model configured to run zero-allocation operations, ensuring flat latency distributions even under heavy memory load.",
    latencyProfile: "No garbage collection jitters"
  },
  {
    name: "Stochastic CUDA Solvers",
    category: "Quant Computing & Runtimes",
    description: "Parallelized CUDA execution blocks optimized for high-dimensional path generation in Option pricing models and liquidity risk stress simulators.",
    latencyProfile: "6.4 TFLOPs of tensor solve"
  },
  {
    name: "Sovereign IA-Core Binding",
    category: "Distributed Networks",
    description: "Operating system levels core pin bindings preventing OS interrupts on system interfaces, maintaining hard real-time execution speeds.",
    latencyProfile: "Jitter free thread pinning"
  }
];

export const STATISTICS: MetricSummary[] = [
  {
    label: "Total System Flow Checked",
    value: "$4.12B+",
    subtext: "Audited & routed since operational inception"
  },
  {
    label: "Mean Core Tick Latency",
    value: "14.2 μs",
    subtext: "End-to-end pricing and risk feedback loop"
  },
  {
    label: "Sovereign Uptime Guarantee",
    value: "99.9995%",
    subtext: "Backed by strict transactional consistency"
  },
  {
    label: "Verified System Integrity",
    value: "Zero Failures",
    subtext: "In production order matching execution"
  }
];
