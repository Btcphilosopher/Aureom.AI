/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Capability {
  id: string;
  title: string;
  description: string;
  area: "AI Systems" | "Fintech Infrastructure" | "Risk Engines";
  details: string[];
}

export interface SystemModule {
  id: string;
  name: string;
  tagline: string;
  description: string;
  status: "Optimized" | "Operational" | "Staging";
  throughput: string;
  latency: string;
  metrics: { label: string; value: string }[];
  configSnippet: string;
}

export interface MetricSummary {
  label: string;
  value: string;
  subtext: string;
}

export interface TechnologyItem {
  name: string;
  category: "Distributed Networks" | "Quant Computing & Runtimes" | "Standards & Protocols";
  description: string;
  latencyProfile: string;
}

export interface LeadSubmission {
  name: string;
  email: string;
  company: string;
  rfpScope: string;
  interests: string[];
  message: string;
}
