/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { SYSTEM_MODULES } from "../data";
import { SystemModule } from "../types";
import { Code, Terminal, Server, Check, ArrowRight, Layers, Cpu } from "lucide-react";

export default function Modules() {
  const [activeTab, setActiveTab] = useState<Record<string, "spec" | "manifest">>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleTab = (moduleId: string, tab: "spec" | "manifest") => {
    setActiveTab((prev) => ({ ...prev, [moduleId]: tab }));
  };

  const copySnippet = (moduleId: string, snippet: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedId(moduleId);
    setTimeout(() => {
      setCopiedId(null);
    }, 2000);
  };

  return (
    <section id="modules" className="py-24 bg-[#08090a] tech-dots relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#E2C374]/20 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-16">
          <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-3 text-left">
            03 // Operational Runtimes
          </p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-white mb-4">
            Deployable System Modules
          </h2>
          <p className="text-sm text-zinc-400 font-light leading-relaxed">
            Our infrastructure components are compiled as isolated, high-performance static binaries. Review performance profiles and click "Deployment Manifest" to inspect configuration parameters.
          </p>
        </div>

        {/* Modules Stack */}
        <div className="space-y-12">
          {SYSTEM_MODULES.map((module: SystemModule, idx) => {
            const currentTab = activeTab[module.id] || "spec";
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#131518]/35 border border-white/5 rounded p-6 md:p-8 relative"
              >
                {/* Visual Accent Pin */}
                <div className="absolute top-0 left-8 w-12 h-[1px] bg-gradient-to-r from-[#E2C374] to-transparent" />

                {/* Left Side: Module specs & details */}
                <div className="lg:col-span-6 flex flex-col justify-between">
                  <div className="space-y-6">
                    {/* Header bar */}
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/5 pb-4">
                      <div>
                        <span className="text-[9px] font-mono uppercase tracking-widest text-[#E2C374] font-bold">
                          System Artifact {module.id.toUpperCase()}
                        </span>
                        <h3 className="text-xl md:text-2xl font-display font-semibold text-white mt-1">
                          {module.name}
                        </h3>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-wider uppercase border border-white/10 ${
                          module.status === "Optimized"
                            ? "bg-emerald-500/10 text-emerald-400"
                            : "bg-[#E2C374]/15 text-[#E2C374]"
                        }`}>
                          ● {module.status}
                        </span>
                      </div>
                    </div>

                    <p className="text-sm font-light text-zinc-300 leading-relaxed">
                      {module.tagline}
                    </p>

                    <p className="text-xs font-light text-zinc-400 leading-relaxed font-sans">
                      {module.description}
                    </p>

                    {/* Performance metrics breakdown */}
                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/5">
                      {module.metrics.map((metric, mIdx) => (
                        <div key={mIdx} className="space-y-1">
                          <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest leading-none">
                            {metric.label}
                          </p>
                          <p className="text-sm font-semibold text-white font-mono">
                            {metric.value}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Operational Controls */}
                  <div className="flex items-center space-x-4 pt-8">
                    <button
                      onClick={() => toggleTab(module.id, "spec")}
                      className={`px-3 py-1.5 font-mono text-xs rounded transition-all duration-200 cursor-pointer ${
                        currentTab === "spec"
                          ? "bg-white/5 text-white border border-white/10"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      Infrastructure Specs
                    </button>
                    <button
                      onClick={() => toggleTab(module.id, "manifest")}
                      className={`px-3 py-1.5 font-mono text-xs rounded transition-all duration-200 cursor-pointer ${
                        currentTab === "manifest"
                          ? "bg-white/5 text-white border border-white/10"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      Deployment Manifest (.yaml)
                    </button>
                  </div>
                </div>

                {/* Right Side: Interactive Shell Terminal / Config viewer */}
                <div className="lg:col-span-6 border border-white/5 rounded-sm bg-[#08090a]/90 relative flex flex-col min-h-[320px]">
                  {/* Terminal Header */}
                  <div className="flex items-center justify-between px-4 py-3 bg-[#0c0d10] border-b border-white/5 font-mono text-[10px]">
                    <div className="flex items-center space-x-2">
                      <Terminal className="w-3.5 h-3.5 text-[#E2C374]" />
                      <span className="text-zinc-400 select-none">
                        {currentTab === "manifest" ? `${module.id}.config.yaml` : `${module.id}_runtime_registers.json`}
                      </span>
                    </div>
                    {currentTab === "manifest" && (
                      <button
                        onClick={() => copySnippet(module.id, module.configSnippet)}
                        className="px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/5 text-[#E2C374] hover:text-white transition-all text-[9px] rounded flex items-center space-x-1 cursor-pointer focus:outline-none"
                      >
                        {copiedId === module.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Code className="w-3 h-3" />
                            <span>Copy Config</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {/* Terminal Body */}
                  <div className="flex-1 p-5 font-mono text-[11px] overflow-auto select-text leading-relaxed">
                    <AnimatePresence mode="wait">
                      {currentTab === "manifest" ? (
                        <motion.pre
                          key="manifest"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="text-[#ebd59a]"
                        >
                          <code>{module.configSnippet}</code>
                        </motion.pre>
                      ) : (
                        <motion.div
                          key="spec"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="space-y-4 text-zinc-400"
                        >
                          <div className="flex justify-between items-center bg-[#131518]/20 p-2 rounded border border-white/5">
                            <span className="text-zinc-500">Execution Kernel Protocol:</span>
                            <span className="text-[#4CA5FF] font-bold">Native AOT Static Compile</span>
                          </div>
                          
                          <div className="space-y-2">
                            <span className="text-[#E2C374] block font-semibold uppercase tracking-wider text-[9px]">
                              // CPU REGISTER ALLOCATION PROFILE
                            </span>
                            <div className="grid grid-cols-2 gap-4 text-xs font-sans text-zinc-300">
                              <div className="bg-[#131518]/10 p-2 border border-white/5 rounded">
                                <p className="text-[10px] font-mono text-zinc-500 uppercase">Core Binding ID</p>
                                <p className="font-mono text-white font-bold">Node-00{idx + 1}</p>
                              </div>
                              <div className="bg-[#131518]/10 p-2 border border-white/5 rounded">
                                <p className="text-[10px] font-mono text-zinc-500 uppercase">Aeron Channel ID</p>
                                <p className="font-mono text-[#4CA5FF] font-bold">10098:A7</p>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <span className="text-emerald-400 block font-semibold uppercase tracking-wider text-[9px]">
                              // ATOMIC HARDWARE CAPABILITIES
                            </span>
                            <div className="space-y-1.5 font-mono text-[10px] text-zinc-500">
                              <div className="flex justify-between">
                                <span>Throughput Bandwidth Invariant</span>
                                <span className="text-white font-bold">{module.throughput}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Mean Target Latency Over Partition</span>
                                <span className="text-[#4CA5FF] font-bold">{module.latency}</span>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
