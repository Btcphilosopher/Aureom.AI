/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ArrowUpRight, Cpu, ShieldCheck } from "lucide-react";

interface HeaderProps {
  onContactClick: () => void;
}

export default function Header({ onContactClick }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const navLinks = [
    { label: "Systems", id: "capabilities" },
    { label: "Interactive Architecture", id: "topology" },
    { label: "Deployable Modules", id: "modules" },
    { label: "Technology Stack", id: "technology" },
    { label: "Institutional Mission", id: "about" }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
        isScrolled
          ? "bg-[#08090a]/90 backdrop-blur-md border-white/5 py-3"
          : "bg-transparent border-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex items-center space-x-3 group cursor-pointer text-left focus:outline-none"
        >
          <div className="relative w-8 h-8 flex items-center justify-center rounded border border-[#E2C374]/30 bg-gradient-to-br from-[#131518] to-[#08090a] group-hover:border-[#E2C374] transition-colors duration-300">
            <span className="text-sm font-mono text-[#E2C374] font-bold">A</span>
            <div className="absolute inset-0 bg-[#E2C374]/10 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-display text-lg font-bold tracking-tight text-white">
                Aureom
              </span>
              <span className="text-[#E2C374] font-mono text-sm font-semibold tracking-widest">
                .AI
              </span>
            </div>
            <p className="text-[9px] font-mono tracking-widest text-[#8a8a93] uppercase font-medium leading-none">
              Systems & Infra
            </p>
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollToSection(link.id)}
              className="text-xs font-mono font-medium tracking-wide text-[#b5b5c0] hover:text-[#E2C374] transition-colors duration-200 cursor-pointer focus:outline-none"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Header Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          <div className="flex items-center space-x-1.5 px-3 py-1 bg-[#131518] rounded-full border border-white/5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E2C374]/60 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#E2C374]"></span>
            </span>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#b5b5c0]">
              Mesh-v4.2 Live
            </span>
          </div>
          <button
            onClick={onContactClick}
            className="flex items-center space-x-1.5 bg-[#E2C374] hover:bg-[#ebd59a] text-black text-xs font-mono font-bold px-4 py-2 rounded-sm transition-all duration-300 hover:shadow-[0_0_15px_-3px_rgba(226,193,116,0.3)] shadow-md cursor-pointer"
          >
            <span>Request Protocol Access</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex lg:hidden items-center space-x-3">
          <span className="px-2 py-0.5 bg-[#131518] rounded border border-white/5 text-[9px] font-mono text-[#E2C374]">
            LIVE
          </span>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/5 rounded-md focus:outline-none cursor-pointer"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Sliding Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 right-0 bg-[#08090a] border-b border-white/5 flex flex-col py-6 px-6 space-y-6 shadow-2xl lg:hidden"
          >
            {/* Nav connections */}
            <div className="flex flex-col space-y-4">
              <p className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 font-semibold">
                Sovereign Directory
              </p>
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left text-sm font-semibold tracking-wide text-zinc-300 hover:text-[#E2C374] transition-colors py-1 cursor-pointer focus:outline-none"
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* Ingress status */}
            <div className="pt-4 border-t border-white/5 flex flex-col space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-mono text-zinc-500">Node Ingress Status</span>
                <span className="text-xs font-mono text-[#E2C374] font-semibold flex items-center space-x-1">
                  <div className="w-1.5 h-1.5 bg-[#E2C374] rounded-full animate-pulse mr-1" />
                  Active Cluster 01
                </span>
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onContactClick();
                }}
                className="w-full flex justify-center items-center space-x-2 bg-gradient-to-r from-[#E2C374] to-[#c7a452] text-black text-xs font-mono font-bold py-3 rounded-sm"
              >
                <span>Request Protocol Access</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
