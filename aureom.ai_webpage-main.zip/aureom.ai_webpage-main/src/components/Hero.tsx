/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ArrowDown, Flame, CornerDownRight, Database, Code, Shield } from "lucide-react";
import { MetricSummary } from "../types";
import { STATISTICS } from "../data";

interface HeroProps {
  onContactClick: () => void;
  onExploreClick: () => void;
}

export default function Hero({ onContactClick, onExploreClick }: HeroProps) {
  return (
    <section className="relative min-h-screen flex flex-col justify-between pt-32 pb-16 overflow-hidden tech-grid">
      {/* Visual Ambient Glows - Elegant subtle gradients, no massive obnoxious shapes */}
      <div className="absolute top-[20%] left-[10%] w-[350px] h-[350px] rounded-full bg-[#E2C374]/5 blur-[120px] animate-pulse-glow" />
      <div className="absolute bottom-[15%] right-[5%] w-[450px] h-[450px] rounded-full bg-[#4CA5FF]/3 blur-[140px] animate-pulse-glow" />

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-6 flex-1 flex flex-col justify-center items-start w-full relative z-10 my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 w-full items-center">
          
          {/* Hero Text Information */}
          <div className="lg:col-span-8 flex flex-col space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="flex items-center space-x-2 bg-[#131518] px-3.5 py-1.5 rounded-full border border-white/5 w-fit"
            >
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E2C374] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#E2C374]"></span>
              </span>
              <span className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase">
                Aureom.AI Institutional Ledger v4.2
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
              className="text-4xl md:text-6xl lg:text-7xl font-display font-semibold tracking-tight text-white leading-[1.05]"
            >
              Financial infrastructure.
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-zinc-200 via-zinc-450 to-[#E2C374] drop-shadow-sm">
                AI systems.
              </span>
              <br />
              Built for scale.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
              className="text-[#a1a1aa] text-base md:text-lg max-w-2xl font-light leading-relaxed font-sans"
            >
              Aureom.AI engineers enterprise-grade software capabilities and deterministic automated intelligence. We bridge advanced, low-latency financial execution rails with verified multi-agent systems to ensure high-velocity system processing, institutional liquidity, and mathematical integrity.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="flex flex-wrap gap-4 pt-4"
            >
              <button
                onClick={onContactClick}
                className="bg-[#E2C374] hover:bg-[#ebd59a] text-black text-xs font-mono font-bold px-6 py-3.5 rounded-sm transition-all duration-300 hover:shadow-[0_0_20px_-3px_rgba(226,193,116,0.4)] cursor-pointer"
              >
                Inquire Access Protocol
              </button>
              <button
                onClick={onExploreClick}
                className="bg-transparent hover:bg-white/5 text-white border border-white/10 hover:border-white/30 text-xs font-mono font-bold px-6 py-3.5 rounded-sm transition-all duration-300 flex items-center space-x-2 cursor-pointer"
              >
                <span>Deployable Modules</span>
                <CornerDownRight className="w-3.5 h-3.5 text-[#E2C374]" />
              </button>
            </motion.div>
          </div>

          {/* Institutional Tech Visual Deck (No Slop, just ultra-clean structural lines) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="lg:col-span-4 hidden lg:flex flex-col border border-white/5 bg-[#0e1012]/80 rounded p-6 shadow-2xl relative"
          >
            <div className="absolute top-0 right-0 w-24 h-[1px] bg-gradient-to-l from-[#E2C374] to-transparent" />
            <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4">
              <div className="flex items-center space-x-2">
                <Code className="w-4 h-4 text-[#E2C374]" />
                <span className="font-mono text-xs uppercase tracking-wider text-white font-bold">
                  CORE_REPLICATOR_01
                </span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500">AUREOM OS v4</span>
            </div>

            {/* Spec lines */}
            <div className="space-y-4 font-mono text-xs text-zinc-300">
              <div className="p-3 bg-[#08090a] rounded border border-white/5 space-y-2">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Core Threads Bound</span>
                  <span className="text-white font-bold">16 CPU Cores / Isolated</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded overflow-hidden">
                  <div className="bg-[#E2C374] h-full w-[85%]" />
                </div>
              </div>

              <div className="p-3 bg-[#08090a] rounded border border-white/5 space-y-2">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Atomic SBE Parser</span>
                  <span className="text-[#4CA5FF] font-bold">DPDK Zero-Copy Mode</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded overflow-hidden">
                  <div className="bg-[#4CA5FF] h-full w-[95%]" />
                </div>
              </div>

              <div className="p-3 bg-[#08090a] rounded border border-white/5 space-y-2">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Static Verification Suite</span>
                  <span className="text-emerald-400 font-bold">Active / Strict</span>
                </div>
                <div className="flex items-center space-x-1.5 text-zinc-500 text-[10px] pt-1">
                  <Shield className="w-3 h-3 text-emerald-400" />
                  <span>Verified 82,900 unit variants prior to compile</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Grid statistics - Luxury Tech Row at Bottom */}
      <div className="border-t border-white/5 bg-[#08090a]/50 backdrop-blur-sm pt-8 pb-4">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {STATISTICS.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + idx * 0.1 }}
                className="flex flex-col"
              >
                <span className="text-2xl md:text-3xl font-display font-semibold tracking-tight text-white mb-1">
                  {stat.value}
                </span>
                <span className="text-xs font-mono font-medium tracking-wide text-[#E2C374] mb-1">
                  {stat.label}
                </span>
                <span className="text-xs text-zinc-400 font-light font-sans">
                  {stat.subtext}
                </span>
              </motion.div>
            ))}
          </div>

          {/* Smooth Scroll Indicator */}
          <div className="flex justify-center mt-12 mb-2">
            <button
              onClick={onExploreClick}
              className="flex items-center space-x-2 text-zinc-500 hover:text-[#E2C374] transition-colors font-mono text-[10px] tracking-widest uppercase cursor-pointer focus:outline-none"
            >
              <span>Audit Corporate Architecture</span>
              <ArrowDown className="w-3 h-3 animate-bounce" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
