/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Activity, ShieldCheck, Database, Cpu, HelpCircle, Network, ArrowRight } from "lucide-react";

interface NodeDetail {
  id: string;
  name: string;
  category: string;
  status: string;
  spec: string;
  metrics: string[];
}

export default function Topology() {
  const [selectedNode, setSelectedNode] = useState<string>("ingest");

  const nodes: Record<string, NodeDetail> = {
    ingest: {
      id: "ingest",
      name: "AMT-1 Ingest Daemon",
      category: "Network Interface Layer",
      status: "Optimized (DPDK Enabled)",
      spec: "Zero-copy UDP parsing of exchange multicast packets directly into kernel rings.",
      metrics: [
        "Throughput: 4.2M packets/sec",
        "HW Time-stamp jitter: < 0.2μs",
        "NUMA Node affinity: Pin-1",
        "Protocol codec: SBE v2.1"
      ]
    },
    buffer: {
      id: "buffer",
      name: "Sovereign Low-Latency Ring Buffer",
      category: "IPC & Queue Layer",
      status: "Lock-Free Ring Buffer",
      spec: "Thread-isolated circular buffer with sequence barriers preventing dirty cache fetches.",
      metrics: [
        "Depth capacity: 16.7M elements",
        "Wait strategy: Busy-Spin-Wait",
        "Average transfer hop: 80 nanoseconds",
        "L3 Cache optimization: Active"
      ]
    },
    pricer: {
      id: "pricer",
      name: "AAP-4 Asset Pricing Kernel",
      category: "Math & Quant Layer",
      status: "JIT CUDA Compiled",
      spec: "Stochastic pricing matrix resolver for multi-entity European and American derivative variants.",
      metrics: [
        "Evaluation cycle: 850k targets/sec",
        "Thread pool: 512 Vector Block CUDA",
        "Absolute mathematical precision: Float64",
        "Average volatility warp: 2.1ms"
      ]
    },
    danger: {
      id: "danger",
      name: "ARE-7 Risk Evaluator",
      category: "Risk Control Layer",
      status: "Operational Check",
      spec: "Computes portfolio Margin and extreme stress-scenarios (shocks) on concurrent balance sheets.",
      metrics: [
        "Concurrent stress matrices: 12,000 / sec",
        "Re-margining reaction trigger: < 45μs",
        "Risk metrics supported: VaR, Expected Shortfall (ES)",
        "Liquidation router: Auto-Armed"
      ]
    },
    auditor: {
      id: "auditor",
      name: "Autonomous Agent Audit Hub",
      category: "AI & Cognitive Verification",
      status: "Formal Verification Sovereign",
      spec: "Multi-agent swarm running automated formal proofs to verify that settlement transactions do not violate ledger invariants.",
      metrics: [
        "Proof generation speed: 180ms",
        "Synthesized unit assertions: 450 / block",
        "AI model logic constraint: Absolute strictness",
        "Incomplete proof veto rate: 100%"
      ]
    }
  };

  return (
    <section id="topology" className="py-24 bg-[#0e1012] tech-grid relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#E2C374]/15 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-16">
          <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-3">
            02 // Interactive System Topology
          </p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-white mb-4">
            Aureom Execution Grid Mesh
          </h2>
          <p className="text-sm text-zinc-400 font-light leading-relaxed">
            Examine our low-latency financial ledger processing loop. Click on any system sector node in the flowchart layout below to read active core telemetry and isolated execution layers.
          </p>
        </div>

        {/* Visual Map + Info Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* SVG Interactive Architecture Map (Responsive Layout) */}
          <div className="lg:col-span-7 bg-[#08090a]/80 border border-white/5 p-6 rounded relative min-h-[480px] flex flex-col justify-between">
            <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-6">
              <span className="font-mono text-[10px] tracking-wider text-zinc-500 uppercase font-semibold">
                Sovereign Flowchart Visualizer
              </span>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-mono text-[10px] text-zinc-400">Mesh Sync: Core Ready</span>
              </div>
            </div>

            {/* Simulated Vector / Graph Canvas */}
            <div className="flex-1 flex flex-col justify-around py-4">
              
              {/* Row 1 Ingest */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode("ingest")}
                  className={`w-52 p-3 font-mono text-xs border text-left rounded transition-all duration-300 relative group cursor-pointer ${
                    selectedNode === "ingest"
                      ? "border-[#E2C374] bg-[#E2C374]/5 gold-glow"
                      : "border-white/5 bg-[#131518]/40 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1.5">
                    <Network className={`w-3.5 h-3.5 ${selectedNode === "ingest" ? "text-[#E2C374]" : "text-zinc-500"}`} />
                    <span className="text-white font-bold">AMT-1 Ingest</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-zinc-500">Multicast UDP</span>
                    <span className="text-[#E2C374]">{selectedNode === "ingest" ? "PINNED" : "99.98%"}</span>
                  </div>
                </button>
              </div>

              {/* Arrow down */}
              <div className="flex justify-center text-zinc-700 py-1">
                <div className="w-[1px] h-6 bg-gradient-to-b from-[#E2C374]/40 to-[#4CA5FF]/40" />
              </div>

              {/* Row 2 Buffer */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode("buffer")}
                  className={`w-52 p-3 font-mono text-xs border text-left rounded transition-all duration-300 relative group cursor-pointer ${
                    selectedNode === "buffer"
                      ? "border-[#4CA5FF] bg-[#4CA5FF]/5 blue-glow"
                      : "border-white/5 bg-[#131518]/40 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1.5">
                    <Database className={`w-3.5 h-3.5 ${selectedNode === "buffer" ? "text-[#4CA5FF]" : "text-zinc-500"}`} />
                    <span className="text-white font-semibold">Low-Latency Ring</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-zinc-500">Atomic IPC</span>
                    <span className="text-[#4CA5FF]">80ns</span>
                  </div>
                </button>
              </div>

              {/* Arrow and path split */}
              <div className="flex justify-center max-w-sm mx-auto items-center py-1">
                <div className="w-[1px] h-6 bg-[#4CA5FF]/30" />
              </div>

              {/* Row 3 Math / Risk Parallel Split */}
              <div className="flex justify-center space-x-4 md:space-x-8">
                <button
                  onClick={() => setSelectedNode("pricer")}
                  className={`w-[155px] md:w-48 p-3 font-mono text-xs border text-left rounded transition-all duration-300 relative group cursor-pointer ${
                    selectedNode === "pricer"
                      ? "border-[#E2C374] bg-[#E2C374]/5 gold-glow"
                      : "border-white/5 bg-[#131518]/40 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center space-x-1.5 mb-1.5">
                    <Cpu className={`w-3.5 h-3.5 ${selectedNode === "pricer" ? "text-[#E2C374]" : "text-zinc-500"}`} />
                    <span className="text-white font-semibold">AAP-4 Pricing</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-zinc-500">CUDA JIT</span>
                    <span className="text-[#E2C374]">850k/s</span>
                  </div>
                </button>

                <button
                  onClick={() => setSelectedNode("danger")}
                  className={`w-[155px] md:w-48 p-3 font-mono text-xs border text-left rounded transition-all duration-300 relative group cursor-pointer ${
                    selectedNode === "danger"
                      ? "border-[#4CA5FF] bg-[#4CA5FF]/5 blue-glow"
                      : "border-white/5 bg-[#131518]/40 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center space-x-1.5 mb-1.5">
                    <Activity className={`w-3.5 h-3.5 ${selectedNode === "danger" ? "text-[#4CA5FF]" : "text-zinc-500"}`} />
                    <span className="text-white font-semibold">ARE-7 Risk Evaluator</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-zinc-500">Stress Engine</span>
                    <span className="text-[#4CA5FF]">&lt;45μs</span>
                  </div>
                </button>
              </div>

              {/* Arrow Converging down */}
              <div className="flex justify-center py-1">
                <div className="w-[1px] h-6 bg-gradient-to-b from-[#4CA5FF]/30 to-[#E2C374]/30" />
              </div>

              {/* Row 4 AI Formal Proof Auditor */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode("auditor")}
                  className={`w-52 p-3 font-mono text-xs border text-left rounded transition-all duration-300 relative group cursor-pointer ${
                    selectedNode === "auditor"
                      ? "border-[#E2C374] bg-[#E2C374]/5 gold-glow"
                      : "border-white/5 bg-[#131518]/40 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1.5">
                    <ShieldCheck className={`w-3.5 h-3.5 ${selectedNode === "auditor" ? "text-emerald-400" : "text-zinc-500"}`} />
                    <span className="text-white font-bold">Audit Agent swarm</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-zinc-500">Formal Prover</span>
                    <span className="text-emerald-400">Strict-Check</span>
                  </div>
                </button>
              </div>

            </div>

            <div className="border-t border-white/5 pt-4 flex justify-between items-center text-[10px] font-mono text-zinc-500">
              <span>* Flow direction indicates transactional execution priority</span>
              <span>Click element to inspect registers</span>
            </div>
          </div>

          {/* Core Register Inspector Pane */}
          <div className="lg:col-span-5 h-full">
            <div className="border border-white/5 bg-[#08090a] p-6 rounded h-full relative flex flex-col justify-between">
              
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedNode}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-6"
                >
                  {/* Category & Status */}
                  <div className="flex items-center justify-between border-b border-white/5 pb-4">
                    <div>
                      <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-1">
                        System Register Logs
                      </p>
                      <h4 className="text-sm font-mono font-bold text-white uppercase tracking-wider">
                        {nodes[selectedNode].name}
                      </h4>
                    </div>
                    <span className="px-2 py-0.5 bg-white/5 border border-white/5 text-[9px] font-mono rounded text-[#E2C374]">
                      ACTIVE
                    </span>
                  </div>

                  {/* Core Details */}
                  <div className="space-y-2">
                    <p className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest font-semibold">
                      Layer Category
                    </p>
                    <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                      {nodes[selectedNode].category}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest font-semibold">
                      System Specifications
                    </p>
                    <p className="text-xs text-zinc-400 font-sans font-light leading-relaxed">
                      {nodes[selectedNode].spec}
                    </p>
                  </div>

                  {/* Active Hardware Telemetry Details */}
                  <div className="space-y-3">
                    <p className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest font-semibold">
                      Isolated Registers Telemetry
                    </p>
                    <div className="grid grid-cols-1 gap-2 bg-[#0e1012] border border-white/5 p-4 rounded font-mono text-xs">
                      {nodes[selectedNode].metrics.map((m, idx) => (
                        <div key={idx} className="flex justify-between items-center text-zinc-300">
                          <span className="text-zinc-500 flex items-center">
                            <span className="font-semibold text-[#E2C374] mr-2">&gt;</span>
                            {m.split(":")[0]}
                          </span>
                          <span className="font-semibold text-white">{m.split(":")[1]}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              <div className="pt-6 border-t border-white/5 mt-6">
                <div className="p-4 bg-orange-400/5 rounded border border-orange-400/10 flex items-start space-x-3 text-xs">
                  <ShieldCheck className="w-4 h-4 text-[#E2C374] flex-shrink-0 mt-0.5" />
                  <div className="space-y-1 font-sans">
                    <p className="text-[#E2C374] font-mono font-semibold">Immutable Real-Time Guarantee</p>
                    <p className="text-zinc-400 font-light leading-relaxed">
                      Any thread jitter exceeding 1 microsecond triggers auto-isolation. The grid re-orders message priorities automatically without losing execution state.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
