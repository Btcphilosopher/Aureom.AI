/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ShieldCheck, Target, FileText, Landmark, Cpu } from "lucide-react";

export default function About() {
  const values = [
    {
      title: "Systemic Reliability",
      desc: "We prioritize deterministic, formal proofs over stochastic heuristics. Every autonomous AI agent pipeline is governed by hard limits, strict validation, and transaction audit boundaries."
    },
    {
      title: "Real-World Economic Synthesis",
      desc: "Our solutions don't sit in an isolated research vacuum. We bridge the frontier of machine intelligence with real-world, high-volume economic pipelines, clearing systems, and ledger infrastructure."
    },
    {
      title: "Absolute Technical Trust",
      desc: "Enterprise clients trust our software. We operate as a precise, elite engineering advisory and custom solutions builder, maintaining clean, uncompromised structures designed for audit readiness."
    }
  ];

  return (
    <section id="about" className="py-24 bg-[#08090a] tech-dots relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#E2C374]/15 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Block: Institutional Text */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase">
                05 // Institutional Mission
              </p>
              <h2 className="text-3xl md:text-5xl font-display font-semibold tracking-tight text-white">
                Bridging Machine Intelligence With Global Capital Systems
              </h2>
            </div>

            <div className="space-y-6 font-sans text-sm text-zinc-400 font-light leading-relaxed">
              <p>
                Aureom.AI was founded on a singular conviction: as Artificial Intelligence transforms financial markets, general-purpose software templates will inevitably collapse under extreme transaction stress and regulatory scrutiny. The future demands hardened, mathematical runtime correctness and deterministic multi-agent auditing loops.
              </p>
              <p>
                We do not build simple conversational tools or generic wrappers. We design the low-level, high-impact systems, pricing models, and danger mitigation solvers that sit at the core of major financial and administrative networks. By combining low-latency hardware execution with formal proof theory, we give enterprises the tools required to delegate mission-critical workflows with zero systemic risk.
              </p>
            </div>

            {/* Micro spec details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-[#131518]/20 border border-white/5 rounded flex space-x-3 items-start">
                <Landmark className="w-5 h-5 text-[#E2C374] flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-mono text-xs font-bold text-white uppercase tracking-wider">
                    Fintech Compliance Ready
                  </p>
                  <p className="text-xs text-zinc-400 font-sans font-light">
                    Built with strict audit trails compatible with ISO 20022 and SEC trade-clearing reporting guidelines.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-[#131518]/20 border border-white/5 rounded flex space-x-3 items-start">
                <Cpu className="w-5 h-5 text-[#4CA5FF] flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-mono text-xs font-bold text-white uppercase tracking-wider">
                    Pre-Linked Kernels
                  </p>
                  <p className="text-xs text-zinc-400 font-sans font-light">
                    Fully optimized custom executables pre-linked for low-jitter Bare-Metal processing rigs.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Block: Core Principles Deck */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="font-display text-sm font-bold uppercase tracking-widest text-[#E2C374] border-b border-white/5 pb-2">
              Corporate Directives
            </h3>
            
            <div className="space-y-6">
              {values.map((v, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  className="space-y-2 border-l-2 border-[#E2C374]/30 pl-4 hover:border-[#E2C374] transition-colors duration-300"
                >
                  <h4 className="font-display font-medium text-white text-base">
                    {v.title}
                  </h4>
                  <p className="text-xs text-zinc-400 font-sans font-light leading-relaxed">
                    {v.desc}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Decorative block */}
            <div className="p-4 border border-zinc-800 bg-[#0e1012] rounded font-mono text-[10px] text-zinc-500">
              <p className="flex justify-between">
                <span>FOUNDRY IDENTIFIER:</span>
                <span className="text-[#E2C374]">AUREOM_FOUNDRY_SECURE_01</span>
              </p>
              <p className="flex justify-between mt-1">
                <span>AUDITED SECTOR COMPILATION:</span>
                <span className="text-emerald-400">PASSED // STABLE</span>
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
