/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { TECHNOLOGIES } from "../data";
import { ShieldAlert, ServerCrash, Cpu, Activity, Zap, Layers, Network, GitMerge, Pocket } from "lucide-react";

export default function Technology() {
  const customSpecPiles = [
    {
      title: "Distributed Systems Design",
      code: "DIST_SYS_P2P",
      description: "Our microservices function in decentralized high-availability state clusters using customized RAFT consensus engine overlays."
    },
    {
      title: "Event-Driven IPC Mesh",
      code: "EVENT_DRIVEN_AERON",
      description: "Uses UDP unicast and server-to-server multicasting to pass binary serialized message matrices in under 1000ns."
    },
    {
      title: "Kotlin / R / Python Multi-Engine",
      code: "RUNTIME_COMPAT",
      description: "We bundle polyglot solvers. Pure C++ kernels pass complex matrix arrays seamlessly to high-fidelity Python models and Kotlin ledgers."
    },
    {
      title: "API-First System Architecture",
      code: "API_FIRST_GRPC",
      description: "Strict schemas generated with Protocol Buffers ensure backward compatibility, strong compile-time type verification, and automated client generation."
    },
    {
      title: "Cloud Native Deployment",
      code: "CLOUD_AOT_CONTAINER",
      description: "Binaries pre-linked statically allowing deployment into ultra-light scratch images, bypassing legacy OS layers and kernel bottlenecks."
    }
  ];

  return (
    <section id="technology" className="py-24 bg-[#0e1012] tech-grid relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-16">
          <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-3 text-left">
            04 // Mathematical Stack
          </p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-white mb-4">
            Low-Level Engineering Foundations
          </h2>
          <p className="text-sm text-zinc-400 font-light leading-relaxed">
            Aureom.AI prioritizes hard real-time latency optimization, event-driven message architectures, and sovereign type layouts over standard web frameworks.
          </p>
        </div>

        {/* Main Tech Specifications Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Detailed Spec Block Lists */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {customSpecPiles.map((spec, idx) => (
              <motion.div
                key={spec.code}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                className="bg-[#131518]/30 border border-white/5 hover:border-white/10 p-6 rounded transition-all duration-300 group"
              >
                <div className="flex justify-between items-center mb-3">
                  <span className="font-mono text-[9px] text-[#E2C374] bg-[#E2C374]/5 border border-[#E2C374]/15 px-2 py-0.5 rounded font-bold">
                    {spec.code}
                  </span>
                  <span className="font-mono text-[10px] text-zinc-600">SPEC // 0{idx + 1}</span>
                </div>
                <h3 className="text-base font-display font-semibold text-white mb-2 group-hover:text-[#E2C374] transition-colors duration-200">
                  {spec.title}
                </h3>
                <p className="text-xs font-light text-zinc-400 leading-relaxed font-sans">
                  {spec.description}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Hard Technical Microspec Pane on Right */}
          <div className="lg:col-span-4 bg-[#08090a] border border-white/5 p-6 rounded space-y-6">
            <div className="border-b border-white/5 pb-4">
              <span className="font-mono text-[10px] tracking-wider text-zinc-500 uppercase font-semibold">
                Kernel Target Matrix
              </span>
              <p className="text-sm font-display font-bold text-white mt-1">Runtime Constraints</p>
            </div>

            {/* List of hardware features */}
            <div className="space-y-4">
              {TECHNOLOGIES.map((tech, idx) => (
                <div key={idx} className="space-y-1.5 border-b border-white/5 pb-3 last:border-b-0 last:pb-0">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-mono font-bold text-zinc-200">{tech.name}</span>
                    <span className="text-[10px] font-mono text-[#E2C374]">{tech.latencyProfile}</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 font-sans font-light leading-relaxed">
                    {tech.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Micro spec metrics footer */}
            <div className="pt-4 border-t border-white/5 bg-[#131518]/15 rounded p-3.5 border border-white/5 space-y-2">
              <div className="flex items-center space-x-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-[#E2C374] animate-ping" />
                <span className="font-mono text-[10px] uppercase text-[#E2C374] font-bold">
                  Absolute Lock Tolerance Spec
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed font-sans font-light">
                Our code patterns completely ban synchronization block locks in critical code paths, preferring lock-free concurrent circular buffers (ring arrays) to eliminate deadlocks and priority inversion.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
