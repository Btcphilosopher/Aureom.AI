/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { Cpu, Database, Activity, Waypoints, ArrowRight, CornerDownRight } from "lucide-react";
import { Capability } from "../types";
import { CAPABILITIES } from "../data";

export default function Capabilities() {
  const getIcon = (id: string) => {
    switch (id) {
      case "ai-eng":
        return <Cpu className="w-5 h-5 text-[#E2C374]" />;
      case "fin-infra":
        return <Database className="w-5 h-5 text-[#4CA5FF]" />;
      case "risk-model":
        return <Activity className="w-5 h-5 text-[#E2C374]" />;
      case "data-pipe":
        return <Waypoints className="w-5 h-5 text-[#4CA5FF]" />;
      default:
        return <Cpu className="w-5 h-5 text-zinc-400" />;
    }
  };

  return (
    <section id="capabilities" className="py-24 bg-[#08090a] tech-dots relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 gap-6">
          <div className="max-w-xl">
            <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-3 flex items-center space-x-1.5">
              <span>01 // System Disciplines</span>
            </p>
            <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-white mb-4">
              Core Institutional Capabilities
            </h2>
            <p className="text-sm text-zinc-400 font-light leading-relaxed">
              We design and execute specialized micro-platforms for economic entities. Each discipline integrates deterministic state processing and formal execution safety.
            </p>
          </div>
          
          <div className="text-left lg:text-right font-mono text-xs text-zinc-500">
            <span>Operating Invariant: Max Parallelism & Zero-Copy</span>
          </div>
        </div>

        {/* Capabilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {CAPABILITIES.map((cap, idx) => (
            <motion.div
              key={cap.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group p-8 rounded bg-[#131518]/40 border border-white/5 hover:border-white/10 hover:bg-[#131518]/70 transition-all duration-300 relative overflow-hidden"
            >
              {/* Top border glowing highlight */}
              <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-[#E2C374]/0 via-[#E2C374]/30 to-[#E2C374]/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Card Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 ml-px rounded border border-white/5 bg-[#08090a] group-hover:border-[#E2C374]/30 transition-colors duration-300">
                    {getIcon(cap.id)}
                  </div>
                  <span className="text-[10px] font-mono tracking-widest text-zinc-500 group-hover:text-[#E2C374] transition-colors duration-300 uppercase font-bold">
                    {cap.area}
                  </span>
                </div>
                <span className="font-mono text-xs text-zinc-600">0{idx + 1}</span>
              </div>

              {/* Title & Desc */}
              <h3 className="text-lg font-display font-semibold text-white mb-3 group-hover:text-[#E2C374] transition-colors duration-300">
                {cap.title}
              </h3>
              <p className="text-sm text-zinc-400 font-light leading-relaxed mb-6">
                {cap.description}
              </p>

              {/* Sub Technical Details */}
              <div className="pt-6 border-t border-white/5 space-y-3">
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-semibold">
                  Technical Specifications
                </p>
                <ul className="grid grid-cols-1 gap-2">
                  {cap.details.map((detail, dIdx) => (
                    <li key={dIdx} className="flex items-start text-xs text-zinc-300">
                      <CornerDownRight className="w-3.5 h-3.5 mr-2 text-[#E2C374]/60 flex-shrink-0 mt-0.5" />
                      <span className="font-sans font-light text-zinc-400 group-hover:text-zinc-300 transition-colors duration-200">
                        {detail}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
