/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Shield, Send, Terminal, Loader2, CheckCircle2, ChevronRight, Calendar, Clock, Globe } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    scope: "Quant Pricing Mesh",
    message: "",
    protocolKey: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionComplete, setSubmissionComplete] = useState(false);
  const [activeSegment, setActiveSegment] = useState<"form" | "calendar">("form");

  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  const availableSlots = [
    { label: "09:00 UTC", id: "0900" },
    { label: "11:00 UTC", id: "1100" },
    { label: "14:00 UTC", id: "1400" },
    { label: "16:00 UTC", id: "1600" }
  ];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !selectedTime) {
      alert("Please select both a date and time slot prior to scheduling synchronization.");
      return;
    }
    setBookingConfirmed(true);
  };

  const validate = () => {
    const nextErrors: Record<string, string> = {};
    if (!formData.name.trim()) {
      nextErrors.name = "Full descriptor name is required.";
    }
    if (!formData.email.trim()) {
      nextErrors.email = "Valid corporate email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      nextErrors.email = "A valid email format is required.";
    }
    if (!formData.company.trim()) {
      nextErrors.company = "Enterprise entity name is required.";
    }
    if (!formData.message.trim()) {
      nextErrors.message = "Please describe proposal parameters.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate high-security system ledger pipeline submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmissionComplete(true);
    }, 2200);
  };

  return (
    <section id="contact" className="py-24 bg-[#0e1012] tech-grid relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#E2C374]/30 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16 items-start">
          <div className="lg:col-span-8">
            <p className="text-[10px] font-mono tracking-widest text-[#E2C374] font-bold uppercase mb-3 text-left">
              06 // Access Gateway
            </p>
            <h2 className="text-3xl md:text-5xl font-display font-semibold tracking-tight text-white mb-4">
              Commence System Integration
            </h2>
            <p className="text-sm text-zinc-400 font-light leading-relaxed max-w-2xl font-sans">
              Request credentials for sandboxed testing or submit an RFP specification directly to our technical desk. All communication remains protected under strict end-to-end institutional protocols.
            </p>
          </div>

          {/* Toggle Gateway Type */}
          <div className="lg:col-span-4 flex items-center justify-end h-full">
            <div className="bg-[#08090a] p-1 border border-white/5 rounded flex w-full max-w-xs">
              <button
                onClick={() => {
                  setActiveSegment("form");
                  setSubmissionComplete(false);
                }}
                className={`flex-1 text-[10px] font-mono font-medium tracking-wide py-2 text-center rounded-sm transition-all focus:outline-none cursor-pointer ${
                  activeSegment === "form" ? "bg-white/5 text-white border border-white/5 font-bold" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                1 // Secure RFP Form
              </button>
              <button
                onClick={() => {
                  setActiveSegment("calendar");
                  setBookingConfirmed(false);
                }}
                className={`flex-1 text-[10px] font-mono font-medium tracking-wide py-2 text-center rounded-sm transition-all focus:outline-none cursor-pointer ${
                  activeSegment === "calendar" ? "bg-white/5 text-white border border-white/5 font-bold" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                2 // Sync Calendar
              </button>
            </div>
          </div>
        </div>

        {/* Portal Core Modules */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left info column */}
          <div className="lg:col-span-4 space-y-8">
            <div className="space-y-6">
              <h3 className="font-display text-sm font-bold uppercase tracking-widest text-[#E2C374] border-b border-white/5 pb-2">
                Operational Gateways
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3 text-xs">
                  <Mail className="w-4 h-4 text-[#E2C374] flex-shrink-0 mt-0.5" />
                  <div className="space-y-1 font-sans">
                    <p className="text-white font-mono font-semibold">General Digital Ingress</p>
                    <a href="mailto:contact@aureom.ai" className="text-zinc-400 hover:text-[#E2C374] transition-colors leading-none">
                      contact@aureom.ai
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-xs">
                  <Shield className="w-4 h-4 text-[#4CA5FF] flex-shrink-0 mt-0.5" />
                  <div className="space-y-1 font-sans">
                    <p className="text-white font-mono font-semibold">Security Assertion GPG Key</p>
                    <span className="text-zinc-400 font-mono text-[9px] block leading-relaxed select-all">
                      F82E C921 A012 3FF8 DE91
                    </span>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-xs">
                  <Globe className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1 font-sans">
                    <p className="text-white font-mono font-semibold">Dynamic Cluster Node Location</p>
                    <p className="text-zinc-400 leading-none">
                      Basel / Munich Edge Clusters
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Cryptographic safety banner */}
            <div className="p-4 bg-[#131518]/20 border border-white/5 rounded space-y-2 text-xs">
              <p className="font-mono text-[#E2C374] font-semibold flex items-center space-x-1.5">
                <Shield className="w-3.5 h-3.5" />
                <span>Zero Trust Active</span>
              </p>
              <p className="text-zinc-400 font-light font-sans leading-relaxed">
                All submitted parameter blocks are encrypted using local RSA envelope matrices before syncing onto the ledger. No clear-text logs are ever written.
              </p>
            </div>
          </div>

          {/* Right Segment Window: Form vs Calendar */}
          <div className="lg:col-span-8 bg-[#08090a]/60 border border-white/5 p-6 md:p-8 rounded min-h-[460px] flex flex-col justify-center">
            
            <AnimatePresence mode="wait">
              {activeSegment === "form" ? (
                // RPF Form segment
                !submissionComplete ? (
                  <motion.form
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="space-y-6"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Name */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          1.1 Full Descriptor Name
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="e.g. Dr. Arthur Vance"
                          className="w-full bg-[#131518]/40 border border-white/5 hover:border-white/10 focus:border-[#E2C374] px-4 py-3 text-xs text-white rounded outline-none transition-colors"
                        />
                        {errors.name && (
                          <span className="text-[10px] font-mono text-red-400">{errors.name}</span>
                        )}
                      </div>

                      {/* Corporate Email */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          1.2 Corporate Email Ingress
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="vance@capitalfoundry.com"
                          className="w-full bg-[#131518]/40 border border-white/5 hover:border-white/10 focus:border-[#E2C374] px-4 py-3 text-xs text-white rounded outline-none transition-colors"
                        />
                        {errors.email && (
                          <span className="text-[10px] font-mono text-red-100">{errors.email}</span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Company */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          1.3 Corporate Entity Name
                        </label>
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleInputChange}
                          placeholder="Capital Foundry LLC"
                          className="w-full bg-[#131518]/40 border border-white/5 hover:border-white/10 focus:border-[#E2C374] px-4 py-3 text-xs text-white rounded outline-none transition-colors"
                        />
                        {errors.company && (
                          <span className="text-[10px] font-mono text-red-400">{errors.company}</span>
                        )}
                      </div>

                      {/* Integration Scope */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          1.4 Intended Target Scope
                        </label>
                        <select
                          name="scope"
                          value={formData.scope}
                          onChange={handleInputChange}
                          className="w-full bg-[#131518] border border-white/5 focus:border-[#E2C374] px-4 py-3 text-xs text-white rounded outline-none cursor-pointer"
                        >
                          <option value="Quant Pricing Mesh">AAP-4 Pricing Mesh Core</option>
                          <option value="Risk Evaluation Engine">ARE-7 Stochastic Evaluator</option>
                          <option value="Autonomous Audit Agents">Multi-Agent Sovereign Auditing</option>
                          <option value="Sovereign Low-Latency Infrastructure">Zero-Copy Low-Latency Infrastructure</option>
                        </select>
                      </div>
                    </div>

                    {/* Specification Description */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                        1.5 Integration Scope Proposal Parameters
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        rows={4}
                        placeholder="Detail peak transaction capacity, interface protocols (gRPC/Aeron), compliance boundaries, or sandbox timeline constraints."
                        className="w-full bg-[#131518]/40 border border-white/5 hover:border-white/10 focus:border-[#E2C374] px-4 py-3 text-xs text-white rounded outline-none transition-colors resize-none font-sans font-light"
                      />
                      {errors.message && (
                        <span className="text-[10px] font-mono text-red-400">{errors.message}</span>
                      )}
                    </div>

                    {/* Action submit button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full flex items-center justify-center space-x-2 bg-[#E2C374] hover:bg-[#ebd59a] text-black text-xs font-mono font-bold py-3.5 rounded-sm transition-all duration-300 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-black" />
                          <span>Constructing Handshake Matrix...</span>
                        </>
                      ) : (
                        <>
                          <span>Establish Handshake Encryption & Send</span>
                          <ChevronRight className="w-3.5 h-3.5 text-black" />
                        </>
                      )}
                    </button>
                  </motion.form>
                ) : (
                  // Success Message: Realistic System Ledger Simulation!
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-6 font-mono text-xs text-zinc-400 text-left"
                  >
                    <div className="flex items-center space-x-3 text-emerald-400 mb-6 bg-emerald-500/5 p-3 rounded border border-emerald-500/10">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                      <div>
                        <p className="font-bold uppercase tracking-wider text-xs">System Ingress Handshake Complete</p>
                        <p className="text-[10px] text-zinc-500 uppercase font-light">Envelope successfully serialized onto the secure outbound queue.</p>
                      </div>
                    </div>

                    <div className="bg-[#0e1012] border border-white/5 p-5 rounded space-y-4">
                      <p className="text-[#E2C374] tracking-widest text-[10px] uppercase font-bold">// SECURE LEDGER REGISTRY OUTPUT</p>
                      
                      <div className="space-y-1.5 text-[11px] text-zinc-400">
                        <p><span className="text-zinc-600">&gt; Sender Entity:</span> <span className="text-white font-medium">{formData.company}</span></p>
                        <p><span className="text-zinc-600">&gt; Target Scope:</span> <span className="text-[#4CA5FF] font-medium">{formData.scope}</span></p>
                        <p><span className="text-zinc-600">&gt; Ingress Route:</span> <span className="text-white">SSL_TLS_CIPHER_ECDHE_RSA</span></p>
                        <p><span className="text-zinc-600">&gt; Core Invariant Hash:</span> <span className="text-[#E2C374]">9a92c81a7bdfd92be804ff10e0129</span></p>
                      </div>

                      <div className="p-3 bg-white/5 border border-white/5 rounded text-[10px] text-zinc-500 font-sans font-light leading-relaxed">
                        An encrypted copy of this ledger handshake record has been forwarded to <strong className="text-white font-mono">{formData.email}</strong>. Our senior integration architect will synchronize on secure channels within 4 business hours.
                      </div>
                    </div>

                    <button
                      onClick={() => setSubmissionComplete(false)}
                      className="text-[10px] text-zinc-500 hover:text-[#E2C374] transition-colors uppercase font-bold flex items-center"
                    >
                      <span>Transmit another specification</span>
                      <ChevronRight className="w-3.5 h-3.5 ml-1" />
                    </button>
                  </motion.div>
                )
              ) : (
                // Interactive Calendar Booking embed placeholder!
                !bookingConfirmed ? (
                  <motion.form
                    key="calendar"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleBooking}
                    className="space-y-6"
                  >
                    <div>
                      <span className="text-[#E2C374] text-[10px] font-mono uppercase tracking-widest font-bold block mb-1">
                        // SECURE DIRECTORY SYNCHRONIZER
                      </span>
                      <h4 className="text-lg font-display font-medium text-white">
                        Inquire Direct Architecht Audit
                      </h4>
                      <p className="text-xs text-zinc-400 mt-1 font-sans font-light">
                        Select a target sync date and time slot to secure an direct technical evaluation regarding economic integration logic.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Date selector */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          Date Selection
                        </label>
                        <input
                          type="date"
                          min="2026-06-01"
                          onChange={(e) => setSelectedDate(e.target.value)}
                          className="w-full bg-[#131518]/45 border border-white/5 text-white text-xs px-4 py-3 rounded outline-none focus:border-[#E2C374]"
                        />
                      </div>

                      {/* Time slot selector */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                          Time Slot (UTC Consensus)
                        </label>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          {availableSlots.map((slot) => (
                            <button
                              key={slot.id}
                              type="button"
                              onClick={() => setSelectedTime(slot.label)}
                              className={`py-2 text-[11px] font-mono rounded border transition-all cursor-pointer ${
                                selectedTime === slot.label
                                  ? "border-[#E2C374] bg-[#E2C374]/10 text-[#E2C374] font-bold"
                                  : "border-white/5 bg-[#131518]/40 text-zinc-400 hover:border-white/20 hover:text-white"
                              }`}
                            >
                              {slot.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-[#E2C374] to-[#ebd59a] text-black text-xs font-mono font-bold py-3.5 rounded-sm transition-all duration-300"
                    >
                      <Calendar className="w-4 h-4 text-black mr-1" />
                      <span>Request Core Sync Reservation</span>
                    </button>
                  </motion.form>
                ) : (
                  // Calendar Booking Confirmation
                  <motion.div
                    key="booking-success"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-6 font-mono text-xs text-zinc-400"
                  >
                    <div className="flex items-center space-x-3 text-[#E2C374] mb-6 bg-[#E2C374]/5 p-3 rounded border border-[#E2C374]/20">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-[#E2C374]" />
                      <div>
                        <p className="font-bold uppercase tracking-wider text-xs text-white">Sync Reservation Staged</p>
                        <p className="text-[10px] text-zinc-500 uppercase font-light">Consensus scheduled for {selectedDate} at {selectedTime}.</p>
                      </div>
                    </div>

                    <div className="bg-[#0e1012] border border-white/5 p-5 pr-8 rounded space-y-4">
                      <p className="text-[#E2C374] tracking-widest text-[10px] uppercase font-bold">// INTEGRITY CONSOLE CONFIRMATION</p>
                      
                      <div className="space-y-1.5 text-[11px]">
                        <p><span className="text-zinc-600">&gt; Target Session:</span> <span className="text-white font-medium">Core Ledger Architecture Evaluation</span></p>
                        <p><span className="text-zinc-600">&gt; Slotted Date:</span> <span className="text-[#E2C374] font-medium">{selectedDate}</span></p>
                        <p><span className="text-zinc-600">&gt; Slotted Segment:</span> <span className="text-white">{selectedTime}</span></p>
                        <p><span className="text-zinc-600">&gt; Host Handshake Target:</span> <span className="text-white font-mono">meetings-v42.aureom.ai</span></p>
                      </div>

                      <div className="p-3 bg-white/5 border border-white/5 rounded text-[10px] text-zinc-500 font-sans font-light leading-relaxed">
                        An automated secure invitation block (including cryptographic dial-in codes) has been compiled. Our system integration panel has locked this segment of the ledger.
                      </div>
                    </div>

                    <button
                      onClick={() => setBookingConfirmed(false)}
                      className="text-[10px] text-zinc-500 hover:text-[#E2C374] transition-colors uppercase font-bold flex items-center"
                    >
                      <span>Reschedule reserve slots</span>
                      <ChevronRight className="w-3.5 h-3.5 ml-1" />
                    </button>
                  </motion.div>
                )
              )}
            </AnimatePresence>

          </div>

        </div>

      </div>
    </section>
  );
}
