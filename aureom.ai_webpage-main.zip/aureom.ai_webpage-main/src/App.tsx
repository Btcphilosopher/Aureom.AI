/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Header from "./components/Header";
import Hero from "./components/Hero";
import Capabilities from "./components/Capabilities";
import Topology from "./components/Topology";
import Modules from "./components/Modules";
import Technology from "./components/Technology";
import About from "./components/About";
import Contact from "./components/Contact";
import { ArrowUpRight, Cpu, ShieldCheck } from "lucide-react";

export default function App() {
  const handleScrollToContact = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      const headerOffset = 85;
      const elementPosition = contactSection.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleScrollToModules = () => {
    const modulesSection = document.getElementById("modules");
    if (modulesSection) {
      const headerOffset = 85;
      const elementPosition = modulesSection.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#08090a] text-zinc-300 font-sans antialiased relative">
      {/* Structural Headers */}
      <Header onContactClick={handleScrollToContact} />

      {/* Main Flow Modules */}
      <main id="main-content">
        <Hero
          onContactClick={handleScrollToContact}
          onExploreClick={handleScrollToModules}
        />
        
        <Capabilities />
        
        <Topology />
        
        <Modules />
        
        <Technology />
        
        <About />
        
        <Contact />
      </main>

      {/* Institutional Footer */}
      <footer className="bg-[#08090a] border-t border-white/5 py-16 text-zinc-500 font-mono text-xs">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-12">
            
            {/* Logo block */}
            <div className="md:col-span-4 space-y-4">
              <div className="flex items-center space-x-2">
                <span className="font-display text-base font-bold text-white tracking-tight">Aureom</span>
                <span className="text-[#E2C374] text-xs font-semibold tracking-wider">.AI</span>
              </div>
              <p className="text-[11px] text-zinc-600 font-sans font-light leading-relaxed max-w-xs">
                Sovereign architectural frameworks, low-latency transaction processing models, and validated intelligence layers engineered for economic enterprises.
              </p>
            </div>

            {/* Directory Indices */}
            <div className="md:col-span-4 grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <p className="text-[10px] font-bold text-white uppercase tracking-wider">// LIBRARIES</p>
                <ul className="space-y-1.5 text-[11px] text-zinc-500 font-sans">
                  <li><a href="#capabilities" className="hover:text-[#E2C374] transition-colors">Core Systems</a></li>
                  <li><a href="#topology" className="hover:text-[#E2C374] transition-colors">Mesh Grid</a></li>
                  <li><a href="#modules" className="hover:text-[#E2C374] transition-colors font-mono">AAP-4 / ARE-7</a></li>
                </ul>
              </div>

              <div className="space-y-3">
                <p className="text-[10px] font-bold text-white uppercase tracking-wider">// SECURE INGRESS</p>
                <ul className="space-y-1.5 text-[11px] text-zinc-400 font-sans">
                  <li><button onClick={handleScrollToContact} className="hover:text-[#E2C374] cursor-pointer transition-colors text-left">Request Sandbox Access</button></li>
                  <li><a href="mailto:contact@aureom.ai" className="hover:text-[#E2C374] transition-colors">Secure Node Mailbox</a></li>
                  <li><span className="text-zinc-600">GPG Fingerprint: F82E</span></li>
                </ul>
              </div>
            </div>

            {/* Network cluster indicator */}
            <div className="md:col-span-4 bg-[#131518]/25 p-4 rounded border border-white/5 space-y-3">
              <div className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] font-bold text-white uppercase tracking-wider">Nodes Cluster Status</span>
              </div>
              <div className="space-y-1 text-[10px] text-zinc-500 text-left">
                <p>Ingress Router: <span className="text-emerald-400">ONLINE [DE_MUC_01]</span></p>
                <p>Consensus Node: <span className="text-emerald-400">ONLINE [CH_BSL_04]</span></p>
                <p>Telemetry Sync: <span className="text-zinc-400">99.9995% Consistent</span></p>
              </div>
            </div>

          </div>

          {/* Legal / Bottom block */}
          <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-[10px] text-zinc-600 leading-relaxed font-sans">
            <div className="space-y-1 max-w-2xl text-left">
              <p>© {new Date().getFullYear()} Aureom.AI. All rights reserved. Cryptographic signatures verified annually.</p>
              <p className="text-[9px] text-zinc-700 font-light">
                Regulatory Invariant: Aureom.AI designs sovereign execution software and low-latency infrastructure kernels. We do not operate brokerage services, trade execution accounts, or handle direct consumer retail deposits. All assets and transactions remain routed through compliant primary institutional clearinghouses.
              </p>
            </div>
            
            <div className="flex items-center space-x-1 whitespace-nowrap bg-[#131518]/45 px-3 py-1 rounded border border-white/5 text-[9px] font-mono uppercase text-[#E2C374]">
              <ShieldCheck className="w-3.5 h-3.5 mr-0.5 text-[#E2C374]" />
              <span>Verified Audit Standard // ISO 27001 Readiness</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
