package com.example.model

import java.util.UUID

enum class DeckId(val label: String, val index: Int) {
    DECK_A("DECK A", 0),
    DECK_B("DECK B", 1),
    DECK_C("DECK C", 2),
    DECK_D("DECK D", 3)
}

enum class CrossfaderCurve {
    LINEAR,
    CONSTANT_POWER,
    CUT_SCRATCH,
    SMOOTH_FADE
}

enum class PerformanceMode {
    PERFORMANCE,
    PRACTICE,
    AUTOMIX
}

enum class PerformanceTab {
    HOT_CUES,
    LOOPS_SLICER,
    SAMPLER,
    STEMS,
    FX_UNIT,
    AI_DJ,
    LIBRARY,
    SETTINGS_MIDI
}

enum class EffectType(val displayName: String, val param1Name: String, val param2Name: String) {
    ECHO("Echo", "Feedback", "Hi-Cut"),
    DELAY("Delay", "Feedback", "Color"),
    REVERB("Reverb", "Size", "Damping"),
    FILTER("Filter Sweep", "Resonance", "Drive"),
    FLANGER("Flanger", "Depth", "Rate"),
    PHASER("Phaser", "Feedback", "Stages"),
    CHORUS("Chorus", "Depth", "Detune"),
    BITCRUSH("Bitcrush", "Bits", "Sample Rate"),
    DISTORTION("Distortion", "Drive", "Tone"),
    GATE("Noise Gate", "Threshold", "Attack"),
    COMPRESSOR("Master Comp", "Ratio", "Threshold")
}

data class Track(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val artist: String,
    val album: String = "Single",
    val genre: String = "Tech House",
    val bpm: Double = 124.0,
    val key: String = "8A",             // Camelot Notation
    val musicalKey: String = "A Minor",
    val durationSec: Double = 348.0,
    val rating: Int = 5,
    val energy: Int = 85,               // 0 - 100%
    val colorHex: Long = 0xFF00E5FF,
    val waveformPeaks: List<Float> = emptyList(), // Normalized 0..1 amplitude
    val lowPeaks: List<Float> = emptyList(),      // Bass peaks
    val midPeaks: List<Float> = emptyList(),      // Mid peaks
    val highPeaks: List<Float> = emptyList(),     // Treble peaks
    val hotCues: List<HotCue> = emptyList(),
    val downbeats: List<Double> = emptyList(),    // Downbeat markers in seconds
    val phrasePositions: List<Double> = emptyList()
)

data class HotCue(
    val index: Int,             // 0..7 (Cue 1..8)
    val positionSec: Double,
    val label: String,
    val colorHex: Long = 0xFF00E676,
    val isActive: Boolean = true
)

data class LoopState(
    val isActive: Boolean = false,
    val inPositionSec: Double = 0.0,
    val outPositionSec: Double = 0.0,
    val lengthBars: Float = 4.0f,
    val isAutoLoop: Boolean = true
)

data class StemsState(
    val vocalsGain: Float = 1.0f,
    val drumsGain: Float = 1.0f,
    val bassGain: Float = 1.0f,
    val melodyGain: Float = 1.0f,
    val vocalsMuted: Boolean = false,
    val drumsMuted: Boolean = false,
    val bassMuted: Boolean = false,
    val melodyMuted: Boolean = false
)

data class DeckState(
    val deckId: DeckId,
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val playheadPositionSec: Double = 0.0,
    val targetBpm: Double = 124.0,
    val pitchPercent: Float = 0.0f,      // -50% to +50%
    val pitchRange: Float = 8.0f,        // 4, 8, 16, 50%
    val isMasterDeck: Boolean = false,
    val isSyncEnabled: Boolean = false,
    val isKeyLockEnabled: Boolean = true,
    val isSlipModeEnabled: Boolean = false,
    val vinylBrakeActive: Boolean = false,
    val jogAngle: Float = 0.0f,
    val scratchVelocity: Float = 0.0f,
    val loopState: LoopState = LoopState(),
    val hotCues: List<HotCue> = emptyList(),
    val stems: StemsState = StemsState(),
    // Channel Mixer controls
    val trimGain: Float = 1.0f,          // 0.0 .. 2.0 (1.0 = unity 0dB)
    val eqHigh: Float = 1.0f,            // 0.0 (kill) .. 1.0 (flat) .. 2.0 (+6dB)
    val eqMid: Float = 1.0f,
    val eqLow: Float = 1.0f,
    val filterColor: Float = 0.5f,       // 0.0 (full LPF) .. 0.5 (off) .. 1.0 (full HPF)
    val pan: Float = 0.0f,               // -1.0 (Left) .. 0.0 (Center) .. 1.0 (Right)
    val channelFader: Float = 1.0f,      // 0.0 .. 1.0
    val isCueMonitoring: Boolean = false,
    val vuLevelLeft: Float = 0.0f,       // 0.0 .. 1.2
    val vuLevelRight: Float = 0.0f,
    val isClipping: Boolean = false,
    // Active FX on deck
    val activeEffect: EffectType = EffectType.ECHO,
    val effectEnabled: Boolean = false,
    val effectDryWet: Float = 0.35f,
    val effectBeatTime: Float = 0.75f,    // in beats: 0.25 (1/4), 0.5 (1/2), 0.75 (3/4), 1.0 (1 beat)
    val effectFeedback: Float = 0.6f,
    val effectParam2: Float = 0.5f
)

data class MixerMasterState(
    val masterVolume: Float = 0.85f,
    val cueVolume: Float = 0.8f,
    val cueMixBalance: Float = 0.5f,     // 0.0 (Cue only) .. 1.0 (Master only)
    val crossfaderPosition: Float = 0.5f,// 0.0 (Full Left A/C) .. 0.5 (Center) .. 1.0 (Full Right B/D)
    val crossfaderCurve: CrossfaderCurve = CrossfaderCurve.CONSTANT_POWER,
    val masterVuLeft: Float = 0.0f,
    val masterVuRight: Float = 0.0f,
    val masterClipping: Boolean = false,
    val limiterEnabled: Boolean = true,
    val limiterThresholdDb: Float = -0.5f,
    val isRecording: Boolean = false,
    val recordingTimeFormatted: String = "00:00:00"
)

data class SamplerPadState(
    val id: Int,
    val name: String,
    val category: String,
    val sampleResId: Int? = null,
    val colorHex: Long = 0xFF00E5FF,
    val volume: Float = 0.9f,
    val pitchSemiTones: Int = 0,
    val isLooping: Boolean = false,
    val isPlaying: Boolean = false
)

data class RecordingState(
    val isRecording: Boolean = false,
    val durationSeconds: Long = 0L,
    val recordedBytes: Long = 0L,
    val recordingFormat: String = "WAV 24-bit / 48kHz Stereo",
    val recentRecordings: List<SavedRecording> = emptyList()
)

data class SavedRecording(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val date: String,
    val duration: String,
    val fileSize: String,
    val tracklist: List<String> = emptyList()
)

data class LatencyConfig(
    val sampleRate: Int = 48000,
    val bufferSizeSamples: Int = 128,
    val estimatedLatencyMs: Float = 2.7f,
    val cpuUsagePercent: Int = 14,
    val audioDropouts: Int = 0,
    val outputDevice: String = "Built-in Master Speakers (Stereo)",
    val cueDevice: String = "Headphones / USB DJ Interface (Ch 3-4)"
)

data class MIDIMapItem(
    val controlName: String,
    val hardwareSource: String,
    val channel: Int,
    val ccOrNote: Int,
    val isLearning: Boolean = false
)

data class AIDJTransitionAdvice(
    val fromTrack: Track,
    val toTrack: Track,
    val compatibilityScore: Int,         // 0 - 100%
    val harmonicMatch: String,           // e.g., "Harmonic (8A -> 9A, +1 Energy)"
    val bpmDifference: Double,           // e.g., +2.0 BPM
    val recommendedOutroSec: Double,
    val recommendedIntroSec: Double,
    val eqStrategy: String,
    val transitionPrompt: String
)

data class AISetProposal(
    val title: String,
    val estimatedMinutes: Int,
    val targetGenre: String,
    val trackProgression: List<Track>,
    val energyCurve: List<Int>,
    val notes: String
)
