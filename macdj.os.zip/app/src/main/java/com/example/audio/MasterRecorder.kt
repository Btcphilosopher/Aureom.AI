package com.example.audio

import android.content.Context
import com.example.model.SavedRecording
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MasterRecorder(private val context: Context) {
    private var isRecording = false
    private var tempFile: File? = null
    private var outputStream: FileOutputStream? = null
    private var totalAudioBytes: Long = 0L
    private var startTimeMillis: Long = 0L
    private val recordedTracklist = mutableListOf<String>()

    fun startRecording(currentTracks: List<String>) {
        if (isRecording) return
        recordedTracklist.clear()
        recordedTracklist.addAll(currentTracks)
        totalAudioBytes = 0L
        startTimeMillis = System.currentTimeMillis()

        val recordDir = File(context.filesDir, "recordings")
        if (!recordDir.exists()) recordDir.mkdirs()

        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        tempFile = File(recordDir, "MACDJ_SESSION_$timeStamp.raw")
        outputStream = FileOutputStream(tempFile)
        isRecording = true
    }

    fun addTrackToHistory(trackTitle: String) {
        if (isRecording && !recordedTracklist.contains(trackTitle)) {
            recordedTracklist.add(trackTitle)
        }
    }

    fun writeAudioData(bytes: ByteArray) {
        if (!isRecording) return
        try {
            outputStream?.write(bytes)
            totalAudioBytes += bytes.size
        } catch (_: Exception) {}
    }

    suspend fun stopRecording(): SavedRecording? = withContext(Dispatchers.IO) {
        if (!isRecording) return@withContext null
        isRecording = false

        try {
            outputStream?.flush()
            outputStream?.close()
        } catch (_: Exception) {}

        val raw = tempFile ?: return@withContext null
        val durationMs = System.currentTimeMillis() - startTimeMillis
        val durationSec = (durationMs / 1000).toInt()
        val durationFormatted = String.format(Locale.US, "%02d:%02d:%02d", durationSec / 3600, (durationSec % 3600) / 60, durationSec % 60)

        val timeStamp = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.US).format(Date())
        val wavFile = File(raw.parentFile, raw.nameWithoutExtension + ".wav")

        // Convert raw PCM to standard WAV format
        writeWavHeader(raw, wavFile, totalAudioBytes, 48000, 2, 16)
        raw.delete()

        val sizeFormatted = String.format(Locale.US, "%.1f MB", wavFile.length() / (1024.0 * 1024.0))

        SavedRecording(
            id = UUID.randomUUID().toString(),
            fileName = wavFile.name,
            date = timeStamp,
            duration = durationFormatted,
            fileSize = sizeFormatted,
            tracklist = ArrayList(recordedTracklist)
        )
    }

    private fun writeWavHeader(
        rawFile: File,
        wavFile: File,
        totalAudioLen: Long,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val totalDataLen = totalAudioLen + 36
        val byteRate = (sampleRate * channels * bitsPerSample / 8).toLong()

        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // PCM
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * bitsPerSample / 8).toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        val wavOut = FileOutputStream(wavFile)
        wavOut.write(header)
        rawFile.inputStream().use { input ->
            input.copyTo(wavOut)
        }
        wavOut.close()
    }
}
