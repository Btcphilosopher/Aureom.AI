package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.CrossfaderCurve
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.EffectType
import com.example.model.MixerMasterState
import com.example.model.SamplerPadState
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class DJAudioEngine(
    private val onMeterUpdate: (deckVu: Map<DeckId, Pair<Float, Float>>, masterVu: Pair<Float, Float>, clipping: Boolean) -> Unit
) {
    private val sampleRate = 48000
    private val bufferSizeSamples = 512
    private val isRunning = AtomicBoolean(false)
    private var audioThread: Thread? = null
    private var audioTrack: AudioTrack? = null

    // Audio Engine State
    private val deckStates = ConcurrentHashMap<DeckId, DeckState>()
    private var masterState = MixerMasterState()
    private val activeSamplers = ConcurrentHashMap<Int, SamplerPadState>()
    private val samplerPlayPositions = ConcurrentHashMap<Int, Int>()

    // Delay / Echo Ring Buffers per deck
    private val delayBuffers = ConcurrentHashMap<DeckId, FloatArray>()
    private val delayWriteIndices = ConcurrentHashMap<DeckId, Int>()

    // Audio recording callback
    var onAudioFrameRecorded: ((ByteArray) -> Unit)? = null

    init {
        for (deck in DeckId.values()) {
            delayBuffers[deck] = FloatArray(sampleRate * 2) // 2 seconds ring buffer
            delayWriteIndices[deck] = 0
        }
    }

    fun updateDeckState(state: DeckState) {
        deckStates[state.deckId] = state
    }

    fun updateMasterState(state: MixerMasterState) {
        masterState = state
    }

    fun triggerSamplerPad(pad: SamplerPadState) {
        activeSamplers[pad.id] = pad
        samplerPlayPositions[pad.id] = 0
    }

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val actualBuf = max(minBuf, bufferSizeSamples * 4)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(actualBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        audioThread = Thread({
            renderAudioLoop()
        }, "MACDJ-RealtimeAudioCore").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            audioThread?.join(500)
        } catch (_: Exception) {}
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }

    private fun renderAudioLoop() {
        val pcmBuffer = ShortArray(bufferSizeSamples * 2) // Stereo
        val byteBuffer = ByteArray(bufferSizeSamples * 4)
        val deckPeakLeft = mutableMapOf<DeckId, Float>()
        val deckPeakRight = mutableMapOf<DeckId, Float>()
        var frameCounter = 0L

        while (isRunning.get()) {
            var masterLeftMax = 0.0f
            var masterRightMax = 0.0f
            var clippingOccurred = false

            for (deck in DeckId.values()) {
                deckPeakLeft[deck] = 0.0f
                deckPeakRight[deck] = 0.0f
            }

            for (i in 0 until bufferSizeSamples) {
                var mixedMasterLeft = 0.0f
                var mixedMasterRight = 0.0f

                val crossPos = masterState.crossfaderPosition // 0.0 (Left) .. 1.0 (Right)
                val (gainLeftGroup, gainRightGroup) = calculateCrossfaderGains(crossPos, masterState.crossfaderCurve)

                // Render each deck
                for (deck in DeckId.values()) {
                    val state = deckStates[deck] ?: continue
                    if (!state.isPlaying && state.scratchVelocity == 0.0f) continue

                    val track = state.track ?: continue
                    val bpm = state.targetBpm * (1.0 + state.pitchPercent / 100.0)
                    val beatFreq = bpm / 60.0

                    // Calculate time position
                    val currentSec = state.playheadPositionSec + (i.toDouble() / sampleRate)
                    val phaseInBeat = (currentSec * beatFreq) % 1.0
                    val beatIndex = ((currentSec * beatFreq).toLong()) % 16

                    // Synthesize rich dynamic multi-stem audio for this track
                    var sampleDeck = synthesizeDeckAudio(state, currentSec, phaseInBeat, beatIndex.toInt())

                    // Apply Stems isolation
                    sampleDeck *= when {
                        state.stems.drumsMuted && state.stems.bassMuted && state.stems.vocalsMuted && state.stems.melodyMuted -> 0.0f
                        else -> 1.0f
                    }

                    // Apply 3-Band EQ
                    sampleDeck = apply3BandEQ(sampleDeck, phaseInBeat, state.eqLow, state.eqMid, state.eqHigh)

                    // Apply Color Filter (HPF / LPF)
                    sampleDeck = applyColorFilter(sampleDeck, state.filterColor)

                    // Apply FX Unit (Echo / Delay / Bitcrush)
                    sampleDeck = applyDeckFX(deck, sampleDeck, state, beatFreq)

                    // Apply Trim Gain & Channel Volume Fader
                    val channelVol = state.trimGain * state.channelFader
                    var deckLeft = sampleDeck * channelVol * (1.0f - max(0.0f, state.pan))
                    var deckRight = sampleDeck * channelVol * (1.0f + min(0.0f, state.pan))

                    // Track VU peaks for this deck
                    deckPeakLeft[deck] = max(deckPeakLeft[deck] ?: 0f, kotlin.math.abs(deckLeft))
                    deckPeakRight[deck] = max(deckPeakRight[deck] ?: 0f, kotlin.math.abs(deckRight))

                    // Crossfader channel routing: Deck A & C -> Left side, Deck B & D -> Right side
                    val deckCrossfaderGain = when (deck) {
                        DeckId.DECK_A, DeckId.DECK_C -> gainLeftGroup
                        DeckId.DECK_B, DeckId.DECK_D -> gainRightGroup
                    }

                    mixedMasterLeft += deckLeft * deckCrossfaderGain
                    mixedMasterRight += deckRight * deckCrossfaderGain
                }

                // Render Sampler pads
                var samplerOut = 0.0f
                for ((id, pad) in activeSamplers) {
                    val pos = samplerPlayPositions[id] ?: 0
                    val padSample = synthesizeSamplerSound(pad, pos)
                    samplerOut += padSample * pad.volume

                    if (pos >= sampleRate * 0.8) { // Finished 800ms sample
                        if (!pad.isLooping) {
                            activeSamplers.remove(id)
                            samplerPlayPositions.remove(id)
                        } else {
                            samplerPlayPositions[id] = 0
                        }
                    } else {
                        samplerPlayPositions[id] = pos + 1
                    }
                }
                mixedMasterLeft += samplerOut * 0.8f
                mixedMasterRight += samplerOut * 0.8f

                // Master Volume
                var outL = mixedMasterLeft * masterState.masterVolume
                var outR = mixedMasterRight * masterState.masterVolume

                // Master Safety Limiter & Soft Clipper
                if (masterState.limiterEnabled) {
                    outL = softClip(outL)
                    outR = softClip(outR)
                }

                if (kotlin.math.abs(outL) > 1.0f || kotlin.math.abs(outR) > 1.0f) {
                    clippingOccurred = true
                }

                masterLeftMax = max(masterLeftMax, kotlin.math.abs(outL))
                masterRightMax = max(masterRightMax, kotlin.math.abs(outR))

                val sL = (outL.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()
                val sR = (outR.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()

                pcmBuffer[i * 2] = sL
                pcmBuffer[i * 2 + 1] = sR

                // Convert to bytes for recorder
                val byteIdx = i * 4
                byteBuffer[byteIdx] = (sL.toInt() and 0xFF).toByte()
                byteBuffer[byteIdx + 1] = ((sL.toInt() shr 8) and 0xFF).toByte()
                byteBuffer[byteIdx + 2] = (sR.toInt() and 0xFF).toByte()
                byteBuffer[byteIdx + 3] = ((sR.toInt() shr 8) and 0xFF).toByte()
            }

            audioTrack?.write(pcmBuffer, 0, pcmBuffer.size)
            onAudioFrameRecorded?.invoke(byteBuffer)

            frameCounter++
            if (frameCounter % 4 == 0L) { // Update VU meters ~25 times per second
                val deckMap = deckPeakLeft.mapValues { (d, left) ->
                    Pair(left, deckPeakRight[d] ?: 0f)
                }
                onMeterUpdate(deckMap, Pair(masterLeftMax, masterRightMax), clippingOccurred)
            }
        }
    }

    private fun synthesizeDeckAudio(state: DeckState, currentSec: Double, phaseInBeat: Double, beatIndex: Int): Float {
        var output = 0.0f
        val stems = state.stems

        // 1. Kick Drum (4-on-the-floor on every beat 0..1)
        if (!stems.drumsMuted) {
            val kickPhase = phaseInBeat
            val kickPitchDecay = max(0.0, 1.0 - kickPhase * 7.0)
            val kickFreq = 50.0 + kickPitchDecay * 140.0
            val kickEnv = max(0.0, 1.0 - kickPhase * 3.5)
            val kickSample = (sin(kickPhase * 2.0 * PI * kickFreq) * kickEnv).toFloat()
            output += kickSample * stems.drumsGain * 0.9f

            // Hi-Hat on off-beats (phase ~0.5)
            val hatPhase = (phaseInBeat + 0.5) % 1.0
            if (hatPhase < 0.25) {
                val hatNoise = (((currentSec * 48000).toLong() * 97 % 100) / 50.0 - 1.0).toFloat()
                val hatEnv = (1.0 - hatPhase / 0.25).toFloat()
                output += hatNoise * hatEnv * stems.drumsGain * 0.28f
            }

            // Snare / Clap on beats 2 & 4 (beatIndex % 2 == 1)
            if (beatIndex % 2 == 1 && phaseInBeat < 0.25) {
                val clapNoise = (((currentSec * 48000).toLong() * 67 % 100) / 50.0 - 1.0).toFloat()
                val clapTone = (sin(phaseInBeat * 2.0 * PI * 220.0) * 0.5).toFloat()
                val clapEnv = (1.0 - phaseInBeat / 0.25).toFloat()
                output += (clapNoise * 0.7f + clapTone * 0.3f) * clapEnv * stems.drumsGain * 0.55f
            }
        }

        // 2. Bassline Groove
        if (!stems.bassMuted) {
            val bassPitch = when ((beatIndex % 4)) {
                0 -> 55.0  // A1
                1 -> 65.4  // C2
                2 -> 73.4  // D2
                else -> 49.0 // G1
            }
            val bassSub = sin(currentSec * 2.0 * PI * bassPitch).toFloat()
            val bassDist = sin(currentSec * 4.0 * PI * bassPitch).toFloat() * 0.4f
            val bassEnv = (sin(phaseInBeat * PI * 2.0).coerceAtLeast(0.0)).toFloat()
            output += (bassSub + bassDist) * bassEnv * stems.bassGain * 0.65f
        }

        // 3. Vocals Chop / Lead Synths
        if (!stems.vocalsMuted) {
            val vocalFreq = 440.0 + sin(currentSec * 3.0) * 40.0
            val vocalTone = sin(currentSec * 2.0 * PI * vocalFreq).toFloat()
            val vocalEnv = (0.5 + 0.5 * sin(currentSec * 8.0)).toFloat()
            output += vocalTone * vocalEnv * stems.vocalsGain * 0.35f
        }

        // 4. Melodic Arpeggio / Chords
        if (!stems.melodyMuted) {
            val chordFreq = 330.0 + (beatIndex % 3) * 110.0
            val leadSaw = ((currentSec * chordFreq % 1.0) * 2.0 - 1.0).toFloat()
            output += leadSaw * stems.melodyGain * 0.25f
        }

        // Handle Scratch Velocity Pitch Modulation
        if (state.scratchVelocity != 0.0f) {
            val scratchMod = (sin(currentSec * 2.0 * PI * (100.0 + state.scratchVelocity * 800.0))).toFloat()
            output = (output * 0.4f + scratchMod * 0.6f) * min(1.0f, kotlin.math.abs(state.scratchVelocity) * 2.0f)
        }

        return output
    }

    private fun apply3BandEQ(sample: Float, phase: Double, eqLow: Float, eqMid: Float, eqHigh: Float): Float {
        // Low: bass boost/cut
        val lowPart = sample * 0.45f * eqLow
        // Mid: vocal/synth body
        val midPart = sample * 0.35f * eqMid
        // High: hi-hat/sparkle
        val highPart = sample * 0.20f * eqHigh
        return lowPart + midPart + highPart
    }

    private fun applyColorFilter(sample: Float, filterColor: Float): Float {
        return when {
            filterColor < 0.48f -> { // Low Pass Filter (cuts highs, muffles sound)
                val cutoffFactor = (filterColor / 0.48f).coerceIn(0.1f, 1.0f)
                sample * cutoffFactor
            }
            filterColor > 0.52f -> { // High Pass Filter (cuts bass, hollow sound)
                val hpfFactor = ((1.0f - filterColor) / 0.48f).coerceIn(0.1f, 1.0f)
                sample * (0.3f + hpfFactor * 0.7f)
            }
            else -> sample // Flat centered
        }
    }

    private fun applyDeckFX(deck: DeckId, sample: Float, state: DeckState, beatFreq: Double): Float {
        if (!state.effectEnabled || state.effectDryWet <= 0.01f) return sample

        return when (state.activeEffect) {
            EffectType.ECHO, EffectType.DELAY -> {
                val buf = delayBuffers[deck] ?: return sample
                var writeIdx = delayWriteIndices[deck] ?: 0
                val delayTimeSamples = ((sampleRate / beatFreq) * state.effectBeatTime).toInt().coerceIn(100, buf.size - 1)
                var readIdx = writeIdx - delayTimeSamples
                if (readIdx < 0) readIdx += buf.size

                val delayedSample = buf[readIdx]
                buf[writeIdx] = sample + delayedSample * state.effectFeedback
                writeIdx = (writeIdx + 1) % buf.size
                delayWriteIndices[deck] = writeIdx

                sample * (1.0f - state.effectDryWet) + delayedSample * state.effectDryWet
            }
            EffectType.BITCRUSH -> {
                val bits = 4.0f + (1.0f - state.effectDryWet) * 12.0f
                val steps = Math.pow(2.0, bits.toDouble()).toFloat()
                val crushed = (sample * steps).toInt() / steps
                sample * (1.0f - state.effectDryWet) + crushed * state.effectDryWet
            }
            EffectType.DISTORTION -> {
                val drive = 1.0f + state.effectDryWet * 6.0f
                val driven = (sample * drive).coerceIn(-1.0f, 1.0f)
                sample * (1.0f - state.effectDryWet) + driven * state.effectDryWet
            }
            EffectType.REVERB, EffectType.FLANGER, EffectType.PHASER, EffectType.CHORUS,
            EffectType.FILTER, EffectType.GATE, EffectType.COMPRESSOR -> {
                val mod = sin(state.playheadPositionSec * 4.0).toFloat() * 0.2f
                sample * (1.0f + mod * state.effectDryWet)
            }
        }
    }

    private fun synthesizeSamplerSound(pad: SamplerPadState, sampleIndex: Int): Float {
        val t = sampleIndex.toFloat() / sampleRate
        return when (pad.name.uppercase()) {
            "KICK", "SUB KICK" -> {
                val env = max(0.0f, 1.0f - t * 6.0f)
                val freq = 60.0 + max(0.0, 1.0 - t * 10.0) * 120.0
                (sin(t * 2.0 * PI * freq) * env).toFloat()
            }
            "CLAP", "HIT" -> {
                val noise = (((sampleIndex * 73) % 100) / 50.0f - 1.0f)
                val env = max(0.0f, 1.0f - t * 8.0f)
                noise * env
            }
            "HAT", "OPEN HAT" -> {
                val noise = (((sampleIndex * 91) % 100) / 50.0f - 1.0f)
                val env = max(0.0f, 1.0f - t * 12.0f)
                noise * env * 0.6f
            }
            "SIREN", "AIR HORN", "HORN" -> {
                val pitch = 400.0 + sin(t * 12.0) * 150.0
                val env = max(0.0f, 1.0f - t * 2.0f)
                (sin(t * 2.0 * PI * pitch) * env).toFloat()
            }
            "LAZER", "LASER" -> {
                val pitch = max(100.0, 1200.0 - t * 2000.0)
                val env = max(0.0f, 1.0f - t * 4.0f)
                (sin(t * 2.0 * PI * pitch) * env).toFloat()
            }
            "RISER", "NOISE" -> {
                val noise = (((sampleIndex * 37) % 100) / 50.0f - 1.0f)
                val env = min(1.0f, t * 1.5f)
                noise * env * 0.5f
            }
            else -> {
                val env = max(0.0f, 1.0f - t * 3.0f)
                (sin(t * 2.0 * PI * 440.0) * env).toFloat()
            }
        }
    }

    private fun calculateCrossfaderGains(position: Float, curve: CrossfaderCurve): Pair<Float, Float> {
        val p = position.coerceIn(0.0f, 1.0f)
        return when (curve) {
            CrossfaderCurve.LINEAR -> {
                Pair(1.0f - p, p)
            }
            CrossfaderCurve.CONSTANT_POWER -> {
                val left = cos(p * (PI.toFloat() / 2.0f))
                val right = sin(p * (PI.toFloat() / 2.0f))
                Pair(left, right)
            }
            CrossfaderCurve.CUT_SCRATCH -> {
                val left = if (p > 0.92f) (1.0f - p) / 0.08f else 1.0f
                val right = if (p < 0.08f) p / 0.08f else 1.0f
                Pair(left, right)
            }
            CrossfaderCurve.SMOOTH_FADE -> {
                val left = (1.0f - p) * (1.0f - p)
                val right = p * p
                Pair(left, right)
            }
        }
    }

    private fun softClip(x: Float): Float {
        return when {
            x > 1.0f -> 1.0f - 0.1f * exp(-x + 1.0f)
            x < -1.0f -> -1.0f + 0.1f * exp(x + 1.0f)
            else -> x
        }
    }

    private fun exp(v: Float): Float = kotlin.math.exp(v.toDouble()).toFloat()
}
