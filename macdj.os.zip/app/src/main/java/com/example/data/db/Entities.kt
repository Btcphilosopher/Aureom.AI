package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val bpm: Double,
    val musicalKey: String,
    val camelotKey: String,
    val durationSec: Double,
    val rating: Int,
    val energy: Int,
    val colorHex: Long,
    val waveformDataCsv: String,
    val lowDataCsv: String,
    val midDataCsv: String,
    val highDataCsv: String,
    val hotCuesJson: String = "[]",
    val isFavorite: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String = "",
    val trackCount: Int = 0,
    val ruleFilter: String = "" // For Smart Playlists
)

@Entity(tableName = "history_entries")
data class HistoryEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val trackId: String,
    val title: String,
    val artist: String,
    val deckLabel: String,
    val playedAt: Long = System.currentTimeMillis(),
    val durationPlayedSec: Int = 0
)

@Entity(tableName = "saved_recordings")
data class RecordingEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val dateFormatted: String,
    val duration: String,
    val fileSizeFormatted: String,
    val tracklistCsv: String
)
