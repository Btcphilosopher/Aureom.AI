package com.example.data

import com.example.data.db.DJDatabase
import com.example.data.db.HistoryEntryEntity
import com.example.data.db.PlaylistEntity
import com.example.data.db.RecordingEntity
import com.example.data.db.TrackEntity
import com.example.model.HotCue
import com.example.model.SavedRecording
import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.sin

class DJRepository(private val db: DJDatabase) {

    val allTracks: Flow<List<Track>> = db.trackDao().getAllTracks().map { entities ->
        if (entities.isEmpty()) {
            PRELOADED_TRACKS
        } else {
            entities.map { it.toDomain() }
        }
    }

    val allPlaylists: Flow<List<PlaylistEntity>> = db.playlistDao().getAllPlaylists()
    val playHistory: Flow<List<HistoryEntryEntity>> = db.historyDao().getHistory()
    val allRecordings: Flow<List<SavedRecording>> = db.recordingDao().getAllRecordings().map { entities ->
        entities.map { entity ->
            SavedRecording(
                id = entity.id,
                fileName = entity.fileName,
                date = entity.dateFormatted,
                duration = entity.duration,
                fileSize = entity.fileSizeFormatted,
                tracklist = entity.tracklistCsv.split(",").filter { it.isNotBlank() }
            )
        }
    }

    suspend fun initializePreloadedDataIfEmpty() = withContext(Dispatchers.IO) {
        val count = db.trackDao().getTrackCount()
        if (count == 0) {
            val entities = PRELOADED_TRACKS.map { it.toEntity() }
            db.trackDao().insertTracks(entities)

            // Seed initial playlists
            db.playlistDao().insertPlaylist(PlaylistEntity(name = "🔥 Peak Time Anthems", description = "High energy 125-130 BPM club weapons", trackCount = 6))
            db.playlistDao().insertPlaylist(PlaylistEntity(name = "🌙 Dark Melodic Techno", description = "Deep driving 8A/9A underground grooves", trackCount = 4))
            db.playlistDao().insertPlaylist(PlaylistEntity(name = "✨ Vocal Sunset House", description = "Warm disco vibes and smooth drops", trackCount = 5))
            db.playlistDao().insertPlaylist(PlaylistEntity(name = "⚡ Fast Transitions 130+", description = "High BPM techno & bass mix crate", trackCount = 3))
        }
    }

    suspend fun addTrack(track: Track) = withContext(Dispatchers.IO) {
        db.trackDao().insertTrack(track.toEntity())
    }

    suspend fun recordPlayedTrack(track: Track, deckLabel: String, durationSec: Int) = withContext(Dispatchers.IO) {
        db.historyDao().insertHistory(
            HistoryEntryEntity(
                trackId = track.id,
                title = track.title,
                artist = track.artist,
                deckLabel = deckLabel,
                durationPlayedSec = durationSec
            )
        )
    }

    suspend fun saveRecording(recording: SavedRecording) = withContext(Dispatchers.IO) {
        db.recordingDao().insertRecording(
            RecordingEntity(
                id = recording.id,
                fileName = recording.fileName,
                dateFormatted = recording.date,
                duration = recording.duration,
                fileSizeFormatted = recording.fileSize,
                tracklistCsv = recording.tracklist.joinToString(",")
            )
        )
    }

    companion object {
        private fun generateRealisticWaveform(length: Int, seed: Double): Triple<List<Float>, List<Float>, List<Float>> {
            val full = ArrayList<Float>(length)
            val low = ArrayList<Float>(length)
            val mid = ArrayList<Float>(length)
            val high = ArrayList<Float>(length)

            for (i in 0 until length) {
                val progress = i.toFloat() / length
                // Envelope shape: intro (builds), drops (high peaks), breakdowns (low mid), outro
                val envelope = when {
                    progress < 0.15f -> 0.4f + 0.6f * (progress / 0.15f)
                    progress in 0.35f..0.45f -> 0.35f // Breakdown
                    progress in 0.45f..0.75f -> 0.95f // Main drop
                    progress in 0.75f..0.85f -> 0.5f  // Second breakdown
                    progress in 0.85f..0.95f -> 0.9f  // Final drop
                    else -> 0.8f * (1.0f - (progress - 0.95f) / 0.05f)
                }

                val beatPulse = (sin(i.toDouble() * 0.4 + seed) * 0.5 + 0.5).toFloat()
                val subPulse = (sin(i.toDouble() * 0.1 + seed) * 0.3 + 0.7).toFloat()
                val highNoise = ((i * 37 % 100) / 100f) * 0.3f

                val lowVal = (envelope * (0.6f + beatPulse * 0.4f)).coerceIn(0.1f, 1.0f)
                val midVal = (envelope * 0.7f * subPulse).coerceIn(0.1f, 0.9f)
                val highVal = (envelope * (0.3f + highNoise)).coerceIn(0.05f, 0.85f)

                low.add(lowVal)
                mid.add(midVal)
                high.add(highVal)
                full.add(((lowVal + midVal + highVal) / 2.2f).coerceIn(0.1f, 1.0f))
            }
            return Triple(full, low, mid)
        }

        private val wf1 = generateRealisticWaveform(200, 1.2)
        private val wf2 = generateRealisticWaveform(200, 3.4)
        private val wf3 = generateRealisticWaveform(200, 5.6)
        private val wf4 = generateRealisticWaveform(200, 7.8)
        private val wf5 = generateRealisticWaveform(200, 9.0)
        private val wf6 = generateRealisticWaveform(200, 2.1)
        private val wf7 = generateRealisticWaveform(200, 4.3)
        private val wf8 = generateRealisticWaveform(200, 6.5)

        val PRELOADED_TRACKS: List<Track> = listOf(
            Track(
                id = "track_fisher_lose_control",
                title = "Lose Control (Extended Mix)",
                artist = "Fisher & Chris Lake",
                album = "Club Anthems Vol. 4",
                genre = "Tech House",
                bpm = 124.0,
                key = "7A",
                musicalKey = "D Minor",
                durationSec = 348.2,
                rating = 5,
                energy = 88,
                colorHex = 0xFFFF5252,
                waveformPeaks = wf1.first,
                lowPeaks = wf1.second,
                midPeaks = wf1.third,
                highPeaks = wf1.second.map { it * 0.7f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Intro Kick", 0xFFFF5252),
                    HotCue(1, 31.0, "Vocal Build", 0xFF00E5FF),
                    HotCue(2, 62.0, "MAIN DROP", 0xFFFFD600),
                    HotCue(3, 155.0, "Breakdown", 0xFF00E676),
                    HotCue(4, 217.0, "Second Drop", 0xFFB388FF),
                    HotCue(5, 279.0, "Outro 32", 0xFFFF9100)
                )
            ),
            Track(
                id = "track_candi_you_got_love",
                title = "You Got The Love (Original Mix)",
                artist = "Candi Staton & The Source",
                album = "House Classics Remastered",
                genre = "Classic House",
                bpm = 124.0,
                key = "12A",
                musicalKey = "D-flat Minor",
                durationSec = 395.1,
                rating = 5,
                energy = 82,
                colorHex = 0xFF00E5FF,
                waveformPeaks = wf2.first,
                lowPeaks = wf2.second,
                midPeaks = wf2.third,
                highPeaks = wf2.second.map { it * 0.65f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Beat 1", 0xFFFF5252),
                    HotCue(1, 15.5, "Acappella Start", 0xFF00E5FF),
                    HotCue(2, 46.5, "Bass Drop", 0xFFFFD600),
                    HotCue(3, 124.0, "Choir Peak", 0xFF00E676)
                )
            ),
            Track(
                id = "track_kideko_make_it_right",
                title = "Make It Right (Extended Mix)",
                artist = "Kideko",
                album = "Ministry of Sound",
                genre = "Bass House",
                bpm = 126.0,
                key = "2A",
                musicalKey = "E-flat Minor",
                durationSec = 299.0,
                rating = 5,
                energy = 91,
                colorHex = 0xFF00E676,
                waveformPeaks = wf3.first,
                lowPeaks = wf3.second,
                midPeaks = wf3.third,
                highPeaks = wf3.second.map { it * 0.8f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Intro", 0xFFFF5252),
                    HotCue(1, 30.5, "Buildup", 0xFF00E5FF),
                    HotCue(2, 61.0, "DROP", 0xFFFFD600)
                )
            ),
            Track(
                id = "track_elderbrook_about_that",
                title = "About That (Original Club Mix)",
                artist = "Elderbrook",
                album = "Inner Light",
                genre = "Melodic House",
                bpm = 123.0,
                key = "9A",
                musicalKey = "E Minor",
                durationSec = 372.4,
                rating = 5,
                energy = 76,
                colorHex = 0xFFFFAB00,
                waveformPeaks = wf4.first,
                lowPeaks = wf4.second,
                midPeaks = wf4.third,
                highPeaks = wf4.second.map { it * 0.5f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Intro 16", 0xFFFF5252),
                    HotCue(1, 46.8, "Vocal", 0xFF00E5FF),
                    HotCue(2, 93.6, "Groove", 0xFFFFD600)
                )
            ),
            Track(
                id = "track_fatboy_praise_you",
                title = "Praise You (Purple Disco Machine Remix)",
                artist = "Fatboy Slim & PDM",
                album = "Club Disco Essentials",
                genre = "Nu-Disco / House",
                bpm = 125.0,
                key = "2A",
                musicalKey = "E-flat Minor",
                durationSec = 337.0,
                rating = 5,
                energy = 84,
                colorHex = 0xFFB388FF,
                waveformPeaks = wf5.first,
                lowPeaks = wf5.second,
                midPeaks = wf5.third,
                highPeaks = wf5.second.map { it * 0.75f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Piano Hook", 0xFFFF5252),
                    HotCue(1, 30.7, "Funky Bass", 0xFF00E5FF),
                    HotCue(2, 61.4, "Full Drop", 0xFFFFD600)
                )
            ),
            Track(
                id = "track_solardo_i_need_you",
                title = "I Need You (Extended Mix)",
                artist = "Solardo & Eli Brown",
                album = "Sola Records",
                genre = "Tech House",
                bpm = 126.0,
                key = "4A",
                musicalKey = "F Minor",
                durationSec = 356.2,
                rating = 4,
                energy = 89,
                colorHex = 0xFFFF5252,
                waveformPeaks = wf6.first,
                lowPeaks = wf6.second,
                midPeaks = wf6.third,
                highPeaks = wf6.second.map { it * 0.7f }
            ),
            Track(
                id = "track_camelphat_higher",
                title = "Higher (Extended Mix)",
                artist = "Chris Lake & CamelPhat",
                album = "Black Book Records",
                genre = "Tech House",
                bpm = 124.0,
                key = "8A",
                musicalKey = "A Minor",
                durationSec = 451.0,
                rating = 5,
                energy = 87,
                colorHex = 0xFF00E5FF,
                waveformPeaks = wf7.first,
                lowPeaks = wf7.second,
                midPeaks = wf7.third,
                highPeaks = wf7.second.map { it * 0.8f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Intro", 0xFFFF5252),
                    HotCue(1, 62.0, "Lead Drop", 0xFFFFD600)
                )
            ),
            Track(
                id = "track_anyma_hypnotized",
                title = "Hypnotized (Original Mix)",
                artist = "Anyma & Chris Avantgarde",
                album = "Afterlife Odyssey",
                genre = "Melodic Techno",
                bpm = 125.0,
                key = "6A",
                musicalKey = "G Minor",
                durationSec = 400.0,
                rating = 5,
                energy = 94,
                colorHex = 0xFFD500F9,
                waveformPeaks = wf8.first,
                lowPeaks = wf8.second,
                midPeaks = wf8.third,
                highPeaks = wf8.second.map { it * 0.9f },
                hotCues = listOf(
                    HotCue(0, 0.0, "Sub Kick", 0xFFFF5252),
                    HotCue(1, 61.4, "Synth Arp", 0xFF00E5FF),
                    HotCue(2, 122.8, "CLIMAX DROP", 0xFFFFD600)
                )
            ),
            Track(
                id = "track_vintage_culture_freak",
                title = "Freak (Extended Club Mix)",
                artist = "Vintage Culture",
                album = "Promised Land",
                genre = "Deep House",
                bpm = 123.0,
                key = "1A",
                musicalKey = "A-flat Minor",
                durationSec = 320.0,
                rating = 4,
                energy = 80,
                colorHex = 0xFFFFD600,
                waveformPeaks = wf1.first,
                lowPeaks = wf1.second,
                midPeaks = wf1.third,
                highPeaks = wf1.second.map { it * 0.6f }
            ),
            Track(
                id = "track_dimension_dj_turn_it_up",
                title = "DJ Turn It Up (Extended Mix)",
                artist = "Dimension",
                album = "Organ World",
                genre = "Drum & Bass",
                bpm = 174.0,
                key = "8A",
                musicalKey = "A Minor",
                durationSec = 224.0,
                rating = 5,
                energy = 98,
                colorHex = 0xFFFF1744,
                waveformPeaks = wf3.first,
                lowPeaks = wf3.second,
                midPeaks = wf3.third,
                highPeaks = wf3.second.map { it * 0.95f }
            )
        )
    }
}

private fun Track.toEntity(): TrackEntity {
    return TrackEntity(
        id = id,
        title = title,
        artist = artist,
        album = album,
        genre = genre,
        bpm = bpm,
        musicalKey = musicalKey,
        camelotKey = key,
        durationSec = durationSec,
        rating = rating,
        energy = energy,
        colorHex = colorHex,
        waveformDataCsv = waveformPeaks.joinToString(","),
        lowDataCsv = lowPeaks.joinToString(","),
        midDataCsv = midPeaks.joinToString(","),
        highDataCsv = highPeaks.joinToString(",")
    )
}

private fun TrackEntity.toDomain(): Track {
    fun parseCsv(csv: String): List<Float> {
        if (csv.isBlank()) return emptyList()
        return csv.split(",").mapNotNull { it.toFloatOrNull() }
    }
    return Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        genre = genre,
        bpm = bpm,
        key = camelotKey,
        musicalKey = musicalKey,
        durationSec = durationSec,
        rating = rating,
        energy = energy,
        colorHex = colorHex,
        waveformPeaks = parseCsv(waveformDataCsv),
        lowPeaks = parseCsv(lowDataCsv),
        midPeaks = parseCsv(midDataCsv),
        highPeaks = parseCsv(highDataCsv)
    )
}
