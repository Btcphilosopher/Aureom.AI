package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TrackEntity::class,
        PlaylistEntity::class,
        HistoryEntryEntity::class,
        RecordingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DJDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun historyDao(): HistoryDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile
        private var INSTANCE: DJDatabase? = null

        fun getInstance(context: Context): DJDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DJDatabase::class.java,
                    "macdj_workstation.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
