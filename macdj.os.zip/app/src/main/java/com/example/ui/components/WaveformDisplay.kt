package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckState
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.WaveformHigh
import com.example.ui.theme.WaveformLow
import com.example.ui.theme.WaveformMid
import java.util.Locale

@Composable
fun WaveformDisplay(
    deckState: DeckState,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier,
    isMasterWaveform: Boolean = false
) {
    val track = deckState.track
    val totalSec = track?.durationSec ?: 300.0
    val currentSec = deckState.playheadPositionSec
    val progress = (currentSec / totalSec).toFloat().coerceIn(0f, 1f)

    val remainSec = totalSec - currentSec
    val elapsedStr = String.format(Locale.US, "%02d:%04.1f", (currentSec / 60).toInt(), currentSec % 60)
    val remainStr = String.format(Locale.US, "-%02d:%04.1f", (remainSec / 60).toInt(), remainSec % 60)

    Box(
        modifier = modifier
            .background(DJBackground, RoundedCornerShape(6.dp))
            .pointerInput(totalSec) {
                detectTapGestures { offset ->
                    val seekProgress = (offset.x / size.width).coerceIn(0f, 1f)
                    onSeek(seekProgress * totalSec)
                }
            }
            .pointerInput(totalSec) {
                detectDragGestures { change, _ ->
                    val seekProgress = (change.position.x / size.width).coerceIn(0f, 1f)
                    onSeek(seekProgress * totalSec)
                }
            }
            .testTag("waveform_${deckState.deckId.name.lowercase()}")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerY = canvasHeight / 2f

            // Draw subtle beat grid background
            val bpm = if (deckState.targetBpm > 0) deckState.targetBpm else 124.0
            val totalBeats = (totalSec * (bpm / 60.0)).toInt()
            val pixelsPerBeat = canvasWidth / totalBeats.coerceAtLeast(1)

            val beatStep = if (pixelsPerBeat < 4f) 16 else if (pixelsPerBeat < 10f) 8 else 4
            for (b in 0..totalBeats step beatStep) {
                val x = b * pixelsPerBeat
                val isDownbeat = (b % 32 == 0)
                drawLine(
                    color = if (isDownbeat) Color(0x33FFFFFF) else Color(0x15FFFFFF),
                    start = Offset(x, 0f),
                    end = Offset(x, canvasHeight),
                    strokeWidth = if (isDownbeat) 1.5f else 0.8f
                )
            }

            // Draw multi-frequency RGB waveform peaks
            val peaks = track?.waveformPeaks ?: emptyList()
            val lowPeaks = track?.lowPeaks ?: emptyList()
            val midPeaks = track?.midPeaks ?: emptyList()

            if (peaks.isNotEmpty()) {
                val barWidth = canvasWidth / peaks.size
                for (i in peaks.indices) {
                    val x = i * barWidth
                    val amp = peaks[i].coerceIn(0.05f, 1f)
                    val lowAmp = if (i < lowPeaks.size) lowPeaks[i] else amp * 0.5f
                    val midAmp = if (i < midPeaks.size) midPeaks[i] else amp * 0.3f

                    val barHeight = amp * centerY * 0.92f
                    val isPast = (x / canvasWidth) <= progress

                    // Frequency-based color mapping: Bass = Red/Orange, Mid = Amber, Treble = Cyan
                    val barColor = when {
                        !isPast -> Color(0x4426334A)
                        lowAmp > 0.6f -> WaveformLow
                        midAmp > 0.5f -> WaveformMid
                        else -> WaveformHigh
                    }

                    // Top and bottom symmetrical waveform mirror
                    drawRect(
                        color = barColor,
                        topLeft = Offset(x, centerY - barHeight),
                        size = Size(barWidth.coerceAtLeast(1.2f), barHeight * 2f)
                    )
                }
            } else {
                // Placeholder simulated waveform
                val numBars = (canvasWidth / 3f).toInt()
                for (i in 0 until numBars) {
                    val x = i * 3f
                    val simulatedAmp = kotlin.math.sin(i * 0.15).toFloat() * 0.5f + 0.5f
                    val barHeight = simulatedAmp * centerY * 0.8f
                    val isPast = (x / canvasWidth) <= progress

                    drawRect(
                        color = if (isPast) DJNeonCyan else Color(0x33384357),
                        topLeft = Offset(x, centerY - barHeight),
                        size = Size(2f, barHeight * 2f)
                    )
                }
            }

            // Draw Loop region overlay if active
            val loop = deckState.loopState
            if (loop.isActive && loop.outPositionSec > loop.inPositionSec) {
                val loopStartX = (loop.inPositionSec / totalSec).toFloat() * canvasWidth
                val loopEndX = (loop.outPositionSec / totalSec).toFloat() * canvasWidth
                drawRect(
                    color = Color(0x3300E676),
                    topLeft = Offset(loopStartX, 0f),
                    size = Size(loopEndX - loopStartX, canvasHeight)
                )
                drawLine(
                    color = DJNeonGreen,
                    start = Offset(loopStartX, 0f),
                    end = Offset(loopStartX, canvasHeight),
                    strokeWidth = 2f
                )
                drawLine(
                    color = DJNeonGreen,
                    start = Offset(loopEndX, 0f),
                    end = Offset(loopEndX, canvasHeight),
                    strokeWidth = 2f
                )
            }

            // Draw Hot Cue Markers
            for (cue in deckState.hotCues) {
                if (!cue.isActive) continue
                val cueX = (cue.positionSec / totalSec).toFloat() * canvasWidth
                val cueColor = Color(cue.colorHex)

                drawLine(
                    color = cueColor,
                    start = Offset(cueX, 0f),
                    end = Offset(cueX, canvasHeight),
                    strokeWidth = 2f
                )
                // Draw cue triangular flag
                drawRect(
                    color = cueColor,
                    topLeft = Offset(cueX, 0f),
                    size = Size(10f, 10f)
                )
            }

            // Draw Playhead cursor
            val playheadX = progress * canvasWidth
            drawLine(
                color = Color.White,
                start = Offset(playheadX, 0f),
                end = Offset(playheadX, canvasHeight),
                strokeWidth = 2.5f
            )

            // Playhead triangle cursor top and bottom
            drawRect(
                color = DJNeonCyan,
                topLeft = Offset(playheadX - 4f, 0f),
                size = Size(8f, 6f)
            )
            drawRect(
                color = DJNeonCyan,
                topLeft = Offset(playheadX - 4f, canvasHeight - 6f),
                size = Size(8f, 6f)
            )
        }

        // Time indicators overlay
        if (!isMasterWaveform) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = elapsedStr,
                    color = DJTextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Box(modifier = Modifier.weight(1f))
                Text(
                    text = remainStr,
                    color = DJTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
