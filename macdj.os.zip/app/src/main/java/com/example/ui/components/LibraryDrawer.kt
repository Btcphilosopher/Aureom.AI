package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.PlaylistEntity
import com.example.model.DeckId
import com.example.model.Track
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJSurfaceCard
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary
import com.example.ui.theme.DeckAColor
import com.example.ui.theme.DeckBColor
import java.util.Locale

@Composable
fun LibraryDrawer(
    tracks: List<Track>,
    playlists: List<PlaylistEntity>,
    onLoadTrackToDeck: (Track, DeckId) -> Unit,
    onAISearch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Collection") }

    val filteredTracks = remember(tracks, searchQuery) {
        if (searchQuery.isBlank()) {
            tracks
        } else {
            val q = searchQuery.lowercase()
            tracks.filter {
                it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.genre.lowercase().contains(q) ||
                it.key.lowercase().contains(q) ||
                it.bpm.toString().contains(q)
            }
        }
    }

    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(8.dp))
            .padding(8.dp)
            .testTag("library_drawer")
    ) {
        // Top Toolbar: Search Bar & Smart AI Query
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Search Input Field
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(DJBackground)
                    .border(1.dp, DJBorderSubtle, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = DJTextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    textStyle = TextStyle(color = DJTextPrimary, fontSize = 11.sp),
                    cursorBrush = SolidColor(DJNeonCyan),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (searchQuery.isEmpty()) {
                            Text("Search title, artist, BPM, Camelot Key (e.g. 8A, 125)", color = DJTextMuted, fontSize = 10.sp)
                        }
                        innerTextField()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("library_search_input")
                )
            }

            // AI Natural Language Search Button
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x3300F0FF))
                    .border(1.dp, DJNeonCyan, RoundedCornerShape(6.dp))
                    .clickable {
                        onAISearch(if (searchQuery.isNotBlank()) searchQuery else "Find high energy 124 BPM melodic tracks")
                    }
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Search",
                        tint = DJNeonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI FILTER", color = DJNeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Library Body: Side Categories & Track Table
        Row(modifier = Modifier.fillMaxSize()) {
            // Left Categories Sidebar
            Column(
                modifier = Modifier
                    .width(110.dp)
                    .fillMaxHeight()
                    .background(DJBackground, RoundedCornerShape(6.dp))
                    .padding(4.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                val categories = listOf("Collection", "Playlists", "Hot Cue Bank", "History")
                for (cat in categories) {
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) DJSurfaceElevated else Color.Transparent)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = cat,
                            color = if (isSel) DJNeonCyan else DJTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${filteredTracks.size} Tracks",
                    color = DJTextMuted,
                    fontSize = 8.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Right Track Table
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(22.dp)
                        .background(DJSurfaceCard, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TITLE / ARTIST", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                    Text("BPM", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                    Text("KEY", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp))
                    Text("TIME", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                    Text("ENERGY", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(45.dp))
                    Text("LOAD", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp))
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Track Rows
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(filteredTracks, key = { it.id }) { track ->
                        TrackRow(
                            track = track,
                            onLoadDeckA = { onLoadTrackToDeck(track, DeckId.DECK_A) },
                            onLoadDeckB = { onLoadTrackToDeck(track, DeckId.DECK_B) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrackRow(
    track: Track,
    onLoadDeckA: () -> Unit,
    onLoadDeckB: () -> Unit
) {
    val durationMin = (track.durationSec / 60).toInt()
    val durationSec = (track.durationSec % 60).toInt()
    val timeStr = String.format(Locale.US, "%02d:%02d", durationMin, durationSec)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(DJBackground)
            .border(0.5.dp, DJBorderSubtle, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Title & Artist
        Column(modifier = Modifier.weight(2f)) {
            Text(
                text = track.title,
                color = DJTextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = "${track.artist} • ${track.genre}",
                color = DJTextSecondary,
                fontSize = 8.sp,
                maxLines = 1
            )
        }

        // BPM
        Text(
            text = String.format(Locale.US, "%.1f", track.bpm),
            color = DJTextPrimary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.width(42.dp)
        )

        // Camelot Key Badge
        Box(
            modifier = Modifier
                .width(30.dp)
                .height(16.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0x3300E5FF))
                .border(0.5.dp, DJNeonCyan, RoundedCornerShape(3.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = track.key,
                color = DJNeonCyan,
                fontSize = 8.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Time
        Text(
            text = timeStr,
            color = DJTextSecondary,
            fontSize = 8.5.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(42.dp)
        )

        // Energy Bar
        Row(
            modifier = Modifier.width(45.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0x33FFFFFF))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(track.energy / 100f)
                        .background(if (track.energy > 88) DJNeonAmber else DJNeonGreen)
                )
            }
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = "${track.energy}",
                color = DJTextMuted,
                fontSize = 7.sp
            )
        }

        // Load Buttons
        Row(
            modifier = Modifier.width(64.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            // Load to Deck A
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(20.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(DeckAColor.copy(alpha = 0.8f))
                    .clickable { onLoadDeckA() }
                    .testTag("load_deck_a_${track.id}"),
                contentAlignment = Alignment.Center
            ) {
                Text("A", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
            }

            // Load to Deck B
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(20.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(DeckBColor.copy(alpha = 0.8f))
                    .clickable { onLoadDeckB() }
                    .testTag("load_deck_b_${track.id}"),
                contentAlignment = Alignment.Center
            ) {
                Text("B", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}
