package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AIDJService
import com.example.audio.DJAudioEngine
import com.example.audio.MasterRecorder
import com.example.data.DJRepository
import com.example.data.db.DJDatabase
import com.example.data.db.PlaylistEntity
import com.example.model.AIDJTransitionAdvice
import com.example.model.AISetProposal
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.MixerMasterState
import com.example.model.PerformanceTab
import com.example.model.SamplerPadState
import com.example.model.SavedRecording
import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class DJViewModel(application: Application) : AndroidViewModel(application) {

    private val db = DJDatabase.getInstance(application)
    private val repository = DJRepository(db)
    private val aiService = AIDJService()
    private val masterRecorder = MasterRecorder(application)

    // Audio Engine
    private val audioEngine: DJAudioEngine

    // Decks State
    private val _deckA = MutableStateFlow(DeckState(deckId = DeckId.DECK_A))
    val deckA: StateFlow<DeckState> = _deckA.asStateFlow()

    private val _deckB = MutableStateFlow(DeckState(deckId = DeckId.DECK_B))
    val deckB: StateFlow<DeckState> = _deckB.asStateFlow()

    private val _deckC = MutableStateFlow(DeckState(deckId = DeckId.DECK_C))
    val deckC: StateFlow<DeckState> = _deckC.asStateFlow()

    private val _deckD = MutableStateFlow(DeckState(deckId = DeckId.DECK_D))
    val deckD: StateFlow<DeckState> = _deckD.asStateFlow()

    // Master Mixer State
    private val _masterState = MutableStateFlow(MixerMasterState())
    val masterState: StateFlow<MixerMasterState> = _masterState.asStateFlow()

    // UI Performance Dock State
    private val _selectedDeckForPerformance = MutableStateFlow(DeckId.DECK_A)
    val selectedDeckForPerformance: StateFlow<DeckId> = _selectedDeckForPerformance.asStateFlow()

    private val _selectedPerformanceTab = MutableStateFlow(PerformanceTab.HOT_CUES)
    val selectedPerformanceTab: StateFlow<PerformanceTab> = _selectedPerformanceTab.asStateFlow()

    // Sampler Pads Matrix (16 pads)
    private val _samplerPads = MutableStateFlow(createDefaultSamplerPads())
    val samplerPads: StateFlow<List<SamplerPadState>> = _samplerPads.asStateFlow()

    // Library Data
    val allTracks: StateFlow<List<Track>> = MutableStateFlow(DJRepository.PRELOADED_TRACKS).apply {
        viewModelScope.launch {
            repository.allTracks.collect { value = it }
        }
    }
    val allPlaylists: StateFlow<List<PlaylistEntity>> = MutableStateFlow<List<PlaylistEntity>>(emptyList()).apply {
        viewModelScope.launch {
            repository.allPlaylists.collect { value = it }
        }
    }
    val savedRecordings: StateFlow<List<SavedRecording>> = MutableStateFlow<List<SavedRecording>>(emptyList()).apply {
        viewModelScope.launch {
            repository.allRecordings.collect { value = it }
        }
    }

    // Modal Overlays
    private val _isLibraryOpen = MutableStateFlow(false)
    val isLibraryOpen: StateFlow<Boolean> = _isLibraryOpen.asStateFlow()

    private val _isAIAssistantOpen = MutableStateFlow(false)
    val isAIAssistantOpen: StateFlow<Boolean> = _isAIAssistantOpen.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _is4DeckMode = MutableStateFlow(false)
    val is4DeckMode: StateFlow<Boolean> = _is4DeckMode.asStateFlow()

    // AI Intelligence State
    private val _harmonicAdvice = MutableStateFlow<AIDJTransitionAdvice?>(null)
    val harmonicAdvice: StateFlow<AIDJTransitionAdvice?> = _harmonicAdvice.asStateFlow()

    private val _setProposal = MutableStateFlow<AISetProposal?>(null)
    val setProposal: StateFlow<AISetProposal?> = _setProposal.asStateFlow()

    private val _aiResponseText = MutableStateFlow("")
    val aiResponseText: StateFlow<String> = _aiResponseText.asStateFlow()

    private val _isAILoading = MutableStateFlow(false)
    val isAILoading: StateFlow<Boolean> = _isAILoading.asStateFlow()

    // Playback Ticker Job
    private var playbackTickerJob: Job? = null
    private var recordingTimerJob: Job? = null

    init {
        audioEngine = DJAudioEngine { deckVuMap, masterVu, clipping ->
            // Update Deck VU levels
            deckVuMap[DeckId.DECK_A]?.let { _deckA.value = _deckA.value.copy(vuLevelLeft = it.first, vuLevelRight = it.second) }
            deckVuMap[DeckId.DECK_B]?.let { _deckB.value = _deckB.value.copy(vuLevelLeft = it.first, vuLevelRight = it.second) }
            deckVuMap[DeckId.DECK_C]?.let { _deckC.value = _deckC.value.copy(vuLevelLeft = it.first, vuLevelRight = it.second) }
            deckVuMap[DeckId.DECK_D]?.let { _deckD.value = _deckD.value.copy(vuLevelLeft = it.first, vuLevelRight = it.second) }

            // Update Master VU
            _masterState.value = _masterState.value.copy(
                masterVuLeft = masterVu.first,
                masterVuRight = masterVu.second,
                masterClipping = clipping
            )
        }

        audioEngine.onAudioFrameRecorded = { bytes ->
            masterRecorder.writeAudioData(bytes)
        }

        viewModelScope.launch {
            repository.initializePreloadedDataIfEmpty()
            // Load initial tracks into Deck A and Deck B
            val initialTracks = DJRepository.PRELOADED_TRACKS
            if (initialTracks.isNotEmpty()) {
                loadTrackToDeck(initialTracks[0], DeckId.DECK_A)
            }
            if (initialTracks.size > 1) {
                loadTrackToDeck(initialTracks[1], DeckId.DECK_B)
            }

            audioEngine.start()
            startPlaybackTicker()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stop()
    }

    private fun startPlaybackTicker() {
        playbackTickerJob?.cancel()
        playbackTickerJob = viewModelScope.launch(Dispatchers.Default) {
            val intervalMs = 25L
            val intervalSec = intervalMs / 1000.0

            while (isActive) {
                val decks = listOf(_deckA, _deckB, _deckC, _deckD)
                for (deckFlow in decks) {
                    val current = deckFlow.value
                    if (current.isPlaying && current.track != null) {
                        val pitchFactor = (1.0 + current.pitchPercent / 100.0)
                        val advance = intervalSec * pitchFactor
                        var nextPos = current.playheadPositionSec + advance

                        // Handle loop wrap
                        val loop = current.loopState
                        if (loop.isActive && loop.outPositionSec > loop.inPositionSec) {
                            if (nextPos >= loop.outPositionSec) {
                                nextPos = loop.inPositionSec + (nextPos - loop.outPositionSec)
                            }
                        }

                        // Rotate jog angle (1 rotation per 1.8 sec)
                        val angleAdvance = (360.0 * (advance / 1.8)).toFloat()
                        val nextAngle = (current.jogAngle + angleAdvance) % 360f

                        val updated = current.copy(
                            playheadPositionSec = nextPos,
                            jogAngle = nextAngle
                        )
                        deckFlow.value = updated
                        audioEngine.updateDeckState(updated)
                    }
                }
                delay(intervalMs)
            }
        }
    }

    fun loadTrackToDeck(track: Track, deckId: DeckId) {
        val newState = DeckState(
            deckId = deckId,
            track = track,
            targetBpm = track.bpm,
            hotCues = track.hotCues,
            playheadPositionSec = 0.0
        )
        when (deckId) {
            DeckId.DECK_A -> _deckA.value = newState
            DeckId.DECK_B -> _deckB.value = newState
            DeckId.DECK_C -> _deckC.value = newState
            DeckId.DECK_D -> _deckD.value = newState
        }
        audioEngine.updateDeckState(newState)
        updateHarmonicAdvice()
    }

    fun updateDeck(state: DeckState) {
        when (state.deckId) {
            DeckId.DECK_A -> _deckA.value = state
            DeckId.DECK_B -> _deckB.value = state
            DeckId.DECK_C -> _deckC.value = state
            DeckId.DECK_D -> _deckD.value = state
        }
        audioEngine.updateDeckState(state)
    }

    fun togglePlayPause(deckId: DeckId) {
        val current = getDeckState(deckId)
        val updated = current.copy(isPlaying = !current.isPlaying)
        updateDeck(updated)
    }

    fun cueDeck(deckId: DeckId) {
        val current = getDeckState(deckId)
        if (current.isPlaying) {
            // Pause and return to first cue or start
            val targetPos = current.hotCues.firstOrNull()?.positionSec ?: 0.0
            updateDeck(current.copy(isPlaying = false, playheadPositionSec = targetPos))
        } else {
            // Jump to start/cue and momentary trigger
            val targetPos = current.hotCues.firstOrNull()?.positionSec ?: 0.0
            updateDeck(current.copy(playheadPositionSec = targetPos))
        }
    }

    fun toggleSync(deckId: DeckId) {
        val current = getDeckState(deckId)
        val isNowSync = !current.isSyncEnabled
        if (isNowSync) {
            // Sync to Master BPM (e.g. from opposite deck)
            val masterBpm = if (deckId == DeckId.DECK_A) _deckB.value.targetBpm else _deckA.value.targetBpm
            val pitchDelta = ((masterBpm / current.track?.bpm!!) - 1.0) * 100.0
            updateDeck(current.copy(isSyncEnabled = true, pitchPercent = pitchDelta.toFloat()))
        } else {
            updateDeck(current.copy(isSyncEnabled = false))
        }
    }

    fun handleScratch(deckId: DeckId, velocity: Float) {
        val current = getDeckState(deckId)
        val newAngle = (current.jogAngle + velocity * 15f) % 360f
        val newPos = (current.playheadPositionSec + velocity * 0.05).coerceAtLeast(0.0)
        val updated = current.copy(
            jogAngle = newAngle,
            scratchVelocity = velocity,
            playheadPositionSec = newPos
        )
        updateDeck(updated)
    }

    fun seekDeck(deckId: DeckId, targetSec: Double) {
        val current = getDeckState(deckId)
        updateDeck(current.copy(playheadPositionSec = targetSec))
    }

    fun updateMaster(state: MixerMasterState) {
        _masterState.value = state
        audioEngine.updateMasterState(state)
    }

    fun triggerSampler(pad: SamplerPadState) {
        audioEngine.triggerSamplerPad(pad)
    }

    fun toggleRecording() {
        val current = _masterState.value
        if (current.isRecording) {
            // Stop recording
            recordingTimerJob?.cancel()
            viewModelScope.launch {
                val recording = masterRecorder.stopRecording()
                if (recording != null) {
                    repository.saveRecording(recording)
                }
                _masterState.value = _masterState.value.copy(
                    isRecording = false,
                    recordingTimeFormatted = "00:00:00"
                )
            }
        } else {
            // Start recording
            val tracks = listOfNotNull(_deckA.value.track?.title, _deckB.value.track?.title)
            masterRecorder.startRecording(tracks)
            _masterState.value = _masterState.value.copy(isRecording = true)

            recordingTimerJob?.cancel()
            val startMs = System.currentTimeMillis()
            recordingTimerJob = viewModelScope.launch {
                while (_masterState.value.isRecording) {
                    val elapsed = (System.currentTimeMillis() - startMs) / 1000
                    val formatted = String.format(Locale.US, "%02d:%02d:%02d", elapsed / 3600, (elapsed % 3600) / 60, elapsed % 60)
                    _masterState.value = _masterState.value.copy(recordingTimeFormatted = formatted)
                    delay(1000L)
                }
            }
        }
    }

    fun selectDeckForPerformance(deckId: DeckId) {
        _selectedDeckForPerformance.value = deckId
    }

    fun selectPerformanceTab(tab: PerformanceTab) {
        _selectedPerformanceTab.value = tab
    }

    fun toggleLibrary(open: Boolean? = null) {
        _isLibraryOpen.value = open ?: !_isLibraryOpen.value
    }

    fun toggleAIAssistant(open: Boolean? = null) {
        _isAIAssistantOpen.value = open ?: !_isAIAssistantOpen.value
    }

    fun toggleSettings(open: Boolean? = null) {
        _isSettingsOpen.value = open ?: !_isSettingsOpen.value
    }

    fun toggle4DeckMode() {
        _is4DeckMode.value = !_is4DeckMode.value
    }

    fun sendAIPrompt(prompt: String) {
        viewModelScope.launch {
            _isAILoading.value = true
            val tracks = allTracks.value
            val response = aiService.queryGeminiDJ(prompt, tracks)
            _aiResponseText.value = response
            _isAILoading.value = false
        }
    }

    fun generateAISet() {
        val proposal = aiService.buildSmartSet(allTracks.value)
        _setProposal.value = proposal
    }

    private fun updateHarmonicAdvice() {
        val tA = _deckA.value.track
        val tB = _deckB.value.track
        if (tA != null && tB != null) {
            _harmonicAdvice.value = aiService.calculateHarmonicCompatibility(tA, tB)
        }
    }

    private fun getDeckState(deckId: DeckId): DeckState {
        return when (deckId) {
            DeckId.DECK_A -> _deckA.value
            DeckId.DECK_B -> _deckB.value
            DeckId.DECK_C -> _deckC.value
            DeckId.DECK_D -> _deckD.value
        }
    }

    companion object {
        private fun createDefaultSamplerPads(): List<SamplerPadState> {
            return listOf(
                SamplerPadState(0, "KICK", "Drums", colorHex = 0xFFFF5252),
                SamplerPadState(1, "CLAP", "Drums", colorHex = 0xFFFFD600),
                SamplerPadState(2, "HAT", "Drums", colorHex = 0xFF00E5FF),
                SamplerPadState(3, "HIT", "Drums", colorHex = 0xFF00E676),
                SamplerPadState(4, "VOC 1", "Vocals", colorHex = 0xFFB388FF),
                SamplerPadState(5, "VOC 2", "Vocals", colorHex = 0xFFD500F9),
                SamplerPadState(6, "RISER", "FX", colorHex = 0xFFFF9100),
                SamplerPadState(7, "DROP", "FX", colorHex = 0xFFFF1744),
                SamplerPadState(8, "SIREN", "Classic", colorHex = 0xFFFF5252),
                SamplerPadState(9, "AIR HORN", "Classic", colorHex = 0xFFFFD600),
                SamplerPadState(10, "LASER", "Classic", colorHex = 0xFF00E5FF),
                SamplerPadState(11, "NOISE", "Classic", colorHex = 0xFF00E676),
                SamplerPadState(12, "SUB KICK", "Bass", colorHex = 0xFFB388FF),
                SamplerPadState(13, "OPEN HAT", "Drums", colorHex = 0xFFD500F9),
                SamplerPadState(14, "ACID 1", "Synth", colorHex = 0xFFFF9100),
                SamplerPadState(15, "ACID 2", "Synth", colorHex = 0xFFFF1744)
            )
        }
    }
}
