package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckState
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JogWheel(
    deckState: DeckState,
    onScratch: (velocity: Float) -> Unit,
    onNudge: (delta: Float) -> Unit,
    onPlayPause: () -> Unit,
    onCue: () -> Unit,
    onToggleSync: () -> Unit,
    onToggleKeyLock: () -> Unit,
    onToggleSlip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val deckColor = when (deckState.deckId) {
        com.example.model.DeckId.DECK_A -> com.example.ui.theme.DeckAColor
        com.example.model.DeckId.DECK_B -> com.example.ui.theme.DeckBColor
        com.example.model.DeckId.DECK_C -> com.example.ui.theme.DeckCColor
        com.example.model.DeckId.DECK_D -> com.example.ui.theme.DeckDColor
    }

    var lastTouchAngle by remember { mutableFloatStateOf(0f) }
    val animatedAngle by animateFloatAsState(
        targetValue = deckState.jogAngle,
        label = "jog_rotation"
    )

    Column(
        modifier = modifier.testTag("jog_wheel_${deckState.deckId.name.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Main Circular Turntable Platter
        Box(
            modifier = Modifier
                .size(190.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1E2638),
                            Color(0xFF121622),
                            Color(0xFF0A0C13)
                        )
                    )
                )
                .border(2.5.dp, DJBorder, CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val center = Offset(size.width / 2f, size.height / 2f)
                            lastTouchAngle = atan2(offset.y - center.y, offset.x - center.x)
                        },
                        onDrag = { change, _ ->
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val currentAngle = atan2(change.position.y - center.y, change.position.x - center.x)
                            var deltaAngle = currentAngle - lastTouchAngle
                            if (deltaAngle > PI) deltaAngle -= (2 * PI).toFloat()
                            if (deltaAngle < -PI) deltaAngle += (2 * PI).toFloat()
                            lastTouchAngle = currentAngle

                            val velocity = (deltaAngle * 10f).coerceIn(-4f, 4f)
                            onScratch(velocity)
                        },
                        onDragEnd = {
                            onScratch(0f)
                        },
                        onDragCancel = {
                            onScratch(0f)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f

                // Outer grip grooves (vinyl rings)
                for (r in listOf(0.92f, 0.86f, 0.80f, 0.74f)) {
                    drawCircle(
                        color = Color(0x18FFFFFF),
                        radius = radius * r,
                        center = center,
                        style = Stroke(width = 1f)
                    )
                }

                // Rotating needle LED position marker
                val needleAngleRad = (deckState.jogAngle * PI / 180.0).toFloat()
                val needleStart = Offset(
                    center.x + cos(needleAngleRad) * radius * 0.65f,
                    center.y + sin(needleAngleRad) * radius * 0.65f
                )
                val needleEnd = Offset(
                    center.x + cos(needleAngleRad) * radius * 0.94f,
                    center.y + sin(needleAngleRad) * radius * 0.94f
                )

                drawLine(
                    color = deckColor,
                    start = needleStart,
                    end = needleEnd,
                    strokeWidth = 3.5f,
                    cap = StrokeCap.Round
                )

                // Top reference position dot
                drawCircle(
                    color = Color.White,
                    radius = 3f,
                    center = Offset(center.x, center.y - radius * 0.94f)
                )
            }

            // Central LCD Display Screen
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF070A10))
                    .border(1.5.dp, Color(0xFF26334A), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // BPM Display
                    val bpm = deckState.targetBpm * (1.0 + deckState.pitchPercent / 100.0)
                    Text(
                        text = String.format(Locale.US, "%.2f", bpm),
                        color = DJTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Pitch %
                    val pitchSign = if (deckState.pitchPercent >= 0) "+" else ""
                    Text(
                        text = "$pitchSign${String.format(Locale.US, "%.1f", deckState.pitchPercent)}%  ±${deckState.pitchRange.toInt()}",
                        color = DJTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Status Badges (Key Lock / Slip)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MT",
                            color = if (deckState.isKeyLockEnabled) DJNeonCyan else DJTextMuted,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "SLIP",
                            color = if (deckState.isSlipModeEnabled) DJNeonAmber else DJTextMuted,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = deckState.track?.key ?: "8A",
                            color = deckColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Transport Controls: SYNC, SLIP, MT, CUE, PLAY
        Row(
            modifier = Modifier.width(190.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // SYNC Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (deckState.isSyncEnabled) DJNeonCyan else DJSurfaceDark)
                    .border(1.dp, if (deckState.isSyncEnabled) DJNeonCyan else DJBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleSync() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SYNC",
                    color = if (deckState.isSyncEnabled) Color.Black else DJTextPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // SLIP Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (deckState.isSlipModeEnabled) DJNeonAmber else DJSurfaceDark)
                    .border(1.dp, if (deckState.isSlipModeEnabled) DJNeonAmber else DJBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleSlip() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SLIP",
                    color = if (deckState.isSlipModeEnabled) Color.Black else DJTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // MT (Master Tempo / Key Lock) Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (deckState.isKeyLockEnabled) Color(0x3300F0FF) else DJSurfaceDark)
                    .border(1.dp, if (deckState.isKeyLockEnabled) DJNeonCyan else DJBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleKeyLock() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "MT",
                    color = if (deckState.isKeyLockEnabled) DJNeonCyan else DJTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Large CUE and PLAY/PAUSE backlit buttons
        Row(
            modifier = Modifier.width(190.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // CUE Button
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF2E2412),
                                Color(0xFF19140A)
                            )
                        )
                    )
                    .border(2.dp, DJNeonAmber, CircleShape)
                    .clickable { onCue() }
                    .testTag("cue_button_${deckState.deckId.name.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CUE",
                    color = DJNeonAmber,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // PLAY / PAUSE Button
            val isPlaying = deckState.isPlaying
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isPlaying) listOf(
                                Color(0xFF133B22),
                                Color(0xFF081C10)
                            ) else listOf(
                                Color(0xFF1E2838),
                                Color(0xFF101622)
                            )
                        )
                    )
                    .border(2.dp, if (isPlaying) DJNeonGreen else DJBorder, CircleShape)
                    .clickable { onPlayPause() }
                    .testTag("play_button_${deckState.deckId.name.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = if (isPlaying) DJNeonGreen else DJTextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
