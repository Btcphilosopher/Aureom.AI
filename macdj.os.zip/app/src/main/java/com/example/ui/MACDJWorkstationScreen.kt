package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.ui.components.AIDJAssistantPanel
import com.example.ui.components.JogWheel
import com.example.ui.components.LibraryDrawer
import com.example.ui.components.MixerSection
import com.example.ui.components.PerformancePadsContainer
import com.example.ui.components.SettingsAndMIDIPanel
import com.example.ui.components.WaveformDisplay
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJNeonRed
import com.example.ui.theme.DJSurfaceCard
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary
import com.example.ui.theme.DeckAColor
import com.example.ui.theme.DeckBColor
import java.util.Locale

@Composable
fun MACDJWorkstationScreen(
    viewModel: DJViewModel,
    modifier: Modifier = Modifier
) {
    val deckA by viewModel.deckA.collectAsState()
    val deckB by viewModel.deckB.collectAsState()
    val deckC by viewModel.deckC.collectAsState()
    val deckD by viewModel.deckD.collectAsState()
    val masterState by viewModel.masterState.collectAsState()

    val selectedDeckForPads by viewModel.selectedDeckForPerformance.collectAsState()
    val selectedTab by viewModel.selectedPerformanceTab.collectAsState()
    val samplerPads by viewModel.samplerPads.collectAsState()

    val allTracks by viewModel.allTracks.collectAsState()
    val allPlaylists by viewModel.allPlaylists.collectAsState()
    val recordings by viewModel.savedRecordings.collectAsState()

    val isLibraryOpen by viewModel.isLibraryOpen.collectAsState()
    val isAIAssistantOpen by viewModel.isAIAssistantOpen.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val is4DeckMode by viewModel.is4DeckMode.collectAsState()

    val harmonicAdvice by viewModel.harmonicAdvice.collectAsState()
    val setProposal by viewModel.setProposal.collectAsState()
    val aiResponseText by viewModel.aiResponseText.collectAsState()
    val isAILoading by viewModel.isAILoading.collectAsState()

    val activePadDeckState = when (selectedDeckForPads) {
        DeckId.DECK_A -> deckA
        DeckId.DECK_B -> deckB
        DeckId.DECK_C -> deckC
        DeckId.DECK_D -> deckD
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DJBackground)
            .testTag("macdj_workstation_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // 1. Top Pro DJ Workstation Menu Bar
            WorkstationTopBar(
                masterBpm = 124.0,
                isRecording = masterState.isRecording,
                recordingTime = masterState.recordingTimeFormatted,
                is4DeckMode = is4DeckMode,
                isLibraryOpen = isLibraryOpen,
                isAIOpen = isAIAssistantOpen,
                isSettingsOpen = isSettingsOpen,
                onToggleRecording = { viewModel.toggleRecording() },
                onToggle4Deck = { viewModel.toggle4DeckMode() },
                onToggleLibrary = { viewModel.toggleLibrary() },
                onToggleAI = { viewModel.toggleAIAssistant() },
                onToggleSettings = { viewModel.toggleSettings() }
            )

            // 2. Parallel Stacked Master Waveforms (Visual Beatmatching Phase Scope)
            ParallelStackedWaveforms(
                deckAState = deckA,
                deckBState = deckB,
                onSeekA = { viewModel.seekDeck(DeckId.DECK_A, it) },
                onSeekB = { viewModel.seekDeck(DeckId.DECK_B, it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            )

            // 3. Main Stage: Deck A | Central Mixer | Deck B
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Deck A Player
                DeckPlayerUnit(
                    deckState = deckA,
                    deckColor = DeckAColor,
                    onPlayPause = { viewModel.togglePlayPause(DeckId.DECK_A) },
                    onCue = { viewModel.cueDeck(DeckId.DECK_A) },
                    onToggleSync = { viewModel.toggleSync(DeckId.DECK_A) },
                    onToggleKeyLock = { viewModel.updateDeck(deckA.copy(isKeyLockEnabled = !deckA.isKeyLockEnabled)) },
                    onToggleSlip = { viewModel.updateDeck(deckA.copy(isSlipModeEnabled = !deckA.isSlipModeEnabled)) },
                    onScratch = { viewModel.handleScratch(DeckId.DECK_A, it) },
                    onPitchChange = { viewModel.updateDeck(deckA.copy(pitchPercent = it)) },
                    onSeek = { viewModel.seekDeck(DeckId.DECK_A, it) },
                    modifier = Modifier.weight(1.2f)
                )

                // Central DJ Mixer
                MixerSection(
                    deckAState = deckA,
                    deckBState = deckB,
                    masterState = masterState,
                    onUpdateDeckA = { viewModel.updateDeck(it) },
                    onUpdateDeckB = { viewModel.updateDeck(it) },
                    onUpdateMaster = { viewModel.updateMaster(it) },
                    modifier = Modifier.weight(1.1f)
                )

                // Deck B Player
                DeckPlayerUnit(
                    deckState = deckB,
                    deckColor = DeckBColor,
                    onPlayPause = { viewModel.togglePlayPause(DeckId.DECK_B) },
                    onCue = { viewModel.cueDeck(DeckId.DECK_B) },
                    onToggleSync = { viewModel.toggleSync(DeckId.DECK_B) },
                    onToggleKeyLock = { viewModel.updateDeck(deckB.copy(isKeyLockEnabled = !deckB.isKeyLockEnabled)) },
                    onToggleSlip = { viewModel.updateDeck(deckB.copy(isSlipModeEnabled = !deckB.isSlipModeEnabled)) },
                    onScratch = { viewModel.handleScratch(DeckId.DECK_B, it) },
                    onPitchChange = { viewModel.updateDeck(deckB.copy(pitchPercent = it)) },
                    onSeek = { viewModel.seekDeck(DeckId.DECK_B, it) },
                    modifier = Modifier.weight(1.2f)
                )
            }

            // 4. Lower Performance Dock Header & Pads Matrix
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.9f)
            ) {
                // Deck Target Selector Tabs: [DECK A] [DECK B] [DECK C] [DECK D]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val deckTabs = listOf(
                        DeckId.DECK_A to ("DECK A: " + (deckA.track?.title?.take(16) ?: "EMPTY")),
                        DeckId.DECK_B to ("DECK B: " + (deckB.track?.title?.take(16) ?: "EMPTY")),
                        DeckId.DECK_C to "DECK C",
                        DeckId.DECK_D to "DECK D"
                    )

                    for ((dId, label) in deckTabs) {
                        val isSel = selectedDeckForPads == dId
                        val dColor = when (dId) {
                            DeckId.DECK_A -> DeckAColor
                            DeckId.DECK_B -> DeckBColor
                            DeckId.DECK_C -> com.example.ui.theme.DeckCColor
                            DeckId.DECK_D -> com.example.ui.theme.DeckDColor
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(if (isSel) DJSurfaceDark else Color(0xFF0F141E))
                                .border(1.dp, if (isSel) dColor else DJBorderSubtle, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .clickable { viewModel.selectDeckForPerformance(dId) }
                                .padding(horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) dColor else DJTextMuted,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }

                // Performance Pads (Hot Cues, Loops/Slicer, Sampler, Stems, FX Unit)
                PerformancePadsContainer(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.selectPerformanceTab(it) },
                    activeDeckState = activePadDeckState,
                    onUpdateDeck = { viewModel.updateDeck(it) },
                    samplerPads = samplerPads,
                    onTriggerSamplerPad = { viewModel.triggerSampler(it) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Modal Overlay 1: Music Library Drawer
        AnimatedVisibility(
            visible = isLibraryOpen,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.72f)
                .align(Alignment.BottomCenter)
        ) {
            LibraryDrawer(
                tracks = allTracks,
                playlists = allPlaylists,
                onLoadTrackToDeck = { track, deckId ->
                    viewModel.loadTrackToDeck(track, deckId)
                    viewModel.toggleLibrary(false)
                },
                onAISearch = { query ->
                    viewModel.toggleLibrary(false)
                    viewModel.toggleAIAssistant(true)
                    viewModel.sendAIPrompt(query)
                }
            )
        }

        // Modal Overlay 2: AI DJ Assistant Co-Pilot
        AnimatedVisibility(
            visible = isAIAssistantOpen,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .align(Alignment.BottomCenter)
        ) {
            AIDJAssistantPanel(
                transitionAdvice = harmonicAdvice,
                setProposal = setProposal,
                aiResponseText = aiResponseText,
                isLoading = isAILoading,
                onSendPrompt = { viewModel.sendAIPrompt(it) },
                onGenerateSet = { viewModel.generateAISet() },
                onClose = { viewModel.toggleAIAssistant(false) }
            )
        }

        // Modal Overlay 3: Preferences & MIDI Hardware Panel
        AnimatedVisibility(
            visible = isSettingsOpen,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .align(Alignment.BottomCenter)
        ) {
            SettingsAndMIDIPanel(
                recordings = recordings,
                onClose = { viewModel.toggleSettings(false) }
            )
        }
    }
}

@Composable
fun WorkstationTopBar(
    masterBpm: Double,
    isRecording: Boolean,
    recordingTime: String,
    is4DeckMode: Boolean,
    isLibraryOpen: Boolean,
    isAIOpen: Boolean,
    isSettingsOpen: Boolean,
    onToggleRecording: () -> Unit,
    onToggle4Deck: () -> Unit,
    onToggleLibrary: () -> Unit,
    onToggleAI: () -> Unit,
    onToggleSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(DJSurfaceDark)
            .border(1.dp, DJBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Identity Brand Badge
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(DJNeonCyan)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "MACDJ.OS",
                color = DJTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "PRO WORKSTATION",
                color = DJTextMuted,
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Master Clock & Quantize status
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MASTER CLOCK: ${String.format(Locale.US, "%.1f", masterBpm)} BPM",
                color = DJNeonCyan,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0x3300E5FF))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text("Q: 1/4", color = DJNeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Live Recording Session Pill
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(if (isRecording) Color(0x33FF1744) else DJBackground)
                .border(1.dp, if (isRecording) DJNeonRed else DJBorderSubtle, RoundedCornerShape(4.dp))
                .clickable { onToggleRecording() }
                .padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FiberManualRecord,
                contentDescription = "REC",
                tint = if (isRecording) DJNeonRed else DJTextMuted,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isRecording) "REC $recordingTime" else "REC",
                color = if (isRecording) DJNeonRed else DJTextSecondary,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        // Action Buttons: AI Co-Pilot, Library, 4-Deck, Preferences
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // AI CO-PILOT
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isAIOpen) DJNeonCyan else Color(0x2200E5FF))
                    .border(1.dp, DJNeonCyan, RoundedCornerShape(4.dp))
                    .clickable { onToggleAI() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("top_bar_ai_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI",
                        tint = if (isAIOpen) Color.Black else DJNeonCyan,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "AI CO-PILOT",
                        color = if (isAIOpen) Color.Black else DJNeonCyan,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // CRATE / LIBRARY
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isLibraryOpen) DJNeonAmber else DJBackground)
                    .border(1.dp, if (isLibraryOpen) DJNeonAmber else DJBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleLibrary() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("top_bar_library_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LibraryMusic,
                        contentDescription = "Library",
                        tint = if (isLibraryOpen) Color.Black else DJTextPrimary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "CRATE",
                        color = if (isLibraryOpen) Color.Black else DJTextPrimary,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // PREFERENCES / SETTINGS
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isSettingsOpen) DJSurfaceElevated else DJBackground)
                    .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleSettings() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("top_bar_settings_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = DJTextSecondary,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@Composable
fun ParallelStackedWaveforms(
    deckAState: DeckState,
    deckBState: DeckState,
    onSeekA: (Double) -> Unit,
    onSeekB: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(6.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(6.dp))
            .padding(2.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        WaveformDisplay(
            deckState = deckAState,
            onSeek = onSeekA,
            modifier = Modifier.weight(1f),
            isMasterWaveform = true
        )
        WaveformDisplay(
            deckState = deckBState,
            onSeek = onSeekB,
            modifier = Modifier.weight(1f),
            isMasterWaveform = true
        )
    }
}

@Composable
fun DeckPlayerUnit(
    deckState: DeckState,
    deckColor: Color,
    onPlayPause: () -> Unit,
    onCue: () -> Unit,
    onToggleSync: () -> Unit,
    onToggleKeyLock: () -> Unit,
    onToggleSlip: () -> Unit,
    onScratch: (Float) -> Unit,
    onPitchChange: (Float) -> Unit,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val track = deckState.track

    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(8.dp))
            .padding(6.dp)
            .testTag("deck_unit_${deckState.deckId.name.lowercase()}"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Track Information Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(DJBackground)
                .border(1.dp, DJBorderSubtle, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track?.title ?: "NO TRACK LOADED",
                    color = DJTextPrimary,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = track?.artist ?: "Press CRATE to load music",
                    color = DJTextSecondary,
                    fontSize = 8.sp,
                    maxLines = 1
                )
            }

            // Camelot Key Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(deckColor.copy(alpha = 0.25f))
                    .border(0.5.dp, deckColor, RoundedCornerShape(3.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(
                    text = track?.key ?: "8A",
                    color = deckColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        // Deck Individual Scrolling Waveform
        WaveformDisplay(
            deckState = deckState,
            onSeek = onSeek,
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Turntable Jog Wheel & Pitch Fader Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Jog Wheel Platter & Controls
            JogWheel(
                deckState = deckState,
                onScratch = onScratch,
                onNudge = { /* pitch bend nudge */ },
                onPlayPause = onPlayPause,
                onCue = onCue,
                onToggleSync = onToggleSync,
                onToggleKeyLock = onToggleKeyLock,
                onToggleSlip = onToggleSlip,
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Vertical Pitch Fader (±8% / ±16%)
            Column(
                modifier = Modifier
                    .width(28.dp)
                    .height(180.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0D121B))
                    .border(1.dp, DJBorderSubtle, RoundedCornerShape(4.dp))
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text("+", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)

                // Vertical pitch slider
                Slider(
                    value = deckState.pitchPercent,
                    onValueChange = onPitchChange,
                    valueRange = -deckState.pitchRange..deckState.pitchRange,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = deckColor,
                        inactiveTrackColor = DJBorder
                    ),
                    modifier = Modifier
                        .height(120.dp)
                        .width(24.dp)
                )

                Text("-", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
