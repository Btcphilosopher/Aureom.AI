package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckState
import com.example.model.EffectType
import com.example.model.HotCue
import com.example.model.LoopState
import com.example.model.PerformanceTab
import com.example.model.SamplerPadState
import com.example.model.StemsState
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJNeonPurple
import com.example.ui.theme.DJNeonRed
import com.example.ui.theme.DJSurfaceCard
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary
import java.util.Locale

@Composable
fun PerformancePadsContainer(
    selectedTab: PerformanceTab,
    onTabSelected: (PerformanceTab) -> Unit,
    activeDeckState: DeckState,
    onUpdateDeck: (DeckState) -> Unit,
    samplerPads: List<SamplerPadState>,
    onTriggerSamplerPad: (SamplerPadState) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(8.dp))
            .padding(6.dp)
            .testTag("performance_pads_container")
    ) {
        // Tab Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .background(DJBackground, RoundedCornerShape(6.dp))
                .padding(2.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                PerformanceTab.HOT_CUES to "HOT CUES",
                PerformanceTab.LOOPS_SLICER to "LOOP / SLICER",
                PerformanceTab.SAMPLER to "SAMPLER",
                PerformanceTab.STEMS to "STEMS",
                PerformanceTab.FX_UNIT to "FX & X-PAD"
            )

            for ((tab, title) in tabs) {
                val isSelected = selectedTab == tab
                val tabColor by animateColorAsState(
                    targetValue = if (isSelected) DJNeonCyan else Color.Transparent,
                    label = "tab_color"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(4.dp))
                        .background(tabColor)
                        .clickable { onTabSelected(tab) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        color = if (isSelected) Color.Black else DJTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                PerformanceTab.HOT_CUES -> HotCuesView(
                    deckState = activeDeckState,
                    onUpdateDeck = onUpdateDeck
                )
                PerformanceTab.LOOPS_SLICER -> LoopsAndSlicerView(
                    deckState = activeDeckState,
                    onUpdateDeck = onUpdateDeck
                )
                PerformanceTab.SAMPLER -> SamplerView(
                    pads = samplerPads,
                    onTriggerPad = onTriggerSamplerPad
                )
                PerformanceTab.STEMS -> StemsView(
                    stems = activeDeckState.stems,
                    onUpdateStems = { onUpdateDeck(activeDeckState.copy(stems = it)) }
                )
                PerformanceTab.FX_UNIT -> FXUnitView(
                    deckState = activeDeckState,
                    onUpdateDeck = onUpdateDeck
                )
                else -> HotCuesView(deckState = activeDeckState, onUpdateDeck = onUpdateDeck)
            }
        }
    }
}

@Composable
fun HotCuesView(
    deckState: DeckState,
    onUpdateDeck: (DeckState) -> Unit
) {
    val cues = deckState.hotCues
    val defaultColors = listOf(
        0xFFFF5252, 0xFF00E5FF, 0xFFFFD600, 0xFF00E676,
        0xFFB388FF, 0xFFFF9100, 0xFFD500F9, 0xFF00B0FF
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (i in 0..3) {
                HotCuePad(
                    index = i,
                    cue = cues.find { it.index == i },
                    defaultColorHex = defaultColors[i],
                    playheadSec = deckState.playheadPositionSec,
                    onJumpOrSet = { targetSec ->
                        if (cues.any { it.index == i }) {
                            // Jump
                            val existing = cues.first { it.index == i }
                            onUpdateDeck(deckState.copy(playheadPositionSec = existing.positionSec))
                        } else {
                            // Set cue on current playhead
                            val newCue = HotCue(i, targetSec, "Cue ${i + 1}", defaultColors[i], true)
                            onUpdateDeck(deckState.copy(hotCues = cues + newCue))
                        }
                    },
                    onDelete = {
                        onUpdateDeck(deckState.copy(hotCues = cues.filter { it.index != i }))
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (i in 4..7) {
                HotCuePad(
                    index = i,
                    cue = cues.find { it.index == i },
                    defaultColorHex = defaultColors[i],
                    playheadSec = deckState.playheadPositionSec,
                    onJumpOrSet = { targetSec ->
                        if (cues.any { it.index == i }) {
                            val existing = cues.first { it.index == i }
                            onUpdateDeck(deckState.copy(playheadPositionSec = existing.positionSec))
                        } else {
                            val newCue = HotCue(i, targetSec, "Cue ${i + 1}", defaultColors[i], true)
                            onUpdateDeck(deckState.copy(hotCues = cues + newCue))
                        }
                    },
                    onDelete = {
                        onUpdateDeck(deckState.copy(hotCues = cues.filter { it.index != i }))
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    }
}

@Composable
fun HotCuePad(
    index: Int,
    cue: HotCue?,
    defaultColorHex: Long,
    playheadSec: Double,
    onJumpOrSet: (Double) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSet = cue != null && cue.isActive
    val cueColor = if (isSet) Color(cue!!.colorHex) else Color(defaultColorHex)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSet) cueColor.copy(alpha = 0.85f) else DJSurfaceCard)
            .border(1.dp, if (isSet) cueColor else DJBorder, RoundedCornerShape(6.dp))
            .pointerInput(isSet, playheadSec) {
                detectTapGestures(
                    onTap = { onJumpOrSet(playheadSec) },
                    onLongPress = { if (isSet) onDelete() }
                )
            }
            .padding(4.dp)
            .testTag("hot_cue_pad_$index"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = cue?.label ?: "CUE ${index + 1}",
                color = if (isSet) Color.Black else DJTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black
            )
            if (isSet) {
                val sec = cue!!.positionSec
                val timeStr = String.format(Locale.US, "%02d:%04.1f", (sec / 60).toInt(), sec % 60)
                Text(
                    text = timeStr,
                    color = Color.Black,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = "TAP TO SET",
                    color = DJTextMuted,
                    fontSize = 7.5.sp
                )
            }
        }
    }
}

@Composable
fun LoopsAndSlicerView(
    deckState: DeckState,
    onUpdateDeck: (DeckState) -> Unit
) {
    val loop = deckState.loopState
    val currentSec = deckState.playheadPositionSec
    val bpm = deckState.targetBpm * (1.0 + deckState.pitchPercent / 100.0)
    val secPerBeat = 60.0 / bpm

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Auto Loop Size Selectors (1/4 to 32 beats)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val loopSizes = listOf(0.25f to "1/4", 0.5f to "1/2", 1f to "1", 2f to "2", 4f to "4", 8f to "8", 16f to "16", 32f to "32")
            for ((sizeBars, label) in loopSizes) {
                val isSelected = loop.isActive && loop.lengthBars == sizeBars
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) DJNeonGreen else DJSurfaceCard)
                        .border(1.dp, if (isSelected) DJNeonGreen else DJBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            val loopLengthSec = sizeBars * 4.0 * secPerBeat
                            onUpdateDeck(
                                deckState.copy(
                                    loopState = LoopState(
                                        isActive = true,
                                        inPositionSec = currentSec,
                                        outPositionSec = currentSec + loopLengthSec,
                                        lengthBars = sizeBars,
                                        isAutoLoop = true
                                    )
                                )
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.Black else DJTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Loop Actions: IN, OUT, EXIT / RELOOP, 1/2X, 2X
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // LOOP IN
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DJSurfaceElevated)
                    .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        onUpdateDeck(deckState.copy(loopState = loop.copy(inPositionSec = currentSec)))
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("IN", color = DJNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // LOOP OUT
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DJSurfaceElevated)
                    .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        onUpdateDeck(deckState.copy(loopState = loop.copy(isActive = true, outPositionSec = currentSec)))
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("OUT", color = DJNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // RELOOP / EXIT
            Box(
                modifier = Modifier
                    .weight(1.5f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (loop.isActive) DJNeonGreen else DJSurfaceElevated)
                    .border(1.dp, if (loop.isActive) DJNeonGreen else DJBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        onUpdateDeck(deckState.copy(loopState = loop.copy(isActive = !loop.isActive)))
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (loop.isActive) "ACTIVE (EXIT)" else "RELOOP",
                    color = if (loop.isActive) Color.Black else DJNeonGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // 1/2X Loop Length
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DJSurfaceElevated)
                    .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        val newBars = (loop.lengthBars / 2f).coerceAtLeast(0.125f)
                        val newOut = loop.inPositionSec + (newBars * 4.0 * secPerBeat)
                        onUpdateDeck(deckState.copy(loopState = loop.copy(lengthBars = newBars, outPositionSec = newOut)))
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("1/2X", color = DJTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // 2X Loop Length
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DJSurfaceElevated)
                    .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        val newBars = (loop.lengthBars * 2f).coerceAtMost(64f)
                        val newOut = loop.inPositionSec + (newBars * 4.0 * secPerBeat)
                        onUpdateDeck(deckState.copy(loopState = loop.copy(lengthBars = newBars, outPositionSec = newOut)))
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("2X", color = DJTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SamplerView(
    pads: List<SamplerPadState>,
    onTriggerPad: (SamplerPadState) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        val chunk1 = pads.take(8)
        val chunk2 = pads.drop(8)

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (p in chunk1.take(4)) {
                    SamplerPad(pad = p, onTrigger = { onTriggerPad(p) }, modifier = Modifier.weight(1f).fillMaxHeight())
                }
            }
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (p in chunk1.drop(4)) {
                    SamplerPad(pad = p, onTrigger = { onTriggerPad(p) }, modifier = Modifier.weight(1f).fillMaxHeight())
                }
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (p in chunk2.take(4)) {
                    SamplerPad(pad = p, onTrigger = { onTriggerPad(p) }, modifier = Modifier.weight(1f).fillMaxHeight())
                }
            }
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (p in chunk2.drop(4)) {
                    SamplerPad(pad = p, onTrigger = { onTriggerPad(p) }, modifier = Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
fun SamplerPad(
    pad: SamplerPadState,
    onTrigger: () -> Unit,
    modifier: Modifier = Modifier
) {
    val padColor = Color(pad.colorHex)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DJSurfaceCard)
            .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
            .clickable { onTrigger() }
            .padding(2.dp)
            .testTag("sampler_pad_${pad.name.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = pad.name,
                color = padColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = pad.category,
                color = DJTextMuted,
                fontSize = 7.sp
            )
        }
    }
}

@Composable
fun StemsView(
    stems: StemsState,
    onUpdateStems: (StemsState) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        StemChannel(
            name = "VOCALS",
            gain = stems.vocalsGain,
            isMuted = stems.vocalsMuted,
            color = DJNeonCyan,
            onGainChange = { onUpdateStems(stems.copy(vocalsGain = it)) },
            onToggleMute = { onUpdateStems(stems.copy(vocalsMuted = !stems.vocalsMuted)) },
            modifier = Modifier.weight(1f)
        )

        StemChannel(
            name = "DRUMS",
            gain = stems.drumsGain,
            isMuted = stems.drumsMuted,
            color = DJNeonAmber,
            onGainChange = { onUpdateStems(stems.copy(drumsGain = it)) },
            onToggleMute = { onUpdateStems(stems.copy(drumsMuted = !stems.drumsMuted)) },
            modifier = Modifier.weight(1f)
        )

        StemChannel(
            name = "BASS",
            gain = stems.bassGain,
            isMuted = stems.bassMuted,
            color = DJNeonRed,
            onGainChange = { onUpdateStems(stems.copy(bassGain = it)) },
            onToggleMute = { onUpdateStems(stems.copy(bassMuted = !stems.bassMuted)) },
            modifier = Modifier.weight(1f)
        )

        StemChannel(
            name = "MELODY",
            gain = stems.melodyGain,
            isMuted = stems.melodyMuted,
            color = DJNeonPurple,
            onGainChange = { onUpdateStems(stems.copy(melodyGain = it)) },
            onToggleMute = { onUpdateStems(stems.copy(melodyMuted = !stems.melodyMuted)) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StemChannel(
    name: String,
    gain: Float,
    isMuted: Boolean,
    color: Color,
    onGainChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(name, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)

        // Mute Button
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isMuted) DJNeonRed else DJSurfaceCard)
                .border(1.dp, if (isMuted) DJNeonRed else DJBorder, RoundedCornerShape(3.dp))
                .clickable { onToggleMute() }
                .padding(horizontal = 6.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isMuted) "MUTED" else "MUTE",
                color = if (isMuted) Color.White else DJTextSecondary,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Stem Volume Slider
        Slider(
            value = gain,
            onValueChange = onGainChange,
            valueRange = 0f..1.5f,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                inactiveTrackColor = DJBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(26.dp)
        )
    }
}

@Composable
fun FXUnitView(
    deckState: DeckState,
    onUpdateDeck: (DeckState) -> Unit
) {
    var xPadX by remember { mutableFloatStateOf(deckState.effectDryWet) }
    var xPadY by remember { mutableFloatStateOf(deckState.effectFeedback) }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Column: Effect Type, Dry/Wet, On/Off, Beat fractions
        Column(
            modifier = Modifier.weight(1.2f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Effect Toggle ON / OFF
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (deckState.effectEnabled) DJNeonGreen else DJSurfaceCard)
                        .border(1.dp, if (deckState.effectEnabled) DJNeonGreen else DJBorder, RoundedCornerShape(4.dp))
                        .clickable { onUpdateDeck(deckState.copy(effectEnabled = !deckState.effectEnabled)) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (deckState.effectEnabled) "FX ON" else "FX OFF",
                        color = if (deckState.effectEnabled) Color.Black else DJTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Effect Type Pill Selector
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DJSurfaceElevated)
                        .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            val allTypes = EffectType.values()
                            val nextIdx = (deckState.activeEffect.ordinal + 1) % allTypes.size
                            onUpdateDeck(deckState.copy(activeEffect = allTypes[nextIdx]))
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = deckState.activeEffect.displayName,
                        color = DJNeonCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Beat Times (1/8, 1/4, 1/2, 3/4, 1, 2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                val fractions = listOf(0.125f to "1/8", 0.25f to "1/4", 0.5f to "1/2", 0.75f to "3/4", 1.0f to "1", 2.0f to "2")
                for ((f, label) in fractions) {
                    val isSel = deckState.effectBeatTime == f
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(22.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSel) DJNeonCyan else DJSurfaceCard)
                            .border(1.dp, if (isSel) DJNeonCyan else DJBorderSubtle, RoundedCornerShape(3.dp))
                            .clickable { onUpdateDeck(deckState.copy(effectBeatTime = f)) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSel) Color.Black else DJTextSecondary,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Dry/Wet Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DRY/WET", color = DJTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Slider(
                    value = deckState.effectDryWet,
                    onValueChange = {
                        xPadX = it
                        onUpdateDeck(deckState.copy(effectDryWet = it))
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = DJNeonCyan,
                        activeTrackColor = DJNeonCyan,
                        inactiveTrackColor = DJBorder
                    ),
                    modifier = Modifier.weight(1f).height(24.dp)
                )
            }
        }

        // Right Column: Interactive 2D X-Pad for live touch modulation
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(6.dp))
                .background(DJBackground)
                .border(1.dp, DJBorder, RoundedCornerShape(6.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        xPadX = (change.position.x / size.width).coerceIn(0f, 1f)
                        xPadY = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                        onUpdateDeck(
                            deckState.copy(
                                effectDryWet = xPadX,
                                effectFeedback = xPadY,
                                effectEnabled = true
                            )
                        )
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        xPadX = (offset.x / size.width).coerceIn(0f, 1f)
                        xPadY = (1f - offset.y / size.height).coerceIn(0f, 1f)
                        onUpdateDeck(
                            deckState.copy(
                                effectDryWet = xPadX,
                                effectFeedback = xPadY,
                                effectEnabled = true
                            )
                        )
                    }
                }
                .testTag("fx_x_pad"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = xPadX * size.width
                val cy = (1f - xPadY) * size.height

                // Grid lines
                drawLine(Color(0x22FFFFFF), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), 1f)
                drawLine(Color(0x22FFFFFF), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)

                // Laser crosshair
                drawLine(DJNeonCyan.copy(alpha = 0.5f), Offset(cx, 0f), Offset(cx, size.height), 1.5f)
                drawLine(DJNeonCyan.copy(alpha = 0.5f), Offset(0f, cy), Offset(size.width, cy), 1.5f)

                // Touch point
                drawCircle(DJNeonCyan, radius = 6.dp.toPx(), center = Offset(cx, cy))
                drawCircle(Color.White, radius = 2.5.dp.toPx(), center = Offset(cx, cy))
            }
            Text(
                text = "X-PAD MODULATION",
                color = DJTextMuted,
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp)
            )
        }
    }
}
