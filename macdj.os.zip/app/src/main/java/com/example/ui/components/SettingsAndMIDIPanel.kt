package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SavedRecording
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJSurfaceCard
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary

@Composable
fun SettingsAndMIDIPanel(
    recordings: List<SavedRecording>,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedBufferSize by remember { mutableIntStateOf(256) }
    var selectedSampleRate by remember { mutableIntStateOf(48000) }
    var isMidiLearnActive by remember { mutableStateOf(false) }

    val latencyMs = (selectedBufferSize.toDouble() / selectedSampleRate.toDouble()) * 1000.0

    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("settings_midi_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = DJNeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "WORKSTATION PREFERENCES & HARDWARE SETUP",
                    color = DJTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = DJTextMuted, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Left Column: Audio Latency & Hardware Setup
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Section 1: Audio Core & Latency Buffer
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(DJBackground)
                        .border(1.dp, DJBorderSubtle, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text("REAL-TIME AUDIO BUFFER & LATENCY", color = DJNeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val buffers = listOf(64, 128, 256, 512, 1024)
                        for (b in buffers) {
                            val isSel = selectedBufferSize == b
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(24.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isSel) DJNeonCyan else DJSurfaceElevated)
                                    .border(1.dp, if (isSel) DJNeonCyan else DJBorderSubtle, RoundedCornerShape(3.dp))
                                    .clickable { selectedBufferSize = b },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$b",
                                    color = if (isSel) Color.Black else DJTextPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Calculated Latency: ${String.format("%.2f", latencyMs)} ms  •  Sample Rate: ${selectedSampleRate / 1000} kHz",
                        color = DJNeonGreen,
                        fontSize = 8.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Section 2: MIDI Controller Integration
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(DJBackground)
                        .border(1.dp, DJBorderSubtle, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text("MIDI CONTROLLERS & USB INTERFACE", color = DJNeonAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Connected Hardware: Pioneer DDJ / USB Audio Compliant", color = DJTextPrimary, fontSize = 8.5.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(26.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isMidiLearnActive) DJNeonAmber else DJSurfaceElevated)
                            .border(1.dp, if (isMidiLearnActive) DJNeonAmber else DJBorder, RoundedCornerShape(4.dp))
                            .clickable { isMidiLearnActive = !isMidiLearnActive },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isMidiLearnActive) "MIDI LEARN ACTIVE (TOUCH CONTROLS)" else "ENABLE MIDI LEARN",
                            color = if (isMidiLearnActive) Color.Black else DJTextPrimary,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Right Column: Master Mix Recordings Manager
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(DJBackground)
                    .border(1.dp, DJBorderSubtle, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Text("RECORDED SESSIONS & WAV EXPORTS", color = DJNeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                if (recordings.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No recorded sessions yet. Press REC in master bar to capture live mixes.", color = DJTextMuted, fontSize = 9.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(recordings, key = { it.id }) { rec ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DJSurfaceCard)
                                    .border(0.5.dp, DJBorderSubtle, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(rec.fileName, color = DJTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(rec.duration, color = DJNeonGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("${rec.date} • ${rec.fileSize}", color = DJTextMuted, fontSize = 7.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
