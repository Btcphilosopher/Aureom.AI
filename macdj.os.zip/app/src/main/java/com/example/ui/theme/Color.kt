package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Dark Slate Surfaces
val DJBackground = Color(0xFF0A0D14)
val DJSurfaceDark = Color(0xFF111622)
val DJSurfaceCard = Color(0xFF161D2B)
val DJSurfaceElevated = Color(0xFF1F293D)
val DJBorder = Color(0xFF26334A)
val DJBorderSubtle = Color(0xFF1B2433)

// Deck Accents
val DeckAColor = Color(0xFFFF5252)       // Neon Red/Orange
val DeckBColor = Color(0xFF00E5FF)       // Electric Cyan
val DeckCColor = Color(0xFFFFD600)       // Neon Amber/Yellow
val DeckDColor = Color(0xFFB388FF)       // Electric Violet

// Neon Performance Highlights
val DJNeonGreen = Color(0xFF00E676)      // Play / Active / Sync Green
val DJNeonAmber = Color(0xFFFF9100)      // Cue / Warning Amber
val DJNeonRed = Color(0xFFFF1744)        // Recording / Limit Red
val DJNeonCyan = Color(0xFF00F0FF)       // High Energy Blue
val DJNeonPurple = Color(0xFFD500F9)     // Special FX Magenta

// VU Meter Colors
val VUGreen = Color(0xFF00E676)
val VUAmber = Color(0xFFFFD600)
val VURed = Color(0xFFFF1744)

// Text Colors
val DJTextPrimary = Color(0xFFF0F4FC)
val DJTextSecondary = Color(0xFF8E9EB5)
val DJTextTertiary = Color(0xFF53627A)
val DJTextMuted = Color(0xFF384357)

// Waveform Frequency Colors
val WaveformLow = Color(0xFFFF3D00)      // Bass / Kick
val WaveformMid = Color(0xFFFFAB00)      // Vocals / Synths
val WaveformHigh = Color(0xFF00E5FF)     // Hi-hats / Cymbals
