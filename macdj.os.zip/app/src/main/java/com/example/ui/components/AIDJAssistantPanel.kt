package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AIDJTransitionAdvice
import com.example.model.AISetProposal
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJNeonPurple
import com.example.ui.theme.DJSurfaceCard
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary

@Composable
fun AIDJAssistantPanel(
    transitionAdvice: AIDJTransitionAdvice?,
    setProposal: AISetProposal?,
    aiResponseText: String,
    isLoading: Boolean,
    onSendPrompt: (String) -> Unit,
    onGenerateSet: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var promptInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJNeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("ai_dj_assistant_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI DJ",
                    tint = DJNeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MACDJ.OS AI PERFORMANCE CO-PILOT",
                    color = DJNeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = DJTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Action Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val chips = listOf(
                "Transition Blueprint" to "Analyze harmonic transition between Deck A and Deck B",
                "Dark Energy Match" to "Recommend a dark driving 125 BPM track",
                "Build 30-Min Set" to "Build a peak time 30 minute club set"
            )

            for ((label, query) in chips) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(DJSurfaceElevated)
                        .border(1.dp, DJBorder, RoundedCornerShape(4.dp))
                        .clickable { onSendPrompt(query) }
                        .padding(vertical = 4.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = DJTextPrimary,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Scrollable Intelligence Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(DJBackground, RoundedCornerShape(6.dp))
                .border(1.dp, DJBorder, RoundedCornerShape(6.dp))
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Live Harmonic Transition Blueprint
            if (transitionAdvice != null) {
                HarmonicAdviceCard(advice = transitionAdvice)
                Spacer(modifier = Modifier.height(8.dp))
            }

            // AI Response / Conversation Output
            if (isLoading) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        color = DJNeonCyan,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("AI analyzing crate & harmonic keys...", color = DJTextSecondary, fontSize = 10.sp)
                }
            } else if (aiResponseText.isNotBlank()) {
                Text(
                    text = aiResponseText,
                    color = DJTextPrimary,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            } else {
                Text(
                    text = "Welcome to MACDJ.OS Intelligence. Select Deck A and Deck B to compute real-time harmonic compatibility, EQ swap strategies, or ask for dynamic crate curation.",
                    color = DJTextMuted,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }

            // Set Proposal Graph
            if (setProposal != null) {
                Spacer(modifier = Modifier.height(8.dp))
                SetProposalCard(proposal = setProposal)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Input Prompt Field
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(DJBackground)
                    .border(1.dp, DJBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    textStyle = TextStyle(color = DJTextPrimary, fontSize = 11.sp),
                    cursorBrush = SolidColor(DJNeonCyan),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (promptInput.isEmpty()) {
                            Text("Ask AI DJ Assistant...", color = DJTextMuted, fontSize = 10.sp)
                        }
                        innerTextField()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("ai_prompt_input")
                )
            }

            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(DJNeonCyan)
                    .clickable {
                        if (promptInput.isNotBlank()) {
                            onSendPrompt(promptInput)
                            promptInput = ""
                        }
                    }
                    .testTag("ai_send_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun HarmonicAdviceCard(advice: AIDJTransitionAdvice) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DJSurfaceCard)
            .border(1.dp, DJNeonCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${advice.fromTrack.title} ➔ ${advice.toTrack.title}",
                color = DJTextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            // Score Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (advice.compatibilityScore > 85) DJNeonGreen else DJNeonAmber)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${advice.compatibilityScore}% HARMONIC MATCH",
                    color = Color.Black,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "• Camelot Lock: ${advice.harmonicMatch}",
            color = DJNeonCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = "• EQ Strategy: ${advice.eqStrategy}",
            color = DJTextSecondary,
            fontSize = 8.5.sp
        )
    }
}

@Composable
fun SetProposalCard(proposal: AISetProposal) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DJSurfaceCard)
            .border(1.dp, DJNeonPurple.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Text(
            text = "${proposal.title} (${proposal.estimatedMinutes} mins)",
            color = DJNeonPurple,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = proposal.notes,
            color = DJTextSecondary,
            fontSize = 8.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        for ((idx, track) in proposal.trackProgression.withIndex()) {
            Text(
                text = "${idx + 1}. ${track.title} (${track.bpm} BPM • ${track.key} • Energy: ${track.energy}%)",
                color = DJTextPrimary,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
