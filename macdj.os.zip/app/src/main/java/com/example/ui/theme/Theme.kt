package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DJNeonCyan,
    onPrimary = Color.Black,
    primaryContainer = DJSurfaceElevated,
    onPrimaryContainer = DJTextPrimary,
    secondary = DJNeonGreen,
    onSecondary = Color.Black,
    secondaryContainer = DJSurfaceCard,
    onSecondaryContainer = DJTextPrimary,
    tertiary = DJNeonAmber,
    onTertiary = Color.Black,
    background = DJBackground,
    onBackground = DJTextPrimary,
    surface = DJSurfaceDark,
    onSurface = DJTextPrimary,
    surfaceVariant = DJSurfaceCard,
    onSurfaceVariant = DJTextSecondary,
    outline = DJBorder,
    outlineVariant = DJBorderSubtle,
    error = DJNeonRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
