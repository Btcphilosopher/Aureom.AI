package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CrossfaderCurve
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.MixerMasterState
import com.example.ui.theme.DJBackground
import com.example.ui.theme.DJBorder
import com.example.ui.theme.DJBorderSubtle
import com.example.ui.theme.DJNeonAmber
import com.example.ui.theme.DJNeonCyan
import com.example.ui.theme.DJNeonGreen
import com.example.ui.theme.DJNeonRed
import com.example.ui.theme.DJSurfaceDark
import com.example.ui.theme.DJSurfaceElevated
import com.example.ui.theme.DJTextMuted
import com.example.ui.theme.DJTextPrimary
import com.example.ui.theme.DJTextSecondary
import com.example.ui.theme.DeckAColor
import com.example.ui.theme.DeckBColor
import com.example.ui.theme.VUAmber
import com.example.ui.theme.VUGreen
import com.example.ui.theme.VURed
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MixerSection(
    deckAState: DeckState,
    deckBState: DeckState,
    masterState: MixerMasterState,
    onUpdateDeckA: (DeckState) -> Unit,
    onUpdateDeckB: (DeckState) -> Unit,
    onUpdateMaster: (MixerMasterState) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(DJSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, DJBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("mixer_section")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Section: Master & Booth Levels & Cue Mix
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Master Volume Knob
                RotaryKnob(
                    value = masterState.masterVolume,
                    label = "MASTER",
                    onValueChange = { onUpdateMaster(masterState.copy(masterVolume = it)) },
                    indicatorColor = DJNeonCyan,
                    sizeDp = 34
                )

                // Master Stereo VU Meters
                MasterVUMeter(
                    leftLevel = masterState.masterVuLeft,
                    rightLevel = masterState.masterVuRight,
                    clipping = masterState.masterClipping
                )

                // Cue Mix Knob
                RotaryKnob(
                    value = masterState.cueMixBalance,
                    label = "CUE MIX",
                    onValueChange = { onUpdateMaster(masterState.copy(cueMixBalance = it)) },
                    indicatorColor = DJNeonAmber,
                    sizeDp = 34
                )
            }

            // Channel Strips (Deck A | Deck B)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Channel 1 (Deck A)
                ChannelStrip(
                    state = deckAState,
                    deckColor = DeckAColor,
                    onUpdateState = onUpdateDeckA,
                    modifier = Modifier.weight(1f)
                )

                // Center Divider
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight(0.85f)
                        .background(DJBorderSubtle)
                )

                // Channel 2 (Deck B)
                ChannelStrip(
                    state = deckBState,
                    deckColor = DeckBColor,
                    onUpdateState = onUpdateDeckB,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom Crossfader Section
            CrossfaderUnit(
                position = masterState.crossfaderPosition,
                curve = masterState.crossfaderCurve,
                onPositionChange = { onUpdateMaster(masterState.copy(crossfaderPosition = it)) },
                onCurveChange = { onUpdateMaster(masterState.copy(crossfaderCurve = it)) }
            )
        }
    }
}

@Composable
fun ChannelStrip(
    state: DeckState,
    deckColor: Color,
    onUpdateState: (DeckState) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // TRIM / GAIN
        RotaryKnob(
            value = (state.trimGain / 2.0f).coerceIn(0f, 1f),
            label = "TRIM",
            onValueChange = { onUpdateState(state.copy(trimGain = it * 2.0f)) },
            indicatorColor = DJTextSecondary,
            sizeDp = 28
        )

        // HIGH EQ
        RotaryKnob(
            value = (state.eqHigh / 2.0f).coerceIn(0f, 1f),
            label = "HI",
            onValueChange = { onUpdateState(state.copy(eqHigh = it * 2.0f)) },
            indicatorColor = DJNeonCyan,
            sizeDp = 28
        )

        // MID EQ
        RotaryKnob(
            value = (state.eqMid / 2.0f).coerceIn(0f, 1f),
            label = "MID",
            onValueChange = { onUpdateState(state.copy(eqMid = it * 2.0f)) },
            indicatorColor = DJNeonGreen,
            sizeDp = 28
        )

        // LOW EQ
        RotaryKnob(
            value = (state.eqLow / 2.0f).coerceIn(0f, 1f),
            label = "LOW",
            onValueChange = { onUpdateState(state.copy(eqLow = it * 2.0f)) },
            indicatorColor = DJNeonAmber,
            sizeDp = 28
        )

        // COLOR FILTER (HPF / LPF)
        RotaryKnob(
            value = state.filterColor,
            label = "FILTER",
            onValueChange = { onUpdateState(state.copy(filterColor = it)) },
            indicatorColor = if (state.filterColor > 0.52f) DJNeonCyan else if (state.filterColor < 0.48f) DJNeonRed else DJTextMuted,
            sizeDp = 28
        )

        // Headphone CUE Monitoring Button
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (state.isCueMonitoring) DJNeonAmber else DJBackground)
                .border(1.dp, if (state.isCueMonitoring) DJNeonAmber else DJBorder, RoundedCornerShape(3.dp))
                .clickable { onUpdateState(state.copy(isCueMonitoring = !state.isCueMonitoring)) }
                .padding(horizontal = 8.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "CUE",
                color = if (state.isCueMonitoring) Color.Black else DJNeonAmber,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Channel Fader with Integrated Vertical VU Meter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Channel VU Meter
            VerticalLEDVUMeter(
                level = (state.vuLevelLeft + state.vuLevelRight) / 2f,
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Vertical Fader Bar (Touch drag)
            VerticalFader(
                value = state.channelFader,
                onValueChange = { onUpdateState(state.copy(channelFader = it)) },
                modifier = Modifier
                    .width(28.dp)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
fun RotaryKnob(
    value: Float, // 0.0 .. 1.0
    label: String,
    onValueChange: (Float) -> Unit,
    indicatorColor: Color,
    sizeDp: Int = 30
) {
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0xFF222B3D),
                            Color(0xFF101520)
                        )
                    )
                )
                .border(1.dp, DJBorder, CircleShape)
                .pointerInput(value) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            // Drag up to increase, down to decrease
                            dragAccumulator -= dragAmount.y * 0.008f
                            val newValue = (value + dragAccumulator).coerceIn(0f, 1f)
                            if (newValue != value) {
                                onValueChange(newValue)
                                dragAccumulator = 0f
                            }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f

                // Arc background
                drawArc(
                    color = Color(0x33FFFFFF),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )

                // Active Arc
                val currentSweep = value * 270f
                drawArc(
                    color = indicatorColor,
                    startAngle = 135f,
                    sweepAngle = currentSweep,
                    useCenter = false,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Indicator needle
                val angleRad = ((135f + currentSweep) * PI / 180.0).toFloat()
                val needleStart = center
                val needleEnd = Offset(
                    center.x + cos(angleRad) * (radius - 2.dp.toPx()),
                    center.y + sin(angleRad) * (radius - 2.dp.toPx())
                )
                drawLine(
                    color = indicatorColor,
                    start = needleStart,
                    end = needleEnd,
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
        Text(
            text = label,
            color = DJTextMuted,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 1.dp)
        )
    }
}

@Composable
fun VerticalFader(
    value: Float, // 0.0 (bottom) .. 1.0 (top)
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF0C1018), RoundedCornerShape(4.dp))
            .border(1.dp, DJBorderSubtle, RoundedCornerShape(4.dp))
            .pointerInput(value) {
                detectDragGestures { change, _ ->
                    val progress = (1f - (change.position.y / size.height)).coerceIn(0f, 1f)
                    onValueChange(progress)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerTrackX = size.width / 2f

            // Fader groove line
            drawLine(
                color = Color(0x33FFFFFF),
                start = Offset(centerTrackX, 4.dp.toPx()),
                end = Offset(centerTrackX, size.height - 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )

            // dB calibration notches
            for (f in listOf(0.1f, 0.3f, 0.5f, 0.75f, 0.9f)) {
                val y = size.height * (1f - f)
                drawLine(
                    color = Color(0x22FFFFFF),
                    start = Offset(2.dp.toPx(), y),
                    end = Offset(6.dp.toPx(), y),
                    strokeWidth = 1f
                )
                drawLine(
                    color = Color(0x22FFFFFF),
                    start = Offset(size.width - 6.dp.toPx(), y),
                    end = Offset(size.width - 2.dp.toPx(), y),
                    strokeWidth = 1f
                )
            }

            // Fader Cap Handle
            val capY = size.height * (1f - value).coerceIn(0.05f, 0.95f)
            val capHeight = 12.dp.toPx()
            val capWidth = size.width - 4.dp.toPx()

            drawRoundRect(
                color = Color(0xFFD0D7E5),
                topLeft = Offset(2.dp.toPx(), capY - capHeight / 2f),
                size = Size(capWidth, capHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )

            // Center marker line on cap
            drawLine(
                color = Color(0xFF101622),
                start = Offset(4.dp.toPx(), capY),
                end = Offset(size.width - 4.dp.toPx(), capY),
                strokeWidth = 1.5.dp.toPx()
            )
        }
    }
}

@Composable
fun VerticalLEDVUMeter(
    level: Float, // 0.0 .. 1.2
    modifier: Modifier = Modifier
) {
    val totalSegments = 10
    val activeSegments = (level * totalSegments).toInt().coerceIn(0, totalSegments)

    Column(
        modifier = modifier
            .background(Color(0xFF090D14), RoundedCornerShape(2.dp))
            .padding(1.dp),
        verticalArrangement = Arrangement.spacedBy(1.5.dp, Alignment.Bottom)
    ) {
        for (i in totalSegments downTo 1) {
            val isActive = i <= activeSegments
            val segColor = when {
                i >= 9 -> VURed
                i >= 7 -> VUAmber
                else -> VUGreen
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(1.dp))
                    .background(if (isActive) segColor else Color(0x18FFFFFF))
            )
        }
    }
}

@Composable
fun MasterVUMeter(
    leftLevel: Float,
    rightLevel: Float,
    clipping: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "MASTER",
            color = if (clipping) DJNeonRed else DJTextSecondary,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            modifier = Modifier.height(30.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            VerticalLEDVUMeter(level = leftLevel, modifier = Modifier.width(4.dp).fillMaxHeight())
            VerticalLEDVUMeter(level = rightLevel, modifier = Modifier.width(4.dp).fillMaxHeight())
        }
    }
}

@Composable
fun CrossfaderUnit(
    position: Float,
    curve: CrossfaderCurve,
    onPositionChange: (Float) -> Unit,
    onCurveChange: (CrossfaderCurve) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("A", color = DeckAColor, fontSize = 11.sp, fontWeight = FontWeight.Black)

            // Curve Selector Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF141A26))
                    .border(1.dp, DJBorder, RoundedCornerShape(3.dp))
                    .clickable {
                        val nextCurve = when (curve) {
                            CrossfaderCurve.CONSTANT_POWER -> CrossfaderCurve.LINEAR
                            CrossfaderCurve.LINEAR -> CrossfaderCurve.CUT_SCRATCH
                            CrossfaderCurve.CUT_SCRATCH -> CrossfaderCurve.SMOOTH_FADE
                            CrossfaderCurve.SMOOTH_FADE -> CrossfaderCurve.CONSTANT_POWER
                        }
                        onCurveChange(nextCurve)
                    }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = curve.name.replace("_", " "),
                    color = DJNeonCyan,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text("B", color = DeckBColor, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Horizontal Crossfader Slider
        Slider(
            value = position,
            onValueChange = onPositionChange,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = DJNeonCyan,
                inactiveTrackColor = Color(0xFF1B2434)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(26.dp)
                .testTag("crossfader_slider")
        )
    }
}
