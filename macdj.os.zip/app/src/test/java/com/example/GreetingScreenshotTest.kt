package com.example

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.test.core.app.ApplicationProvider
import com.example.ui.DJViewModel
import com.example.ui.MACDJWorkstationScreen
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun workstation_screenshot() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = DJViewModel(app)

        composeTestRule.setContent {
            MyApplicationTheme {
                MACDJWorkstationScreen(viewModel = vm, modifier = Modifier.fillMaxSize())
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/workstation.png")
    }
}
