package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AIDJService
import com.example.data.DJRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun read_app_name_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MACDJ.OS", appName)
    }

    @Test
    fun verify_harmonic_mixing_compatibility() {
        val aiService = AIDJService()
        val trackA = DJRepository.PRELOADED_TRACKS[0] // Lose Control (7A, 124 BPM)
        val trackB = DJRepository.PRELOADED_TRACKS[6] // Higher (8A, 124 BPM)

        val advice = aiService.calculateHarmonicCompatibility(trackA, trackB)
        assertNotNull(advice)
        assertTrue(advice.compatibilityScore >= 90)
        assertTrue(advice.harmonicMatch.contains("Harmonic Boost"))
    }
}
