/**
 * DEUTSCHSUCH - Local Privacy & History Storage
 * Strictly client-side, encrypted/isolated in localStorage, zero server tracking.
 */

export interface SearchHistoryItem {
  id: string;
  query: string;
  timestamp: number;
}

export interface PrivacySettings {
  historyEnabled: boolean;
  regionBoost: boolean;
  safeSearch: 'strict' | 'moderate' | 'off';
  theme: 'light' | 'dark' | 'system';
}

const DEFAULT_SETTINGS: PrivacySettings = {
  historyEnabled: true,
  regionBoost: true,
  safeSearch: 'moderate',
  theme: 'system',
};

export function getLocalPrivacySettings(): PrivacySettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem('deutschsuch_privacy');
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveLocalPrivacySettings(settings: PrivacySettings) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('deutschsuch_privacy', JSON.stringify(settings));
  } catch {}
}

export function getLocalSearchHistory(): SearchHistoryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('deutschsuch_history');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addLocalSearchHistory(query: string) {
  if (typeof window === 'undefined') return;
  const settings = getLocalPrivacySettings();
  if (!settings.historyEnabled || !query.trim()) return;

  try {
    const history = getLocalSearchHistory().filter((item) => item.query.toLowerCase() !== query.toLowerCase());
    history.unshift({
      id: Math.random().toString(36).substring(2, 9),
      query: query.trim(),
      timestamp: Date.now(),
    });
    localStorage.setItem('deutschsuch_history', JSON.stringify(history.slice(0, 20)));
  } catch {}
}

export function clearLocalSearchHistory() {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem('deutschsuch_history');
  } catch {}
}
