/**
 * DEUTSCHSUCH - German Language Processing Engine (GermanLanguageEngine)
 * Modules: Tokenizer, Stemmer, CompoundSplitter, SpellChecker, NER, IntentClassifier
 */

import { SearchIntent } from './types';

// Stop words in German
export const GERMAN_STOPWORDS = new Set([
  'der', 'die', 'das', 'den', 'dem', 'des', 'ein', 'eine', 'einer', 'einem', 'einen', 'eines',
  'und', 'oder', 'aber', 'denn', 'doch', 'mit', 'auf', 'in', 'im', 'bei', 'beim', 'an', 'am',
  'zu', 'zum', 'zur', 'von', 'vom', 'aus', 'nach', 'über', 'unter', 'vor', 'hinter', 'für',
  'um', 'ohne', 'durch', 'gegen', 'ist', 'sind', 'war', 'waren', 'wird', 'werden', 'wurde',
  'wurden', 'hat', 'hatte', 'haben', 'hatten', 'kann', 'können', 'konnte', 'könnten', 'muss',
  'müssen', 'soll', 'sollte', 'wie', 'was', 'wer', 'wo', 'wann', 'warum', 'welche', 'welcher',
  'welches', 'dies', 'diese', 'dieser', 'dieses', 'nicht', 'kein', 'keine', 'keiner', 'auch',
  'nur', 'noch', 'schon', 'sehr', 'so', 'dass', 'da', 'wenn', 'als', 'ihr', 'ihre', 'ihres',
  'sein', 'seine', 'seines', 'er', 'sie', 'es', 'wir', 'ihr',
]);

// German compound dictionary with known prefixes, stems and common interfixes
const GERMAN_KNOWN_COMPOUNDS: Record<string, string[]> = {
  bundesausbildungsförderungsgesetz: ['Bund', 'Ausbildung', 'Förderung', 'Gesetz'],
  bafög: ['Bundesausbildungsförderungsgesetz'],
  kraftfahrzeughaftpflichtversicherung: ['Kraftfahrzeug', 'Haftpflicht', 'Versicherung'],
  energiewirtschaftsgesetz: ['Energie', 'Wirtschaft', 'Gesetz'],
  datenschutzgrundverordnung: ['Datenschutz', 'Grund', 'Verordnung'],
  dsgvo: ['Datenschutz', 'Grund', 'Verordnung'],
  hochgeschwindigkeitsbahnstrecke: ['Hochgeschwindigkeit', 'Bahn', 'Strecke'],
  bundeskanzleramt: ['Bund', 'Kanzler', 'Amt'],
  bundesverfassungsgericht: ['Bund', 'Verfassung', 'Gericht'],
  bundesnetzagentur: ['Bund', 'Netz', 'Agentur'],
  bundesregierung: ['Bund', 'Regierung'],
  bundestagswahl: ['Bundestag', 'Wahl'],
  strompreisentwicklung: ['Strom', 'Preis', 'Entwicklung'],
  wasserstoffwirtschaft: ['Wasserstoff', 'Wirtschaft'],
  übertragungsnetzbetreiber: ['Übertragung', 'Netz', 'Betreiber'],
  verkehrswende: ['Verkehr', 'Wende'],
  energiewende: ['Energie', 'Wende'],
  sozialemarktwirtschaft: ['Sozial', 'Markt', 'Wirtschaft'],
  maschinenbau: ['Maschine', 'Bau'],
  automobilindustrie: ['Automobil', 'Industrie'],
  kraftfahrzeug: ['Kraft', 'Fahrzeug'],
};

// Common German word components for algorithmic compound splitting
const NOUN_STEMS = [
  'bund', 'bundes', 'bahn', 'netz', 'strom', 'gas', 'energie', 'wirtschaft', 'gesetz',
  'recht', 'steuer', 'haushalt', 'ausbildung', 'förderung', 'schule', 'universität',
  'forschung', 'institut', 'gesellschaft', 'agentur', 'kraft', 'fahrzeug', 'auto',
  'mobil', 'verkehr', 'straße', 'schiene', 'zug', 'strecke', 'hoch', 'geschwindigkeit',
  'daten', 'schutz', 'verordnung', 'verfassung', 'gericht', 'preis', 'kosten', 'markt',
  'sozial', 'entwicklung', 'wasser', 'stoff', 'luft', 'umwelt', 'klima', 'politik',
  'stadt', 'land', 'kreis', 'amt', 'kanzler', 'minister', 'ministerium', 'vertrag',
  'versicherung', 'haftpflicht', 'betrieb', 'unternehmen', 'industrie', 'arbeit',
  'personal', 'kunde', 'service', 'beratung', 'elektro', 'technik', 'bau', 'meister'
];

/**
 * Normalizes text: handles lowercasing while preserving semantic umlauts
 */
export function normalizeGerman(text: string): string {
  return text.trim().toLowerCase();
}

/**
 * Tokenizes German text into clean alphanumeric words
 */
export function tokenizeGerman(text: string): string[] {
  // Matches German words including umlauts and ß
  const matches = text.match(/[a-zäöüß0-9]+/gi);
  if (!matches) return [];
  return matches.map((m) => m.toLowerCase());
}

/**
 * German Stemmer (based on German Snowball Stemming Algorithm)
 * Correctly strips plural endings, case declensions, and handles umlauts.
 */
export function stemGerman(word: string): string {
  let w = word.toLowerCase();

  // Handle special suffixes
  if (w.length <= 3) return w;

  // Step 1: Replace ß and standardize
  w = w.replace(/ß/g, 'ss');

  // Strip common inflectional endings in German (noun plurals, cases, adjectives)
  // -innen (feminine plural)
  if (w.endsWith('innen')) {
    w = w.slice(0, -5);
  } else if (w.endsWith('in') && w.length > 4) {
    w = w.slice(0, -2);
  }

  // -heiten, -keiten, -ungen, -schaften
  if (w.endsWith('heiten') || w.endsWith('keiten') || w.endsWith('ungen')) {
    w = w.slice(0, -2); // leaves -heit, -keit, -ung
  } else if (w.endsWith('schaften')) {
    w = w.slice(0, -2);
  }

  // Plurals and cases: -ern, -er, -en, -es, -e, -s
  if (w.endsWith('ern') && w.length > 5) {
    w = w.slice(0, -3);
  } else if (w.endsWith('en') && w.length > 4) {
    w = w.slice(0, -2);
  } else if (w.endsWith('es') && w.length > 4) {
    w = w.slice(0, -2);
  } else if (w.endsWith('er') && w.length > 4) {
    w = w.slice(0, -2);
  } else if (w.endsWith('e') && w.length > 3) {
    w = w.slice(0, -1);
  } else if (w.endsWith('s') && !w.endsWith('ss') && w.length > 4) {
    w = w.slice(0, -1);
  }

  return w;
}

/**
 * German Compound Splitter (Kompositzerlegung)
 * Breaks complex German words into constituent words and stems.
 */
export function splitGermanCompound(word: string): string[] {
  const clean = word.toLowerCase().replace(/[^a-zäöüß]/g, '');
  if (clean.length < 7) return [word];

  // 1. Check exact known dictionary
  if (GERMAN_KNOWN_COMPOUNDS[clean]) {
    return GERMAN_KNOWN_COMPOUNDS[clean];
  }

  // 2. Algorithmic compound splitting with interfix (Fugen-s, Fugen-en)
  const parts: string[] = [];
  let remaining = clean;

  for (let i = 0; i < 4; i++) {
    let matched = false;
    for (const stem of NOUN_STEMS) {
      if (remaining.startsWith(stem) && remaining.length > stem.length + 2) {
        parts.push(capitalize(stem));
        remaining = remaining.slice(stem.length);
        // Strip interfix (Fugen-s, Fugen-en, Fugen-e)
        if (remaining.startsWith('s') && !remaining.startsWith('st')) {
          remaining = remaining.slice(1);
        } else if (remaining.startsWith('en')) {
          remaining = remaining.slice(2);
        } else if (remaining.startsWith('e') && remaining.length > 3) {
          remaining = remaining.slice(1);
        }
        matched = true;
        break;
      }
    }
    if (!matched) break;
  }

  if (remaining.length >= 3) {
    parts.push(capitalize(remaining));
  }

  if (parts.length > 1) {
    return parts;
  }

  return [word];
}

function capitalize(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * German Spell Checker & Typo Corrector
 * Identifies common German typos, missing umlauts (ae/oe/ue or plain a/o/u), ss vs ß.
 */
export interface SpellCheckResult {
  hasCorrection: boolean;
  originalQuery: string;
  correctedQuery: string;
  suggestionMessage?: string;
}

const COMMON_SPELL_MAP: Record<string, string> = {
  munchen: 'München',
  muenchen: 'München',
  koln: 'Köln',
  koeln: 'Köln',
  nurnberg: 'Nürnberg',
  nuernberg: 'Nürnberg',
  dusseldorf: 'Düsseldorf',
  duesseldorf: 'Düsseldorf',
  strasse: 'Straße',
  bundeskanzleram: 'Bundeskanzleramt',
  bundesverfasungsgericht: 'Bundesverfassungsgericht',
  bavaria: 'Bayern',
  elektriker: 'Elektriker',
  energiwende: 'Energiewende',
  kraftfahrzeug: 'Kraftfahrzeug',
  haftflicht: 'Haftpflicht',
  osterreich: 'Österreich',
  oesterreich: 'Österreich',
  zurich: 'Zürich',
  zuerich: 'Zürich',
  strombörse: 'Strombörse',
  strompreis: 'Strompreis',
};

export function checkGermanSpelling(query: string): SpellCheckResult {
  const words = query.split(/\s+/);
  let changed = false;

  const correctedWords = words.map((w) => {
    const rawClean = w.toLowerCase().replace(/[^a-zäöüß]/g, '');
    if (COMMON_SPELL_MAP[rawClean]) {
      changed = true;
      return COMMON_SPELL_MAP[rawClean];
    }
    return w;
  });

  if (changed) {
    const correctedQuery = correctedWords.join(' ');
    return {
      hasCorrection: true,
      originalQuery: query,
      correctedQuery,
      suggestionMessage: `Meinten Sie: ${correctedQuery}?`,
    };
  }

  return {
    hasCorrection: false,
    originalQuery: query,
    correctedQuery: query,
  };
}

/**
 * Named Entity Recognizer for German Queries
 */
export function extractGermanEntities(query: string): string[] {
  const lower = query.toLowerCase();
  const entities: string[] = [];

  const KNOWN_ENTITIES = [
    { key: 'deutsche bahn', name: 'Deutsche Bahn AG' },
    { key: 'bundesbahn', name: 'Deutsche Bundesbahn' },
    { key: 'bundesverfassungsgericht', name: 'Bundesverfassungsgericht' },
    { key: 'bundesnetzagentur', name: 'Bundesnetzagentur' },
    { key: 'bundestag', name: 'Deutscher Bundestag' },
    { key: 'bundesregierung', name: 'Bundesregierung' },
    { key: 'fraunhofer', name: 'Fraunhofer-Gesellschaft' },
    { key: 'max-planck', name: 'Max-Planck-Gesellschaft' },
    { key: 'siemens', name: 'Siemens AG' },
    { key: 'bmw', name: 'BMW Group' },
    { key: 'volkswagen', name: 'Volkswagen AG' },
    { key: 'mercedes', name: 'Mercedes-Benz' },
    { key: 'ice 4', name: 'ICE 4' },
    { key: 'tgv duplex', name: 'TGV Duplex' },
    { key: 'münchen', name: 'München' },
    { key: 'munchen', name: 'München' },
    { key: 'berlin', name: 'Berlin' },
    { key: 'hamburg', name: 'Hamburg' },
    { key: 'köln', name: 'Köln' },
    { key: 'frankfurt', name: 'Frankfurt am Main' },
    { key: 'stuttgart', name: 'Stuttgart' },
    { key: 'leipzig', name: 'Leipzig' },
    { key: 'dresden', name: 'Dresden' },
    { key: '§ 823 bgb', name: '§ 823 BGB' },
    { key: '823 bgb', name: '§ 823 BGB' },
    { key: 'grundgesetz', name: 'Grundgesetz für die Bundesrepublik Deutschland' },
    { key: 'energiewende', name: 'Energiewende' },
    { key: 'soziale marktwirtschaft', name: 'Soziale Marktwirtschaft' },
    { key: 'kraftfahrzeughaftpflichtversicherung', name: 'Kraftfahrzeug-Haftpflichtversicherung' },
    { key: 'tum', name: 'Technische Universität München' },
    { key: 'lmu', name: 'Ludwig-Maximilians-Universität München' },
    { key: 'rwth', name: 'RWTH Aachen' },
  ];

  for (const ent of KNOWN_ENTITIES) {
    if (lower.includes(ent.key)) {
      entities.push(ent.name);
    }
  }

  return Array.from(new Set(entities));
}

/**
 * Classifies the intent of a German search query
 */
export function classifyQueryIntent(query: string): SearchIntent {
  const lower = query.toLowerCase();

  // Comparison intent (e.g. ICE 4 vs TGV Duplex)
  if (lower.includes(' vs ') || lower.includes(' versus ') || lower.includes('vergleich')) {
    return 'COMPARISON';
  }

  // Legal / Law intent
  if (lower.includes('§') || lower.includes('bgb') || lower.includes('gesetz') || lower.includes('urteil') || lower.includes('bgh') || lower.includes('grundgesetz')) {
    return 'LAW';
  }

  // Local intent (e.g. guter Elektriker in München, Restaurant Berlin)
  const localKeywords = ['in münchen', 'in berlin', 'in hamburg', 'in köln', 'in frankfurt', 'in stuttgart', 'in leipzig', 'in dresden', 'in nürnberg', 'nähe', 'lokal', 'vor ort', 'handwerker', 'elektriker', 'notdienst', 'arzt', 'öffnungszeiten'];
  if (localKeywords.some((k) => lower.includes(k))) {
    return 'LOCAL';
  }

  // News intent
  if (lower.includes('nachrichten') || lower.includes('aktuell') || lower.includes('heute') || lower.includes('eilmeldung') || lower.includes('politik') || lower.includes('schlagzeilen')) {
    return 'NEWS';
  }

  // Academic / Science
  if (lower.includes('studie') || lower.includes('wissenschaft') || lower.includes('forschung') || lower.includes('doi') || lower.includes('universität') || lower.includes('dissertation') || lower.includes('paper')) {
    return 'ACADEMIC';
  }

  // Document intent
  if (lower.includes('filetype:pdf') || lower.includes('pdf') || lower.includes('bericht') || lower.includes('formular') || lower.includes('antrag')) {
    return 'DOCUMENT';
  }

  // Image intent
  if (lower.startsWith('bild') || lower.startsWith('bilder') || lower.includes('fotos') || lower.includes('grafik')) {
    return 'IMAGE';
  }

  // Video intent
  if (lower.startsWith('video') || lower.includes('film') || lower.includes('dokumentation')) {
    return 'VIDEO';
  }

  // Default informational
  return 'INFORMATIONAL';
}

/**
 * Synonym Resolver for German search terms
 */
export const GERMAN_SYNONYMS: Record<string, string[]> = {
  auto: ['kraftfahrzeug', 'pkw', 'automobil', 'wagen', 'fahrzeug'],
  pkw: ['auto', 'kraftfahrzeug', 'automobil'],
  kraftfahrzeug: ['auto', 'pkw', 'automobil'],
  kaufen: ['erwerben', 'anschaffen'],
  hochschule: ['universität', 'uni', 'fakultät'],
  universität: ['hochschule', 'uni'],
  bundesbahn: ['deutsche bahn', 'db', 'bahn'],
  arzt: ['mediziner', 'doktor', 'praxis'],
  strompreis: ['energiepreis', 'stromkosten', 'kwh preis'],
  job: ['stelle', 'arbeitsplatz', 'karriere', 'beruf'],
};

export function resolveGermanSynonyms(term: string): string[] {
  const clean = term.toLowerCase();
  return GERMAN_SYNONYMS[clean] || [];
}
