/**
 * DEUTSCHSUCH - BM25 Retrieval & Hybrid Scoring Engine
 * Phase 8, 9, 14, 15: Okapi BM25 implementation with German field weighting,
 * compound matching, authority boosts and search operator filtering.
 */

import { IndexedDocument, ParsedSearchQuery, SearchHit, SearchQueryFilters } from './types';
import { stemGerman, tokenizeGerman, splitGermanCompound } from './germanEngine';

export class GermanBM25Index {
  private documents: IndexedDocument[] = [];
  // Inverted index: term -> Map<docId, termFrequency>
  private invertedIndex: Map<string, Map<string, number>> = new Map();
  // Document lengths in words for BM25 normalization
  private docLengths: Map<string, number> = new Map();
  private avgDocLength: number = 0;
  // Field-specific inverted indices for title and entities
  private titleIndex: Map<string, Set<string>> = new Map();
  private entityIndex: Map<string, Set<string>> = new Map();

  // Okapi BM25 parameters
  private readonly k1 = 1.2;
  private readonly b = 0.75;

  constructor(initialDocs: IndexedDocument[] = []) {
    this.indexDocuments(initialDocs);
  }

  public indexDocuments(docs: IndexedDocument[]) {
    this.documents = [...docs];
    this.invertedIndex.clear();
    this.docLengths.clear();
    this.titleIndex.clear();
    this.entityIndex.clear();

    let totalLength = 0;

    for (const doc of this.documents) {
      // Collect words from title, snippet, body and entities
      const titleTokens = tokenizeGerman(doc.title);
      const bodyTokens = tokenizeGerman(`${doc.headline || ''} ${doc.snippet} ${doc.body}`);
      const entityTokens = doc.entities.flatMap((e) => tokenizeGerman(e));

      // Title indexing
      for (const t of titleTokens) {
        const stem = stemGerman(t);
        if (!this.titleIndex.has(stem)) this.titleIndex.set(stem, new Set());
        this.titleIndex.get(stem)!.add(doc.id);
      }

      // Entity indexing
      for (const e of entityTokens) {
        const stem = stemGerman(e);
        if (!this.entityIndex.has(stem)) this.entityIndex.set(stem, new Set());
        this.entityIndex.get(stem)!.add(doc.id);
      }

      // All tokens combined with compound decomposition
      const allTokens = [...titleTokens, ...bodyTokens];
      const docLen = allTokens.length;
      this.docLengths.set(doc.id, docLen);
      totalLength += docLen;

      // Calculate term frequencies in this document
      const tfMap: Map<string, number> = new Map();
      for (const rawToken of allTokens) {
        const stem = stemGerman(rawToken);
        tfMap.set(stem, (tfMap.get(stem) || 0) + 1);

        // Also index compound constituents if applicable
        const compounds = splitGermanCompound(rawToken);
        if (compounds.length > 1) {
          for (const part of compounds) {
            const partStem = stemGerman(part);
            tfMap.set(partStem, (tfMap.get(partStem) || 0) + 0.6);
          }
        }
      }

      // Populate global inverted index
      for (const [term, freq] of tfMap.entries()) {
        if (!this.invertedIndex.has(term)) {
          this.invertedIndex.set(term, new Map());
        }
        this.invertedIndex.get(term)!.set(doc.id, freq);
      }
    }

    this.avgDocLength = this.documents.length > 0 ? totalLength / this.documents.length : 1;
  }

  public search(parsedQuery: ParsedSearchQuery, filters: SearchQueryFilters = {}): SearchHit[] {
    const N = this.documents.length;
    if (N === 0) return [];

    // 1. Pre-filter by strict operators (site:, -site:, filetype:, etc.)
    const candidateDocs = this.documents.filter((doc) => {
      // site: filter
      if (parsedQuery.siteFilters.length > 0) {
        const matchesSite = parsedQuery.siteFilters.some((s) => doc.domain.endsWith(s) || doc.domain === s);
        if (!matchesSite) return false;
      }
      if (filters.site) {
        if (!doc.domain.endsWith(filters.site) && doc.domain !== filters.site) return false;
      }

      // -site: excluded domains
      if (parsedQuery.excludedSites.length > 0) {
        const excluded = parsedQuery.excludedSites.some((s) => doc.domain.endsWith(s) || doc.domain === s);
        if (excluded) return false;
      }

      // filetype: filter
      const requiredType = parsedQuery.filetypeFilter || filters.filetype;
      if (requiredType) {
        if (doc.filetype !== requiredType) return false;
      }

      // country filter
      if (filters.country && filters.country !== 'ALL' && filters.country !== 'GLOBAL') {
        if (doc.country !== filters.country && doc.country !== 'GLOBAL') return false;
      }

      // language filter
      if (filters.language && filters.language !== 'all') {
        if (doc.language !== filters.language) return false;
      }

      // source type filter (e.g. government, academic, news)
      if (filters.sourceType && filters.sourceType !== 'all') {
        if (doc.documentType !== filters.sourceType) return false;
      }

      // Excluded words (-wort)
      if (parsedQuery.excludedWords.length > 0) {
        const docText = `${doc.title} ${doc.snippet} ${doc.body}`.toLowerCase();
        for (const ex of parsedQuery.excludedWords) {
          if (docText.includes(ex)) return false;
        }
      }

      // Exact phrases ("exakte Wortgruppe")
      if (parsedQuery.exactPhrases.length > 0) {
        const docFull = `${doc.title} ${doc.snippet} ${doc.body}`.toLowerCase();
        for (const phrase of parsedQuery.exactPhrases) {
          if (!docFull.includes(phrase.toLowerCase())) return false;
        }
      }

      return true;
    });

    // 2. Compute BM25 and hybrid relevance for candidate documents
    const queryStems = parsedQuery.stemmedTokens;
    // Include sub-compounds in query terms
    const expandedQueryStems = new Set<string>(queryStems);
    for (const [orig, parts] of Object.entries(parsedQuery.compounds)) {
      for (const p of parts) {
        expandedQueryStems.add(stemGerman(p));
      }
    }

    const hits: SearchHit[] = [];

    for (const doc of candidateDocs) {
      let bm25Score = 0;
      let titleMatches = 0;
      let entityMatches = 0;
      const matchReasons: string[] = [];

      const docLen = this.docLengths.get(doc.id) || this.avgDocLength;

      for (const term of expandedQueryStems) {
        const postingMap = this.invertedIndex.get(term);
        if (!postingMap) continue;

        const tf = postingMap.get(doc.id) || 0;
        if (tf > 0) {
          // Document frequency: number of documents containing this term
          const df = postingMap.size;
          // BM25 IDF: ln((N - df + 0.5) / (df + 0.5) + 1)
          const idf = Math.log((N - df + 0.5) / (df + 0.5) + 1.0);

          // BM25 Term Weight
          const termScore = idf * ((tf * (this.k1 + 1)) / (tf + this.k1 * (1 - this.b + this.b * (docLen / this.avgDocLength))));
          bm25Score += termScore;

          // Check title boost
          if (this.titleIndex.get(term)?.has(doc.id)) {
            bm25Score += idf * 2.5; // Title bonus
            titleMatches++;
          }

          // Check entity boost
          if (this.entityIndex.get(term)?.has(doc.id)) {
            bm25Score += idf * 1.8;
            entityMatches++;
          }
        }
      }

      // Law specific query match (e.g. § 823 BGB)
      if (doc.lawCode && parsedQuery.cleanText.toLowerCase().includes('823')) {
        bm25Score += 25.0;
        matchReasons.push('Direkter Gesetzestreffer');
      }

      // Local query match (city matches local business city)
      if (parsedQuery.localCity && doc.localData?.city.toLowerCase() === parsedQuery.localCity.toLowerCase()) {
        bm25Score += 20.0;
        matchReasons.push(`Lokales Ergebnis für ${doc.localData.city}`);
      }

      // Skip documents with zero BM25 score unless exact phrase or local matched
      if (bm25Score <= 0.05 && parsedQuery.exactPhrases.length === 0) {
        continue;
      }

      if (titleMatches > 0) matchReasons.push(`Übereinstimmung im Titel (${titleMatches})`);
      if (entityMatches > 0) matchReasons.push('Entitätsbezug erkannt');

      // Authority and Primary Source boost
      const authorityBoost = doc.primarySource ? 1.4 : doc.authorityScore >= 0.95 ? 1.25 : 1.0;
      if (doc.primarySource) matchReasons.push('Verifizierte Primärquelle');

      // Freshness boost (if news/recent)
      let freshnessBoost = 1.0;
      if (doc.documentType === 'news' || parsedQuery.intent === 'NEWS' || parsedQuery.intent === 'CURRENT_EVENT') {
        freshnessBoost = 1.0 + doc.freshnessScore * 0.4;
      }

      // Semantic / entity score component
      const semanticScore = (entityMatches * 2.0) + (doc.authorityScore * 3.0);

      // Final rank calculation
      const finalScore = (bm25Score * 1.5 + semanticScore) * authorityBoost * freshnessBoost;

      // Build highlighted snippet
      const highlightedSnippet = this.generateSnippet(doc, parsedQuery);

      hits.push({
        document: doc,
        bm25Score: Number(bm25Score.toFixed(3)),
        semanticScore: Number(semanticScore.toFixed(3)),
        authorityBoost: Number(authorityBoost.toFixed(2)),
        freshnessBoost: Number(freshnessBoost.toFixed(2)),
        finalScore: Number(finalScore.toFixed(3)),
        highlightedSnippet,
        matchReasons,
      });
    }

    // Sort descending by finalScore
    hits.sort((a, b) => b.finalScore - a.finalScore);

    return hits;
  }

  private generateSnippet(doc: IndexedDocument, query: ParsedSearchQuery): string {
    const rawSnippet = doc.snippet || doc.body.substring(0, 220);
    // Return clean snippet text
    return rawSnippet;
  }
}
