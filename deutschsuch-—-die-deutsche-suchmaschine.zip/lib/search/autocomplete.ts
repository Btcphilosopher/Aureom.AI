/**
 * DEUTSCHSUCH - German Autocomplete & Query Suggestions
 * Fast prefix lookup optimized for German vocabulary and topical trends.
 */

export const POPULAR_GERMAN_QUERIES = [
  'Wie hoch ist der aktuelle Strompreis in Deutschland?',
  'Wie funktioniert das deutsche Stromnetz?',
  'Deutsche Bahn Fahrplan und Verspätung',
  'deutsche Bundesbahn Geschichte',
  'Was ist die soziale Marktwirtschaft?',
  'site:bund.de Energiewende',
  'filetype:pdf Deutschland Wasserstoff',
  'aktuelle Nachrichten Deutschland Wirtschaft',
  'Universitäten München Maschinenbau',
  'deutsche Automobilindustrie 2030',
  'ICE 4 technische Daten',
  'ICE 4 vs TGV Duplex',
  'Kraftfahrzeughaftpflichtversicherung',
  'Bundesverfassungsgericht Grundgesetz',
  '§ 823 BGB Schadensersatzpflicht',
  'guter Elektriker in München',
  'Bundesnetzagentur Stromnetze',
  'Datenschutzgrundverordnung DSGVO Rechte',
  'Bundestagswahl Wahltermine',
  'Fraunhofer ISE Solarstudie',
];

export function getGermanSuggestions(input: string): string[] {
  const clean = input.trim().toLowerCase();
  if (!clean || clean.length < 2) return [];

  const matched = POPULAR_GERMAN_QUERIES.filter((q) => q.toLowerCase().includes(clean));

  if (matched.length > 0) {
    return matched.slice(0, 6);
  }

  // Dynamic prefix synthesis if no exact match
  if (clean.startsWith('bundes')) {
    return [
      'Bundesnetzagentur Stromnetze',
      'Bundesverfassungsgericht Grundgesetz',
      'Bundesregierung Wasserstoffstrategie',
      'Bundestagswahl Termine und Umfragen',
      'Bundesausbildungsförderungsgesetz BAföG',
    ];
  }
  if (clean.startsWith('strom')) {
    return [
      'Wie hoch ist der aktuelle Strompreis in Deutschland?',
      'Wie funktioniert das deutsche Stromnetz?',
      'Strompreisentwicklung für Industrie und Haushalte',
    ];
  }
  if (clean.startsWith('ice')) {
    return [
      'ICE 4 technische Daten',
      'ICE 4 vs TGV Duplex',
      'ICE Flotte Deutsche Bahn AG',
    ];
  }

  return [];
}
