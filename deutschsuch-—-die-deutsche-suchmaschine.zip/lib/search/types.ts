/**
 * DEUTSCHSUCH - Core Data Types & Interfaces
 * Phase 2 of Architecture
 */

export type DocumentType =
  | 'webpage'
  | 'news'
  | 'academic'
  | 'government'
  | 'enterprise'
  | 'law'
  | 'local'
  | 'pdf'
  | 'image'
  | 'video';

export type SearchIntent =
  | 'INFORMATIONAL'
  | 'NAVIGATIONAL'
  | 'TRANSACTIONAL'
  | 'LOCAL'
  | 'NEWS'
  | 'ACADEMIC'
  | 'DOCUMENT'
  | 'LAW'
  | 'IMAGE'
  | 'VIDEO'
  | 'COMPARISON'
  | 'CURRENT_EVENT';

export interface IndexedDocument {
  id: string;
  url: string;
  canonicalUrl: string;
  title: string;
  headline?: string;
  domain: string;
  snippet: string;
  body: string;
  metaDescription?: string;
  author?: string;
  publishedAt: string;
  crawledAt: string;
  lastModified?: string;
  language: 'de' | 'en' | 'fr' | 'it';
  country: 'DE' | 'AT' | 'CH' | 'EU' | 'GLOBAL';
  documentType: DocumentType;
  filetype?: 'html' | 'pdf' | 'docx' | 'txt';
  pageCount?: number;
  pdfDownloadUrl?: string;
  primarySource: boolean;
  authorityScore: number; // 0.0 - 1.0
  freshnessScore: number;
  entities: string[];
  topics: string[];
  contentHash: string;
  imageUrl?: string;
  // Specific metadata
  lawCode?: string; // e.g. "§ 823 BGB"
  academicDoi?: string; // e.g. "10.1002/..."
  localData?: {
    city: string;
    address: string;
    phone: string;
    rating: number;
    reviewsCount: number;
    openingHours: string;
    lat: number;
    lng: number;
  };
  videoData?: {
    duration: string;
    views: string;
    channel: string;
  };
}

export interface SearchQueryFilters {
  language?: string;
  country?: string;
  timeRange?: 'all' | '24h' | 'week' | 'month' | 'year';
  filetype?: string;
  sourceType?: string;
  site?: string;
  exactPhrase?: string;
  safeSearch?: 'strict' | 'moderate' | 'off';
  sort?: 'relevance' | 'date';
}

export interface ParsedSearchQuery {
  raw: string;
  cleanText: string;
  exactPhrases: string[];
  excludedWords: string[];
  siteFilters: string[];
  excludedSites: string[];
  filetypeFilter?: string;
  intitleTerms: string[];
  inurlTerms: string[];
  tokens: string[];
  stemmedTokens: string[];
  compounds: { [word: string]: string[] };
  intent: SearchIntent;
  detectedEntities: string[];
  temporalConstraint?: string;
  isComparison: boolean;
  comparisonEntities?: [string, string];
  localCity?: string;
}

export interface SearchHit {
  document: IndexedDocument;
  bm25Score: number;
  semanticScore: number;
  authorityBoost: number;
  freshnessBoost: number;
  finalScore: number;
  highlightedSnippet: string;
  matchReasons: string[];
}

export interface KnowledgeEntity {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  type: 'Unternehmen' | 'Behörde' | 'Gericht' | 'Ort' | 'Person' | 'Technologie' | 'Gesetz' | 'Konzept';
  attributes: { label: string; value: string; link?: string }[];
  website?: string;
  verifiedSource: string;
  sourceUrl: string;
  relatedEntities: string[];
  imageUrl?: string;
}

export interface ComparisonData {
  entityA: string;
  entityB: string;
  category: string;
  specs: { property: string; valA: string; valB: string }[];
  source: string;
  sourceUrl: string;
}

export interface SearchResponse {
  query: string;
  parsedQuery: ParsedSearchQuery;
  correctedQuery?: string;
  didYouMean?: string;
  totalResults: number;
  page: number;
  limit: number;
  durationMs: number;
  results: SearchHit[];
  knowledgeEntity?: KnowledgeEntity;
  comparison?: ComparisonData;
  aiOverview?: {
    summary: string;
    sourceConfidence: 'stark' | 'mittel' | 'begrenzt';
    citations: { index: number; title: string; domain: string; url: string; publishedAt: string }[];
  };
}
