/**
 * DEUTSCHSUCH - Synthetic Curated German Corpus
 * Phase 5 & 76: Authentic German Web Index spanning federal government,
 * science institutes, industries, press, legal codes, and local hubs.
 */

import { IndexedDocument } from './types';

export const GERMAN_CORPUS: IndexedDocument[] = [
  // 1. STROMNETZ & ENERGIEWIRTSCHAFT (Bundesnetzagentur, Fraunhofer ISE)
  {
    id: 'doc-bnetza-stromnetz-01',
    url: 'https://www.bundesnetzagentur.de/DE/Fachthemen/ElektrizitaetundGas/Stromnetze/start.html',
    canonicalUrl: 'https://www.bundesnetzagentur.de/DE/Fachthemen/ElektrizitaetundGas/Stromnetze/start.html',
    title: 'Bundesnetzagentur - Wie funktioniert das deutsche Stromnetz?',
    headline: 'Übertragungsnetze, Verteilnetze und Frequenzstabilität in Deutschland',
    domain: 'bundesnetzagentur.de',
    snippet: 'Das deutsche Stromnetz gliedert sich in vier Spannungsebenen: Höchstspannung (380 kV / 220 kV) der vier Übertragungsnetzbetreiber (50Hertz, Amprion, TenneT, TransnetBW) sowie Hoch-, Mittel- und Niederspannung zur Feinverteilung. Die Netzfrequenz von 50 Hz sichert die Systemstabilität bei volatiler Einspeisung aus Wind und Photovoltaik.',
    body: `Das deutsche Stromnetz ist eines der zuverlässigsten Verbundnetze weltweit mit einer durchschnittlichen Ausfallzeit von unter 12 Minuten pro Letztverbraucher und Jahr (SAIDI-Wert).
Struktur und Spannungsebenen:
1. Höchstspannungsnetz (380 kV und 220 kV): Transport über weite Entfernungen, betrieben von den vier Übertragungsnetzbetreibern (ÜNB) 50Hertz Transmission, Amprion, TenneT TSO und TransnetBW.
2. Hochspannungsnetz (110 kV): Regionale Verteilung an Großindustrie und Stadtwerke.
3. Mittelspannungsnetz (10 kV bis 30 kV): Lokale Unterverteilung an Gewerbebetriebe und Ortsnetzstationen.
4. Niederspannungsnetz (400 V / 230 V): Endkundenversorgung von Privathaushalten.
Herausforderungen der Energiewende: Der massive Zubau von Onshore- und Offshore-Windenergie im Norden und Photovoltaik im Süden erfordert den beschleunigten Netzausbau (SuedLink, SuedOstLink, A-Nord) und intelligente Smart-Grid-Systeme zur Redispatch-Minimierung.`,
    metaDescription: 'Offizielle Erklärung der Bundesnetzagentur zur Architektur des deutschen Stromnetzes, Spannungsebenen und Übertragungsnetzbetreiber.',
    author: 'Referat Netzentwicklung Strom, Bundesnetzagentur',
    publishedAt: '2026-03-12',
    crawledAt: '2026-04-01T08:15:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.98,
    freshnessScore: 0.92,
    entities: ['Bundesnetzagentur', 'Übertragungsnetzbetreiber', '50Hertz', 'Amprion', 'TenneT', 'TransnetBW', 'SuedLink'],
    topics: ['Stromnetz', 'Energie', 'Netzausbau', 'Infrastruktur'],
    contentHash: 'a7b8c9d0e1f2a3b4',
    imageUrl: '/images/german_energy_grid.jpg',
  },
  {
    id: 'doc-bmwk-strompreis-02',
    url: 'https://www.bmwk.de/Redaktion/DE/Artikel/Energie/strompreise-deutschland-analyse.html',
    canonicalUrl: 'https://www.bmwk.de/Redaktion/DE/Artikel/Energie/strompreise-deutschland-analyse.html',
    title: 'Bundesministerium für Wirtschaft und Klimaschutz - Aktuelle Strompreise in Deutschland',
    headline: 'Strompreise für Haushalte und Industrie: Zusammensetzung und Entwicklung',
    domain: 'bmwk.de',
    snippet: 'Wie hoch ist der aktuelle Strompreis in Deutschland? Im Bundesdurchschnitt zahlen Privathaushalte derzeit rund 37,2 Cent pro Kilowattstunde (kWh) für Neukundenverträge und 41,5 Cent im Bestand. Der Strompreis setzt sich zusammen aus Beschaffung und Vertrieb (ca. 42 %), Netzentgelten (ca. 27 %) sowie Steuern, Abgaben und Umlagen (ca. 31 %).',
    body: `Aktuelle Strompreisentwicklung in Deutschland:
Nach den historischen Spitzenwerten während der Energiekrise hat sich das Preisniveau auf den Großhandelsmärkten (EEX Strombörse Leipzig) stabilisiert.
Bestandteile des Haushaltsstrompreises:
- Energiebeschaffung und Marge des Versorgers: ca. 15,6 ct/kWh
- Netzentgelte für Übertragung und Verteilung: ca. 10,8 ct/kWh
- Gesetzliche Umlagen (KWKG-Umlage, Offshore-Netzumlage, § 19 StromNEV-Umlage): ca. 2,1 ct/kWh
- Stromsteuer: 2,05 ct/kWh
- Konzessionsabgabe an Kommunen: ca. 1,66 ct/kWh
- Umsatzsteuer (19 %): ca. 6,8 ct/kWh
Für energieintensive Industrieunternehmen greifen Entlastungspakete wie die Strompreiskompensation und die Absenkung der Stromsteuer auf das europäische Mindestmaß.`,
    author: 'Bundesministerium für Wirtschaft und Klimaschutz (BMWK)',
    publishedAt: '2026-04-02',
    crawledAt: '2026-04-05T10:20:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.99,
    freshnessScore: 0.98,
    entities: ['BMWK', 'Bundesnetzagentur', 'EEX Leipzig'],
    topics: ['Strompreis', 'Wirtschaft', 'Energie', 'Steuern'],
    contentHash: 'f4e3d2c1b0a9f8e7',
  },
  {
    id: 'doc-fraunhofer-energiewende-03',
    url: 'https://www.ise.fraunhofer.de/de/veroeffentlichungen/studien/aktuelle-fakten-zur-photovoltaik-und-erneuerbaren.html',
    canonicalUrl: 'https://www.ise.fraunhofer.de/de/veroeffentlichungen/studien/aktuelle-fakten-zur-photovoltaik-und-erneuerbaren.html',
    title: 'Fraunhofer ISE - Fakten zur Energiewende und Stromerzeugung in Deutschland',
    headline: 'Jahresauswertung öffentliche Nettostromerzeugung aus erneuerbaren Energien',
    domain: 'ise.fraunhofer.de',
    snippet: 'Fraunhofer-Institut für Solare Energiesysteme ISE: Die erneuerbaren Energien decken über 56 % der öffentlichen Nettostromerzeugung in Deutschland ab. Windkraft (Onshore und Offshore) und Photovoltaik sind die tragenden Säulen der deutschen Energiewende.',
    body: `Wissenschaftliche Analyse der Stromerzeugung in Deutschland:
Das Fraunhofer ISE dokumentiert auf Energy-Charts die Echtzeitdaten der deutschen Stromerzeugung.
Ergebnisse der aktuellen Studie:
1. Windenergie bleibt wichtigster Einzelerzeuger mit einem Anteil von über 31 % an der Jahreserzeugung.
2. Photovoltaik verzeichnet stetigen Zuwachs bei Dachanlagen und Freiflächen.
3. Batteriespeicher und Großbatterien stabilisieren zunehmend die Residuallast bei Spitzenzeiten.
4. Wasserstofffähige Gaskraftwerke (H2-ready) werden als Brückentechnologie für Dunkelflauten ausgebaut.`,
    author: 'Prof. Dr. Bruno Burger, Fraunhofer ISE Freiburg',
    publishedAt: '2026-01-20',
    crawledAt: '2026-02-11T14:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'academic',
    filetype: 'html',
    academicDoi: '10.24406/ise-2026-energy-charts',
    primarySource: true,
    authorityScore: 0.96,
    freshnessScore: 0.88,
    entities: ['Fraunhofer ISE', 'Energy-Charts', 'Photovoltaik', 'Windkraft'],
    topics: ['Wissenschaft', 'Energiewende', 'Erneuerbare Energien', 'Forschung'],
    contentHash: 'c1d2e3f4a5b6c7d8',
  },

  // 2. WASSERSTOFF & BUND.DE (PDF & Federal Strategy)
  {
    id: 'doc-bund-wasserstoff-pdf-04',
    url: 'https://www.bundesregierung.de/resource/blob/975226/nationale-wasserstoffstrategie-fortschreibung.pdf',
    canonicalUrl: 'https://www.bundesregierung.de/resource/blob/975226/nationale-wasserstoffstrategie-fortschreibung.pdf',
    title: 'Bundesregierung: Nationale Wasserstoffstrategie der Bundesrepublik Deutschland (PDF)',
    headline: 'Fortschreibung der Wasserstoffstrategie: Ausbauziel 10 GW Elektrolysekapazität bis 2030',
    domain: 'bundesregierung.de',
    snippet: 'Offizielles Strategiepapier der Bundesregierung (PDF, 68 Seiten): Maßnahmenplan für das deutsche Wasserstoff-Kernnetz, Importkorridore und den Einsatz von grünem Wasserstoff in Stahl-, Chemie- und Schwerlastverkehrsindustrie bis 2030.',
    body: `NATIONALE WASSERSTOFFSTRATEGIE DER BUNDESREGIERUNG (FORTSCHREIBUNG)
Beschluss des Bundeskabinetts.
Kernziele und Handlungsfelder:
- Elektrolyseleistung im Inland: Verdopplung des Zielwerts auf mindestens 10 Gigawatt (GW) bis 2030 zur Erzeugung von grünem Wasserstoff.
- Wasserstoff-Kernnetz (H2-Startnetz): Genehmigung eines über 9.700 km langen Leitungsnetzes durch die Bundesnetzagentur, zu über 60 % basierend auf umgewidmeten Erdgasleitungen.
- Importstrategie: Da Deutschland ca. 50-70 % seines Bedarfs importieren muss, werden Energiepartnerschaften mit Norwegen, Dänemark, Nordafrika und Namibia vertraglich abgesichert.
- Sektorkopplung: Prioritärer Einsatz von Wasserstoff in industriellen Prozessen ohne direkte Elektrifizierungsmöglichkeit (Primärstahlroute, Grundstoffchemie).`,
    author: 'Bundesregierung / Bundesministerium für Wirtschaft und Klimaschutz',
    publishedAt: '2025-11-15',
    crawledAt: '2026-03-01T09:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'pdf',
    pageCount: 68,
    pdfDownloadUrl: 'https://www.bundesregierung.de/resource/blob/975226/nationale-wasserstoffstrategie-fortschreibung.pdf',
    primarySource: true,
    authorityScore: 0.99,
    freshnessScore: 0.90,
    entities: ['Bundesregierung', 'Wasserstoff-Kernnetz', 'Elektrolyse', 'Grüner Wasserstoff'],
    topics: ['Wasserstoff', 'Energiepolitik', 'Industriepolitik', 'PDF'],
    contentHash: 'e9d8c7b6a5f4e3d2',
  },
  {
    id: 'doc-bund-energiewende-05',
    url: 'https://www.bund.de/DE/Themen/Energie/Energiewende/energiewende-zielsetzungen.html',
    canonicalUrl: 'https://www.bund.de/DE/Themen/Energie/Energiewende/energiewende-zielsetzungen.html',
    title: 'Bund.de - Das Informationsportal des Bundes: Die deutsche Energiewende',
    headline: 'Klimaneutralität bis 2045: Gesetzliche Grundlagen und Etappenziele',
    domain: 'bund.de',
    snippet: 'Das Bundesportal informiert über die Kernziele des Bundes-Klimaschutzgesetzes (KSG): 65 % Treibhausgasminderung bis 2030, 88 % bis 2040 und Treibhausgasneutralität bis 2045. Die Energiewende umfasst Strom, Wärme und Verkehrssektor.',
    body: `Die deutsche Energiewende auf einen Blick (Quelle: bund.de):
Gesetzliche Pfeiler:
1. Bundes-Klimaschutzgesetz (KSG): Verbindliche Jahresemissionsmengen für die Sektoren Energie, Industrie, Verkehr, Gebäude und Landwirtschaft.
2. Erneuerbare-Energien-Gesetz (EEG 2023/2026): Ziel: Mindestens 80 % des deutschen Bruttostromverbrauchs aus Erneuerbaren Energien bis 2030.
3. Wärmeplanungsgesetz und Gebäudeenergiegesetz (GEG): Umstellung der kommunalen Wärmeversorgung auf erneuerbare Quellen.
Bürgerbeteiligung, Netzausbau und Versorgungssicherheit stehen unter kontinuierlicher Aufsicht der Bundesnetzagentur.`,
    author: 'Bundesverwaltungsamt / Bundesministerium für Wirtschaft und Klimaschutz',
    publishedAt: '2026-02-18',
    crawledAt: '2026-03-15T12:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.99,
    freshnessScore: 0.91,
    entities: ['Bundesregierung', 'Bundes-Klimaschutzgesetz', 'Energiewende', 'EEG'],
    topics: ['Energiewende', 'Klimaschutz', 'Bundesportal'],
    contentHash: '7b8a9c0d1e2f3a4b',
  },

  // 3. DEUTSCHE BAHN & BUNDESBAHN & ICE 4
  {
    id: 'doc-db-ice4-technische-daten-06',
    url: 'https://www.deutschebahn.com/de/presse/hintergrund/ice4-technische-daten-flotte.html',
    canonicalUrl: 'https://www.deutschebahn.com/de/presse/hintergrund/ice4-technische-daten-flotte.html',
    title: 'Deutsche Bahn AG - ICE 4 (Baureihe 412): Technische Daten und Fakten',
    headline: 'Das Rückgrat des DB Fernverkehrs: 137 Züge von Siemens Mobility und Bombardier',
    domain: 'deutschebahn.com',
    snippet: 'Technische Daten des ICE 4 (Baureihe 412): Höchstgeschwindigkeit 265 km/h, Zuglänge bis zu 374 Meter (13-Teiler XXL) mit 918 Sitzplätzen. Antrieb durch autarke Powercars mit Einzelachsantrieb für hohe Redundanz und Energieeffizienz.',
    body: `FAKTENBLATT ICE 4 (BAUREIHE 412) - DEUTSCHE BAHN AG:
Der ICE 4 bildet das operative Rückgrat der Fernverkehrsflotte der Deutschen Bahn.
Wichtigste technische Spezifikationen:
- Hersteller: Siemens Mobility in Konsortium mit Bombardier Transportation (heute Alstom)
- Höchstgeschwindigkeit (Vmax): 265 km/h (zugelassen nach Software- und Fahrwerksupdate)
- Konfigurationen:
  * 7-teiliger Zug: 202 Meter Länge, 456 Sitzplätze
  * 12-teiliger Zug: 346 Meter Länge, 830 Sitzplätze
  * 13-teiliger XXL-Zug: 374 Meter Länge, 918 Sitzplätze, Platz für 8 Fahrräder
- Antriebskonzept: Modularer Powercar-Antrieb (keine Triebköpfe an den Zugenden), verbesserte Traktionsleistung und Redundanz.
- Energieeffizienz: Bis zu 22 % weniger Energieverbrauch pro Sitzplatz im Vergleich zum modernisierten ICE 1.
- Fahrgastkomfort: Reservierungsanzeigen, ETCS-Zugsicherung, WLAN, Bistro- und Speisewagen, barrierefreie Hublifte.`,
    author: 'Deutsche Bahn AG, Konzernkommunikation Berlin',
    publishedAt: '2026-02-10',
    crawledAt: '2026-03-05T07:30:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'enterprise',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.97,
    freshnessScore: 0.90,
    entities: ['Deutsche Bahn AG', 'ICE 4', 'Siemens Mobility', 'DB Fernverkehr'],
    topics: ['Bahn', 'ICE', 'Mobilität', 'Verkehr', 'Technik'],
    contentHash: '1a2b3c4d5e6f7a8b',
    imageUrl: '/images/ice_train_speed.jpg',
  },
  {
    id: 'doc-db-geschichte-bundesbahn-07',
    url: 'https://www.deutschebahn.com/de/konzern/geschichte/chronik_bahnreform_bundesbahn-1835-heute.html',
    canonicalUrl: 'https://www.deutschebahn.com/de/konzern/geschichte/chronik_bahnreform_bundesbahn-1835-heute.html',
    title: 'Deutsche Bahn - Von der Deutschen Bundesbahn zum modernen Mobilitätskonzern',
    headline: 'Geschichte der deutschen Eisenbahnen: Deutsche Bundesbahn, Deutsche Reichsbahn und Bahnreform 1994',
    domain: 'deutschebahn.com',
    snippet: 'Die Deutsche Bundesbahn (DB) war die staatliche Eisenbahn der Bundesrepublik Deutschland von 1949 bis zur Bahnreform am 1. Januar 1994. Durch die Zusammenführung von Deutscher Bundesbahn und Deutscher Reichsbahn entstand die privatrechtlich organisierte Deutsche Bahn AG mit Bundeseigentum.',
    body: `Chronik der Deutschen Bundesbahn und Bahnreform:
- 1949: Gründung der Deutschen Bundesbahn als Sondervermögen des Bundes mit Inkrafttreten des Bundesbahngesetzes.
- 1994: Bahnreform (Art. 87e Grundgesetz). Zusammenlegung von Deutscher Bundesbahn (West) und Deutscher Reichsbahn (Ost) zur Aktiengesellschaft Deutsche Bahn AG (DB AG) in 100-prozentigem Bundesbesitz.
- Struktur heute: Trennung von Eisenbahnverkehrsunternehmen (DB Fernverkehr, DB Regio, DB Cargo) und Eisenbahninfrastruktur (DB InfraGO AG).
- Hauptsitz: Berlin (Potsdamer Platz / BahnTower). Mitarbeiter: ca. 340.000 weltweit.`,
    author: 'Historische Sammlung der Deutschen Bahn AG',
    publishedAt: '2025-09-01',
    crawledAt: '2026-01-15T11:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'enterprise',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.96,
    freshnessScore: 0.85,
    entities: ['Deutsche Bundesbahn', 'Deutsche Bahn AG', 'Bahnreform 1994', 'DB InfraGO'],
    topics: ['Geschichte', 'Bundesbahn', 'Deutsche Bahn', 'Mobilität'],
    contentHash: '3f2e1d0c9b8a7f6e',
  },

  // 4. COMPARISON: ICE 4 VS TGV DUPLEX
  {
    id: 'doc-vergleich-ice4-tgv-08',
    url: 'https://www.eisenbahn-journal.de/technik-vergleich/ice-4-vs-tgv-duplex-daten-analyse.html',
    canonicalUrl: 'https://www.eisenbahn-journal.de/technik-vergleich/ice-4-vs-tgv-duplex-daten-analyse.html',
    title: 'Eisenbahn Magazin - Systemvergleich: ICE 4 vs. TGV Duplex im Detail',
    headline: 'Deutsches Powercar-Konzept versus französischer Doppelstock-Hochgeschwindigkeitszug',
    domain: 'eisenbahn-journal.de',
    snippet: 'ICE 4 vs TGV Duplex im direkten Vergleich: Der französische TGV Duplex erreicht bis zu 320 km/h auf separaten Neubaustrecken (LGV) mit Doppelstockwagen (510 Sitzplätze). Der ICE 4 ist auf 265 km/h und maximale Kapazität (bis 918 Sitzplätze im 13-Teiler XXL) im deutschen Mischverkehrsnetz optimiert.',
    body: `SYSTEMVERGLEICH HOCHGESCHWINDIGKEITSVERKEHR: ICE 4 VS. TGV DUPLEX
1. Höchstgeschwindigkeit:
- ICE 4: 265 km/h (optimiert für das deutsche Haltestellen- und Taktsystem mit kürzeren Stationsabständen).
- TGV Duplex: 320 km/h (optimiert für Punkt-zu-Punkt-Direktverbindungen auf französischen LGV-Strecken).
2. Wagen- und Kapazitätsarchitektur:
- ICE 4: Einzeltriebwagen mit stufenweisem Powercar-Konzept, Zuglänge 346–374 m, Kapazität: 830–918 Sitze.
- TGV Duplex: Doppelstockzug mit zwei Triebköpfen an den Enden und Jakobs-Drehgestellen, Zuglänge 200 m (400 m in Doppeltraktion), Kapazität: 510 Sitze pro Einheit.
3. Betreiber und Hersteller:
- ICE 4: Deutsche Bahn AG (Siemens Mobility / Alstom)
- TGV Duplex: SNCF Voyageurs (Alstom)
4. Einsatzgebiet:
- ICE 4: Deutschland, Schweiz, Österreich
- TGV Duplex: Frankreich, Deutschland, Schweiz, Spanien`,
    author: 'Dipl.-Ing. Markus Lindner, Eisenbahn Magazin',
    publishedAt: '2026-02-28',
    crawledAt: '2026-03-20T14:45:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'academic',
    filetype: 'html',
    primarySource: false,
    authorityScore: 0.91,
    freshnessScore: 0.89,
    entities: ['ICE 4', 'TGV Duplex', 'Deutsche Bahn AG', 'SNCF', 'Siemens Mobility', 'Alstom'],
    topics: ['Vergleich', 'ICE 4 vs TGV Duplex', 'Eisenbahn', 'Technik'],
    contentHash: '4b5a6c7d8e9f0a1b',
  },

  // 5. SOZIALE MARKTWIRTSCHAFT (BMWK / Bundeszentrale für politische Bildung)
  {
    id: 'doc-bpb-soziale-marktwirtschaft-09',
    url: 'https://www.bpb.de/themen/wirtschaft/lexikon-der-wirtschaft/20658/soziale-marktwirtschaft/',
    canonicalUrl: 'https://www.bpb.de/themen/wirtschaft/lexikon-der-wirtschaft/20658/soziale-marktwirtschaft/',
    title: 'Bundeszentrale für politische Bildung: Was ist die soziale Marktwirtschaft?',
    headline: 'Grundprinzipien der Wirtschaftsordnung der Bundesrepublik Deutschland',
    domain: 'bpb.de',
    snippet: 'Die soziale Marktwirtschaft ist die Wirtschaftsordnung der Bundesrepublik Deutschland. Sie verbindet die Freiheit der Marktmechanismen (Wettbewerb, freie Preisbildung, Privateigentum) mit dem Prinzip des sozialen Ausgleichs (Sozialversicherungen, Kündigungsschutz, Kartellrecht). Begründet von Ludwig Erhard und Alfred Müller-Armack.',
    body: `LEITFADEN SOZIALE MARKTWIRTSCHAFT (BPB):
Grundlegende Definition:
Die Konzeption der Sozialen Marktwirtschaft basiert auf den theoretischen Grundlagen des Ordoliberalismus (Freiburger Schule: Walter Eucken, Franz Böhm).
Zentrale Säulen:
1. Konstituierende Prinzipien:
- Funktionsfähiges Preissystem bei vollständiger Konkurrenz
- Primat der Währungspolitik (Geldwertstabilität durch unabhängige Notenbank)
- Offene Märkte und Privateigentum an Produktionsmitteln
- Vertragsfreiheit und Haftungsprinzip (wer entscheidet, haftet)
2. Soziale Flankierung:
- Gesetzliche Sozialversicherung (Kranken-, Renten-, Pflege-, Arbeitslosen- und Unfallversicherung)
- Strenges Kartellrecht (Bundeskartellamt zur Vermeidung von Monopolen und Marktmachtmissbrauch)
- Tarifautonomie und Mitbestimmung von Arbeitnehmern
- Chancengleichheit durch Bildungs- und Förderpolitik (z.B. BAföG).`,
    author: 'Bundeszentrale für politische Bildung (bpb)',
    publishedAt: '2025-10-10',
    crawledAt: '2026-02-01T10:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.99,
    freshnessScore: 0.88,
    entities: ['Soziale Marktwirtschaft', 'Ludwig Erhard', 'Alfred Müller-Armack', 'Walter Eucken', 'Bundeskartellamt'],
    topics: ['Wirtschaft', 'Politik', 'Gesellschaft', 'Definition'],
    contentHash: '7c8b9a0f1e2d3c4b',
  },

  // 6. RECHT & GESETZE: § 823 BGB & BUNDESVERFASSUNGSGERICHT
  {
    id: 'doc-gesetze-823-bgb-10',
    url: 'https://www.gesetze-im-internet.de/bgb/__823.html',
    canonicalUrl: 'https://www.gesetze-im-internet.de/bgb/__823.html',
    title: '§ 823 BGB - Schadensersatzpflicht (Bürgerliches Gesetzbuch)',
    headline: 'Bundesministerium der Justiz und Bundesamt für Justiz - Amtlicher Gesetzestext',
    domain: 'gesetze-im-internet.de',
    snippet: '§ 823 Bürgerliches Gesetzbuch (BGB) - Schadensersatzpflicht: (1) Wer vorsätzlich oder fahrlässig das Leben, den Körper, die Gesundheit, die Freiheit, das Eigentum oder ein sonstiges Recht eines anderen widerrechtlich verletzt, ist dem anderen zum Ersatz des daraus entstehenden Schadens verpflichtet. (2) Die gleiche Verpflichtung trifft denjenigen, welcher gegen den Schutz eines anderen bezweckendes Gesetz verstößt.',
    body: `BÜRGERLICHES GESETZBUCH (BGB) - BUCH 2: RECHT DER SCHULDVERHÄLTNISSE
§ 823 Schadensersatzpflicht:
(1) Wer vorsätzlich oder fahrlässig das Leben, den Körper, die Gesundheit, die Freiheit, das Eigentum oder ein sonstiges Recht eines anderen widerrechtlich verletzt, ist dem anderen zum Ersatz des daraus entstehenden Schadens verpflichtet.
(2) Die gleiche Verpflichtung trifft welchen, welcher gegen ein den Schutz eines anderen bezweckendes Gesetz verstößt. Ist nach dem Inhalt des Gesetzes ein Verstoß gegen dieses auch ohne Verschulden möglich, so tritt die Ersatzpflicht nur im Falle des Verschuldens ein.
Prüfungsschema des § 823 Abs. 1 BGB:
I. Tatbestand
1. Rechtsgutsverletzung (Leben, Körper, Gesundheit, Freiheit, Eigentum, sonstiges Recht wie allg. Persönlichkeitsrecht oder Recht am eingerichteten Gewerbebetrieb)
2. Verletzungshandlung (Tun oder pflichtwidriges Unterlassen)
3. Haftungsbegründende Kausalität (Äquivalenz, Adäquanz, Schutzzweck der Norm)
II. Rechtswidrigkeit (wird bei unmittelbarer Verletzung indiziert)
III. Verschulden (Vorsatz oder Fahrlässigkeit nach § 276 BGB)
IV. Rechtsfolge: Schadensersatz nach §§ 249 ff. BGB.`,
    author: 'Bundesamt für Justiz / Bundesministerium der Justiz',
    publishedAt: '2026-01-01',
    crawledAt: '2026-02-15T09:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'law',
    filetype: 'html',
    lawCode: '§ 823 BGB',
    primarySource: true,
    authorityScore: 1.0,
    freshnessScore: 0.95,
    entities: ['BGB', '§ 823 BGB', 'Schadensersatz', 'Bundesministerium der Justiz'],
    topics: ['Recht', 'Gesetz', 'BGB', 'Deliktsrecht', 'Schadensersatz'],
    contentHash: '8a9b0c1d2e3f4a5b',
  },
  {
    id: 'doc-bverfg-grundgesetz-11',
    url: 'https://www.bundesverfassungsgericht.de/DE/Das-Gericht/Aufgaben/aufgaben_node.html',
    canonicalUrl: 'https://www.bundesverfassungsgericht.de/DE/Das-Gericht/Aufgaben/aufgaben_node.html',
    title: 'Bundesverfassungsgericht - Hüter des Grundgesetzes für die Bundesrepublik Deutschland',
    headline: 'Zuständigkeiten, Verfassungsbeschwerde, Normenkontrolle und Organstreitverfahren',
    domain: 'bundesverfassungsgericht.de',
    snippet: 'Das Bundesverfassungsgericht (BVerfG) in Karlsruhe ist das oberste Verfassungsorgan der deutschen Gerichtsbarkeit. Es wacht über die Einhaltung des Grundgesetzes und sichert die Grundrechte aller Bürgerinnen und Bürger. Seine Entscheidungen sind für alle Verfassungsorgane von Bund und Ländern bindend.',
    body: `DAS BUNDESVERFASSUNGSGERICHT IN KARLSRUHE:
Verfassungsrechtliche Stellung:
Gemäß Artikel 93 und 94 Grundgesetz (GG) entscheidet das BVerfG unter anderem über:
- Verfassungsbeschwerden (Art. 93 Abs. 1 Nr. 4a GG): Kann von jedermann erhoben werden, der sich durch die öffentliche Gewalt in einem seiner Grundrechte verletzt fühlt.
- Konkrete Normenkontrolle (Art. 100 GG): Prüfung der Verfassungsmäßigkeit von Gesetzen auf Vorlage eines Fachgerichts.
- Abstrakte Normenkontrolle: Prüfung auf Antrag von Bundesregierung, Landesregierung oder einem Viertel der Mitglieder des Bundestages.
- Organstreitigkeiten zwischen obersten Bundesorganen.
Organisation:
Das Gericht gliedert sich in zwei Senate mit jeweils acht Richterinnen und Richtern, die je zur Hälfte vom Bundestag und vom Bundesrat mit Zwei-Drittel-Mehrheit gewählt werden. Amtszeit: 12 Jahre.`,
    author: 'Pressestelle des Bundesverfassungsgerichts, Karlsruhe',
    publishedAt: '2026-03-08',
    crawledAt: '2026-03-25T11:20:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 1.0,
    freshnessScore: 0.94,
    entities: ['Bundesverfassungsgericht', 'Grundgesetz', 'Karlsruhe', 'Verfassungsbeschwerde'],
    topics: ['Recht', 'Verfassungsrecht', 'Grundrechte', 'Gericht'],
    contentHash: '5e6f7a8b9c0d1e2f',
  },

  // 7. KRAFTFAHRZEUG-HAFTPFLICHTVERSICHERUNG (Kompositum & GDV)
  {
    id: 'doc-gdv-kfz-haftpflicht-12',
    url: 'https://www.gdv.de/gdv/themen/schaden-unfall/kraftfahrzeughaftpflichtversicherung-leitfaden-deckung.html',
    canonicalUrl: 'https://www.gdv.de/gdv/themen/schaden-unfall/kraftfahrzeughaftpflichtversicherung-leitfaden-deckung.html',
    title: 'Gesamtverband der Versicherer (GDV) - Kraftfahrzeughaftpflichtversicherung in Deutschland',
    headline: 'Gesetzliche Pflichtversicherung nach PflVG, Deckungssummen und Schadensregulierung',
    domain: 'gdv.de',
    snippet: 'Die Kraftfahrzeughaftpflichtversicherung (Kfz-Haftpflicht) ist in Deutschland nach dem Pflichtversicherungsgesetz (PflVG) für jedes zum Straßenverkehr zugelassene Kraftfahrzeug vorgeschrieben. Sie deckt Personen-, Sach- und Vermögensschäden ab, die Dritten durch den Betrieb des Fahrzeugs entstehen.',
    body: `LEITFADEN KRAFTFAHRZEUGHAFTPFLICHTVERSICHERUNG (GDV):
Rechtliche Grundlagen und Deckungsumfang:
- Pflichtcharakter: Ohne Nachweis des Versicherungsschutzes (elektronische Versicherungsbestätigung, eVB-Nummer) verweigert die Zulassungsbehörde die Zulassung des Fahrzeugs.
- Gesetzliche Mindestdeckungssummen nach § 4 PflVG:
  * 7,5 Millionen Euro für Personenschäden
  * 1,22 Millionen Euro für Sachschäden
  * 50.000 Euro für reine Vermögensschäden
- Marktübliche Deckung: Seriöse Versicherer bieten pauschal 100 Millionen Euro Deckungssumme (maximal 15 Mio. Euro je geschädigte Person).
- Schadenfreiheitsrabatt (SFR): Das System der Schadenfreiheitsklassen (SF-Klassen) belohnt unfallfreies Fahren mit sinkenden Beitragssätzen.
- Abgrenzung: Die Kfz-Haftpflicht schützt fremde Geschädigte. Eigenschäden am Fahrzeug erfordern eine Teilkasko- oder Vollkaskoversicherung.`,
    author: 'Gesamtverband der Deutschen Versicherungswirtschaft e.V. (GDV)',
    publishedAt: '2026-02-14',
    crawledAt: '2026-03-10T16:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'enterprise',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.95,
    freshnessScore: 0.91,
    entities: ['GDV', 'Kraftfahrzeughaftpflichtversicherung', 'PflVG', 'Kfz-Versicherung'],
    topics: ['Versicherung', 'Kraftfahrzeug', 'Haftpflicht', 'Kfz', 'Verkehr'],
    contentHash: '9a8b7c6d5e4f3a2b',
  },

  // 8. UNIVERSITÄTEN MÜNCHEN: MASCHINENBAU (TUM & LMU)
  {
    id: 'doc-tum-maschinenbau-13',
    url: 'https://www.ed.tum.de/ed/studium/studiengaenge/maschinenwesen-b-sc/',
    canonicalUrl: 'https://www.ed.tum.de/ed/studium/studiengaenge/maschinenwesen-b-sc/',
    title: 'Technische Universität München (TUM) - Maschinenbau & Maschinenwesen (B.Sc. / M.Sc.)',
    headline: 'TUM School of Engineering and Design: Spitzenforschung am Forschungscampus Garching',
    domain: 'tum.de',
    snippet: 'Universitäten München Maschinenbau: Die Technische Universität München (TUM) gehört im Maschinenbau weltweit zur Spitzengruppe. Der Studiengang Maschinenwesen am Campus Garching umfasst Thermodynamik, Werkstoffkunde, Konstruktionslehre, Mechatronik und KI in der Produktion.',
    body: `STUDIUM MASCHINENBAU & MASCHINENWESEN AN DER TUM MÜNCHEN:
Standort: Campus Garching bei München.
Fakultät: TUM School of Engineering and Design.
Profil des Studiengangs:
- Bachelor of Science (B.Sc., 6 Semester) und Master of Science (M.Sc., 4 Semester)
- Kernkompetenzen: Höhere Mathematik, Technische Mechanik, Strömungsmechanik, Regelungstechnik, Robotik und Leichtbau.
- Forschungsschwerpunkte: Additive Fertigung (3D-Druck), nachhaltige Wasserstoffantriebe, autonome Produktionssysteme, Computational Mechanics.
- Exzellenzinitiative: Die TUM ist seit 2006 kontinuierlich als Exzellenzuniversität ausgezeichnet und pflegt enge Kooperationen mit Unternehmen wie BMW, Siemens, MAN und Airbus.`,
    author: 'TUM School of Engineering and Design, München/Garching',
    publishedAt: '2026-01-15',
    crawledAt: '2026-02-20T13:30:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'academic',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.98,
    freshnessScore: 0.90,
    entities: ['Technische Universität München', 'TUM', 'München', 'Maschinenbau'],
    topics: ['Universitäten', 'München', 'Maschinenbau', 'Ingenieurwissenschaften', 'Studium'],
    contentHash: '2c3d4e5f6a7b8c9d',
  },

  // 9. AUTOMOBILINDUSTRIE 2030 (VDA & Handelsblatt)
  {
    id: 'doc-vda-auto-2030-14',
    url: 'https://www.vda.de/de/themen/wirtschaft-und-politik/transformation-der-automobilindustrie-2030.html',
    canonicalUrl: 'https://www.vda.de/de/themen/wirtschaft-und-politik/transformation-der-automobilindustrie-2030.html',
    title: 'Verband der Automobilindustrie (VDA) - Deutsche Automobilindustrie 2030',
    headline: 'Elektromobilität, Software-defined Vehicles und Batteriezellfertigung in Deutschland',
    domain: 'vda.de',
    snippet: 'Strategiebericht des VDA zur Transformation der deutschen Automobilindustrie bis 2030: Investitionen von über 280 Milliarden Euro in Forschung und Entwicklung für Batterietechnologie, softwaredefinierte Fahrzeuge und autonome Fahrassistenten der Stufe 3 und 4.',
    body: `TRANSFORMATION DER DEUTSCHEN AUTOMOBILINDUSTRIE BIS 2030 (VDA):
Wirtschaftliche Leitdaten:
- Beschäftigung: Über 780.000 Kernarbeitsplätze in Deutschland bei Herstellern (OEMs wie BMW, Mercedes-Benz, Volkswagen) und Zulieferern (Bosch, ZF, Continental).
- Antriebswende: Bis 2030 strebt der deutsche Markt einen Anteil von über 60 % reinen Batterie-Elektrofahrzeugen (BEV) an Neuzulassungen an.
- Schlüsselthemen:
  1. Softwarearchitektur: Übergang zu zentralen Fahrzeugrechnern und herstellereigenen Betriebssystemen (z.B. MB.OS, CARIAD).
  2. Batteriezellfertigung: Aufbau europäischer Gigafactories zur Reduzierung asiatischer Lieferkettenabhängigkeiten.
  3. Kreislaufwirtschaft: Recyclingquoten von über 90 % für Lithium, Nickel und Kobalt gemäß EU-Batterieverordnung.`,
    author: 'Verband der Automobilindustrie e.V. (VDA), Berlin',
    publishedAt: '2026-03-01',
    crawledAt: '2026-03-28T10:15:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'enterprise',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.95,
    freshnessScore: 0.96,
    entities: ['VDA', 'Automobilindustrie', 'Volkswagen', 'BMW', 'Mercedes-Benz', 'Bosch'],
    topics: ['Automobilindustrie', 'Wirtschaft', 'Elektromobilität', '2030'],
    contentHash: '3d4e5f6a7b8c9d0e',
  },

  // 10. AKTUELLE NACHRICHTEN DEUTSCHLAND WIRTSCHAFT (Tagesschau & Handelsblatt)
  {
    id: 'doc-tagesschau-wirtschaft-news-15',
    url: 'https://www.tagesschau.de/wirtschaft/konjunktur-deutschland-wachstumsinitiative-ifo-index-100.html',
    canonicalUrl: 'https://www.tagesschau.de/wirtschaft/konjunktur-deutschland-wachstumsinitiative-ifo-index-100.html',
    title: 'Tagesschau - Deutsche Wirtschaft: Ifo-Geschäftsklimaindex signalisiert Erholung',
    headline: 'Stimmungsaufschwung im verarbeitenden Gewerbe und bei Dienstleistern',
    domain: 'tagesschau.de',
    snippet: 'Aktuelle Wirtschaftsnachrichten Deutschland: Der Ifo-Geschäftsklimaindex ist den dritten Monat in Folge gestiegen. Insbesondere die Erwartungen der exportorientierten Industrieunternehmen haben sich aufgehellt. Sinkende Energiepreise und die geldpolitische Zinswende stützen Investitionen.',
    body: `TAGESSCHAU WIRTSCHAFTSTREND:
Der ifo Geschäftsklimaindex für Deutschland hat im laufenden Quartal deutlich zugelegt.
Wichtigste Faktoren laut ifo-Präsident Clemens Fuest:
- Verarbeitendes Gewerbe: Der Auftragsbestand im Maschinenbau und in der Elektroindustrie stabilisiert sich.
- Inflation: Die Teuerungsrate in Deutschland liegt bei 2,2 %, was die Reallöhne und den privaten Konsum stärkt.
- Bauwirtschaft: Zwar bleibt der Wohnungsbau gedämpft, gewerbliche Infrastrukturinvestitionen und Sanierungsaufträge zeigen jedoch kräftige Zuwächse.
- Reaktionen der Bundesregierung: Wirtschaftsminister betont die Notwendigkeit von Bürokratieabbau und schnelleren Genehmigungsverfahren für Fabriken.`,
    author: 'Tagesschau Wirtschaftsredaktion, ARD-Hauptstadtstudio',
    publishedAt: '2026-04-08T07:45:00Z',
    crawledAt: '2026-04-08T08:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'news',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.97,
    freshnessScore: 1.0,
    entities: ['Tagesschau', 'Ifo-Institut', 'Deutsche Wirtschaft', 'Bundesregierung'],
    topics: ['Nachrichten', 'Wirtschaft', 'Konjunktur', 'Deutschland', 'Aktuell'],
    contentHash: '8e9f0a1b2c3d4e5f',
    imageUrl: '/images/reichstag_dome_news.jpg',
  },

  // 11. LOKALE SUCHE: ELEKTRIKER IN MÜNCHEN
  {
    id: 'doc-lokal-elektriker-muenchen-16',
    url: 'https://www.elektro-meister-muenchen.de/leistungen-notdienst-preise.html',
    canonicalUrl: 'https://www.elektro-meister-muenchen.de/leistungen-notdienst-preise.html',
    title: 'Elektro Meisterbetrieb München GmbH - Elektroinstallation & 24h Notdienst',
    headline: 'Zertifizierter Innungsbetrieb für München, Schwabing, Bogenhausen und Sendling',
    domain: 'elektro-meister-muenchen.de',
    snippet: 'Guter Elektriker in München gesucht? Elektro Meisterbetrieb München GmbH bietet fachgerechte Hausinstallation, Smart-Home-Lösungen, Wallbox-Montage und 24h-Elektronotdienst. Ausgezeichnet mit 4,9 Sternen bei über 340 Kundenbewertungen.',
    body: `ELEKTRO MEISTERBETRIEB MÜNCHEN GMBH - IHR INNUNGSFACHBETRIEB
Leistungen:
- Komplette Neuinstallation und Altbausanierung nach VDE-Richtlinien
- Zählerschrankerneuerung und E-Check für Wohnungen und Gewerbe
- Montage von PV-Anlagen, Wechselrichtern und E-Auto-Wallboxen
- 24/7 Notdienst bei Stromausfall und Kurzschluss in ganz München
Adresse: Leopoldstraße 184, 80804 München (Schwabing)
Telefon: +49 89 36098000
Öffnungszeiten: Mo-Fr 07:30 - 18:00 Uhr (Notdienst 24 Stunden erreichbar)
Bewertungen: 4,9 von 5 Sternen (342 geprüfte Bewertungen auf Google & Handwerkskammer München).`,
    author: 'Elektromeister Thomas Huber, Handwerkskammer München und Oberbayern',
    publishedAt: '2026-03-01',
    crawledAt: '2026-03-25T15:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'local',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.90,
    freshnessScore: 0.88,
    entities: ['München', 'Elektro Meisterbetrieb München', 'Handwerkskammer München'],
    topics: ['Lokal', 'Elektriker', 'München', 'Handwerk', 'Notdienst'],
    contentHash: '5f6a7b8c9d0e1f2a',
    localData: {
      city: 'München',
      address: 'Leopoldstraße 184, 80804 München',
      phone: '+49 89 36098000',
      rating: 4.9,
      reviewsCount: 342,
      openingHours: 'Mo-Fr: 07:30–18:00 Uhr · 24h Notdienst',
      lat: 48.175,
      lng: 11.589,
    },
  },
  {
    id: 'doc-lokal-elektro-schmid-muenchen-17',
    url: 'https://www.elektro-schmid-sendling.de/ueber-uns.html',
    canonicalUrl: 'https://www.elektro-schmid-sendling.de/ueber-uns.html',
    title: 'Elektro Schmid München-Sendling - Fachbetrieb für Elektrotechnik',
    headline: 'Traditionsunternehmen seit 1968: Ihr zuverlässiger Elektriker in München',
    domain: 'elektro-schmid-sendling.de',
    snippet: 'Elektro Schmid ist Ihr Elektriker-Fachbetrieb in München-Sendling. Wir planen und installieren elektrotechnische Anlagen, Beleuchtungskonzepte und Wärmepumpen-Stromanschlüsse mit Festpreisgarantie.',
    body: `Elektro Schmid München: Zuverlässige Handwerksqualität im Herzen von München.
Adresse: Plinganserstraße 45, 81369 München
Telefon: +49 89 772211
Öffnungszeiten: Mo-Do 07:00 - 16:30 Uhr, Fr 07:00 - 13:00 Uhr
Bewertung: 4,8 von 5 Sternen (189 Bewertungen).`,
    author: 'Elektro Schmid GmbH, München',
    publishedAt: '2026-02-15',
    crawledAt: '2026-03-12T14:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'local',
    filetype: 'html',
    primarySource: false,
    authorityScore: 0.88,
    freshnessScore: 0.85,
    entities: ['München', 'Elektro Schmid'],
    topics: ['Lokal', 'Elektriker', 'München'],
    contentHash: '6a7b8c9d0e1f2a3b',
    localData: {
      city: 'München',
      address: 'Plinganserstraße 45, 81369 München',
      phone: '+49 89 772211',
      rating: 4.8,
      reviewsCount: 189,
      openingHours: 'Mo-Do: 07:00–16:30 Uhr, Fr: 07:00–13:00 Uhr',
      lat: 48.118,
      lng: 11.541,
    },
  },

  // 12. DATENSCHUTZGRUNDVERORDNUNG (DSGVO / BfDI)
  {
    id: 'doc-bfdi-dsgvo-18',
    url: 'https://www.bfdi.bund.de/DE/Buerger/Inhalte/Datenschutz/Allgemein/dsgvo-uebersicht.html',
    canonicalUrl: 'https://www.bfdi.bund.de/DE/Buerger/Inhalte/Datenschutz/Allgemein/dsgvo-uebersicht.html',
    title: 'Der Bundesbeauftragte für den Datenschutz (BfDI) - Datenschutzgrundverordnung',
    headline: 'DSGVO Leitfaden: Grundsätze der Datenverarbeitung und Betroffenenrechte',
    domain: 'bfdi.bund.de',
    snippet: 'Die Datenschutzgrundverordnung (DSGVO / Verordnung (EU) 2016/679) regelt EU-weit den Schutz personenbezogener Daten. Grundprinzipien sind Rechtmäßigkeit, Treu und Glauben, Transparenz, Zweckbindung, Datenminimierung und Speicherbegrenzung.',
    body: `DATENSCHUTZGRUNDVERORDNUNG (DSGVO) - LEITFADEN DES BFDI:
Zentrale Betroffenenrechte (Art. 12-23 DSGVO):
- Art. 15 DSGVO: Recht auf Auskunft über gespeicherte personenbezogene Daten.
- Art. 16 & 17 DSGVO: Recht auf Berichtigung und Recht auf Löschung ("Recht auf Vergessenwerden").
- Art. 18 & 20 DSGVO: Einschränkung der Verarbeitung und Datenübertragbarkeit.
- Art. 21 DSGVO: Widerspruchsrecht gegen Direktwerbung und Profiling.
Technische Anforderungen: Privacy by Design und Privacy by Default nach Art. 25 DSGVO.`,
    author: 'Der Bundesbeauftragte für den Datenschutz und die Informationsfreiheit (BfDI), Bonn',
    publishedAt: '2026-01-10',
    crawledAt: '2026-02-28T09:30:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.99,
    freshnessScore: 0.91,
    entities: ['BfDI', 'DSGVO', 'Datenschutz', 'Bundesbeauftragter für den Datenschutz'],
    topics: ['Datenschutz', 'DSGVO', 'Recht', 'Privatsphäre'],
    contentHash: '7b8c9d0e1f2a3b4c',
  },

  // 13. SIEMENS AG & DEUTSCHE INDUSTRIE
  {
    id: 'doc-siemens-automatisierung-19',
    url: 'https://www.siemens.com/de/de/unternehmen/nachhaltigkeit-technologie/industrie-40-deutschland.html',
    canonicalUrl: 'https://www.siemens.com/de/de/unternehmen/nachhaltigkeit-technologie/industrie-40-deutschland.html',
    title: 'Siemens AG - Digitale Industrie und Automatisierungstechnologien in Deutschland',
    headline: 'Siemens Xcelerator: Industrielle KI, digitaler Zwilling und Energieeffizienz',
    domain: 'siemens.com',
    snippet: 'Siemens AG: Führender Technologiekonzern für Automatisierung, Digitalisierung und Schieneninfrastruktur. Hauptsitz in München und Berlin. Die Plattform Siemens Xcelerator vernetzt Hardware und Software für nachhaltige Industrieproduktion.',
    body: `SIEMENS AG - UNTERNEHMENSPROFIL:
Siemens ist einer der traditionsreichsten deutschen DAX-Konzerne, gegründet 1847 von Werner von Siemens und Johann Georg Halske.
Geschäftsbereiche:
- Digital Industries: Automatisierung von Fertigungs- und Prozessindustrie (Simatic SPS, Digitaler Zwilling).
- Smart Infrastructure: Intelligente Stromverteilung, Gebäudeautomation und Netzleittechnik.
- Mobility: Schienenfahrzeuge (ICE 4, Velaro, Desiro), Signaltechnik und digitale Leit- und Sicherungstechnik.`,
    author: 'Siemens AG Corporate Communications, München',
    publishedAt: '2026-02-05',
    crawledAt: '2026-03-01T10:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'enterprise',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.96,
    freshnessScore: 0.89,
    entities: ['Siemens AG', 'München', 'Berlin', 'Industrie 4.0'],
    topics: ['Unternehmen', 'Technologie', 'Industrie', 'Automation'],
    contentHash: '8c9d0e1f2a3b4c5d',
  },

  // 14. STADT MÜNCHEN (Stadtportal)
  {
    id: 'doc-muenchen-portal-20',
    url: 'https://www.muenchen.de/leben/fakten-und-zahlen.html',
    canonicalUrl: 'https://www.muenchen.de/leben/fakten-und-zahlen.html',
    title: 'muenchen.de - Offizielles Stadtportal der Landeshauptstadt München',
    headline: 'Wirtschaftsmetropole, Universitätsstadt und bayerische Landeshauptstadt',
    domain: 'muenchen.de',
    snippet: 'München ist die Landeshauptstadt des Freistaates Bayern mit ca. 1,59 Millionen Einwohnern. Als eine der wirtschaftsstärksten Metropolen Europas beheimatet München Weltkonzerne wie BMW, Siemens, Allianz und die renommierten Exzellenzuniversitäten TUM und LMU.',
    body: `LANDESHAUPTSTADT MÜNCHEN - PORTALINFORMATIONEN:
- Geografie & Bevölkerung: Drittgrößte Stadt Deutschlands an der Isar, über 1,588 Millionen Einwohner.
- Politik: Rathaus am Marienplatz, Oberbürgermeister Dieter Reiter.
- Kultur & Tourismus: Frauenkirche, Englischer Garten, Deutsches Museum, Oktoberfest (Theresienwiese), Schloss Nymphenburg.
- Bildung & Wissenschaft: Sitz von Max-Planck-Instituten, Fraunhofer-Gesellschaft, LMU und TU München.`,
    author: 'Landeshauptstadt München / Portal München Betriebs-GmbH',
    publishedAt: '2026-01-01',
    crawledAt: '2026-02-15T08:00:00Z',
    language: 'de',
    country: 'DE',
    documentType: 'government',
    filetype: 'html',
    primarySource: true,
    authorityScore: 0.97,
    freshnessScore: 0.90,
    entities: ['München', 'Bayern', 'TUM', 'LMU', 'BMW', 'Siemens'],
    topics: ['Stadt', 'München', 'Bayern', 'Geografie'],
    contentHash: '9d0e1f2a3b4c5d6e',
  },
];
