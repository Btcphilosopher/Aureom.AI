/**
 * DEUTSCHSUCH - German Knowledge Graph & Comparison Engine
 * Phase 13, 31, 32, 53: Structured entity graph with verified facts and comparison capabilities.
 */

import { KnowledgeEntity, ComparisonData } from './types';

export const KNOWLEDGE_ENTITIES: Record<string, KnowledgeEntity> = {
  'deutsche bahn ag': {
    id: 'ent-db-ag',
    name: 'Deutsche Bahn AG',
    subtitle: 'Deutsches Bundesunternehmen für Eisenbahnverkehr & Schieneninfrastruktur',
    description: 'Die Deutsche Bahn AG (DB) ist das größte Eisenbahnverkehrs- und Schieneninfrastrukturunternehmen in Mitteleuropa. Sie entstand 1994 durch die Zusammenlegung der westdeutschen Deutschen Bundesbahn und der ostdeutschen Deutschen Reichsbahn.',
    type: 'Unternehmen',
    attributes: [
      { label: 'Rechtsform', value: 'Aktiengesellschaft (100 % Bundeseigentum)' },
      { label: 'Hauptsitz', value: 'Berlin (BahnTower, Potsdamer Platz)' },
      { label: 'Gründung', value: '1. Januar 1994 (Bahnreform)' },
      { label: 'Mitarbeiter', value: 'ca. 340.000 weltweit' },
      { label: 'Infrastruktur', value: 'DB InfraGO AG (ca. 33.400 km Schienennetz)' },
      { label: 'Vorstandsvorsitz', value: 'Dr. Richard Lutz' },
      { label: 'Flotte Fernverkehr', value: 'ICE 1, ICE 3, ICE 4, ICE Neo, Intercity' },
    ],
    website: 'https://www.deutschebahn.com',
    verifiedSource: 'Deutsche Bahn AG Geschäftsbericht & Bundesministerium für Digitales und Verkehr',
    sourceUrl: 'https://www.deutschebahn.com/de/konzern/ueber_uns',
    relatedEntities: ['Deutsche Bundesbahn', 'ICE 4', 'Siemens Mobility', 'DB InfraGO', 'Bundesnetzagentur'],
    imageUrl: '/images/ice_train_speed.jpg',
  },
  'deutsche bundesbahn': {
    id: 'ent-db-historie',
    name: 'Deutsche Bundesbahn',
    subtitle: 'Historisches Sondervermögen der Bundesrepublik Deutschland (1949–1993)',
    description: 'Die Deutsche Bundesbahn war die Staatsbahn der Bundesrepublik Deutschland bis zur Bahnreform 1994. Ihr Betrieb wurde zum 1. Januar 1994 mit der Deutschen Reichsbahn zur neu gegründeten Deutschen Bahn AG fusioniert.',
    type: 'Behörde',
    attributes: [
      { label: 'Bestehen', value: '7. September 1949 – 31. Dezember 1993' },
      { label: 'Sitz der Hauptverwaltung', value: 'Frankfurt am Main' },
      { label: 'Nachfolger', value: 'Deutsche Bahn AG' },
      { label: 'Rechtsgrundlage', value: 'Bundesbahngesetz (BbG) von 1951' },
    ],
    verifiedSource: 'Bundesarchiv & Deutsche Bahn Historische Sammlung',
    sourceUrl: 'https://www.deutschebahn.com/de/konzern/geschichte',
    relatedEntities: ['Deutsche Bahn AG', 'Bahnreform 1994', 'Deutsche Reichsbahn'],
  },
  'bundesverfassungsgericht': {
    id: 'ent-bverfg',
    name: 'Bundesverfassungsgericht',
    subtitle: 'Höchstes Verfassungsorgan der deutschen Gerichtsbarkeit in Karlsruhe',
    description: 'Das Bundesverfassungsgericht (BVerfG) wacht über die Auslegung und Einhaltung des Grundgesetzes für die Bundesrepublik Deutschland. Seine Urteile besitzen Gesetzeskraft und binden sämtliche staatlichen Organe.',
    type: 'Gericht',
    attributes: [
      { label: 'Sitz', value: 'Karlsruhe (Schlossbezirk)' },
      { label: 'Gründung', value: '28. September 1951' },
      { label: 'Präsidentin / Präsident', value: 'Prof. Dr. Stephan Harbarth' },
      { label: 'Zusammensetzung', value: '2 Senate mit je 8 Richterinnen und Richtern' },
      { label: 'Wahl', value: 'Zu 50 % durch Bundestag, zu 50 % durch Bundesrat (2/3-Mehrheit)' },
      { label: 'Amtszeit', value: '12 Jahre (keine Wiederwahl möglich)' },
      { label: 'Zentrale Verfahren', value: 'Verfassungsbeschwerde, Normenkontrolle, Organstreit' },
    ],
    website: 'https://www.bundesverfassungsgericht.de',
    verifiedSource: 'Bundesverfassungsgericht - Amtliches Portal Karlsruhe',
    sourceUrl: 'https://www.bundesverfassungsgericht.de/DE/Das-Gericht/aufgaben_node.html',
    relatedEntities: ['Grundgesetz', 'Deutscher Bundestag', 'Bundesrat', 'Bundespräsident'],
  },
  'münchen': {
    id: 'ent-muenchen',
    name: 'München',
    subtitle: 'Landeshauptstadt des Freistaates Bayern & Wirtschaftsmetropole',
    description: 'München ist mit knapp 1,59 Millionen Einwohnern die drittgrößte Stadt Deutschlands. Die Stadt ist Sitz der Bayerischen Staatsregierung und ein führender Technologie- und Forschungsstandort in Europa.',
    type: 'Ort',
    attributes: [
      { label: 'Bundesland', value: 'Freistaat Bayern' },
      { label: 'Einwohner', value: '1.588.330 (31. Dez. 2024)' },
      { label: 'Oberbürgermeister', value: 'Dieter Reiter (SPD)' },
      { label: 'Universitäten', value: 'TUM (TU München), LMU (Ludwig-Maximilians-Universität)' },
      { label: 'DAX-Unternehmen', value: 'BMW Group, Siemens AG, Allianz SE, Munich Re' },
      { label: 'Geografie', value: 'Fluss Isar, Nähe zu den bayerischen Alpen' },
    ],
    website: 'https://www.muenchen.de',
    verifiedSource: 'Bayerisches Landesamt für Statistik & Stadtportal muenchen.de',
    sourceUrl: 'https://www.muenchen.de',
    relatedEntities: ['Technische Universität München', 'Siemens AG', 'BMW Group', 'Freistaat Bayern'],
  },
  'berlin': {
    id: 'ent-berlin',
    name: 'Berlin',
    subtitle: 'Bundeshauptstadt und Land der Bundesrepublik Deutschland',
    description: 'Berlin ist die bevölkerungsreichste Stadt der Europäischen Union mit über 3,85 Millionen Einwohnern. Als Bundeshauptstadt ist Berlin Sitz der Bundesregierung, des Bundestages und des Bundesrates.',
    type: 'Ort',
    attributes: [
      { label: 'Status', value: 'Bundeshauptstadt & Stadtstaat' },
      { label: 'Einwohner', value: 'ca. 3.878.000' },
      { label: 'Regierender Bürgermeister', value: 'Kai Wegner (CDU)' },
      { label: 'Verfassungsorgane', value: 'Deutscher Bundestag (Reichstag), Bundeskanzleramt, Bundesrat' },
      { label: 'Wahrzeichen', value: 'Brandenburger Tor, Berliner Fernsehturm, Museumsinsel' },
    ],
    website: 'https://www.berlin.de',
    verifiedSource: 'Amt für Statistik Berlin-Brandenburg',
    sourceUrl: 'https://www.berlin.de',
    relatedEntities: ['Deutscher Bundestag', 'Bundeskanzleramt', 'Deutsche Bahn AG'],
    imageUrl: '/images/berlin_skyline_hero.jpg',
  },
  'ice 4': {
    id: 'ent-ice4',
    name: 'ICE 4 (Baureihe 412)',
    subtitle: 'Modularer Hochgeschwindigkeitszug der Deutschen Bahn',
    description: 'Der ICE 4 bildet das tragende Fundament des deutschen Schienenpersonenfernverkehrs. Konzipiert für hohe Energieeffizienz, flexible Zuglängen (7 bis 13 Wagen) und bis zu 918 Sitzplätze.',
    type: 'Technologie',
    attributes: [
      { label: 'Hersteller', value: 'Siemens Mobility & Bombardier Transportation' },
      { label: 'Höchstgeschwindigkeit', value: '265 km/h' },
      { label: 'Betreiber', value: 'DB Fernverkehr AG' },
      { label: 'Konfiguration XXL', value: '13-teilig, 374 m Länge, 918 Sitzplätze' },
      { label: 'Antriebsart', value: 'Powercars mit verteiltem Einzelachsantrieb' },
      { label: 'Stromsysteme', value: '15 kV 16,7 Hz (Deutschland, Österreich, Schweiz)' },
    ],
    verifiedSource: 'Siemens Mobility Datenblatt & DB Konzernflotte',
    sourceUrl: 'https://www.deutschebahn.com/de/presse/hintergrund/ice4-technische-daten-flotte.html',
    relatedEntities: ['Deutsche Bahn AG', 'Siemens AG', 'TGV Duplex'],
    imageUrl: '/images/ice_train_speed.jpg',
  },
  '§ 823 bgb': {
    id: 'ent-823-bgb',
    name: '§ 823 BGB - Schadensersatzpflicht',
    subtitle: 'Zentrale Grundnorm des deutschen deliktischen Haftungsrechts',
    description: '§ 823 des Bürgerlichen Gesetzbuches regelt die Schadensersatzpflicht bei widerrechtlicher Verletzung von Leben, Körper, Gesundheit, Freiheit, Eigentum oder Schutzgesetzen.',
    type: 'Gesetz',
    attributes: [
      { label: 'Gesetzbuch', value: 'Bürgerliches Gesetzbuch (BGB)' },
      { label: 'Abschnitt', value: 'Buch 2, Abschnitt 8, Titel 27 (Unerlaubte Handlungen)' },
      { label: 'Geschützte Rechtsgüter', value: 'Leben, Körper, Gesundheit, Freiheit, Eigentum, sonstige Rechte' },
      { label: 'Verschuldensmaßstab', value: 'Vorsatz oder Fahrlässigkeit (§ 276 BGB)' },
      { label: 'Zuständige Gerichte', value: 'Zivilgerichte (Amtsgerichte, Landgerichte, BGH)' },
    ],
    verifiedSource: 'Bundesministerium der Justiz & Juris Portal',
    sourceUrl: 'https://www.gesetze-im-internet.de/bgb/__823.html',
    relatedEntities: ['Bürgerliches Gesetzbuch', 'Bundesgerichtshof', 'Grundgesetz'],
  },
  'energiewende': {
    id: 'ent-energiewende',
    name: 'Energiewende in Deutschland',
    subtitle: 'Transformation zu einer treibhausgasneutralen Energieversorgung',
    description: 'Die deutsche Energiewende bezeichnet den langfristigen Umbau der Energieversorgung von fossilen und nuklearen Brennstoffen hin zu erneuerbaren Energien und Steigerung der Energieeffizienz bis zur Klimaneutralität 2045.',
    type: 'Konzept',
    attributes: [
      { label: 'Ziel 2030', value: '80 % erneuerbarer Strom am Bruttostromverbrauch' },
      { label: 'Ziel 2045', value: 'Treibhausgasneutralität der Bundesrepublik Deutschland' },
      { label: 'Federführendes Ressort', value: 'Bundesministerium für Wirtschaft und Klimaschutz (BMWK)' },
      { label: 'Schlüsseltechnologien', value: 'Windkraft, Photovoltaik, Stromnetze, Wasserstoff, Wärmepumpen' },
      { label: 'Regulierungsbehörde', value: 'Bundesnetzagentur (BNetzA)' },
    ],
    verifiedSource: 'Bundesnetzagentur & Fraunhofer ISE',
    sourceUrl: 'https://www.bund.de/DE/Themen/Energie/Energiewende/energiewende-zielsetzungen.html',
    relatedEntities: ['Bundesnetzagentur', 'Fraunhofer ISE', 'BMWK', 'Stromnetz'],
    imageUrl: '/images/german_energy_grid.jpg',
  },
};

/**
 * Searches the Knowledge Graph for matching entities
 */
export function lookupKnowledgeEntity(query: string): KnowledgeEntity | undefined {
  const lower = query.toLowerCase();

  // Direct matches
  for (const [key, entity] of Object.entries(KNOWLEDGE_ENTITIES)) {
    if (lower.includes(key)) {
      return entity;
    }
  }

  // Synonym / partial matches
  if (lower.includes('deutsche bahn') || lower.includes('db ag') || lower.includes('bahn ag')) {
    return KNOWLEDGE_ENTITIES['deutsche bahn ag'];
  }
  if (lower.includes('bundesbahn')) {
    return KNOWLEDGE_ENTITIES['deutsche bundesbahn'];
  }
  if (lower.includes('verfassungsgericht') || lower.includes('bverfg')) {
    return KNOWLEDGE_ENTITIES['bundesverfassungsgericht'];
  }
  if (lower.includes('ice 4') || lower.includes('baureihe 412')) {
    return KNOWLEDGE_ENTITIES['ice 4'];
  }
  if (lower.includes('823 bgb') || lower.includes('schadensersatz bgb')) {
    return KNOWLEDGE_ENTITIES['§ 823 bgb'];
  }
  if (lower.includes('energiewende')) {
    return KNOWLEDGE_ENTITIES['energiewende'];
  }
  if (lower.includes('münchen') || lower.includes('munchen')) {
    return KNOWLEDGE_ENTITIES['münchen'];
  }
  if (lower.includes('berlin')) {
    return KNOWLEDGE_ENTITIES['berlin'];
  }

  return undefined;
}

/**
 * Generates structured comparison table if query compares two entities
 * Specifically supports prompt test case: "ICE 4 vs TGV Duplex" (Section 53)
 */
export function generateComparison(query: string): ComparisonData | undefined {
  const lower = query.toLowerCase();

  if (
    (lower.includes('ice 4') || lower.includes('ice')) &&
    (lower.includes('tgv') || lower.includes('tgv duplex'))
  ) {
    return {
      entityA: 'ICE 4 (DB Baureihe 412)',
      entityB: 'TGV Duplex (SNCF Dasye/Océane)',
      category: 'Hochgeschwindigkeitszüge im europäischen Vergleich',
      specs: [
        { property: 'Höchstgeschwindigkeit (Vmax)', valA: '265 km/h', valB: '320 km/h' },
        { property: 'Wagenarchitektur', valA: 'Einstöckig mit verteilten Powercars', valB: 'Doppelstockwagen mit Triebköpfen' },
        { property: 'Maximale Sitzplatzkapazität', valA: '918 Sitzplätze (13-Teiler XXL)', valB: '510 Sitzplätze (Einzelelement)' },
        { property: 'Zuglänge', valA: '346 m (12-Teiler) / 374 m (XXL)', valB: '200 m (400 m in Doppeltraktion)' },
        { property: 'Hauptbetreiber', valA: 'Deutsche Bahn AG (Deutschland)', valB: 'SNCF Voyageurs (Frankreich)' },
        { property: 'Hersteller', valA: 'Siemens Mobility & Bombardier', valB: 'Alstom' },
        { property: 'Fahrradstellplätze', valA: 'Ja (8 Stellplätze im Zug)', valB: 'Sehr begrenzt / demontiert' },
        { property: 'Netzoptimierung', valA: 'Deutsches Takt- und Mischverkehrsnetz', valB: 'Französisches LGV-Schnellfahrnetz' },
      ],
      source: 'Eisenbahn Magazin & Technische Fachdatenblätter DB / SNCF',
      sourceUrl: 'https://www.deutschebahn.com',
    };
  }

  return undefined;
}
