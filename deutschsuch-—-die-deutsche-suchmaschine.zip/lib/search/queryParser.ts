/**
 * DEUTSCHSUCH - Query Understanding & Operator Parser
 * Handles site:, -site:, filetype:, "quotes", AND, OR, exclusions, and German linguistics
 */

import { ParsedSearchQuery } from './types';
import {
  tokenizeGerman,
  stemGerman,
  splitGermanCompound,
  classifyQueryIntent,
  extractGermanEntities,
  GERMAN_STOPWORDS,
} from './germanEngine';

export function parseSearchQuery(rawQuery: string): ParsedSearchQuery {
  let text = rawQuery.trim();

  const exactPhrases: string[] = [];
  const excludedWords: string[] = [];
  const siteFilters: string[] = [];
  const excludedSites: string[] = [];
  let filetypeFilter: string | undefined;
  const intitleTerms: string[] = [];
  const inurlTerms: string[] = [];

  // 1. Extract exact phrases in quotes "..."
  const quoteRegex = /"([^"]+)"/g;
  let match;
  while ((match = quoteRegex.exec(text)) !== null) {
    if (match[1].trim()) {
      exactPhrases.push(match[1].trim());
    }
  }
  text = text.replace(quoteRegex, ' ');

  // 2. Parse special search operators (site:, -site:, filetype:, intitle:, inurl:)
  const tokens = text.split(/\s+/).filter(Boolean);
  const remainingTokens: string[] = [];

  for (const token of tokens) {
    const lower = token.toLowerCase();

    if (lower.startsWith('site:')) {
      const site = token.substring(5).trim();
      if (site) siteFilters.push(site);
    } else if (lower.startsWith('-site:')) {
      const site = token.substring(6).trim();
      if (site) excludedSites.push(site);
    } else if (lower.startsWith('filetype:')) {
      filetypeFilter = token.substring(9).trim().toLowerCase();
    } else if (lower.startsWith('intitle:')) {
      const t = token.substring(8).trim();
      if (t) intitleTerms.push(t);
    } else if (lower.startsWith('inurl:')) {
      const u = token.substring(6).trim();
      if (u) inurlTerms.push(u);
    } else if (token.startsWith('-') && token.length > 1) {
      excludedWords.push(token.substring(1).toLowerCase());
    } else {
      remainingTokens.push(token);
    }
  }

  const cleanText = remainingTokens.join(' ');
  const wordTokens = tokenizeGerman(cleanText);

  // Filter non-stopwords for primary keywords, but keep all for exact matches
  const meaningfulTokens = wordTokens.filter((t) => !GERMAN_STOPWORDS.has(t) || wordTokens.length <= 2);
  const effectiveTokens = meaningfulTokens.length > 0 ? meaningfulTokens : wordTokens;

  // German stemming
  const stemmedTokens = effectiveTokens.map(stemGerman);

  // German compound decomposition (Kompositzerlegung)
  const compounds: Record<string, string[]> = {};
  for (const token of effectiveTokens) {
    const parts = splitGermanCompound(token);
    if (parts.length > 1) {
      compounds[token] = parts;
    }
  }

  // Detect entities
  const detectedEntities = extractGermanEntities(rawQuery);

  // Detect Comparison (e.g. "ICE 4 vs TGV Duplex")
  const isComparison = /\b(vs|versus|vergleich)\b/i.test(rawQuery);
  let comparisonEntities: [string, string] | undefined;
  if (isComparison) {
    const parts = rawQuery.split(/\b(?:vs|versus)\b/i);
    if (parts.length >= 2) {
      comparisonEntities = [parts[0].trim(), parts[1].trim()];
    }
  }

  // Detect Local city (e.g. "in München", "in Berlin")
  let localCity: string | undefined;
  const cityMatch = rawQuery.match(/in\s+([A-ZÄÖÜ][a-zäöüß]+)/i);
  if (cityMatch) {
    localCity = cityMatch[1];
  }

  // Detect intent
  const intent = classifyQueryIntent(rawQuery);

  return {
    raw: rawQuery,
    cleanText,
    exactPhrases,
    excludedWords,
    siteFilters,
    excludedSites,
    filetypeFilter,
    intitleTerms,
    inurlTerms,
    tokens: effectiveTokens,
    stemmedTokens,
    compounds,
    intent,
    detectedEntities,
    isComparison,
    comparisonEntities,
    localCity,
  };
}
