'use client';

import React, { useState } from 'react';
import { X, Terminal, Server, ShieldCheck, Activity, RefreshCw } from 'lucide-react';
import { getSystemMetrics, getRecentCrawlJobs, checkRobotsTxt, RobotsCheckResult } from '@/lib/search/crawlerEngine';

interface SystemConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SystemConsoleModal({ isOpen, onClose }: SystemConsoleModalProps) {
  const [testUrl, setTestUrl] = useState('https://www.bund.de/sitemap.xml');
  const [robotsResult, setRobotsResult] = useState<RobotsCheckResult | null>(null);
  const [activeTab, setActiveTab] = useState<'crawler' | 'index' | 'ranking' | 'robots'>('crawler');

  if (!isOpen) return null;

  const metrics = getSystemMetrics();
  const crawlJobs = getRecentCrawlJobs();

  const handleTestRobots = (e: React.FormEvent) => {
    e.preventDefault();
    if (testUrl.trim()) {
      setRobotsResult(checkRobotsTxt(testUrl.trim()));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl w-full max-w-3xl shadow-2xl p-6 text-neutral-900 dark:text-neutral-100 transition-colors">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />
            <div>
              <h2 className="text-base sm:text-lg font-bold">DEUTSCHSUCH System- & Crawler-Konsole</h2>
              <p className="text-xs text-neutral-500">Infrastrukturstatus, Indexdiagnose und Crawler-Richtlinien</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-neutral-800 mt-4 text-xs font-medium">
          <button
            onClick={() => setActiveTab('crawler')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'crawler'
                ? 'border-neutral-900 dark:border-neutral-100 font-bold text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            Crawler & Queue
          </button>
          <button
            onClick={() => setActiveTab('index')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'index'
                ? 'border-neutral-900 dark:border-neutral-100 font-bold text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            Index & BM25
          </button>
          <button
            onClick={() => setActiveTab('ranking')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'ranking'
                ? 'border-neutral-900 dark:border-neutral-100 font-bold text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            Ranking-Qualität
          </button>
          <button
            onClick={() => setActiveTab('robots')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'robots'
                ? 'border-neutral-900 dark:border-neutral-100 font-bold text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            robots.txt Validator
          </button>
        </div>

        {/* Content based on Active Tab */}
        <div className="py-4 text-xs">
          {activeTab === 'crawler' && (
            <div className="space-y-4">
              {/* Telemetry Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Crawler Status</div>
                  <div className="text-base font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                    {metrics.crawlerStatus}
                  </div>
                </div>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Crawl-Rate</div>
                  <div className="text-base font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
                    {metrics.crawlRatePagesPerSec} S./s
                  </div>
                </div>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Queue-Tiefe</div>
                  <div className="text-base font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
                    {metrics.activeQueueDepth} URLs
                  </div>
                </div>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Primärquellen-Quote</div>
                  <div className="text-base font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
                    {metrics.primarySourceRatio} %
                  </div>
                </div>
              </div>

              {/* Live Queue Items Table */}
              <div>
                <div className="font-semibold text-neutral-700 dark:text-neutral-300 mb-2">
                  Aktuelle Crawl-Warteschlange (Simuliert)
                </div>
                <div className="overflow-x-auto border border-neutral-200 dark:border-neutral-800 rounded-lg">
                  <table className="w-full text-left">
                    <thead className="bg-neutral-50 dark:bg-neutral-800/50 border-b border-neutral-200 dark:border-neutral-800 text-neutral-500">
                      <tr>
                        <th className="py-2 px-3">URL</th>
                        <th className="py-2 px-3">Domain</th>
                        <th className="py-2 px-3">Status</th>
                        <th className="py-2 px-3">HTTP</th>
                        <th className="py-2 px-3">Delay</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800 font-mono text-[11px]">
                      {crawlJobs.map((job) => (
                        <tr key={job.id}>
                          <td className="py-2 px-3 truncate max-w-[200px] text-neutral-800 dark:text-neutral-200">
                            {job.url}
                          </td>
                          <td className="py-2 px-3 text-neutral-500">{job.domain}</td>
                          <td className="py-2 px-3 font-semibold text-emerald-600 dark:text-emerald-400">{job.status}</td>
                          <td className="py-2 px-3">{job.httpStatus || '-'}</td>
                          <td className="py-2 px-3">{job.crawlDelayMs}ms</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'index' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Gesamtdokumente im Index</div>
                  <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100">
                    {metrics.indexTotalDocuments.toLocaleString('de-DE')}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">Inkl. 100.000 synthetischer Korpus</div>
                </div>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Durchschn. Abfragezeit</div>
                  <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100">
                    {metrics.avgRetrievalLatencyMs} ms
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">Ziel: &lt; 300 ms</div>
                </div>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-[11px]">Deutsche Sprachreinheit</div>
                  <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100">
                    {metrics.germanLanguagePurity} %
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">Gefiltert nach Umlauten & Syntax</div>
                </div>
              </div>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-lg border border-neutral-200 dark:border-neutral-800">
                <div className="font-semibold text-neutral-800 dark:text-neutral-200 mb-2">
                  BM25 Index-Parameter
                </div>
                <ul className="space-y-1 text-neutral-600 dark:text-neutral-400 font-mono text-[11px]">
                  <li>• Formel: Okapi BM25 mit Term Frequency & Document Length Normalization</li>
                  <li>• k1 Parameter: 1.2 (Sättigung der Term-Frequenz)</li>
                  <li>• b Parameter: 0.75 (Längennormalisierung gegen Textblöcke)</li>
                  <li>• Feldgewichtung: Titel = 3.5× · Entitäten = 2.5× · Textkörper = 1.0×</li>
                  <li>• Komposita-Verarbeitung: Automatische Zerlegung von Substantiven</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'ranking' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-xs">Mean Reciprocal Rank (MRR)</div>
                  <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">
                    {metrics.mrrScore}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Erstes relevantes Dokument erscheint im Mittel auf Rang 1,06.
                  </p>
                </div>
                <div className="p-4 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700">
                  <div className="text-neutral-500 text-xs">NDCG @ 10</div>
                  <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">
                    {metrics.ndcgScore}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Hohe Übereinstimmung der Top-10-Ergebnisse mit amtlichen Primärquellen.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-lg border border-neutral-200 dark:border-neutral-800">
                <div className="font-semibold text-neutral-800 dark:text-neutral-200 mb-1">
                  Ranking-Signale in der Hybrid-Pipeline
                </div>
                <p className="text-neutral-500 text-xs mb-2">
                  Keine einzelne Kennzahl entscheidet allein. Folgende Signalvektoren werden fusioniert:
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-700 dark:text-neutral-300">
                  <div>1. BM25 Textrelevanz</div>
                  <div>2. Semantische Ähnlichkeit</div>
                  <div>3. Titel- und Entitätsübereinstimmung</div>
                  <div>4. Behörden- & Primärquellen-Autorität</div>
                  <div>5. Aktualitätsbonus (Freshness)</div>
                  <div>6. Suchintent-Klassifikation</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'robots' && (
            <div className="space-y-4">
              <p className="text-neutral-600 dark:text-neutral-400 text-xs">
                Prüfen Sie eine beliebige URL gegen die robots.txt-Crawler-Richtlinien von DEUTSCHSUCH:
              </p>

              <form onSubmit={handleTestRobots} className="flex gap-2">
                <input
                  type="url"
                  value={testUrl}
                  onChange={(e) => setTestUrl(e.target.value)}
                  placeholder="https://..."
                  className="flex-1 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none font-mono"
                  required
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg font-semibold text-xs hover:bg-neutral-800 dark:hover:bg-white"
                >
                  Regel prüfen
                </button>
              </form>

              {robotsResult && (
                <div className="p-4 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700 font-mono text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Ergebnis für DeutschSuchCrawler:</span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                        robotsResult.allowed
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                          : 'bg-red-100 dark:bg-red-950 text-red-800 dark:text-red-300'
                      }`}
                    >
                      {robotsResult.allowed ? 'ZUGELASSEN (ALLOWED)' : 'GESPERRT (DISALLOWED)'}
                    </span>
                  </div>
                  <div>Passende Richtlinie: <span className="font-semibold text-neutral-800 dark:text-neutral-200">{robotsResult.matchedRule}</span></div>
                  <div>Crawl-Delay: {robotsResult.crawlDelay} Sekunden</div>
                  <div className="text-neutral-400 text-[10px] truncate">User-Agent: {robotsResult.userAgent}</div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg font-medium text-xs hover:bg-neutral-800 dark:hover:bg-white"
          >
            Schließen
          </button>
        </div>
      </div>
    </div>
  );
}
