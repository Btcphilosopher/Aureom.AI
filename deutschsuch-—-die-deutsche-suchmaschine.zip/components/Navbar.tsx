'use client';

import React from 'react';
import { SlidersHorizontal, Shield, Terminal, Sun, Moon } from 'lucide-react';

export type SearchTab = 'web' | 'news' | 'images' | 'videos' | 'science' | 'law' | 'local';

interface NavbarProps {
  activeTab: SearchTab;
  onTabChange: (tab: SearchTab) => void;
  onOpenAdvanced: () => void;
  onOpenConsole: () => void;
  onOpenPrivacy: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  compact?: boolean;
}

export function Navbar({
  activeTab,
  onTabChange,
  onOpenAdvanced,
  onOpenConsole,
  onOpenPrivacy,
  isDarkMode,
  onToggleDarkMode,
  compact = false,
}: NavbarProps) {
  const tabs: { id: SearchTab; label: string; shortcut: string }[] = [
    { id: 'web', label: 'Web', shortcut: 'Alt+1' },
    { id: 'news', label: 'Nachrichten', shortcut: 'Alt+2' },
    { id: 'images', label: 'Bilder', shortcut: 'Alt+3' },
    { id: 'videos', label: 'Videos', shortcut: 'Alt+4' },
    { id: 'science', label: 'Wissenschaft', shortcut: 'Alt+5' },
    { id: 'law', label: 'Recht & Normen', shortcut: '' },
    { id: 'local', label: 'Lokal', shortcut: '' },
  ];

  return (
    <header className="w-full border-b border-neutral-200 dark:border-neutral-800 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onTabChange('web')}
            className="flex items-center gap-2 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-900 dark:focus-visible:ring-neutral-100 rounded"
            title="DEUTSCHSUCH Startseite"
          >
            {/* German flag minimalist 3-stripe mark */}
            <div className="flex flex-col w-4 h-3.5 rounded-[2px] overflow-hidden shadow-xs shrink-0" aria-hidden="true">
              <div className="h-1/3 bg-neutral-950 w-full" />
              <div className="h-1/3 bg-red-600 w-full" />
              <div className="h-1/3 bg-amber-400 w-full" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="font-bold tracking-tight text-neutral-900 dark:text-neutral-50 text-base sm:text-lg">
                DEUTSCHSUCH
              </span>
              <span className="text-[10px] uppercase font-semibold tracking-wider text-neutral-400 dark:text-neutral-500 hidden sm:inline">
                DE
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single-line, unboxed tabs) */}
        <nav
          className="hidden md:flex items-center gap-5 text-sm font-medium overflow-x-auto py-1 scrollbar-none"
          aria-label="Suchkategorien"
        >
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`whitespace-nowrap transition-colors py-1 relative ${
                  isActive
                    ? 'text-neutral-900 dark:text-neutral-100 font-semibold border-b-2 border-neutral-900 dark:border-neutral-100'
                    : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200'
                }`}
                title={tab.shortcut ? `${tab.label} (${tab.shortcut})` : tab.label}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Utility & Operational Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Quick Weather widget */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-neutral-600 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-800/60 px-2.5 py-1 rounded">
            <span>☀️ 12°</span>
            <span className="text-neutral-400">·</span>
            <span className="font-medium">Berlin</span>
          </div>

          {/* Advanced Search Filter trigger */}
          <button
            onClick={onOpenAdvanced}
            className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
            title="Erweiterte Suche"
            aria-label="Erweiterte Suche öffnen"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          {/* Crawler / System Konsole */}
          <button
            onClick={onOpenConsole}
            className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
            title="System- & Crawler-Konsole"
            aria-label="Systemkonsole öffnen"
          >
            <Terminal className="w-4 h-4" />
          </button>

          {/* Privacy & DSGVO */}
          <button
            onClick={onOpenPrivacy}
            className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
            title="Datenschutz & Einstellungen"
            aria-label="Datenschutzeinstellungen"
          >
            <Shield className="w-4 h-4" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
            title={isDarkMode ? 'Helles Design aktivieren' : 'Dunkles Design aktivieren'}
            aria-label="Farbschema umschalten"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
}
