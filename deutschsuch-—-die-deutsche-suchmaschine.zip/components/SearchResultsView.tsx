'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import {
  Search,
  X,
  FileText,
  Building,
  Scale,
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  MapPin,
  Phone,
  Star,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { SearchResponse, SearchHit, SearchQueryFilters } from '@/lib/search/types';

interface SearchResultsViewProps {
  query: string;
  response: SearchResponse;
  onSearch: (query: string, filters?: SearchQueryFilters) => void;
  filters: SearchQueryFilters;
  onFilterChange: (filters: SearchQueryFilters) => void;
  isAiStreaming?: boolean;
}

export function SearchResultsView({
  query,
  response,
  onSearch,
  filters,
  onFilterChange,
  isAiStreaming = false,
}: SearchResultsViewProps) {
  const [searchInput, setSearchInput] = useState(query);
  const [showAiOverview, setShowAiOverview] = useState(true);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim(), filters);
    }
  };

  const handleFilterUpdate = (key: keyof SearchQueryFilters, val: any) => {
    const updated = { ...filters, [key]: val };
    onFilterChange(updated);
    onSearch(query, updated);
  };

  return (
    <div className="w-full min-h-screen bg-neutral-50/50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 flex flex-col transition-colors">
      {/* Sticky Header with Search Input */}
      <div className="border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 sticky top-14 z-30 px-4 sm:px-6 py-3 transition-colors shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-2xl">
            <div className="relative flex items-center bg-neutral-100 dark:bg-neutral-800 rounded-full border border-neutral-300 dark:border-neutral-700 focus-within:ring-2 focus-within:ring-neutral-900 dark:focus-within:ring-neutral-100 px-3 py-1.5 transition-all">
              <Search className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full bg-transparent text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none"
                placeholder="Suchbegriff eingeben..."
              />
              {searchInput && (
                <button
                  type="button"
                  onClick={() => setSearchInput('')}
                  className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 mr-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                type="submit"
                className="px-3 py-1 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-full text-xs font-medium hover:bg-neutral-800 dark:hover:bg-white transition-colors"
              >
                Suchen
              </button>
            </div>
          </form>

          {/* Quick Filter Ribbon */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs text-neutral-600 dark:text-neutral-400 scrollbar-none py-1">
            {/* Region Filter */}
            <select
              value={filters.country || 'DE'}
              onChange={(e) => handleFilterUpdate('country', e.target.value)}
              className="bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none"
            >
              <option value="DE">Region: Deutschland</option>
              <option value="AT">Region: Österreich</option>
              <option value="CH">Region: Schweiz</option>
              <option value="GLOBAL">Weltweit</option>
            </select>

            {/* Date range Filter */}
            <select
              value={filters.timeRange || 'all'}
              onChange={(e) => handleFilterUpdate('timeRange', e.target.value)}
              className="bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none"
            >
              <option value="all">Zeitraum: Beliebig</option>
              <option value="24h">Letzte 24 Stunden</option>
              <option value="week">Letzte Woche</option>
              <option value="month">Letzter Monat</option>
            </select>

            {/* Filetype Filter */}
            <select
              value={filters.filetype || ''}
              onChange={(e) => handleFilterUpdate('filetype', e.target.value || undefined)}
              className="bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none"
            >
              <option value="">Dateityp: Alle</option>
              <option value="pdf">Nur PDF-Dokumente</option>
              <option value="html">Webseiten (HTML)</option>
            </select>

            {/* Source Type Filter */}
            <select
              value={filters.sourceType || 'all'}
              onChange={(e) => handleFilterUpdate('sourceType', e.target.value === 'all' ? undefined : e.target.value)}
              className="bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none"
            >
              <option value="all">Quellen: Alle</option>
              <option value="government">Bundesbehörden</option>
              <option value="academic">Wissenschaft & Forschung</option>
              <option value="law">Gesetze & Justiz</option>
              <option value="news">Nachrichten</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Container: 2-Column Desktop Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex-1 w-full">
        {/* Spelling Suggestion Notice ("Meinten Sie: ...?") */}
        {response.didYouMean && response.correctedQuery && (
          <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-lg text-sm text-amber-900 dark:text-amber-200 flex items-center justify-between">
            <div>
              <span>Meinten Sie: </span>
              <button
                onClick={() => {
                  setSearchInput(response.correctedQuery!);
                  onSearch(response.correctedQuery!);
                }}
                className="font-bold underline hover:text-amber-700 dark:hover:text-amber-100 transition-colors"
              >
                {response.correctedQuery}
              </button>
              <span>?</span>
            </div>
            <span className="text-xs text-amber-700 dark:text-amber-400 font-mono">Rechtschreibkorrektur</span>
          </div>
        )}

        {/* Search Results Count and Latency Telemetry */}
        <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>
              ca. <strong className="font-semibold text-neutral-800 dark:text-neutral-200">{response.totalResults}</strong> Ergebnisse
            </span>
            <span>·</span>
            <span className="font-mono tabular-nums">{(response.durationMs / 1000).toFixed(3)} Sekunden</span>
            <span>·</span>
            <span>BM25 & Semantischer Index</span>
            {response.parsedQuery.siteFilters.length > 0 && (
              <>
                <span>·</span>
                <span className="font-medium text-neutral-800 dark:text-neutral-200">
                  site:{response.parsedQuery.siteFilters.join(', ')}
                </span>
              </>
            )}
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-neutral-400 text-[11px]">
            <span>Primärquellen bevorzugt</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          </div>
        </div>

        {/* 2-Column Split: Results (Left 65%) vs Knowledge Graph (Right 35%) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN: Organic Results + AI Overview + Comparisons */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6">
            {/* 1. DEUTSCHSUCH INTELLIGENT: Grounded AI Overview */}
            {response.aiOverview && (
              <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs transition-all">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-neutral-800 dark:text-neutral-200" />
                    <h2 className="text-sm font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
                      DEUTSCHSUCH Intelligent · Zusammenfassung
                    </h2>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-neutral-500 font-medium">
                      Quellenlage: <span className="font-semibold text-emerald-700 dark:text-emerald-400">{response.aiOverview.sourceConfidence}</span>
                    </span>
                    <button
                      onClick={() => setShowAiOverview(!showAiOverview)}
                      className="text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors p-1"
                      aria-label="Zusammenfassung ein-/ausklappen"
                    >
                      {showAiOverview ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {showAiOverview && (
                  <div className="mt-3.5">
                    <p className="text-sm leading-relaxed text-neutral-800 dark:text-neutral-200">
                      {response.aiOverview.summary}
                    </p>

                    {/* Citations List */}
                    <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                      <div className="text-[11px] uppercase tracking-wider font-semibold text-neutral-500 mb-2">
                        Verwendete Quellen ({response.aiOverview.citations.length})
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {response.aiOverview.citations.map((cite) => (
                          <a
                            key={cite.index}
                            href={cite.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-100 dark:bg-neutral-800 text-xs text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors border border-neutral-200/60 dark:border-neutral-700/60"
                          >
                            <span className="font-bold font-mono text-[10px] text-neutral-500">[{cite.index}]</span>
                            <span className="font-medium truncate max-w-[180px]">{cite.domain}</span>
                            <ExternalLink className="w-3 h-3 text-neutral-400 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </section>
            )}

            {/* 2. Comparison Search Card (e.g. ICE 4 vs TGV Duplex) */}
            {response.comparison && (
              <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-neutral-700 dark:text-neutral-300" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
                      Systemvergleich: {response.comparison.entityA} vs. {response.comparison.entityB}
                    </h3>
                  </div>
                  <span className="text-xs text-neutral-400">{response.comparison.category}</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/50">
                        <th className="py-2.5 px-3 font-semibold text-neutral-600 dark:text-neutral-400">Merkmal</th>
                        <th className="py-2.5 px-3 font-bold text-neutral-900 dark:text-neutral-100">
                          {response.comparison.entityA}
                        </th>
                        <th className="py-2.5 px-3 font-bold text-neutral-900 dark:text-neutral-100">
                          {response.comparison.entityB}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                      {response.comparison.specs.map((row, i) => (
                        <tr key={i} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30">
                          <td className="py-2 px-3 font-medium text-neutral-500 dark:text-neutral-400">{row.property}</td>
                          <td className="py-2 px-3 font-semibold text-neutral-900 dark:text-neutral-100">{row.valA}</td>
                          <td className="py-2 px-3 font-semibold text-neutral-900 dark:text-neutral-100">{row.valB}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 text-[11px] text-neutral-400 flex items-center justify-between">
                  <span>Quelle: {response.comparison.source}</span>
                  <a href={response.comparison.sourceUrl} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                    <span>Vollständiger Bericht</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </section>
            )}

            {/* 3. Local Search Entity Card (e.g. guter Elektriker in München) */}
            {response.parsedQuery.intent === 'LOCAL' && response.results.some((r) => r.document.localData) && (
              <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-red-600" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
                      Geprüfte Fachbetriebe in {response.parsedQuery.localCity || 'der Region'}
                    </h3>
                  </div>
                  <span className="text-xs text-neutral-400">Handwerkskammer-Zertifizierung</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {response.results
                    .filter((r) => r.document.localData)
                    .map((item, idx) => {
                      const local = item.document.localData!;
                      return (
                        <div
                          key={idx}
                          className="border border-neutral-200 dark:border-neutral-800 rounded-lg p-4 bg-neutral-50/50 dark:bg-neutral-800/30 flex flex-col justify-between"
                        >
                          <div>
                            <div className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                              {item.document.title.split('-')[0].trim()}
                            </div>
                            <div className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 mt-1">
                              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                              <span className="font-bold">{local.rating}</span>
                              <span className="text-neutral-400">({local.reviewsCount} Bewertungen)</span>
                            </div>
                            <div className="text-xs text-neutral-600 dark:text-neutral-400 mt-2 space-y-1">
                              <div className="flex items-center gap-1.5">
                                <MapPin className="w-3 h-3 text-neutral-400 shrink-0" />
                                <span className="truncate">{local.address}</span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <Phone className="w-3 h-3 text-neutral-400 shrink-0" />
                                <span>{local.phone}</span>
                              </div>
                            </div>
                          </div>
                          <div className="mt-3 pt-2 border-t border-neutral-200 dark:border-neutral-700/60 flex items-center justify-between text-[11px]">
                            <span className="text-neutral-500">{local.openingHours.split('·')[0]}</span>
                            <a
                              href={item.document.url}
                              target="_blank"
                              rel="noreferrer"
                              className="font-semibold text-neutral-900 dark:text-neutral-100 hover:underline flex items-center gap-0.5"
                            >
                              Details <ArrowRight className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </section>
            )}

            {/* 4. Organic Search Results List */}
            {response.results.length === 0 ? (
              <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-8 text-center">
                <h3 className="text-base font-semibold text-neutral-800 dark:text-neutral-200">
                  Keine direkten Treffer für „{query}“ gefunden.
                </h3>
                <p className="text-xs text-neutral-500 mt-2 max-w-md mx-auto">
                  Versuchen Sie allgemeinere Suchbegriffe, überprüfen Sie die Schreibweise oder entfernen Sie aktive Filter.
                </p>
                <div className="mt-4 flex flex-wrap justify-center gap-2 text-xs">
                  <button
                    onClick={() => onSearch('Wie funktioniert das deutsche Stromnetz?')}
                    className="px-3 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 rounded text-neutral-700 dark:text-neutral-300"
                  >
                    Stromnetz Deutschland
                  </button>
                  <button
                    onClick={() => onSearch('§ 823 BGB')}
                    className="px-3 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 rounded text-neutral-700 dark:text-neutral-300"
                  >
                    § 823 BGB
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {response.results.map((hit, index) => {
                  const doc = hit.document;
                  return (
                    <article
                      key={doc.id || index}
                      className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 hover:border-neutral-300 dark:hover:border-neutral-700 transition-all shadow-xs"
                    >
                      {/* URL Breadcrumb & Metadata Header */}
                      <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                        <div className="flex items-center gap-2 truncate">
                          <span className="font-semibold text-neutral-700 dark:text-neutral-300">{doc.domain}</span>
                          <span className="text-neutral-300 dark:text-neutral-600">›</span>
                          <span className="truncate max-w-[280px]">{doc.url.replace(/^https?:\/\/[^/]+/, '')}</span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {doc.filetype === 'pdf' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-mono text-red-700 dark:text-red-400 font-semibold bg-red-50 dark:bg-red-950/40 px-1.5 py-0.5 rounded">
                              <FileText className="w-3 h-3" />
                              PDF{doc.pageCount ? ` · ${doc.pageCount} S.` : ''}
                            </span>
                          )}
                          {doc.primarySource && (
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                              <CheckCircle2 className="w-3 h-3" />
                              Primärquelle
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Document Title */}
                      <h3 className="text-base sm:text-lg font-bold text-neutral-950 dark:text-neutral-50 hover:underline leading-snug">
                        <a href={doc.url} target="_blank" rel="noopener noreferrer">
                          {doc.title}
                        </a>
                      </h3>

                      {/* Snippet */}
                      <p className="mt-2 text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                        {hit.highlightedSnippet}
                      </p>

                      {/* Footer Metadata */}
                      <div className="mt-3.5 pt-2.5 border-t border-neutral-100 dark:border-neutral-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400">
                        <div className="flex items-center gap-3">
                          {doc.author && <span>{doc.author}</span>}
                          {doc.publishedAt && (
                            <span className="flex items-center gap-1 font-mono">
                              <Calendar className="w-3 h-3" />
                              {doc.publishedAt}
                            </span>
                          )}
                          <span className="uppercase text-[10px] font-mono tracking-wider bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded">
                            {doc.documentType}
                          </span>
                        </div>

                        {/* Internal score transparency */}
                        <div className="flex items-center gap-2 text-[11px] font-mono">
                          <span>BM25: {hit.bm25Score}</span>
                          <span>·</span>
                          <span>Gesamtscore: {hit.finalScore}</span>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: Knowledge Graph Entity Panel (Desktop Sticky) */}
          <div className="lg:col-span-5 xl:col-span-4 sticky top-32 space-y-6">
            {response.knowledgeEntity ? (
              <aside className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
                {/* Entity Image if available */}
                {response.knowledgeEntity.imageUrl && (
                  <div className="relative w-full h-44 rounded-lg overflow-hidden mb-4 border border-neutral-100 dark:border-neutral-800">
                    <Image
                      src={response.knowledgeEntity.imageUrl}
                      alt={response.knowledgeEntity.name}
                      fill
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}

                <div>
                  <div className="text-[11px] uppercase tracking-wider font-semibold text-neutral-400 dark:text-neutral-500">
                    {response.knowledgeEntity.type}
                  </div>
                  <h3 className="text-xl font-bold text-neutral-900 dark:text-neutral-100 mt-0.5">
                    {response.knowledgeEntity.name}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                    {response.knowledgeEntity.subtitle}
                  </p>
                </div>

                <p className="mt-3 text-xs leading-relaxed text-neutral-700 dark:text-neutral-300">
                  {response.knowledgeEntity.description}
                </p>

                {/* Structured Attributes List */}
                <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 space-y-2 text-xs">
                  {response.knowledgeEntity.attributes.map((attr, idx) => (
                    <div key={idx} className="flex justify-between gap-2">
                      <span className="text-neutral-400 shrink-0">{attr.label}:</span>
                      <span className="font-medium text-neutral-800 dark:text-neutral-200 text-right">{attr.value}</span>
                    </div>
                  ))}
                </div>

                {/* Official Website */}
                {response.knowledgeEntity.website && (
                  <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                    <a
                      href={response.knowledgeEntity.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg text-xs font-semibold hover:bg-neutral-800 dark:hover:bg-white transition-colors flex items-center justify-center gap-1.5"
                    >
                      <span>Offizielle Website besuchen</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}

                {/* Related entities */}
                {response.knowledgeEntity.relatedEntities.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-neutral-400 mb-2">
                      Verwandte Themen
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {response.knowledgeEntity.relatedEntities.map((rel, idx) => (
                        <button
                          key={idx}
                          onClick={() => onSearch(rel)}
                          className="px-2 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded text-[11px] transition-colors"
                        >
                          {rel}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Verification Source Citation */}
                <div className="mt-4 pt-2 text-[10px] text-neutral-400 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                  <span>Quelle: {response.knowledgeEntity.verifiedSource}</span>
                  <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 ml-1" />
                </div>
              </aside>
            ) : (
              <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs text-xs">
                <div className="font-semibold text-neutral-900 dark:text-neutral-100 mb-2 flex items-center gap-1.5">
                  <Building className="w-4 h-4 text-neutral-400" />
                  <span>DEUTSCHSUCH Transparenz</span>
                </div>
                <p className="text-neutral-500 leading-relaxed">
                  Suchergebnisse basieren auf unserem deutschen Webindex mit BM25-Relevanz, Kompositzerlegung und Primärquellenpriorisierung.
                </p>
                <div className="mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex flex-col gap-1.5 text-neutral-600 dark:text-neutral-400 text-[11px]">
                  <div>✓ Keine Tracking-Cookies</div>
                  <div>✓ Lokale Speicherung der Historie</div>
                  <div>✓ Strikte Trennung von Suche und KI</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
