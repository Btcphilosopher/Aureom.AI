'use client';

import React, { useState } from 'react';
import { X, SlidersHorizontal, Search } from 'lucide-react';
import { SearchQueryFilters } from '@/lib/search/types';

interface AdvancedSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (query: string, filters: SearchQueryFilters) => void;
  currentQuery: string;
  currentFilters: SearchQueryFilters;
}

export function AdvancedSearchModal({
  isOpen,
  onClose,
  onApply,
  currentQuery,
  currentFilters,
}: AdvancedSearchModalProps) {
  const [allWords, setAllWords] = useState(currentQuery);
  const [exactPhrase, setExactPhrase] = useState(currentFilters.exactPhrase || '');
  const [excludeWords, setExcludeWords] = useState('');
  const [siteDomain, setSiteDomain] = useState(currentFilters.site || '');
  const [filetype, setFiletype] = useState(currentFilters.filetype || '');
  const [timeRange, setTimeRange] = useState(currentFilters.timeRange || 'all');
  const [country, setCountry] = useState(currentFilters.country || 'DE');
  const [sourceType, setSourceType] = useState(currentFilters.sourceType || 'all');

  if (!isOpen) return null;

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Assemble query string with search operators
    let composedQuery = allWords.trim();
    if (exactPhrase.trim()) {
      composedQuery += ` "${exactPhrase.trim()}"`;
    }
    if (excludeWords.trim()) {
      const excluded = excludeWords
        .split(/\s+/)
        .map((w) => `-${w}`)
        .join(' ');
      composedQuery += ` ${excluded}`;
    }
    if (siteDomain.trim()) {
      composedQuery += ` site:${siteDomain.trim()}`;
    }
    if (filetype.trim()) {
      composedQuery += ` filetype:${filetype.trim()}`;
    }

    onApply(composedQuery.trim(), {
      timeRange,
      country,
      sourceType: sourceType === 'all' ? undefined : sourceType,
      site: siteDomain.trim() || undefined,
      filetype: filetype.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl w-full max-w-xl shadow-2xl p-6 text-neutral-900 dark:text-neutral-100 transition-colors">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-neutral-700 dark:text-neutral-300" />
            <h2 className="text-lg font-bold">Erweiterte Suche</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleFormSubmit} className="mt-4 space-y-4 text-xs">
          {/* All words */}
          <div>
            <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Alle diese Wörter enthalten
            </label>
            <input
              type="text"
              value={allWords}
              onChange={(e) => setAllWords(e.target.value)}
              placeholder="z.B. Energiewende Stromnetz"
              className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
            />
          </div>

          {/* Exact phrase */}
          <div>
            <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Exakte Wortgruppe oder Phrase
            </label>
            <input
              type="text"
              value={exactPhrase}
              onChange={(e) => setExactPhrase(e.target.value)}
              placeholder="z.B. Soziale Marktwirtschaft"
              className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
            />
          </div>

          {/* Exclude words */}
          <div>
            <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Keines dieser Wörter (-wort)
            </label>
            <input
              type="text"
              value={excludeWords}
              onChange={(e) => setExcludeWords(e.target.value)}
              placeholder="z.B. Werbung Gebraucht"
              className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
            />
          </div>

          {/* Site / Domain */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Website oder Domain (site:)
              </label>
              <input
                type="text"
                value={siteDomain}
                onChange={(e) => setSiteDomain(e.target.value)}
                placeholder="z.B. bund.de oder tagesschau.de"
                className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Dateiformat (filetype:)
              </label>
              <select
                value={filetype}
                onChange={(e) => setFiletype(e.target.value)}
                className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="">Beliebiges Format</option>
                <option value="pdf">Adobe Acrobat PDF (.pdf)</option>
                <option value="html">Webseite (.html)</option>
              </select>
            </div>
          </div>

          {/* Region and Date */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Region / Land
              </label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-2 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="DE">Deutschland (DE)</option>
                <option value="AT">Österreich (AT)</option>
                <option value="CH">Schweiz (CH)</option>
                <option value="GLOBAL">Weltweit</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Aktualität / Zeitraum
              </label>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as any)}
                className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-2 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="all">Beliebiger Zeitraum</option>
                <option value="24h">Letzte 24 Stunden</option>
                <option value="week">Letzte Woche</option>
                <option value="month">Letzter Monat</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Quellenart
              </label>
              <select
                value={sourceType}
                onChange={(e) => setSourceType(e.target.value)}
                className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg px-2 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="all">Alle Quellen</option>
                <option value="government">Behörden</option>
                <option value="academic">Wissenschaft</option>
                <option value="law">Gesetze</option>
              </select>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3 border-t border-neutral-100 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 font-medium"
            >
              Abbrechen
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg font-semibold hover:bg-neutral-800 dark:hover:bg-white flex items-center gap-1.5"
            >
              <Search className="w-4 h-4" />
              <span>Suche ausführen</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
