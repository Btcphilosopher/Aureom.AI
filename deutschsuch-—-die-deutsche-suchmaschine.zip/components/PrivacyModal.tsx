'use client';

import React, { useState, useEffect } from 'react';
import { X, Shield, Trash2, Check, Lock } from 'lucide-react';
import {
  getLocalPrivacySettings,
  saveLocalPrivacySettings,
  clearLocalSearchHistory,
  getLocalSearchHistory,
  PrivacySettings,
} from '@/lib/storage';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PrivacyModal({ isOpen, onClose }: PrivacyModalProps) {
  const [settings, setSettings] = useState<PrivacySettings>(getLocalPrivacySettings);
  const [historyCount, setHistoryCount] = useState<number>(() => getLocalSearchHistory().length);
  const [clearedNotice, setClearedNotice] = useState(false);

  if (!isOpen) return null;

  const handleToggleHistory = () => {
    const updated = { ...settings, historyEnabled: !settings.historyEnabled };
    setSettings(updated);
    saveLocalPrivacySettings(updated);
    if (!updated.historyEnabled) {
      clearLocalSearchHistory();
      setHistoryCount(0);
    }
  };

  const handleClearHistory = () => {
    clearLocalSearchHistory();
    setHistoryCount(0);
    setClearedNotice(true);
    setTimeout(() => setClearedNotice(false), 3000);
  };

  const handleClearAll = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('deutschsuch_history');
      localStorage.removeItem('deutschsuch_privacy');
    }
    setHistoryCount(0);
    setSettings(getLocalPrivacySettings());
    setClearedNotice(true);
    setTimeout(() => setClearedNotice(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 text-neutral-900 dark:text-neutral-100 transition-colors">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />
            <div>
              <h2 className="text-base sm:text-lg font-bold">Datenschutz & DSGVO-Konfiguration</h2>
              <p className="text-xs text-neutral-500">Ihre Daten gehören Ihnen — Zero-Tracking-Prinzip</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-5 text-xs">
          {/* Privacy Principles */}
          <div className="p-3.5 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200/80 dark:border-neutral-700/80 flex items-start gap-3">
            <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-neutral-600 dark:text-neutral-300 space-y-1">
              <div className="font-semibold text-neutral-900 dark:text-neutral-100">
                Europäische Datenschutzgarantie
              </div>
              <p className="text-[11px] leading-relaxed">
                DEUTSCHSUCH speichert standardmäßig keine IP-Adressen, erstellt keine Werbeprofile und setzt keine Third-Party-Tracker ein.
              </p>
            </div>
          </div>

          {/* Toggle History */}
          <div className="flex items-center justify-between p-3 border border-neutral-200 dark:border-neutral-800 rounded-lg">
            <div>
              <div className="font-semibold text-neutral-900 dark:text-neutral-100">
                Lokale Suchhistorie auf diesem Gerät
              </div>
              <div className="text-neutral-500 text-[11px]">
                {settings.historyEnabled
                  ? `Aktiv (${historyCount} gespeicherte Suchanfragen im Browser)`
                  : 'Deaktiviert (Keine Speicherung)'}
              </div>
            </div>
            <button
              onClick={handleToggleHistory}
              className={`w-11 h-6 rounded-full transition-colors relative flex items-center p-0.5 ${
                settings.historyEnabled ? 'bg-neutral-900 dark:bg-neutral-100' : 'bg-neutral-300 dark:bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white dark:bg-neutral-900 shadow-md transform transition-transform ${
                  settings.historyEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* SafeSearch */}
          <div>
            <label className="block font-semibold text-neutral-800 dark:text-neutral-200 mb-1">
              Jugendschutz & SafeSearch
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['strict', 'moderate', 'off'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    const upd = { ...settings, safeSearch: mode };
                    setSettings(upd);
                    saveLocalPrivacySettings(upd);
                  }}
                  className={`py-2 px-3 rounded-lg border text-xs font-medium text-center transition-all ${
                    settings.safeSearch === mode
                      ? 'border-neutral-900 dark:border-neutral-100 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 font-bold'
                      : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/40 text-neutral-600 dark:text-neutral-400'
                  }`}
                >
                  {mode === 'strict' ? 'Streng' : mode === 'moderate' ? 'Moderat' : 'Aus'}
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons to delete */}
          <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
            <button
              onClick={handleClearHistory}
              disabled={historyCount === 0}
              className="w-full py-2 px-3 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center justify-center gap-1.5 transition-colors disabled:opacity-40"
            >
              <Trash2 className="w-4 h-4 text-neutral-500" />
              <span>Suchverlauf auf diesem Gerät löschen</span>
            </button>

            <button
              onClick={handleClearAll}
              className="w-full py-2 px-3 border border-red-200 dark:border-red-900/60 rounded-lg text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Alle lokalen Einstellungen und Cookies zurücksetzen</span>
            </button>

            {clearedNotice && (
              <div className="text-center text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center justify-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>Daten erfolgreich gelöscht!</span>
              </div>
            )}
          </div>
        </div>

        <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg font-semibold text-xs hover:bg-neutral-800 dark:hover:bg-white"
          >
            Fertig
          </button>
        </div>
      </div>
    </div>
  );
}
