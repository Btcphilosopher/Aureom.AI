'use client';

import React, { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { Search, X, ArrowRight, Cloud, TrendingUp, Train, Scale, Zap, BookOpen, ExternalLink } from 'lucide-react';
import { getGermanSuggestions } from '@/lib/search/autocomplete';

interface SearchHeroProps {
  onSearch: (query: string) => void;
  onSelectSuggestion?: (query: string) => void;
}

export function SearchHero({ onSearch, onSelectSuggestion }: SearchHeroProps) {
  const [inputValue, setInputValue] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Compute suggestions reactively without triggering cascading renders in useEffect
  const suggestions = React.useMemo(() => {
    if (inputValue.trim().length >= 2) {
      return getGermanSuggestions(inputValue);
    }
    return [];
  }, [inputValue]);

  // Handle outside click to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      setShowDropdown(false);
      onSearch(inputValue.trim());
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    setShowDropdown(false);
    if (onSelectSuggestion) {
      onSelectSuggestion(suggestion);
    } else {
      onSearch(suggestion);
    }
  };

  return (
    <div className="w-full flex flex-col">
      {/* Hero Marquee Section with Berlin Skyline Background */}
      <section className="relative w-full min-h-[460px] lg:min-h-[500px] flex flex-col justify-center items-center px-4 py-16 overflow-hidden">
        {/* Background Image with dark contrast scrim */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/berlin_skyline_hero.jpg"
            alt="Berlin Skyline bei Sonnenaufgang mit Fernsehturm und Spree"
            fill
            priority
            className="object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Measured contrast scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/65 to-neutral-950/75 backdrop-blur-[1px]" />
        </div>

        {/* Content Box */}
        <div className="relative z-10 w-full max-w-3xl mx-auto flex flex-col items-center text-center">
          {/* Minimalist German Flag accent line */}
          <div className="flex items-center gap-1.5 mb-3" aria-hidden="true">
            <span className="w-6 h-1 bg-neutral-900 rounded-xs" />
            <span className="w-6 h-1 bg-red-600 rounded-xs" />
            <span className="w-6 h-1 bg-amber-400 rounded-xs" />
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white font-sans drop-shadow-md">
            Alles finden. Schneller.
          </h1>
          <p className="mt-3 text-sm sm:text-base text-neutral-300 max-w-xl font-normal drop-shadow-sm">
            Die unabhängige deutsche Suchmaschine mit eigener linguistischer Sprachverarbeitung und Datenschutz.
          </p>

          {/* Search Bar Form */}
          <div className="w-full mt-7 relative" ref={dropdownRef}>
            <form
              onSubmit={handleSubmit}
              className="relative flex items-center bg-white dark:bg-neutral-900 rounded-full shadow-2xl border border-white/20 focus-within:ring-3 focus-within:ring-white/40 transition-all p-1.5"
            >
              <div className="pl-3.5 pr-2 text-neutral-400 flex items-center justify-center">
                <Search className="w-5 h-5 text-neutral-500" />
              </div>
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => {
                  setInputValue(e.target.value);
                  if (e.target.value.trim().length >= 2) {
                    setShowDropdown(true);
                  }
                }}
                placeholder="Wonach suchen Sie? (z.B. Strompreis Deutschland, § 823 BGB, ICE 4 vs TGV...)"
                className="w-full bg-transparent border-none text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 dark:placeholder-neutral-500 text-sm sm:text-base px-2 py-2 focus:outline-none"
                autoComplete="off"
                spellCheck="false"
              />

              {inputValue && (
                <button
                  type="button"
                  onClick={() => setInputValue('')}
                  className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors mr-1"
                  title="Eingabe löschen"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              <button
                type="submit"
                className="bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-neutral-800 dark:hover:bg-white transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
              >
                <span>Suchen</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Autocomplete Suggestions Dropdown */}
            {showDropdown && suggestions.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-neutral-900 rounded-2xl shadow-xl border border-neutral-200 dark:border-neutral-800 py-2 z-50 text-left overflow-hidden">
                <div className="px-4 py-1 text-[11px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
                  Vorschläge
                </div>
                {suggestions.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSuggestionClick(item)}
                    className="w-full px-4 py-2 text-sm text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800/80 flex items-center justify-between text-left transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <Search className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span>{item}</span>
                    </span>
                    <span className="text-xs text-neutral-400 font-mono">↵</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick Search Chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-5">
            {[
              { label: 'Wetter', query: 'Wetter Berlin', icon: Cloud },
              { label: 'Aktien & DAX', query: 'aktuelle Nachrichten Deutschland Wirtschaft', icon: TrendingUp },
              { label: 'Fahrpläne', query: 'deutsche Bundesbahn', icon: Train },
              { label: 'Gesetze', query: '§ 823 BGB', icon: Scale },
              { label: 'Strompreis', query: 'Wie hoch ist der aktuelle Strompreis in Deutschland?', icon: Zap },
              { label: 'Wissenschaft', query: 'Fraunhofer ISE Solarstudie', icon: BookOpen },
            ].map((chip) => {
              const Icon = chip.icon;
              return (
                <button
                  key={chip.label}
                  type="button"
                  onClick={() => handleSuggestionClick(chip.query)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium text-white/90 bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Icon className="w-3.5 h-3.5 text-white/80" />
                  <span>{chip.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Frontpage 4-Column Content Modules (Directly inspired by german-search.png) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Module 1: Top News */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2">
                <span>Top News</span>
                <span className="text-[11px] font-normal text-neutral-400">Tagesschau</span>
              </div>
              <h3
                onClick={() => onSearch('aktuelle Nachrichten Deutschland Wirtschaft')}
                className="text-base font-bold text-neutral-900 dark:text-neutral-100 hover:text-red-700 dark:hover:text-red-400 cursor-pointer transition-colors leading-snug"
              >
                Bundesregierung bringt Wachstumsinitiative auf den Weg
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-2 line-clamp-3">
                Kanzler und Wirtschaftsminister kündigen Entlastungen für Unternehmen und Investitionsanreize für erneuerbare Energien an.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
              <span>Heute, 08:24 Uhr</span>
              <button
                onClick={() => onSearch('aktuelle Nachrichten Deutschland Wirtschaft')}
                className="text-neutral-700 dark:text-neutral-300 hover:underline font-medium"
              >
                Mehr Nachrichten →
              </button>
            </div>
          </div>

          {/* Module 2: Wetter Berlin */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2">
                <span>Wetterdienst</span>
                <span>Berlin</span>
              </div>
              <div className="flex items-baseline gap-3 my-2">
                <span className="text-4xl font-extrabold text-neutral-900 dark:text-neutral-100 tabular-nums font-mono">
                  12°
                </span>
                <span className="text-sm text-neutral-600 dark:text-neutral-400">☀️ Heiter</span>
              </div>
              <div className="text-xs text-neutral-500">
                Höchstwert: 16° · Tiefstwert: 6° · Wind: 14 km/h
              </div>

              {/* Hourly preview */}
              <div className="grid grid-cols-4 gap-2 text-center mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-xs">
                <div>
                  <div className="text-[10px] text-neutral-400">09:00</div>
                  <div className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5">11°</div>
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400">12:00</div>
                  <div className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5">14°</div>
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400">15:00</div>
                  <div className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5">15°</div>
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400">18:00</div>
                  <div className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5">13°</div>
                </div>
              </div>
            </div>
            <button
              onClick={() => onSearch('Wetter Deutschland')}
              className="mt-3 text-[11px] text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 text-left transition-colors"
            >
              7-Tage-Prognose öffnen →
            </button>
          </div>

          {/* Module 3: Beliebte Suchen (Trends) */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-3">
                Beliebte Suchen
              </div>
              <ul className="space-y-2 text-xs">
                {[
                  { text: 'Wie funktioniert das deutsche Stromnetz?', label: 'Infrastruktur' },
                  { text: 'ICE 4 vs TGV Duplex', label: 'Vergleich' },
                  { text: 'Universitäten München Maschinenbau', label: 'Bildung' },
                  { text: 'Kraftfahrzeughaftpflichtversicherung', label: 'Kompositum' },
                  { text: 'Bundesverfassungsgericht Grundgesetz', label: 'Justiz' },
                ].map((trend, i) => (
                  <li key={i}>
                    <button
                      onClick={() => onSearch(trend.text)}
                      className="w-full text-left flex items-center justify-between text-neutral-800 dark:text-neutral-200 hover:text-red-700 dark:hover:text-red-400 transition-colors py-0.5"
                    >
                      <span className="truncate pr-2">{trend.text}</span>
                      <span className="text-[10px] text-neutral-400 font-mono shrink-0">{trend.label}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400">
              Anonymisiert & aggregiert
            </div>
          </div>

          {/* Module 4: Schnellzugriff (Amtliche Portale & Dienste) */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-3">
                Schnellzugriff
              </div>
              <ul className="space-y-2.5 text-xs">
                {[
                  { title: '§ 823 BGB Gesetze', query: '§ 823 BGB', desc: 'Bundesministerium der Justiz' },
                  { title: 'Wasserstoffstrategie (PDF)', query: 'filetype:pdf Deutschland Wasserstoff', desc: 'Bundesregierung' },
                  { title: 'Deutsche Bundesbahn Chronik', query: 'deutsche Bundesbahn', desc: 'Historisches Archiv' },
                  { title: 'Elektriker vor Ort', query: 'guter Elektriker in München', desc: 'Lokale Handwerkssuche' },
                ].map((item, i) => (
                  <li key={i}>
                    <button
                      onClick={() => onSearch(item.query)}
                      className="w-full text-left p-1.5 rounded hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors flex items-start justify-between"
                    >
                      <div>
                        <div className="font-semibold text-neutral-900 dark:text-neutral-100">{item.title}</div>
                        <div className="text-[11px] text-neutral-500">{item.desc}</div>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400">
              Direkte Verifikation von Primärquellen
            </div>
          </div>
        </div>
      </section>

      {/* Footer info */}
      <footer className="border-t border-neutral-200 dark:border-neutral-800 py-6 text-center text-xs text-neutral-500 dark:text-neutral-400 bg-white dark:bg-neutral-900 transition-colors">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span>DEUTSCHSUCH — Die deutsche Suchmaschine</span>
            <span>·</span>
            <span>Datenschutzkonform (DSGVO)</span>
            <span>·</span>
            <span>Ohne Tracking-Cookies</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Entwickelt für das europäische Web</span>
            <span>🇩🇪</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
