'use client';

import React, { useState, useEffect } from 'react';
import {
  Search,
  SlidersHorizontal,
  Terminal,
  Shield,
  FileText,
  Layers,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (action: string) => void;
}

export function CommandPalette({ isOpen, onClose, onSelectAction }: CommandPaletteProps) {
  const [search, setSearch] = useState('');

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const commands = [
    { id: 'search-strom', title: 'Wie funktioniert das deutsche Stromnetz?', category: 'Top-Suche', icon: Search },
    { id: 'search-strompreis', title: 'Wie hoch ist der aktuelle Strompreis in Deutschland?', category: 'Top-Suche', icon: Search },
    { id: 'search-ice4-tgv', title: 'ICE 4 vs TGV Duplex', category: 'Vergleichssuche', icon: Layers },
    { id: 'search-823-bgb', title: '§ 823 BGB Schadensersatzpflicht', category: 'Bundesgesetze', icon: FileText },
    { id: 'search-maschinenbau', title: 'Universitäten München Maschinenbau', category: 'Wissenschaft', icon: Search },
    { id: 'search-wasserstoff-pdf', title: 'filetype:pdf Deutschland Wasserstoff', category: 'Dokumente', icon: FileText },
    { id: 'open-advanced', title: 'Erweiterte Suche öffnen', category: 'Werkzeuge', icon: SlidersHorizontal },
    { id: 'open-console', title: 'Crawler & Systemkonsole öffnen', category: 'Infrastruktur', icon: Terminal },
    { id: 'open-privacy', title: 'Datenschutz- & DSGVO-Einstellungen', category: 'Sicherheit', icon: Shield },
  ];

  const filtered = commands.filter((c) => c.title.toLowerCase().includes(search.toLowerCase()) || c.category.toLowerCase().includes(search.toLowerCase()));

  const handleSelect = (cmdId: string, title: string) => {
    onClose();
    if (cmdId.startsWith('search-')) {
      onSelectAction(`QUERY:${title}`);
    } else {
      onSelectAction(cmdId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden text-neutral-900 dark:text-neutral-100 transition-colors">
        {/* Input */}
        <div className="flex items-center px-4 py-3 border-b border-neutral-200 dark:border-neutral-800">
          <Search className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Befehl oder Abfrage tippen... (z.B. Strompreis, Gesetze, Konsole)"
            className="w-full bg-transparent text-sm focus:outline-none placeholder-neutral-400 dark:placeholder-neutral-500 text-neutral-900 dark:text-neutral-100"
            autoFocus
          />
          <kbd className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-400 border border-neutral-200 dark:border-neutral-700">
            Esc
          </kbd>
        </div>

        {/* Results */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1 text-xs">
          {filtered.length === 0 ? (
            <div className="py-6 text-center text-neutral-400">Keine passenden Befehle gefunden.</div>
          ) : (
            filtered.map((cmd) => {
              const Icon = cmd.icon;
              return (
                <button
                  key={cmd.id}
                  onClick={() => handleSelect(cmd.id, cmd.title)}
                  className="w-full px-3 py-2.5 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-800/80 text-left transition-colors group"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Icon className="w-4 h-4 text-neutral-500 shrink-0" />
                    <span className="font-medium text-neutral-800 dark:text-neutral-200 truncate">{cmd.title}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    <span className="text-[10px] text-neutral-400 uppercase font-mono">{cmd.category}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-neutral-300 group-hover:text-neutral-700 dark:group-hover:text-neutral-200 transition-colors" />
                  </div>
                </button>
              );
            })
          )}
        </div>

        <div className="p-2.5 bg-neutral-50 dark:bg-neutral-800/50 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
          <span>Tipp: Drücken Sie Strg+K überall, um diese Palette aufzurufen.</span>
          <span className="font-mono">DEUTSCHSUCH v1.0</span>
        </div>
      </div>
    </div>
  );
}
