/**
 * DEUTSCHSUCH - Public Search API (v1)
 * Section 60 & 61: Public REST Search API
 * GET /api/v1/search?q=...&language=de&country=DE
 */

import { NextRequest, NextResponse } from 'next/server';
import { executeGermanSearch } from '@/lib/search/searchService';
import { SearchQueryFilters } from '@/lib/search/types';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);

  const q = searchParams.get('q') || '';
  if (!q.trim()) {
    return NextResponse.json(
      { error: 'Parameter "q" (Suchanfrage) ist erforderlich.' },
      { status: 400 }
    );
  }

  const language = searchParams.get('language') || 'de';
  const country = searchParams.get('country') || 'DE';
  const page = parseInt(searchParams.get('page') || '1', 10);
  const limit = Math.min(parseInt(searchParams.get('limit') || '10', 10), 50);
  const site = searchParams.get('site') || undefined;
  const filetype = searchParams.get('filetype') || undefined;
  const safeSearch = (searchParams.get('safe_search') as 'strict' | 'moderate' | 'off') || 'moderate';

  const filters: SearchQueryFilters = {
    language,
    country,
    site,
    filetype,
    safeSearch,
  };

  const searchResult = executeGermanSearch(q, filters, page, limit);

  // Map to the public API contract specified in Section 61
  const formattedResults = searchResult.results.map((hit) => ({
    title: hit.document.title,
    url: hit.document.url,
    domain: hit.document.domain,
    snippet: hit.document.snippet,
    language: hit.document.language,
    published_at: hit.document.publishedAt,
    source_type: hit.document.documentType,
    primary_source: hit.document.primarySource,
    score: hit.finalScore,
    entities: hit.document.entities,
  }));

  return NextResponse.json({
    query: searchResult.query,
    language,
    country,
    duration_ms: searchResult.durationMs,
    corrected_query: searchResult.correctedQuery,
    did_you_mean: searchResult.didYouMean,
    intent: searchResult.parsedQuery.intent,
    results: formattedResults,
    pagination: {
      page: searchResult.page,
      limit: searchResult.limit,
      total: searchResult.totalResults,
    },
    knowledge_panel: searchResult.knowledgeEntity
      ? {
          name: searchResult.knowledgeEntity.name,
          type: searchResult.knowledgeEntity.type,
          description: searchResult.knowledgeEntity.description,
          attributes: searchResult.knowledgeEntity.attributes,
          source: searchResult.knowledgeEntity.verifiedSource,
        }
      : null,
    ai_overview: searchResult.aiOverview || null,
  });
}
