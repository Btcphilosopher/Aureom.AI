/**
 * DEUTSCHSUCH - Server-Side AI Summary Endpoint
 * Section 33, 34, 84, 85: DEUTSCHSUCH INTELLIGENT
 * Strictly grounded on the retrieved documents using gemini-3.8-flash.
 */

import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export async function POST(request: NextRequest) {
  try {
    const { query, documents } = await request.json();

    if (!query || !Array.isArray(documents) || documents.length === 0) {
      return NextResponse.json({ error: 'Ungültige Anfrage oder keine Dokumente übergeben.' }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    // Grounded document context for Gemini
    const docContext = documents
      .slice(0, 4)
      .map(
        (doc: { title: string; domain: string; snippet: string; body?: string }, i: number) =>
          `[Quelle ${i + 1}]:\nTitel: ${doc.title}\nDomain: ${doc.domain}\nInhalt: ${doc.body || doc.snippet}\n`
      )
      .join('\n---\n');

    if (apiKey) {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const systemInstruction = `Du bist die KI-Zusammenfassungsschicht von DEUTSCHSUCH, einer deutschen Websuchmaschine.
WICHTIGE REGELN:
1. Antworte in präzisem, klarem Deutsch.
2. Verwende AUSSCHLIESSLICH die bereitgestellten Quellen.
3. Erfinde KEINE Fakten, URLs oder Quellen hinzu.
4. Setze nach jeder Kernaussage den Quellennachweis in eckigen Klammern, z.B. [1] oder [2].
5. Halte die Zusammenfassung kompakt (2 bis 4 prägnante Sätze).
6. Wenn die Quellen keine ausreichende Antwort liefern, erkläre sachlich, dass die vorliegenden Dokumente keine hinreichende Evidenz enthalten.`;

      const prompt = `Suchanfrage: "${query}"

Gefundene Dokumente aus dem deutschen Webindex:
${docContext}

Erstelle nun einen sachlichen, belegten Überblick mit Quellennummern [1], [2].`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      });

      const summaryText = response.text || '';

      return NextResponse.json({
        summary: summaryText,
        sourceConfidence: documents.some((d: { primarySource?: boolean }) => d.primarySource) ? 'stark' : 'mittel',
      });
    }

    // Deterministic fallback if API key is pending
    const topDoc = documents[0];
    const fallbackSummary = `${topDoc.snippet} [1]`;

    return NextResponse.json({
      summary: fallbackSummary,
      sourceConfidence: topDoc.primarySource ? 'stark' : 'mittel',
    });
  } catch (error) {
    console.error('Error generating AI summary:', error);
    return NextResponse.json(
      { error: 'Zusammenfassung konnte nicht generiert werden.' },
      { status: 500 }
    );
  }
}
