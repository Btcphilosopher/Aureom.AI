'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar, SearchTab } from '@/components/Navbar';
import { SearchHero } from '@/components/SearchHero';
import { SearchResultsView } from '@/components/SearchResultsView';
import { AdvancedSearchModal } from '@/components/AdvancedSearchModal';
import { SystemConsoleModal } from '@/components/SystemConsoleModal';
import { PrivacyModal } from '@/components/PrivacyModal';
import { CommandPalette } from '@/components/CommandPalette';
import { executeGermanSearch } from '@/lib/search/searchService';
import { SearchResponse, SearchQueryFilters } from '@/lib/search/types';
import { addLocalSearchHistory, getLocalPrivacySettings } from '@/lib/storage';

export default function DeutschSuchApp() {
  const [query, setQuery] = useState('');
  const [searchResponse, setSearchResponse] = useState<SearchResponse | null>(null);
  const [activeTab, setActiveTab] = useState<SearchTab>('web');
  const [filters, setFilters] = useState<SearchQueryFilters>({
    country: 'DE',
    language: 'de',
    timeRange: 'all',
  });

  // Modal dialog states
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Dark mode state with lazy initializer
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const settings = getLocalPrivacySettings();
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return settings.theme === 'dark' || (settings.theme === 'system' && prefersDark);
  });

  // Synchronize document classList with isDarkMode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Execute Search Function
  const handlePerformSearch = useCallback(
    (searchQuery: string, customFilters?: SearchQueryFilters, tab?: SearchTab) => {
      const targetQuery = searchQuery.trim();
      if (!targetQuery) return;

      setQuery(targetQuery);
      addLocalSearchHistory(targetQuery);

      const effectiveTab = tab || activeTab;
      const combinedFilters: SearchQueryFilters = {
        ...filters,
        ...(customFilters || {}),
      };

      // Set source filter based on active tab
      if (effectiveTab === 'news') combinedFilters.sourceType = 'news';
      else if (effectiveTab === 'science') combinedFilters.sourceType = 'academic';
      else if (effectiveTab === 'law') combinedFilters.sourceType = 'law';
      else if (effectiveTab === 'local') combinedFilters.sourceType = 'local';
      else if (effectiveTab === 'web' && !customFilters?.sourceType) {
        delete combinedFilters.sourceType;
      }

      // Execute classical BM25 & German Linguistic Retrieval
      const initialResponse = executeGermanSearch(targetQuery, combinedFilters);
      setSearchResponse(initialResponse);

      // Asynchronous server-side Gemini AI summary enrichment (AI on top)
      if (initialResponse.results.length > 0) {
        fetch('/api/ai-summary', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: targetQuery,
            documents: initialResponse.results.map((r) => ({
              title: r.document.title,
              domain: r.document.domain,
              snippet: r.document.snippet,
              body: r.document.body,
              primarySource: r.document.primarySource,
            })),
          }),
        })
          .then((res) => (res.ok ? res.json() : null))
          .then((aiData) => {
            if (aiData?.summary) {
              setSearchResponse((prev) => {
                if (!prev || prev.query !== targetQuery) return prev;
                return {
                  ...prev,
                  aiOverview: {
                    summary: aiData.summary,
                    sourceConfidence: aiData.sourceConfidence || 'stark',
                    citations: prev.results.slice(0, 3).map((r, i) => ({
                      index: i + 1,
                      title: r.document.title,
                      domain: r.document.domain,
                      url: r.document.url,
                      publishedAt: r.document.publishedAt,
                    })),
                  },
                };
              });
            }
          })
          .catch(() => {
            // Classical search remains completely intact even if AI summary is unavailable
          });
      }
    },
    [activeTab, filters]
  );

  // Handle Tab Switch
  const handleTabChange = useCallback(
    (tab: SearchTab) => {
      setActiveTab(tab);
      if (searchResponse && query) {
        handlePerformSearch(query, undefined, tab);
      }
    },
    [searchResponse, query, handlePerformSearch]
  );

  // Keyboard shortcut listener (Ctrl+K, Alt+1..5, etc.)
  useEffect(() => {
    function handleGlobalKeyDown(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      } else if (e.altKey && e.key === '1') {
        e.preventDefault();
        handleTabChange('web');
      } else if (e.altKey && e.key === '2') {
        e.preventDefault();
        handleTabChange('news');
      } else if (e.altKey && e.key === '3') {
        e.preventDefault();
        handleTabChange('images');
      } else if (e.altKey && e.key === '4') {
        e.preventDefault();
        handleTabChange('videos');
      } else if (e.altKey && e.key === '5') {
        e.preventDefault();
        handleTabChange('science');
      }
    }
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [handleTabChange]);

  // Handle Command Palette actions
  const handleCommandAction = (action: string) => {
    if (action.startsWith('QUERY:')) {
      const q = action.replace('QUERY:', '');
      handlePerformSearch(q);
    } else if (action === 'open-advanced') {
      setIsAdvancedOpen(true);
    } else if (action === 'open-console') {
      setIsConsoleOpen(true);
    } else if (action === 'open-privacy') {
      setIsPrivacyOpen(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors font-sans selection:bg-neutral-900 selection:text-white dark:selection:bg-white dark:selection:text-neutral-900">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onOpenAdvanced={() => setIsAdvancedOpen(true)}
        onOpenConsole={() => setIsConsoleOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
        compact={Boolean(searchResponse)}
      />

      {/* Main View Area: Either Search Hero or Search Results */}
      <main className="flex-1 flex flex-col">
        {searchResponse ? (
          <SearchResultsView
            query={query}
            response={searchResponse}
            onSearch={(q, f) => handlePerformSearch(q, f)}
            filters={filters}
            onFilterChange={setFilters}
          />
        ) : (
          <SearchHero
            onSearch={(q) => handlePerformSearch(q)}
            onSelectSuggestion={(q) => handlePerformSearch(q)}
          />
        )}
      </main>

      {/* Modals */}
      <AdvancedSearchModal
        isOpen={isAdvancedOpen}
        onClose={() => setIsAdvancedOpen(false)}
        onApply={(q, f) => {
          setFilters(f);
          handlePerformSearch(q, f);
        }}
        currentQuery={query}
        currentFilters={filters}
      />

      <SystemConsoleModal
        isOpen={isConsoleOpen}
        onClose={() => setIsConsoleOpen(false)}
      />

      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />

      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectAction={handleCommandAction}
      />
    </div>
  );
}
