import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'DEUTSCHSUCH — Die deutsche Suchmaschine',
  description: 'Vollständige deutsche Websuchmaschine der nächsten Generation mit eigener linguistischer Sprachverarbeitung, BM25-Retrieval, Knowledge Graph und privatsphäre-orientierter Suche.',
  openGraph: {
    title: 'DEUTSCHSUCH — Die deutsche Suchmaschine',
    description: 'Vollständige deutsche Websuchmaschine der nächsten Generation mit eigener linguistischer Sprachverarbeitung, BM25-Retrieval, Knowledge Graph und privatsphäre-orientierter Suche.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DEUTSCHSUCH — Die deutsche Suchmaschine',
    description: 'Vollständige deutsche Websuchmaschine der nächsten Generation mit eigener linguistischer Sprachverarbeitung, BM25-Retrieval, Knowledge Graph und privatsphäre-orientierter Suche.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="de">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
