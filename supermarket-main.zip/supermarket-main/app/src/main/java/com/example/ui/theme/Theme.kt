package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimaryMinimal,
    secondary = DarkSecondaryMinimal,
    tertiary = DarkPrimaryMinimal,
    background = DarkMinimalBg,
    surface = DarkMinimalSurface,
    onPrimary = Color(0xFF141E0D),
    onSecondary = Color(0xFFFFFFFF),
    onBackground = DarkMinimalText,
    onSurface = DarkMinimalText,
    primaryContainer = Color(0xFF386B20),
    onPrimaryContainer = Color(0xFFD7E8CD)
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryMinimalGreen,
    secondary = SecondaryTonalGreen,
    tertiary = PrimaryMinimalGreen,
    background = MinimalBg,
    surface = MinimalSurface,
    onPrimary = OnPrimaryMinimal,
    onSecondary = OnPrimaryContainerMinimal,
    onBackground = MinimalOnSurface,
    onSurface = MinimalOnSurface,
    primaryContainer = SecondaryTonalGreen,
    onPrimaryContainer = OnPrimaryContainerMinimal,
    surfaceVariant = MinimalSurfaceVariant,
    onSurfaceVariant = MinimalOnSurfaceVariant,
    error = AlertRed,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
