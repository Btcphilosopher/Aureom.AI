package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: String): ProductEntity?

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%'")
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)
}

@Dao
interface BasketDao {
    @Query("SELECT * FROM basket_items")
    fun getBasketItems(): Flow<List<BasketItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBasketItem(item: BasketItemEntity)

    @Query("DELETE FROM basket_items WHERE id = :id")
    suspend fun deleteBasketItem(id: String)

    @Query("DELETE FROM basket_items")
    suspend fun clearBasket()
}

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes")
    fun getAllRecipes(): Flow<List<RecipeEntity>>

    @Query("SELECT * FROM recipes WHERE id = :id")
    suspend fun getRecipeById(id: String): RecipeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipes(recipes: List<RecipeEntity>)
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM digital_receipts ORDER BY timestamp DESC")
    fun getAllReceipts(): Flow<List<DigitalReceiptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: DigitalReceiptEntity)
}

@Dao
interface LoyaltyDao {
    @Query("SELECT * FROM loyalty_profile WHERE id = 1")
    fun getLoyaltyProfile(): Flow<LoyaltyProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoyaltyProfile(profile: LoyaltyProfile)
}
