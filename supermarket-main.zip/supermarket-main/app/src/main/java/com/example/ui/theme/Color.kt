package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Light Colors
val PrimaryMinimalGreen = Color(0xFF386B20)
val SecondaryTonalGreen = Color(0xFFD7E8CD)
val OnPrimaryMinimal = Color(0xFFFFFFFF)
val OnPrimaryContainerMinimal = Color(0xFF141E0D)

val MinimalBg = Color(0xFFFCFDF6)
val MinimalBorder = Color(0xFFDDE4D1)
val MinimalSurface = Color(0xFFFFFFFF)
val MinimalSurfaceVariant = Color(0xFFF0F1E8)
val MinimalOnSurface = Color(0xFF1A1C18)
val MinimalOnSurfaceVariant = Color(0xFF43493E)

val AlertRed = Color(0xFFBA1A1A)
val PromoYellow = Color(0xFFFFEFA7)

// Dark Palette alternatives that preserve the same structure
val DarkPrimaryMinimal = Color(0xFF9CD67E)
val DarkSecondaryMinimal = Color(0xFF3B522C)
val DarkMinimalBg = Color(0xFF121411)
val DarkMinimalSurface = Color(0xFF1A1C18)
val DarkMinimalText = Color(0xFFE2E3DC)

