package com.example.data.repository

import com.example.data.database.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MarketRepository(private val db: AppDatabase) {

    val allFullProducts: Flow<List<ProductEntity>> = db.productDao().getAllProducts()
    val basketItems: Flow<List<BasketItemEntity>> = db.basketDao().getBasketItems()
    val allRecipes: Flow<List<RecipeEntity>> = db.recipeDao().getAllRecipes()
    val receipts: Flow<List<DigitalReceiptEntity>> = db.receiptDao().getAllReceipts()
    val loyaltyProfile: Flow<LoyaltyProfile?> = db.loyaltyDao().getLoyaltyProfile()

    suspend fun searchProducts(query: String): Flow<List<ProductEntity>> {
        if (query.isBlank()) return allFullProducts
        return db.productDao().searchProducts(query)
    }

    suspend fun addToBasket(product: ProductEntity, quantity: Int = 1) {
        withContext(Dispatchers.IO) {
            val existing = db.basketDao().getBasketItems()
            var currentQty = quantity
            db.basketDao().insertBasketItem(
                BasketItemEntity(
                    id = product.id,
                    name = product.name,
                    price = product.price,
                    quantity = currentQty,
                    category = product.category,
                    unit = product.unit,
                    promoMessage = product.promoMessage,
                    ownBrandEquivalentId = product.ownBrandEquivalentId
                )
            )
        }
    }

    suspend fun updateBasketQty(id: String, name: String, price: Double, qty: Int, category: String, unit: String, promo: String?, ownBrandId: String?) {
        withContext(Dispatchers.IO) {
            if (qty <= 0) {
                db.basketDao().deleteBasketItem(id)
            } else {
                db.basketDao().insertBasketItem(
                    BasketItemEntity(id, name, price, qty, category, unit, promo, ownBrandId)
                )
            }
        }
    }

    suspend fun deleteBasketItem(id: String) {
        withContext(Dispatchers.IO) {
            db.basketDao().deleteBasketItem(id)
        }
    }

    suspend fun clearBasket() {
        withContext(Dispatchers.IO) {
            db.basketDao().clearBasket()
        }
    }

    suspend fun recordReceipt(total: Double, saved: Double, categoryBreakdown: Map<String, Double>, itemsCount: Int) {
        withContext(Dispatchers.IO) {
            val json = JSONObject()
            categoryBreakdown.forEach { (cat, amt) ->
                json.put(cat, amt)
            }
            val formatter = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            val dateStr = formatter.format(Date())
            db.receiptDao().insertReceipt(
                DigitalReceiptEntity(
                    timestamp = System.currentTimeMillis(),
                    totalSpent = total,
                    totalSaved = saved,
                    categoryBreakdownJson = json.toString(),
                    itemsCount = itemsCount,
                    dateString = dateStr
                )
            )
            // also increment loyalty points: 2 points per £1 spent
            val currentLoyalty = db.loyaltyDao().getLoyaltyProfile()
            var ptIncrement = (total * 2).toInt()
            db.loyaltyDao().insertLoyaltyProfile(
                LoyaltyProfile(
                    id = 1,
                    points = 1450 + ptIncrement, // retain previous baseline plus rewards
                    memberCode = "M-9821-4820",
                    tier = if (1450 + ptIncrement > 1800) "Gold" else "Silver",
                    gasSavingsPercent = 8,
                    activeCouponsJson = "[\"£5 Off Fresh Fruit\",\"Free Organic Eggs with Shop\",\"10% Off Bakery\"]"
                )
            )
        }
    }

    suspend fun preseedDatabase() {
        withContext(Dispatchers.IO) {
            val defaultProducts = listOf(
                ProductEntity("P-milk", "Organic Semi-Skimmed Milk", "Dairy & Eggs", 1.85, "1L", "P-milk-own", "Buy 2 Save 10%", 120, 24, "Aisle 4", "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=150"),
                ProductEntity("P-milk-own", "MarketOS Semi-Skimmed Milk", "Dairy & Eggs", 1.25, "1L", null, null, 118, 48, "Aisle 4", ""),
                
                ProductEntity("P-bread", "Luxury Sourdough Crust Loaf", "Bakery", 2.20, "400g", "P-bread-own", "Save 15% on Butter Combo", 240, 12, "Aisle 1", "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=150"),
                ProductEntity("P-bread-own", "MarketOS Soft White Loaf", "Bakery", 1.10, "800g", null, null, 220, 30, "Aisle 1", ""),
                
                ProductEntity("P-eggs", "Free Range Large British Eggs", "Dairy & Eggs", 2.65, "6 pack", "P-eggs-own", "3 for 2 on Essentials", 143, 8, "Aisle 4", ""),
                ProductEntity("P-eggs-own", "Saver Brand Barn Eggs", "Dairy & Eggs", 1.50, "6 pack", null, null, 140, 25, "Aisle 4", ""),
                
                ProductEntity("P-salmon", "Atlantic Salmon Fillets x2", "Meat, Fish & Poultry", 5.95, "240g", "P-salmon-saver", "Multibuy: £10 for 2 packs", 380, 5, "Aisle 8 (Cold)", ""),
                ProductEntity("P-salmon-saver", "Cod Fillets Econ Fish x2", "Meat, Fish & Poultry", 3.80, "240g", null, null, 290, 15, "Aisle 8 (Cold)", ""),
                
                ProductEntity("P-tomato", "Specially Selected Cherry Vine Tomatoes", "Fresh Produce", 2.45, "220g", "P-tomato-own", null, 45, 18, "Aisle 2", ""),
                ProductEntity("P-tomato-own", "Everyday Red Salad Tomatoes", "Fresh Produce", 1.10, "500g", null, null, 80, 42, "Aisle 2", ""),
                
                ProductEntity("P-cheese", "Cathedral City Mature Cheddar", "Dairy & Eggs", 4.40, "350g", "P-cheese-own", "Buy 2 Get Mature Promo", 410, 4, "Aisle 4 (Cold)", ""),
                ProductEntity("P-cheese-own", "MarketOS Mild White Cheddar", "Dairy & Eggs", 2.50, "350g", null, null, 400, 19, "Aisle 4 (Cold)", ""),
                
                ProductEntity("P-apples", "Pink Lady Apples Pack", "Fresh Produce", 2.95, "6 pack", "P-apples-own", "Buy One Get One Free", 95, 22, "Aisle 2", ""),
                ProductEntity("P-apples-own", "Everyday Crisp Red Apples", "Fresh Produce", 1.60, "1kg", null, null, 90, 50, "Aisle 2", ""),
                
                ProductEntity("P-pasta", "De Cecco Penne Rigate Pasta", "Pantry", 1.95, "500g", "P-pasta-own", "3 for £4.50 Pantry Match", 360, 44, "Aisle 6", ""),
                ProductEntity("P-pasta-own", "MarketOS Italian Penne Pasta", "Pantry", 0.75, "500g", null, null, 355, 120, "Aisle 6", ""),

                ProductEntity("P-butter", "Lurpak Spreadable Butter", "Dairy & Eggs", 3.80, "400g", "P-butter-own", null, 320, 15, "Aisle 4 (Cold)", ""),
                ProductEntity("P-butter-own", "MarketOS English Salted Butter", "Dairy & Eggs", 1.90, "250g", null, null, 310, 20, "Aisle 4 (Cold)", ""),

                ProductEntity("P-avocado", "Ready To Eat Hass Avocado", "Fresh Produce", 1.20, "Individual", null, "Price Drop: Save 20p", 160, 31, "Aisle 2", "")
            )

            db.productDao().insertProducts(defaultProducts)

            val defaultRecipes = listOf(
                RecipeEntity(
                    id = "R-carbonara",
                    title = "Classic Spaghetti Carbonara Duo",
                    description = "Creamy, golden egg yolks and salty black pepper melted over warm pasta. Beautifully satisfying, ready in under 15 minutes.",
                    prepTime = "12 min",
                    calorieCount = 650,
                    dietType = "Vegetarian Options",
                    costBudget = 4.80,
                    ingredientIds = "P-pasta-own,P-eggs-own,P-cheese-own,P-milk",
                    imageUrl = ""
                ),
                RecipeEntity(
                    id = "R-salmon",
                    title = "Crisp Pan-Seared Salmon & Vine Tomatoes",
                    description = "A refreshing protein punch. Flaky, juicy salmon fillets accompanied by warm caramelised vine tomatoes.",
                    prepTime = "18 min",
                    calorieCount = 490,
                    dietType = "High-Protein & Keto",
                    costBudget = 7.05,
                    ingredientIds = "P-salmon,P-tomato,P-avocado",
                    imageUrl = ""
                ),
                RecipeEntity(
                    id = "R-scramble",
                    title = "Savory Sourdough & Scrambled Egg Toast",
                    description = "Perfect breakfast or speedy dinner. Creamy scrambled eggs cooked with a splash of milk and served on toasted sourdough.",
                    prepTime = "8 min",
                    calorieCount = 380,
                    dietType = "Vegetarian",
                    costBudget = 3.65,
                    ingredientIds = "P-bread,P-eggs,P-milk,P-cheese",
                    imageUrl = ""
                )
            )
            db.recipeDao().insertRecipes(defaultRecipes)

            // preseed loyalty profile
            db.loyaltyDao().insertLoyaltyProfile(
                LoyaltyProfile(
                    id = 1,
                    points = 1450,
                    memberCode = "M-9821-4820",
                    tier = "Silver",
                    gasSavingsPercent = 8,
                    activeCouponsJson = "[\"£5 Off Fresh Fruit\",\"Free Organic Eggs with Shop\",\"10% Off Bakery\"]"
                )
            )

            // preseed dynamic receipts for dashboard analytics (Inflation tracking!)
            val formatter = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            val calendar = Calendar.getInstance()
            
            // Receipt 1 (April)
            calendar.add(Calendar.DAY_OF_YEAR, -24)
            db.receiptDao().insertReceipt(
                DigitalReceiptEntity(
                    timestamp = calendar.timeInMillis,
                    totalSpent = 74.20,
                    totalSaved = 8.50,
                    categoryBreakdownJson = "{\"Dairy & Eggs\":24.50,\"Fresh Produce\":18.70,\"Bakery\":11.00,\"Meat, Fish & Poultry\":15.00,\"Pantry\":5.00}",
                    itemsCount = 15,
                    dateString = formatter.format(calendar.time)
                )
            )

            // Receipt 2 (May early)
            calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + 12)
            db.receiptDao().insertReceipt(
                DigitalReceiptEntity(
                    timestamp = calendar.timeInMillis,
                    totalSpent = 62.40,
                    totalSaved = 11.20,
                    categoryBreakdownJson = "{\"Dairy & Eggs\":18.00,\"Fresh Produce\":15.40,\"Meat, Fish & Poultry\":23.00,\"Bakery\":6.00}",
                    itemsCount = 11,
                    dateString = formatter.format(calendar.time)
                )
            )

            // Receipt 3 (Recent)
            calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + 8)
            db.receiptDao().insertReceipt(
                DigitalReceiptEntity(
                    timestamp = calendar.timeInMillis,
                    totalSpent = 88.60,
                    totalSaved = 14.80,
                    categoryBreakdownJson = "{\"Dairy & Eggs\":32.10,\"Fresh Produce\":22.50,\"Meat, Fish & Poultry\":20.00,\"Bakery\":10.00,\"Pantry\":4.00}",
                    itemsCount = 20,
                    dateString = formatter.format(calendar.time)
                )
            )
        }
    }
}
