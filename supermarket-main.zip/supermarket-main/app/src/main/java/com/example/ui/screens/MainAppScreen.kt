package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.database.BasketItemEntity
import com.example.data.database.ProductEntity
import com.example.data.database.RecipeEntity
import com.example.viewmodel.DeliverySystemState
import com.example.viewmodel.MarketViewModel
import com.example.viewmodel.SwapProposal
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val viewModel: MarketViewModel = viewModel()
    var currentTab by remember { mutableStateOf("shop") }

    val basketItems by viewModel.basket.collectAsState()
    val totalItems = basketItems.sumOf { it.quantity }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "MarketOS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Supermarket Logistics Platform",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { currentTab = "basket" },
                        modifier = Modifier.testTag("nav_cart_icon")
                    ) {
                        BadgedBox(
                            badge = {
                                if (totalItems > 0) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primary) { 
                                        Text(text = "$totalItems") 
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Shopping Basket"
                            )
                        }
                    }
                    IconButton(
                        onClick = { currentTab = "instore" },
                        modifier = Modifier.testTag("nav_scan_ic")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "In-store Mode"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.testTag("top_bar_app")
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 0.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                listOf(
                    Triple("shop", "Shop", Icons.Outlined.Storefront),
                    Triple("basket", "Basket", Icons.Outlined.ShoppingBag),
                    Triple("logistics", "Logistics", Icons.Outlined.LocalShipping),
                    Triple("loyalty", "Loyalty", Icons.Outlined.CardMembership),
                    Triple("assistant", "AI Agent", Icons.Outlined.Psychology)
                ).forEach { (tag, label, icon) ->
                    val isSelected = currentTab == tag
                    NavigationBarItem(
                        selected = isSelected,
                        label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                        icon = { Icon(icon, contentDescription = label) },
                        onClick = { currentTab = tag },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$tag")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { tab ->
                when (tab) {
                    "shop" -> ShopTab(viewModel, onNavigateToRecipes = { currentTab = "assistant" })
                    "basket" -> BasketTab(viewModel, onNavigateToLogistics = { currentTab = "logistics" })
                    "logistics" -> LogisticsTab(viewModel)
                    "loyalty" -> LoyaltyTab(viewModel)
                    "assistant" -> AssistantTab(viewModel)
                    "instore" -> InStoreScannerTab(viewModel)
                }
            }
        }
    }
}

@Composable
fun ShopTab(viewModel: MarketViewModel, onNavigateToRecipes: () -> Unit) {
    val products by viewModel.filteredProducts.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val activeCat by viewModel.selectedCategory.collectAsState()
    val focusManager = LocalFocusManager.current

    val categories = listOf("All", "Dairy & Eggs", "Fresh Produce", "Bakery", "Meat, Fish & Poultry", "Pantry")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("shop_tab_scroll")
    ) {
        // Search & Greeting
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Good day, tom@ahyx.org",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Prices optimized live at London King's Cross Superstore",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = query,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shop_search_field"),
                        placeholder = { Text("Search 10,000+ optimized products...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = MaterialTheme.colorScheme.background,
                            focusedContainerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }
            }
        }

        // Fast "Buy Again" carousel
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = "📦 BUY AGAIN STAPLES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // preseed favorites represent quick clicks
                    val favorites = listOf(
                        Pair("Organic Milk", "P-milk"),
                        Pair("Sourdough Bread", "P-bread"),
                        Pair("Eggs 6 Pack", "P-eggs"),
                        Pair("Avocado", "P-avocado")
                    )
                    items(favorites) { fav ->
                        SuggestionChip(
                            onClick = {
                                viewModel.addToBasketById(fav.second, 1)
                            },
                            label = { Text(fav.first) },
                            icon = { Icon(Icons.Default.Replay, contentDescription = "Buy Again", modifier = Modifier.size(14.dp)) },
                            modifier = Modifier.testTag("buy_again_chip_${fav.second}")
                        )
                    }
                }
            }
        }

        // Category scroll chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = cat == activeCat
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setCategory(cat) },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("cat_chip_$cat")
                    )
                }
            }
        }

        // Grocery catalog grids
        item {
            if (products.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No optimized products match standard criteria.")
                }
            } else {
                Text(
                    text = "🏪 RETAIL CATALOG",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                Column(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .fillMaxWidth()
                ) {
                    // Compose Column mimicking grid with 2 items per row
                    products.chunked(2).forEach { rowProducts ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowProducts.forEach { prod ->
                                Box(modifier = Modifier.weight(1f)) {
                                    ProductCard(product = prod, onAdd = { viewModel.addToBasket(prod, 1) })
                                }
                            }
                            if (rowProducts.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }

        // Direct Quick Recipes Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { onNavigateToRecipes() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "💡 OPTIMIZED WEEKLY MEAL PLANS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Instant 1-click recipe bundle purchase. Tap to let AI design your zero-waste meal kits.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "Go to AI Helper",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ProductCard(product: ProductEntity, onAdd: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.18f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Price & Badges top row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "£${String.format(Locale.UK, "%.2f", product.price)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = product.unit,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.height(38.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Info (Aisle position & Stock alerts)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = product.aisle,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )

                if (product.stockLevel < 10) {
                    Box(
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Low Stock (${product.stockLevel})",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                } else {
                    Text(
                        text = "In Stock",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (product.promoMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = product.promoMessage,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = onAdd,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .testTag("add_button_${product.id}"),
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add symbol", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BasketTab(viewModel: MarketViewModel, onNavigateToLogistics: () -> Unit) {
    val basketItems by viewModel.basket.collectAsState()
    val totalAmt by viewModel.totalBasketPrice.collectAsState()
    val pointsSaved by viewModel.loyalPointsSaved.collectAsState()
    val swapProposals by viewModel.ownBrandSuggestions.collectAsState()
    val chosenSlot by viewModel.selectedDeliverySlot.collectAsState()

    val totalToPay = totalAmt + (chosenSlot?.fee ?: 0.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("basket_scroll_column")
    ) {
        item {
            Text(
                text = "🛒 INTEL BASKET FEED",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (basketItems.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Empty basket",
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your basket is currently empty.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Go check the Shop catalog to add fresh ingredients.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            // Basket checkout list
            items(basketItems) { item ->
                BasketItemRow(item, onQtyChange = { qty -> viewModel.updateBasketQty(item, qty) })
                Spacer(modifier = Modifier.height(8.dp))
            }

            // PRICE OPTIMIZATION CARDS (Own-brand switches)
            if (swapProposals.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "💷 PRICE OPTIMISATION SUITE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(swapProposals) { proposal ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.24f)),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("swap_card_${proposal.originalItem.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PriceCheck,
                                    contentDescription = "Optimisation Check",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Switch to Own-Brand and Save £${String.format(Locale.UK, "%.2f", proposal.savingGained * proposal.originalItem.quantity)}!",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = "Replace '${proposal.originalItem.name}' count (${proposal.originalItem.quantity}) with high-quality '${proposal.alternativeName}'",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.82f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.replaceWithOwnBrand(proposal) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .height(36.dp)
                                    .testTag("execute_swap_${proposal.originalItem.id}"),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
                            ) {
                                Text("Instantly Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // DELIVERY & COLLETION SYSTEM SLOT
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "📦 DELIVERY & CLICK-AND-COLLECT SLOTS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                viewModel.deliverySlots.forEach { slot ->
                    val isChecked = slot.id == chosenSlot?.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { viewModel.selectDeliverySlot(slot) }
                            .testTag("slot_card_${slot.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isChecked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isChecked) CardDefaults.outlinedCardBorder() else null
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = isChecked,
                                    onClick = { viewModel.selectDeliverySlot(slot) },
                                    modifier = Modifier.testTag("radio_${slot.id}")
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Column {
                                    Text(
                                        text = slot.displayTime,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = slot.note,
                                        fontSize = 11.sp,
                                        color = if (isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Text(
                                text = if (slot.fee == 0.0) "FREE" else "£${String.format(Locale.UK, "%.2f", slot.fee)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = if (isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // STORE FINDER LIST
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = "Store Finder", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Nearest Fulfillment Centre", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                val store by viewModel.selectedStore.collectAsState()
                                Text("${store.name} (${store.distance})", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // ORDER SUMMARY
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("summary_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "RECEIPT SUMMARY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Basket Subtotal", fontSize = 13.sp)
                            Text("£${String.format(Locale.UK, "%.2f", totalAmt)}", fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Loyalty Promos & Club Matches", fontSize = 13.sp, color = Color(0xFF007A3E))
                            Text("-£${String.format(Locale.UK, "%.2f", pointsSaved)}", fontSize = 13.sp, color = Color(0xFF007A3E))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Fulfillment Routing Fee", fontSize = 13.sp)
                            Text("£${String.format(Locale.UK, "%.2f", chosenSlot?.fee ?: 0.0)}", fontSize = 13.sp)
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Estimated Total", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                text = "£${String.format(Locale.UK, "%.2f", totalToPay - pointsSaved)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.checkoutCurrentBasket()
                                onNavigateToLogistics()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("checkout_commit_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = "Pay")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Place Order & Track Logistics (Mock Wallet)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BasketItemRow(item: BasketItemEntity, onQtyChange: (Int) -> Unit) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "£${String.format(Locale.UK, "%.2f", item.price)} / ${item.unit}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onQtyChange(item.quantity - 1) }) {
                    Icon(
                        imageVector = Icons.Default.RemoveCircleOutline,
                        contentDescription = "Reduce qty",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = "${item.quantity}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                IconButton(onClick = { onQtyChange(item.quantity + 1) }) {
                    Icon(
                        imageVector = Icons.Default.AddCircleOutline,
                        contentDescription = "Increase qty",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "£${String.format(Locale.UK, "%.2f", item.price * item.quantity)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun LogisticsTab(viewModel: MarketViewModel) {
    val deliveryState by viewModel.deliveryState.collectAsState()
    val lat by viewModel.driverLatitude.collectAsState()
    val lon by viewModel.driverLongitude.collectAsState()
    val eta by viewModel.etaMinutes.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("logistics_tab_view")
    ) {
        item {
            Text(
                text = "🚚 REAL-TIME LOGISTICS TRACKING",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Warehouse-to-Home Routing Engine",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Logistics flow progress steps
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LogisticsStep("Dispatched", active = deliveryState != DeliverySystemState.NOT_ORDERED)
                        Divider(modifier = Modifier.weight(1f).padding(horizontal = 4.dp), color = if (deliveryState != DeliverySystemState.NOT_ORDERED) MaterialTheme.colorScheme.primary else Color.LightGray)
                        LogisticsStep("En-Route", active = deliveryState == DeliverySystemState.EN_ROUTE || deliveryState == DeliverySystemState.DELIVERED)
                        Divider(modifier = Modifier.weight(1f).padding(horizontal = 4.dp), color = if (deliveryState == DeliverySystemState.DELIVERED) MaterialTheme.colorScheme.primary else Color.LightGray)
                        LogisticsStep("Delivered", active = deliveryState == DeliverySystemState.DELIVERED)
                    }
                }
            }
        }

        if (deliveryState == DeliverySystemState.NOT_ORDERED) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassEmpty,
                            contentDescription = "No order",
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No active deliveries scheduled.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Checkout your smart basket to dispatch immediate courier routing.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            // Live Driver Tracking Map Card
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (deliveryState == DeliverySystemState.DELIVERED) "ORDER DELIVERED!" else "OUT FOR DELIVERY",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(text = "Driver: Liam Smith · EV Courier Van", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (deliveryState != DeliverySystemState.DELIVERED) {
                                Box(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "ETA: $eta min",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // INTERACTIVE MAP CANVAS DRAWING
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFE8F1FC))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize().testTag("logistics_interactive_map")) {
                                val canvasWidth = size.width
                                val canvasHeight = size.height

                                // Draw London Street lines
                                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                
                                // Euston Road
                                drawLine(
                                    color = Color.White,
                                    start = Offset(0f, canvasHeight * 0.3f),
                                    end = Offset(canvasWidth, canvasHeight * 0.3f),
                                    strokeWidth = 14.sp.toPx(),
                                )
                                // York Way Grid
                                drawLine(
                                    color = Color.White,
                                    start = Offset(canvasWidth * 0.4f, 0f),
                                    end = Offset(canvasWidth * 0.4f, canvasHeight),
                                    strokeWidth = 12.sp.toPx()
                                )
                                // Penton Road diagonal
                                drawLine(
                                    color = Color.White,
                                    start = Offset(canvasWidth * 0.1f, canvasHeight * 0.9f),
                                    end = Offset(canvasWidth * 0.9f, canvasHeight * 0.1f),
                                    strokeWidth = 10.sp.toPx()
                                )

                                // Draw Warehousing Hub at coordinate (0.2, 0.8)
                                drawCircle(
                                    color = Color(0xFF006C47),
                                    radius = 16f,
                                    center = Offset(canvasWidth * 0.2f, canvasHeight * 0.8f)
                                )
                                // Label it
                                // (We can let user visualize via graphics)

                                // Draw Customer Address at coordinate (0.5, 0.4)
                                drawCircle(
                                    color = Color(0xFFBA1A1A),
                                    radius = 16f,
                                    center = Offset(canvasWidth * 0.5f, canvasHeight * 0.4f)
                                )

                                // Draw live driver tracking dot based on current animated coords
                                val driverX = canvasWidth * lat
                                val driverY = canvasHeight * lon

                                drawCircle(
                                    color = Color(0xFFE67E22),
                                    radius = 24f,
                                    center = Offset(driverX, driverY)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 10f,
                                    center = Offset(driverX, driverY)
                                )
                            }
                            
                            // Map Overlay Info
                            Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                                Text(
                                    text = "Hub - King's Cross Store",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier
                                        .background(Color(0xFF006C47), shape = RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                        .offset(x = 10.dp, y = 160.dp)
                                )

                                Text(
                                    text = "Delivery Point (Home)",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier
                                        .background(Color(0xFFBA1A1A), shape = RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                        .align(Alignment.Center)
                                        .offset(y = (-30).dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Live GPS updates every 3s. Delivery vehicle is fully electric to offset 420g of carbon dioxide emissions.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LogisticsStep(title: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(
                    if (active) MaterialTheme.colorScheme.primary else Color.LightGray,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Completed step",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun LoyaltyTab(viewModel: MarketViewModel) {
    val loyaltyProfile by viewModel.loyalty.collectAsState()
    val receiptsList by viewModel.receipts.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("loyalty_tab_view")
    ) {
        item {
            Text(
                text = "⭐ LOYALTY CLUB & PORTFOLIO",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // LOYALTY CARD DETAILS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("loyalty_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "MarketOS Clubcard",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(text = "Tier: ${loyaltyProfile?.tier ?: "Silver"}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = "Loyalty points star",
                            tint = Color(0xFFFFD54F),
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(text = "Member ID: ${loyaltyProfile?.memberCode ?: "M-9821-4820"}", color = Color.White, fontSize = 12.sp)
                            Text(text = "Fuel Perks: ${loyaltyProfile?.gasSavingsPercent ?: 8}% Off Partners", color = Color.White, fontSize = 11.sp)
                        }

                        // Points count
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "BALANCE POINTS", fontSize = 9.sp, color = Color.White.copy(alpha = 0.7f))
                            Text(
                                text = "${loyaltyProfile?.points ?: 1450} pts",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp
                            )
                        }
                    }
                }
            }
        }

        // PERSONALISED COUPONS
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "🎁 ACTIVE HOUSEHOLD COUPONS",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Dynamic Coupons list
            listOf(
                Triple("£5 Off Fresh Fruit", "Applies to salad & berries", "Claimed"),
                Triple("Free Organic Eggs", "With grocery spend above £25", "Claimed"),
                Triple("10% Off Premium Bakery Rows", "Organic sourdough inclusion", "Claim")
            ).forEach { (title, subtitle, status) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = { /* Claimed action */ },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (status == "Claimed") Color(0xFFECEFF1) else MaterialTheme.colorScheme.primary
                            ),
                            enabled = status != "Claimed",
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(
                                text = status,
                                fontSize = 11.sp,
                                color = if (status == "Claimed") Color.Gray else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // HOUSEHOLD CONSUMPTION ANALYTICS & SPENDING
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "📊 HOUSEHOLD SPEND & CONSUMPTION TRENDS",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Spend Breakdown by Shelf Category",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val analytics = viewModel.getCategoryTrendAnalytics()
                    analytics.forEach { (cat, spend) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                modifier = Modifier.width(110.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            
                            // Visual percentage bar on raw canvas
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(Color(0xFFE8F1FC))
                            ) {
                                val proportion = (spend / 150.0).coerceIn(0.1, 1.0).toFloat()
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(proportion)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "£${String.format(Locale.UK, "%.2f", spend)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    // CONSUMPTION INSIGHTS
                    Text(
                        text = "🧠 Operational Observations & Food-waste Insights",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    listOf(
                        "🥛 Standard Milk purchase frequency: Lasts 6.2 days on average.",
                        "🍉 Salad & berry over-purchasing index: 14% waste footprint detected.",
                        "📈 Basket inflation forecast: +3.4% rise vs corresponding last year trimester."
                    ).forEach { insight ->
                        Text(
                            text = insight,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 2.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // HISTORICAL DIGITAL RECEIPTS LIST
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "🧾 DIGITAL RECEIPT FEED",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        if (receiptsList.isEmpty()) {
            item {
                Text("No past checkout invoices recorded in this database.", fontSize = 12.sp)
            }
        } else {
            items(receiptsList) { receipt ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Shop completed on ${receipt.dateString}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "${receipt.itemsCount} total products purchased", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "£${String.format(Locale.UK, "%.2f", receipt.totalSpent)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                            if (receipt.totalSaved > 0) {
                                Text(
                                    text = "Saved £${String.format(Locale.UK, "%.2f", receipt.totalSaved)}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF007A3E),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AssistantTab(viewModel: MarketViewModel) {
    val messages by viewModel.aiMessages.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val recipesList by viewModel.recipes.collectAsState()

    var inputPrompt by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("ai_assistant_view")
    ) {
        Text(
            text = "🧠 COGNITIVE SHOPPING COMPANION",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // CHAT MESSAGE STREAM
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Include automated quick meal plans chips
            item {
                Text("Quick Actions:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendAiPrompt("Compile high-protein budget shopping list and zero-waste routine") },
                            label = { Text("High-protein list") }
                        )
                    }
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendAiPrompt("Design a £45 weekly meal plan for 2 people switching to premium-to-budget alternatives") },
                            label = { Text("£45 Weekly plan") }
                        )
                    }
                    item {
                        SuggestionChip(
                            onClick = { viewModel.sendAiPrompt("Suggest meal combos to reduce yogurt and sourdough bread waste") },
                            label = { Text("Food-waste helper") }
                        )
                    }
                }
            }

            // Recipe 1-Click Buy List
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "🍲 1-CLICK MEAL BUNDLES (AUTO ADD TO BASKET)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            items(recipesList) { recipe ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = recipe.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(text = recipe.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        
                        Divider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${recipe.dietType} · Cook: ${recipe.prepTime} · Approx: £${String.format(Locale.UK, "%.2f", recipe.costBudget)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Button(
                                onClick = { viewModel.addRecipeIngredientsToBasket(recipe) },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(26.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Text("Auto-Buy Kit", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "💬 AI BUDGET CONVERSATION",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            items(messages) { msg ->
                val isUser = msg.sender == "user"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(
                            topStart = 12.dp,
                            topEnd = 12.dp,
                            bottomStart = if (isUser) 12.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 12.dp
                        ),
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isUser) "You" else "Gemini Nutritionist",
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = msg.content,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // CHAT PROMPT FIELD
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_text_field"),
                placeholder = { Text("Ask about recipes or budget plans...") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputPrompt.isNotBlank()) {
                        viewModel.sendAiPrompt(inputPrompt)
                        inputPrompt = ""
                        focusManager.clearFocus()
                    }
                }),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            FloatingActionButton(
                onClick = {
                    if (inputPrompt.isNotBlank()) {
                        viewModel.sendAiPrompt(inputPrompt)
                        inputPrompt = ""
                        focusManager.clearFocus()
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("ai_send_fab"),
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun InStoreScannerTab(viewModel: MarketViewModel) {
    val scannedProduct by viewModel.scannedProduct.collectAsState()
    val allProducts by viewModel.products.collectAsState(initial = emptyList())

    var activeViewfinder by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("instore_scanner_view")
    ) {
        Text(
            text = "🏪 IN-STORE COMPANION CORE",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Mock camera viewfinder
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(if (scannedProduct == null) 1.2f else 0.8f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Camera viewport active",
                    tint = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Align Barcode in the Guideline Frame",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 11.sp
                )
            }

            // Green crosshairs/scanner guides
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2
                val cy = size.height / 2
                val borderSize = 130.dp.toPx()

                // Draw bounding box
                drawRect(
                    color = Color(0xFF00FF88),
                    topLeft = Offset(cx - borderSize, cy - borderSize / 1.5f),
                    size = androidx.compose.ui.geometry.Size(borderSize * 2, borderSize * 1.3f),
                    style = Stroke(width = 3.dp.toPx())
                )

                // Laser scan line animating coordinates horizontally or vertically
                drawLine(
                    color = Color(0xFFFF3D00),
                    start = Offset(cx - borderSize, cy),
                    end = Offset(cx + borderSize, cy),
                    strokeWidth = 2.dp.toPx()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // DROPDOWN PRODUCT SELECTOR TO SIMULATE PHYSICAL SCANNING
        Text(
            text = "Select item to mock physical product barcode scan:",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(4.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(allProducts.filter { !it.id.endsWith("-own") && !it.id.endsWith("-saver") }) { p ->
                SuggestionChip(
                    onClick = { viewModel.scanMockBarcode(p.id) },
                    label = { Text("Scan ${p.name}") },
                    modifier = Modifier.testTag("scan_trigger_${p.id}")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SCAN RESULTS DIALOG CARD
        AnimatedVisibility(
            visible = scannedProduct != null,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut()
        ) {
            scannedProduct?.let { prod ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("scan_response_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "BARCODE MATCH DETECTED",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = { viewModel.clearScannedProduct() }) {
                                Icon(Icons.Default.Close, contentDescription = "Close Scanner view")
                            }
                        }

                        Text(
                            text = prod.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Standard retail cost: £${String.format(Locale.UK, "%.2f", prod.price)} / ${prod.unit}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "📌 SHELF POSITION",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(text = prod.aisle, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text(
                                    text = "📦 SHELF STOCK",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(text = "${prod.stockLevel} units remaining", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            OutlinedButton(
                                onClick = { viewModel.clearScannedProduct() },
                                modifier = Modifier.height(36.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Dismiss", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    viewModel.addToBasket(prod, 1)
                                    viewModel.clearScannedProduct()
                                },
                                modifier = Modifier.height(36.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.AddShoppingCart, contentDescription = "Add", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add To In-Store Basket", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
