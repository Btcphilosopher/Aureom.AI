package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val price: Double,
    val unit: String,
    val ownBrandEquivalentId: String?, // Switch to own brand recommendation
    val promoMessage: String?,      // Multibuy active promo
    val calories: Int,
    val stockLevel: Int,
    val aisle: String,
    val imageUrl: String
)

@Entity(tableName = "basket_items")
data class BasketItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val price: Double,
    val quantity: Int,
    val category: String,
    val unit: String,
    val promoMessage: String?,
    val ownBrandEquivalentId: String? = null
)

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val prepTime: String,
    val calorieCount: Int,
    val dietType: String, // Vegan, Vegetarian, Gluten-Free, High-Protein, Keto
    val costBudget: Double,
    val ingredientIds: String, // Comma-separated list of product IDs: "P-milk,P-egg"
    val imageUrl: String
)

@Entity(tableName = "digital_receipts")
data class DigitalReceiptEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val totalSpent: Double,
    val totalSaved: Double,
    var categoryBreakdownJson: String, // JSON matching category to spend and inflation trends
    var itemsCount: Int,
    val dateString: String
)

@Entity(tableName = "loyalty_profile")
data class LoyaltyProfile(
    @PrimaryKey val id: Int = 1,
    val points: Int,
    val memberCode: String,
    val tier: String, // Silver, Gold, Platinum
    val gasSavingsPercent: Int,
    val activeCouponsJson: String // List represented in JSON
)
