package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.BasketItemEntity
import com.example.data.database.DigitalReceiptEntity
import com.example.data.database.ProductEntity
import com.example.data.database.RecipeEntity
import com.example.data.database.LoyaltyProfile
import com.example.data.repository.MarketRepository
import com.example.data.api.GeminiClient
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.util.Locale

class MarketViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = MarketRepository(db)

    // Catalog state
    val products = repository.allFullProducts
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    val filteredProducts = combine(products, searchQuery, selectedCategory) { prodList, query, cat ->
        var list = prodList
        if (cat != "All") {
            list = list.filter { it.category == cat }
        }
        if (query.isNotBlank()) {
            val q = query.lowercase()
            list = list.filter { it.name.lowercase().contains(q) || it.category.lowercase().contains(q) }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Basket & Optimisation Engine
    val basket = repository.basketItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalBasketPrice = basket.map { list ->
        list.sumOf { it.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val loyalPointsSaved = basket.map { list ->
        // simulate standard loyalty promotional deductions
        list.size * 0.45 
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Swapping optimization suggestions
    val ownBrandSuggestions = basket.map { items ->
        val suggestions = mutableListOf<Pair<BasketItemEntity, ProductEntity>>()
        items.forEach { basketItem ->
            if (basketItem.ownBrandEquivalentId != null) {
                // look up alternative in full product list
                viewModelScope.launch {
                    val alternative = db.productDao().getProductById(basketItem.ownBrandEquivalentId)
                    if (alternative != null) {
                        suggestions.add(Pair(basketItem, alternative))
                    }
                }
            }
        }
        // Let's populate dynamically from our pre-seeded rules to ensure rapid sync
        val list = mutableListOf<SwapProposal>()
        items.forEach { basketItem ->
            when (basketItem.id) {
                "P-milk" -> list.add(SwapProposal(basketItem, "P-milk-own", "MarketOS Semi-Skimmed Milk", 1.25, 0.60))
                "P-bread" -> list.add(SwapProposal(basketItem, "P-bread-own", "MarketOS Soft White Loaf", 1.10, 1.10))
                "P-eggs" -> list.add(SwapProposal(basketItem, "P-eggs-own", "Saver Brand Barn Eggs", 1.50, 1.15))
                "P-salmon" -> list.add(SwapProposal(basketItem, "P-salmon-saver", "Cod Fillets Econ Fish x2", 3.80, 2.15))
                "P-tomato" -> list.add(SwapProposal(basketItem, "P-tomato-own", "Everyday Red Salad Tomatoes", 1.10, 1.35))
                "P-cheese" -> list.add(SwapProposal(basketItem, "P-cheese-own", "MarketOS Mild White Cheddar", 2.50, 1.90))
                "P-apples" -> list.add(SwapProposal(basketItem, "P-apples-own", "Everyday Crisp Red Apples", 1.60, 1.35))
                "P-pasta" -> list.add(SwapProposal(basketItem, "P-pasta-own", "MarketOS Italian Penne Pasta", 0.75, 1.20))
                "P-butter" -> list.add(SwapProposal(basketItem, "P-butter-own", "MarketOS English Salted Butter", 1.90, 1.90))
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Delivery settings
    private val _selectedDeliverySlot = MutableStateFlow<DeliverySlot?>(null)
    val selectedDeliverySlot = _selectedDeliverySlot.asStateFlow()

    val deliverySlots = listOf(
        DeliverySlot("Slot A", "Today, 14:00 - 16:00", 5.50, "Peak Hour"),
        DeliverySlot("Slot B", "Today, 19:30 - 21:30", 3.00, "Normal Hour"),
        DeliverySlot("Slot C", "Tomorrow, 08:30 - 10:30", 1.50, "Off-Peak"),
        DeliverySlot("Slot D", "Tomorrow, 14:00 - 16:00", 2.00, "Green Eco-friendly Slot")
    )

    // Store Picker
    private val _selectedStore = MutableStateFlow(StoreLocation("King's Cross Superstore", "0.4 miles away", "Euston Rd, N1 9AL", "Fully Stocked"))
    val selectedStore = _selectedStore.asStateFlow()

    val nearStores = listOf(
        StoreLocation("King's Cross Superstore", "0.4 miles away", "Euston Rd, London N1 9AL", "Fully Stocked - High Service"),
        StoreLocation("Camden High Street Local", "1.2 miles away", "Camden High St, London NW1 0JH", "Medium Stocked - Fresh Only"),
        StoreLocation("Islington Retail Park", "2.1 miles away", "Parkfield St, London N1 0PS", "Fully Stocked - Fuel Station available")
    )

    // Logistics Live Tracker
    private val _deliveryState = MutableStateFlow(DeliverySystemState.NOT_ORDERED)
    val deliveryState = _deliveryState.asStateFlow()

    private val _driverLatitude = MutableStateFlow(0.2f)
    val driverLatitude = _driverLatitude.asStateFlow()

    private val _driverLongitude = MutableStateFlow(0.8f)
    val driverLongitude = _driverLongitude.asStateFlow()

    private val _etaMinutes = MutableStateFlow(15)
    val etaMinutes = _etaMinutes.asStateFlow()

    // Recipes
    val recipes = repository.allRecipes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Historical receipts & analytics
    val receipts = repository.receipts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val loyalty = repository.loyaltyProfile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // AI Chat Shopping Assistant state
    private val _aiMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("assistant", "Hello! I am your MarketOS Personal Shopping Assistant. I can generate optimized meal budgets, suggest waste reduction habits, or compile high-protein plans. Try asking below!")
    ))
    val aiMessages = _aiMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading = _isAiLoading.asStateFlow()

    // Barcode scanner mock state
    private val _scannedProduct = MutableStateFlow<ProductEntity?>(null)
    val scannedProduct = _scannedProduct.asStateFlow()

    init {
        // Pre-populate Database and verify product setups
        viewModelScope.launch {
            repository.preseedDatabase()
        }
        // Set default delivery slot
        _selectedDeliverySlot.value = deliverySlots[2]
    }

    fun setStore(store: StoreLocation) {
        _selectedStore.value = store
    }

    fun selectDeliverySlot(slot: DeliverySlot) {
        _selectedDeliverySlot.value = slot
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addToBasket(product: ProductEntity, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToBasket(product, quantity)
        }
    }

    fun addToBasketById(id: String, quantity: Int = 1) {
        viewModelScope.launch {
            val product = db.productDao().getProductById(id)
            if (product != null) {
                repository.addToBasket(product, quantity)
            }
        }
    }

    fun updateBasketQty(item: BasketItemEntity, newQty: Int) {
        viewModelScope.launch {
            repository.updateBasketQty(
                item.id, item.name, item.price, newQty, item.category, item.unit, item.promoMessage, item.ownBrandEquivalentId
            )
        }
    }

    fun replaceWithOwnBrand(proposal: SwapProposal) {
        viewModelScope.launch {
            // Remove the premium name
            repository.deleteBasketItem(proposal.originalItem.id)
            // Add budget substitute
            val alternative = db.productDao().getProductById(proposal.alternativeId)
            if (alternative != null) {
                repository.addToBasket(alternative, proposal.originalItem.quantity)
            } else {
                // Back-up in case product is not directly fetched
                db.basketDao().insertBasketItem(
                    BasketItemEntity(
                        id = proposal.alternativeId,
                        name = proposal.alternativeName,
                        price = proposal.alternativePrice,
                        quantity = proposal.originalItem.quantity,
                        category = proposal.originalItem.category,
                        unit = proposal.originalItem.unit,
                        promoMessage = null,
                        ownBrandEquivalentId = null
                    )
                )
            }
        }
    }

    fun clearBasket() {
        viewModelScope.launch {
            repository.clearBasket()
        }
    }

    // Checkout payment logic
    fun checkoutCurrentBasket() {
        viewModelScope.launch {
            val items = basket.value
            if (items.isEmpty()) return@launch

            val totalAmount = totalBasketPrice.value + (selectedDeliverySlot.value?.fee ?: 0.0)
            val savedAmount = loyalPointsSaved.value + ownBrandSuggestions.value.sumOf { it.savingGained * it.originalItem.quantity }

            // compile categories
            val breakdown = mutableMapOf<String, Double>()
            items.forEach {
                breakdown[it.category] = (breakdown[it.category] ?: 0.0) + (it.price * it.quantity)
            }
            val totalItems = items.sumOf { it.quantity }

            // clear basket
            repository.clearBasket()

            // record local receipt
            repository.recordReceipt(totalAmount, savedAmount, breakdown, totalItems)

            // switch delivery flow to DISPATCHED
            _deliveryState.value = DeliverySystemState.DISPATCHED
            _etaMinutes.value = 15
            simulateLiveDeliveryDriver()
        }
    }

    // Interactive Driver Simulator
    private fun simulateLiveDeliveryDriver() {
        viewModelScope.launch {
            delay(4000)
            _deliveryState.value = DeliverySystemState.EN_ROUTE
            _driverLatitude.value = 0.2f
            _driverLongitude.value = 0.8f

            // Animate driving from (0.2, 0.8) down and left to customer at (0.5, 0.4)
            for (step in 1..20) {
                delay(3000)
                _driverLatitude.value = 0.2f + (0.3f * step / 20.0f)
                _driverLongitude.value = 0.8f - (0.4f * step / 20.0f)
                val newEta = 15 - (15 * step / 20)
                _etaMinutes.value = if (newEta < 1) 1 else newEta
            }

            _deliveryState.value = DeliverySystemState.DELIVERED
            _etaMinutes.value = 0
        }
    }

    fun scanMockBarcode(scannedId: String) {
        viewModelScope.launch {
            val prod = db.productDao().getProductById(scannedId)
            _scannedProduct.value = prod
        }
    }

    fun clearScannedProduct() {
        _scannedProduct.value = null
    }

    // Recipe auto addition
    fun addRecipeIngredientsToBasket(recipe: RecipeEntity) {
        viewModelScope.launch {
            val ids = recipe.ingredientIds.split(",")
            ids.forEach { pid ->
                val prod = db.productDao().getProductById(pid.trim())
                if (prod != null) {
                    repository.addToBasket(prod, 1)
                }
            }
        }
    }

    // AI Query
    fun sendAiPrompt(prompt: String) {
        if (prompt.isBlank()) return
        val userItem = ChatMessage("user", prompt)
        _aiMessages.value = _aiMessages.value + userItem

        viewModelScope.launch {
            _isAiLoading.value = true
            val response = GeminiClient.askGemini(
                "You are the Supermarket Intelligence Assistant for MarketOS retail app. The user is asking: '$prompt'. Encourage budget brands and list products by price. Keep the guidance practical and focused. Maximum 200 words."
            )
            _isAiLoading.value = false
            _aiMessages.value = _aiMessages.value + ChatMessage("assistant", response)
        }
    }

    // Helper to calculate category spend analytics for trends
    fun getCategoryTrendAnalytics(): Map<String, Double> {
        val list = receipts.value
        val res = mutableMapOf<String, Double>()
        list.forEach { receipt ->
            try {
                val json = JSONObject(receipt.categoryBreakdownJson)
                json.keys().forEach { cat ->
                    val amt = json.getDouble(cat)
                    res[cat] = (res[cat] ?: 0.0) + amt
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        if (res.isEmpty()) {
            return mapOf("Dairy & Eggs" to 74.60, "Fresh Produce" to 56.60, "Bakery" to 27.00, "Meat, Fish & Poultry" to 58.00)
        }
        return res
    }
}

// Data models
data class SwapProposal(
    val originalItem: BasketItemEntity,
    val alternativeId: String,
    val alternativeName: String,
    val alternativePrice: Double,
    val savingGained: Double
)

data class DeliverySlot(
    val id: String,
    val displayTime: String,
    val fee: Double,
    val note: String
)

data class StoreLocation(
    val name: String,
    val distance: String,
    val address: String,
    val stockAvailability: String
)

data class ChatMessage(
    val sender: String, // "user" or "assistant"
    val content: String
)

enum class DeliverySystemState {
    NOT_ORDERED,
    DISPATCHED,
    EN_ROUTE,
    DELIVERED
}
