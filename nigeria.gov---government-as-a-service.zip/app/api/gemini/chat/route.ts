import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { prompt, language = "English", history = [] } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ 
        text: `[System Note: Fallback Mode - No API key detected]\n\nBased on official Federal Republic of Nigeria service guidelines:\n\n1. **Service**: CAC Business Registration / Tax Registration\n2. **Responsible Agency**: Corporate Affairs Commission (CAC) / Federal Inland Revenue Service (FIRS)\n3. **Requirements**: Verified NIN, Proof of address, Name reservation.\n4. **Official Portal**: https://services.gov.ng\n\n*Source: Federal Ministry of Communications, Innovation and Digital Economy (Last Updated: October 2026)*` 
      });
    }

    const ai = new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      } 
    });

    const systemInstruction = `You are "Ask Nigeria", the official GovGuide AI Assistant for NIGERIA.GOV (Government as a Service platform).
Your duty is to assist Nigerian citizens and business owners with official government services, requirements, forms, eligibility, tax obligations, passport procedures, driver's licences, CAC company registration, NIMC identity verification, and government procurement.

RULES:
1. Always respond in ${language} (if Hausa, Igbo, or Yoruba, use clear natural phrasing, or English if preferred by user).
2. NEVER invent non-existent government fees, laws, deadlines, or legal decisions.
3. Every answer MUST clearly include:
   - **RESPONSIBLE AGENCY** (e.g. CAC, FRSC, FIRS, NIMC, NIS, BPP, NHIA)
   - **CLEAR STEPS OR REQUIREMENTS**
   - **LAST UPDATED** (October 2026)
   - **OFFICIAL SOURCE** (e.g. services.gov.ng / Official Gazette)
4. Keep answers clean, encouraging, respectful, simple, and direct.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.3,
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json({ 
      text: `[GovGuide System Notice]: Official Service Catalogue Response:\n\nFor your inquiry, please refer to the NIGERIA.GOV Service Catalogue. For CAC, FRSC, FIRS, NIMC or NIS services, visit services.gov.ng or launch the service workflow in this application.\n\n*Source: Federal Republic of Nigeria e-Government Infrastructure (Last Updated: October 2026)*`
    });
  }
}
