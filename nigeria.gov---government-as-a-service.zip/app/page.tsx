'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeaderBanner } from '@/components/HeaderBanner';
import { HomeSearchAndCategories } from '@/components/HomeSearchAndCategories';
import { DigitalIdModal } from '@/components/DigitalIdModal';
import { ServiceCatalogueAndWorkflowModal } from '@/components/ServiceCatalogueAndWorkflowModal';
import { DocumentWalletModal } from '@/components/DocumentWalletModal';
import { TaxAreaModal } from '@/components/TaxAreaModal';
import { BusinessStarterModal } from '@/components/BusinessStarterModal';
import { SpecializedHubsModal } from '@/components/SpecializedHubsModal';
import { AppointmentSchedulerModal } from '@/components/AppointmentSchedulerModal';
import { GovernmentOfficeFinderModal } from '@/components/GovernmentOfficeFinderModal';
import { WhistleblowerModal } from '@/components/WhistleblowerModal';
import { OpenGovAndPerformanceModal } from '@/components/OpenGovAndPerformanceModal';
import { GovGuideAiAssistantModal } from '@/components/GovGuideAiAssistantModal';
import { ConsentAndAuditModal } from '@/components/ConsentAndAuditModal';
import { OfficialAdminPlatform } from '@/components/OfficialAdminPlatform';
import { DeveloperModeConsole } from '@/components/DeveloperModeConsole';
import { EmergencyModal } from '@/components/EmergencyModal';

import { 
  INITIAL_CITIZEN_PROFILE, 
  MOCK_SERVICES, 
  INITIAL_APPLICATIONS, 
  INITIAL_DOCUMENTS, 
  INITIAL_TAX_PROFILE, 
  INITIAL_APPOINTMENTS, 
  MOCK_NOTICES, 
  MOCK_PROJECTS, 
  MOCK_CONSENT_PERMISSIONS, 
  MOCK_AUDIT_LOGS, 
  INITIAL_OFFICIAL_CASES 
} from '@/lib/data/mockDatabase';

import { GovernmentService, GovernmentApplication, GovernmentAppointment, FraudReport, IdentityState } from '@/lib/types';

// Asset URLs generated via generate_image
const COAT_OF_ARMS_URL = "/src/assets/images/nigerian_coat_of_arms_1793102469086.jpg";
const SECRETARIAT_HERO_URL = "/src/assets/images/abuja_secretariat_hero_1793102471020.jpg";
const CITIZEN_AVATAR_URL = "/src/assets/images/citizen_avatar_tom_1793102470814.jpg";

export default function HomePage() {
  // State
  const [profile, setProfile] = useState(INITIAL_CITIZEN_PROFILE);
  const [services, setServices] = useState<GovernmentService[]>(MOCK_SERVICES);
  const [applications, setApplications] = useState<GovernmentApplication[]>(INITIAL_APPLICATIONS);
  const [documents, setDocuments] = useState(INITIAL_DOCUMENTS);
  const [taxProfile, setTaxProfile] = useState(INITIAL_TAX_PROFILE);
  const [appointments, setAppointments] = useState<GovernmentAppointment[]>(INITIAL_APPOINTMENTS);
  const [notices] = useState(MOCK_NOTICES);
  const [projects] = useState(MOCK_PROJECTS);
  const [fraudReports, setFraudReports] = useState<FraudReport[]>([
    {
      reportId: 'REP-101',
      caseId: 'CASE-NG-889102',
      agencyTarget: 'FRSC',
      category: 'Extortion',
      description: 'Demand for unofficial processing surcharge at Ojota DLC desk.',
      timestamp: '2026-10-25 14:10',
      anonymous: true,
      status: 'INVESTIGATING',
      evidenceCount: 1
    }
  ]);
  const [permissions, setPermissions] = useState(MOCK_CONSENT_PERMISSIONS);
  const [auditLogs, setAuditLogs] = useState(MOCK_AUDIT_LOGS);
  const [officialCases, setOfficialCases] = useState(INITIAL_OFFICIAL_CASES);

  // Navigation & View Modes
  const [mode, setMode] = useState<'CITIZEN' | 'OFFICIAL'>('CITIZEN');
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedState, setSelectedState] = useState('Lagos');
  const [selectedLga, setSelectedLga] = useState('Eti Osa');
  const [isLowDataMode, setIsLowDataMode] = useState(false);

  // Workflow Initial Trigger
  const [workflowInitialService, setWorkflowInitialService] = useState<GovernmentService | null>(null);

  // Modals
  const [isDigitalIdOpen, setIsDigitalIdOpen] = useState(false);
  const [isDevConsoleOpen, setIsDevConsoleOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);

  // Handlers
  const handleAddNewApplication = (newApp: GovernmentApplication) => {
    setApplications(prev => [newApp, ...prev]);

    // Add Audit Log Entry
    setAuditLogs(prev => [
      {
        logId: `LOG-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        actor: `${profile.name} (Citizen)`,
        agency: newApp.agency,
        action: `Application Submitted (${newApp.serviceName})`,
        resource: newApp.applicationId,
        purpose: 'Citizen Service Execution',
        result: 'SUCCESS'
      },
      ...prev
    ]);
  };

  const handleAddNewAppointment = (newApt: GovernmentAppointment) => {
    setAppointments(prev => [newApt, ...prev]);
  };

  const handleAddNewReport = (newRep: FraudReport) => {
    setFraudReports(prev => [newRep, ...prev]);
  };

  const handleTogglePermission = (agencyId: string) => {
    setPermissions(prev => prev.map(p => {
      if (p.agencyId === agencyId) {
        return {
          ...p,
          status: p.status === 'ACTIVE' ? 'REVOKED' : 'ACTIVE'
        };
      }
      return p;
    }));
  };

  const handleApproveCase = (caseId: string) => {
    setOfficialCases(prev => prev.map(c => {
      if (c.caseId === caseId) {
        return { ...c, status: 'APPROVED' };
      }
      return c;
    }));
  };

  const handleRejectCase = (caseId: string) => {
    setOfficialCases(prev => prev.map(c => {
      if (c.caseId === caseId) {
        return { ...c, status: 'REJECTED' };
      }
      return c;
    }));
  };

  const handleRunTestScenario = (scenarioName: string) => {
    alert(`Running Deterministic E2E Test Scenario: "${scenarioName}"... Complete. All mock government APIs responded with 200 OK.`);
  };

  const handleOpenWorkflowForService = (srv: GovernmentService) => {
    setWorkflowInitialService(srv);
    setActiveTab('catalogue');
  };

  return (
    <div className={`min-h-screen bg-[#F8FAF9] text-slate-900 flex flex-col font-sans ${isLowDataMode ? 'contrast-125' : ''}`}>
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedState={selectedState}
        setSelectedState={setSelectedState}
        selectedLga={selectedLga}
        setSelectedLga={setSelectedLga}
        isLowDataMode={isLowDataMode}
        setIsLowDataMode={setIsLowDataMode}
        onOpenDevConsole={() => setIsDevConsoleOpen(true)}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenDigitalId={() => setIsDigitalIdOpen(true)}
        mode={mode}
        setMode={setMode}
        coatOfArmsUrl={COAT_OF_ARMS_URL}
      />

      {/* Main View Router */}
      <main className="flex-1 pb-16">
        
        {mode === 'OFFICIAL' ? (
          /* Official Government Operations SLA View */
          <OfficialAdminPlatform
            cases={officialCases}
            onApproveCase={handleApproveCase}
            onRejectCase={handleRejectCase}
          />
        ) : (
          /* Citizen Operating View */
          <>
            {/* Header Banner (Greeting & Identity Status) */}
            <HeaderBanner
              profile={profile}
              selectedState={selectedState}
              selectedLga={selectedLga}
              onOpenDigitalId={() => setIsDigitalIdOpen(true)}
              onOpenConsent={() => setActiveTab('consent')}
              heroImgUrl={SECRETARIAT_HERO_URL}
              avatarUrl={CITIZEN_AVATAR_URL}
            />

            {/* Quick Secondary Navigation Bar for Citizen Views */}
            <div className="bg-white border-b border-slate-200 py-2.5 px-4 shadow-xs">
              <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto text-xs font-mono scrollbar-none gap-2">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setActiveTab('home')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'home' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Home
                  </button>
                  <button
                    onClick={() => setActiveTab('business_starter')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'business_starter' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Start Business
                  </button>
                  <button
                    onClick={() => setActiveTab('tax')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'tax' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Tax Area (FIRS)
                  </button>
                  <button
                    onClick={() => setActiveTab('transport_hub')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'transport_hub' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Transport (FRSC)
                  </button>
                  <button
                    onClick={() => setActiveTab('passport_hub')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'passport_hub' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Passport (NIS)
                  </button>
                  <button
                    onClick={() => setActiveTab('appointments')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'appointments' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Appointments
                  </button>
                  <button
                    onClick={() => setActiveTab('offices')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'offices' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Office Finder
                  </button>
                  <button
                    onClick={() => setActiveTab('whistleblower')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'whistleblower' ? 'bg-red-700 text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Whistleblower
                  </button>
                  <button
                    onClick={() => setActiveTab('consent')}
                    className={`px-3 py-1 rounded-md font-bold transition-colors ${
                      activeTab === 'consent' ? 'bg-[#008751] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Consent & Audit
                  </button>
                </div>

                <div className="shrink-0 text-slate-400 font-sans text-[11px]">
                  <span>Jurisdiction: <strong className="text-slate-900">{selectedState} State</strong></span>
                </div>
              </div>
            </div>

            {/* Tab Body Render */}
            {activeTab === 'home' && (
              <HomeSearchAndCategories
                services={services}
                applications={applications}
                notices={notices}
                onSelectCategory={(cat) => {
                  setSelectedCategory(cat);
                  setActiveTab('catalogue');
                }}
                onOpenServiceWorkflow={handleOpenWorkflowForService}
                onOpenApplicationDetails={() => setActiveTab('inbox')}
                onOpenBusinessStarter={() => setActiveTab('business_starter')}
                onOpenTaxPortal={() => setActiveTab('tax')}
                onOpenTransportHub={() => setActiveTab('transport_hub')}
                onOpenPassportHub={() => setActiveTab('passport_hub')}
              />
            )}

            {activeTab === 'catalogue' && (
              <ServiceCatalogueAndWorkflowModal
                services={services}
                profile={profile}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                onAddNewApplication={handleAddNewApplication}
                initialSelectedService={workflowInitialService}
                onClearInitialService={() => setWorkflowInitialService(null)}
              />
            )}

            {activeTab === 'inbox' && (
              <DocumentWalletModal
                documents={documents}
                onOpenDigitalId={() => setIsDigitalIdOpen(true)}
              />
            )}

            {activeTab === 'business_starter' && (
              <BusinessStarterModal
                onOpenServiceWorkflow={handleOpenWorkflowForService}
                services={services}
              />
            )}

            {activeTab === 'tax' && (
              <TaxAreaModal taxProfile={taxProfile} />
            )}

            {activeTab === 'transport_hub' && (
              <SpecializedHubsModal
                hubType="TRANSPORT"
                onOpenServiceWorkflow={handleOpenWorkflowForService}
                services={services}
                onOpenAppointments={() => setActiveTab('appointments')}
              />
            )}

            {activeTab === 'passport_hub' && (
              <SpecializedHubsModal
                hubType="PASSPORT"
                onOpenServiceWorkflow={handleOpenWorkflowForService}
                services={services}
                onOpenAppointments={() => setActiveTab('appointments')}
              />
            )}

            {activeTab === 'appointments' && (
              <AppointmentSchedulerModal
                appointments={appointments}
                onAddNewAppointment={handleAddNewAppointment}
                selectedState={selectedState}
              />
            )}

            {activeTab === 'offices' && (
              <GovernmentOfficeFinderModal selectedState={selectedState} />
            )}

            {activeTab === 'whistleblower' && (
              <WhistleblowerModal
                reports={fraudReports}
                onAddNewReport={handleAddNewReport}
              />
            )}

            {activeTab === 'opengov' && (
              <OpenGovAndPerformanceModal projects={projects} />
            )}

            {activeTab === 'ai' && (
              <GovGuideAiAssistantModal />
            )}

            {activeTab === 'consent' && (
              <ConsentAndAuditModal
                permissions={permissions}
                auditLogs={auditLogs}
                onTogglePermission={handleTogglePermission}
              />
            )}
          </>
        )}

      </main>

      {/* Persistent Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 border-t border-slate-800 text-xs font-mono mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-slate-800 rounded p-1 border border-[#D4AF37]">
              <img src={COAT_OF_ARMS_URL} alt="Arms" className="w-full h-full object-cover" />
            </div>
            <div>
              <p className="font-bold text-white">FEDERAL REPUBLIC OF NIGERIA</p>
              <p className="text-[10px] text-slate-500">National Digital Public-Service Operating System (GaaS)</p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>services.gov.ng</span>
            <span>·</span>
            <span>NDPA Data Privacy Compliant</span>
            <span>·</span>
            <button onClick={() => setIsDevConsoleOpen(true)} className="text-[#D4AF37] hover:underline font-bold">
              Developer Simulation Console
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <DigitalIdModal
        isOpen={isDigitalIdOpen}
        onClose={() => setIsDigitalIdOpen(false)}
        profile={profile}
        coatOfArmsUrl={COAT_OF_ARMS_URL}
        avatarUrl={CITIZEN_AVATAR_URL}
      />

      <DeveloperModeConsole
        isOpen={isDevConsoleOpen}
        onClose={() => setIsDevConsoleOpen(false)}
        identityState={profile.identityState}
        setIdentityState={(st: IdentityState) => setProfile({ ...profile, identityState: st })}
        onRunTestScenario={handleRunTestScenario}
      />

      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        selectedState={selectedState}
      />

    </div>
  );
}
