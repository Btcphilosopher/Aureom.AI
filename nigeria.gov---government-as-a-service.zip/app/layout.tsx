import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'NIGERIA.GOV — Government as a Service',
  description: "Nigeria's National Digital Public-Service Operating System. One citizen, one secure identity, one government interface, many services.",
  openGraph: {
    title: 'NIGERIA.GOV — Government as a Service',
    description: "Nigeria's National Digital Public-Service Operating System. One citizen, one secure identity, one government interface, many services.",
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NIGERIA.GOV — Government as a Service',
    description: "Nigeria's National Digital Public-Service Operating System. One citizen, one secure identity, one government interface, many services.",
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body suppressHydrationWarning className="font-sans antialiased bg-[#F8FAF9] text-slate-900 selection:bg-[#008751] selection:text-white">{children}</body>
    </html>
  );
}
