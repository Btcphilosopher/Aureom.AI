import { 
  CitizenProfile, 
  GovernmentService, 
  GovernmentApplication, 
  DigitalDocument, 
  TaxProfile, 
  GovernmentAppointment, 
  GovernmentNotice, 
  PublicProject, 
  FraudReport, 
  DataConsentPermission, 
  AuditLogEntry, 
  OfficialCase 
} from '../types';

export const INITIAL_CITIZEN_PROFILE: CitizenProfile = {
  name: "Tom O. Okafor",
  nin: "23049182910",
  maskedNin: "••••••9821",
  dob: "1994-08-14",
  gender: "Male",
  stateOfOrigin: "Anambra",
  lgaOfOrigin: "Nnewi North",
  residentialAddress: "14 Admiralty Way, Lekki Phase 1, Lagos",
  phone: "+234 803 123 4567",
  email: "tom.okafor@example.ng",
  identityState: "VERIFIED",
  issuanceDate: "2021-03-15",
  expiryDate: "2031-03-15",
  biometricVerified: true
};

export const MOCK_SERVICES: GovernmentService[] = [
  {
    serviceId: "CAC-REG-001",
    agency: "CAC",
    name: "Business Name & Company Registration",
    description: "Register a new business name, private limited company (LTD), or NGO under the Companies and Allied Matters Act.",
    category: "Business",
    eligibility: "Nigerian citizens or legal entities aged 18+ with valid NIN.",
    documentsRequired: ["NIN Verification", "Proof of Address", "Proposed Names (2)", "Object of Business"],
    feesNaira: 15000,
    estimatedDuration: "24 Hours - 3 Working Days",
    applicationMethod: "Digital Online",
    status: "ACTIVE",
    supportContact: "helpdesk@cac.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "FRSC-LIC-002",
    agency: "FRSC",
    name: "National Driver's Licence Renewal",
    description: "Renew 3-year or 5-year National Driver's Licence with biometrics verification across FRSC DLC centres.",
    category: "Transport",
    eligibility: "Holders of expiring or expired driver's licence.",
    documentsRequired: ["Existing Driver's Licence No.", "NIN Verification", "Vision Test Certification"],
    feesNaira: 10450,
    estimatedDuration: "3 Working Days",
    applicationMethod: "Digital + Biometric Capture",
    status: "ACTIVE",
    supportContact: "licence@frsc.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "FIRS-TAX-003",
    agency: "FIRS",
    name: "Taxpayer Identification & e-Clearance Certificate",
    description: "Instant Tax Identification Number (TIN) issuance and Tax Clearance Certificate (TCC) generation.",
    category: "Tax",
    eligibility: "All gainfully employed individuals, sole proprietors, and registered companies.",
    documentsRequired: ["NIN / CAC RC Number", "Bank Verification Number (BVN)", "Proof of Income / Returns"],
    feesNaira: 0,
    estimatedDuration: "Instant to 24 Hours",
    applicationMethod: "Digital Automated",
    status: "ACTIVE",
    supportContact: "taxpayerservice@firs.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "NIMC-ID-004",
    agency: "NIMC",
    name: "National Identity Verification & Mobile Digital ID",
    description: "National Identification Number (NIN) enrolment, data modification, and secure virtual digital identity card generation.",
    category: "Identity",
    eligibility: "All Nigerian citizens and legal residents.",
    documentsRequired: ["Birth Certificate / Age Declaration", "Proof of Residency"],
    feesNaira: 0,
    estimatedDuration: "Instant",
    applicationMethod: "Digital Identity Layer",
    status: "ACTIVE",
    supportContact: "nimcsupport@nimc.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "NIS-PAS-005",
    agency: "NIS",
    name: "Standard International Passport Application & Renewal",
    description: "Apply for or renew 32-page or 64-page 10-year e-Passport with appointment booking at NIS passport offices.",
    category: "Immigration",
    eligibility: "Nigerian citizens with verified NIN.",
    documentsRequired: ["NIN Slip", "Birth Certificate", "Letter of Identification from LGA", "Passport Photograph"],
    feesNaira: 35000,
    estimatedDuration: "2 - 3 Weeks",
    applicationMethod: "Digital Form + Office Appointment",
    status: "ACTIVE",
    supportContact: "passport@immigration.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "BPP-CON-006",
    agency: "BPP",
    name: "Federal Contractor & Supplier Registration",
    description: "National Database of Federal Contractors, Consultants and Service Providers registration for public procurement.",
    category: "Business",
    eligibility: "CAC Registered Companies with active FIRS Tax Clearance.",
    documentsRequired: ["CAC Certificate", "TCC", "PENCOM Certificate", "ITF Clearance"],
    feesNaira: 25000,
    estimatedDuration: "5 Working Days",
    applicationMethod: "Digital Portal",
    status: "ACTIVE",
    supportContact: "info@bpp.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "NHIA-HEA-007",
    agency: "NHIA",
    name: "National Health Insurance Enrolment",
    description: "Enrolment in the National Health Insurance Authority scheme for formal and informal sector coverage.",
    category: "Health",
    eligibility: "All Nigerian residents.",
    documentsRequired: ["NIN Verification", "Passport Photograph", "Dependent Details"],
    feesNaira: 15000,
    estimatedDuration: "Instant Digital Coverage",
    applicationMethod: "Digital Online",
    status: "ACTIVE",
    supportContact: "coverage@nhia.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "NDE-JOB-008",
    agency: "NDE",
    name: "National Youth Skills & Apprenticeship Programme",
    description: "Register for federal vocational training, digital skills apprenticeships, and youth enterprise grants.",
    category: "Jobs",
    eligibility: "Nigerian youth aged 18 - 35.",
    documentsRequired: ["NIN", "Educational Certificates", "State of Origin Cert"],
    feesNaira: 0,
    estimatedDuration: "Batch Enrolment",
    applicationMethod: "Digital Portal",
    status: "ACTIVE",
    supportContact: "skills@nde.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "FMAG-AGR-009",
    agency: "FMARD",
    name: "National Farmer Identity & Agricultural Subsidy",
    description: "Digital registration of farmers for subsidized high-yield seeds, fertilizer distribution, and agro-grants.",
    category: "Agriculture",
    eligibility: "Active smallholder or commercial farmers.",
    documentsRequired: ["NIN", "Farm Location GPS/Address", "Cooperative Membership"],
    feesNaira: 0,
    estimatedDuration: "Instant Registration",
    applicationMethod: "Digital / Low-Bandwidth SMS",
    status: "ACTIVE",
    supportContact: "agro@agriculture.gov.ng",
    governmentLevel: "Federal"
  },
  {
    serviceId: "LIRS-ST-010",
    agency: "LIRS",
    name: "Lagos State Personal Income Tax Return",
    description: "File annual PAYE / Direct Assessment income tax returns with the Lagos State Internal Revenue Service.",
    category: "Tax",
    eligibility: "Residents of Lagos State earning taxable income.",
    documentsRequired: ["LIRS Tax ID (State TIN)", "Form H1 Return", "Proof of Deductions"],
    feesNaira: 0,
    estimatedDuration: "2 Working Days",
    applicationMethod: "Digital Online",
    status: "ACTIVE",
    supportContact: "etax@lirs.gov.ng",
    governmentLevel: "State",
    applicableState: "Lagos"
  }
];

export const INITIAL_APPLICATIONS: GovernmentApplication[] = [
  {
    applicationId: "APP-2026-FRSC-89102",
    serviceId: "FRSC-LIC-002",
    agency: "FRSC",
    serviceName: "National Driver's Licence Renewal",
    category: "Transport",
    submittedAt: "2026-10-24 09:15",
    lastUpdate: "2026-10-26 14:30",
    currentStage: "Agency Review & Card Printing",
    progressPercent: 80,
    slaDaysTotal: 5,
    slaDaysRemaining: 2,
    slaStatus: "ON_TRACK",
    status: "AGENCY_REVIEW",
    applicantName: "Tom O. Okafor",
    applicantNin: "••••••9821",
    state: "Lagos",
    lga: "Eti-Osa",
    steps: [
      { stepId: "s1", title: "Identity Verification", description: "NIMC NIN Authentication", status: "COMPLETED", requirementType: "BIOMETRIC" },
      { stepId: "s2", title: "Form & Medical Declaration", description: "Self-declaration of fitness", status: "COMPLETED", requirementType: "FORM" },
      { stepId: "s3", title: "Statutory Payment", description: "FRSC Licence Renewal Fee ₦10,450", status: "COMPLETED", requirementType: "PAYMENT", feeNaira: 10450 },
      { stepId: "s4", title: "Biometric Capture & Verification", description: "FRSC DLC Centre Check-in", status: "COMPLETED", requirementType: "BIOMETRIC" },
      { stepId: "s5", title: "Agency Approval & Card Issuance", description: "Final quality check & print", status: "IN_PROGRESS", requirementType: "AGENCY_REVIEW" }
    ],
    receiptId: "REC-2026-FRSC-10450"
  },
  {
    applicationId: "APP-2026-FIRS-44109",
    serviceId: "FIRS-TAX-003",
    agency: "FIRS",
    serviceName: "Taxpayer Registration & e-TIN",
    category: "Tax",
    submittedAt: "2026-10-15 11:20",
    lastUpdate: "2026-10-15 11:22",
    currentStage: "Tax Clearance Issued",
    progressPercent: 100,
    slaDaysTotal: 1,
    slaDaysRemaining: 1,
    slaStatus: "ON_TRACK",
    status: "APPROVED",
    applicantName: "Tom O. Okafor",
    applicantNin: "••••••9821",
    documentIssuedId: "DOC-FIRS-TCC-2026",
    receiptId: "REC-2026-FIRS-FREE",
    state: "Lagos",
    lga: "Eti-Osa",
    steps: [
      { stepId: "s1", title: "NIN Identity Sync", description: "Verification via NIMC", status: "COMPLETED", requirementType: "BIOMETRIC" },
      { stepId: "s2", title: "Automated TIN Generation", description: "FIRS Core Registry", status: "COMPLETED", requirementType: "FORM" },
      { stepId: "s3", title: "e-Clearance Generation", description: "Digital TCC Issued", status: "COMPLETED", requirementType: "DOCUMENT" }
    ]
  },
  {
    applicationId: "APP-2026-NIS-11093",
    serviceId: "NIS-PAS-005",
    agency: "NIS",
    serviceName: "Standard International Passport Renewal",
    category: "Immigration",
    submittedAt: "2026-10-26 16:45",
    lastUpdate: "2026-10-27 08:00",
    currentStage: "Appointment Required",
    progressPercent: 40,
    slaDaysTotal: 14,
    slaDaysRemaining: 13,
    slaStatus: "ON_TRACK",
    status: "APPOINTMENT_REQUIRED",
    applicantName: "Tom O. Okafor",
    applicantNin: "••••••9821",
    state: "Lagos",
    lga: "Eti-Osa",
    steps: [
      { stepId: "s1", title: "NIN Verification", description: "Validated against NIMC", status: "COMPLETED", requirementType: "BIOMETRIC" },
      { stepId: "s2", title: "Application Form", description: "Personal & Guarantor Data", status: "COMPLETED", requirementType: "FORM" },
      { stepId: "s3", title: "Passport Fee Payment", description: "64-Page 10-Year ₦35,000", status: "COMPLETED", requirementType: "PAYMENT", feeNaira: 35000 },
      { stepId: "s4", title: "Office Appointment", description: "Biometric & Document Capture at Alausa NIS Office", status: "PENDING_ACTION", requirementType: "BIOMETRIC" },
      { stepId: "s5", title: "Production & Collection", description: "Passport Booklet Issuance", status: "NOT_STARTED", requirementType: "AGENCY_REVIEW" }
    ],
    receiptId: "REC-2026-NIS-35000"
  }
];

export const INITIAL_DOCUMENTS: DigitalDocument[] = [
  {
    docId: "DOC-NIMC-ID-9821",
    title: "National Digital Identity Card",
    documentType: "National ID",
    issuer: "National Identity Management Commission (NIMC)",
    issueDate: "2021-03-15",
    expiryDate: "2031-03-15",
    verificationState: "VERIFIED",
    verificationQrCode: "NIMC://VERIFY/NIN=23049182910/HASH=8a9f02b1c",
    category: "Identity",
    keystoreProtected: true,
    metadata: {
      "NIN": "••••••9821",
      "Full Name": "Tom O. Okafor",
      "State of Origin": "Anambra",
      "Issuer Authority": "NIMC Federal HQ Abuja"
    }
  },
  {
    docId: "DOC-FRSC-DL-7712",
    title: "National Driver's Licence",
    documentType: "Driver's Licence",
    issuer: "Federal Road Safety Corps (FRSC)",
    issueDate: "2021-11-10",
    expiryDate: "2026-11-09",
    verificationState: "VERIFIED",
    verificationQrCode: "FRSC://VERIFY/DL=FRSC9821092/HASH=4d7e21a8",
    category: "Licences",
    keystoreProtected: true,
    metadata: {
      "Licence Class": "Class B (Private Cars)",
      "Licence Number": "FRSC-LA-9821092",
      "Blood Group": "O+",
      "Restrictions": "01 (Glasses Required)"
    }
  },
  {
    docId: "DOC-FIRS-TCC-2026",
    title: "Tax Clearance Certificate (TCC 2026)",
    documentType: "Tax Clearance",
    issuer: "Federal Inland Revenue Service (FIRS)",
    issueDate: "2026-01-10",
    expiryDate: "2026-12-31",
    verificationState: "VERIFIED",
    verificationQrCode: "FIRS://VERIFY/TCC=FIRS-2026-982100/HASH=1a2b3c4d",
    category: "Tax documents",
    keystoreProtected: true,
    metadata: {
      "TIN": "23091823-0001",
      "Taxpayer Name": "Tom O. Okafor",
      "Tax Assessment Year": "2026",
      "Compliance Rating": "Category A (Fully Compliant)"
    }
  },
  {
    docId: "DOC-CAC-CERT-4412",
    title: "CAC Certificate of Incorporation",
    documentType: "Business Certificate",
    issuer: "Corporate Affairs Commission (CAC)",
    issueDate: "2023-04-18",
    expiryDate: "Permanent",
    verificationState: "VERIFIED",
    verificationQrCode: "CAC://VERIFY/RC=RC-1928371/HASH=99a18b2c",
    category: "Business documents",
    keystoreProtected: true,
    metadata: {
      "RC Number": "RC-1928371",
      "Company Name": "Okafor Innovations Nigeria LTD",
      "Classification": "Private Limited Company",
      "Registered Address": "14 Admiralty Way, Lekki, Lagos"
    }
  }
];

export const INITIAL_TAX_PROFILE: TaxProfile = {
  tin: "23091823-0001",
  taxpayerName: "Tom O. Okafor",
  taxpayerType: "INDIVIDUAL",
  jurisdictionState: "Lagos",
  filingStatus: "COMPLIANT",
  totalPaidThisYearNaira: 420000,
  pendingReturnsCount: 0,
  eClearanceId: "DOC-FIRS-TCC-2026",
  obligations: [
    { name: "Personal Income Tax (PAYE) Q3", dueDate: "2026-09-30", amountNaira: 105000, status: "PAID" },
    { name: "Personal Income Tax (PAYE) Q4", dueDate: "2026-12-31", amountNaira: 105000, status: "PENDING" }
  ]
};

export const INITIAL_APPOINTMENTS: GovernmentAppointment[] = [
  {
    appointmentId: "APT-2026-NIS-091",
    agency: "NIS",
    serviceName: "Passport Biometrics Capture",
    locationName: "NIS Passport Office, Alausa Ikeja",
    address: "Mobolaji Johnson Ave, Alausa, Ikeja, Lagos",
    date: "2026-11-03",
    timeSlot: "10:30 AM",
    queueNumber: "Q-042",
    status: "BOOKED"
  }
];

export const MOCK_NOTICES: GovernmentNotice[] = [
  {
    noticeId: "NOT-2026-001",
    verifiedAgency: "NIMC HQ",
    publicationDate: "2026-10-25",
    expiryDate: "2026-11-30",
    title: "Mandatory NIN-SIM Linkage Upgrade for 5G Data Services",
    category: "Identity",
    summary: "NIMC and NCC issue joint compliance directive for digital public infrastructure security.",
    details: "All citizens are advised to check their NIN linkage state using the NIGERIA.GOV Data Consent Centre. Mobile services remain uninterrupted for verified NIN holders.",
    sourceUrl: "https://services.gov.ng/notices/nimc-ncc-2026",
    urgency: "HIGH"
  },
  {
    noticeId: "NOT-2026-002",
    verifiedAgency: "FIRS",
    publicationDate: "2026-10-20",
    expiryDate: "2026-12-31",
    title: "Automated e-Tax Clearance Certificate Waiver for MSMEs",
    category: "Tax",
    summary: "FIRS waives administrative processing fees for small business tax clearances under ₦25M turnover.",
    details: "Micro, Small, and Medium Enterprises can instantly generate their 2026 e-TCC via the Tax module on NIGERIA.GOV without physical office visitation.",
    sourceUrl: "https://services.gov.ng/notices/firs-tcc-msme",
    urgency: "NORMAL"
  },
  {
    noticeId: "NOT-2026-003",
    verifiedAgency: "FRSC HQ",
    publicationDate: "2026-10-18",
    expiryDate: "2026-11-15",
    title: "National Digital Driving Licence Mobile Verification Rollout",
    category: "Transport",
    summary: "Traffic officers equipped with QR verification scanners across major highways.",
    details: "Drivers can present their cryptographically signed NIGERIA.GOV Digital Wallet Driving Licence during routine highway checks.",
    sourceUrl: "https://services.gov.ng/notices/frsc-digital-verification",
    urgency: "NORMAL"
  }
];

export const MOCK_PROJECTS: PublicProject[] = [
  {
    projectId: "PRJ-NG-2026-01",
    name: "Lagos-Ibadan Expressway Modernization & Intelligent Toll",
    agency: "Federal Ministry of Works",
    locationState: "Lagos / Ogun / Oyo",
    budgetNairaMillions: 185000,
    status: "NEAR_COMPLETION",
    contractor: "Julius Berger Nigeria Plc",
    startDate: "2022-01-15",
    expectedCompletion: "2026-12-15",
    progressPercent: 92,
    description: "Reconstruction and addition of solar smart highway lighting, automated weigh bridges, and toll cameras."
  },
  {
    projectId: "PRJ-NG-2026-02",
    name: "Abuja-Kano Dual Carriageway Railway Freight Link",
    agency: "Federal Ministry of Transportation",
    locationState: "FCT / Kaduna / Kano",
    budgetNairaMillions: 340000,
    status: "IN_PROGRESS",
    contractor: "CCECC Nigeria Limited",
    startDate: "2023-03-01",
    expectedCompletion: "2027-06-30",
    progressPercent: 68,
    description: "Standard gauge rail corridor connecting the Federal Capital Territory directly to Kano commercial hub."
  },
  {
    projectId: "PRJ-NG-2026-03",
    name: "National Primary Healthcare Digitalization & Solar Grid",
    agency: "Federal Ministry of Health & NHIA",
    locationState: "All 36 States & FCT",
    budgetNairaMillions: 75000,
    status: "IN_PROGRESS",
    contractor: "Green Energy & Tech Consortium",
    startDate: "2024-06-01",
    expectedCompletion: "2026-11-30",
    progressPercent: 84,
    description: "Equipping 5,000 rural primary healthcare centres with solar electrification and telemedicine kiosks."
  }
];

export const MOCK_CONSENT_PERMISSIONS: DataConsentPermission[] = [
  {
    agencyId: "AG-NIMC",
    agencyName: "National Identity Management Commission (NIMC)",
    purpose: "Biometric and Identity Verification",
    scope: "Read NIN, Full Name, DOB, Biometric Verification State",
    grantedAt: "2026-01-10",
    expiry: "2027-01-10",
    status: "ACTIVE"
  },
  {
    agencyId: "AG-FIRS",
    agencyName: "Federal Inland Revenue Service (FIRS)",
    purpose: "Tax Clearance & TIN Verification",
    scope: "Read Income Declarations, PAYE Deductions, Corporate Records",
    grantedAt: "2026-02-14",
    expiry: "2027-02-14",
    status: "ACTIVE"
  },
  {
    agencyId: "AG-FRSC",
    agencyName: "Federal Road Safety Corps (FRSC)",
    purpose: "Driver's Licence Validation",
    scope: "Read Licence Status, Driving History, Vision Test Records",
    grantedAt: "2024-05-01",
    expiry: "2026-05-01",
    status: "EXPIRED"
  }
];

export const MOCK_AUDIT_LOGS: AuditLogEntry[] = [
  {
    logId: "LOG-99201",
    timestamp: "2026-10-27 08:31:02",
    actor: "Tom O. Okafor (Citizen)",
    agency: "NIMC Identity Gateway",
    action: "NIN Identity Authentication",
    resource: "NIN-23049182910",
    purpose: "Portal Session Sign-In",
    result: "SUCCESS"
  },
  {
    logId: "LOG-99202",
    timestamp: "2026-10-27 08:34:15",
    actor: "Tom O. Okafor (Citizen)",
    agency: "NIS Passport System",
    action: "Passport Renewal Application Submitted",
    resource: "APP-2026-NIS-11093",
    purpose: "Citizen Application Submission",
    result: "SUCCESS"
  },
  {
    logId: "LOG-99203",
    timestamp: "2026-10-27 08:35:40",
    actor: "MockPaymentProvider (Remita System)",
    agency: "Central Bank of Nigeria Gateway",
    action: "Payment Authorization ₦35,000",
    resource: "REC-2026-NIS-35000",
    purpose: "Statutory Passport Application Fee",
    result: "SUCCESS"
  },
  {
    logId: "LOG-99204",
    timestamp: "2026-10-27 08:36:10",
    actor: "NIGERIA.GOV Wallet Vault",
    agency: "NIS Passport System",
    action: "Government Digital Receipt Issued",
    resource: "DOC-NIS-REC-35000",
    purpose: "Verifiable Credential Store",
    result: "SUCCESS"
  }
];

export const INITIAL_OFFICIAL_CASES: OfficialCase[] = [
  {
    caseId: "CASE-FRSC-89102",
    applicantName: "Tom O. Okafor",
    applicantNinMasked: "••••••9821",
    serviceName: "Driver's Licence Renewal",
    agency: "FRSC DLC Lagos",
    submittedAt: "2026-10-24 09:15",
    priority: "HIGH",
    status: "ASSIGNED",
    assignedOfficer: "Inspr. A. Bello (FRSC-4401)",
    slaDaysRemaining: 2,
    slaDaysTotal: 5
  },
  {
    caseId: "CASE-NIS-11093",
    applicantName: "Tom O. Okafor",
    applicantNinMasked: "••••••9821",
    serviceName: "Standard Passport Renewal",
    agency: "NIS Alausa Command",
    submittedAt: "2026-10-26 16:45",
    priority: "NORMAL",
    status: "NEW",
    assignedOfficer: "Unassigned Queue",
    slaDaysRemaining: 13,
    slaDaysTotal: 14
  },
  {
    caseId: "CASE-CAC-00921",
    applicantName: "Chinedu V. Eze",
    applicantNinMasked: "••••••3104",
    serviceName: "Company Incorporation (LTD)",
    agency: "CAC HQ Abuja",
    submittedAt: "2026-10-21 10:00",
    priority: "URGENT",
    status: "OVERDUE",
    assignedOfficer: "Officer F. Adebayo",
    slaDaysRemaining: -1,
    slaDaysTotal: 3
  }
];
