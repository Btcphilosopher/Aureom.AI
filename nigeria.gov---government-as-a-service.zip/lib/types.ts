export type IdentityState = 
  | 'UNKNOWN' 
  | 'PARTIALLY_VERIFIED' 
  | 'VERIFIED' 
  | 'REQUIRES_UPDATE' 
  | 'SUSPENDED';

export type GovernmentLevel = 'Federal' | 'State' | 'FCT' | 'Local';

export type WorkflowStepStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'PENDING_ACTION' | 'FAILED';

export type WorkflowRequirementType = 'FORM' | 'DOCUMENT' | 'PAYMENT' | 'BIOMETRIC' | 'AGENCY_REVIEW';

export interface WorkflowStep {
  stepId: string;
  title: string;
  description: string;
  status: WorkflowStepStatus;
  requirementType: WorkflowRequirementType;
  details?: string;
  formFields?: { key: string; label: string; type: string; required: boolean; value?: string }[];
  feeNaira?: number;
  documentRequiredType?: string;
}

export interface GovernmentService {
  serviceId: string;
  agency: string; // e.g. CAC, FRSC, FIRS, NIMC, NIS, BPP, NHIA, NDE, Ministry of Agriculture
  name: string;
  description: string;
  category: string; // Identity, Tax, Business, Transport, Documents, Education, Health, Jobs, Housing, Social Support, Immigration, Agriculture, Utilities, Justice, Licences
  eligibility: string;
  documentsRequired: string[];
  feesNaira: number;
  estimatedDuration: string;
  applicationMethod: string;
  status: 'ACTIVE' | 'MAINTENANCE' | 'DEPRECATED';
  supportContact: string;
  governmentLevel: GovernmentLevel;
  applicableState?: string;
}

export interface GovernmentApplication {
  applicationId: string;
  serviceId: string;
  agency: string;
  serviceName: string;
  category: string;
  submittedAt: string;
  lastUpdate: string;
  currentStage: string;
  progressPercent: number;
  slaDaysTotal: number;
  slaDaysRemaining: number;
  slaStatus: 'ON_TRACK' | 'WARNING' | 'ESCALATED';
  status: 'DRAFT' | 'SUBMITTED' | 'AGENCY_REVIEW' | 'APPOINTMENT_REQUIRED' | 'APPROVED' | 'REJECTED';
  applicantName: string;
  applicantNin: string;
  steps: WorkflowStep[];
  documentIssuedId?: string;
  receiptId?: string;
  rejectionReason?: string;
  state: string;
  lga: string;
}

export interface CitizenProfile {
  name: string;
  nin: string; // e.g. "23049182910"
  maskedNin: string; // "••••••9821"
  dob: string;
  gender: string;
  stateOfOrigin: string;
  lgaOfOrigin: string;
  residentialAddress: string;
  phone: string;
  email: string;
  identityState: IdentityState;
  issuanceDate: string;
  expiryDate: string;
  biometricVerified: boolean;
}

export interface DigitalDocument {
  docId: string;
  title: string;
  documentType: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  verificationState: 'VERIFIED' | 'PENDING' | 'EXPIRED' | 'REVOKED';
  verificationQrCode: string;
  category: string;
  metadata: Record<string, string>;
  keystoreProtected: boolean;
}

export interface TaxProfile {
  tin: string;
  taxpayerName: string;
  taxpayerType: 'INDIVIDUAL' | 'CORPORATE' | 'NON_RESIDENT' | 'FREE_ZONE';
  jurisdictionState: string;
  filingStatus: 'COMPLIANT' | 'DUE' | 'OVERDUE';
  totalPaidThisYearNaira: number;
  pendingReturnsCount: number;
  eClearanceId: string;
  obligations: { name: string; dueDate: string; amountNaira: number; status: 'PAID' | 'PENDING' }[];
}

export interface GovernmentAppointment {
  appointmentId: string;
  agency: string;
  serviceName: string;
  locationName: string;
  address: string;
  date: string;
  timeSlot: string;
  queueNumber: string;
  status: 'BOOKED' | 'CHECKED_IN' | 'COMPLETED' | 'CANCELLED';
}

export interface GovernmentNotice {
  noticeId: string;
  verifiedAgency: string;
  publicationDate: string;
  expiryDate: string;
  title: string;
  category: 'Emergency' | 'Public Service' | 'Tax' | 'Transport' | 'Health' | 'Education' | 'Immigration' | 'Infrastructure' | 'Identity' | 'Business';
  summary: string;
  details: string;
  sourceUrl: string;
  urgency: 'NORMAL' | 'HIGH' | 'CRITICAL';
}

export interface PublicProject {
  projectId: string;
  name: string;
  agency: string;
  locationState: string;
  budgetNairaMillions: number;
  status: 'PLANNING' | 'IN_PROGRESS' | 'NEAR_COMPLETION' | 'COMPLETED';
  contractor: string;
  startDate: string;
  expectedCompletion: string;
  progressPercent: number;
  description: string;
}

export interface FraudReport {
  reportId: string;
  caseId: string;
  agencyTarget: string;
  category: 'Bribery / Corruption' | 'Impersonation' | 'Extortion' | 'Identity Theft' | 'Fake Document' | 'Other';
  description: string;
  timestamp: string;
  anonymous: boolean;
  status: 'RECEIVED' | 'ASSIGNED' | 'INVESTIGATING' | 'RESOLVED' | 'CLOSED';
  evidenceCount: number;
}

export interface DataConsentPermission {
  agencyId: string;
  agencyName: string;
  purpose: string;
  scope: string;
  grantedAt: string;
  expiry: string;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
}

export interface AuditLogEntry {
  logId: string;
  timestamp: string;
  actor: string;
  agency: string;
  action: string;
  resource: string;
  purpose: string;
  result: 'SUCCESS' | 'DENIED' | 'FLAGGED';
}

export interface OfficialCase {
  caseId: string;
  applicantName: string;
  applicantNinMasked: string;
  serviceName: string;
  agency: string;
  submittedAt: string;
  priority: 'NORMAL' | 'HIGH' | 'URGENT';
  status: 'NEW' | 'ASSIGNED' | 'OVERDUE' | 'APPROVED' | 'REJECTED';
  assignedOfficer: string;
  slaDaysRemaining: number;
  slaDaysTotal: number;
}
