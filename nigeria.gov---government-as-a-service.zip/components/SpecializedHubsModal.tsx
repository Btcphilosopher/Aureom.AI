'use client';

import React, { useState } from 'react';
import { 
  Car, 
  Plane, 
  GraduationCap, 
  HeartPulse, 
  Sprout, 
  Users, 
  Briefcase, 
  ShieldCheck, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  Download,
  Zap,
  Phone
} from 'lucide-react';
import { GovernmentService } from '@/lib/types';

interface SpecializedHubsModalProps {
  hubType: 'TRANSPORT' | 'PASSPORT' | 'HEALTH' | 'AGRICULTURE' | 'JOBS';
  onOpenServiceWorkflow: (service: GovernmentService) => void;
  services: GovernmentService[];
  onOpenAppointments: () => void;
}

export const SpecializedHubsModal: React.FC<SpecializedHubsModalProps> = ({
  hubType,
  onOpenServiceWorkflow,
  services,
  onOpenAppointments
}) => {
  if (hubType === 'TRANSPORT') {
    const frscService = services.find(s => s.agency === 'FRSC') || services[1];

    return (
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full uppercase">
              FRSC National Transport Layer
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-2">TRANSPORT & VEHICLE SERVICES</h2>
          <p className="text-xs text-slate-600 mt-1">
            Federal Road Safety Corps (FRSC) national driver's licence renewal, vehicle registration verification, and mobile traffic verification.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <Car className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">National Driver's Licence Renewal</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Renew your 3-year or 5-year National Driver's Licence. Verification is cryptographically signed and stored in your Digital Document Wallet.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onOpenServiceWorkflow(frscService)}
                className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
              >
                <span>Launch Driver's Licence Workflow</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#008751] flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Vehicle Registration & Verification</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Verify plate numbers, vehicle roadworthiness clearance, and insurance registration against FRSC central database.
            </p>
            <button
              onClick={() => alert("Vehicle Verification Lookup: Plate # KJA-881-LA is VERIFIED & INSURED under FRSC Registry.")}
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
            >
              <span>Instant Vehicle Status Lookup</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (hubType === 'PASSPORT') {
    const passportService = services.find(s => s.agency === 'NIS') || services[4];

    return (
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-full uppercase">
            NIS Immigration Gateway
          </span>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-2">PASSPORT & IMMIGRATION SERVICES</h2>
          <p className="text-xs text-slate-600 mt-1">
            Nigerian Immigration Service (NIS) e-Passport application, appointment scheduling, and biometrics tracking.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Standard e-Passport Application Workflow</h3>
              <p className="text-xs text-slate-500 font-mono">Workflow: Eligibility → Application → Payment → Appointment → Biometrics → Collection</p>
            </div>
            <button
              onClick={onOpenAppointments}
              className="px-4 py-2 bg-[#D4AF37] hover:bg-[#c59c2b] text-slate-950 font-bold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Passport Office Appointment</span>
            </button>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs space-y-1">
            <p className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              Official Compliance Notice
            </p>
            <p className="text-amber-800">
              The application engine prepares official applications directly for NIS processing. Passports are issued exclusively by NIS Officers following physical biometric capture at designated offices.
            </p>
          </div>

          <button
            onClick={() => onOpenServiceWorkflow(passportService)}
            className="w-full py-3.5 bg-[#008751] hover:bg-[#006e40] text-white font-extrabold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
          >
            <span>Start International Passport Application</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  if (hubType === 'AGRICULTURE') {
    const agroService = services.find(s => s.agency === 'FMARD') || services[8];

    return (
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-lime-800 bg-lime-100 px-2.5 py-1 rounded-full uppercase">
              Federal Ministry of Agriculture
            </span>
            <span className="bg-amber-100 text-amber-900 text-[10px] font-mono px-2 py-0.5 rounded font-bold flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-600" />
              LOW-BANDWIDTH & SMS FALLBACK READY
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-2">NATIONAL FARMER SERVICES & AGRO-GRANTS</h2>
          <p className="text-xs text-slate-600 mt-1">
            Digital farmer registration, fertilizer vouchers, subsidized seed allocation, and extension services optimized for low connectivity.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="w-10 h-10 rounded-xl bg-lime-50 text-lime-800 flex items-center justify-center">
              <Sprout className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">National Farmer ID Enrolment</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Register farm acreage and produce type to access federal agricultural input subsidies and direct cash transfers.
            </p>
            <button
              onClick={() => onOpenServiceWorkflow(agroService)}
              className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
            >
              <span>Enrol Farmer Profile</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center">
              <Phone className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">USSD / SMS Offline Voucher Fallback</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              In low-connectivity rural LGAs, farmers can dial <strong>*347*33#</strong> to claim fertilizer e-vouchers offline without internet data.
            </p>
            <button
              onClick={() => alert("USSD Simulation: Dial *347*33# on any mobile device to claim agro-vouchers offline.")}
              className="w-full py-3 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors"
            >
              <span>Test USSD Offline Code (*347*33#)</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Default HEALTH & JOBS
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">HEALTH & EDUCATION SERVICES</h2>
        <p className="text-xs text-slate-600 mt-1">NHIA national health coverage, vaccination credentials, and student scholarships.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <HeartPulse className="w-8 h-8 text-red-600" />
          <h3 className="text-base font-bold text-slate-900">NHIA Health Insurance Enrolment</h3>
          <p className="text-xs text-slate-600">Access affordable primary healthcare across 5,000 accredited hospitals nationwide.</p>
          <button
            onClick={() => onOpenServiceWorkflow(services[6] || services[0])}
            className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl"
          >
            Enrol in Health Scheme
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <GraduationCap className="w-8 h-8 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900">Education Credentials & Verification</h3>
          <p className="text-xs text-slate-600">Standardized EducationCredential architecture for WAEC, NECO, and University degree verification.</p>
          <button
            onClick={() => alert("Education Credential Verified: WAEC Certificate #W2012-9901 is VERIFIED.")}
            className="w-full py-3 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800"
          >
            Verify WAEC / Degree Credential
          </button>
        </div>
      </div>
    </div>
  );
};
