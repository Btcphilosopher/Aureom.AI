'use client';

import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  X, 
  UserCheck, 
  Plus, 
  AlertCircle 
} from 'lucide-react';
import { GovernmentAppointment } from '@/lib/types';

interface AppointmentSchedulerModalProps {
  appointments: GovernmentAppointment[];
  onAddNewAppointment: (apt: GovernmentAppointment) => void;
  selectedState: string;
}

export const AppointmentSchedulerModal: React.FC<AppointmentSchedulerModalProps> = ({
  appointments,
  onAddNewAppointment,
  selectedState
}) => {
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [agency, setAgency] = useState('NIS');
  const [serviceName, setServiceName] = useState('Passport Biometric Capture');
  const [officeLocation, setOfficeLocation] = useState('NIS Passport Office, Alausa Ikeja');
  const [date, setDate] = useState('2026-11-05');
  const [timeSlot, setTimeSlot] = useState('11:00 AM');

  const handleCreateBooking = () => {
    const newApt: GovernmentAppointment = {
      appointmentId: `APT-2026-${agency}-${Math.floor(100 + Math.random() * 900)}`,
      agency,
      serviceName,
      locationName: officeLocation,
      address: `${officeLocation}, ${selectedState}`,
      date,
      timeSlot,
      queueNumber: `Q-0${Math.floor(10 + Math.random() * 80)}`,
      status: 'BOOKED'
    };

    onAddNewAppointment(newApt);
    setShowBookingForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold text-[#008751] uppercase">Universal Appointment Engine</span>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">GOVERNMENT APPOINTMENT SCHEDULER</h2>
          <p className="text-xs text-slate-600 mt-1">
            Book, reschedule, or check-in for physical biometric capture and document collection at NIMC, NIS, FRSC, and FIRS offices.
          </p>
        </div>

        <button
          onClick={() => setShowBookingForm(true)}
          className="px-4 py-2.5 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Book New Appointment</span>
        </button>
      </div>

      {/* Booking Form Modal */}
      {showBookingForm && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900 font-mono">BOOK APPOINTMENT</h3>
              <button onClick={() => setShowBookingForm(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Government MDA</label>
                <select 
                  value={agency} 
                  onChange={(e) => {
                    const ag = e.target.value;
                    setAgency(ag);
                    if (ag === 'NIS') {
                      setServiceName('Passport Biometrics Capture');
                      setOfficeLocation('NIS Passport Office, Alausa Ikeja');
                    } else if (ag === 'FRSC') {
                      setServiceName('Driver\'s Licence Biometric Capture');
                      setOfficeLocation('FRSC DLC Office, Ojota Lagos');
                    } else if (ag === 'NIMC') {
                      setServiceName('Identity Update & Card Collection');
                      setOfficeLocation('NIMC Enrolment Centre, Ikeja HQ');
                    }
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="NIS">NIS (Nigerian Immigration Service - Passport)</option>
                  <option value="FRSC">FRSC (Federal Road Safety Corps - Driver's Licence)</option>
                  <option value="NIMC">NIMC (National Identity Management Commission)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Service</label>
                <input type="text" readOnly value={serviceName} className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-medium" />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Government Office</label>
                <input type="text" value={officeLocation} onChange={(e) => setOfficeLocation(e.target.value)} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Preferred Date</label>
                  <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium" />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Time Slot</label>
                  <select value={timeSlot} onChange={(e) => setTimeSlot(e.target.value)} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium">
                    <option value="09:00 AM">09:00 AM</option>
                    <option value="10:30 AM">10:30 AM</option>
                    <option value="11:45 AM">11:45 AM</option>
                    <option value="02:00 PM">02:00 PM</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleCreateBooking}
                className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors font-mono"
              >
                Confirm Appointment Booking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Appointments List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {appointments.map((apt) => (
          <div key={apt.appointmentId} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-start justify-between gap-2">
              <span className="text-xs font-mono font-bold bg-slate-900 text-white px-2.5 py-0.5 rounded uppercase">
                {apt.agency}
              </span>

              <span className="bg-emerald-100 text-emerald-800 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                {apt.status}
              </span>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">{apt.serviceName}</h3>
              <p className="text-xs text-slate-600 font-mono mt-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#008751]" />
                <span>{apt.locationName}</span>
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div>
                <span className="text-[10px] text-slate-400 block">DATE</span>
                <span className="font-bold text-slate-900">{apt.date}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">TIME</span>
                <span className="font-bold text-slate-900">{apt.timeSlot}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">QUEUE TOKEN</span>
                <span className="font-extrabold text-[#008751]">{apt.queueNumber}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 text-xs font-mono">
              <button
                onClick={() => alert(`Checked-in at ${apt.locationName}! Your queue ticket is active: ${apt.queueNumber}. Please approach Desk 4.`)}
                className="flex-1 py-2 bg-[#008751] hover:bg-[#006e40] text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Check-in at Office</span>
              </button>

              <button
                onClick={() => alert("Simulating reschedule request to agency portal...")}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg"
              >
                Reschedule
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
