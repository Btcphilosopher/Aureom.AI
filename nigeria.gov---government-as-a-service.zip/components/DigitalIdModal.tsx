'use client';

import React, { useState } from 'react';
import { X, ShieldCheck, QrCode, Lock, Key, Copy, Check, Eye, EyeOff, Building2, Download } from 'lucide-react';
import { CitizenProfile } from '@/lib/types';

interface DigitalIdModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: CitizenProfile;
  coatOfArmsUrl: string;
  avatarUrl: string;
}

export const DigitalIdModal: React.FC<DigitalIdModalProps> = ({
  isOpen,
  onClose,
  profile,
  coatOfArmsUrl,
  avatarUrl
}) => {
  const [showNin, setShowNin] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyNin = () => {
    navigator.clipboard.writeText(profile.nin);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#004225] border-b border-[#D4AF37]/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-slate-900 p-1 border border-[#D4AF37]">
              <img src={coatOfArmsUrl} alt="Arms" className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold font-mono text-white tracking-wider uppercase">NIGERIA DIGITAL ID</h2>
              <p className="text-[10px] text-emerald-300 font-mono">National Identity Management Commission (NIMC)</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Digital ID Card Surface */}
        <div className="p-6 space-y-6">
          
          <div className="relative rounded-2xl bg-gradient-to-br from-[#005C36] via-[#004225] to-[#002B1B] border-2 border-[#D4AF37] p-6 shadow-2xl text-white overflow-hidden">
            
            {/* Watermark Background Coat of Arms */}
            <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none w-48 h-48 translate-x-10 translate-y-10">
              <img src={coatOfArmsUrl} alt="Watermark" className="w-full h-full object-cover" />
            </div>

            {/* Card Top Header */}
            <div className="flex items-start justify-between border-b border-[#D4AF37]/40 pb-4">
              <div>
                <p className="text-[10px] font-mono tracking-widest text-[#D4AF37] font-bold uppercase">FEDERAL REPUBLIC OF NIGERIA</p>
                <h3 className="text-base font-extrabold tracking-tight text-white font-mono">NATIONAL IDENTITY CREDENTIAL</h3>
              </div>

              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 font-mono">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                VERIFIED
              </span>
            </div>

            {/* Photo, Details & QR Code Grid */}
            <div className="grid grid-cols-12 gap-4 mt-5 items-center">
              
              {/* Avatar Photo */}
              <div className="col-span-4">
                <div className="w-24 h-28 rounded-xl overflow-hidden border-2 border-[#D4AF37] shadow-md bg-slate-800 relative">
                  <img 
                    src={avatarUrl} 
                    alt={profile.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[8px] font-mono text-emerald-300 text-center py-0.5">
                    NIMC BIOMETRIC
                  </div>
                </div>
              </div>

              {/* Citizen Details */}
              <div className="col-span-8 space-y-1.5 text-xs">
                <div>
                  <span className="text-[10px] text-emerald-200/70 uppercase block font-mono">Full Name</span>
                  <p className="font-bold text-white text-sm">{profile.name}</p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-200/70 uppercase block font-mono">Date of Birth</span>
                    <p className="font-semibold text-emerald-100">{profile.dob}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-200/70 uppercase block font-mono">Gender</span>
                    <p className="font-semibold text-emerald-100">{profile.gender}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-200/70 uppercase block font-mono">State of Origin</span>
                    <p className="font-semibold text-emerald-100">{profile.stateOfOrigin}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-200/70 uppercase block font-mono">LGA</span>
                    <p className="font-semibold text-emerald-100">{profile.lgaOfOrigin}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* NIN Row with Minimisation Discipline */}
            <div className="mt-5 pt-4 border-t border-[#D4AF37]/30 flex items-center justify-between bg-black/30 p-3 rounded-xl">
              <div>
                <span className="text-[10px] text-[#D4AF37] font-mono font-bold uppercase block">National Identity Number (NIN)</span>
                <span className="text-base font-mono font-extrabold tracking-widest text-white">
                  {showNin ? profile.nin : profile.maskedNin}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowNin(!showNin)}
                  className="p-1.5 text-emerald-300 hover:text-white bg-emerald-950/80 rounded-lg border border-emerald-700/50"
                  title={showNin ? "Hide NIN" : "Unmask NIN"}
                >
                  {showNin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>

                <button
                  onClick={handleCopyNin}
                  className="p-1.5 text-emerald-300 hover:text-white bg-emerald-950/80 rounded-lg border border-emerald-700/50"
                  title="Copy NIN"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Demonstration QR Code Credentials */}
            <div className="mt-4 p-3 bg-white text-slate-900 rounded-xl flex items-center justify-between shadow-inner">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-slate-900 text-white rounded-lg p-1 flex items-center justify-center shrink-0">
                  <QrCode className="w-10 h-10 text-[#D4AF37]" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900 font-mono">Verifiable QR Credential</p>
                  <p className="text-[10px] text-slate-500 font-mono">Sig: ed25519:NIMC_HQ_8a9f02b1c</p>
                  <p className="text-[9px] text-slate-400 font-sans mt-0.5">Valid for offline government & highway checks</p>
                </div>
              </div>

              <div className="text-right text-[10px] font-mono text-slate-600">
                <p>Issued: {profile.issuanceDate}</p>
                <p>Expires: {profile.expiryDate}</p>
              </div>
            </div>

          </div>

          {/* Security & Data Protection Notice */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-2 text-[#D4AF37] font-semibold font-mono">
              <Lock className="w-4 h-4" />
              <span>Android Keystore Protected Digital Credential</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              This digital identity presentation complies with Nigeria NDPA data minimisation standards. Credentials are backed by cryptographically verifiable signatures from the National Identity Management Commission.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={() => {
                alert("Simulating Offline Credential Export: Secured PDF and JSON proof generated in Keystore.");
              }}
              className="flex-1 py-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2 font-mono"
            >
              <Download className="w-4 h-4" />
              Export Signed Credential
            </button>
            <button
              onClick={onClose}
              className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl transition-colors"
            >
              Close
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
