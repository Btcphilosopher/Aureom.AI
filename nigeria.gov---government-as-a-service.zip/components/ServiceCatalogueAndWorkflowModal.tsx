'use client';

import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ShieldCheck, 
  Building2, 
  CreditCard, 
  Download, 
  X, 
  ChevronRight,
  AlertCircle,
  HelpCircle,
  Layers,
  Sparkles,
  Lock
} from 'lucide-react';
import { GovernmentService, WorkflowStep, GovernmentApplication, CitizenProfile } from '@/lib/types';
import { CATEGORIES_LIST } from './HomeSearchAndCategories';

interface ServiceCatalogueAndWorkflowModalProps {
  services: GovernmentService[];
  profile: CitizenProfile;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  onAddNewApplication: (app: GovernmentApplication) => void;
  initialSelectedService?: GovernmentService | null;
  onClearInitialService?: () => void;
}

export const ServiceCatalogueAndWorkflowModal: React.FC<ServiceCatalogueAndWorkflowModalProps> = ({
  services,
  profile,
  selectedCategory,
  setSelectedCategory,
  onAddNewApplication,
  initialSelectedService,
  onClearInitialService
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState<'All' | 'Federal' | 'State'>('All');
  const [activeWorkflowService, setActiveWorkflowService] = useState<GovernmentService | null>(initialSelectedService || null);
  
  // Workflow Runner State
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isPaymentPaid, setIsPaymentPaid] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [issuedDocId, setIssuedDocId] = useState<string | null>(null);

  // Filter services
  const filteredServices = services.filter(s => {
    const matchesCat = selectedCategory === 'All' || s.category === selectedCategory;
    const matchesLevel = levelFilter === 'All' || s.governmentLevel === levelFilter;
    const matchesSearch = !searchTerm || 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.agency.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesLevel && matchesSearch;
  });

  const handleStartWorkflow = (service: GovernmentService) => {
    setActiveWorkflowService(service);
    setCurrentStepIndex(0);
    setFormData({});
    setIsPaymentPaid(false);
    setIsSubmitted(false);
    setIssuedDocId(null);
  };

  const handleCloseWorkflow = () => {
    setActiveWorkflowService(null);
    if (onClearInitialService) onClearInitialService();
  };

  // Workflow Step Templates for Orchestrator Engine
  const generateWorkflowSteps = (service: GovernmentService): WorkflowStep[] => {
    return [
      {
        stepId: 'w1',
        title: 'Identity Authentication',
        description: `Verify citizen identity against NIMC NIN (${profile.maskedNin})`,
        status: 'COMPLETED',
        requirementType: 'BIOMETRIC',
        details: 'Identity confirmed via National Identity Management Commission.'
      },
      {
        stepId: 'w2',
        title: 'Eligibility & Statutory Check',
        description: service.eligibility,
        status: currentStepIndex > 0 ? 'COMPLETED' : 'IN_PROGRESS',
        requirementType: 'FORM',
        details: 'System validated citizen age, residency, and tax compliance status.'
      },
      {
        stepId: 'w3',
        title: 'Document Upload & Verification',
        description: `Required: ${service.documentsRequired.join(', ')}`,
        status: currentStepIndex > 1 ? 'COMPLETED' : currentStepIndex === 1 ? 'IN_PROGRESS' : 'NOT_STARTED',
        requirementType: 'DOCUMENT',
        details: 'Documents securely encrypted and uploaded to Keystore Vault.'
      },
      {
        stepId: 'w4',
        title: 'Official Application Form',
        description: `Enter official parameters for ${service.agency} processing`,
        status: currentStepIndex > 2 ? 'COMPLETED' : currentStepIndex === 2 ? 'IN_PROGRESS' : 'NOT_STARTED',
        requirementType: 'FORM',
        formFields: [
          { key: 'applicantName', label: 'Full Name', type: 'text', required: true, value: profile.name },
          { key: 'phone', label: 'Phone Number', type: 'text', required: true, value: profile.phone },
          { key: 'email', label: 'Email Address', type: 'email', required: true, value: profile.email },
          { key: 'purposeDetails', label: 'Service Purpose / Business Details', type: 'text', required: true }
        ]
      },
      {
        stepId: 'w5',
        title: 'Statutory Fee Payment',
        description: `Fee: ₦${service.feesNaira.toLocaleString()} via Remita / CBN Gateway`,
        status: isPaymentPaid ? 'COMPLETED' : currentStepIndex === 3 ? 'IN_PROGRESS' : 'NOT_STARTED',
        requirementType: 'PAYMENT',
        feeNaira: service.feesNaira
      },
      {
        stepId: 'w6',
        title: 'Agency SLA Review & Issuance',
        description: `${service.agency} automated decision engine and officer review`,
        status: isSubmitted ? 'COMPLETED' : currentStepIndex === 4 ? 'IN_PROGRESS' : 'NOT_STARTED',
        requirementType: 'AGENCY_REVIEW'
      }
    ];
  };

  const currentWorkflowSteps = activeWorkflowService ? generateWorkflowSteps(activeWorkflowService) : [];

  const handleProceedStep = () => {
    if (currentStepIndex < currentWorkflowSteps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    }
  };

  const handleSimulatePayment = () => {
    setIsPaymentPaid(true);
    setCurrentStepIndex(4);
  };

  const handleFinalSubmit = () => {
    if (!activeWorkflowService) return;
    setIsSubmitted(true);
    const newDocId = `DOC-${activeWorkflowService.agency}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReceiptId = `REC-2026-${activeWorkflowService.agency}-${activeWorkflowService.feesNaira}`;
    setIssuedDocId(newDocId);

    const newApp: GovernmentApplication = {
      applicationId: `APP-2026-${activeWorkflowService.agency}-${Math.floor(10000 + Math.random() * 90000)}`,
      serviceId: activeWorkflowService.serviceId,
      agency: activeWorkflowService.agency,
      serviceName: activeWorkflowService.name,
      category: activeWorkflowService.category,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      lastUpdate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      currentStage: 'Agency Review & Document Issuance',
      progressPercent: 90,
      slaDaysTotal: 3,
      slaDaysRemaining: 3,
      slaStatus: 'ON_TRACK',
      status: 'AGENCY_REVIEW',
      applicantName: profile.name,
      applicantNin: profile.maskedNin,
      state: 'Lagos',
      lga: 'Eti-Osa',
      steps: currentWorkflowSteps,
      documentIssuedId: newDocId,
      receiptId: newReceiptId
    };

    onAddNewApplication(newApp);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Search & Header Section */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-mono font-bold text-[#008751] uppercase">Single Window Catalogue</span>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">CENTRAL GOVERNMENT SERVICE CATALOGUE</h2>
            <p className="text-xs text-slate-600 mt-1">
              Extensible National Service Directory spanning CAC, FRSC, FIRS, NIMC, NIS, BPP, NHIA, NDE, and 36 State Ministries.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setLevelFilter('All')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                levelFilter === 'All' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Levels
            </button>
            <button
              onClick={() => setLevelFilter('Federal')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                levelFilter === 'Federal' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Federal MDA
            </button>
            <button
              onClick={() => setLevelFilter('State')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                levelFilter === 'State' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              State Government
            </button>
          </div>
        </div>

        {/* Search Bar & Category Filter horizontal scroll */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by service name, agency acronym (e.g. CAC, FRSC), or keyword..."
              className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#008751]"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === 'All'
                  ? 'bg-slate-900 text-white font-bold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Categories ({services.length})
            </button>

            {CATEGORIES_LIST.map((c) => (
              <button
                key={c.name}
                onClick={() => setSelectedCategory(c.name)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  selectedCategory === c.name
                    ? 'bg-[#008751] text-white font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Service Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredServices.map((service) => (
          <div 
            key={service.serviceId}
            className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:border-emerald-500 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-xs font-mono font-bold bg-[#005C36] text-white px-2.5 py-0.5 rounded uppercase">
                  {service.agency}
                </span>
                <span className="text-[11px] font-mono text-slate-500">
                  {service.governmentLevel}
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug">{service.name}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-3">{service.description}</p>

              {/* Requirements & Info */}
              <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                <div>
                  <span className="font-semibold text-slate-800">Eligibility: </span>
                  <span className="text-slate-600">{service.eligibility}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Documents: </span>
                  <span className="text-slate-600">{service.documentsRequired.join(', ')}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono block">Statutory Fee</span>
                <span className="text-sm font-bold text-slate-900 font-mono">
                  {service.feesNaira === 0 ? 'FREE / FREE TIER' : `₦${service.feesNaira.toLocaleString()}`}
                </span>
              </div>

              <button
                onClick={() => handleStartWorkflow(service)}
                className="px-4 py-2 bg-[#008751] hover:bg-[#006e40] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <span>Apply Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Workflow Runner Modal */}
      {activeWorkflowService && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 text-slate-900 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-[#004225] text-white flex items-center justify-between border-b border-[#D4AF37]">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-[#D4AF37] text-slate-950 text-[10px] font-bold font-mono px-2 py-0.5 rounded">
                    {activeWorkflowService.agency}
                  </span>
                  <span className="text-xs font-mono text-emerald-200">Ref: {activeWorkflowService.serviceId}</span>
                </div>
                <h3 className="text-lg font-bold mt-1 text-white">{activeWorkflowService.name}</h3>
              </div>

              <button 
                onClick={handleCloseWorkflow}
                className="p-1 text-slate-300 hover:text-white rounded-lg hover:bg-emerald-900 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Workflow Progress Steps Bar */}
            <div className="bg-slate-100 px-6 py-3 border-b border-slate-200 overflow-x-auto">
              <div className="flex items-center justify-between min-w-max gap-4 text-xs font-mono">
                {currentWorkflowSteps.map((step, sIdx) => {
                  const isActive = sIdx === currentStepIndex;
                  const isDone = sIdx < currentStepIndex || step.status === 'COMPLETED';

                  return (
                    <div key={step.stepId} className="flex items-center gap-2">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${
                        isDone ? 'bg-emerald-600 text-white' : isActive ? 'bg-[#008751] text-white ring-2 ring-emerald-300' : 'bg-slate-300 text-slate-600'
                      }`}>
                        {isDone ? '✓' : sIdx + 1}
                      </div>
                      <span className={`font-semibold ${isActive ? 'text-[#008751]' : isDone ? 'text-slate-800' : 'text-slate-400'}`}>
                        {step.title.split(' ')[0]}
                      </span>
                      {sIdx < currentWorkflowSteps.length - 1 && <span className="text-slate-300">→</span>}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Active Step Content Frame */}
            <div className="p-6 space-y-6">
              {!isSubmitted ? (
                <>
                  <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-xs space-y-1">
                    <h4 className="font-bold text-emerald-900 text-sm flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-700" />
                      Step {currentStepIndex + 1}: {currentWorkflowSteps[currentStepIndex].title}
                    </h4>
                    <p className="text-emerald-800">{currentWorkflowSteps[currentStepIndex].description}</p>
                  </div>

                  {/* Step 0: Identity */}
                  {currentStepIndex === 0 && (
                    <div className="space-y-4">
                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                        <p className="font-semibold text-slate-800">NIMC Identity Layer Authorization</p>
                        <p className="text-slate-600">Name: <strong className="text-slate-900">{profile.name}</strong></p>
                        <p className="text-slate-600">NIN: <strong className="font-mono text-slate-900">{profile.maskedNin}</strong></p>
                        <p className="text-slate-600">Biometric State: <strong className="text-emerald-700 font-bold">VERIFIED (NIMC HQ)</strong></p>
                      </div>
                      <button
                        onClick={handleProceedStep}
                        className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                      >
                        <span>Confirm Identity & Proceed</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Step 1: Eligibility */}
                  {currentStepIndex === 1 && (
                    <div className="space-y-4 text-xs">
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                        <p className="font-semibold text-slate-900">Statutory Eligibility Criteria</p>
                        <p className="text-slate-600">{activeWorkflowService.eligibility}</p>
                        <div className="pt-2 text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Citizen Profile satisfies all prerequisites for {activeWorkflowService.agency}.</span>
                        </div>
                      </div>
                      <button
                        onClick={handleProceedStep}
                        className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                      >
                        <span>Confirm Eligibility & Proceed</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Step 2: Documents */}
                  {currentStepIndex === 2 && (
                    <div className="space-y-4 text-xs">
                      <p className="font-semibold text-slate-800">Uploaded Encrypted Credentials:</p>
                      <div className="space-y-2">
                        {activeWorkflowService.documentsRequired.map((doc, idx) => (
                          <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-[#008751]" />
                              <span className="font-medium text-slate-800">{doc}</span>
                            </div>
                            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                              ENCRYPTED (KEYSTORE)
                            </span>
                          </div>
                        ))}
                      </div>
                      <button
                        onClick={handleProceedStep}
                        className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                      >
                        <span>Validate Documents & Proceed</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Step 3: Application Form */}
                  {currentStepIndex === 3 && (
                    <div className="space-y-4 text-xs">
                      <div className="space-y-3">
                        <div>
                          <label className="block text-slate-700 font-semibold mb-1">Applicant Name</label>
                          <input type="text" readOnly value={profile.name} className="w-full p-2.5 bg-slate-100 border border-slate-300 rounded-lg font-medium" />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-semibold mb-1">Service Details / Purpose</label>
                          <input 
                            type="text" 
                            placeholder="Enter purpose or specific location preference..." 
                            value={formData.purposeDetails || ''}
                            onChange={(e) => setFormData({ ...formData, purposeDetails: e.target.value })}
                            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg focus:border-[#008751] focus:outline-none" 
                          />
                        </div>
                      </div>
                      
                      <button
                        onClick={handleProceedStep}
                        className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                      >
                        <span>Save Form & Proceed to Payment</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Step 4: Statutory Fee Payment */}
                  {currentStepIndex === 4 && (
                    <div className="space-y-4 text-xs">
                      <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2 font-mono">
                        <div className="flex justify-between border-b border-slate-800 pb-2">
                          <span className="text-slate-400">Agency</span>
                          <span className="font-bold text-[#D4AF37]">{activeWorkflowService.agency}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-800 pb-2">
                          <span className="text-slate-400">Service Fee</span>
                          <span className="font-bold text-white">
                            {activeWorkflowService.feesNaira === 0 ? '₦0 (Statutory Waiver)' : `₦${activeWorkflowService.feesNaira.toLocaleString()}`}
                          </span>
                        </div>
                        <div className="flex justify-between pt-1 text-emerald-400 font-bold">
                          <span>Payment Gateway</span>
                          <span>CBN Remita / GaaS Mock</span>
                        </div>
                      </div>

                      {!isPaymentPaid ? (
                        <button
                          onClick={handleSimulatePayment}
                          className="w-full py-3.5 bg-[#D4AF37] hover:bg-[#c59c2b] text-slate-950 font-extrabold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                        >
                          <CreditCard className="w-4 h-4" />
                          <span>Simulate Payment Authorization (₦{activeWorkflowService.feesNaira.toLocaleString()})</span>
                        </button>
                      ) : (
                        <div className="p-3 bg-emerald-100 text-emerald-900 rounded-xl font-bold flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                            Payment Confirmed (Receipt #REC-2026-{activeWorkflowService.agency})
                          </span>
                          <button
                            onClick={handleProceedStep}
                            className="px-3 py-1 bg-[#008751] text-white text-xs rounded hover:bg-[#006e40]"
                          >
                            Proceed
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Step 5: Submission */}
                  {currentStepIndex === 5 && (
                    <div className="space-y-4 text-xs text-center py-4">
                      <div className="w-16 h-16 bg-emerald-100 text-[#008751] rounded-full flex items-center justify-center mx-auto">
                        <Sparkles className="w-8 h-8" />
                      </div>
                      <h4 className="text-lg font-bold text-slate-900">Ready to Submit to {activeWorkflowService.agency}</h4>
                      <p className="text-slate-600 max-w-md mx-auto">
                        Your application will be routed to the official agency SLA review engine. You will receive real-time updates in your Universal Inbox.
                      </p>

                      <button
                        onClick={handleFinalSubmit}
                        className="w-full py-4 bg-[#008751] hover:bg-[#006e40] text-white font-extrabold text-sm rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2"
                      >
                        <ShieldCheck className="w-5 h-5" />
                        <span>SUBMIT OFFICIAL APPLICATION</span>
                      </button>
                    </div>
                  )}
                </>
              ) : (
                /* Application Submitted Success State */
                <div className="py-6 space-y-6 text-center">
                  <div className="w-16 h-16 bg-emerald-600 text-white rounded-full flex items-center justify-center mx-auto shadow-lg">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div>
                    <span className="text-xs font-mono font-bold bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full uppercase">
                      APPLICATION RECEIVED & ROUTED
                    </span>
                    <h4 className="text-xl font-extrabold text-slate-900 mt-3">
                      Application Submitted Successfully
                    </h4>
                    <p className="text-xs text-slate-600 mt-1">
                      Submitted to <strong className="text-slate-900">{activeWorkflowService.agency}</strong> · Estimated Duration: <strong>{activeWorkflowService.estimatedDuration}</strong>
                    </p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl font-mono text-xs text-left space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Service:</span>
                      <span className="font-bold text-slate-900">{activeWorkflowService.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Digital Document ID:</span>
                      <span className="font-bold text-[#008751]">{issuedDocId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Verification QR:</span>
                      <span className="font-bold text-slate-900">{activeWorkflowService.agency}://VERIFY/2026/VALID</span>
                    </div>
                  </div>

                  <button
                    onClick={handleCloseWorkflow}
                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors"
                  >
                    View in Universal Inbox
                  </button>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
