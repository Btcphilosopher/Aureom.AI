'use client';

import React, { useState } from 'react';
import { 
  Lock, 
  ShieldCheck, 
  FileText, 
  QrCode, 
  Download, 
  Eye, 
  CheckCircle2, 
  Award, 
  Building2, 
  Car, 
  Receipt, 
  Plane, 
  HeartPulse, 
  X,
  ExternalLink
} from 'lucide-react';
import { DigitalDocument } from '@/lib/types';

interface DocumentWalletModalProps {
  documents: DigitalDocument[];
  onOpenDigitalId: () => void;
}

export const DocumentWalletModal: React.FC<DocumentWalletModalProps> = ({
  documents,
  onOpenDigitalId
}) => {
  const [selectedDoc, setSelectedDoc] = useState<DigitalDocument | null>(null);

  const getDocIcon = (type: string) => {
    if (type.includes('ID')) return ShieldCheck;
    if (type.includes('Driver')) return Car;
    if (type.includes('Tax')) return Receipt;
    if (type.includes('Business')) return Building2;
    if (type.includes('Passport')) return Plane;
    return FileText;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Wallet Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-[#008751] uppercase">Keystore Protected Vault</span>
            <span className="bg-slate-900 text-white text-[10px] font-mono px-2 py-0.5 rounded font-bold">
              ANDROID KEYSTORE ENCRYPTED
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">MY DIGITAL DOCUMENTS & CREDENTIALS</h2>
          <p className="text-xs text-slate-600 mt-1">
            Verifiable digital credentials issued by NIMC, FRSC, FIRS, CAC, NIS, and NHIA. Protected by hardware enclave security.
          </p>
        </div>

        <button
          onClick={onOpenDigitalId}
          className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#c59c2b] text-slate-950 font-bold text-xs rounded-xl shadow transition-colors flex items-center gap-2 font-mono"
        >
          <QrCode className="w-4 h-4" />
          <span>Present Digital Identity Card</span>
        </button>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {documents.map((doc) => {
          const Icon = getDocIcon(doc.documentType);
          const isVerified = doc.verificationState === 'VERIFIED';

          return (
            <div 
              key={doc.docId}
              className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:border-emerald-500 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#008751] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>

                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono flex items-center gap-1 ${
                    isVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    <ShieldCheck className="w-3 h-3" />
                    {doc.verificationState}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900">{doc.title}</h3>
                <p className="text-xs text-slate-500 font-mono mt-0.5">{doc.issuer}</p>

                {/* Metadata Summary */}
                <div className="mt-4 p-3 bg-slate-50 rounded-lg space-y-1.5 text-xs text-slate-700 font-mono">
                  {Object.entries(doc.metadata).slice(0, 3).map(([key, val]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-slate-500">{key}:</span>
                      <span className="font-semibold text-slate-900 truncate max-w-[150px]">{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">Expires: {doc.expiryDate}</span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedDoc(doc)}
                    className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-bold flex items-center gap-1 text-xs"
                    title="View Credential PDF & QR"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#008751]" />
                    <span>View</span>
                  </button>

                  <button
                    onClick={() => alert(`Downloading verified ${doc.title} signed payload...`)}
                    className="p-2 bg-[#008751] hover:bg-[#006e40] text-white rounded-lg font-bold flex items-center gap-1 text-xs"
                    title="Download Official PDF"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Document View Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative">
            
            <div className="px-6 py-4 bg-[#004225] text-white flex items-center justify-between border-b border-[#D4AF37]">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="text-sm font-bold font-mono uppercase">{selectedDoc.title}</h3>
              </div>

              <button 
                onClick={() => setSelectedDoc(null)}
                className="p-1 text-slate-300 hover:text-white rounded-lg hover:bg-emerald-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              
              {/* Document Certificate Sheet Simulation */}
              <div className="bg-white text-slate-900 p-6 rounded-2xl border-2 border-[#D4AF37] space-y-4 shadow-xl">
                <div className="text-center border-b border-slate-200 pb-3">
                  <span className="text-[9px] font-mono tracking-widest text-[#008751] font-bold uppercase block">FEDERAL REPUBLIC OF NIGERIA</span>
                  <h4 className="text-base font-extrabold text-slate-900 font-mono mt-0.5">{selectedDoc.issuer}</h4>
                  <p className="text-xs font-semibold text-slate-600 mt-0.5">{selectedDoc.title}</p>
                </div>

                <div className="space-y-2 text-xs font-mono">
                  {Object.entries(selectedDoc.metadata).map(([k, v]) => (
                    <div key={k} className="flex justify-between border-b border-slate-100 pb-1">
                      <span className="text-slate-500">{k}:</span>
                      <span className="font-bold text-slate-900">{v}</span>
                    </div>
                  ))}
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-500">Issue Date:</span>
                    <span className="font-semibold text-slate-900">{selectedDoc.issueDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Expiry Date:</span>
                    <span className="font-semibold text-slate-900">{selectedDoc.expiryDate}</span>
                  </div>
                </div>

                {/* QR Code Verification Footer */}
                <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-12 h-12 bg-slate-900 text-white p-1 rounded-lg flex items-center justify-center">
                      <QrCode className="w-10 h-10 text-[#D4AF37]" />
                    </div>
                    <div className="text-[10px] font-mono">
                      <p className="font-bold text-slate-900">VERIFIED CREDENTIAL</p>
                      <p className="text-slate-500 truncate max-w-[140px]">{selectedDoc.verificationQrCode}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold font-mono bg-emerald-100 text-emerald-800 px-2 py-1 rounded">
                    VALID
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => alert(`Official ${selectedDoc.title} PDF downloaded.`)}
                  className="flex-1 py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2 font-mono"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Verified PDF</span>
                </button>
                <button
                  onClick={() => setSelectedDoc(null)}
                  className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl"
                >
                  Close
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
};
