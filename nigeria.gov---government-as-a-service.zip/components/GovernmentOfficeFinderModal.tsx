'use client';

import React, { useState } from 'react';
import { MapPin, Phone, Clock, Navigation, Search, CheckCircle2, Building, ShieldCheck } from 'lucide-react';

interface OfficeLocation {
  id: string;
  name: string;
  agency: string;
  type: 'Federal' | 'State' | 'LGA';
  state: string;
  lga: string;
  address: string;
  openingHours: string;
  services: string[];
  contactPhone: string;
  isAccessible: boolean;
  isOpenNow: boolean;
}

export const MOCK_OFFICES: OfficeLocation[] = [
  {
    id: "OFF-LA-01",
    name: "NIMC State Headquarters & Enrolment Centre",
    agency: "NIMC",
    type: "Federal",
    state: "Lagos",
    lga: "Ikeja",
    address: "1 Obafemi Awolowo Way, Ikeja, Lagos State",
    openingHours: "Mon - Fri: 08:00 AM - 04:00 PM",
    services: ["NIN Enrolment", "Identity Modification", "Digital ID Verification"],
    contactPhone: "+234 800 646 2000",
    isAccessible: true,
    isOpenNow: true
  },
  {
    id: "OFF-LA-02",
    name: "FRSC Driver's Licence Centre (DLC Ojota)",
    agency: "FRSC",
    type: "Federal",
    state: "Lagos",
    lga: "Kosofe",
    address: "FRSC Sector Command, Ojota Interchange, Lagos",
    openingHours: "Mon - Fri: 08:00 AM - 04:00 PM",
    services: ["Driver's Licence Renewal", "Biometric Capture", "Vehicle Inspection"],
    contactPhone: "+234 700 225 53772",
    isAccessible: true,
    isOpenNow: true
  },
  {
    id: "OFF-LA-03",
    name: "NIS Passport Control Office (Alausa Command)",
    agency: "NIS",
    type: "Federal",
    state: "Lagos",
    lga: "Ikeja",
    address: "Mobolaji Johnson Avenue, Alausa, Ikeja, Lagos",
    openingHours: "Mon - Fri: 08:00 AM - 04:00 PM",
    services: ["International Passport Renewal", "Biometric Capture", "Visa Services"],
    contactPhone: "+234 800 225 5647",
    isAccessible: true,
    isOpenNow: true
  },
  {
    id: "OFF-LA-04",
    name: "FIRS Micro & Small Taxpayer Office (VI)",
    agency: "FIRS",
    type: "Federal",
    state: "Lagos",
    lga: "Eti-Osa",
    address: "24 Adeola Odeku Street, Victoria Island, Lagos",
    openingHours: "Mon - Fri: 08:00 AM - 05:00 PM",
    services: ["Tax Identification Number (TIN)", "Tax Clearance Certificates", "VAT Returns"],
    contactPhone: "+234 1 271 4000",
    isAccessible: true,
    isOpenNow: true
  },
  {
    id: "OFF-ABJ-01",
    name: "CAC Corporate Headquarters Abuja",
    agency: "CAC",
    type: "Federal",
    state: "FCT - Abuja",
    lga: "Municipal Area Council (AMAC)",
    address: "Plot 420 Tigris Crescent, Maitama, Abuja",
    openingHours: "Mon - Fri: 08:00 AM - 04:00 PM",
    services: ["Company Registration", "Name Reservation", "Annual Returns"],
    contactPhone: "+234 9 873 2222",
    isAccessible: true,
    isOpenNow: true
  }
];

interface GovernmentOfficeFinderModalProps {
  selectedState: string;
}

export const GovernmentOfficeFinderModal: React.FC<GovernmentOfficeFinderModalProps> = ({ selectedState }) => {
  const [filterAgency, setFilterAgency] = useState('All');
  const [filterSearch, setFilterSearch] = useState('');

  const filteredOffices = MOCK_OFFICES.filter(off => {
    const matchAgency = filterAgency === 'All' || off.agency === filterAgency;
    const matchSearch = !filterSearch || off.name.toLowerCase().includes(filterSearch.toLowerCase()) || off.address.toLowerCase().includes(filterSearch.toLowerCase());
    return matchAgency && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <span className="text-xs font-mono font-bold text-[#008751] uppercase">National Physical Infrastructure Directory</span>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">GOVERNMENT OFFICE FINDER & MAP</h2>
        <p className="text-xs text-slate-600 mt-1">
          Locate nearest NIMC enrolment centres, NIS passport offices, FRSC DLC hubs, and FIRS tax offices across {selectedState} State.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={filterSearch}
            onChange={(e) => setFilterSearch(e.target.value)}
            placeholder="Search office name or street address..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto text-xs font-mono">
          <button
            onClick={() => setFilterAgency('All')}
            className={`px-3 py-1.5 rounded-lg ${filterAgency === 'All' ? 'bg-[#008751] text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
          >
            All MDAs
          </button>
          <button
            onClick={() => setFilterAgency('NIMC')}
            className={`px-3 py-1.5 rounded-lg ${filterAgency === 'NIMC' ? 'bg-[#008751] text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
          >
            NIMC
          </button>
          <button
            onClick={() => setFilterAgency('FRSC')}
            className={`px-3 py-1.5 rounded-lg ${filterAgency === 'FRSC' ? 'bg-[#008751] text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
          >
            FRSC
          </button>
          <button
            onClick={() => setFilterAgency('NIS')}
            className={`px-3 py-1.5 rounded-lg ${filterAgency === 'NIS' ? 'bg-[#008751] text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
          >
            NIS Passport
          </button>
          <button
            onClick={() => setFilterAgency('FIRS')}
            className={`px-3 py-1.5 rounded-lg ${filterAgency === 'FIRS' ? 'bg-[#008751] text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
          >
            FIRS Tax
          </button>
        </div>
      </div>

      {/* Office Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredOffices.map((off) => (
          <div key={off.id} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="flex items-start justify-between gap-2">
              <span className="text-xs font-mono font-bold bg-slate-900 text-white px-2.5 py-0.5 rounded uppercase">
                {off.agency}
              </span>

              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                OPEN NOW ({off.openingHours.split(':')[1]}...)
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900">{off.name}</h3>

            <p className="text-xs text-slate-600 flex items-start gap-1.5">
              <MapPin className="w-4 h-4 text-[#008751] shrink-0 mt-0.5" />
              <span>{off.address}</span>
            </p>

            <div className="pt-2 text-xs space-y-1 text-slate-500 font-mono">
              <p>Services: {off.services.join(' · ')}</p>
              <p className="flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>Contact: {off.contactPhone}</span>
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] font-mono text-emerald-700 font-bold">
                ✓ Wheelchair Accessible
              </span>

              <button
                onClick={() => alert(`Launching Directions to ${off.name} (${off.address})...`)}
                className="px-3.5 py-1.5 bg-[#008751] hover:bg-[#006e40] text-white text-xs font-bold rounded-lg flex items-center gap-1 font-mono"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Directions</span>
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
