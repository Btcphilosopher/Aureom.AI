'use client';

import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, Globe, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'USER' | 'AI';
  text: string;
  language: string;
  timestamp: string;
}

export const GovGuideAiAssistantModal: React.FC = () => {
  const [language, setLanguage] = useState<'English' | 'Hausa' | 'Igbo' | 'Yoruba'>('English');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'AI',
      text: "Sannu / Sanu / Welcome to Ask Nigeria (GovGuide). How can I assist you with official Nigerian government services, CAC registration, FRSC driver's licence, FIRS tax, or NIS passports today?",
      language: 'English',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputPrompt.trim() || isLoading) return;

    const userText = inputPrompt.trim();
    setInputPrompt('');

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'USER',
      text: userText,
      language,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userText,
          language,
          history: messages.map(m => ({ role: m.sender === 'USER' ? 'user' : 'model', parts: [{ text: m.text }] }))
        })
      });

      const data = await res.json();
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'AI',
        text: data.text || "Sorry, I could not process your query at this moment. Please check services.gov.ng",
        language,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error("Chat error:", err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'AI',
        text: "System Notice: Unable to connect to GovGuide server. Please refer to NIGERIA.GOV Service Catalogue.",
        language,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-xs font-mono font-bold text-[#008751] uppercase">GovGuide AI Layer</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">ASK NIGERIA AI ASSISTANT</h2>
          <p className="text-xs text-slate-600 mt-0.5">
            AI government assistant grounded in official service catalogues. Grounded answers only.
          </p>
        </div>

        {/* Language Selector */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs font-mono">
          <Globe className="w-3.5 h-3.5 text-slate-500 ml-1" />
          {(['English', 'Hausa', 'Igbo', 'Yoruba'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => setLanguage(lang)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                language === lang ? 'bg-[#008751] text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Frame */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[500px]">
        
        {/* Messages Scroll Area */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex items-start gap-3 ${msg.sender === 'USER' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                msg.sender === 'USER' ? 'bg-slate-900 text-white' : 'bg-[#005C36] text-[#D4AF37]'
              }`}>
                {msg.sender === 'USER' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className={`max-w-xl rounded-2xl p-4 text-xs leading-relaxed space-y-2 ${
                msg.sender === 'USER' 
                  ? 'bg-[#008751] text-white rounded-tr-none' 
                  : 'bg-slate-50 border border-slate-200 text-slate-900 rounded-tl-none font-sans'
              }`}>
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div className={`text-[9px] font-mono text-right ${msg.sender === 'USER' ? 'text-emerald-200' : 'text-slate-400'}`}>
                  {msg.timestamp} · {msg.language}
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#005C36] text-[#D4AF37] flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-500 flex items-center gap-2 font-mono">
                <Loader2 className="w-4 h-4 animate-spin text-[#008751]" />
                <span>Consulting Federal Government Service Catalogue...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSendMessage} className="p-4 bg-slate-50 border-t border-slate-200 flex items-center gap-3">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder={`Ask in ${language} e.g. 'How do I start a business in Lagos?'`}
            className="flex-1 p-3 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:border-[#008751] focus:outline-none"
          />

          <button
            type="submit"
            disabled={isLoading || !inputPrompt.trim()}
            className="px-5 py-3 bg-[#008751] hover:bg-[#006e40] disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow font-mono"
          >
            <span>Ask</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

    </div>
  );
};
