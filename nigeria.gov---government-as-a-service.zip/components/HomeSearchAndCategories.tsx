'use client';

import React, { useState } from 'react';
import { 
  Search, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  ShieldCheck, 
  Building2, 
  Car, 
  Receipt, 
  GraduationCap, 
  HeartPulse, 
  Briefcase, 
  Home, 
  Users, 
  Plane, 
  Sprout, 
  Zap, 
  Scale, 
  Award,
  ChevronRight,
  Info
} from 'lucide-react';
import { GovernmentService, GovernmentApplication, GovernmentNotice } from '@/lib/types';

interface HomeSearchAndCategoriesProps {
  services: GovernmentService[];
  applications: GovernmentApplication[];
  notices: GovernmentNotice[];
  onSelectCategory: (cat: string) => void;
  onOpenServiceWorkflow: (service: GovernmentService) => void;
  onOpenApplicationDetails: (app: GovernmentApplication) => void;
  onOpenBusinessStarter: () => void;
  onOpenTaxPortal: () => void;
  onOpenTransportHub: () => void;
  onOpenPassportHub: () => void;
}

export const CATEGORIES_LIST = [
  { name: 'Identity', icon: ShieldCheck, color: 'text-emerald-700 bg-emerald-50' },
  { name: 'Tax', icon: Receipt, color: 'text-blue-700 bg-blue-50' },
  { name: 'Business', icon: Building2, color: 'text-purple-700 bg-purple-50' },
  { name: 'Transport', icon: Car, color: 'text-amber-700 bg-amber-50' },
  { name: 'Documents', icon: FileText, color: 'text-[#008751] bg-emerald-50' },
  { name: 'Education', icon: GraduationCap, color: 'text-indigo-700 bg-indigo-50' },
  { name: 'Health', icon: HeartPulse, color: 'text-red-700 bg-red-50' },
  { name: 'Jobs', icon: Briefcase, color: 'text-teal-700 bg-teal-50' },
  { name: 'Housing', icon: Home, color: 'text-stone-700 bg-stone-100' },
  { name: 'Social Support', icon: Users, color: 'text-rose-700 bg-rose-50' },
  { name: 'Immigration', icon: Plane, color: 'text-sky-700 bg-sky-50' },
  { name: 'Agriculture', icon: Sprout, color: 'text-lime-700 bg-lime-50' },
  { name: 'Utilities', icon: Zap, color: 'text-orange-700 bg-orange-50' },
  { name: 'Justice', icon: Scale, color: 'text-cyan-700 bg-cyan-50' },
  { name: 'Licences', icon: Award, color: 'text-amber-800 bg-amber-100' },
];

export const HomeSearchAndCategories: React.FC<HomeSearchAndCategoriesProps> = ({
  services,
  applications,
  notices,
  onSelectCategory,
  onOpenServiceWorkflow,
  onOpenApplicationDetails,
  onOpenBusinessStarter,
  onOpenTaxPortal,
  onOpenTransportHub,
  onOpenPassportHub
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Natural language mapping logic
  const getNaturalLanguageMatches = () => {
    if (!searchQuery.trim()) return [];

    const query = searchQuery.toLowerCase();
    
    if (query.includes('company') || query.includes('start a business') || query.includes('cac') || query.includes('incorporat')) {
      return [
        {
          title: "BUSINESS REGISTRATION PACKAGE (CAC + FIRS + BANKING)",
          matchedService: services.find(s => s.serviceId === "CAC-REG-001") || services[0],
          recommendations: [
            "CAC Business Registration (24h - 3 Days)",
            "Automated FIRS Tax Identification Number (TIN)",
            "Corporate Bank Account Opening Consent",
            "Federal Ministry of Industry Sector Licence"
          ],
          action: "Launch Business Starter Wizard",
          handler: onOpenBusinessStarter
        }
      ];
    }

    if (query.includes('driv') || query.includes('licence') || query.includes('frsc') || query.includes('vehicle')) {
      return [
        {
          title: "DRIVER'S LICENCE & TRANSPORT SERVICES",
          matchedService: services.find(s => s.serviceId === "FRSC-LIC-002") || services[1],
          recommendations: [
            "National Driver's Licence Renewal (FRSC)",
            "Biometric Verification & Vision Test",
            "Digital Driving Credential Store",
            "FRSC Vehicle Registration Verification"
          ],
          action: "Open Driver's Licence Workflow",
          handler: () => {
            const frsc = services.find(s => s.serviceId === "FRSC-LIC-002");
            if (frsc) onOpenServiceWorkflow(frsc);
          }
        }
      ];
    }

    if (query.includes('tax') || query.includes('tin') || query.includes('firs') || query.includes('clearance')) {
      return [
        {
          title: "TAXPAYER SERVICES & CERTIFICATES",
          matchedService: services.find(s => s.serviceId === "FIRS-TAX-003") || services[2],
          recommendations: [
            "Instant e-TIN Generation",
            "Annual PAYE / Income Tax Filing",
            "e-Tax Clearance Certificate (TCC 2026)",
            "Lagos / State Revenue Integration"
          ],
          action: "Open Tax Portal",
          handler: onOpenTaxPortal
        }
      ];
    }

    if (query.includes('passport') || query.includes('travel') || query.includes('visa') || query.includes('nis')) {
      return [
        {
          title: "PASSPORT & IMMIGRATION SERVICES",
          matchedService: services.find(s => s.serviceId === "NIS-PAS-005") || services[4],
          recommendations: [
            "International Passport Renewal (NIS)",
            "Passport Office Appointment Booking",
            "Biometric Data Capture Queue",
            "Guarantor & LGA Identity Slip"
          ],
          action: "Open Passport Application Hub",
          handler: onOpenPassportHub
        }
      ];
    }

    // Default search filtering over services
    return services
      .filter(s => s.name.toLowerCase().includes(query) || s.description.toLowerCase().includes(query) || s.agency.toLowerCase().includes(query) || s.category.toLowerCase().includes(query))
      .map(s => ({
        title: s.name,
        matchedService: s,
        recommendations: [s.description, `Agency: ${s.agency}`, `Fee: ₦${s.feesNaira.toLocaleString()}`],
        action: `Apply for ${s.name}`,
        handler: () => onOpenServiceWorkflow(s)
      }));
  };

  const matchedResults = getNaturalLanguageMatches();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10">
      
      {/* 1. Natural Language Search Section */}
      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-sm border border-slate-200">
        <div className="max-w-3xl mx-auto text-center space-y-3">
          <span className="text-xs font-mono font-bold tracking-widest text-[#008751] uppercase">
            Government Service Orchestration Layer
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            WHAT DO YOU NEED?
          </h2>
          <p className="text-sm text-slate-600">
            Describe what you want in simple language. The platform automatically maps your request to official MDAs, fees, and requirements.
          </p>

          <div className="relative mt-4">
            <div className="relative flex items-center">
              <Search className="absolute left-4 w-5 h-5 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search government services... e.g. 'I want to start a company' or 'renew driving licence'"
                className="w-full pl-12 pr-12 py-4 bg-slate-50 border-2 border-slate-200 focus:border-[#008751] focus:bg-white rounded-xl text-sm font-medium text-slate-900 placeholder-slate-400 focus:outline-none transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 text-xs font-bold text-slate-400 hover:text-slate-700 bg-slate-200 hover:bg-slate-300 px-2 py-1 rounded"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Quick Prompt Pill Recommendations */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-xs text-slate-500">
              <span className="font-semibold text-slate-600">Try:</span>
              <button 
                onClick={() => setSearchQuery('I want to start a company in Lagos')}
                className="hover:text-[#008751] hover:underline"
              >
                "I want to start a company"
              </button>
              <span>·</span>
              <button 
                onClick={() => setSearchQuery('I need to renew my driving licence')}
                className="hover:text-[#008751] hover:underline"
              >
                "Renew my driving licence"
              </button>
              <span>·</span>
              <button 
                onClick={() => setSearchQuery('Tax clearance certificate')}
                className="hover:text-[#008751] hover:underline"
              >
                "Tax clearance"
              </button>
            </div>
          </div>
        </div>

        {/* Search Results / Natural Language Orchestrator Box */}
        {searchQuery.trim() !== '' && (
          <div className="mt-8 pt-6 border-t border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 font-mono flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#008751]" />
                ORCHESTRATED MATCHES ({matchedResults.length})
              </h3>
              <span className="text-xs text-slate-500">Auto-mapped to CAC, FRSC, FIRS & NIMC APIs</span>
            </div>

            {matchedResults.length === 0 ? (
              <div className="p-6 bg-slate-50 rounded-xl text-center text-slate-600 text-sm">
                No exact match found for "{searchQuery}". Browse categories below or ask our <strong>Ask Nigeria AI</strong> assistant.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {matchedResults.map((res, idx) => (
                  <div key={idx} className="bg-slate-50 border border-slate-200 hover:border-[#008751] rounded-xl p-5 transition-all shadow-sm">
                    <span className="text-[10px] font-mono font-bold uppercase bg-[#008751] text-white px-2 py-0.5 rounded">
                      {res.matchedService.agency}
                    </span>
                    <h4 className="text-base font-bold text-slate-900 mt-2">{res.title}</h4>
                    
                    <ul className="mt-3 space-y-1 text-xs text-slate-600">
                      {res.recommendations.map((rec, rIdx) => (
                        <li key={rIdx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-mono">
                        Est: {res.matchedService.estimatedDuration}
                      </span>
                      <button
                        onClick={res.handler}
                        className="px-3.5 py-1.5 bg-[#008751] hover:bg-[#006e40] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <span>{res.action}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. Service Categories Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">GOVERNMENT CATEGORIES</h2>
            <p className="text-xs text-slate-500">Access single-window government functions across federal and state agencies</p>
          </div>
          <button 
            onClick={() => onSelectCategory('All')}
            className="text-xs font-bold text-[#008751] hover:underline flex items-center gap-1"
          >
            <span>View All Services</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 gap-3">
          {CATEGORIES_LIST.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.name}
                onClick={() => onSelectCategory(cat.name)}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-emerald-500 transition-all text-center group shadow-xs focus:outline-none focus:ring-2 focus:ring-[#008751]"
              >
                <div className={`w-10 h-10 rounded-xl ${cat.color} flex items-center justify-center mb-2 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-700 group-hover:text-slate-900 leading-tight">
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. YOUR APPLICATIONS Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">YOUR APPLICATIONS</h2>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-mono font-bold px-2 py-0.5 rounded-full">
              {applications.length} Active
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {applications.map((app) => {
            const isCompleted = app.status === 'APPROVED';
            const isAppointment = app.status === 'APPOINTMENT_REQUIRED';

            return (
              <div 
                key={app.applicationId}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded uppercase">
                      {app.agency}
                    </span>
                    <span className={`text-[11px] font-bold px-2 py-0.5 rounded font-mono ${
                      isCompleted 
                        ? 'bg-emerald-100 text-emerald-800'
                        : isAppointment
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-blue-100 text-blue-900'
                    }`}>
                      {app.status === 'AGENCY_REVIEW' ? 'IN PROGRESS' : app.status}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 line-clamp-1">{app.serviceName}</h3>
                  <p className="text-xs text-slate-500 mt-1 font-mono">Ref: {app.applicationId}</p>

                  {/* Stage & Progress Bar */}
                  <div className="mt-4 space-y-1.5">
                    <div className="flex justify-between text-xs text-slate-600">
                      <span className="font-medium text-slate-700">{app.currentStage}</span>
                      <span className="font-mono font-bold">{app.progressPercent}%</span>
                    </div>

                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${
                          isCompleted ? 'bg-emerald-600' : 'bg-[#008751]'
                        }`}
                        style={{ width: `${app.progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 flex items-center gap-1 font-mono">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Updated: {app.lastUpdate.split(' ')[0]}
                  </span>

                  <button
                    onClick={() => onOpenApplicationDetails(app)}
                    className="font-bold text-[#008751] hover:underline flex items-center gap-1"
                  >
                    <span>View Inbox</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. IMPORTANT GOVERNMENT NOTICES */}
      <div className="bg-emerald-950 text-white rounded-2xl p-6 md:p-8 shadow-md border border-emerald-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-lg font-bold font-mono tracking-tight text-white">IMPORTANT GOVERNMENT NOTICES</h2>
          </div>
          <span className="text-xs text-emerald-300 font-mono">Cryptographically Verified</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {notices.map((n) => (
            <div key={n.noticeId} className="bg-emerald-900/60 border border-emerald-700/60 rounded-xl p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-[11px] text-emerald-300 mb-2 font-mono">
                  <span className="font-bold text-[#D4AF37]">{n.verifiedAgency}</span>
                  <span>{n.publicationDate}</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-2 leading-snug">{n.title}</h4>
                <p className="text-xs text-emerald-200/90 leading-relaxed line-clamp-3">{n.summary}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-emerald-800/80 flex items-center justify-between text-[11px]">
                <span className="text-emerald-300 font-mono">Category: {n.category}</span>
                <a 
                  href={n.sourceUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#D4AF37] hover:underline font-bold flex items-center gap-1"
                >
                  <span>Official Notice</span>
                  <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
