'use client';

import React from 'react';
import { 
  Building2, 
  ShieldCheck, 
  FileText, 
  Search, 
  Sparkles, 
  Zap, 
  MapPin, 
  UserCheck, 
  AlertTriangle, 
  Terminal,
  Activity,
  Layers,
  ChevronDown
} from 'lucide-react';
import { NIGERIAN_STATES } from '@/lib/data/statesData';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedState: string;
  setSelectedState: (state: string) => void;
  selectedLga: string;
  setSelectedLga: (lga: string) => void;
  isLowDataMode: boolean;
  setIsLowDataMode: (val: boolean) => void;
  onOpenDevConsole: () => void;
  onOpenEmergency: () => void;
  onOpenDigitalId: () => void;
  mode: 'CITIZEN' | 'OFFICIAL';
  setMode: (m: 'CITIZEN' | 'OFFICIAL') => void;
  coatOfArmsUrl: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  selectedState,
  setSelectedState,
  selectedLga,
  setSelectedLga,
  isLowDataMode,
  setIsLowDataMode,
  onOpenDevConsole,
  onOpenEmergency,
  onOpenDigitalId,
  mode,
  setMode,
  coatOfArmsUrl
}) => {
  const [showStateDropdown, setShowStateDropdown] = React.useState(false);

  const currentStateObj = NIGERIAN_STATES.find(s => s.name === selectedState) || NIGERIAN_STATES[23]; // Default Lagos

  return (
    <header className="sticky top-0 z-40 bg-[#005C36] text-white border-b-2 border-[#D4AF37] shadow-lg">
      {/* Top Federal Strip */}
      <div className="bg-[#004225] px-4 py-1 text-xs font-mono text-[#D4AF37] flex items-center justify-between border-b border-[#006E40]">
        <div className="flex items-center gap-3 truncate">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
          <span className="font-bold tracking-widest text-[#F8FAF9]">FEDERAL REPUBLIC OF NIGERIA</span>
          <span className="text-emerald-300 hidden sm:inline">| NATIONAL DIGITAL PUBLIC INFRASTRUCTURE</span>
        </div>

        <div className="flex items-center gap-3 shrink-0 text-xs">
          {/* View Mode Switcher */}
          <button
            onClick={() => setMode(mode === 'CITIZEN' ? 'OFFICIAL' : 'CITIZEN')}
            className={`px-2.5 py-0.5 rounded text-[11px] font-semibold transition-colors flex items-center gap-1.5 ${
              mode === 'OFFICIAL' 
                ? 'bg-[#D4AF37] text-slate-950 font-bold' 
                : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
            }`}
          >
            <Layers className="w-3 h-3" />
            {mode === 'CITIZEN' ? 'Official Admin Portal' : 'Return to Citizen View'}
          </button>

          {/* Dev Mode Button */}
          <button 
            onClick={onOpenDevConsole}
            className="text-emerald-200 hover:text-white transition-colors flex items-center gap-1 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-700/50"
            title="Open Developer Simulation Console"
          >
            <Terminal className="w-3 h-3" />
            <span className="hidden md:inline">Dev Mode</span>
          </button>
        </div>
      </div>

      {/* Main 3-Zone Header Contract */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={onOpenDigitalId} 
            className="relative group focus:outline-none focus:ring-2 focus:ring-[#D4AF37] rounded-lg p-0.5"
            title="Click to view National Digital ID"
          >
            <div className="w-10 h-10 rounded-lg overflow-hidden border border-[#D4AF37]/60 bg-[#004225] flex items-center justify-center shadow-inner">
              <img 
                src={coatOfArmsUrl} 
                alt="Nigeria Coat of Arms" 
                className="w-full h-full object-cover" 
                referrerPolicy="no-referrer"
                onError={(e) => {
                  // Fallback to SVG if image fails
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <Building2 className="w-6 h-6 text-[#D4AF37] hidden" />
            </div>
            <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-[9px] font-bold text-slate-950 px-1 rounded-full border border-slate-900">
              ✓
            </span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-extrabold tracking-tight text-white font-mono">NIGERIA.GOV</span>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-[#D4AF37] text-slate-950 px-1.5 py-0.2 rounded font-mono">
                GaaS
              </span>
            </div>
            <p className="text-[11px] text-emerald-200 font-medium tracking-wide">Government as a Service OS</p>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 font-medium text-sm text-emerald-100">
          <button
            onClick={() => setActiveTab('home')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'home' ? 'bg-[#004225] text-white font-semibold border-b-2 border-[#D4AF37]' : 'hover:bg-emerald-800/40 hover:text-white'
            }`}
          >
            My Government
          </button>

          <button
            onClick={() => setActiveTab('catalogue')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'catalogue' ? 'bg-[#004225] text-white font-semibold border-b-2 border-[#D4AF37]' : 'hover:bg-emerald-800/40 hover:text-white'
            }`}
          >
            <Search className="w-4 h-4 text-emerald-300" />
            Service Catalogue
          </button>

          <button
            onClick={() => setActiveTab('inbox')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'inbox' ? 'bg-[#004225] text-white font-semibold border-b-2 border-[#D4AF37]' : 'hover:bg-emerald-800/40 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-300" />
            Applications & Wallet
          </button>

          <button
            onClick={() => setActiveTab('opengov')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'opengov' ? 'bg-[#004225] text-white font-semibold border-b-2 border-[#D4AF37]' : 'hover:bg-emerald-800/40 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-300" />
            Open Gov & Projects
          </button>

          <button
            onClick={() => setActiveTab('ai')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 bg-emerald-950/40 border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-slate-950`}
          >
            <Sparkles className="w-4 h-4" />
            Ask Nigeria AI
          </button>
        </nav>

        {/* Zone 3: Actions & Personalization */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Low Data Mode Toggle */}
          <button
            onClick={() => setIsLowDataMode(!isLowDataMode)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
              isLowDataMode
                ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                : 'bg-emerald-950/30 text-emerald-200 border-emerald-700 hover:bg-emerald-900/50'
            }`}
            title="Toggle Low Bandwidth Data Saver Mode"
          >
            <Zap className={`w-3.5 h-3.5 ${isLowDataMode ? 'text-amber-300 fill-amber-300' : ''}`} />
            <span className="hidden sm:inline">{isLowDataMode ? 'Low Data ON' : 'Low Data'}</span>
          </button>

          {/* Location State & LGA Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowStateDropdown(!showStateDropdown)}
              className="px-3 py-1.5 bg-[#004225] text-emerald-100 hover:text-white rounded-lg border border-emerald-700 text-xs font-medium flex items-center gap-1.5"
            >
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="font-semibold text-white">{selectedState}</span>
              <span className="text-emerald-300 text-[10px] hidden sm:inline">({selectedLga})</span>
              <ChevronDown className="w-3.5 h-3.5 text-emerald-300" />
            </button>

            {showStateDropdown && (
              <div className="absolute right-0 mt-2 w-72 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 p-3 z-50">
                <p className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider mb-2 font-mono">State Jurisdiction</p>
                <div className="space-y-2">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">State / FCT</label>
                    <select
                      value={selectedState}
                      onChange={(e) => {
                        const newSt = e.target.value;
                        setSelectedState(newSt);
                        const stObj = NIGERIAN_STATES.find(s => s.name === newSt);
                        if (stObj && stObj.lgas.length > 0) {
                          setSelectedLga(stObj.lgas[0]);
                        }
                      }}
                      className="w-full bg-slate-800 text-white text-xs rounded-lg p-2 border border-slate-700 focus:outline-none focus:border-[#008751]"
                    >
                      {NIGERIAN_STATES.map((s) => (
                        <option key={s.name} value={s.name}>{s.name} {s.capital ? `(${s.capital})` : ''}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Local Government Area (LGA)</label>
                    <select
                      value={selectedLga}
                      onChange={(e) => setSelectedLga(e.target.value)}
                      className="w-full bg-slate-800 text-white text-xs rounded-lg p-2 border border-slate-700 focus:outline-none focus:border-[#008751]"
                    >
                      {currentStateObj.lgas.map((lga) => (
                        <option key={lga} value={lga}>{lga}</option>
                      ))}
                    </select>
                  </div>

                  <div className="pt-2 border-t border-slate-800 text-[10px] text-emerald-300 flex items-center justify-between">
                    <span>Federal + {selectedState} Adapters</span>
                    <button 
                      onClick={() => setShowStateDropdown(false)}
                      className="text-[#D4AF37] hover:underline font-bold"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Emergency Red Trigger */}
          <button
            onClick={onOpenEmergency}
            className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg shadow transition-colors flex items-center gap-1.5"
            title="Emergency Mode Services (Police, Ambulance, Fire, NEMA)"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-white" />
            <span className="hidden sm:inline">Emergency</span>
          </button>
        </div>
      </div>
    </header>
  );
};
