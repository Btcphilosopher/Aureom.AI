'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  ShieldCheck, 
  FileText, 
  Briefcase, 
  Receipt, 
  Award, 
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { GovernmentService } from '@/lib/types';
import { NIGERIAN_STATES } from '@/lib/data/statesData';

interface BusinessStarterModalProps {
  onOpenServiceWorkflow: (service: GovernmentService) => void;
  services: GovernmentService[];
}

export const BusinessStarterModal: React.FC<BusinessStarterModalProps> = ({
  onOpenServiceWorkflow,
  services
}) => {
  const [entityType, setEntityType] = useState<'INDIVIDUAL' | 'COMPANY'>('COMPANY');
  const [stateSelection, setStateSelection] = useState('Lagos');
  const [industry, setIndustry] = useState('Technology & Digital Economy');
  const [hasEmployees, setHasEmployees] = useState(true);
  const [isImportExport, setIsImportExport] = useState(false);
  const [isGenerated, setIsGenerated] = useState(false);

  const getChecklistItems = () => {
    return [
      {
        step: 1,
        title: "CAC Business Registration",
        agency: "CAC",
        desc: entityType === 'COMPANY' ? "Private Limited Company (LTD) Incorporation" : "Business Name Registration",
        required: true,
        status: "RECOMMENDED",
        serviceId: "CAC-REG-001"
      },
      {
        step: 2,
        title: "Federal Tax Identification Number (TIN)",
        agency: "FIRS",
        desc: "Automated e-TIN issuance & VAT registration for corporate transactions",
        required: true,
        status: "RECOMMENDED",
        serviceId: "FIRS-TAX-003"
      },
      {
        step: 3,
        title: `${stateSelection} State Trade & Local Permit`,
        agency: `${stateSelection} Ministry of Commerce`,
        desc: `State government local business premises registration in ${stateSelection}`,
        required: true,
        status: "REQUIRED_STATE",
        serviceId: "CAC-REG-001"
      },
      {
        step: 4,
        title: "Federal Procurement Database (BPP)",
        agency: "BPP",
        desc: "Federal Contractor & Supplier database registration for government tenders",
        required: false,
        status: "OPTIONAL_GOV",
        serviceId: "BPP-CON-006"
      },
      ...(hasEmployees ? [{
        step: 5,
        title: "Employer Compliance (PENCOM & ITF)",
        agency: "PENCOM / ITF",
        desc: "Mandatory pension and industrial training fund employer compliance",
        required: true,
        status: "EMPLOYER_MANDATORY",
        serviceId: "CAC-REG-001"
      }] : []),
      ...(isImportExport ? [{
        step: 6,
        title: "Nigerian Customs Service (NCS) Import/Export Code",
        agency: "NCS",
        desc: "Trade portal registration for international maritime and air cargo clearance",
        required: true,
        status: "TRADE_MANDATORY",
        serviceId: "CAC-REG-001"
      }] : [])
    ];
  };

  const checklist = getChecklistItems();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold text-[#008751] uppercase">Guided Business Starter Engine</span>
          <span className="bg-purple-100 text-purple-900 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
            CAC + FIRS + BPP COMPLIANCE GRAPH
          </span>
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">START A BUSINESS IN NIGERIA</h2>
        <p className="text-xs text-slate-600 mt-1">
          Answer a few questions to generate your tailor-made Government Compliance Checklist across CAC, FIRS, state permits, and sector licences.
        </p>
      </div>

      {/* Guided Wizard Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          <h3 className="text-sm font-bold font-mono text-slate-900 border-b border-slate-100 pb-2">
            1. BUSINESS PARAMETERS
          </h3>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Structure Type</label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setEntityType('COMPANY')}
                className={`p-3 rounded-xl border text-center font-bold transition-all ${
                  entityType === 'COMPANY' 
                    ? 'border-[#008751] bg-emerald-50 text-[#008751]' 
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Limited Company (LTD)
              </button>
              <button
                type="button"
                onClick={() => setEntityType('INDIVIDUAL')}
                className={`p-3 rounded-xl border text-center font-bold transition-all ${
                  entityType === 'INDIVIDUAL' 
                    ? 'border-[#008751] bg-emerald-50 text-[#008751]' 
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Business Name / Enterprise
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Primary Operating State</label>
            <select
              value={stateSelection}
              onChange={(e) => setStateSelection(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#008751]"
            >
              {NIGERIAN_STATES.map(s => (
                <option key={s.name} value={s.name}>{s.name} State</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Industry Sector</label>
            <select
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#008751]"
            >
              <option value="Technology & Digital Economy">Technology & Digital Economy</option>
              <option value="Agriculture & Food Processing">Agriculture & Food Processing</option>
              <option value="Commerce & Retail Trade">Commerce & Retail Trade</option>
              <option value="Healthcare & Pharmaceuticals">Healthcare & Pharmaceuticals</option>
              <option value="Construction & Real Estate">Construction & Real Estate</option>
              <option value="Financial Services & Fintech">Financial Services & Fintech</option>
            </select>
          </div>

          <div className="space-y-3 pt-2">
            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium cursor-pointer">
              <input 
                type="checkbox" 
                checked={hasEmployees} 
                onChange={(e) => setHasEmployees(e.target.checked)}
                className="w-4 h-4 rounded text-[#008751] focus:ring-[#008751]"
              />
              <span>Will employ 3+ staff (Triggers PENCOM pension compliance)</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium cursor-pointer">
              <input 
                type="checkbox" 
                checked={isImportExport} 
                onChange={(e) => setIsImportExport(e.target.checked)}
                className="w-4 h-4 rounded text-[#008751] focus:ring-[#008751]"
              />
              <span>Engaging in international import/export trade</span>
            </label>
          </div>

          <button
            onClick={() => setIsGenerated(true)}
            className="w-full py-3.5 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>GENERATE COMPLIANCE CHECKLIST</span>
          </button>
        </div>

        {/* Dynamic Checklist Results */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold font-mono text-slate-900">2. YOUR GOVERNMENT CHECKLIST</h3>
              <p className="text-xs text-slate-500">Tailored requirements for {industry} in {stateSelection} State</p>
            </div>
            <span className="text-xs font-mono font-bold bg-purple-100 text-purple-900 px-2.5 py-1 rounded-full">
              {checklist.length} Steps Identified
            </span>
          </div>

          <div className="space-y-3">
            {checklist.map((item) => (
              <div 
                key={item.step}
                className="p-4 bg-slate-50 rounded-xl border border-slate-200 hover:border-purple-300 transition-all flex items-start justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-mono text-[10px] font-bold flex items-center justify-center">
                      {item.step}
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-900 bg-slate-200 px-2 py-0.5 rounded">
                      {item.agency}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">{item.title}</h4>
                  </div>
                  <p className="text-xs text-slate-600 pl-7">{item.desc}</p>
                </div>

                <button
                  onClick={() => {
                    const matched = services.find(s => s.serviceId === item.serviceId) || services[0];
                    onOpenServiceWorkflow(matched);
                  }}
                  className="shrink-0 px-3 py-1.5 bg-[#008751] hover:bg-[#006e40] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
                >
                  <span>Start Step</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

        </div>
      </div>

    </div>
  );
};
