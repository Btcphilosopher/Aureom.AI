'use client';

import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, FileText, CheckCircle2, Lock, Upload, EyeOff, X } from 'lucide-react';
import { FraudReport } from '@/lib/types';

interface WhistleblowerModalProps {
  reports: FraudReport[];
  onAddNewReport: (rep: FraudReport) => void;
}

export const WhistleblowerModal: React.FC<WhistleblowerModalProps> = ({
  reports,
  onAddNewReport
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'FEEDBACK' | 'FRAUD'>('FEEDBACK');
  const [agencyTarget, setAgencyTarget] = useState('FRSC');
  const [category, setCategory] = useState<'Bribery / Corruption' | 'Impersonation' | 'Extortion' | 'Identity Theft' | 'Fake Document' | 'Other'>('Bribery / Corruption');
  const [description, setDescription] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [submittedCaseId, setSubmittedCaseId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    const caseId = `CASE-NG-${Math.floor(100000 + Math.random() * 900000)}`;
    const newRep: FraudReport = {
      reportId: `REP-${Math.floor(1000 + Math.random() * 9000)}`,
      caseId,
      agencyTarget,
      category,
      description,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      anonymous: isAnonymous,
      status: 'RECEIVED',
      evidenceCount: 1
    };

    onAddNewReport(newRep);
    setSubmittedCaseId(caseId);
    setDescription('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <span className="text-xs font-mono font-bold text-red-700 uppercase">Anti-Corruption & Transparency Portal</span>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">CITIZEN FEEDBACK & WHISTLEBLOWER</h2>
        <p className="text-xs text-slate-600 mt-1">
          Report service delays, extortion, bribery, or misconduct. Reports receive official Case IDs for public tracking and ICPC / EFCC oversight.
        </p>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveSubTab('FEEDBACK')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeSubTab === 'FEEDBACK' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Report Service Problem / Delay
        </button>
        <button
          onClick={() => setActiveSubTab('FRAUD')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeSubTab === 'FRAUD' ? 'bg-red-700 text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Report Corruption / Extortion (Whistleblower)
        </button>
      </div>

      {/* Warning Banner */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
        <p className="font-bold flex items-center gap-1.5 text-amber-900">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
          Emergency Warning
        </p>
        <p className="text-amber-800">
          For immediate life-threatening physical emergencies or active crimes, please use the <strong>Emergency Mode</strong> trigger in the top bar to connect directly to 112 Police / NEMA Hotline.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Report Submission Form */}
        <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          <h3 className="text-sm font-bold font-mono text-slate-900 border-b border-slate-100 pb-2">
            SUBMIT NEW CASE ({activeSubTab})
          </h3>

          {!submittedCaseId ? (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Government Agency</label>
                <select 
                  value={agencyTarget} 
                  onChange={(e) => setAgencyTarget(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="FRSC">FRSC (Federal Road Safety Corps)</option>
                  <option value="NIS">NIS (Nigerian Immigration Service)</option>
                  <option value="NIMC">NIMC (National Identity Management Commission)</option>
                  <option value="FIRS">FIRS (Federal Inland Revenue Service)</option>
                  <option value="CAC">CAC (Corporate Affairs Commission)</option>
                  <option value="Customs">Nigerian Customs Service</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category</label>
                <select 
                  value={category} 
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="Bribery / Corruption">Bribery / Illegal Demands</option>
                  <option value="Extortion">Extortion or Unofficial Surcharges</option>
                  <option value="Impersonation">Fake Officials / Impersonation</option>
                  <option value="Fake Document">Fake Document / Certificate Issuance</option>
                  <option value="Identity Theft">Identity Theft Concern</option>
                  <option value="Other">Service Delay / Staff Conduct</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Detailed Description & Evidence</label>
                <textarea 
                  rows={4}
                  required
                  placeholder="Provide date, office location, staff badge or desk description, and incident details..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:border-[#008751] focus:outline-none"
                />
              </div>

              {activeSubTab === 'FRAUD' && (
                <div className="p-3 bg-slate-900 text-white rounded-xl space-y-2">
                  <label className="flex items-center gap-2 text-xs font-mono cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={isAnonymous} 
                      onChange={(e) => setIsAnonymous(e.target.checked)}
                      className="w-4 h-4 rounded text-red-600 focus:ring-red-600"
                    />
                    <span className="font-bold text-red-400">ANONYMOUS WHISTLEBLOWER PROTECTION</span>
                  </label>
                  <p className="text-[10px] text-slate-400">
                    When checked, citizen NIN and personal contact details are completely stripped from the report before reaching agency investigators.
                  </p>
                </div>
              )}

              <button
                type="submit"
                className={`w-full py-3.5 text-white font-bold text-xs rounded-xl shadow transition-colors font-mono ${
                  activeSubTab === 'FRAUD' ? 'bg-red-700 hover:bg-red-800' : 'bg-[#008751] hover:bg-[#006e40]'
                }`}
              >
                SUBMIT REPORT & GENERATE CASE ID
              </button>
            </form>
          ) : (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-[#008751] mx-auto" />
              <h4 className="text-base font-extrabold text-slate-900">Report Registered</h4>
              <p className="text-xs text-slate-600">Your report has been logged and assigned an official tracking case reference.</p>
              
              <div className="p-3 bg-white rounded-xl border border-emerald-300 font-mono text-xs">
                <span className="text-slate-400 block">CASE ID:</span>
                <span className="text-lg font-bold text-[#008751]">{submittedCaseId}</span>
              </div>

              <button
                onClick={() => setSubmittedCaseId(null)}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
              >
                Submit Another Case
              </button>
            </div>
          )}
        </div>

        {/* Existing Cases List */}
        <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-sm font-bold font-mono text-slate-900">YOUR FILED REPORTS ({reports.length})</h3>
            <span className="text-xs text-slate-500 font-mono">Traceable Audit Registry</span>
          </div>

          <div className="space-y-3">
            {reports.map((rep) => (
              <div key={rep.reportId} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-900">{rep.caseId}</span>
                  <span className="bg-blue-100 text-blue-800 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                    {rep.status}
                  </span>
                </div>

                <div className="flex items-center gap-2 font-mono text-slate-500">
                  <span className="font-bold text-slate-800">{rep.agencyTarget}</span>
                  <span>·</span>
                  <span>{rep.category}</span>
                </div>

                <p className="text-slate-700 line-clamp-2">{rep.description}</p>
                <p className="text-[10px] text-slate-400 font-mono">Logged: {rep.timestamp} {rep.anonymous ? '(Anonymous Protected)' : ''}</p>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
