'use client';

import React from 'react';
import { ShieldCheck, UserCheck, MapPin, QrCode, Building, Award, ArrowRight } from 'lucide-react';
import { CitizenProfile } from '@/lib/types';

interface HeaderBannerProps {
  profile: CitizenProfile;
  selectedState: string;
  selectedLga: string;
  onOpenDigitalId: () => void;
  onOpenConsent: () => void;
  heroImgUrl: string;
  avatarUrl: string;
}

export const HeaderBanner: React.FC<HeaderBannerProps> = ({
  profile,
  selectedState,
  selectedLga,
  onOpenDigitalId,
  onOpenConsent,
  heroImgUrl,
  avatarUrl
}) => {
  return (
    <div className="relative bg-[#005C36] text-white overflow-hidden shadow-xl border-b border-[#D4AF37]/40">
      {/* Background Hero Image overlay */}
      <div className="absolute inset-0 z-0 opacity-20 bg-cover bg-center pointer-events-none" style={{ backgroundImage: `url(${heroImgUrl})` }}>
        <div className="absolute inset-0 bg-gradient-to-r from-[#003820] via-[#005C36]/90 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-8 md:py-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Left Greeting & Citizen Profile Summary */}
          <div className="flex items-center gap-5">
            <button 
              onClick={onOpenDigitalId}
              className="relative group shrink-0 focus:outline-none focus:ring-4 focus:ring-[#D4AF37] rounded-full transition-transform transform hover:scale-105"
            >
              <div className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-2 border-[#D4AF37] shadow-lg bg-slate-800">
                <img 
                  src={avatarUrl} 
                  alt={profile.name} 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-slate-950 p-1 rounded-full border border-slate-900 shadow" title="NIN Verified">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </button>

            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="text-xs font-mono tracking-widest text-[#D4AF37] uppercase font-bold">
                  Federal Republic of Nigeria
                </span>
                <span className="text-slate-400">·</span>
                <span className="bg-emerald-950/80 text-emerald-300 text-[11px] font-mono font-bold px-2 py-0.5 rounded border border-emerald-700/60 flex items-center gap-1">
                  <UserCheck className="w-3 h-3 text-emerald-400" />
                  NIN Verified ({profile.maskedNin})
                </span>
              </div>

              <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
                Good morning, {profile.name.split(' ')[0]}
              </h1>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-emerald-100/90 font-medium">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{selectedState} State</span>
                  <span className="text-emerald-300">({selectedLga} LGA)</span>
                </span>
                <span className="hidden sm:inline text-emerald-400/60">·</span>
                <span>NIMC ID State: <strong className="text-white">{profile.identityState}</strong></span>
                <span className="hidden sm:inline text-emerald-400/60">·</span>
                <span>TIN: <span className="font-mono text-[#D4AF37]">23091823-0001</span></span>
              </div>
            </div>
          </div>

          {/* Right Digital ID & Consent Quick Launch Buttons */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={onOpenDigitalId}
              className="flex-1 md:flex-initial px-4 py-3 bg-[#D4AF37] hover:bg-[#c59c2b] text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 border border-yellow-300/40"
            >
              <QrCode className="w-4 h-4 text-slate-950" />
              <span>NIGERIA DIGITAL ID</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-80" />
            </button>

            <button
              onClick={onOpenConsent}
              className="flex-1 md:flex-initial px-4 py-3 bg-emerald-900/60 hover:bg-emerald-800 text-white font-semibold text-xs rounded-xl border border-emerald-700/80 transition-all flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              <span>Data Consent Vault</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
