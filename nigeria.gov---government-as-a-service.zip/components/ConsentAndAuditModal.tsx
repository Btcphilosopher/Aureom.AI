'use client';

import React from 'react';
import { ShieldCheck, Lock, Key, Clock, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { DataConsentPermission, AuditLogEntry } from '@/lib/types';

interface ConsentAndAuditModalProps {
  permissions: DataConsentPermission[];
  auditLogs: AuditLogEntry[];
  onTogglePermission: (agencyId: string) => void;
}

export const ConsentAndAuditModal: React.FC<ConsentAndAuditModalProps> = ({
  permissions,
  auditLogs,
  onTogglePermission
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <span className="text-xs font-mono font-bold text-[#008751] uppercase">NDPA Data Privacy & Transparency</span>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">WHO HAS MY DATA? (CONSENT & AUDIT TRAIL)</h2>
        <p className="text-xs text-slate-600 mt-1">
          Explicit consent management under Nigeria Data Protection Act (NDPA). View, grant, or revoke agency access to your digital profile.
        </p>
      </div>

      {/* 1. Consent Centre */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-bold font-mono text-slate-900">ACTIVE DATA SHARING CONSENTS</h3>
          <span className="text-xs font-mono text-slate-500">Zero-Trust Boundaries</span>
        </div>

        <div className="space-y-3">
          {permissions.map((p) => {
            const isActive = p.status === 'ACTIVE';

            return (
              <div key={p.agencyId} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:between justify-between gap-4 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{p.agencyName}</span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {p.status}
                    </span>
                  </div>
                  <p className="text-slate-600 font-mono mt-1">Purpose: {p.purpose}</p>
                  <p className="text-slate-500 mt-0.5">Scope: {p.scope}</p>
                </div>

                <button
                  onClick={() => onTogglePermission(p.agencyId)}
                  className={`px-4 py-2 font-bold font-mono text-xs rounded-lg transition-colors ${
                    isActive 
                      ? 'bg-red-600 hover:bg-red-700 text-white' 
                      : 'bg-[#008751] hover:bg-[#006e40] text-white'
                  }`}
                >
                  {isActive ? 'REVOKE ACCESS' : 'GRANT CONSENT'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Audit Trail */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-bold font-mono text-slate-900">CITIZEN DIGITAL AUDIT LOG</h3>
          <span className="text-xs font-mono text-slate-500">Append-Only Immutable Log</span>
        </div>

        <div className="space-y-2 font-mono text-xs">
          {auditLogs.map((log) => (
            <div key={log.logId} className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">{log.timestamp}</span>
                  <span className="font-bold text-[#008751]">{log.action}</span>
                </div>
                <p className="text-slate-600">{log.actor} · {log.agency} · {log.purpose}</p>
              </div>

              <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[10px]">
                {log.result}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
