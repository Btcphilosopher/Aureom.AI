'use client';

import React from 'react';
import { AlertTriangle, Phone, ShieldAlert, X, HeartPulse, Flame, Building2 } from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedState: string;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  selectedState
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-red-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-red-600 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative">
        
        {/* Header */}
        <div className="px-6 py-4 bg-red-700 text-white flex items-center justify-between border-b border-red-600">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-yellow-300" />
            <div>
              <h3 className="font-extrabold text-base font-mono tracking-wider">NATIONAL EMERGENCY RESPONSE</h3>
              <p className="text-[10px] text-red-100 font-mono">Federal & State Emergency Dispatch ({selectedState} State)</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-red-100 hover:text-white rounded-lg hover:bg-red-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          
          <div className="p-3 bg-red-950 border border-red-800 rounded-xl text-xs text-red-200 font-mono text-center">
            FOR IMMEDIATE LIFE-THREATENING EMERGENCY SITUATIONS
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">National Emergency Helpline</h4>
                  <p className="text-slate-400 text-[10px]">Toll-Free Nationwide (Police, Fire, Ambulance)</p>
                </div>
              </div>
              <a href="tel:112" className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-lg text-sm">
                112
              </a>
            </div>

            <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">Nigeria Police Force Control</h4>
                  <p className="text-slate-400 text-[10px]">Federal Headquarters Dispatch</p>
                </div>
              </div>
              <a href="tel:08033134143" className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs">
                Call Control
              </a>
            </div>

            <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                  <HeartPulse className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{selectedState} State Ambulance Service</h4>
                  <p className="text-slate-400 text-[10px]">LASBUS / Regional Medical Emergency</p>
                </div>
              </div>
              <a href="tel:767" className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-lg text-sm">
                767
              </a>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
          >
            Close Emergency Section
          </button>

        </div>
      </div>
    </div>
  );
};
