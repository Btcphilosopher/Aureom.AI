'use client';

import React, { useState } from 'react';
import { 
  Activity, 
  BarChart3, 
  Building2, 
  CheckCircle2, 
  Clock, 
  FileText, 
  MapPin, 
  Layers, 
  TrendingUp, 
  ShieldCheck, 
  ExternalLink,
  Award
} from 'lucide-react';
import { PublicProject } from '@/lib/types';

interface OpenGovAndPerformanceModalProps {
  projects: PublicProject[];
}

export const OpenGovAndPerformanceModal: React.FC<OpenGovAndPerformanceModalProps> = ({ projects }) => {
  const [activeTab, setActiveTab] = useState<'PROJECTS' | 'PERFORMANCE' | 'OPENDATA'>('PROJECTS');

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <span className="text-xs font-mono font-bold text-[#008751] uppercase">Federal e-Government Infrastructure</span>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">OPEN GOVERNMENT & PUBLIC PERFORMANCE</h2>
        <p className="text-xs text-slate-600 mt-1">
          Non-sensitive public datasets, national infrastructure project tracker, and real-time MDA service SLA performance metrics.
        </p>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setActiveTab('PROJECTS')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'PROJECTS' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          Public Infrastructure Projects ({projects.length})
        </button>

        <button
          onClick={() => setActiveTab('PERFORMANCE')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'PERFORMANCE' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          National SLA Performance
        </button>

        <button
          onClick={() => setActiveTab('OPENDATA')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'OPENDATA' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          Open Data & Budget Portal
        </button>
      </div>

      {/* Tab 1: PROJECTS */}
      {activeTab === 'PROJECTS' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map((prj) => (
            <div key={prj.projectId} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-mono mb-2">
                  <span className="font-bold text-[#008751] bg-emerald-50 px-2 py-0.5 rounded">
                    {prj.agency}
                  </span>
                  <span className="text-slate-500 font-bold">{prj.status}</span>
                </div>

                <h3 className="text-base font-bold text-slate-900 leading-snug">{prj.name}</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">{prj.description}</p>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Location:</span>
                    <span className="font-bold text-slate-800">{prj.locationState}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Contractor:</span>
                    <span className="font-bold text-slate-800">{prj.contractor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Budget:</span>
                    <span className="font-bold text-[#008751]">₦{prj.budgetNairaMillions.toLocaleString()}M</span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-4 space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-600">Completion</span>
                    <span className="font-bold text-slate-900">{prj.progressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-[#008751] h-full" style={{ width: `${prj.progressPercent}%` }} />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 text-[10px] font-mono text-slate-500 flex justify-between">
                <span>Start: {prj.startDate}</span>
                <span>Expected: {prj.expectedCompletion}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: PERFORMANCE */}
      {activeTab === 'PERFORMANCE' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center font-mono">
              <span className="text-[10px] text-slate-400 block uppercase">Total Applications</span>
              <span className="text-2xl font-extrabold text-slate-900">1,284,301</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center font-mono">
              <span className="text-[10px] text-slate-400 block uppercase">Completed</span>
              <span className="text-2xl font-extrabold text-[#008751]">1,103,221</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center font-mono">
              <span className="text-[10px] text-slate-400 block uppercase">Pending Review</span>
              <span className="text-2xl font-extrabold text-amber-600">181,080</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center font-mono">
              <span className="text-[10px] text-slate-400 block uppercase">Avg Processing</span>
              <span className="text-2xl font-extrabold text-slate-900">2.7 Days</span>
            </div>
          </div>

          {/* Agency Scoreboard Bar Charts */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-4">
            <h3 className="text-sm font-bold font-mono text-slate-900 uppercase">AGENCY SLA RESPONSE INDEX</h3>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span>NIMC Identity Gateway</span>
                  <span className="font-bold text-[#008751]">98% SLA Compliance</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div className="bg-[#008751] h-full" style={{ width: '98%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>CAC Company Registry</span>
                  <span className="font-bold text-[#008751]">94% SLA Compliance</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div className="bg-[#008751] h-full" style={{ width: '94%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>FRSC Driver's Licence DLC</span>
                  <span className="font-bold text-[#008751]">91% SLA Compliance</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div className="bg-[#008751] h-full" style={{ width: '91%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>FIRS e-Tax Portal</span>
                  <span className="font-bold text-[#008751]">96% SLA Compliance</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div className="bg-[#008751] h-full" style={{ width: '96%' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: OPENDATA */}
      {activeTab === 'OPENDATA' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-4">
          <h3 className="text-base font-bold text-slate-900">National Open Data Portal Datasets</h3>
          <p className="text-xs text-slate-600">Download official non-sensitive machine-readable CSV / JSON datasets under Open Government Partnership (OGP) standards.</p>

          <div className="space-y-2 text-xs font-mono">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <span>Federal Annual Budget Appropriations (2026 GAZETTE)</span>
              <a href="https://services.gov.ng" target="_blank" rel="noopener noreferrer" className="text-[#008751] font-bold hover:underline">
                Download CSV
              </a>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <span>Public Procurement Awards & BPP Contract Tenders Registry</span>
              <a href="https://services.gov.ng" target="_blank" rel="noopener noreferrer" className="text-[#008751] font-bold hover:underline">
                Download JSON
              </a>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
