'use client';

import React, { useState } from 'react';
import { 
  Receipt, 
  ShieldCheck, 
  CheckCircle2, 
  Download, 
  CreditCard, 
  AlertCircle, 
  Building2, 
  FileText, 
  Clock, 
  ArrowRight,
  Info
} from 'lucide-react';
import { TaxProfile } from '@/lib/types';

interface TaxAreaModalProps {
  taxProfile: TaxProfile;
}

export const TaxAreaModal: React.FC<TaxAreaModalProps> = ({ taxProfile }) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'OBLIGATIONS' | 'RETURNS' | 'CERTIFICATES'>('OVERVIEW');
  const [isFiling, setIsFiling] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-[#008751] uppercase">Integrated Tax System</span>
            <span className="bg-blue-100 text-blue-900 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
              FIRS & STATE REVENUE GATEWAY
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">TAX SERVICES & OBLIGATIONS</h2>
          <p className="text-xs text-slate-600 mt-1">
            Taxpayer self-service for corporate, individual, non-resident, and free-trade-zone taxpayers under FIRS and State IRS.
          </p>
        </div>

        {/* TIN Card */}
        <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-800 font-mono text-xs w-full md:w-auto shrink-0 shadow-md">
          <span className="text-[10px] text-slate-400 block uppercase">Tax Identification Number (TIN)</span>
          <span className="text-lg font-extrabold text-[#D4AF37] tracking-widest block">{taxProfile.tin}</span>
          <span className="text-[10px] text-emerald-400 font-bold block mt-1">✓ Status: COMPLIANT (2026)</span>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'OVERVIEW' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Tax Overview
        </button>
        <button
          onClick={() => setActiveTab('OBLIGATIONS')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'OBLIGATIONS' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Obligations ({taxProfile.obligations.length})
        </button>
        <button
          onClick={() => setActiveTab('RETURNS')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'RETURNS' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          File Annual Return
        </button>
        <button
          onClick={() => setActiveTab('CERTIFICATES')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'CERTIFICATES' ? 'bg-[#008751] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          e-Clearance Certificates (TCC)
        </button>
      </div>

      {/* Tab 1: OVERVIEW */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-mono text-slate-500 uppercase block">Taxpayer Category</span>
              <p className="text-xl font-bold text-slate-900 mt-1">{taxProfile.taxpayerType}</p>
              <p className="text-xs text-slate-500 mt-2 font-mono">Jurisdiction: {taxProfile.jurisdictionState} State</p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-mono text-slate-500 uppercase block">Total Remitted (2026)</span>
              <p className="text-xl font-bold text-[#008751] font-mono mt-1">₦{taxProfile.totalPaidThisYearNaira.toLocaleString()}</p>
              <p className="text-xs text-emerald-600 mt-2 font-bold font-mono">✓ Verified via Remita CBN</p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-mono text-slate-500 uppercase block">e-TCC Certificate</span>
              <p className="text-base font-bold text-slate-900 font-mono mt-1">{taxProfile.eClearanceId}</p>
              <button 
                onClick={() => setActiveTab('CERTIFICATES')}
                className="text-xs font-bold text-[#008751] hover:underline mt-2 inline-block"
              >
                Download Official Certificate →
              </button>
            </div>
          </div>

          {/* TaxRulesProvider Versioning Banner */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-[#D4AF37] font-mono font-bold">
              <Info className="w-4 h-4" />
              <span>Versioned TaxRulesProvider Architecture</span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              Calculations and statutory rules are supplied dynamically by authorized FIRS and Lagos LIRS backends (Tax Rules Version 2026.4). The mobile client does not use arbitrary invented tax rules.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: OBLIGATIONS */}
      {activeTab === 'OBLIGATIONS' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 font-mono">TAX OBLIGATIONS & REMITTANCES</h3>
            <span className="text-xs text-slate-500 font-mono">FIRS & LIRS Combined</span>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {taxProfile.obligations.map((ob, idx) => (
              <div key={idx} className="p-4 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{ob.name}</h4>
                  <p className="text-slate-500 font-mono mt-0.5">Due Date: {ob.dueDate}</p>
                </div>

                <div className="flex items-center gap-4">
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    ₦{ob.amountNaira.toLocaleString()}
                  </span>

                  {ob.status === 'PAID' ? (
                    <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full font-mono flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      PAID
                    </span>
                  ) : (
                    <button
                      onClick={() => alert(`Simulating remittance payment of ₦${ob.amountNaira.toLocaleString()} to FIRS...`)}
                      className="px-3 py-1.5 bg-[#008751] hover:bg-[#006e40] text-white font-bold rounded-lg transition-colors flex items-center gap-1"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Remit Now</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: RETURNS */}
      {activeTab === 'RETURNS' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
          <h3 className="text-base font-bold text-slate-900">File Annual Tax Return (Form H1 / FIRS Direct Assessment)</h3>
          <p className="text-xs text-slate-600">
            Submit income self-assessment declarations directly to FIRS and State IRS without manual office visitation.
          </p>

          {!isFiling ? (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <p className="font-semibold text-slate-800">Income Assessment Year 2026</p>
                <p className="text-slate-600">Declared Gross Income: ₦4,200,000</p>
                <p className="text-slate-600">Consolidated Relief Allowance (CRA): ₦840,000</p>
                <p className="text-slate-600">Net Tax Payable: ₦420,000</p>
              </div>

              <button
                onClick={() => setIsFiling(true)}
                className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <FileText className="w-4 h-4" />
                <span>Submit Electronic Return to FIRS & LIRS</span>
              </button>
            </div>
          ) : (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-[#008751] mx-auto" />
              <h4 className="text-base font-bold text-slate-900">2026 Annual Tax Return Filed</h4>
              <p className="text-xs text-slate-600">FIRS Return Reference: <strong>FIRS-RET-2026-99120</strong></p>
              <button
                onClick={() => setIsFiling(false)}
                className="px-4 py-2 bg-[#008751] text-white text-xs font-bold rounded-lg"
              >
                Done
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: CERTIFICATES */}
      {activeTab === 'CERTIFICATES' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Tax Clearance Certificate (TCC 2026)</h3>
              <p className="text-xs text-slate-500 font-mono">Issued by Federal Inland Revenue Service (FIRS)</p>
            </div>

            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold font-mono px-3 py-1 rounded-full">
              VALID TILL DEC 2026
            </span>
          </div>

          <div className="p-6 bg-slate-900 text-white rounded-2xl border-2 border-[#D4AF37] space-y-4 font-mono text-xs">
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">TIN</span>
              <span className="font-bold text-[#D4AF37]">{taxProfile.tin}</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Taxpayer Name</span>
              <span className="font-bold text-white">{taxProfile.taxpayerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Compliance Rating</span>
              <span className="font-bold text-emerald-400">Category A (100% Compliant)</span>
            </div>
          </div>

          <button
            onClick={() => alert("Official FIRS Tax Clearance Certificate PDF downloaded.")}
            className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2 font-mono"
          >
            <Download className="w-4 h-4" />
            <span>Download Official e-TCC PDF</span>
          </button>
        </div>
      )}

    </div>
  );
};
