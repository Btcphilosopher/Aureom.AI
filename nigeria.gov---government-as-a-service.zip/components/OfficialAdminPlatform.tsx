'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  Layers, 
  Users, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  FileText, 
  ShieldCheck, 
  TrendingUp,
  Search
} from 'lucide-react';
import { OfficialCase } from '@/lib/types';

interface OfficialAdminPlatformProps {
  cases: OfficialCase[];
  onApproveCase: (caseId: string) => void;
  onRejectCase: (caseId: string) => void;
}

export const OfficialAdminPlatform: React.FC<OfficialAdminPlatformProps> = ({
  cases,
  onApproveCase,
  onRejectCase
}) => {
  const [role, setRole] = useState<'Case Officer' | 'Agency Admin' | 'State Admin' | 'Federal Admin' | 'Auditor'>('Case Officer');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCases = cases.filter(c => 
    !searchQuery || 
    c.caseId.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.applicantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.agency.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      
      {/* Official Top Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl border border-slate-800 space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-[#D4AF37] text-slate-950 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                GOVERNMENT OPERATIONS OS
              </span>
              <span className="text-xs font-mono text-emerald-400">Federal Secretariat Network</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight mt-1 font-mono">
              CASE OFFICERS & SLA ADMINISTRATION PLATFORM
            </h2>
          </div>

          {/* Role Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-800 p-1.5 rounded-xl border border-slate-700 text-xs font-mono">
            {(['Case Officer', 'Agency Admin', 'State Admin', 'Federal Admin', 'Auditor'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                  role === r ? 'bg-[#008751] text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* SLA Summary Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 font-mono text-xs">
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">ACTIVE QUEUE</span>
            <span className="text-xl font-bold text-white">{cases.length} Cases</span>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">SLA WARNING / BREACH</span>
            <span className="text-xl font-bold text-red-400">1 Overdue</span>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">ACTIVE ROLE</span>
            <span className="text-base font-bold text-[#D4AF37]">{role}</span>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">AVG SLA COMPLIANCE</span>
            <span className="text-xl font-bold text-emerald-400">96.4%</span>
          </div>
        </div>
      </div>

      {/* Case Management Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <h3 className="text-base font-bold text-slate-900 font-mono">CASE MANAGEMENT QUEUE</h3>
          
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Case ID or Applicant..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {filteredCases.map((c) => {
            const isOverdue = c.status === 'OVERDUE' || c.slaDaysRemaining < 0;

            return (
              <div key={c.caseId} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 font-mono">
                    <span className="font-bold text-slate-900 text-sm">{c.caseId}</span>
                    <span className="bg-slate-100 text-slate-800 font-bold px-2 py-0.5 rounded text-[10px]">
                      {c.agency}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      isOverdue ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {c.status}
                    </span>
                  </div>

                  <p className="text-slate-700 font-medium">{c.serviceName} · Applicant: <strong className="text-slate-900">{c.applicantName}</strong> ({c.applicantNinMasked})</p>
                  <p className="text-slate-500 font-mono text-[11px]">Submitted: {c.submittedAt} · Assigned Officer: {c.assignedOfficer}</p>
                </div>

                <div className="flex items-center gap-3 shrink-0 font-mono">
                  <span className={`text-xs font-bold ${isOverdue ? 'text-red-600' : 'text-slate-700'}`}>
                    SLA: {c.slaDaysRemaining}d remaining
                  </span>

                  {c.status !== 'APPROVED' && c.status !== 'REJECTED' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onApproveCase(c.caseId)}
                        className="px-3 py-1.5 bg-[#008751] hover:bg-[#006e40] text-white font-bold rounded-lg transition-colors flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approve & Sign</span>
                      </button>

                      <button
                        onClick={() => onRejectCase(c.caseId)}
                        className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-colors flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
