'use client';

import React from 'react';
import { Terminal, X, Play, RefreshCw, AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { IdentityState } from '@/lib/types';

interface DeveloperModeConsoleProps {
  isOpen: boolean;
  onClose: () => void;
  identityState: IdentityState;
  setIdentityState: (state: IdentityState) => void;
  onRunTestScenario: (scenarioName: string) => void;
}

export const DeveloperModeConsole: React.FC<DeveloperModeConsoleProps> = ({
  isOpen,
  onClose,
  identityState,
  setIdentityState,
  onRunTestScenario
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 text-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative font-mono text-xs">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-extrabold text-sm text-white tracking-widest">DEVELOPER SIMULATION ENVIRONMENT</h3>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Identity State Switcher */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <span className="text-[10px] text-[#D4AF37] font-bold uppercase block">1. MOCK IDENTITY STATE SWITCHER</span>
            <div className="grid grid-cols-3 gap-2">
              {(['UNKNOWN', 'PARTIALLY_VERIFIED', 'VERIFIED', 'REQUIRES_UPDATE', 'SUSPENDED'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setIdentityState(st)}
                  className={`p-2.5 rounded-lg font-bold border transition-all text-[11px] ${
                    identityState === st 
                      ? 'bg-[#008751] text-white border-emerald-400' 
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-slate-400">Current active state: <strong className="text-white">{identityState}</strong></p>
          </div>

          {/* Test Scenarios Runner */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <span className="text-[10px] text-[#D4AF37] font-bold uppercase block">2. DETERMINISTIC END-TO-END TEST SCENARIO RUNNER</span>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <button
                onClick={() => onRunTestScenario('Full Business Incorporation Flow')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-left border border-slate-700 font-bold flex items-center justify-between"
              >
                <span>Full Business Incorporation (CAC + FIRS)</span>
                <Play className="w-3.5 h-3.5 text-[#008751]" />
              </button>

              <button
                onClick={() => onRunTestScenario('Driver\'s Licence Renewal & Biometrics')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-left border border-slate-700 font-bold flex items-center justify-between"
              >
                <span>Driver's Licence Renewal (FRSC)</span>
                <Play className="w-3.5 h-3.5 text-[#008751]" />
              </button>

              <button
                onClick={() => onRunTestScenario('Passport Biometric Appointment')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-left border border-slate-700 font-bold flex items-center justify-between"
              >
                <span>Passport Appointment (NIS)</span>
                <Play className="w-3.5 h-3.5 text-[#008751]" />
              </button>

              <button
                onClick={() => onRunTestScenario('Corruption Complaint & Case ID')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-left border border-slate-700 font-bold flex items-center justify-between"
              >
                <span>Corruption Whistleblower Logging</span>
                <Play className="w-3.5 h-3.5 text-[#008751]" />
              </button>
            </div>
          </div>

          {/* Fault Simulation Toggles */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[10px] text-red-400 font-bold uppercase block">3. SIMULATE SYSTEM FAULTS / OUTAGES</span>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => alert("Fault Simulation: Simulated agency network latency (+2500ms)")} className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700">
                Simulate Latency
              </button>
              <button onClick={() => alert("Fault Simulation: Simulated NIMC gateway 503 outage.")} className="px-3 py-1.5 bg-red-900/60 text-red-200 rounded border border-red-700 font-bold">
                Simulate Agency Outage
              </button>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-[#008751] hover:bg-[#006e40] text-white font-bold rounded-xl"
          >
            Close Developer Environment
          </button>

        </div>
      </div>
    </div>
  );
};
