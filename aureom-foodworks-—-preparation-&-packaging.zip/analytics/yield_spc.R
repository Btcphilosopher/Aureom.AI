# Statistical Process Monitoring & Yield Analysis Script (R)
# Designed for offline/scheduled SPC analysis against exported Aureom batch data.

analyze_tray_fill_spc <- function(weights_g, target_g = 380.0, lsl_g = 372.0, usl_g = 395.0) {
  n <- length(weights_g)
  mean_w <- mean(weights_g)
  sd_w <- sd(weights_g)
  ucl <- mean_w + 3 * sd_w
  lcl <- mean_w - 3 * sd_w
  cpk <- min((usl_g - mean_w) / (3 * sd_w), (mean_w - lsl_g) / (3 * sd_w))
  out_of_control <- which(weights_g > ucl | weights_g < lcl)

  list(
    sample_count = n,
    mean_g = round(mean_w, 2),
    sd_g = round(sd_w, 3),
    ucl_g = round(ucl, 2),
    lcl_g = round(lcl, 2),
    cpk = round(cpk, 3),
    out_of_control_indices = out_of_control
  )
}

if (sys.nframe() == 0) {
  set.seed(20261120)
  synthetic_weights <- rnorm(60, mean = 381.1, sd = 1.65)
  res <- analyze_tray_fill_spc(synthetic_weights)
  cat("Synthetic SPC Result (380g Tray Fill):\n")
  print(res)
}
