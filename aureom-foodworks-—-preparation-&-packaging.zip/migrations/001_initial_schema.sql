-- PostgreSQL-compatible schema reference matching runtime SQLite migrations (src/server/db/migrations.ts)
CREATE TABLE IF NOT EXISTS stations (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  stage TEXT NOT NULL,
  sequence_order INTEGER NOT NULL,
  state TEXT NOT NULL,
  line_id TEXT NOT NULL,
  active_order_id TEXT,
  active_operator TEXT,
  setpoint_label TEXT NOT NULL,
  setpoint_value DOUBLE PRECISION,
  measured_value DOUBLE PRECISION,
  unit TEXT NOT NULL,
  sensor_id TEXT NOT NULL,
  calibration_due TEXT NOT NULL,
  calibration_valid BOOLEAN NOT NULL DEFAULT TRUE,
  throughput_per_min DOUBLE PRECISION NOT NULL DEFAULT 0,
  buffer_count INTEGER NOT NULL DEFAULT 0,
  buffer_capacity INTEGER NOT NULL DEFAULT 100,
  fault_reason TEXT,
  last_observation_at TIMESTAMPTZ NOT NULL,
  is_synthetic BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS inventory_lots (
  id TEXT PRIMARY KEY,
  internal_uid TEXT NOT NULL UNIQUE,
  material_code TEXT NOT NULL,
  material_name TEXT NOT NULL,
  material_kind TEXT NOT NULL,
  supplier_id TEXT NOT NULL,
  supplier_name TEXT NOT NULL,
  supplier_lot_code TEXT NOT NULL,
  barcode_value TEXT NOT NULL,
  po_number TEXT NOT NULL,
  quantity_on_hand DOUBLE PRECISION NOT NULL CHECK (quantity_on_hand >= 0),
  quantity_reserved DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (quantity_reserved >= 0 AND quantity_reserved <= quantity_on_hand),
  unit TEXT NOT NULL,
  location_code TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL,
  expiry_date TIMESTAMPTZ NOT NULL,
  temperature_c DOUBLE PRECISION,
  quality_status TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id TEXT PRIMARY KEY,
  lot_id TEXT NOT NULL REFERENCES inventory_lots(id),
  movement_type TEXT NOT NULL,
  quantity_delta DOUBLE PRECISION NOT NULL,
  unit TEXT NOT NULL,
  order_id TEXT,
  batch_id TEXT,
  reference_id TEXT,
  linked_movement_id TEXT,
  reason TEXT NOT NULL,
  performed_by TEXT NOT NULL,
  performed_role TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);
