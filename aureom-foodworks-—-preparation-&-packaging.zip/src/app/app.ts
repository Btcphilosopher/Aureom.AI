import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
} from '@angular/core';
import {DatePipe} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore, NavSection} from './services/factory-store';
import {OperatingMode, UserRole} from '../shared/domain';
import {OverviewView} from './views/overview-view';
import {
  PreparationView,
  ProductionView,
  RecipesView,
} from './views/operations-views';
import {
  IngredientsView,
  PackagingView,
  WarehouseView,
} from './views/inventory-warehouse-views';
import {
  QualityView,
  TraceabilityView,
} from './views/quality-traceability-views';
import {
  AdministrationView,
  EnergyView,
  MaintenanceView,
  PlanningView,
  ReportsView,
} from './views/planning-perf-admin-views';

interface NavItem {
  id: NavSection;
  label: string;
  icon: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    DatePipe,
    OverviewView,
    ProductionView,
    RecipesView,
    IngredientsView,
    PreparationView,
    PackagingView,
    QualityView,
    TraceabilityView,
    MaintenanceView,
    WarehouseView,
    PlanningView,
    EnergyView,
    ReportsView,
    AdministrationView,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  readonly store = inject(FactoryStore);

  readonly navItems: NavItem[] = [
    {id: 'overview', label: 'Overview', icon: 'dashboard'},
    {id: 'production', label: 'Production', icon: 'precision_manufacturing'},
    {id: 'recipes', label: 'Recipes', icon: 'menu_book'},
    {id: 'ingredients', label: 'Ingredients', icon: 'inventory_2'},
    {id: 'preparation', label: 'Preparation', icon: 'soup_kitchen'},
    {id: 'packaging', label: 'Packaging', icon: 'package_2'},
    {id: 'quality', label: 'Quality', icon: 'verified'},
    {id: 'traceability', label: 'Traceability', icon: 'account_tree'},
    {id: 'maintenance', label: 'Maintenance', icon: 'build'},
    {id: 'warehouse', label: 'Warehouse', icon: 'warehouse'},
    {id: 'planning', label: 'Planning', icon: 'schedule'},
    {id: 'energy', label: 'Energy', icon: 'bolt'},
    {id: 'reports', label: 'Reports', icon: 'assessment'},
    {id: 'administration', label: 'Administration', icon: 'admin_panel_settings'},
  ];

  readonly modes: {id: OperatingMode; label: string}[] = [
    {id: 'simulation', label: 'Simulation'},
    {id: 'monitoring', label: 'Monitoring'},
    {id: 'supervised', label: 'Supervised Integration'},
  ];

  readonly roles: {id: UserRole; label: string}[] = [
    {id: 'operator', label: 'Operator'},
    {id: 'supervisor', label: 'Supervisor'},
    {id: 'quality', label: 'Quality Staff'},
    {id: 'maintenance', label: 'Maintenance Eng'},
    {id: 'planner', label: 'Planner'},
    {id: 'warehouse', label: 'Warehouse Team'},
    {id: 'admin', label: 'Administrator'},
  ];

  ngOnInit(): void {
    void this.store.init();
  }

  activeNavLabel(): string {
    return (
      this.navItems.find((n) => n.id === this.store.activeSection())?.label ??
      'Overview'
    );
  }

  onRoleChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    this.store.setRole(select.value as UserRole);
  }
}
