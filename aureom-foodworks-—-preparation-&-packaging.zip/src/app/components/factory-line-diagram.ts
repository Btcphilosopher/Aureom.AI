import {ChangeDetectionStrategy, Component, input, output} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Station, StationState} from '../../shared/domain';

@Component({
  selector: 'app-factory-line-diagram',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div
      class="bg-white border border-slate-200 rounded-xl p-5"
      [class.reduced-motion]="reducedMotion()"
    >
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 class="text-base font-semibold text-[#0F1D32]">
            Line 01 — Chilled Ready-Meal Production Flow
          </h2>
          <p class="text-xs text-slate-600 mt-0.5">
            Select any station to inspect sensor telemetry, calibration status, or change state.
            @if (dataStale()) {
              <span class="font-semibold text-red-700 ml-1">
                Telemetry disconnected — displaying last recorded observation.
              </span>
            }
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-4 text-xs text-slate-600">
          <span class="inline-flex items-center gap-1.5">
            <mat-icon class="!text-[15px] !w-[15px] !h-[15px] text-emerald-700">play_circle</mat-icon>
            Running
          </span>
          <span class="inline-flex items-center gap-1.5">
            <mat-icon class="!text-[15px] !w-[15px] !h-[15px] text-amber-600">hourglass_empty</mat-icon>
            Starved / Blocked
          </span>
          <span class="inline-flex items-center gap-1.5">
            <mat-icon class="!text-[15px] !w-[15px] !h-[15px] text-sky-700">cleaning_services</mat-icon>
            Cleaning / Changeover
          </span>
          <span class="inline-flex items-center gap-1.5">
            <mat-icon class="!text-[15px] !w-[15px] !h-[15px] text-red-700">error_outline</mat-icon>
            Faulted / Stopped
          </span>
        </div>
      </div>

      <!-- Engineering Conveyor Schematic (2 rows of 5 stations for clear readability at 1440px and tablet) -->
      <div class="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        @for (station of stations(); track station.id; let idx = $index) {
          <div class="relative flex items-stretch">
            <button
              type="button"
              (click)="stationSelected.emit(station.id)"
              [attr.aria-pressed]="selectedId() === station.id"
              class="w-full text-left rounded-lg border p-3.5 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F1D32] min-h-[126px] flex flex-col justify-between cursor-pointer"
              [class]="cardClasses(station)"
            >
              <div>
                <div class="flex items-center justify-between gap-2">
                  <span class="font-mono text-[11px] font-semibold text-slate-600 tabular-nums">
                    {{ station.code }} · {{ station.stage }}
                  </span>
                  <span
                    class="inline-flex items-center gap-1 text-[11px] font-semibold whitespace-nowrap shrink-0"
                    [class]="stateTextClass(station.state)"
                  >
                    <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">
                      {{ stateIcon(station.state) }}
                    </mat-icon>
                    {{ stateLabel(station.state) }}
                  </span>
                </div>

                <div class="mt-1.5 text-sm font-semibold text-[#0F1D32] leading-snug">
                  {{ station.name }}
                </div>
              </div>

              <div class="mt-3 pt-2.5 border-t border-slate-200/80">
                <div class="flex items-baseline justify-between gap-2">
                  <span class="text-[11px] text-slate-600 truncate">{{ station.setpointLabel }}</span>
                  <span class="font-mono text-xs font-semibold text-[#0F1D32] tabular-nums whitespace-nowrap">
                    {{ station.measuredValue ?? '—' }} {{ station.unit }}
                  </span>
                </div>

                <!-- Animated conveyor link bar -->
                <div class="mt-2 flex items-center gap-2">
                  <svg
                    viewBox="0 0 120 8"
                    class="w-full h-2 overflow-hidden rounded bg-slate-200"
                    aria-hidden="true"
                  >
                    <line
                      x1="0"
                      y1="4"
                      x2="120"
                      y2="4"
                      stroke-width="4"
                      [attr.stroke]="conveyorStroke(station.state)"
                      stroke-dasharray="12 12"
                      [class.animate-conveyor]="station.state === 'running' && !dataStale()"
                      [class.animate-conveyor-slow]="(station.state === 'cleaning' || station.state === 'changeover') && !dataStale()"
                    />
                  </svg>
                  <span class="font-mono text-[10px] text-slate-500 tabular-nums whitespace-nowrap">
                    {{ station.bufferCount }}/{{ station.bufferCapacity }}
                  </span>
                </div>
              </div>
            </button>
          </div>
        }
      </div>
    </div>
  `,
})
export class FactoryLineDiagram {
  readonly stations = input.required<Station[]>();
  readonly selectedId = input<string | null>(null);
  readonly dataStale = input<boolean>(false);
  readonly reducedMotion = input<boolean>(false);
  readonly stationSelected = output<string>();

  cardClasses(s: Station): string {
    const isSelected = this.selectedId() === s.id;
    if (isSelected) {
      return 'bg-[#EAECEF] border-[#0F1D32] ring-1 ring-[#0F1D32]';
    }
    if (s.state === 'faulted') {
      return 'bg-red-50/60 border-red-300 hover:border-red-500';
    }
    if (s.state === 'starved' || s.state === 'blocked') {
      return 'bg-amber-50/50 border-amber-300 hover:border-amber-500';
    }
    if (s.state === 'cleaning' || s.state === 'changeover') {
      return 'bg-sky-50/50 border-sky-300 hover:border-sky-500';
    }
    return 'bg-[#F8F9FA] border-slate-200 hover:border-slate-400';
  }

  stateTextClass(state: StationState): string {
    switch (state) {
      case 'running':
        return 'text-emerald-700';
      case 'starved':
      case 'blocked':
        return 'text-amber-700';
      case 'cleaning':
      case 'changeover':
        return 'text-sky-700';
      case 'faulted':
        return 'text-red-700';
      case 'stopped':
        return 'text-slate-600';
    }
  }

  stateIcon(state: StationState): string {
    switch (state) {
      case 'running':
        return 'play_circle';
      case 'starved':
        return 'hourglass_empty';
      case 'blocked':
        return 'block';
      case 'cleaning':
        return 'cleaning_services';
      case 'changeover':
        return 'swap_horiz';
      case 'faulted':
        return 'error_outline';
      case 'stopped':
        return 'pause_circle_outline';
    }
  }

  stateLabel(state: StationState): string {
    switch (state) {
      case 'running':
        return 'Running';
      case 'starved':
        return 'Starved';
      case 'blocked':
        return 'Blocked';
      case 'cleaning':
        return 'Cleaning';
      case 'changeover':
        return 'Changeover';
      case 'faulted':
        return 'Faulted';
      case 'stopped':
        return 'Stopped';
    }
  }

  conveyorStroke(state: StationState): string {
    switch (state) {
      case 'running':
        return '#059669';
      case 'starved':
      case 'blocked':
        return '#D97706';
      case 'cleaning':
      case 'changeover':
        return '#0369A1';
      case 'faulted':
        return '#DC2626';
      case 'stopped':
        return '#64748B';
    }
  }
}
