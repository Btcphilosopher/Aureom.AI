import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {DatePipe, DecimalPipe} from '@angular/common';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore} from '../services/factory-store';
import {OrderStatus} from '../../shared/domain';

@Component({
  selector: 'app-production-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DecimalPipe, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Production Orders & Execution</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Orders bind immutably to an approved recipe version. Production completion is strictly separated from QA finished-goods release.
            </p>
          </div>
          <button
            type="button"
            (click)="showCreateForm.set(!showCreateForm())"
            class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-[#047857] text-white hover:bg-emerald-800 cursor-pointer"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">add</mat-icon>
            New Production Order
          </button>
        </div>

        @if (showCreateForm()) {
          <form [formGroup]="orderForm" (ngSubmit)="submitOrder()" class="mt-4 p-4 bg-[#F7F5F0] border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label for="ord-recipe" class="block text-xs font-medium text-slate-700 mb-1">Approved Recipe Version</label>
              <select id="ord-recipe" formControlName="recipeVersionId" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg">
                @for (r of store.recipes(); track r.id) {
                  @if (r.status === 'approved') {
                    <option [value]="r.id">{{ r.recipeCode }} {{ r.versionNumber }} — {{ r.productName }}</option>
                  }
                }
              </select>
            </div>
            <div>
              <label for="ord-target" class="block text-xs font-medium text-slate-700 mb-1">Target Units (Trays/Bowls)</label>
              <input id="ord-target" type="number" formControlName="targetUnits" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
            </div>
            <div>
              <label for="ord-cust" class="block text-xs font-medium text-slate-700 mb-1">Customer Reference</label>
              <input id="ord-cust" type="text" formControlName="customerOrderRef" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg" />
            </div>
            <div class="md:col-span-3 flex justify-end gap-2">
              <button type="button" (click)="showCreateForm.set(false)" class="px-3 py-2 text-xs font-medium border border-slate-300 bg-white rounded-lg cursor-pointer">
                Cancel
              </button>
              <button type="submit" [disabled]="orderForm.invalid" class="px-4 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer">
                Create Order
              </button>
            </div>
          </form>
        }

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2.5 pr-3 font-medium">Order / Recipe</th>
                <th class="py-2.5 pr-3 font-medium">Product</th>
                <th class="py-2.5 pr-3 font-medium text-right">Produced / Target</th>
                <th class="py-2.5 pr-3 font-medium text-right">Reject / Rework</th>
                <th class="py-2.5 pr-3 font-medium">Order Status</th>
                <th class="py-2.5 pr-3 font-medium">QA Release</th>
                <th class="py-2.5 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (o of store.snapshot()?.orders ?? []; track o.id) {
                <tr class="hover:bg-slate-50">
                  <td class="py-3 pr-3 font-mono font-semibold text-[#0F1D32]">
                    {{ o.orderNumber }}<br />
                    <span class="text-[11px] font-normal text-slate-500">{{ o.recipeVersionId }}</span>
                  </td>
                  <td class="py-3 pr-3">
                    <div class="font-medium text-[#0F1D32]">{{ o.productName }}</div>
                    <div class="text-[11px] text-slate-500">
                      {{ o.shiftName }} · Due {{ o.dispatchDeadline | date:'dd MMM HH:mm' }}
                    </div>
                  </td>
                  <td class="py-3 pr-3 text-right font-mono tabular-nums font-semibold">
                    {{ o.producedUnits | number }} / {{ o.targetUnits | number }}
                  </td>
                  <td class="py-3 pr-3 text-right font-mono tabular-nums">
                    {{ o.rejectedUnits }} / {{ o.reworkUnits }}
                  </td>
                  <td class="py-3 pr-3 font-semibold">{{ o.status }}</td>
                  <td class="py-3 pr-3 font-semibold" [class]="o.qualityReleaseStatus === 'released' ? 'text-emerald-700' : o.qualityReleaseStatus === 'hold' ? 'text-red-700' : 'text-amber-700'">
                    {{ o.qualityReleaseStatus }}
                  </td>
                  <td class="py-3 text-right whitespace-nowrap space-x-1.5">
                    @if (o.status === 'planned') {
                      <button type="button" (click)="transition(o.id, 'released')" class="px-2.5 py-1.5 border border-slate-300 rounded bg-white hover:bg-slate-100 cursor-pointer">Release</button>
                    }
                    @if (o.status === 'released' || o.status === 'paused') {
                      <button type="button" (click)="transition(o.id, 'in_progress')" class="px-2.5 py-1.5 bg-emerald-700 text-white rounded hover:bg-emerald-800 cursor-pointer">Run</button>
                    }
                    @if (o.status === 'in_progress') {
                      <button type="button" (click)="transition(o.id, 'paused')" class="px-2.5 py-1.5 border border-amber-400 text-amber-800 rounded bg-amber-50 cursor-pointer">Pause</button>
                      <button type="button" (click)="recordTranche(o.id)" class="px-2.5 py-1.5 bg-[#0F1D32] text-white rounded cursor-pointer">+1,200 Units</button>
                      <button type="button" (click)="transition(o.id, 'completed')" class="px-2.5 py-1.5 border border-slate-300 rounded bg-white cursor-pointer">Complete</button>
                    }
                    @if (o.status === 'completed') {
                      <button type="button" (click)="transition(o.id, 'reconciled')" class="px-2.5 py-1.5 border border-slate-300 rounded bg-white cursor-pointer">Reconcile</button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Record Custom Output & Rework Split -->
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h3 class="text-base font-semibold text-[#0F1D32]">Record Output & Rework Split</h3>
        <form [formGroup]="outputForm" (ngSubmit)="submitCustomOutput()" class="mt-3 grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
          <div>
            <label for="out-order" class="block text-xs font-medium text-slate-700 mb-1">Order</label>
            <select id="out-order" formControlName="orderId" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono">
              @for (o of store.snapshot()?.orders ?? []; track o.id) {
                <option [value]="o.id">{{ o.orderNumber }}</option>
              }
            </select>
          </div>
          <div>
            <label for="out-good" class="block text-xs font-medium text-slate-700 mb-1">Good Units</label>
            <input id="out-good" type="number" formControlName="goodUnits" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <div>
            <label for="out-rej" class="block text-xs font-medium text-slate-700 mb-1">Rejected Units</label>
            <input id="out-rej" type="number" formControlName="rejectedUnits" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <div>
            <label for="out-rwk" class="block text-xs font-medium text-slate-700 mb-1">Rework Units (Tracked)</label>
            <input id="out-rwk" type="number" formControlName="reworkUnits" class="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <button type="submit" class="px-4 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg hover:bg-slate-800 cursor-pointer">
            Record Production Output
          </button>
        </form>
      </div>
    </div>
  `,
})
export class ProductionView {
  readonly store = inject(FactoryStore);
  readonly showCreateForm = signal(false);

  readonly orderForm = new FormGroup({
    recipeVersionId: new FormControl('RCP-CVMT-V2_1', {nonNullable: true, validators: [Validators.required]}),
    targetUnits: new FormControl(2500, {nonNullable: true, validators: [Validators.required, Validators.min(1)]}),
    customerOrderRef: new FormControl('CUST-DEMO-881', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly outputForm = new FormGroup({
    orderId: new FormControl('PO-2026-1041', {nonNullable: true}),
    goodUnits: new FormControl(6400, {nonNullable: true}),
    rejectedUnits: new FormControl(12, {nonNullable: true}),
    reworkUnits: new FormControl(12, {nonNullable: true}),
  });

  submitOrder(): void {
    if (this.orderForm.invalid) return;
    const v = this.orderForm.getRawValue();
    void this.store.createOrder({
      recipeVersionId: v.recipeVersionId,
      targetUnits: v.targetUnits,
      shiftName: 'Shift B (14:00–22:00)',
      scheduledStart: new Date().toISOString(),
      scheduledEnd: new Date(Date.now() + 4 * 3600_000).toISOString(),
      dispatchDeadline: new Date(Date.now() + 10 * 3600_000).toISOString(),
      customerOrderRef: v.customerOrderRef,
    });
    this.showCreateForm.set(false);
  }

  transition(id: string, status: OrderStatus): void {
    void this.store.transitionOrder(id, status);
  }

  recordTranche(id: string): void {
    void this.store.recordOutput(id, 1200, 4, 0);
  }

  submitCustomOutput(): void {
    const v = this.outputForm.getRawValue();
    void this.store.recordOutput(v.orderId, v.goodUnits, v.rejectedUnits, v.reworkUnits);
  }
}

@Component({
  selector: 'app-recipes-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Version-Controlled Recipes & Allergen Declarations</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Approved recipes are immutable. Changes require a drafted revision, explicit revision reason, and QA approval.
            </p>
          </div>
        </div>

        <div class="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
          @for (r of store.recipes(); track r.id) {
            <div class="border rounded-xl p-4" [class]="r.status === 'approved' ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200 bg-[#F8F9FA]'">
              <div class="flex items-center justify-between gap-2">
                <span class="font-mono text-xs font-semibold text-[#0F1D32]">
                  {{ r.recipeCode }} · {{ r.versionNumber }}
                </span>
                <span class="text-xs font-semibold" [class]="r.status === 'approved' ? 'text-emerald-700' : r.status === 'draft' ? 'text-amber-700' : 'text-slate-500'">
                  {{ r.status }}
                </span>
              </div>
              <h3 class="mt-1 text-base font-semibold text-[#0F1D32]">{{ r.productName }}</h3>
              <div class="mt-1 text-xs text-slate-600">
                Batch: {{ r.batchSizeKg }} kg · Expected Yield: {{ r.expectedYieldUnits }} units ({{ r.unitWeightGrams }}g)
              </div>
              <div class="mt-2 text-xs text-slate-700">
                Allergens: <strong>{{ r.allergens.length ? r.allergens.join(', ') : 'None declared' }}</strong>
              </div>
              <div class="mt-1 text-[11px] text-slate-600">
                Label: <span class="font-mono">{{ r.approvedLabelTemplateId }} ({{ r.approvedLabelVersion }})</span>
              </div>
              <div class="mt-2 text-[11px] text-slate-600">
                Revision note: {{ r.revisionReason }}
              </div>
              @if (r.approvedBy) {
                <div class="mt-1 text-[11px] text-slate-500">
                  Approved by {{ r.approvedBy }} · {{ r.approvedAt | date:'dd MMM yyyy' }}
                </div>
              }

              <div class="mt-3 pt-3 border-t border-slate-200 flex flex-wrap gap-2">
                <button
                  type="button"
                  (click)="selectedRecipeId.set(r.id)"
                  class="px-3 py-1.5 text-xs font-medium border border-slate-300 bg-white rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  Inspect BOM & HACCP
                </button>
                @if (r.status === 'draft') {
                  <button
                    type="button"
                    (click)="store.approveRecipe(r.id)"
                    class="px-3 py-1.5 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
                  >
                    Approve Draft
                  </button>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Selected Recipe Detail & New Revision Form -->
      @if (selectedRecipe(); as rec) {
        <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-5">
          <div class="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
            <div>
              <h3 class="text-base font-semibold text-[#0F1D32]">
                {{ rec.recipeCode }} {{ rec.versionNumber }} — Ingredients, Packaging BOM & Synthetic Process Limits
              </h3>
              <p class="text-xs text-slate-600">Cross-contact: {{ rec.crossContactNotes }}</p>
            </div>
            <form [formGroup]="revisionForm" (ngSubmit)="draftRevision(rec.id)" class="flex flex-wrap items-center gap-2">
              <input formControlName="versionNumber" placeholder="e.g. v2.2" class="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg w-24 font-mono" />
              <input formControlName="revisionReason" placeholder="Revision reason..." class="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg w-56" />
              <button type="submit" [disabled]="revisionForm.invalid" class="px-3 py-1.5 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer">
                Draft Revision
              </button>
            </form>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 class="text-xs font-semibold text-slate-700 mb-2">Recipe Ingredients (Per {{ rec.batchSizeKg }} kg Batch)</h4>
              <table class="w-full text-left text-xs">
                <thead>
                  <tr class="border-b border-slate-200 text-slate-500">
                    <th class="py-2">Code / Material</th>
                    <th class="py-2 text-right">Qty</th>
                    <th class="py-2 pl-3">Allergen / Prep</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  @for (ing of rec.ingredients; track ing.id) {
                    <tr>
                      <td class="py-2 font-medium text-[#0F1D32]">
                        <span class="font-mono text-[11px] text-slate-500">{{ ing.materialCode }}</span> · {{ ing.materialName }}
                      </td>
                      <td class="py-2 text-right font-mono tabular-nums">{{ ing.quantityPerBatch }} {{ ing.unit }}</td>
                      <td class="py-2 pl-3 text-slate-600">{{ ing.allergen ?? 'None' }} · {{ ing.prepInstruction }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <div>
              <h4 class="text-xs font-semibold text-slate-700 mb-2">Site-Approved Process Limits (Explicitly Marked Synthetic)</h4>
              <table class="w-full text-left text-xs">
                <thead>
                  <tr class="border-b border-slate-200 text-slate-500">
                    <th class="py-2">Parameter</th>
                    <th class="py-2">Target Spec</th>
                    <th class="py-2">CCP</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  @for (lim of rec.processLimits; track lim.parameter) {
                    <tr>
                      <td class="py-2 font-medium text-[#0F1D32]">
                        {{ lim.parameter }}
                        <div class="text-[11px] text-slate-500">{{ lim.syntheticNote }}</div>
                      </td>
                      <td class="py-2 font-mono text-xs">{{ lim.target }}</td>
                      <td class="py-2 font-semibold" [class]="lim.haccpCritical ? 'text-red-700' : 'text-slate-600'">
                        {{ lim.haccpCritical ? 'CCP' : 'Control' }}
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class RecipesView {
  readonly store = inject(FactoryStore);
  readonly selectedRecipeId = signal<string>('RCP-CVMT-V2_1');

  readonly revisionForm = new FormGroup({
    versionNumber: new FormControl('v2.2', {nonNullable: true, validators: [Validators.required]}),
    revisionReason: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  selectedRecipe() {
    const id = this.selectedRecipeId();
    return this.store.recipes().find((r) => r.id === id) ?? this.store.recipes()[0] ?? null;
  }

  draftRevision(sourceId: string): void {
    if (this.revisionForm.invalid) return;
    const v = this.revisionForm.getRawValue();
    void this.store.createRecipeRevision(sourceId, v.versionNumber, v.revisionReason);
    this.revisionForm.patchValue({revisionReason: ''});
  }
}

@Component({
  selector: 'app-preparation-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h2 class="text-lg font-semibold text-[#0F1D32]">Preparation, Cooking & Blast Cooling Execution</h2>
        <p class="text-xs text-slate-600 mt-0.5">
          Setpoints are stored separately from measured sensor values. Deviations automatically open quality holds for disposition. Synthetic limits shown are site demo values only.
        </p>

        <form [formGroup]="procForm" (ngSubmit)="submitEvent()" class="mt-4 p-4 bg-[#F7F5F0] border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-6 gap-3 items-end">
          <div>
            <label for="proc-order" class="block text-xs font-medium text-slate-700 mb-1">Order</label>
            <select id="proc-order" formControlName="orderId" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono">
              @for (o of store.snapshot()?.orders ?? []; track o.id) {
                <option [value]="o.id">{{ o.orderNumber }}</option>
              }
            </select>
          </div>
          <div>
            <label for="proc-stn" class="block text-xs font-medium text-slate-700 mb-1">Station</label>
            <select id="proc-stn" formControlName="stationId" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg">
              <option value="STN-WASH">Produce Wash (WSH-01)</option>
              <option value="STN-CUT">Rotary Dicer (CUT-01)</option>
              <option value="STN-COOK">Steam Kettle (CKT-01)</option>
              <option value="STN-COOL">Blast Chiller (BCL-01)</option>
            </select>
          </div>
          <div>
            <label for="proc-sp" class="block text-xs font-medium text-slate-700 mb-1">Setpoint</label>
            <input id="proc-sp" type="number" step="0.1" formControlName="setpointValue" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <div>
            <label for="proc-meas" class="block text-xs font-medium text-slate-700 mb-1">Measured Value</label>
            <input id="proc-meas" type="number" step="0.1" formControlName="measuredValue" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <div>
            <label for="proc-out" class="block text-xs font-medium text-slate-700 mb-1">Output Qty (kg)</label>
            <input id="proc-out" type="number" formControlName="outputQuantity" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
          </div>
          <button type="submit" class="px-4 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer">
            Log Process Step
          </button>
        </form>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Timestamp</th>
                <th class="py-2 pr-3 font-medium">Station · Sensor</th>
                <th class="py-2 pr-3 font-medium">Order / Batch</th>
                <th class="py-2 pr-3 font-medium text-right">Setpoint</th>
                <th class="py-2 pr-3 font-medium text-right">Measured</th>
                <th class="py-2 pr-3 font-medium text-right">Output</th>
                <th class="py-2 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (ev of store.processingEvents(); track ev.id) {
                <tr>
                  <td class="py-2.5 pr-3 font-mono text-slate-600">{{ ev.recordedAt | date:'dd MMM HH:mm' }}</td>
                  <td class="py-2.5 pr-3">
                    <div class="font-medium text-[#0F1D32]">{{ ev.stationName }}</div>
                    <div class="text-[11px] font-mono text-slate-500">{{ ev.sensorId }} · Cal {{ ev.calibrationStatus }} · {{ ev.operatorName }}</div>
                  </td>
                  <td class="py-2.5 pr-3 font-mono">{{ ev.orderId }}</td>
                  <td class="py-2.5 pr-3 text-right font-mono tabular-nums">{{ ev.setpointValue ?? '—' }} {{ ev.unit }}</td>
                  <td class="py-2.5 pr-3 text-right font-mono tabular-nums font-semibold">{{ ev.measuredValue ?? '—' }} {{ ev.unit }}</td>
                  <td class="py-2.5 pr-3 text-right font-mono tabular-nums">{{ ev.outputQuantity }} {{ ev.outputUnit }}</td>
                  <td class="py-2.5 text-right font-semibold" [class]="ev.deviationFlag ? 'text-red-700' : 'text-emerald-700'">
                    {{ ev.deviationFlag ? 'Deviation Held' : 'Within Limit' }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class PreparationView {
  readonly store = inject(FactoryStore);

  readonly procForm = new FormGroup({
    orderId: new FormControl('PO-2026-1041', {nonNullable: true}),
    stationId: new FormControl('STN-COOK', {nonNullable: true}),
    setpointValue: new FormControl(76.0, {nonNullable: true}),
    measuredValue: new FormControl(77.8, {nonNullable: true}),
    outputQuantity: new FormControl(1250, {nonNullable: true}),
  });

  submitEvent(): void {
    const v = this.procForm.getRawValue();
    void this.store.recordProcessing({
      orderId: v.orderId,
      stationId: v.stationId,
      ingredientLotIds: ['LOT-CAR-01A', 'LOT-BRO-02A', 'LOT-PEP-03A'],
      setpointValue: v.setpointValue,
      measuredValue: v.measuredValue,
      unit: '°C',
      durationMinutes: 25,
      outputQuantity: v.outputQuantity,
      outputUnit: 'kg',
    });
  }
}
