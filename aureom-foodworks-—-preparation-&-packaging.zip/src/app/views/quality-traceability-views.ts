import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {DatePipe, DecimalPipe} from '@angular/common';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore} from '../services/factory-store';

@Component({
  selector: 'app-quality-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DatePipe],
  template: `
    <div class="space-y-6">
      <!-- Authorised Order QA Release Gate -->
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Quality Inspections, Holds & Authorised Release</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Missing inspection results remain <strong>Pending</strong> and are never inferred as passing. Release requires Quality or Admin role with zero pending checks or open holds.
            </p>
          </div>
          <div class="flex flex-wrap gap-2">
            <button
              type="button"
              (click)="store.releaseOrderGoods('PO-2026-1041', 'released', 'All CCPs, seal integrity, and micro screen verified')"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified_user</mat-icon>
              Authorise QA Release (PO-2026-1041)
            </button>
          </div>
        </div>

        <!-- Quality Checks Table -->
        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Plan & Check Type</th>
                <th class="py-2 pr-3 font-medium">Sampling & Spec</th>
                <th class="py-2 pr-3 font-medium">Measured</th>
                <th class="py-2 pr-3 font-medium">Result</th>
                <th class="py-2 font-medium text-right">Record Result</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (qc of store.qualityChecks(); track qc.id) {
                <tr>
                  <td class="py-3 pr-3">
                    <div class="font-semibold text-[#0F1D32]">{{ qc.checkType }}</div>
                    <div class="text-[11px] text-slate-500">{{ qc.planName }} · {{ qc.orderId ?? qc.lotId }}</div>
                  </td>
                  <td class="py-3 pr-3 text-slate-700">
                    <div>{{ qc.targetSpec }}</div>
                    <div class="text-[11px] text-slate-500">{{ qc.samplingInstruction }}</div>
                  </td>
                  <td class="py-3 pr-3 font-mono font-semibold">
                    {{ qc.measuredValue ?? 'Missing / Pending' }}
                  </td>
                  <td class="py-3 pr-3 font-semibold" [class]="qc.result === 'pass' ? 'text-emerald-700' : qc.result === 'fail' ? 'text-red-700' : 'text-amber-700'">
                    {{ qc.result }}
                  </td>
                  <td class="py-3 text-right whitespace-nowrap space-x-1.5">
                    @if (qc.result === 'pending') {
                      <button
                        type="button"
                        (click)="recordPass(qc.id, qc.checkType)"
                        class="px-2.5 py-1 bg-emerald-700 text-white rounded hover:bg-emerald-800 cursor-pointer"
                      >
                        Record Pass
                      </button>
                      <button
                        type="button"
                        (click)="recordFail(qc.id)"
                        class="px-2.5 py-1 bg-red-700 text-white rounded hover:bg-red-800 cursor-pointer"
                      >
                        Record Fail
                      </button>
                    } @else {
                      <span class="text-[11px] text-slate-500">
                        {{ qc.inspectorName }} · {{ qc.recordedAt | date:'dd MMM HH:mm' }}
                      </span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Quality Holds & CAPA -->
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h3 class="text-base font-semibold text-[#0F1D32]">Batch Holds, Nonconformances & Disposition</h3>
        <div class="mt-3 space-y-3">
          @for (h of store.qualityHolds(); track h.id) {
            <div class="p-4 rounded-lg border" [class]="h.status === 'closed' ? 'border-slate-200 bg-[#F8F9FA]' : 'border-red-300 bg-red-50/60'">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div class="font-mono text-xs font-semibold text-[#0F1D32]">
                  {{ h.id }} · {{ h.reasonCode }} · {{ h.severity }}
                </div>
                <div class="text-xs font-semibold" [class]="h.status === 'closed' ? 'text-emerald-700' : 'text-red-700'">
                  {{ h.status }} (Disposition: {{ h.disposition }})
                </div>
              </div>
              <p class="mt-1 text-xs text-slate-800">{{ h.description }}</p>
              <div class="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600">
                <span>Opened by {{ h.openedBy }} · {{ h.openedAt | date:'dd MMM HH:mm' }}</span>
                @if (h.status !== 'closed') {
                  <div class="flex gap-2">
                    <button
                      type="button"
                      (click)="store.closeHold(h.id, 'rework', 'Segregated affected units and verified corrective setup')"
                      class="px-3 py-1.5 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer"
                    >
                      Close Hold (Rework Disposition)
                    </button>
                    <button
                      type="button"
                      (click)="store.closeHold(h.id, 'release', 'Verified compliant under QA inspection')"
                      class="px-3 py-1.5 text-xs font-semibold bg-emerald-700 text-white rounded-lg cursor-pointer"
                    >
                      Close & Release
                    </button>
                  </div>
                } @else {
                  <span>CAPA: {{ h.correctiveAction }}</span>
                }
              </div>
            </div>
          } @empty {
            <p class="text-xs text-slate-500">No quality holds recorded.</p>
          }
        </div>
      </div>
    </div>
  `,
})
export class QualityView {
  readonly store = inject(FactoryStore);

  recordPass(checkId: string, checkType: string): void {
    const val = checkType === 'seal_integrity' ? '0 leaks (4.4 mm seal)' : '<100 cfu/g (Verified)';
    void this.store.recordQualityCheck(checkId, val, 'pass', 'Verified against synthetic site release criteria.');
  }

  recordFail(checkId: string): void {
    void this.store.recordQualityCheck(checkId, 'Out-of-spec failure', 'fail', 'Triggered nonconformance hold.');
  }
}

@Component({
  selector: 'app-traceability-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DecimalPipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">End-to-End Batch Genealogy & Recall Simulation</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Trace supplier lots forward to shipments or finished pallets backward to raw materials, with explicit mass-balance reconciliation.
            </p>
          </div>
          <a
            [href]="'/api/traceability/export?q=' + encodeQuery(lastQuery())"
            class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg hover:bg-slate-800"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">download</mat-icon>
            Download CSV Report
          </a>
        </div>

        <form [formGroup]="traceForm" (ngSubmit)="executeTrace()" class="mt-4 flex flex-wrap items-center gap-2">
          <input
            formControlName="query"
            placeholder="Enter Lot ID, Batch Code, SSCC, or Shipment..."
            class="px-3 py-2 text-xs border border-slate-300 rounded-lg w-72 font-mono"
          />
          <select formControlName="direction" class="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white">
            <option value="full">Full Graph (Forward + Backward)</option>
            <option value="forward">Forward Recall Trace</option>
            <option value="backward">Backward Root-Cause Trace</option>
          </select>
          <button type="submit" class="px-4 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg cursor-pointer">
            Run Trace
          </button>
          <button type="button" (click)="quickTrace('LOT-CAR-01A')" class="px-3 py-2 text-xs border border-slate-300 bg-[#F8F9FA] rounded-lg cursor-pointer">
            Trace Carrot Lot LOT-CAR-01A
          </button>
          <button type="button" (click)="quickTrace('PLT-261120-001')" class="px-3 py-2 text-xs border border-slate-300 bg-[#F8F9FA] rounded-lg cursor-pointer">
            Trace Pallet PLT-261120-001
          </button>
        </form>

        @if (store.traceResult(); as tr) {
          <!-- Mass-Balance Reconciliation -->
          <div class="mt-5 grid grid-cols-2 md:grid-cols-5 gap-3">
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Ingredient Input</div>
              <div class="mt-1 font-mono text-base font-semibold tabular-nums">{{ tr.reconciliation.totalIngredientInputKg | number }} kg</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Good Output Units</div>
              <div class="mt-1 font-mono text-base font-semibold tabular-nums text-emerald-700">{{ tr.reconciliation.actualGoodUnits | number }}</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Estimated Output Mass</div>
              <div class="mt-1 font-mono text-base font-semibold tabular-nums">{{ tr.reconciliation.estimatedOutputKg | number }} kg</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Recorded Waste</div>
              <div class="mt-1 font-mono text-base font-semibold tabular-nums">{{ tr.reconciliation.recordedWasteKg | number }} kg</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Unresolved Variance</div>
              <div class="mt-1 font-mono text-base font-semibold tabular-nums text-amber-700">{{ tr.reconciliation.unresolvedVarianceKg | number }} kg</div>
            </div>
          </div>

          <!-- Linked Genealogy Table -->
          <div class="mt-5 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 class="text-xs font-semibold text-slate-700 mb-2">Genealogy Links ({{ tr.edges.length }})</h3>
              <table class="w-full text-left text-xs">
                <thead>
                  <tr class="border-b border-slate-200 text-slate-500">
                    <th class="py-2">Parent</th>
                    <th class="py-2">Relationship</th>
                    <th class="py-2">Child</th>
                    <th class="py-2 text-right">Qty</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  @for (e of tr.edges; track e.id) {
                    <tr>
                      <td class="py-2 font-mono text-[#0F1D32]">{{ e.parentId }}</td>
                      <td class="py-2 text-slate-500">{{ e.relationship }}</td>
                      <td class="py-2 font-mono text-[#0F1D32]">{{ e.childId }}</td>
                      <td class="py-2 text-right font-mono tabular-nums">{{ e.quantity }} {{ e.unit }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <div class="space-y-4">
              <div>
                <h3 class="text-xs font-semibold text-slate-700 mb-2">Affected Pallets ({{ tr.pallets.length }}) & Shipments ({{ tr.shipments.length }})</h3>
                <div class="space-y-2 text-xs">
                  @for (p of tr.pallets; track p['id']) {
                    <div class="p-2.5 rounded border border-slate-200 bg-[#F8F9FA] flex justify-between font-mono">
                      <span>{{ p['id'] }} · SSCC {{ p['sscc_code'] }}</span>
                      <span>{{ p['total_units'] }} units · {{ p['quality_status'] }}</span>
                    </div>
                  }
                  @for (s of tr.shipments; track s['id']) {
                    <div class="p-2.5 rounded border border-emerald-300 bg-emerald-50/40 flex justify-between font-mono">
                      <span>{{ s['shipment_number'] }} · {{ s['customer_name'] }}</span>
                      <span>{{ s['total_units'] }} units</span>
                    </div>
                  }
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class TraceabilityView {
  readonly store = inject(FactoryStore);
  readonly lastQuery = signal('BAT-261120-01');

  readonly traceForm = new FormGroup({
    query: new FormControl('BAT-261120-01', {nonNullable: true}),
    direction: new FormControl<'forward' | 'backward' | 'full'>('full', {nonNullable: true}),
  });

  executeTrace(): void {
    const v = this.traceForm.getRawValue();
    this.lastQuery.set(v.query);
    void this.store.runTrace(v.query, v.direction);
  }

  quickTrace(id: string): void {
    this.traceForm.patchValue({query: id, direction: 'full'});
    this.lastQuery.set(id);
    void this.store.runTrace(id, 'full');
  }

  encodeQuery(val: string): string {
    return encodeURIComponent(val);
  }
}
