import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {DatePipe, DecimalPipe} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore} from '../services/factory-store';
import {FactoryLineDiagram} from '../components/factory-line-diagram';
import {StationState} from '../../shared/domain';

@Component({
  selector: 'app-overview-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DatePipe, DecimalPipe, FactoryLineDiagram],
  template: `
    @if (store.snapshot(); as snap) {
      <div class="space-y-6">
        <!-- Synthetic Factory Notice & Guided 10-Step Workflow Strip -->
        <section class="bg-white border border-slate-200 rounded-xl p-5">
          <div class="flex flex-wrap items-start justify-between gap-4">
            <div class="max-w-3xl">
              <div class="text-xs font-medium text-slate-600">
                Site 01 · Line 01 Ready Meals Chilled · {{ snap.syntheticBanner }}
              </div>
              <h2 class="mt-1 text-lg font-semibold text-[#0F1D32]">
                Shift Overview — 10,000 Chilled Vegetable Meal Trays (PO-2026-1041)
              </h2>
              <p class="mt-1 text-sm text-slate-600">
                Real-time summary of active production orders, material constraints, quality holds, and dispatch readiness. Select any metric card below to inspect its underlying ledger or operational records.
              </p>
            </div>
            <div class="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                (click)="showPlaybook.set(!showPlaybook())"
                class="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg border border-slate-300 bg-[#F8F9FA] text-[#0F1D32] hover:bg-slate-200/70 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">playlist_play</mat-icon>
                {{ showPlaybook() ? 'Hide Workflow Guide' : '10-Step Demo Guide' }}
              </button>
              <button
                type="button"
                (click)="store.stepSimulation()"
                [disabled]="snap.operatingMode !== 'simulation' || snap.telemetryOutageSimulated"
                class="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#047857] text-white hover:bg-emerald-800 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">skip_next</mat-icon>
                Step Simulation
              </button>
            </div>
          </div>

          @if (showPlaybook()) {
            <div class="mt-4 pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              @for (step of demoSteps; track step.num) {
                <button
                  type="button"
                  (click)="store.activeSection.set(step.target)"
                  class="text-left p-3 rounded-lg border border-slate-200 bg-[#F7F5F0] hover:border-[#0F1D32] transition-colors cursor-pointer"
                >
                  <div class="font-mono text-[11px] font-semibold text-emerald-800">
                    Step {{ step.num }} · {{ step.module }}
                  </div>
                  <div class="mt-1 font-medium text-[#0F1D32]">{{ step.title }}</div>
                </button>
              }
            </div>
          }
        </section>

        <!-- Clickable Operational KPI Strip -->
        <section class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <button
            type="button"
            (click)="store.activeSection.set('reports')"
            class="text-left bg-white border border-slate-200 hover:border-[#0F1D32] rounded-xl p-4 transition-colors cursor-pointer"
          >
            <div class="text-xs text-slate-600">Throughput</div>
            <div class="mt-1 font-mono text-xl font-semibold text-[#0F1D32] tabular-nums">
              {{ snap.oee.throughputUnitsPerHour | number }}
              <span class="text-xs font-normal text-slate-500">u/hr</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-500">OEE {{ snap.oee.oeePct }}% · View Calc</div>
          </button>

          <button
            type="button"
            (click)="store.activeSection.set('production')"
            class="text-left bg-white border border-slate-200 hover:border-[#0F1D32] rounded-xl p-4 transition-colors cursor-pointer"
          >
            <div class="text-xs text-slate-600">First-Pass Yield</div>
            <div class="mt-1 font-mono text-xl font-semibold text-emerald-700 tabular-nums">
              {{ snap.oee.yieldPct }}%
            </div>
            <div class="mt-1 text-[11px] text-slate-500">
              {{ snap.oee.rejectsCount }} rejects · Orders
            </div>
          </button>

          <button
            type="button"
            (click)="store.activeSection.set('reports')"
            class="text-left bg-white border border-slate-200 hover:border-[#0F1D32] rounded-xl p-4 transition-colors cursor-pointer"
          >
            <div class="text-xs text-slate-600">Unplanned Downtime</div>
            <div class="mt-1 font-mono text-xl font-semibold text-[#0F1D32] tabular-nums">
              {{ snap.oee.downtimeMinutes }}
              <span class="text-xs font-normal text-slate-500">min</span>
            </div>
            <div class="mt-1 text-[11px] text-slate-500">45m changeover excl.</div>
          </button>

          <button
            type="button"
            (click)="store.activeSection.set('quality')"
            class="text-left border rounded-xl p-4 transition-colors cursor-pointer"
            [class]="snap.activeHoldsCount > 0 ? 'bg-red-50/70 border-red-300 hover:border-red-500' : 'bg-white border-slate-200 hover:border-[#0F1D32]'"
          >
            <div class="text-xs text-slate-600">Open Quality Holds</div>
            <div
              class="mt-1 font-mono text-xl font-semibold tabular-nums"
              [class]="snap.activeHoldsCount > 0 ? 'text-red-700' : 'text-[#0F1D32]'"
            >
              {{ snap.activeHoldsCount }}
            </div>
            <div class="mt-1 text-[11px] text-slate-600">
              {{ snap.activeHoldsCount > 0 ? 'Action required' : 'No active holds' }}
            </div>
          </button>

          <button
            type="button"
            (click)="store.activeSection.set('ingredients')"
            class="text-left border rounded-xl p-4 transition-colors cursor-pointer"
            [class]="snap.expiringLotsCount > 0 ? 'bg-amber-50/70 border-amber-300 hover:border-amber-500' : 'bg-white border-slate-200 hover:border-[#0F1D32]'"
          >
            <div class="text-xs text-slate-600">Expiring Stock (&le;72h)</div>
            <div
              class="mt-1 font-mono text-xl font-semibold tabular-nums"
              [class]="snap.expiringLotsCount > 0 ? 'text-amber-800' : 'text-[#0F1D32]'"
            >
              {{ snap.expiringLotsCount }}
            </div>
            <div class="mt-1 text-[11px] text-slate-600">FEFO Priority Lots</div>
          </button>

          <button
            type="button"
            (click)="store.activeSection.set('planning')"
            class="text-left border rounded-xl p-4 transition-colors cursor-pointer"
            [class]="snap.shortageCount > 0 ? 'bg-amber-50/70 border-amber-300 hover:border-amber-500' : 'bg-white border-slate-200 hover:border-[#0F1D32]'"
          >
            <div class="text-xs text-slate-600">Material Shortages</div>
            <div
              class="mt-1 font-mono text-xl font-semibold tabular-nums"
              [class]="snap.shortageCount > 0 ? 'text-amber-800' : 'text-[#0F1D32]'"
            >
              {{ snap.shortageCount }}
            </div>
            <div class="mt-1 text-[11px] text-slate-600">
              {{ snap.shortageCount > 0 ? 'PO-2026-1042 Bowls' : 'All BOMs covered' }}
            </div>
          </button>
        </section>

        <!-- Interactive Factory Flow Diagram -->
        <app-factory-line-diagram
          [stations]="snap.stations"
          [selectedId]="store.selectedStationId()"
          [dataStale]="snap.dataStale"
          [reducedMotion]="store.reducedMotion()"
          (stationSelected)="store.selectedStationId.set($event)"
        />

        <!-- Selected Station Inspector -->
        @if (store.selectedStation(); as st) {
          <section class="bg-[#EAECEF] border border-slate-300 rounded-xl p-5">
            <div class="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div class="font-mono text-xs text-slate-600">
                  {{ st.code }} · Sensor {{ st.sensorId }} · Calibration due {{ st.calibrationDue }}
                </div>
                <h3 class="mt-1 text-base font-semibold text-[#0F1D32]">
                  {{ st.name }} — Station Inspector
                </h3>
                <div class="mt-2 flex flex-wrap items-center gap-6 text-xs text-slate-700">
                  <span>
                    Operator: <strong class="text-[#0F1D32]">{{ st.activeOperator ?? 'Unassigned' }}</strong>
                  </span>
                  <span>
                    Setpoint: <strong class="font-mono tabular-nums">{{ st.setpointValue ?? '—' }} {{ st.unit }}</strong>
                  </span>
                  <span>
                    Last Observation: <strong class="font-mono tabular-nums">{{ st.measuredValue ?? '—' }} {{ st.unit }}</strong>
                    ({{ st.lastObservationAt | date:'HH:mm:ss' }})
                  </span>
                  <span>
                    Buffer: <strong class="font-mono tabular-nums">{{ st.bufferCount }}/{{ st.bufferCapacity }}</strong>
                  </span>
                </div>
                @if (st.faultReason) {
                  <p class="mt-2 text-xs font-semibold text-red-700">
                    Active Fault: {{ st.faultReason }}
                  </p>
                }
              </div>
              <div class="flex flex-wrap items-center gap-2">
                @for (targetState of stationStates; track targetState) {
                  <button
                    type="button"
                    (click)="setStationState(st.id, targetState)"
                    class="px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap cursor-pointer"
                    [class]="st.state === targetState ? 'bg-[#0F1D32] text-white border-[#0F1D32]' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'"
                  >
                    {{ targetState }}
                  </button>
                }
                <button
                  type="button"
                  (click)="store.selectedStationId.set(null)"
                  class="px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 bg-white text-slate-600 hover:text-[#0F1D32] cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </section>
        }

        <!-- Active Orders & Dispatch Commitments Split -->
        <section class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div class="bg-white border border-slate-200 rounded-xl p-5">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 class="text-base font-semibold text-[#0F1D32]">Production Orders & Shift Progress</h3>
              <button
                type="button"
                (click)="store.activeSection.set('production')"
                class="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
              >
                Manage Orders
              </button>
            </div>
            <div class="mt-4 space-y-4">
              @for (order of snap.orders; track order.id) {
                <div class="p-3.5 rounded-lg border border-slate-200 bg-[#F8F9FA]">
                  <div class="flex items-center justify-between gap-2">
                    <div class="font-mono text-xs font-semibold text-[#0F1D32]">
                      {{ order.orderNumber }} · {{ order.recipeCode }}
                    </div>
                    <div class="text-xs font-medium text-slate-700">
                      Order: <span class="font-semibold">{{ order.status }}</span> · QA: <span class="font-semibold">{{ order.qualityReleaseStatus }}</span>
                    </div>
                  </div>
                  <div class="mt-1 text-sm font-semibold text-[#0F1D32]">{{ order.productName }}</div>
                  <div class="mt-2 w-full h-2 bg-slate-200 rounded overflow-hidden">
                    <div
                      class="h-full bg-emerald-700 transition-all"
                      [style.width.%]="progressPct(order.producedUnits, order.targetUnits)"
                    ></div>
                  </div>
                  <div class="mt-2 flex items-center justify-between text-xs text-slate-600 font-mono tabular-nums">
                    <span>{{ order.producedUnits | number }} / {{ order.targetUnits | number }} trays</span>
                    <span>{{ order.shiftName }}</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="bg-white border border-slate-200 rounded-xl p-5">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 class="text-base font-semibold text-[#0F1D32]">Upcoming Dispatch & Attention Items</h3>
              <button
                type="button"
                (click)="store.activeSection.set('warehouse')"
                class="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
              >
                Open Warehouse
              </button>
            </div>
            <div class="mt-4 overflow-x-auto">
              <table class="w-full text-left text-xs">
                <thead>
                  <tr class="border-b border-slate-200 text-slate-500">
                    <th class="py-2 pr-3 font-medium">Order</th>
                    <th class="py-2 pr-3 font-medium">Customer Ref</th>
                    <th class="py-2 pr-3 font-medium text-right">Staged / Target</th>
                    <th class="py-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  @for (dc of snap.dispatchCommitments; track dc.id) {
                    <tr>
                      <td class="py-2.5 pr-3 font-mono font-medium text-[#0F1D32]">{{ dc.orderNumber }}</td>
                      <td class="py-2.5 pr-3 text-slate-700">{{ dc.customer }}</td>
                      <td class="py-2.5 pr-3 text-right font-mono tabular-nums">
                        {{ dc.stagedUnits | number }} / {{ dc.targetUnits | number }}
                      </td>
                      <td class="py-2.5 text-right font-semibold" [class]="dc.status === 'at_risk' ? 'text-amber-700' : dc.status === 'dispatched' ? 'text-emerald-700' : 'text-[#0F1D32]'">
                        {{ dc.status }}
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-200 space-y-2 text-xs text-slate-700">
              <div class="flex items-center justify-between">
                <span>Packaging Consumption (PO-2026-1041)</span>
                <button
                  type="button"
                  (click)="store.activeSection.set('packaging')"
                  class="font-mono font-semibold text-[#0F1D32] hover:underline cursor-pointer"
                >
                  {{ store.packagingSetups()[0]?.labelsPrinted ?? 0 | number }} labels printed
                </button>
              </div>
              <div class="flex items-center justify-between">
                <span>Changeover / Cleaning Window</span>
                <span class="font-mono">Shift B 14:00 (45m Celery Washdown)</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    }
  `,
})
export class OverviewView {
  readonly store = inject(FactoryStore);
  readonly showPlaybook = signal<boolean>(false);

  readonly stationStates: StationState[] = [
    'running',
    'starved',
    'blocked',
    'cleaning',
    'changeover',
    'faulted',
    'stopped',
  ];

  readonly demoSteps = [
    {num: '01', module: 'Ingredients', title: 'Receive & QA-release quarantined carrot lot', target: 'ingredients' as const},
    {num: '02', module: 'Ingredients', title: 'Reserve FEFO ingredients & packaging for PO-2026-1041', target: 'ingredients' as const},
    {num: '03', module: 'Production', title: 'Release / monitor PO-2026-1041 (10,000 trays)', target: 'production' as const},
    {num: '04', module: 'Preparation', title: 'Log kettle cooking & blast chill CCP readings', target: 'preparation' as const},
    {num: '05', module: 'Production', title: 'Consume materials & record packaged tray output', target: 'production' as const},
    {num: '06', module: 'Packaging', title: 'Trigger simulated v1.0 label mismatch & auto-hold', target: 'packaging' as const},
    {num: '07', module: 'Packaging', title: 'Correct setup with v2.1 roll via QA/Supervisor', target: 'packaging' as const},
    {num: '08', module: 'Quality', title: 'Complete pending QC checks & release batch goods', target: 'quality' as const},
    {num: '09', module: 'Warehouse', title: 'Aggregate SSCC pallets & dispatch released shipment', target: 'warehouse' as const},
    {num: '10', module: 'Traceability', title: 'Trace lot → batch → pallet → shipment & reconcile', target: 'traceability' as const},
  ];

  progressPct(produced: number, target: number): number {
    if (!target) return 0;
    return Math.min(100, Math.round((produced / target) * 100));
  }

  setStationState(stationId: string, state: StationState): void {
    const faultReason = state === 'faulted' ? 'Manual fault test triggered by operator' : null;
    void this.store.setStationState(stationId, state, faultReason);
  }
}
