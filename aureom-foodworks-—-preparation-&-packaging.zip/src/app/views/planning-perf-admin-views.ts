import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {DatePipe, DecimalPipe} from '@angular/common';
import {ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore} from '../services/factory-store';

@Component({
  selector: 'app-maintenance-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h2 class="text-lg font-semibold text-[#0F1D32]">Asset Maintenance, Calibration & Inspection Advisories</h2>
        <p class="text-xs text-slate-600 mt-0.5">
          Optional predictive advisories suggest targeted human inspections with recorded evidence and uncertainty — they never fabricate remaining useful life or replace scheduled preventive maintenance.
        </p>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Work Order</th>
                <th class="py-2 pr-3 font-medium">Station & Type</th>
                <th class="py-2 pr-3 font-medium">Spare Parts & Evidence</th>
                <th class="py-2 pr-3 font-medium">Status</th>
                <th class="py-2 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (wo of store.workOrders(); track wo.id) {
                <tr>
                  <td class="py-3 pr-3 font-mono font-semibold text-[#0F1D32]">
                    {{ wo.id }}<br />
                    <span class="text-[11px] font-normal text-slate-500">Due {{ wo.dueAt | date:'dd MMM' }}</span>
                  </td>
                  <td class="py-3 pr-3">
                    <div class="font-medium text-[#0F1D32]">{{ wo.title }}</div>
                    <div class="text-[11px] text-slate-500">{{ wo.stationName }} · {{ wo.workType }} · {{ wo.priority }}</div>
                  </td>
                  <td class="py-3 pr-3 text-slate-700 max-w-md">
                    <div><strong>Parts:</strong> {{ wo.sparePartsRequired }}</div>
                    <div class="text-[11px] text-slate-500 mt-0.5">{{ wo.evidenceNote }}</div>
                  </td>
                  <td class="py-3 pr-3 font-semibold" [class]="wo.status === 'completed' ? 'text-emerald-700' : 'text-amber-700'">
                    {{ wo.status }}
                  </td>
                  <td class="py-3 text-right">
                    @if (wo.status !== 'completed') {
                      <button
                        type="button"
                        (click)="store.completeWorkOrder(wo.id, 'Inspected & verified by Maintenance Engineer')"
                        class="px-3 py-1.5 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer"
                      >
                        Complete
                      </button>
                    } @else {
                      <span class="text-[11px] text-slate-500">{{ wo.completedAt | date:'dd MMM HH:mm' }}</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Calibration Register -->
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h3 class="text-base font-semibold text-[#0F1D32]">Instrument Calibration Register</h3>
        <div class="mt-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          @for (st of store.snapshot()?.stations ?? []; track st.id) {
            <div class="p-3 rounded-lg border border-slate-200 bg-[#F8F9FA]">
              <div class="font-mono font-semibold text-[#0F1D32]">{{ st.sensorId }}</div>
              <div class="text-slate-600 mt-0.5 truncate">{{ st.name }}</div>
              <div class="mt-2 font-mono text-[11px]" [class]="st.calibrationValid ? 'text-emerald-700' : 'text-red-700'">
                Due {{ st.calibrationDue }} · {{ st.calibrationValid ? 'Valid' : 'Overdue' }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class MaintenanceView {
  readonly store = inject(FactoryStore);
}

@Component({
  selector: 'app-planning-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DecimalPipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Discrete-Event Digital Twin & Replanning</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Compares transparent scheduling baselines using seeded discrete-event simulation. Recommendations require Planner or Supervisor approval before modifying released orders.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="runScenario(false)"
              class="px-3.5 py-2 text-xs font-medium border border-slate-300 bg-[#F8F9FA] rounded-lg hover:bg-slate-200 cursor-pointer"
            >
              Simulate Nominal Shift
            </button>
            <button
              type="button"
              (click)="runScenario(true)"
              class="px-3.5 py-2 text-xs font-semibold bg-amber-700 text-white rounded-lg hover:bg-amber-800 cursor-pointer"
            >
              Scenario 2: Breakdown & Bowl Shortage
            </button>
          </div>
        </div>

        @if (store.planningComparison(); as pc) {
          <div class="mt-4 p-3.5 rounded-lg bg-[#EAECEF] border border-slate-300 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div>
              <strong>Random Seed:</strong> <span class="font-mono">{{ pc.seed }}</span> ·
              <strong>Scenario Mode:</strong> {{ pc.breakdownInjected ? 'Sealer Breakdown + PK-TRAY-400B Shortage' : 'Nominal' }}
            </div>
            <div class="font-mono tabular-nums">
              Forecast Rate: <strong>{{ pc.forecastVsActual.forecastUnitsPerHour | number }} u/hr</strong> vs
              Measured: <strong>{{ pc.forecastVsActual.measuredUnitsPerHour | number }} u/hr</strong>
              ({{ pc.forecastVsActual.deltaPct }}%)
            </div>
          </div>

          <div class="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-5">
            @for (strat of pc.strategies; track strat.strategyId) {
              <div class="border border-slate-200 rounded-xl p-4 bg-[#F8F9FA] flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between">
                    <h3 class="text-base font-semibold text-[#0F1D32]">{{ strat.strategyName }}</h3>
                    <span class="font-mono text-xs text-slate-500">±{{ strat.uncertaintyRangePct }}% uncertainty</span>
                  </div>
                  <p class="mt-1 text-xs text-slate-600">{{ strat.description }}</p>

                  <div class="mt-4 grid grid-cols-3 gap-2 text-xs font-mono tabular-nums">
                    <div class="p-2.5 bg-white border border-slate-200 rounded">
                      <div class="text-[11px] font-sans text-slate-500">Throughput</div>
                      <div class="font-semibold text-[#0F1D32]">{{ strat.throughputUnitsPerHour | number }} u/hr</div>
                    </div>
                    <div class="p-2.5 bg-white border border-slate-200 rounded">
                      <div class="text-[11px] font-sans text-slate-500">Lateness</div>
                      <div class="font-semibold" [class]="strat.latenessMinutes > 0 ? 'text-red-700' : 'text-emerald-700'">
                        {{ strat.latenessMinutes }} min
                      </div>
                    </div>
                    <div class="p-2.5 bg-white border border-slate-200 rounded">
                      <div class="text-[11px] font-sans text-slate-500">Est. Waste</div>
                      <div class="font-semibold text-[#0F1D32]">{{ strat.expectedWasteKg }} kg</div>
                    </div>
                  </div>

                  <div class="mt-3 text-xs text-slate-700">
                    <div class="font-semibold mb-1">Explicit Assumptions:</div>
                    <ul class="list-disc pl-4 space-y-0.5 text-[11px] text-slate-600">
                      @for (a of strat.assumptions; track a) {
                        <li>{{ a }}</li>
                      }
                    </ul>
                  </div>

                  @for (mc of strat.materialConstraints; track mc.materialCode) {
                    <div class="mt-3 p-2.5 rounded border text-xs font-mono" [class]="mc.status === 'shortage' ? 'bg-red-50 border-red-300 text-red-800' : 'bg-emerald-50 border-emerald-300 text-emerald-800'">
                      {{ mc.materialCode }}: {{ mc.available | number }} avail vs {{ mc.required | number }} req ({{ mc.status }})
                    </div>
                  }
                </div>

                <div class="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between gap-2">
                  <span class="text-xs text-slate-700">{{ strat.recommendedAction }}</span>
                  @if (strat.strategyId === 'split_batch_replan') {
                    <button
                      type="button"
                      (click)="store.approveReplan('PO-2026-1042', 1800, 'Approved split-lot replan due to PK-TRAY-400B shortage and sealer PM')"
                      class="px-3.5 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Approve Replan (1,800 Bowls)
                    </button>
                  }
                </div>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `,
})
export class PlanningView {
  readonly store = inject(FactoryStore);
  readonly seedVal = signal(20261120);

  runScenario(breakdown: boolean): void {
    void this.store.runPlanningSimulation(this.seedVal(), breakdown);
  }
}

@Component({
  selector: 'app-energy-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DecimalPipe, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h2 class="text-lg font-semibold text-[#0F1D32]">Energy & Water Resource Intensity</h2>
        <p class="text-xs text-slate-600 mt-0.5">
          Resource consumption normalised explicitly per 1,000 packaged 380g chilled meal trays produced.
        </p>

        @for (e of store.energyReadings(); track e.id) {
          <div class="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Electricity</div>
              <div class="mt-1 font-mono text-xl font-semibold tabular-nums">{{ e.electricityKwh | number:'1.1-1' }} kWh</div>
              <div class="text-[11px] font-mono text-slate-600">
                {{ (e.electricityKwh / (e.unitsProducedContext / 1000)) | number:'1.1-1' }} kWh / 1k trays
              </div>
            </div>
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Culinary Steam</div>
              <div class="mt-1 font-mono text-xl font-semibold tabular-nums">{{ e.steamKg | number:'1.0-0' }} kg</div>
              <div class="text-[11px] font-mono text-slate-600">
                {{ (e.steamKg / (e.unitsProducedContext / 1000)) | number:'1.1-1' }} kg / 1k trays
              </div>
            </div>
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Chilled Water Loop</div>
              <div class="mt-1 font-mono text-xl font-semibold tabular-nums">{{ e.chilledWaterLitres | number:'1.0-0' }} L</div>
              <div class="text-[11px] font-mono text-slate-600">
                {{ (e.chilledWaterLitres / (e.unitsProducedContext / 1000)) | number:'1.0-0' }} L / 1k trays
              </div>
            </div>
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Wash & CIP Water</div>
              <div class="mt-1 font-mono text-xl font-semibold tabular-nums">{{ e.processWaterLitres | number:'1.0-0' }} L</div>
              <div class="text-[11px] font-mono text-slate-600">
                {{ (e.processWaterLitres / (e.unitsProducedContext / 1000)) | number:'1.0-0' }} L / 1k trays
              </div>
            </div>
          </div>
          <div class="mt-3 text-[11px] text-slate-500 font-mono">
            Shift: {{ e.shiftName }} · Baseline Units: {{ e.unitsProducedContext | number }} trays · Logged {{ e.recordedAt | date:'dd MMM HH:mm' }}
          </div>
        }
      </div>
    </div>
  `,
})
export class EnergyView {
  readonly store = inject(FactoryStore);
}

@Component({
  selector: 'app-reports-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (store.snapshot(); as snap) {
      <div class="space-y-6">
        <div class="bg-white border border-slate-200 rounded-xl p-5">
          <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h2 class="text-lg font-semibold text-[#0F1D32]">OEE Calculation, Downtime & Yield Reporting</h2>
              <p class="text-xs text-slate-600 mt-0.5">
                Every metric is computed from documented shift definitions: Planned Production Time = {{ snap.oee.plannedProductionMinutes }} min, Ideal Cycle = {{ snap.oee.idealCycleSecondsPerUnit }} s/tray.
              </p>
            </div>
            <a
              href="/api/traceability/export?q=BAT-261120-01"
              class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">download</mat-icon>
              Export Batch Dossier CSV
            </a>
          </div>

          <div class="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Availability</div>
              <div class="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#0F1D32]">{{ snap.oee.availabilityPct }}%</div>
              <div class="text-[11px] text-slate-600">{{ snap.oee.actualRuntimeMinutes }} / {{ snap.oee.plannedProductionMinutes }} min</div>
            </div>
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Performance</div>
              <div class="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#0F1D32]">{{ snap.oee.performancePct }}%</div>
              <div class="text-[11px] text-slate-600">Ideal {{ snap.oee.idealCycleSecondsPerUnit }} s/unit</div>
            </div>
            <div class="p-4 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-xs text-slate-500">Quality</div>
              <div class="mt-1 font-mono text-2xl font-semibold tabular-nums text-emerald-700">{{ snap.oee.qualityPct }}%</div>
              <div class="text-[11px] text-slate-600">{{ snap.oee.rejectsCount }} rejected units</div>
            </div>
            <div class="p-4 rounded-lg bg-[#EAECEF] border border-slate-300">
              <div class="text-xs text-slate-700 font-semibold">Composite OEE</div>
              <div class="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#0F1D32]">{{ snap.oee.oeePct }}%</div>
              <div class="text-[11px] text-slate-600">{{ snap.oee.changeoverTreatment }}</div>
            </div>
          </div>

          <div class="mt-5">
            <h3 class="text-xs font-semibold text-slate-700 mb-2">Downtime Attribution</h3>
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500">
                  <th class="py-2">Reason</th>
                  <th class="py-2 text-right">Duration (min)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (dr of snap.oee.downtimeReasons; track dr.reason) {
                  <tr>
                    <td class="py-2 font-medium text-[#0F1D32]">{{ dr.reason }}</td>
                    <td class="py-2 text-right font-mono tabular-nums">{{ dr.minutes }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    }
  `,
})
export class ReportsView {
  readonly store = inject(FactoryStore);
}

@Component({
  selector: 'app-administration-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Administration, Backups, Resilience & Audit Log</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Demonstrate telemetry outage handling, SQLite database snapshots, role-based access enforcement, and reset the 10,000-tray seed environment.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            @if (store.snapshot()?.telemetryOutageSimulated) {
              <button
                type="button"
                (click)="store.toggleSimulatedOutage(false)"
                class="px-3.5 py-2 text-xs font-semibold bg-emerald-700 text-white rounded-lg cursor-pointer"
              >
                Restore Live Telemetry
              </button>
            } @else {
              <button
                type="button"
                (click)="store.toggleSimulatedOutage(true)"
                class="px-3.5 py-2 text-xs font-semibold bg-amber-700 text-white rounded-lg cursor-pointer"
              >
                Simulate Telemetry Outage
              </button>
            }
            <button
              type="button"
              (click)="store.createBackup()"
              class="px-3.5 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer"
            >
              Create DB Backup Snapshot
            </button>
            <button
              type="button"
              (click)="store.resetDemo()"
              class="px-3.5 py-2 text-xs font-medium border border-slate-300 bg-white rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              Reset Synthetic 10k Seed
            </button>
          </div>
        </div>

        @if (store.backups().length > 0) {
          <div class="mt-4">
            <h3 class="text-xs font-semibold text-slate-700 mb-2">Available Database Snapshots</h3>
            <div class="space-y-1.5 text-xs font-mono">
              @for (b of store.backups(); track b.fileName) {
                <div class="p-2.5 rounded border border-slate-200 bg-[#F8F9FA] flex justify-between">
                  <span>{{ b.fileName }}</span>
                  <span>{{ b.sizeBytes }} bytes · {{ b.modifiedAt | date:'dd MMM HH:mm:ss' }}</span>
                </div>
              }
            </div>
          </div>
        }

        <div class="mt-5">
          <h3 class="text-xs font-semibold text-slate-700 mb-2">Immutable Security & Operations Audit Log</h3>
          <div class="overflow-x-auto max-h-80 overflow-y-auto">
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500">
                  <th class="py-2 pr-3 font-medium">Time</th>
                  <th class="py-2 pr-3 font-medium">Actor · Role</th>
                  <th class="py-2 pr-3 font-medium">Action</th>
                  <th class="py-2 font-medium">Details</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (ev of store.auditEvents(); track ev.id) {
                  <tr>
                    <td class="py-2 pr-3 font-mono text-slate-500 whitespace-nowrap">{{ ev.createdAt | date:'dd MMM HH:mm:ss' }}</td>
                    <td class="py-2 pr-3 whitespace-nowrap">
                      <span class="font-medium text-[#0F1D32]">{{ ev.actor }}</span>
                      <span class="text-slate-500"> · {{ ev.role }}</span>
                    </td>
                    <td class="py-2 pr-3 font-mono font-semibold text-[#0F1D32]">{{ ev.action }}</td>
                    <td class="py-2 text-slate-700">{{ ev.details }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AdministrationView {
  readonly store = inject(FactoryStore);
}
