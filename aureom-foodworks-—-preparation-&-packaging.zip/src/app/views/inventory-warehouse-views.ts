import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {DatePipe, DecimalPipe} from '@angular/common';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {FactoryStore} from '../services/factory-store';

@Component({
  selector: 'app-ingredients-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule, DecimalPipe, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Ingredient & Packaging Lots (FEFO & Quarantine Control)</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Quarantined, expired, or rejected lots are strictly blocked from production issue. All movements append to an immutable ledger.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="showReceiveForm.set(!showReceiveForm())"
              class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">local_shipping</mat-icon>
              Receive PO Delivery
            </button>
            <button
              type="button"
              (click)="reserveBundle()"
              class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg hover:bg-slate-800 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">lock_clock</mat-icon>
              FEFO Reserve for PO-2026-1041
            </button>
          </div>
        </div>

        <!-- Barcode / QR Scanner Simulator & Filter -->
        <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div class="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            @for (k of ['all', 'ingredient', 'packaging']; track k) {
              <button
                type="button"
                (click)="kindFilter.set(k)"
                class="px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer"
                [class]="kindFilter() === k ? 'bg-white text-[#0F1D32] shadow-sm' : 'text-slate-600 hover:text-[#0F1D32]'"
              >
                {{ k === 'all' ? 'All Stock' : k === 'ingredient' ? 'Ingredients' : 'Packaging' }}
              </button>
            }
          </div>

          <form [formGroup]="scanForm" (ngSubmit)="runScan()" class="flex items-center gap-2">
            <input
              formControlName="barcode"
              placeholder="Scan barcode / lot UID (e.g. 010501234500101110GV881)"
              class="px-3 py-1.5 text-xs border border-slate-300 rounded-lg w-72 font-mono"
            />
            <button type="submit" class="px-3 py-1.5 text-xs font-medium border border-slate-300 bg-[#F8F9FA] rounded-lg hover:bg-slate-200 cursor-pointer">
              Scan Barcode
            </button>
          </form>
        </div>

        @if (scannedMessage()) {
          <div class="mt-3 p-3 rounded-lg bg-[#EAECEF] border border-slate-300 text-xs text-[#0F1D32]">
            {{ scannedMessage() }}
          </div>
        }

        @if (showReceiveForm()) {
          <form [formGroup]="receiveForm" (ngSubmit)="submitReceipt()" class="mt-4 p-4 bg-[#F7F5F0] border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div>
              <label for="rcv-material" class="block text-xs font-medium text-slate-700 mb-1">Material</label>
              <select id="rcv-material" formControlName="materialCode" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg">
                <option value="RM-CAR-01">RM-CAR-01 · Diced Carrots</option>
                <option value="RM-BRO-02">RM-BRO-02 · Broccoli Florets</option>
                <option value="PK-TRAY-400B">PK-TRAY-400B · Square Salad Bowl 400g</option>
              </select>
            </div>
            <div>
              <label for="rcv-lot" class="block text-xs font-medium text-slate-700 mb-1">Supplier Lot Code</label>
              <input id="rcv-lot" formControlName="supplierLotCode" class="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
            </div>
            <div>
              <label for="rcv-qty" class="block text-xs font-medium text-slate-700 mb-1">Quantity & Intake Temp (°C)</label>
              <div class="flex gap-2">
                <input id="rcv-qty" type="number" formControlName="quantity" class="w-1/2 px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
                <input aria-label="Intake Temperature °C" type="number" step="0.1" formControlName="temperatureC" class="w-1/2 px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
            </div>
            <button type="submit" class="px-4 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg cursor-pointer">
              Confirm Goods Receipt
            </button>
          </form>
        }

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Internal UID / Lot</th>
                <th class="py-2 pr-3 font-medium">Material & Supplier</th>
                <th class="py-2 pr-3 font-medium">Location</th>
                <th class="py-2 pr-3 font-medium">Expiry</th>
                <th class="py-2 pr-3 font-medium text-right">On Hand / Reserved</th>
                <th class="py-2 pr-3 font-medium">Status</th>
                <th class="py-2 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (lot of filteredLots(); track lot.id) {
                <tr class="hover:bg-slate-50">
                  <td class="py-2.5 pr-3 font-mono">
                    <div class="font-semibold text-[#0F1D32]">{{ lot.id }}</div>
                    <div class="text-[11px] text-slate-500">{{ lot.internalUid }} · {{ lot.supplierLotCode }}</div>
                  </td>
                  <td class="py-2.5 pr-3">
                    <div class="font-medium text-[#0F1D32]">{{ lot.materialName }}</div>
                    <div class="text-[11px] text-slate-500">{{ lot.supplierName }} · {{ lot.poNumber }}</div>
                  </td>
                  <td class="py-2.5 pr-3 font-mono text-slate-700">{{ lot.locationCode }}</td>
                  <td class="py-2.5 pr-3 font-mono text-slate-700">{{ lot.expiryDate | date:'dd MMM yyyy' }}</td>
                  <td class="py-2.5 pr-3 text-right font-mono tabular-nums">
                    <span class="font-semibold text-[#0F1D32]">{{ lot.quantityOnHand | number:'1.0-2' }}</span>
                    <span class="text-slate-500"> ({{ lot.quantityReserved | number:'1.0-2' }} res) {{ lot.unit }}</span>
                  </td>
                  <td class="py-2.5 pr-3 font-semibold" [class]="lot.qualityStatus === 'released' ? 'text-emerald-700' : lot.qualityStatus === 'quarantined' ? 'text-amber-700' : 'text-red-700'">
                    {{ lot.qualityStatus }}
                  </td>
                  <td class="py-2.5 text-right whitespace-nowrap space-x-1.5">
                    @if (lot.qualityStatus === 'quarantined') {
                      <button type="button" (click)="store.changeLotStatus(lot.id, 'released', 'QA intake verified')" class="px-2.5 py-1 bg-emerald-700 text-white rounded cursor-pointer">
                        QA Release
                      </button>
                    }
                    <button
                      type="button"
                      (click)="consumeSample(lot.id, lot.unit)"
                      class="px-2.5 py-1 border border-slate-300 bg-white rounded hover:bg-slate-100 cursor-pointer"
                    >
                      Issue 50 {{ lot.unit }}
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Append-Only Inventory Movement Ledger -->
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h3 class="text-base font-semibold text-[#0F1D32]">Append-Only Inventory Movement Ledger</h3>
        <div class="mt-3 overflow-x-auto max-h-64 overflow-y-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Timestamp</th>
                <th class="py-2 pr-3 font-medium">Type</th>
                <th class="py-2 pr-3 font-medium">Lot ID</th>
                <th class="py-2 pr-3 font-medium text-right">Delta</th>
                <th class="py-2 pr-3 font-medium">Actor</th>
                <th class="py-2 font-medium">Reason</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (m of store.movements().slice(0, 20); track m.id) {
                <tr>
                  <td class="py-2 pr-3 font-mono text-slate-500">{{ m.createdAt | date:'dd MMM HH:mm:ss' }}</td>
                  <td class="py-2 pr-3 font-mono font-semibold">{{ m.movementType }}</td>
                  <td class="py-2 pr-3 font-mono">{{ m.lotId }}</td>
                  <td class="py-2 pr-3 text-right font-mono tabular-nums" [class]="m.quantityDelta < 0 ? 'text-red-700' : 'text-emerald-700'">
                    {{ m.quantityDelta > 0 ? '+' : '' }}{{ m.quantityDelta }} {{ m.unit }}
                  </td>
                  <td class="py-2 pr-3">{{ m.performedBy }}</td>
                  <td class="py-2 text-slate-600">{{ m.reason }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class IngredientsView {
  readonly store = inject(FactoryStore);
  readonly kindFilter = signal<string>('all');
  readonly showReceiveForm = signal(false);
  readonly scannedMessage = signal<string | null>(null);

  readonly scanForm = new FormGroup({
    barcode: new FormControl('', {nonNullable: true}),
  });

  readonly receiveForm = new FormGroup({
    materialCode: new FormControl('RM-CAR-01', {nonNullable: true, validators: [Validators.required]}),
    supplierLotCode: new FormControl('GV-CAR-905', {nonNullable: true, validators: [Validators.required]}),
    quantity: new FormControl(500, {nonNullable: true, validators: [Validators.required]}),
    temperatureC: new FormControl(3.0, {nonNullable: true}),
  });

  filteredLots() {
    const k = this.kindFilter();
    const list = this.store.lots();
    if (k === 'all') return list;
    return list.filter((l) => l.materialKind === k);
  }

  runScan(): void {
    const code = this.scanForm.controls.barcode.value.trim();
    if (!code) return;
    const match = this.store
      .lots()
      .find((l) => l.barcodeValue === code || l.internalUid === code || l.id === code);
    this.scannedMessage.set(
      match
        ? `Scanner SIM-HONEYWELL-1950G matched ${match.id} (${match.materialName}) · Status: ${match.qualityStatus} · Location: ${match.locationCode}`
        : `Scanner SIM-HONEYWELL-1950G: no lot matched '${code}'.`,
    );
  }

  submitReceipt(): void {
    const v = this.receiveForm.getRawValue();
    const isBowl = v.materialCode === 'PK-TRAY-400B';
    void this.store.receiveLot({
      materialCode: v.materialCode,
      materialName: isBowl
        ? 'Square Salad Bowl 400g'
        : v.materialCode === 'RM-CAR-01'
          ? 'Diced Carrots (Washed)'
          : 'Broccoli Florets',
      materialKind: isBowl ? 'packaging' : 'ingredient',
      supplierId: isBowl ? 'SUP-ALBA' : 'SUP-GREEN',
      supplierName: isBowl ? 'Alba Thermoform Packaging' : 'Greenvale Produce Ltd',
      supplierLotCode: v.supplierLotCode,
      poNumber: 'PO-SUP-9099',
      quantity: v.quantity,
      unit: isBowl ? 'units' : 'kg',
      locationCode: isBowl ? 'PKG-INTAKE-01' : 'INTAKE-Q-02',
      expiryDate: new Date(Date.now() + 7 * 86400_000).toISOString(),
      temperatureC: isBowl ? null : v.temperatureC,
    });
    this.showReceiveForm.set(false);
  }

  reserveBundle(): void {
    void this.store.reserveStock('RM-CAR-01', 400, 'kg', 'PO-2026-1041');
  }

  consumeSample(lotId: string, unit: string): void {
    void this.store.issueOrConsume({
      lotId,
      quantity: 50,
      unit,
      movementType: 'consume',
      orderId: 'PO-2026-1041',
      batchId: 'BAT-261120-01',
      reason: 'Operator consumption tranche on Line 01',
    });
  }
}

@Component({
  selector: 'app-packaging-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe, DatePipe],
  template: `
    <div class="space-y-6">
      @for (setup of store.packagingSetups(); track setup.id) {
        <div
          class="border rounded-xl p-5"
          [class]="setup.mismatchDetected ? 'bg-red-50/60 border-red-300' : 'bg-white border-slate-200'"
        >
          <div class="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <div class="font-mono text-xs text-slate-600">
                {{ setup.lineId }} · Order {{ setup.orderId }} · {{ setup.barcodeFormat }}
              </div>
              <h2 class="mt-1 text-lg font-semibold text-[#0F1D32]">
                Packaging Line Setup & Label Verification — {{ setup.formatName }}
              </h2>
              <p class="text-xs text-slate-600 mt-0.5">{{ store.printerAdapterNote() }}</p>
            </div>
            <div class="flex flex-wrap items-center gap-2">
              <button
                type="button"
                (click)="injectMismatch(setup.id)"
                class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-red-700 text-white rounded-lg hover:bg-red-800 cursor-pointer"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">warning</mat-icon>
                Simulate v1.0 Label Mismatch
              </button>
              <button
                type="button"
                (click)="correctSetup(setup.id)"
                class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified</mat-icon>
                Authorise & Load v2.1 Label Roll
              </button>
            </div>
          </div>

          @if (setup.mismatchDetected) {
            <div class="mt-4 p-4 rounded-lg bg-red-100 border border-red-300 text-xs text-red-900">
              <strong>PACKAGING INTERLOCK TRIGGERED:</strong> Loaded label
              <span class="font-mono font-semibold">{{ setup.loadedLabelTemplateId }} {{ setup.loadedLabelVersion }}</span>
              (Roll {{ setup.loadedLabelLotId }}) does not match approved recipe label
              <span class="font-mono font-semibold">{{ setup.expectedLabelTemplateId }} {{ setup.expectedLabelVersion }}</span>.
              Production halted and critical quality hold opened. Switch role to <strong>Quality</strong> or <strong>Supervisor</strong> to correct setup and restore line clearance.
            </div>
          }

          <div class="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-slate-500">Loaded Label Version</div>
              <div class="mt-1 font-mono font-semibold text-[#0F1D32]">
                {{ setup.loadedLabelTemplateId }} · {{ setup.loadedLabelVersion }}
              </div>
              <div class="text-[11px] text-slate-500">Roll: {{ setup.loadedLabelLotId }}</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-slate-500">Line Clearance</div>
              <div class="mt-1 font-semibold text-[#0F1D32]">
                {{ setup.lineClearanceSignedBy ?? 'Cleared / Required' }}
              </div>
              <div class="text-[11px] text-slate-500">
                {{ setup.lineClearanceAt ? (setup.lineClearanceAt | date:'dd MMM HH:mm') : 'Pending sign-off' }}
              </div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-slate-500">Seal Integrity Tests</div>
              <div class="mt-1 font-mono font-semibold tabular-nums text-emerald-700">
                {{ setup.sealIntegrityPassCount }} Pass / {{ setup.sealIntegrityFailCount }} Fail
              </div>
              <div class="text-[11px] text-slate-500">MAP Sealer: {{ setup.sealerStatus }}</div>
            </div>
            <div class="p-3 rounded-lg bg-[#F8F9FA] border border-slate-200">
              <div class="text-slate-500">Label Reconciliation</div>
              <div class="mt-1 font-mono font-semibold tabular-nums text-[#0F1D32]">
                {{ setup.labelsPrinted | number }} printed · {{ setup.labelsVoided }} void
              </div>
              <div class="text-[11px] text-slate-500">{{ setup.labelsRemainingReconciled | number }} left on roll</div>
            </div>
          </div>
        </div>
      }

      <!-- Approved Label Data Preview & Case/Pallet Packing -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-xl p-5">
          <h3 class="text-base font-semibold text-[#0F1D32]">Approved Label Template Data (TPL-CVMT-380 v2.1)</h3>
          @for (tpl of store.labelTemplates(); track tpl.id) {
            @if (tpl.status === 'approved' && tpl.productSku === 'SKU-CVMT-380') {
              <div class="mt-3 p-4 rounded-lg border border-slate-300 bg-[#FAF8F4] text-xs space-y-2">
                <div class="flex justify-between font-mono text-[11px] text-slate-600">
                  <span>{{ tpl.templateCode }} · {{ tpl.version }}</span>
                  <span>{{ tpl.barcodeFormat }}</span>
                </div>
                <div class="text-sm font-semibold text-[#0F1D32]">{{ tpl.productName }} — {{ tpl.netQuantityText }}</div>
                <p class="text-slate-700"><strong>Ingredients:</strong> {{ tpl.ingredientsText }}</p>
                <p class="text-slate-800"><strong>Allergens:</strong> {{ tpl.allergensDeclaration }}</p>
                <p class="text-slate-600">{{ tpl.storageInstructions }} · {{ tpl.dateMarkRule }}</p>
              </div>
            }
          }
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-5">
          <div class="flex items-center justify-between pb-3 border-b border-slate-200">
            <h3 class="text-base font-semibold text-[#0F1D32]">Case & Pallet Aggregation</h3>
            <button
              type="button"
              (click)="store.packPallet('PO-2026-1041', 1200, 'FG-CHILL-R4')"
              class="px-3.5 py-2 text-xs font-semibold bg-[#0F1D32] text-white rounded-lg hover:bg-slate-800 cursor-pointer"
            >
              Pack 100 Cases (1,200 Trays) onto Pallet
            </button>
          </div>
          <div class="mt-3 overflow-x-auto max-h-56 overflow-y-auto">
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500">
                  <th class="py-2">Case UID</th>
                  <th class="py-2">Pallet</th>
                  <th class="py-2 text-right">Units</th>
                  <th class="py-2 text-right">Label Ver</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (c of store.cases().slice(0, 12); track c.id) {
                  <tr>
                    <td class="py-2 font-mono font-medium">{{ c.caseUid }}</td>
                    <td class="py-2 font-mono text-slate-600">{{ c.palletId ?? 'Unassigned' }}</td>
                    <td class="py-2 text-right font-mono tabular-nums">{{ c.unitCount }}</td>
                    <td class="py-2 text-right font-mono">{{ c.labelVersionUsed }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PackagingView {
  readonly store = inject(FactoryStore);

  injectMismatch(setupId: string): void {
    void this.store.applyPackagingSetup(setupId, {
      loadedLabelTemplateId: 'LBL-CVMT-V1',
      loadedLabelVersion: 'v1.0',
      loadedLabelLotId: 'LOT-LBL-LEGACY-V1',
    });
  }

  correctSetup(setupId: string): void {
    void this.store.applyPackagingSetup(setupId, {
      loadedLabelTemplateId: 'LBL-CVMT-V2',
      loadedLabelVersion: 'v2.1',
      loadedLabelLotId: 'LOT-LBL-CVMT-V2',
    });
  }
}

@Component({
  selector: 'app-warehouse-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, DecimalPipe, DatePipe],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="text-lg font-semibold text-[#0F1D32]">Finished Goods Storage & QA-Gated Dispatch</h2>
            <p class="text-xs text-slate-600 mt-0.5">
              Only pallets with Quality Status <strong>released</strong> may be dispatched. Pending or held pallets are blocked server-side.
            </p>
          </div>
          <form [formGroup]="dispatchForm" (ngSubmit)="dispatchAllReleased()" class="flex flex-wrap items-center gap-2">
            <input formControlName="customerName" placeholder="Customer" class="px-3 py-2 text-xs border border-slate-300 rounded-lg" />
            <input formControlName="destination" placeholder="Destination depot" class="px-3 py-2 text-xs border border-slate-300 rounded-lg" />
            <button type="submit" class="px-4 py-2 text-xs font-semibold bg-[#047857] text-white rounded-lg hover:bg-emerald-800 cursor-pointer">
              Dispatch Eligible Pallets
            </button>
          </form>
        </div>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2 pr-3 font-medium">Pallet ID / SSCC</th>
                <th class="py-2 pr-3 font-medium">Order</th>
                <th class="py-2 pr-3 font-medium">Rack Location</th>
                <th class="py-2 pr-3 font-medium text-right">Cases / Units</th>
                <th class="py-2 pr-3 font-medium">QA Release</th>
                <th class="py-2 font-medium text-right">Shipment</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (p of store.pallets(); track p.id) {
                <tr>
                  <td class="py-2.5 pr-3 font-mono">
                    <div class="font-semibold text-[#0F1D32]">{{ p.id }}</div>
                    <div class="text-[11px] text-slate-500">SSCC {{ p.ssccCode }}</div>
                  </td>
                  <td class="py-2.5 pr-3 font-mono">{{ p.orderId }}</td>
                  <td class="py-2.5 pr-3 font-mono">{{ p.locationCode }}</td>
                  <td class="py-2.5 pr-3 text-right font-mono tabular-nums">{{ p.caseCount }} / {{ p.totalUnits | number }}</td>
                  <td class="py-2.5 pr-3 font-semibold" [class]="p.qualityStatus === 'released' ? 'text-emerald-700' : 'text-amber-700'">
                    {{ p.qualityStatus }}
                  </td>
                  <td class="py-2.5 text-right font-mono">
                    @if (p.shipmentId) {
                      <span class="text-emerald-700 font-semibold">{{ p.shipmentId }}</span>
                    } @else {
                      <button
                        type="button"
                        (click)="dispatchSingle(p.id)"
                        class="px-2.5 py-1 border border-slate-300 rounded bg-white hover:bg-slate-100 cursor-pointer"
                      >
                        Attempt Dispatch
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <div class="bg-white border border-slate-200 rounded-xl p-5">
        <h3 class="text-base font-semibold text-[#0F1D32]">Dispatched Shipments</h3>
        <div class="mt-3 overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500">
                <th class="py-2">Dispatch Note</th>
                <th class="py-2">Customer & Destination</th>
                <th class="py-2 text-right">Vehicle Temp</th>
                <th class="py-2 text-right">Units</th>
                <th class="py-2 text-right">Dispatched At</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (s of store.shipments(); track s.id) {
                <tr>
                  <td class="py-2.5 font-mono font-semibold text-[#0F1D32]">{{ s.shipmentNumber }}</td>
                  <td class="py-2.5">{{ s.customerName }} · {{ s.destination }}</td>
                  <td class="py-2.5 text-right font-mono tabular-nums">{{ s.vehicleTempC }} °C</td>
                  <td class="py-2.5 text-right font-mono tabular-nums font-semibold">{{ s.totalUnits | number }}</td>
                  <td class="py-2.5 text-right font-mono text-slate-600">{{ s.dispatchedAt | date:'dd MMM HH:mm' }}</td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="5" class="py-4 text-center text-slate-500">
                    No shipments dispatched yet. Complete Quality checks and QA release pallets first.
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class WarehouseView {
  readonly store = inject(FactoryStore);

  readonly dispatchForm = new FormGroup({
    customerName: new FormControl('Aldi UK Chilled RDC', {nonNullable: true}),
    destination: new FormControl('Atherstone Depot, UK', {nonNullable: true}),
  });

  dispatchAllReleased(): void {
    const eligible = this.store
      .pallets()
      .filter((p) => p.qualityStatus === 'released' && !p.shipmentId)
      .map((p) => p.id);
    const fallback = eligible.length ? eligible : [this.store.pallets()[0]?.id ?? 'PLT-261120-001'];
    const v = this.dispatchForm.getRawValue();
    void this.store.dispatchShipment(fallback, v.customerName, v.destination, 2.4);
  }

  dispatchSingle(palletId: string): void {
    const v = this.dispatchForm.getRawValue();
    void this.store.dispatchShipment([palletId], v.customerName, v.destination, 2.4);
  }
}
