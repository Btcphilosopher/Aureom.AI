import {isPlatformBrowser} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {computed, inject, Injectable, PLATFORM_ID, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import {
  AuditEvent,
  EnergyReading,
  FactorySnapshot,
  InventoryLot,
  InventoryMovement,
  LabelTemplate,
  MaintenanceWorkOrder,
  OperatingMode,
  OrderStatus,
  PackagingCase,
  PackagingSetup,
  Pallet,
  ProcessingEvent,
  ProductionOrder,
  QualityCheck,
  QualityHold,
  RecipeVersion,
  Shipment,
  StationState,
  UserRole,
} from '../../shared/domain';
import {PlanningStrategyResult} from '../../server/services/planning-service';
import {TraceabilityResult} from '../../server/services/traceability-service';

export type NavSection =
  | 'overview'
  | 'production'
  | 'recipes'
  | 'ingredients'
  | 'preparation'
  | 'packaging'
  | 'quality'
  | 'traceability'
  | 'maintenance'
  | 'warehouse'
  | 'planning'
  | 'energy'
  | 'reports'
  | 'administration';

export interface PlanningComparisonResponse {
  seed: number;
  breakdownInjected: boolean;
  strategies: PlanningStrategyResult[];
  forecastVsActual: {
    forecastUnitsPerHour: number;
    measuredUnitsPerHour: number;
    deltaPct: number;
  };
}

@Injectable({providedIn: 'root'})
export class FactoryStore {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  readonly activeSection = signal<NavSection>('overview');
  readonly activeRole = signal<UserRole>('supervisor');
  readonly actorName = signal<string>('C. Vance');
  readonly reducedMotion = signal<boolean>(false);

  readonly snapshot = signal<FactorySnapshot | null>(null);
  readonly recipes = signal<RecipeVersion[]>([]);
  readonly labelTemplates = signal<LabelTemplate[]>([]);
  readonly lots = signal<InventoryLot[]>([]);
  readonly movements = signal<InventoryMovement[]>([]);
  readonly processingEvents = signal<ProcessingEvent[]>([]);
  readonly packagingSetups = signal<PackagingSetup[]>([]);
  readonly cases = signal<PackagingCase[]>([]);
  readonly pallets = signal<Pallet[]>([]);
  readonly shipments = signal<Shipment[]>([]);
  readonly printerAdapterNote = signal<string>('Simulated Zebra ZT411 Local Adapter');
  readonly qualityChecks = signal<QualityCheck[]>([]);
  readonly qualityHolds = signal<QualityHold[]>([]);
  readonly workOrders = signal<MaintenanceWorkOrder[]>([]);
  readonly energyReadings = signal<EnergyReading[]>([]);
  readonly auditEvents = signal<AuditEvent[]>([]);
  readonly backups = signal<{fileName: string; sizeBytes: number; modifiedAt: string}[]>([]);
  readonly traceResult = signal<TraceabilityResult | null>(null);
  readonly planningComparison = signal<PlanningComparisonResponse | null>(null);

  readonly selectedStationId = signal<string | null>(null);
  readonly selectedStation = computed(() => {
    const snap = this.snapshot();
    const id = this.selectedStationId();
    if (!snap || !id) return null;
    return snap.stations.find((s) => s.id === id) ?? null;
  });

  readonly streamProtocol = signal<'ws' | 'sse' | 'disconnected'>('disconnected');
  readonly lastActionBanner = signal<{type: 'success' | 'error'; message: string} | null>(null);
  readonly loading = signal<boolean>(false);

  private ws: WebSocket | null = null;
  private sse: EventSource | null = null;

  private headers(idempotencyKey?: string): HttpHeaders {
    let h = new HttpHeaders({
      'X-Aureom-Role': this.activeRole(),
      'X-Aureom-Actor': this.actorName(),
    });
    if (idempotencyKey) {
      h = h.set('Idempotency-Key', idempotencyKey);
    }
    return h;
  }

  setRole(role: UserRole): void {
    this.activeRole.set(role);
    const roleNames: Record<UserRole, string> = {
      operator: 'E. Kowalski (Operator)',
      supervisor: 'C. Vance (Shift Supervisor)',
      quality: 'Dr. R. Gallagher (QA Lead)',
      maintenance: 'T. Brennan (Maintenance Eng)',
      planner: 'A. Lindqvist (Production Planner)',
      warehouse: 'M. Patel (Warehouse Lead)',
      admin: 'S. Mercer (Site Admin)',
    };
    this.actorName.set(roleNames[role]);
  }

  notify(type: 'success' | 'error', message: string): void {
    this.lastActionBanner.set({type, message});
  }

  clearNotice(): void {
    this.lastActionBanner.set(null);
  }

  async init(): Promise<void> {
    if (!isPlatformBrowser(this.platformId)) return;
    await this.refreshAll();
    this.connectLiveStream();
  }

  connectLiveStream(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    try {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${proto}//${window.location.host}/api/live`;
      const ws = new WebSocket(wsUrl);
      let opened = false;

      ws.onopen = () => {
        opened = true;
        this.streamProtocol.set('ws');
      };

      ws.onmessage = (event) => {
        try {
          const parsed = JSON.parse(String(event.data)) as {type: string; data: FactorySnapshot};
          if (parsed.type === 'snapshot') {
            this.snapshot.set(parsed.data);
          }
        } catch {
          // ignore malformed frames
        }
      };

      ws.onerror = () => {
        if (!opened) {
          ws.close();
          this.connectSseFallback();
        }
      };

      ws.onclose = () => {
        if (!opened) {
          this.connectSseFallback();
        } else {
          this.streamProtocol.set('disconnected');
        }
      };

      this.ws = ws;
    } catch {
      this.connectSseFallback();
    }
  }

  private connectSseFallback(): void {
    if (this.sse || !isPlatformBrowser(this.platformId)) return;
    const es = new EventSource('/api/stream');
    es.onopen = () => {
      this.streamProtocol.set('sse');
    };
    es.onmessage = (event) => {
      try {
        const parsed = JSON.parse(String(event.data)) as {type: string; data: FactorySnapshot};
        if (parsed.type === 'snapshot') {
          this.snapshot.set(parsed.data);
          this.streamProtocol.set('sse');
        }
      } catch {
        // ignore
      }
    };
    es.onerror = () => {
      this.streamProtocol.set('disconnected');
    };
    this.sse = es;
  }

  async refreshAll(): Promise<void> {
    this.loading.set(true);
    try {
      const [snap, rcp, inv, prod, pkg, qual, maint, eng, adm] = await Promise.all([
        firstValueFrom(this.http.get<FactorySnapshot>('/api/snapshot')),
        firstValueFrom(
          this.http.get<{recipes: RecipeVersion[]; labelTemplates: LabelTemplate[]}>('/api/recipes'),
        ),
        firstValueFrom(
          this.http.get<{lots: InventoryLot[]; movements: InventoryMovement[]}>('/api/inventory'),
        ),
        firstValueFrom(
          this.http.get<{orders: ProductionOrder[]; processingEvents: ProcessingEvent[]}>(
            '/api/production',
          ),
        ),
        firstValueFrom(
          this.http.get<{
            setups: PackagingSetup[];
            cases: PackagingCase[];
            pallets: Pallet[];
            shipments: Shipment[];
            printerAdapter: {adapterName: string; note: string};
          }>('/api/packaging'),
        ),
        firstValueFrom(
          this.http.get<{checks: QualityCheck[]; holds: QualityHold[]}>('/api/quality'),
        ),
        firstValueFrom(
          this.http.get<{workOrders: MaintenanceWorkOrder[]}>('/api/maintenance'),
        ),
        firstValueFrom(this.http.get<{readings: EnergyReading[]}>('/api/energy')),
        firstValueFrom(
          this.http.get<{
            events: AuditEvent[];
            backups: {fileName: string; sizeBytes: number; modifiedAt: string}[];
          }>('/api/admin/audit'),
        ),
      ]);

      this.snapshot.set(snap);
      this.recipes.set(rcp.recipes);
      this.labelTemplates.set(rcp.labelTemplates);
      this.lots.set(inv.lots);
      this.movements.set(inv.movements);
      this.processingEvents.set(prod.processingEvents);
      this.packagingSetups.set(pkg.setups);
      this.cases.set(pkg.cases);
      this.pallets.set(pkg.pallets);
      this.shipments.set(pkg.shipments);
      this.printerAdapterNote.set(`${pkg.printerAdapter.adapterName} — ${pkg.printerAdapter.note}`);
      this.qualityChecks.set(qual.checks);
      this.qualityHolds.set(qual.holds);
      this.workOrders.set(maint.workOrders);
      this.energyReadings.set(eng.readings);
      this.auditEvents.set(adm.events);
      this.backups.set(adm.backups);

      if (!this.traceResult()) {
        await this.runTrace('BAT-261120-01', 'full');
      }
      if (!this.planningComparison()) {
        await this.runPlanningSimulation(20261120, true);
      }
    } catch (err) {
      this.notify('error', this.extractError(err));
    } finally {
      this.loading.set(false);
    }
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    if (err instanceof Error) return err.message;
    return 'Request failed.';
  }

  async setOperatingMode(mode: OperatingMode): Promise<void> {
    try {
      const snap = await firstValueFrom(
        this.http.post<FactorySnapshot>(
          '/api/system/mode',
          {mode},
          {headers: this.headers()},
        ),
      );
      this.snapshot.set(snap);
      this.notify('success', `Operating mode switched to ${mode.toUpperCase()}.`);
      await this.refreshAll();
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async toggleSimulatedOutage(active: boolean): Promise<void> {
    try {
      const snap = await firstValueFrom(
        this.http.post<FactorySnapshot>(
          '/api/system/outage',
          {active},
          {headers: this.headers()},
        ),
      );
      this.snapshot.set(snap);
      this.notify(
        active ? 'error' : 'success',
        active
          ? 'Telemetry outage simulated — displaying last observation timestamp.'
          : 'Live telemetry connection restored.',
      );
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async stepSimulation(): Promise<void> {
    try {
      const snap = await firstValueFrom(
        this.http.post<FactorySnapshot>('/api/sim/step', {}, {headers: this.headers()}),
      );
      this.snapshot.set(snap);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async resetDemo(): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post('/api/system/reset-demo', {}, {headers: this.headers()}),
      );
      await this.refreshAll();
      this.notify('success', 'Synthetic 10,000-tray factory demonstration dataset reset.');
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async setStationState(
    stationId: string,
    state: StationState,
    faultReason: string | null = null,
  ): Promise<void> {
    try {
      const snap = await firstValueFrom(
        this.http.post<FactorySnapshot>(
          `/api/stations/${stationId}/state`,
          {state, faultReason},
          {headers: this.headers()},
        ),
      );
      this.snapshot.set(snap);
      await this.refreshAll();
      this.notify('success', `Station ${stationId} set to ${state}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async receiveLot(payload: Record<string, unknown>): Promise<void> {
    try {
      const key = `rcv-${Date.now()}`;
      await firstValueFrom(
        this.http.post('/api/inventory/receive', payload, {headers: this.headers(key)}),
      );
      await this.refreshAll();
      this.notify('success', 'Goods receipt logged into quarantine.');
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async changeLotStatus(
    lotId: string,
    status: 'released' | 'quarantined' | 'rejected',
    reason: string,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/inventory/lots/${lotId}/status`,
          {status, reason},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Lot ${lotId} updated to ${status}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async reserveStock(
    materialCode: string,
    quantity: number,
    unit: string,
    orderId: string,
  ): Promise<void> {
    try {
      const key = `res-${orderId}-${materialCode}-${Date.now()}`;
      await firstValueFrom(
        this.http.post(
          '/api/inventory/reserve',
          {materialCode, quantity, unit, orderId},
          {headers: this.headers(key)},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Reserved ${quantity} ${unit} of ${materialCode} via FEFO.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async issueOrConsume(payload: {
    lotId: string;
    quantity: number;
    unit: string;
    movementType: 'issue' | 'consume' | 'waste' | 'return_to_stock';
    orderId: string | null;
    batchId: string | null;
    reason: string;
  }): Promise<void> {
    try {
      const key = `iss-${payload.lotId}-${Date.now()}`;
      await firstValueFrom(
        this.http.post('/api/inventory/issue', payload, {headers: this.headers(key)}),
      );
      await this.refreshAll();
      this.notify('success', `Ledger movement '${payload.movementType}' recorded.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async createOrder(payload: Record<string, unknown>): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post('/api/production/orders', payload, {headers: this.headers()}),
      );
      await this.refreshAll();
      this.notify('success', 'Production order created against approved recipe version.');
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async transitionOrder(orderId: string, status: OrderStatus): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/production/orders/${orderId}/transition`,
          {status},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Order ${orderId} transitioned to ${status}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async recordProcessing(payload: Record<string, unknown>): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post('/api/production/processing-events', payload, {
          headers: this.headers(),
        }),
      );
      await this.refreshAll();
      this.notify('success', 'Processing & CCP observation recorded.');
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async recordOutput(
    orderId: string,
    goodUnits: number,
    rejectedUnits: number,
    reworkUnits: number,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/production/orders/${orderId}/output`,
          {goodUnits, rejectedUnits, reworkUnits},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Recorded +${goodUnits} packaged units on ${orderId}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async applyPackagingSetup(
    setupId: string,
    payload: {
      loadedLabelTemplateId: string;
      loadedLabelVersion: string;
      loadedLabelLotId: string;
    },
  ): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<{holdCreatedId: string | null}>(
          `/api/packaging/setups/${setupId}/apply`,
          payload,
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      if (res.holdCreatedId) {
        this.notify(
          'error',
          `Label mismatch detected! Line halted and critical quality hold ${res.holdCreatedId} created.`,
        );
      } else {
        this.notify('success', 'Packaging setup verified and line clearance restored.');
      }
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async packPallet(orderId: string, unitCount: number, palletLocation: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/packaging/pack',
          {orderId, unitCount, palletLocation},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Packed ${unitCount} units onto SSCC pallet (pending QA release).`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async recordQualityCheck(
    checkId: string,
    measuredValue: string,
    result: 'pass' | 'fail',
    notes: string,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/quality/checks/${checkId}/record`,
          {measuredValue, result, notes},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Quality check ${checkId} recorded as ${result}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async closeHold(
    holdId: string,
    disposition: 'release' | 'rework' | 'reject' | 'destroy',
    correctiveAction: string,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/quality/holds/${holdId}/close`,
          {disposition, correctiveAction},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Hold ${holdId} closed with disposition '${disposition}'.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async releaseOrderGoods(
    orderId: string,
    disposition: 'released' | 'rejected' | 'rework' | 'destroyed',
    notes: string,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/quality/orders/${orderId}/release`,
          {disposition, notes},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Order ${orderId} finished goods disposition set to '${disposition}'.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async dispatchShipment(
    palletIds: string[],
    customerName: string,
    destination: string,
    vehicleTempC: number,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/warehouse/dispatch',
          {palletIds, customerName, destination, vehicleTempC},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Dispatched ${palletIds.length} released pallet(s) to ${customerName}.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async runTrace(query: string, direction: 'forward' | 'backward' | 'full'): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.get<TraceabilityResult>(
          `/api/traceability?q=${encodeURIComponent(query)}&direction=${direction}`,
        ),
      );
      this.traceResult.set(res);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async runPlanningSimulation(
    seed: number,
    simulateBreakdownAndShortage: boolean,
  ): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<PlanningComparisonResponse>('/api/planning/simulate', {
          seed,
          simulateBreakdownAndShortage,
        }),
      );
      this.planningComparison.set(res);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async approveReplan(orderId: string, newTargetUnits: number, reason: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/planning/approve-replan',
          {orderId, newTargetUnits, reason},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      await this.runPlanningSimulation(20261120, true);
      this.notify('success', `Approved replan for ${orderId} (${newTargetUnits} units).`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async createRecipeRevision(
    sourceId: string,
    versionNumber: string,
    revisionReason: string,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/recipes/${sourceId}/revisions`,
          {versionNumber, revisionReason},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Draft recipe revision ${versionNumber} created.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async approveRecipe(recipeId: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(`/api/recipes/${recipeId}/approve`, {}, {headers: this.headers()}),
      );
      await this.refreshAll();
      this.notify('success', `Recipe ${recipeId} approved and locked as immutable.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async completeWorkOrder(workOrderId: string, note: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/maintenance/work-orders/${workOrderId}/complete`,
          {note},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Maintenance work order ${workOrderId} completed.`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }

  async createBackup(): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<{backupFile: string; sizeBytes: number}>(
          '/api/admin/backup',
          {},
          {headers: this.headers()},
        ),
      );
      await this.refreshAll();
      this.notify('success', `Created database backup ${res.backupFile} (${res.sizeBytes} B).`);
    } catch (err) {
      this.notify('error', this.extractError(err));
    }
  }
}
