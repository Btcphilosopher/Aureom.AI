import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, {Response} from 'express';
import {createServer} from 'node:http';
import {join} from 'node:path';
import {WebSocket, WebSocketServer} from 'ws';
import {createApiRouter} from './server/api-router';
import {getDb} from './server/db/connection';
import {runMigrations} from './server/db/migrations';
import {seedFactoryDatabase} from './server/db/seed';
import {
  getFactorySnapshot,
  stepFactorySimulation,
} from './server/sim/factory-simulator';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

const db = getDb();
runMigrations(db);
seedFactoryDatabase(db);

const wss = new WebSocketServer({noServer: true});
const sseClients = new Set<Response>();

function broadcastSnapshot(): void {
  const snapshot = getFactorySnapshot(db);
  const payload = JSON.stringify({type: 'snapshot', data: snapshot});

  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
  for (const res of sseClients) {
    res.write(`data: ${payload}\n\n`);
  }
}

wss.on('connection', (ws) => {
  const snapshot = getFactorySnapshot(db);
  ws.send(JSON.stringify({type: 'snapshot', data: snapshot}));
});

// Handle WebSocket upgrade for /api/live before Angular SSR
app.use('/api/live', (req, res, next) => {
  if (req.headers.upgrade?.toLowerCase() === 'websocket') {
    wss.handleUpgrade(req, req.socket, Buffer.alloc(0), (ws) => {
      wss.emit('connection', ws, req);
    });
    return;
  }
  next();
});

// SSE endpoint for environments where dev proxy intercepts WS upgrades
app.get('/api/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const snapshot = getFactorySnapshot(db);
  res.write(`data: ${JSON.stringify({type: 'snapshot', data: snapshot})}\n\n`);
  sseClients.add(res);

  req.on('close', () => {
    sseClients.delete(res);
  });
});

app.use('/api', createApiRouter(db, broadcastSnapshot));

// Simulation heartbeat (only advances when mode === 'simulation' and not in outage)
const globalState = globalThis as {__aureomSimTimer?: ReturnType<typeof setInterval>};
if (!globalState.__aureomSimTimer) {
  globalState.__aureomSimTimer = setInterval(() => {
    try {
      const advanced = stepFactorySimulation(db);
      if (advanced) {
        broadcastSnapshot();
      }
    } catch {
      // Keep simulation timer resilient
    }
  }, 2500);
}

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  const server = createServer(app);
  server.on('upgrade', (req, socket, head) => {
    if (req.url?.startsWith('/api/live')) {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    }
  });
  server.listen(port, () => {
    console.log(`Aureom Foodworks server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
