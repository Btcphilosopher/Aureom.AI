declare module 'node:sqlite' {
  export interface StatementSync {
    run(...params: unknown[]): {changes: number; lastInsertRowid: number | bigint};
    get(...params: unknown[]): Record<string, unknown> | undefined;
    all(...params: unknown[]): Record<string, unknown>[];
  }

  export class DatabaseSync {
    constructor(location: string, options?: {open?: boolean; readOnly?: boolean});
    exec(sql: string): void;
    prepare(sql: string): StatementSync;
    close(): void;
  }
}
