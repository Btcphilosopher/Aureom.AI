export type OperatingMode = 'simulation' | 'monitoring' | 'supervised';

export type UserRole =
  | 'operator'
  | 'supervisor'
  | 'quality'
  | 'maintenance'
  | 'planner'
  | 'warehouse'
  | 'admin';

export type StationState =
  | 'running'
  | 'starved'
  | 'blocked'
  | 'cleaning'
  | 'changeover'
  | 'faulted'
  | 'stopped';

export type OrderStatus =
  | 'planned'
  | 'released'
  | 'in_progress'
  | 'paused'
  | 'completed'
  | 'cancelled'
  | 'reconciled';

export type QualityStatus =
  | 'pending'
  | 'quarantined'
  | 'released'
  | 'hold'
  | 'rejected'
  | 'rework'
  | 'destroyed';

export interface Station {
  id: string;
  code: string;
  name: string;
  stage: string;
  sequenceOrder: number;
  state: StationState;
  lineId: string;
  activeOrderId: string | null;
  activeOperator: string | null;
  setpointLabel: string;
  setpointValue: number | null;
  measuredValue: number | null;
  unit: string;
  sensorId: string;
  calibrationDue: string;
  calibrationValid: boolean;
  throughputPerMin: number;
  bufferCount: number;
  bufferCapacity: number;
  faultReason: string | null;
  lastObservationAt: string;
  isSynthetic: boolean;
}

export interface RecipeIngredientItem {
  id: string;
  materialCode: string;
  materialName: string;
  quantityPerBatch: number;
  unit: string;
  allergen: string | null;
  prepInstruction: string;
}

export interface RecipePackagingItem {
  id: string;
  materialCode: string;
  materialName: string;
  packagingType: 'tray' | 'film' | 'label' | 'carton' | 'case' | 'pouch' | 'bottle';
  quantityPerUnit: number;
  unit: string;
}

export interface ProcessLimit {
  parameter: string;
  stage: string;
  target: string;
  minLimit: number | null;
  maxLimit: number | null;
  unit: string;
  haccpCritical: boolean;
  syntheticNote: string;
}

export interface RecipeVersion {
  id: string;
  recipeCode: string;
  productSku: string;
  productName: string;
  category: 'ready_meal' | 'sandwich' | 'salad' | 'bakery' | 'sauce' | 'chilled_prepared';
  versionNumber: string;
  status: 'draft' | 'approved' | 'superseded' | 'retired';
  batchSizeKg: number;
  expectedYieldUnits: number;
  unitWeightGrams: number;
  allergens: string[];
  crossContactNotes: string;
  approvedLabelTemplateId: string;
  approvedLabelVersion: string;
  effectiveFrom: string;
  approvedBy: string | null;
  approvedAt: string | null;
  revisionReason: string;
  ingredients: RecipeIngredientItem[];
  packagingBom: RecipePackagingItem[];
  processLimits: ProcessLimit[];
  prepSteps: string[];
}

export interface InventoryLot {
  id: string;
  internalUid: string;
  materialCode: string;
  materialName: string;
  materialKind: 'ingredient' | 'packaging' | 'finished_good';
  supplierId: string;
  supplierName: string;
  supplierLotCode: string;
  barcodeValue: string;
  poNumber: string;
  quantityOnHand: number;
  quantityReserved: number;
  unit: string;
  locationCode: string;
  receivedAt: string;
  expiryDate: string;
  temperatureC: number | null;
  qualityStatus: QualityStatus;
  notes: string;
}

export interface InventoryMovement {
  id: string;
  lotId: string;
  movementType:
    | 'receipt'
    | 'release'
    | 'quarantine'
    | 'reserve'
    | 'unreserve'
    | 'issue'
    | 'consume'
    | 'waste'
    | 'return_to_stock'
    | 'supplier_return'
    | 'adjustment'
    | 'dispatch';
  quantityDelta: number;
  unit: string;
  orderId: string | null;
  batchId: string | null;
  referenceId: string | null;
  linkedMovementId: string | null;
  reason: string;
  performedBy: string;
  performedRole: UserRole;
  createdAt: string;
}

export interface ProductionOrder {
  id: string;
  orderNumber: string;
  recipeVersionId: string;
  recipeCode: string;
  productSku: string;
  productName: string;
  lineId: string;
  shiftName: string;
  targetUnits: number;
  producedUnits: number;
  rejectedUnits: number;
  reworkUnits: number;
  status: OrderStatus;
  qualityReleaseStatus: QualityStatus;
  scheduledStart: string;
  scheduledEnd: string;
  actualStart: string | null;
  actualEnd: string | null;
  dispatchDeadline: string;
  customerOrderRef: string;
  assignedSupervisor: string;
  notes: string;
}

export interface ProcessingEvent {
  id: string;
  orderId: string;
  batchId: string;
  stationId: string;
  stationName: string;
  operatorName: string;
  ingredientLotIds: string[];
  setpointValue: number | null;
  measuredValue: number | null;
  unit: string;
  durationMinutes: number;
  outputQuantity: number;
  outputUnit: string;
  sensorId: string;
  calibrationStatus: 'valid' | 'due_soon' | 'overdue';
  deviationFlag: boolean;
  dispositionNote: string | null;
  recordedAt: string;
}

export interface PackagingSetup {
  id: string;
  lineId: string;
  orderId: string;
  formatName: string;
  trayLotId: string;
  filmLotId: string;
  loadedLabelTemplateId: string;
  loadedLabelVersion: string;
  loadedLabelLotId: string;
  expectedLabelTemplateId: string;
  expectedLabelVersion: string;
  mismatchDetected: boolean;
  lineClearanceSignedBy: string | null;
  lineClearanceAt: string | null;
  fillerStatus: StationState;
  sealerStatus: StationState;
  printerStatus: StationState;
  checkweigherStatus: StationState;
  sealIntegrityPassCount: number;
  sealIntegrityFailCount: number;
  labelsPrinted: number;
  labelsVoided: number;
  labelsRemainingReconciled: number;
  scrapUnits: number;
  barcodeFormat: string;
  printerAdapterMode: string;
  updatedAt: string;
}

export interface LabelTemplate {
  id: string;
  templateCode: string;
  version: string;
  productSku: string;
  productName: string;
  ingredientsText: string;
  allergensDeclaration: string;
  netQuantityText: string;
  storageInstructions: string;
  dateMarkRule: string;
  barcodeFormat: string;
  status: 'approved' | 'retired';
}

export interface QualityCheck {
  id: string;
  orderId: string | null;
  batchId: string | null;
  lotId: string | null;
  planName: string;
  checkType:
    | 'incoming_temp'
    | 'weight'
    | 'core_temp'
    | 'chill_temp'
    | 'seal_integrity'
    | 'visual'
    | 'metal_detector'
    | 'lab_micro';
  samplingInstruction: string;
  targetSpec: string;
  measuredValue: string | null;
  unit: string;
  result: 'pending' | 'pass' | 'fail';
  inspectorName: string | null;
  sensorOrDeviceId: string | null;
  notes: string;
  recordedAt: string | null;
}

export interface QualityHold {
  id: string;
  batchId: string | null;
  orderId: string | null;
  lotId: string | null;
  reasonCode: string;
  description: string;
  severity: 'warning' | 'critical';
  status: 'open' | 'investigating' | 'closed';
  affectedUnits: number;
  disposition: 'pending' | 'release' | 'rework' | 'reject' | 'destroy';
  correctiveAction: string;
  openedBy: string;
  openedAt: string;
  closedBy: string | null;
  closedAt: string | null;
}

export interface PackagingCase {
  id: string;
  caseUid: string;
  orderId: string;
  batchId: string;
  palletId: string | null;
  unitCount: number;
  packagingLotId: string;
  labelVersionUsed: string;
  qualityStatus: QualityStatus;
  packedAt: string;
}

export interface Pallet {
  id: string;
  ssccCode: string;
  orderId: string;
  caseCount: number;
  totalUnits: number;
  locationCode: string;
  qualityStatus: QualityStatus;
  shipmentId: string | null;
  builtAt: string;
}

export interface Shipment {
  id: string;
  shipmentNumber: string;
  customerName: string;
  destination: string;
  vehicleTempC: number;
  status: 'staged' | 'dispatched' | 'delivered';
  palletIds: string[];
  totalUnits: number;
  dispatchedBy: string | null;
  dispatchedAt: string | null;
}

export interface MaintenanceWorkOrder {
  id: string;
  stationId: string;
  stationName: string;
  title: string;
  priority: 'routine' | 'high' | 'critical';
  workType: 'preventive' | 'corrective' | 'calibration' | 'inspection_advisory';
  status: 'open' | 'in_progress' | 'completed';
  sparePartsRequired: string;
  evidenceNote: string;
  dueAt: string;
  assignedTo: string;
  completedAt: string | null;
}

export interface EnergyReading {
  id: string;
  lineId: string;
  shiftName: string;
  electricityKwh: number;
  steamKg: number;
  chilledWaterLitres: number;
  processWaterLitres: number;
  unitsProducedContext: number;
  recordedAt: string;
}

export interface AuditEvent {
  id: string;
  actor: string;
  role: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  createdAt: string;
}

export interface DispatchCommitment {
  id: string;
  customer: string;
  orderNumber: string;
  productName: string;
  targetUnits: number;
  stagedUnits: number;
  dueAt: string;
  status: 'on_track' | 'at_risk' | 'dispatched';
}

export interface OeeMetrics {
  plannedProductionMinutes: number;
  actualRuntimeMinutes: number;
  changeoverTreatment: string;
  idealCycleSecondsPerUnit: number;
  availabilityPct: number;
  performancePct: number;
  qualityPct: number;
  oeePct: number;
  throughputUnitsPerHour: number;
  yieldPct: number;
  rejectsCount: number;
  downtimeMinutes: number;
  downtimeReasons: {reason: string; minutes: number}[];
}

export interface FactorySnapshot {
  operatingMode: OperatingMode;
  telemetryConnected: boolean;
  telemetryOutageSimulated: boolean;
  lastTelemetryAt: string;
  telemetryAgeSeconds: number;
  dataStale: boolean;
  syntheticBanner: string;
  stations: Station[];
  orders: ProductionOrder[];
  oee: OeeMetrics;
  activeHoldsCount: number;
  expiringLotsCount: number;
  shortageCount: number;
  dispatchCommitments: DispatchCommitment[];
  recentAudit: AuditEvent[];
}
