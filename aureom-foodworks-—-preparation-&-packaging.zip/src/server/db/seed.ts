import {DatabaseSync} from 'node:sqlite';
import {withTransaction} from './connection';

export function seedFactoryDatabase(db: DatabaseSync, forceReset = false): void {
  const existing = db
    .prepare("SELECT value FROM system_state WHERE key = 'seeded_v1'")
    .get();

  if (existing && !forceReset) {
    return;
  }

  withTransaction(db, () => {
    if (forceReset) {
      const tables = [
        'audit_events',
        'telemetry_dedup',
        'energy_readings',
        'maintenance_work_orders',
        'shipments',
        'pallets',
        'packaging_cases',
        'quality_holds',
        'quality_checks',
        'packaging_setups',
        'processing_events',
        'batch_genealogy',
        'production_batches',
        'production_orders',
        'inventory_movements',
        'inventory_lots',
        'suppliers',
        'recipe_versions',
        'label_templates',
        'stations',
        'idempotency_keys',
        'system_state',
      ];
      for (const table of tables) {
        db.exec(`DELETE FROM ${table};`);
      }
    }

    const now = new Date('2026-11-20T08:00:00.000Z').toISOString();

    db.prepare(
      'INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES (?, ?, ?)',
    ).run('seeded_v1', 'true', now);
    db.prepare(
      'INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES (?, ?, ?)',
    ).run('operating_mode', 'simulation', now);
    db.prepare(
      'INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES (?, ?, ?)',
    ).run('telemetry_outage_simulated', 'false', now);
    db.prepare(
      'INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES (?, ?, ?)',
    ).run('last_telemetry_at', now, now);
    db.prepare(
      'INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES (?, ?, ?)',
    ).run('sim_tick_count', '0', now);

    // 1. Stations on Line 1 (Ready Meals Chilled)
    const stations = [
      {
        id: 'STN-REC',
        code: 'REC-01',
        name: 'Goods Receipt & Intake',
        stage: 'Goods Receipt',
        sequence_order: 1,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'M. Patel',
        setpoint_label: 'Intake Dock Max Temp',
        setpoint_value: 4.0,
        measured_value: 3.1,
        unit: '°C',
        sensor_id: 'TT-REC-101',
        calibration_due: '2027-02-15',
        calibration_valid: 1,
        throughput_per_min: 0,
        buffer_count: 14,
        buffer_capacity: 40,
        fault_reason: null,
      },
      {
        id: 'STN-WASH',
        code: 'WSH-01',
        name: 'Produce Wash & Sanitise',
        stage: 'Preparation',
        sequence_order: 2,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'H. Okafor',
        setpoint_label: 'Wash Water Temp (Synthetic)',
        setpoint_value: 6.0,
        measured_value: 5.4,
        unit: '°C',
        sensor_id: 'TT-WSH-102',
        calibration_due: '2027-01-30',
        calibration_valid: 1,
        throughput_per_min: 52,
        buffer_count: 18,
        buffer_capacity: 60,
        fault_reason: null,
      },
      {
        id: 'STN-CUT',
        code: 'CUT-01',
        name: 'Rotary Dicer & Prep',
        stage: 'Preparation',
        sequence_order: 3,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'H. Okafor',
        setpoint_label: 'Cut Size Spec',
        setpoint_value: 12.0,
        measured_value: 12.0,
        unit: 'mm',
        sensor_id: 'POS-CUT-103',
        calibration_due: '2027-03-10',
        calibration_valid: 1,
        throughput_per_min: 50,
        buffer_count: 22,
        buffer_capacity: 60,
        fault_reason: null,
      },
      {
        id: 'STN-COOK',
        code: 'CKT-01',
        name: 'Steam Kettle & Roast',
        stage: 'Cooking',
        sequence_order: 4,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'L. Byrne',
        setpoint_label: 'Core Target (Synthetic)',
        setpoint_value: 76.0,
        measured_value: 77.4,
        unit: '°C',
        sensor_id: 'TT-CKT-104',
        calibration_due: '2027-01-12',
        calibration_valid: 1,
        throughput_per_min: 48,
        buffer_count: 16,
        buffer_capacity: 50,
        fault_reason: null,
      },
      {
        id: 'STN-COOL',
        code: 'BCL-01',
        name: 'Spiral Blast Chiller',
        stage: 'Cooling',
        sequence_order: 5,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'L. Byrne',
        setpoint_label: 'Discharge Max (Synthetic)',
        setpoint_value: 4.5,
        measured_value: 3.8,
        unit: '°C',
        sensor_id: 'TT-BCL-105',
        calibration_due: '2027-01-12',
        calibration_valid: 1,
        throughput_per_min: 48,
        buffer_count: 25,
        buffer_capacity: 80,
        fault_reason: null,
      },
      {
        id: 'STN-FILL',
        code: 'FIL-01',
        name: 'Denester & Multi-Head Filler',
        stage: 'Portioning',
        sequence_order: 6,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'E. Kowalski',
        setpoint_label: 'Target Fill Weight',
        setpoint_value: 380.0,
        measured_value: 381.2,
        unit: 'g',
        sensor_id: 'LC-FIL-106',
        calibration_due: '2027-02-01',
        calibration_valid: 1,
        throughput_per_min: 46,
        buffer_count: 19,
        buffer_capacity: 60,
        fault_reason: null,
      },
      {
        id: 'STN-SEAL',
        code: 'SEL-01',
        name: 'MAP Tray Sealer',
        stage: 'Packaging',
        sequence_order: 7,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'E. Kowalski',
        setpoint_label: 'Seal Bar Temp (Synthetic)',
        setpoint_value: 175.0,
        measured_value: 174.8,
        unit: '°C',
        sensor_id: 'TT-SEL-107',
        calibration_due: '2027-02-20',
        calibration_valid: 1,
        throughput_per_min: 46,
        buffer_count: 12,
        buffer_capacity: 40,
        fault_reason: null,
      },
      {
        id: 'STN-LBL',
        code: 'LBL-01',
        name: 'Print & Apply Labeller',
        stage: 'Packaging',
        sequence_order: 8,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'E. Kowalski',
        setpoint_label: 'Vision OCR Confidence',
        setpoint_value: 98.0,
        measured_value: 99.4,
        unit: '%',
        sensor_id: 'CAM-LBL-108',
        calibration_due: '2027-04-01',
        calibration_valid: 1,
        throughput_per_min: 46,
        buffer_count: 9,
        buffer_capacity: 40,
        fault_reason: null,
      },
      {
        id: 'STN-INSP',
        code: 'INS-01',
        name: 'Checkweigher & Metal Detector',
        stage: 'Inspection',
        sequence_order: 9,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'S. Ahmed',
        setpoint_label: 'Nominal Checkweight',
        setpoint_value: 380.0,
        measured_value: 380.9,
        unit: 'g',
        sensor_id: 'CW-INS-109',
        calibration_due: '2026-12-28',
        calibration_valid: 1,
        throughput_per_min: 45,
        buffer_count: 8,
        buffer_capacity: 40,
        fault_reason: null,
      },
      {
        id: 'STN-PACK',
        code: 'PCK-01',
        name: 'Case Packer & Palletiser',
        stage: 'Finished Storage',
        sequence_order: 10,
        state: 'running',
        line_id: 'LINE-01',
        active_order_id: 'PO-2026-1041',
        active_operator: 'D. Hughes',
        setpoint_label: 'Units per Case',
        setpoint_value: 12.0,
        measured_value: 12.0,
        unit: 'trays',
        sensor_id: 'CNT-PCK-110',
        calibration_due: '2027-03-15',
        calibration_valid: 1,
        throughput_per_min: 45,
        buffer_count: 10,
        buffer_capacity: 60,
        fault_reason: null,
      },
    ];

    const insertStation = db.prepare(`
      INSERT INTO stations (
        id, code, name, stage, sequence_order, state, line_id, active_order_id,
        active_operator, setpoint_label, setpoint_value, measured_value, unit,
        sensor_id, calibration_due, calibration_valid, throughput_per_min,
        buffer_count, buffer_capacity, fault_reason, last_observation_at, is_synthetic
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `);
    for (const s of stations) {
      insertStation.run(
        s.id,
        s.code,
        s.name,
        s.stage,
        s.sequence_order,
        s.state,
        s.line_id,
        s.active_order_id,
        s.active_operator,
        s.setpoint_label,
        s.setpoint_value,
        s.measured_value,
        s.unit,
        s.sensor_id,
        s.calibration_due,
        s.calibration_valid,
        s.throughput_per_min,
        s.buffer_count,
        s.buffer_capacity,
        s.fault_reason,
        now,
      );
    }

    // 2. Suppliers
    const suppliers = [
      ['SUP-GREEN', 'GV-01', 'Greenvale Produce Ltd', 'Fresh Vegetables', 'approved'],
      ['SUP-COTSWOLD', 'CO-02', 'Cotswold Oils & Herbs', 'Oils & Seasoning', 'approved'],
      ['SUP-ALBA', 'AT-03', 'Alba Thermoform Packaging', 'Trays, Film & Labels', 'approved'],
    ];
    for (const sup of suppliers) {
      db.prepare(
        'INSERT INTO suppliers (id, code, name, category, approval_status) VALUES (?, ?, ?, ?, ?)',
      ).run(...sup);
    }

    // 3. Label Templates
    db.prepare(`
      INSERT INTO label_templates (
        id, template_code, version, product_sku, product_name, ingredients_text,
        allergens_declaration, net_quantity_text, storage_instructions, date_mark_rule,
        barcode_format, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'LBL-CVMT-V2',
      'TPL-CVMT-380',
      'v2.1',
      'SKU-CVMT-380',
      'Chilled Vegetable Meal Tray',
      'Carrots (34%), Broccoli Florets (28%), Roasted Red Peppers (22%), Herb Olive Oil (10%), Vegetable Stock Seasoning (6%, contains Celery trace control).',
      'Allergy advice: Manufactured in a facility handling Celery. No dairy, gluten, or nuts declared in recipe.',
      '380g e',
      'Keep refrigerated 0°C to +4°C (Synthetic example storage text). Do not freeze.',
      'USE BY: DD MMM YYYY (Synthetic +5d)',
      'GS1-128 / EAN-13',
      'approved',
    );

    db.prepare(`
      INSERT INTO label_templates (
        id, template_code, version, product_sku, product_name, ingredients_text,
        allergens_declaration, net_quantity_text, storage_instructions, date_mark_rule,
        barcode_format, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'LBL-CVMT-V1',
      'TPL-CVMT-380',
      'v1.0',
      'SKU-CVMT-380',
      'Chilled Vegetable Meal Tray (Legacy)',
      'Carrots (36%), Broccoli (28%), Peppers (22%), Olive Oil (14%).',
      'Legacy label missing Celery trace cross-contact declaration.',
      '380g e',
      'Keep chilled.',
      'USE BY: DD MMM YYYY',
      'EAN-13',
      'retired',
    );

    db.prepare(`
      INSERT INTO label_templates (
        id, template_code, version, product_sku, product_name, ingredients_text,
        allergens_declaration, net_quantity_text, storage_instructions, date_mark_rule,
        barcode_format, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'LBL-MLSB-V1',
      'TPL-MLSB-400',
      'v1.2',
      'SKU-MLSB-400',
      'Mediterranean Lentil & Roast Squash Bowl',
      'Puy Lentils (38%), Butternut Squash (32%), Spinach (16%), Lemon Herb Dressing (14%).',
      'Allergy advice: Celery trace control.',
      '400g e',
      'Keep refrigerated 0°C to +4°C (Synthetic example).',
      'USE BY: DD MMM YYYY',
      'GS1-128',
      'approved',
    );

    // 4. Approved Recipes
    const cvmtIngredients = [
      {
        id: 'ING-1',
        materialCode: 'RM-CAR-01',
        materialName: 'Diced Carrots (Washed)',
        quantityPerBatch: 1360,
        unit: 'kg',
        allergen: null,
        prepInstruction: 'Wash at 6°C max, 12mm dice inspection',
      },
      {
        id: 'ING-2',
        materialCode: 'RM-BRO-02',
        materialName: 'Broccoli Florets',
        quantityPerBatch: 1120,
        unit: 'kg',
        allergen: null,
        prepInstruction: 'Trim stem & sanitised rinse',
      },
      {
        id: 'ING-3',
        materialCode: 'RM-PEP-03',
        materialName: 'Roasted Red Peppers',
        quantityPerBatch: 880,
        unit: 'kg',
        allergen: null,
        prepInstruction: 'Drain & inspect prior to kettle blend',
      },
      {
        id: 'ING-4',
        materialCode: 'RM-OIL-04',
        materialName: 'Herb Infused Olive Oil',
        quantityPerBatch: 400,
        unit: 'kg',
        allergen: null,
        prepInstruction: 'Metered dosing into steam kettle',
      },
      {
        id: 'ING-5',
        materialCode: 'RM-HRB-05',
        materialName: 'Vegetable Stock Seasoning',
        quantityPerBatch: 240,
        unit: 'kg',
        allergen: 'Celery (Trace Control)',
        prepInstruction: 'Dedicated allergen-checked scoop',
      },
    ];

    const cvmtPackaging = [
      {
        id: 'PKG-1',
        materialCode: 'PK-TRAY-380',
        materialName: 'CPET Meal Tray 380g',
        packagingType: 'tray',
        quantityPerUnit: 1,
        unit: 'units',
      },
      {
        id: 'PKG-2',
        materialCode: 'PK-FILM-MAP',
        materialName: 'Barrier MAP Lidding Film',
        packagingType: 'film',
        quantityPerUnit: 0.25,
        unit: 'm',
      },
      {
        id: 'PKG-3',
        materialCode: 'PK-LBL-CVMT',
        materialName: 'Top Applied Product Label (CVMT v2.1)',
        packagingType: 'label',
        quantityPerUnit: 1,
        unit: 'units',
      },
      {
        id: 'PKG-4',
        materialCode: 'PK-CASE-12',
        materialName: 'Corrugated Outer Case (12-Tray)',
        packagingType: 'case',
        quantityPerUnit: 0.083333,
        unit: 'units',
      },
    ];

    const cvmtLimits = [
      {
        parameter: 'Cooking Core Temperature',
        stage: 'Cooking',
        target: '≥ 75.0 °C (Synthetic Site Plan)',
        minLimit: 75.0,
        maxLimit: 92.0,
        unit: '°C',
        haccpCritical: true,
        syntheticNote: 'Synthetic demonstration parameter — not a universal regulatory standard.',
      },
      {
        parameter: 'Blast Chill Exit Temperature',
        stage: 'Cooling',
        target: '≤ 5.0 °C (Synthetic Site Plan)',
        minLimit: -1.0,
        maxLimit: 5.0,
        unit: '°C',
        haccpCritical: true,
        syntheticNote: 'Synthetic demonstration parameter — site HACCP plan governs real limits.',
      },
      {
        parameter: 'Net Tray Fill Weight',
        stage: 'Portioning',
        target: '380.0 g (±8.0 g synthetic tolerance)',
        minLimit: 372.0,
        maxLimit: 395.0,
        unit: 'g',
        haccpCritical: false,
        syntheticNote: 'Synthetic e-mark demonstration target.',
      },
      {
        parameter: 'MAP Seal Temperature',
        stage: 'Packaging',
        target: '175.0 °C (±5.0 °C)',
        minLimit: 170.0,
        maxLimit: 180.0,
        unit: '°C',
        haccpCritical: false,
        syntheticNote: 'Synthetic packaging film profile.',
      },
    ];

    const cvmtPrepSteps = [
      '1. Verify all ingredient lots are Released (never Quarantined or Expired) and pick via FEFO.',
      '2. Wash carrots and broccoli florets in sanitised chilled wash flume (synthetic target ≤ 6.0 °C).',
      '3. Dice carrots to 12mm cube and inspect for foreign material.',
      '4. Blend vegetables, herb olive oil, and seasoning in Steam Kettle CKT-01 to synthetic core target ≥ 75.0 °C.',
      '5. Transfer immediately to Spiral Blast Chiller BCL-01 until discharge temp ≤ 5.0 °C.',
      '6. Perform line clearance on FIL-01 / SEL-01 / LBL-01 and verify loaded label matches TPL-CVMT-380 v2.1.',
      '7. Fill 380g trays, MAP seal, print/apply verified labels, checkweigh & metal-detect, and pack 12 trays per case.',
    ];

    db.prepare(`
      INSERT INTO recipe_versions (
        id, recipe_code, product_sku, product_name, category, version_number, status,
        batch_size_kg, expected_yield_units, unit_weight_grams, allergens_json,
        cross_contact_notes, approved_label_template_id, approved_label_version,
        effective_from, approved_by, approved_at, revision_reason,
        ingredients_json, packaging_bom_json, process_limits_json, prep_steps_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'RCP-CVMT-V2_1',
      'RCP-CVMT-380',
      'SKU-CVMT-380',
      'Chilled Vegetable Meal Tray',
      'ready_meal',
      'v2.1',
      'approved',
      4000,
      10000,
      380,
      JSON.stringify(['Celery (Trace Control)']),
      'Shared seasoning scoop line with celery-containing stocks; post-run wet sanitisation required.',
      'LBL-CVMT-V2',
      'v2.1',
      '2026-11-01T00:00:00.000Z',
      'Dr. R. Gallagher (QA Director)',
      '2026-10-28T14:20:00.000Z',
      'Added Celery trace control declaration on v2.1 label & updated roast pepper ratio.',
      JSON.stringify(cvmtIngredients),
      JSON.stringify(cvmtPackaging),
      JSON.stringify(cvmtLimits),
      JSON.stringify(cvmtPrepSteps),
    );

    db.prepare(`
      INSERT INTO recipe_versions (
        id, recipe_code, product_sku, product_name, category, version_number, status,
        batch_size_kg, expected_yield_units, unit_weight_grams, allergens_json,
        cross_contact_notes, approved_label_template_id, approved_label_version,
        effective_from, approved_by, approved_at, revision_reason,
        ingredients_json, packaging_bom_json, process_limits_json, prep_steps_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'RCP-CVMT-V1_0',
      'RCP-CVMT-380',
      'SKU-CVMT-380',
      'Chilled Vegetable Meal Tray',
      'ready_meal',
      'v1.0',
      'superseded',
      4000,
      10000,
      380,
      JSON.stringify([]),
      'Legacy specification without celery trace warning.',
      'LBL-CVMT-V1',
      'v1.0',
      '2026-06-01T00:00:00.000Z',
      'Dr. R. Gallagher (QA Director)',
      '2026-05-25T10:00:00.000Z',
      'Initial release.',
      JSON.stringify(cvmtIngredients),
      JSON.stringify(cvmtPackaging),
      JSON.stringify(cvmtLimits),
      JSON.stringify(cvmtPrepSteps),
    );

    db.prepare(`
      INSERT INTO recipe_versions (
        id, recipe_code, product_sku, product_name, category, version_number, status,
        batch_size_kg, expected_yield_units, unit_weight_grams, allergens_json,
        cross_contact_notes, approved_label_template_id, approved_label_version,
        effective_from, approved_by, approved_at, revision_reason,
        ingredients_json, packaging_bom_json, process_limits_json, prep_steps_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'RCP-MLSB-V1_2',
      'RCP-MLSB-400',
      'SKU-MLSB-400',
      'Mediterranean Lentil & Roast Squash Bowl',
      'salad',
      'v1.2',
      'approved',
      1800,
      4500,
      400,
      JSON.stringify(['Celery (Trace Control)']),
      'Requires full line washdown between tray formats.',
      'LBL-MLSB-V1',
      'v1.2',
      '2026-11-05T00:00:00.000Z',
      'Dr. R. Gallagher (QA Director)',
      '2026-11-02T09:15:00.000Z',
      'Autumn squash seasonal yield calibration.',
      JSON.stringify([
        {
          id: 'ING-M1',
          materialCode: 'RM-LEN-06',
          materialName: 'Cooked Puy Lentils',
          quantityPerBatch: 720,
          unit: 'kg',
          allergen: null,
          prepInstruction: 'Chill-verified ready-to-assemble',
        },
        {
          id: 'ING-M2',
          materialCode: 'RM-SQU-07',
          materialName: 'Diced Butternut Squash',
          quantityPerBatch: 640,
          unit: 'kg',
          allergen: null,
          prepInstruction: 'Roast at 185°C synthetic profile',
        },
      ]),
      JSON.stringify([
        {
          id: 'PKG-M1',
          materialCode: 'PK-TRAY-400B',
          materialName: 'Square Salad Bowl 400g',
          packagingType: 'tray',
          quantityPerUnit: 1,
          unit: 'units',
        },
        {
          id: 'PKG-M2',
          materialCode: 'PK-LBL-MLSB',
          materialName: 'Bowl Sleeve Label (MLSB v1.2)',
          packagingType: 'label',
          quantityPerUnit: 1,
          unit: 'units',
        },
      ]),
      JSON.stringify(cvmtLimits),
      JSON.stringify(['1. Roast squash and cool <= 5.0 °C.', '2. Assemble bowls and apply MLSB v1.2 label.']),
    );

    // 5. Inventory Lots (Ingredients + Packaging, including Quarantine, Expiring Soon, Legacy Label Roll)
    const lots = [
      {
        id: 'LOT-CAR-01A',
        internal_uid: 'AUM-RM-20261119-001',
        material_code: 'RM-CAR-01',
        material_name: 'Diced Carrots (Washed)',
        material_kind: 'ingredient',
        supplier_id: 'SUP-GREEN',
        supplier_name: 'Greenvale Produce Ltd',
        supplier_lot_code: 'GV-CAR-881',
        barcode_value: '010501234500101110GV881',
        po_number: 'PO-SUP-9012',
        quantity_on_hand: 1800,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'CHILL-BAY-A1',
        received_at: '2026-11-19T06:30:00.000Z',
        expiry_date: '2026-11-24T23:59:59.000Z',
        temperature_c: 2.8,
        quality_status: 'released',
        notes: 'FEFO primary carrot lot (synthetic).',
      },
      {
        id: 'LOT-CAR-01B',
        internal_uid: 'AUM-RM-20261120-002',
        material_code: 'RM-CAR-01',
        material_name: 'Diced Carrots (Washed)',
        material_kind: 'ingredient',
        supplier_id: 'SUP-GREEN',
        supplier_name: 'Greenvale Produce Ltd',
        supplier_lot_code: 'GV-CAR-894',
        barcode_value: '010501234500101110GV894',
        po_number: 'PO-SUP-9044',
        quantity_on_hand: 950,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'INTAKE-Q-01',
        received_at: '2026-11-20T05:45:00.000Z',
        expiry_date: '2026-11-26T23:59:59.000Z',
        temperature_c: 3.2,
        quality_status: 'quarantined',
        notes: 'Awaiting incoming QA intake release.',
      },
      {
        id: 'LOT-BRO-02A',
        internal_uid: 'AUM-RM-20261119-003',
        material_code: 'RM-BRO-02',
        material_name: 'Broccoli Florets',
        material_kind: 'ingredient',
        supplier_id: 'SUP-GREEN',
        supplier_name: 'Greenvale Produce Ltd',
        supplier_lot_code: 'GV-BRO-412',
        barcode_value: '010501234500201110GV412',
        po_number: 'PO-SUP-9012',
        quantity_on_hand: 1500,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'CHILL-BAY-A2',
        received_at: '2026-11-19T06:40:00.000Z',
        expiry_date: '2026-11-22T23:59:59.000Z',
        temperature_c: 2.5,
        quality_status: 'released',
        notes: 'Expiring within 48h — FEFO priority.',
      },
      {
        id: 'LOT-PEP-03A',
        internal_uid: 'AUM-RM-20261118-004',
        material_code: 'RM-PEP-03',
        material_name: 'Roasted Red Peppers',
        material_kind: 'ingredient',
        supplier_id: 'SUP-GREEN',
        supplier_name: 'Greenvale Produce Ltd',
        supplier_lot_code: 'GV-PEP-309',
        barcode_value: '010501234500301110GV309',
        po_number: 'PO-SUP-8998',
        quantity_on_hand: 1200,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'CHILL-BAY-B1',
        received_at: '2026-11-18T11:20:00.000Z',
        expiry_date: '2026-11-29T23:59:59.000Z',
        temperature_c: 3.1,
        quality_status: 'released',
        notes: '',
      },
      {
        id: 'LOT-OIL-04A',
        internal_uid: 'AUM-RM-20261115-005',
        material_code: 'RM-OIL-04',
        material_name: 'Herb Infused Olive Oil',
        material_kind: 'ingredient',
        supplier_id: 'SUP-COTSWOLD',
        supplier_name: 'Cotswold Oils & Herbs',
        supplier_lot_code: 'CO-OIL-771',
        barcode_value: '010501234500401110CO771',
        po_number: 'PO-SUP-8910',
        quantity_on_hand: 700,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'AMBIENT-D2',
        received_at: '2026-11-15T09:00:00.000Z',
        expiry_date: '2027-03-15T23:59:59.000Z',
        temperature_c: 15.0,
        quality_status: 'released',
        notes: '',
      },
      {
        id: 'LOT-HRB-05A',
        internal_uid: 'AUM-RM-20261116-006',
        material_code: 'RM-HRB-05',
        material_name: 'Vegetable Stock Seasoning',
        material_kind: 'ingredient',
        supplier_id: 'SUP-COTSWOLD',
        supplier_name: 'Cotswold Oils & Herbs',
        supplier_lot_code: 'CO-HRB-502',
        barcode_value: '010501234500501110CO502',
        po_number: 'PO-SUP-8921',
        quantity_on_hand: 420,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'DRY-ALLERGEN-C1',
        received_at: '2026-11-16T10:15:00.000Z',
        expiry_date: '2027-05-01T23:59:59.000Z',
        temperature_c: 16.5,
        quality_status: 'released',
        notes: 'Contains Celery trace control; segregated allergen rack.',
      },
      {
        id: 'LOT-BRO-EXPIRED',
        internal_uid: 'AUM-RM-20261110-007',
        material_code: 'RM-BRO-02',
        material_name: 'Broccoli Florets',
        material_kind: 'ingredient',
        supplier_id: 'SUP-GREEN',
        supplier_name: 'Greenvale Produce Ltd',
        supplier_lot_code: 'GV-BRO-388',
        barcode_value: '010501234500201110GV388',
        po_number: 'PO-SUP-8811',
        quantity_on_hand: 180,
        quantity_reserved: 0,
        unit: 'kg',
        location_code: 'HOLD-BAY-Z1',
        received_at: '2026-11-10T07:00:00.000Z',
        expiry_date: '2026-11-18T23:59:59.000Z',
        temperature_c: 4.1,
        quality_status: 'rejected',
        notes: 'Expired synthetic sample lot — blocked from production issue.',
      },
      // Packaging lots
      {
        id: 'LOT-TRAY-4401',
        internal_uid: 'AUM-PK-20261117-101',
        material_code: 'PK-TRAY-380',
        material_name: 'CPET Meal Tray 380g',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-CPET-4401',
        barcode_value: 'PKG-AT-CPET-4401',
        po_number: 'PO-SUP-8955',
        quantity_on_hand: 16000,
        quantity_reserved: 0,
        unit: 'units',
        location_code: 'PKG-STORE-P1',
        received_at: '2026-11-17T13:00:00.000Z',
        expiry_date: '2028-11-17T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'released',
        notes: '',
      },
      {
        id: 'LOT-FILM-4402',
        internal_uid: 'AUM-PK-20261117-102',
        material_code: 'PK-FILM-MAP',
        material_name: 'Barrier MAP Lidding Film',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-FILM-4402',
        barcode_value: 'PKG-AT-FILM-4402',
        po_number: 'PO-SUP-8955',
        quantity_on_hand: 5000,
        quantity_reserved: 0,
        unit: 'm',
        location_code: 'PKG-STORE-P2',
        received_at: '2026-11-17T13:10:00.000Z',
        expiry_date: '2028-11-17T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'released',
        notes: '',
      },
      {
        id: 'LOT-LBL-CVMT-V2',
        internal_uid: 'AUM-PK-20261118-103',
        material_code: 'PK-LBL-CVMT',
        material_name: 'Top Applied Product Label (CVMT v2.1)',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-LBL-2109',
        barcode_value: 'PKG-AT-LBL-2109',
        po_number: 'PO-SUP-8980',
        quantity_on_hand: 15000,
        quantity_reserved: 0,
        unit: 'units',
        location_code: 'PKG-LABEL-CAGE',
        received_at: '2026-11-18T14:00:00.000Z',
        expiry_date: '2028-11-18T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'released',
        notes: 'Approved v2.1 pre-printed allergen base stock.',
      },
      {
        id: 'LOT-LBL-LEGACY-V1',
        internal_uid: 'AUM-PK-20261015-099',
        material_code: 'PK-LBL-CVMT',
        material_name: 'Top Applied Product Label (Legacy v1.0)',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-LBL-1002',
        barcode_value: 'PKG-AT-LBL-1002',
        po_number: 'PO-SUP-8410',
        quantity_on_hand: 4000,
        quantity_reserved: 0,
        unit: 'units',
        location_code: 'PKG-QUARANTINE-C2',
        received_at: '2026-10-15T10:00:00.000Z',
        expiry_date: '2027-10-15T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'quarantined',
        notes: 'Superseded v1.0 label roll — triggers mismatch detection if loaded.',
      },
      {
        id: 'LOT-CASE-12A',
        internal_uid: 'AUM-PK-20261118-104',
        material_code: 'PK-CASE-12',
        material_name: 'Corrugated Outer Case (12-Tray)',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-CS-1204',
        barcode_value: 'PKG-AT-CS-1204',
        po_number: 'PO-SUP-8980',
        quantity_on_hand: 1500,
        quantity_reserved: 0,
        unit: 'units',
        location_code: 'PKG-STORE-P4',
        received_at: '2026-11-18T14:15:00.000Z',
        expiry_date: '2029-11-18T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'released',
        notes: '',
      },
      {
        id: 'LOT-BOWL-400B',
        internal_uid: 'AUM-PK-20261119-105',
        material_code: 'PK-TRAY-400B',
        material_name: 'Square Salad Bowl 400g',
        material_kind: 'packaging',
        supplier_id: 'SUP-ALBA',
        supplier_name: 'Alba Thermoform Packaging',
        supplier_lot_code: 'AT-BWL-4001',
        barcode_value: 'PKG-AT-BWL-4001',
        po_number: 'PO-SUP-9005',
        quantity_on_hand: 1800,
        quantity_reserved: 0,
        unit: 'units',
        location_code: 'PKG-STORE-P5',
        received_at: '2026-11-19T12:00:00.000Z',
        expiry_date: '2028-11-19T23:59:59.000Z',
        temperature_c: null,
        quality_status: 'released',
        notes: 'Shortage: only 1,800 bowls on hand vs 4,500 required for PO-2026-1042.',
      },
    ];

    const insertLot = db.prepare(`
      INSERT INTO inventory_lots (
        id, internal_uid, material_code, material_name, material_kind, supplier_id,
        supplier_name, supplier_lot_code, barcode_value, po_number, quantity_on_hand,
        quantity_reserved, unit, location_code, received_at, expiry_date, temperature_c,
        quality_status, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertMovement = db.prepare(`
      INSERT INTO inventory_movements (
        id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
        reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const l of lots) {
      insertLot.run(
        l.id,
        l.internal_uid,
        l.material_code,
        l.material_name,
        l.material_kind,
        l.supplier_id,
        l.supplier_name,
        l.supplier_lot_code,
        l.barcode_value,
        l.po_number,
        l.quantity_on_hand,
        l.quantity_reserved,
        l.unit,
        l.location_code,
        l.received_at,
        l.expiry_date,
        l.temperature_c,
        l.quality_status,
        l.notes,
      );
      insertMovement.run(
        `MOV-INIT-${l.id}`,
        l.id,
        'receipt',
        l.quantity_on_hand,
        l.unit,
        null,
        null,
        l.po_number,
        null,
        `Initial goods receipt against ${l.po_number}`,
        'M. Patel',
        'warehouse',
        l.received_at,
      );
    }

    // 6. Production Orders & Batches
    db.prepare(`
      INSERT INTO production_orders (
        id, order_number, recipe_version_id, recipe_code, product_sku, product_name,
        line_id, shift_name, target_units, produced_units, rejected_units, rework_units,
        status, quality_release_status, scheduled_start, scheduled_end, actual_start,
        actual_end, dispatch_deadline, customer_order_ref, assigned_supervisor, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'PO-2026-1041',
      'PO-2026-1041',
      'RCP-CVMT-V2_1',
      'RCP-CVMT-380',
      'SKU-CVMT-380',
      'Chilled Vegetable Meal Tray',
      'LINE-01',
      'Shift A (06:00–14:00)',
      10000,
      3600,
      48,
      24,
      'in_progress',
      'pending',
      '2026-11-20T06:00:00.000Z',
      '2026-11-20T13:30:00.000Z',
      '2026-11-20T06:08:00.000Z',
      null,
      '2026-11-20T16:00:00.000Z',
      'CUST-ALDI-UK-772',
      'C. Vance',
      'Primary synthetic demonstration run for 10,000 chilled vegetable meal trays.',
    );

    db.prepare(`
      INSERT INTO production_orders (
        id, order_number, recipe_version_id, recipe_code, product_sku, product_name,
        line_id, shift_name, target_units, produced_units, rejected_units, rework_units,
        status, quality_release_status, scheduled_start, scheduled_end, actual_start,
        actual_end, dispatch_deadline, customer_order_ref, assigned_supervisor, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'PO-2026-1042',
      'PO-2026-1042',
      'RCP-MLSB-V1_2',
      'RCP-MLSB-400',
      'SKU-MLSB-400',
      'Mediterranean Lentil & Roast Squash Bowl',
      'LINE-01',
      'Shift B (14:00–22:00)',
      4500,
      0,
      0,
      0,
      'planned',
      'pending',
      '2026-11-20T14:30:00.000Z',
      '2026-11-20T20:00:00.000Z',
      null,
      null,
      '2026-11-21T05:00:00.000Z',
      'CUST-WAITROSE-419',
      'C. Vance',
      'Scheduled after 45 min allergen washdown changeover; subject to Scenario 2 bowl shortage.',
    );

    db.prepare(`
      INSERT INTO production_batches (
        id, batch_code, order_id, recipe_version_id, parent_batch_id, is_rework,
        produced_units, waste_kg, quality_status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'BAT-261120-01',
      'B261120-CVMT-01',
      'PO-2026-1041',
      'RCP-CVMT-V2_1',
      null,
      0,
      3600,
      28.5,
      'pending',
      '2026-11-20T06:08:00.000Z',
    );

    // Seed initial consumed ingredients for first 3600 trays so genealogy is already rich
    const initialIssues = [
      {lot: 'LOT-CAR-01A', qty: 510, unit: 'kg'},
      {lot: 'LOT-BRO-02A', qty: 420, unit: 'kg'},
      {lot: 'LOT-PEP-03A', qty: 330, unit: 'kg'},
      {lot: 'LOT-OIL-04A', qty: 150, unit: 'kg'},
      {lot: 'LOT-HRB-05A', qty: 90, unit: 'kg'},
      {lot: 'LOT-TRAY-4401', qty: 3648, unit: 'units'},
      {lot: 'LOT-FILM-4402', qty: 912, unit: 'm'},
      {lot: 'LOT-LBL-CVMT-V2', qty: 3648, unit: 'units'},
      {lot: 'LOT-CASE-12A', qty: 300, unit: 'units'},
    ];

    for (const issue of initialIssues) {
      db.prepare(
        'UPDATE inventory_lots SET quantity_on_hand = quantity_on_hand - ? WHERE id = ?',
      ).run(issue.qty, issue.lot);
      insertMovement.run(
        `MOV-ISS-${issue.lot}`,
        issue.lot,
        'consume',
        -issue.qty,
        issue.unit,
        'PO-2026-1041',
        'BAT-261120-01',
        'PO-2026-1041',
        null,
        'Consumed for initial shift tranche (3,600 trays)',
        'E. Kowalski',
        'operator',
        '2026-11-20T06:45:00.000Z',
      );
      db.prepare(`
        INSERT INTO batch_genealogy (
          id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        `GEN-${issue.lot}-B1`,
        'inventory_lot',
        issue.lot,
        'production_batch',
        'BAT-261120-01',
        issue.qty,
        issue.unit,
        'consumed_in',
        '2026-11-20T06:45:00.000Z',
      );
    }

    // 7. Initial Processing Events
    const procEvents = [
      {
        id: 'PE-001',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        station_id: 'STN-COOK',
        station_name: 'Steam Kettle & Roast',
        operator_name: 'L. Byrne',
        lots: ['LOT-CAR-01A', 'LOT-BRO-02A', 'LOT-PEP-03A', 'LOT-OIL-04A', 'LOT-HRB-05A'],
        setpoint: 76.0,
        measured: 77.4,
        unit: '°C',
        duration: 24,
        out_qty: 1480,
        out_unit: 'kg',
        sensor: 'TT-CKT-104',
        cal: 'valid',
        dev: 0,
        note: null,
        ts: '2026-11-20T06:42:00.000Z',
      },
      {
        id: 'PE-002',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        station_id: 'STN-COOL',
        station_name: 'Spiral Blast Chiller',
        operator_name: 'L. Byrne',
        lots: ['LOT-CAR-01A', 'LOT-BRO-02A'],
        setpoint: 4.5,
        measured: 3.8,
        unit: '°C',
        duration: 38,
        out_qty: 1465,
        out_unit: 'kg',
        sensor: 'TT-BCL-105',
        cal: 'valid',
        dev: 0,
        note: null,
        ts: '2026-11-20T07:20:00.000Z',
      },
    ];
    for (const pe of procEvents) {
      db.prepare(`
        INSERT INTO processing_events (
          id, order_id, batch_id, station_id, station_name, operator_name,
          ingredient_lot_ids_json, setpoint_value, measured_value, unit,
          duration_minutes, output_quantity, output_unit, sensor_id,
          calibration_status, deviation_flag, disposition_note, recorded_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        pe.id,
        pe.order_id,
        pe.batch_id,
        pe.station_id,
        pe.station_name,
        pe.operator_name,
        JSON.stringify(pe.lots),
        pe.setpoint,
        pe.measured,
        pe.unit,
        pe.duration,
        pe.out_qty,
        pe.out_unit,
        pe.sensor,
        pe.cal,
        pe.dev,
        pe.note,
        pe.ts,
      );
    }

    // 8. Packaging Setup
    db.prepare(`
      INSERT INTO packaging_setups (
        id, line_id, order_id, format_name, tray_lot_id, film_lot_id,
        loaded_label_template_id, loaded_label_version, loaded_label_lot_id,
        expected_label_template_id, expected_label_version, mismatch_detected,
        line_clearance_signed_by, line_clearance_at, filler_status, sealer_status,
        printer_status, checkweigher_status, seal_integrity_pass_count,
        seal_integrity_fail_count, labels_printed, labels_voided,
        labels_remaining_reconciled, scrap_units, barcode_format,
        printer_adapter_mode, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'PKG-SETUP-L1',
      'LINE-01',
      'PO-2026-1041',
      '380g CPET Single Cavity MAP',
      'LOT-TRAY-4401',
      'LOT-FILM-4402',
      'LBL-CVMT-V2',
      'v2.1',
      'LOT-LBL-CVMT-V2',
      'LBL-CVMT-V2',
      'v2.1',
      0,
      'S. Ahmed',
      '2026-11-20T06:02:00.000Z',
      'running',
      'running',
      'running',
      'running',
      42,
      0,
      3648,
      14,
      11338,
      48,
      'GS1-128 / EAN-13',
      'Simulated Zebra ZT411 Local Adapter',
      now,
    );

    // 9. Quality Checks (including pending/missing checks — never inferred as passing!)
    const checks = [
      {
        id: 'QC-001',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        lot_id: 'LOT-CAR-01A',
        plan_name: 'Incoming Chilled Produce Plan',
        check_type: 'incoming_temp',
        sampling: 'Core probe 3 totes per pallet on arrival',
        spec: '≤ 4.0 °C (Synthetic)',
        measured: '2.8 °C',
        unit: '°C',
        result: 'pass',
        inspector: 'S. Ahmed',
        device: 'PROBE-QA-02',
        notes: 'All totes within synthetic intake range.',
        ts: '2026-11-19T06:35:00.000Z',
      },
      {
        id: 'QC-002',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        lot_id: null,
        plan_name: 'Line 1 In-Process CCP Plan (Synthetic)',
        check_type: 'core_temp',
        sampling: 'Every kettle batch at discharge',
        spec: '≥ 75.0 °C (Synthetic)',
        measured: '77.4 °C',
        unit: '°C',
        result: 'pass',
        inspector: 'L. Byrne',
        device: 'TT-CKT-104',
        notes: 'Verified against calibrated probe.',
        ts: '2026-11-20T06:42:00.000Z',
      },
      {
        id: 'QC-003',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        lot_id: null,
        plan_name: 'Line 1 Metal Detector Verification',
        check_type: 'metal_detector',
        sampling: 'Hourly Fe 1.5mm / Non-Fe 2.0mm / SS 2.5mm test wands',
        spec: '3/3 Test Wands Rejected',
        measured: '3/3 Rejected',
        unit: 'wands',
        result: 'pass',
        inspector: 'S. Ahmed',
        device: 'MD-INS-109',
        notes: '07:00 hourly test passed.',
        ts: '2026-11-20T07:05:00.000Z',
      },
      {
        id: 'QC-004',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        lot_id: null,
        plan_name: 'Finished Goods Final Release Plan (Synthetic)',
        check_type: 'seal_integrity',
        sampling: 'Vacuum dye burst test — 6 trays per 2,500 units',
        spec: '0 leaks, seal width ≥ 4.0 mm',
        measured: null,
        unit: 'leaks',
        result: 'pending',
        inspector: null,
        device: 'VAC-TEST-01',
        notes: 'Awaiting end-of-run sample test before QA release.',
        ts: null,
      },
      {
        id: 'QC-005',
        order_id: 'PO-2026-1041',
        batch_id: 'BAT-261120-01',
        lot_id: null,
        plan_name: 'Finished Goods Final Release Plan (Synthetic)',
        check_type: 'lab_micro',
        sampling: 'Composite swab & TVC rapid screen',
        spec: 'Within site-approved synthetic threshold',
        measured: null,
        unit: 'cfu/g',
        result: 'pending',
        inspector: null,
        device: 'LAB-LIMS-SYNC',
        notes: 'Sample logged; result intentionally missing until entered.',
        ts: null,
      },
    ];
    for (const q of checks) {
      db.prepare(`
        INSERT INTO quality_checks (
          id, order_id, batch_id, lot_id, plan_name, check_type,
          sampling_instruction, target_spec, measured_value, unit, result,
          inspector_name, sensor_or_device_id, notes, recorded_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        q.id,
        q.order_id,
        q.batch_id,
        q.lot_id,
        q.plan_name,
        q.check_type,
        q.sampling,
        q.spec,
        q.measured,
        q.unit,
        q.result,
        q.inspector,
        q.device,
        q.notes,
        q.ts,
      );
    }

    // 10. Seed initial cases & pallet for first 3,600 trays (300 cases on 3 pallets)
    for (let p = 1; p <= 3; p++) {
      const palletId = `PLT-261120-00${p}`;
      const sscc = `00350123450000000${p}`;
      db.prepare(`
        INSERT INTO pallets (
          id, sscc_code, order_id, case_count, total_units, location_code,
          quality_status, shipment_id, built_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        palletId,
        sscc,
        'PO-2026-1041',
        100,
        1200,
        `FG-CHILL-R${p}`,
        'pending',
        null,
        '2026-11-20T07:45:00.000Z',
      );
      for (let c = 1; c <= 5; c++) {
        // Representative tracked cases per pallet in DB
        const caseId = `CASE-${p}-0${c}`;
        db.prepare(`
          INSERT INTO packaging_cases (
            id, case_uid, order_id, batch_id, pallet_id, unit_count,
            packaging_lot_id, label_version_used, quality_status, packed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          caseId,
          `CS-261120-${p}0${c}`,
          'PO-2026-1041',
          'BAT-261120-01',
          palletId,
          12,
          'LOT-CASE-12A',
          'v2.1',
          'pending',
          '2026-11-20T07:40:00.000Z',
        );
      }
      db.prepare(`
        INSERT INTO batch_genealogy (
          id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        `GEN-B1-${palletId}`,
        'production_batch',
        'BAT-261120-01',
        'pallet',
        palletId,
        1200,
        'units',
        'packed_into',
        '2026-11-20T07:45:00.000Z',
      );
    }

    // 11. Maintenance Work Orders
    const workOrders = [
      {
        id: 'MWO-101',
        station_id: 'STN-SEAL',
        station_name: 'MAP Tray Sealer',
        title: 'Inspect PTFE heat-seal jaw tape & vacuum gasket',
        priority: 'high',
        work_type: 'inspection_advisory',
        status: 'open',
        parts: 'PTFE Jaw Strip 420mm, Silicone Gasket Seal',
        evidence: 'Advisory: slight seal bar thermal recovery variance (+1.4s over 400 cycles). Human inspection required; does not replace scheduled PM.',
        due_at: '2026-11-20T18:00:00.000Z',
        assigned_to: 'T. Brennan',
      },
      {
        id: 'MWO-102',
        station_id: 'STN-INSP',
        station_name: 'Checkweigher & Metal Detector',
        title: 'Annual ISO/UKAS load cell calibration certificate renewal',
        priority: 'routine',
        work_type: 'calibration',
        status: 'open',
        parts: '200g / 500g F1 Reference Weights',
        evidence: 'Calibration due 2026-12-28.',
        due_at: '2026-12-20T12:00:00.000Z',
        assigned_to: 'K. Osei',
      },
    ];
    for (const m of workOrders) {
      db.prepare(`
        INSERT INTO maintenance_work_orders (
          id, station_id, station_name, title, priority, work_type, status,
          spare_parts_required, evidence_note, due_at, assigned_to, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        m.id,
        m.station_id,
        m.station_name,
        m.title,
        m.priority,
        m.work_type,
        m.status,
        m.parts,
        m.evidence,
        m.due_at,
        m.assigned_to,
        null,
      );
    }

    // 12. Energy Readings
    db.prepare(`
      INSERT INTO energy_readings (
        id, line_id, shift_name, electricity_kwh, steam_kg, chilled_water_litres,
        process_water_litres, units_produced_context, recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'ENR-001',
      'LINE-01',
      'Shift A (06:00–14:00)',
      412.6,
      685.0,
      4200.0,
      6850.0,
      3600,
      now,
    );

    // 13. Initial Audit Entry
    db.prepare(`
      INSERT INTO audit_events (id, actor, role, action, entity_type, entity_id, details, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'AUD-001',
      'System Seeder',
      'admin',
      'FACTORY_SEED_INITIALISED',
      'system',
      'LINE-01',
      'Initialised synthetic factory environment for 10,000 Chilled Vegetable Meal Trays (PO-2026-1041).',
      now,
    );
  });
}
