import {createRequire} from 'node:module';
import type {DatabaseSync as DatabaseSyncType} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname, resolve} from 'node:path';

const require = createRequire(import.meta.url);

let defaultDb: DatabaseSyncType | null = null;

export function createDatabase(dbPath: string): DatabaseSyncType {
  if (dbPath !== ':memory:') {
    mkdirSync(dirname(dbPath), {recursive: true});
  }
  const {DatabaseSync} = require('node:sqlite') as {
    DatabaseSync: typeof DatabaseSyncType;
  };
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  if (dbPath !== ':memory:') {
    db.exec('PRAGMA journal_mode = WAL;');
  }
  return db;
}

export function getDb(): DatabaseSyncType {
  if (!defaultDb) {
    const dbPath =
      process.env['AUREOM_DB_PATH'] || resolve(process.cwd(), 'data', 'aureom.db');
    defaultDb = createDatabase(dbPath);
  }
  return defaultDb;
}

export function resetDefaultDbForTests(db: DatabaseSyncType): void {
  defaultDb = db;
}

export function withTransaction<T>(db: DatabaseSyncType, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // Ignore rollback error if transaction already aborted
    }
    throw err;
  }
}
