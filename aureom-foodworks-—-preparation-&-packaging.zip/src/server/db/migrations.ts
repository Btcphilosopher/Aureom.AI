import {DatabaseSync} from 'node:sqlite';

const MIGRATION_001 = `
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS system_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  key TEXT PRIMARY KEY,
  endpoint TEXT NOT NULL,
  status_code INTEGER NOT NULL,
  response_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stations (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  stage TEXT NOT NULL,
  sequence_order INTEGER NOT NULL,
  state TEXT NOT NULL,
  line_id TEXT NOT NULL,
  active_order_id TEXT,
  active_operator TEXT,
  setpoint_label TEXT NOT NULL,
  setpoint_value REAL,
  measured_value REAL,
  unit TEXT NOT NULL,
  sensor_id TEXT NOT NULL,
  calibration_due TEXT NOT NULL,
  calibration_valid INTEGER NOT NULL DEFAULT 1,
  throughput_per_min REAL NOT NULL DEFAULT 0,
  buffer_count INTEGER NOT NULL DEFAULT 0,
  buffer_capacity INTEGER NOT NULL DEFAULT 100,
  fault_reason TEXT,
  last_observation_at TEXT NOT NULL,
  is_synthetic INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS label_templates (
  id TEXT PRIMARY KEY,
  template_code TEXT NOT NULL,
  version TEXT NOT NULL,
  product_sku TEXT NOT NULL,
  product_name TEXT NOT NULL,
  ingredients_text TEXT NOT NULL,
  allergens_declaration TEXT NOT NULL,
  net_quantity_text TEXT NOT NULL,
  storage_instructions TEXT NOT NULL,
  date_mark_rule TEXT NOT NULL,
  barcode_format TEXT NOT NULL,
  status TEXT NOT NULL,
  UNIQUE(template_code, version)
);

CREATE TABLE IF NOT EXISTS recipe_versions (
  id TEXT PRIMARY KEY,
  recipe_code TEXT NOT NULL,
  product_sku TEXT NOT NULL,
  product_name TEXT NOT NULL,
  category TEXT NOT NULL,
  version_number TEXT NOT NULL,
  status TEXT NOT NULL,
  batch_size_kg REAL NOT NULL,
  expected_yield_units INTEGER NOT NULL,
  unit_weight_grams REAL NOT NULL,
  allergens_json TEXT NOT NULL,
  cross_contact_notes TEXT NOT NULL,
  approved_label_template_id TEXT NOT NULL,
  approved_label_version TEXT NOT NULL,
  effective_from TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  revision_reason TEXT NOT NULL,
  ingredients_json TEXT NOT NULL,
  packaging_bom_json TEXT NOT NULL,
  process_limits_json TEXT NOT NULL,
  prep_steps_json TEXT NOT NULL,
  UNIQUE(recipe_code, version_number)
);

CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  approval_status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS inventory_lots (
  id TEXT PRIMARY KEY,
  internal_uid TEXT NOT NULL UNIQUE,
  material_code TEXT NOT NULL,
  material_name TEXT NOT NULL,
  material_kind TEXT NOT NULL,
  supplier_id TEXT NOT NULL,
  supplier_name TEXT NOT NULL,
  supplier_lot_code TEXT NOT NULL,
  barcode_value TEXT NOT NULL,
  po_number TEXT NOT NULL,
  quantity_on_hand REAL NOT NULL,
  quantity_reserved REAL NOT NULL DEFAULT 0,
  unit TEXT NOT NULL,
  location_code TEXT NOT NULL,
  received_at TEXT NOT NULL,
  expiry_date TEXT NOT NULL,
  temperature_c REAL,
  quality_status TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  CHECK (quantity_on_hand >= 0),
  CHECK (quantity_reserved >= 0),
  CHECK (quantity_reserved <= quantity_on_hand)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id TEXT PRIMARY KEY,
  lot_id TEXT NOT NULL REFERENCES inventory_lots(id),
  movement_type TEXT NOT NULL,
  quantity_delta REAL NOT NULL,
  unit TEXT NOT NULL,
  order_id TEXT,
  batch_id TEXT,
  reference_id TEXT,
  linked_movement_id TEXT,
  reason TEXT NOT NULL,
  performed_by TEXT NOT NULL,
  performed_role TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS production_orders (
  id TEXT PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  recipe_version_id TEXT NOT NULL REFERENCES recipe_versions(id),
  recipe_code TEXT NOT NULL,
  product_sku TEXT NOT NULL,
  product_name TEXT NOT NULL,
  line_id TEXT NOT NULL,
  shift_name TEXT NOT NULL,
  target_units INTEGER NOT NULL,
  produced_units INTEGER NOT NULL DEFAULT 0,
  rejected_units INTEGER NOT NULL DEFAULT 0,
  rework_units INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  quality_release_status TEXT NOT NULL,
  scheduled_start TEXT NOT NULL,
  scheduled_end TEXT NOT NULL,
  actual_start TEXT,
  actual_end TEXT,
  dispatch_deadline TEXT NOT NULL,
  customer_order_ref TEXT NOT NULL,
  assigned_supervisor TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS production_batches (
  id TEXT PRIMARY KEY,
  batch_code TEXT NOT NULL UNIQUE,
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  recipe_version_id TEXT NOT NULL REFERENCES recipe_versions(id),
  parent_batch_id TEXT,
  is_rework INTEGER NOT NULL DEFAULT 0,
  produced_units INTEGER NOT NULL DEFAULT 0,
  waste_kg REAL NOT NULL DEFAULT 0,
  quality_status TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS batch_genealogy (
  id TEXT PRIMARY KEY,
  parent_type TEXT NOT NULL,
  parent_id TEXT NOT NULL,
  child_type TEXT NOT NULL,
  child_id TEXT NOT NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  relationship TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS processing_events (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  batch_id TEXT NOT NULL REFERENCES production_batches(id),
  station_id TEXT NOT NULL REFERENCES stations(id),
  station_name TEXT NOT NULL,
  operator_name TEXT NOT NULL,
  ingredient_lot_ids_json TEXT NOT NULL,
  setpoint_value REAL,
  measured_value REAL,
  unit TEXT NOT NULL,
  duration_minutes REAL NOT NULL,
  output_quantity REAL NOT NULL,
  output_unit TEXT NOT NULL,
  sensor_id TEXT NOT NULL,
  calibration_status TEXT NOT NULL,
  deviation_flag INTEGER NOT NULL DEFAULT 0,
  disposition_note TEXT,
  recorded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS packaging_setups (
  id TEXT PRIMARY KEY,
  line_id TEXT NOT NULL,
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  format_name TEXT NOT NULL,
  tray_lot_id TEXT NOT NULL,
  film_lot_id TEXT NOT NULL,
  loaded_label_template_id TEXT NOT NULL,
  loaded_label_version TEXT NOT NULL,
  loaded_label_lot_id TEXT NOT NULL,
  expected_label_template_id TEXT NOT NULL,
  expected_label_version TEXT NOT NULL,
  mismatch_detected INTEGER NOT NULL DEFAULT 0,
  line_clearance_signed_by TEXT,
  line_clearance_at TEXT,
  filler_status TEXT NOT NULL,
  sealer_status TEXT NOT NULL,
  printer_status TEXT NOT NULL,
  checkweigher_status TEXT NOT NULL,
  seal_integrity_pass_count INTEGER NOT NULL DEFAULT 0,
  seal_integrity_fail_count INTEGER NOT NULL DEFAULT 0,
  labels_printed INTEGER NOT NULL DEFAULT 0,
  labels_voided INTEGER NOT NULL DEFAULT 0,
  labels_remaining_reconciled INTEGER NOT NULL DEFAULT 0,
  scrap_units INTEGER NOT NULL DEFAULT 0,
  barcode_format TEXT NOT NULL,
  printer_adapter_mode TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS quality_checks (
  id TEXT PRIMARY KEY,
  order_id TEXT,
  batch_id TEXT,
  lot_id TEXT,
  plan_name TEXT NOT NULL,
  check_type TEXT NOT NULL,
  sampling_instruction TEXT NOT NULL,
  target_spec TEXT NOT NULL,
  measured_value TEXT,
  unit TEXT NOT NULL,
  result TEXT NOT NULL,
  inspector_name TEXT,
  sensor_or_device_id TEXT,
  notes TEXT NOT NULL DEFAULT '',
  recorded_at TEXT
);

CREATE TABLE IF NOT EXISTS quality_holds (
  id TEXT PRIMARY KEY,
  batch_id TEXT,
  order_id TEXT,
  lot_id TEXT,
  reason_code TEXT NOT NULL,
  description TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL,
  affected_units INTEGER NOT NULL DEFAULT 0,
  disposition TEXT NOT NULL,
  corrective_action TEXT NOT NULL DEFAULT '',
  opened_by TEXT NOT NULL,
  opened_at TEXT NOT NULL,
  closed_by TEXT,
  closed_at TEXT
);

CREATE TABLE IF NOT EXISTS packaging_cases (
  id TEXT PRIMARY KEY,
  case_uid TEXT NOT NULL UNIQUE,
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  batch_id TEXT NOT NULL REFERENCES production_batches(id),
  pallet_id TEXT,
  unit_count INTEGER NOT NULL,
  packaging_lot_id TEXT NOT NULL,
  label_version_used TEXT NOT NULL,
  quality_status TEXT NOT NULL,
  packed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pallets (
  id TEXT PRIMARY KEY,
  sscc_code TEXT NOT NULL UNIQUE,
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  case_count INTEGER NOT NULL,
  total_units INTEGER NOT NULL,
  location_code TEXT NOT NULL,
  quality_status TEXT NOT NULL,
  shipment_id TEXT,
  built_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shipments (
  id TEXT PRIMARY KEY,
  shipment_number TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  destination TEXT NOT NULL,
  vehicle_temp_c REAL NOT NULL,
  status TEXT NOT NULL,
  pallet_ids_json TEXT NOT NULL,
  total_units INTEGER NOT NULL,
  dispatched_by TEXT,
  dispatched_at TEXT
);

CREATE TABLE IF NOT EXISTS maintenance_work_orders (
  id TEXT PRIMARY KEY,
  station_id TEXT NOT NULL REFERENCES stations(id),
  station_name TEXT NOT NULL,
  title TEXT NOT NULL,
  priority TEXT NOT NULL,
  work_type TEXT NOT NULL,
  status TEXT NOT NULL,
  spare_parts_required TEXT NOT NULL,
  evidence_note TEXT NOT NULL,
  due_at TEXT NOT NULL,
  assigned_to TEXT NOT NULL,
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS energy_readings (
  id TEXT PRIMARY KEY,
  line_id TEXT NOT NULL,
  shift_name TEXT NOT NULL,
  electricity_kwh REAL NOT NULL,
  steam_kg REAL NOT NULL,
  chilled_water_litres REAL NOT NULL,
  process_water_litres REAL NOT NULL,
  units_produced_context INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry_dedup (
  event_id TEXT PRIMARY KEY,
  source_topic TEXT NOT NULL,
  seq_number INTEGER NOT NULL,
  device_timestamp TEXT NOT NULL,
  received_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  actor TEXT NOT NULL,
  role TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  details TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_movements_lot ON inventory_movements(lot_id, created_at);
CREATE INDEX IF NOT EXISTS idx_genealogy_parent ON batch_genealogy(parent_id);
CREATE INDEX IF NOT EXISTS idx_genealogy_child ON batch_genealogy(child_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at DESC);
`;

export function runMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const applied = db
    .prepare('SELECT version FROM schema_migrations WHERE version = 1')
    .get();

  if (!applied) {
    db.exec(MIGRATION_001);
    db.prepare(
      'INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)',
    ).run(1, '001_initial_schema', new Date().toISOString());
  }
}
