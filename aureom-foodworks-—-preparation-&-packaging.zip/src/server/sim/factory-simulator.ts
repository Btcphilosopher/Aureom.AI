import {DatabaseSync} from 'node:sqlite';
import {
  AuditEvent,
  DispatchCommitment,
  FactorySnapshot,
  Station,
  StationState,
} from '../../shared/domain';
import {listProductionOrders} from '../services/production-service';
import {calculateOeeMetrics} from '../services/maintenance-energy-backup-service';
import {getOperatingMode} from '../services/rbac';

function mapStationRow(r: Record<string, unknown>): Station {
  return {
    id: String(r['id']),
    code: String(r['code']),
    name: String(r['name']),
    stage: String(r['stage']),
    sequenceOrder: Number(r['sequence_order']),
    state: r['state'] as StationState,
    lineId: String(r['line_id']),
    activeOrderId: r['active_order_id'] ? String(r['active_order_id']) : null,
    activeOperator: r['active_operator'] ? String(r['active_operator']) : null,
    setpointLabel: String(r['setpoint_label']),
    setpointValue: r['setpoint_value'] === null ? null : Number(r['setpoint_value']),
    measuredValue: r['measured_value'] === null ? null : Number(r['measured_value']),
    unit: String(r['unit']),
    sensorId: String(r['sensor_id']),
    calibrationDue: String(r['calibration_due']),
    calibrationValid: Number(r['calibration_valid']) === 1,
    throughputPerMin: Number(r['throughput_per_min']),
    bufferCount: Number(r['buffer_count']),
    bufferCapacity: Number(r['buffer_capacity']),
    faultReason: r['fault_reason'] ? String(r['fault_reason']) : null,
    lastObservationAt: String(r['last_observation_at']),
    isSynthetic: Number(r['is_synthetic']) === 1,
  };
}

export function listStations(db: DatabaseSync): Station[] {
  return db
    .prepare('SELECT * FROM stations ORDER BY sequence_order ASC')
    .all()
    .map(mapStationRow);
}

export function getFactorySnapshot(db: DatabaseSync): FactorySnapshot {
  const mode = getOperatingMode(db);
  const outageRow = db
    .prepare("SELECT value FROM system_state WHERE key = 'telemetry_outage_simulated'")
    .get() as {value: string} | undefined;
  const telemetryOutageSimulated = outageRow?.value === 'true';

  const lastRow = db
    .prepare("SELECT value FROM system_state WHERE key = 'last_telemetry_at'")
    .get() as {value: string} | undefined;
  const lastTelemetryAt = lastRow?.value ?? new Date().toISOString();
  const telemetryAgeSeconds = Math.max(
    0,
    Math.round((Date.now() - new Date(lastTelemetryAt).getTime()) / 1000),
  );
  const dataStale = telemetryOutageSimulated || telemetryAgeSeconds > 15;

  const stations = listStations(db);
  const orders = listProductionOrders(db);
  const oee = calculateOeeMetrics(db);

  const activeHoldsCount = Number(
    (
      db
        .prepare("SELECT COUNT(*) as c FROM quality_holds WHERE status != 'closed'")
        .get() as {c: number}
    ).c,
  );

  const threeDaysAhead = new Date(Date.now() + 3 * 86400_000).toISOString();
  const expiringLotsCount = Number(
    (
      db
        .prepare(
          "SELECT COUNT(*) as c FROM inventory_lots WHERE expiry_date <= ? AND quality_status != 'rejected' AND quantity_on_hand > 0",
        )
        .get(threeDaysAhead) as {c: number}
    ).c,
  );

  // Check packaging shortage for PO-2026-1042 (PK-TRAY-400B)
  const bowlAvail = db
    .prepare(
      "SELECT COALESCE(SUM(quantity_on_hand - quantity_reserved), 0) AS avail FROM inventory_lots WHERE material_code = 'PK-TRAY-400B' AND quality_status = 'released'",
    )
    .get() as {avail: number};
  const shortageCount = bowlAvail.avail < 4500 ? 1 : 0;

  const dispatchCommitments: DispatchCommitment[] = orders.map((o) => {
    const staged = db
      .prepare('SELECT COALESCE(SUM(total_units), 0) AS u FROM pallets WHERE order_id = ?')
      .get(o.id) as {u: number};
    const shipped = db
      .prepare(
        "SELECT COALESCE(SUM(total_units), 0) AS u FROM pallets WHERE order_id = ? AND shipment_id IS NOT NULL",
      )
      .get(o.id) as {u: number};
    return {
      id: `DC-${o.id}`,
      customer: o.customerOrderRef,
      orderNumber: o.orderNumber,
      productName: o.productName,
      targetUnits: o.targetUnits,
      stagedUnits: Number(staged.u),
      dueAt: o.dispatchDeadline,
      status:
        Number(shipped.u) >= o.targetUnits
          ? 'dispatched'
          : o.id === 'PO-2026-1042' && shortageCount > 0
            ? 'at_risk'
            : 'on_track',
    };
  });

  const recentAudit = db
    .prepare('SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 12')
    .all()
    .map((r) => ({
      id: String(r['id']),
      actor: String(r['actor']),
      role: r['role'] as AuditEvent['role'],
      action: String(r['action']),
      entityType: String(r['entity_type']),
      entityId: String(r['entity_id']),
      details: String(r['details']),
      createdAt: String(r['created_at']),
    }));

  return {
    operatingMode: mode,
    telemetryConnected: !telemetryOutageSimulated,
    telemetryOutageSimulated,
    lastTelemetryAt,
    telemetryAgeSeconds,
    dataStale,
    syntheticBanner:
      'Synthetic Factory Environment — example process limits and equipment telemetry are simulated for demonstration.',
    stations,
    orders,
    oee,
    activeHoldsCount,
    expiringLotsCount,
    shortageCount,
    dispatchCommitments,
    recentAudit,
  };
}

/**
 * Advances the discrete-event factory simulation by one step when mode === 'simulation'
 * and telemetry outage is not simulated.
 */
export function stepFactorySimulation(db: DatabaseSync): boolean {
  const mode = getOperatingMode(db);
  if (mode !== 'simulation') {
    return false;
  }
  const outageRow = db
    .prepare("SELECT value FROM system_state WHERE key = 'telemetry_outage_simulated'")
    .get() as {value: string} | undefined;
  if (outageRow?.value === 'true') {
    return false;
  }

  const now = new Date().toISOString();
  db.prepare(
    "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('last_telemetry_at', ?, ?)",
  ).run(now, now);

  const tickRow = db
    .prepare("SELECT value FROM system_state WHERE key = 'sim_tick_count'")
    .get() as {value: string} | undefined;
  const tick = Number(tickRow?.value ?? '0') + 1;
  db.prepare(
    "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('sim_tick_count', ?, ?)",
  ).run(String(tick), now);

  const stations = listStations(db);
  for (const st of stations) {
    if (st.state === 'running' && st.setpointValue !== null) {
      const wave = Math.sin((tick + st.sequenceOrder) * 0.65);
      const jitter =
        st.unit === '°C'
          ? Number((wave * 0.35).toFixed(1))
          : st.unit === 'g'
            ? Number((wave * 0.9).toFixed(1))
            : st.unit === '%'
              ? Number((wave * 0.2).toFixed(1))
              : 0;
      const base =
        st.id === 'STN-COOK'
          ? 77.4
          : st.id === 'STN-COOL'
            ? 3.7
            : st.id === 'STN-FILL'
              ? 381.0
              : st.id === 'STN-INSP'
                ? 380.8
                : st.setpointValue;
      const nextVal = Number((base + jitter).toFixed(1));
      const nextBuf = Math.max(
        4,
        Math.min(st.bufferCapacity - 2, st.bufferCount + (tick % 2 === 0 ? 1 : -1)),
      );
      db.prepare(
        'UPDATE stations SET measured_value = ?, buffer_count = ?, last_observation_at = ? WHERE id = ?',
      ).run(nextVal, nextBuf, now, st.id);
    }
  }

  // Gently advance produced units if PO-2026-1041 is in_progress and no mismatch/fault
  const activeOrder = db
    .prepare("SELECT * FROM production_orders WHERE id = 'PO-2026-1041'")
    .get() as Record<string, unknown> | undefined;
  const pkgMismatch = db
    .prepare("SELECT mismatch_detected FROM packaging_setups WHERE order_id = 'PO-2026-1041'")
    .get() as {mismatch_detected: number} | undefined;

  if (
    activeOrder &&
    activeOrder['status'] === 'in_progress' &&
    (!pkgMismatch || pkgMismatch.mismatch_detected === 0)
  ) {
    const produced = Number(activeOrder['produced_units']);
    const target = Number(activeOrder['target_units']);
    if (produced < target) {
      const increment = Math.min(24, target - produced);
      db.prepare(
        "UPDATE production_orders SET produced_units = produced_units + ? WHERE id = 'PO-2026-1041'",
      ).run(increment);
      db.prepare(
        "UPDATE packaging_setups SET labels_printed = labels_printed + ?, labels_remaining_reconciled = MAX(0, labels_remaining_reconciled - ?), updated_at = ? WHERE order_id = 'PO-2026-1041'",
      ).run(increment, increment, now);
    }
  }

  return true;
}
