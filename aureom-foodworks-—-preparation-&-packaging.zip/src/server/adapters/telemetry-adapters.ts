import {DatabaseSync} from 'node:sqlite';
import {withTransaction} from '../db/connection';
import {DomainError} from '../services/rbac';

export interface TelemetryObservation {
  eventId: string;
  sourceProtocol: 'mqtt' | 'opcua' | 'simulated_des';
  topicOrNodeId: string;
  stationId: string;
  sensorId: string;
  seqNumber: number;
  measuredValue: number;
  unit: string;
  deviceTimestamp: string;
}

export interface PrinterAdapterStatus {
  adapterName: string;
  protocol: string;
  connected: boolean;
  lastJobId: string;
  note: string;
}

export interface ScannerAdapterResult {
  scannerId: string;
  barcodeValue: string;
  matchedLotId: string | null;
  matchedMaterialName: string | null;
  qualityStatus: string | null;
  scannedAt: string;
}

export interface TelemetryIngestionOutcome {
  accepted: boolean;
  duplicate: boolean;
  outOfOrder: boolean;
  clockSkewSeconds: number;
  reason: string;
}

/**
 * Ingests equipment telemetry with deduplication, sequence-number out-of-order protection,
 * and clock-skew visibility. Never sends machine control commands.
 */
export function ingestTelemetryObservation(
  db: DatabaseSync,
  obs: TelemetryObservation,
): TelemetryIngestionOutcome {
  return withTransaction(db, () => {
    const dup = db
      .prepare('SELECT event_id FROM telemetry_dedup WHERE event_id = ?')
      .get(obs.eventId);
    if (dup) {
      return {
        accepted: false,
        duplicate: true,
        outOfOrder: false,
        clockSkewSeconds: 0,
        reason: `Duplicate telemetry event '${obs.eventId}' ignored idempotently.`,
      };
    }

    const latestSeq = db
      .prepare(
        'SELECT MAX(seq_number) AS max_seq FROM telemetry_dedup WHERE source_topic = ?',
      )
      .get(obs.topicOrNodeId) as {max_seq: number | null} | undefined;

    const outOfOrder =
      latestSeq?.max_seq !== null &&
      latestSeq?.max_seq !== undefined &&
      obs.seqNumber <= latestSeq.max_seq;

    const nowMs = Date.now();
    const deviceMs = new Date(obs.deviceTimestamp).getTime();
    const clockSkewSeconds = Number.isFinite(deviceMs)
      ? Math.round((nowMs - deviceMs) / 1000)
      : 0;

    db.prepare(`
      INSERT INTO telemetry_dedup (event_id, source_topic, seq_number, device_timestamp, received_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      obs.eventId,
      obs.topicOrNodeId,
      obs.seqNumber,
      obs.deviceTimestamp,
      new Date(nowMs).toISOString(),
    );

    if (outOfOrder) {
      return {
        accepted: false,
        duplicate: false,
        outOfOrder: true,
        clockSkewSeconds,
        reason: `Out-of-order sequence ${obs.seqNumber} <= ${latestSeq?.max_seq}; archived to dedup log without overwriting newer station value.`,
      };
    }

    const updateRes = db
      .prepare(
        'UPDATE stations SET measured_value = ?, last_observation_at = ? WHERE id = ?',
      )
      .run(obs.measuredValue, obs.deviceTimestamp, obs.stationId);

    if (updateRes.changes === 0) {
      throw new DomainError(`Unknown station '${obs.stationId}'.`, 404, 'STATION_NOT_FOUND');
    }

    db.prepare(
      "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('last_telemetry_at', ?, ?)",
    ).run(new Date(nowMs).toISOString(), new Date(nowMs).toISOString());

    return {
      accepted: true,
      duplicate: false,
      outOfOrder: false,
      clockSkewSeconds,
      reason: `Applied ${obs.sourceProtocol.toUpperCase()} reading (${obs.measuredValue} ${obs.unit}) from ${obs.sensorId}.`,
    };
  });
}

export function simulateBarcodeScan(
  db: DatabaseSync,
  barcodeValue: string,
): ScannerAdapterResult {
  const row = db
    .prepare(
      'SELECT id, material_name, quality_status FROM inventory_lots WHERE barcode_value = ? OR internal_uid = ? OR id = ?',
    )
    .get(barcodeValue.trim(), barcodeValue.trim(), barcodeValue.trim()) as
    | {id: string; material_name: string; quality_status: string}
    | undefined;

  return {
    scannerId: 'SIM-HONEYWELL-1950G',
    barcodeValue: barcodeValue.trim(),
    matchedLotId: row?.id ?? null,
    matchedMaterialName: row?.material_name ?? null,
    qualityStatus: row?.quality_status ?? null,
    scannedAt: new Date().toISOString(),
  };
}

export function getSimulatedPrinterStatus(): PrinterAdapterStatus {
  return {
    adapterName: 'Simulated Zebra ZT411 Local Adapter',
    protocol: 'ZPL-TCP-Sim (Local Only — Not Hardware Verified)',
    connected: true,
    lastJobId: 'ZPL-JOB-261120-084',
    note: 'Local simulation adapter; real PLC/printer driver integration requires site FAT.',
  };
}
