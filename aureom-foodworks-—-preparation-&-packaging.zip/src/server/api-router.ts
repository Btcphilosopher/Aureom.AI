import express, {Request, Response, Router} from 'express';
import {DatabaseSync} from 'node:sqlite';
import {OperatingMode, OrderStatus, UserRole} from '../shared/domain';
import {seedFactoryDatabase} from './db/seed';
import {
  DomainError,
  getOperatingMode,
  recordAudit,
  runIdempotent,
  assertPermission,
} from './services/rbac';
import {
  adjustLotLedger,
  changeLotQualityStatus,
  issueOrConsumeLot,
  listLots,
  listMovements,
  receiveInventoryLot,
  reserveFefoStock,
} from './services/inventory-service';
import {
  approveRecipeRevision,
  assertRecipeImmutableUpdateBlocked,
  createRecipeRevision,
  listLabelTemplates,
  listRecipes,
} from './services/recipe-service';
import {
  createProductionOrder,
  listProcessingEvents,
  listProductionOrders,
  recordProcessingEvent,
  recordProductionOutput,
  transitionOrderStatus,
} from './services/production-service';
import {
  applyPackagingSetup,
  dispatchPallets,
  listCases,
  listPackagingSetups,
  listPallets,
  listShipments,
  packCaseAndPallet,
} from './services/packaging-service';
import {
  createQualityHold,
  listQualityChecks,
  listQualityHolds,
  recordQualityCheckResult,
  releaseFinishedGoodsOrder,
  resolveQualityHold,
} from './services/quality-service';
import {buildTraceabilityCsv, traceEntity} from './services/traceability-service';
import {
  applyApprovedScheduleReplan,
  runDiscreteEventPlanningComparison,
} from './services/planning-service';
import {
  completeMaintenanceWorkOrder,
  createDatabaseBackup,
  createWorkOrder,
  listBackups,
  listEnergyReadings,
  listMaintenanceWorkOrders,
} from './services/maintenance-energy-backup-service';
import {
  getSimulatedPrinterStatus,
  ingestTelemetryObservation,
  simulateBarcodeScan,
  TelemetryObservation,
} from './adapters/telemetry-adapters';
import {getFactorySnapshot, stepFactorySimulation} from './sim/factory-simulator';

function getActorContext(req: Request): {actor: string; role: UserRole} {
  const roleHeader = String(req.header('x-aureom-role') ?? 'supervisor').toLowerCase();
  const validRoles: UserRole[] = [
    'operator',
    'supervisor',
    'quality',
    'maintenance',
    'planner',
    'warehouse',
    'admin',
  ];
  const role = validRoles.includes(roleHeader as UserRole)
    ? (roleHeader as UserRole)
    : 'supervisor';
  const actor = String(req.header('x-aureom-actor') ?? `${role.toUpperCase()} User`).slice(0, 80);
  return {actor, role};
}

function handleError(res: Response, err: unknown): void {
  if (err instanceof DomainError) {
    res.status(err.statusCode).json({error: err.message, code: err.code});
    return;
  }
  const msg = err instanceof Error ? err.message : 'Unexpected server error';
  res.status(500).json({error: msg, code: 'INTERNAL_ERROR'});
}

export function createApiRouter(
  db: DatabaseSync,
  onStateChange?: () => void,
): Router {
  const router = express.Router();
  router.use(express.json());

  const notify = () => {
    if (onStateChange) onStateChange();
  };

  router.get('/health', (_req, res) => {
    res.json({status: 'ok', mode: getOperatingMode(db), timestamp: new Date().toISOString()});
  });

  router.get('/snapshot', (_req, res) => {
    res.json(getFactorySnapshot(db));
  });

  // Operating mode & outage simulation
  router.post('/system/mode', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      assertPermission(role, 'admin:mode_change');
      const mode = String(req.body?.mode ?? '') as OperatingMode;
      if (!['simulation', 'monitoring', 'supervised'].includes(mode)) {
        throw new DomainError(`Invalid operating mode '${mode}'.`, 400, 'INVALID_MODE');
      }
      const now = new Date().toISOString();
      db.prepare(
        "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('operating_mode', ?, ?)",
      ).run(mode, now);
      recordAudit(
        db,
        actor,
        role,
        'OPERATING_MODE_CHANGED',
        'system',
        'LINE-01',
        `Switched operating mode to '${mode}'.`,
      );
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/system/outage', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const active = Boolean(req.body?.active);
      const now = new Date().toISOString();
      db.prepare(
        "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('telemetry_outage_simulated', ?, ?)",
      ).run(active ? 'true' : 'false', now);
      if (!active) {
        db.prepare(
          "INSERT OR REPLACE INTO system_state (key, value, updated_at) VALUES ('last_telemetry_at', ?, ?)",
        ).run(now, now);
      }
      recordAudit(
        db,
        actor,
        role,
        active ? 'TELEMETRY_OUTAGE_SIMULATED' : 'TELEMETRY_RESTORED',
        'system',
        'LINE-01',
        active
          ? 'Simulated telemetry disconnect: UI must display last observation timestamp and stale-data banner.'
          : 'Restored live telemetry stream.',
      );
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/system/reset-demo', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      seedFactoryDatabase(db, true);
      recordAudit(db, actor, role, 'DEMO_SEED_RESET', 'system', 'LINE-01', 'Reset synthetic 10,000-tray factory demonstration dataset.');
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/sim/step', (_req, res) => {
    try {
      stepFactorySimulation(db);
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  // Station state transitions (cleaning, changeover, fault, running)
  router.post('/stations/:id/state', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      assertPermission(role, 'order:execute');
      const stationId = req.params['id'];
      const nextState = String(req.body?.state ?? '');
      const faultReason = req.body?.faultReason ? String(req.body.faultReason) : null;
      const valid = ['running', 'starved', 'blocked', 'cleaning', 'changeover', 'faulted', 'stopped'];
      if (!valid.includes(nextState)) {
        throw new DomainError(`Invalid station state '${nextState}'.`, 400, 'INVALID_STATION_STATE');
      }
      const now = new Date().toISOString();
      const result = db
        .prepare('UPDATE stations SET state = ?, fault_reason = ?, last_observation_at = ? WHERE id = ?')
        .run(nextState, faultReason, now, stationId);
      if (result.changes === 0) {
        throw new DomainError(`Station '${stationId}' not found.`, 404, 'STATION_NOT_FOUND');
      }
      recordAudit(
        db,
        actor,
        role,
        'STATION_STATE_CHANGED',
        'station',
        stationId,
        `Station ${stationId} transitioned to '${nextState}'${faultReason ? ` (${faultReason})` : ''}.`,
      );
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  // Recipes & Label Templates
  router.get('/recipes', (_req, res) => {
    res.json({recipes: listRecipes(db), labelTemplates: listLabelTemplates(db)});
  });

  router.put('/recipes/:id', (req, res) => {
    try {
      assertRecipeImmutableUpdateBlocked(db, req.params['id']);
      res.status(409).json({error: 'Approved recipes are immutable.'});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/recipes/:id/revisions', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const created = createRecipeRevision(
        db,
        req.params['id'],
        String(req.body?.versionNumber ?? ''),
        String(req.body?.revisionReason ?? ''),
        {
          batchSizeKg: req.body?.batchSizeKg ? Number(req.body.batchSizeKg) : undefined,
          expectedYieldUnits: req.body?.expectedYieldUnits
            ? Number(req.body.expectedYieldUnits)
            : undefined,
          crossContactNotes: req.body?.crossContactNotes
            ? String(req.body.crossContactNotes)
            : undefined,
        },
        actor,
        role,
      );
      notify();
      res.status(201).json(created);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/recipes/:id/approve', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const approved = approveRecipeRevision(db, req.params['id'], actor, role);
      notify();
      res.json(approved);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Inventory & Warehouse
  router.get('/inventory', (_req, res) => {
    res.json({lots: listLots(db), movements: listMovements(db)});
  });

  router.post('/inventory/receive', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const idemKey = req.header('idempotency-key');
      const outcome = runIdempotent(db, idemKey, '/api/inventory/receive', () => {
        const lot = receiveInventoryLot(db, req.body, actor, role);
        return {statusCode: 201, body: lot};
      });
      notify();
      res.status(outcome.statusCode).json(outcome.body);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/lots/:id/status', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const lot = changeLotQualityStatus(
        db,
        req.params['id'],
        req.body?.status,
        String(req.body?.reason ?? 'QA status update'),
        actor,
        role,
      );
      notify();
      res.json(lot);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/reserve', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const idemKey = req.header('idempotency-key');
      const outcome = runIdempotent(db, idemKey, '/api/inventory/reserve', () => {
        const resData = reserveFefoStock(
          db,
          String(req.body?.materialCode ?? ''),
          Number(req.body?.quantity ?? 0),
          String(req.body?.unit ?? 'kg'),
          String(req.body?.orderId ?? ''),
          actor,
          role,
        );
        return {statusCode: 200, body: resData};
      });
      notify();
      res.status(outcome.statusCode).json(outcome.body);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/issue', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const idemKey = req.header('idempotency-key');
      const outcome = runIdempotent(db, idemKey, '/api/inventory/issue', () => {
        const lot = issueOrConsumeLot(
          db,
          String(req.body?.lotId ?? ''),
          Number(req.body?.quantity ?? 0),
          String(req.body?.unit ?? 'kg'),
          req.body?.movementType ?? 'consume',
          req.body?.orderId ? String(req.body.orderId) : null,
          req.body?.batchId ? String(req.body.batchId) : null,
          String(req.body?.reason ?? 'Production consumption'),
          actor,
          role,
        );
        return {statusCode: 200, body: lot};
      });
      notify();
      res.status(outcome.statusCode).json(outcome.body);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/adjust', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const lot = adjustLotLedger(
        db,
        String(req.body?.lotId ?? ''),
        Number(req.body?.deltaQuantity ?? 0),
        String(req.body?.unit ?? 'kg'),
        req.body?.linkedMovementId ? String(req.body.linkedMovementId) : null,
        String(req.body?.reason ?? ''),
        actor,
        role,
      );
      notify();
      res.json(lot);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/scan', (req, res) => {
    try {
      const scan = simulateBarcodeScan(db, String(req.body?.barcode ?? ''));
      res.json(scan);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Production Orders & Processing Events
  router.get('/production', (_req, res) => {
    res.json({
      orders: listProductionOrders(db),
      processingEvents: listProcessingEvents(db),
    });
  });

  router.post('/production/orders', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const order = createProductionOrder(db, req.body, actor, role);
      notify();
      res.status(201).json(order);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/production/orders/:id/transition', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const order = transitionOrderStatus(
        db,
        req.params['id'],
        String(req.body?.status ?? '') as OrderStatus,
        actor,
        role,
      );
      notify();
      res.json(order);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/production/processing-events', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const ev = recordProcessingEvent(db, req.body, actor, role);
      notify();
      res.status(201).json(ev);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/production/orders/:id/output', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const order = recordProductionOutput(
        db,
        req.params['id'],
        Number(req.body?.goodUnits ?? 0),
        Number(req.body?.rejectedUnits ?? 0),
        Number(req.body?.reworkUnits ?? 0),
        actor,
        role,
      );
      notify();
      res.json(order);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Packaging, Label Mismatch, Cases, Pallets, Dispatch
  router.get('/packaging', (_req, res) => {
    res.json({
      setups: listPackagingSetups(db),
      cases: listCases(db),
      pallets: listPallets(db),
      shipments: listShipments(db),
      printerAdapter: getSimulatedPrinterStatus(),
    });
  });

  router.post('/packaging/setups/:id/apply', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const result = applyPackagingSetup(db, req.params['id'], req.body, actor, role);
      notify();
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/packaging/pack', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const result = packCaseAndPallet(
        db,
        String(req.body?.orderId ?? ''),
        Number(req.body?.unitCount ?? 1200),
        String(req.body?.palletLocation ?? 'FG-CHILL-R4'),
        actor,
        role,
      );
      notify();
      res.status(201).json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/warehouse/dispatch', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const shipment = dispatchPallets(db, req.body, actor, role);
      notify();
      res.status(201).json(shipment);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Quality & Release
  router.get('/quality', (_req, res) => {
    res.json({
      checks: listQualityChecks(db),
      holds: listQualityHolds(db),
    });
  });

  router.post('/quality/checks/:id/record', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const check = recordQualityCheckResult(
        db,
        req.params['id'],
        String(req.body?.measuredValue ?? ''),
        req.body?.result,
        String(req.body?.notes ?? ''),
        actor,
        role,
      );
      notify();
      res.json(check);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/quality/holds', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const hold = createQualityHold(db, req.body, actor, role);
      notify();
      res.status(201).json(hold);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/quality/holds/:id/close', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const hold = resolveQualityHold(
        db,
        req.params['id'],
        req.body?.disposition,
        String(req.body?.correctiveAction ?? ''),
        actor,
        role,
      );
      notify();
      res.json(hold);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/quality/orders/:id/release', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const result = releaseFinishedGoodsOrder(
        db,
        req.params['id'],
        req.body?.disposition ?? 'released',
        String(req.body?.notes ?? 'QA batch dossier verified'),
        actor,
        role,
      );
      notify();
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Traceability
  router.get('/traceability', (req, res) => {
    try {
      const query = String(req.query['q'] ?? 'BAT-261120-01');
      const dir = String(req.query['direction'] ?? 'full') as 'forward' | 'backward' | 'full';
      const trace = traceEntity(db, query, dir);
      res.json(trace);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.get('/traceability/export', (req, res) => {
    try {
      const query = String(req.query['q'] ?? 'BAT-261120-01');
      const trace = traceEntity(db, query, 'full');
      const csv = buildTraceabilityCsv(trace);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="trace-${trace.queryId}.csv"`);
      res.send(csv);
    } catch (err) {
      handleError(res, err);
    }
  });

  // Planning & Digital Twin
  router.post('/planning/simulate', (req, res) => {
    try {
      const seed = req.body?.seed ? Number(req.body.seed) : 20261120;
      const simulateBreakdownAndShortage = Boolean(req.body?.simulateBreakdownAndShortage);
      res.json(runDiscreteEventPlanningComparison(db, {seed, simulateBreakdownAndShortage}));
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/planning/approve-replan', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      applyApprovedScheduleReplan(
        db,
        String(req.body?.orderId ?? 'PO-2026-1042'),
        Number(req.body?.newTargetUnits ?? 1800),
        String(req.body?.reason ?? 'Split batch to match available bowl stock'),
        actor,
        role,
      );
      notify();
      res.json(getFactorySnapshot(db));
    } catch (err) {
      handleError(res, err);
    }
  });

  // Maintenance, Energy, Telemetry Ingestion, Administration
  router.get('/maintenance', (_req, res) => {
    res.json({workOrders: listMaintenanceWorkOrders(db)});
  });

  router.post('/maintenance/work-orders', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const wo = createWorkOrder(
        db,
        String(req.body?.stationId ?? ''),
        String(req.body?.title ?? ''),
        req.body?.priority ?? 'routine',
        String(req.body?.sparePartsRequired ?? ''),
        actor,
        role,
      );
      notify();
      res.status(201).json(wo);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/maintenance/work-orders/:id/complete', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const wo = completeMaintenanceWorkOrder(
        db,
        req.params['id'],
        String(req.body?.note ?? 'Completed'),
        actor,
        role,
      );
      notify();
      res.json(wo);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.get('/energy', (_req, res) => {
    res.json({readings: listEnergyReadings(db)});
  });

  router.post('/telemetry/ingest', (req, res) => {
    try {
      const obs = req.body as TelemetryObservation;
      const result = ingestTelemetryObservation(db, obs);
      notify();
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.get('/admin/audit', (_req, res) => {
    const events = db
      .prepare('SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 100')
      .all();
    res.json({events, backups: listBackups()});
  });

  router.post('/admin/backup', (req, res) => {
    try {
      const {actor, role} = getActorContext(req);
      const backup = createDatabaseBackup(db, actor, role);
      notify();
      res.status(201).json(backup);
    } catch (err) {
      handleError(res, err);
    }
  });

  return router;
}
