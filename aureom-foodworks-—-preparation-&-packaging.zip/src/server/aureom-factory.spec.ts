import {beforeEach, describe, expect, it} from 'vitest';
import {DatabaseSync} from 'node:sqlite';
import {createDatabase} from './db/connection';
import {runMigrations} from './db/migrations';
import {seedFactoryDatabase} from './db/seed';
import {
  changeLotQualityStatus,
  convertUnit,
  issueOrConsumeLot,
  receiveInventoryLot,
  reserveFefoStock,
} from './services/inventory-service';
import {
  approveRecipeRevision,
  assertRecipeImmutableUpdateBlocked,
  createRecipeRevision,
} from './services/recipe-service';
import {
  applyPackagingSetup,
  dispatchPallets,
  packCaseAndPallet,
} from './services/packaging-service';
import {
  recordQualityCheckResult,
  releaseFinishedGoodsOrder,
} from './services/quality-service';
import {traceEntity} from './services/traceability-service';
import {ingestTelemetryObservation} from './adapters/telemetry-adapters';
import {DomainError} from './services/rbac';

describe('AUREOM FOODWORKS — Core Manufacturing & Safety Invariants', () => {
  let db: DatabaseSync;

  beforeEach(() => {
    db = createDatabase(':memory:');
    runMigrations(db);
    seedFactoryDatabase(db, true);
  });

  it('blocks issuing quarantined or expired stock and enforces FEFO', () => {
    // Quarantined lot LOT-CAR-01B cannot be issued
    expect(() =>
      issueOrConsumeLot(
        db,
        'LOT-CAR-01B',
        10,
        'kg',
        'consume',
        'PO-2026-1041',
        'BAT-261120-01',
        'Attempted issue from quarantine',
        'M. Patel',
        'warehouse',
      ),
    ).toThrowError(DomainError);

    // Expired/rejected lot LOT-BRO-EXPIRED cannot be issued
    expect(() =>
      issueOrConsumeLot(
        db,
        'LOT-BRO-EXPIRED',
        10,
        'kg',
        'consume',
        'PO-2026-1041',
        'BAT-261120-01',
        'Attempted issue expired lot',
        'M. Patel',
        'warehouse',
      ),
    ).toThrowError(/Blocked/);

    // Release quarantined lot as QA and verify FEFO picks earliest expiry first (LOT-CAR-01A before LOT-CAR-01B)
    changeLotQualityStatus(db, 'LOT-CAR-01B', 'released', 'QA passed', 'Dr. R. Gallagher', 'quality');
    const res = reserveFefoStock(db, 'RM-CAR-01', 1400, 'kg', 'PO-2026-1041', 'A. Lindqvist', 'planner');
    expect(res.allocations[0]?.lotId).toBe('LOT-CAR-01A');
    expect(res.allocations.length).toBe(2);
  });

  it('prevents over-reservation under sequential/concurrent stock contention', () => {
    // LOT-PEP-03A starts with 1200 - 330 = 870 kg on hand
    reserveFefoStock(db, 'RM-PEP-03', 800, 'kg', 'PO-2026-1041', 'A. Lindqvist', 'planner');
    expect(() =>
      reserveFefoStock(db, 'RM-PEP-03', 100, 'kg', 'PO-2026-1042', 'A. Lindqvist', 'planner'),
    ).toThrowError(/Insufficient released non-expired stock/);
  });

  it('enforces dimensional validation on unit conversions', () => {
    expect(convertUnit(2.5, 'kg', 'g')).toBe(2500);
    expect(() => convertUnit(10, 'kg', 'L')).toThrowError(/Dimensional mismatch/);
  });

  it('enforces recipe version immutability and requires draft + approval workflow', () => {
    expect(() => assertRecipeImmutableUpdateBlocked(db, 'RCP-CVMT-V2_1')).toThrowError(/immutable/);
    const draft = createRecipeRevision(
      db,
      'RCP-CVMT-V2_1',
      'v2.2',
      'Seasonal oil viscosity update',
      {},
      'C. Vance',
      'supervisor',
    );
    expect(draft.status).toBe('draft');

    // Operator cannot approve recipe
    expect(() => approveRecipeRevision(db, draft.id, 'E. Kowalski', 'operator')).toThrowError(
      /not authorised/,
    );

    const approved = approveRecipeRevision(db, draft.id, 'Dr. R. Gallagher', 'quality');
    expect(approved.status).toBe('approved');
  });

  it('detects label mismatch, halts line with hold, and requires authorised clearance', () => {
    const mismatchRes = applyPackagingSetup(
      db,
      'PKG-SETUP-L1',
      {
        loadedLabelTemplateId: 'LBL-CVMT-V1',
        loadedLabelVersion: 'v1.0',
        loadedLabelLotId: 'LOT-LBL-LEGACY-V1',
      },
      'E. Kowalski',
      'operator',
    );
    expect(mismatchRes.setup.mismatchDetected).toBe(true);
    expect(mismatchRes.holdCreatedId).toBeTruthy();

    // Operator cannot clear mismatch
    expect(() =>
      applyPackagingSetup(
        db,
        'PKG-SETUP-L1',
        {
          loadedLabelTemplateId: 'LBL-CVMT-V2',
          loadedLabelVersion: 'v2.1',
          loadedLabelLotId: 'LOT-LBL-CVMT-V2',
        },
        'E. Kowalski',
        'operator',
      ),
    ).toThrowError(/not authorised/);

    // Supervisor or Quality clears mismatch
    const cleared = applyPackagingSetup(
      db,
      'PKG-SETUP-L1',
      {
        loadedLabelTemplateId: 'LBL-CVMT-V2',
        loadedLabelVersion: 'v2.1',
        loadedLabelLotId: 'LOT-LBL-CVMT-V2',
      },
      'Dr. R. Gallagher',
      'quality',
    );
    expect(cleared.setup.mismatchDetected).toBe(false);
  });

  it('blocks QA release while checks are pending, enforces RBAC, and executes full trace + dispatch', () => {
    // Cannot release while QC-004 and QC-005 are pending (never inferred passing)
    expect(() =>
      releaseFinishedGoodsOrder(db, 'PO-2026-1041', 'released', 'Attempt early release', 'Dr. R. Gallagher', 'quality'),
    ).toThrowError(/pending or failed/);

    // Cannot dispatch unreleased pallet
    expect(() =>
      dispatchPallets(
        db,
        {
          palletIds: ['PLT-261120-001'],
          customerName: 'Aldi UK',
          destination: 'Atherstone',
          vehicleTempC: 2.5,
        },
        'M. Patel',
        'warehouse',
      ),
    ).toThrowError(/Dispatch blocked/);

    // Complete pending checks
    recordQualityCheckResult(db, 'QC-004', '0 leaks', 'pass', 'Verified', 'S. Ahmed', 'quality');
    recordQualityCheckResult(db, 'QC-005', '<100 cfu/g', 'pass', 'Verified', 'S. Ahmed', 'quality');

    // Operator cannot authorise finished goods release
    expect(() =>
      releaseFinishedGoodsOrder(db, 'PO-2026-1041', 'released', 'Operator try', 'E. Kowalski', 'operator'),
    ).toThrowError(/not authorised/);

    // Quality releases order
    const rel = releaseFinishedGoodsOrder(
      db,
      'PO-2026-1041',
      'released',
      'All checks complete',
      'Dr. R. Gallagher',
      'quality',
    );
    expect(rel.palletsUpdated).toBeGreaterThanOrEqual(3);

    // Pack an additional pallet and dispatch
    const {pallet} = packCaseAndPallet(db, 'PO-2026-1041', 1200, 'FG-CHILL-R4', 'E. Kowalski', 'operator');
    releaseFinishedGoodsOrder(db, 'PO-2026-1041', 'released', 'Include R4 pallet', 'Dr. R. Gallagher', 'quality');

    const shipment = dispatchPallets(
      db,
      {
        palletIds: ['PLT-261120-001', pallet.id],
        customerName: 'Aldi UK',
        destination: 'Atherstone',
        vehicleTempC: 2.2,
      },
      'M. Patel',
      'warehouse',
    );
    expect(shipment.status).toBe('dispatched');

    // End-to-end forward trace from carrot lot LOT-CAR-01A reaches shipment
    const trace = traceEntity(db, 'LOT-CAR-01A', 'forward');
    expect(trace.shipments.some((s) => s['id'] === shipment.id)).toBe(true);
    expect(trace.reconciliation.totalIngredientInputKg).toBeGreaterThan(0);
  });

  it('handles duplicate and out-of-order telemetry events idempotently', () => {
    const first = ingestTelemetryObservation(db, {
      eventId: 'EVT-100',
      sourceProtocol: 'mqtt',
      topicOrNodeId: 'aureom/site1/line1/cook/temp',
      stationId: 'STN-COOK',
      sensorId: 'TT-CKT-104',
      seqNumber: 10,
      measuredValue: 78.2,
      unit: '°C',
      deviceTimestamp: '2026-11-20T08:10:00.000Z',
    });
    expect(first.accepted).toBe(true);

    const dup = ingestTelemetryObservation(db, {
      eventId: 'EVT-100',
      sourceProtocol: 'mqtt',
      topicOrNodeId: 'aureom/site1/line1/cook/temp',
      stationId: 'STN-COOK',
      sensorId: 'TT-CKT-104',
      seqNumber: 10,
      measuredValue: 78.2,
      unit: '°C',
      deviceTimestamp: '2026-11-20T08:10:00.000Z',
    });
    expect(dup.duplicate).toBe(true);
    expect(dup.accepted).toBe(false);

    const outOfOrder = ingestTelemetryObservation(db, {
      eventId: 'EVT-099',
      sourceProtocol: 'mqtt',
      topicOrNodeId: 'aureom/site1/line1/cook/temp',
      stationId: 'STN-COOK',
      sensorId: 'TT-CKT-104',
      seqNumber: 9,
      measuredValue: 72.0,
      unit: '°C',
      deviceTimestamp: '2026-11-20T08:09:00.000Z',
    });
    expect(outOfOrder.outOfOrder).toBe(true);
    expect(outOfOrder.accepted).toBe(false);

    const newLot = receiveInventoryLot(
      db,
      {
        materialCode: 'RM-CAR-01',
        materialName: 'Diced Carrots',
        materialKind: 'ingredient',
        supplierId: 'SUP-GREEN',
        supplierName: 'Greenvale Produce Ltd',
        supplierLotCode: 'GV-999',
        poNumber: 'PO-999',
        quantity: 200,
        unit: 'kg',
        locationCode: 'INTAKE-Q-01',
        expiryDate: '2026-11-28T00:00:00.000Z',
        temperatureC: 3.0,
      },
      'M. Patel',
      'warehouse',
    );
    expect(newLot.qualityStatus).toBe('quarantined');
  });
});
