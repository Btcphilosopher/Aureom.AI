import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {QualityCheck, QualityHold, UserRole} from '../../shared/domain';
import {withTransaction} from '../db/connection';
import {assertPermission, DomainError, recordAudit} from './rbac';

function mapCheckRow(r: Record<string, unknown>): QualityCheck {
  return {
    id: String(r['id']),
    orderId: r['order_id'] ? String(r['order_id']) : null,
    batchId: r['batch_id'] ? String(r['batch_id']) : null,
    lotId: r['lot_id'] ? String(r['lot_id']) : null,
    planName: String(r['plan_name']),
    checkType: r['check_type'] as QualityCheck['checkType'],
    samplingInstruction: String(r['sampling_instruction']),
    targetSpec: String(r['target_spec']),
    measuredValue: r['measured_value'] ? String(r['measured_value']) : null,
    unit: String(r['unit']),
    result: r['result'] as QualityCheck['result'],
    inspectorName: r['inspector_name'] ? String(r['inspector_name']) : null,
    sensorOrDeviceId: r['sensor_or_device_id'] ? String(r['sensor_or_device_id']) : null,
    notes: String(r['notes'] ?? ''),
    recordedAt: r['recorded_at'] ? String(r['recorded_at']) : null,
  };
}

function mapHoldRow(r: Record<string, unknown>): QualityHold {
  return {
    id: String(r['id']),
    batchId: r['batch_id'] ? String(r['batch_id']) : null,
    orderId: r['order_id'] ? String(r['order_id']) : null,
    lotId: r['lot_id'] ? String(r['lot_id']) : null,
    reasonCode: String(r['reason_code']),
    description: String(r['description']),
    severity: r['severity'] as QualityHold['severity'],
    status: r['status'] as QualityHold['status'],
    affectedUnits: Number(r['affected_units']),
    disposition: r['disposition'] as QualityHold['disposition'],
    correctiveAction: String(r['corrective_action'] ?? ''),
    openedBy: String(r['opened_by']),
    openedAt: String(r['opened_at']),
    closedBy: r['closed_by'] ? String(r['closed_by']) : null,
    closedAt: r['closed_at'] ? String(r['closed_at']) : null,
  };
}

export function listQualityChecks(db: DatabaseSync): QualityCheck[] {
  return db
    .prepare('SELECT * FROM quality_checks ORDER BY CASE WHEN result = \'pending\' THEN 0 ELSE 1 END, recorded_at DESC')
    .all()
    .map(mapCheckRow);
}

export function listQualityHolds(db: DatabaseSync): QualityHold[] {
  return db
    .prepare("SELECT * FROM quality_holds ORDER BY CASE WHEN status != 'closed' THEN 0 ELSE 1 END, opened_at DESC")
    .all()
    .map(mapHoldRow);
}

export function recordQualityCheckResult(
  db: DatabaseSync,
  checkId: string,
  measuredValue: string,
  result: 'pass' | 'fail',
  notes: string,
  actor: string,
  role: UserRole,
): QualityCheck {
  assertPermission(role, 'quality:inspect');
  if (!measuredValue.trim()) {
    throw new DomainError(
      'Measured value cannot be blank; missing results must remain pending.',
      400,
      'MISSING_MEASUREMENT',
    );
  }

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM quality_checks WHERE id = ?').get(checkId);
    if (!row) {
      throw new DomainError(`Quality check '${checkId}' not found.`, 404, 'CHECK_NOT_FOUND');
    }
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE quality_checks
      SET measured_value = ?, result = ?, inspector_name = ?, notes = ?, recorded_at = ?
      WHERE id = ?
    `).run(measuredValue, result, actor, notes, now, checkId);

    if (result === 'fail') {
      const check = mapCheckRow(row);
      db.prepare(`
        INSERT INTO quality_holds (
          id, batch_id, order_id, lot_id, reason_code, description, severity,
          status, affected_units, disposition, corrective_action, opened_by, opened_at
        ) VALUES (?, ?, ?, ?, 'INSPECTION_FAILURE', ?, 'critical', 'open', 0, 'pending', '', ?, ?)
      `).run(
        `HLD-${randomUUID().slice(0, 6).toUpperCase()}`,
        check.batchId,
        check.orderId,
        check.lotId,
        `Failed ${check.checkType}: measured '${measuredValue}' against spec '${check.targetSpec}'. ${notes}`,
        actor,
        now,
      );
    }

    recordAudit(
      db,
      actor,
      role,
      'QUALITY_CHECK_RECORDED',
      'quality_check',
      checkId,
      `Recorded result '${result}' (${measuredValue}).`,
    );

    return mapCheckRow(db.prepare('SELECT * FROM quality_checks WHERE id = ?').get(checkId)!);
  });
}

export function createQualityHold(
  db: DatabaseSync,
  input: {
    orderId: string | null;
    batchId: string | null;
    lotId: string | null;
    reasonCode: string;
    description: string;
    severity: 'warning' | 'critical';
    affectedUnits: number;
  },
  actor: string,
  role: UserRole,
): QualityHold {
  assertPermission(role, 'quality:hold');
  return withTransaction(db, () => {
    const id = `HLD-${randomUUID().slice(0, 6).toUpperCase()}`;
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO quality_holds (
        id, batch_id, order_id, lot_id, reason_code, description, severity,
        status, affected_units, disposition, corrective_action, opened_by, opened_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, 'pending', '', ?, ?)
    `).run(
      id,
      input.batchId,
      input.orderId,
      input.lotId,
      input.reasonCode,
      input.description,
      input.severity,
      input.affectedUnits,
      actor,
      now,
    );

    if (input.orderId) {
      db.prepare("UPDATE production_orders SET quality_release_status = 'hold' WHERE id = ?").run(
        input.orderId,
      );
    }

    recordAudit(
      db,
      actor,
      role,
      'QUALITY_HOLD_OPENED',
      'quality_hold',
      id,
      `Opened ${input.severity} hold (${input.reasonCode}): ${input.description}`,
    );

    return mapHoldRow(db.prepare('SELECT * FROM quality_holds WHERE id = ?').get(id)!);
  });
}

export function resolveQualityHold(
  db: DatabaseSync,
  holdId: string,
  disposition: 'release' | 'rework' | 'reject' | 'destroy',
  correctiveAction: string,
  actor: string,
  role: UserRole,
): QualityHold {
  assertPermission(role, 'quality:release');
  if (!correctiveAction.trim()) {
    throw new DomainError('Corrective action documentation is required to close a hold.', 400, 'CAPA_REQUIRED');
  }

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM quality_holds WHERE id = ?').get(holdId);
    if (!row) {
      throw new DomainError(`Hold '${holdId}' not found.`, 404, 'HOLD_NOT_FOUND');
    }
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE quality_holds
      SET status = 'closed', disposition = ?, corrective_action = ?, closed_by = ?, closed_at = ?
      WHERE id = ?
    `).run(disposition, correctiveAction, actor, now, holdId);

    recordAudit(
      db,
      actor,
      role,
      'QUALITY_HOLD_CLOSED',
      'quality_hold',
      holdId,
      `Closed hold with disposition '${disposition}'. CAPA: ${correctiveAction}`,
    );

    return mapHoldRow(db.prepare('SELECT * FROM quality_holds WHERE id = ?').get(holdId)!);
  });
}

export function releaseFinishedGoodsOrder(
  db: DatabaseSync,
  orderId: string,
  disposition: 'released' | 'rejected' | 'rework' | 'destroyed',
  notes: string,
  actor: string,
  role: UserRole,
): {orderId: string; qualityReleaseStatus: string; palletsUpdated: number} {
  assertPermission(role, 'quality:release');

  return withTransaction(db, () => {
    const order = db
      .prepare('SELECT * FROM production_orders WHERE id = ?')
      .get(orderId) as Record<string, unknown> | undefined;
    if (!order) {
      throw new DomainError(`Order '${orderId}' not found.`, 404, 'ORDER_NOT_FOUND');
    }

    if (disposition === 'released') {
      const pendingChecks = db
        .prepare("SELECT id, check_type FROM quality_checks WHERE order_id = ? AND result != 'pass'")
        .all(orderId) as {id: string; check_type: string}[];
      if (pendingChecks.length > 0) {
        throw new DomainError(
          `Cannot release ${orderId}: ${pendingChecks.length} quality check(s) remain pending or failed (${pendingChecks
            .map((c) => c.check_type)
            .join(', ')}).`,
          409,
          'PENDING_OR_FAILED_QC',
        );
      }

      const openHolds = db
        .prepare("SELECT id FROM quality_holds WHERE order_id = ? AND status != 'closed'")
        .all(orderId);
      if (openHolds.length > 0) {
        throw new DomainError(
          `Cannot release ${orderId}: ${openHolds.length} open quality hold(s) must be closed first.`,
          409,
          'OPEN_QUALITY_HOLDS',
        );
      }
    }

    db.prepare('UPDATE production_orders SET quality_release_status = ? WHERE id = ?').run(
      disposition,
      orderId,
    );
    db.prepare('UPDATE production_batches SET quality_status = ? WHERE order_id = ?').run(
      disposition,
      orderId,
    );
    db.prepare('UPDATE packaging_cases SET quality_status = ? WHERE order_id = ?').run(
      disposition,
      orderId,
    );
    const palletRes = db
      .prepare('UPDATE pallets SET quality_status = ? WHERE order_id = ?')
      .run(disposition, orderId);

    recordAudit(
      db,
      actor,
      role,
      'FINISHED_GOODS_DISPOSITION',
      'production_order',
      orderId,
      `QA disposition set to '${disposition}' across ${palletRes.changes} pallet(s). Notes: ${notes}`,
    );

    return {
      orderId,
      qualityReleaseStatus: disposition,
      palletsUpdated: palletRes.changes,
    };
  });
}
