import {DatabaseSync} from 'node:sqlite';
import {UserRole} from '../../shared/domain';
import {assertPermission, recordAudit} from './rbac';

export interface PlanningStrategyResult {
  strategyId: string;
  strategyName: string;
  description: string;
  seed: number;
  assumptions: string[];
  throughputUnitsPerHour: number;
  totalMakespanHours: number;
  changeoverMinutes: number;
  expectedWasteKg: number;
  latenessMinutes: number;
  energyKwhEstimate: number;
  uncertaintyRangePct: number;
  recommendedAction: string;
  materialConstraints: {materialCode: string; available: number; required: number; status: 'ok' | 'shortage'}[];
}

function seededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

export function runDiscreteEventPlanningComparison(
  db: DatabaseSync,
  options: {
    seed?: number;
    simulateBreakdownAndShortage?: boolean;
  },
): {
  seed: number;
  breakdownInjected: boolean;
  strategies: PlanningStrategyResult[];
  forecastVsActual: {
    forecastUnitsPerHour: number;
    measuredUnitsPerHour: number;
    deltaPct: number;
  };
} {
  const seed = options.seed ?? 20261120;
  const breakdownInjected = options.simulateBreakdownAndShortage ?? false;
  const rng = seededRandom(seed);

  const bowlLot = db
    .prepare("SELECT SUM(quantity_on_hand - quantity_reserved) AS avail FROM inventory_lots WHERE material_code = 'PK-TRAY-400B' AND quality_status = 'released'")
    .get() as {avail: number | null};
  const bowlsAvailable = Number(bowlLot?.avail ?? 1800);
  const bowlsRequired = 4500;
  const bowlShortage = bowlsAvailable < bowlsRequired;

  const orders = db.prepare('SELECT * FROM production_orders').all() as Record<string, unknown>[];
  const activeOrder = orders.find((o) => String(o['id']) === 'PO-2026-1041');
  const measuredRate = activeOrder ? Math.max(2100, Number(activeOrder['produced_units']) / 1.5) : 2400;

  const jitter = () => (rng() - 0.5) * 0.04;

  const baseline: PlanningStrategyResult = {
    strategyId: 'baseline_fifo',
    strategyName: 'Baseline FIFO Schedule',
    description:
      'Executes orders in planned release sequence (PO-2026-1041 followed by PO-2026-1042) with full 45-min allergen washdown changeover.',
    seed,
    assumptions: [
      'Nominal filler speed 46 trays/min (2,760 units/hr) on Line 1.',
      '45 min wet sanitisation changeover between Celery-control trays and Lentil bowls.',
      breakdownInjected
        ? 'Injected 38 min unplanned sealer breakdown + 2,700 bowl packaging shortage on PO-2026-1042.'
        : 'Zero unplanned breakdowns; standard shift break cadence.',
    ],
    throughputUnitsPerHour: Math.round(2520 * (1 + jitter()) * (breakdownInjected ? 0.84 : 1)),
    totalMakespanHours: Number((breakdownInjected ? 8.9 : 6.4).toFixed(2)),
    changeoverMinutes: 45,
    expectedWasteKg: Number((breakdownInjected ? 84.5 : 42.0).toFixed(1)),
    latenessMinutes: breakdownInjected || bowlShortage ? 165 : 0,
    energyKwhEstimate: Math.round(breakdownInjected ? 980 : 790),
    uncertaintyRangePct: 6.5,
    recommendedAction:
      breakdownInjected || bowlShortage
        ? 'Blocked by PK-TRAY-400B shortage (1,800 avail vs 4,500 req) — triggers late dispatch.'
        : 'Meets PO-2026-1041 deadline; tight buffer on Shift B.',
    materialConstraints: [
      {
        materialCode: 'PK-TRAY-400B',
        available: bowlsAvailable,
        required: bowlsRequired,
        status: bowlShortage ? 'shortage' : 'ok',
      },
    ],
  };

  const splitAndExpedite: PlanningStrategyResult = {
    strategyId: 'split_batch_replan',
    strategyName: 'Split-Lot Replan & Partial Release',
    description:
      'Caps PO-2026-1042 Phase A to 1,800 bowls (matching released PK-TRAY-400B stock), schedules preventive sealer jaw swap during changeover, and defers 2,700 bowls to next PO delivery.',
    seed,
    assumptions: [
      'Splits PO-2026-1042 into 1,800-unit Phase A + 2,700-unit Phase B awaiting Alba replenishment.',
      'Combines MWO-101 PTFE jaw swap inside existing 45-min changeover window (saves 38 min downtime).',
    ],
    throughputUnitsPerHour: Math.round(2680 * (1 + jitter())),
    totalMakespanHours: Number((breakdownInjected ? 5.9 : 5.4).toFixed(2)),
    changeoverMinutes: 45,
    expectedWasteKg: Number((breakdownInjected ? 46.2 : 34.5).toFixed(1)),
    latenessMinutes: 0,
    energyKwhEstimate: 745,
    uncertaintyRangePct: 4.8,
    recommendedAction:
      'Approve split of PO-2026-1042 to 1,800 units on Shift B and issue urgent PO for 3,000 Square Salad Bowls.',
    materialConstraints: [
      {
        materialCode: 'PK-TRAY-400B',
        available: bowlsAvailable,
        required: 1800,
        status: 'ok',
      },
    ],
  };

  return {
    seed,
    breakdownInjected,
    strategies: [baseline, splitAndExpedite],
    forecastVsActual: {
      forecastUnitsPerHour: 2680,
      measuredUnitsPerHour: Math.round(measuredRate),
      deltaPct: Number((((measuredRate - 2680) / 2680) * 100).toFixed(1)),
    },
  };
}

export function applyApprovedScheduleReplan(
  db: DatabaseSync,
  orderId: string,
  newTargetUnits: number,
  reason: string,
  actor: string,
  role: UserRole,
): void {
  assertPermission(role, 'planning:apply_schedule');
  db.prepare('UPDATE production_orders SET target_units = ?, notes = ? WHERE id = ?').run(
    newTargetUnits,
    `Replanned by ${actor}: ${reason}`,
    orderId,
  );
  recordAudit(
    db,
    actor,
    role,
    'SCHEDULE_REPLAN_APPROVED',
    'production_order',
    orderId,
    `Approved schedule adjustment for ${orderId} to ${newTargetUnits} units. Reason: ${reason}`,
  );
}
