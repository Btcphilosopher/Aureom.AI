import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {
  PackagingCase,
  PackagingSetup,
  Pallet,
  Shipment,
  UserRole,
} from '../../shared/domain';
import {withTransaction} from '../db/connection';
import {
  assertPermission,
  assertWriteAllowedInMode,
  DomainError,
  recordAudit,
} from './rbac';

function mapSetupRow(r: Record<string, unknown>): PackagingSetup {
  return {
    id: String(r['id']),
    lineId: String(r['line_id']),
    orderId: String(r['order_id']),
    formatName: String(r['format_name']),
    trayLotId: String(r['tray_lot_id']),
    filmLotId: String(r['film_lot_id']),
    loadedLabelTemplateId: String(r['loaded_label_template_id']),
    loadedLabelVersion: String(r['loaded_label_version']),
    loadedLabelLotId: String(r['loaded_label_lot_id']),
    expectedLabelTemplateId: String(r['expected_label_template_id']),
    expectedLabelVersion: String(r['expected_label_version']),
    mismatchDetected: Number(r['mismatch_detected']) === 1,
    lineClearanceSignedBy: r['line_clearance_signed_by']
      ? String(r['line_clearance_signed_by'])
      : null,
    lineClearanceAt: r['line_clearance_at'] ? String(r['line_clearance_at']) : null,
    fillerStatus: r['filler_status'] as PackagingSetup['fillerStatus'],
    sealerStatus: r['sealer_status'] as PackagingSetup['sealerStatus'],
    printerStatus: r['printer_status'] as PackagingSetup['printerStatus'],
    checkweigherStatus: r['checkweigher_status'] as PackagingSetup['checkweigherStatus'],
    sealIntegrityPassCount: Number(r['seal_integrity_pass_count']),
    sealIntegrityFailCount: Number(r['seal_integrity_fail_count']),
    labelsPrinted: Number(r['labels_printed']),
    labelsVoided: Number(r['labels_voided']),
    labelsRemainingReconciled: Number(r['labels_remaining_reconciled']),
    scrapUnits: Number(r['scrap_units']),
    barcodeFormat: String(r['barcode_format']),
    printerAdapterMode: String(r['printer_adapter_mode']),
    updatedAt: String(r['updated_at']),
  };
}

export function listPackagingSetups(db: DatabaseSync): PackagingSetup[] {
  return db.prepare('SELECT * FROM packaging_setups').all().map(mapSetupRow);
}

export function listCases(db: DatabaseSync): PackagingCase[] {
  return db
    .prepare('SELECT * FROM packaging_cases ORDER BY packed_at DESC LIMIT 100')
    .all()
    .map((r) => ({
      id: String(r['id']),
      caseUid: String(r['case_uid']),
      orderId: String(r['order_id']),
      batchId: String(r['batch_id']),
      palletId: r['pallet_id'] ? String(r['pallet_id']) : null,
      unitCount: Number(r['unit_count']),
      packagingLotId: String(r['packaging_lot_id']),
      labelVersionUsed: String(r['label_version_used']),
      qualityStatus: r['quality_status'] as PackagingCase['qualityStatus'],
      packedAt: String(r['packed_at']),
    }));
}

export function listPallets(db: DatabaseSync): Pallet[] {
  return db
    .prepare('SELECT * FROM pallets ORDER BY built_at DESC')
    .all()
    .map((r) => ({
      id: String(r['id']),
      ssccCode: String(r['sscc_code']),
      orderId: String(r['order_id']),
      caseCount: Number(r['case_count']),
      totalUnits: Number(r['total_units']),
      locationCode: String(r['location_code']),
      qualityStatus: r['quality_status'] as Pallet['qualityStatus'],
      shipmentId: r['shipment_id'] ? String(r['shipment_id']) : null,
      builtAt: String(r['built_at']),
    }));
}

export function listShipments(db: DatabaseSync): Shipment[] {
  return db
    .prepare('SELECT * FROM shipments ORDER BY dispatched_at DESC')
    .all()
    .map((r) => ({
      id: String(r['id']),
      shipmentNumber: String(r['shipment_number']),
      customerName: String(r['customer_name']),
      destination: String(r['destination']),
      vehicleTempC: Number(r['vehicle_temp_c']),
      status: r['status'] as Shipment['status'],
      palletIds: JSON.parse(String(r['pallet_ids_json'])) as string[],
      totalUnits: Number(r['total_units']),
      dispatchedBy: r['dispatched_by'] ? String(r['dispatched_by']) : null,
      dispatchedAt: r['dispatched_at'] ? String(r['dispatched_at']) : null,
    }));
}

export function applyPackagingSetup(
  db: DatabaseSync,
  setupId: string,
  input: {
    loadedLabelTemplateId: string;
    loadedLabelVersion: string;
    loadedLabelLotId: string;
    trayLotId?: string;
    filmLotId?: string;
  },
  actor: string,
  role: UserRole,
): {setup: PackagingSetup; holdCreatedId: string | null} {
  assertPermission(role, 'packaging:setup');
  assertWriteAllowedInMode(db, true);

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM packaging_setups WHERE id = ?').get(setupId);
    if (!row) {
      throw new DomainError(`Packaging setup '${setupId}' not found.`, 404, 'SETUP_NOT_FOUND');
    }
    const current = mapSetupRow(row);
    const now = new Date().toISOString();

    const mismatch =
      input.loadedLabelTemplateId !== current.expectedLabelTemplateId ||
      input.loadedLabelVersion !== current.expectedLabelVersion;

    if (!mismatch && current.mismatchDetected) {
      // Clearing an existing mismatch requires supervisor or quality authorisation
      assertPermission(role, 'packaging:clear_mismatch');
    }

    const nextPrinterStatus = mismatch ? 'faulted' : 'running';
    const nextSealerStatus = mismatch ? 'blocked' : 'running';
    const nextFillerStatus = mismatch ? 'blocked' : 'running';

    db.prepare(`
      UPDATE packaging_setups
      SET loaded_label_template_id = ?,
          loaded_label_version = ?,
          loaded_label_lot_id = ?,
          tray_lot_id = COALESCE(?, tray_lot_id),
          film_lot_id = COALESCE(?, film_lot_id),
          mismatch_detected = ?,
          printer_status = ?,
          sealer_status = ?,
          filler_status = ?,
          line_clearance_signed_by = ?,
          line_clearance_at = ?,
          updated_at = ?
      WHERE id = ?
    `).run(
      input.loadedLabelTemplateId,
      input.loadedLabelVersion,
      input.loadedLabelLotId,
      input.trayLotId ?? null,
      input.filmLotId ?? null,
      mismatch ? 1 : 0,
      nextPrinterStatus,
      nextSealerStatus,
      nextFillerStatus,
      mismatch ? null : actor,
      mismatch ? null : now,
      now,
      setupId,
    );

    let holdCreatedId: string | null = null;
    if (mismatch) {
      holdCreatedId = `HLD-LBL-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(`
        INSERT INTO quality_holds (
          id, batch_id, order_id, lot_id, reason_code, description, severity,
          status, affected_units, disposition, corrective_action, opened_by, opened_at
        ) VALUES (?, (SELECT id FROM production_batches WHERE order_id = ? LIMIT 1), ?, ?, 'LABEL_MISMATCH', ?, 'critical', 'open', 120, 'pending', '', ?, ?)
      `).run(
        holdCreatedId,
        current.orderId,
        current.orderId,
        input.loadedLabelLotId,
        `Label mismatch on ${current.lineId}: loaded ${input.loadedLabelTemplateId} ${input.loadedLabelVersion} (roll ${input.loadedLabelLotId}), expected ${current.expectedLabelTemplateId} ${current.expectedLabelVersion}. Packaging automatically halted.`,
        actor,
        now,
      );

      db.prepare(`
        UPDATE stations
        SET state = 'faulted',
            fault_reason = ?
        WHERE id = 'STN-LBL'
      `).run(
        `Label mismatch: ${input.loadedLabelTemplateId} ${input.loadedLabelVersion} != ${current.expectedLabelTemplateId} ${current.expectedLabelVersion}`,
      );

      db.prepare(`
        UPDATE stations SET state = 'blocked' WHERE id IN ('STN-FILL', 'STN-SEAL')
      `).run();

      recordAudit(
        db,
        actor,
        role,
        'LABEL_MISMATCH_DETECTED_AND_HELD',
        'packaging_setup',
        setupId,
        `Detected label mismatch (${input.loadedLabelVersion} vs ${current.expectedLabelVersion}); opened critical hold ${holdCreatedId}.`,
      );
    } else {
      // Clear station fault and close mismatch holds if authorised
      db.prepare(`
        UPDATE stations
        SET state = 'running', fault_reason = NULL
        WHERE id IN ('STN-FILL', 'STN-SEAL', 'STN-LBL')
      `).run();

      db.prepare(`
        UPDATE quality_holds
        SET status = 'closed',
            disposition = 'rework',
            corrective_action = ?,
            closed_by = ?,
            closed_at = ?
        WHERE order_id = ? AND reason_code = 'LABEL_MISMATCH' AND status != 'closed'
      `).run(
        `Verified roll ${input.loadedLabelLotId} (${input.loadedLabelTemplateId} ${input.loadedLabelVersion}) and completed line clearance.`,
        actor,
        now,
        current.orderId,
      );

      recordAudit(
        db,
        actor,
        role,
        'PACKAGING_SETUP_VERIFIED_AND_CLEARED',
        'packaging_setup',
        setupId,
        `Verified ${input.loadedLabelTemplateId} ${input.loadedLabelVersion} and restored line clearance.`,
      );
    }

    return {
      setup: mapSetupRow(db.prepare('SELECT * FROM packaging_setups WHERE id = ?').get(setupId)!),
      holdCreatedId,
    };
  });
}

export function packCaseAndPallet(
  db: DatabaseSync,
  orderId: string,
  unitCount: number,
  palletLocation: string,
  actor: string,
  role: UserRole,
): {caseRecord: PackagingCase; pallet: Pallet} {
  assertPermission(role, 'order:execute');
  return withTransaction(db, () => {
    const setupRow = db
      .prepare('SELECT * FROM packaging_setups WHERE order_id = ?')
      .get(orderId);
    if (setupRow && Number(setupRow['mismatch_detected']) === 1) {
      throw new DomainError(
        'Cannot pack cases while label mismatch is active.',
        409,
        'LABEL_MISMATCH_BLOCK',
      );
    }

    const batch = db
      .prepare('SELECT id, quality_status FROM production_batches WHERE order_id = ? LIMIT 1')
      .get(orderId) as {id: string; quality_status: string} | undefined;
    if (!batch) {
      throw new DomainError(`No batch found for order '${orderId}'.`, 404, 'BATCH_NOT_FOUND');
    }

    const now = new Date().toISOString();
    const palletId = `PLT-${randomUUID().slice(0, 6).toUpperCase()}`;
    const sscc = `0035012345${Math.floor(10000000 + Math.random() * 89999999)}`;
    const caseId = `CASE-${randomUUID().slice(0, 6).toUpperCase()}`;
    const caseUid = `CS-${Date.now().toString().slice(-6)}`;
    const labelVer = setupRow ? String(setupRow['loaded_label_version']) : 'v2.1';

    db.prepare(`
      INSERT INTO pallets (
        id, sscc_code, order_id, case_count, total_units, location_code,
        quality_status, shipment_id, built_at
      ) VALUES (?, ?, ?, 1, ?, ?, 'pending', NULL, ?)
    `).run(palletId, sscc, orderId, unitCount, palletLocation, now);

    db.prepare(`
      INSERT INTO packaging_cases (
        id, case_uid, order_id, batch_id, pallet_id, unit_count,
        packaging_lot_id, label_version_used, quality_status, packed_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'LOT-CASE-12A', ?, 'pending', ?)
    `).run(caseId, caseUid, orderId, batch.id, palletId, unitCount, labelVer, now);

    db.prepare(`
      INSERT INTO batch_genealogy (
        id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
      ) VALUES (?, 'production_batch', ?, 'pallet', ?, ?, 'units', 'packed_into', ?)
    `).run(`GEN-${randomUUID().slice(0, 8).toUpperCase()}`, batch.id, palletId, unitCount, now);

    recordAudit(
      db,
      actor,
      role,
      'CASE_AND_PALLET_AGGREGATED',
      'pallet',
      palletId,
      `Aggregated ${unitCount} units (case ${caseUid}) onto pallet ${sscc} at ${palletLocation} (status: pending QA release).`,
    );

    const caseRow = db.prepare('SELECT * FROM packaging_cases WHERE id = ?').get(caseId)!;
    const palletRow = db.prepare('SELECT * FROM pallets WHERE id = ?').get(palletId)!;

    return {
      caseRecord: {
        id: String(caseRow['id']),
        caseUid: String(caseRow['case_uid']),
        orderId: String(caseRow['order_id']),
        batchId: String(caseRow['batch_id']),
        palletId: String(caseRow['pallet_id']),
        unitCount: Number(caseRow['unit_count']),
        packagingLotId: String(caseRow['packaging_lot_id']),
        labelVersionUsed: String(caseRow['label_version_used']),
        qualityStatus: caseRow['quality_status'] as PackagingCase['qualityStatus'],
        packedAt: String(caseRow['packed_at']),
      },
      pallet: {
        id: String(palletRow['id']),
        ssccCode: String(palletRow['sscc_code']),
        orderId: String(palletRow['order_id']),
        caseCount: Number(palletRow['case_count']),
        totalUnits: Number(palletRow['total_units']),
        locationCode: String(palletRow['location_code']),
        qualityStatus: palletRow['quality_status'] as Pallet['qualityStatus'],
        shipmentId: null,
        builtAt: String(palletRow['built_at']),
      },
    };
  });
}

export function dispatchPallets(
  db: DatabaseSync,
  input: {
    palletIds: string[];
    customerName: string;
    destination: string;
    vehicleTempC: number;
  },
  actor: string,
  role: UserRole,
): Shipment {
  assertPermission(role, 'dispatch:ship');
  if (!input.palletIds.length) {
    throw new DomainError('Select at least one pallet to dispatch.', 400, 'NO_PALLETS_SELECTED');
  }

  return withTransaction(db, () => {
    let totalUnits = 0;
    const now = new Date().toISOString();

    for (const pid of input.palletIds) {
      const pRow = db.prepare('SELECT * FROM pallets WHERE id = ?').get(pid);
      if (!pRow) {
        throw new DomainError(`Pallet '${pid}' not found.`, 404, 'PALLET_NOT_FOUND');
      }
      if (pRow['quality_status'] !== 'released') {
        throw new DomainError(
          `Dispatch blocked: Pallet ${String(pRow['sscc_code'])} has quality status '${String(pRow['quality_status'])}' (must be 'released' by QA).`,
          409,
          'DISPATCH_UNRELEASED_GOODS',
        );
      }
      if (pRow['shipment_id']) {
        throw new DomainError(
          `Pallet ${String(pRow['sscc_code'])} is already assigned to shipment ${String(pRow['shipment_id'])}.`,
          409,
          'PALLET_ALREADY_DISPATCHED',
        );
      }
      totalUnits += Number(pRow['total_units']);
    }

    const shipmentId = `SHP-${randomUUID().slice(0, 6).toUpperCase()}`;
    const shipmentNumber = `DN-2026-${Math.floor(4000 + Math.random() * 5999)}`;

    db.prepare(`
      INSERT INTO shipments (
        id, shipment_number, customer_name, destination, vehicle_temp_c,
        status, pallet_ids_json, total_units, dispatched_by, dispatched_at
      ) VALUES (?, ?, ?, ?, ?, 'dispatched', ?, ?, ?, ?)
    `).run(
      shipmentId,
      shipmentNumber,
      input.customerName,
      input.destination,
      input.vehicleTempC,
      JSON.stringify(input.palletIds),
      totalUnits,
      actor,
      now,
    );

    for (const pid of input.palletIds) {
      db.prepare('UPDATE pallets SET shipment_id = ? WHERE id = ?').run(shipmentId, pid);
      db.prepare(`
        INSERT INTO batch_genealogy (
          id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
        ) VALUES (?, 'pallet', ?, 'shipment', ?, (SELECT total_units FROM pallets WHERE id = ?), 'units', 'shipped_in', ?)
      `).run(`GEN-${randomUUID().slice(0, 8).toUpperCase()}`, pid, shipmentId, pid, now);
    }

    recordAudit(
      db,
      actor,
      role,
      'SHIPMENT_DISPATCHED',
      'shipment',
      shipmentId,
      `Dispatched ${shipmentNumber} (${totalUnits} units across ${input.palletIds.length} QA-released pallets) to ${input.customerName}.`,
    );

    return {
      id: shipmentId,
      shipmentNumber,
      customerName: input.customerName,
      destination: input.destination,
      vehicleTempC: input.vehicleTempC,
      status: 'dispatched',
      palletIds: input.palletIds,
      totalUnits,
      dispatchedBy: actor,
      dispatchedAt: now,
    };
  });
}
