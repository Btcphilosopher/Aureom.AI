import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {
  OrderStatus,
  ProcessingEvent,
  ProductionOrder,
  UserRole,
} from '../../shared/domain';
import {withTransaction} from '../db/connection';
import {
  assertPermission,
  assertWriteAllowedInMode,
  DomainError,
  recordAudit,
} from './rbac';

function mapOrderRow(r: Record<string, unknown>): ProductionOrder {
  return {
    id: String(r['id']),
    orderNumber: String(r['order_number']),
    recipeVersionId: String(r['recipe_version_id']),
    recipeCode: String(r['recipe_code']),
    productSku: String(r['product_sku']),
    productName: String(r['product_name']),
    lineId: String(r['line_id']),
    shiftName: String(r['shift_name']),
    targetUnits: Number(r['target_units']),
    producedUnits: Number(r['produced_units']),
    rejectedUnits: Number(r['rejected_units']),
    reworkUnits: Number(r['rework_units']),
    status: r['status'] as OrderStatus,
    qualityReleaseStatus: r['quality_release_status'] as ProductionOrder['qualityReleaseStatus'],
    scheduledStart: String(r['scheduled_start']),
    scheduledEnd: String(r['scheduled_end']),
    actualStart: r['actual_start'] ? String(r['actual_start']) : null,
    actualEnd: r['actual_end'] ? String(r['actual_end']) : null,
    dispatchDeadline: String(r['dispatch_deadline']),
    customerOrderRef: String(r['customer_order_ref']),
    assignedSupervisor: String(r['assigned_supervisor']),
    notes: String(r['notes'] ?? ''),
  };
}

function mapProcessingEvent(r: Record<string, unknown>): ProcessingEvent {
  return {
    id: String(r['id']),
    orderId: String(r['order_id']),
    batchId: String(r['batch_id']),
    stationId: String(r['station_id']),
    stationName: String(r['station_name']),
    operatorName: String(r['operator_name']),
    ingredientLotIds: JSON.parse(String(r['ingredient_lot_ids_json'])) as string[],
    setpointValue: r['setpoint_value'] === null ? null : Number(r['setpoint_value']),
    measuredValue: r['measured_value'] === null ? null : Number(r['measured_value']),
    unit: String(r['unit']),
    durationMinutes: Number(r['duration_minutes']),
    outputQuantity: Number(r['output_quantity']),
    outputUnit: String(r['output_unit']),
    sensorId: String(r['sensor_id']),
    calibrationStatus: r['calibration_status'] as ProcessingEvent['calibrationStatus'],
    deviationFlag: Number(r['deviation_flag']) === 1,
    dispositionNote: r['disposition_note'] ? String(r['disposition_note']) : null,
    recordedAt: String(r['recorded_at']),
  };
}

export function listProductionOrders(db: DatabaseSync): ProductionOrder[] {
  return db
    .prepare('SELECT * FROM production_orders ORDER BY scheduled_start ASC')
    .all()
    .map(mapOrderRow);
}

export function listProcessingEvents(db: DatabaseSync, orderId?: string): ProcessingEvent[] {
  if (orderId) {
    return db
      .prepare('SELECT * FROM processing_events WHERE order_id = ? ORDER BY recorded_at DESC')
      .all(orderId)
      .map(mapProcessingEvent);
  }
  return db
    .prepare('SELECT * FROM processing_events ORDER BY recorded_at DESC LIMIT 100')
    .all()
    .map(mapProcessingEvent);
}

export function createProductionOrder(
  db: DatabaseSync,
  input: {
    recipeVersionId: string;
    targetUnits: number;
    shiftName: string;
    scheduledStart: string;
    scheduledEnd: string;
    dispatchDeadline: string;
    customerOrderRef: string;
    notes?: string;
  },
  actor: string,
  role: UserRole,
): ProductionOrder {
  assertPermission(role, 'order:manage');
  return withTransaction(db, () => {
    const recipe = db
      .prepare('SELECT * FROM recipe_versions WHERE id = ?')
      .get(input.recipeVersionId) as Record<string, unknown> | undefined;

    if (!recipe) {
      throw new DomainError(`Recipe version '${input.recipeVersionId}' not found.`, 404, 'RECIPE_NOT_FOUND');
    }
    if (recipe['status'] !== 'approved') {
      throw new DomainError(
        `Production orders must reference an approved recipe version (got '${String(recipe['status'])}').`,
        409,
        'UNAPPROVED_RECIPE',
      );
    }

    const id = `PO-2026-${Math.floor(1050 + Math.random() * 8900)}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO production_orders (
        id, order_number, recipe_version_id, recipe_code, product_sku, product_name,
        line_id, shift_name, target_units, produced_units, rejected_units, rework_units,
        status, quality_release_status, scheduled_start, scheduled_end, actual_start,
        actual_end, dispatch_deadline, customer_order_ref, assigned_supervisor, notes
      ) VALUES (?, ?, ?, ?, ?, ?, 'LINE-01', ?, ?, 0, 0, 0, 'planned', 'pending', ?, ?, NULL, NULL, ?, ?, ?, ?)
    `).run(
      id,
      id,
      String(recipe['id']),
      String(recipe['recipe_code']),
      String(recipe['product_sku']),
      String(recipe['product_name']),
      input.shiftName,
      input.targetUnits,
      input.scheduledStart,
      input.scheduledEnd,
      input.dispatchDeadline,
      input.customerOrderRef,
      actor,
      input.notes ?? '',
    );

    const batchId = `BAT-${id.slice(-4)}-${randomUUID().slice(0, 4).toUpperCase()}`;
    db.prepare(`
      INSERT INTO production_batches (
        id, batch_code, order_id, recipe_version_id, parent_batch_id, is_rework,
        produced_units, waste_kg, quality_status, created_at
      ) VALUES (?, ?, ?, ?, NULL, 0, 0, 0, 'pending', ?)
    `).run(batchId, `B-${id}`, id, String(recipe['id']), now);

    recordAudit(
      db,
      actor,
      role,
      'PRODUCTION_ORDER_CREATED',
      'production_order',
      id,
      `Created order ${id} for ${input.targetUnits} units using immutable recipe ${String(recipe['recipe_code'])} ${String(recipe['version_number'])}.`,
    );

    return mapOrderRow(db.prepare('SELECT * FROM production_orders WHERE id = ?').get(id)!);
  });
}

export function transitionOrderStatus(
  db: DatabaseSync,
  orderId: string,
  nextStatus: OrderStatus,
  actor: string,
  role: UserRole,
): ProductionOrder {
  if (nextStatus === 'released' || nextStatus === 'cancelled' || nextStatus === 'reconciled') {
    assertPermission(role, 'order:manage');
  } else {
    assertPermission(role, 'order:execute');
  }
  if (nextStatus === 'in_progress') {
    assertWriteAllowedInMode(db, true);
  }

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM production_orders WHERE id = ?').get(orderId);
    if (!row) {
      throw new DomainError(`Order '${orderId}' not found.`, 404, 'ORDER_NOT_FOUND');
    }
    const order = mapOrderRow(row);
    const now = new Date().toISOString();

    if (nextStatus === 'in_progress') {
      const openCriticalHold = db
        .prepare(
          "SELECT id FROM quality_holds WHERE order_id = ? AND status != 'closed' AND severity = 'critical'",
        )
        .get(orderId);
      if (openCriticalHold) {
        throw new DomainError(
          `Cannot run order ${orderId} while a critical quality hold is open.`,
          409,
          'ORDER_BLOCKED_BY_HOLD',
        );
      }
    }

    const actualStart = order.actualStart ?? (nextStatus === 'in_progress' ? now : null);
    const actualEnd =
      nextStatus === 'completed' || nextStatus === 'cancelled' ? now : order.actualEnd;

    db.prepare(`
      UPDATE production_orders
      SET status = ?, actual_start = ?, actual_end = ?
      WHERE id = ?
    `).run(nextStatus, actualStart, actualEnd, orderId);

    // Ensure at least one batch exists
    const batch = db.prepare('SELECT id FROM production_batches WHERE order_id = ?').get(orderId);
    if (!batch) {
      db.prepare(`
        INSERT INTO production_batches (
          id, batch_code, order_id, recipe_version_id, parent_batch_id, is_rework,
          produced_units, waste_kg, quality_status, created_at
        ) VALUES (?, ?, ?, ?, NULL, 0, 0, 0, 'pending', ?)
      `).run(`BAT-${orderId}`, `B-${orderId}`, orderId, order.recipeVersionId, now);
    }

    if (nextStatus === 'paused' || nextStatus === 'completed') {
      db.prepare("UPDATE stations SET state = 'stopped' WHERE active_order_id = ?").run(orderId);
    } else if (nextStatus === 'in_progress') {
      db.prepare(
        "UPDATE stations SET state = 'running', active_order_id = ?, fault_reason = NULL WHERE line_id = ?",
      ).run(orderId, order.lineId);
    }

    recordAudit(
      db,
      actor,
      role,
      'PRODUCTION_ORDER_STATUS_CHANGED',
      'production_order',
      orderId,
      `Order ${orderId} transitioned from ${order.status} to ${nextStatus}.`,
    );

    return mapOrderRow(db.prepare('SELECT * FROM production_orders WHERE id = ?').get(orderId)!);
  });
}

export function recordProcessingEvent(
  db: DatabaseSync,
  input: {
    orderId: string;
    stationId: string;
    ingredientLotIds: string[];
    setpointValue: number | null;
    measuredValue: number | null;
    unit: string;
    durationMinutes: number;
    outputQuantity: number;
    outputUnit: string;
    dispositionNote?: string;
  },
  actor: string,
  role: UserRole,
): ProcessingEvent {
  assertPermission(role, 'order:execute');
  return withTransaction(db, () => {
    const station = db
      .prepare('SELECT * FROM stations WHERE id = ?')
      .get(input.stationId) as Record<string, unknown> | undefined;
    if (!station) {
      throw new DomainError(`Station '${input.stationId}' not found.`, 404, 'STATION_NOT_FOUND');
    }

    const batch = db
      .prepare('SELECT id FROM production_batches WHERE order_id = ? ORDER BY created_at ASC LIMIT 1')
      .get(input.orderId) as {id: string} | undefined;
    if (!batch) {
      throw new DomainError(`No batch found for order '${input.orderId}'.`, 404, 'BATCH_NOT_FOUND');
    }

    // Check deviation against station setpoint heuristically when both provided
    let deviationFlag = false;
    if (
      input.setpointValue !== null &&
      input.measuredValue !== null &&
      (input.stationId === 'STN-COOK' && input.measuredValue < input.setpointValue)
    ) {
      deviationFlag = true;
    }
    if (
      input.setpointValue !== null &&
      input.measuredValue !== null &&
      (input.stationId === 'STN-COOL' && input.measuredValue > input.setpointValue)
    ) {
      deviationFlag = true;
    }

    const now = new Date().toISOString();
    const id = `PE-${randomUUID().slice(0, 8).toUpperCase()}`;
    const calStatus = Number(station['calibration_valid']) === 1 ? 'valid' : 'overdue';

    db.prepare(`
      INSERT INTO processing_events (
        id, order_id, batch_id, station_id, station_name, operator_name,
        ingredient_lot_ids_json, setpoint_value, measured_value, unit,
        duration_minutes, output_quantity, output_unit, sensor_id,
        calibration_status, deviation_flag, disposition_note, recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      input.orderId,
      batch.id,
      input.stationId,
      String(station['name']),
      actor,
      JSON.stringify(input.ingredientLotIds),
      input.setpointValue,
      input.measuredValue,
      input.unit,
      input.durationMinutes,
      input.outputQuantity,
      input.outputUnit,
      String(station['sensor_id']),
      calStatus,
      deviationFlag ? 1 : 0,
      input.dispositionNote ?? null,
      now,
    );

    if (input.measuredValue !== null) {
      db.prepare(
        'UPDATE stations SET measured_value = ?, last_observation_at = ? WHERE id = ?',
      ).run(input.measuredValue, now, input.stationId);
    }

    if (deviationFlag) {
      db.prepare(`
        INSERT INTO quality_holds (
          id, batch_id, order_id, lot_id, reason_code, description, severity,
          status, affected_units, disposition, corrective_action, opened_by, opened_at
        ) VALUES (?, ?, ?, NULL, 'PROCESS_DEVIATION', ?, 'warning', 'open', 0, 'pending', '', ?, ?)
      `).run(
        `HLD-${randomUUID().slice(0, 6).toUpperCase()}`,
        batch.id,
        input.orderId,
        `${String(station['name'])} measured ${input.measuredValue} ${input.unit} vs target ${input.setpointValue} ${input.unit}.`,
        actor,
        now,
      );
    }

    recordAudit(
      db,
      actor,
      role,
      'PROCESSING_EVENT_RECORDED',
      'processing_event',
      id,
      `Recorded ${String(station['name'])} event for ${input.orderId}: measured=${input.measuredValue ?? 'n/a'} ${input.unit}.`,
    );

    return mapProcessingEvent(db.prepare('SELECT * FROM processing_events WHERE id = ?').get(id)!);
  });
}

export function recordProductionOutput(
  db: DatabaseSync,
  orderId: string,
  goodUnits: number,
  rejectedUnits: number,
  reworkUnits: number,
  actor: string,
  role: UserRole,
): ProductionOrder {
  assertPermission(role, 'order:execute');
  assertWriteAllowedInMode(db, true);

  return withTransaction(db, () => {
    const orderRow = db.prepare('SELECT * FROM production_orders WHERE id = ?').get(orderId);
    if (!orderRow) {
      throw new DomainError(`Order '${orderId}' not found.`, 404, 'ORDER_NOT_FOUND');
    }
    const order = mapOrderRow(orderRow);

    const pkgSetup = db
      .prepare('SELECT mismatch_detected FROM packaging_setups WHERE order_id = ?')
      .get(orderId) as {mismatch_detected: number} | undefined;
    if (pkgSetup && pkgSetup.mismatch_detected === 1) {
      throw new DomainError(
        `Packaging halted: active label mismatch detected on ${orderId}. Clear mismatch before producing units.`,
        409,
        'LABEL_MISMATCH_BLOCK',
      );
    }

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE production_orders
      SET produced_units = produced_units + ?,
          rejected_units = rejected_units + ?,
          rework_units = rework_units + ?
      WHERE id = ?
    `).run(goodUnits, rejectedUnits, reworkUnits, orderId);

    const batch = db
      .prepare('SELECT id FROM production_batches WHERE order_id = ? AND is_rework = 0 LIMIT 1')
      .get(orderId) as {id: string} | undefined;
    if (batch) {
      db.prepare(
        'UPDATE production_batches SET produced_units = produced_units + ? WHERE id = ?',
      ).run(goodUnits, batch.id);
    }

    if (reworkUnits > 0 && batch) {
      const reworkId = `BAT-RWK-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(`
        INSERT INTO production_batches (
          id, batch_code, order_id, recipe_version_id, parent_batch_id, is_rework,
          produced_units, waste_kg, quality_status, created_at
        ) VALUES (?, ?, ?, ?, ?, 1, ?, 0, 'hold', ?)
      `).run(
        reworkId,
        `RWK-${orderId.slice(-4)}-${reworkId.slice(-3)}`,
        orderId,
        order.recipeVersionId,
        batch.id,
        reworkUnits,
        now,
      );
      db.prepare(`
        INSERT INTO batch_genealogy (
          id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
        ) VALUES (?, 'production_batch', ?, 'production_batch', ?, ?, 'units', 'rework_split', ?)
      `).run(
        `GEN-${randomUUID().slice(0, 8).toUpperCase()}`,
        batch.id,
        reworkId,
        reworkUnits,
        now,
      );
    }

    recordAudit(
      db,
      actor,
      role,
      'PRODUCTION_OUTPUT_RECORDED',
      'production_order',
      orderId,
      `Recorded +${goodUnits} good, +${rejectedUnits} reject, +${reworkUnits} rework units.`,
    );

    return mapOrderRow(db.prepare('SELECT * FROM production_orders WHERE id = ?').get(orderId)!);
  });
}
