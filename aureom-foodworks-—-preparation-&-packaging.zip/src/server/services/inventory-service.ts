import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {
  InventoryLot,
  InventoryMovement,
  QualityStatus,
  UserRole,
} from '../../shared/domain';
import {withTransaction} from '../db/connection';
import {assertPermission, DomainError, recordAudit} from './rbac';

const DIMENSION_FACTORS: Record<string, {dim: 'mass' | 'volume' | 'count' | 'length'; factor: number}> = {
  kg: {dim: 'mass', factor: 1000},
  g: {dim: 'mass', factor: 1},
  mg: {dim: 'mass', factor: 0.001},
  L: {dim: 'volume', factor: 1000},
  mL: {dim: 'volume', factor: 1},
  units: {dim: 'count', factor: 1},
  trays: {dim: 'count', factor: 1},
  cases: {dim: 'count', factor: 12},
  m: {dim: 'length', factor: 1},
  mm: {dim: 'length', factor: 0.001},
};

export function convertUnit(quantity: number, fromUnit: string, toUnit: string): number {
  if (fromUnit === toUnit) return quantity;
  const from = DIMENSION_FACTORS[fromUnit];
  const to = DIMENSION_FACTORS[toUnit];
  if (!from || !to) {
    throw new DomainError(
      `Unsupported unit conversion: '${fromUnit}' to '${toUnit}'.`,
      400,
      'UNSUPPORTED_UNIT',
    );
  }
  if (from.dim !== to.dim) {
    throw new DomainError(
      `Dimensional mismatch: cannot convert '${fromUnit}' (${from.dim}) to '${toUnit}' (${to.dim}) without explicit density/pack specification.`,
      422,
      'DIMENSIONAL_MISMATCH',
    );
  }
  return (quantity * from.factor) / to.factor;
}

function mapLotRow(row: Record<string, unknown>): InventoryLot {
  return {
    id: String(row['id']),
    internalUid: String(row['internal_uid']),
    materialCode: String(row['material_code']),
    materialName: String(row['material_name']),
    materialKind: row['material_kind'] as InventoryLot['materialKind'],
    supplierId: String(row['supplier_id']),
    supplierName: String(row['supplier_name']),
    supplierLotCode: String(row['supplier_lot_code']),
    barcodeValue: String(row['barcode_value']),
    poNumber: String(row['po_number']),
    quantityOnHand: Number(row['quantity_on_hand']),
    quantityReserved: Number(row['quantity_reserved']),
    unit: String(row['unit']),
    locationCode: String(row['location_code']),
    receivedAt: String(row['received_at']),
    expiryDate: String(row['expiry_date']),
    temperatureC: row['temperature_c'] === null ? null : Number(row['temperature_c']),
    qualityStatus: row['quality_status'] as QualityStatus,
    notes: String(row['notes'] ?? ''),
  };
}

function mapMovementRow(row: Record<string, unknown>): InventoryMovement {
  return {
    id: String(row['id']),
    lotId: String(row['lot_id']),
    movementType: row['movement_type'] as InventoryMovement['movementType'],
    quantityDelta: Number(row['quantity_delta']),
    unit: String(row['unit']),
    orderId: row['order_id'] ? String(row['order_id']) : null,
    batchId: row['batch_id'] ? String(row['batch_id']) : null,
    referenceId: row['reference_id'] ? String(row['reference_id']) : null,
    linkedMovementId: row['linked_movement_id'] ? String(row['linked_movement_id']) : null,
    reason: String(row['reason']),
    performedBy: String(row['performed_by']),
    performedRole: row['performed_role'] as UserRole,
    createdAt: String(row['created_at']),
  };
}

export function listLots(db: DatabaseSync): InventoryLot[] {
  const rows = db
    .prepare('SELECT * FROM inventory_lots ORDER BY expiry_date ASC, received_at ASC')
    .all();
  return rows.map(mapLotRow);
}

export function listMovements(db: DatabaseSync, lotId?: string): InventoryMovement[] {
  if (lotId) {
    return db
      .prepare('SELECT * FROM inventory_movements WHERE lot_id = ? ORDER BY created_at DESC')
      .all(lotId)
      .map(mapMovementRow);
  }
  return db
    .prepare('SELECT * FROM inventory_movements ORDER BY created_at DESC LIMIT 150')
    .all()
    .map(mapMovementRow);
}

export interface ReceiveLotInput {
  materialCode: string;
  materialName: string;
  materialKind: 'ingredient' | 'packaging';
  supplierId: string;
  supplierName: string;
  supplierLotCode: string;
  barcodeValue?: string;
  poNumber: string;
  quantity: number;
  unit: string;
  locationCode: string;
  expiryDate: string;
  temperatureC: number | null;
  notes?: string;
}

export function receiveInventoryLot(
  db: DatabaseSync,
  input: ReceiveLotInput,
  actor: string,
  role: UserRole,
): InventoryLot {
  assertPermission(role, 'inventory:receive');
  if (input.quantity <= 0) {
    throw new DomainError('Receipt quantity must be greater than zero.', 400, 'INVALID_QUANTITY');
  }
  if (!DIMENSION_FACTORS[input.unit]) {
    throw new DomainError(`Unknown unit '${input.unit}'.`, 400, 'UNSUPPORTED_UNIT');
  }

  return withTransaction(db, () => {
    const now = new Date().toISOString();
    const id = `LOT-${randomUUID().slice(0, 8).toUpperCase()}`;
    const internalUid = `AUM-${input.materialKind === 'packaging' ? 'PK' : 'RM'}-${Date.now()
      .toString()
      .slice(-6)}`;
    const barcode = input.barcodeValue?.trim() || internalUid;

    db.prepare(`
      INSERT INTO inventory_lots (
        id, internal_uid, material_code, material_name, material_kind,
        supplier_id, supplier_name, supplier_lot_code, barcode_value, po_number,
        quantity_on_hand, quantity_reserved, unit, location_code, received_at,
        expiry_date, temperature_c, quality_status, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, 'quarantined', ?)
    `).run(
      id,
      internalUid,
      input.materialCode,
      input.materialName,
      input.materialKind,
      input.supplierId,
      input.supplierName,
      input.supplierLotCode,
      barcode,
      input.poNumber,
      input.quantity,
      input.unit,
      input.locationCode,
      now,
      input.expiryDate,
      input.temperatureC,
      input.notes ?? 'Received into intake quarantine pending QA inspection.',
    );

    db.prepare(`
      INSERT INTO inventory_movements (
        id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
        reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
      ) VALUES (?, ?, 'receipt', ?, ?, NULL, NULL, ?, NULL, ?, ?, ?, ?)
    `).run(
      `MOV-${randomUUID().slice(0, 8).toUpperCase()}`,
      id,
      input.quantity,
      input.unit,
      input.poNumber,
      `Goods receipt against ${input.poNumber} (Supplier Lot ${input.supplierLotCode})`,
      actor,
      role,
      now,
    );

    recordAudit(
      db,
      actor,
      role,
      'INVENTORY_LOT_RECEIVED',
      'inventory_lot',
      id,
      `Received ${input.quantity} ${input.unit} of ${input.materialName} (${internalUid}) into quarantine.`,
    );

    const created = db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(id);
    if (!created) throw new Error('Failed to retrieve created lot.');
    return mapLotRow(created);
  });
}

export function changeLotQualityStatus(
  db: DatabaseSync,
  lotId: string,
  newStatus: 'released' | 'quarantined' | 'rejected',
  reason: string,
  actor: string,
  role: UserRole,
): InventoryLot {
  assertPermission(role, 'inventory:release_lot');
  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lotId);
    if (!row) {
      throw new DomainError(`Inventory lot '${lotId}' not found.`, 404, 'LOT_NOT_FOUND');
    }
    const lot = mapLotRow(row);
    const now = new Date().toISOString();

    if (newStatus === 'released' && new Date(lot.expiryDate).getTime() < Date.now()) {
      throw new DomainError(
        `Cannot release expired lot ${lot.id} (expired ${lot.expiryDate}).`,
        409,
        'LOT_EXPIRED',
      );
    }

    db.prepare('UPDATE inventory_lots SET quality_status = ?, notes = ? WHERE id = ?').run(
      newStatus,
      reason || lot.notes,
      lotId,
    );

    db.prepare(`
      INSERT INTO inventory_movements (
        id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
        reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
      ) VALUES (?, ?, ?, 0, ?, NULL, NULL, ?, NULL, ?, ?, ?, ?)
    `).run(
      `MOV-${randomUUID().slice(0, 8).toUpperCase()}`,
      lotId,
      newStatus === 'released' ? 'release' : newStatus === 'quarantined' ? 'quarantine' : 'supplier_return',
      lot.unit,
      lot.poNumber,
      `Status changed from ${lot.qualityStatus} to ${newStatus}: ${reason}`,
      actor,
      role,
      now,
    );

    recordAudit(
      db,
      actor,
      role,
      'LOT_STATUS_CHANGED',
      'inventory_lot',
      lotId,
      `Lot ${lot.internalUid} marked '${newStatus}'. Reason: ${reason}`,
    );

    return mapLotRow(db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lotId)!);
  });
}

export function assertLotIssuable(lot: InventoryLot, nowMs = Date.now()): void {
  if (lot.qualityStatus !== 'released') {
    throw new DomainError(
      `Blocked: Lot ${lot.internalUid} (${lot.materialName}) is '${lot.qualityStatus}' and cannot be issued to production.`,
      409,
      'LOT_NOT_RELEASED',
    );
  }
  if (new Date(lot.expiryDate).getTime() <= nowMs) {
    throw new DomainError(
      `Blocked: Lot ${lot.internalUid} (${lot.materialName}) expired on ${lot.expiryDate}.`,
      409,
      'LOT_EXPIRED',
    );
  }
}

export function reserveFefoStock(
  db: DatabaseSync,
  materialCode: string,
  requiredQty: number,
  unit: string,
  orderId: string,
  actor: string,
  role: UserRole,
): {allocations: {lotId: string; internalUid: string; reservedQty: number; unit: string}[]} {
  assertPermission(role, 'inventory:reserve');
  if (requiredQty <= 0) {
    throw new DomainError('Reservation quantity must be positive.', 400, 'INVALID_QUANTITY');
  }

  return withTransaction(db, () => {
    const nowIso = new Date().toISOString();
    const candidates = db
      .prepare(`
        SELECT * FROM inventory_lots
        WHERE material_code = ?
          AND quality_status = 'released'
          AND expiry_date > ?
          AND (quantity_on_hand - quantity_reserved) > 0
        ORDER BY expiry_date ASC, received_at ASC
      `)
      .all(materialCode, nowIso)
      .map(mapLotRow);

    let remaining = requiredQty;
    const allocations: {lotId: string; internalUid: string; reservedQty: number; unit: string}[] = [];

    for (const lot of candidates) {
      if (remaining <= 0.0001) break;
      const availableInLotUnit = lot.quantityOnHand - lot.quantityReserved;
      const availableInReqUnit = convertUnit(availableInLotUnit, lot.unit, unit);
      if (availableInReqUnit <= 0) continue;

      const takeReqUnit = Math.min(remaining, availableInReqUnit);
      const takeLotUnit = convertUnit(takeReqUnit, unit, lot.unit);

      const updateRes = db
        .prepare(`
          UPDATE inventory_lots
          SET quantity_reserved = quantity_reserved + ?
          WHERE id = ? AND (quantity_on_hand - quantity_reserved) >= ?
        `)
        .run(takeLotUnit, lot.id, takeLotUnit - 1e-6);

      if (updateRes.changes === 0) {
        throw new DomainError(
          `Concurrent stock conflict while reserving ${lot.internalUid}.`,
          409,
          'STOCK_CONCURRENCY_CONFLICT',
        );
      }

      db.prepare(`
        INSERT INTO inventory_movements (
          id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
          reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
        ) VALUES (?, ?, 'reserve', 0, ?, ?, NULL, ?, NULL, ?, ?, ?, ?)
      `).run(
        `MOV-${randomUUID().slice(0, 8).toUpperCase()}`,
        lot.id,
        lot.unit,
        orderId,
        orderId,
        `FEFO reserved ${takeLotUnit.toFixed(2)} ${lot.unit} for ${orderId}`,
        actor,
        role,
        nowIso,
      );

      allocations.push({
        lotId: lot.id,
        internalUid: lot.internalUid,
        reservedQty: Number(takeLotUnit.toFixed(3)),
        unit: lot.unit,
      });
      remaining -= takeReqUnit;
    }

    if (remaining > 0.01) {
      throw new DomainError(
        `Insufficient released non-expired stock for '${materialCode}'. Short by ${remaining.toFixed(2)} ${unit}.`,
        409,
        'INSUFFICIENT_STOCK',
      );
    }

    recordAudit(
      db,
      actor,
      role,
      'FEFO_STOCK_RESERVED',
      'production_order',
      orderId,
      `Reserved ${requiredQty} ${unit} of ${materialCode} across ${allocations.length} FEFO lot(s).`,
    );

    return {allocations};
  });
}

export function issueOrConsumeLot(
  db: DatabaseSync,
  lotId: string,
  quantity: number,
  unit: string,
  movementType: 'issue' | 'consume' | 'waste' | 'return_to_stock',
  orderId: string | null,
  batchId: string | null,
  reason: string,
  actor: string,
  role: UserRole,
): InventoryLot {
  assertPermission(role, 'inventory:issue');
  if (quantity <= 0) {
    throw new DomainError('Quantity must be greater than zero.', 400, 'INVALID_QUANTITY');
  }

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lotId);
    if (!row) {
      throw new DomainError(`Lot '${lotId}' not found.`, 404, 'LOT_NOT_FOUND');
    }
    const lot = mapLotRow(row);
    const qtyInLotUnit = convertUnit(quantity, unit, lot.unit);
    const now = new Date().toISOString();

    if (movementType !== 'return_to_stock') {
      assertLotIssuable(lot);
      if (lot.quantityOnHand < qtyInLotUnit - 1e-6) {
        throw new DomainError(
          `Insufficient on-hand quantity in lot ${lot.internalUid} (available ${lot.quantityOnHand} ${lot.unit}, requested ${qtyInLotUnit} ${lot.unit}).`,
          409,
          'INSUFFICIENT_STOCK',
        );
      }
      const releaseFromReserved = Math.min(lot.quantityReserved, qtyInLotUnit);
      db.prepare(`
        UPDATE inventory_lots
        SET quantity_on_hand = quantity_on_hand - ?,
            quantity_reserved = MAX(0, quantity_reserved - ?)
        WHERE id = ? AND quantity_on_hand >= ?
      `).run(qtyInLotUnit, releaseFromReserved, lot.id, qtyInLotUnit - 1e-6);
    } else {
      db.prepare(
        'UPDATE inventory_lots SET quantity_on_hand = quantity_on_hand + ? WHERE id = ?',
      ).run(qtyInLotUnit, lot.id);
    }

    const delta = movementType === 'return_to_stock' ? qtyInLotUnit : -qtyInLotUnit;
    db.prepare(`
      INSERT INTO inventory_movements (
        id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
        reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
    `).run(
      `MOV-${randomUUID().slice(0, 8).toUpperCase()}`,
      lot.id,
      movementType,
      delta,
      lot.unit,
      orderId,
      batchId,
      orderId,
      reason,
      actor,
      role,
      now,
    );

    if (batchId && (movementType === 'consume' || movementType === 'issue')) {
      db.prepare(`
        INSERT INTO batch_genealogy (
          id, parent_type, parent_id, child_type, child_id, quantity, unit, relationship, created_at
        ) VALUES (?, 'inventory_lot', ?, 'production_batch', ?, ?, ?, 'consumed_in', ?)
      `).run(
        `GEN-${randomUUID().slice(0, 8).toUpperCase()}`,
        lot.id,
        batchId,
        qtyInLotUnit,
        lot.unit,
        now,
      );
    }

    recordAudit(
      db,
      actor,
      role,
      `INVENTORY_${movementType.toUpperCase()}`,
      'inventory_lot',
      lot.id,
      `${movementType} ${qtyInLotUnit} ${lot.unit} (${lot.internalUid}). ${reason}`,
    );

    return mapLotRow(db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lot.id)!);
  });
}

export function adjustLotLedger(
  db: DatabaseSync,
  lotId: string,
  deltaQuantity: number,
  unit: string,
  linkedMovementId: string | null,
  reason: string,
  actor: string,
  role: UserRole,
): InventoryLot {
  assertPermission(role, 'inventory:adjust');
  if (!reason.trim()) {
    throw new DomainError('An explicit adjustment reason is required.', 400, 'REASON_REQUIRED');
  }

  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lotId);
    if (!row) {
      throw new DomainError(`Lot '${lotId}' not found.`, 404, 'LOT_NOT_FOUND');
    }
    const lot = mapLotRow(row);
    const deltaInLotUnit = convertUnit(deltaQuantity, unit, lot.unit);
    const nextQty = lot.quantityOnHand + deltaInLotUnit;
    if (nextQty < lot.quantityReserved) {
      throw new DomainError(
        'Adjustment cannot reduce quantity on hand below reserved quantity.',
        409,
        'ADJUSTMENT_BELOW_RESERVED',
      );
    }

    const now = new Date().toISOString();
    db.prepare('UPDATE inventory_lots SET quantity_on_hand = ? WHERE id = ?').run(nextQty, lot.id);
    db.prepare(`
      INSERT INTO inventory_movements (
        id, lot_id, movement_type, quantity_delta, unit, order_id, batch_id,
        reference_id, linked_movement_id, reason, performed_by, performed_role, created_at
      ) VALUES (?, ?, 'adjustment', ?, ?, NULL, NULL, NULL, ?, ?, ?, ?, ?)
    `).run(
      `MOV-${randomUUID().slice(0, 8).toUpperCase()}`,
      lot.id,
      deltaInLotUnit,
      lot.unit,
      linkedMovementId,
      reason,
      actor,
      role,
      now,
    );

    recordAudit(
      db,
      actor,
      role,
      'INVENTORY_LEDGER_ADJUSTED',
      'inventory_lot',
      lot.id,
      `Adjusted ${lot.internalUid} by ${deltaInLotUnit} ${lot.unit}. Linked: ${linkedMovementId ?? 'none'}. Reason: ${reason}`,
    );

    return mapLotRow(db.prepare('SELECT * FROM inventory_lots WHERE id = ?').get(lot.id)!);
  });
}
