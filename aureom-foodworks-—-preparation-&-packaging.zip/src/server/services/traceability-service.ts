import {DatabaseSync} from 'node:sqlite';
import {DomainError} from './rbac';

export interface TraceEdge {
  id: string;
  parentType: string;
  parentId: string;
  childType: string;
  childId: string;
  quantity: number;
  unit: string;
  relationship: string;
  createdAt: string;
}

export interface TraceabilityResult {
  queryId: string;
  direction: 'forward' | 'backward' | 'full';
  lots: Record<string, unknown>[];
  batches: Record<string, unknown>[];
  pallets: Record<string, unknown>[];
  shipments: Record<string, unknown>[];
  edges: TraceEdge[];
  reconciliation: {
    totalIngredientInputKg: number;
    expectedYieldUnits: number;
    actualGoodUnits: number;
    rejectedUnits: number;
    reworkUnits: number;
    recordedWasteKg: number;
    estimatedOutputKg: number;
    unresolvedVarianceKg: number;
  };
}

export function traceEntity(
  db: DatabaseSync,
  queryId: string,
  direction: 'forward' | 'backward' | 'full' = 'full',
): TraceabilityResult {
  const allEdges = db
    .prepare('SELECT * FROM batch_genealogy ORDER BY created_at ASC')
    .all()
    .map((r) => ({
      id: String(r['id']),
      parentType: String(r['parent_type']),
      parentId: String(r['parent_id']),
      childType: String(r['child_type']),
      childId: String(r['child_id']),
      quantity: Number(r['quantity']),
      unit: String(r['unit']),
      relationship: String(r['relationship']),
      createdAt: String(r['created_at']),
    }));

  // Resolve input queryId (could be lot id, internal_uid, supplier_lot_code, batch_code, sscc, shipment_number)
  let resolvedId = queryId.trim();
  const lotMatch = db
    .prepare(
      'SELECT id FROM inventory_lots WHERE id = ? OR internal_uid = ? OR supplier_lot_code = ? OR barcode_value = ?',
    )
    .get(resolvedId, resolvedId, resolvedId, resolvedId) as {id: string} | undefined;
  if (lotMatch) resolvedId = lotMatch.id;

  const batchMatch = db
    .prepare('SELECT id FROM production_batches WHERE id = ? OR batch_code = ? OR order_id = ?')
    .get(resolvedId, resolvedId, resolvedId) as {id: string} | undefined;
  if (batchMatch && !lotMatch) resolvedId = batchMatch.id;

  const palletMatch = db
    .prepare('SELECT id FROM pallets WHERE id = ? OR sscc_code = ?')
    .get(resolvedId, resolvedId) as {id: string} | undefined;
  if (palletMatch) resolvedId = palletMatch.id;

  const shipMatch = db
    .prepare('SELECT id FROM shipments WHERE id = ? OR shipment_number = ?')
    .get(resolvedId, resolvedId) as {id: string} | undefined;
  if (shipMatch) resolvedId = shipMatch.id;

  const visitedNodes = new Set<string>([resolvedId]);
  const collectedEdges = new Map<string, TraceEdge>();

  if (direction === 'forward' || direction === 'full') {
    const queue = [resolvedId];
    const seen = new Set<string>([resolvedId]);
    while (queue.length > 0) {
      const cur = queue.shift()!;
      for (const e of allEdges) {
        if (e.parentId === cur) {
          collectedEdges.set(e.id, e);
          visitedNodes.add(e.childId);
          if (!seen.has(e.childId)) {
            seen.add(e.childId);
            queue.push(e.childId);
          }
        }
      }
    }
  }

  if (direction === 'backward' || direction === 'full') {
    const queue = [resolvedId];
    const seen = new Set<string>([resolvedId]);
    while (queue.length > 0) {
      const cur = queue.shift()!;
      for (const e of allEdges) {
        if (e.childId === cur) {
          collectedEdges.set(e.id, e);
          visitedNodes.add(e.parentId);
          if (!seen.has(e.parentId)) {
            seen.add(e.parentId);
            queue.push(e.parentId);
          }
        }
      }
    }
  }

  if (visitedNodes.size === 1 && !lotMatch && !batchMatch && !palletMatch && !shipMatch) {
    throw new DomainError(
      `No lot, batch, pallet, or shipment matched identifier '${queryId}'.`,
      404,
      'TRACE_TARGET_NOT_FOUND',
    );
  }

  const nodeList = Array.from(visitedNodes);
  const placeholders = nodeList.map(() => '?').join(',');

  const lots = db
    .prepare(`SELECT * FROM inventory_lots WHERE id IN (${placeholders})`)
    .all(...nodeList);
  const batches = db
    .prepare(`SELECT * FROM production_batches WHERE id IN (${placeholders})`)
    .all(...nodeList);
  const pallets = db
    .prepare(`SELECT * FROM pallets WHERE id IN (${placeholders})`)
    .all(...nodeList);
  const shipments = db
    .prepare(`SELECT * FROM shipments WHERE id IN (${placeholders})`)
    .all(...nodeList);

  const edges = Array.from(collectedEdges.values());

  // Quantity reconciliation across traced batches
  let totalIngredientInputKg = 0;
  for (const e of edges) {
    if (e.parentType === 'inventory_lot' && e.unit === 'kg') {
      totalIngredientInputKg += e.quantity;
    }
  }

  let actualGoodUnits = 0;
  let rejectedUnits = 0;
  let reworkUnits = 0;
  let expectedYieldUnits = 0;
  let recordedWasteKg = 0;
  let unitWeightKg = 0.38;

  for (const b of batches) {
    const order = db
      .prepare('SELECT * FROM production_orders WHERE id = ?')
      .get(String(b['order_id'])) as Record<string, unknown> | undefined;
    if (order) {
      actualGoodUnits += Number(order['produced_units']);
      rejectedUnits += Number(order['rejected_units']);
      reworkUnits += Number(order['rework_units']);
      expectedYieldUnits += Number(order['target_units']);
      const rcp = db
        .prepare('SELECT unit_weight_grams FROM recipe_versions WHERE id = ?')
        .get(String(order['recipe_version_id'])) as {unit_weight_grams: number} | undefined;
      if (rcp) unitWeightKg = rcp.unit_weight_grams / 1000;
    }
    recordedWasteKg += Number(b['waste_kg']);
  }

  const estimatedOutputKg = (actualGoodUnits + rejectedUnits + reworkUnits) * unitWeightKg;
  const unresolvedVarianceKg = Number(
    (totalIngredientInputKg - estimatedOutputKg - recordedWasteKg).toFixed(2),
  );

  return {
    queryId: resolvedId,
    direction,
    lots,
    batches,
    pallets,
    shipments,
    edges,
    reconciliation: {
      totalIngredientInputKg: Number(totalIngredientInputKg.toFixed(2)),
      expectedYieldUnits,
      actualGoodUnits,
      rejectedUnits,
      reworkUnits,
      recordedWasteKg: Number(recordedWasteKg.toFixed(2)),
      estimatedOutputKg: Number(estimatedOutputKg.toFixed(2)),
      unresolvedVarianceKg,
    },
  };
}

export function buildTraceabilityCsv(trace: TraceabilityResult): string {
  const lines = [
    'record_type,id,secondary_ref,quantity,unit,status_or_relationship,timestamp',
  ];
  for (const e of trace.edges) {
    lines.push(
      `genealogy_edge,${e.parentId}->${e.childId},${e.parentType}->${e.childType},${e.quantity},${e.unit},${e.relationship},${e.createdAt}`,
    );
  }
  for (const p of trace.pallets) {
    lines.push(
      `pallet,${String(p['id'])},${String(p['sscc_code'])},${Number(p['total_units'])},units,${String(p['quality_status'])},${String(p['built_at'])}`,
    );
  }
  for (const s of trace.shipments) {
    lines.push(
      `shipment,${String(s['id'])},${String(s['shipment_number'])},${Number(s['total_units'])},units,${String(s['status'])},${String(s['dispatched_at'] ?? '')}`,
    );
  }
  lines.push(
    `reconciliation,variance,,${trace.reconciliation.unresolvedVarianceKg},kg,input=${trace.reconciliation.totalIngredientInputKg}kg_output=${trace.reconciliation.estimatedOutputKg}kg,`,
  );
  return lines.join('\n');
}
