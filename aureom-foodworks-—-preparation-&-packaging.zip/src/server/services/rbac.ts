import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {OperatingMode, UserRole} from '../../shared/domain';

export type PermissionAction =
  | 'inventory:receive'
  | 'inventory:reserve'
  | 'inventory:issue'
  | 'inventory:adjust'
  | 'inventory:release_lot'
  | 'recipe:create_draft'
  | 'recipe:approve'
  | 'order:manage'
  | 'order:execute'
  | 'packaging:setup'
  | 'packaging:clear_mismatch'
  | 'quality:inspect'
  | 'quality:release'
  | 'quality:hold'
  | 'dispatch:ship'
  | 'planning:apply_schedule'
  | 'maintenance:manage'
  | 'admin:mode_change'
  | 'admin:backup_restore';

const ROLE_PERMISSIONS: Record<UserRole, PermissionAction[]> = {
  operator: ['order:execute', 'packaging:setup', 'quality:inspect'],
  supervisor: [
    'inventory:reserve',
    'inventory:issue',
    'recipe:create_draft',
    'order:manage',
    'order:execute',
    'packaging:setup',
    'packaging:clear_mismatch',
    'quality:inspect',
    'quality:hold',
    'planning:apply_schedule',
    'maintenance:manage',
  ],
  quality: [
    'inventory:release_lot',
    'recipe:create_draft',
    'recipe:approve',
    'packaging:setup',
    'packaging:clear_mismatch',
    'quality:inspect',
    'quality:release',
    'quality:hold',
  ],
  maintenance: ['maintenance:manage', 'packaging:setup'],
  planner: ['order:manage', 'inventory:reserve', 'planning:apply_schedule'],
  warehouse: [
    'inventory:receive',
    'inventory:reserve',
    'inventory:issue',
    'dispatch:ship',
  ],
  admin: [
    'inventory:receive',
    'inventory:reserve',
    'inventory:issue',
    'inventory:adjust',
    'inventory:release_lot',
    'recipe:create_draft',
    'recipe:approve',
    'order:manage',
    'order:execute',
    'packaging:setup',
    'packaging:clear_mismatch',
    'quality:inspect',
    'quality:release',
    'quality:hold',
    'dispatch:ship',
    'planning:apply_schedule',
    'maintenance:manage',
    'admin:mode_change',
    'admin:backup_restore',
  ],
};

export class DomainError extends Error {
  readonly statusCode: number;
  readonly code: string;

  constructor(message: string, statusCode = 400, code = 'DOMAIN_ERROR') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

export function assertPermission(role: UserRole, action: PermissionAction): void {
  const allowed = ROLE_PERMISSIONS[role];
  if (!allowed || !allowed.includes(action)) {
    throw new DomainError(
      `Role '${role}' is not authorised to perform '${action}'.`,
      403,
      'FORBIDDEN_ROLE_ACTION',
    );
  }
}

export function getOperatingMode(db: DatabaseSync): OperatingMode {
  const row = db
    .prepare("SELECT value FROM system_state WHERE key = 'operating_mode'")
    .get() as {value: string} | undefined;
  const mode = row?.value;
  if (mode === 'monitoring' || mode === 'supervised' || mode === 'simulation') {
    return mode;
  }
  return 'simulation';
}

export function assertWriteAllowedInMode(db: DatabaseSync, isEquipmentControl = false): void {
  const mode = getOperatingMode(db);
  if (mode === 'monitoring' && isEquipmentControl) {
    throw new DomainError(
      'Monitoring mode is read-only for equipment instructions. Switch to Simulation or Supervised Integration.',
      409,
      'READ_ONLY_MONITORING_MODE',
    );
  }
}

export function recordAudit(
  db: DatabaseSync,
  actor: string,
  role: UserRole,
  action: string,
  entityType: string,
  entityId: string,
  details: string,
): void {
  db.prepare(`
    INSERT INTO audit_events (id, actor, role, action, entity_type, entity_id, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    `AUD-${randomUUID().slice(0, 8).toUpperCase()}`,
    actor,
    role,
    action,
    entityType,
    entityId,
    details,
    new Date().toISOString(),
  );
}

export function runIdempotent<T>(
  db: DatabaseSync,
  idempotencyKey: string | undefined,
  endpoint: string,
  fn: () => {statusCode: number; body: T},
): {statusCode: number; body: T; replayed: boolean} {
  if (idempotencyKey) {
    const existing = db
      .prepare(
        'SELECT status_code, response_json FROM idempotency_keys WHERE key = ? AND endpoint = ?',
      )
      .get(idempotencyKey, endpoint) as
      | {status_code: number; response_json: string}
      | undefined;
    if (existing) {
      return {
        statusCode: existing.status_code,
        body: JSON.parse(existing.response_json) as T,
        replayed: true,
      };
    }
  }

  const result = fn();
  if (idempotencyKey) {
    db.prepare(
      'INSERT OR IGNORE INTO idempotency_keys (key, endpoint, status_code, response_json, created_at) VALUES (?, ?, ?, ?, ?)',
    ).run(
      idempotencyKey,
      endpoint,
      result.statusCode,
      JSON.stringify(result.body),
      new Date().toISOString(),
    );
  }
  return {...result, replayed: false};
}
