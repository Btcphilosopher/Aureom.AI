import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {
  LabelTemplate,
  ProcessLimit,
  RecipeIngredientItem,
  RecipePackagingItem,
  RecipeVersion,
  UserRole,
} from '../../shared/domain';
import {withTransaction} from '../db/connection';
import {assertPermission, DomainError, recordAudit} from './rbac';

function mapRecipeRow(row: Record<string, unknown>): RecipeVersion {
  return {
    id: String(row['id']),
    recipeCode: String(row['recipe_code']),
    productSku: String(row['product_sku']),
    productName: String(row['product_name']),
    category: row['category'] as RecipeVersion['category'],
    versionNumber: String(row['version_number']),
    status: row['status'] as RecipeVersion['status'],
    batchSizeKg: Number(row['batch_size_kg']),
    expectedYieldUnits: Number(row['expected_yield_units']),
    unitWeightGrams: Number(row['unit_weight_grams']),
    allergens: JSON.parse(String(row['allergens_json'])) as string[],
    crossContactNotes: String(row['cross_contact_notes']),
    approvedLabelTemplateId: String(row['approved_label_template_id']),
    approvedLabelVersion: String(row['approved_label_version']),
    effectiveFrom: String(row['effective_from']),
    approvedBy: row['approved_by'] ? String(row['approved_by']) : null,
    approvedAt: row['approved_at'] ? String(row['approved_at']) : null,
    revisionReason: String(row['revision_reason']),
    ingredients: JSON.parse(String(row['ingredients_json'])) as RecipeIngredientItem[],
    packagingBom: JSON.parse(String(row['packaging_bom_json'])) as RecipePackagingItem[],
    processLimits: JSON.parse(String(row['process_limits_json'])) as ProcessLimit[],
    prepSteps: JSON.parse(String(row['prep_steps_json'])) as string[],
  };
}

export function listRecipes(db: DatabaseSync): RecipeVersion[] {
  return db
    .prepare('SELECT * FROM recipe_versions ORDER BY recipe_code ASC, effective_from DESC')
    .all()
    .map(mapRecipeRow);
}

export function listLabelTemplates(db: DatabaseSync): LabelTemplate[] {
  return db
    .prepare('SELECT * FROM label_templates ORDER BY template_code ASC, version DESC')
    .all()
    .map((r) => ({
      id: String(r['id']),
      templateCode: String(r['template_code']),
      version: String(r['version']),
      productSku: String(r['product_sku']),
      productName: String(r['product_name']),
      ingredientsText: String(r['ingredients_text']),
      allergensDeclaration: String(r['allergens_declaration']),
      netQuantityText: String(r['net_quantity_text']),
      storageInstructions: String(r['storage_instructions']),
      dateMarkRule: String(r['date_mark_rule']),
      barcodeFormat: String(r['barcode_format']),
      status: r['status'] as LabelTemplate['status'],
    }));
}

export function createRecipeRevision(
  db: DatabaseSync,
  sourceRecipeId: string,
  newVersionNumber: string,
  revisionReason: string,
  updates: {
    batchSizeKg?: number;
    expectedYieldUnits?: number;
    crossContactNotes?: string;
    ingredients?: RecipeIngredientItem[];
  },
  actor: string,
  role: UserRole,
): RecipeVersion {
  assertPermission(role, 'recipe:create_draft');
  if (!revisionReason.trim()) {
    throw new DomainError('A revision reason is mandatory for recipe changes.', 400, 'REVISION_REASON_REQUIRED');
  }

  return withTransaction(db, () => {
    const srcRow = db
      .prepare('SELECT * FROM recipe_versions WHERE id = ?')
      .get(sourceRecipeId);
    if (!srcRow) {
      throw new DomainError(`Source recipe '${sourceRecipeId}' not found.`, 404, 'RECIPE_NOT_FOUND');
    }
    const src = mapRecipeRow(srcRow);

    const dup = db
      .prepare('SELECT id FROM recipe_versions WHERE recipe_code = ? AND version_number = ?')
      .get(src.recipeCode, newVersionNumber);
    if (dup) {
      throw new DomainError(
        `Version '${newVersionNumber}' already exists for recipe ${src.recipeCode}. Approved versions are immutable.`,
        409,
        'RECIPE_VERSION_EXISTS',
      );
    }

    const newId = `RCP-${src.recipeCode.replace(/[^A-Z0-9]/g, '')}-${newVersionNumber.replace(/\./g, '_')}-${randomUUID().slice(0, 4).toUpperCase()}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO recipe_versions (
        id, recipe_code, product_sku, product_name, category, version_number, status,
        batch_size_kg, expected_yield_units, unit_weight_grams, allergens_json,
        cross_contact_notes, approved_label_template_id, approved_label_version,
        effective_from, approved_by, approved_at, revision_reason,
        ingredients_json, packaging_bom_json, process_limits_json, prep_steps_json
      ) VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, ?, ?, ?)
    `).run(
      newId,
      src.recipeCode,
      src.productSku,
      src.productName,
      src.category,
      newVersionNumber,
      updates.batchSizeKg ?? src.batchSizeKg,
      updates.expectedYieldUnits ?? src.expectedYieldUnits,
      src.unitWeightGrams,
      JSON.stringify(src.allergens),
      updates.crossContactNotes ?? src.crossContactNotes,
      src.approvedLabelTemplateId,
      src.approvedLabelVersion,
      now,
      revisionReason,
      JSON.stringify(updates.ingredients ?? src.ingredients),
      JSON.stringify(src.packagingBom),
      JSON.stringify(src.processLimits),
      JSON.stringify(src.prepSteps),
    );

    recordAudit(
      db,
      actor,
      role,
      'RECIPE_REVISION_DRAFTED',
      'recipe_version',
      newId,
      `Created draft ${src.recipeCode} ${newVersionNumber} from ${src.versionNumber}. Reason: ${revisionReason}`,
    );

    return mapRecipeRow(db.prepare('SELECT * FROM recipe_versions WHERE id = ?').get(newId)!);
  });
}

export function approveRecipeRevision(
  db: DatabaseSync,
  recipeId: string,
  actor: string,
  role: UserRole,
): RecipeVersion {
  assertPermission(role, 'recipe:approve');
  return withTransaction(db, () => {
    const row = db.prepare('SELECT * FROM recipe_versions WHERE id = ?').get(recipeId);
    if (!row) {
      throw new DomainError(`Recipe version '${recipeId}' not found.`, 404, 'RECIPE_NOT_FOUND');
    }
    const recipe = mapRecipeRow(row);
    if (recipe.status === 'approved') {
      throw new DomainError(
        `Recipe ${recipe.recipeCode} ${recipe.versionNumber} is already approved and immutable.`,
        409,
        'RECIPE_IMMUTABLE',
      );
    }
    if (recipe.status !== 'draft') {
      throw new DomainError(
        `Only draft recipe versions can be approved (current: ${recipe.status}).`,
        409,
        'INVALID_RECIPE_STATUS',
      );
    }

    const now = new Date().toISOString();
    db.prepare(
      "UPDATE recipe_versions SET status = 'superseded' WHERE recipe_code = ? AND status = 'approved'",
    ).run(recipe.recipeCode);

    db.prepare(
      "UPDATE recipe_versions SET status = 'approved', approved_by = ?, approved_at = ?, effective_from = ? WHERE id = ?",
    ).run(actor, now, now, recipe.id);

    recordAudit(
      db,
      actor,
      role,
      'RECIPE_REVISION_APPROVED',
      'recipe_version',
      recipe.id,
      `Approved ${recipe.recipeCode} ${recipe.versionNumber}; prior approved versions superseded.`,
    );

    return mapRecipeRow(db.prepare('SELECT * FROM recipe_versions WHERE id = ?').get(recipe.id)!);
  });
}

export function assertRecipeImmutableUpdateBlocked(db: DatabaseSync, recipeId: string): void {
  const row = db.prepare('SELECT status FROM recipe_versions WHERE id = ?').get(recipeId) as
    | {status: string}
    | undefined;
  if (!row) {
    throw new DomainError(`Recipe '${recipeId}' not found.`, 404, 'RECIPE_NOT_FOUND');
  }
  if (row.status === 'approved' || row.status === 'superseded') {
    throw new DomainError(
      `Recipe '${recipeId}' is '${row.status}' and immutable. Create a new draft revision instead.`,
      409,
      'RECIPE_IMMUTABLE',
    );
  }
}
