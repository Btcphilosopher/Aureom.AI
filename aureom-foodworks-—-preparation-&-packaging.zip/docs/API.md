# AUREOM FOODWORKS — API Reference

All state-mutating endpoints accept:
- `X-Aureom-Role`: `operator | supervisor | quality | maintenance | planner | warehouse | admin`
- `X-Aureom-Actor`: Actor display identifier for audit trail attribution
- `Idempotency-Key`: Optional key preventing duplicate execution on network retries

## Endpoints
- `GET /api/health` — Server health and active operating mode
- `GET /api/snapshot` — Full factory snapshot (stations, orders, OEE, stale-data status, dispatch commitments)
- `GET /api/stream` — Server-Sent Events live snapshot stream
- `WS /api/live` — WebSocket live snapshot stream
- `POST /api/system/mode` — Switch operating mode (`simulation | monitoring | supervised`)
- `POST /api/system/outage` — Simulate or clear telemetry outage
- `POST /api/system/reset-demo` — Reset synthetic 10,000-tray seed dataset
- `POST /api/sim/step` — Advance discrete-event simulation by one tick
- `GET /api/recipes` — List versioned recipes and label templates
- `POST /api/recipes/:id/revisions` — Draft a new recipe version
- `POST /api/recipes/:id/approve` — QA approve a draft recipe version
- `GET /api/inventory` — List inventory lots and append-only ledger movements
- `POST /api/inventory/receive` — Receive PO delivery into quarantine
- `POST /api/inventory/lots/:id/status` — QA release, quarantine, or reject a lot
- `POST /api/inventory/reserve` — Transactional FEFO stock reservation
- `POST /api/inventory/issue` — Issue, consume, waste, or return stock (blocks unreleased/expired lots)
- `POST /api/inventory/adjust` — Linked ledger adjustment with reason
- `GET /api/production` — List production orders and processing events
- `POST /api/production/orders` — Create order bound to approved recipe version
- `POST /api/production/orders/:id/transition` — Transition order lifecycle state
- `POST /api/production/processing-events` — Log station setpoint vs measured value & CCP check
- `POST /api/production/orders/:id/output` — Record good, rejected, and rework units
- `GET /api/packaging` — Packaging setups, cases, pallets, shipments, printer adapter status
- `POST /api/packaging/setups/:id/apply` — Apply packaging/label setup (auto-halts & holds on mismatch)
- `POST /api/packaging/pack` — Pack cases & aggregate SSCC pallet
- `POST /api/warehouse/dispatch` — Dispatch QA-released pallets
- `GET /api/quality` — Inspection plans, checks, and quality holds
- `POST /api/quality/checks/:id/record` — Record inspection measurement (`pass | fail`)
- `POST /api/quality/holds/:id/close` — Close hold with CAPA and disposition
- `POST /api/quality/orders/:id/release` — Authorise finished goods release/disposition
- `GET /api/traceability?q=<id>&direction=full|forward|backward` — Genealogy graph & mass reconciliation
- `GET /api/traceability/export?q=<id>` — Download CSV traceability report
- `POST /api/planning/simulate` — Run seeded discrete-event strategy comparison
- `POST /api/planning/approve-replan` — Apply approved schedule replan
- `GET /api/maintenance` & `POST /api/maintenance/work-orders/:id/complete` — Maintenance & calibration
- `GET /api/energy` — Resource consumption & intensity per 1,000 trays
- `POST /api/telemetry/ingest` — Idempotent MQTT/OPC UA telemetry ingestion
- `GET /api/admin/audit` & `POST /api/admin/backup` — Audit log & SQLite snapshot backup
