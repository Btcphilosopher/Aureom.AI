package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.fluxpay.data.local.FluxPayDatabase
import com.example.fluxpay.data.model.*
import com.example.fluxpay.data.repository.FluxPayRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: FluxPayDatabase
    private lateinit var repository: FluxPayRepository
    private val orgId = "org_test"

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, FluxPayDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = FluxPayRepository(db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testAppNameIsFluxPay() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FluxPay", appName)
    }

    @Test
    fun testDoubleEntryLedgerBalancingInvariant() = runBlocking {
        repository.ensureSystemAccounts(orgId)
        val customerAccount = repository.getOrCreateCustomerPrepaidAccount(orgId, "cus_test_1")
        val nodeAccount = db.ledgerDao().getSystemAccount(orgId, AccountType.ASSET_LIGHTNING_NODE)!!

        // Balanced transaction: Debit Asset 10,000, Credit Prepaid Liability 10,000
        val txId = "tx_balanced_01"
        val tx = LedgerTransaction(
            transactionId = txId,
            orgId = orgId,
            referenceType = "DEPOSIT",
            referenceId = "dep_01",
            description = "Balanced deposit"
        )
        val entries = listOf(
            LedgerEntry(transactionId = txId, accountId = nodeAccount.accountId, entryType = EntryType.DEBIT, amountSats = 10000L),
            LedgerEntry(transactionId = txId, accountId = customerAccount.accountId, entryType = EntryType.CREDIT, amountSats = 10000L)
        )
        db.ledgerDao().postDoubleEntryTransaction(tx, entries)

        // Verify balance
        val balance = repository.getCustomerPrepaidBalance(orgId, "cus_test_1")
        assertEquals(10000L, balance)

        // Verify total debits == total credits across ledger
        val totalDebits = db.ledgerDao().getTotalDebits()
        val totalCredits = db.ledgerDao().getTotalCredits()
        assertEquals(totalDebits, totalCredits)
    }

    @Test(expected = IllegalArgumentException::class)
    fun testUnbalancedTransactionIsRejected() = runBlocking {
        repository.ensureSystemAccounts(orgId)
        val customerAccount = repository.getOrCreateCustomerPrepaidAccount(orgId, "cus_test_2")

        // Unbalanced: Debit 5,000, Credit 4,000 -> must throw
        val txId = "tx_unbalanced"
        val tx = LedgerTransaction(
            transactionId = txId,
            orgId = orgId,
            referenceType = "TEST",
            referenceId = "unb_01",
            description = "Unbalanced attempt"
        )
        val entries = listOf(
            LedgerEntry(transactionId = txId, accountId = customerAccount.accountId, entryType = EntryType.DEBIT, amountSats = 5000L),
            LedgerEntry(transactionId = txId, accountId = customerAccount.accountId, entryType = EntryType.CREDIT, amountSats = 4000L)
        )
        db.ledgerDao().postDoubleEntryTransaction(tx, entries)
    }

    @Test
    fun testIdempotentUsageIngestionDoesNotDoubleCharge() = runBlocking {
        repository.getOrCreateOrganization(orgId, "Test Org")
        val customer = Customer(
            customerId = "cus_agent_01",
            orgId = orgId,
            externalId = "agent_01",
            displayName = "Agent 01",
            email = "agent@test.io"
        )
        db.customerDao().insertCustomer(customer)

        val product = Product(
            productId = "prod_tokens",
            orgId = orgId,
            name = "Tokens",
            description = "Inference tokens",
            usageUnit = "tokens",
            pricingModel = PricingModel.PER_UNIT,
            rateSatsPerUnit = 2.0,
            unitMultiplier = 1000L
        )
        db.productDao().insertProduct(product)

        // Top up customer with 10,000 sats
        val inv = repository.createLightningInvoice(orgId, customer.customerId, 10000L, "Seed funding").getOrThrow()
        repository.settleLightningPayment(inv.paymentHash).getOrThrow()

        val balanceBefore = repository.getCustomerPrepaidBalance(orgId, customer.customerId)
        assertEquals(10000L, balanceBefore)

        val idempotencyKey = "req_unique_12345"

        // 1st ingestion: 1000 tokens @ 2 sats per 1000 = 2 sats
        val result1 = repository.ingestUsageEvent(orgId, customer.customerId, product.productId, 1000L, idempotencyKey).getOrThrow()
        assertFalse(result1.isDuplicate)
        assertEquals(2L, result1.chargeSats)
        assertEquals(9998L, result1.remainingBalanceSats)

        // 2nd ingestion with exact same idempotency key
        val result2 = repository.ingestUsageEvent(orgId, customer.customerId, product.productId, 1000L, idempotencyKey).getOrThrow()
        assertTrue(result2.isDuplicate)
        assertEquals(2L, result2.chargeSats)
        // Balance remains 9998L, not deducted again!
        val balanceAfter = repository.getCustomerPrepaidBalance(orgId, customer.customerId)
        assertEquals(9998L, balanceAfter)
    }

    @Test
    fun testInsufficientFundsRejected() = runBlocking {
        repository.getOrCreateOrganization(orgId, "Test Org")
        val customer = Customer(
            customerId = "cus_broke_01",
            orgId = orgId,
            externalId = "broke_01",
            displayName = "Unfunded Customer",
            email = "broke@test.io"
        )
        db.customerDao().insertCustomer(customer)

        val product = Product(
            productId = "prod_api",
            orgId = orgId,
            name = "API",
            description = "API Request",
            usageUnit = "requests",
            pricingModel = PricingModel.PER_REQUEST,
            rateSatsPerUnit = 100.0
        )
        db.productDao().insertProduct(product)

        // Zero balance customer tries to make 100 sats request
        val result = repository.ingestUsageEvent(orgId, customer.customerId, product.productId, 1L, "req_broke_01")
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("Insufficient funds") == true)
    }
}
