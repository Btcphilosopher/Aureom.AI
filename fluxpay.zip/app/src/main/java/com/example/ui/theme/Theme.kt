package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FluxPayColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = ElectricBlueDark,
    onPrimaryContainer = Color.White,
    secondary = CyanAccent,
    onSecondary = Color.Black,
    secondaryContainer = FluxSurfaceVariant,
    onSecondaryContainer = CyanGlow,
    tertiary = LightningGold,
    onTertiary = Color.Black,
    background = FluxBackground,
    onBackground = TextPrimary,
    surface = FluxSurface,
    onSurface = TextPrimary,
    surfaceVariant = FluxSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = FluxBorder,
    outlineVariant = FluxBorderActive,
    error = ErrorRose,
    onError = Color.White,
    errorContainer = ErrorContainer,
    onErrorContainer = ErrorRose
)

@Composable
fun FluxPayTheme(
    content: @Composable () -> Unit
) {
    // FluxPay is an institutional fintech dark platform: always use the refined dark fintech scheme
    MaterialTheme(
        colorScheme = FluxPayColorScheme,
        typography = Typography,
        content = content
    )
}
