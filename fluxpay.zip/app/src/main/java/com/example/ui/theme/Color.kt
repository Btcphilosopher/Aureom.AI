package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FluxPay Dark Fintech Palette
val FluxBackground = Color(0xFF070B14)
val FluxSurface = Color(0xFF0D1527)
val FluxSurfaceVariant = Color(0xFF141E34)
val FluxSurfaceCard = Color(0xFF0F182C)
val FluxBorder = Color(0xFF1E293B)
val FluxBorderActive = Color(0xFF334155)

// Accents
val ElectricBlue = Color(0xFF3B82F6)
val ElectricBlueLight = Color(0xFF60A5FA)
val ElectricBlueDark = Color(0xFF1D4ED8)
val CyanAccent = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val LightningGold = Color(0xFFF7931A)
val LightningAmber = Color(0xFFF59E0B)

// Functional states
val SuccessEmerald = Color(0xFF10B981)
val SuccessContainer = Color(0xFF064E3B)
val ErrorRose = Color(0xFFF43F5E)
val ErrorContainer = Color(0xFF4C0519)
val WarningAmber = Color(0xFFF59E0B)

// Typography colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)
