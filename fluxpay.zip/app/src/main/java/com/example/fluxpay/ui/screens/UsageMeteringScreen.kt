package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageMeteringScreen(
    viewModel: FluxPayViewModel
) {
    val customers by viewModel.customers.collectAsState()
    val products by viewModel.products.collectAsState()
    val events by viewModel.usageEvents.collectAsState()
    val lastResult by viewModel.lastIngestionResult.collectAsState()

    var selectedCustomerId by remember { mutableStateOf("") }
    var selectedProductId by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("1500") }
    var idempotencyKey by remember { mutableStateOf("req_" + UUID.randomUUID().toString().take(8)) }

    var customerDropdownExpanded by remember { mutableStateOf(false) }
    var productDropdownExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(customers, products) {
        if (selectedCustomerId.isEmpty() && customers.isNotEmpty()) {
            selectedCustomerId = customers.first().customerId
        }
        if (selectedProductId.isEmpty() && products.isNotEmpty()) {
            selectedProductId = products.first().productId
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Header & Live Ingestion Console ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = ElectricBlue.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Usage Ingestion Engine",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Sub-millisecond idempotent metering pipeline",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = ElectricBlue
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customer Selector
                Text("Target Customer", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedCard(
                        onClick = { customerDropdownExpanded = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("select_customer_dropdown"),
                        colors = CardDefaults.outlinedCardColors(containerColor = FluxSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val activeCust = customers.find { it.customerId == selectedCustomerId }
                            Text(
                                text = activeCust?.displayName ?: "Select Customer",
                                color = TextPrimary,
                                fontSize = 13.sp
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                        }
                    }
                    DropdownMenu(
                        expanded = customerDropdownExpanded,
                        onDismissRequest = { customerDropdownExpanded = false },
                        modifier = Modifier.background(FluxSurfaceCard)
                    ) {
                        customers.forEach { cust ->
                            DropdownMenuItem(
                                text = { Text("${cust.displayName} (${cust.customerId})", color = TextPrimary) },
                                onClick = {
                                    selectedCustomerId = cust.customerId
                                    customerDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Product Selector
                Text("Billable Product", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedCard(
                        onClick = { productDropdownExpanded = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("select_product_dropdown"),
                        colors = CardDefaults.outlinedCardColors(containerColor = FluxSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val activeProd = products.find { it.productId == selectedProductId }
                            Text(
                                text = "${activeProd?.name ?: "Select Product"} (${activeProd?.usageUnit})",
                                color = TextPrimary,
                                fontSize = 13.sp
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                        }
                    }
                    DropdownMenu(
                        expanded = productDropdownExpanded,
                        onDismissRequest = { productDropdownExpanded = false },
                        modifier = Modifier.background(FluxSurfaceCard)
                    ) {
                        products.forEach { prod ->
                            DropdownMenuItem(
                                text = { Text("${prod.name} - ${prod.rateSatsPerUnit} sats/${prod.usageUnit}", color = TextPrimary) },
                                onClick = {
                                    selectedProductId = prod.productId
                                    productDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity and Idempotency Key
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity Units") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_usage_quantity"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = FluxBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = idempotencyKey,
                        onValueChange = { idempotencyKey = it },
                        label = { Text("Idempotency Key") },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("input_idempotency_key"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = FluxBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { idempotencyKey = "req_" + UUID.randomUUID().toString().take(8) }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Regenerate key", tint = TextSecondary)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val qty = quantityText.toLongOrNull() ?: 1L
                            viewModel.submitUsageEvent(selectedCustomerId, selectedProductId, qty, idempotencyKey)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_usage_button")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ingest Event", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            // Re-submit with same idempotency key to demonstrate idempotency guarantee
                            val qty = quantityText.toLongOrNull() ?: 1L
                            viewModel.submitUsageEvent(selectedCustomerId, selectedProductId, qty, idempotencyKey)
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyanAccent)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_idempotency_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simulate Dupe", color = CyanAccent, fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. Ingestion Feedback Banner ---
        if (lastResult != null) {
            item {
                val res = lastResult!!
                FintechCard(
                    backgroundColor = if (res.isDuplicate) CyanAccent.copy(alpha = 0.1f) else FluxSurfaceVariant,
                    borderColor = if (res.isDuplicate) CyanAccent else ElectricBlue
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (res.isDuplicate) "IDEMPOTENT EVENT SKIPPED" else "USAGE CHARGED",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (res.isDuplicate) CyanAccent else SuccessEmerald
                                )
                            )
                            Text(
                                text = res.message,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                            )
                            Text(
                                text = "Remaining Balance: ${String.format("%,d", res.remainingBalanceSats)} sats",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                        SatsAmountText(amountSats = res.chargeSats, fontSize = 16, isPositive = false)
                    }
                }
            }
        }

        // --- 3. Events History ---
        item {
            FintechSectionHeader(
                title = "Authoritative Ingested Events (${events.size})",
                subtitle = "Permanent auditable usage log"
            )
        }

        if (events.isEmpty()) {
            item {
                Text(
                    text = "No usage events recorded.",
                    color = TextSecondary,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            items(events) { event ->
                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = FluxBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = event.eventId,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = event.status)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${event.customerId} • ${event.quantity} ${event.unit}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary)
                            )
                            Text(
                                text = "Key: ${event.idempotencyKey}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = TextTertiary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            SatsAmountText(amountSats = event.calculatedChargeSats, fontSize = 14)
                            Text(
                                text = "v${event.priceVersionApplied}",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
