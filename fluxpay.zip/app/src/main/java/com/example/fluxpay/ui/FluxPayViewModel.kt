package com.example.fluxpay.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.fluxpay.data.lightning.BTCPayServerProvider
import com.example.fluxpay.data.lightning.MockLightningProvider
import com.example.fluxpay.data.model.*
import com.example.fluxpay.data.repository.FluxPayRepository
import com.example.fluxpay.data.repository.IngestionResult
import com.example.fluxpay.data.repository.ReconciliationReport
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class FluxPayViewModel(
    val repository: FluxPayRepository
) : ViewModel() {

    private val _currentOrgId = MutableStateFlow("org_acme_ai")
    val currentOrgId: StateFlow<String> = _currentOrgId.asStateFlow()

    private val _environment = MutableStateFlow("TEST") // "TEST" or "PRODUCTION"
    val environment: StateFlow<String> = _environment.asStateFlow()

    val organizations: StateFlow<List<Organization>> =
        repository.organizationDao.getAllOrganizations()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentOrg: StateFlow<Organization?> = _currentOrgId.flatMapLatest { id ->
        flow {
            emit(repository.organizationDao.getOrganization(id))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val customers: StateFlow<List<Customer>> = _currentOrgId.flatMapLatest { id ->
        repository.customerDao.getCustomers(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = _currentOrgId.flatMapLatest { id ->
        repository.productDao.getProducts(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val usageEvents: StateFlow<List<UsageEvent>> = _currentOrgId.flatMapLatest { id ->
        repository.usageEventDao.getUsageEvents(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalMeteredCharges: StateFlow<Long> = _currentOrgId.flatMapLatest { id ->
        repository.usageEventDao.getTotalMeteredCharges(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalSettledDeposits: StateFlow<Long> = _currentOrgId.flatMapLatest { id ->
        repository.lightningPaymentDao.getTotalSettledSats(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val ledgerTransactions: StateFlow<List<LedgerTransaction>> = _currentOrgId.flatMapLatest { id ->
        repository.ledgerDao.getTransactions(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerAccounts: StateFlow<List<LedgerAccount>> = _currentOrgId.flatMapLatest { id ->
        repository.ledgerDao.getAccounts(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices: StateFlow<List<Invoice>> = _currentOrgId.flatMapLatest { id ->
        repository.invoiceDao.getInvoices(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<LightningPayment>> = _currentOrgId.flatMapLatest { id ->
        repository.lightningPaymentDao.getPayments(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val apiKeys: StateFlow<List<ApiKey>> = _currentOrgId.flatMapLatest { id ->
        repository.apiKeyDao.getApiKeys(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val webhookEndpoints: StateFlow<List<WebhookEndpoint>> = _currentOrgId.flatMapLatest { id ->
        repository.webhookDao.getEndpoints(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentWebhookDeliveries: StateFlow<List<WebhookDelivery>> =
        repository.webhookDao.getRecentDeliveries()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Feedback UI state
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _lastIngestionResult = MutableStateFlow<IngestionResult?>(null)
    val lastIngestionResult: StateFlow<IngestionResult?> = _lastIngestionResult.asStateFlow()

    private val _reconciliationReport = MutableStateFlow<ReconciliationReport?>(null)
    val reconciliationReport: StateFlow<ReconciliationReport?> = _reconciliationReport.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialData()
        }
    }

    fun switchOrganization(orgId: String) {
        _currentOrgId.value = orgId
        viewModelScope.launch {
            repository.ensureSystemAccounts(orgId)
        }
    }

    fun toggleEnvironment() {
        val next = if (_environment.value == "TEST") "PRODUCTION" else "TEST"
        _environment.value = next
        _userMessage.value = "Switched to $next mode"
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // --- Actions ---

    fun submitUsageEvent(
        customerId: String,
        productId: String,
        quantity: Long,
        idempotencyKey: String
    ) {
        viewModelScope.launch {
            val key = idempotencyKey.ifBlank { "req_" + UUID.randomUUID().toString().take(10) }
            val result = repository.ingestUsageEvent(
                orgId = _currentOrgId.value,
                customerId = customerId,
                productId = productId,
                quantity = quantity,
                idempotencyKey = key
            )
            result.onSuccess { ingestion ->
                _lastIngestionResult.value = ingestion
                _userMessage.value = if (ingestion.isDuplicate) {
                    "Duplicate Event Ignored (Key: ${ingestion.event.idempotencyKey})"
                } else {
                    "Metered ${ingestion.chargeSats} sats for $customerId"
                }
            }.onFailure { err ->
                _userMessage.value = "Metering Error: ${err.message}"
            }
        }
    }

    fun createLightningTopUp(customerId: String, amountSats: Long, memo: String) {
        viewModelScope.launch {
            val result = repository.createLightningInvoice(
                orgId = _currentOrgId.value,
                customerId = customerId,
                amountSats = amountSats,
                memo = memo
            )
            result.onSuccess { payment ->
                _userMessage.value = "Created Lightning invoice for ${payment.amountSats} sats"
            }.onFailure { err ->
                _userMessage.value = "Error: ${err.message}"
            }
        }
    }

    fun settleLightningPayment(paymentHash: String) {
        viewModelScope.launch {
            val result = repository.settleLightningPayment(paymentHash)
            result.onSuccess { payment ->
                _userMessage.value = "Settled payment #${payment.paymentId.take(8)}: +${payment.amountSats} sats posted to ledger!"
            }.onFailure { err ->
                _userMessage.value = "Settlement failed: ${err.message}"
            }
        }
    }

    fun runReconciliation() {
        viewModelScope.launch {
            val report = repository.runReconciliation(_currentOrgId.value)
            _reconciliationReport.value = report
            _userMessage.value = if (report.isBalanced) {
                "Audit Passed: Ledger debits/credits in exact balance (0 discrepancy)"
            } else {
                "Audit Alert: Discrepancy of ${report.discrepancySats} sats detected!"
            }
        }
    }

    fun createProduct(
        name: String,
        description: String,
        usageUnit: String,
        pricingModel: PricingModel,
        rateSats: Double,
        unitMultiplier: Long
    ) {
        viewModelScope.launch {
            val product = Product(
                productId = "prod_" + name.lowercase().replace(" ", "_").take(16),
                orgId = _currentOrgId.value,
                name = name,
                description = description,
                usageUnit = usageUnit,
                pricingModel = pricingModel,
                rateSatsPerUnit = rateSats,
                unitMultiplier = unitMultiplier
            )
            repository.productDao.insertProduct(product)
            _userMessage.value = "Created product ${product.name}"
        }
    }

    fun createCustomer(
        displayName: String,
        email: String,
        externalId: String,
        maxPerRequest: Long,
        dailyLimit: Long
    ) {
        viewModelScope.launch {
            val customer = Customer(
                customerId = "cus_" + UUID.randomUUID().toString().take(8),
                orgId = _currentOrgId.value,
                externalId = externalId.ifBlank { "ext_" + UUID.randomUUID().toString().take(6) },
                displayName = displayName,
                email = email,
                maxSpendPerRequestSats = maxPerRequest,
                dailySpendLimitSats = dailyLimit
            )
            repository.customerDao.insertCustomer(customer)
            repository.getOrCreateCustomerPrepaidAccount(_currentOrgId.value, customer.customerId)
            _userMessage.value = "Added customer ${customer.displayName}"
        }
    }

    fun createApiKey(label: String, scopes: String) {
        viewModelScope.launch {
            val prefix = "fp_${_environment.value.lowercase()}_" + UUID.randomUUID().toString().take(6)
            val apiKey = ApiKey(
                keyId = "key_" + UUID.randomUUID().toString().take(8),
                orgId = _currentOrgId.value,
                keyPrefix = prefix,
                keyHash = "sha256:" + UUID.randomUUID().toString().replace("-", ""),
                label = label,
                scopes = scopes,
                environment = _environment.value
            )
            repository.apiKeyDao.insertApiKey(apiKey)
            _userMessage.value = "Generated API Key: $prefix... (Scopes: $scopes)"
        }
    }

    fun revokeApiKey(keyId: String) {
        viewModelScope.launch {
            repository.apiKeyDao.revokeApiKey(keyId)
            _userMessage.value = "Revoked API key"
        }
    }

    fun createInvoiceFromUsage(customerId: String, billingPeriod: String) {
        viewModelScope.launch {
            val items = listOf(
                InvoiceLineItem(
                    lineItemId = "li_" + UUID.randomUUID().toString().take(8),
                    invoiceId = "",
                    productId = "prod_gpt4_tokens",
                    description = "Metered AI Model Inference",
                    quantity = 5000L,
                    unit = "tokens",
                    unitRateSats = 2.0,
                    totalSats = 10L
                ),
                InvoiceLineItem(
                    lineItemId = "li_" + UUID.randomUUID().toString().take(8),
                    invoiceId = "",
                    productId = "prod_api_call",
                    description = "API Gateway Requests",
                    quantity = 40L,
                    unit = "requests",
                    unitRateSats = 5.0,
                    totalSats = 200L
                )
            )
            val inv = repository.createInvoice(_currentOrgId.value, customerId, billingPeriod, items)
            _userMessage.value = "Generated Invoice #${inv.invoiceId.take(8)} for ${inv.totalSats} sats"
        }
    }

    fun payInvoice(invoiceId: String) {
        viewModelScope.launch {
            val result = repository.payInvoiceFromPrepaid(invoiceId)
            result.onSuccess {
                _userMessage.value = "Invoice #${invoiceId.take(8)} paid from prepaid balance!"
            }.onFailure { err ->
                _userMessage.value = "Payment failed: ${err.message}"
            }
        }
    }

    fun setLightningProvider(providerType: String) {
        if (providerType == "BTCPAY") {
            repository.lightningProvider = BTCPayServerProvider()
            _userMessage.value = "Switched to BTCPay Server Provider"
        } else {
            repository.lightningProvider = MockLightningProvider()
            _userMessage.value = "Switched to Mock Lightning Provider"
        }
    }
}

class FluxPayViewModelFactory(
    private val repository: FluxPayRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return FluxPayViewModel(repository) as T
    }
}
