package com.example.fluxpay.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.fluxpay.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class FluxScreen(val route: String, val title: String, val icon: ImageVector) {
    OVERVIEW("overview", "Overview", Icons.Default.Dashboard),
    METERING("metering", "Metering", Icons.Default.Speed),
    LEDGER("ledger", "Ledger", Icons.Default.AccountBalance),
    BILLING("billing", "Billing", Icons.Default.ReceiptLong),
    PAYMENTS("payments", "Lightning", Icons.Default.Bolt),
    PRODUCTS("products", "Products", Icons.Default.Inventory2),
    CUSTOMERS("customers", "Customers", Icons.Default.Group),
    DEVELOPERS("developers", "API & SDK", Icons.Default.Code),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FluxPayApp(viewModel: FluxPayViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: FluxScreen.OVERVIEW.route

    val environment by viewModel.environment.collectAsState()
    val org by viewModel.currentOrg.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = FluxSurfaceCard,
                modifier = Modifier.width(300.dp)
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(FluxBackground)
                            .border(1.dp, FluxBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.fluxpay_icon_1792664376428),
                            contentDescription = "FluxPay Logo",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "FluxPay",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Programmable Billing",
                            style = MaterialTheme.typography.bodySmall.copy(color = CyanAccent)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = FluxBorder, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(8.dp))

                // Navigation Items inside Drawer
                FluxScreen.values().forEach { screen ->
                    val isSelected = (currentRoute == screen.route)
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = null,
                                tint = if (isSelected) CyanAccent else TextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TextPrimary else TextSecondary
                            )
                        },
                        selected = isSelected,
                        onClick = {
                            scope.launch { drawerState.close() }
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = ElectricBlueDark.copy(alpha = 0.35f),
                            unselectedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 2.dp)
                            .testTag("drawer_nav_${screen.route}")
                    )
                }

                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(FluxBackground)
                        .padding(12.dp)
                ) {
                    Column {
                        Text("Active Workspace", fontSize = 11.sp, color = TextTertiary)
                        Text(org?.name ?: "Acme AI Labs", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text("$environment Environment", fontSize = 11.sp, color = if (environment == "TEST") CyanAccent else SuccessEmerald)
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FluxPay",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (environment == "TEST") CyanAccent.copy(alpha = 0.15f) else SuccessEmerald.copy(alpha = 0.15f))
                                    .clickable { viewModel.toggleEnvironment() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = environment,
                                    color = if (environment == "TEST") CyanAccent else SuccessEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { navController.navigate(FluxScreen.SETTINGS.route) },
                            modifier = Modifier.testTag("nav_settings_action")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = FluxSurface,
                        titleContentColor = TextPrimary
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = FluxSurface,
                    contentColor = TextPrimary,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    // Primary 5 tabs in bottom bar
                    val primaryScreens = listOf(
                        FluxScreen.OVERVIEW,
                        FluxScreen.METERING,
                        FluxScreen.LEDGER,
                        FluxScreen.BILLING,
                        FluxScreen.PAYMENTS
                    )
                    primaryScreens.forEach { screen ->
                        val selected = (currentRoute == screen.route)
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title,
                                    tint = if (selected) CyanAccent else TextSecondary
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selected) CyanAccent else TextSecondary
                                )
                            },
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = ElectricBlueDark.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("bottom_nav_${screen.route}")
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = FluxBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = FluxScreen.OVERVIEW.route
                ) {
                    composable(FluxScreen.OVERVIEW.route) {
                        OverviewScreen(
                            viewModel = viewModel,
                            onNavigateToTab = { tabIndex ->
                                val target = when (tabIndex) {
                                    1 -> FluxScreen.METERING.route
                                    2 -> FluxScreen.LEDGER.route
                                    3 -> FluxScreen.BILLING.route
                                    4 -> FluxScreen.PAYMENTS.route
                                    else -> FluxScreen.OVERVIEW.route
                                }
                                navController.navigate(target)
                            }
                        )
                    }
                    composable(FluxScreen.METERING.route) {
                        UsageMeteringScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.LEDGER.route) {
                        LedgerScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.BILLING.route) {
                        BillingScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.PAYMENTS.route) {
                        LightningScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.PRODUCTS.route) {
                        ProductsScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.CUSTOMERS.route) {
                        CustomersScreen(
                            viewModel = viewModel,
                            onNavigateToLightning = { navController.navigate(FluxScreen.PAYMENTS.route) }
                        )
                    }
                    composable(FluxScreen.DEVELOPERS.route) {
                        DeveloperScreen(viewModel = viewModel)
                    }
                    composable(FluxScreen.SETTINGS.route) {
                        SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
