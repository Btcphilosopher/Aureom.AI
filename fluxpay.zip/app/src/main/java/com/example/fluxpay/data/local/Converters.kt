package com.example.fluxpay.data.local

import androidx.room.TypeConverter
import com.example.fluxpay.data.model.AccountType
import com.example.fluxpay.data.model.EntryType
import com.example.fluxpay.data.model.InvoiceStatus
import com.example.fluxpay.data.model.PaymentStatus
import com.example.fluxpay.data.model.PricingModel

class FluxPayConverters {
    @TypeConverter
    fun fromPricingModel(value: PricingModel?): String? = value?.name

    @TypeConverter
    fun toPricingModel(value: String?): PricingModel? = value?.let { PricingModel.valueOf(it) }

    @TypeConverter
    fun fromAccountType(value: AccountType?): String? = value?.name

    @TypeConverter
    fun toAccountType(value: String?): AccountType? = value?.let { AccountType.valueOf(it) }

    @TypeConverter
    fun fromEntryType(value: EntryType?): String? = value?.name

    @TypeConverter
    fun toEntryType(value: String?): EntryType? = value?.let { EntryType.valueOf(it) }

    @TypeConverter
    fun fromInvoiceStatus(value: InvoiceStatus?): String? = value?.name

    @TypeConverter
    fun toInvoiceStatus(value: String?): InvoiceStatus? = value?.let { InvoiceStatus.valueOf(it) }

    @TypeConverter
    fun fromPaymentStatus(value: PaymentStatus?): String? = value?.name

    @TypeConverter
    fun toPaymentStatus(value: String?): PaymentStatus? = value?.let { PaymentStatus.valueOf(it) }
}
