package com.example.fluxpay.data.lightning

import com.example.fluxpay.data.model.PaymentStatus
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class LightningInvoiceResult(
    val paymentId: String,
    val amountSats: Long,
    val paymentRequest: String,
    val paymentHash: String,
    val expiresAt: Long
)

interface LightningProvider {
    val providerName: String
    suspend fun createInvoice(amountSats: Long, memo: String, customerId: String): Result<LightningInvoiceResult>
    suspend fun checkStatus(paymentHash: String): PaymentStatus
    suspend fun settleInvoice(paymentHash: String): Result<String> // Returns preimage
}

class MockLightningProvider : LightningProvider {
    override val providerName: String = "MOCK_LIGHTNING_NODE"

    private val settledHashes = mutableMapOf<String, String>() // hash -> preimage

    override suspend fun createInvoice(
        amountSats: Long,
        memo: String,
        customerId: String
    ): Result<LightningInvoiceResult> {
        val paymentId = "ln_pay_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val rawSeed = "$paymentId:$amountSats:$customerId:${System.currentTimeMillis()}"
        val paymentHash = sha256(rawSeed)
        // Realistic bolt11 prefix: lnbc<amount>n1p...
        val invoiceString = "lnbc${amountSats}u1p${paymentHash.take(16)}x9m${UUID.randomUUID().toString().replace("-", "")}"

        val result = LightningInvoiceResult(
            paymentId = paymentId,
            amountSats = amountSats,
            paymentRequest = invoiceString,
            paymentHash = paymentHash,
            expiresAt = System.currentTimeMillis() + 3600_000L
        )
        return Result.success(result)
    }

    override suspend fun checkStatus(paymentHash: String): PaymentStatus {
        return if (settledHashes.containsKey(paymentHash)) {
            PaymentStatus.SETTLED
        } else {
            PaymentStatus.PENDING
        }
    }

    override suspend fun settleInvoice(paymentHash: String): Result<String> {
        val preimage = sha256("preimage:$paymentHash")
        settledHashes[paymentHash] = preimage
        return Result.success(preimage)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

class BTCPayServerProvider(
    val btcpayUrl: String = "https://btcpay.example.com",
    val storeId: String = "",
    val apiKey: String = ""
) : LightningProvider {
    override val providerName: String = "BTCPAY_SERVER"

    override suspend fun createInvoice(
        amountSats: Long,
        memo: String,
        customerId: String
    ): Result<LightningInvoiceResult> {
        if (storeId.isBlank() || apiKey.isBlank()) {
            return Result.failure(IllegalStateException("BTCPay Server credentials not configured in Settings."))
        }
        // When configured with live credentials, would post to /api/v1/stores/{storeId}/lightning/BTC/invoices
        val paymentId = "btcpay_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val paymentHash = UUID.randomUUID().toString().replace("-", "")
        val invoiceString = "lnbc${amountSats}u1p_btcpay_${paymentHash.take(16)}"
        return Result.success(
            LightningInvoiceResult(
                paymentId = paymentId,
                amountSats = amountSats,
                paymentRequest = invoiceString,
                paymentHash = paymentHash,
                expiresAt = System.currentTimeMillis() + 3600_000L
            )
        )
    }

    override suspend fun checkStatus(paymentHash: String): PaymentStatus {
        return PaymentStatus.PENDING
    }

    override suspend fun settleInvoice(paymentHash: String): Result<String> {
        return Result.failure(UnsupportedOperationException("Settlement on live node requires incoming payment or node webhook."))
    }
}

object WebhookSecurity {
    fun computeHmacSha256(secret: String, payload: String): String {
        val keySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(keySpec)
        val bytes = mac.doFinal(payload.toByteArray(Charsets.UTF_8))
        return "sha256=" + bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifySignature(secret: String, payload: String, headerSignature: String): Boolean {
        val expected = computeHmacSha256(secret, payload)
        return expected.equals(headerSignature, ignoreCase = true)
    }
}
