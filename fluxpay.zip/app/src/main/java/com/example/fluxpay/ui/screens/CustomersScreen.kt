package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun CustomersScreen(
    viewModel: FluxPayViewModel,
    onNavigateToLightning: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val transactions by viewModel.ledgerTransactions.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showAddCustomerDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Customer Management Header ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = ElectricBlue.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Customer Accounts",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Autonomous agents, software tenants, and API users",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Button(
                        onClick = { showAddCustomerDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_customer_button")
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Customer", fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. Customer Cards ---
        item {
            FintechSectionHeader(
                title = "Registered Customers (${customers.size})",
                subtitle = "Prepaid balances derived from authoritative double-entry ledger"
            )
        }

        if (customers.isEmpty()) {
            item {
                Text("No customers found.", color = TextSecondary, modifier = Modifier.padding(16.dp))
            }
        } else {
            items(customers) { c ->
                var prepaidBalance by remember { mutableStateOf(0L) }
                LaunchedEffect(c.customerId, transactions) {
                    coroutineScope.launch {
                        prepaidBalance = viewModel.repository.getCustomerPrepaidBalance(c.orgId, c.customerId)
                    }
                }

                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = FluxBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = c.displayName,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                StatusBadge(status = c.status)
                            }
                            Text(
                                text = "ID: ${c.customerId} • Ext: ${c.externalId}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = CyanAccent,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            Text(
                                text = "Email: ${c.email}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Max Request: ${c.maxSpendPerRequestSats} sats",
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                                Text(" • ", color = TextMuted)
                                Text(
                                    text = "Daily Limit: ${c.dailySpendLimitSats} sats",
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Prepaid Balance", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            SatsAmountText(amountSats = prepaidBalance, fontSize = 16, isPositive = true)
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = onNavigateToLightning,
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("fund_customer_${c.customerId}")
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = LightningGold, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Top Up", fontSize = 11.sp, color = LightningGold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddCustomerDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var externalId by remember { mutableStateOf("") }
        var maxPerReqStr by remember { mutableStateOf("1000") }
        var dailyLimitStr by remember { mutableStateOf("50000") }

        AlertDialog(
            onDismissRequest = { showAddCustomerDialog = false },
            title = { Text("Add Customer Account", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Display Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = externalId,
                        onValueChange = { externalId = it },
                        label = { Text("External ID (your system)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = maxPerReqStr,
                            onValueChange = { maxPerReqStr = it },
                            label = { Text("Max Sats/Req") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = dailyLimitStr,
                            onValueChange = { dailyLimitStr = it },
                            label = { Text("Daily Limit (sats)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val maxPerReq = maxPerReqStr.toLongOrNull() ?: 500L
                        val daily = dailyLimitStr.toLongOrNull() ?: 20000L
                        viewModel.createCustomer(name, email, externalId, maxPerReq, daily)
                        showAddCustomerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    modifier = Modifier.testTag("confirm_add_customer")
                ) {
                    Text("Create Customer")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCustomerDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = FluxSurfaceCard
        )
    }
}
