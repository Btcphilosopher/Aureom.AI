package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: FluxPayViewModel
) {
    val currentOrgId by viewModel.currentOrgId.collectAsState()
    val environment by viewModel.environment.collectAsState()
    val organizations by viewModel.organizations.collectAsState()

    var btcpayUrl by remember { mutableStateOf("https://btcpay.internal.io") }
    var btcpayStoreId by remember { mutableStateOf("store_live_8912") }
    var btcpayApiKey by remember { mutableStateOf("••••••••••••••••") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Organization & Multi-Tenancy ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = ElectricBlue.copy(alpha = 0.5f)
            ) {
                Text(
                    text = "Tenant Organization Workspace",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "Isolated tenant environments with segregated accounting ledgers",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val orgList = if (organizations.isNotEmpty()) organizations else listOf(
                        com.example.fluxpay.data.model.Organization("org_acme_ai", "Acme AI Labs", "acme_ai"),
                        com.example.fluxpay.data.model.Organization("org_neural_video", "NeuralStream", "neural_video")
                    )

                    orgList.forEach { o ->
                        val isSelected = (o.orgId == currentOrgId)
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.switchOrganization(o.orgId) },
                            label = { Text(o.name, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBlueDark,
                                selectedLabelColor = TextPrimary
                            ),
                            modifier = Modifier.testTag("switch_org_${o.orgId}")
                        )
                    }
                }
            }
        }

        // --- 2. Environment Mode ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = if (environment == "TEST") CyanAccent.copy(alpha = 0.5f) else SuccessEmerald.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Runtime Environment Mode",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = if (environment == "TEST") "Test Mode - Simulated Lightning & Test Balances" else "Production Mode - Live Settlement",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Switch(
                        checked = (environment == "PRODUCTION"),
                        onCheckedChange = { viewModel.toggleEnvironment() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SuccessEmerald,
                            checkedTrackColor = SuccessContainer,
                            uncheckedThumbColor = CyanAccent,
                            uncheckedTrackColor = FluxSurfaceVariant
                        ),
                        modifier = Modifier.testTag("environment_switch")
                    )
                }
            }
        }

        // --- 3. Lightning Node & Provider Configuration ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = LightningGold.copy(alpha = 0.4f)
            ) {
                Text(
                    text = "Lightning Provider Configuration",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "Configure non-custodial Lightning node or gateway integration",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val activeProvider = viewModel.repository.lightningProvider.providerName
                    FilterChip(
                        selected = (activeProvider == "MOCK_LIGHTNING_NODE"),
                        onClick = { viewModel.setLightningProvider("MOCK") },
                        label = { Text("Mock Lightning Node", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LightningGold.copy(alpha = 0.2f),
                            selectedLabelColor = LightningGold
                        )
                    )
                    FilterChip(
                        selected = (activeProvider == "BTCPAY_SERVER"),
                        onClick = { viewModel.setLightningProvider("BTCPAY") },
                        label = { Text("BTCPay Server", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBlueDark,
                            selectedLabelColor = TextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = btcpayUrl,
                    onValueChange = { btcpayUrl = it },
                    label = { Text("BTCPay Server Host URL") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = btcpayStoreId,
                        onValueChange = { btcpayStoreId = it },
                        label = { Text("Store ID") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = btcpayApiKey,
                        onValueChange = { btcpayApiKey = it },
                        label = { Text("API Token") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        }

        // --- 4. System Info & Compliance Notice ---
        item {
            FintechCard(backgroundColor = FluxBackground, borderColor = FluxBorder) {
                Text(
                    text = "FluxPay Architectural Integrity",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• Double-entry accounting: Every transaction balances Dr/Cr in integer satoshis.\n" +
                           "• Idempotent ingestion: Duplicate requests rejected without double-charging.\n" +
                           "• Lightning clearing: Settlement verified before ledger balance crediting.\n" +
                           "• Regulatory notice: Digital asset accounting conforms to internal double-entry ledgers.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
