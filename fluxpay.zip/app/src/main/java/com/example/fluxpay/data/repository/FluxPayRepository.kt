package com.example.fluxpay.data.repository

import com.example.fluxpay.data.lightning.LightningInvoiceResult
import com.example.fluxpay.data.lightning.LightningProvider
import com.example.fluxpay.data.lightning.MockLightningProvider
import com.example.fluxpay.data.lightning.WebhookSecurity
import com.example.fluxpay.data.local.FluxPayDatabase
import com.example.fluxpay.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToLong

data class IngestionResult(
    val event: UsageEvent,
    val isDuplicate: Boolean,
    val chargeSats: Long,
    val remainingBalanceSats: Long,
    val message: String
)

data class ReconciliationReport(
    val isBalanced: Boolean,
    val totalLedgerDebits: Long,
    val totalLedgerCredits: Long,
    val totalSettledPaymentsSats: Long,
    val totalAssetNodeCredits: Long,
    val discrepancySats: Long,
    val timestamp: Long = System.currentTimeMillis()
)

class FluxPayRepository(
    private val db: FluxPayDatabase,
    var lightningProvider: LightningProvider = MockLightningProvider()
) {
    val organizationDao = db.organizationDao()
    val customerDao = db.customerDao()
    val productDao = db.productDao()
    val usageEventDao = db.usageEventDao()
    val usageReservationDao = db.usageReservationDao()
    val ledgerDao = db.ledgerDao()
    val invoiceDao = db.invoiceDao()
    val lightningPaymentDao = db.lightningPaymentDao()
    val apiKeyDao = db.apiKeyDao()
    val webhookDao = db.webhookDao()

    // --- Active Tenant & Environment State ---
    suspend fun getOrCreateOrganization(orgId: String = "org_acme_ai", name: String = "Acme AI Labs"): Organization {
        val existing = organizationDao.getOrganization(orgId)
        if (existing != null) return existing
        val newOrg = Organization(
            orgId = orgId,
            name = name,
            slug = name.lowercase().replace(" ", "_"),
            environment = "TEST"
        )
        organizationDao.insertOrganization(newOrg)
        ensureSystemAccounts(orgId)
        return newOrg
    }

    suspend fun ensureSystemAccounts(orgId: String) {
        val nodeAcc = ledgerDao.getSystemAccount(orgId, AccountType.ASSET_LIGHTNING_NODE)
        if (nodeAcc == null) {
            ledgerDao.insertAccount(
                LedgerAccount(
                    accountId = "acc_node_${orgId}",
                    orgId = orgId,
                    accountType = AccountType.ASSET_LIGHTNING_NODE,
                    name = "Lightning Node Clearing Asset"
                )
            )
        }
        val revAcc = ledgerDao.getSystemAccount(orgId, AccountType.REVENUE_MERCHANT)
        if (revAcc == null) {
            ledgerDao.insertAccount(
                LedgerAccount(
                    accountId = "acc_rev_merchant_${orgId}",
                    orgId = orgId,
                    accountType = AccountType.REVENUE_MERCHANT,
                    name = "Merchant Earned Revenue"
                )
            )
        }
        val feeAcc = ledgerDao.getSystemAccount(orgId, AccountType.REVENUE_PLATFORM_FEE)
        if (feeAcc == null) {
            ledgerDao.insertAccount(
                LedgerAccount(
                    accountId = "acc_rev_fee_${orgId}",
                    orgId = orgId,
                    accountType = AccountType.REVENUE_PLATFORM_FEE,
                    name = "FluxPay Platform Fee Revenue"
                )
            )
        }
        val escrowAcc = ledgerDao.getSystemAccount(orgId, AccountType.CLEARING_ESCROW)
        if (escrowAcc == null) {
            ledgerDao.insertAccount(
                LedgerAccount(
                    accountId = "acc_escrow_${orgId}",
                    orgId = orgId,
                    accountType = AccountType.CLEARING_ESCROW,
                    name = "Pre-Authorisation Escrow"
                )
            )
        }
    }

    suspend fun getOrCreateCustomerPrepaidAccount(orgId: String, customerId: String): LedgerAccount {
        ensureSystemAccounts(orgId)
        val existing = ledgerDao.getCustomerPrepaidAccount(orgId, customerId)
        if (existing != null) return existing

        val newAccount = LedgerAccount(
            accountId = "acc_prepaid_${customerId}",
            orgId = orgId,
            accountType = AccountType.LIABILITY_CUSTOMER_PREPAID,
            customerId = customerId,
            name = "Customer Prepaid Liability ($customerId)"
        )
        ledgerDao.insertAccount(newAccount)
        return newAccount
    }

    suspend fun getCustomerPrepaidBalance(orgId: String, customerId: String): Long {
        val account = getOrCreateCustomerPrepaidAccount(orgId, customerId)
        return ledgerDao.getPrepaidAccountBalance(account.accountId)
    }

    fun observeCustomerPrepaidBalance(orgId: String, customerId: String): Flow<Long> {
        val accountId = "acc_prepaid_${customerId}"
        return ledgerDao.observePrepaidAccountBalance(accountId)
    }

    // --- Usage Ingestion & Pricing Engine ---
    suspend fun ingestUsageEvent(
        orgId: String,
        customerId: String,
        productId: String,
        quantity: Long,
        idempotencyKey: String,
        correlationId: String? = null
    ): Result<IngestionResult> {
        // 1. Idempotency Check
        val existingEvent = usageEventDao.getEventByIdempotencyKey(orgId, idempotencyKey)
        if (existingEvent != null) {
            val balance = getCustomerPrepaidBalance(orgId, customerId)
            return Result.success(
                IngestionResult(
                    event = existingEvent,
                    isDuplicate = true,
                    chargeSats = existingEvent.calculatedChargeSats,
                    remainingBalanceSats = balance,
                    message = "Duplicate event skipped (Idempotency Key: $idempotencyKey)"
                )
            )
        }

        // 2. Fetch Customer & Product
        val customer = customerDao.getCustomerById(customerId)
            ?: return Result.failure(IllegalArgumentException("Customer $customerId not found"))
        if (customer.status != "ACTIVE") {
            return Result.failure(IllegalStateException("Customer account is ${customer.status}"))
        }

        val product = productDao.getProductById(productId)
            ?: return Result.failure(IllegalArgumentException("Product $productId not found"))

        // 3. Calculate Rate according to Pricing Model
        val chargeSats: Long = calculateCharge(product, quantity)

        // Check per-request spending limit
        if (customer.maxSpendPerRequestSats > 0 && chargeSats > customer.maxSpendPerRequestSats) {
            val rejectedEvent = UsageEvent(
                eventId = "evt_" + UUID.randomUUID().toString().take(12),
                orgId = orgId,
                customerId = customerId,
                productId = productId,
                quantity = quantity,
                unit = product.usageUnit,
                idempotencyKey = idempotencyKey,
                calculatedChargeSats = chargeSats,
                priceVersionApplied = product.priceVersion,
                status = "REJECTED_LIMIT_EXCEEDED",
                correlationId = correlationId
            )
            usageEventDao.insertEvent(rejectedEvent)
            return Result.failure(
                IllegalStateException("Charge of $chargeSats sats exceeds max per-request limit (${customer.maxSpendPerRequestSats} sats)")
            )
        }

        // 4. Verify Prepaid Balance
        val currentBalance = getCustomerPrepaidBalance(orgId, customerId)
        if (currentBalance < chargeSats) {
            val rejectedEvent = UsageEvent(
                eventId = "evt_" + UUID.randomUUID().toString().take(12),
                orgId = orgId,
                customerId = customerId,
                productId = productId,
                quantity = quantity,
                unit = product.usageUnit,
                idempotencyKey = idempotencyKey,
                calculatedChargeSats = chargeSats,
                priceVersionApplied = product.priceVersion,
                status = "REJECTED_INSUFFICIENT_FUNDS",
                correlationId = correlationId
            )
            usageEventDao.insertEvent(rejectedEvent)
            dispatchWebhook(orgId, "wallet.balance.low", """{"customerId":"$customerId","balance":$currentBalance,"required":$chargeSats}""")
            return Result.failure(
                IllegalStateException("Insufficient funds: Available $currentBalance sats, required $chargeSats sats")
            )
        }

        // 5. Post Double-Entry Ledger Charge
        // Debit: Customer Prepaid Liability (reduces balance)
        // Credit: Platform Fee (1.5% min 0 sat) + Merchant Revenue (remainder)
        val customerAccount = getOrCreateCustomerPrepaidAccount(orgId, customerId)
        val merchantAccount = ledgerDao.getSystemAccount(orgId, AccountType.REVENUE_MERCHANT)
            ?: throw IllegalStateException("Merchant account missing")
        val feeAccount = ledgerDao.getSystemAccount(orgId, AccountType.REVENUE_PLATFORM_FEE)
            ?: throw IllegalStateException("Fee account missing")

        val txId = "tx_usage_" + UUID.randomUUID().toString().take(12)
        val eventId = "evt_" + UUID.randomUUID().toString().take(12)

        val platformFeeSats = if (chargeSats >= 10) (chargeSats * 0.015).roundToLong() else 0L
        val merchantRevenueSats = chargeSats - platformFeeSats

        val entries = mutableListOf(
            LedgerEntry(
                transactionId = txId,
                accountId = customerAccount.accountId,
                entryType = EntryType.DEBIT,
                amountSats = chargeSats
            ),
            LedgerEntry(
                transactionId = txId,
                accountId = merchantAccount.accountId,
                entryType = EntryType.CREDIT,
                amountSats = merchantRevenueSats
            )
        )
        if (platformFeeSats > 0) {
            entries.add(
                LedgerEntry(
                    transactionId = txId,
                    accountId = feeAccount.accountId,
                    entryType = EntryType.CREDIT,
                    amountSats = platformFeeSats
                )
            )
        }

        val tx = LedgerTransaction(
            transactionId = txId,
            orgId = orgId,
            referenceType = "USAGE_CHARGE",
            referenceId = eventId,
            description = "Usage charge for ${product.name}: $quantity ${product.usageUnit}"
        )

        ledgerDao.postDoubleEntryTransaction(tx, entries)

        // 6. Record Accepted Event
        val acceptedEvent = UsageEvent(
            eventId = eventId,
            orgId = orgId,
            customerId = customerId,
            productId = productId,
            quantity = quantity,
            unit = product.usageUnit,
            idempotencyKey = idempotencyKey,
            calculatedChargeSats = chargeSats,
            priceVersionApplied = product.priceVersion,
            status = "ACCEPTED",
            correlationId = correlationId
        )
        usageEventDao.insertEvent(acceptedEvent)

        val updatedBalance = currentBalance - chargeSats
        dispatchWebhook(orgId, "usage.event.accepted", """{"eventId":"$eventId","customerId":"$customerId","chargeSats":$chargeSats,"remainingBalance":$updatedBalance}""")

        return Result.success(
            IngestionResult(
                event = acceptedEvent,
                isDuplicate = false,
                chargeSats = chargeSats,
                remainingBalanceSats = updatedBalance,
                message = "Metered and charged $chargeSats sats successfully"
            )
        )
    }

    private fun calculateCharge(product: Product, quantity: Long): Long {
        return when (product.pricingModel) {
            PricingModel.PER_REQUEST -> {
                (quantity * product.rateSatsPerUnit).roundToLong().coerceAtLeast(1L)
            }
            PricingModel.PER_UNIT -> {
                val multiplier = product.unitMultiplier.coerceAtLeast(1L)
                val units = quantity.toDouble() / multiplier
                ceil(units * product.rateSatsPerUnit).toLong().coerceAtLeast(1L)
            }
            PricingModel.TIME_BASED -> {
                ceil(quantity * product.rateSatsPerUnit).toLong().coerceAtLeast(1L)
            }
            PricingModel.TIERED -> {
                // Example Tiered logic: first 10,000 units at rate, subsequent units at 80% rate
                if (quantity <= 10000) {
                    ceil(quantity * product.rateSatsPerUnit).toLong()
                } else {
                    val tier1 = 10000 * product.rateSatsPerUnit
                    val tier2 = (quantity - 10000) * (product.rateSatsPerUnit * 0.8)
                    ceil(tier1 + tier2).toLong()
                }
            }
            PricingModel.FIXED_ACCESS -> {
                product.rateSatsPerUnit.roundToLong().coerceAtLeast(1L)
            }
        }
    }

    // --- Lightning Payments & Ledger Funding ---
    suspend fun createLightningInvoice(
        orgId: String,
        customerId: String,
        amountSats: Long,
        memo: String
    ): Result<LightningPayment> {
        ensureSystemAccounts(orgId)
        val customer = customerDao.getCustomerById(customerId)
            ?: return Result.failure(IllegalArgumentException("Customer $customerId not found"))

        val providerResult = lightningProvider.createInvoice(amountSats, memo, customerId)
            .getOrElse { return Result.failure(it) }

        val payment = LightningPayment(
            paymentId = providerResult.paymentId,
            orgId = orgId,
            customerId = customerId,
            amountSats = amountSats,
            paymentRequest = providerResult.paymentRequest,
            paymentHash = providerResult.paymentHash,
            status = PaymentStatus.PENDING,
            providerType = lightningProvider.providerName,
            memo = memo,
            expiresAt = providerResult.expiresAt
        )
        lightningPaymentDao.insertPayment(payment)
        dispatchWebhook(orgId, "payment.invoice.created", """{"paymentId":"${payment.paymentId}","amountSats":$amountSats}""")
        return Result.success(payment)
    }

    suspend fun settleLightningPayment(paymentHash: String): Result<LightningPayment> {
        val payment = lightningPaymentDao.getPaymentByHash(paymentHash)
            ?: return Result.failure(IllegalArgumentException("Payment not found for hash: $paymentHash"))

        if (payment.status == PaymentStatus.SETTLED) {
            return Result.success(payment) // Already settled, idempotent return
        }

        // Settle via provider
        val preimageResult = lightningProvider.settleInvoice(paymentHash)
        val preimage = preimageResult.getOrNull()

        // Post Double-Entry Ledger Deposit:
        // Debit: ASSET_LIGHTNING_NODE (Assets increase)
        // Credit: LIABILITY_CUSTOMER_PREPAID (Customer prepaid balance increases)
        val nodeAccount = ledgerDao.getSystemAccount(payment.orgId, AccountType.ASSET_LIGHTNING_NODE)
            ?: throw IllegalStateException("Lightning node account missing")
        val customerAccount = getOrCreateCustomerPrepaidAccount(payment.orgId, payment.customerId)

        val txId = "tx_settle_" + UUID.randomUUID().toString().take(12)
        val entries = listOf(
            LedgerEntry(
                transactionId = txId,
                accountId = nodeAccount.accountId,
                entryType = EntryType.DEBIT,
                amountSats = payment.amountSats
            ),
            LedgerEntry(
                transactionId = txId,
                accountId = customerAccount.accountId,
                entryType = EntryType.CREDIT,
                amountSats = payment.amountSats
            )
        )

        val tx = LedgerTransaction(
            transactionId = txId,
            orgId = payment.orgId,
            referenceType = "DEPOSIT",
            referenceId = payment.paymentId,
            description = "Lightning deposit settlement for ${payment.customerId}: ${payment.amountSats} sats"
        )

        ledgerDao.postDoubleEntryTransaction(tx, entries)

        val updatedPayment = payment.copy(
            status = PaymentStatus.SETTLED,
            preimage = preimage,
            settledAt = System.currentTimeMillis()
        )
        lightningPaymentDao.updatePayment(updatedPayment)
        dispatchWebhook(payment.orgId, "payment.settled", """{"paymentId":"${payment.paymentId}","amountSats":${payment.amountSats},"preimage":"$preimage"}""")

        return Result.success(updatedPayment)
    }

    // --- Billing & Invoices ---
    suspend fun createInvoice(
        orgId: String,
        customerId: String,
        billingPeriod: String = "Current Period",
        items: List<InvoiceLineItem>
    ): Invoice {
        val invoiceId = "inv_" + UUID.randomUUID().toString().take(12)
        val subtotal = items.sumOf { it.totalSats }
        val tax = 0L
        val total = subtotal + tax

        val invoice = Invoice(
            invoiceId = invoiceId,
            orgId = orgId,
            customerId = customerId,
            billingPeriod = billingPeriod,
            subtotalSats = subtotal,
            taxSats = tax,
            totalSats = total,
            status = InvoiceStatus.OPEN
        )
        invoiceDao.insertInvoice(invoice)
        val lineItemsWithInvoiceId = items.map { it.copy(invoiceId = invoiceId) }
        invoiceDao.insertLineItems(lineItemsWithInvoiceId)

        dispatchWebhook(orgId, "billing.invoice.created", """{"invoiceId":"$invoiceId","totalSats":$total}""")
        return invoice
    }

    suspend fun payInvoiceFromPrepaid(invoiceId: String): Result<Invoice> {
        val invoice = invoiceDao.getInvoiceById(invoiceId)
            ?: return Result.failure(IllegalArgumentException("Invoice not found"))
        if (invoice.status == InvoiceStatus.PAID) {
            return Result.success(invoice)
        }

        val balance = getCustomerPrepaidBalance(invoice.orgId, invoice.customerId)
        val amountDue = invoice.totalSats - invoice.amountPaidSats
        if (balance < amountDue) {
            return Result.failure(IllegalStateException("Insufficient prepaid balance ($balance sats) to pay $amountDue sats"))
        }

        // Post ledger entries for paying invoice
        val customerAccount = getOrCreateCustomerPrepaidAccount(invoice.orgId, invoice.customerId)
        val merchantAccount = ledgerDao.getSystemAccount(invoice.orgId, AccountType.REVENUE_MERCHANT)
            ?: throw IllegalStateException("Merchant account missing")

        val txId = "tx_inv_pay_" + UUID.randomUUID().toString().take(12)
        val entries = listOf(
            LedgerEntry(
                transactionId = txId,
                accountId = customerAccount.accountId,
                entryType = EntryType.DEBIT,
                amountSats = amountDue
            ),
            LedgerEntry(
                transactionId = txId,
                accountId = merchantAccount.accountId,
                entryType = EntryType.CREDIT,
                amountSats = amountDue
            )
        )
        val tx = LedgerTransaction(
            transactionId = txId,
            orgId = invoice.orgId,
            referenceType = "INVOICE_SETTLEMENT",
            referenceId = invoiceId,
            description = "Settlement of invoice $invoiceId via customer prepaid balance"
        )
        ledgerDao.postDoubleEntryTransaction(tx, entries)

        val updatedInvoice = invoice.copy(
            amountPaidSats = invoice.totalSats,
            status = InvoiceStatus.PAID
        )
        invoiceDao.updateInvoice(updatedInvoice)
        dispatchWebhook(invoice.orgId, "billing.invoice.paid", """{"invoiceId":"$invoiceId","amountPaid":$amountDue}""")
        return Result.success(updatedInvoice)
    }

    // --- Webhooks Dispatcher ---
    private suspend fun dispatchWebhook(orgId: String, eventType: String, payloadJson: String) {
        val endpoints = webhookDao.getEndpoints(orgId).firstOrNull() ?: emptyList()
        for (ep in endpoints) {
            if (!ep.isActive || !ep.enabledEvents.contains(eventType)) continue
            val sig = WebhookSecurity.computeHmacSha256(ep.secretKey, payloadJson)
            val delivery = WebhookDelivery(
                deliveryId = "del_" + UUID.randomUUID().toString().take(12),
                endpointId = ep.endpointId,
                eventType = eventType,
                payloadJson = payloadJson,
                httpStatusCode = 200,
                status = "DELIVERED",
                signatureHeader = sig
            )
            webhookDao.insertDelivery(delivery)
        }
    }

    // --- Reconciliation Engine ---
    suspend fun runReconciliation(orgId: String): ReconciliationReport {
        val totalDebits = ledgerDao.getTotalDebits()
        val totalCredits = ledgerDao.getTotalCredits()
        val totalSettledSats = lightningPaymentDao.getTotalSettledSats(orgId).firstOrNull() ?: 0L

        val nodeAccount = ledgerDao.getSystemAccount(orgId, AccountType.ASSET_LIGHTNING_NODE)
        val assetEntries = if (nodeAccount != null) ledgerDao.getEntriesForAccount(nodeAccount.accountId) else emptyList()
        val assetDebits = assetEntries.filter { it.entryType == EntryType.DEBIT }.sumOf { it.amountSats }

        val discrepancy = assetDebits - totalSettledSats
        val isBalanced = (totalDebits == totalCredits) && (discrepancy == 0L)

        return ReconciliationReport(
            isBalanced = isBalanced,
            totalLedgerDebits = totalDebits,
            totalLedgerCredits = totalCredits,
            totalSettledPaymentsSats = totalSettledSats,
            totalAssetNodeCredits = assetDebits,
            discrepancySats = discrepancy
        )
    }

    // --- Seed Initial Data ---
    suspend fun seedInitialData() {
        val defaultOrg = getOrCreateOrganization("org_acme_ai", "Acme AI Labs")
        ensureSystemAccounts(defaultOrg.orgId)

        // Seed Customers
        val c1 = Customer(
            customerId = "cus_aurora_01",
            orgId = defaultOrg.orgId,
            externalId = "agent_aurora",
            displayName = "Aurora AI Autonomous Agent",
            email = "aurora@autonomous.agent",
            maxSpendPerRequestSats = 1000L,
            dailySpendLimitSats = 50000L
        )
        val c2 = Customer(
            customerId = "cus_synth_02",
            orgId = defaultOrg.orgId,
            externalId = "synthwave_corp",
            displayName = "SynthWave Streaming Corp",
            email = "billing@synthwave.io",
            maxSpendPerRequestSats = 2500L,
            dailySpendLimitSats = 100000L
        )
        val c3 = Customer(
            customerId = "cus_dev_03",
            orgId = defaultOrg.orgId,
            externalId = "devpulse_eng",
            displayName = "DevPulse Microservices",
            email = "infra@devpulse.dev",
            maxSpendPerRequestSats = 500L,
            dailySpendLimitSats = 20000L
        )
        customerDao.insertCustomer(c1)
        customerDao.insertCustomer(c2)
        customerDao.insertCustomer(c3)

        // Seed Products
        val p1 = Product(
            productId = "prod_gpt4_tokens",
            orgId = defaultOrg.orgId,
            name = "AI Model Inference (Tokens)",
            description = "Deep reasoning model input and output token consumption",
            usageUnit = "tokens",
            pricingModel = PricingModel.PER_UNIT,
            rateSatsPerUnit = 2.0,
            unitMultiplier = 1000L
        )
        val p2 = Product(
            productId = "prod_api_call",
            orgId = defaultOrg.orgId,
            name = "Microservices API Request",
            description = "High-availability authenticated gateway requests",
            usageUnit = "requests",
            pricingModel = PricingModel.PER_REQUEST,
            rateSatsPerUnit = 5.0,
            unitMultiplier = 1L
        )
        val p3 = Product(
            productId = "prod_video_stream",
            orgId = defaultOrg.orgId,
            name = "Video Streaming & Transcoding",
            description = "Per-second live video transcoding and edge bandwidth",
            usageUnit = "seconds",
            pricingModel = PricingModel.TIME_BASED,
            rateSatsPerUnit = 1.5,
            unitMultiplier = 1L
        )
        val p4 = Product(
            productId = "prod_vector_db",
            orgId = defaultOrg.orgId,
            name = "Vector Embeddings & Queries",
            description = "Milvus/Pinecone similarity search queries",
            usageUnit = "queries",
            pricingModel = PricingModel.PER_REQUEST,
            rateSatsPerUnit = 3.0,
            unitMultiplier = 1L
        )
        val p5 = Product(
            productId = "prod_gpu_a100",
            orgId = defaultOrg.orgId,
            name = "GPU Cloud Compute (A100)",
            description = "Elastic GPU training time with tiered usage rate",
            usageUnit = "seconds",
            pricingModel = PricingModel.TIERED,
            rateSatsPerUnit = 8.0,
            unitMultiplier = 1L
        )
        productDao.insertProduct(p1)
        productDao.insertProduct(p2)
        productDao.insertProduct(p3)
        productDao.insertProduct(p4)
        productDao.insertProduct(p5)

        // Seed Initial API Key
        apiKeyDao.insertApiKey(
            ApiKey(
                keyId = "key_01",
                orgId = defaultOrg.orgId,
                keyPrefix = "fp_test_live_9a8b",
                keyHash = "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                label = "Production Agent Backend Key",
                scopes = "meter:write,billing:read,wallet:manage"
            )
        )

        // Seed Initial Webhook Endpoint
        webhookDao.insertEndpoint(
            WebhookEndpoint(
                endpointId = "ep_01",
                orgId = defaultOrg.orgId,
                url = "https://api.acme-ai.internal/webhooks/fluxpay",
                secretKey = "whsec_live_99214abce3847a9128f"
            )
        )

        // Seed Lightning Top-up & Settle for Aurora (15,000 sats) and SynthWave (30,000 sats)
        val invoice1 = createLightningInvoice(defaultOrg.orgId, c1.customerId, 15000L, "Initial funding for Aurora AI").getOrThrow()
        settleLightningPayment(invoice1.paymentHash)

        val invoice2 = createLightningInvoice(defaultOrg.orgId, c2.customerId, 30000L, "Monthly reserve funding for SynthWave").getOrThrow()
        settleLightningPayment(invoice2.paymentHash)

        // Record a couple of realistic usage events
        ingestUsageEvent(defaultOrg.orgId, c1.customerId, p1.productId, 1500L, "req_seed_001")
        ingestUsageEvent(defaultOrg.orgId, c1.customerId, p2.productId, 2L, "req_seed_002")
        ingestUsageEvent(defaultOrg.orgId, c2.customerId, p3.productId, 60L, "req_seed_003")
    }
}
