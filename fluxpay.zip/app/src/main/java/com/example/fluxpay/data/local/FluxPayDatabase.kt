package com.example.fluxpay.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.fluxpay.data.model.*

@Database(
    entities = [
        Organization::class,
        Customer::class,
        Product::class,
        UsageEvent::class,
        UsageReservation::class,
        LedgerAccount::class,
        LedgerTransaction::class,
        LedgerEntry::class,
        Invoice::class,
        InvoiceLineItem::class,
        LightningPayment::class,
        ApiKey::class,
        WebhookEndpoint::class,
        WebhookDelivery::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(FluxPayConverters::class)
abstract class FluxPayDatabase : RoomDatabase() {
    abstract fun organizationDao(): OrganizationDao
    abstract fun customerDao(): CustomerDao
    abstract fun productDao(): ProductDao
    abstract fun usageEventDao(): UsageEventDao
    abstract fun usageReservationDao(): UsageReservationDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun lightningPaymentDao(): LightningPaymentDao
    abstract fun apiKeyDao(): ApiKeyDao
    abstract fun webhookDao(): WebhookDao

    companion object {
        @Volatile
        private var INSTANCE: FluxPayDatabase? = null

        fun getInstance(context: Context): FluxPayDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FluxPayDatabase::class.java,
                    "fluxpay_master.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
