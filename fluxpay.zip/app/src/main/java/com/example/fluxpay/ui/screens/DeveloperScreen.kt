package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*

@Composable
fun DeveloperScreen(
    viewModel: FluxPayViewModel
) {
    val apiKeys by viewModel.apiKeys.collectAsState()
    val endpoints by viewModel.webhookEndpoints.collectAsState()
    val deliveries by viewModel.recentWebhookDeliveries.collectAsState()
    val orgId by viewModel.currentOrgId.collectAsState()

    var showGenerateKeyDialog by remember { mutableStateOf(false) }
    var sdkLanguageTab by remember { mutableStateOf(0) } // 0: Python, 1: TypeScript, 2: cURL

    val pythonSnippet = """
from fluxpay import FluxPayClient

client = FluxPayClient(
    api_key="fp_test_live_9a8b...",
    base_url="https://api.fluxpay.io/api/v1"
)

# 1. Authorize & report measured consumption
event = client.usage.create_event(
    customer_id="cus_aurora_01",
    product_id="prod_gpt4_tokens",
    quantity=1500,
    unit="tokens",
    idempotency_key="job_req_9281a"
)

print(f"Charged: {event.charge_sats} sats, Remaining: {event.remaining_balance_sats} sats")
""".trimIndent()

    val typescriptSnippet = """
import { FluxPay } from '@fluxpay/sdk';

const fluxpay = new FluxPay({
  apiKey: process.env.FLUXPAY_API_KEY!,
  environment: 'test'
});

// Report streaming minutes or inference tokens
const result = await fluxpay.usage.ingest({
  customerId: 'cus_synth_02',
  productId: 'prod_video_stream',
  quantity: 120,
  idempotencyKey: 'stream_segment_44'
});
console.log('Metered sats:', result.calculatedChargeSats);
""".trimIndent()

    val curlSnippet = """
curl -X POST https://api.fluxpay.io/api/v1/usage/events \
  -H "Authorization: Bearer fp_test_live_9a8b..." \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "cus_aurora_01",
    "product_id": "prod_api_call",
    "quantity": 1,
    "idempotency_key": "req_8812a"
  }'
""".trimIndent()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Developer Header ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = ElectricBlue.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Developer API & SDK Console",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Programmable integration for microservices and agents",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Button(
                        onClick = { showGenerateKeyDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("generate_api_key_button")
                    ) {
                        Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New API Key", fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. SDK Code Snippet Tab ---
        item {
            FintechSectionHeader(
                title = "Client SDK Integration",
                subtitle = "Official SDK patterns"
            )
            TabRow(
                selectedTabIndex = sdkLanguageTab,
                containerColor = FluxSurface,
                contentColor = CyanAccent,
                indicator = {},
                divider = {}
            ) {
                Tab(
                    selected = (sdkLanguageTab == 0),
                    onClick = { sdkLanguageTab = 0 },
                    text = { Text("Python SDK", fontSize = 12.sp) }
                )
                Tab(
                    selected = (sdkLanguageTab == 1),
                    onClick = { sdkLanguageTab = 1 },
                    text = { Text("TypeScript", fontSize = 12.sp) }
                )
                Tab(
                    selected = (sdkLanguageTab == 2),
                    onClick = { sdkLanguageTab = 2 },
                    text = { Text("cURL REST", fontSize = 12.sp) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            when (sdkLanguageTab) {
                0 -> CodeSnippetBox(code = pythonSnippet, language = "python")
                1 -> CodeSnippetBox(code = typescriptSnippet, language = "typescript")
                2 -> CodeSnippetBox(code = curlSnippet, language = "bash")
            }
        }

        // --- 3. API Keys List ---
        item {
            FintechSectionHeader(
                title = "Active API Credentials (${apiKeys.size})",
                subtitle = "Scoped secret keys"
            )
        }

        if (apiKeys.isEmpty()) {
            item {
                Text("No API keys found.", color = TextSecondary, modifier = Modifier.padding(16.dp))
            }
        } else {
            items(apiKeys) { k ->
                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = if (k.isRevoked) FluxBorder else CyanAccent.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${k.keyPrefix}••••••••",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (k.isRevoked) TextTertiary else CyanAccent
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = if (k.isRevoked) "REVOKED" else "ACTIVE")
                            }
                            Text(
                                text = "${k.label} • Scopes: ${k.scopes}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        if (!k.isRevoked) {
                            TextButton(
                                onClick = { viewModel.revokeApiKey(k.keyId) },
                                modifier = Modifier.testTag("revoke_key_${k.keyId}")
                            ) {
                                Text("Revoke", color = ErrorRose, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // --- 4. Webhook Endpoints & Deliveries ---
        item {
            FintechSectionHeader(
                title = "Webhook Endpoints & Logs",
                subtitle = "Cryptographically signed event deliveries"
            )
        }

        items(endpoints) { ep ->
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = FluxBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = ep.url,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )
                        StatusBadge(status = if (ep.isActive) "ACTIVE" else "INACTIVE")
                    }
                    Text(
                        text = "Secret: ${ep.secretKey.take(12)}•••• (HMAC-SHA256)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = TextTertiary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (deliveries.isNotEmpty()) {
            item {
                Text(
                    text = "Recent Deliveries:",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(deliveries.take(4)) { del ->
                FintechCard(backgroundColor = FluxBackground, borderColor = FluxBorder) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = del.eventType,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                            Text(
                                text = del.payloadJson.take(35) + "...",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                        StatusBadge(status = "${del.httpStatusCode} OK")
                    }
                }
            }
        }
    }

    if (showGenerateKeyDialog) {
        var label by remember { mutableStateOf("Microservices Backend Key") }
        var scopes by remember { mutableStateOf("meter:write,billing:read,wallet:manage") }

        AlertDialog(
            onDismissRequest = { showGenerateKeyDialog = false },
            title = { Text("Generate API Key", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        label = { Text("Key Label / Description") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = scopes,
                        onValueChange = { scopes = it },
                        label = { Text("Scopes (comma-separated)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createApiKey(label, scopes)
                        showGenerateKeyDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    modifier = Modifier.testTag("confirm_generate_key")
                ) {
                    Text("Generate Key")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGenerateKeyDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = FluxSurfaceCard
        )
    }
}
