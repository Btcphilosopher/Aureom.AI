package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.data.model.AccountType
import com.example.fluxpay.data.model.EntryType
import com.example.fluxpay.data.model.LedgerEntry
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LedgerScreen(
    viewModel: FluxPayViewModel
) {
    val accounts by viewModel.ledgerAccounts.collectAsState()
    val transactions by viewModel.ledgerTransactions.collectAsState()
    val report by viewModel.reconciliationReport.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showAuditDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Ledger Invariant & Reconciliation Banner ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = SuccessEmerald.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = SuccessEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Double-Entry Accounting Invariant",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Text(
                            text = "Every transaction is balanced: Sum(Debits) == Sum(Credits)",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.runReconciliation()
                            showAuditDialog = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("run_audit_button")
                    ) {
                        Icon(Icons.Default.FactCheck, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run Audit", color = CyanAccent, fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. Chart of Accounts ---
        item {
            FintechSectionHeader(
                title = "Chart of Accounts (${accounts.size})",
                subtitle = "Categorised asset, liability, and revenue ledgers"
            )
        }

        items(accounts) { acc ->
            var balance by remember { mutableStateOf<Long?>(null) }
            LaunchedEffect(acc.accountId, transactions) {
                coroutineScope.launch {
                    val bal = viewModel.repository.ledgerDao.getPrepaidAccountBalance(acc.accountId)
                    balance = bal
                }
            }

            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = FluxBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = acc.name,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = acc.accountId,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(FluxSurfaceVariant)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = acc.accountType.name.replace("_", " "),
                                    fontSize = 9.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (acc.accountType == AccountType.LIABILITY_CUSTOMER_PREPAID) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Available", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            SatsAmountText(amountSats = balance ?: 0L, fontSize = 14)
                        }
                    }
                }
            }
        }

        // --- 3. Journal Transactions Feed ---
        item {
            FintechSectionHeader(
                title = "Journal Transactions (${transactions.size})",
                subtitle = "Balanced, immutable accounting transactions"
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text("No ledger transactions recorded.", color = TextSecondary, modifier = Modifier.padding(16.dp))
            }
        } else {
            items(transactions) { tx ->
                var entries by remember { mutableStateOf<List<LedgerEntry>>(emptyList()) }
                LaunchedEffect(tx.transactionId) {
                    entries = viewModel.repository.ledgerDao.getEntriesForTransaction(tx.transactionId)
                }

                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = FluxBorder
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = tx.transactionId,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = CyanAccent
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusBadge(status = tx.referenceType)
                                }
                                Text(
                                    text = tx.description,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }

                        if (entries.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FluxBackground)
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Account", fontSize = 10.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                                        Text("Debit (Dr)", fontSize = 10.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                                        Text("Credit (Cr)", fontSize = 10.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Divider(color = FluxBorder, thickness = 0.5.dp)
                                entries.forEach { entry ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = entry.accountId.take(20),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = TextSecondary
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                                            Text(
                                                text = if (entry.entryType == EntryType.DEBIT) "${entry.amountSats} sats" else "-",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (entry.entryType == EntryType.DEBIT) ErrorRose else TextMuted
                                            )
                                            Text(
                                                text = if (entry.entryType == EntryType.CREDIT) "${entry.amountSats} sats" else "-",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (entry.entryType == EntryType.CREDIT) SuccessEmerald else TextMuted
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAuditDialog && report != null) {
        val rep = report!!
        AlertDialog(
            onDismissRequest = { showAuditDialog = false },
            title = {
                Text(
                    text = if (rep.isBalanced) "Reconciliation Audit: PASSED" else "Reconciliation Discrepancy",
                    color = if (rep.isBalanced) SuccessEmerald else ErrorRose,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Total Ledger Debits: ${rep.totalLedgerDebits} sats", color = TextPrimary)
                    Text("Total Ledger Credits: ${rep.totalLedgerCredits} sats", color = TextPrimary)
                    Text("Lightning Provider Settled: ${rep.totalSettledPaymentsSats} sats", color = TextPrimary)
                    Text("Node Clearing Asset: ${rep.totalAssetNodeCredits} sats", color = TextPrimary)
                    Divider(color = FluxBorder)
                    Text(
                        text = "Net Discrepancy: ${rep.discrepancySats} sats",
                        fontWeight = FontWeight.Bold,
                        color = if (rep.discrepancySats == 0L) SuccessEmerald else ErrorRose
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAuditDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            },
            containerColor = FluxSurfaceCard
        )
    }
}
