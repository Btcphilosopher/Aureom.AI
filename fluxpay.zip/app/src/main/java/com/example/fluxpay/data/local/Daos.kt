package com.example.fluxpay.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.fluxpay.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OrganizationDao {
    @Query("SELECT * FROM organizations")
    fun getAllOrganizations(): Flow<List<Organization>>

    @Query("SELECT * FROM organizations WHERE orgId = :orgId")
    suspend fun getOrganization(orgId: String): Organization?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrganization(organization: Organization)

    @Update
    suspend fun updateOrganization(organization: Organization)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE orgId = :orgId ORDER BY createdAt DESC")
    fun getCustomers(orgId: String): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE customerId = :customerId")
    suspend fun getCustomerById(customerId: String): Customer?

    @Query("SELECT * FROM customers WHERE orgId = :orgId AND externalId = :externalId LIMIT 1")
    suspend fun getCustomerByExternalId(orgId: String, externalId: String): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer)

    @Update
    suspend fun updateCustomer(customer: Customer)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE orgId = :orgId ORDER BY name ASC")
    fun getProducts(orgId: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE productId = :productId")
    suspend fun getProductById(productId: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)
}

@Dao
interface UsageEventDao {
    @Query("SELECT * FROM usage_events WHERE orgId = :orgId ORDER BY timestamp DESC")
    fun getUsageEvents(orgId: String): Flow<List<UsageEvent>>

    @Query("SELECT * FROM usage_events WHERE orgId = :orgId AND idempotencyKey = :idempotencyKey LIMIT 1")
    suspend fun getEventByIdempotencyKey(orgId: String, idempotencyKey: String): UsageEvent?

    @Query("SELECT * FROM usage_events WHERE orgId = :orgId AND customerId = :customerId ORDER BY timestamp DESC")
    fun getEventsByCustomer(orgId: String, customerId: String): Flow<List<UsageEvent>>

    @Query("SELECT COUNT(*) FROM usage_events WHERE orgId = :orgId")
    fun getEventCount(orgId: String): Flow<Long>

    @Query("SELECT COALESCE(SUM(calculatedChargeSats), 0) FROM usage_events WHERE orgId = :orgId AND status = 'ACCEPTED'")
    fun getTotalMeteredCharges(orgId: String): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertEvent(event: UsageEvent)
}

@Dao
interface UsageReservationDao {
    @Query("SELECT * FROM usage_reservations WHERE reservationId = :id")
    suspend fun getReservation(id: String): UsageReservation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReservation(reservation: UsageReservation)

    @Update
    suspend fun updateReservation(reservation: UsageReservation)
}

data class AccountBalanceResult(
    val accountId: String,
    val name: String,
    val accountType: AccountType,
    val totalCredits: Long,
    val totalDebits: Long
)

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_accounts WHERE orgId = :orgId")
    fun getAccounts(orgId: String): Flow<List<LedgerAccount>>

    @Query("SELECT * FROM ledger_accounts WHERE orgId = :orgId AND customerId = :customerId AND accountType = 'LIABILITY_CUSTOMER_PREPAID' LIMIT 1")
    suspend fun getCustomerPrepaidAccount(orgId: String, customerId: String): LedgerAccount?

    @Query("SELECT * FROM ledger_accounts WHERE orgId = :orgId AND accountType = :accountType LIMIT 1")
    suspend fun getSystemAccount(orgId: String, accountType: AccountType): LedgerAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: LedgerAccount)

    @Insert
    suspend fun insertTransaction(transaction: LedgerTransaction)

    @Insert
    suspend fun insertEntries(entries: List<LedgerEntry>)

    @Query("SELECT * FROM ledger_transactions WHERE orgId = :orgId ORDER BY timestamp DESC")
    fun getTransactions(orgId: String): Flow<List<LedgerTransaction>>

    @Query("SELECT * FROM ledger_entries WHERE transactionId = :txId")
    suspend fun getEntriesForTransaction(txId: String): List<LedgerEntry>

    @Query("SELECT * FROM ledger_entries WHERE accountId = :accountId")
    suspend fun getEntriesForAccount(accountId: String): List<LedgerEntry>

    // Derived customer prepaid balance: For LIABILITY accounts, Credits increase balance, Debits decrease balance!
    @Query("""
        SELECT COALESCE(
            (SELECT SUM(amountSats) FROM ledger_entries WHERE accountId = :accountId AND entryType = 'CREDIT'), 0
        ) - COALESCE(
            (SELECT SUM(amountSats) FROM ledger_entries WHERE accountId = :accountId AND entryType = 'DEBIT'), 0
        )
    """)
    suspend fun getPrepaidAccountBalance(accountId: String): Long

    @Query("""
        SELECT COALESCE(
            (SELECT SUM(amountSats) FROM ledger_entries WHERE accountId = :accountId AND entryType = 'CREDIT'), 0
        ) - COALESCE(
            (SELECT SUM(amountSats) FROM ledger_entries WHERE accountId = :accountId AND entryType = 'DEBIT'), 0
        )
    """)
    fun observePrepaidAccountBalance(accountId: String): Flow<Long>

    // Verify system invariant: Total debits across all posted entries must equal total credits
    @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries WHERE entryType = 'DEBIT'")
    suspend fun getTotalDebits(): Long

    @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries WHERE entryType = 'CREDIT'")
    suspend fun getTotalCredits(): Long

    @Transaction
    suspend fun postDoubleEntryTransaction(tx: LedgerTransaction, entries: List<LedgerEntry>) {
        val totalDebits = entries.filter { it.entryType == EntryType.DEBIT }.sumOf { it.amountSats }
        val totalCredits = entries.filter { it.entryType == EntryType.CREDIT }.sumOf { it.amountSats }
        require(totalDebits == totalCredits) {
            "Ledger transaction $tx does not balance! Total Debits ($totalDebits) != Total Credits ($totalCredits)"
        }
        insertTransaction(tx)
        insertEntries(entries)
    }
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices WHERE orgId = :orgId ORDER BY createdAt DESC")
    fun getInvoices(orgId: String): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices WHERE invoiceId = :invoiceId")
    suspend fun getInvoiceById(invoiceId: String): Invoice?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice)

    @Update
    suspend fun updateInvoice(invoice: Invoice)

    @Query("SELECT * FROM invoice_line_items WHERE invoiceId = :invoiceId")
    suspend fun getLineItems(invoiceId: String): List<InvoiceLineItem>

    @Query("SELECT * FROM invoice_line_items WHERE invoiceId = :invoiceId")
    fun observeLineItems(invoiceId: String): Flow<List<InvoiceLineItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLineItems(items: List<InvoiceLineItem>)
}

@Dao
interface LightningPaymentDao {
    @Query("SELECT * FROM lightning_payments WHERE orgId = :orgId ORDER BY createdAt DESC")
    fun getPayments(orgId: String): Flow<List<LightningPayment>>

    @Query("SELECT * FROM lightning_payments WHERE paymentHash = :paymentHash LIMIT 1")
    suspend fun getPaymentByHash(paymentHash: String): LightningPayment?

    @Query("SELECT * FROM lightning_payments WHERE paymentId = :paymentId LIMIT 1")
    suspend fun getPaymentById(paymentId: String): LightningPayment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: LightningPayment)

    @Update
    suspend fun updatePayment(payment: LightningPayment)

    @Query("SELECT COALESCE(SUM(amountSats), 0) FROM lightning_payments WHERE orgId = :orgId AND status = 'SETTLED'")
    fun getTotalSettledSats(orgId: String): Flow<Long>
}

@Dao
interface ApiKeyDao {
    @Query("SELECT * FROM api_keys WHERE orgId = :orgId ORDER BY createdAt DESC")
    fun getApiKeys(orgId: String): Flow<List<ApiKey>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKey(apiKey: ApiKey)

    @Query("UPDATE api_keys SET isRevoked = 1 WHERE keyId = :keyId")
    suspend fun revokeApiKey(keyId: String)
}

@Dao
interface WebhookDao {
    @Query("SELECT * FROM webhook_endpoints WHERE orgId = :orgId")
    fun getEndpoints(orgId: String): Flow<List<WebhookEndpoint>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEndpoint(endpoint: WebhookEndpoint)

    @Query("SELECT * FROM webhook_deliveries ORDER BY attemptedAt DESC LIMIT 50")
    fun getRecentDeliveries(): Flow<List<WebhookDelivery>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDelivery(delivery: WebhookDelivery)
}
