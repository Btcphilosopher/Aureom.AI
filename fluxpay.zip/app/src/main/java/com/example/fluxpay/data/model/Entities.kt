package com.example.fluxpay.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// --- 1. Tenancy & Auth ---

@Entity(tableName = "organizations")
data class Organization(
    @PrimaryKey val orgId: String,
    val name: String,
    val slug: String,
    val currency: String = "SATS",
    val environment: String = "TEST", // "TEST" or "PRODUCTION"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "api_keys",
    indices = [Index(value = ["keyPrefix"]), Index(value = ["orgId"])]
)
data class ApiKey(
    @PrimaryKey val keyId: String,
    val orgId: String,
    val keyPrefix: String, // e.g., "fp_test_9a8b"
    val keyHash: String,
    val label: String,
    val scopes: String = "meter:write,billing:read,wallet:manage", // Comma-separated
    val environment: String = "TEST",
    val isRevoked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// --- 2. Customers ---

@Entity(
    tableName = "customers",
    indices = [Index(value = ["orgId"]), Index(value = ["orgId", "externalId"], unique = true)]
)
data class Customer(
    @PrimaryKey val customerId: String,
    val orgId: String,
    val externalId: String,
    val displayName: String,
    val email: String,
    val maxSpendPerRequestSats: Long = 500L,
    val dailySpendLimitSats: Long = 10000L,
    val status: String = "ACTIVE", // ACTIVE, SUSPENDED
    val createdAt: Long = System.currentTimeMillis()
)

// --- 3. Products & Pricing ---

enum class PricingModel {
    PER_REQUEST,
    PER_UNIT,     // e.g. per 1000 tokens, per MB
    TIME_BASED,   // e.g. per second, per minute
    TIERED,       // 0-10k: 1 sat, 10k+: 0.8 sat
    FIXED_ACCESS
}

@Entity(
    tableName = "products",
    indices = [Index(value = ["orgId"])]
)
data class Product(
    @PrimaryKey val productId: String,
    val orgId: String,
    val name: String,
    val description: String,
    val usageUnit: String, // "tokens", "requests", "seconds", "megabytes", "queries"
    val pricingModel: PricingModel,
    val rateSatsPerUnit: Double, // e.g. 1.0 sat per 1000 tokens, 5.0 sats per request
    val unitMultiplier: Long = 1L, // e.g. 1000 for tokens, 1 for requests
    val priceVersion: Int = 1,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// --- 4. Metering & Usage Events ---

@Entity(
    tableName = "usage_events",
    indices = [
        Index(value = ["orgId", "idempotencyKey"], unique = true),
        Index(value = ["orgId", "customerId"]),
        Index(value = ["timestamp"])
    ]
)
data class UsageEvent(
    @PrimaryKey val eventId: String,
    val orgId: String,
    val customerId: String,
    val productId: String,
    val quantity: Long,
    val unit: String,
    val idempotencyKey: String,
    val calculatedChargeSats: Long,
    val priceVersionApplied: Int,
    val status: String = "ACCEPTED", // ACCEPTED, REJECTED, DUPLICATE_SKIPPED
    val correlationId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val ingestionTimestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "usage_reservations",
    indices = [Index(value = ["orgId", "customerId"])]
)
data class UsageReservation(
    @PrimaryKey val reservationId: String,
    val orgId: String,
    val customerId: String,
    val productId: String,
    val estimatedMaxSats: Long,
    val committedSats: Long = 0L,
    val status: String = "ACTIVE", // ACTIVE, COMMITTED, RELEASED, EXPIRED
    val createdAt: Long = System.currentTimeMillis()
)

// --- 5. Double-Entry Accounting Ledger ---

enum class AccountType {
    LIABILITY_CUSTOMER_PREPAID, // Credit increases customer prepaid balance, Debit decreases (upon usage)
    ASSET_LIGHTNING_NODE,       // Holds incoming settled Lightning funds
    REVENUE_MERCHANT,           // Earned revenue from metered services
    REVENUE_PLATFORM_FEE,       // FluxPay platform fee (e.g. 1-2%)
    CLEARING_ESCROW             // For reserved funds during execution
}

@Entity(
    tableName = "ledger_accounts",
    indices = [Index(value = ["orgId"]), Index(value = ["orgId", "customerId"])]
)
data class LedgerAccount(
    @PrimaryKey val accountId: String,
    val orgId: String,
    val accountType: AccountType,
    val customerId: String? = null, // Set if this is a customer-specific prepaid account
    val name: String,
    val currency: String = "SATS",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ledger_transactions",
    indices = [Index(value = ["orgId"]), Index(value = ["referenceId"])]
)
data class LedgerTransaction(
    @PrimaryKey val transactionId: String,
    val orgId: String,
    val referenceType: String, // "DEPOSIT", "USAGE_CHARGE", "INVOICE_SETTLEMENT", "REFUND"
    val referenceId: String,   // paymentId, eventId, invoiceId
    val description: String,
    val isPosted: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

enum class EntryType {
    DEBIT,
    CREDIT
}

@Entity(
    tableName = "ledger_entries",
    indices = [Index(value = ["transactionId"]), Index(value = ["accountId"])]
)
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val entryId: Long = 0,
    val transactionId: String,
    val accountId: String,
    val entryType: EntryType,
    val amountSats: Long
)

// --- 6. Billing & Invoicing ---

enum class InvoiceStatus {
    DRAFT,
    OPEN,
    FINALISED,
    PAID,
    VOID
}

@Entity(
    tableName = "invoices",
    indices = [Index(value = ["orgId"]), Index(value = ["customerId"])]
)
data class Invoice(
    @PrimaryKey val invoiceId: String,
    val orgId: String,
    val customerId: String,
    val billingPeriod: String, // e.g. "October 2026"
    val subtotalSats: Long,
    val taxSats: Long = 0L,
    val totalSats: Long,
    val amountPaidSats: Long = 0L,
    val status: InvoiceStatus = InvoiceStatus.OPEN,
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000)
)

@Entity(
    tableName = "invoice_line_items",
    indices = [Index(value = ["invoiceId"])]
)
data class InvoiceLineItem(
    @PrimaryKey val lineItemId: String,
    val invoiceId: String,
    val productId: String,
    val description: String,
    val quantity: Long,
    val unit: String,
    val unitRateSats: Double,
    val totalSats: Long
)

// --- 7. Bitcoin Lightning Payments ---

enum class PaymentStatus {
    PENDING,
    SETTLED,
    EXPIRED,
    FAILED
}

@Entity(
    tableName = "lightning_payments",
    indices = [Index(value = ["orgId"]), Index(value = ["paymentHash"]), Index(value = ["customerId"])]
)
data class LightningPayment(
    @PrimaryKey val paymentId: String,
    val orgId: String,
    val customerId: String,
    val amountSats: Long,
    val paymentRequest: String, // "lnbc..."
    val paymentHash: String,
    val preimage: String? = null,
    val status: PaymentStatus = PaymentStatus.PENDING,
    val providerType: String = "MOCK", // "MOCK" or "BTCPAY"
    val memo: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 3600_000L,
    val settledAt: Long? = null
)

// --- 8. Webhook Endpoints & Deliveries ---

@Entity(
    tableName = "webhook_endpoints",
    indices = [Index(value = ["orgId"])]
)
data class WebhookEndpoint(
    @PrimaryKey val endpointId: String,
    val orgId: String,
    val url: String,
    val secretKey: String,
    val enabledEvents: String = "usage.event.accepted,payment.settled,billing.invoice.paid",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "webhook_deliveries",
    indices = [Index(value = ["endpointId"])]
)
data class WebhookDelivery(
    @PrimaryKey val deliveryId: String,
    val endpointId: String,
    val eventType: String,
    val payloadJson: String,
    val httpStatusCode: Int = 200,
    val status: String = "DELIVERED", // DELIVERED, FAILED
    val signatureHeader: String,
    val attemptedAt: Long = System.currentTimeMillis()
)
