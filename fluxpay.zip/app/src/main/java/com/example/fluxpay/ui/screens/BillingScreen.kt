package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.data.model.Invoice
import com.example.fluxpay.data.model.InvoiceLineItem
import com.example.fluxpay.data.model.InvoiceStatus
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun BillingScreen(
    viewModel: FluxPayViewModel
) {
    val invoices by viewModel.invoices.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedInvoiceForDetail by remember { mutableStateOf<Invoice?>(null) }
    var showCreateInvoiceDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Billing Header & Actions ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = ElectricBlue.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Billing & Invoicing",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Prepaid allocations and postpaid statements",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Button(
                        onClick = { showCreateInvoiceDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("create_invoice_button")
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New Invoice", fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. Invoices List ---
        item {
            FintechSectionHeader(
                title = "Customer Invoices (${invoices.size})",
                subtitle = "Itemised usage statements"
            )
        }

        if (invoices.isEmpty()) {
            item {
                Text("No invoices generated yet.", color = TextSecondary, modifier = Modifier.padding(16.dp))
            }
        } else {
            items(invoices) { inv ->
                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = FluxBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = inv.invoiceId,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = inv.status.name)
                            }
                            Text(
                                text = "Customer: ${inv.customerId} • ${inv.billingPeriod}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            SatsAmountText(amountSats = inv.totalSats, fontSize = 14)
                            TextButton(
                                onClick = { selectedInvoiceForDetail = inv },
                                modifier = Modifier.testTag("view_invoice_${inv.invoiceId}")
                            ) {
                                Text("Details →", fontSize = 11.sp, color = ElectricBlueLight)
                            }
                        }
                    }
                }
            }
        }
    }

    // Detail Modal Dialog
    if (selectedInvoiceForDetail != null) {
        val inv = selectedInvoiceForDetail!!
        var lineItems by remember { mutableStateOf<List<InvoiceLineItem>>(emptyList()) }

        LaunchedEffect(inv.invoiceId) {
            coroutineScope.launch {
                lineItems = viewModel.repository.invoiceDao.getLineItems(inv.invoiceId)
            }
        }

        AlertDialog(
            onDismissRequest = { selectedInvoiceForDetail = null },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Invoice ${inv.invoiceId.take(12)}",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    StatusBadge(status = inv.status.name)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Customer: ${inv.customerId}", color = TextSecondary, fontSize = 12.sp)
                    Text("Billing Period: ${inv.billingPeriod}", color = TextSecondary, fontSize = 12.sp)
                    Divider(color = FluxBorder)

                    Text("Line Items:", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 12.sp)
                    lineItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(item.description, color = TextPrimary, fontSize = 12.sp)
                                Text("${item.quantity} ${item.unit} @ ${item.unitRateSats} sats", color = TextTertiary, fontSize = 10.sp)
                            }
                            SatsAmountText(amountSats = item.totalSats, fontSize = 12)
                        }
                    }

                    Divider(color = FluxBorder)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Due", fontWeight = FontWeight.Bold, color = TextPrimary)
                        SatsAmountText(amountSats = inv.totalSats, fontSize = 14)
                    }

                    if (inv.status != InvoiceStatus.PAID) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                viewModel.payInvoice(inv.invoiceId)
                                selectedInvoiceForDetail = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pay_invoice_prepaid_button")
                        ) {
                            Text("Settle From Customer Prepaid Balance", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedInvoiceForDetail = null }) {
                    Text("Close", color = TextSecondary)
                }
            },
            containerColor = FluxSurfaceCard
        )
    }

    // Create Invoice Dialog
    if (showCreateInvoiceDialog) {
        var selectedCustId by remember { mutableStateOf(customers.firstOrNull()?.customerId ?: "") }
        var period by remember { mutableStateOf("October 2026") }

        AlertDialog(
            onDismissRequest = { showCreateInvoiceDialog = false },
            title = { Text("Generate Customer Invoice", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Customer", color = TextSecondary, fontSize = 12.sp)
                    customers.forEach { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (c.customerId == selectedCustId) ElectricBlueDark else FluxSurface)
                                .clickable { selectedCustId = c.customerId }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (c.customerId == selectedCustId),
                                onClick = { selectedCustId = c.customerId }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(c.displayName, color = TextPrimary, fontSize = 12.sp)
                        }
                    }

                    OutlinedTextField(
                        value = period,
                        onValueChange = { period = it },
                        label = { Text("Billing Period") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createInvoiceFromUsage(selectedCustId, period)
                        showCreateInvoiceDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    modifier = Modifier.testTag("confirm_create_invoice")
                ) {
                    Text("Generate")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateInvoiceDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = FluxSurfaceCard
        )
    }
}
