package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*

@Composable
fun OverviewScreen(
    viewModel: FluxPayViewModel,
    onNavigateToTab: (Int) -> Unit
) {
    val totalMetered by viewModel.totalMeteredCharges.collectAsState()
    val totalSettled by viewModel.totalSettledDeposits.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val events by viewModel.usageEvents.collectAsState()
    val transactions by viewModel.ledgerTransactions.collectAsState()
    val environment by viewModel.environment.collectAsState()
    val org by viewModel.currentOrg.collectAsState()
    val reconciliation by viewModel.reconciliationReport.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Top Organization & Environment Banner ---
        item {
            FintechCard(
                backgroundColor = FluxSurface,
                borderColor = if (environment == "TEST") CyanAccent.copy(alpha = 0.5f) else SuccessEmerald.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = org?.name ?: "Acme AI Labs",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (environment == "TEST") CyanAccent.copy(alpha = 0.15f) else SuccessEmerald.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "$environment MODE",
                                    color = if (environment == "TEST") CyanAccent else SuccessEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Text(
                            text = "Universal Micropayments & Metering Engine",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleEnvironment() },
                        modifier = Modifier.testTag("toggle_environment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Switch environment",
                            tint = CyanAccent
                        )
                    }
                }
            }
        }

        // --- 2. Key Business Metrics Grid ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = "Metered Charges",
                        value = "${String.format("%,d", totalMetered)} sats",
                        subtitle = "${events.count { it.status == "ACCEPTED" }} billable calls",
                        icon = Icons.Default.Speed,
                        accentColor = ElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Lightning Settled",
                        value = "${String.format("%,d", totalSettled)} sats",
                        subtitle = "Non-custodial clearing",
                        icon = Icons.Default.Bolt,
                        accentColor = LightningGold,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = "Active Customers",
                        value = "${customers.size}",
                        subtitle = "Autonomous agents & apps",
                        icon = Icons.Default.Group,
                        accentColor = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Ledger Audit",
                        value = if (reconciliation?.isBalanced == false) "DISCREPANCY" else "BALANCED",
                        subtitle = "Double-entry integrity",
                        icon = Icons.Default.AccountBalance,
                        accentColor = if (reconciliation?.isBalanced == false) ErrorRose else SuccessEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // --- 3. Quick Infrastructure Actions ---
        item {
            FintechSectionHeader(title = "Infrastructure Controls")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onNavigateToTab(1) }, // Metering tab
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlueDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_meter_usage")
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Meter Usage", fontSize = 12.sp)
                }

                Button(
                    onClick = { onNavigateToTab(4) }, // Lightning tab
                    colors = ButtonDefaults.buttonColors(containerColor = FluxSurfaceVariant),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_fund_lightning")
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = LightningGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Top Up", fontSize = 12.sp, color = TextPrimary)
                }

                OutlinedButton(
                    onClick = { viewModel.runReconciliation() },
                    shape = RoundedCornerShape(8.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(FluxBorder)),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_run_audit")
                ) {
                    Icon(Icons.Default.FactCheck, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reconcile", fontSize = 12.sp, color = CyanAccent)
                }
            }
        }

        // --- 4. Financial Summary Card ---
        item {
            FintechCard {
                Text(
                    text = "Double-Entry Balance Overview",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Lightning Node Assets", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        SatsAmountText(amountSats = totalSettled, fontSize = 16)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Prepaid Available", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        val available = (totalSettled - totalMetered).coerceAtLeast(0L)
                        SatsAmountText(amountSats = available, fontSize = 16, isPositive = true)
                    }
                }
                Divider(
                    color = FluxBorder,
                    modifier = Modifier.padding(vertical = 12.dp),
                    thickness = 0.5.dp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Ledger Invariant: Sum(Debits) == Sum(Credits)",
                        fontSize = 11.sp,
                        color = TextTertiary
                    )
                    TextButton(onClick = { onNavigateToTab(2) }) { // Ledger tab
                        Text("Inspect Ledger →", fontSize = 11.sp, color = CyanAccent)
                    }
                }
            }
        }

        // --- 5. Live Activity Stream ---
        item {
            FintechSectionHeader(
                title = "Live Metering & Settlement Feed",
                subtitle = "Authoritative ingestion stream"
            )
        }

        if (events.isEmpty() && transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No events recorded yet. Ingest usage to start metering.", color = TextSecondary)
                }
            }
        } else {
            items(events.take(6)) { event ->
                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = FluxBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ElectricBlueDark.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timeline,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = event.customerId,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "${event.quantity} ${event.unit} • ${event.productId}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            SatsAmountText(amountSats = event.calculatedChargeSats, fontSize = 14)
                            StatusBadge(status = event.status)
                        }
                    }
                }
            }
        }
    }
}
