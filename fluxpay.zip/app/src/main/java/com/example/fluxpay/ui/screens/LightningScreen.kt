package com.example.fluxpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxpay.data.model.PaymentStatus
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.components.*
import com.example.ui.theme.*

@Composable
fun LightningScreen(
    viewModel: FluxPayViewModel
) {
    val payments by viewModel.payments.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val clipboard: ClipboardManager = LocalClipboardManager.current

    var selectedCustId by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("10000") }
    var memoText by remember { mutableStateOf("Top-up AI Agent Balance") }

    LaunchedEffect(customers) {
        if (selectedCustId.isEmpty() && customers.isNotEmpty()) {
            selectedCustId = customers.first().customerId
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Lightning Gateway Banner ---
        item {
            FintechCard(
                backgroundColor = FluxSurfaceCard,
                borderColor = LightningGold.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = LightningGold,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Bitcoin Lightning Gateway",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Text(
                            text = "Instant global settlement for metered digital services",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(LightningAmber.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = viewModel.repository.lightningProvider.providerName,
                            color = LightningAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customer Selection Chips
                Text("Select Customer to Fund", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    customers.forEach { c ->
                        val isSelected = (c.customerId == selectedCustId)
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCustId = c.customerId },
                            label = { Text(c.displayName.take(16), fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBlueDark,
                                selectedLabelColor = TextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount and Quick Presets
                Text("Amount (Satoshis)", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(5000L, 10000L, 25000L, 50000L).forEach { preset ->
                        AssistChip(
                            onClick = { amountText = preset.toString() },
                            label = { Text("${preset / 1000}k sats", fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount in sats") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_lightning_amount"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LightningGold,
                        unfocusedBorderColor = FluxBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = memoText,
                    onValueChange = { memoText = it },
                    label = { Text("Memo / Reference") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val sats = amountText.toLongOrNull() ?: 5000L
                        viewModel.createLightningTopUp(selectedCustId, sats, memoText)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LightningGold),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_lightning_invoice_button")
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = null, tint = androidx.compose.ui.graphics.Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate Lightning Invoice", fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.Black)
                }
            }
        }

        // --- 2. Invoices & Settlements List ---
        item {
            FintechSectionHeader(
                title = "Settlement Queue (${payments.size})",
                subtitle = "Active invoices & payment history"
            )
        }

        if (payments.isEmpty()) {
            item {
                Text("No payments found.", color = TextSecondary, modifier = Modifier.padding(16.dp))
            }
        } else {
            items(payments) { p ->
                FintechCard(
                    backgroundColor = FluxSurfaceCard,
                    borderColor = if (p.status == PaymentStatus.PENDING) LightningGold.copy(alpha = 0.5f) else FluxBorder
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = p.paymentId,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = LightningGold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusBadge(status = p.status.name)
                                }
                                Text(
                                    text = "${p.customerId} • ${p.memo}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            SatsAmountText(amountSats = p.amountSats, fontSize = 16)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // BOLT11 Invoice String snippet box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(FluxBackground)
                                .clickable { clipboard.setText(AnnotatedString(p.paymentRequest)) }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = p.paymentRequest.take(38) + "...",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = CyanAccent
                            )
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy invoice",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        if (p.status == PaymentStatus.PENDING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.settleLightningPayment(p.paymentHash) },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("simulate_settlement_${p.paymentId}")
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Simulate Wallet Payment Settlement", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else if (p.preimage != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Preimage: ${p.preimage.take(24)}...",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = TextTertiary
                            )
                        }
                    }
                }
            }
        }
    }
}
