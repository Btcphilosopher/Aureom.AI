package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.fluxpay.data.local.FluxPayDatabase
import com.example.fluxpay.data.repository.FluxPayRepository
import com.example.fluxpay.ui.FluxPayApp
import com.example.fluxpay.ui.FluxPayViewModel
import com.example.fluxpay.ui.FluxPayViewModelFactory
import com.example.ui.theme.FluxPayTheme

class MainActivity : ComponentActivity() {

    private val viewModel: FluxPayViewModel by viewModels {
        val database = FluxPayDatabase.getInstance(applicationContext)
        val repository = FluxPayRepository(database)
        FluxPayViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FluxPayTheme {
                FluxPayApp(viewModel = viewModel)
            }
        }
    }
}
