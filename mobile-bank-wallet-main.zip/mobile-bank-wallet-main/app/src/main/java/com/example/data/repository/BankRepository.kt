package com.example.data.repository

import com.example.data.dao.BankDao
import com.example.data.entities.Account
import com.example.data.entities.Transaction
import com.example.data.entities.WatchlistItem
import com.example.data.entities.ChatHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class BankRepository(private val bankDao: BankDao) {

    val allAccounts: Flow<List<Account>> = bankDao.getAllAccounts()
    val allTransactions: Flow<List<Transaction>> = bankDao.getAllTransactions()
    val watchlistItems: Flow<List<WatchlistItem>> = bankDao.getWatchlistItems()
    val chatHistory: Flow<List<ChatHistory>> = bankDao.getChatHistory()

    fun getTransactionsForAccount(accountId: String): Flow<List<Transaction>> =
        bankDao.getTransactionsForAccount(accountId)

    suspend fun getAccountById(id: String): Account? = withContext(Dispatchers.IO) {
        bankDao.getAccountById(id)
    }

    suspend fun insertAccount(account: Account) = withContext(Dispatchers.IO) {
        bankDao.insertAccount(account)
    }

    suspend fun updateAccount(account: Account) = withContext(Dispatchers.IO) {
        bankDao.updateAccount(account)
    }

    suspend fun insertTransaction(transaction: Transaction) = withContext(Dispatchers.IO) {
        bankDao.insertTransaction(transaction)
    }

    suspend fun insertChatMessage(sender: String, message: String) = withContext(Dispatchers.IO) {
        bankDao.insertChatMessage(ChatHistory(sender = sender, message = message))
    }

    suspend fun clearChatHistory() = withContext(Dispatchers.IO) {
        bankDao.clearChatHistory()
    }

    suspend fun clearAllTransactions() = withContext(Dispatchers.IO) {
        bankDao.clearAllTransactions()
    }

    suspend fun checkAndSeedDatabase() = withContext(Dispatchers.IO) {
        // Seed default accounts if empty
        val currentAccounts = bankDao.getAllAccounts().first()
        if (currentAccounts.isEmpty()) {
            val defaultAccounts = listOf(
                Account(
                    id = "current",
                    name = "Aero Current Account",
                    balance = 12450.80,
                    type = "CURRENT",
                    cardFrozen = false,
                    dailyLimit = 2500.0,
                    accountNo = "GB82 AERO 4004 0411 9022",
                    interestRate = 0.0
                ),
                Account(
                    id = "savings",
                    name = "Vault Quantum Goal",
                    balance = 35120.00,
                    type = "SAVINGS",
                    cardFrozen = false,
                    dailyLimit = 5000.0,
                    accountNo = "GB82 AERO 2002 0111 9484",
                    interestRate = 4.5
                ),
                Account(
                    id = "investment",
                    name = "Aero High-Growth Wallet",
                    balance = 8940.40,
                    type = "INVESTMENT",
                    cardFrozen = false,
                    dailyLimit = 10000.0,
                    accountNo = "GB82 AERO 7007 0711 7434",
                    interestRate = 0.0
                )
            )
            bankDao.insertAccounts(defaultAccounts)

            // Seed default transactions
            val now = System.currentTimeMillis()
            val dayMs = 24 * 60 * 60 * 1000L
            val defaultTransactions = listOf(
                Transaction(
                    accountId = "current",
                    title = "Salary AeroTech Corp",
                    amount = 4200.00,
                    category = "income",
                    timestamp = now - (0.1 * dayMs).toLong(),
                    reference = "REF-SALARY-AEROTECH",
                    isOutflow = false
                ),
                Transaction(
                    accountId = "current",
                    title = "Whole Foods Market",
                    amount = 54.30,
                    category = "food",
                    timestamp = now - (0.5 * dayMs).toLong(),
                    reference = "WFM-RETAIL-0824",
                    isOutflow = true
                ),
                Transaction(
                    accountId = "current",
                    title = "Uber Ride Central",
                    amount = 18.50,
                    category = "transport",
                    timestamp = now - (1.2 * dayMs).toLong(),
                    reference = "UBER-TX-99120",
                    isOutflow = true
                ),
                Transaction(
                    accountId = "current",
                    title = "Netflix Hologram",
                    amount = 10.99,
                    category = "subscriptions",
                    timestamp = now - (2 * dayMs).toLong(),
                    reference = "NETFLIX-MEMBER-NET",
                    isOutflow = true
                ),
                Transaction(
                    accountId = "current",
                    title = "Google Cloud CloudVibe",
                    amount = 143.20,
                    category = "utilities",
                    timestamp = now - (3.1 * dayMs).toLong(),
                    reference = "GCP-COMPUTE-71B",
                    isOutflow = true
                ),
                Transaction(
                    accountId = "current",
                    title = "Spotify Quantum Audio",
                    amount = 11.99,
                    category = "subscriptions",
                    timestamp = now - (4 * dayMs).toLong(),
                    reference = "SPOTIFY-PREMIUM-OFF",
                    isOutflow = true
                ),
                Transaction(
                    accountId = "current",
                    title = "Weekly Interest Payout",
                    amount = 29.80,
                    category = "income",
                    timestamp = now - (5 * dayMs).toLong(),
                    reference = "AERO-INTEREST-V01-SAVINGS",
                    isOutflow = false
                ),
                // Savings goal movements
                Transaction(
                    accountId = "savings",
                    title = "Auto-Vault Sweeper",
                    amount = 50.00,
                    category = "transfers",
                    timestamp = now - (1 * dayMs).toLong(),
                    reference = "SWEEP-CURRENT-TO-SAVINGS",
                    isOutflow = false
                ),
                Transaction(
                    accountId = "savings",
                    title = "Interest Earned compounding",
                    amount = 131.70,
                    category = "income",
                    timestamp = now - (20 * dayMs).toLong(),
                    reference = "APY-COMPOUND-PAY",
                    isOutflow = false
                ),
                // Investments
                Transaction(
                    accountId = "investment",
                    title = "TSLA Stock Allocation",
                    amount = 250.00,
                    category = "investment",
                    timestamp = now - (4.5 * dayMs).toLong(),
                    reference = "AERO-TRADE-STOCK-TSLA",
                    isOutflow = true
                )
            )
            bankDao.insertTransactions(defaultTransactions)

            // Seed default watchlist assets (stocks + crypto)
            val defaultWatchlist = listOf(
                WatchlistItem("BTC", "Bitcoin Ledger", 88230.12, 4.25, "CRYPTO", false),
                WatchlistItem("ETH", "Ethereum Core", 3450.45, -1.80, "CRYPTO", false),
                WatchlistItem("SOL", "Solana Quantum", 165.20, 12.42, "CRYPTO", false),
                WatchlistItem("TSLA", "Tesla Robotics", 210.45, 1.82, "STOCK", false),
                WatchlistItem("NVDA", "Nvidia Neural Core", 475.20, 8.34, "STOCK", false),
                WatchlistItem("AAPL", "Apple Spatial Ltd", 182.30, -0.42, "STOCK", false),
                // Suggested assets (AI-driven suggested toggle)
                WatchlistItem("AVAX", "Avalanche Node", 32.80, 5.12, "CRYPTO", true),
                WatchlistItem("MSFT", "Microsoft Azure AI", 420.15, 2.30, "STOCK", true)
            )
            bankDao.insertWatchlistItems(defaultWatchlist)

            // Seed Initial Chat Assistant greeting
            bankDao.insertChatMessage(ChatHistory(
                sender = "AI",
                message = "Greetings, Pilot. Aether Bank AI systems are online. Ask me about your current balances, spending diagnostics, or if you can afford a purchase such as a £1,200 flight or laptop. I am standing by.",
                timestamp = now - (1 * dayMs).toLong()
            ))
        }
    }
}
