package com.example.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey val id: String,
    val name: String,
    val balance: Double,
    val type: String, // CURRENT, SAVINGS, INVESTMENT
    val cardFrozen: Boolean = false,
    val dailyLimit: Double = 2000.0,
    val accountNo: String,
    val interestRate: Double = 0.0 // interest earned rate, e.g. 4.5%
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val accountId: String,
    val title: String,
    val amount: Double,
    val category: String, // food, transport, subscriptions, utilities, investment, etc.
    val timestamp: Long,
    val reference: String,
    val isOutflow: Boolean // true for spent, false for incoming
)

@Entity(tableName = "watchlist_items")
data class WatchlistItem(
    @PrimaryKey val symbol: String,
    val name: String,
    val price: Double,
    val changePercent: Double,
    val assetType: String, // STOCK, CRYPTO
    val isSuggested: Boolean = false // Suggested asset or user added
)

@Entity(tableName = "chat_history")
data class ChatHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String, // USER, AI
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)
