package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.screens.MainCompositeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BankViewModel
import com.example.viewmodel.BankViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: BankViewModel by viewModels {
        BankViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup edge-to-edge full screen support
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    MainCompositeScreen(viewModel = viewModel)
                }
            }
        }
    }
}
