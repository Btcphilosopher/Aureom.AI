package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entities.Account
import com.example.data.entities.Transaction
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.BankViewModel
import kotlinx.coroutines.launch

@Composable
fun MainCompositeScreen(
    viewModel: BankViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateFlowOf("home") } // home, accounts, payments, analytics, portfolio, ai, settings
    var isOnboardingComplete by remember { mutableStateOf(false) }

    if (!isOnboardingComplete) {
        SplashOnboarding(onOnboardingFinished = { isOnboardingComplete = true })
    } else {
        Scaffold(
            bottomBar = {
                FintechBottomNavigation(
                    currentTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            },
            containerColor = Color.Transparent,
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            CyberBackground {
                Box(modifier = Modifier.padding(innerPadding)) {
                    when (currentTab) {
                        "home" -> FintechDashboardScreen(viewModel, onNavigateToTab = { currentTab = it })
                        "accounts" -> FintechAccountsScreen(viewModel)
                        "payments" -> FintechPaymentsScreen(viewModel)
                        "analytics" -> FintechAnalyticsScreen(viewModel)
                        "portfolio" -> FintechPortfolioScreen(viewModel)
                        "ai" -> FintechAiAssistantScreen(viewModel)
                        "settings" -> FintechSettingsScreen(viewModel)
                    }
                }
            }
        }
    }
}

// --- UTILITY: HELPER FOR MUTABLE STATE MUTATORS ---
fun <T> mutableStateFlowOf(value: T) = mutableStateOf(value)

// --- SCREEN 1: SPLASH & ONBOARDING ---
@Composable
fun SplashOnboarding(
    onOnboardingFinished: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) } // 0 = Splash, 1 = Spend page, 2 = Transfer page, 3 = Portfolio, 4 = AI Coach
    val scale = remember { Animatable(0f) }
    
    LaunchedEffect(key1 = true) {
        scale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        )
    }

    CyberBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
            ) {
            Spacer(modifier = Modifier.height(30.dp))

            if (step == 0) {
                // Animated Splash Core Logo
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .border(2.dp, ElectricBlue, CircleShape)
                            .padding(12.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(ElectricBlue.copy(0.2f), Color.Transparent))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cyclone,
                            contentDescription = "Aero Bank",
                            tint = ElectricBlue,
                            modifier = Modifier.size(70.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "AERO BANK",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 6.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "“Money, but intelligent.”",
                        style = MaterialTheme.typography.titleMedium,
                        color = SlateGlow,
                        letterSpacing = 1.sp
                    )
                }

                NeonButton(
                    onClick = { step = 1 },
                    text = "Boot Systems",
                    neonColor = ElectricBlue,
                    modifier = Modifier.fillMaxWidth().testTag("boot_systems_button")
                )
            } else {
                // Interactive Onboarding slides
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .border(1.dp, NeonGreen, CircleShape)
                            .background(NeonGreen.copy(0.05f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when(step) {
                                1 -> Icons.Default.QueryStats
                                2 -> Icons.AutoMirrored.Filled.Send
                                3 -> Icons.Default.CurrencyBitcoin
                                else -> Icons.Default.Insights
                            },
                            contentDescription = "Onboarding Icon",
                            tint = NeonGreen,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = when(step) {
                            1 -> "SPEND INTELLIGENCE"
                            2 -> "INSTANT TRANSFER VECTOR"
                            3 -> "MULTI-ASSET COMPENSATOR"
                            else -> "VIBE FINANCIAL ASSISTANT"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = when(step) {
                            1 -> "Analyze all outflows. Track utilities, subscriptions, and general card spends with deep neural categorizations instantly."
                            2 -> "Transmit assets directly, internal vault sweeping or cross-border LEDGER routing. Secure, instant and frictionless."
                            3 -> "Pilot a hybrid portfolio tracking crypto aggregates alongside global stock market movements inside a unified dashboard cockpit."
                            else -> "Ask your Vibe Assistant to test immediate laptop purchases, run monthly projections, predict balances, or optimize savings."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateGlow,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (step > 1) {
                        OutlinedButton(
                            onClick = { step-- },
                            border = BorderStroke(1.dp, GlassBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BACK")
                        }
                    }

                    NeonButton(
                        onClick = {
                            if (step < 4) step++ else onOnboardingFinished()
                        },
                        text = if (step == 4) "ACTIVATE COCKPIT" else "CONTINUE",
                        neonColor = if (step == 4) ElectricBlue else NeonGreen,
                        modifier = Modifier.weight(1f).testTag("onboarding_continue_button")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 2: HOME DASHBOARD (MAIN HUB) ---
@Composable
fun FintechDashboardScreen(
    viewModel: BankViewModel,
    onNavigateToTab: (String) -> Unit
) {
    val totalBalance by viewModel.totalBalance.collectAsStateWithLifecycle()
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Wallet Cockpit", subtitle = "UTC: 12:00")
        }

        // Aggregate Balance Card
        item {
            GlassCard(glowColor = ElectricBlue) {
                Text(
                    text = "AGGREGATED TOTAL BALANCE",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "£${"%,.2f".format(totalBalance)}",
                    style = MaterialTheme.typography.displayLarge,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(modifier = Modifier.size(8.dp).background(NeonGreen, RoundedCornerShape(50)))
                        Text("Active Accounts: ${accounts.size}", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                    }
                    Text("SECURE AES-256 ENCRYPTED", style = MaterialTheme.typography.labelSmall, color = NeonGreen.copy(0.8f))
                }
            }
        }

        // Quick Actions Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Send Action
                Button(
                    onClick = { onNavigateToTab("payments") },
                    modifier = Modifier.weight(1f).testTag("action_send"),
                    colors = ButtonDefaults.buttonColors(containerColor = GlassCard),
                    border = BorderStroke(0.5.dp, GlassBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send Money", tint = ElectricBlue)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("SEND", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }

                // AI Portfolio Action
                Button(
                    onClick = { onNavigateToTab("portfolio") },
                    modifier = Modifier.weight(1f).testTag("action_invest"),
                    colors = ButtonDefaults.buttonColors(containerColor = GlassCard),
                    border = BorderStroke(0.5.dp, GlassBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ShowChart, contentDescription = "Invest Portal", tint = NeonGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("INVEST", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }

                // AI assistant
                Button(
                    onClick = { onNavigateToTab("ai") },
                    modifier = Modifier.weight(1f).testTag("action_ai"),
                    colors = ButtonDefaults.buttonColors(containerColor = GlassCard),
                    border = BorderStroke(0.5.dp, GlassBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ChatBubbleOutline, contentDescription = "Vibe Assistant", tint = CyberAmber)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("AI VIBE", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }
        }

        // Active AI Insight Card
        item {
            GlassCard(glowColor = CyberAmber) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TipsAndUpdates,
                        contentDescription = "AI Insights",
                        tint = CyberAmber,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "ACTIVE INTELLIGENCE NUDGE",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberAmber,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Aero Neural diagnostics show £22.98 spent on subscriptions. Switching utilities could sweep £42.00/mo directly into savings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WhiteLight,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "TAP TO RUN ANALYSIS ON AI ASSISTANT",
                    color = ElectricBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToTab("ai") }
                        .padding(top = 6.dp)
                )
            }
        }

        // Recent Transaction Header
        item {
            Text(
                "RECENT MOVEMENT LOGS",
                style = MaterialTheme.typography.labelSmall,
                color = SlateGlow,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Recent Transactions Feed
        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "No recorded logs active",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateGlow,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(transactions.take(5)) { tx ->
                TransactionRow(tx = tx)
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 3: ACCOUNTS SCREEN ---
@Composable
fun FintechAccountsScreen(
    viewModel: BankViewModel
) {
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val selectedAccountId by viewModel.selectedAccountId.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeSelectedAccount.collectAsStateWithLifecycle()
    val chartPeriod by viewModel.chartPeriod.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    
    val selectedAccountTransactions by remember(selectedAccountId) {
        derivedStateOf {
            viewModel.transactions.value.filter { it.accountId == selectedAccountId }
        }
    }

    // High fidelity historical graph tracking curves based on period selection
    val activeHistoryPoints = remember(selectedAccountId, chartPeriod) {
        when(chartPeriod) {
            "1D" -> listOf(10200f, 10220f, 10180f, 10300f, 10280f, 10450f)
            "1W" -> listOf(9800f, 10100f, 9950f, 10200f, 10350f, 10450f)
            "1Y" -> listOf(5000f, 7500f, 8200f, 9100f, 10350f, 10450f)
            else -> { // "1M" (default)
                if (selectedAccountId == "savings") {
                    listOf(35000f, 35040f, 35080f, 35100f, 35120f)
                } else if (selectedAccountId == "investment") {
                    listOf(8200f, 8500f, 8100f, 8600f, 8940.40f)
                } else {
                    listOf(11500f, 12100f, 11900f, 12200f, 12450.80f)
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Asset Ledger", subtitle = "Telemetry")
        }

        // Horizontal Accounts List
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(accounts) { acc ->
                    val isSelected = acc.id == selectedAccountId
                    Card(
                        modifier = Modifier
                            .width(280.dp)
                            .clickable { viewModel.selectAccountId(acc.id) }
                            .testTag("account_card_${acc.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) CarbonNavy else GlassCard
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) ElectricBlue else GlassBorder
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                acc.name.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) ElectricBlue else SlateGlow,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                "£${"%,.2f".format(acc.balance)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "RATE: ${acc.interestRate}% APY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (acc.interestRate > 0) NeonGreen else SlateGlow
                                )
                                Text(
                                    text = acc.accountNo.takeLast(4).padStart(8, '•'),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SlateGlow
                                )
                            }
                        }
                    }
                }
            }
        }

        // Detailed Selected Account Information Panel
        activeAccount?.let { acc ->
            item {
                GlassCard(glowColor = ElectricBlue) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("LEDGER: " + acc.name.uppercase(), style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "£${"%,.2f".format(acc.balance)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Chart Period Timeline Selector
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("1D", "1W", "1M", "1Y").forEach { period ->
                                val active = period == chartPeriod
                                Text(
                                    text = period,
                                    modifier = Modifier
                                        .clickable { viewModel.setChartPeriod(period) }
                                        .background(
                                            if (active) ElectricBlue.copy(0.12f) else Color.Transparent,
                                            RoundedCornerShape(4.dp)
                                        )
                                        .border(
                                            0.5.dp,
                                            if (active) ElectricBlue else Color.Transparent,
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (active) ElectricBlue else SlateGlow
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Line Graph representing Balance performance
                    LineGraph(
                        points = activeHistoryPoints,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("YIELD TO DATE ACCRUED", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                        Text(
                            text = if (acc.interestRate > 0) "+£131.70" else "£0.00",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (acc.interestRate > 0) NeonGreen else SlateGlow
                        )
                    }
                }
            }
        }

        // Selected Account Specific Transaction logs
        item {
            Text(
                "SPECIFIC LEDGER LOGS",
                style = MaterialTheme.typography.labelSmall,
                color = SlateGlow,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (selectedAccountTransactions.isEmpty()) {
            item {
                Text(
                    text = "No transactions tracked for this ledger node",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateGlow,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(selectedAccountTransactions) { tx ->
                TransactionRow(tx = tx)
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 4: INSTANT PAYMENTS / TRANSFERS ---
@Composable
fun FintechPaymentsScreen(
    viewModel: BankViewModel
) {
    val recipient by viewModel.transferRecipient.collectAsStateWithLifecycle()
    val amount by viewModel.transferAmount.collectAsStateWithLifecycle()
    val category by viewModel.transferCategory.collectAsStateWithLifecycle()
    val statusMsg by viewModel.transferStatus.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeSelectedAccount.collectAsStateWithLifecycle()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Contacts Quick Fill lists
    val quickContacts = listOf("Vault Goal", "Investment High", "Robert G", "Alex Velo", "Sarah Mon")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Transfer Vector", subtitle = "Direct Send")
        }

        // Quick contacts sliders
        item {
            Column {
                Text(
                    "SUGGESTED TARGET CORRIDORS",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(quickContacts) { rcp ->
                        Card(
                            modifier = Modifier
                                .clickable {
                                    viewModel.updateRecipient(rcp)
                                    // Set category automatically for internal sweeps!
                                    if (rcp.contains("Vault") || rcp.contains("Savings")) {
                                        viewModel.updateCategory("transfers")
                                    } else if (rcp.contains("Investment") || rcp.contains("High")) {
                                        viewModel.updateCategory("investment")
                                    } else {
                                        viewModel.updateCategory("transfers")
                                    }
                                }
                                .testTag("contact_$rcp"),
                            colors = CardDefaults.cardColors(containerColor = GlassCard),
                            border = BorderStroke(0.5.dp, GlassBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(ElectricBlue.copy(alpha = 0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = rcp.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // Ledger Transmission Form
        item {
            GlassCard(glowColor = ElectricBlue) {
                Text(
                    "LEDGER TRANSLATOR",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.25.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // Recipient
                Text("RECIPIENT CORRIDOR", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                Spacer(modifier = Modifier.height(4.dp))
                TextField(
                    value = recipient,
                    onValueChange = { viewModel.updateRecipient(it) },
                    modifier = Modifier.fillMaxWidth().testTag("input_recipient"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = GlassCard,
                        unfocusedContainerColor = GlassCard,
                        disabledContainerColor = GlassCard,
                        focusedIndicatorColor = ElectricBlue,
                        unfocusedIndicatorColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    placeholder = { Text("E.g. Alex Velo or Vault Savings", color = SlateGlow, fontSize = 14.sp) },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Amount
                Text("QUANTITY TO TRANSMIT (£)", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                Spacer(modifier = Modifier.height(4.dp))
                TextField(
                    value = amount,
                    onValueChange = { viewModel.updateAmount(it) },
                    modifier = Modifier.fillMaxWidth().testTag("input_amount"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = GlassCard,
                        unfocusedContainerColor = GlassCard,
                        disabledContainerColor = GlassCard,
                        focusedIndicatorColor = ElectricBlue,
                        unfocusedIndicatorColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("E.g. 150.00", color = SlateGlow, fontSize = 14.sp) },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Category Selection
                Text("DISBURSEMENT CATEGORY", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val categories = listOf("food", "transport", "subscriptions", "utilities", "investment", "transfers")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { cat ->
                            val active = category == cat
                            Text(
                                text = cat.uppercase(),
                                modifier = Modifier
                                    .clickable { viewModel.updateCategory(cat) }
                                    .background(
                                        if (active) ElectricBlue.copy(0.12f) else Color.Transparent,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .border(
                                        0.5.dp,
                                        if (active) ElectricBlue else GlassBorder,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (active) ElectricBlue else SlateGlow
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Transmit Action Button
                NeonButton(
                    onClick = {
                        keyboardController?.hide()
                        viewModel.executeInstantTransfer {
                            // Reset keyboard or clear focus if needed
                        }
                    },
                    text = "TRANSMIT ASSETS NOW",
                    neonColor = ElectricBlue,
                    modifier = Modifier.fillMaxWidth().testTag("action_execute_transfer"),
                    enabled = activeAccount?.cardFrozen == false
                )

                if (activeAccount?.cardFrozen == true) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "ERROR: LEDGER FROZEN. Disable card freeze in settings first.",
                        color = HotPink,
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                statusMsg?.let { msg ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (msg.contains("ERROR")) HotPink.copy(0.1f) else NeonGreen.copy(0.1f)
                        ),
                        border = BorderStroke(
                            0.5.dp,
                            if (msg.contains("ERROR")) HotPink else NeonGreen
                        )
                    ) {
                        Text(
                            text = msg,
                            color = if (msg.contains("ERROR")) HotPink else NeonGreen,
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Simulated QR Code Payment Generator
        item {
            GlassCard(glowColor = NeonGreen) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = NeonGreen)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("ORBIT TRANSMISSION: SCAN", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                        Text("Hold camera to screen or export QR code tag.", style = MaterialTheme.typography.bodyMedium, color = WhiteLight)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 5: ANALYTICS / SPENDING INTELLIGENCE ---
@Composable
fun FintechAnalyticsScreen(
    viewModel: BankViewModel
) {
    val categorySpendSummary by viewModel.categorySpendSummary.collectAsStateWithLifecycle()
    var sliderState by remember { mutableStateOf(1f) } // Month comparison slider

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Neural Spend", subtitle = "Diagnostics")
        }

        // Native Arc Graphic Pie Chart representation
        item {
            GlassCard(glowColor = ElectricBlue) {
                Text(
                    text = "CATEGORY OUTFLOW ALLOCATION INDEX",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                CanvasArcChart(
                    data = categorySpendSummary,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Slider Comparing Spending compared to other Months
        item {
            GlassCard(glowColor = CyberAmber) {
                Text("HISTORICAL COMPARATIVE REGISTRY", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Telemetry Scale Period Multiplier: ${"%.1f".format(sliderState)}x",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                    Text(
                        text = if (sliderState > 1.2f) "LEAKAGE ALERT" else "NORMAL VECTOR",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sliderState > 1.2f) HotPink else NeonGreen
                    )
                }
                
                Slider(
                    value = sliderState,
                    onValueChange = { sliderState = it },
                    valueRange = 0.5f..2.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricBlue,
                        activeTrackColor = ElectricBlue,
                        inactiveTrackColor = SlateGlow.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("analytics_slider")
                )

                Spacer(modifier = Modifier.height(4.dp))
                val baseline = 243.99
                Text(
                    text = "Simulated delta comparison output: Account spent £${"%.2f".format(baseline * sliderState)} comparative to past average baseline £${"%.2f".format(baseline)}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateGlow
                )
            }
        }

        // Leak Detection Systems
        item {
            GlassCard(glowColor = HotPink) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = HotPink)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("VELO SYSTEM LEAK DETECTION", style = MaterialTheme.typography.labelSmall, color = HotPink, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "• DUPLICATE SUSPECT: 2 Streaming provider logs active (Netflix & Spotify detected). Possible leakage vector of £22.98/mo.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WhiteLight
                    )
                    Text(
                        "• HEAVY CONCORD DELTA: Dining & Food sector delta is £${"%.2f".format(categorySpendSummary["food"] ?: 54.30)}, trending as highly active.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WhiteLight
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 6: INVESTMENTS / PORTFOLIO ---
@Composable
fun FintechPortfolioScreen(
    viewModel: BankViewModel
) {
    val watchlistItems by viewModel.watchlistItems.collectAsStateWithLifecycle()
    val showSuggested by viewModel.showSuggestedAssets.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeSelectedAccount.collectAsStateWithLifecycle()

    val filteredList = remember(watchlistItems, showSuggested) {
        watchlistItems.filter { it.isSuggested == showSuggested }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Markets Core", subtitle = "Assets")
        }

        // Suggested toggle filter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showSuggested) "AI RECOMMENDED WATCHLIST" else "PRIMARY WATCHLISTS ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Show Suggestions",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (showSuggested) ElectricBlue else SlateGlow,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Switch(
                        checked = showSuggested,
                        onCheckedChange = { viewModel.toggleSuggestedAssets() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricBlue,
                            checkedTrackColor = ElectricBlue.copy(0.3f),
                            uncheckedThumbColor = SlateGlow,
                            uncheckedTrackColor = Color.Transparent
                        ),
                        modifier = Modifier.testTag("suggestions_switch")
                    )
                }
            }
        }

        // Active List Items representing Stocks + Cryptos
        items(filteredList) { item ->
            GlassCard(glowColor = if (item.changePercent > 0) NeonGreen else HotPink) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = item.symbol,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = SlateGlow
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$${"%,.2f".format(item.price)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (item.changePercent > 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = if (item.changePercent > 0) NeonGreen else HotPink,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${if (item.changePercent > 0) "+" else ""}${"%.2f".format(item.changePercent)}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (item.changePercent > 0) NeonGreen else HotPink
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- SCREEN 7: AI FINANCIAL ASSISTANT (“VIBE AI”) ---
@Composable
fun FintechAiAssistantScreen(
    viewModel: BankViewModel
) {
    val chatHistory by viewModel.chatHistoryFlow.collectAsStateWithLifecycle()
    val loading by viewModel.aiResponseLoading.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Scroll to bottom of chat automatically when history loads or updates
    LaunchedEffect(chatHistory.size) {
        if (chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(chatHistory.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        AeroHeader(title = "Aero Core AI", subtitle = "Active")

        // Interactive diagnostic purge button
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("AI DIAGNOSTIC CONSOLE LOGS", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
            Text(
                "CLEAR COREG",
                style = MaterialTheme.typography.labelSmall,
                color = HotPink,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { viewModel.clearChat() }
                    .padding(4.dp)
                    .testTag("btn_clear_chat")
            )
        }

        // Chat Bubble Scroll Area
        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(chatHistory) { msg ->
                    val isUser = msg.sender == "USER"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Card(
                            modifier = Modifier
                                .widthIn(max = 300.dp)
                                .border(
                                    0.5.dp,
                                    if (isUser) ElectricBlue.copy(0.4f) else GlassBorder,
                                    RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isUser) 16.dp else 4.dp,
                                        bottomEnd = if (isUser) 4.dp else 16.dp
                                    )
                                ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) ElectricBlue.copy(0.08f) else GlassCard
                            ),
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isUser) "CLIENT INPUT SOURCE" else "AERO CORE INTERFACE OUTPUT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isUser) ElectricBlue else NeonGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = msg.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WhiteLight,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                }

                if (loading) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Card(
                                modifier = Modifier
                                    .widthIn(max = 180.dp)
                                    .border(0.5.dp, CyberAmber.copy(0.3f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = GlassCard)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = CyberAmber,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "COMPILING VECTOR...",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberAmber
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Text input form for prompt transmissions!
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .navigationBarsPadding(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = inputQuery,
                onValueChange = { inputQuery = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = GlassCard,
                    unfocusedContainerColor = GlassCard,
                    focusedIndicatorColor = ElectricBlue,
                    unfocusedIndicatorColor = GlassBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                placeholder = { Text("E.g Can I afford a £1,200 laptop?", color = SlateGlow, fontSize = 13.sp) },
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (inputQuery.trim().isNotEmpty()) {
                        keyboardController?.hide()
                        viewModel.sendMessageToAi(inputQuery)
                        inputQuery = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(ElectricBlue.copy(0.12f), RoundedCornerShape(12.dp))
                    .border(0.5.dp, ElectricBlue, RoundedCornerShape(12.dp))
                    .testTag("btn_send_ai"),
                enabled = !loading
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send Prompt",
                    tint = ElectricBlue
                )
            }
        }
    }
}


// --- SCREEN 8: SETTINGS & SECURITY ---
@Composable
fun FintechSettingsScreen(
    viewModel: BankViewModel
) {
    val limits by viewModel.dailySpendLimit.collectAsStateWithLifecycle()
    val isNotificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val isBiometricsEnabled by viewModel.biometricEnabled.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeSelectedAccount.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AeroHeader(title = "Aero Protection", subtitle = "Security")
        }

        // Card freeze toggle! Updates Room state in real time.
        item {
            GlassCard(glowColor = if (activeAccount?.cardFrozen == true) HotPink else NeonGreen) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (activeAccount?.cardFrozen == true) "AERO CARD FROZEN" else "AERO DIRECT CARD ACTIVE",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (activeAccount?.cardFrozen == true) HotPink else NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Lock or unfreeze ledger communications on account GB82-AERO-4004 instantly.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateGlow
                        )
                    }
                    Switch(
                        checked = activeAccount?.cardFrozen == true,
                        onCheckedChange = { viewModel.toggleCardFreeze("current") },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = HotPink,
                            checkedTrackColor = HotPink.copy(0.3f),
                            uncheckedThumbColor = NeonGreen,
                            uncheckedTrackColor = NeonGreen.copy(0.12f)
                        ),
                        modifier = Modifier.testTag("card_freeze_switch")
                    )
                }
            }
        }

        // Spending Limits Adjustable Sliders
        item {
            GlassCard(glowColor = ElectricBlue) {
                Text(
                    "ADJUST DAILY TRANSMISSION LIMITS",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGlow
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Current Max Cap: £${"%,d".format(limits.toInt())}",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Delta Cap", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                }

                Slider(
                    value = limits,
                    onValueChange = { viewModel.updateSpendLimit(it) },
                    valueRange = 500f..5000f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricBlue,
                        activeTrackColor = ElectricBlue
                    ),
                    modifier = Modifier.testTag("limits_slider")
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Your cards and transmissions will reject any outwards payment vectors that bypass this limit threshold.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateGlow
                )
            }
        }

        // Biometrics + Notifications configuration
        item {
            GlassCard(glowColor = SlateGlow) {
                Text("COCKPIT BROADCAST CONTROLS", style = MaterialTheme.typography.labelSmall, color = SlateGlow)
                Spacer(modifier = Modifier.height(14.dp))
                
                // Notifications
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Instant Push Notifications", style = MaterialTheme.typography.bodyLarge, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Broadcast transaction deltas instantly.", style = MaterialTheme.typography.bodyMedium, color = SlateGlow)
                    }
                    Switch(
                        checked = isNotificationsEnabled,
                        onCheckedChange = { viewModel.toggleNotifications() },
                        colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue),
                        modifier = Modifier.testTag("notifications_switch")
                    )
                }

                Divider(color = GlassBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Biometrics
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Neural Biometric Signatures", style = MaterialTheme.typography.bodyLarge, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Execute logins via fingerprint or facial scans.", style = MaterialTheme.typography.bodyMedium, color = SlateGlow)
                    }
                    Switch(
                        checked = isBiometricsEnabled,
                        onCheckedChange = { viewModel.toggleBiometrics() },
                        colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue),
                        modifier = Modifier.testTag("biometrics_switch")
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}


// --- REUSABLE COMPONENT: RECENT LOG TRANSACTION LIST ITEM ROW ---
@Composable
fun TransactionRow(
    tx: Transaction
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tx_item_${tx.reference}"),
        colors = CardDefaults.cardColors(containerColor = GlassCard),
        border = BorderStroke(0.5.dp, GlassBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Category Icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (tx.isOutflow) HotPink.copy(0.08f) else NeonGreen.copy(0.08f),
                            CircleShape
                        )
                        .border(
                            0.5.dp,
                            if (tx.isOutflow) HotPink.copy(0.3f) else NeonGreen.copy(0.3f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when(tx.category) {
                            "food" -> Icons.Default.Restaurant
                            "transport" -> Icons.Default.DirectionsCar
                            "subscriptions" -> Icons.Default.Payment
                            "utilities" -> Icons.Default.Bolt
                            "investment" -> Icons.Default.ShowChart
                            "income" -> Icons.Default.AddCard
                            else -> Icons.Default.SwapHoriz
                        },
                        contentDescription = tx.category,
                        tint = if (tx.isOutflow) HotPink else NeonGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Title + Sub details
                Column {
                    Text(
                        text = tx.title,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "REF: " + tx.reference + " | " + tx.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateGlow
                    )
                }
            }

            // Amount tracking text readout
            Text(
                text = "${if (tx.isOutflow) "-" else "+"}£${"%,.2f".format(tx.amount)}",
                style = MaterialTheme.typography.labelMedium,
                color = if (tx.isOutflow) HotPink else NeonGreen,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


// --- REUSABLE COMPONENT: CUSTOM COMPOSABLE BOTTOM NAVIGATION BAR ---
@Composable
fun FintechBottomNavigation(
    currentTab: String,
    onTabSelected: (String) -> Unit
) {
    // Custom bottom navigation bar respecting WindowInsets.navigationBars padding properly!
    NavigationBar(
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(0.5.dp, GlassBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        containerColor = CarbonNavy.copy(alpha = 0.85f),
        tonalElevation = 6.dp
    ) {
        val navigationItems = listOf(
            Triple("home", "HOME", Icons.Default.Dashboard),
            Triple("accounts", "LEDGER", Icons.Default.Wallet),
            Triple("payments", "PAY", Icons.AutoMirrored.Filled.Send),
            Triple("analytics", "SPEND", Icons.Default.Insights),
            Triple("portfolio", "ASSETS", Icons.Default.CurrencyBitcoin),
            Triple("ai", "AEROAI", Icons.Default.Chat),
            Triple("settings", "SHIELD", Icons.Default.Security)
        )

        navigationItems.forEach { (route, label, icon) ->
            val isSelected = route == currentTab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(route) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) ElectricBlue else SlateGlow,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = if (isSelected) ElectricBlue else SlateGlow,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = ElectricBlue.copy(0.18f)
                ),
                modifier = Modifier.testTag("nav_tab_$route")
            )
        }
    }
}
