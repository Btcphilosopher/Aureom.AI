package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

// Dark theme is the default and optimized visual style for this premium cock-pit experience
private val CyberDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = NeonGreen,
    tertiary = CyberAmber,
    background = CyberMidnight,
    surface = CarbonNavy,
    onPrimary = CyberMidnight,
    onSecondary = CyberMidnight,
    onTertiary = CyberMidnight,
    onBackground = WhiteLight,
    onSurface = WhiteLight,
    surfaceVariant = GlassCard,
    outline = GlassBorder,
    error = HotPink
)

// Fallback Light Color Scheme (though UI will default to dark for the cinematic/neon aesthetic)
private val CyberLightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    secondary = NeonGreen,
    tertiary = CyberAmber,
    background = WhiteLight,
    surface = WhiteLight,
    onPrimary = CyberMidnight,
    onSecondary = CyberMidnight,
    onBackground = CyberMidnight,
    onSurface = CyberMidnight,
    surfaceVariant = WhiteLight,
    outline = SlateGlow,
    error = HotPink
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default for neobank glass-cyber aesthetic
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce the custom-designed futuristic identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) CyberDarkColorScheme else CyberLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
