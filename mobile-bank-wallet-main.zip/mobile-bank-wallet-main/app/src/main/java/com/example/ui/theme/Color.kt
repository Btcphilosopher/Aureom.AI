package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Frosted Glass Aesthetic Color Palette
val CyberMidnight = Color(0xFF0A0C10) // Ultra deep charcoal/slate midnight basis
val CarbonNavy = Color(0xFF0F1219)    // Frosted dark slate navigation / drawer fill
val GlassCard = Color(0x0DFFFFFF)     // Frosted glass composite plate background (5% translucent white)
val GlassBorder = Color(0x1BFFFFFF)   // Frosted glass fine structural border (10% structural white sheen)

// Accent Colors & Linear Blend Orbits
val ElectricBlue = Color(0xFF3D8BFF)  // Digital Sky Blue (Net Liquidity brand primary)
val NeonPurple = Color(0xFFAB47BC)    // Amethyst Purple (Vibe secondary layout bloom accent)
val NeonGreen = Color(0xFF34D399)     // Soft Emerald (Positive rates and gains accumulator)
val CyberAmber = Color(0xFFFBBF24)    // Ambient amber warning/caution highlights
val HotPink = Color(0xFFF87171)       // Coral Red (Anomalistic outflows and negative index trackers)

// Typography & Structural Nodes
val WhiteLight = Color(0xFFF8FAFC)    // Pure Slate-50 high-readability foreground
val SlateGlow = Color(0xFF94A3B8)     // Slate-400 muted telemetry readout text
val UnderlineGrid = Color(0x04FFFFFF) // Extremely subtle horizontal grid trace line
