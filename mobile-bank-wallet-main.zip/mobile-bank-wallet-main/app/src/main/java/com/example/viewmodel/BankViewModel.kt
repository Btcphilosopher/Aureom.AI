package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.entities.Account
import com.example.data.entities.Transaction
import com.example.data.entities.WatchlistItem
import com.example.data.repository.BankRepository
import com.example.network.GeminiManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class BankViewModel(application: Application) : AndroidViewModel(application) {

    private val bankDao = AppDatabase.getDatabase(application).bankDao()
    val repository = BankRepository(bankDao)

    init {
        viewModelScope.launch {
            repository.checkAndSeedDatabase()
        }
    }

    // --- Exposed Database Flows ---
    val accounts: StateFlow<List<Account>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchlistItems: StateFlow<List<WatchlistItem>> = repository.watchlistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatHistoryFlow: StateFlow<List<com.example.data.entities.ChatHistory>> = repository.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Interactive State Management ---
    private val _selectedAccountId = MutableStateFlow("current")
    val selectedAccountId: StateFlow<String> = _selectedAccountId.asStateFlow()

    private val _chartPeriod = MutableStateFlow("1M") // 1D, 1W, 1M, 1Y
    val chartPeriod: StateFlow<String> = _chartPeriod.asStateFlow()

    private val _showSuggestedAssets = MutableStateFlow(false)
    val showSuggestedAssets: StateFlow<Boolean> = _showSuggestedAssets.asStateFlow()

    private val _aiResponseLoading = MutableStateFlow(false)
    val aiResponseLoading: StateFlow<Boolean> = _aiResponseLoading.asStateFlow()

    // --- Instant Payment Form State ---
    private val _transferRecipient = MutableStateFlow("")
    val transferRecipient: StateFlow<String> = _transferRecipient.asStateFlow()

    private val _transferAmount = MutableStateFlow("")
    val transferAmount: StateFlow<String> = _transferAmount.asStateFlow()

    private val _transferCategory = MutableStateFlow("food")
    val transferCategory: StateFlow<String> = _transferCategory.asStateFlow()

    private val _transferStatus = MutableStateFlow<String?>(null)
    val transferStatus: StateFlow<String?> = _transferStatus.asStateFlow()

    // --- Settings states ---
    private val _dailySpendLimit = MutableStateFlow(1200f) // default
    val dailySpendLimit: StateFlow<Float> = _dailySpendLimit.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _biometricEnabled = MutableStateFlow(true)
    val biometricEnabled: StateFlow<Boolean> = _biometricEnabled.asStateFlow()

    // --- Computed Flow derived parameters ---
    val totalBalance: StateFlow<Double> = accounts.map { list ->
        list.sumOf { it.balance }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val activeSelectedAccount: StateFlow<Account?> = combine(accounts, selectedAccountId) { list, id ->
        list.find { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Category Spend summaries computed reactively!
    val categorySpendSummary: StateFlow<Map<String, Double>> = transactions.map { list ->
        list.filter { it.isOutflow }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // --- Action Methods ---

    fun selectAccountId(id: String) {
        _selectedAccountId.value = id
    }

    fun setChartPeriod(period: String) {
        _chartPeriod.value = period
    }

    fun toggleSuggestedAssets() {
        _showSuggestedAssets.value = !_showSuggestedAssets.value
    }

    fun updateRecipient(name: String) {
        _transferRecipient.value = name
    }

    fun updateAmount(amt: String) {
        _transferAmount.value = amt
    }

    fun updateCategory(cat: String) {
        _transferCategory.value = cat
    }

    fun updateSpendLimit(value: Float) {
        _dailySpendLimit.value = value
    }

    fun toggleNotifications() {
        _notificationsEnabled.value = !_notificationsEnabled.value
    }

    fun toggleBiometrics() {
        _biometricEnabled.value = !_biometricEnabled.value
    }

    fun toggleCardFreeze(accountId: String) {
        viewModelScope.launch {
            val account = repository.getAccountById(accountId) ?: return@launch
            val updated = account.copy(cardFrozen = !account.cardFrozen)
            repository.updateAccount(updated)
            
            // Push an info transaction for log purposes or system visual feedback
            val status = if (updated.cardFrozen) "PRO-TEM FREEZE ACTIVATED" else "CARD DE-FROZEN"
            repository.insertTransaction(
                Transaction(
                    accountId = accountId,
                    title = "Card Freeze Status: $status",
                    amount = 0.0,
                    category = "utilities",
                    timestamp = System.currentTimeMillis(),
                    reference = "FREEZE-LOCK-VECTOR",
                    isOutflow = true
                )
            )
        }
    }

    fun executeInstantTransfer(onComplete: () -> Unit) {
        val qty = _transferAmount.value.toDoubleOrNull()
        val rcp = _transferRecipient.value.trim()
        val cat = _transferCategory.value

        if (rcp.isEmpty() || qty == null || qty <= 0.0) {
            _transferStatus.value = "ERROR: TELEMETRY FAIL - Fields invalid."
            return
        }

        viewModelScope.launch {
            val currentAcc = repository.getAccountById("current")
            if (currentAcc == null || currentAcc.balance < qty) {
                _transferStatus.value = "ERROR: INSUFFICIENT LIQUIDITY."
                return@launch
            }

            // Deduct from current account
            val updatedCurrent = currentAcc.copy(balance = currentAcc.balance - qty)
            repository.insertAccount(updatedCurrent)

            // If target is "savings" (internal transfers!) credit the savings Vault
            if (rcp.lowercase() == "vault" || rcp.lowercase() == "savings") {
                val savingsAcc = repository.getAccountById("savings")
                if (savingsAcc != null) {
                    val updatedSavings = savingsAcc.copy(balance = savingsAcc.balance + qty)
                    repository.insertAccount(updatedSavings)
                }
            } else if (rcp.lowercase() == "investment" || rcp.lowercase() == "wallet") {
                val investAcc = repository.getAccountById("investment")
                if (investAcc != null) {
                    val updatedInvest = investAcc.copy(balance = investAcc.balance + qty)
                    repository.insertAccount(updatedInvest)
                }
            }

            // Record transaction
            repository.insertTransaction(
                Transaction(
                    accountId = "current",
                    title = "Instant transfer to $rcp",
                    amount = qty,
                    category = cat,
                    timestamp = System.currentTimeMillis(),
                    reference = "INST-SEND-${(100000..999999).random()}",
                    isOutflow = true
                )
            )

            _transferStatus.value = "TRANSACTION SEALED: OUTFLOW £${"%.2f".format(qty)} AUTHORIZED."
            _transferAmount.value = ""
            _transferRecipient.value = ""
            
            // Clean status message after delay
            kotlinx.coroutines.delay(4000)
            _transferStatus.value = null
            onComplete()
        }
    }

    fun sendMessageToAi(prompt: String) {
        val text = prompt.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            // Save USER message to Room DB
            repository.insertChatMessage("USER", text)
            _aiResponseLoading.value = true

            // Gather context for Gemini prompt call
            val currentTotal = totalBalance.value
            val categories = categorySpendSummary.value
            val foodSpend = categories["food"] ?: 54.30
            val transitSpend = categories["transport"] ?: 18.50
            val subsSpend = categories["subscriptions"] ?: 22.98
            
            val currentHistory = chatHistoryFlow.value

            // Call API
            val aiResponse = GeminiManager.getVibeResponse(
                prompt = text,
                history = currentHistory,
                currentBalanceTotal = currentTotal,
                recentSpendFood = foodSpend,
                recentSpendTransit = transitSpend,
                recentSpendSubs = subsSpend
            )

            // Save AI message to Room DB
            repository.insertChatMessage("AI", aiResponse)
            _aiResponseLoading.value = false
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChatHistory()
            repository.insertChatMessage("AI", "Aero Quantum Vibe Systems diagnostics purged. Chat buffer cleared.")
        }
    }
}

// Custom simple provider factory for ViewModel
class BankViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BankViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BankViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
