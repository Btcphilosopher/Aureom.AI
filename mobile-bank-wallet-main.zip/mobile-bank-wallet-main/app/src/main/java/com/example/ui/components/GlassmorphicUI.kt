package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CyberBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberMidnight)
    ) {
        // High fidelity frosted background with floating primary blue & purple orbs
        val infiniteTransition = rememberInfiniteTransition(label = "Aura Orbit")
        val glowScale by infiniteTransition.animateFloat(
            initialValue = 0.85f,
            targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                animation = tween(6000, easing = EaseInOutSine),
                repeatMode = RepeatMode.Reverse
            ),
            label = "Glow Pulse Animation"
        )
        
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            
            // Primary Sky Blue background light plume (Top Right)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ElectricBlue.copy(alpha = 0.12f), Color.Transparent),
                    center = Offset(width * 0.85f, height * 0.15f),
                    radius = width * 0.9f * glowScale
                )
            )
            
            // Secondary Amethyst Purple background light plume (Bottom Left)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonPurple.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(width * 0.15f, height * 0.85f),
                    radius = width * 1.0f * (2f - glowScale)
                )
            )

            // Extremely subtle horizontal/vertical guide lines for depth
            val spacing = 120f
            var y = 0f
            while (y < height) {
                drawLine(
                    color = Color.White.copy(alpha = 0.015f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
                y += spacing
            }

            var x = 0f
            while (x < width) {
                drawLine(
                    color = Color.White.copy(alpha = 0.015f),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
                x += spacing
            }
        }
        
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glowColor: Color = ElectricBlue,
    glowWidth: Dp = 1.dp,
    cornerRadius: Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(GlassCard)
            .border(
                glowWidth,
                Brush.linearGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.3f),
                        glowColor.copy(alpha = 0.05f),
                        Color.White.copy(alpha = 0.08f)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(150f, 400f)
                ),
                shape = RoundedCornerShape(cornerRadius)
            ),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            content()
        }
    }
}

@Composable
fun NeonButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    text: String,
    icon: @Composable (() -> Unit)? = null,
    neonColor: Color = ElectricBlue,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(
                1.5.dp,
                if (enabled) neonColor.copy(alpha = 0.8f) else SlateGlow.copy(alpha = 0.3f),
                RoundedCornerShape(12.dp)
            ),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (enabled) neonColor.copy(alpha = 0.08f) else Color.Transparent,
            contentColor = if (enabled) neonColor else SlateGlow
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.25.sp,
                color = if (enabled) neonColor else SlateGlow
            )
        }
    }
}

@Composable
fun AeroHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // JD/AB Gradient Avatar matching the exact design HTML
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        Brush.sweepGradient(listOf(ElectricBlue, NeonPurple, ElectricBlue)),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(39.dp)
                        .background(CyberMidnight, shape = androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "JD",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = WhiteLight
                        )
                    )
                }
            }

            Column {
                Text(
                    text = "AERO PILOT • COCKPIT ACTIVE",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 1.5.sp,
                        color = SlateGlow
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = title.uppercase(),
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        color = Color.White
                    )
                )
            }
        }

        // Translucent Glass telemetry pill matching the Design HTML header button/badge
        Box(
            modifier = Modifier
                .background(GlassCard, RoundedCornerShape(12.dp))
                .border(0.5.dp, GlassBorder, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = subtitle,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = ElectricBlue
                )
            )
        }
    }
}

@Composable
fun CanvasArcChart(
    data: Map<String, Double>,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) {
        Box(
            modifier = modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "NO COMPILING DATA FOUND",
                style = MaterialTheme.typography.labelMedium,
                color = SlateGlow
            )
        }
        return
    }

    val total = data.values.sum()
    if (total == 0.0) return

    val colors = listOf(ElectricBlue, NeonGreen, CyberAmber, HotPink, Color.Magenta, Color.Yellow)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Transparent),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Canvas(modifier = Modifier.size(130.dp)) {
                var startAngle = 0f
                data.entries.forEachIndexed { i, entry ->
                    val angle = ((entry.value / total) * 360).toFloat()
                    val color = colors[i % colors.size]
                    
                    drawArc(
                        color = color,
                        startAngle = startAngle,
                        sweepAngle = angle,
                        useCenter = false,
                        style = Stroke(width = 16f, cap = StrokeCap.Round),
                        size = Size(size.width, size.height)
                    )
                    startAngle += angle
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                data.entries.forEachIndexed { i, entry ->
                    val color = colors[i % colors.size]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(color, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${entry.key.uppercase()} - £${"%.2f".format(entry.value)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = WhiteLight
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LineGraph(
    points: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = ElectricBlue,
    fillColor: Color = ElectricBlue.copy(alpha = 0.15f)
) {
    if (points.isEmpty()) return

    val textMeasurer = rememberTextMeasurer()

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val maxVal = (points.maxOrNull() ?: 100f).coerceAtLeast(1f)
        val minVal = points.minOrNull() ?: 0f
        val delta = (maxVal - minVal).coerceAtLeast(1f)

        val spacing = width / (points.size - 1).coerceAtLeast(1)
        
        val path = Path()
        val fillPath = Path()

        // Move to start
        val firstY = height - ((points[0] - minVal) / delta) * height
        path.moveTo(0f, firstY)
        fillPath.moveTo(0f, height)
        fillPath.lineTo(0f, firstY)

        for (i in 1 until points.size) {
            val rx = i * spacing
            val ry = height - ((points[i] - minVal) / delta) * height
            path.lineTo(rx, ry)
            fillPath.lineTo(rx, ry)
        }

        fillPath.lineTo(width, height)
        fillPath.close()

        // Draw grids on canvas background
        val gridLines = 4
        for (g in 0..gridLines) {
            val gy = (height / gridLines) * g
            drawLine(
                color = Color.White.copy(alpha = 0.04f),
                start = Offset(0f, gy),
                end = Offset(width, gy),
                strokeWidth = 1f
            )
        }

        // Draw path strokes
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Draw glowing gradient fill under line
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(fillColor, Color.Transparent),
                startY = 0f,
                endY = height
            )
        )

        // Draw points nodes for extreme peaks
        points.forEachIndexed { i, p ->
            if (i == points.size - 1 || p == maxVal || p == minVal) {
                val px = i * spacing
                val py = height - ((p - minVal) / delta) * height
                drawCircle(
                    color = lineColor,
                    radius = 8f,
                    center = Offset(px, py)
                )
                drawCircle(
                    color = CyberMidnight,
                    radius = 4f,
                    center = Offset(px, py)
                )
            }
        }
    }
}
