package com.example.network

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

object GeminiManager {
    private const val TAG = "GeminiManager"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // --- Direct Models for Moshi Serialization ---
    data class ContentPart(val text: String)
    data class Content(val parts: List<ContentPart>, val role: String = "user")
    data class SystemInstruction(val parts: List<ContentPart>)
    data class GenerateContentRequest(
        val contents: List<Content>,
        val systemInstruction: SystemInstruction? = null
    )

    data class ResponseCandidateContent(val parts: List<ContentPart>)
    data class ResponseCandidate(val content: ResponseCandidateContent)
    data class GenerateContentResponse(val candidates: List<ResponseCandidate>?)

    suspend fun getVibeResponse(
        prompt: String,
        history: List<com.example.data.entities.ChatHistory>,
        currentBalanceTotal: Double,
        recentSpendFood: Double,
        recentSpendTransit: Double,
        recentSpendSubs: Double,
        monthlyIncome: Double = 4200.00
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        
        // System Prompt specifying cyber neobank Cockpit AI identity and current system state context!
        val systemPrompt = """
            You are 'Aero Quantum Vibe Systems', the intelligence core of Aero Bank.
            Your tone is sleek, cyber-minimal, slightly futuristic, helpful, highly data-informed, and brief.
            Speak as an advanced AI financial copilot interface.
            
            Current Cockpit Financial Telemetry:
            - Client Total Aggregated Liquidity: £${"%,.2f".format(currentBalanceTotal)}
            - Primary Active Income Stream: £${"%,.2f".format(monthlyIncome)} (AeroTech Corp Salary)
            - Category Spend (Food/Dining): £${"%,.2f".format(recentSpendFood)}
            - Category Spend (Transit): £${"%,.2f".format(recentSpendTransit)}
            - Category Spend (Subscriptions): £${"%,.2f".format(recentSpendSubs)}
            
            Key guidelines for your analysis:
            1. If they ask about buying a specific expensive item (e.g. £1,200 laptop), calculate the affordability. If their balance is £12k, they can afford it (it is only <10% of their total liquidity), but warn them of of visual impact on their target compounding speed and provide a futuristic 'Vibe Indicator' like 'Vibe Core: Stable. Delta impact 9.6%.'
            2. If they ask about saving, suggest custom budget optimizations (e.g., swapping utility bills can save them £42/month, or trimming unused subscriptions).
            3. Answer questions directly, with data-rich responses, but keep answers under 4-5 sentences max in high-end cyber bullet points or structured text. Do not write lengthy explanations. Use terminology like 'Liquidity telemetry', 'Compounding vectors', 'Delta indicators'.
        """.trimIndent()

        // If API key is empty or default placeholder, run intelligent fallback!
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key is empty or default. Standard fallback activated.")
            return@withContext simulateIntelligentFallback(prompt, currentBalanceTotal, recentSpendFood, recentSpendTransit, recentSpendSubs)
        }

        try {
            // Build chat contents (Option B Direct REST API representation)
            val requestContents = mutableListOf<Content>()
            
            // Map last 6 messages of history for context
            val historyOffset = if (history.size > 6) history.size - 6 else 0
            for (i in historyOffset until history.size) {
                val hist = history[i]
                val role = if (hist.sender == "USER") "user" else "model"
                requestContents.add(Content(parts = listOf(ContentPart(hist.message)), role = role))
            }
            
            // Add current prompt
            requestContents.add(Content(parts = listOf(ContentPart(prompt)), role = "user"))

            val requestObj = GenerateContentRequest(
                contents = requestContents,
                systemInstruction = SystemInstruction(parts = listOf(ContentPart(systemPrompt)))
            )

            val adapter = moshi.adapter(GenerateContentRequest::class.java)
            val jsonRequestBody = adapter.toJson(requestObj)

            val request = Request.Builder()
                .url("$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey")
                .post(jsonRequestBody.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    Log.e(TAG, "Request failed code: ${response.code} body: $errorBody")
                    return@withContext simulateIntelligentFallback(prompt, currentBalanceTotal, recentSpendFood, recentSpendTransit, recentSpendSubs)
                }

                val responseBody = response.body?.string()
                if (responseBody != null) {
                    val responseAdapter = moshi.adapter(GenerateContentResponse::class.java)
                    val responseObj = responseAdapter.fromJson(responseBody)
                    val textResult = responseObj?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (textResult != null) {
                        return@withContext textResult
                    }
                }
                return@withContext "Signal interrupt. Cyber core unable to compile response. Re-syncing telemetry."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call exception: ${e.message}", e)
            return@withContext simulateIntelligentFallback(prompt, currentBalanceTotal, recentSpendFood, recentSpendTransit, recentSpendSubs)
        }
    }

    private fun simulateIntelligentFallback(
        prompt: String,
        balance: Double,
        food: Double,
        transit: Double,
        subs: Double
    ): String {
        val query = prompt.lowercase()
        return when {
            query.contains("laptop") || query.contains("1,200") || query.contains("afford") || query.contains("buy") -> {
                val price = 1200.00
                val ratio = (price / balance) * 100
                """
                🔍 ⚖️ TELEMETRY ANALYSIS: AFFORDABILITY CALCULATION
                • Item Price: £1,200.00 | Total Available Liquidity: £${"%,.2f".format(balance)}
                • Delta Shock: -${"%.2f".format(ratio)}% of total net holdings.
                • Status: APPROVED. You can comfortably execute this purchase without impacting essential liability vectors.
                • Savings suggestion: Switching redundant utilities could offset £42/month, recouping this cost in 28 months automatically.
                • Velo Vibe Index: STABLE (9.4/10).
                """.trimIndent()
            }
            query.contains("save") || query.contains("budget") || query.contains("spending") -> {
                """
                📉 🧬 SPENDING DIAGNOSTICS & SYSTEM RECOMMENDATIONS
                • Active Leak Detected: You spent £${"%.2f".format(subs)} on digital subscription vectors. Trim at least 1 inactive node.
                • Dining Trend: Spent £${"%.2f".format(food)} on food. Dining delta is down 18% compared to last period, performing optimally!
                • Wealth Catalyst: Redirect £150.00 of transport cost automatically into your 'Vault Quantum Goal' to accrue 4.5% APY.
                """.trimIndent()
            }
            query.contains("invest") || query.contains("crypto") || query.contains("stocks") -> {
                """
                📈 🚀 INVESTMENT READOUT: DELTA RECOMMENDATIONS
                • Markets Update: High volatilities on NVDA (+8.34%) and Solana (+12.42%).
                • Portfolio Recommendation: Toggle 'AI Portfolio Autopilot' to rebalance your 4.5% Vault and Crypto Core holdings automatically.
                • Action suggest: Accumulate AVAX (Avalanche Node is currently flagged as 'High Growth Potential' by Aero Core).
                """.trimIndent()
            }
            query.contains("predict") || query.contains("forecast") || query.contains("month") -> {
                val forecast = balance + 4200.00 - 1500.00 // Simple forecast
                """
                🔮 📈 FORECAST ENGINE ACCELERATED:
                • Telemetry Prediction: Inflow +£4,200.00 expected in 9 cycles. Outflows estimated at £1,500.00.
                • End-of-Month Anticipated Core Holdings: £${"%,.2f".format(forecast)}
                • Compounding Coefficient: Accumulating with solid vectors. No alerts active.
                """.trimIndent()
            }
            else -> {
                """
                ⚡ Aero Quantum Vibe Systems [v1.4] Online.
                • Core telemetry looks normal. Net holdings are £${"%,.2f".format(balance)} with positive compounding in Vault at 4.5% APY.
                • Prompt processed: "$prompt"
                • Signal Status: Fallback interactive core active. Ask me: "Can I buy a £1,200 laptop?" or "Where can I save?"
                """.trimIndent()
            }
        }
    }
}
