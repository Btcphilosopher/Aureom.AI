import express, { Request, Response } from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { PRODUCTS_DATA, ARTISANS_DATA, STATES_DATA, MOCK_ORDERS } from './src/data/mockData';

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper for Gemini AI client initialization
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

// --- API ROUTES ---

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'BharatBazaar Core Engine' });
});

// Products API
app.get('/api/products', (req: Request, res: Response) => {
  const { category, state, giOnly, search, minPrice, maxPrice } = req.query;

  let filtered = [...PRODUCTS_DATA];

  if (category && typeof category === 'string' && category !== 'All') {
    filtered = filtered.filter(p => p.category.toLowerCase() === category.toLowerCase());
  }

  if (state && typeof state === 'string' && state !== 'All') {
    filtered = filtered.filter(p => p.stateOfOrigin.toLowerCase() === state.toLowerCase());
  }

  if (giOnly === 'true') {
    filtered = filtered.filter(p => p.isGiTagged);
  }

  if (search && typeof search === 'string' && search.trim()) {
    const q = search.toLowerCase().trim();
    filtered = filtered.filter(
      p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.stateOfOrigin.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  if (minPrice) {
    filtered = filtered.filter(p => p.price >= Number(minPrice));
  }
  if (maxPrice) {
    filtered = filtered.filter(p => p.price <= Number(maxPrice));
  }

  res.json({ count: filtered.length, products: filtered });
});

// Single product
app.get('/api/products/:id', (req: Request, res: Response) => {
  const product = PRODUCTS_DATA.find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json(product);
});

// Artisans API
app.get('/api/artisans', (req: Request, res: Response) => {
  res.json({ count: ARTISANS_DATA.length, artisans: ARTISANS_DATA });
});

app.get('/api/artisans/:id', (req: Request, res: Response) => {
  const artisan = ARTISANS_DATA.find(a => a.id === req.params.id);
  if (!artisan) {
    return res.status(404).json({ error: 'Artisan not found' });
  }
  res.json(artisan);
});

// States API
app.get('/api/states', (req: Request, res: Response) => {
  res.json({ count: STATES_DATA.length, states: STATES_DATA });
});

// Orders API
app.get('/api/orders', (req: Request, res: Response) => {
  res.json({ orders: MOCK_ORDERS });
});

app.post('/api/orders', (req: Request, res: Response) => {
  const newOrder = req.body;
  if (!newOrder.items || newOrder.items.length === 0) {
    return res.status(400).json({ error: 'Cart is empty' });
  }

  const orderId = `BB-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const createdOrder = {
    ...newOrder,
    id: orderId,
    date: new Date().toISOString().split('T')[0],
    status: 'placed',
    trackingNumber: `IN-EXPRESS-${Math.floor(1000000 + Math.random() * 9000000)}`,
    estimatedDelivery: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    currentLocation: 'Order confirmed by Artisan & Seller',
  };

  MOCK_ORDERS.unshift(createdOrder);
  res.json({ success: true, order: createdOrder });
});

// Gemini AI Assistant Endpoint
app.post('/api/gemini/assistant', async (req: Request, res: Response) => {
  try {
    const { prompt, language = 'en' } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGeminiClient();

    if (!ai) {
      // Intelligent fallback when Gemini API key is not yet set up
      return res.json({
        answer: `Namaste! I am BharatBazaar's AI Shopping Assistant. Here are top authentic recommendations based on your inquiry ("${prompt}"):\n\n1. **Royal Banarasi Kadhwa Silk Saree** (Varanasi, UP) - GI Tagged\n2. **GI Kashmiri Mongra Saffron** (Pampore, J&K) - Pure Export Grade\n3. **Jaipur Blue Pottery Vase** (Jaipur, RJ) - Traditional Quartz Artistry\n4. **First Flush Darjeeling Black Tea** (West Bengal) - Handpicked High Altitude\n\n*Note: Configure your GEMINI_API_KEY in Secrets for live custom generative advice!*`,
        recommendations: [PRODUCTS_DATA[0].id, PRODUCTS_DATA[4].id, PRODUCTS_DATA[2].id, PRODUCTS_DATA[9].id],
      });
    }

    const systemInstruction = `You are BharatBazaar AI Guru, an expert in Indian crafts, textiles, spices, handloom heritage, regional festivals, and authentic gift recommendations.
The user is inquiring in language: ${language}.
Provide warm, culturally respectful, detailed advice highlighting authentic Indian craftsmanship, GI tag certifications, state of origin, and traditional artisanal techniques. Keep response scannable with bullet points.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: `${systemInstruction}\n\nUser Question: ${prompt}` }] }
      ],
    });

    const text = response.text || 'Thank you for exploring BharatBazaar! How else can I assist your Indian craft discovery?';
    res.json({ answer: text });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: error.message || 'Gemini service failed' });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BharatBazaar Server running on http://localhost:${PORT}`);
  });
}

startServer();
