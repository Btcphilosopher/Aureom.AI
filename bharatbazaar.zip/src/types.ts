export type LanguageCode =
  | 'en' // English
  | 'hi' // Hindi (हिन्दी)
  | 'bn' // Bengali (বাংলা)
  | 'ta' // Tamil (தமிழ்)
  | 'te' // Telugu (తెలుగు)
  | 'kn' // Kannada (ಕನ್ನಡ)
  | 'ml' // Malayalam (മലയാളം)
  | 'gu' // Gujarati (ગુજરાતી)
  | 'mr' // Marathi (मराठी)
  | 'pa' // Punjabi (ਪੰਜਾਬੀ)
  | 'ur' // Urdu (اردو)
  | 'as' // Assamese (অসমীয়া)
  | 'or' // Odia (ଓଡ଼ିଆ)
  | 'sa' // Sanskrit (संस्कृतम्)
  | 'ks' // Kashmiri (कॉशुर)
  | 'ne' // Nepali (नेपाली)
  | 'kok' // Konkani (कोंकणी)
  | 'mni' // Manipuri / Meitei (ꯃꯤꯇꯩꯂꯣꯟ)
  | 'doi' // Dogri (डोगरी)
  | 'brx' // Bodo (बड़ो)
  | 'sat' // Santali (ᱥᱟᱱᱛᱟᱲᱤ)
  | 'mai' // Maithili (मैथिली)
  | 'bho' // Bhojpuri (भोजपुरी)
  | 'raj' // Rajasthani (राजस्थानी)
  | 'tcy' // Tulu (ತುಳು)
  | 'hne' // Chhattisgarhi (छत्तीसगढ़ी)
  | 'gbm' // Garhwali (गढ़वाली)
  | 'kfy' // Kumaoni (कुमाऊँनी)
  | 'mag' // Magahi (मगही)
  | 'awa' // Awadhi (अवधी)
  | 'bns' // Bundeli (बुंदेली)
  | 'bgc' // Haryanvi (हरियाणवी)
  | 'mzo' // Mizo (Mizo ṭawng)
  | 'kha' // Khasi (Ka Ktien Khasi)
  | 'grt' // Garo (A·chik)
  | 'trv' // Kokborok (কোকবোরোক)
  | 'nag' // Nagamese (Nagamese)
  | 'lbj'; // Ladakhi (ལ་དྭགས་སྐད།)

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  script: string;
}

export interface Product {
  id: string;
  name: string;
  nameTranslated?: Record<string, string>;
  category: string;
  subCategory?: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviewCount: number;
  images: string[];
  stateOfOrigin: string;
  artisanId?: string;
  artisanName?: string;
  isGiTagged: boolean; // Geographical Indication Tagged
  giTagNumber?: string;
  description: string;
  materials: string[];
  specifications: Record<string, string>;
  seller: {
    id: string;
    name: string;
    location: string;
    verified: boolean;
    rating: number;
  };
  stock: number;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isDealOfDay?: boolean;
  festiveTags?: string[];
  tags: string[];
}

export interface Artisan {
  id: string;
  name: string;
  craftName: string;
  state: string;
  city: string;
  avatar: string;
  coverImage: string;
  story: string;
  experienceYears: number;
  familyGenerations: number;
  certifications: string[];
  rating: number;
  productCount: number;
  workshopLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  videoUrl?: string;
  featuredProducts: string[]; // Product IDs
}

export interface StateMarketplace {
  id: string;
  name: string;
  code: string;
  capital: string;
  heroImage: string;
  tagline: string;
  description: string;
  famousCrafts: string[];
  topSpecialties: string[];
  famousFood: string[];
  artisanCount: number;
  colorTheme: string; // Tailwind color class or hex
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  totalAmount: number;
  shippingAddress: {
    fullName: string;
    addressLine: string;
    city: string;
    state: string;
    pincode: string;
    phone: string;
  };
  paymentMethod: 'upi' | 'card' | 'netbanking' | 'cod' | 'bnpl';
  paymentStatus: 'paid' | 'pending' | 'failed';
  status: 'placed' | 'artisan_crafting' | 'quality_checked' | 'shipped' | 'out_for_delivery' | 'delivered';
  trackingNumber: string;
  estimatedDelivery: string;
  currentLocation?: string;
}

export type ActiveTab =
  | 'home'
  | 'states'
  | 'artisans'
  | 'categories'
  | 'orders'
  | 'seller_portal'
  | 'admin_dashboard'
  | 'maps';

export interface FestivalTheme {
  id: string;
  name: string;
  greeting: string;
  bannerMessage: string;
  accentColor: string;
  bgPattern: string;
  active: boolean;
}
