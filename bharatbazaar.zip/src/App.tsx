import React, { useState, useEffect } from 'react';
import {
  LanguageCode,
  Product,
  CartItem,
  ActiveTab,
  FestivalTheme,
  Order,
} from './types';
import { PRODUCTS_DATA, MOCK_ORDERS, FESTIVAL_THEMES } from './data/mockData';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { ProductGrid } from './components/ProductGrid';
import { StateExplorer } from './components/StateExplorer';
import { ArtisanMarketplace } from './components/ArtisanMarketplace';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTracking } from './components/OrderTracking';
import { SellerPortal } from './components/SellerPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { AiAssistantModal } from './components/AiAssistantModal';
import { InteractiveMap } from './components/InteractiveMap';
import { HeartHandshake, ShieldCheck, Phone, Mail, Award } from 'lucide-react';

export default function App() {
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('en');
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [products, setProducts] = useState<Product[]>(PRODUCTS_DATA);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistCount, setWishlistCount] = useState<number>(3);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStateFilter, setSelectedStateFilter] = useState('All');

  // Modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);

  // Cart Enhancements
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [isGiftWrapped, setIsGiftWrapped] = useState(false);

  // Orders
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);

  // Festivals
  const [activeFestival, setActiveFestival] = useState<FestivalTheme | null>(FESTIVAL_THEMES[0]);

  // Fetch initial products from backend API if available
  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (data.products && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(err => console.log('Using fallback local catalog dataset:', err));
  }, []);

  const handleAddToCart = (product: Product, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCartItems(prev =>
      prev.map(item => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleBuyNow = (product: Product) => {
    handleAddToCart(product, 1);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleAddSellerProduct = (newProd: Partial<Product>) => {
    const fullProd: Product = {
      id: `prod_custom_${Date.now()}`,
      name: newProd.name || 'Handcrafted Craft Item',
      category: newProd.category || 'Handicrafts',
      price: newProd.price || 1999,
      originalPrice: newProd.originalPrice || 2499,
      rating: 5.0,
      reviewCount: 1,
      images: newProd.images || ['/src/assets/images/bharat_bazaar_hero_1785957854949.jpg'],
      stateOfOrigin: newProd.stateOfOrigin || 'Rajasthan',
      isGiTagged: newProd.isGiTagged || false,
      description: newProd.description || 'Authentic artisan product',
      materials: newProd.materials || ['Handloom Fabric'],
      specifications: newProd.specifications || {},
      seller: newProd.seller || {
        id: 'seller_1',
        name: 'Artisan Guild',
        location: 'India',
        verified: true,
        rating: 4.9,
      },
      stock: 10,
      tags: newProd.tags || [],
    };

    setProducts(prev => [fullProd, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] font-sans text-[#1A1A1A] flex flex-col selection:bg-[#1A237E] selection:text-white">
      {/* Navigation Header */}
      <Header
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        searchQuery={searchQuery}
        onSearchChange={q => {
          setSearchQuery(q);
          if (activeTab !== 'home') setActiveTab('home');
        }}
        cartCount={cartItems.reduce((a, b) => a + b.quantity, 0)}
        wishlistCount={wishlistCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        activeFestival={activeFestival}
        onToggleFestival={() => {
          if (!activeFestival) setActiveFestival(FESTIVAL_THEMES[0]);
          else setActiveFestival(prev => (prev?.active ? null : FESTIVAL_THEMES[0]));
        }}
        selectedStateFilter={selectedStateFilter}
        onSelectStateFilter={setSelectedStateFilter}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <HeroBanner
              currentLanguage={currentLanguage}
              onExploreStates={() => setActiveTab('states')}
              onExploreArtisans={() => setActiveTab('artisans')}
              onSelectCategory={cat => {
                setSelectedCategory(cat);
                const gridElem = document.getElementById('product-grid-section');
                if (gridElem) gridElem.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
            />

            <ProductGrid
              products={products}
              onSelectProduct={setSelectedProduct}
              onAddToCart={p => handleAddToCart(p, 1)}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              searchQuery={searchQuery}
            />
          </>
        )}

        {activeTab === 'states' && (
          <StateExplorer
            products={products}
            onSelectProduct={setSelectedProduct}
            onAddToCart={p => handleAddToCart(p, 1)}
            onSelectState={st => setSelectedStateFilter(st)}
          />
        )}

        {activeTab === 'artisans' && (
          <ArtisanMarketplace
            products={products}
            onSelectProduct={setSelectedProduct}
            onAddToCart={p => handleAddToCart(p, 1)}
          />
        )}

        {activeTab === 'maps' && <InteractiveMap />}

        {activeTab === 'orders' && <OrderTracking orders={orders} />}

        {activeTab === 'seller_portal' && (
          <SellerPortal onAddProduct={handleAddSellerProduct} />
        )}

        {activeTab === 'admin_dashboard' && <AdminDashboard />}
      </main>

      {/* Editorial Footer */}
      <footer className="bg-[#1A237E] text-white mt-16 border-t border-[#E5E0D8]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-full bg-[#C28E0E] flex items-center justify-center font-serif text-white font-normal text-lg">
                  भ
                </div>
                <span className="font-serif text-2xl font-normal text-white">BharatBazaar</span>
              </div>
              <p className="text-xs text-stone-300 leading-relaxed mb-4 font-serif italic">
                India’s premier digital marketplace connecting authentic artisans, local retailers, weavers, and national brands across 13 Indian languages.
              </p>
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-amber-200 font-bold">
                <ShieldCheck className="w-4 h-4 text-[#C28E0E]" />
                <span>100% GI Tag Authentic Origin</span>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-[#C28E0E] text-[10px] uppercase tracking-[0.2em] mb-4">
                State Marketplaces
              </h4>
              <ul className="space-y-2.5 text-xs text-stone-300">
                <li className="hover:text-amber-200 cursor-pointer" onClick={() => setActiveTab('states')}>Rajasthan (Blue Pottery & Bandhani)</li>
                <li className="hover:text-amber-200 cursor-pointer" onClick={() => setActiveTab('states')}>Uttar Pradesh (Banarasi & Chikankari)</li>
                <li className="hover:text-amber-200 cursor-pointer" onClick={() => setActiveTab('states')}>Kerala (Kasavu & Wayanad Spices)</li>
                <li className="hover:text-amber-200 cursor-pointer" onClick={() => setActiveTab('states')}>West Bengal (Baluchari & Darjeeling Tea)</li>
                <li className="hover:text-amber-200 cursor-pointer" onClick={() => setActiveTab('states')}>Jammu & Kashmir (Pashmina & Saffron)</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-[#C28E0E] text-[10px] uppercase tracking-[0.2em] mb-4">
                38 Supported Languages
              </h4>
              <p className="text-xs text-stone-300 leading-relaxed">
                English • हिन्दी • বাংলা • తెలుగు • मराठी • தமிழ் • اردو • ગુજરાતી • ಕನ್ನಡ • മലയാളം • ଓଡ଼ିଆ • ਪੰਜਾਬੀ • অসমীয়া • संस्कृतम् • कॉशुर • नेपाली • कोंकणी • ꯃꯤꯇꯩꯂꯣꯟ • डोगरी • बड़ो • ᱥᱟᱱᱛᱟᱲᱤ • मैथिली & Regional Dialects
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-[#C28E0E] text-[10px] uppercase tracking-[0.2em] mb-4">
                Artisan Guild Support
              </h4>
              <div className="space-y-2 text-xs text-stone-300">
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#C28E0E]" />
                  <span>Toll Free: 1800-BHARAT-BAZAAR</span>
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#C28E0E]" />
                  <span>support@bharatbazaar.in</span>
                </p>
                <p className="text-[11px] text-stone-400 mt-2 italic font-serif">
                  Direct artisan guild queries & wholesale bulk enquiries welcome.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] uppercase tracking-wider text-stone-400 gap-4">
            <p>© 2026 BharatBazaar. Crafted by Hand, Rooted in Heritage.</p>
            <div className="flex items-center gap-4 text-stone-300">
              <span>GST Compliance</span>
              <span>•</span>
              <span>Made with Pride in India</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedToCheckout={() => setIsCheckoutOpen(true)}
        appliedCoupon={appliedCoupon}
        onApplyCoupon={code => setAppliedCoupon(code)}
        isGiftWrapped={isGiftWrapped}
        onToggleGiftWrap={() => setIsGiftWrapped(!isGiftWrapped)}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        appliedCoupon={appliedCoupon}
        isGiftWrapped={isGiftWrapped}
        onOrderComplete={newOrder => {
          setOrders(prev => [newOrder, ...prev]);
          setCartItems([]);
        }}
      />

      {/* AI Assistant Gemini Modal */}
      <AiAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        currentLanguage={currentLanguage}
      />
    </div>
  );
}
