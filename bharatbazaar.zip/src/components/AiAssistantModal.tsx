import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, RefreshCcw, Compass, Gift, Heart } from 'lucide-react';
import { LanguageCode } from '../types';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: LanguageCode;
}

export function AiAssistantModal({ isOpen, onClose, currentLanguage }: AiAssistantModalProps) {
  const [promptInput, setPromptInput] = useState('');
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: 'Namaste! I am your BharatBazaar AI Shopping & Heritage Guide. Ask me anything about authentic Indian handlooms, regional GI tagged specialties, wedding shopping lists, festival gifts, or traditional recipe ingredients!',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (customPrompt?: string) => {
    const query = customPrompt || promptInput;
    if (!query.trim() || isLoading) return;

    const userMsg = { role: 'user' as const, text: query };
    setMessages(prev => [...prev, userMsg]);
    setPromptInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query, language: currentLanguage }),
      });

      const data = await response.json();
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: data.answer || 'I am delighted to assist your Indian craft discovery!',
        },
      ]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: 'I recommend exploring our GI Tagged Pashmina Shawls from Kashmir, Banarasi Silk Sarees from Varanasi, and Blue Pottery from Jaipur!',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-amber-300 flex flex-col h-[80vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950 via-stone-900 to-amber-900 text-white flex items-center justify-between border-b border-amber-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-amber-50">
                AI Shopping & Heritage Guru
              </h3>
              <p className="text-[11px] text-amber-300/80">
                Powered by Gemini AI • Multilingual Cultural Advisor
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-300 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-3 bg-amber-50/60 border-b border-amber-200 flex items-center gap-2 overflow-x-auto text-[11px] no-scrollbar">
          <button
            onClick={() => handleSend('What are the best GI tagged Diwali gifts from South India?')}
            className="px-3 py-1 bg-white border border-amber-300 text-amber-900 rounded-full font-semibold hover:bg-amber-100 whitespace-nowrap flex items-center gap-1"
          >
            <Gift className="w-3 h-3 text-amber-600" />
            <span>Diwali South Indian Gifts</span>
          </button>
          <button
            onClick={() => handleSend('Suggest authentic Varanasi silk saree styles for a traditional wedding')}
            className="px-3 py-1 bg-white border border-amber-300 text-amber-900 rounded-full font-semibold hover:bg-amber-100 whitespace-nowrap flex items-center gap-1"
          >
            <Heart className="w-3 h-3 text-rose-500" />
            <span>Banarasi Wedding Saree Guide</span>
          </button>
          <button
            onClick={() => handleSend('Explain the difference between Kashmiri Mongra Saffron and standard saffron')}
            className="px-3 py-1 bg-white border border-amber-300 text-amber-900 rounded-full font-semibold hover:bg-amber-100 whitespace-nowrap flex items-center gap-1"
          >
            <Compass className="w-3 h-3 text-emerald-600" />
            <span>Kashmiri Saffron Facts</span>
          </button>
        </div>

        {/* Chat History */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shrink-0 text-xs font-bold">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-amber-600 text-white font-medium rounded-tr-none'
                    : 'bg-stone-100 text-stone-900 border border-stone-200 rounded-tl-none whitespace-pre-line'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 items-center text-xs text-amber-700 font-medium">
              <Sparkles className="w-4 h-4 animate-spin text-amber-600" />
              <span>Gemini AI is crafting authentic heritage advice...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center gap-2">
          <input
            type="text"
            value={promptInput}
            onChange={e => setPromptInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Ask about authentic crafts, spices, regional handlooms..."
            className="flex-1 px-4 py-2.5 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-amber-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !promptInput.trim()}
            className="p-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl disabled:opacity-50 transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
