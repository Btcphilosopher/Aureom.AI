import React, { useState } from 'react';
import { MapPin, Navigation, Store, Warehouse, ShieldCheck } from 'lucide-react';

interface LocationPin {
  id: string;
  name: string;
  type: 'artisan' | 'warehouse' | 'market';
  state: string;
  lat: number;
  lng: number;
  craft: string;
}

const MAP_LOCATIONS: LocationPin[] = [
  { id: '1', name: 'Varanasi Weavers Guild', type: 'artisan', state: 'Uttar Pradesh', lat: 25.3176, lng: 82.9739, craft: 'Banarasi Brocade Silk' },
  { id: '2', name: 'Jaipur Blue Pottery Studio', type: 'artisan', state: 'Rajasthan', lat: 26.9124, lng: 75.7873, craft: 'Quartz Blue Pottery' },
  { id: '3', name: 'Pampore Saffron Harvest', type: 'artisan', state: 'Jammu & Kashmir', lat: 34.0837, lng: 74.7973, craft: 'GI Mongra Saffron' },
  { id: '4', name: 'Kanchipuram Silk Co-op', type: 'artisan', state: 'Tamil Nadu', lat: 12.8342, lng: 79.7036, craft: 'Kanchipuram Zari Silk' },
  { id: '5', name: 'Wayanad Spice Plantation Hub', type: 'artisan', state: 'Kerala', lat: 11.6854, lng: 76.132, craft: 'Organic Black Pepper' },
  { id: '6', name: 'Bishnupur Terracotta Village', type: 'artisan', state: 'West Bengal', lat: 23.07, lng: 87.32, craft: 'Bankura Terracotta' },
  { id: '7', name: 'Kutch Ajrakh Print Guild', type: 'artisan', state: 'Gujarat', lat: 23.242, lng: 69.6669, craft: 'Ajrakh Natural Dyes' },
  { id: '8', name: 'Assam Muga Silk Weavers', type: 'artisan', state: 'Assam', lat: 26.1445, lng: 91.7362, craft: 'Golden Muga Silk' },
  { id: '9', name: 'Bengaluru Logistics Fulfilment Center', type: 'warehouse', state: 'Karnataka', lat: 12.9716, lng: 77.5946, craft: 'National Hub' },
  { id: '10', name: 'Delhi NCR Central Warehouse', type: 'warehouse', state: 'Delhi', lat: 28.6139, lng: 77.209, craft: 'North Logistics Hub' },
];

export function InteractiveMap() {
  const [selectedPin, setSelectedPin] = useState<LocationPin>(MAP_LOCATIONS[0]);

  return (
    <div id="interactive-map-view" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-2">
          <Navigation className="w-3.5 h-3.5 text-amber-600" />
          <span>Interactive National Craft Map</span>
        </div>
        <h2 className="font-serif text-3xl font-extrabold text-stone-900">
          Artisan & Warehouse Locations Across India
        </h2>
        <p className="text-stone-600 text-xs sm:text-sm mt-1">
          Trace verified seller hubs, direct workshop locations, and regional fulfillment centers covering 28,000+ Indian pincodes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Interactive SVG Canvas Simulator */}
        <div className="lg:col-span-2 bg-stone-950 rounded-3xl p-6 sm:p-8 text-white relative min-h-[400px] flex flex-col justify-between overflow-hidden shadow-xl border border-stone-800">
          {/* Subtle Map Graphic Background */}
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" />

          <div className="relative z-10 flex justify-between items-center text-xs">
            <span className="bg-amber-500/20 text-amber-300 font-bold px-3 py-1 rounded-full border border-amber-400/30">
              India Coverage: 28 States & 8 Union Territories
            </span>
            <span className="text-stone-400">Live Logistics Grid</span>
          </div>

          {/* Simulated Location Pins Grid */}
          <div className="relative z-10 grid grid-cols-2 sm:grid-cols-3 gap-3 my-8">
            {MAP_LOCATIONS.map(pin => {
              const isSelected = pin.id === selectedPin.id;
              return (
                <button
                  key={pin.id}
                  onClick={() => setSelectedPin(pin)}
                  className={`p-3 rounded-2xl text-left transition transform hover:-translate-y-0.5 border ${
                    isSelected
                      ? 'bg-amber-600 text-white border-amber-400 ring-2 ring-amber-400/30'
                      : 'bg-stone-900/80 text-stone-300 border-stone-800 hover:border-amber-500/50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    {pin.type === 'artisan' ? (
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    ) : (
                      <Warehouse className="w-3.5 h-3.5 text-emerald-400" />
                    )}
                    <span className="font-bold text-xs truncate">{pin.state}</span>
                  </div>
                  <p className="text-[11px] font-medium opacity-90 truncate">{pin.name}</p>
                </button>
              );
            })}
          </div>

          <div className="relative z-10 flex items-center justify-between text-xs text-stone-400 pt-4 border-t border-stone-800">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Artisan Guild Hubs
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Fulfillment Centers
            </span>
          </div>
        </div>

        {/* Selected Hub Card Detail */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-900 text-xs font-bold mb-3">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
              <span>Verified Location Detail</span>
            </div>

            <h3 className="font-serif font-bold text-xl text-stone-900 mb-1">
              {selectedPin.name}
            </h3>
            <p className="text-xs text-amber-700 font-semibold mb-4">{selectedPin.state}</p>

            <div className="space-y-3 text-xs text-stone-700">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-400 block text-[10px] font-bold">Craft Specialty</span>
                <span className="font-bold text-stone-900">{selectedPin.craft}</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-400 block text-[10px] font-bold">Coordinates</span>
                <span className="font-mono text-stone-800">{selectedPin.lat}° N, {selectedPin.lng}° E</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-400 block text-[10px] font-bold">Service Status</span>
                <span className="font-bold text-emerald-700">Active - Direct Artisan Dispatch</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => alert(`Exploring products directly from ${selectedPin.name}`)}
            className="w-full mt-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md"
          >
            Explore Regional Products from {selectedPin.state}
          </button>
        </div>
      </div>
    </div>
  );
}
