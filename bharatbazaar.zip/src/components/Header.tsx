import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Globe,
  Sparkles,
  MapPin,
  Heart,
  User,
  Menu,
  X,
  Store,
  BarChart3,
  Flame,
  Mic,
  Check,
} from 'lucide-react';
import { LanguageCode, ActiveTab, FestivalTheme } from '../types';
import { LANGUAGE_OPTIONS, getTranslation } from '../lib/translations';

interface HeaderProps {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenAiAssistant: () => void;
  activeFestival: FestivalTheme | null;
  onToggleFestival: () => void;
  selectedStateFilter: string;
  onSelectStateFilter: (state: string) => void;
}

export function Header({
  currentLanguage,
  onLanguageChange,
  activeTab,
  onTabChange,
  searchQuery,
  onSearchChange,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenAiAssistant,
  activeFestival,
  onToggleFestival,
  selectedStateFilter,
  onSelectStateFilter,
}: HeaderProps) {
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [pincode, setPincode] = useState('560038');
  const [isChangingPincode, setIsChangingPincode] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const handleVoiceSearch = () => {
    setIsListening(true);
    setTimeout(() => {
      onSearchChange('Kashmiri Pashmina Shawl');
      setIsListening(false);
    }, 2000);
  };

  const [langSearchFilter, setLangSearchFilter] = useState('');
  const selectedLangObj = LANGUAGE_OPTIONS.find(l => l.code === currentLanguage) || LANGUAGE_OPTIONS[0];

  const filteredLanguages = LANGUAGE_OPTIONS.filter(l =>
    l.name.toLowerCase().includes(langSearchFilter.toLowerCase()) ||
    l.nativeName.toLowerCase().includes(langSearchFilter.toLowerCase()) ||
    l.code.toLowerCase().includes(langSearchFilter.toLowerCase())
  );

  return (
    <header id="bharat-bazaar-header" className="sticky top-0 z-40 bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#E5E0D8] transition-colors">
      {/* Top Banner: Free Delivery + Festival Theme Indicator */}
      {activeFestival && activeFestival.active ? (
        <div className={`py-1.5 px-6 bg-[#1A237E] text-[#FDFBF7] text-[11px] font-medium tracking-wide flex items-center justify-between border-b border-[#E5E0D8]/20`}>
          <div className="flex items-center gap-2 mx-auto sm:mx-0">
            <Flame className="w-3.5 h-3.5 text-[#C28E0E] animate-pulse" />
            <span className="font-serif italic text-amber-200">{activeFestival.greeting}</span>
            <span className="hidden md:inline border-l border-white/20 pl-2 text-stone-300">{activeFestival.bannerMessage}</span>
          </div>
          <button
            onClick={onToggleFestival}
            className="hidden sm:flex items-center gap-1 bg-white/10 hover:bg-white/20 px-2.5 py-0.5 rounded-full text-[10px] uppercase tracking-wider transition"
          >
            <span>Festive Edit</span>
            <Check className="w-3 h-3 text-[#C28E0E]" />
          </button>
        </div>
      ) : (
        <div className="py-1.5 px-6 bg-[#1A237E] text-[#FDFBF7] text-[10px] uppercase tracking-[0.2em] font-medium flex items-center justify-between">
          <div className="flex items-center gap-2 mx-auto sm:mx-0">
            <span className="w-2 h-2 rounded-full bg-[#C28E0E] animate-ping" />
            <span>{getTranslation('free_shipping_india', currentLanguage)}</span>
          </div>
          <div className="hidden sm:flex items-center gap-4 text-[#FDFBF7]/80">
            <span>Direct Artisan Guilds</span>
            <span>•</span>
            <span>100% GI Tag Authentic</span>
          </div>
        </div>
      )}

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between gap-6">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onTabChange('home')}
              className="flex items-center gap-3 group text-left focus:outline-none"
              id="brand-logo-btn"
            >
              <div className="w-10 h-10 rounded-full bg-[#1A237E] flex items-center justify-center text-[#FDFBF7] shadow-sm group-hover:scale-105 transition duration-200 border border-[#C28E0E]/40">
                <span className="font-serif text-xl font-normal">भ</span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-2xl font-normal tracking-tight text-[#1A237E]">
                    BharatBazaar
                  </span>
                  <span className="bg-[#C28E0E]/15 text-[#C28E0E] text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-widest border border-[#C28E0E]/30">
                    India
                  </span>
                </div>
                <p className="text-[10px] uppercase tracking-[0.15em] text-[#5C5C5C] font-semibold hidden sm:block">
                  {getTranslation('brand_tagline', currentLanguage)}
                </p>
              </div>
            </button>
          </div>

          {/* Search Bar & AI Helper */}
          <div className="flex-1 max-w-xl hidden md:block">
            <div className="relative flex items-center">
              <div className="relative flex-1 flex items-center">
                <Search className="absolute left-3.5 w-4 h-4 text-[#5C5C5C] pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => onSearchChange(e.target.value)}
                  placeholder={getTranslation('search_placeholder', currentLanguage)}
                  className="w-full pl-10 pr-20 py-2.5 bg-[#F5F2EC] border border-[#E5E0D8] rounded-l-full text-xs text-[#1A1A1A] placeholder-[#5C5C5C] focus:outline-none focus:ring-1 focus:ring-[#1A237E] focus:border-[#1A237E] transition"
                  id="search-input-main"
                />
                <button
                  onClick={handleVoiceSearch}
                  title="Voice Search"
                  className={`absolute right-3 p-1 rounded-full text-[#5C5C5C] hover:text-[#1A237E] transition ${
                    isListening ? 'animate-bounce text-[#1A237E]' : ''
                  }`}
                >
                  <Mic className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* AI Shopping Assistant Button */}
              <button
                onClick={onOpenAiAssistant}
                id="ai-assistant-btn"
                className="flex items-center gap-1.5 px-5 py-2.5 bg-[#1A237E] hover:bg-[#121858] text-white font-semibold text-[11px] uppercase tracking-wider rounded-r-full transition shadow-sm whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#C28E0E]" />
                <span>{getTranslation('ai_assistant', currentLanguage)}</span>
              </button>
            </div>
          </div>

          {/* Location / Pincode + Language + Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Pincode Deliverability Quick Tool */}
            <div className="hidden xl:flex items-center gap-1.5 text-xs text-[#5C5C5C] bg-[#F5F2EC] px-3 py-1.5 rounded-full border border-[#E5E0D8]">
              <MapPin className="w-3.5 h-3.5 text-[#1A237E] shrink-0" />
              <div>
                <span className="text-[9px] uppercase tracking-wider block text-[#5C5C5C]">Deliver to</span>
                {isChangingPincode ? (
                  <input
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={e => setPincode(e.target.value)}
                    onBlur={() => setIsChangingPincode(false)}
                    onKeyDown={e => e.key === 'Enter' && setIsChangingPincode(false)}
                    className="w-14 bg-white border border-[#1A237E] px-1 text-xs text-[#1A1A1A] focus:outline-none rounded"
                    autoFocus
                  />
                ) : (
                  <button
                    onClick={() => setIsChangingPincode(true)}
                    className="font-semibold text-[#1A1A1A] hover:text-[#1A237E] text-[11px]"
                  >
                    IN-{pincode}
                  </button>
                )}
              </div>
            </div>

            {/* Language Switcher */}
            <div className="relative">
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                id="language-selector-btn"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#1A237E]/20 text-[#1A237E] text-xs font-semibold hover:bg-[#1A237E]/5 transition"
              >
                <Globe className="w-3.5 h-3.5 text-[#1A237E]" />
                <span>{selectedLangObj.nativeName}</span>
              </button>

              {isLangDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-[#FDFBF7] border border-[#E5E0D8] rounded-2xl shadow-2xl z-50 p-3 animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#E5E0D8]">
                    <div className="text-[10px] font-bold text-[#1A237E] uppercase tracking-[0.2em]">
                      38 Indian Languages
                    </div>
                    <span className="text-[9px] text-[#C28E0E] font-semibold bg-[#C28E0E]/10 px-2 py-0.5 rounded-full">
                      22 Official + Regional
                    </span>
                  </div>

                  {/* Language Search Input */}
                  <div className="relative mb-2">
                    <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-[#5C5C5C]" />
                    <input
                      type="text"
                      placeholder="Search language or script..."
                      value={langSearchFilter}
                      onChange={e => setLangSearchFilter(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 bg-[#F5F2EC] border border-[#E5E0D8] rounded-xl text-xs text-[#1A1A1A] placeholder-[#5C5C5C] focus:outline-none focus:ring-1 focus:ring-[#1A237E]"
                    />
                  </div>

                  <div className="max-h-72 overflow-y-auto pr-1 grid grid-cols-2 gap-1.5">
                    {filteredLanguages.length > 0 ? (
                      filteredLanguages.map(lang => (
                        <button
                          key={lang.code}
                          onClick={() => {
                            onLanguageChange(lang.code);
                            setIsLangDropdownOpen(false);
                            setLangSearchFilter('');
                          }}
                          className={`flex flex-col items-start px-2.5 py-1.5 rounded-xl text-left transition ${
                            currentLanguage === lang.code
                              ? 'bg-[#1A237E] text-white font-bold'
                              : 'hover:bg-[#F5F2EC] text-[#1A1A1A]'
                          }`}
                        >
                          <span className="text-xs font-semibold">{lang.nativeName}</span>
                          <span className={`text-[10px] ${currentLanguage === lang.code ? 'text-amber-200' : 'text-[#5C5C5C]'}`}>
                            {lang.name}
                          </span>
                        </button>
                      ))
                    ) : (
                      <div className="col-span-2 py-4 text-center text-xs text-[#5C5C5C]">
                        No language matching "{langSearchFilter}"
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              id="header-cart-btn"
              className="relative p-2 text-[#1A237E] hover:bg-[#1A237E]/5 rounded-full transition"
              title="Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#C28E0E] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-[#1A237E] hover:text-[#121858]"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <div className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-[#5C5C5C]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => onSearchChange(e.target.value)}
              placeholder="Search Indian crafts, sarees, spices..."
              className="w-full pl-9 pr-24 py-2 bg-[#F5F2EC] border border-[#E5E0D8] rounded-full text-xs text-[#1A1A1A] focus:outline-none"
            />
            <button
              onClick={onOpenAiAssistant}
              className="absolute right-1 px-3 py-1 bg-[#1A237E] text-white text-[10px] font-semibold uppercase tracking-wider rounded-full flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-[#C28E0E]" />
              <span>AI Guide</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="mt-3 pt-2.5 border-t border-[#E5E0D8] flex items-center justify-between overflow-x-auto no-scrollbar gap-2 text-[11px] uppercase tracking-[0.15em] font-semibold">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onTabChange('home')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap ${
                activeTab === 'home'
                  ? 'bg-[#1A237E] text-white shadow-sm'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              Storefront
            </button>
            <button
              onClick={() => onTabChange('states')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'states'
                  ? 'bg-[#1A237E] text-white shadow-sm'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              <MapPin className="w-3.5 h-3.5 text-[#C28E0E]" />
              <span>{getTranslation('explore_states', currentLanguage)}</span>
            </button>
            <button
              onClick={() => onTabChange('artisans')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'artisans'
                  ? 'bg-[#1A237E] text-white shadow-sm'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              <User className="w-3.5 h-3.5 text-[#C28E0E]" />
              <span>{getTranslation('artisan_marketplace', currentLanguage)}</span>
            </button>
            <button
              onClick={() => onTabChange('maps')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap ${
                activeTab === 'maps'
                  ? 'bg-[#1A237E] text-white shadow-sm'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              Artisan Map
            </button>
            <button
              onClick={() => onTabChange('orders')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap ${
                activeTab === 'orders'
                  ? 'bg-[#1A237E] text-white shadow-sm'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              Track Orders
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onTabChange('seller_portal')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'seller_portal'
                  ? 'bg-[#C28E0E] text-white font-bold'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              <Store className="w-3.5 h-3.5 text-[#C28E0E]" />
              <span>{getTranslation('seller_portal', currentLanguage)}</span>
            </button>
            <button
              onClick={() => onTabChange('admin_dashboard')}
              className={`px-4 py-1.5 rounded-full transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'admin_dashboard'
                  ? 'bg-[#1A237E] text-white font-bold'
                  : 'text-[#5C5C5C] hover:text-[#1A237E] hover:bg-[#F5F2EC]'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-[#C28E0E]" />
              <span>{getTranslation('admin_dashboard', currentLanguage)}</span>
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
}
