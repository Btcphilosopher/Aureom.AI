import React, { useState } from 'react';
import { CartItem, Order } from '../types';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  QrCode,
  CreditCard,
  Building2,
  Banknote,
  Sparkles,
  MapPin,
  Lock,
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  appliedCoupon: string | null;
  isGiftWrapped: boolean;
  onOrderComplete: (order: Order) => void;
}

export function CheckoutModal({
  isOpen,
  onClose,
  cartItems,
  appliedCoupon,
  isGiftWrapped,
  onOrderComplete,
}: CheckoutModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'cod'>('upi');
  const [upiId, setUpiId] = useState('aarav@okaxis');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const [shippingAddress, setShippingAddress] = useState({
    fullName: 'Aarav Sharma',
    addressLine: '42 Lotus Villa, Indiranagar 100ft Road',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560038',
    phone: '+91 98765 43210',
  });

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discount = appliedCoupon ? Math.round(subtotal * 0.1) : 0;
  const giftWrapFee = isGiftWrapped ? 49 : 0;
  const shippingFee = subtotal > 999 ? 0 : 99;
  const grandTotal = Math.max(0, subtotal - discount + giftWrapFee + shippingFee);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartItems,
          totalAmount: grandTotal,
          shippingAddress,
          paymentMethod,
          paymentStatus: 'paid',
        }),
      });

      const data = await response.json();
      if (data.order) {
        setCreatedOrder(data.order);
        setIsProcessing(false);
        setIsSuccess(true);
        onOrderComplete(data.order);
      }
    } catch (err) {
      console.error('Order submission error:', err);
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-amber-200 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-stone-100 hover:bg-stone-200 rounded-full text-stone-700 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess && createdOrder ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-lg animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="font-serif text-3xl font-bold text-stone-900">
              Order Confirmed & Placed!
            </h2>
            <p className="text-xs text-stone-600 max-w-md mx-auto">
              Your order <span className="font-mono font-bold text-amber-700">{createdOrder.id}</span> has been dispatched directly to our artisan workshop. Live tracking is available now.
            </p>

            <div className="bg-stone-50 border border-stone-200 p-4 rounded-2xl max-w-md mx-auto text-left text-xs space-y-1">
              <div className="flex justify-between text-stone-600">
                <span>Estimated Delivery:</span>
                <span className="font-bold text-stone-900">{createdOrder.estimatedDelivery}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Tracking Number:</span>
                <span className="font-mono font-bold text-stone-900">{createdOrder.trackingNumber}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Amount Paid:</span>
                <span className="font-bold text-amber-700">₹{createdOrder.totalAmount.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md"
            >
              Continue Shopping
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 md:grid-cols-2">
            {/* Left Column: Delivery Address */}
            <div className="p-6 sm:p-8 bg-stone-50 border-r border-stone-200 space-y-4">
              <div className="flex items-center gap-2 text-amber-800 font-bold text-sm">
                <MapPin className="w-4 h-4 text-amber-600" />
                <span>Shipping & Delivery Address</span>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-stone-600 font-medium mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.fullName}
                    onChange={e => setShippingAddress({ ...shippingAddress, fullName: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-stone-600 font-medium mb-1">Street Address / House No.</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.addressLine}
                    onChange={e => setShippingAddress({ ...shippingAddress, addressLine: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-stone-600 font-medium mb-1">City</label>
                    <input
                      type="text"
                      required
                      value={shippingAddress.city}
                      onChange={e => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-600 font-medium mb-1">Pincode</label>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={shippingAddress.pincode}
                      onChange={e => setShippingAddress({ ...shippingAddress, pincode: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-600 font-medium mb-1">Mobile Number (for Order Updates)</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.phone}
                    onChange={e => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Modular Payment Options */}
            <div className="p-6 sm:p-8 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-stone-900 font-bold text-sm mb-4">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  <span>Modular Digital Payment</span>
                </div>

                {/* Payment Option Selector */}
                <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('upi')}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 font-semibold transition ${
                      paymentMethod === 'upi'
                        ? 'bg-amber-50 border-amber-600 text-amber-900'
                        : 'bg-stone-50 border-stone-200 text-stone-700'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-amber-600" />
                    <span>UPI / GPay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 font-semibold transition ${
                      paymentMethod === 'card'
                        ? 'bg-amber-50 border-amber-600 text-amber-900'
                        : 'bg-stone-50 border-stone-200 text-stone-700'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-amber-600" />
                    <span>Cards</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('netbanking')}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 font-semibold transition ${
                      paymentMethod === 'netbanking'
                        ? 'bg-amber-50 border-amber-600 text-amber-900'
                        : 'bg-stone-50 border-stone-200 text-stone-700'
                    }`}
                  >
                    <Building2 className="w-4 h-4 text-amber-600" />
                    <span>Net Banking</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cod')}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 font-semibold transition ${
                      paymentMethod === 'cod'
                        ? 'bg-amber-50 border-amber-600 text-amber-900'
                        : 'bg-stone-50 border-stone-200 text-stone-700'
                    }`}
                  >
                    <Banknote className="w-4 h-4 text-amber-600" />
                    <span>Pay on Delivery</span>
                  </button>
                </div>

                {/* Method Specific Interactive Panels */}
                {paymentMethod === 'upi' && (
                  <div className="bg-amber-50/50 p-3 rounded-xl border border-amber-200 text-xs space-y-2">
                    <span className="font-bold text-stone-800 block">Instant UPI Payment</span>
                    <input
                      type="text"
                      value={upiId}
                      onChange={e => setUpiId(e.target.value)}
                      placeholder="e.g. mobile@upi"
                      className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none"
                    />
                    <p className="text-[10px] text-stone-500">Supports PhonePe, Google Pay, Paytm, BHIM & CRED UPI</p>
                  </div>
                )}
              </div>

              {/* Submit & Grand Total */}
              <div className="pt-4 border-t border-stone-200 space-y-3">
                <div className="flex justify-between items-baseline font-serif">
                  <span className="text-xs text-stone-500 font-sans">Total Payable</span>
                  <span className="text-xl font-bold text-stone-900">₹{grandTotal.toLocaleString('en-IN')}</span>
                </div>

                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-amber-600/20 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span>Processing Payment securely...</span>
                  ) : (
                    <span>Pay ₹{grandTotal.toLocaleString('en-IN')} & Confirm Order</span>
                  )}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
