import React, { useState } from 'react';
import { StateMarketplace, Product } from '../types';
import { STATES_DATA } from '../data/mockData';
import { MapPin, Sparkles, ChevronRight, Award, Utensils, Users, ShoppingBag } from 'lucide-react';
import { ProductCard } from './ProductCard';

interface StateExplorerProps {
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  selectedStateId?: string;
  onSelectState: (stateId: string) => void;
}

export function StateExplorer({
  products,
  onSelectProduct,
  onAddToCart,
  selectedStateId,
  onSelectState,
}: StateExplorerProps) {
  const [activeStateId, setActiveStateId] = useState<string>(selectedStateId || STATES_DATA[0].id);

  const activeState = STATES_DATA.find(s => s.id === activeStateId) || STATES_DATA[0];

  const stateProducts = products.filter(
    p => p.stateOfOrigin.toLowerCase() === activeState.name.toLowerCase()
  );

  return (
    <div id="state-explorer-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="mb-8 text-center sm:text-left">
        <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C28E0E] block mb-1">
          Regional Heritage Marketplaces
        </span>
        <h2 className="font-serif text-3xl sm:text-4xl font-normal text-[#1A1A1A] tracking-tight">
          Explore India, State by State
        </h2>
        <p className="text-[#5C5C5C] text-sm max-w-2xl mt-1 italic font-serif">
          Every state holds centuries of distinct craft traditions, culinary secrets, and artisan guilds. Select a state to enter its regional marketplace.
        </p>
      </div>

      {/* State Selection Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
        {STATES_DATA.map(state => {
          const isActive = state.id === activeStateId;
          return (
            <button
              key={state.id}
              onClick={() => {
                setActiveStateId(state.id);
                onSelectState(state.id);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-semibold uppercase tracking-[0.15em] transition whitespace-nowrap border ${
                isActive
                  ? 'bg-[#1A237E] text-white border-[#1A237E] shadow-sm'
                  : 'bg-[#FDFBF7] text-[#5C5C5C] border-[#E5E0D8] hover:border-[#1A237E]/40 hover:text-[#1A237E]'
              }`}
            >
              <span className={`w-4 h-4 rounded-full text-[9px] flex items-center justify-center font-bold ${
                isActive ? 'bg-[#C28E0E] text-white' : 'bg-[#E5E0D8] text-[#1A1A1A]'
              }`}>
                {state.code}
              </span>
              <span>{state.name}</span>
            </button>
          );
        })}
      </div>

      {/* Selected State Hero Feature */}
      <div className="relative overflow-hidden rounded-3xl bg-[#1A237E] text-white mb-10 shadow-xl border border-[#E5E0D8]/20">
        <div className="absolute inset-0 z-0 opacity-30 mix-blend-luminosity">
          <img
            src={activeState.heroImage}
            alt={activeState.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A237E] via-[#1A237E]/80 to-transparent" />
        </div>

        <div className="relative z-10 p-6 sm:p-12">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div>
              <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C28E0E] block">
                State Marketplace • {activeState.code}
              </span>
              <h3 className="font-serif text-3xl sm:text-5xl font-normal text-white">
                {activeState.name}
              </h3>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/20 text-right">
              <span className="text-[9px] uppercase tracking-widest text-stone-300 block">Registered Artisans</span>
              <span className="text-xl font-bold text-amber-200">
                {activeState.artisanCount.toLocaleString('en-IN')}+
              </span>
            </div>
          </div>

          <p className="text-amber-200 text-base font-serif italic mb-3">{activeState.tagline}</p>
          <p className="text-stone-200 text-xs sm:text-sm max-w-3xl mb-6 leading-relaxed">
            {activeState.description}
          </p>

          {/* Highlights Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-white/15 text-xs">
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-2 text-[#C28E0E] font-semibold text-[11px] uppercase tracking-wider mb-2">
                <Award className="w-4 h-4 text-[#C28E0E]" />
                <span>Famous Heritage Crafts</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {activeState.famousCrafts.map((craft, i) => (
                  <span key={i} className="bg-white/10 text-white text-[11px] px-2.5 py-1 rounded-full border border-white/10">
                    {craft}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-2 text-[#C28E0E] font-semibold text-[11px] uppercase tracking-wider mb-2">
                <Sparkles className="w-4 h-4 text-[#C28E0E]" />
                <span>Regional Specialties</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {activeState.topSpecialties.map((spec, i) => (
                  <span key={i} className="bg-white/10 text-white text-[11px] px-2.5 py-1 rounded-full border border-white/10">
                    {spec}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-2 text-[#C28E0E] font-semibold text-[11px] uppercase tracking-wider mb-2">
                <Utensils className="w-4 h-4 text-[#C28E0E]" />
                <span>Famous Cuisine & Flavors</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {activeState.famousFood.map((food, i) => (
                  <span key={i} className="bg-white/10 text-white text-[11px] px-2.5 py-1 rounded-full border border-white/10">
                    {food}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* State Products Showcase */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="font-serif text-2xl font-normal text-[#1A1A1A]">
            Products from {activeState.name} ({stateProducts.length})
          </h3>
          <p className="text-xs text-[#5C5C5C]">Authentic regional goods handcrafted by verified state sellers</p>
        </div>
      </div>

      {stateProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stateProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      ) : (
        <div className="bg-[#F5F2EC] rounded-3xl p-8 text-center border border-[#E5E0D8]">
          <ShoppingBag className="w-10 h-10 text-[#C28E0E] mx-auto mb-2" />
          <h4 className="font-serif text-lg font-normal text-[#1A1A1A]">State Crafts Catalogue Expanding</h4>
          <p className="text-xs text-[#5C5C5C] max-w-md mx-auto mt-1">
            We are onboarding more certified weavers and craft guilds from {activeState.name}. Check out our featured state crafts above!
          </p>
        </div>
      )}
    </div>
  );
}
