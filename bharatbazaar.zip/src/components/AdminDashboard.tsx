import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { BarChart3, Users, ShieldAlert, CheckCircle2, TrendingUp, Layers } from 'lucide-react';

const STATE_REVENUE_DATA = [
  { state: 'Uttar Pradesh', gmv: 420000 },
  { state: 'Rajasthan', gmv: 380000 },
  { state: 'West Bengal', gmv: 310000 },
  { state: 'Tamil Nadu', gmv: 290000 },
  { state: 'Kerala', gmv: 240000 },
  { state: 'Jammu & Kashmir', gmv: 210000 },
];

const CATEGORY_DISTRIBUTION = [
  { name: 'Handloom & Sarees', value: 40, color: '#d97706' },
  { name: 'Spices & Teas', value: 25, color: '#059669' },
  { name: 'Home Decor & Pottery', value: 18, color: '#e11d48' },
  { name: 'Jewellery & Brass', value: 17, color: '#2563eb' },
];

export function AdminDashboard() {
  return (
    <div id="admin-dashboard-view" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-stone-900 text-amber-300 text-xs font-bold mb-2">
          <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
          <span>BharatBazaar Platform Intelligence</span>
        </div>
        <h2 className="font-serif text-3xl font-extrabold text-stone-900">
          National Marketplace Analytics & Governance
        </h2>
        <p className="text-stone-600 text-xs sm:text-sm mt-1">
          Real-time metrics on regional GMV, artisan guild onboarding, language session distribution, and GI Tag compliance.
        </p>
      </div>

      {/* Top Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
          <span className="text-xs text-stone-500 block">Total Annual GMV</span>
          <span className="font-serif font-extrabold text-2xl text-stone-900">₹18.5 Cr</span>
          <span className="text-[10px] text-emerald-700 font-bold block mt-1">+24% YoY Growth</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
          <span className="text-xs text-stone-500 block">Onboarded Artisans</span>
          <span className="font-serif font-extrabold text-2xl text-stone-900">121,400+</span>
          <span className="text-[10px] text-amber-700 font-bold block mt-1">Across 28 States & UTs</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
          <span className="text-xs text-stone-500 block">Active Language Sessions</span>
          <span className="font-serif font-extrabold text-2xl text-stone-900">13 Languages</span>
          <span className="text-[10px] text-stone-400 block mt-1">Highest: Hindi & Bengali</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
          <span className="text-xs text-stone-500 block">GI Tag Authenticity</span>
          <span className="font-serif font-extrabold text-2xl text-emerald-700">100% Verified</span>
          <span className="text-[10px] text-emerald-700 font-bold block mt-1">Zero Fake Knockoffs</span>
        </div>
      </div>

      {/* Recharts Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Bar Chart: State GMV Demand */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
          <h3 className="font-serif font-bold text-stone-900 text-base mb-4">
            State-by-State Gross Merchandise Value (₹)
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={STATE_REVENUE_DATA} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
                <XAxis dataKey="state" tick={{ fontSize: 10 }} interval={0} angle={-15} textAnchor="end" />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip
                  formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'GMV']}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="gmv" fill="#d97706" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart: Category Sales Distribution */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
          <h3 className="font-serif font-bold text-stone-900 text-base mb-4">
            Category Revenue Share (%)
          </h3>
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={CATEGORY_DISTRIBUTION}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                >
                  {CATEGORY_DISTRIBUTION.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Artisan Onboarding Approvals Queue */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
        <h3 className="font-serif font-bold text-stone-900 text-base mb-4">
          Pending Guild & Artisan Onboarding Approvals
        </h3>

        <div className="space-y-3 text-xs">
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between">
            <div>
              <span className="font-bold text-stone-900 block">Mithila Painting Artisan Collective</span>
              <span className="text-stone-500">Madhubani, Bihar • GI Tag Certification Submitted</span>
            </div>
            <button
              onClick={() => alert('Mithila Artisans approved!')}
              className="px-3 py-1.5 bg-emerald-700 text-white font-bold rounded-lg hover:bg-emerald-800"
            >
              Approve Guild
            </button>
          </div>

          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between">
            <div>
              <span className="font-bold text-stone-900 block">Channapatna Wooden Toys Guild</span>
              <span className="text-stone-500">Ramanagara, Karnataka • Non-toxic Lacquer Certified</span>
            </div>
            <button
              onClick={() => alert('Channapatna Guild approved!')}
              className="px-3 py-1.5 bg-emerald-700 text-white font-bold rounded-lg hover:bg-emerald-800"
            >
              Approve Guild
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
