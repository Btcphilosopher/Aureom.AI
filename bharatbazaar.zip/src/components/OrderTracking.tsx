import React, { useState } from 'react';
import { Order } from '../types';
import { Package, Truck, CheckCircle2, Clock, MapPin, Download, RefreshCw, ChevronRight } from 'lucide-react';

interface OrderTrackingProps {
  orders: Order[];
}

export function OrderTracking({ orders }: OrderTrackingProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order>(orders[0]);

  const stages = [
    { key: 'placed', label: 'Order Placed', desc: 'Verified by Seller' },
    { key: 'artisan_crafting', label: 'Artisan Handcrafting', desc: 'Craft Guild Workshop' },
    { key: 'quality_checked', label: 'GI Tag Quality Check', desc: 'Craft Council Inspection' },
    { key: 'shipped', label: 'Dispatched in Transit', desc: 'Express Speed Post' },
    { key: 'delivered', label: 'Delivered', desc: 'Destination Address' },
  ];

  const getCurrentStepIdx = (status: string) => {
    switch (status) {
      case 'placed': return 0;
      case 'artisan_crafting': return 1;
      case 'quality_checked': return 2;
      case 'shipped': return 3;
      case 'delivered': return 4;
      default: return 3;
    }
  };

  const currentIdx = getCurrentStepIdx(selectedOrder.status);

  return (
    <div id="order-tracking-view" className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="mb-8">
        <h2 className="font-serif text-3xl font-extrabold text-stone-900">
          Live Order & Shipment Tracking
        </h2>
        <p className="text-stone-600 text-xs sm:text-sm mt-1">
          Monitor your direct artisan orders, download digital GST invoices, and trace shipments across India.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Orders List */}
        <div className="space-y-3">
          <h3 className="font-bold text-stone-800 text-sm">Your Orders ({orders.length})</h3>
          {orders.map(order => {
            const isSelected = order.id === selectedOrder.id;
            return (
              <div
                key={order.id}
                onClick={() => setSelectedOrder(order)}
                className={`p-4 rounded-2xl border cursor-pointer transition ${
                  isSelected
                    ? 'bg-amber-50/80 border-amber-600 ring-2 ring-amber-500/20 shadow-sm'
                    : 'bg-white border-stone-200 hover:border-amber-300'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="font-mono font-bold text-xs text-stone-900">{order.id}</span>
                    <span className="text-[10px] text-stone-500 block">{order.date}</span>
                  </div>
                  <span className="bg-amber-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
                    {order.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="text-xs text-stone-700 font-medium line-clamp-1 mb-2">
                  {order.items.map(i => i.product.name).join(', ')}
                </div>

                <div className="flex justify-between items-center text-xs pt-2 border-t border-stone-100 font-serif">
                  <span className="text-stone-500 font-sans text-[11px]">Total Paid</span>
                  <span className="font-bold text-stone-900">₹{order.totalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Selected Order Detail & Interactive Timeline */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-stone-200">
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-700 block">
                Active Order Tracking
              </span>
              <h3 className="font-mono font-bold text-xl text-stone-900">
                {selectedOrder.id}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => alert(`Downloading GST Digital Receipt for ${selectedOrder.id}...`)}
                className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl flex items-center gap-1.5 border border-stone-300"
              >
                <Download className="w-3.5 h-3.5" />
                <span>GST Receipt</span>
              </button>
            </div>
          </div>

          {/* Timeline */}
          <div className="py-8">
            <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-6">
              Shipment Progress Lifecycle
            </h4>

            <div className="space-y-6 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
              {stages.map((stage, idx) => {
                const isCompleted = idx <= currentIdx;
                const isCurrent = idx === currentIdx;

                return (
                  <div key={stage.key} className="relative flex items-start gap-4">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 z-10 transition ${
                        isCompleted
                          ? 'bg-amber-600 text-white shadow-md'
                          : 'bg-stone-100 text-stone-400 border border-stone-300'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>

                    <div className="flex-1 pt-1">
                      <div className="flex justify-between items-baseline">
                        <h5 className={`text-xs font-bold ${isCurrent ? 'text-amber-700 font-extrabold text-sm' : 'text-stone-900'}`}>
                          {stage.label}
                        </h5>
                        {isCurrent && (
                          <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded">
                            Current Stage
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-500">{stage.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Location & Delivery Info */}
          <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-stone-800 font-bold">
              <MapPin className="w-4 h-4 text-amber-600" />
              <span>Current Status: {selectedOrder.currentLocation || 'In Transit'}</span>
            </div>
            <p className="text-stone-500">
              Estimated Delivery: <span className="font-bold text-stone-800">{selectedOrder.estimatedDelivery}</span>
            </p>
            <p className="text-stone-500">
              Tracking Number: <span className="font-mono font-bold text-stone-800">{selectedOrder.trackingNumber}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
