import React, { useState } from 'react';
import { Product } from '../types';
import { Star, ShieldCheck, ShoppingBag, Heart, MapPin, Tag } from 'lucide-react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onSelect: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

export function ProductCard({ product, onSelect, onAddToCart }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <div
      id={`product-card-${product.id}`}
      className="group relative rounded-2xl bg-[#FDFBF7] border border-[#E5E0D8] hover:border-[#1A237E]/40 transition-all duration-300 hover:shadow-xl hover:shadow-[#1A237E]/5 flex flex-col overflow-hidden"
    >
      {/* Image Container */}
      <div
        className="relative aspect-4/3 w-full overflow-hidden bg-[#F5F2EC] cursor-pointer"
        onClick={() => onSelect(product)}
      >
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
          {product.isGiTagged ? (
            <span className="bg-[#1A237E] text-white text-[9px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full flex items-center gap-1 shadow-md border border-[#C28E0E]/40">
              <ShieldCheck className="w-3 h-3 text-[#C28E0E]" />
              <span>GI Tag Authentic</span>
            </span>
          ) : (
            <span className="bg-[#2D5A27] text-white text-[9px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full shadow-md">
              {product.stateOfOrigin}
            </span>
          )}

          <button
            onClick={e => {
              e.stopPropagation();
              setIsWishlisted(!isWishlisted);
            }}
            className={`pointer-events-auto p-1.5 rounded-full backdrop-blur-md shadow-md transition ${
              isWishlisted
                ? 'bg-rose-600 text-white'
                : 'bg-white/80 text-[#5C5C5C] hover:text-rose-600 hover:bg-white'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* State Tag Overlay at Bottom */}
        <div className="absolute bottom-2 left-2.5 bg-[#1A1A1A]/80 backdrop-blur-sm text-[#FDFBF7] text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1">
          <MapPin className="w-2.5 h-2.5 text-[#C28E0E]" />
          <span>{product.stateOfOrigin}</span>
        </div>
      </div>

      {/* Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-[#5C5C5C] mb-1">
            <span className="font-semibold text-[#C28E0E] uppercase text-[10px] tracking-wider">{product.category}</span>
            <span className="flex items-center gap-1 font-bold text-[#1A1A1A]">
              <Star className="w-3 h-3 text-[#C28E0E] fill-[#C28E0E]" />
              {product.rating} <span className="text-[#5C5C5C] font-normal">({product.reviewCount})</span>
            </span>
          </div>

          <h3
            onClick={() => onSelect(product)}
            className="font-serif font-normal text-[#1A1A1A] text-base hover:text-[#1A237E] cursor-pointer line-clamp-2 leading-snug mb-2 transition"
          >
            {product.name}
          </h3>

          {product.artisanName && (
            <p className="text-[11px] text-[#5C5C5C] mb-3 flex items-center gap-1 italic font-serif">
              <span>Crafted by</span>
              <span className="font-semibold text-[#1A1A1A] not-italic">{product.artisanName}</span>
            </p>
          )}
        </div>

        {/* Pricing & Add Button */}
        <div className="pt-3 border-t border-[#E5E0D8] flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="font-serif font-bold text-lg text-[#1A237E]">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              {discountPercent > 0 && (
                <span className="text-xs text-[#5C5C5C] line-through">
                  ₹{product.originalPrice.toLocaleString('en-IN')}
                </span>
              )}
            </div>
            {discountPercent > 0 && (
              <span className="text-[10px] font-bold text-[#2D5A27] block uppercase tracking-wider">
                Save {discountPercent}% OFF
              </span>
            )}
          </div>

          <button
            onClick={() => onAddToCart(product)}
            id={`add-to-cart-${product.id}`}
            className="px-4 py-1.5 bg-[#1A237E] hover:bg-[#121858] text-white rounded-full text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#C28E0E]" />
            <span>Add</span>
          </button>
        </div>
      </div>
    </div>
  );
}
