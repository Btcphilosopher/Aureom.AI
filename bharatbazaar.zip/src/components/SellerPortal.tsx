import React, { useState } from 'react';
import { Store, PlusCircle, PackageCheck, BarChart2, ShieldCheck, CheckCircle2, MessageSquare } from 'lucide-react';
import { Product } from '../types';

interface SellerPortalProps {
  onAddProduct: (newProd: Partial<Product>) => void;
}

export function SellerPortal({ onAddProduct }: SellerPortalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'add_product' | 'inventory'>('overview');
  const [productForm, setProductForm] = useState({
    name: '',
    category: 'Handloom & Textiles',
    stateOfOrigin: 'Rajasthan',
    price: 2499,
    originalPrice: 3200,
    isGiTagged: true,
    giTagNumber: 'GI-RJ-2026-88',
    description: '',
    artisanName: '',
    materials: 'Pure Cotton, Natural Dyes',
  });

  const [formSuccess, setFormSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddProduct({
      name: productForm.name,
      category: productForm.category,
      stateOfOrigin: productForm.stateOfOrigin,
      price: Number(productForm.price),
      originalPrice: Number(productForm.originalPrice),
      isGiTagged: productForm.isGiTagged,
      giTagNumber: productForm.giTagNumber,
      description: productForm.description,
      artisanName: productForm.artisanName,
      materials: productForm.materials.split(','),
      rating: 5.0,
      reviewCount: 1,
      stock: 10,
      images: ['/src/assets/images/bharat_bazaar_hero_1785957854949.jpg'],
      specifications: {
        Origin: productForm.stateOfOrigin,
        Handcrafted: 'Yes',
      },
      seller: {
        id: 'seller_self',
        name: productForm.artisanName || 'Artisan Guild Member',
        location: productForm.stateOfOrigin,
        verified: true,
        rating: 4.9,
      },
      tags: ['handcrafted', 'artisan', 'authentic'],
    });

    setFormSuccess(true);
    setTimeout(() => {
      setFormSuccess(false);
      setActiveTab('overview');
    }, 2000);
  };

  return (
    <div id="seller-portal-view" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-900 text-xs font-bold mb-2">
            <Store className="w-3.5 h-3.5 text-orange-600" />
            <span>BharatBazaar Merchant & Guild Hub</span>
          </div>
          <h2 className="font-serif text-3xl font-extrabold text-stone-900">
            Artisan & Business Seller Portal
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm mt-1">
            Zero commission listing for direct Indian weavers, farmers, cooperatives, and small scale craftsmen.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('add_product')}
          className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          <span>List New Craft Product</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-stone-200 mb-8 text-xs font-bold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 px-4 transition border-b-2 ${
            activeTab === 'overview'
              ? 'border-amber-600 text-amber-900 font-extrabold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          Seller Overview
        </button>
        <button
          onClick={() => setActiveTab('add_product')}
          className={`pb-3 px-4 transition border-b-2 ${
            activeTab === 'add_product'
              ? 'border-amber-600 text-amber-900 font-extrabold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          Product Onboarding
        </button>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <span className="text-xs text-stone-500 block">Total GMV Revenue</span>
              <span className="font-serif font-extrabold text-2xl text-stone-900">₹1,84,500</span>
              <span className="text-[10px] text-emerald-700 font-bold block mt-1">+18.4% vs last month</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <span className="text-xs text-stone-500 block">Active Listings</span>
              <span className="font-serif font-extrabold text-2xl text-stone-900">24 Items</span>
              <span className="text-[10px] text-stone-400 block mt-1">100% GI Verified</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <span className="text-xs text-stone-500 block">Pending Orders</span>
              <span className="font-serif font-extrabold text-2xl text-amber-600">3 Orders</span>
              <span className="text-[10px] text-stone-400 block mt-1">Ready for Crafting</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <span className="text-xs text-stone-500 block">Artisan Rating</span>
              <span className="font-serif font-extrabold text-2xl text-stone-900">4.92 / 5</span>
              <span className="text-[10px] text-emerald-700 font-bold block mt-1">Master Guild Status</span>
            </div>
          </div>

          {/* Seller Guidelines Card */}
          <div className="bg-amber-50/80 p-6 rounded-3xl border border-amber-200 text-xs space-y-3">
            <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
              <ShieldCheck className="w-5 h-5 text-amber-600" />
              <span>GI Tag & Quality Certification Standard</span>
            </div>
            <p className="text-stone-700 leading-relaxed">
              To preserve authentic Indian heritage, every product listed under "GI Tag Authentic" undergoes inspection by state handicraft development corporations. BharatBazaar charges 0% commission on verified direct artisan sales.
            </p>
          </div>
        </div>
      )}

      {activeTab === 'add_product' && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm max-w-2xl mx-auto">
          <h3 className="font-serif text-xl font-bold text-stone-900 mb-4">
            List New Handcrafted Item
          </h3>

          {formSuccess ? (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center text-emerald-800 text-xs space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <p className="font-bold text-sm">Product Listed Successfully!</p>
              <p>Your item is now live across all 13 supported Indian languages.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1">Product Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sanganeri Block Print Cotton Dupatta"
                  value={productForm.name}
                  onChange={e => setProductForm({ ...productForm, name: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-bold mb-1">Category</label>
                  <select
                    value={productForm.category}
                    onChange={e => setProductForm({ ...productForm, category: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none"
                  >
                    <option>Handloom & Textiles</option>
                    <option>Handicrafts</option>
                    <option>Fashion</option>
                    <option>Spices</option>
                    <option>Tea & Coffee</option>
                    <option>Ayurveda</option>
                    <option>Jewellery</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-700 font-bold mb-1">State of Origin</label>
                  <input
                    type="text"
                    required
                    value={productForm.stateOfOrigin}
                    onChange={e => setProductForm({ ...productForm, stateOfOrigin: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-bold mb-1">Price (₹ INR)</label>
                  <input
                    type="number"
                    required
                    value={productForm.price}
                    onChange={e => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-bold mb-1">Master Artisan Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Master Weaver / Artist Name"
                    value={productForm.artisanName}
                    onChange={e => setProductForm({ ...productForm, artisanName: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">Item Description & Craft Story</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe the weaving technique, natural dye materials, and cultural heritage..."
                  value={productForm.description}
                  onChange={e => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md"
              >
                Publish to BharatBazaar Marketplace
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
