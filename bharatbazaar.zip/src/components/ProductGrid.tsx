import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { Filter, ShieldCheck, Sparkles, SlidersHorizontal, Search } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  searchQuery: string;
}

const CATEGORIES = [
  'All',
  'Handloom & Textiles',
  'Fashion',
  'Handicrafts',
  'Spices',
  'Home & Kitchen',
  'Tea & Coffee',
  'Ayurveda',
  'Jewellery',
  'Pottery',
];

export function ProductGrid({
  products,
  onSelectProduct,
  onAddToCart,
  selectedCategory,
  onSelectCategory,
  searchQuery,
}: ProductGridProps) {
  const [giOnlyFilter, setGiOnlyFilter] = useState(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'rating'>('featured');
  const [selectedState, setSelectedState] = useState<string>('All');

  const availableStates = useMemo(() => {
    const set = new Set(products.map(p => p.stateOfOrigin));
    return ['All', ...Array.from(set)];
  }, [products]);

  const filteredProducts = useMemo(() => {
    let list = [...products];

    if (selectedCategory !== 'All') {
      list = list.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());
    }

    if (selectedState !== 'All') {
      list = list.filter(p => p.stateOfOrigin.toLowerCase() === selectedState.toLowerCase());
    }

    if (giOnlyFilter) {
      list = list.filter(p => p.isGiTagged);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.stateOfOrigin.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    if (sortBy === 'price_low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price_high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  }, [products, selectedCategory, selectedState, giOnlyFilter, searchQuery, sortBy]);

  return (
    <div id="product-grid-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Category Pills Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C28E0E] block">
            The Curation
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-normal text-[#1A1A1A]">
            Handcrafted Treasures of India
          </h2>
        </div>
        <span className="text-[11px] text-[#5C5C5C] font-semibold uppercase tracking-wider hidden sm:block">
          {filteredProducts.length} authentic items
        </span>
      </div>

      {/* Category Horizontal Scroll */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 no-scrollbar">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => onSelectCategory(cat)}
            className={`px-5 py-2 rounded-full text-[10px] font-semibold uppercase tracking-[0.15em] whitespace-nowrap transition border ${
              selectedCategory === cat
                ? 'bg-[#1A237E] text-white border-[#1A237E] shadow-sm'
                : 'bg-[#FDFBF7] text-[#5C5C5C] border-[#E5E0D8] hover:border-[#1A237E]/40 hover:text-[#1A237E]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Filter Control Bar */}
      <div className="bg-[#F5F2EC] border border-[#E5E0D8] rounded-2xl p-4 mb-8 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* GI Tag Filter Toggle */}
          <button
            onClick={() => setGiOnlyFilter(!giOnlyFilter)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full border text-[10px] font-semibold uppercase tracking-wider transition ${
              giOnlyFilter
                ? 'bg-[#1A237E] text-white border-[#1A237E] shadow-sm'
                : 'bg-[#FDFBF7] text-[#5C5C5C] border-[#E5E0D8] hover:border-[#1A237E]'
            }`}
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${giOnlyFilter ? 'text-[#C28E0E]' : 'text-[#2D5A27]'}`} />
            <span>GI Tag Certified Only</span>
          </button>

          {/* State Filter Dropdown */}
          <div className="flex items-center gap-1.5 bg-[#FDFBF7] border border-[#E5E0D8] px-3.5 py-1.5 rounded-full">
            <span className="text-[#5C5C5C] text-[10px] uppercase tracking-wider font-semibold">State:</span>
            <select
              value={selectedState}
              onChange={e => setSelectedState(e.target.value)}
              className="bg-transparent font-bold text-[#1A1A1A] focus:outline-none cursor-pointer text-xs"
            >
              {availableStates.map(st => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-3.5 h-3.5 text-[#5C5C5C]" />
          <span className="text-[#5C5C5C] text-[10px] uppercase tracking-wider font-semibold">Sort:</span>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="bg-[#FDFBF7] border border-[#E5E0D8] px-3.5 py-1.5 rounded-full font-semibold text-[#1A1A1A] focus:outline-none text-xs cursor-pointer"
          >
            <option value="featured">Featured Curations</option>
            <option value="rating">Highest Rated</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      ) : (
        <div className="py-16 text-center bg-[#F5F2EC] rounded-3xl border border-dashed border-[#E5E0D8]">
          <Search className="w-12 h-12 text-[#5C5C5C] mx-auto mb-3" />
          <h3 className="font-serif text-xl font-normal text-[#1A1A1A]">No authentic items found</h3>
          <p className="text-[#5C5C5C] text-xs mt-1">
            Try adjusting your search query, state filter, or GI Tag toggle.
          </p>
          <button
            onClick={() => {
              onSelectCategory('All');
              setSelectedState('All');
              setGiOnlyFilter(false);
            }}
            className="mt-4 px-6 py-2.5 bg-[#1A237E] text-white font-semibold text-xs uppercase tracking-wider rounded-full"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
}
