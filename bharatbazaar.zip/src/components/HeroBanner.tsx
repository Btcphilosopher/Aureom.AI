import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, HeartHandshake, Compass, Award } from 'lucide-react';
import { LanguageCode } from '../types';
import { getTranslation } from '../lib/translations';

interface HeroBannerProps {
  currentLanguage: LanguageCode;
  onExploreStates: () => void;
  onExploreArtisans: () => void;
  onSelectCategory: (cat: string) => void;
  onOpenAiAssistant: () => void;
}

export function HeroBanner({
  currentLanguage,
  onExploreStates,
  onExploreArtisans,
  onSelectCategory,
  onOpenAiAssistant,
}: HeroBannerProps) {
  return (
    <div id="hero-banner-container" className="relative overflow-hidden bg-[#1A237E] text-white rounded-3xl mx-4 sm:mx-6 lg:mx-8 my-6 shadow-xl border border-[#E5E0D8]/20">
      {/* Background Image with Warm Overlay */}
      <div className="absolute inset-0 z-0 opacity-30 mix-blend-luminosity">
        <img
          src="/src/assets/images/bharat_bazaar_hero_1785957854949.jpg"
          alt="BharatBazaar Indian Craft Heritage"
          className="w-full h-full object-cover object-center scale-105 transform hover:scale-100 transition duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1A237E] via-[#1A237E]/90 to-[#121858]/80" />
      </div>

      {/* Decorative Gold Border Accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-[#C28E0E]" />

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl px-6 sm:px-12 py-12 sm:py-16">
        {/* Editorial Eyebrow */}
        <div className="space-y-1 mb-4">
          <span className="text-[11px] uppercase tracking-[0.3em] text-[#C28E0E] font-bold block">
            The Artisan Spotlight
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-white leading-[1.05]">
            Crafted by Hand, <br />
            Rooted in Heritage.
          </h1>
        </div>

        {/* Editorial Subtitle */}
        <p className="text-stone-200 text-sm sm:text-base max-w-xl mb-8 leading-relaxed italic font-serif">
          Celebrating the intricate geometry of Banarasi silk, the earthy soul of Terracotta, and the warmth of Kashmiri Pashmina. Direct weaver looms connected to world homes.
        </p>

        {/* Action Pill Buttons */}
        <div className="flex flex-wrap items-center gap-4 mb-10">
          <button
            onClick={onExploreStates}
            id="hero-explore-states-btn"
            className="px-8 py-3 bg-[#FDFBF7] hover:bg-white text-[#1A237E] font-semibold text-xs uppercase tracking-[0.2em] rounded-full shadow-md flex items-center gap-2 transition"
          >
            <span>Shop the Edit</span>
            <ArrowRight className="w-4 h-4 text-[#C28E0E]" />
          </button>

          <button
            onClick={onExploreArtisans}
            id="hero-explore-artisans-btn"
            className="px-8 py-3 bg-white/10 hover:bg-white/20 border border-white/30 backdrop-blur-md text-white font-semibold text-xs uppercase tracking-[0.2em] rounded-full flex items-center gap-2 transition"
          >
            <HeartHandshake className="w-4 h-4 text-[#C28E0E]" />
            <span>Meet Local Guilds</span>
          </button>

          <button
            onClick={onOpenAiAssistant}
            className="px-6 py-3 bg-[#C28E0E] hover:bg-[#a6780b] text-white text-xs font-semibold uppercase tracking-[0.15em] rounded-full flex items-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4 text-amber-200" />
            <span>AI Cultural Guide</span>
          </button>
        </div>

        {/* Value Proposition Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-6 border-t border-white/15 text-xs text-stone-200">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#C28E0E] shrink-0" />
            <div>
              <span className="font-semibold text-white block">GI Tag Authentic</span>
              <span className="text-[10px] text-stone-300 uppercase tracking-wider">100% Certified</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <HeartHandshake className="w-4 h-4 text-[#C28E0E] shrink-0" />
            <div>
              <span className="font-semibold text-white block">Direct Artisan Hub</span>
              <span className="text-[10px] text-stone-300 uppercase tracking-wider">0% Commission</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <Compass className="w-4 h-4 text-[#C28E0E] shrink-0" />
            <div>
              <span className="font-semibold text-white block">28 States & UTs</span>
              <span className="text-[10px] text-stone-300 uppercase tracking-wider">Regional Legacy</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <Award className="w-4 h-4 text-[#C28E0E] shrink-0" />
            <div>
              <span className="font-semibold text-white block">38 Languages</span>
              <span className="text-[10px] text-stone-300 uppercase tracking-wider">National Reach</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
