import React, { useState } from 'react';
import { Artisan, Product } from '../types';
import { ARTISANS_DATA } from '../data/mockData';
import { Award, MapPin, HeartHandshake, Star, Video, CheckCircle2, ShieldCheck } from 'lucide-react';
import { ProductCard } from './ProductCard';

interface ArtisanMarketplaceProps {
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

export function ArtisanMarketplace({ products, onSelectProduct, onAddToCart }: ArtisanMarketplaceProps) {
  const [selectedArtisan, setSelectedArtisan] = useState<Artisan>(ARTISANS_DATA[0]);

  const artisanProducts = products.filter(
    p => p.artisanId === selectedArtisan.id || p.stateOfOrigin === selectedArtisan.state
  );

  return (
    <div id="artisan-marketplace-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8 text-center sm:text-left">
        <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C28E0E] block mb-1">
          Craft Master Directory
        </span>
        <h2 className="font-serif text-3xl sm:text-4xl font-normal text-[#1A1A1A] tracking-tight">
          Meet India’s Master Artisans
        </h2>
        <p className="text-[#5C5C5C] text-sm max-w-2xl mt-1 italic font-serif">
          Support multigenerational artisan families preserving India’s intangible cultural heritage. Every order goes directly to their workshops with zero intermediary exploitation.
        </p>
      </div>

      {/* Grid of Artisans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {ARTISANS_DATA.map(artisan => {
          const isSelected = artisan.id === selectedArtisan.id;
          return (
            <div
              key={artisan.id}
              onClick={() => setSelectedArtisan(artisan)}
              className={`cursor-pointer rounded-2xl bg-[#FDFBF7] border p-5 transition duration-300 hover:shadow-lg flex flex-col justify-between ${
                isSelected
                  ? 'border-[#1A237E] ring-1 ring-[#1A237E] shadow-md'
                  : 'border-[#E5E0D8] hover:border-[#1A237E]/40'
              }`}
            >
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <img
                    src={artisan.avatar}
                    alt={artisan.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-[#C28E0E] shadow-sm"
                  />
                  <div>
                    <h3 className="font-serif font-normal text-[#1A1A1A] text-base leading-snug">{artisan.name}</h3>
                    <p className="text-[10px] uppercase tracking-wider text-[#C28E0E] font-bold">{artisan.craftName}</p>
                    <div className="flex items-center gap-1 text-[11px] text-[#5C5C5C] mt-0.5">
                      <MapPin className="w-3 h-3 text-[#1A237E]" />
                      <span>{artisan.city}, {artisan.state}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-[#5C5C5C] line-clamp-2 mb-4 italic font-serif">"{artisan.story}"</p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#E5E0D8] text-[11px]">
                <span className="font-semibold text-[#1A1A1A]">
                  {artisan.familyGenerations} Gen Heritage
                </span>
                <span className="flex items-center gap-1 bg-[#1A237E]/5 text-[#1A237E] font-bold px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 text-[#C28E0E] fill-[#C28E0E]" />
                  {artisan.rating}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Artisan Deep Dive Card */}
      <div className="bg-[#1A237E] text-white rounded-3xl p-6 sm:p-12 mb-10 shadow-xl border border-[#E5E0D8]/20 relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center relative z-10">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-4/3 border border-[#C28E0E]/40">
            <img
              src={selectedArtisan.coverImage}
              alt={selectedArtisan.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A237E]/90 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 text-xs">
              <span className="bg-[#C28E0E] text-white font-bold px-3 py-1 rounded-full text-[9px] uppercase tracking-widest mb-1 inline-block">
                Master Workshop
              </span>
              <p className="text-stone-200 font-medium text-[11px]">{selectedArtisan.workshopLocation.address}</p>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-amber-200 text-xs font-semibold mb-3 border border-white/20">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C28E0E]" />
              <span>Verified Direct Artisan Guild</span>
            </div>

            <h3 className="font-serif text-3xl sm:text-4xl font-normal text-white mb-1">
              {selectedArtisan.name}
            </h3>
            <p className="text-[#C28E0E] text-xs font-bold uppercase tracking-[0.2em] mb-4">{selectedArtisan.craftName}</p>

            <p className="text-stone-200 text-sm leading-relaxed mb-6 font-serif italic">
              {selectedArtisan.story}
            </p>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3 bg-white/5 p-4 rounded-2xl border border-white/10 text-center mb-6">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-stone-300 block">Experience</span>
                <span className="text-lg font-bold text-amber-200">{selectedArtisan.experienceYears} Years</span>
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-stone-300 block">Family Legacy</span>
                <span className="text-lg font-bold text-amber-200">{selectedArtisan.familyGenerations}th Generation</span>
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-stone-300 block">Craft Rating</span>
                <span className="text-lg font-bold text-amber-200 flex items-center justify-center gap-1">
                  <Star className="w-4 h-4 text-[#C28E0E] fill-[#C28E0E]" />
                  {selectedArtisan.rating}
                </span>
              </div>
            </div>

            {/* Certifications */}
            <div>
              <span className="text-[10px] font-bold text-stone-300 uppercase tracking-widest block mb-2">
                Certifications & National Honors
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedArtisan.certifications.map((cert, i) => (
                  <span
                    key={i}
                    className="flex items-center gap-1.5 bg-white/10 border border-white/20 text-white text-xs px-3 py-1 rounded-full"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#C28E0E]" />
                    <span>{cert}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Artisan Products Collection */}
      <h3 className="font-serif text-2xl font-normal text-[#1A1A1A] mb-6">
        Handcrafted Collection by {selectedArtisan.name}
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {artisanProducts.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onSelect={onSelectProduct}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>
    </div>
  );
}
