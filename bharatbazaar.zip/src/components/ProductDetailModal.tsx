import React, { useState } from 'react';
import { Product } from '../types';
import {
  X,
  Star,
  ShieldCheck,
  ShoppingBag,
  Heart,
  MapPin,
  Truck,
  Rotate3d,
  Check,
  ChevronRight,
  MessageSquare,
  HelpCircle,
  Award,
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (p: Product, qty: number) => void;
  onBuyNow: (p: Product) => void;
}

export function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
}: ProductDetailModalProps) {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [pincode, setPincode] = useState('560038');
  const [deliveryStatus, setDeliveryStatus] = useState<string | null>(null);
  const [is360Active, setIs360Active] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);

  const checkPincodeDelivery = () => {
    if (pincode.length === 6) {
      setDeliveryStatus('Delivery Available in 2-3 Days via India Post Speed & Express');
    } else {
      setDeliveryStatus('Please enter a valid 6-digit Indian Pincode');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in">
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-amber-200 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-white/80 hover:bg-white rounded-full text-stone-700 shadow-md transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 sm:p-10">
          {/* Left: Product Images & 360 Viewer */}
          <div className="flex flex-col gap-4">
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-inner group">
              <img
                src={product.images[selectedImageIdx]}
                alt={product.name}
                className={`w-full h-full object-cover transition-transform duration-300 ${
                  is360Active ? 'cursor-grab active:cursor-grabbing' : ''
                }`}
                style={{
                  transform: is360Active ? `rotate(${rotationAngle}deg) scale(1.05)` : 'none',
                }}
                onMouseMove={e => {
                  if (is360Active) {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    setRotationAngle(Math.round((x / rect.width) * 360));
                  }
                }}
              />

              {/* 360 Viewer Toggle Button */}
              <button
                onClick={() => setIs360Active(!is360Active)}
                className={`absolute bottom-3 right-3 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition ${
                  is360Active
                    ? 'bg-amber-600 text-white'
                    : 'bg-white/90 text-stone-800 hover:bg-white'
                }`}
              >
                <Rotate3d className="w-4 h-4 text-amber-500" />
                <span>{is360Active ? '360° Interactive Active' : 'Enable 360° View'}</span>
              </button>

              {product.isGiTagged && (
                <div className="absolute top-3 left-3 bg-emerald-700 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                  <ShieldCheck className="w-4 h-4 text-emerald-200" />
                  <span>{product.giTagNumber || 'GI Tag Certified'}</span>
                </div>
              )}
            </div>

            {/* Thumbnail Gallery */}
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedImageIdx(idx);
                    setIs360Active(false);
                  }}
                  className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 transition ${
                    selectedImageIdx === idx ? 'border-amber-600 ring-2 ring-amber-500/30' : 'border-stone-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Right: Info & Actions */}
          <div className="flex flex-col justify-between">
            <div>
              {/* Origin & Category Tag */}
              <div className="flex items-center gap-2 mb-2 text-xs font-bold text-amber-700">
                <span className="flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>State of Origin: {product.stateOfOrigin}</span>
                </span>
                <span className="bg-stone-100 text-stone-700 px-2.5 py-1 rounded-lg">
                  {product.category}
                </span>
              </div>

              {/* Title */}
              <h2 className="font-serif text-2xl font-bold text-stone-900 mb-2 leading-snug">
                {product.name}
              </h2>

              {/* Ratings & Reviews */}
              <div className="flex items-center gap-3 text-xs mb-4">
                <span className="flex items-center gap-1 bg-amber-100 text-amber-900 font-extrabold px-2 py-0.5 rounded">
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  {product.rating}
                </span>
                <span className="text-stone-500">{product.reviewCount} Verified Buyer Reviews</span>
                <span className="text-stone-300">•</span>
                <span className="text-emerald-700 font-bold">In Stock ({product.stock} left)</span>
              </div>

              {/* Price Block */}
              <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200/80 mb-6 flex items-baseline justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-stone-500 block">
                    Special Direct Price
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif font-extrabold text-3xl text-stone-900">
                      ₹{product.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-sm text-stone-400 line-through">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="bg-emerald-700 text-white font-bold text-xs px-2.5 py-1 rounded-full">
                    Save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] text-stone-500 block mt-1">Inclusive of all Taxes</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-stone-600 leading-relaxed mb-6">
                {product.description}
              </p>

              {/* Materials & Specifications */}
              <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 mb-6 text-xs">
                <span className="font-bold text-stone-900 block mb-2">Authentic Craft Specifications:</span>
                <div className="grid grid-cols-2 gap-2 text-stone-600">
                  {Object.entries(product.specifications).map(([key, val]) => (
                    <div key={key}>
                      <span className="text-stone-400 font-medium">{key}: </span>
                      <span className="font-semibold text-stone-800">{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pincode Estimator */}
              <div className="mb-6">
                <span className="text-xs font-bold text-stone-800 block mb-1">
                  Check Delivery Speed & Pincode:
                </span>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Truck className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={e => setPincode(e.target.value)}
                      placeholder="Enter 6-digit Pincode"
                      className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <button
                    onClick={checkPincodeDelivery}
                    className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs rounded-xl"
                  >
                    Check
                  </button>
                </div>
                {deliveryStatus && (
                  <p className="text-xs text-emerald-700 font-medium mt-1 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>{deliveryStatus}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Quantity & Action Buttons */}
            <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center gap-3">
              {/* Quantity Selector */}
              <div className="flex items-center border border-stone-300 rounded-xl overflow-hidden bg-stone-50">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2.5 text-stone-700 hover:bg-stone-200 font-bold"
                >
                  -
                </button>
                <span className="px-4 py-2.5 text-xs font-bold text-stone-900">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2.5 text-stone-700 hover:bg-stone-200 font-bold"
                >
                  +
                </button>
              </div>

              <button
                onClick={() => {
                  onAddToCart(product, quantity);
                  onClose();
                }}
                className="flex-1 w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md shadow-amber-600/20"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add {quantity} to Cart</span>
              </button>

              <button
                onClick={() => {
                  onBuyNow(product);
                  onClose();
                }}
                className="flex-1 w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md"
              >
                <span>Express Checkout</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
