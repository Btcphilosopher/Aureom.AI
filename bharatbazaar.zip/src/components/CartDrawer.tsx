import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Tag, Gift } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: () => void;
  appliedCoupon: string | null;
  onApplyCoupon: (code: string) => void;
  isGiftWrapped: boolean;
  onToggleGiftWrap: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  appliedCoupon,
  onApplyCoupon,
  isGiftWrapped,
  onToggleGiftWrap,
}: CartDrawerProps) {
  const [couponInput, setCouponInput] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discount = appliedCoupon ? Math.round(subtotal * 0.1) : 0;
  const giftWrapFee = isGiftWrapped ? 49 : 0;
  const shippingFee = subtotal > 999 ? 0 : 99;
  const grandTotal = Math.max(0, subtotal - discount + giftWrapFee + shippingFee);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end animate-in fade-in">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-amber-200">
        {/* Cart Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-700" />
            <h2 className="font-serif font-bold text-stone-900 text-lg">Your Artisan Basket</h2>
            <span className="bg-amber-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {cartItems.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-stone-100">
          {cartItems.length > 0 ? (
            cartItems.map(item => (
              <div key={item.product.id} className="py-4 flex gap-3">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-20 h-20 rounded-xl object-cover border border-stone-200"
                />
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h4 className="font-bold text-stone-900 text-xs line-clamp-2 leading-snug">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.product.id)}
                        className="text-stone-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="text-[10px] text-amber-700 font-semibold block mt-0.5">
                      {item.product.stateOfOrigin} Craft
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    {/* Quantity counter */}
                    <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="px-2 py-0.5 hover:bg-stone-100 font-bold"
                      >
                        -
                      </button>
                      <span className="px-2.5 py-0.5 font-bold text-stone-900">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="px-2 py-0.5 hover:bg-stone-100 font-bold"
                      >
                        +
                      </button>
                    </div>

                    <span className="font-serif font-bold text-stone-900 text-sm">
                      ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-stone-500">
              <ShoppingBag className="w-12 h-12 text-stone-300 mb-2" />
              <p className="font-bold text-stone-700">Your basket is empty</p>
              <p className="text-xs text-stone-400 mt-1">
                Explore handloom sarees, spices, and state crafts!
              </p>
            </div>
          )}
        </div>

        {/* Cart Footer */}
        {cartItems.length > 0 && (
          <div className="p-4 border-t border-stone-200 bg-stone-50 space-y-3">
            {/* Promo Code Input */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Tag className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-stone-400" />
                <input
                  type="text"
                  value={couponInput}
                  onChange={e => setCouponInput(e.target.value.toUpperCase())}
                  placeholder="Promo Code (BHARAT10)"
                  className="w-full pl-8 pr-2 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-mono uppercase text-stone-900 focus:outline-none focus:border-amber-500"
                />
              </div>
              <button
                onClick={() => {
                  onApplyCoupon(couponInput || 'BHARAT10');
                  setCouponInput('');
                }}
                className="px-3 py-1.5 bg-stone-900 text-white font-bold text-xs rounded-lg hover:bg-stone-800"
              >
                Apply
              </button>
            </div>

            {appliedCoupon && (
              <p className="text-[11px] text-emerald-700 font-bold flex items-center justify-between">
                <span>Coupon '{appliedCoupon}' Applied (-10%)</span>
                <span>-₹{discount.toLocaleString('en-IN')}</span>
              </p>
            )}

            {/* Gift Wrap Option */}
            <label className="flex items-center justify-between text-xs text-stone-700 cursor-pointer pt-1">
              <div className="flex items-center gap-1.5">
                <Gift className="w-4 h-4 text-rose-500" />
                <span>Handmade Festive Gift Wrap (+₹49)</span>
              </div>
              <input
                type="checkbox"
                checked={isGiftWrapped}
                onChange={onToggleGiftWrap}
                className="rounded accent-amber-600"
              />
            </label>

            {/* Price Calculations */}
            <div className="pt-2 border-t border-stone-200 space-y-1 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Discount</span>
                  <span>-₹{discount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Delivery Charge</span>
                <span>{shippingFee === 0 ? <span className="text-emerald-700 font-bold">FREE</span> : `₹${shippingFee}`}</span>
              </div>
              <div className="flex justify-between font-serif font-extrabold text-stone-900 text-base pt-2 border-t border-stone-200">
                <span>Grand Total</span>
                <span>₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-amber-600/20 flex items-center justify-center gap-2"
            >
              <span>Proceed to Payment</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
