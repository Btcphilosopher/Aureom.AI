package com.example.domain.model

import com.example.core.i18n.AppLanguage

enum class KioskFlow {
  BUY_CARD,
  RELOAD_CARD,
  CHECK_BALANCE,
  PLAN_JOURNEY,
  HELP_ACCESSIBILITY,
  STAFF_WORKSPACE,
}

enum class StepProgress(val stepNumber: Int) {
  CHOOSE(1),
  REVIEW_AND_PAY(2),
  COLLECT(3),
}

enum class ProductCategory {
  NEW_CARD,
  RELOAD,
  PASS,
}

enum class EligibilityRestriction {
  NONE,
  REDUCED_FARE_VERIFIED,
  DEMO_ADULT,
}

enum class RefundRule {
  NON_REFUNDABLE_ISSUE_FEE,
  REFUNDABLE_PRIOR_TO_FIRST_USE,
  STORE_CREDIT_ONLY,
}

enum class PaymentMethod {
  CONTACTLESS_NFC,
  CHIP_CARD,
  CASH,
}

enum class PaymentState {
  CREATED,
  AWAITING_PAYMENT,
  PROCESSING,
  CONFIRMED,
  DECLINED,
  CANCELLED,
  OUTCOME_UNKNOWN,
}

enum class PaymentSubState {
  NONE,
  AUTHORIZED,
  CAPTURED,
  REVERSED,
  REFUND_REQUESTED,
  REFUND_COMPLETED,
}

enum class OrderState {
  DRAFT,
  PRICED,
  AWAITING_PAYMENT,
  PAYMENT_CONFIRMED,
  FULFILLING,
  COMPLETED,
  FULFILLMENT_FAILED,
  NEEDS_RECONCILIATION,
  CANCELLED,
  EXPIRED,
}

enum class FulfilmentState {
  PENDING,
  PROVISIONING,
  PROVISIONED_RESPONSE_LOST,
  PROVISIONED,
  DISPENSING,
  DISPENSED_AWAITING_COLLECTION,
  COLLECTED,
  DISPENSER_JAMMED,
  CARD_NOT_COLLECTED,
  FAILED,
  RECOVERED,
}

enum class RefundStatus {
  REFUND_REQUESTED,
  APPROVED,
  SETTLED,
  REJECTED,
}

enum class ReconciliationStatus {
  OPEN,
  AUTO_RESOLVED,
  STAFF_RESOLVED,
  ESCALATED,
}

enum class StaffRole {
  OPERATOR,
  SUPERVISOR,
}

data class AccessibilitySettings(
  val largeText: Boolean = false,
  val highContrast: Boolean = false,
  val reducedMotion: Boolean = false,
  val audioGuidance: Boolean = false,
)

data class OperatorIdentity(
  val operatorId: String,
  val badgeCode: String,
  val displayName: String,
  val badgeColorHex: Long,
  val demoWatermark: String,
)

data class PricingQuote(
  val productVersionId: String,
  val productCode: String,
  val versionNumber: Int,
  val storedValueCents: Int,
  val fareEntitlementCents: Int,
  val cardIssueFeeCents: Int,
  val totalCents: Int,
  val currency: String = "USD",
  val entitlementLabel: String,
  val isDemoPrice: Boolean = true,
) {
  companion object {
    fun formatUsd(cents: Int): String {
      val abs = kotlin.math.abs(cents)
      val dollars = abs / 100
      val rem = abs % 100
      val sign = if (cents < 0) "-" else ""
      return "$sign$${dollars}.${rem.toString().padStart(2, '0')}"
    }
  }
}

data class StaffUser(
  val staffId: String,
  val displayName: String,
  val role: StaffRole,
)

data class KioskUiStateSnapshot(
  val language: AppLanguage = AppLanguage.EN,
  val enabledLanguages: Set<AppLanguage> = setOf(AppLanguage.EN, AppLanguage.ES),
  val accessibility: AccessibilitySettings = AccessibilitySettings(),
  val sessionId: String = "",
  val sessionSecondsRemaining: Int = 90,
  val showTimeoutWarning: Boolean = false,
)
