package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.domain.model.KioskFlow
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SubwayBlue
import com.example.ui.theme.SubwayGreen
import com.example.ui.theme.SubwayRed
import com.example.ui.theme.SubwayYellow

@Composable
fun LeftNavigationSidebar(
  language: AppLanguage,
  activeFlow: KioskFlow,
  onSelectFlow: (KioskFlow) -> Unit,
  onOpenNetworkMap: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalKioskTokens.current
  val items = listOf(
    KioskFlow.BUY_CARD to TKey.NAV_BUY_CARD,
    KioskFlow.RELOAD_CARD to TKey.NAV_RELOAD_CARD,
    KioskFlow.CHECK_BALANCE to TKey.NAV_CHECK_BALANCE,
    KioskFlow.PLAN_JOURNEY to TKey.NAV_PLAN_JOURNEY,
    KioskFlow.HELP_ACCESSIBILITY to TKey.NAV_HELP_A11Y,
  )

  Column(
    modifier = modifier
      .background(tokens.panelBg)
      .padding(horizontal = 14.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(
      text = Translations.get(TKey.START_HERE, language),
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.ExtraBold,
      color = tokens.textPrimary,
    )

    items.forEach { (flow, key) ->
      val selected = activeFlow == flow
      Surface(
        onClick = { onSelectFlow(flow) },
        shape = RoundedCornerShape(8.dp),
        color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
        border = BorderStroke(1.2.dp, if (selected) tokens.selectedCardBlue else tokens.border),
        modifier = Modifier
          .fillMaxWidth()
          .minimumInteractiveComponentSize()
          .testTag("nav_${flow.name.lowercase()}"),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 13.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = Translations.get(key, language),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (selected) PureWhite else tokens.textPrimary,
          )
          Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = if (selected) PureWhite else tokens.textPrimary,
          )
        }
      }
    }

    Spacer(Modifier.height(2.dp))
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(tokens.border))
    Spacer(Modifier.height(2.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      MiniSchematicNetworkMap(
        modifier = Modifier
          .width(102.dp)
          .height(92.dp),
      )
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
          SubwayBulletBadge("A", SubwayBlue, size = 22.dp)
          SubwayBulletBadge("C", SubwayBlue, size = 22.dp)
          SubwayBulletBadge("E", SubwayBlue, size = 22.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
          SubwayBulletBadge("1", SubwayRed, size = 22.dp)
          SubwayBulletBadge("2", SubwayRed, size = 22.dp)
          SubwayBulletBadge("3", SubwayRed, size = 22.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
          SubwayBulletBadge("N", SubwayYellow, Color(0xFF111111), size = 22.dp)
          SubwayBulletBadge("Q", SubwayYellow, Color(0xFF111111), size = 22.dp)
          SubwayBulletBadge("R", SubwayYellow, Color(0xFF111111), size = 22.dp)
          SubwayBulletBadge("W", SubwayYellow, Color(0xFF111111), size = 22.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
          SubwayBulletBadge("4", SubwayGreen, size = 22.dp)
          SubwayBulletBadge("5", SubwayGreen, size = 22.dp)
          SubwayBulletBadge("6", SubwayGreen, size = 22.dp)
        }
      }
    }

    Text(
      text = Translations.get(TKey.EXPLORE_NETWORK, language),
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = tokens.textPrimary,
    )

    Surface(
      onClick = onOpenNetworkMap,
      shape = RoundedCornerShape(8.dp),
      color = tokens.panelBg,
      border = BorderStroke(1.2.dp, tokens.textPrimary),
      modifier = Modifier
        .minimumInteractiveComponentSize()
        .testTag("view_map_button"),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = Translations.get(TKey.VIEW_MAP, language),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
        Spacer(Modifier.width(6.dp))
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = tokens.textPrimary,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
fun CompactNavigationStrip(
  language: AppLanguage,
  activeFlow: KioskFlow,
  onSelectFlow: (KioskFlow) -> Unit,
) {
  val tokens = LocalKioskTokens.current
  val items = listOf(
    KioskFlow.BUY_CARD to TKey.NAV_BUY_CARD,
    KioskFlow.RELOAD_CARD to TKey.NAV_RELOAD_CARD,
    KioskFlow.CHECK_BALANCE to TKey.NAV_CHECK_BALANCE,
    KioskFlow.PLAN_JOURNEY to TKey.NAV_PLAN_JOURNEY,
    KioskFlow.HELP_ACCESSIBILITY to TKey.NAV_HELP_A11Y,
  )
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(tokens.panelBg)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    items.forEach { (flow, key) ->
      val selected = activeFlow == flow
      Surface(
        onClick = { onSelectFlow(flow) },
        shape = RoundedCornerShape(8.dp),
        color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
        border = BorderStroke(1.dp, if (selected) tokens.selectedCardBlue else tokens.border),
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("compact_nav_${flow.name.lowercase()}"),
      ) {
        Text(
          text = Translations.get(key, language),
          color = if (selected) PureWhite else tokens.textPrimary,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
        )
      }
    }
  }
}
