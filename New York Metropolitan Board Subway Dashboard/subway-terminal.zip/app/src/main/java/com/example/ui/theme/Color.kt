package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// New York Subway Terminal Palette
val MatteBlack = Color(0xFF0B0C0E)
val PureWhite = Color(0xFFFFFFFF)
val PaleWorkspace = Color(0xFFEEF1F5)
val CardBorderGrey = Color(0xFFD0D5DD)
val SubtleDivider = Color(0xFF1A1D21)
val MutedText = Color(0xFF475467)
val DisabledGrey = Color(0xFF98A2B3)
val DisabledBg = Color(0xFFF2F4F7)

// Transit Blues (exact match to screenshot)
val TransitBluePrimary = Color(0xFF0039A6)
val TransitBlueBright = Color(0xFF0052CC)
val TransitBlueDarkCard = Color(0xFF09254D)
val TransitBlueTint = Color(0xFFDCE9F8)
val TransitBlueTintBorder = Color(0xFF93B8E8)

// Subway Line Bullets
val SubwayBlue = Color(0xFF0039A6)
val SubwayRed = Color(0xFFEE352E)
val SubwayYellow = Color(0xFFFCCC0A)
val SubwayGreen = Color(0xFF00933C)
val SubwayOrange = Color(0xFFFF6319)

// Status Colors (always paired with icons + text, never color alone)
val StatusSuccessBg = Color(0xFFECFDF3)
val StatusSuccessFg = Color(0xFF067647)
val StatusWarnBg = Color(0xFFFFFAEB)
val StatusWarnFg = Color(0xFFB54708)
val StatusErrorBg = Color(0xFFFEF3F2)
val StatusErrorFg = Color(0xFFB42318)

// High Contrast Overrides
val HighContrastBlack = Color(0xFF000000)
val HighContrastYellow = Color(0xFFFFD600)
val HighContrastBlue = Color(0xFF0040C1)
