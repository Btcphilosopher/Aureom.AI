package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PricingQuote
import com.example.domain.model.ProductCategory
import com.example.hardware.AuthoritativeCardSnapshot
import com.example.hardware.HardwareHealthSnapshot
import com.example.ui.CheckoutPhase
import com.example.ui.KioskMainUiState
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite

@Composable
fun ReloadCardPane(
  uiState: KioskMainUiState,
  hardwareHealth: HardwareHealthSnapshot,
  onIdentifyCard: (String) -> Unit,
  onSelectRule: (String) -> Unit,
  onSelectPaymentMethod: (PaymentMethod) -> Unit,
  onSimulateTapOrChip: () -> Unit,
  onRetryDeclined: () -> Unit,
  onConfirmCollected: () -> Unit,
  onRunReconciliation: () -> Unit,
  onFinishClearSession: () -> Unit,
  onBack: () -> Unit,
) {
  BackHandler { onBack() }
  val tokens = LocalKioskTokens.current
  val lang = uiState.language

  if (uiState.checkoutPhase != CheckoutPhase.CONFIGURE) {
    CheckoutExecutionView(
      uiState = uiState,
      onSimulateTapOrChip = onSimulateTapOrChip,
      onRetryDeclined = onRetryDeclined,
      onConfirmCollected = onConfirmCollected,
      onRunReconciliation = onRunReconciliation,
      onFinishClearSession = onFinishClearSession,
    )
    return
  }

  val reloadProduct = uiState.products.firstOrNull { it.category == ProductCategory.RELOAD.name }
  val rules = uiState.pricingRulesByProduct[reloadProduct?.productVersionId].orEmpty()

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = Translations.get(TKey.RELOAD_TITLE, lang),
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.ExtraBold,
      color = tokens.textPrimary,
    )

    TransitCardIdentifierCard(
      language = lang,
      identifiedCard = uiState.identifiedCard,
      identifyError = uiState.cardIdentifyError,
      onIdentifyCard = onIdentifyCard,
    )

    if (uiState.identifiedCard != null && uiState.identifiedCard.status == "ACTIVE") {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = Translations.get(TKey.ILLUSTRATIVE_OPTIONS, lang),
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold,
          color = tokens.textPrimary,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          rules.forEach { rule ->
            val selected = rule.pricingRuleId == uiState.selectedPricingRuleId
            Surface(
              onClick = { onSelectRule(rule.pricingRuleId) },
              shape = RoundedCornerShape(8.dp),
              color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
              border = BorderStroke(1.2.dp, if (selected) tokens.selectedCardBlue else tokens.border),
              modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("reload_option_${rule.optionLabel}"),
            ) {
              Box(modifier = Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                Text(
                  text = "+${rule.optionLabel}",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.ExtraBold,
                  color = if (selected) PureWhite else tokens.textPrimary,
                )
              }
            }
          }
        }
      }

      Surface(
        color = tokens.panelBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, tokens.border),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = Translations.get(TKey.CHOOSE_HOW_TO_PAY, lang),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = tokens.textPrimary,
          )
          PaymentMethodsRow(
            language = lang,
            selectedMethod = uiState.selectedPaymentMethod,
            cashAvailable = hardwareHealth.cashAcceptor.available,
            onSelect = onSelectPaymentMethod,
          )
        }
      }
    }
  }
}

@Composable
fun CheckBalancePane(
  uiState: KioskMainUiState,
  onIdentifyCard: (String) -> Unit,
  onReloadIdentified: () -> Unit,
  onBack: () -> Unit,
) {
  BackHandler { onBack() }
  val tokens = LocalKioskTokens.current
  val lang = uiState.language

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = Translations.get(TKey.CHECK_BALANCE_TITLE, lang),
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.ExtraBold,
      color = tokens.textPrimary,
    )
    Text(
      text = Translations.get(TKey.CHECK_BALANCE_SUBTITLE, lang),
      style = MaterialTheme.typography.bodyMedium,
      color = tokens.textSecondary,
    )

    TransitCardIdentifierCard(
      language = lang,
      identifiedCard = uiState.identifiedCard,
      identifyError = uiState.cardIdentifyError,
      onIdentifyCard = onIdentifyCard,
    )

    uiState.identifiedCard?.let { card ->
      if (card.status == "ACTIVE") {
        Button(
          onClick = onReloadIdentified,
          colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("reload_this_card_button"),
        ) {
          Text(
            text = Translations.get(TKey.RELOAD_THIS_CARD, lang),
            color = PureWhite,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.width(8.dp))
          Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = PureWhite)
        }
      }
    }
  }
}

@Composable
fun TransitCardIdentifierCard(
  language: AppLanguage,
  identifiedCard: AuthoritativeCardSnapshot?,
  identifyError: String?,
  onIdentifyCard: (String) -> Unit,
) {
  val tokens = LocalKioskTokens.current
  Surface(
    color = tokens.panelBg,
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(1.2.dp, tokens.border),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Contactless, contentDescription = null, tint = tokens.accentBlue)
        Text(
          text = Translations.get(TKey.TAP_TRANSIT_CARD_PROMPT, language),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
      }
      Text(
        text = Translations.get(TKey.RELOAD_IDENTIFY_HINT, language),
        style = MaterialTheme.typography.bodyMedium,
        color = tokens.textSecondary,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = { onIdentifyCard("CRD-4829-1104") },
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("identify_card_button"),
        ) {
          Text("Card CRD-4829", fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
          onClick = { onIdentifyCard("ACCT-9012-7731") },
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("identify_account_button"),
        ) {
          Icon(Icons.Default.QrCodeScanner, contentDescription = null)
          Spacer(Modifier.width(4.dp))
          Text("Acct ACCT-9012", fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
          onClick = { onIdentifyCard("CRD-0000-BLOCKED") },
          modifier = Modifier
            .weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("identify_blocked_button"),
        ) {
          Text("Blocked Demo", fontWeight = FontWeight.Bold)
        }
      }

      if (identifyError != null) {
        StatusAlertBanner(isError = true, title = identifyError, detail = null)
      }

      if (identifiedCard != null) {
        Surface(
          color = tokens.promptBannerBg.copy(alpha = 0.45f),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, tokens.promptBannerBorder),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("identified_card_snapshot"),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, tint = tokens.accentBlue)
                Text(
                  text = identifiedCard.cardRef,
                  fontFamily = MonoFontFamily,
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.titleMedium,
                  color = tokens.textPrimary,
                )
              }
              Text(
                text = identifiedCard.status,
                fontFamily = MonoFontFamily,
                fontWeight = FontWeight.Bold,
                color = tokens.textPrimary,
              )
            }
            Text(
              text = if (identifiedCard.isAccountBased) {
                Translations.get(TKey.RELOAD_ACCOUNT_BASED, language)
              } else {
                Translations.get(TKey.RELOAD_CARD_BASED, language)
              },
              style = MaterialTheme.typography.bodyMedium,
              color = tokens.textSecondary,
            )
            Text(
              text = "${Translations.get(TKey.AUTHORITATIVE_BALANCE, language)}: ${PricingQuote.formatUsd(identifiedCard.authoritativeBalanceCents)}",
              fontSize = 22.sp,
              fontWeight = FontWeight.ExtraBold,
              color = tokens.textPrimary,
            )
            Text(
              text = "${Translations.get(TKey.ACTIVE_ENTITLEMENT, language)}: ${if (language == AppLanguage.ES) identifiedCard.activeEntitlementEs else identifiedCard.activeEntitlementEn}",
              style = MaterialTheme.typography.bodyMedium,
              color = tokens.textPrimary,
            )
          }
        }
      }
    }
  }
}
