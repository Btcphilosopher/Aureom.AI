package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PrintDisabled
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.data.local.PricingRuleEntity
import com.example.data.local.ProductVersionEntity
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PricingQuote
import com.example.domain.model.ProductCategory
import com.example.hardware.HardwareHealthSnapshot
import com.example.ui.CheckoutPhase
import com.example.ui.KioskMainUiState
import com.example.ui.components.ContactlessWavesIcon
import com.example.ui.components.TransitCardArtwork
import com.example.ui.theme.DisabledBg
import com.example.ui.theme.DisabledGrey
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusErrorFg
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusSuccessFg
import com.example.ui.theme.StatusWarnBg
import com.example.ui.theme.StatusWarnFg

@Composable
fun PurchaseCentrePane(
  uiState: KioskMainUiState,
  hardwareHealth: HardwareHealthSnapshot,
  onSelectProduct: (String) -> Unit,
  onSelectRule: (String) -> Unit,
  onSelectPaymentMethod: (PaymentMethod) -> Unit,
  onSimulateTapOrChip: () -> Unit,
  onRetryDeclined: () -> Unit,
  onConfirmCollected: () -> Unit,
  onRunReconciliation: () -> Unit,
  onFinishClearSession: () -> Unit,
  onBackFromCheckout: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  val lang = uiState.language

  if (uiState.checkoutPhase != CheckoutPhase.CONFIGURE) {
    BackHandler { onBackFromCheckout() }
    CheckoutExecutionView(
      uiState = uiState,
      onSimulateTapOrChip = onSimulateTapOrChip,
      onRetryDeclined = onRetryDeclined,
      onConfirmCollected = onConfirmCollected,
      onRunReconciliation = onRunReconciliation,
      onFinishClearSession = onFinishClearSession,
    )
    return
  }

  val buyProducts = uiState.products.filter { it.category != ProductCategory.RELOAD.name }
  val activeProduct: ProductVersionEntity? = buyProducts.firstOrNull { it.productVersionId == uiState.selectedProductId }
    ?: buyProducts.firstOrNull()
  val rules: List<PricingRuleEntity> = uiState.pricingRulesByProduct[activeProduct?.productVersionId].orEmpty()
  val quote = uiState.currentQuote

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = Translations.get(TKey.REVIEW_PURCHASE_TITLE, lang),
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.ExtraBold,
      color = tokens.textPrimary,
    )

    if (buyProducts.size > 1) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        buyProducts.forEach { prod ->
          val isSelected = prod.productVersionId == activeProduct?.productVersionId
          val title = if (lang == AppLanguage.ES) prod.titleEs else prod.titleEn
          Surface(
            onClick = { onSelectProduct(prod.productVersionId) },
            shape = RoundedCornerShape(999.dp),
            color = if (isSelected) tokens.selectedCardBlue else tokens.panelBg,
            border = BorderStroke(1.dp, if (isSelected) tokens.selectedCardBlue else tokens.border),
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("product_chip_${prod.productCode}"),
          ) {
            Text(
              text = "$title (v${prod.versionNumber})",
              color = if (isSelected) PureWhite else tokens.textPrimary,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            )
          }
        }
      }
    }

    // Hero Card + Selected Value Panel matching screenshot
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      TransitCardArtwork(
        cardTitle = if (activeProduct?.category == ProductCategory.PASS.name) "7-DAY PASS • DEMO" else "TRANSIT • DEMO",
        modifier = Modifier
          .width(196.dp)
          .height(126.dp),
      )

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = if (activeProduct != null) {
            if (lang == AppLanguage.ES) activeProduct.titleEs else activeProduct.titleEn
          } else Translations.get(TKey.CARD_TITLE_RELOADABLE, lang),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        Text(
          text = if (activeProduct?.category == ProductCategory.PASS.name) {
            Translations.get(TKey.PASS_LABEL, lang)
          } else {
            Translations.get(TKey.SELECTED_STORED_VALUE, lang)
          },
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
        Text(
          text = PricingQuote.formatUsd(
            quote?.let { if (it.storedValueCents > 0) it.storedValueCents else it.fareEntitlementCents } ?: 2000
          ),
          fontSize = 30.sp,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          SmallAttributePill(Translations.get(TKey.BADGE_REUSABLE, lang))
          SmallAttributePill(Translations.get(TKey.BADGE_NFC_ENABLED, lang))
        }
      }
    }

    if (activeProduct != null) {
      Text(
        text = "${Translations.get(TKey.ELIGIBILITY_LABEL, lang)}: ${activeProduct.eligibilityRestriction} • ${Translations.get(TKey.REFUND_RULE_LABEL, lang)}: ${activeProduct.refundRule}",
        style = MaterialTheme.typography.labelSmall,
        color = tokens.textSecondary,
      )
    }

    // Illustrative stored-value options ($10, $20, $40)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Text(
        text = Translations.get(TKey.ILLUSTRATIVE_OPTIONS, lang),
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        color = tokens.textPrimary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        rules.forEach { rule ->
          val selected = rule.pricingRuleId == uiState.selectedPricingRuleId
          Surface(
            onClick = { onSelectRule(rule.pricingRuleId) },
            shape = RoundedCornerShape(8.dp),
            color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
            border = BorderStroke(1.2.dp, if (selected) tokens.selectedCardBlue else tokens.border),
            modifier = Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .testTag("value_option_${rule.optionLabel}"),
          ) {
            Box(
              modifier = Modifier.padding(vertical = 13.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = rule.optionLabel,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = if (selected) PureWhite else tokens.textPrimary,
              )
            }
          }
        }
      }
    }

    // Choose how to pay panel
    Surface(
      color = tokens.panelBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = Translations.get(TKey.CHOOSE_HOW_TO_PAY, lang),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        PaymentMethodsRow(
          language = lang,
          selectedMethod = uiState.selectedPaymentMethod,
          cashAvailable = hardwareHealth.cashAcceptor.available,
          onSelect = onSelectPaymentMethod,
        )
      }
    }

    // Tap when reader lights up banner
    Surface(
      color = tokens.promptBannerBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.dp, tokens.promptBannerBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        ContactlessWavesIcon(
          color = tokens.textPrimary,
          modifier = Modifier.size(44.dp),
        )
        Box(
          modifier = Modifier
            .width(1.2.dp)
            .height(48.dp)
            .background(tokens.textPrimary.copy(alpha = 0.25f)),
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text = if (uiState.selectedPaymentMethod == PaymentMethod.CHIP_CARD) {
              Translations.get(TKey.CHIP_READER_TITLE, lang)
            } else {
              Translations.get(TKey.TAP_READER_TITLE, lang)
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = tokens.textPrimary,
          )
          Text(
            text = if (uiState.selectedPaymentMethod == PaymentMethod.CHIP_CARD) {
              Translations.get(TKey.CHIP_READER_SUBTITLE, lang)
            } else {
              Translations.get(TKey.TAP_READER_SUBTITLE, lang)
            },
            style = MaterialTheme.typography.bodyMedium,
            color = tokens.textPrimary,
          )
          Text(
            text = Translations.get(TKey.TAP_READER_NOTE, lang),
            style = MaterialTheme.typography.bodyMedium,
            fontStyle = FontStyle.Italic,
            color = tokens.textSecondary,
          )
        }
      }
    }

    if (uiState.transientErrorBanner != null) {
      StatusAlertBanner(
        isError = true,
        title = uiState.transientErrorBanner,
        detail = null,
      )
    }
  }
}

@Composable
fun PaymentMethodsRow(
  language: AppLanguage,
  selectedMethod: PaymentMethod,
  cashAvailable: Boolean,
  onSelect: (PaymentMethod) -> Unit,
) {
  val tokens = LocalKioskTokens.current
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    // Contactless
    val nfcSelected = selectedMethod == PaymentMethod.CONTACTLESS_NFC
    Surface(
      onClick = { onSelect(PaymentMethod.CONTACTLESS_NFC) },
      shape = RoundedCornerShape(8.dp),
      color = if (nfcSelected) tokens.promptBannerBg.copy(alpha = 0.55f) else tokens.panelBg,
      border = BorderStroke(if (nfcSelected) 2.dp else 1.2.dp, if (nfcSelected) tokens.accentBlue else tokens.border),
      modifier = Modifier
        .weight(1f)
        .minimumInteractiveComponentSize()
        .testTag("pay_method_contactless"),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        ContactlessWavesIcon(color = tokens.textPrimary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(
          text = Translations.get(TKey.PAY_CONTACTLESS, language),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
      }
    }

    // Chip card
    val chipSelected = selectedMethod == PaymentMethod.CHIP_CARD
    Surface(
      onClick = { onSelect(PaymentMethod.CHIP_CARD) },
      shape = RoundedCornerShape(8.dp),
      color = if (chipSelected) tokens.promptBannerBg.copy(alpha = 0.55f) else tokens.panelBg,
      border = BorderStroke(if (chipSelected) 2.dp else 1.2.dp, if (chipSelected) tokens.accentBlue else tokens.border),
      modifier = Modifier
        .weight(1f)
        .minimumInteractiveComponentSize()
        .testTag("pay_method_chip"),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        Icon(Icons.Default.CreditCard, contentDescription = null, tint = tokens.textPrimary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(
          text = Translations.get(TKey.PAY_CHIP_CARD, language),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
      }
    }

    // Cash (disabled unless adapter reports available)
    val cashSelected = selectedMethod == PaymentMethod.CASH && cashAvailable
    Surface(
      onClick = { if (cashAvailable) onSelect(PaymentMethod.CASH) },
      enabled = cashAvailable,
      shape = RoundedCornerShape(8.dp),
      color = if (!cashAvailable) DisabledBg else if (cashSelected) tokens.promptBannerBg else tokens.panelBg,
      border = BorderStroke(1.2.dp, if (!cashAvailable) Color(0xFFD0D5DD) else if (cashSelected) tokens.accentBlue else tokens.border),
      modifier = Modifier
        .weight(1f)
        .minimumInteractiveComponentSize()
        .testTag("pay_method_cash"),
    ) {
      Column(
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Payments,
            contentDescription = null,
            tint = if (cashAvailable) tokens.textPrimary else DisabledGrey,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.width(6.dp))
          Text(
            text = Translations.get(TKey.PAY_CASH, language),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (cashAvailable) tokens.textPrimary else DisabledGrey,
          )
        }
        if (!cashAvailable) {
          Text(
            text = Translations.get(TKey.CASH_UNAVAILABLE, language),
            style = MaterialTheme.typography.labelSmall,
            color = DisabledGrey,
            maxLines = 1,
          )
        }
      }
    }
  }
}

@Composable
fun CheckoutExecutionView(
  uiState: KioskMainUiState,
  onSimulateTapOrChip: () -> Unit,
  onRetryDeclined: () -> Unit,
  onConfirmCollected: () -> Unit,
  onRunReconciliation: () -> Unit,
  onFinishClearSession: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  val lang = uiState.language
  val order = uiState.activeOrder
  val outcome = uiState.executionOutcome

  Surface(
    color = tokens.panelBg,
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(1.2.dp, tokens.border),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("checkout_execution_panel"),
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = Translations.get(TKey.PAYMENT_PROCESSING_TITLE, lang),
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        Surface(
          color = tokens.promptBannerBg,
          shape = RoundedCornerShape(6.dp),
        ) {
          Text(
            text = Translations.get(TKey.DEMO_WATERMARK, lang),
            color = tokens.accentBlue,
            fontFamily = MonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      if (order != null) {
        Text(
          text = "Order ${order.orderId} • ${PricingQuote.formatUsd(order.totalCents)} USD • ${Translations.get(TKey.RECEIPT_REFERENCE, lang)}: ${order.claimReference}",
          fontFamily = MonoFontFamily,
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
      }

      when (uiState.checkoutPhase) {
        CheckoutPhase.AWAITING_TAP_OR_CHIP -> {
          StatusAlertBanner(
            isError = false,
            title = Translations.get(TKey.PAYMENT_STATE_AWAITING, lang),
            detail = if (uiState.selectedPaymentMethod == PaymentMethod.CHIP_CARD) {
              Translations.get(TKey.CHIP_READER_SUBTITLE, lang)
            } else {
              Translations.get(TKey.TAP_READER_SUBTITLE, lang)
            },
          )
          Button(
            onClick = onSimulateTapOrChip,
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("simulate_payment_tap_button"),
          ) {
            Text(
              text = if (uiState.selectedPaymentMethod == PaymentMethod.CHIP_CARD) {
                Translations.get(TKey.PAYMENT_INSERT_SIMULATED_CHIP, lang)
              } else {
                Translations.get(TKey.PAYMENT_TAP_SIMULATED_NFC, lang)
              },
              color = PureWhite,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
          }
        }

        CheckoutPhase.PROCESSING_PAYMENT, CheckoutPhase.FULFILLING -> {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            if (!tokens.reducedMotion) {
              CircularProgressIndicator(color = tokens.accentBlue, modifier = Modifier.size(30.dp))
            }
            Text(
              text = if (uiState.checkoutPhase == CheckoutPhase.PROCESSING_PAYMENT) {
                Translations.get(TKey.PAYMENT_STATE_PROCESSING, lang)
              } else {
                Translations.get(TKey.FULFILMENT_PROVISIONING, lang)
              },
              style = MaterialTheme.typography.titleLarge,
              color = tokens.textPrimary,
            )
          }
        }

        CheckoutPhase.PAYMENT_DECLINED -> {
          StatusAlertBanner(
            isError = true,
            title = Translations.get(TKey.PAYMENT_STATE_DECLINED, lang),
            detail = Translations.get(TKey.PAYMENT_DECLINED_DESC, lang),
          )
          Button(
            onClick = onRetryDeclined,
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("retry_payment_button"),
          ) {
            Text(Translations.get(TKey.RETRY_PAYMENT, lang), color = PureWhite, fontWeight = FontWeight.Bold)
          }
        }

        CheckoutPhase.PAYMENT_UNKNOWN -> {
          StatusAlertBanner(
            isError = true,
            title = Translations.get(TKey.PAYMENT_STATE_UNKNOWN, lang),
            detail = Translations.get(TKey.PAYMENT_UNKNOWN_DESC, lang),
          )
          OutlinedButton(
            onClick = onRunReconciliation,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("reconcile_now_button"),
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Check reconciliation status", fontWeight = FontWeight.Bold)
          }
        }

        CheckoutPhase.READY_TO_COLLECT -> {
          StatusAlertBanner(
            isError = false,
            title = Translations.get(TKey.FULFILMENT_COLLECT_TITLE, lang),
            detail = Translations.get(TKey.FULFILMENT_COLLECT_DESC, lang),
            isSuccess = true,
          )
          outcome?.updatedCardSnapshot?.let { snap ->
            Text(
              text = "Issued Card Ref: ${snap.cardRef} • Balance: ${PricingQuote.formatUsd(snap.authoritativeBalanceCents)}",
              fontFamily = MonoFontFamily,
              style = MaterialTheme.typography.bodyLarge,
              fontWeight = FontWeight.Bold,
              color = tokens.textPrimary,
            )
          }
          ReceiptPreviewCard(uiState = uiState)
          Button(
            onClick = onConfirmCollected,
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("confirm_collected_button"),
          ) {
            Text(
              text = Translations.get(TKey.FULFILMENT_CONFIRM_COLLECTED, lang),
              color = PureWhite,
              fontWeight = FontWeight.Bold,
            )
          }
        }

        CheckoutPhase.COMPLETED -> {
          StatusAlertBanner(
            isError = false,
            title = Translations.get(TKey.RELOAD_VERIFIED, lang),
            detail = outcome?.updatedCardSnapshot?.let {
              "${it.cardRef} • ${Translations.get(TKey.AUTHORITATIVE_BALANCE, lang)}: ${PricingQuote.formatUsd(it.authoritativeBalanceCents)}"
            },
            isSuccess = true,
          )
          ReceiptPreviewCard(uiState = uiState)
          Button(
            onClick = onFinishClearSession,
            colors = ButtonDefaults.buttonColors(containerColor = tokens.selectedCardBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("finish_clear_session_button"),
          ) {
            Text(
              text = Translations.get(TKey.FINISH_CLEAR_SESSION, lang),
              color = PureWhite,
              fontWeight = FontWeight.Bold,
            )
          }
        }

        CheckoutPhase.RECOVERY_CLAIM -> {
          val recon = outcome?.reconciliationCase
          StatusAlertBanner(
            isError = true,
            title = Translations.get(TKey.FULFILMENT_DISPENSER_JAM, lang) + " (${recon?.caseType ?: "RECOVERY"})",
            detail = "${Translations.get(TKey.FULFILMENT_CLAIM_PRESERVED, lang)}\n${Translations.get(TKey.RECEIPT_REFERENCE, lang)}: ${order?.claimReference}",
          )
          ReceiptPreviewCard(uiState = uiState)
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
              onClick = onRunReconciliation,
              modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("recovery_reconcile_button"),
            ) {
              Text("Verify / Reconcile", fontWeight = FontWeight.Bold)
            }
            Button(
              onClick = onFinishClearSession,
              colors = ButtonDefaults.buttonColors(containerColor = tokens.selectedCardBlue),
              modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("recovery_finish_button"),
            ) {
              Text(Translations.get(TKey.FINISH_CLEAR_SESSION, lang), color = PureWhite, fontWeight = FontWeight.Bold)
            }
          }
        }

        else -> {}
      }
    }
  }
}

@Composable
private fun ReceiptPreviewCard(uiState: KioskMainUiState) {
  val receipt = uiState.executionOutcome?.receipt ?: return
  val lang = uiState.language
  val tokens = LocalKioskTokens.current
  Surface(
    color = Color(0xFFF8FAFC),
    shape = RoundedCornerShape(8.dp),
    border = BorderStroke(1.dp, tokens.border),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("demo_receipt_card"),
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = Translations.get(TKey.RECEIPT_TITLE, lang),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
        if (!receipt.printedPhysically) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PrintDisabled, contentDescription = null, tint = StatusWarnFg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(
              text = Translations.get(TKey.FULFILMENT_PRINTER_UNAVAILABLE, lang),
              style = MaterialTheme.typography.labelSmall,
              color = StatusWarnFg,
            )
          }
        }
      }
      Text(
        text = if (lang == AppLanguage.ES) receipt.summaryEs else receipt.summaryEn,
        fontFamily = MonoFontFamily,
        style = MaterialTheme.typography.bodyMedium,
        color = tokens.textPrimary,
      )
    }
  }
}

@Composable
fun StatusAlertBanner(
  isError: Boolean,
  title: String,
  detail: String?,
  isSuccess: Boolean = false,
) {
  val bg = when {
    isSuccess -> StatusSuccessBg
    isError -> StatusErrorBg
    else -> StatusWarnBg
  }
  val fg = when {
    isSuccess -> StatusSuccessFg
    isError -> StatusErrorFg
    else -> StatusWarnFg
  }
  val icon = when {
    isSuccess -> Icons.Default.CheckCircle
    isError -> Icons.Default.ErrorOutline
    else -> Icons.Default.Warning
  }
  Surface(
    color = bg,
    shape = RoundedCornerShape(8.dp),
    border = BorderStroke(1.dp, fg),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.Top,
    ) {
      Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(22.dp))
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(text = title, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        if (!detail.isNullOrBlank()) {
          Text(text = detail, color = fg, style = MaterialTheme.typography.bodyMedium)
        }
      }
    }
  }
}

@Composable
private fun SmallAttributePill(label: String) {
  val tokens = LocalKioskTokens.current
  Surface(
    color = Color(0xFFE4E7EC),
    shape = RoundedCornerShape(6.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.SemiBold,
      color = tokens.textPrimary,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
    )
  }
}
