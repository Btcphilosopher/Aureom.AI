package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.data.local.AuditEventEntity
import com.example.data.local.DeviceEventEntity
import com.example.data.local.OrderEntity
import com.example.data.local.ProductVersionEntity
import com.example.data.local.ReconciliationCaseEntity
import com.example.data.local.RefundEntity
import com.example.data.local.TerminalEntity
import com.example.domain.model.AccessibilitySettings
import com.example.domain.model.PricingQuote
import com.example.domain.model.RefundStatus
import com.example.domain.model.StaffRole
import com.example.domain.model.StaffUser
import com.example.hardware.FulfilmentFaultMode
import com.example.hardware.HardwareHealthSnapshot
import com.example.hardware.PaymentFaultMode
import com.example.ui.KioskMainUiState
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusErrorFg
import com.example.ui.theme.StatusSuccessFg

@Composable
fun HelpAccessibilityPane(
  uiState: KioskMainUiState,
  onUpdateAccessibility: ((AccessibilitySettings) -> AccessibilitySettings) -> Unit,
  onExtendSession: () -> Unit,
  onRunScenario: (String) -> Unit,
  onOpenStaffLogin: () -> Unit,
  onBack: () -> Unit,
) {
  BackHandler { onBack() }
  val tokens = LocalKioskTokens.current
  val lang = uiState.language

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = Translations.get(TKey.HELP_A11Y_TITLE, lang),
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.ExtraBold,
      color = tokens.textPrimary,
    )

    AccessibilityControlsCard(
      language = lang,
      settings = uiState.accessibility,
      sessionSeconds = uiState.sessionSecondsRemaining,
      onUpdate = onUpdateAccessibility,
      onExtendSession = onExtendSession,
    )

    // Interactive Demo Scenarios Launcher
    Surface(
      color = tokens.panelBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.2.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Demonstration Flow & Fault Scenarios",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
        )
        Text(
          text = "Launch pre-wired flows to verify $21 purchase, reload, decline, unknown payment reconciliation, and dispenser jam recovery.",
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
        val scenarios = listOf(
          "NORMAL_BUY" to "1. Standard $20 Card + $1 Fee ($21.00 USD)",
          "RELOAD" to "2. Reload Existing Card (CRD-4829-1104)",
          "DECLINE" to "3. Simulated Payment Decline",
          "UNKNOWN_PAYMENT" to "4. Payment Outcome Unknown + Reconcile",
          "DISPENSER_JAM" to "5. Dispenser Jam + Claim Preservation",
        )
        scenarios.forEach { (id, label) ->
          OutlinedButton(
            onClick = { onRunScenario(id) },
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("scenario_$id"),
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }

    // Discreet Staff Maintenance Login (hidden from primary guest navigation)
    Surface(
      color = Color(0xFFF8FAFC),
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "Authorized Station Personnel",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = tokens.textPrimary,
          )
          Text(
            text = "PIN-protected maintenance, pricing versions, reconciliation, and audit history.",
            style = MaterialTheme.typography.bodyMedium,
            color = tokens.textSecondary,
          )
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(
          onClick = onOpenStaffLogin,
          modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("open_staff_login_button"),
        ) {
          Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
          Spacer(Modifier.width(6.dp))
          Text("Staff Sign-In", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun AccessibilityControlsCard(
  language: AppLanguage,
  settings: AccessibilitySettings,
  sessionSeconds: Int,
  onUpdate: ((AccessibilitySettings) -> AccessibilitySettings) -> Unit,
  onExtendSession: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  Surface(
    color = tokens.panelBg,
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(1.2.dp, tokens.border),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      ToggleRow(
        label = Translations.get(TKey.A11Y_LARGE_TEXT, language),
        checked = settings.largeText,
        tag = "a11y_large_text",
        onCheckedChange = { v -> onUpdate { it.copy(largeText = v) } },
      )
      ToggleRow(
        label = Translations.get(TKey.A11Y_HIGH_CONTRAST, language),
        checked = settings.highContrast,
        tag = "a11y_high_contrast",
        onCheckedChange = { v -> onUpdate { it.copy(highContrast = v) } },
      )
      ToggleRow(
        label = Translations.get(TKey.A11Y_REDUCED_MOTION, language),
        checked = settings.reducedMotion,
        tag = "a11y_reduced_motion",
        onCheckedChange = { v -> onUpdate { it.copy(reducedMotion = v) } },
      )
      ToggleRow(
        label = Translations.get(TKey.A11Y_AUDIO_GUIDANCE, language),
        checked = settings.audioGuidance,
        tag = "a11y_audio_guidance",
        onCheckedChange = { v -> onUpdate { it.copy(audioGuidance = v) } },
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "Session timer: ${sessionSeconds}s remaining",
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold,
          color = tokens.textSecondary,
        )
        OutlinedButton(onClick = onExtendSession, modifier = Modifier.minimumInteractiveComponentSize()) {
          Text(Translations.get(TKey.EXTEND_SESSION, language), fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun ToggleRow(
  label: String,
  checked: Boolean,
  tag: String,
  onCheckedChange: (Boolean) -> Unit,
) {
  val tokens = LocalKioskTokens.current
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.SemiBold,
      color = tokens.textPrimary,
    )
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(tag),
    )
  }
}

@Composable
fun AccessibilityQuickDialog(
  language: AppLanguage,
  settings: AccessibilitySettings,
  sessionSeconds: Int,
  onUpdate: ((AccessibilitySettings) -> AccessibilitySettings) -> Unit,
  onExtendSession: () -> Unit,
  onDismiss: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = Translations.get(TKey.A11Y_BUTTON_DESC, language),
        fontWeight = FontWeight.ExtraBold,
      )
    },
    text = {
      AccessibilityControlsCard(
        language = language,
        settings = settings,
        sessionSeconds = sessionSeconds,
        onUpdate = onUpdate,
        onExtendSession = onExtendSession,
      )
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
      ) {
        Text("Done", color = PureWhite)
      }
    },
  )
}

@Composable
fun StaffAuthDialog(
  language: AppLanguage,
  error: String?,
  onAuthenticate: (String, String) -> Unit,
  onDismiss: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  var staffId by remember { mutableStateOf("SUP-201") }
  var pin by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = Translations.get(TKey.STAFF_LOGIN_TITLE, language),
        fontWeight = FontWeight.ExtraBold,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Demo credentials: Operator OP-101 (PIN 1234) or Supervisor SUP-201 (PIN 5678).",
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
        OutlinedTextField(
          value = staffId,
          onValueChange = { staffId = it },
          label = { Text("Staff ID") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("staff_id_input"),
        )
        OutlinedTextField(
          value = pin,
          onValueChange = { pin = it },
          label = { Text("PIN") },
          singleLine = true,
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          modifier = Modifier.fillMaxWidth().testTag("staff_pin_input"),
        )
        if (error != null) {
          Text(text = error, color = StatusErrorFg, fontWeight = FontWeight.Bold)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onAuthenticate(staffId, pin) },
        colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
        modifier = Modifier.testTag("staff_login_submit"),
      ) {
        Text("Sign In", color = PureWhite)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    },
  )
}

@Composable
fun StaffWorkspacePane(
  staff: StaffUser,
  language: AppLanguage,
  terminal: TerminalEntity?,
  hardwareHealth: HardwareHealthSnapshot,
  productVersions: List<ProductVersionEntity>,
  recentOrders: List<OrderEntity>,
  reconciliationCases: List<ReconciliationCaseEntity>,
  refunds: List<RefundEntity>,
  deviceEvents: List<DeviceEventEntity>,
  auditEvents: List<AuditEventEntity>,
  onSetPaymentFault: (PaymentFaultMode) -> Unit,
  onSetFulfilmentFault: (FulfilmentFaultMode) -> Unit,
  onToggleCashAdapter: (Boolean) -> Unit,
  onClearJamRestock: () -> Unit,
  onRefillPaper: () -> Unit,
  onPublishNewPrice: (String, Int, List<Int>, (String) -> Unit) -> Unit,
  onRequestRefund: (String, String, (String) -> Unit) -> Unit,
  onSettleRefund: (String, (String) -> Unit) -> Unit,
  onResolveCase: (String, String, (String) -> Unit) -> Unit,
  onToggleSpanish: (Boolean, (String) -> Unit) -> Unit,
  onLogout: () -> Unit,
) {
  BackHandler { onLogout() }
  val tokens = LocalKioskTokens.current
  var activeTab by remember { mutableIntStateOf(0) }
  var feedbackBanner by remember { mutableStateOf<String?>(null) }
  var spanishEnabled by remember { mutableStateOf(true) }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = Translations.get(TKey.STAFF_WORKSPACE_TITLE, language),
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        Text(
          text = "${staff.displayName} (${staff.staffId}) • Role: ${staff.role.name}",
          fontFamily = MonoFontFamily,
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
      }
      OutlinedButton(onClick = onLogout, modifier = Modifier.testTag("staff_logout_button")) {
        Text("Exit Staff Mode", fontWeight = FontWeight.Bold)
      }
    }

    if (feedbackBanner != null) {
      StatusAlertBanner(isError = false, title = feedbackBanner!!, detail = null, isSuccess = true)
    }

    val tabs = listOf("Hardware & Stock", "Catalog & Pricing", "Reconciliation & Refunds", "Audit & Config")
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      tabs.forEachIndexed { idx, label ->
        val selected = activeTab == idx
        Surface(
          onClick = { activeTab = idx },
          shape = RoundedCornerShape(8.dp),
          color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
          border = BorderStroke(1.dp, if (selected) tokens.selectedCardBlue else tokens.border),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("staff_tab_$idx"),
        ) {
          Text(
            text = label,
            color = if (selected) PureWhite else tokens.textPrimary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          )
        }
      }
    }

    when (activeTab) {
      0 -> {
        Surface(
          color = tokens.panelBg,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, tokens.border),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              text = "Terminal ${terminal?.terminalId ?: "KIOSK-NY-042"} • Stock: ${hardwareHealth.cardStockRemaining} cards • Receipt Paper: ${hardwareHealth.receiptPaperPercent}%",
              fontFamily = MonoFontFamily,
              fontWeight = FontWeight.Bold,
              color = tokens.textPrimary,
            )
            val adapters = listOf(
              hardwareHealth.paymentTerminal,
              hardwareHealth.transitReader,
              hardwareHealth.fulfilmentService,
              hardwareHealth.cardDispenser,
              hardwareHealth.receiptPrinter,
              hardwareHealth.barcodeScanner,
              hardwareHealth.cashAcceptor,
            )
            adapters.forEach { cap ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(
                    imageVector = if (cap.available) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = if (cap.available) StatusSuccessFg else StatusErrorFg,
                  )
                  Text(cap.adapterName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                Text(cap.status.name, fontFamily = MonoFontFamily, style = MaterialTheme.typography.labelSmall)
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(onClick = { onClearJamRestock(); feedbackBanner = "Dispenser cleared & restocked" }) {
                Icon(Icons.Default.Build, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Clear Jam / Restock")
              }
              OutlinedButton(onClick = { onRefillPaper(); feedbackBanner = "Receipt paper refilled to 100%" }) {
                Text("Refill Paper")
              }
            }

            ToggleRow(
              label = "Enable Cash Acceptor Adapter (Sim)",
              checked = hardwareHealth.cashAcceptor.available,
              tag = "staff_cash_toggle",
              onCheckedChange = onToggleCashAdapter,
            )

            Text("Simulated Payment Fault Mode", fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              PaymentFaultMode.entries.forEach { mode ->
                val sel = hardwareHealth.paymentFaultMode == mode
                Surface(
                  onClick = { onSetPaymentFault(mode) },
                  color = if (sel) tokens.selectedCardBlue else tokens.panelBg,
                  border = BorderStroke(1.dp, tokens.border),
                  shape = RoundedCornerShape(6.dp),
                ) {
                  Text(
                    mode.name,
                    color = if (sel) PureWhite else tokens.textPrimary,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                  )
                }
              }
            }

            Text("Simulated Fulfilment Fault Mode", fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              FulfilmentFaultMode.entries.forEach { mode ->
                val sel = hardwareHealth.fulfilmentFaultMode == mode
                Surface(
                  onClick = { onSetFulfilmentFault(mode) },
                  color = if (sel) tokens.selectedCardBlue else tokens.panelBg,
                  border = BorderStroke(1.dp, tokens.border),
                  shape = RoundedCornerShape(6.dp),
                ) {
                  Text(
                    mode.name,
                    color = if (sel) PureWhite else tokens.textPrimary,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                  )
                }
              }
            }
          }
        }
      }

      1 -> {
        Surface(
          color = tokens.panelBg,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, tokens.border),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              text = "Versioned Product Catalog (Supervisor required to publish new prices)",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            productVersions.forEach { pv ->
              Text(
                text = "${pv.productCode} • v${pv.versionNumber} • Active=${pv.isActive} • ${pv.titleEn}",
                fontFamily = MonoFontFamily,
                style = MaterialTheme.typography.bodyMedium,
              )
            }
            Button(
              onClick = {
                onPublishNewPrice("CARD_RELOADABLE_SV", 200, listOf(1000, 2000, 4000)) { feedbackBanner = it }
              },
              modifier = Modifier.testTag("staff_publish_v2_button"),
            ) {
              Text("Publish CARD_RELOADABLE_SV Next Version ($2.00 fee)")
            }
            if (staff.role != StaffRole.SUPERVISOR) {
              Text(
                text = "Note: Signed in as OPERATOR — Supervisor PIN (5678) required for catalog publishing.",
                style = MaterialTheme.typography.bodyMedium,
                color = StatusErrorFg,
              )
            }
          }
        }
      }

      2 -> {
        Surface(
          color = tokens.panelBg,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, tokens.border),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Reconciliation Queue (${reconciliationCases.size})", fontWeight = FontWeight.Bold)
            reconciliationCases.take(6).forEach { rc ->
              Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, tokens.border),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text("${rc.caseId} [${rc.status}] • ${rc.caseType} • Claim ${rc.claimReference}", fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold)
                  Text(rc.description, style = MaterialTheme.typography.bodyMedium)
                  if (rc.status == "OPEN") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      OutlinedButton(
                        onClick = { onResolveCase(rc.caseId, "Supervisor cleared & verified fulfilment") { feedbackBanner = it } },
                      ) {
                        Text("Supervisor Recover")
                      }
                      OutlinedButton(
                        onClick = { onRequestRefund(rc.orderId, "Customer claim ${rc.claimReference}") { feedbackBanner = it } },
                      ) {
                        Text("Request Refund")
                      }
                    }
                  }
                }
              }
            }

            Text("Refund Requests (${refunds.size})", fontWeight = FontWeight.Bold)
            refunds.take(6).forEach { rf ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "${rf.refundId} • ${PricingQuote.formatUsd(rf.amountCents)} • ${rf.status}",
                  fontFamily = MonoFontFamily,
                  style = MaterialTheme.typography.bodyMedium,
                )
                if (rf.status == RefundStatus.REFUND_REQUESTED.name) {
                  Button(onClick = { onSettleRefund(rf.refundId) { feedbackBanner = it } }) {
                    Text("Approve & Settle")
                  }
                }
              }
            }

            Text("Recent Orders (${recentOrders.size})", fontWeight = FontWeight.Bold)
            recentOrders.take(4).forEach { ord ->
              Text(
                text = "${ord.orderId} • v${ord.productVersionNumber} • ${PricingQuote.formatUsd(ord.totalCents)} • ${ord.orderState}",
                fontFamily = MonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
              )
            }
          }
        }
      }

      else -> {
        Surface(
          color = tokens.panelBg,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, tokens.border),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleRow(
              label = "Enable Spanish (Español) at terminal",
              checked = spanishEnabled,
              tag = "staff_spanish_toggle",
              onCheckedChange = { enabled ->
                spanishEnabled = enabled
                onToggleSpanish(enabled) { feedbackBanner = it }
              },
            )
            Text("Device Events (${deviceEvents.size})", fontWeight = FontWeight.Bold)
            deviceEvents.take(5).forEach { dev ->
              Text("${dev.adapterName} [${dev.severity}]: ${dev.message}", fontFamily = MonoFontFamily, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(4.dp))
            Text("Redacted Audit Events (${auditEvents.size})", fontWeight = FontWeight.Bold)
            auditEvents.take(8).forEach { aud ->
              Text("${aud.actorId} | ${aud.action} | ${aud.redactedDetails}", fontFamily = MonoFontFamily, style = MaterialTheme.typography.labelSmall)
            }
          }
        }
      }
    }
  }
}
