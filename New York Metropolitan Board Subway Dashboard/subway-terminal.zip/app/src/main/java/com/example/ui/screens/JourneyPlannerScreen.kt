package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Accessible
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.backend.SubwayStation
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.ui.KioskMainUiState
import com.example.ui.components.SubwayBulletBadge
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SubwayBlue
import com.example.ui.theme.SubwayGreen
import com.example.ui.theme.SubwayRed
import com.example.ui.theme.SubwayYellow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun JourneyPlannerPane(
  uiState: KioskMainUiState,
  onSelectOrigin: (String) -> Unit,
  onSelectDestination: (String) -> Unit,
  onToggleAccessible: (Boolean) -> Unit,
  onOpenNetworkMap: () -> Unit,
  onBack: () -> Unit,
) {
  BackHandler { onBack() }
  val tokens = LocalKioskTokens.current
  val lang = uiState.language
  val plan = uiState.journeyPlan

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = Translations.get(TKey.JOURNEY_TITLE, lang),
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = tokens.textPrimary,
      )
      Surface(
        onClick = onOpenNetworkMap,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, tokens.textPrimary),
        color = tokens.panelBg,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text(
          text = Translations.get(TKey.VIEW_MAP, lang),
          fontWeight = FontWeight.Bold,
          color = tokens.textPrimary,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
      }
    }

    // Origin / Destination selector
    Surface(
      color = tokens.panelBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.2.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StationChipRow(
          label = Translations.get(TKey.JOURNEY_ORIGIN, lang),
          stations = uiState.stations,
          selectedId = uiState.originStationId,
          onSelect = onSelectOrigin,
          tagPrefix = "origin",
        )
        StationChipRow(
          label = Translations.get(TKey.JOURNEY_DESTINATION, lang),
          stations = uiState.stations,
          selectedId = uiState.destinationStationId,
          onSelect = onSelectDestination,
          tagPrefix = "dest",
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.AutoMirrored.Filled.Accessible, contentDescription = null, tint = tokens.accentBlue)
            Text(
              text = Translations.get(TKey.JOURNEY_ACCESSIBLE_ONLY, lang),
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              color = tokens.textPrimary,
            )
          }
          Switch(
            checked = uiState.accessibleRouteOnly,
            onCheckedChange = onToggleAccessible,
            modifier = Modifier.testTag("journey_accessible_switch"),
          )
        }
      }
    }

    if (plan != null) {
      if (plan.isFeedUnavailable) {
        StatusAlertBanner(
          isError = true,
          title = Translations.get(TKey.JOURNEY_UNAVAILABLE, lang),
          detail = null,
        )
      } else if (plan.isStale) {
        StatusAlertBanner(
          isError = false,
          title = Translations.get(TKey.JOURNEY_STALE_WARNING, lang),
          detail = null,
        )
      }

      val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
      val updatedStr = fmt.format(Date(plan.serviceInfoTimestampMs))

      Surface(
        color = tokens.panelBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.2.dp, tokens.border),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("journey_result_card"),
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(Icons.Default.Schedule, contentDescription = null, tint = tokens.accentBlue)
              Text(
                text = "${Translations.get(TKey.JOURNEY_ESTIMATED_TIME, lang)}: ${plan.totalMinutes} min",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = tokens.textPrimary,
              )
            }
            Text(
              text = "${Translations.get(TKey.JOURNEY_SERVICE_UPDATED, lang)}: $updatedStr",
              fontFamily = MonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = tokens.textSecondary,
            )
          }

          if (plan.legs.isEmpty()) {
            Text(
              text = "${plan.origin.name} (0 min)",
              style = MaterialTheme.typography.bodyLarge,
              color = tokens.textPrimary,
            )
          } else {
            plan.legs.forEach { leg ->
              Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, tokens.border),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  SubwayBulletBadge(
                    label = leg.line.lineCode,
                    bgColor = Color(leg.line.colorHex),
                    textColor = Color(leg.line.textHex),
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "${leg.fromStation.name} → ${leg.toStation.name}",
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = tokens.textPrimary,
                    )
                    Text(
                      text = "${leg.stopsCount} stop(s) • ${leg.minutes} min" +
                        if (leg.toStation.accessible) " • Step-free elevator" else "",
                      style = MaterialTheme.typography.bodyMedium,
                      color = tokens.textSecondary,
                    )
                  }
                }
              }
            }
          }

          Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Info, contentDescription = null, tint = tokens.textSecondary, modifier = Modifier.size(18.dp))
            Text(
              text = if (lang == AppLanguage.ES) plan.disclaimerEs else plan.disclaimerEn,
              style = MaterialTheme.typography.bodyMedium,
              color = tokens.textSecondary,
            )
          }
        }
      }
    } else {
      StatusAlertBanner(
        isError = true,
        title = "No step-free accessible route found between selected stations.",
        detail = "Try disabling the accessible-only filter or choosing an elevator-equipped station.",
      )
    }
  }
}

@Composable
private fun StationChipRow(
  label: String,
  stations: List<SubwayStation>,
  selectedId: String,
  onSelect: (String) -> Unit,
  tagPrefix: String,
) {
  val tokens = LocalKioskTokens.current
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = tokens.textPrimary)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      stations.forEach { st ->
        val selected = st.id == selectedId
        Surface(
          onClick = { onSelect(st.id) },
          shape = RoundedCornerShape(8.dp),
          color = if (selected) tokens.selectedCardBlue else tokens.panelBg,
          border = BorderStroke(1.dp, if (selected) tokens.selectedCardBlue else tokens.border),
          modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("${tagPrefix}_${st.id}"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              text = st.name,
              color = if (selected) PureWhite else tokens.textPrimary,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
            )
            if (st.accessible) {
              Icon(
                Icons.AutoMirrored.Filled.Accessible,
                contentDescription = "Step-free accessible",
                tint = if (selected) PureWhite else tokens.accentBlue,
                modifier = Modifier.size(15.dp),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun NetworkMapDialog(
  language: AppLanguage,
  stations: List<SubwayStation>,
  onDismiss: () -> Unit,
) {
  val tokens = LocalKioskTokens.current
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.DirectionsSubway, contentDescription = null, tint = tokens.accentBlue)
        Text(
          text = "Synthetic Subway Network Map (Demo)",
          fontWeight = FontWeight.ExtraBold,
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
          color = Color(0xFFF8FAFC),
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, tokens.border),
          modifier = Modifier
            .fillMaxWidth()
            .height(210.dp),
        ) {
          Canvas(modifier = Modifier.fillMaxSize().padding(18.dp)) {
            val w = size.width
            val h = size.height
            val sw = 8f
            // Schematic A/C/E Blue Spine
            drawLine(SubwayBlue, Offset(w * 0.2f, 0f), Offset(w * 0.2f, h * 0.72f), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(SubwayBlue, Offset(w * 0.2f, h * 0.72f), Offset(w * 0.75f, h * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
            // 1/2/3 Red Line
            drawLine(SubwayRed, Offset(w * 0.35f, 0f), Offset(w * 0.35f, h * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
            // N/Q/R/W Yellow Line
            drawLine(SubwayYellow, Offset(w * 0.1f, h * 0.22f), Offset(w * 0.85f, h * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
            // 4/5/6 Green Line
            drawLine(SubwayGreen, Offset(w * 0.78f, h * 0.12f), Offset(w * 0.78f, h * 0.92f), strokeWidth = sw, cap = StrokeCap.Round)
            // Crosstown 42 St Shuttle
            drawLine(Color(0xFF475467), Offset(w * 0.2f, h * 0.25f), Offset(w * 0.78f, h * 0.25f), strokeWidth = sw)

            listOf(
              Offset(w * 0.2f, h * 0.25f),
              Offset(w * 0.78f, h * 0.25f),
              Offset(w * 0.35f, h * 0.45f),
              Offset(w * 0.52f, h * 0.62f),
              Offset(w * 0.78f, h * 0.85f),
            ).forEach { pt ->
              drawCircle(PureWhite, radius = 10f, center = pt)
              drawCircle(Color(0xFF111111), radius = 10f, center = pt, style = Stroke(width = 3f))
            }
          }
        }
        Text(
          text = "${stations.size} synthetic demo stations • ${Translations.get(TKey.DEMO_WATERMARK, language)}",
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
      ) {
        Text("Close", color = PureWhite)
      }
    },
  )
}
