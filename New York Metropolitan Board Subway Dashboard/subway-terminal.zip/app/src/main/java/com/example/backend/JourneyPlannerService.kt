package com.example.backend

import java.util.PriorityQueue

data class SubwayLineBadge(
  val lineCode: String,
  val colorHex: Long,
  val textHex: Long = 0xFFFFFFFF,
)

data class SubwayStation(
  val id: String,
  val name: String,
  val accessible: Boolean,
  val lines: List<SubwayLineBadge>,
)

data class RouteLeg(
  val line: SubwayLineBadge,
  val fromStation: SubwayStation,
  val toStation: SubwayStation,
  val stopsCount: Int,
  val minutes: Int,
)

data class JourneyPlanResult(
  val origin: SubwayStation,
  val destination: SubwayStation,
  val accessibleOnly: Boolean,
  val legs: List<RouteLeg>,
  val totalMinutes: Int,
  val serviceInfoTimestampMs: Long,
  val isStale: Boolean,
  val isFeedUnavailable: Boolean,
  val disclaimerEn: String = "Suggested route is informational only and does not prove your product covers this trip.",
  val disclaimerEs: String = "La ruta sugerida es informativa y no garantiza que tu producto cubra este viaje.",
)

interface TransitDataAdapter {
  fun stations(): List<SubwayStation>
  fun planJourney(
    originId: String,
    destinationId: String,
    accessibleOnly: Boolean,
  ): JourneyPlanResult?

  fun setSimulatedStale(stale: Boolean)
  fun setSimulatedFeedUnavailable(unavailable: Boolean)
  fun isStale(): Boolean
  fun isFeedUnavailable(): Boolean
}

class SyntheticNycTransitDataAdapter : TransitDataAdapter {
  private var staleFlag = false
  private var unavailableFlag = false
  private var lastUpdatedMs = System.currentTimeMillis()

  private val blue = 0xFF0039A6L
  private val red = 0xFFEE352EL
  private val yellow = 0xFFFCCC0AL
  private val green = 0xFF00933CL
  private val blackText = 0xFF111111L

  private val badgeA = SubwayLineBadge("A", blue)
  private val badgeC = SubwayLineBadge("C", blue)
  private val badge1 = SubwayLineBadge("1", red)
  private val badge2 = SubwayLineBadge("2", red)
  private val badgeN = SubwayLineBadge("N", yellow, blackText)
  private val badgeQ = SubwayLineBadge("Q", yellow, blackText)
  private val badge4 = SubwayLineBadge("4", green)
  private val badge5 = SubwayLineBadge("5", green)

  private val stationList = listOf(
    SubwayStation("CC", "59 St–Columbus Circle", accessible = true, listOf(badgeA, badgeC, badge1)),
    SubwayStation("TSQ", "Times Sq–42 St", accessible = true, listOf(badgeA, badge1, badge2, badgeN, badgeQ)),
    SubwayStation("GC", "Grand Central–42 St", accessible = true, listOf(badge4, badge5)),
    SubwayStation("PENN", "34 St–Penn Station", accessible = true, listOf(badgeA, badgeC, badge1, badge2)),
    SubwayStation("HSQ", "34 St–Herald Sq", accessible = true, listOf(badgeN, badgeQ)),
    SubwayStation("USQ", "14 St–Union Sq", accessible = true, listOf(badgeN, badgeQ, badge4, badge5)),
    SubwayStation("BLEECK", "Bleecker St", accessible = false, listOf(badge4, badge5)),
    SubwayStation("FUL", "Fulton St", accessible = true, listOf(badgeA, badgeC, badge2, badge4, badge5)),
    SubwayStation("JAY", "Jay St–MetroTech", accessible = true, listOf(badgeA, badgeC, badgeN)),
    SubwayStation("ATL", "Atlantic Av–Barclays Ctr", accessible = true, listOf(badge2, badge4, badge5, badgeN, badgeQ)),
  )

  private data class Edge(val toId: String, val line: SubwayLineBadge, val minutes: Int, val stops: Int)

  private val graph: Map<String, List<Edge>> = mapOf(
    "CC" to listOf(Edge("TSQ", badge1, 4, 1), Edge("TSQ", badgeA, 3, 1)),
    "TSQ" to listOf(
      Edge("CC", badge1, 4, 1),
      Edge("PENN", badgeA, 3, 1),
      Edge("HSQ", badgeN, 3, 1),
      Edge("GC", badge4, 4, 1),
    ),
    "GC" to listOf(Edge("TSQ", badge4, 4, 1), Edge("USQ", badge4, 5, 2)),
    "PENN" to listOf(Edge("TSQ", badgeA, 3, 1), Edge("FUL", badgeA, 9, 4), Edge("HSQ", badgeN, 2, 1)),
    "HSQ" to listOf(Edge("TSQ", badgeN, 3, 1), Edge("PENN", badgeN, 2, 1), Edge("USQ", badgeQ, 4, 2)),
    "USQ" to listOf(
      Edge("GC", badge4, 5, 2),
      Edge("HSQ", badgeQ, 4, 2),
      Edge("BLEECK", badge4, 3, 1),
      Edge("FUL", badge5, 7, 3),
    ),
    "BLEECK" to listOf(Edge("USQ", badge4, 3, 1), Edge("FUL", badge4, 5, 2)),
    "FUL" to listOf(
      Edge("PENN", badgeA, 9, 4),
      Edge("USQ", badge5, 7, 3),
      Edge("BLEECK", badge4, 5, 2),
      Edge("JAY", badgeA, 5, 2),
    ),
    "JAY" to listOf(Edge("FUL", badgeA, 5, 2), Edge("ATL", badgeN, 6, 2)),
    "ATL" to listOf(Edge("JAY", badgeN, 6, 2), Edge("FUL", badge4, 9, 3)),
  )

  override fun stations(): List<SubwayStation> = stationList

  override fun planJourney(
    originId: String,
    destinationId: String,
    accessibleOnly: Boolean,
  ): JourneyPlanResult? {
    val byId = stationList.associateBy { it.id }
    val origin = byId[originId] ?: return null
    val dest = byId[destinationId] ?: return null
    if (originId == destinationId) {
      return JourneyPlanResult(
        origin = origin,
        destination = dest,
        accessibleOnly = accessibleOnly,
        legs = emptyList(),
        totalMinutes = 0,
        serviceInfoTimestampMs = if (staleFlag) lastUpdatedMs - 45 * 60_000L else System.currentTimeMillis(),
        isStale = staleFlag,
        isFeedUnavailable = unavailableFlag,
      )
    }

    if (accessibleOnly && (!origin.accessible || !dest.accessible)) {
      return null
    }

    val dist = mutableMapOf<String, Int>().withDefault { Int.MAX_VALUE }
    val prev = mutableMapOf<String, Pair<String, Edge>>()
    val pq = PriorityQueue<Pair<String, Int>>(compareBy { it.second })
    dist[originId] = 0
    pq.add(originId to 0)

    while (pq.isNotEmpty()) {
      val (u, d) = pq.poll() ?: break
      if (d > dist.getValue(u)) continue
      if (u == destinationId) break
      for (edge in graph[u].orEmpty()) {
        val nextStation = byId[edge.toId] ?: continue
        if (accessibleOnly && !nextStation.accessible) continue
        val nd = d + edge.minutes
        if (nd < dist.getValue(edge.toId)) {
          dist[edge.toId] = nd
          prev[edge.toId] = u to edge
          pq.add(edge.toId to nd)
        }
      }
    }

    if (!prev.containsKey(destinationId)) return null

    val rawEdges = mutableListOf<Pair<String, Edge>>()
    var cur = destinationId
    while (cur != originId) {
      val p = prev[cur] ?: break
      rawEdges.add(p)
      cur = p.first
    }
    rawEdges.reverse()

    val legs = rawEdges.mapNotNull { (fromId, edge) ->
      val fromStation = byId[fromId] ?: return@mapNotNull null
      val toStation = byId[edge.toId] ?: return@mapNotNull null
      RouteLeg(
        line = edge.line,
        fromStation = fromStation,
        toStation = toStation,
        stopsCount = edge.stops,
        minutes = edge.minutes,
      )
    }

    return JourneyPlanResult(
      origin = origin,
      destination = dest,
      accessibleOnly = accessibleOnly,
      legs = legs,
      totalMinutes = dist.getValue(destinationId),
      serviceInfoTimestampMs = if (staleFlag) lastUpdatedMs - 45 * 60_000L else System.currentTimeMillis(),
      isStale = staleFlag,
      isFeedUnavailable = unavailableFlag,
    )
  }

  override fun setSimulatedStale(stale: Boolean) {
    staleFlag = stale
  }

  override fun setSimulatedFeedUnavailable(unavailable: Boolean) {
    unavailableFlag = unavailable
  }

  override fun isStale(): Boolean = staleFlag
  override fun isFeedUnavailable(): Boolean = unavailableFlag
}
