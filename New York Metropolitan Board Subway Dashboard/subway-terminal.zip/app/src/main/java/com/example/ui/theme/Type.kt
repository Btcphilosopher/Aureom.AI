package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val InterFontFamily = FontFamily(
  Font(R.font.inter, FontWeight.Normal),
  Font(R.font.inter, FontWeight.Medium),
  Font(R.font.inter, FontWeight.SemiBold),
  Font(R.font.inter, FontWeight.Bold),
)

val MonoFontFamily = FontFamily(
  Font(R.font.jetbrains_mono, FontWeight.Normal),
  Font(R.font.jetbrains_mono, FontWeight.Bold),
)

fun buildKioskTypography(largeText: Boolean): Typography {
  val scale = if (largeText) 1.22f else 1.0f
  return Typography(
    displaySmall = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Bold,
      fontSize = (32 * scale).sp,
      lineHeight = (38 * scale).sp,
      letterSpacing = (-0.5).sp,
    ),
    headlineMedium = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Bold,
      fontSize = (24 * scale).sp,
      lineHeight = (30 * scale).sp,
      letterSpacing = (-0.3).sp,
    ),
    titleLarge = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Bold,
      fontSize = (20 * scale).sp,
      lineHeight = (26 * scale).sp,
    ),
    titleMedium = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.SemiBold,
      fontSize = (16 * scale).sp,
      lineHeight = (22 * scale).sp,
    ),
    bodyLarge = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Normal,
      fontSize = (15 * scale).sp,
      lineHeight = (22 * scale).sp,
    ),
    bodyMedium = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Normal,
      fontSize = (13 * scale).sp,
      lineHeight = (18 * scale).sp,
    ),
    labelLarge = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.Bold,
      fontSize = (15 * scale).sp,
      lineHeight = (20 * scale).sp,
    ),
    labelSmall = TextStyle(
      fontFamily = InterFontFamily,
      fontWeight = FontWeight.SemiBold,
      fontSize = (11 * scale).sp,
      lineHeight = (15 * scale).sp,
    ),
  )
}
