package com.example.hardware

import com.example.domain.model.PaymentMethod
import com.example.domain.model.PaymentState
import com.example.domain.model.PaymentSubState
import kotlinx.coroutines.flow.StateFlow

enum class AdapterOperationalStatus {
  READY,
  BUSY,
  DEGRADED,
  OFFLINE,
  JAMMED,
  OUT_OF_SUPPLIES,
}

data class HardwareError(
  val code: String,
  val message: String,
  val recoverable: Boolean,
)

data class AdapterCapabilities(
  val adapterName: String,
  val isSimulated: Boolean = true,
  val supportedOperations: List<String>,
  val available: Boolean,
  val status: AdapterOperationalStatus,
  val lastError: HardwareError? = null,
)

data class PaymentTerminalResult(
  val state: PaymentState,
  val subState: PaymentSubState,
  val maskedInstrumentRef: String? = null,
  val providerEventId: String? = null,
  val error: HardwareError? = null,
)

data class CardIdentificationResult(
  val success: Boolean,
  val opaqueCardRef: String? = null,
  val isAccountBased: Boolean = false,
  val error: HardwareError? = null,
)

data class AuthoritativeCardSnapshot(
  val cardRef: String,
  val isAccountBased: Boolean,
  val authoritativeBalanceCents: Int,
  val activeEntitlementEn: String,
  val activeEntitlementEs: String,
  val eligibilityTier: String,
  val status: String,
  val lastSyncedAtMs: Long,
)

data class FulfilmentExecutionResult(
  val success: Boolean,
  val responseLostAfterCommit: Boolean = false,
  val issuedCardRef: String? = null,
  val externalFulfilmentRef: String? = null,
  val updatedBalanceCents: Int? = null,
  val error: HardwareError? = null,
)

data class DispenserResult(
  val dispensed: Boolean,
  val collected: Boolean = false,
  val jammed: Boolean = false,
  val error: HardwareError? = null,
)

data class PrinterResult(
  val printed: Boolean,
  val error: HardwareError? = null,
)

data class BarcodeScanResult(
  val success: Boolean,
  val scannedCode: String? = null,
  val error: HardwareError? = null,
)

/**
 * 1. Contactless payment & EMV chip terminal adapter.
 * Strictly isolated from transit-card identification and never exposes raw card numbers or PINs.
 */
interface PaymentTerminalAdapter {
  fun capabilities(): AdapterCapabilities
  suspend fun authorizeAndCapture(
    orderId: String,
    amountCents: Int,
    currency: String,
    method: PaymentMethod,
    idempotencyKey: String,
  ): PaymentTerminalResult

  suspend fun queryAuthoritativeOutcome(idempotencyKey: String): PaymentTerminalResult
  suspend fun requestRefundOrReversal(
    paymentAttemptId: String,
    amountCents: Int,
  ): PaymentSubState
}

/**
 * 2. Transit-card reader adapter.
 * Identifying an NFC identifier does NOT prove payment or grant direct stored-value write access.
 */
interface TransitCardReaderAdapter {
  fun capabilities(): AdapterCapabilities
  suspend fun identifyCard(simulatedCardRef: String? = null): CardIdentificationResult
}

/**
 * 3. Authorised fare-system fulfilment service.
 * Credits authoritative accounts, provisions travel products, or queries authoritative balances.
 */
interface TravelProductFulfilmentService {
  fun capabilities(): AdapterCapabilities
  suspend fun fetchAuthoritativeCard(cardRef: String): AuthoritativeCardSnapshot?
  suspend fun provisionNewCard(
    orderId: String,
    idempotencyKey: String,
    storedValueCents: Int,
    entitlementEn: String,
    entitlementEs: String,
    isAccountBased: Boolean,
  ): FulfilmentExecutionResult

  suspend fun applyReload(
    orderId: String,
    idempotencyKey: String,
    cardRef: String,
    addStoredValueCents: Int,
    newEntitlementEn: String?,
    newEntitlementEs: String?,
  ): FulfilmentExecutionResult
}

interface CardDispenserAdapter {
  fun capabilities(): AdapterCapabilities
  suspend fun checkAvailability(): Boolean
  suspend fun dispensePhysicalCard(cardRef: String): DispenserResult
  suspend fun confirmCustomerCollection(): Boolean
  suspend fun clearJamAndRestock(newStockCount: Int)
}

interface ReceiptPrinterAdapter {
  fun capabilities(): AdapterCapabilities
  suspend fun printReceipt(receiptText: String): PrinterResult
}

interface BarcodeScannerAdapter {
  fun capabilities(): AdapterCapabilities
  suspend fun scanDemoCode(presetCode: String? = null): BarcodeScanResult
}

interface CashAcceptorAdapter {
  fun capabilities(): AdapterCapabilities
}

enum class PaymentFaultMode {
  NORMAL,
  DECLINE,
  OUTCOME_UNKNOWN,
  READER_TIMEOUT,
  NETWORK_INTERRUPTION,
}

enum class FulfilmentFaultMode {
  NORMAL,
  PROVISION_FAIL_AFTER_PAYMENT,
  PROVISION_SUCCEEDED_RESPONSE_LOST,
  DISPENSER_JAM,
  CARD_NOT_COLLECTED,
  PRINTER_UNAVAILABLE,
}

data class HardwareHealthSnapshot(
  val paymentTerminal: AdapterCapabilities,
  val transitReader: AdapterCapabilities,
  val fulfilmentService: AdapterCapabilities,
  val cardDispenser: AdapterCapabilities,
  val receiptPrinter: AdapterCapabilities,
  val barcodeScanner: AdapterCapabilities,
  val cashAcceptor: AdapterCapabilities,
  val cardStockRemaining: Int,
  val receiptPaperPercent: Int,
  val paymentFaultMode: PaymentFaultMode,
  val fulfilmentFaultMode: FulfilmentFaultMode,
  val transitReaderTimeoutFault: Boolean,
)

interface DeviceHealthMonitor {
  val healthFlow: StateFlow<HardwareHealthSnapshot>
  fun setPaymentFaultMode(mode: PaymentFaultMode)
  fun setFulfilmentFaultMode(mode: FulfilmentFaultMode)
  fun setTransitReaderTimeoutFault(enabled: Boolean)
  fun setCashAdapterAvailable(available: Boolean)
  fun setPrinterPaperPercent(percent: Int)
  fun setCardStock(count: Int)
}
