package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.domain.model.StepProgress
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusWarnBg
import com.example.ui.theme.StatusWarnFg
import com.example.ui.theme.SubwayBlue
import com.example.ui.theme.SubwayGreen
import com.example.ui.theme.SubwayRed
import com.example.ui.theme.SubwayYellow
import com.example.ui.theme.TransitBlueDarkCard

@Composable
fun KioskHeaderBar(
  operatorTitle: String,
  badgeCode: String,
  badgeColorHex: Long,
  language: AppLanguage,
  canToggleLanguage: Boolean,
  onToggleLanguage: () -> Unit,
  onOpenAccessibility: () -> Unit,
  compact: Boolean,
) {
  val tokens = LocalKioskTokens.current
  Surface(
    color = tokens.headerBg,
    contentColor = tokens.headerFg,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier
        .statusBarsPadding()
        .fillMaxWidth()
        .padding(horizontal = if (compact) 12.dp else 20.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier = Modifier
            .size(if (compact) 38.dp else 44.dp)
            .clip(CircleShape)
            .background(Color(badgeColorHex)),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = badgeCode,
            color = PureWhite,
            fontWeight = FontWeight.ExtraBold,
            fontSize = if (compact) 12.sp else 14.sp,
            maxLines = 1,
          )
        }
        Spacer(Modifier.width(12.dp))
        Box(
          modifier = Modifier
            .width(1.dp)
            .height(34.dp)
            .background(Color.White.copy(alpha = 0.25f))
        )
        Spacer(Modifier.width(12.dp))
        Column {
          Text(
            text = operatorTitle,
            style = MaterialTheme.typography.titleLarge,
            color = tokens.headerFg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = Translations.get(TKey.HEADER_SUBTITLE, language),
            style = MaterialTheme.typography.bodyMedium,
            color = tokens.headerFg.copy(alpha = 0.85f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        if (canToggleLanguage) {
          Surface(
            onClick = onToggleLanguage,
            color = Color.Transparent,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.7f)),
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("language_toggle_button"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = Translations.get(TKey.LANG_TOGGLE_LABEL, language),
                color = tokens.headerFg,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
              )
              Spacer(Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = tokens.headerFg,
                modifier = Modifier.size(18.dp),
              )
            }
          }
          Spacer(Modifier.width(10.dp))
        }

        Box(
          modifier = Modifier
            .width(1.dp)
            .height(28.dp)
            .background(Color.White.copy(alpha = 0.25f))
        )
        Spacer(Modifier.width(10.dp))

        val a11yDesc = Translations.get(TKey.A11Y_BUTTON_DESC, language)
        Surface(
          onClick = onOpenAccessibility,
          color = Color.Transparent,
          shape = CircleShape,
          border = BorderStroke(1.5.dp, tokens.headerFg),
          modifier = Modifier
            .size(44.dp)
            .minimumInteractiveComponentSize()
            .testTag("a11y_button")
            .semantics { contentDescription = a11yDesc },
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.AccessibilityNew,
              contentDescription = a11yDesc,
              tint = tokens.headerFg,
              modifier = Modifier.size(22.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
fun KioskSubHeader(
  language: AppLanguage,
  activeStep: StepProgress,
  compact: Boolean,
) {
  val tokens = LocalKioskTokens.current
  Surface(color = tokens.panelBg, modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.fillMaxWidth()) {
      if (compact) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = Translations.get(TKey.HERO_TITLE, language),
            style = MaterialTheme.typography.headlineMedium,
            color = tokens.textPrimary,
          )
          Text(
            text = Translations.get(TKey.HERO_SUBTITLE, language),
            style = MaterialTheme.typography.bodyMedium,
            color = tokens.textSecondary,
          )
          StepProgressBar(language = language, activeStep = activeStep, compact = true)
        }
      } else {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = Translations.get(TKey.HERO_TITLE, language),
              style = MaterialTheme.typography.displaySmall,
              color = tokens.textPrimary,
            )
            Text(
              text = Translations.get(TKey.HERO_SUBTITLE, language),
              style = MaterialTheme.typography.bodyLarge,
              color = tokens.textPrimary,
              fontWeight = FontWeight.Medium,
            )
          }
          Spacer(Modifier.width(16.dp))
          StepProgressBar(language = language, activeStep = activeStep, compact = false)
        }
      }
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(1.5.dp)
          .background(tokens.divider)
      )
    }
  }
}

@Composable
fun StepProgressBar(
  language: AppLanguage,
  activeStep: StepProgress,
  compact: Boolean,
) {
  val tokens = LocalKioskTokens.current
  val steps = listOf(
    Triple(StepProgress.CHOOSE, 1, Translations.get(TKey.STEP_CHOOSE, language)),
    Triple(StepProgress.REVIEW_AND_PAY, 2, Translations.get(TKey.STEP_REVIEW_PAY, language)),
    Triple(StepProgress.COLLECT, 3, Translations.get(TKey.STEP_COLLECT, language)),
  )
  Row(verticalAlignment = Alignment.CenterVertically) {
    steps.forEachIndexed { index, (step, num, label) ->
      val isCompleted = step.stepNumber < activeStep.stepNumber
      val isCurrent = step == activeStep
      val circleBg = when {
        isCurrent -> tokens.accentBlue
        isCompleted -> tokens.textPrimary
        else -> Color(0xFF8A9099)
      }
      val labelColor = when {
        isCurrent -> tokens.accentBlue
        isCompleted -> tokens.textPrimary
        else -> Color(0xFF6B7280)
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(if (compact) 24.dp else 30.dp)
            .clip(CircleShape)
            .background(circleBg),
          contentAlignment = Alignment.Center,
        ) {
          if (isCompleted) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = null,
              tint = PureWhite,
              modifier = Modifier.size(16.dp),
            )
          } else {
            Text(
              text = num.toString(),
              color = PureWhite,
              fontWeight = FontWeight.Bold,
              fontSize = if (compact) 12.sp else 14.sp,
            )
          }
        }
        Spacer(Modifier.width(6.dp))
        Text(
          text = label,
          color = labelColor,
          fontWeight = if (isCurrent || isCompleted) FontWeight.Bold else FontWeight.Medium,
          style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.titleMedium,
          maxLines = 1,
        )
      }
      if (index < steps.lastIndex) {
        Box(
          modifier = Modifier
            .padding(horizontal = if (compact) 6.dp else 12.dp)
            .width(if (compact) 18.dp else 36.dp)
            .height(1.5.dp)
            .background(Color(0xFF98A2B3))
        )
      }
    }
  }
}

@Composable
fun SessionTimeoutBanner(
  language: AppLanguage,
  secondsRemaining: Int,
  onExtendSession: () -> Unit,
) {
  Surface(
    color = StatusWarnBg,
    border = BorderStroke(1.5.dp, StatusWarnFg),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("timeout_warning_banner"),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarnFg)
        Spacer(Modifier.width(8.dp))
        Text(
          text = "${Translations.get(TKey.SESSION_TIMEOUT_WARNING, language)} (${secondsRemaining}s)",
          color = StatusWarnFg,
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.bodyMedium,
        )
      }
      Button(
        onClick = onExtendSession,
        colors = ButtonDefaults.buttonColors(containerColor = StatusWarnFg),
        modifier = Modifier.testTag("extend_session_button"),
      ) {
        Text(Translations.get(TKey.EXTEND_SESSION, language), color = PureWhite)
      }
    }
  }
}

@Composable
fun KioskFooterBar(
  language: AppLanguage,
  canGoBack: Boolean,
  onBack: () -> Unit,
  onStartOver: () -> Unit,
  onGetHelp: () -> Unit,
  compact: Boolean,
) {
  val tokens = LocalKioskTokens.current
  Surface(
    color = tokens.headerBg,
    contentColor = tokens.headerFg,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier
        .navigationBarsPadding()
        .fillMaxWidth()
        .padding(horizontal = if (compact) 10.dp else 20.dp, vertical = 8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          FooterActionButton(
            icon = {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = if (canGoBack) tokens.headerFg else tokens.headerFg.copy(alpha = 0.45f), modifier = Modifier.size(18.dp))
            },
            label = Translations.get(TKey.FOOTER_BACK, language),
            enabled = canGoBack,
            onClick = onBack,
            tag = "footer_back_button",
          )
          FooterDivider()
          FooterActionButton(
            icon = {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = tokens.headerFg, modifier = Modifier.size(18.dp))
            },
            label = Translations.get(TKey.FOOTER_START_OVER, language),
            enabled = true,
            onClick = onStartOver,
            tag = "footer_start_over_button",
          )
          FooterDivider()
          FooterActionButton(
            icon = {
              Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, tint = tokens.headerFg, modifier = Modifier.size(18.dp))
            },
            label = Translations.get(TKey.FOOTER_GET_HELP, language),
            enabled = true,
            onClick = onGetHelp,
            tag = "footer_help_button",
          )
        }

        if (!compact) {
          Text(
            text = Translations.get(TKey.FOOTER_DEMO_SESSION, language),
            color = tokens.headerFg,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }
      Text(
        text = Translations.get(TKey.FOOTER_DISCLAIMER, language),
        color = tokens.headerFg.copy(alpha = 0.72f),
        style = MaterialTheme.typography.labelSmall,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.align(Alignment.CenterHorizontally),
      )
    }
  }
}

@Composable
private fun FooterActionButton(
  icon: @Composable () -> Unit,
  label: String,
  enabled: Boolean,
  onClick: () -> Unit,
  tag: String,
) {
  val tokens = LocalKioskTokens.current
  Row(
    modifier = Modifier
      .minimumInteractiveComponentSize()
      .clip(RoundedCornerShape(6.dp))
      .clickable(enabled = enabled, onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 6.dp)
      .testTag(tag),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    icon()
    Spacer(Modifier.width(6.dp))
    Text(
      text = label,
      color = if (enabled) tokens.headerFg else tokens.headerFg.copy(alpha = 0.45f),
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
    )
  }
}

@Composable
private fun FooterDivider() {
  Box(
    modifier = Modifier
      .padding(horizontal = 4.dp)
      .width(1.dp)
      .height(20.dp)
      .background(Color.White.copy(alpha = 0.25f))
  )
}

@Composable
fun SubwayBulletBadge(
  label: String,
  bgColor: Color,
  textColor: Color = PureWhite,
  size: Dp = 26.dp,
) {
  Box(
    modifier = Modifier
      .size(size)
      .clip(CircleShape)
      .background(bgColor),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      color = textColor,
      fontWeight = FontWeight.ExtraBold,
      fontSize = (size.value * 0.54f).sp,
    )
  }
}

@Composable
fun ContactlessWavesIcon(
  color: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    val strokeWidth = size.minDimension * 0.09f
    val centerX = size.width * 0.2f
    val centerY = size.height * 0.5f
    listOf(0.28f, 0.48f, 0.68f, 0.88f).forEach { factor ->
      val r = size.minDimension * factor * 0.55f
      drawArc(
        color = color,
        startAngle = -52f,
        sweepAngle = 104f,
        useCenter = false,
        topLeft = Offset(centerX - r, centerY - r),
        size = Size(r * 2f, r * 2f),
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
      )
    }
  }
}

@Composable
fun TransitCardArtwork(
  modifier: Modifier = Modifier,
  cardTitle: String = "DEMO",
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .background(TransitBlueDarkCard)
      .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val stroke = Stroke(width = w * 0.022f, cap = StrokeCap.Round)
      val lineColor = Color.White.copy(alpha = 0.9f)

      // Horizontal + curved transit track motif matching attached image
      val path1 = Path().apply {
        moveTo(0f, h * 0.34f)
        lineTo(w * 0.28f, h * 0.34f)
        quadraticTo(w * 0.42f, h * 0.34f, w * 0.42f, h * 0.54f)
        lineTo(w * 0.42f, h)
      }
      drawPath(path1, lineColor, style = stroke)

      val path2 = Path().apply {
        moveTo(0f, h * 0.72f)
        lineTo(w * 0.46f, h * 0.72f)
        quadraticTo(w * 0.56f, h * 0.72f, w * 0.62f, h * 0.61f)
        lineTo(w, h * 0.61f)
      }
      drawPath(path2, lineColor, style = stroke)

      // Station nodes
      listOf(
        Offset(w * 0.24f, h * 0.34f),
        Offset(w * 0.42f, h * 0.72f),
        Offset(w * 0.75f, h * 0.61f),
      ).forEach { center ->
        drawCircle(color = TransitBlueDarkCard, radius = w * 0.042f, center = center)
        drawCircle(color = lineColor, radius = w * 0.042f, center = center, style = Stroke(width = w * 0.018f))
      }
    }

    ContactlessWavesIcon(
      color = PureWhite,
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(14.dp)
        .size(30.dp),
    )

    Text(
      text = cardTitle,
      color = PureWhite.copy(alpha = 0.78f),
      fontFamily = MonoFontFamily,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier
        .align(Alignment.BottomStart)
        .padding(horizontal = 14.dp, vertical = 10.dp),
    )
  }
}

@Composable
fun MiniSchematicNetworkMap(modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFFF8FAFC))
      .border(1.dp, Color(0xFFD0D5DD), RoundedCornerShape(8.dp)),
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
      val w = size.width
      val h = size.height
      val sw = w * 0.04f

      // Blue line
      drawLine(SubwayBlue, Offset(w * 0.15f, h * 0.25f), Offset(w * 0.55f, h * 0.92f), strokeWidth = sw, cap = StrokeCap.Round)
      // Red line
      drawLine(SubwayRed, Offset(w * 0.4f, h * 0.08f), Offset(w * 0.85f, h * 0.45f), strokeWidth = sw, cap = StrokeCap.Round)
      // Yellow loop
      drawLine(SubwayYellow, Offset(w * 0.1f, h * 0.55f), Offset(w * 0.88f, h * 0.25f), strokeWidth = sw, cap = StrokeCap.Round)
      // Green line
      drawLine(SubwayGreen, Offset(w * 0.1f, h * 0.75f), Offset(w * 0.92f, h * 0.62f), strokeWidth = sw, cap = StrokeCap.Round)

      listOf(
        Offset(w * 0.35f, h * 0.44f),
        Offset(w * 0.68f, h * 0.65f),
        Offset(w * 0.52f, h * 0.26f),
      ).forEach { pt ->
        drawCircle(PureWhite, radius = w * 0.045f, center = pt)
        drawCircle(Color(0xFF111111), radius = w * 0.045f, center = pt, style = Stroke(width = w * 0.018f))
      }
    }
  }
}
