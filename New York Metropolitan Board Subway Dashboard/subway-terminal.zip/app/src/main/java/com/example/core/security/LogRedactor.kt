package com.example.core.security

/**
 * Redacts PAN-like card numbers, PINs, CVVs, and secret tokens before audit logging
 * or diagnostic persistence. Ensures payment secrets never enter storage or logs.
 */
object LogRedactor {
  private val panRegex = Regex("""\b(?:\d[ -]*?){13,19}\b""")
  private val pinRegex = Regex("""(?i)(pin|cvv|cvc|secret|token|password)\s*[:=]\s*\S+""")

  fun redact(input: String): String {
    var sanitized = panRegex.replace(input) { match ->
      val digits = match.value.filter { it.isDigit() }
      if (digits.length >= 13) "••••-••••-••••-${digits.takeLast(4)}" else match.value
    }
    sanitized = pinRegex.replace(sanitized) { match ->
      val key = match.groupValues[1]
      "$key=[REDACTED]"
    }
    return sanitized
  }
}
