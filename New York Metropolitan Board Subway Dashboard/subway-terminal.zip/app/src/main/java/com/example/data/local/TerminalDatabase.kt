package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.runBlocking

@Database(
  entities = [
    OperatorEntity::class,
    TerminalEntity::class,
    ProductVersionEntity::class,
    PricingRuleEntity::class,
    KioskSessionEntity::class,
    OrderEntity::class,
    PaymentAttemptEntity::class,
    FulfilmentOperationEntity::class,
    TransitAccountEntity::class,
    DeviceEventEntity::class,
    ReceiptEntity::class,
    RefundEntity::class,
    ReconciliationCaseEntity::class,
    AuditEventEntity::class,
  ],
  version = 1,
  exportSchema = false,
)
abstract class TerminalDatabase : RoomDatabase() {
  abstract fun terminalDao(): TerminalDao

  companion object {
    @Volatile private var INSTANCE: TerminalDatabase? = null

    fun getInstance(context: Context): TerminalDatabase {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(
          context.applicationContext,
          TerminalDatabase::class.java,
          "subway_terminal_demo.db",
        ).build().also { db ->
          INSTANCE = db
        }
      }
    }

    fun createInMemory(context: Context): TerminalDatabase {
      return Room.inMemoryDatabaseBuilder(
        context.applicationContext,
        TerminalDatabase::class.java,
      ).allowMainThreadQueries().build()
    }
  }
}

object DatabaseSeeder {
  suspend fun seedIfEmpty(dao: TerminalDao) {
    if (dao.getOperator() != null) return
    val now = System.currentTimeMillis()
    val oneYearMs = 365L * 24 * 60 * 60 * 1000

    dao.upsertOperator(
      OperatorEntity(
        operatorId = "OP-NYC-DEMO",
        badgeCode = "MTA",
        displayName = "New York Subway",
        badgeColorHex = 0xFF0039A6,
        demoWatermark = "DEMO — NOT VALID FOR TRAVEL",
        enabledLanguagesCsv = "en,es",
      )
    )

    dao.upsertTerminal(
      TerminalEntity(
        terminalId = "KIOSK-NY-042",
        operatorId = "OP-NYC-DEMO",
        stationName = "Times Sq–42 St (Demo)",
        cardStockRemaining = 48,
        receiptPaperPercent = 82,
        cashAdapterEnabled = false,
        sessionTimeoutSeconds = 90,
        isOnline = true,
      )
    )

    // 1. Reloadable Contactless Travel Card (matches screenshot defaults: $20 + $1 fee = $21.00 USD)
    dao.insertProductVersion(
      ProductVersionEntity(
        productVersionId = "PROD-CARD-V1",
        operatorId = "OP-NYC-DEMO",
        productCode = "CARD_RELOADABLE_SV",
        versionNumber = 1,
        category = "NEW_CARD",
        titleEn = "Reloadable contactless travel card",
        titleEs = "Tarjeta de viaje recargable sin contacto",
        descriptionEn = "Reusable NFC travel card with illustrative stored value.",
        descriptionEs = "Tarjeta NFC reutilizable con saldo ilustrativo.",
        eligibilityRestriction = "NONE",
        refundRule = "NON_REFUNDABLE_ISSUE_FEE",
        salesStartEpochMs = now - oneYearMs,
        salesEndEpochMs = now + oneYearMs,
        isAccountBasedCapable = true,
        isActive = true,
        createdAtMs = now,
      )
    )
    dao.insertPricingRules(
      listOf(
        PricingRuleEntity(
          pricingRuleId = "RULE-CARD-10",
          productVersionId = "PROD-CARD-V1",
          optionLabel = "$10",
          storedValueCents = 1000,
          fareEntitlementCents = 1000,
          cardIssueFeeCents = 100,
          fixedSalePriceCents = null,
          entitlementTextEn = "$10.00 demo stored value",
          entitlementTextEs = "$10.00 saldo demo",
          isDefault = false,
        ),
        PricingRuleEntity(
          pricingRuleId = "RULE-CARD-20",
          productVersionId = "PROD-CARD-V1",
          optionLabel = "$20",
          storedValueCents = 2000,
          fareEntitlementCents = 2000,
          cardIssueFeeCents = 100,
          fixedSalePriceCents = null,
          entitlementTextEn = "$20.00 demo stored value",
          entitlementTextEs = "$20.00 saldo demo",
          isDefault = true,
        ),
        PricingRuleEntity(
          pricingRuleId = "RULE-CARD-40",
          productVersionId = "PROD-CARD-V1",
          optionLabel = "$40",
          storedValueCents = 4000,
          fareEntitlementCents = 4000,
          cardIssueFeeCents = 100,
          fixedSalePriceCents = null,
          entitlementTextEn = "$40.00 demo stored value",
          entitlementTextEs = "$40.00 saldo demo",
          isDefault = false,
        ),
      )
    )

    // 2. Operator-configured 7-Day Unlimited Demo Pass
    dao.insertProductVersion(
      ProductVersionEntity(
        productVersionId = "PROD-PASS7-V1",
        operatorId = "OP-NYC-DEMO",
        productCode = "PASS_7DAY_DEMO",
        versionNumber = 1,
        category = "PASS",
        titleEn = "7-Day Unlimited Demo Pass + Card",
        titleEs = "Pase Ilimitado Demo 7 Días + Tarjeta",
        descriptionEn = "Time-based demo entitlement stored separate from cash value.",
        descriptionEs = "Derecho por tiempo demo separado del saldo monetario.",
        eligibilityRestriction = "DEMO_ADULT",
        refundRule = "REFUNDABLE_PRIOR_TO_FIRST_USE",
        salesStartEpochMs = now - oneYearMs,
        salesEndEpochMs = now + oneYearMs,
        isAccountBasedCapable = true,
        isActive = true,
        createdAtMs = now,
      )
    )
    dao.insertPricingRules(
      listOf(
        PricingRuleEntity(
          pricingRuleId = "RULE-PASS7-DEFAULT",
          productVersionId = "PROD-PASS7-V1",
          optionLabel = "7-Day Pass",
          storedValueCents = 0,
          fareEntitlementCents = 3400,
          cardIssueFeeCents = 100,
          fixedSalePriceCents = 3500,
          entitlementTextEn = "7-Day Demo Pass ($34.00 entitlement)",
          entitlementTextEs = "Pase Demo 7 Días ($34.00 derecho)",
          isDefault = true,
        )
      )
    )

    // 3. Stored-value Reload Product ($0 issue fee)
    dao.insertProductVersion(
      ProductVersionEntity(
        productVersionId = "PROD-RELOAD-V1",
        operatorId = "OP-NYC-DEMO",
        productCode = "RELOAD_STORED_VALUE",
        versionNumber = 1,
        category = "RELOAD",
        titleEn = "Stored-value card or account reload",
        titleEs = "Recarga de saldo en tarjeta o cuenta",
        descriptionEn = "Adds demo stored value to an identified card or account.",
        descriptionEs = "Agrega saldo demo a una tarjeta o cuenta identificada.",
        eligibilityRestriction = "NONE",
        refundRule = "STORE_CREDIT_ONLY",
        salesStartEpochMs = now - oneYearMs,
        salesEndEpochMs = now + oneYearMs,
        isAccountBasedCapable = true,
        isActive = true,
        createdAtMs = now,
      )
    )
    dao.insertPricingRules(
      listOf(
        PricingRuleEntity(
          pricingRuleId = "RULE-RELOAD-10",
          productVersionId = "PROD-RELOAD-V1",
          optionLabel = "$10",
          storedValueCents = 1000,
          fareEntitlementCents = 1000,
          cardIssueFeeCents = 0,
          fixedSalePriceCents = null,
          entitlementTextEn = "+$10.00 demo stored value",
          entitlementTextEs = "+$10.00 saldo demo",
          isDefault = false,
        ),
        PricingRuleEntity(
          pricingRuleId = "RULE-RELOAD-20",
          productVersionId = "PROD-RELOAD-V1",
          optionLabel = "$20",
          storedValueCents = 2000,
          fareEntitlementCents = 2000,
          cardIssueFeeCents = 0,
          fixedSalePriceCents = null,
          entitlementTextEn = "+$20.00 demo stored value",
          entitlementTextEs = "+$20.00 saldo demo",
          isDefault = true,
        ),
        PricingRuleEntity(
          pricingRuleId = "RULE-RELOAD-40",
          productVersionId = "PROD-RELOAD-V1",
          optionLabel = "$40",
          storedValueCents = 4000,
          fareEntitlementCents = 4000,
          cardIssueFeeCents = 0,
          fixedSalePriceCents = null,
          entitlementTextEn = "+$40.00 demo stored value",
          entitlementTextEs = "+$40.00 saldo demo",
          isDefault = false,
        ),
      )
    )

    // Seed authoritative transit cards & accounts
    dao.upsertTransitAccount(
      TransitAccountEntity(
        cardRef = "CRD-4829-1104",
        operatorId = "OP-NYC-DEMO",
        isAccountBased = false,
        authoritativeBalanceCents = 1250,
        activeEntitlementEn = "Pay-per-ride stored value",
        activeEntitlementEs = "Saldo por viaje",
        eligibilityTier = "STANDARD",
        status = "ACTIVE",
        lastSyncedAtMs = now,
      )
    )
    dao.upsertTransitAccount(
      TransitAccountEntity(
        cardRef = "ACCT-9012-7731",
        operatorId = "OP-NYC-DEMO",
        isAccountBased = true,
        authoritativeBalanceCents = 475,
        activeEntitlementEn = "7-Day Demo Pass (Active)",
        activeEntitlementEs = "Pase Demo 7 Días (Activo)",
        eligibilityTier = "REDUCED_FARE_VERIFIED",
        status = "ACTIVE",
        lastSyncedAtMs = now,
      )
    )
    dao.upsertTransitAccount(
      TransitAccountEntity(
        cardRef = "CRD-0000-BLOCKED",
        operatorId = "OP-NYC-DEMO",
        isAccountBased = false,
        authoritativeBalanceCents = 0,
        activeEntitlementEn = "Suspended in operator ledger",
        activeEntitlementEs = "Suspendida en sistema del operador",
        eligibilityTier = "STANDARD",
        status = "BLOCKED",
        lastSyncedAtMs = now,
      )
    )

    dao.insertAuditEvent(
      AuditEventEntity(
        auditId = "AUD-BOOT-001",
        actorId = "SYSTEM",
        actorRole = "SYSTEM",
        action = "TERMINAL_INITIALIZED",
        targetEntityId = "KIOSK-NY-042",
        redactedDetails = "Seeded demonstration operator catalog v1 and authoritative demo accounts.",
        createdAtMs = now,
      )
    )
  }

  fun seedBlocking(dao: TerminalDao) = runBlocking { seedIfEmpty(dao) }
}
