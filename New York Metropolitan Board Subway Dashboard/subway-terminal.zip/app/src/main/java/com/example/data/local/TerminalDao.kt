package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TerminalDao {
  // Operator & Terminal
  @Query("SELECT * FROM operators LIMIT 1")
  fun observeOperator(): Flow<OperatorEntity?>

  @Query("SELECT * FROM operators LIMIT 1")
  suspend fun getOperator(): OperatorEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertOperator(operator: OperatorEntity)

  @Query("SELECT * FROM terminals LIMIT 1")
  fun observeTerminal(): Flow<TerminalEntity?>

  @Query("SELECT * FROM terminals LIMIT 1")
  suspend fun getTerminal(): TerminalEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertTerminal(terminal: TerminalEntity)

  // Catalog & Pricing
  @Query("SELECT * FROM product_versions WHERE isActive = 1 ORDER BY category, versionNumber DESC")
  fun observeActiveProducts(): Flow<List<ProductVersionEntity>>

  @Query("SELECT * FROM product_versions ORDER BY productCode, versionNumber DESC")
  fun observeAllProductVersions(): Flow<List<ProductVersionEntity>>

  @Query("SELECT * FROM product_versions WHERE productVersionId = :id")
  suspend fun getProductVersionById(id: String): ProductVersionEntity?

  @Query("SELECT * FROM product_versions WHERE productCode = :code ORDER BY versionNumber DESC LIMIT 1")
  suspend fun getLatestProductVersion(code: String): ProductVersionEntity?

  @Query("UPDATE product_versions SET isActive = 0 WHERE productCode = :code")
  suspend fun deactivateVersionsForCode(code: String)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertProductVersion(product: ProductVersionEntity)

  @Query("SELECT * FROM pricing_rules WHERE productVersionId = :productVersionId ORDER BY storedValueCents ASC")
  suspend fun getPricingRulesForProduct(productVersionId: String): List<PricingRuleEntity>

  @Query("SELECT * FROM pricing_rules")
  fun observeAllPricingRules(): Flow<List<PricingRuleEntity>>

  @Query("SELECT * FROM pricing_rules WHERE pricingRuleId = :id")
  suspend fun getPricingRuleById(id: String): PricingRuleEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPricingRules(rules: List<PricingRuleEntity>)

  @Transaction
  suspend fun publishNewProductVersion(
    newProduct: ProductVersionEntity,
    rules: List<PricingRuleEntity>,
  ) {
    deactivateVersionsForCode(newProduct.productCode)
    insertProductVersion(newProduct)
    insertPricingRules(rules)
  }

  // Sessions
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSession(session: KioskSessionEntity)

  @Query("SELECT * FROM sessions WHERE sessionId = :sessionId")
  suspend fun getSession(sessionId: String): KioskSessionEntity?

  // Orders
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertOrder(order: OrderEntity)

  @Query("SELECT * FROM orders WHERE orderId = :orderId")
  suspend fun getOrder(orderId: String): OrderEntity?

  @Query("SELECT * FROM orders WHERE orderId = :orderId")
  fun observeOrder(orderId: String): Flow<OrderEntity?>

  @Query("SELECT * FROM orders ORDER BY createdAtMs DESC LIMIT 50")
  fun observeRecentOrders(): Flow<List<OrderEntity>>

  // Payments
  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertPaymentAttempt(attempt: PaymentAttemptEntity)

  @Update
  suspend fun updatePaymentAttempt(attempt: PaymentAttemptEntity)

  @Query("SELECT * FROM payment_attempts WHERE idempotencyKey = :key LIMIT 1")
  suspend fun getPaymentByIdempotencyKey(key: String): PaymentAttemptEntity?

  @Query("SELECT * FROM payment_attempts WHERE orderId = :orderId ORDER BY createdAtMs DESC")
  suspend fun getPaymentsForOrder(orderId: String): List<PaymentAttemptEntity>

  @Query("SELECT * FROM payment_attempts WHERE paymentState = 'OUTCOME_UNKNOWN'")
  suspend fun getUnknownOutcomePayments(): List<PaymentAttemptEntity>

  @Query("SELECT * FROM payment_attempts ORDER BY createdAtMs DESC LIMIT 50")
  fun observePaymentAttempts(): Flow<List<PaymentAttemptEntity>>

  // Fulfilment
  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertFulfilment(op: FulfilmentOperationEntity)

  @Update
  suspend fun updateFulfilment(op: FulfilmentOperationEntity)

  @Query("SELECT * FROM fulfilment_operations WHERE idempotencyKey = :key LIMIT 1")
  suspend fun getFulfilmentByIdempotencyKey(key: String): FulfilmentOperationEntity?

  @Query("SELECT * FROM fulfilment_operations WHERE orderId = :orderId ORDER BY createdAtMs DESC LIMIT 1")
  suspend fun getLatestFulfilmentForOrder(orderId: String): FulfilmentOperationEntity?

  @Query("SELECT * FROM fulfilment_operations ORDER BY createdAtMs DESC LIMIT 50")
  fun observeFulfilments(): Flow<List<FulfilmentOperationEntity>>

  // Transit Accounts (Authoritative Operator Store)
  @Query("SELECT * FROM transit_accounts WHERE cardRef = :cardRef LIMIT 1")
  suspend fun getTransitAccount(cardRef: String): TransitAccountEntity?

  @Query("SELECT * FROM transit_accounts ORDER BY cardRef ASC")
  fun observeAllTransitAccounts(): Flow<List<TransitAccountEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertTransitAccount(account: TransitAccountEntity)

  // Device Events
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDeviceEvent(event: DeviceEventEntity)

  @Query("SELECT * FROM device_events ORDER BY createdAtMs DESC LIMIT 50")
  fun observeDeviceEvents(): Flow<List<DeviceEventEntity>>

  // Receipts
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertReceipt(receipt: ReceiptEntity)

  @Query("SELECT * FROM receipts WHERE orderId = :orderId LIMIT 1")
  suspend fun getReceiptForOrder(orderId: String): ReceiptEntity?

  // Refunds
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRefund(refund: RefundEntity)

  @Query("SELECT * FROM refunds WHERE refundId = :refundId")
  suspend fun getRefund(refundId: String): RefundEntity?

  @Query("SELECT * FROM refunds ORDER BY createdAtMs DESC")
  fun observeRefunds(): Flow<List<RefundEntity>>

  // Reconciliation Cases
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertReconciliationCase(case: ReconciliationCaseEntity)

  @Query("SELECT * FROM reconciliation_cases WHERE caseId = :caseId")
  suspend fun getReconciliationCase(caseId: String): ReconciliationCaseEntity?

  @Query("SELECT * FROM reconciliation_cases WHERE orderId = :orderId LIMIT 1")
  suspend fun getReconciliationForOrder(orderId: String): ReconciliationCaseEntity?

  @Query("SELECT * FROM reconciliation_cases WHERE status IN ('OPEN', 'ESCALATED') ORDER BY createdAtMs DESC")
  suspend fun getOpenReconciliationCases(): List<ReconciliationCaseEntity>

  @Query("SELECT * FROM reconciliation_cases ORDER BY createdAtMs DESC")
  fun observeReconciliationCases(): Flow<List<ReconciliationCaseEntity>>

  // Audit Events
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAuditEvent(event: AuditEventEntity)

  @Query("SELECT * FROM audit_events ORDER BY createdAtMs DESC LIMIT 100")
  fun observeAuditEvents(): Flow<List<AuditEventEntity>>
}
