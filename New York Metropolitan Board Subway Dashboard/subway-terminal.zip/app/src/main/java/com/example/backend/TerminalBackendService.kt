package com.example.backend

import com.example.core.i18n.AppLanguage
import com.example.core.security.LogRedactor
import com.example.data.local.AuditEventEntity
import com.example.data.local.FulfilmentOperationEntity
import com.example.data.local.KioskSessionEntity
import com.example.data.local.OrderEntity
import com.example.data.local.PaymentAttemptEntity
import com.example.data.local.PricingRuleEntity
import com.example.data.local.ProductVersionEntity
import com.example.data.local.ReceiptEntity
import com.example.data.local.ReconciliationCaseEntity
import com.example.data.local.RefundEntity
import com.example.data.local.TerminalDao
import com.example.domain.model.EligibilityRestriction
import com.example.domain.model.FulfilmentState
import com.example.domain.model.OrderState
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PaymentState
import com.example.domain.model.PaymentSubState
import com.example.domain.model.PricingQuote
import com.example.domain.model.ProductCategory
import com.example.domain.model.ReconciliationStatus
import com.example.domain.model.RefundStatus
import com.example.domain.model.StaffRole
import com.example.domain.model.StaffUser
import com.example.hardware.AuthoritativeCardSnapshot
import com.example.hardware.CardDispenserAdapter
import com.example.hardware.CardIdentificationResult
import com.example.hardware.PaymentTerminalAdapter
import com.example.hardware.ReceiptPrinterAdapter
import com.example.hardware.TransitCardReaderAdapter
import com.example.hardware.TravelProductFulfilmentService
import java.util.UUID
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed class BackendResult<out T> {
  data class Success<T>(val data: T) : BackendResult<T>()
  data class Failure(val code: String, val message: String) : BackendResult<Nothing>()
}

data class OrderExecutionOutcome(
  val order: OrderEntity,
  val paymentAttempt: PaymentAttemptEntity?,
  val fulfilment: FulfilmentOperationEntity?,
  val receipt: ReceiptEntity?,
  val reconciliationCase: ReconciliationCaseEntity?,
  val updatedCardSnapshot: AuthoritativeCardSnapshot?,
)

class TerminalBackendService(
  private val dao: TerminalDao,
  private val paymentAdapter: PaymentTerminalAdapter,
  private val transitReader: TransitCardReaderAdapter,
  private val fulfilmentService: TravelProductFulfilmentService,
  private val dispenserAdapter: CardDispenserAdapter,
  private val printerAdapter: ReceiptPrinterAdapter,
) {
  private val orderMutex = Mutex()

  private val staffDirectory = mapOf(
    "OP-101" to Pair("1234", StaffUser("OP-101", "Station Agent Rivera", StaffRole.OPERATOR)),
    "SUP-201" to Pair("5678", StaffUser("SUP-201", "Supervisor Chen", StaffRole.SUPERVISOR)),
  )

  suspend fun startAnonymousSession(language: AppLanguage): KioskSessionEntity {
    val now = System.currentTimeMillis()
    val session = KioskSessionEntity(
      sessionId = "SES-${UUID.randomUUID().toString().take(8).uppercase()}",
      terminalId = "KIOSK-NY-042",
      languageCode = language.code,
      startedAtMs = now,
      lastActivityMs = now,
      endedAtMs = null,
      status = "ACTIVE",
    )
    dao.upsertSession(session)
    audit("GUEST", "KIOSK_GUEST", "SESSION_STARTED", session.sessionId, "Anonymous session started (${language.code})")
    return session
  }

  suspend fun closeSession(sessionId: String, status: String = "CLEARED") {
    val existing = dao.getSession(sessionId) ?: return
    val now = System.currentTimeMillis()
    dao.upsertSession(existing.copy(endedAtMs = now, lastActivityMs = now, status = status))
    audit("GUEST", "KIOSK_GUEST", "SESSION_$status", sessionId, "Public session cleared; unresolved financial records retained.")
  }

  suspend fun calculateServerQuote(
    productVersionId: String,
    pricingRuleId: String,
    targetCardRef: String? = null,
  ): BackendResult<PricingQuote> {
    val product = dao.getProductVersionById(productVersionId)
      ?: return BackendResult.Failure("PRODUCT_NOT_FOUND", "Product version not found.")
    val rule = dao.getPricingRuleById(pricingRuleId)
      ?: return BackendResult.Failure("RULE_NOT_FOUND", "Pricing rule not found.")

    if (rule.productVersionId != product.productVersionId) {
      return BackendResult.Failure("RULE_MISMATCH", "Pricing rule does not belong to product version.")
    }

    val now = System.currentTimeMillis()
    if (now < product.salesStartEpochMs || now > product.salesEndEpochMs) {
      return BackendResult.Failure("OUTSIDE_SALES_WINDOW", "Product is outside configured sales period.")
    }

    if (product.eligibilityRestriction == EligibilityRestriction.REDUCED_FARE_VERIFIED.name && targetCardRef != null) {
      val card = fulfilmentService.fetchAuthoritativeCard(targetCardRef)
      if (card == null || card.eligibilityTier != "REDUCED_FARE_VERIFIED") {
        return BackendResult.Failure("ELIGIBILITY_FAILED", "Target card/account does not meet reduced-fare eligibility.")
      }
    }

    // All totals strictly computed in integer cents
    val totalCents = rule.fixedSalePriceCents ?: (rule.storedValueCents + rule.cardIssueFeeCents)
    return BackendResult.Success(
      PricingQuote(
        productVersionId = product.productVersionId,
        productCode = product.productCode,
        versionNumber = product.versionNumber,
        storedValueCents = rule.storedValueCents,
        fareEntitlementCents = rule.fareEntitlementCents,
        cardIssueFeeCents = rule.cardIssueFeeCents,
        totalCents = totalCents,
        currency = rule.currency,
        entitlementLabel = rule.entitlementTextEn,
        isDemoPrice = true,
      )
    )
  }

  suspend fun createPricedOrder(
    sessionId: String,
    productVersionId: String,
    pricingRuleId: String,
    targetCardRef: String? = null,
  ): BackendResult<OrderEntity> {
    val product = dao.getProductVersionById(productVersionId)
      ?: return BackendResult.Failure("PRODUCT_NOT_FOUND", "Product version not found.")

    var isAccountBased = product.isAccountBasedCapable
    if (product.category == ProductCategory.RELOAD.name) {
      if (targetCardRef.isNullOrBlank()) {
        return BackendResult.Failure("CARD_REQUIRED", "Identify a card or account before reloading.")
      }
      val card = fulfilmentService.fetchAuthoritativeCard(targetCardRef)
        ?: return BackendResult.Failure("CARD_NOT_FOUND", "Target transit reference not found.")
      if (card.status == "BLOCKED") {
        return BackendResult.Failure("CARD_BLOCKED", "Target card is blocked in operator system.")
      }
      isAccountBased = card.isAccountBased
    } else {
      // Check dispenser availability before proceeding with new card order
      if (!dispenserAdapter.checkAvailability()) {
        return BackendResult.Failure("DISPENSER_UNAVAILABLE", "Card dispenser unavailable or out of stock.")
      }
    }

    val quoteResult = calculateServerQuote(productVersionId, pricingRuleId, targetCardRef)
    if (quoteResult is BackendResult.Failure) return quoteResult
    val quote = (quoteResult as BackendResult.Success).data

    val now = System.currentTimeMillis()
    val orderId = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}"
    val claimRef = "CLM-${UUID.randomUUID().toString().take(6).uppercase()}"
    val order = OrderEntity(
      orderId = orderId,
      sessionId = sessionId,
      terminalId = "KIOSK-NY-042",
      operatorId = product.operatorId,
      productVersionId = product.productVersionId,
      productCode = product.productCode,
      productVersionNumber = product.versionNumber,
      pricingRuleId = pricingRuleId,
      storedValueCents = quote.storedValueCents,
      fareEntitlementCents = quote.fareEntitlementCents,
      cardIssueFeeCents = quote.cardIssueFeeCents,
      totalCents = quote.totalCents,
      currency = quote.currency,
      targetCardRef = targetCardRef,
      isAccountBased = isAccountBased,
      orderState = OrderState.AWAITING_PAYMENT.name,
      claimReference = claimRef,
      createdAtMs = now,
      updatedAtMs = now,
    )
    dao.upsertOrder(order)
    audit("GUEST", "KIOSK_GUEST", "ORDER_CREATED", orderId, "Order priced at ${quote.totalCents} cents (v${product.versionNumber})")
    return BackendResult.Success(order)
  }

  suspend fun processPayment(
    orderId: String,
    method: PaymentMethod,
    idempotencyKey: String,
  ): BackendResult<PaymentAttemptEntity> = orderMutex.withLock {
    val existingAttempt = dao.getPaymentByIdempotencyKey(idempotencyKey)
    if (existingAttempt != null) {
      // Idempotent replay protection: return prior recorded attempt without re-charging
      return@withLock BackendResult.Success(existingAttempt)
    }

    val order = dao.getOrder(orderId)
      ?: return@withLock BackendResult.Failure("ORDER_NOT_FOUND", "Order does not exist.")

    // Prevent double payment if order already has a confirmed or unknown attempt
    val priorAttempts = dao.getPaymentsForOrder(orderId)
    priorAttempts.firstOrNull {
      it.paymentState == PaymentState.CONFIRMED.name || it.paymentState == PaymentState.OUTCOME_UNKNOWN.name
    }?.let { active ->
      return@withLock BackendResult.Success(active)
    }

    val now = System.currentTimeMillis()
    val attemptId = "PAY-${UUID.randomUUID().toString().take(8).uppercase()}"
    val initialAttempt = PaymentAttemptEntity(
      paymentAttemptId = attemptId,
      orderId = orderId,
      idempotencyKey = idempotencyKey,
      paymentMethod = method.name,
      amountCents = order.totalCents,
      currency = order.currency,
      paymentState = PaymentState.PROCESSING.name,
      paymentSubState = PaymentSubState.NONE.name,
      maskedInstrumentRef = null,
      providerEventId = null,
      errorCode = null,
      createdAtMs = now,
      updatedAtMs = now,
    )
    dao.insertPaymentAttempt(initialAttempt)

    val terminalResult = paymentAdapter.authorizeAndCapture(
      orderId = orderId,
      amountCents = order.totalCents,
      currency = order.currency,
      method = method,
      idempotencyKey = idempotencyKey,
    )

    val updatedTime = System.currentTimeMillis()
    val finalizedAttempt = initialAttempt.copy(
      paymentState = terminalResult.state.name,
      paymentSubState = terminalResult.subState.name,
      maskedInstrumentRef = terminalResult.maskedInstrumentRef,
      providerEventId = terminalResult.providerEventId,
      errorCode = terminalResult.error?.code,
      updatedAtMs = updatedTime,
    )
    dao.updatePaymentAttempt(finalizedAttempt)

    val nextOrderState = when (terminalResult.state) {
      PaymentState.CONFIRMED -> OrderState.PAYMENT_CONFIRMED.name
      PaymentState.OUTCOME_UNKNOWN -> OrderState.NEEDS_RECONCILIATION.name
      PaymentState.DECLINED, PaymentState.CANCELLED -> OrderState.AWAITING_PAYMENT.name
      else -> order.orderState
    }
    dao.upsertOrder(order.copy(orderState = nextOrderState, updatedAtMs = updatedTime))

    if (terminalResult.state == PaymentState.OUTCOME_UNKNOWN) {
      openReconciliationCase(
        order = order,
        caseType = "UNKNOWN_PAYMENT",
        description = "Payment terminal timed out or disconnected before confirmation (${terminalResult.error?.code}).",
      )
    }

    audit(
      "PAYMENT_TERMINAL",
      "ADAPTER",
      "PAYMENT_${terminalResult.state.name}",
      orderId,
      "Amount=${order.totalCents}c, SubState=${terminalResult.subState}, Ref=${terminalResult.maskedInstrumentRef ?: "NONE"}",
    )

    return@withLock BackendResult.Success(finalizedAttempt)
  }

  suspend fun fulfillPaidOrder(
    orderId: String,
    fulfilmentIdempotencyKey: String,
  ): BackendResult<OrderExecutionOutcome> = orderMutex.withLock {
    val order = dao.getOrder(orderId)
      ?: return@withLock BackendResult.Failure("ORDER_NOT_FOUND", "Order not found.")

    val confirmedPayment = dao.getPaymentsForOrder(orderId).firstOrNull {
      it.paymentState == PaymentState.CONFIRMED.name
    } ?: return@withLock BackendResult.Failure(
      "PAYMENT_NOT_CONFIRMED",
      "Fulfilment blocked: payment is not confirmed.",
    )

    // Idempotent check: never fulfill or dispense twice for the same key or already-fulfilled order
    dao.getFulfilmentByIdempotencyKey(fulfilmentIdempotencyKey)?.let { existing ->
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(
          order = order,
          paymentAttempt = confirmedPayment,
          fulfilment = existing,
          receipt = dao.getReceiptForOrder(orderId),
          reconciliationCase = dao.getReconciliationForOrder(orderId),
          updatedCardSnapshot = existing.issuedOrUpdatedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) },
        )
      )
    }

    dao.getLatestFulfilmentForOrder(orderId)?.let { prior ->
      if (prior.fulfilmentState in setOf(
          FulfilmentState.PROVISIONED.name,
          FulfilmentState.DISPENSED_AWAITING_COLLECTION.name,
          FulfilmentState.COLLECTED.name,
          FulfilmentState.RECOVERED.name,
        )
      ) {
        return@withLock BackendResult.Success(
          OrderExecutionOutcome(
            order = order,
            paymentAttempt = confirmedPayment,
            fulfilment = prior,
            receipt = dao.getReceiptForOrder(orderId),
            reconciliationCase = dao.getReconciliationForOrder(orderId),
            updatedCardSnapshot = prior.issuedOrUpdatedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) },
          )
        )
      }
    }

    val product = dao.getProductVersionById(order.productVersionId)
      ?: return@withLock BackendResult.Failure("PRODUCT_MISSING", "Product version missing.")
    val rule = dao.getPricingRuleById(order.pricingRuleId)
    val isReload = product.category == ProductCategory.RELOAD.name

    val now = System.currentTimeMillis()
    val opType = when {
      isReload && order.isAccountBased -> "RELOAD_ACCOUNT"
      isReload -> "RELOAD_CARD"
      else -> "ISSUE_NEW_CARD"
    }
    val fulfilmentId = "FUL-${UUID.randomUUID().toString().take(8).uppercase()}"
    var op = FulfilmentOperationEntity(
      fulfilmentId = fulfilmentId,
      orderId = orderId,
      idempotencyKey = fulfilmentIdempotencyKey,
      operationType = opType,
      fulfilmentState = FulfilmentState.PROVISIONING.name,
      issuedOrUpdatedCardRef = order.targetCardRef,
      isAccountBased = order.isAccountBased,
      externalFulfilmentRef = null,
      errorCode = null,
      retryCount = 0,
      createdAtMs = now,
      updatedAtMs = now,
    )
    dao.insertFulfilment(op)
    dao.upsertOrder(order.copy(orderState = OrderState.FULFILLING.name, updatedAtMs = now))

    val execResult = if (isReload) {
      fulfilmentService.applyReload(
        orderId = orderId,
        idempotencyKey = fulfilmentIdempotencyKey,
        cardRef = order.targetCardRef!!,
        addStoredValueCents = order.storedValueCents,
        newEntitlementEn = null,
        newEntitlementEs = null,
      )
    } else {
      fulfilmentService.provisionNewCard(
        orderId = orderId,
        idempotencyKey = fulfilmentIdempotencyKey,
        storedValueCents = order.storedValueCents,
        entitlementEn = rule?.entitlementTextEn ?: product.titleEn,
        entitlementEs = rule?.entitlementTextEs ?: product.titleEs,
        isAccountBased = order.isAccountBased,
      )
    }

    var reconCase: ReconciliationCaseEntity? = null
    var receipt: ReceiptEntity? = null

    if (execResult.responseLostAfterCommit) {
      op = op.copy(
        fulfilmentState = FulfilmentState.PROVISIONED_RESPONSE_LOST.name,
        issuedOrUpdatedCardRef = execResult.issuedCardRef,
        externalFulfilmentRef = execResult.externalFulfilmentRef,
        errorCode = "RESPONSE_LOST",
        updatedAtMs = System.currentTimeMillis(),
      )
      dao.updateFulfilment(op)
      val updatedOrder = order.copy(orderState = OrderState.NEEDS_RECONCILIATION.name, updatedAtMs = System.currentTimeMillis())
      dao.upsertOrder(updatedOrder)
      reconCase = openReconciliationCase(
        order = updatedOrder,
        caseType = "LOST_RESPONSE",
        description = "Provisioning succeeded on host but response ACK was lost. Verify idempotently without double-fulfilling.",
      )
      receipt = generateAndAttemptPrintReceipt(updatedOrder, op, confirmedPayment)
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(
          order = updatedOrder,
          paymentAttempt = confirmedPayment,
          fulfilment = op,
          receipt = receipt,
          reconciliationCase = reconCase,
          updatedCardSnapshot = op.issuedOrUpdatedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) },
        )
      )
    }

    if (!execResult.success) {
      op = op.copy(
        fulfilmentState = FulfilmentState.FAILED.name,
        errorCode = execResult.error?.code ?: "PROVISION_FAILED",
        updatedAtMs = System.currentTimeMillis(),
      )
      dao.updateFulfilment(op)
      val updatedOrder = order.copy(orderState = OrderState.FULFILLMENT_FAILED.name, updatedAtMs = System.currentTimeMillis())
      dao.upsertOrder(updatedOrder)
      reconCase = openReconciliationCase(
        order = updatedOrder,
        caseType = "PROVISION_FAILURE",
        description = "Payment confirmed (${confirmedPayment.paymentAttemptId}) but operator provisioning failed: ${execResult.error?.message}",
      )
      receipt = generateAndAttemptPrintReceipt(updatedOrder, op, confirmedPayment)
      audit("SYSTEM", "FULFILMENT", "PROVISION_FAILED", orderId, "Claim=${order.claimReference} preserved for staff recovery.")
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(updatedOrder, confirmedPayment, op, receipt, reconCase, null)
      )
    }

    // Provisioning succeeded!
    op = op.copy(
      fulfilmentState = FulfilmentState.PROVISIONED.name,
      issuedOrUpdatedCardRef = execResult.issuedCardRef,
      externalFulfilmentRef = execResult.externalFulfilmentRef,
      updatedAtMs = System.currentTimeMillis(),
    )
    dao.updateFulfilment(op)

    if (isReload) {
      op = op.copy(fulfilmentState = FulfilmentState.COLLECTED.name, updatedAtMs = System.currentTimeMillis())
      dao.updateFulfilment(op)
      val updatedOrder = order.copy(orderState = OrderState.COMPLETED.name, updatedAtMs = System.currentTimeMillis())
      dao.upsertOrder(updatedOrder)
      receipt = generateAndAttemptPrintReceipt(updatedOrder, op, confirmedPayment)
      val snap = execResult.issuedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) }
      audit("SYSTEM", "FULFILMENT", "RELOAD_VERIFIED", orderId, "Reloaded ${execResult.issuedCardRef} (+${order.storedValueCents}c)")
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(updatedOrder, confirmedPayment, op, receipt, null, snap)
      )
    }

    // Physical card dispense
    val cardRef = execResult.issuedCardRef ?: "CRD-DEMO-0000"
    val dispenseRes = dispenserAdapter.dispensePhysicalCard(cardRef)
    if (dispenseRes.jammed || !dispenseRes.dispensed) {
      op = op.copy(
        fulfilmentState = FulfilmentState.DISPENSER_JAMMED.name,
        errorCode = dispenseRes.error?.code ?: "DISPENSER_JAM",
        updatedAtMs = System.currentTimeMillis(),
      )
      dao.updateFulfilment(op)
      val updatedOrder = order.copy(orderState = OrderState.FULFILLMENT_FAILED.name, updatedAtMs = System.currentTimeMillis())
      dao.upsertOrder(updatedOrder)
      reconCase = openReconciliationCase(
        order = updatedOrder,
        caseType = "DISPENSER_JAM",
        description = "Product provisioned ($cardRef) but card dispenser jammed. Customer claim ${order.claimReference} preserved.",
      )
      receipt = generateAndAttemptPrintReceipt(updatedOrder, op, confirmedPayment)
      audit("SYSTEM", "DISPENSER", "DISPENSER_JAM", orderId, "Claim=${order.claimReference} preserved; card=$cardRef")
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(
          updatedOrder,
          confirmedPayment,
          op,
          receipt,
          reconCase,
          fulfilmentService.fetchAuthoritativeCard(cardRef),
        )
      )
    }

    if (dispenseRes.error?.code == "CARD_NOT_COLLECTED") {
      op = op.copy(
        fulfilmentState = FulfilmentState.CARD_NOT_COLLECTED.name,
        errorCode = "CARD_NOT_COLLECTED",
        updatedAtMs = System.currentTimeMillis(),
      )
      dao.updateFulfilment(op)
      val updatedOrder = order.copy(orderState = OrderState.NEEDS_RECONCILIATION.name, updatedAtMs = System.currentTimeMillis())
      dao.upsertOrder(updatedOrder)
      reconCase = openReconciliationCase(
        order = updatedOrder,
        caseType = "CARD_NOT_COLLECTED",
        description = "Card $cardRef dispensed but not retrieved from tray.",
      )
      receipt = generateAndAttemptPrintReceipt(updatedOrder, op, confirmedPayment)
      return@withLock BackendResult.Success(
        OrderExecutionOutcome(updatedOrder, confirmedPayment, op, receipt, reconCase, fulfilmentService.fetchAuthoritativeCard(cardRef))
      )
    }

    op = op.copy(
      fulfilmentState = FulfilmentState.DISPENSED_AWAITING_COLLECTION.name,
      updatedAtMs = System.currentTimeMillis(),
    )
    dao.updateFulfilment(op)
    receipt = generateAndAttemptPrintReceipt(order, op, confirmedPayment)
    return@withLock BackendResult.Success(
      OrderExecutionOutcome(
        order = order,
        paymentAttempt = confirmedPayment,
        fulfilment = op,
        receipt = receipt,
        reconciliationCase = null,
        updatedCardSnapshot = fulfilmentService.fetchAuthoritativeCard(cardRef),
      )
    )
  }

  suspend fun confirmCardCollection(orderId: String): BackendResult<OrderExecutionOutcome> = orderMutex.withLock {
    val order = dao.getOrder(orderId) ?: return@withLock BackendResult.Failure("ORDER_NOT_FOUND", "Order not found.")
    val op = dao.getLatestFulfilmentForOrder(orderId)
      ?: return@withLock BackendResult.Failure("FULFILMENT_MISSING", "Fulfilment record missing.")

    dispenserAdapter.confirmCustomerCollection()
    val updatedOp = op.copy(fulfilmentState = FulfilmentState.COLLECTED.name, updatedAtMs = System.currentTimeMillis())
    dao.updateFulfilment(updatedOp)
    val updatedOrder = order.copy(orderState = OrderState.COMPLETED.name, updatedAtMs = System.currentTimeMillis())
    dao.upsertOrder(updatedOrder)
    audit("GUEST", "KIOSK_GUEST", "CARD_COLLECTED", orderId, "Card ${op.issuedOrUpdatedCardRef} collected.")
    return@withLock BackendResult.Success(
      OrderExecutionOutcome(
        order = updatedOrder,
        paymentAttempt = dao.getPaymentsForOrder(orderId).firstOrNull(),
        fulfilment = updatedOp,
        receipt = dao.getReceiptForOrder(orderId),
        reconciliationCase = null,
        updatedCardSnapshot = op.issuedOrUpdatedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) },
      )
    )
  }

  suspend fun identifyTransitCard(simulatedCardRef: String? = null): Pair<CardIdentificationResult, AuthoritativeCardSnapshot?> {
    val idResult = transitReader.identifyCard(simulatedCardRef)
    val snapshot = if (idResult.success && idResult.opaqueCardRef != null) {
      fulfilmentService.fetchAuthoritativeCard(idResult.opaqueCardRef)
    } else null
    return idResult to snapshot
  }

  // --- Staff Auth & RBAC ---
  suspend fun authenticateStaff(staffId: String, pin: String): BackendResult<StaffUser> {
    val entry = staffDirectory[staffId.trim().uppercase()]
      ?: return BackendResult.Failure("INVALID_CREDENTIALS", "Unknown staff ID or PIN.")
    if (entry.first != pin.trim()) {
      audit(staffId, "UNKNOWN", "STAFF_LOGIN_FAILED", staffId, LogRedactor.redact("Failed login attempt pin=$pin"))
      return BackendResult.Failure("INVALID_CREDENTIALS", "Unknown staff ID or PIN.")
    }
    audit(entry.second.staffId, entry.second.role.name, "STAFF_LOGIN_SUCCESS", entry.second.staffId, "Authenticated staff session.")
    return BackendResult.Success(entry.second)
  }

  suspend fun staffPublishNewProductPriceVersion(
    staff: StaffUser,
    productCode: String,
    newStoredValueOptionsCents: List<Int>,
    newIssueFeeCents: Int,
  ): BackendResult<ProductVersionEntity> {
    if (staff.role != StaffRole.SUPERVISOR) {
      audit(staff.staffId, staff.role.name, "PERMISSION_DENIED", productCode, "Attempted catalog publish without SUPERVISOR role.")
      return BackendResult.Failure("FORBIDDEN", "Supervisor approval required for pricing changes.")
    }
    val latest = dao.getLatestProductVersion(productCode)
      ?: return BackendResult.Failure("PRODUCT_NOT_FOUND", "Product code not found.")
    val nextVersion = latest.versionNumber + 1
    val newVersionId = "${productCode}_V$nextVersion"
    val now = System.currentTimeMillis()
    val newProduct = latest.copy(
      productVersionId = newVersionId,
      versionNumber = nextVersion,
      isActive = true,
      createdAtMs = now,
    )
    val rules = newStoredValueOptionsCents.mapIndexed { idx, cents ->
      PricingRuleEntity(
        pricingRuleId = "RULE-${newVersionId}-$cents",
        productVersionId = newVersionId,
        optionLabel = PricingQuote.formatUsd(cents),
        storedValueCents = cents,
        fareEntitlementCents = cents,
        cardIssueFeeCents = newIssueFeeCents,
        fixedSalePriceCents = if (latest.category == ProductCategory.PASS.name) cents + newIssueFeeCents else null,
        entitlementTextEn = "${PricingQuote.formatUsd(cents)} demo value",
        entitlementTextEs = "${PricingQuote.formatUsd(cents)} saldo demo",
        isDefault = idx == 1 || newStoredValueOptionsCents.size == 1,
      )
    }
    dao.publishNewProductVersion(newProduct, rules)
    audit(staff.staffId, staff.role.name, "PRODUCT_VERSION_PUBLISHED", newVersionId, "Published v$nextVersion with fee=${newIssueFeeCents}c")
    return BackendResult.Success(newProduct)
  }

  suspend fun staffRequestRefund(
    staff: StaffUser,
    orderId: String,
    reason: String,
  ): BackendResult<RefundEntity> {
    val payment = dao.getPaymentsForOrder(orderId).firstOrNull { it.paymentState == PaymentState.CONFIRMED.name }
      ?: return BackendResult.Failure("NO_CONFIRMED_PAYMENT", "No confirmed payment found to refund.")
    val now = System.currentTimeMillis()
    val refund = RefundEntity(
      refundId = "RFD-${UUID.randomUUID().toString().take(8).uppercase()}",
      orderId = orderId,
      paymentAttemptId = payment.paymentAttemptId,
      amountCents = payment.amountCents,
      reason = reason,
      status = RefundStatus.REFUND_REQUESTED.name,
      requestedBy = staff.staffId,
      approvedBy = null,
      createdAtMs = now,
      updatedAtMs = now,
    )
    dao.upsertRefund(refund)
    dao.updatePaymentAttempt(payment.copy(paymentSubState = PaymentSubState.REFUND_REQUESTED.name, updatedAtMs = now))
    audit(staff.staffId, staff.role.name, "REFUND_REQUESTED", refund.refundId, "Requested refund for $orderId (${payment.amountCents}c)")
    return BackendResult.Success(refund)
  }

  suspend fun staffApproveAndSettleRefund(
    staff: StaffUser,
    refundId: String,
  ): BackendResult<RefundEntity> {
    if (staff.role != StaffRole.SUPERVISOR) {
      audit(staff.staffId, staff.role.name, "PERMISSION_DENIED", refundId, "Refund settlement requires SUPERVISOR.")
      return BackendResult.Failure("FORBIDDEN", "Supervisor role required to approve and settle refunds.")
    }
    val refund = dao.getRefund(refundId) ?: return BackendResult.Failure("NOT_FOUND", "Refund not found.")
    val subState = paymentAdapter.requestRefundOrReversal(refund.paymentAttemptId, refund.amountCents)
    val now = System.currentTimeMillis()
    val settled = refund.copy(status = RefundStatus.SETTLED.name, approvedBy = staff.staffId, updatedAtMs = now)
    dao.upsertRefund(settled)
    dao.getPaymentsForOrder(refund.orderId).firstOrNull { it.paymentAttemptId == refund.paymentAttemptId }?.let { pay ->
      dao.updatePaymentAttempt(pay.copy(paymentSubState = subState.name, updatedAtMs = now))
    }
    audit(staff.staffId, staff.role.name, "REFUND_SETTLED", refundId, "Settled ${refund.amountCents}c for order ${refund.orderId}")
    return BackendResult.Success(settled)
  }

  suspend fun staffResolveExceptionalFulfilment(
    staff: StaffUser,
    caseId: String,
    resolutionNote: String,
  ): BackendResult<ReconciliationCaseEntity> {
    if (staff.role != StaffRole.SUPERVISOR) {
      audit(staff.staffId, staff.role.name, "PERMISSION_DENIED", caseId, "Exceptional recovery requires SUPERVISOR.")
      return BackendResult.Failure("FORBIDDEN", "Supervisor approval required for exceptional fulfilment recovery.")
    }
    val recon = dao.getReconciliationCase(caseId) ?: return BackendResult.Failure("NOT_FOUND", "Case not found.")
    val order = dao.getOrder(recon.orderId)
    val op = order?.let { dao.getLatestFulfilmentForOrder(it.orderId) }
    if (order != null && op != null && op.fulfilmentState == FulfilmentState.DISPENSER_JAMMED.name) {
      dispenserAdapter.clearJamAndRestock(45)
      val cardRef = op.issuedOrUpdatedCardRef ?: "CRD-RECOVERED"
      val dispenseRes = dispenserAdapter.dispensePhysicalCard(cardRef)
      if (dispenseRes.dispensed) {
        dao.updateFulfilment(op.copy(fulfilmentState = FulfilmentState.RECOVERED.name, updatedAtMs = System.currentTimeMillis()))
        dao.upsertOrder(order.copy(orderState = OrderState.COMPLETED.name, updatedAtMs = System.currentTimeMillis()))
      }
    } else if (order != null && op != null && op.fulfilmentState == FulfilmentState.FAILED.name) {
      // Retry fulfilment once with the original idempotency key (prevents double-reload if host already committed)
      fulfillPaidOrder(order.orderId, op.idempotencyKey)
    }

    val resolved = recon.copy(
      status = ReconciliationStatus.STAFF_RESOLVED.name,
      resolutionNote = resolutionNote,
      resolvedBy = staff.staffId,
      updatedAtMs = System.currentTimeMillis(),
    )
    dao.upsertReconciliationCase(resolved)
    audit(staff.staffId, staff.role.name, "CASE_RESOLVED", caseId, resolutionNote)
    return BackendResult.Success(resolved)
  }

  suspend fun staffToggleLanguageSupport(staff: StaffUser, enabledLanguagesCsv: String): BackendResult<Unit> {
    if (staff.role != StaffRole.SUPERVISOR) {
      return BackendResult.Failure("FORBIDDEN", "Supervisor role required.")
    }
    val op = dao.getOperator() ?: return BackendResult.Failure("NO_OPERATOR", "Operator missing.")
    dao.upsertOperator(op.copy(enabledLanguagesCsv = enabledLanguagesCsv))
    audit(staff.staffId, staff.role.name, "LANGUAGE_CONFIG_UPDATED", op.operatorId, "Enabled languages: $enabledLanguagesCsv")
    return BackendResult.Success(Unit)
  }

  private suspend fun openReconciliationCase(
    order: OrderEntity,
    caseType: String,
    description: String,
  ): ReconciliationCaseEntity {
    val existing = dao.getReconciliationForOrder(order.orderId)
    if (existing != null) return existing
    val now = System.currentTimeMillis()
    val recon = ReconciliationCaseEntity(
      caseId = "REC-${UUID.randomUUID().toString().take(8).uppercase()}",
      orderId = order.orderId,
      claimReference = order.claimReference,
      caseType = caseType,
      status = ReconciliationStatus.OPEN.name,
      description = description,
      resolutionNote = null,
      resolvedBy = null,
      createdAtMs = now,
      updatedAtMs = now,
    )
    dao.upsertReconciliationCase(recon)
    return recon
  }

  private suspend fun generateAndAttemptPrintReceipt(
    order: OrderEntity,
    op: FulfilmentOperationEntity,
    payment: PaymentAttemptEntity,
  ): ReceiptEntity {
    val totalFmt = PricingQuote.formatUsd(order.totalCents)
    val svFmt = PricingQuote.formatUsd(order.storedValueCents)
    val feeFmt = PricingQuote.formatUsd(order.cardIssueFeeCents)
    val summaryEn =
      "DEMO RECEIPT (${order.claimReference})\nOrder: ${order.orderId}\nCard/Acct: ${op.issuedOrUpdatedCardRef ?: "Pending"}\nStored value: $svFmt | Issue fee: $feeFmt\nTotal: $totalFmt USD (${payment.paymentState})\nDEMO — NOT VALID FOR TRAVEL"
    val summaryEs =
      "RECIBO DEMO (${order.claimReference})\nOrden: ${order.orderId}\nTarjeta/Cuenta: ${op.issuedOrUpdatedCardRef ?: "Pendiente"}\nSaldo: $svFmt | Emisión: $feeFmt\nTotal: $totalFmt USD (${payment.paymentState})\nDEMO — NO VÁLIDO PARA VIAJAR"
    val printRes = printerAdapter.printReceipt(summaryEn)
    val receipt = ReceiptEntity(
      receiptId = "RCP-${UUID.randomUUID().toString().take(8).uppercase()}",
      orderId = order.orderId,
      claimReference = order.claimReference,
      summaryEn = summaryEn,
      summaryEs = summaryEs,
      totalCents = order.totalCents,
      watermark = "DEMO — NOT VALID FOR TRAVEL",
      printedPhysically = printRes.printed,
      createdAtMs = System.currentTimeMillis(),
    )
    dao.upsertReceipt(receipt)
    return receipt
  }

  private suspend fun audit(
    actorId: String,
    actorRole: String,
    action: String,
    targetId: String,
    details: String,
  ) {
    dao.insertAuditEvent(
      AuditEventEntity(
        auditId = "AUD-${UUID.randomUUID().toString().take(8).uppercase()}",
        actorId = actorId,
        actorRole = actorRole,
        action = action,
        targetEntityId = targetId,
        redactedDetails = LogRedactor.redact(details),
        createdAtMs = System.currentTimeMillis(),
      )
    )
  }
}
