package com.example.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class AudioGuidanceHelper(context: Context) : TextToSpeech.OnInitListener {
  private var tts: TextToSpeech? = null
  private var ready = false
  private var currentLangCode = "en"

  init {
    try {
      tts = TextToSpeech(context.applicationContext, this)
    } catch (_: Throwable) {
      // Safe fallback in Robolectric / headless environments without TTS engine
      tts = null
    }
  }

  override fun onInit(status: Int) {
    ready = status == TextToSpeech.SUCCESS
    if (ready) {
      tts?.language = if (currentLangCode == "es") Locale.forLanguageTag("es-US") else Locale.US
    }
  }

  fun setLanguage(langCode: String) {
    currentLangCode = langCode
    if (ready) {
      tts?.language = if (langCode == "es") Locale.forLanguageTag("es-US") else Locale.US
    }
  }

  fun speak(text: String, enabled: Boolean) {
    if (!enabled || !ready) return
    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kiosk-guidance")
  }

  fun shutdown() {
    tts?.stop()
    tts?.shutdown()
  }
}
