package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "operators")
data class OperatorEntity(
  @PrimaryKey val operatorId: String,
  val badgeCode: String,
  val displayName: String,
  val badgeColorHex: Long,
  val demoWatermark: String,
  val enabledLanguagesCsv: String = "en,es",
)

@Entity(tableName = "terminals")
data class TerminalEntity(
  @PrimaryKey val terminalId: String,
  val operatorId: String,
  val stationName: String,
  val cardStockRemaining: Int,
  val receiptPaperPercent: Int,
  val cashAdapterEnabled: Boolean,
  val sessionTimeoutSeconds: Int,
  val isOnline: Boolean,
)

@Entity(
  tableName = "product_versions",
  indices = [Index(value = ["productCode", "versionNumber"], unique = true)],
)
data class ProductVersionEntity(
  @PrimaryKey val productVersionId: String,
  val operatorId: String,
  val productCode: String,
  val versionNumber: Int,
  val category: String, // NEW_CARD, RELOAD, PASS
  val titleEn: String,
  val titleEs: String,
  val descriptionEn: String,
  val descriptionEs: String,
  val eligibilityRestriction: String, // NONE, REDUCED_FARE_VERIFIED, DEMO_ADULT
  val refundRule: String,
  val salesStartEpochMs: Long,
  val salesEndEpochMs: Long,
  val isAccountBasedCapable: Boolean,
  val isActive: Boolean,
  val createdAtMs: Long,
)

@Entity(tableName = "pricing_rules")
data class PricingRuleEntity(
  @PrimaryKey val pricingRuleId: String,
  val productVersionId: String,
  val optionLabel: String,
  val storedValueCents: Int,
  val fareEntitlementCents: Int,
  val cardIssueFeeCents: Int,
  val fixedSalePriceCents: Int?, // null means storedValue + cardIssueFee
  val currency: String = "USD",
  val entitlementTextEn: String,
  val entitlementTextEs: String,
  val isDefault: Boolean,
)

@Entity(tableName = "sessions")
data class KioskSessionEntity(
  @PrimaryKey val sessionId: String,
  val terminalId: String,
  val languageCode: String,
  val startedAtMs: Long,
  val lastActivityMs: Long,
  val endedAtMs: Long?,
  val status: String, // ACTIVE, CLEARED, EXPIRED
)

@Entity(
  tableName = "orders",
  indices = [Index(value = ["sessionId"])],
)
data class OrderEntity(
  @PrimaryKey val orderId: String,
  val sessionId: String,
  val terminalId: String,
  val operatorId: String,
  val productVersionId: String,
  val productCode: String,
  val productVersionNumber: Int,
  val pricingRuleId: String,
  val storedValueCents: Int,
  val fareEntitlementCents: Int,
  val cardIssueFeeCents: Int,
  val totalCents: Int,
  val currency: String,
  val targetCardRef: String?,
  val isAccountBased: Boolean,
  val orderState: String,
  val claimReference: String,
  val createdAtMs: Long,
  val updatedAtMs: Long,
)

@Entity(
  tableName = "payment_attempts",
  indices = [Index(value = ["idempotencyKey"], unique = true), Index(value = ["orderId"])],
)
data class PaymentAttemptEntity(
  @PrimaryKey val paymentAttemptId: String,
  val orderId: String,
  val idempotencyKey: String,
  val paymentMethod: String,
  val amountCents: Int,
  val currency: String,
  val paymentState: String,
  val paymentSubState: String,
  val maskedInstrumentRef: String?,
  val providerEventId: String?,
  val errorCode: String?,
  val createdAtMs: Long,
  val updatedAtMs: Long,
)

@Entity(
  tableName = "fulfilment_operations",
  indices = [Index(value = ["idempotencyKey"], unique = true), Index(value = ["orderId"])],
)
data class FulfilmentOperationEntity(
  @PrimaryKey val fulfilmentId: String,
  val orderId: String,
  val idempotencyKey: String,
  val operationType: String, // ISSUE_NEW_CARD, RELOAD_CARD, RELOAD_ACCOUNT
  val fulfilmentState: String,
  val issuedOrUpdatedCardRef: String?,
  val isAccountBased: Boolean,
  val externalFulfilmentRef: String?,
  val errorCode: String?,
  val retryCount: Int,
  val createdAtMs: Long,
  val updatedAtMs: Long,
)

@Entity(tableName = "transit_accounts")
data class TransitAccountEntity(
  @PrimaryKey val cardRef: String,
  val operatorId: String,
  val isAccountBased: Boolean,
  val authoritativeBalanceCents: Int,
  val activeEntitlementEn: String,
  val activeEntitlementEs: String,
  val eligibilityTier: String,
  val status: String, // ACTIVE, BLOCKED
  val lastSyncedAtMs: Long,
)

@Entity(tableName = "device_events")
data class DeviceEventEntity(
  @PrimaryKey val eventId: String,
  val terminalId: String,
  val adapterName: String,
  val severity: String, // INFO, WARN, ERROR
  val errorCode: String?,
  val message: String,
  val createdAtMs: Long,
)

@Entity(
  tableName = "receipts",
  indices = [Index(value = ["orderId"], unique = true)],
)
data class ReceiptEntity(
  @PrimaryKey val receiptId: String,
  val orderId: String,
  val claimReference: String,
  val summaryEn: String,
  val summaryEs: String,
  val totalCents: Int,
  val watermark: String,
  val printedPhysically: Boolean,
  val createdAtMs: Long,
)

@Entity(tableName = "refunds")
data class RefundEntity(
  @PrimaryKey val refundId: String,
  val orderId: String,
  val paymentAttemptId: String,
  val amountCents: Int,
  val reason: String,
  val status: String, // REFUND_REQUESTED, APPROVED, SETTLED, REJECTED
  val requestedBy: String,
  val approvedBy: String?,
  val createdAtMs: Long,
  val updatedAtMs: Long,
)

@Entity(tableName = "reconciliation_cases")
data class ReconciliationCaseEntity(
  @PrimaryKey val caseId: String,
  val orderId: String,
  val claimReference: String,
  val caseType: String, // UNKNOWN_PAYMENT, PROVISION_FAILURE, LOST_RESPONSE, DISPENSER_JAM, CARD_NOT_COLLECTED
  val status: String, // OPEN, AUTO_RESOLVED, STAFF_RESOLVED, ESCALATED
  val description: String,
  val resolutionNote: String?,
  val resolvedBy: String?,
  val createdAtMs: Long,
  val updatedAtMs: Long,
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
  @PrimaryKey val auditId: String,
  val actorId: String,
  val actorRole: String,
  val action: String,
  val targetEntityId: String,
  val redactedDetails: String,
  val createdAtMs: Long,
)
