package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.domain.model.KioskFlow
import com.example.domain.model.PricingQuote
import com.example.ui.CheckoutPhase
import com.example.ui.KioskMainUiState
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.PureWhite

@Composable
fun OrderSummaryPane(
  uiState: KioskMainUiState,
  onContinueToPayment: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalKioskTokens.current
  val lang = uiState.language
  val quote = uiState.currentQuote
  val isReload = uiState.activeFlow == KioskFlow.RELOAD_CARD
  val isConfigure = uiState.checkoutPhase == CheckoutPhase.CONFIGURE
  val canSubmitOrder = isConfigure &&
    quote != null &&
    (!isReload || (uiState.identifiedCard != null && uiState.identifiedCard.status == "ACTIVE"))

  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Surface(
      color = tokens.panelBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.2.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column {
        // Matte-black header matching screenshot
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(tokens.headerBg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
          Text(
            text = Translations.get(TKey.YOUR_PURCHASE, lang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            color = tokens.headerFg,
          )
        }

        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = if (quote != null && quote.storedValueCents == 0 && quote.fareEntitlementCents > 0) {
                Translations.get(TKey.ACTIVE_ENTITLEMENT, lang)
              } else {
                Translations.get(TKey.STORED_VALUE_LABEL, lang)
              },
              style = MaterialTheme.typography.titleMedium,
              color = tokens.textPrimary,
            )
            Text(
              text = PricingQuote.formatUsd(
                quote?.let { if (it.storedValueCents > 0) it.storedValueCents else it.fareEntitlementCents } ?: 2000
              ),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = tokens.textPrimary,
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = Translations.get(TKey.CARD_ISSUE_FEE_LABEL, lang),
              style = MaterialTheme.typography.titleMedium,
              color = tokens.textPrimary,
            )
            Text(
              text = PricingQuote.formatUsd(quote?.cardIssueFeeCents ?: 100),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = tokens.textPrimary,
            )
          }

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(1.5.dp)
              .background(tokens.textPrimary),
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom,
          ) {
            Text(
              text = Translations.get(TKey.TOTAL_LABEL, lang),
              fontSize = 24.sp,
              fontWeight = FontWeight.ExtraBold,
              color = tokens.textPrimary,
            )
            Text(
              text = "${PricingQuote.formatUsd(quote?.totalCents ?: 2100)} ${quote?.currency ?: "USD"}",
              fontSize = 24.sp,
              fontWeight = FontWeight.ExtraBold,
              color = tokens.textPrimary,
              modifier = Modifier.testTag("order_summary_total"),
            )
          }

          Text(
            text = Translations.get(TKey.ILLUSTRATIVE_PRICE_NOTE, lang),
            style = MaterialTheme.typography.bodyMedium,
            fontStyle = FontStyle.Italic,
            color = tokens.textSecondary,
          )

          Surface(
            color = Color(0xFFF2F4F7),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = Translations.get(TKey.DEMO_WATERMARK, lang),
              fontFamily = MonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = tokens.textPrimary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            )
          }

          if (isConfigure) {
            Button(
              onClick = onContinueToPayment,
              enabled = canSubmitOrder && !uiState.isBusy,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = tokens.accentBlue),
              modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("continue_to_payment_button"),
            ) {
              Text(
                text = if (isReload) Translations.get(TKey.RELOAD_APPLY_ACTION, lang)
                else Translations.get(TKey.CONTINUE_TO_PAYMENT, lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = PureWhite,
              )
              Spacer(Modifier.width(8.dp))
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = PureWhite,
                modifier = Modifier.size(20.dp),
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = null,
              tint = tokens.textPrimary,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
              text = "${Translations.get(TKey.SECURE_CHECKOUT, lang)}  |  ${Translations.get(TKey.NO_PAYMENT_TAKEN, lang)}",
              style = MaterialTheme.typography.bodyMedium,
              color = tokens.textSecondary,
            )
          }
        }
      }
    }

    // Bottom info card matching screenshot
    Surface(
      color = tokens.panelBg,
      shape = RoundedCornerShape(10.dp),
      border = BorderStroke(1.2.dp, tokens.border),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = Translations.get(TKey.ALREADY_PAYING_PHONE_TITLE, lang),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.ExtraBold,
          color = tokens.textPrimary,
        )
        Text(
          text = Translations.get(TKey.ALREADY_PAYING_PHONE_BODY, lang),
          style = MaterialTheme.typography.bodyMedium,
          color = tokens.textSecondary,
        )
      }
    }
  }
}
