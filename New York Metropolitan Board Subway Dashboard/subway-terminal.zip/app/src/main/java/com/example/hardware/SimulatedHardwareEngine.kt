package com.example.hardware

import com.example.data.local.DeviceEventEntity
import com.example.data.local.TerminalDao
import com.example.data.local.TransitAccountEntity
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PaymentState
import com.example.domain.model.PaymentSubState
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Deterministic, thread-safe local device service simulator implementing all typed hardware
 * interfaces with controllable failure modes and authoritative operator ledger backing.
 */
class SimulatedHardwareEngine(
  private val dao: TerminalDao,
  private val simulatedDelayMs: Long = 180L,
) :
  PaymentTerminalAdapter,
  TransitCardReaderAdapter,
  TravelProductFulfilmentService,
  CardDispenserAdapter,
  ReceiptPrinterAdapter,
  BarcodeScannerAdapter,
  CashAcceptorAdapter,
  DeviceHealthMonitor {

  private var cardStockRemaining: Int = 48
  private var receiptPaperPercent: Int = 82
  private var cashAvailable: Boolean = false
  private var dispenserJammed: Boolean = false
  private var paymentFaultMode: PaymentFaultMode = PaymentFaultMode.NORMAL
  private var fulfilmentFaultMode: FulfilmentFaultMode = FulfilmentFaultMode.NORMAL
  private var transitReaderTimeoutFault: Boolean = false

  // Provider-side idempotency store so lost-response queries never double-charge or double-provision
  private val providerPaymentLedger = ConcurrentHashMap<String, PaymentTerminalResult>()
  private val providerFulfilmentLedger = ConcurrentHashMap<String, FulfilmentExecutionResult>()

  private val _healthFlow = MutableStateFlow(buildSnapshot())
  override val healthFlow: StateFlow<HardwareHealthSnapshot> = _healthFlow.asStateFlow()

  private fun refreshHealth() {
    _healthFlow.value = buildSnapshot()
  }

  private fun buildSnapshot(): HardwareHealthSnapshot {
    val dispenserStatus = when {
      dispenserJammed -> AdapterOperationalStatus.JAMMED
      cardStockRemaining <= 0 -> AdapterOperationalStatus.OUT_OF_SUPPLIES
      else -> AdapterOperationalStatus.READY
    }
    val printerStatus = when {
      receiptPaperPercent <= 0 || fulfilmentFaultMode == FulfilmentFaultMode.PRINTER_UNAVAILABLE ->
        AdapterOperationalStatus.OUT_OF_SUPPLIES
      else -> AdapterOperationalStatus.READY
    }
    return HardwareHealthSnapshot(
      paymentTerminal = AdapterCapabilities(
        adapterName = "EMV / NFC Payment Terminal (Sim)",
        isSimulated = true,
        supportedOperations = listOf("CONTACTLESS_NFC", "CHIP_CARD", "AUTH_CAPTURE", "REFUND"),
        available = true,
        status = AdapterOperationalStatus.READY,
      ),
      transitReader = AdapterCapabilities(
        adapterName = "Transit Card Reader (Sim)",
        isSimulated = true,
        supportedOperations = listOf("IDENTIFY_CARD_TOKEN"),
        available = !transitReaderTimeoutFault,
        status = if (transitReaderTimeoutFault) AdapterOperationalStatus.DEGRADED else AdapterOperationalStatus.READY,
      ),
      fulfilmentService = AdapterCapabilities(
        adapterName = "Operator Fare Fulfilment API (Sim)",
        isSimulated = true,
        supportedOperations = listOf("FETCH_BALANCE", "PROVISION_CARD", "IDEMPOTENT_RELOAD"),
        available = true,
        status = AdapterOperationalStatus.READY,
      ),
      cardDispenser = AdapterCapabilities(
        adapterName = "Smartcard Dispenser Hopper (Sim)",
        isSimulated = true,
        supportedOperations = listOf("CHECK_STOCK", "DISPENSE_CARD", "SENSE_COLLECTION"),
        available = !dispenserJammed && cardStockRemaining > 0,
        status = dispenserStatus,
        lastError = if (dispenserJammed) HardwareError("DISPENSER_JAM", "Card path jammed in hopper", true) else null,
      ),
      receiptPrinter = AdapterCapabilities(
        adapterName = "Thermal Receipt Printer (Sim)",
        isSimulated = true,
        supportedOperations = listOf("PRINT_RECEIPT"),
        available = receiptPaperPercent > 0 && fulfilmentFaultMode != FulfilmentFaultMode.PRINTER_UNAVAILABLE,
        status = printerStatus,
      ),
      barcodeScanner = AdapterCapabilities(
        adapterName = "2D Optical QR Scanner (Sim)",
        isSimulated = true,
        supportedOperations = listOf("SCAN_QR_VOUCHER", "SCAN_CARD_REF"),
        available = true,
        status = AdapterOperationalStatus.READY,
      ),
      cashAcceptor = AdapterCapabilities(
        adapterName = "Cash Note & Coin Acceptor (Sim)",
        isSimulated = true,
        supportedOperations = if (cashAvailable) listOf("ACCEPT_USD_CASH") else emptyList(),
        available = cashAvailable,
        status = if (cashAvailable) AdapterOperationalStatus.READY else AdapterOperationalStatus.OFFLINE,
        lastError = if (!cashAvailable) HardwareError("CASH_UNAVAILABLE", "Unavailable at this terminal", false) else null,
      ),
      cardStockRemaining = cardStockRemaining,
      receiptPaperPercent = receiptPaperPercent,
      paymentFaultMode = paymentFaultMode,
      fulfilmentFaultMode = fulfilmentFaultMode,
      transitReaderTimeoutFault = transitReaderTimeoutFault,
    )
  }

  private suspend fun logDeviceEvent(adapter: String, severity: String, code: String?, msg: String) {
    dao.insertDeviceEvent(
      DeviceEventEntity(
        eventId = "DEV-${UUID.randomUUID().toString().take(8)}",
        terminalId = "KIOSK-NY-042",
        adapterName = adapter,
        severity = severity,
        errorCode = code,
        message = msg,
        createdAtMs = System.currentTimeMillis(),
      )
    )
  }

  // --- PaymentTerminalAdapter ---
  override fun capabilities(): AdapterCapabilities = buildSnapshot().paymentTerminal

  override suspend fun authorizeAndCapture(
    orderId: String,
    amountCents: Int,
    currency: String,
    method: PaymentMethod,
    idempotencyKey: String,
  ): PaymentTerminalResult {
    providerPaymentLedger[idempotencyKey]?.let { existing ->
      return existing
    }
    if (simulatedDelayMs > 0) delay(simulatedDelayMs)

    if (method == PaymentMethod.CASH && !cashAvailable) {
      return PaymentTerminalResult(
        state = PaymentState.DECLINED,
        subState = PaymentSubState.NONE,
        error = HardwareError("CASH_DISABLED", "Cash adapter unavailable at this terminal", false),
      )
    }

    val maskedRef = when (method) {
      PaymentMethod.CONTACTLESS_NFC -> "NFC-WALLET-••••"
      PaymentMethod.CHIP_CARD -> "EMV-CHIP-••••"
      PaymentMethod.CASH -> "CASH-TENDER"
    }

    val result = when (paymentFaultMode) {
      PaymentFaultMode.NORMAL -> {
        val evt = "PGW-${UUID.randomUUID().toString().take(8).uppercase()}"
        logDeviceEvent("PaymentTerminal", "INFO", null, "Authorized & captured $amountCents cents ($method)")
        PaymentTerminalResult(
          state = PaymentState.CONFIRMED,
          subState = PaymentSubState.CAPTURED,
          maskedInstrumentRef = maskedRef,
          providerEventId = evt,
        )
      }
      PaymentFaultMode.DECLINE -> {
        logDeviceEvent("PaymentTerminal", "WARN", "CARD_DECLINED", "Issuer declined transaction for order $orderId")
        PaymentTerminalResult(
          state = PaymentState.DECLINED,
          subState = PaymentSubState.NONE,
          maskedInstrumentRef = maskedRef,
          error = HardwareError("CARD_DECLINED", "Payment declined by issuer", true),
        )
      }
      PaymentFaultMode.OUTCOME_UNKNOWN -> {
        // Provider captured on remote gateway, but terminal response timed out
        val evt = "PGW-UNK-${UUID.randomUUID().toString().take(6).uppercase()}"
        providerPaymentLedger["REMOTE:$idempotencyKey"] = PaymentTerminalResult(
          state = PaymentState.CONFIRMED,
          subState = PaymentSubState.CAPTURED,
          maskedInstrumentRef = maskedRef,
          providerEventId = evt,
        )
        logDeviceEvent("PaymentTerminal", "ERROR", "OUTCOME_UNKNOWN", "Gateway response lost after tap for order $orderId")
        PaymentTerminalResult(
          state = PaymentState.OUTCOME_UNKNOWN,
          subState = PaymentSubState.AUTHORIZED,
          maskedInstrumentRef = maskedRef,
          error = HardwareError("OUTCOME_UNKNOWN", "Gateway confirmation timed out", true),
        )
      }
      PaymentFaultMode.READER_TIMEOUT -> {
        logDeviceEvent("PaymentTerminal", "WARN", "READER_TIMEOUT", "Payment reader timed out waiting for tap")
        PaymentTerminalResult(
          state = PaymentState.CANCELLED,
          subState = PaymentSubState.NONE,
          error = HardwareError("READER_TIMEOUT", "Reader timed out before card tap", true),
        )
      }
      PaymentFaultMode.NETWORK_INTERRUPTION -> {
        logDeviceEvent("PaymentTerminal", "ERROR", "NETWORK_INTERRUPTED", "Payment network connection dropped")
        PaymentTerminalResult(
          state = PaymentState.OUTCOME_UNKNOWN,
          subState = PaymentSubState.NONE,
          error = HardwareError("NETWORK_INTERRUPTED", "Network dropped during processing", true),
        )
      }
    }

    providerPaymentLedger[idempotencyKey] = result
    return result
  }

  override suspend fun queryAuthoritativeOutcome(idempotencyKey: String): PaymentTerminalResult {
    providerPaymentLedger["REMOTE:$idempotencyKey"]?.let { resolved ->
      providerPaymentLedger[idempotencyKey] = resolved
      return resolved
    }
    return providerPaymentLedger[idempotencyKey] ?: PaymentTerminalResult(
      state = PaymentState.CANCELLED,
      subState = PaymentSubState.REVERSED,
      error = HardwareError("NO_CAPTURE_FOUND", "No capture recorded on gateway; reversed", true),
    )
  }

  override suspend fun requestRefundOrReversal(
    paymentAttemptId: String,
    amountCents: Int,
  ): PaymentSubState {
    if (simulatedDelayMs > 0) delay(simulatedDelayMs / 2)
    logDeviceEvent("PaymentTerminal", "INFO", null, "Settled refund for attempt $paymentAttemptId ($amountCents cents)")
    return PaymentSubState.REFUND_COMPLETED
  }

  // --- TransitCardReaderAdapter ---
  override suspend fun identifyCard(simulatedCardRef: String?): CardIdentificationResult {
    if (simulatedDelayMs > 0) delay(simulatedDelayMs / 2)
    if (transitReaderTimeoutFault) {
      logDeviceEvent("TransitCardReader", "WARN", "READER_TIMEOUT", "Transit reader timed out waiting for travel card")
      return CardIdentificationResult(
        success = false,
        error = HardwareError("READER_TIMEOUT", "Transit card reader timed out", true),
      )
    }
    val ref = simulatedCardRef ?: "CRD-4829-1104"
    val acct = dao.getTransitAccount(ref)
    if (acct == null) {
      logDeviceEvent("TransitCardReader", "WARN", "UNRECOGNIZED_CARD", "Unsupported card presented: $ref")
      return CardIdentificationResult(
        success = false,
        error = HardwareError("UNSUPPORTED_CARD", "Card token not recognised by authorised transit reader", true),
      )
    }
    logDeviceEvent("TransitCardReader", "INFO", null, "Identified transit reference $ref (accountBased=${acct.isAccountBased})")
    return CardIdentificationResult(
      success = true,
      opaqueCardRef = acct.cardRef,
      isAccountBased = acct.isAccountBased,
    )
  }

  // --- TravelProductFulfilmentService ---
  override suspend fun fetchAuthoritativeCard(cardRef: String): AuthoritativeCardSnapshot? {
    val acct = dao.getTransitAccount(cardRef) ?: return null
    return AuthoritativeCardSnapshot(
      cardRef = acct.cardRef,
      isAccountBased = acct.isAccountBased,
      authoritativeBalanceCents = acct.authoritativeBalanceCents,
      activeEntitlementEn = acct.activeEntitlementEn,
      activeEntitlementEs = acct.activeEntitlementEs,
      eligibilityTier = acct.eligibilityTier,
      status = acct.status,
      lastSyncedAtMs = acct.lastSyncedAtMs,
    )
  }

  override suspend fun provisionNewCard(
    orderId: String,
    idempotencyKey: String,
    storedValueCents: Int,
    entitlementEn: String,
    entitlementEs: String,
    isAccountBased: Boolean,
  ): FulfilmentExecutionResult {
    providerFulfilmentLedger[idempotencyKey]?.let { existing ->
      // Even if original response was "lost", querying idempotently returns the committed result
      return existing.copy(responseLostAfterCommit = false)
    }
    if (simulatedDelayMs > 0) delay(simulatedDelayMs)

    if (fulfilmentFaultMode == FulfilmentFaultMode.PROVISION_FAIL_AFTER_PAYMENT) {
      logDeviceEvent("FulfilmentService", "ERROR", "PROVISION_FAILED", "Fare host rejected provisioning after payment for $orderId")
      return FulfilmentExecutionResult(
        success = false,
        error = HardwareError("PROVISION_FAILED", "Operator fare host unavailable during provisioning", true),
      )
    }

    val newRef = "CRD-${(1000..9999).random()}-${(1000..9999).random()}"
    val extRef = "OPF-${UUID.randomUUID().toString().take(8).uppercase()}"
    val now = System.currentTimeMillis()
    dao.upsertTransitAccount(
      TransitAccountEntity(
        cardRef = newRef,
        operatorId = "OP-NYC-DEMO",
        isAccountBased = isAccountBased,
        authoritativeBalanceCents = storedValueCents,
        activeEntitlementEn = entitlementEn,
        activeEntitlementEs = entitlementEs,
        eligibilityTier = "STANDARD",
        status = "ACTIVE",
        lastSyncedAtMs = now,
      )
    )

    val committed = FulfilmentExecutionResult(
      success = true,
      responseLostAfterCommit = false,
      issuedCardRef = newRef,
      externalFulfilmentRef = extRef,
      updatedBalanceCents = storedValueCents,
    )
    providerFulfilmentLedger[idempotencyKey] = committed

    if (fulfilmentFaultMode == FulfilmentFaultMode.PROVISION_SUCCEEDED_RESPONSE_LOST) {
      logDeviceEvent("FulfilmentService", "WARN", "RESPONSE_LOST", "Provisioned $newRef on host, but ACK dropped for $orderId")
      return committed.copy(success = false, responseLostAfterCommit = true, error = HardwareError("RESPONSE_LOST", "Host response dropped after commit", true))
    }

    logDeviceEvent("FulfilmentService", "INFO", null, "Provisioned $newRef with $storedValueCents cents")
    return committed
  }

  override suspend fun applyReload(
    orderId: String,
    idempotencyKey: String,
    cardRef: String,
    addStoredValueCents: Int,
    newEntitlementEn: String?,
    newEntitlementEs: String?,
  ): FulfilmentExecutionResult {
    providerFulfilmentLedger[idempotencyKey]?.let { existing ->
      return existing.copy(responseLostAfterCommit = false)
    }
    if (simulatedDelayMs > 0) delay(simulatedDelayMs)

    if (fulfilmentFaultMode == FulfilmentFaultMode.PROVISION_FAIL_AFTER_PAYMENT) {
      logDeviceEvent("FulfilmentService", "ERROR", "RELOAD_FAILED", "Fare host rejected reload for $cardRef")
      return FulfilmentExecutionResult(
        success = false,
        error = HardwareError("RELOAD_FAILED", "Operator reload failed after payment", true),
      )
    }

    val acct = dao.getTransitAccount(cardRef)
      ?: return FulfilmentExecutionResult(
        success = false,
        error = HardwareError("ACCOUNT_NOT_FOUND", "Target card reference missing in operator ledger", false),
      )

    if (acct.status == "BLOCKED") {
      return FulfilmentExecutionResult(
        success = false,
        error = HardwareError("CARD_BLOCKED", "Target card is blocked in operator system", false),
      )
    }

    val updatedBalance = acct.authoritativeBalanceCents + addStoredValueCents
    val updated = acct.copy(
      authoritativeBalanceCents = updatedBalance,
      activeEntitlementEn = newEntitlementEn ?: acct.activeEntitlementEn,
      activeEntitlementEs = newEntitlementEs ?: acct.activeEntitlementEs,
      lastSyncedAtMs = System.currentTimeMillis(),
    )
    dao.upsertTransitAccount(updated)

    val extRef = "RLD-${UUID.randomUUID().toString().take(8).uppercase()}"
    val committed = FulfilmentExecutionResult(
      success = true,
      issuedCardRef = cardRef,
      externalFulfilmentRef = extRef,
      updatedBalanceCents = updatedBalance,
    )
    providerFulfilmentLedger[idempotencyKey] = committed

    if (fulfilmentFaultMode == FulfilmentFaultMode.PROVISION_SUCCEEDED_RESPONSE_LOST) {
      logDeviceEvent("FulfilmentService", "WARN", "RESPONSE_LOST", "Reloaded $cardRef (+$addStoredValueCents), ACK dropped")
      return committed.copy(success = false, responseLostAfterCommit = true, error = HardwareError("RESPONSE_LOST", "Reload succeeded on host, response lost", true))
    }

    logDeviceEvent("FulfilmentService", "INFO", null, "Reloaded $cardRef (+$addStoredValueCents cents -> $updatedBalance cents)")
    return committed
  }

  // --- CardDispenserAdapter ---
  override suspend fun checkAvailability(): Boolean {
    return !dispenserJammed && cardStockRemaining > 0
  }

  override suspend fun dispensePhysicalCard(cardRef: String): DispenserResult {
    if (simulatedDelayMs > 0) delay(simulatedDelayMs)
    if (cardStockRemaining <= 0) {
      logDeviceEvent("CardDispenser", "ERROR", "OUT_OF_STOCK", "Dispenser hopper empty")
      refreshHealth()
      return DispenserResult(
        dispensed = false,
        error = HardwareError("OUT_OF_STOCK", "Card hopper empty", false),
      )
    }
    if (fulfilmentFaultMode == FulfilmentFaultMode.DISPENSER_JAM || dispenserJammed) {
      dispenserJammed = true
      logDeviceEvent("CardDispenser", "ERROR", "DISPENSER_JAM", "Mechanical jam dispensing card $cardRef")
      refreshHealth()
      return DispenserResult(
        dispensed = false,
        jammed = true,
        error = HardwareError("DISPENSER_JAM", "Card jammed inside dispenser chute", true),
      )
    }
    cardStockRemaining = (cardStockRemaining - 1).coerceAtLeast(0)
    dao.getTerminal()?.let {
      dao.upsertTerminal(it.copy(cardStockRemaining = cardStockRemaining))
    }
    refreshHealth()
    logDeviceEvent("CardDispenser", "INFO", null, "Dispensed physical demo card $cardRef (stock=$cardStockRemaining)")

    if (fulfilmentFaultMode == FulfilmentFaultMode.CARD_NOT_COLLECTED) {
      logDeviceEvent("CardDispenser", "WARN", "CARD_NOT_COLLECTED", "Card $cardRef not taken from slot before sensor timeout")
      return DispenserResult(
        dispensed = true,
        collected = false,
        error = HardwareError("CARD_NOT_COLLECTED", "Card remained in dispenser tray", true),
      )
    }
    return DispenserResult(dispensed = true, collected = false)
  }

  override suspend fun confirmCustomerCollection(): Boolean {
    logDeviceEvent("CardDispenser", "INFO", null, "Optical tray sensor confirmed card collected")
    return true
  }

  override suspend fun clearJamAndRestock(newStockCount: Int) {
    dispenserJammed = false
    cardStockRemaining = newStockCount
    if (fulfilmentFaultMode == FulfilmentFaultMode.DISPENSER_JAM) {
      fulfilmentFaultMode = FulfilmentFaultMode.NORMAL
    }
    dao.getTerminal()?.let {
      dao.upsertTerminal(it.copy(cardStockRemaining = newStockCount))
    }
    logDeviceEvent("CardDispenser", "INFO", null, "Staff cleared dispenser jam and restocked to $newStockCount")
    refreshHealth()
  }

  // --- ReceiptPrinterAdapter ---
  override suspend fun printReceipt(receiptText: String): PrinterResult {
    if (receiptPaperPercent <= 0 || fulfilmentFaultMode == FulfilmentFaultMode.PRINTER_UNAVAILABLE) {
      logDeviceEvent("ReceiptPrinter", "WARN", "PRINTER_UNAVAILABLE", "Thermal printer offline or out of paper")
      refreshHealth()
      return PrinterResult(
        printed = false,
        error = HardwareError("PRINTER_UNAVAILABLE", "Printer paper out or offline", true),
      )
    }
    receiptPaperPercent = (receiptPaperPercent - 1).coerceAtLeast(0)
    dao.getTerminal()?.let {
      dao.upsertTerminal(it.copy(receiptPaperPercent = receiptPaperPercent))
    }
    logDeviceEvent("ReceiptPrinter", "INFO", null, "Printed demonstration receipt")
    refreshHealth()
    return PrinterResult(printed = true)
  }

  // --- BarcodeScannerAdapter ---
  override suspend fun scanDemoCode(presetCode: String?): BarcodeScanResult {
    if (simulatedDelayMs > 0) delay(simulatedDelayMs / 3)
    val code = presetCode ?: "ACCT-9012-7731"
    logDeviceEvent("BarcodeScanner", "INFO", null, "Scanned demonstration reference $code")
    return BarcodeScanResult(success = true, scannedCode = code)
  }

  // --- DeviceHealthMonitor ---
  override fun setPaymentFaultMode(mode: PaymentFaultMode) {
    paymentFaultMode = mode
    refreshHealth()
  }

  override fun setFulfilmentFaultMode(mode: FulfilmentFaultMode) {
    fulfilmentFaultMode = mode
    if (mode != FulfilmentFaultMode.DISPENSER_JAM) {
      dispenserJammed = false
    }
    refreshHealth()
  }

  override fun setTransitReaderTimeoutFault(enabled: Boolean) {
    transitReaderTimeoutFault = enabled
    refreshHealth()
  }

  override fun setCashAdapterAvailable(available: Boolean) {
    cashAvailable = available
    refreshHealth()
  }

  override fun setPrinterPaperPercent(percent: Int) {
    receiptPaperPercent = percent.coerceIn(0, 100)
    refreshHealth()
  }

  override fun setCardStock(count: Int) {
    cardStockRemaining = count.coerceAtLeast(0)
    refreshHealth()
  }
}
