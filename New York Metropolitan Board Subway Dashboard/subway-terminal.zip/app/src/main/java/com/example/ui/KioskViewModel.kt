package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.backend.BackendResult
import com.example.backend.JourneyPlanResult
import com.example.backend.OrderExecutionOutcome
import com.example.backend.ReconciliationWorker
import com.example.backend.SubwayStation
import com.example.backend.SyntheticNycTransitDataAdapter
import com.example.backend.TerminalBackendService
import com.example.backend.TransitDataAdapter
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.TKey
import com.example.core.i18n.Translations
import com.example.data.local.AuditEventEntity
import com.example.data.local.DatabaseSeeder
import com.example.data.local.DeviceEventEntity
import com.example.data.local.OrderEntity
import com.example.data.local.PaymentAttemptEntity
import com.example.data.local.PricingRuleEntity
import com.example.data.local.ProductVersionEntity
import com.example.data.local.ReconciliationCaseEntity
import com.example.data.local.RefundEntity
import com.example.data.local.TerminalDao
import com.example.data.local.TerminalDatabase
import com.example.data.local.TerminalEntity
import com.example.data.local.TransitAccountEntity
import com.example.domain.model.AccessibilitySettings
import com.example.domain.model.KioskFlow
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PaymentState
import com.example.domain.model.PricingQuote
import com.example.domain.model.ProductCategory
import com.example.domain.model.StaffUser
import com.example.domain.model.StepProgress
import com.example.hardware.AuthoritativeCardSnapshot
import com.example.hardware.FulfilmentFaultMode
import com.example.hardware.HardwareHealthSnapshot
import com.example.hardware.PaymentFaultMode
import com.example.hardware.SimulatedHardwareEngine
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class CheckoutPhase {
  CONFIGURE,
  AWAITING_TAP_OR_CHIP,
  PROCESSING_PAYMENT,
  PAYMENT_DECLINED,
  PAYMENT_UNKNOWN,
  FULFILLING,
  READY_TO_COLLECT,
  COMPLETED,
  RECOVERY_CLAIM,
}

data class KioskMainUiState(
  val sessionId: String = "",
  val language: AppLanguage = AppLanguage.EN,
  val enabledLanguages: Set<AppLanguage> = setOf(AppLanguage.EN, AppLanguage.ES),
  val accessibility: AccessibilitySettings = AccessibilitySettings(),
  val activeFlow: KioskFlow = KioskFlow.BUY_CARD,
  val backStack: List<KioskFlow> = emptyList(),
  val stepProgress: StepProgress = StepProgress.REVIEW_AND_PAY,
  val operatorTitle: String = "New York Subway",
  val operatorBadgeCode: String = "MTA",
  val operatorBadgeColor: Long = 0xFF0039A6L,
  val demoWatermark: String = "DEMO — NOT VALID FOR TRAVEL",
  val products: List<ProductVersionEntity> = emptyList(),
  val pricingRulesByProduct: Map<String, List<PricingRuleEntity>> = emptyMap(),
  val selectedProductId: String = "PROD-CARD-V1",
  val selectedPricingRuleId: String = "RULE-CARD-20",
  val currentQuote: PricingQuote? = null,
  val selectedPaymentMethod: PaymentMethod = PaymentMethod.CONTACTLESS_NFC,
  val checkoutPhase: CheckoutPhase = CheckoutPhase.CONFIGURE,
  val activeOrder: OrderEntity? = null,
  val latestPaymentAttempt: PaymentAttemptEntity? = null,
  val executionOutcome: OrderExecutionOutcome? = null,
  val identifiedCard: AuthoritativeCardSnapshot? = null,
  val cardIdentifyError: String? = null,
  val transientErrorBanner: String? = null,
  val isBusy: Boolean = false,
  val showNetworkMapModal: Boolean = false,
  val showA11ySheet: Boolean = false,
  val showStaffAuthDialog: Boolean = false,
  val authenticatedStaff: StaffUser? = null,
  val staffAuthError: String? = null,
  val sessionSecondsRemaining: Int = 90,
  val showTimeoutWarning: Boolean = false,
  // Journey planner state
  val stations: List<SubwayStation> = emptyList(),
  val originStationId: String = "TSQ",
  val destinationStationId: String = "FUL",
  val accessibleRouteOnly: Boolean = false,
  val journeyPlan: JourneyPlanResult? = null,
)

class KioskViewModel @JvmOverloads constructor(
  application: Application,
  private val customDb: TerminalDatabase? = null,
  simulatedDelayMs: Long = 180L,
  private val enableBackgroundTimers: Boolean = true,
) : AndroidViewModel(application) {

  private val db: TerminalDatabase = customDb ?: TerminalDatabase.getInstance(application)
  val dao: TerminalDao = db.terminalDao()
  val hardwareEngine = SimulatedHardwareEngine(dao, simulatedDelayMs = simulatedDelayMs)
  val backend = TerminalBackendService(
    dao = dao,
    paymentAdapter = hardwareEngine,
    transitReader = hardwareEngine,
    fulfilmentService = hardwareEngine,
    dispenserAdapter = hardwareEngine,
    printerAdapter = hardwareEngine,
  )
  val transitDataAdapter: TransitDataAdapter = SyntheticNycTransitDataAdapter()
  val reconciliationWorker = ReconciliationWorker(dao, hardwareEngine, hardwareEngine, backend)
  private val audioHelper = AudioGuidanceHelper(application)

  private val _uiState = MutableStateFlow(
    KioskMainUiState(stations = transitDataAdapter.stations())
  )
  val uiState: StateFlow<KioskMainUiState> = _uiState.asStateFlow()

  val hardwareHealth: StateFlow<HardwareHealthSnapshot> = hardwareEngine.healthFlow
  val terminalState: StateFlow<TerminalEntity?> = dao.observeTerminal()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
  val allProductVersions: StateFlow<List<ProductVersionEntity>> = dao.observeAllProductVersions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val recentOrders: StateFlow<List<OrderEntity>> = dao.observeRecentOrders()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val reconciliationCases: StateFlow<List<ReconciliationCaseEntity>> = dao.observeReconciliationCases()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val refunds: StateFlow<List<RefundEntity>> = dao.observeRefunds()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val auditEvents: StateFlow<List<AuditEventEntity>> = dao.observeAuditEvents()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val deviceEvents: StateFlow<List<DeviceEventEntity>> = dao.observeDeviceEvents()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val transitAccounts: StateFlow<List<TransitAccountEntity>> = dao.observeAllTransitAccounts()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private var idleTimerJob: Job? = null
  private var activePaymentIdempotencyKey: String? = null
  private var activeFulfilmentIdempotencyKey: String? = null

  init {
    viewModelScope.launch {
      DatabaseSeeder.seedIfEmpty(dao)
      val session = backend.startAnonymousSession(AppLanguage.EN)
      _uiState.update { it.copy(sessionId = session.sessionId) }
      recomputeJourney()
      observeCatalogAndOperator()
      if (enableBackgroundTimers) {
        reconciliationWorker.start(viewModelScope, intervalMs = 15_000L)
        startIdleTimer()
      }
    }
  }

  private fun observeCatalogAndOperator() {
    viewModelScope.launch {
      combine(
        dao.observeOperator(),
        dao.observeActiveProducts(),
        dao.observeAllPricingRules(),
      ) { op, products, rules ->
        Triple(op, products, rules)
      }.collect { (op, products, rules) ->
        val grouped = rules.groupBy { it.productVersionId }
        val enabledLangs = op?.enabledLanguagesCsv?.split(",")
          ?.mapNotNull { code -> AppLanguage.entries.find { it.code == code.trim() } }
          ?.toSet()
          ?.ifEmpty { setOf(AppLanguage.EN) }
          ?: setOf(AppLanguage.EN, AppLanguage.ES)

        val currentState = _uiState.value
        val validProdId = if (products.any { it.productVersionId == currentState.selectedProductId }) {
          currentState.selectedProductId
        } else {
          products.firstOrNull { it.category != ProductCategory.RELOAD.name }?.productVersionId
            ?: products.firstOrNull()?.productVersionId
            ?: ""
        }
        val prodRules = grouped[validProdId].orEmpty()
        val validRuleId = if (prodRules.any { it.pricingRuleId == currentState.selectedPricingRuleId }) {
          currentState.selectedPricingRuleId
        } else {
          prodRules.firstOrNull { it.isDefault }?.pricingRuleId ?: prodRules.firstOrNull()?.pricingRuleId ?: ""
        }

        _uiState.update {
          it.copy(
            operatorTitle = op?.displayName ?: "New York Subway",
            operatorBadgeCode = op?.badgeCode ?: "MTA",
            operatorBadgeColor = op?.badgeColorHex ?: 0xFF0039A6L,
            demoWatermark = op?.demoWatermark ?: "DEMO — NOT VALID FOR TRAVEL",
            enabledLanguages = enabledLangs,
            language = if (it.language in enabledLangs) it.language else enabledLangs.first(),
            products = products,
            pricingRulesByProduct = grouped,
            selectedProductId = validProdId,
            selectedPricingRuleId = validRuleId,
          )
        }
        refreshQuote()
      }
    }
  }

  private fun startIdleTimer() {
    idleTimerJob?.cancel()
    idleTimerJob = viewModelScope.launch {
      while (isActive) {
        delay(1000L)
        val cur = _uiState.value
        if (cur.activeFlow == KioskFlow.STAFF_WORKSPACE) continue
        val next = cur.sessionSecondsRemaining - 1
        if (next <= 0) {
          startOver(expired = true)
        } else {
          val warn = next <= 20
          if (warn && !cur.showTimeoutWarning) {
            speakIfEnabled(Translations.get(TKey.SESSION_TIMEOUT_WARNING, cur.language))
          }
          _uiState.update {
            it.copy(sessionSecondsRemaining = next, showTimeoutWarning = warn)
          }
        }
      }
    }
  }

  fun touchActivity() {
    _uiState.update { it.copy(sessionSecondsRemaining = 90, showTimeoutWarning = false) }
  }

  fun extendSession() {
    _uiState.update { it.copy(sessionSecondsRemaining = 90, showTimeoutWarning = false) }
  }

  private fun speakIfEnabled(text: String) {
    audioHelper.speak(text, _uiState.value.accessibility.audioGuidance)
  }

  fun toggleLanguage() {
    touchActivity()
    val cur = _uiState.value
    if (cur.enabledLanguages.size <= 1) return
    val nextLang = if (cur.language == AppLanguage.EN) AppLanguage.ES else AppLanguage.EN
    audioHelper.setLanguage(nextLang.code)
    _uiState.update { it.copy(language = nextLang) }
    speakIfEnabled(Translations.get(TKey.HERO_TITLE, nextLang))
  }

  fun setLanguage(lang: AppLanguage) {
    touchActivity()
    if (lang !in _uiState.value.enabledLanguages) return
    audioHelper.setLanguage(lang.code)
    _uiState.update { it.copy(language = lang) }
  }

  fun navigateTo(flow: KioskFlow) {
    touchActivity()
    val cur = _uiState.value
    if (cur.activeFlow == flow) return
    val newStack = cur.backStack + cur.activeFlow
    var nextProd = cur.selectedProductId
    var nextRule = cur.selectedPricingRuleId
    if (flow == KioskFlow.BUY_CARD) {
      val buyProd = cur.products.firstOrNull { it.category != ProductCategory.RELOAD.name }
      if (buyProd != null) {
        nextProd = buyProd.productVersionId
        val rules = cur.pricingRulesByProduct[nextProd].orEmpty()
        nextRule = rules.firstOrNull { it.isDefault }?.pricingRuleId ?: rules.firstOrNull()?.pricingRuleId ?: ""
      }
    } else if (flow == KioskFlow.RELOAD_CARD) {
      val reloadProd = cur.products.firstOrNull { it.category == ProductCategory.RELOAD.name }
      if (reloadProd != null) {
        nextProd = reloadProd.productVersionId
        val rules = cur.pricingRulesByProduct[nextProd].orEmpty()
        nextRule = rules.firstOrNull { it.isDefault }?.pricingRuleId ?: rules.firstOrNull()?.pricingRuleId ?: ""
      }
    }

    val nextStep = when (flow) {
      KioskFlow.BUY_CARD, KioskFlow.RELOAD_CARD -> StepProgress.REVIEW_AND_PAY
      else -> StepProgress.CHOOSE
    }

    _uiState.update {
      it.copy(
        activeFlow = flow,
        backStack = newStack,
        selectedProductId = nextProd,
        selectedPricingRuleId = nextRule,
        checkoutPhase = CheckoutPhase.CONFIGURE,
        activeOrder = null,
        latestPaymentAttempt = null,
        executionOutcome = null,
        transientErrorBanner = null,
        stepProgress = nextStep,
      )
    }
    viewModelScope.launch { refreshQuote() }
  }

  fun goBack(): Boolean {
    touchActivity()
    val cur = _uiState.value
    if (cur.checkoutPhase != CheckoutPhase.CONFIGURE && cur.checkoutPhase != CheckoutPhase.PROCESSING_PAYMENT) {
      _uiState.update {
        it.copy(
          checkoutPhase = CheckoutPhase.CONFIGURE,
          stepProgress = StepProgress.REVIEW_AND_PAY,
          transientErrorBanner = null,
        )
      }
      return true
    }
    if (cur.backStack.isNotEmpty()) {
      val previous = cur.backStack.last()
      _uiState.update {
        it.copy(
          activeFlow = previous,
          backStack = cur.backStack.dropLast(1),
          checkoutPhase = CheckoutPhase.CONFIGURE,
          transientErrorBanner = null,
          authenticatedStaff = if (cur.activeFlow == KioskFlow.STAFF_WORKSPACE) null else cur.authenticatedStaff,
        )
      }
      return true
    }
    return false
  }

  fun startOver(expired: Boolean = false) {
    viewModelScope.launch {
      val oldSession = _uiState.value.sessionId
      if (oldSession.isNotBlank()) {
        backend.closeSession(oldSession, if (expired) "EXPIRED" else "CLEARED")
      }
      val newSession = backend.startAnonymousSession(_uiState.value.language)
      activePaymentIdempotencyKey = null
      activeFulfilmentIdempotencyKey = null
      val buyProd = _uiState.value.products.firstOrNull { it.productCode == "CARD_RELOADABLE_SV" }
        ?: _uiState.value.products.firstOrNull { it.category != ProductCategory.RELOAD.name }
      val prodId = buyProd?.productVersionId ?: "PROD-CARD-V1"
      val rules = _uiState.value.pricingRulesByProduct[prodId].orEmpty()
      val defaultRule = rules.firstOrNull { it.isDefault }?.pricingRuleId ?: rules.firstOrNull()?.pricingRuleId ?: "RULE-CARD-20"

      _uiState.update {
        it.copy(
          sessionId = newSession.sessionId,
          activeFlow = KioskFlow.BUY_CARD,
          backStack = emptyList(),
          stepProgress = StepProgress.REVIEW_AND_PAY,
          selectedProductId = prodId,
          selectedPricingRuleId = defaultRule,
          selectedPaymentMethod = PaymentMethod.CONTACTLESS_NFC,
          checkoutPhase = CheckoutPhase.CONFIGURE,
          activeOrder = null,
          latestPaymentAttempt = null,
          executionOutcome = null,
          identifiedCard = null,
          cardIdentifyError = null,
          transientErrorBanner = null,
          isBusy = false,
          showNetworkMapModal = false,
          showA11ySheet = false,
          showStaffAuthDialog = false,
          authenticatedStaff = null,
          sessionSecondsRemaining = 90,
          showTimeoutWarning = false,
        )
      }
      refreshQuote()
    }
  }

  fun selectProduct(productVersionId: String) {
    touchActivity()
    val rules = _uiState.value.pricingRulesByProduct[productVersionId].orEmpty()
    val defaultRule = rules.firstOrNull { it.isDefault }?.pricingRuleId ?: rules.firstOrNull()?.pricingRuleId ?: ""
    _uiState.update {
      it.copy(
        selectedProductId = productVersionId,
        selectedPricingRuleId = defaultRule,
        checkoutPhase = CheckoutPhase.CONFIGURE,
        transientErrorBanner = null,
      )
    }
    viewModelScope.launch { refreshQuote() }
  }

  fun selectPricingRule(pricingRuleId: String) {
    touchActivity()
    _uiState.update {
      it.copy(
        selectedPricingRuleId = pricingRuleId,
        checkoutPhase = CheckoutPhase.CONFIGURE,
        transientErrorBanner = null,
      )
    }
    viewModelScope.launch { refreshQuote() }
  }

  fun selectPaymentMethod(method: PaymentMethod) {
    touchActivity()
    if (method == PaymentMethod.CASH && !hardwareHealth.value.cashAcceptor.available) return
    _uiState.update { it.copy(selectedPaymentMethod = method, transientErrorBanner = null) }
  }

  private suspend fun refreshQuote() {
    val cur = _uiState.value
    if (cur.selectedProductId.isBlank() || cur.selectedPricingRuleId.isBlank()) return
    when (val res = backend.calculateServerQuote(cur.selectedProductId, cur.selectedPricingRuleId, cur.identifiedCard?.cardRef)) {
      is BackendResult.Success -> _uiState.update { it.copy(currentQuote = res.data, transientErrorBanner = null) }
      is BackendResult.Failure -> _uiState.update { it.copy(currentQuote = null, transientErrorBanner = res.message) }
    }
  }

  fun continueToPayment() {
    touchActivity()
    val cur = _uiState.value
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, transientErrorBanner = null) }
      val targetRef = if (cur.activeFlow == KioskFlow.RELOAD_CARD) cur.identifiedCard?.cardRef else null
      when (val res = backend.createPricedOrder(cur.sessionId, cur.selectedProductId, cur.selectedPricingRuleId, targetRef)) {
        is BackendResult.Failure -> {
          val localized = when (res.code) {
            "DISPENSER_UNAVAILABLE" -> Translations.get(TKey.ERROR_DISPENSER_OUT_OF_STOCK, cur.language)
            "CARD_BLOCKED" -> Translations.get(TKey.ERROR_CARD_BLOCKED, cur.language)
            else -> res.message
          }
          _uiState.update { it.copy(isBusy = false, transientErrorBanner = localized) }
          speakIfEnabled(localized)
        }
        is BackendResult.Success -> {
          activePaymentIdempotencyKey = "PAYKEY-${res.data.orderId}-1"
          activeFulfilmentIdempotencyKey = "FULKEY-${res.data.orderId}-1"
          _uiState.update {
            it.copy(
              isBusy = false,
              activeOrder = res.data,
              checkoutPhase = CheckoutPhase.AWAITING_TAP_OR_CHIP,
              stepProgress = StepProgress.REVIEW_AND_PAY,
            )
          }
          speakIfEnabled(Translations.get(TKey.PAYMENT_PROCESSING_TITLE, cur.language))
        }
      }
    }
  }

  fun submitSimulatedPayment() {
    touchActivity()
    val order = _uiState.value.activeOrder ?: return
    val method = _uiState.value.selectedPaymentMethod
    val payKey = activePaymentIdempotencyKey ?: "PAYKEY-${order.orderId}-1"
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, checkoutPhase = CheckoutPhase.PROCESSING_PAYMENT, transientErrorBanner = null) }
      when (val payRes = backend.processPayment(order.orderId, method, payKey)) {
        is BackendResult.Failure -> {
          _uiState.update { it.copy(isBusy = false, transientErrorBanner = payRes.message, checkoutPhase = CheckoutPhase.AWAITING_TAP_OR_CHIP) }
        }
        is BackendResult.Success -> {
          val attempt = payRes.data
          when (attempt.paymentState) {
            PaymentState.CONFIRMED.name -> {
              _uiState.update {
                it.copy(
                  latestPaymentAttempt = attempt,
                  checkoutPhase = CheckoutPhase.FULFILLING,
                  stepProgress = StepProgress.COLLECT,
                )
              }
              executeFulfilmentInternal(order.orderId)
            }
            PaymentState.DECLINED.name -> {
              // Generate fresh idempotency key for a genuine retry attempt
              activePaymentIdempotencyKey = "PAYKEY-${order.orderId}-${UUID.randomUUID().toString().take(4)}"
              _uiState.update {
                it.copy(
                  isBusy = false,
                  latestPaymentAttempt = attempt,
                  checkoutPhase = CheckoutPhase.PAYMENT_DECLINED,
                )
              }
              speakIfEnabled(Translations.get(TKey.PAYMENT_DECLINED_DESC, _uiState.value.language))
            }
            PaymentState.OUTCOME_UNKNOWN.name -> {
              _uiState.update {
                it.copy(
                  isBusy = false,
                  latestPaymentAttempt = attempt,
                  checkoutPhase = CheckoutPhase.PAYMENT_UNKNOWN,
                )
              }
              speakIfEnabled(Translations.get(TKey.PAYMENT_UNKNOWN_DESC, _uiState.value.language))
            }
            else -> {
              activePaymentIdempotencyKey = "PAYKEY-${order.orderId}-${UUID.randomUUID().toString().take(4)}"
              _uiState.update {
                it.copy(
                  isBusy = false,
                  latestPaymentAttempt = attempt,
                  checkoutPhase = CheckoutPhase.AWAITING_TAP_OR_CHIP,
                  transientErrorBanner = Translations.get(TKey.ERROR_READER_TIMEOUT, _uiState.value.language),
                )
              }
            }
          }
        }
      }
    }
  }

  private suspend fun executeFulfilmentInternal(orderId: String) {
    val fulKey = activeFulfilmentIdempotencyKey ?: "FULKEY-$orderId-1"
    when (val res = backend.fulfillPaidOrder(orderId, fulKey)) {
      is BackendResult.Failure -> {
        _uiState.update { it.copy(isBusy = false, transientErrorBanner = res.message, checkoutPhase = CheckoutPhase.RECOVERY_CLAIM) }
      }
      is BackendResult.Success -> {
        val outcome = res.data
        val isReload = _uiState.value.activeFlow == KioskFlow.RELOAD_CARD
        val nextPhase = when {
          outcome.reconciliationCase != null -> CheckoutPhase.RECOVERY_CLAIM
          isReload -> CheckoutPhase.COMPLETED
          else -> CheckoutPhase.READY_TO_COLLECT
        }
        _uiState.update {
          it.copy(
            isBusy = false,
            activeOrder = outcome.order,
            executionOutcome = outcome,
            identifiedCard = outcome.updatedCardSnapshot ?: it.identifiedCard,
            checkoutPhase = nextPhase,
            stepProgress = StepProgress.COLLECT,
          )
        }
      }
    }
  }

  fun confirmCardCollected() {
    touchActivity()
    val orderId = _uiState.value.activeOrder?.orderId ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true) }
      when (val res = backend.confirmCardCollection(orderId)) {
        is BackendResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              activeOrder = res.data.order,
              executionOutcome = res.data,
              checkoutPhase = CheckoutPhase.COMPLETED,
            )
          }
        }
        is BackendResult.Failure -> {
          _uiState.update { it.copy(isBusy = false, transientErrorBanner = res.message) }
        }
      }
    }
  }

  fun runReconciliationNow() {
    touchActivity()
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true) }
      reconciliationWorker.runSinglePass()
      val orderId = _uiState.value.activeOrder?.orderId
      if (orderId != null) {
        val refreshedOrder = dao.getOrder(orderId)
        val refreshedOp = dao.getLatestFulfilmentForOrder(orderId)
        val refreshedPay = dao.getPaymentsForOrder(orderId).firstOrNull()
        val refreshedRec = dao.getReceiptForOrder(orderId)
        val refreshedCase = dao.getReconciliationForOrder(orderId)
        val refreshedSnap = refreshedOp?.issuedOrUpdatedCardRef?.let { hardwareEngine.fetchAuthoritativeCard(it) }
        val nextPhase = when {
          refreshedOrder?.orderState == "COMPLETED" -> CheckoutPhase.COMPLETED
          refreshedOp?.fulfilmentState == "DISPENSED_AWAITING_COLLECTION" -> CheckoutPhase.READY_TO_COLLECT
          else -> _uiState.value.checkoutPhase
        }
        _uiState.update {
          it.copy(
            isBusy = false,
            activeOrder = refreshedOrder,
            latestPaymentAttempt = refreshedPay,
            executionOutcome = if (refreshedOrder != null) {
              OrderExecutionOutcome(refreshedOrder, refreshedPay, refreshedOp, refreshedRec, refreshedCase, refreshedSnap)
            } else it.executionOutcome,
            checkoutPhase = nextPhase,
          )
        }
      } else {
        _uiState.update { it.copy(isBusy = false) }
      }
    }
  }

  fun retryDeclinedPayment() {
    touchActivity()
    _uiState.update { it.copy(checkoutPhase = CheckoutPhase.AWAITING_TAP_OR_CHIP, transientErrorBanner = null) }
  }

  // --- Transit Card Identification (Check Balance & Reload) ---
  fun identifyTransitCard(simulatedCardRef: String) {
    touchActivity()
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, cardIdentifyError = null) }
      val (res, snap) = backend.identifyTransitCard(simulatedCardRef)
      if (!res.success || snap == null) {
        val msg = when (res.error?.code) {
          "READER_TIMEOUT" -> Translations.get(TKey.ERROR_READER_TIMEOUT, _uiState.value.language)
          else -> res.error?.message ?: "Unsupported card"
        }
        _uiState.update { it.copy(isBusy = false, identifiedCard = null, cardIdentifyError = msg) }
      } else {
        val blockedMsg = if (snap.status == "BLOCKED") Translations.get(TKey.ERROR_CARD_BLOCKED, _uiState.value.language) else null
        _uiState.update {
          it.copy(
            isBusy = false,
            identifiedCard = snap,
            cardIdentifyError = blockedMsg,
          )
        }
        refreshQuote()
      }
    }
  }

  fun jumpToReloadIdentifiedCard() {
    val card = _uiState.value.identifiedCard ?: return
    navigateTo(KioskFlow.RELOAD_CARD)
    _uiState.update { it.copy(identifiedCard = card) }
  }

  // --- Journey Planner ---
  fun setJourneyOrigin(id: String) {
    touchActivity()
    _uiState.update { it.copy(originStationId = id) }
    recomputeJourney()
  }

  fun setJourneyDestination(id: String) {
    touchActivity()
    _uiState.update { it.copy(destinationStationId = id) }
    recomputeJourney()
  }

  fun toggleAccessibleRoute(enabled: Boolean) {
    touchActivity()
    _uiState.update { it.copy(accessibleRouteOnly = enabled) }
    recomputeJourney()
  }

  fun recomputeJourney() {
    val cur = _uiState.value
    val plan = transitDataAdapter.planJourney(cur.originStationId, cur.destinationStationId, cur.accessibleRouteOnly)
    _uiState.update { it.copy(journeyPlan = plan) }
  }

  // --- Accessibility & Modals ---
  fun setShowNetworkMap(show: Boolean) {
    touchActivity()
    _uiState.update { it.copy(showNetworkMapModal = show) }
  }

  fun setShowA11ySheet(show: Boolean) {
    touchActivity()
    _uiState.update { it.copy(showA11ySheet = show) }
  }

  fun updateAccessibility(transform: (AccessibilitySettings) -> AccessibilitySettings) {
    touchActivity()
    _uiState.update { it.copy(accessibility = transform(it.accessibility)) }
  }

  // --- Staff Authentication & Actions ---
  fun openStaffAuthDialog() {
    _uiState.update { it.copy(showStaffAuthDialog = true, staffAuthError = null) }
  }

  fun dismissStaffAuthDialog() {
    _uiState.update { it.copy(showStaffAuthDialog = false, staffAuthError = null) }
  }

  fun authenticateStaff(staffId: String, pin: String) {
    viewModelScope.launch {
      when (val res = backend.authenticateStaff(staffId, pin)) {
        is BackendResult.Failure -> _uiState.update { it.copy(staffAuthError = res.message) }
        is BackendResult.Success -> {
          _uiState.update {
            it.copy(
              showStaffAuthDialog = false,
              staffAuthError = null,
              authenticatedStaff = res.data,
              activeFlow = KioskFlow.STAFF_WORKSPACE,
              backStack = it.backStack + it.activeFlow,
            )
          }
        }
      }
    }
  }

  fun logoutStaff() {
    _uiState.update {
      it.copy(
        authenticatedStaff = null,
        activeFlow = KioskFlow.BUY_CARD,
        backStack = emptyList(),
      )
    }
  }

  fun staffPublishNewPrice(productCode: String, issueFeeCents: Int, optionsCents: List<Int>, onMessage: (String) -> Unit) {
    val staff = _uiState.value.authenticatedStaff ?: return
    viewModelScope.launch {
      when (val res = backend.staffPublishNewProductPriceVersion(staff, productCode, optionsCents, issueFeeCents)) {
        is BackendResult.Success -> onMessage("Published ${res.data.productCode} v${res.data.versionNumber}")
        is BackendResult.Failure -> onMessage("Denied: ${res.message}")
      }
    }
  }

  fun staffRequestRefund(orderId: String, reason: String, onMessage: (String) -> Unit) {
    val staff = _uiState.value.authenticatedStaff ?: return
    viewModelScope.launch {
      when (val res = backend.staffRequestRefund(staff, orderId, reason)) {
        is BackendResult.Success -> onMessage("Status: ${res.data.status} (${res.data.refundId})")
        is BackendResult.Failure -> onMessage("Error: ${res.message}")
      }
    }
  }

  fun staffSettleRefund(refundId: String, onMessage: (String) -> Unit) {
    val staff = _uiState.value.authenticatedStaff ?: return
    viewModelScope.launch {
      when (val res = backend.staffApproveAndSettleRefund(staff, refundId)) {
        is BackendResult.Success -> onMessage("Refund settled (${res.data.refundId})")
        is BackendResult.Failure -> onMessage("Denied: ${res.message}")
      }
    }
  }

  fun staffResolveCase(caseId: String, note: String, onMessage: (String) -> Unit) {
    val staff = _uiState.value.authenticatedStaff ?: return
    viewModelScope.launch {
      when (val res = backend.staffResolveExceptionalFulfilment(staff, caseId, note)) {
        is BackendResult.Success -> onMessage("Resolved ${res.data.caseId}")
        is BackendResult.Failure -> onMessage("Denied: ${res.message}")
      }
    }
  }

  fun staffToggleSpanishEnabled(enabled: Boolean, onMessage: (String) -> Unit) {
    val staff = _uiState.value.authenticatedStaff ?: return
    val csv = if (enabled) "en,es" else "en"
    viewModelScope.launch {
      when (val res = backend.staffToggleLanguageSupport(staff, csv)) {
        is BackendResult.Success -> onMessage("Language config updated: $csv")
        is BackendResult.Failure -> onMessage("Denied: ${res.message}")
      }
    }
  }

  fun runDemoScenario(scenario: String) {
    touchActivity()
    when (scenario) {
      "NORMAL_BUY" -> {
        hardwareEngine.setPaymentFaultMode(PaymentFaultMode.NORMAL)
        hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.NORMAL)
        startOver()
      }
      "RELOAD" -> {
        hardwareEngine.setPaymentFaultMode(PaymentFaultMode.NORMAL)
        hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.NORMAL)
        navigateTo(KioskFlow.RELOAD_CARD)
        identifyTransitCard("CRD-4829-1104")
      }
      "DECLINE" -> {
        hardwareEngine.setPaymentFaultMode(PaymentFaultMode.DECLINE)
        hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.NORMAL)
        navigateTo(KioskFlow.BUY_CARD)
        continueToPayment()
      }
      "UNKNOWN_PAYMENT" -> {
        hardwareEngine.setPaymentFaultMode(PaymentFaultMode.OUTCOME_UNKNOWN)
        hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.NORMAL)
        navigateTo(KioskFlow.BUY_CARD)
        continueToPayment()
      }
      "DISPENSER_JAM" -> {
        hardwareEngine.setPaymentFaultMode(PaymentFaultMode.NORMAL)
        hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.DISPENSER_JAM)
        navigateTo(KioskFlow.BUY_CARD)
        continueToPayment()
      }
    }
  }

  override fun onCleared() {
    super.onCleared()
    reconciliationWorker.stop()
    idleTimerJob?.cancel()
    audioHelper.shutdown()
  }
}
