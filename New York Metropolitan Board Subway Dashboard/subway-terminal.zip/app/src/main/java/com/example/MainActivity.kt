package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.model.KioskFlow
import com.example.hardware.FulfilmentFaultMode
import com.example.hardware.PaymentFaultMode
import com.example.ui.KioskViewModel
import com.example.ui.components.CompactNavigationStrip
import com.example.ui.components.KioskFooterBar
import com.example.ui.components.KioskHeaderBar
import com.example.ui.components.KioskSubHeader
import com.example.ui.components.LeftNavigationSidebar
import com.example.ui.components.SessionTimeoutBanner
import com.example.ui.screens.AccessibilityQuickDialog
import com.example.ui.screens.CheckBalancePane
import com.example.ui.screens.HelpAccessibilityPane
import com.example.ui.screens.JourneyPlannerPane
import com.example.ui.screens.NetworkMapDialog
import com.example.ui.screens.OrderSummaryPane
import com.example.ui.screens.PurchaseCentrePane
import com.example.ui.screens.ReloadCardPane
import com.example.ui.screens.StaffAuthDialog
import com.example.ui.screens.StaffWorkspacePane
import com.example.ui.theme.LocalKioskTokens
import com.example.ui.theme.SubwayTerminalTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val vm: KioskViewModel = viewModel()
      SubwayTerminalAppRoot(vm = vm)
    }
  }
}

@Composable
fun SubwayTerminalAppRoot(vm: KioskViewModel) {
  val uiState by vm.uiState.collectAsStateWithLifecycle()
  val hardwareHealth by vm.hardwareHealth.collectAsStateWithLifecycle()
  val terminal by vm.terminalState.collectAsStateWithLifecycle()
  val productVersions by vm.allProductVersions.collectAsStateWithLifecycle()
  val recentOrders by vm.recentOrders.collectAsStateWithLifecycle()
  val reconciliationCases by vm.reconciliationCases.collectAsStateWithLifecycle()
  val refunds by vm.refunds.collectAsStateWithLifecycle()
  val deviceEvents by vm.deviceEvents.collectAsStateWithLifecycle()
  val auditEvents by vm.auditEvents.collectAsStateWithLifecycle()

  SubwayTerminalTheme(accessibility = uiState.accessibility) {
    val tokens = LocalKioskTokens.current
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxSize()
        .background(tokens.workspaceBg),
    ) {
      val isWideThreeColumn = maxWidth >= 800.dp

      Column(modifier = Modifier.fillMaxSize()) {
        KioskHeaderBar(
          operatorTitle = uiState.operatorTitle,
          badgeCode = uiState.operatorBadgeCode,
          badgeColorHex = uiState.operatorBadgeColor,
          language = uiState.language,
          canToggleLanguage = uiState.enabledLanguages.size > 1,
          onToggleLanguage = vm::toggleLanguage,
          onOpenAccessibility = { vm.setShowA11ySheet(true) },
          compact = !isWideThreeColumn,
        )

        KioskSubHeader(
          language = uiState.language,
          activeStep = uiState.stepProgress,
          compact = !isWideThreeColumn,
        )

        if (uiState.showTimeoutWarning) {
          SessionTimeoutBanner(
            language = uiState.language,
            secondsRemaining = uiState.sessionSecondsRemaining,
            onExtendSession = vm::extendSession,
          )
        }

        if (!isWideThreeColumn && uiState.activeFlow != KioskFlow.STAFF_WORKSPACE) {
          CompactNavigationStrip(
            language = uiState.language,
            activeFlow = uiState.activeFlow,
            onSelectFlow = vm::navigateTo,
          )
        }

        val showSummaryColumn = uiState.activeFlow == KioskFlow.BUY_CARD || uiState.activeFlow == KioskFlow.RELOAD_CARD

        if (isWideThreeColumn) {
          Row(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
          ) {
            if (uiState.activeFlow != KioskFlow.STAFF_WORKSPACE) {
              LeftNavigationSidebar(
                language = uiState.language,
                activeFlow = uiState.activeFlow,
                onSelectFlow = vm::navigateTo,
                onOpenNetworkMap = { vm.setShowNetworkMap(true) },
                modifier = Modifier
                  .weight(0.24f)
                  .fillMaxHeight()
                  .verticalScroll(rememberScrollState()),
              )
              Box(
                modifier = Modifier
                  .width(1.5.dp)
                  .fillMaxHeight()
                  .background(tokens.divider),
              )
            }

            Box(
              modifier = Modifier
                .weight(if (showSummaryColumn) 0.46f else 0.76f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            ) {
              ActiveCenterContent(
                vm = vm,
                uiState = uiState,
                hardwareHealth = hardwareHealth,
                terminal = terminal,
                productVersions = productVersions,
                recentOrders = recentOrders,
                reconciliationCases = reconciliationCases,
                refunds = refunds,
                deviceEvents = deviceEvents,
                auditEvents = auditEvents,
              )
            }

            if (showSummaryColumn) {
              Box(
                modifier = Modifier
                  .width(1.5.dp)
                  .fillMaxHeight()
                  .background(tokens.divider),
              )
              OrderSummaryPane(
                uiState = uiState,
                onContinueToPayment = vm::continueToPayment,
                modifier = Modifier
                  .weight(0.30f)
                  .fillMaxHeight()
                  .verticalScroll(rememberScrollState())
                  .padding(16.dp),
              )
            }
          }
        } else {
          // Compact Portrait Phone Layout: cleanly stacked vertically
          Column(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            ActiveCenterContent(
              vm = vm,
              uiState = uiState,
              hardwareHealth = hardwareHealth,
              terminal = terminal,
              productVersions = productVersions,
              recentOrders = recentOrders,
              reconciliationCases = reconciliationCases,
              refunds = refunds,
              deviceEvents = deviceEvents,
              auditEvents = auditEvents,
            )
            if (showSummaryColumn) {
              OrderSummaryPane(
                uiState = uiState,
                onContinueToPayment = vm::continueToPayment,
                modifier = Modifier.fillMaxWidth(),
              )
            }
          }
        }

        KioskFooterBar(
          language = uiState.language,
          canGoBack = uiState.backStack.isNotEmpty() || uiState.checkoutPhase != com.example.ui.CheckoutPhase.CONFIGURE,
          onBack = { vm.goBack() },
          onStartOver = { vm.startOver() },
          onGetHelp = { vm.navigateTo(KioskFlow.HELP_ACCESSIBILITY) },
          compact = !isWideThreeColumn,
        )
      }

      if (uiState.showNetworkMapModal) {
        NetworkMapDialog(
          language = uiState.language,
          stations = uiState.stations,
          onDismiss = { vm.setShowNetworkMap(false) },
        )
      }

      if (uiState.showA11ySheet) {
        AccessibilityQuickDialog(
          language = uiState.language,
          settings = uiState.accessibility,
          sessionSeconds = uiState.sessionSecondsRemaining,
          onUpdate = vm::updateAccessibility,
          onExtendSession = vm::extendSession,
          onDismiss = { vm.setShowA11ySheet(false) },
        )
      }

      if (uiState.showStaffAuthDialog) {
        StaffAuthDialog(
          language = uiState.language,
          error = uiState.staffAuthError,
          onAuthenticate = vm::authenticateStaff,
          onDismiss = vm::dismissStaffAuthDialog,
        )
      }
    }
  }
}

@Composable
private fun ActiveCenterContent(
  vm: KioskViewModel,
  uiState: com.example.ui.KioskMainUiState,
  hardwareHealth: com.example.hardware.HardwareHealthSnapshot,
  terminal: com.example.data.local.TerminalEntity?,
  productVersions: List<com.example.data.local.ProductVersionEntity>,
  recentOrders: List<com.example.data.local.OrderEntity>,
  reconciliationCases: List<com.example.data.local.ReconciliationCaseEntity>,
  refunds: List<com.example.data.local.RefundEntity>,
  deviceEvents: List<com.example.data.local.DeviceEventEntity>,
  auditEvents: List<com.example.data.local.AuditEventEntity>,
) {
  when (uiState.activeFlow) {
    KioskFlow.BUY_CARD -> PurchaseCentrePane(
      uiState = uiState,
      hardwareHealth = hardwareHealth,
      onSelectProduct = vm::selectProduct,
      onSelectRule = vm::selectPricingRule,
      onSelectPaymentMethod = vm::selectPaymentMethod,
      onSimulateTapOrChip = vm::submitSimulatedPayment,
      onRetryDeclined = vm::retryDeclinedPayment,
      onConfirmCollected = vm::confirmCardCollected,
      onRunReconciliation = vm::runReconciliationNow,
      onFinishClearSession = { vm.startOver() },
      onBackFromCheckout = { vm.goBack() },
    )

    KioskFlow.RELOAD_CARD -> ReloadCardPane(
      uiState = uiState,
      hardwareHealth = hardwareHealth,
      onIdentifyCard = vm::identifyTransitCard,
      onSelectRule = vm::selectPricingRule,
      onSelectPaymentMethod = vm::selectPaymentMethod,
      onSimulateTapOrChip = vm::submitSimulatedPayment,
      onRetryDeclined = vm::retryDeclinedPayment,
      onConfirmCollected = vm::confirmCardCollected,
      onRunReconciliation = vm::runReconciliationNow,
      onFinishClearSession = { vm.startOver() },
      onBack = { vm.goBack() },
    )

    KioskFlow.CHECK_BALANCE -> CheckBalancePane(
      uiState = uiState,
      onIdentifyCard = vm::identifyTransitCard,
      onReloadIdentified = vm::jumpToReloadIdentifiedCard,
      onBack = { vm.goBack() },
    )

    KioskFlow.PLAN_JOURNEY -> JourneyPlannerPane(
      uiState = uiState,
      onSelectOrigin = vm::setJourneyOrigin,
      onSelectDestination = vm::setJourneyDestination,
      onToggleAccessible = vm::toggleAccessibleRoute,
      onOpenNetworkMap = { vm.setShowNetworkMap(true) },
      onBack = { vm.goBack() },
    )

    KioskFlow.HELP_ACCESSIBILITY -> HelpAccessibilityPane(
      uiState = uiState,
      onUpdateAccessibility = vm::updateAccessibility,
      onExtendSession = vm::extendSession,
      onRunScenario = vm::runDemoScenario,
      onOpenStaffLogin = vm::openStaffAuthDialog,
      onBack = { vm.goBack() },
    )

    KioskFlow.STAFF_WORKSPACE -> {
      val staff = uiState.authenticatedStaff
      if (staff != null) {
        StaffWorkspacePane(
          staff = staff,
          language = uiState.language,
          terminal = terminal,
          hardwareHealth = hardwareHealth,
          productVersions = productVersions,
          recentOrders = recentOrders,
          reconciliationCases = reconciliationCases,
          refunds = refunds,
          deviceEvents = deviceEvents,
          auditEvents = auditEvents,
          onSetPaymentFault = vm.hardwareEngine::setPaymentFaultMode,
          onSetFulfilmentFault = vm.hardwareEngine::setFulfilmentFaultMode,
          onToggleCashAdapter = vm.hardwareEngine::setCashAdapterAvailable,
          onClearJamRestock = {
            vm.hardwareEngine.setFulfilmentFaultMode(FulfilmentFaultMode.NORMAL)
            vm.hardwareEngine.setPaymentFaultMode(PaymentFaultMode.NORMAL)
            vm.hardwareEngine.setCardStock(48)
          },
          onRefillPaper = { vm.hardwareEngine.setPrinterPaperPercent(100) },
          onPublishNewPrice = vm::staffPublishNewPrice,
          onRequestRefund = vm::staffRequestRefund,
          onSettleRefund = vm::staffSettleRefund,
          onResolveCase = vm::staffResolveCase,
          onToggleSpanish = vm::staffToggleSpanishEnabled,
          onLogout = vm::logoutStaff,
        )
      }
    }
  }
}
