package com.example.backend

import com.example.data.local.TerminalDao
import com.example.domain.model.FulfilmentState
import com.example.domain.model.OrderState
import com.example.domain.model.PaymentState
import com.example.domain.model.ReconciliationStatus
import com.example.hardware.PaymentTerminalAdapter
import com.example.hardware.TravelProductFulfilmentService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Background reconciliation worker resolving OUTCOME_UNKNOWN payments and LOST_RESPONSE
 * fulfilment operations idempotently without charging or reloading twice.
 */
class ReconciliationWorker(
  private val dao: TerminalDao,
  private val paymentAdapter: PaymentTerminalAdapter,
  private val fulfilmentService: TravelProductFulfilmentService,
  private val backendService: TerminalBackendService,
) {
  private var job: Job? = null

  fun start(scope: CoroutineScope, intervalMs: Long = 10_000L) {
    job?.cancel()
    job = scope.launch {
      while (isActive) {
        runSinglePass()
        delay(intervalMs)
      }
    }
  }

  fun stop() {
    job?.cancel()
  }

  suspend fun runSinglePass(): Int {
    var resolvedCount = 0

    // 1. Reconcile UNKNOWN_PAYMENT attempts
    val unknownPayments = dao.getUnknownOutcomePayments()
    for (attempt in unknownPayments) {
      val authOutcome = paymentAdapter.queryAuthoritativeOutcome(attempt.idempotencyKey)
      if (authOutcome.state == PaymentState.CONFIRMED) {
        val now = System.currentTimeMillis()
        dao.updatePaymentAttempt(
          attempt.copy(
            paymentState = PaymentState.CONFIRMED.name,
            paymentSubState = authOutcome.subState.name,
            providerEventId = authOutcome.providerEventId,
            errorCode = null,
            updatedAtMs = now,
          )
        )
        dao.getOrder(attempt.orderId)?.let { order ->
          dao.upsertOrder(order.copy(orderState = OrderState.PAYMENT_CONFIRMED.name, updatedAtMs = now))
        }
        // Fulfil idempotently using deterministic key tied to orderId
        backendService.fulfillPaidOrder(attempt.orderId, "REC-FUL-${attempt.orderId}")
        dao.getReconciliationForOrder(attempt.orderId)?.let { recon ->
          dao.upsertReconciliationCase(
            recon.copy(
              status = ReconciliationStatus.AUTO_RESOLVED.name,
              resolutionNote = "Background worker verified capture (${authOutcome.providerEventId}) and completed fulfilment.",
              resolvedBy = "RECONCILIATION_WORKER",
              updatedAtMs = now,
            )
          )
        }
        resolvedCount++
      } else if (authOutcome.state == PaymentState.CANCELLED || authOutcome.state == PaymentState.DECLINED) {
        val now = System.currentTimeMillis()
        dao.updatePaymentAttempt(
          attempt.copy(
            paymentState = authOutcome.state.name,
            paymentSubState = authOutcome.subState.name,
            updatedAtMs = now,
          )
        )
        dao.getOrder(attempt.orderId)?.let { order ->
          dao.upsertOrder(order.copy(orderState = OrderState.CANCELLED.name, updatedAtMs = now))
        }
        dao.getReconciliationForOrder(attempt.orderId)?.let { recon ->
          dao.upsertReconciliationCase(
            recon.copy(
              status = ReconciliationStatus.AUTO_RESOLVED.name,
              resolutionNote = "Gateway confirmed no capture; transaction reversed.",
              resolvedBy = "RECONCILIATION_WORKER",
              updatedAtMs = now,
            )
          )
        }
        resolvedCount++
      }
    }

    // 2. Reconcile LOST_RESPONSE cases idempotently
    val openCases = dao.getOpenReconciliationCases()
    for (recon in openCases) {
      if (recon.caseType == "LOST_RESPONSE") {
        val op = dao.getLatestFulfilmentForOrder(recon.orderId) ?: continue
        val order = dao.getOrder(recon.orderId) ?: continue
        val check = op.issuedOrUpdatedCardRef?.let { fulfilmentService.fetchAuthoritativeCard(it) }
        if (check != null) {
          val now = System.currentTimeMillis()
          dao.updateFulfilment(op.copy(fulfilmentState = FulfilmentState.RECOVERED.name, errorCode = null, updatedAtMs = now))
          dao.upsertOrder(order.copy(orderState = OrderState.COMPLETED.name, updatedAtMs = now))
          dao.upsertReconciliationCase(
            recon.copy(
              status = ReconciliationStatus.AUTO_RESOLVED.name,
              resolutionNote = "Verified host commit (${op.externalFulfilmentRef}) without duplicate fulfilment.",
              resolvedBy = "RECONCILIATION_WORKER",
              updatedAtMs = now,
            )
          )
          resolvedCount++
        }
      }
    }

    return resolvedCount
  }
}
