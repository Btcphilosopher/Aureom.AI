package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.domain.model.AccessibilitySettings

data class KioskTokens(
  val headerBg: Color,
  val headerFg: Color,
  val workspaceBg: Color,
  val panelBg: Color,
  val divider: Color,
  val border: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val accentBlue: Color,
  val selectedCardBlue: Color,
  val promptBannerBg: Color,
  val promptBannerBorder: Color,
  val highContrast: Boolean,
  val reducedMotion: Boolean,
  val largeText: Boolean,
)

val LocalKioskTokens = staticCompositionLocalOf {
  KioskTokens(
    headerBg = MatteBlack,
    headerFg = PureWhite,
    workspaceBg = PaleWorkspace,
    panelBg = PureWhite,
    divider = SubtleDivider,
    border = CardBorderGrey,
    textPrimary = MatteBlack,
    textSecondary = MutedText,
    accentBlue = TransitBlueBright,
    selectedCardBlue = TransitBluePrimary,
    promptBannerBg = TransitBlueTint,
    promptBannerBorder = TransitBlueTintBorder,
    highContrast = false,
    reducedMotion = false,
    largeText = false,
  )
}

@Composable
fun SubwayTerminalTheme(
  accessibility: AccessibilitySettings = AccessibilitySettings(),
  content: @Composable () -> Unit,
) {
  val tokens = if (accessibility.highContrast) {
    KioskTokens(
      headerBg = HighContrastBlack,
      headerFg = HighContrastYellow,
      workspaceBg = PureWhite,
      panelBg = PureWhite,
      divider = HighContrastBlack,
      border = HighContrastBlack,
      textPrimary = HighContrastBlack,
      textSecondary = HighContrastBlack,
      accentBlue = HighContrastBlue,
      selectedCardBlue = HighContrastBlack,
      promptBannerBg = HighContrastYellow.copy(alpha = 0.25f),
      promptBannerBorder = HighContrastBlack,
      highContrast = true,
      reducedMotion = accessibility.reducedMotion,
      largeText = accessibility.largeText,
    )
  } else {
    KioskTokens(
      headerBg = MatteBlack,
      headerFg = PureWhite,
      workspaceBg = PaleWorkspace,
      panelBg = PureWhite,
      divider = SubtleDivider,
      border = CardBorderGrey,
      textPrimary = MatteBlack,
      textSecondary = MutedText,
      accentBlue = TransitBlueBright,
      selectedCardBlue = TransitBluePrimary,
      promptBannerBg = TransitBlueTint,
      promptBannerBorder = TransitBlueTintBorder,
      highContrast = false,
      reducedMotion = accessibility.reducedMotion,
      largeText = accessibility.largeText,
    )
  }

  val colorScheme = lightColorScheme(
    primary = tokens.accentBlue,
    onPrimary = PureWhite,
    secondary = tokens.selectedCardBlue,
    onSecondary = PureWhite,
    background = tokens.workspaceBg,
    onBackground = tokens.textPrimary,
    surface = tokens.panelBg,
    onSurface = tokens.textPrimary,
    surfaceVariant = PaleWorkspace,
    onSurfaceVariant = tokens.textSecondary,
    outline = tokens.border,
  )

  CompositionLocalProvider(LocalKioskTokens provides tokens) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = buildKioskTypography(accessibility.largeText),
      content = content,
    )
  }
}
