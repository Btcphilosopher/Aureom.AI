package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.backend.BackendResult
import com.example.backend.ReconciliationWorker
import com.example.backend.SyntheticNycTransitDataAdapter
import com.example.backend.TerminalBackendService
import com.example.core.i18n.AppLanguage
import com.example.core.security.LogRedactor
import com.example.data.local.DatabaseSeeder
import com.example.data.local.TerminalDatabase
import com.example.domain.model.FulfilmentState
import com.example.domain.model.OrderState
import com.example.domain.model.PaymentMethod
import com.example.domain.model.PaymentState
import com.example.domain.model.ReconciliationStatus
import com.example.domain.model.RefundStatus
import com.example.domain.model.StaffRole
import com.example.hardware.FulfilmentFaultMode
import com.example.hardware.PaymentFaultMode
import com.example.hardware.SimulatedHardwareEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TerminalBackendTest {

  private lateinit var app: Application
  private lateinit var db: TerminalDatabase
  private lateinit var hw: SimulatedHardwareEngine
  private lateinit var backend: TerminalBackendService
  private lateinit var worker: ReconciliationWorker

  @Before
  fun setup() {
    app = ApplicationProvider.getApplicationContext()
    db = TerminalDatabase.createInMemory(app)
    val dao = db.terminalDao()
    DatabaseSeeder.seedBlocking(dao)
    hw = SimulatedHardwareEngine(dao, simulatedDelayMs = 0L)
    backend = TerminalBackendService(dao, hw, hw, hw, hw, hw)
    worker = ReconciliationWorker(dao, hw, hw, backend)
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `1 price calculation uses integer cents for $20 stored value plus $1 issue fee`() = runTest {
    val res = backend.calculateServerQuote("PROD-CARD-V1", "RULE-CARD-20")
    assertTrue(res is BackendResult.Success)
    val quote = (res as BackendResult.Success).data
    assertEquals(2000, quote.storedValueCents)
    assertEquals(100, quote.cardIssueFeeCents)
    assertEquals(2100, quote.totalCents)
  }

  @Test
  fun `2 product version preservation keeps v1 prices on existing order after v2 publish`() = runTest {
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val v1Order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    assertEquals(1, v1Order.productVersionNumber)
    assertEquals(2100, v1Order.totalCents)

    val supervisor = (backend.authenticateStaff("SUP-201", "5678") as BackendResult.Success).data
    val pub = backend.staffPublishNewProductPriceVersion(supervisor, "CARD_RELOADABLE_SV", listOf(1000, 2000, 4000), 200)
    assertTrue(pub is BackendResult.Success)

    val fetchedV1 = db.terminalDao().getOrder(v1Order.orderId)!!
    assertEquals(1, fetchedV1.productVersionNumber)
    assertEquals(2100, fetchedV1.totalCents)
  }

  @Test
  fun `3 duplicate payment event with same idempotency key never charges twice`() = runTest {
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    val first = (backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "KEY-DUP-1") as BackendResult.Success).data
    val second = (backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "KEY-DUP-1") as BackendResult.Success).data
    assertEquals(first.paymentAttemptId, second.paymentAttemptId)
    assertEquals(1, db.terminalDao().getPaymentsForOrder(order.orderId).size)
  }

  @Test
  fun `4 repeated reload requests with same key or order do not double credit balance`() = runTest {
    val initial = hw.fetchAuthoritativeCard("CRD-4829-1104")!!.authoritativeBalanceCents
    assertEquals(1250, initial)

    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-RELOAD-V1", "RULE-RELOAD-20", "CRD-4829-1104") as BackendResult.Success).data
    backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "PAY-RLD-1")

    val ful1 = (backend.fulfillPaidOrder(order.orderId, "FUL-RLD-1") as BackendResult.Success).data
    val ful2 = (backend.fulfillPaidOrder(order.orderId, "FUL-RLD-1") as BackendResult.Success).data
    val ful3 = (backend.fulfillPaidOrder(order.orderId, "FUL-RLD-DIFFERENT-KEY") as BackendResult.Success).data

    assertEquals(3250, ful1.updatedCardSnapshot!!.authoritativeBalanceCents)
    assertEquals(3250, ful2.updatedCardSnapshot!!.authoritativeBalanceCents)
    assertEquals(3250, ful3.updatedCardSnapshot!!.authoritativeBalanceCents)
    assertEquals(3250, hw.fetchAuthoritativeCard("CRD-4829-1104")!!.authoritativeBalanceCents)
  }

  @Test
  fun `5 lost response recovers idempotently without duplicate reload`() = runTest {
    hw.setFulfilmentFaultMode(FulfilmentFaultMode.PROVISION_SUCCEEDED_RESPONSE_LOST)
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-RELOAD-V1", "RULE-RELOAD-10", "CRD-4829-1104") as BackendResult.Success).data
    backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "PAY-LOST-1")
    val lostOutcome = (backend.fulfillPaidOrder(order.orderId, "FUL-LOST-1") as BackendResult.Success).data

    assertEquals(FulfilmentState.PROVISIONED_RESPONSE_LOST.name, lostOutcome.fulfilment!!.fulfilmentState)
    assertNotNull(lostOutcome.reconciliationCase)
    assertEquals("LOST_RESPONSE", lostOutcome.reconciliationCase!!.caseType)

    val resolved = worker.runSinglePass()
    assertEquals(1, resolved)
    assertEquals(2250, hw.fetchAuthoritativeCard("CRD-4829-1104")!!.authoritativeBalanceCents)
    assertEquals(OrderState.COMPLETED.name, db.terminalDao().getOrder(order.orderId)!!.orderState)
  }

  @Test
  fun `6 unknown payment outcome is reconciled automatically by background worker`() = runTest {
    hw.setPaymentFaultMode(PaymentFaultMode.OUTCOME_UNKNOWN)
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    val attempt = (backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "PAY-UNK-1") as BackendResult.Success).data
    assertEquals(PaymentState.OUTCOME_UNKNOWN.name, attempt.paymentState)
    assertEquals(OrderState.NEEDS_RECONCILIATION.name, db.terminalDao().getOrder(order.orderId)!!.orderState)

    val resolved = worker.runSinglePass()
    assertEquals(1, resolved)
    val recon = db.terminalDao().getReconciliationForOrder(order.orderId)!!
    assertEquals(ReconciliationStatus.AUTO_RESOLVED.name, recon.status)
    assertEquals(PaymentState.CONFIRMED.name, db.terminalDao().getPaymentsForOrder(order.orderId).first().paymentState)
  }

  @Test
  fun `7 dispenser jam preserves claim and printer unavailable still provides digital receipt`() = runTest {
    hw.setFulfilmentFaultMode(FulfilmentFaultMode.DISPENSER_JAM)
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "PAY-JAM-1")
    val res = (backend.fulfillPaidOrder(order.orderId, "FUL-JAM-1") as BackendResult.Success).data
    assertEquals(FulfilmentState.DISPENSER_JAMMED.name, res.fulfilment!!.fulfilmentState)
    assertNotNull(res.reconciliationCase)
    assertEquals(order.claimReference, res.reconciliationCase!!.claimReference)

    // Test printer unavailable on normal order
    hw.setFulfilmentFaultMode(FulfilmentFaultMode.PRINTER_UNAVAILABLE)
    val order2 = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-10") as BackendResult.Success).data
    backend.processPayment(order2.orderId, PaymentMethod.CHIP_CARD, "PAY-NOPRT-1")
    val res2 = (backend.fulfillPaidOrder(order2.orderId, "FUL-NOPRT-1") as BackendResult.Success).data
    assertFalse(res2.receipt!!.printedPhysically)
    assertTrue(res2.receipt!!.watermark.contains("DEMO"))
  }

  @Test
  fun `8 authoritative balance retrieval distinguishes card vs account and rejects blocked cards`() = runTest {
    val (resCard, snapCard) = backend.identifyTransitCard("CRD-4829-1104")
    assertTrue(resCard.success)
    assertFalse(snapCard!!.isAccountBased)

    val (resAcct, snapAcct) = backend.identifyTransitCard("ACCT-9012-7731")
    assertTrue(resAcct.success)
    assertTrue(snapAcct!!.isAccountBased)

    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val blockedOrder = backend.createPricedOrder(ses.sessionId, "PROD-RELOAD-V1", "RULE-RELOAD-10", "CRD-0000-BLOCKED")
    assertTrue(blockedOrder is BackendResult.Failure)
    assertEquals("CARD_BLOCKED", (blockedOrder as BackendResult.Failure).code)
  }

  @Test
  fun `9 staff RBAC enforces supervisor role for pricing refunds and exceptional recovery`() = runTest {
    val operator = (backend.authenticateStaff("OP-101", "1234") as BackendResult.Success).data
    assertEquals(StaffRole.OPERATOR, operator.role)
    val deniedPrice = backend.staffPublishNewProductPriceVersion(operator, "CARD_RELOADABLE_SV", listOf(1000), 100)
    assertTrue(deniedPrice is BackendResult.Failure)
    assertEquals("FORBIDDEN", (deniedPrice as BackendResult.Failure).code)

    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "PAY-RFD-1")
    val refundReq = (backend.staffRequestRefund(operator, order.orderId, "Customer request") as BackendResult.Success).data
    assertEquals(RefundStatus.REFUND_REQUESTED.name, refundReq.status)

    val deniedSettle = backend.staffApproveAndSettleRefund(operator, refundReq.refundId)
    assertTrue(deniedSettle is BackendResult.Failure)

    val supervisor = (backend.authenticateStaff("SUP-201", "5678") as BackendResult.Success).data
    val settled = (backend.staffApproveAndSettleRefund(supervisor, refundReq.refundId) as BackendResult.Success).data
    assertEquals(RefundStatus.SETTLED.name, settled.status)
  }

  @Test
  fun `10 concurrent payment attempts on same order do not double charge`() = runTest {
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val order = (backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20") as BackendResult.Success).data
    val attempts = (1..5).map { idx ->
      async {
        backend.processPayment(order.orderId, PaymentMethod.CONTACTLESS_NFC, "CONC-KEY-$idx")
      }
    }.awaitAll()
    assertTrue(attempts.all { it is BackendResult.Success })
    assertEquals(1, db.terminalDao().getPaymentsForOrder(order.orderId).size)
  }

  @Test
  fun `11 hardware capability checks session reset and log redaction`() = runTest {
    // Cash disabled by default
    assertFalse(hw.healthFlow.value.cashAcceptor.available)
    hw.setCardStock(0)
    val ses = backend.startAnonymousSession(AppLanguage.EN)
    val noStock = backend.createPricedOrder(ses.sessionId, "PROD-CARD-V1", "RULE-CARD-20")
    assertTrue(noStock is BackendResult.Failure)
    assertEquals("DISPENSER_UNAVAILABLE", (noStock as BackendResult.Failure).code)

    // Transit reader timeout
    hw.setTransitReaderTimeoutFault(true)
    val (timeoutRes, _) = backend.identifyTransitCard("CRD-4829-1104")
    assertFalse(timeoutRes.success)
    assertEquals("READER_TIMEOUT", timeoutRes.error?.code)

    // Log redaction strips PANs and PINs
    val redacted = LogRedactor.redact("Card 4111 2222 3333 4444 with pin=5678 failed")
    assertFalse(redacted.contains("4111"))
    assertFalse(redacted.contains("5678"))
    assertTrue(redacted.contains("••••-••••-••••-4444"))

    // Session reset closes active guest session while preserving unresolved financial records
    val openSession = backend.startAnonymousSession(AppLanguage.EN)
    assertEquals("ACTIVE", db.terminalDao().getSession(openSession.sessionId)!!.status)
    backend.closeSession(openSession.sessionId, "CLEARED")
    assertEquals("CLEARED", db.terminalDao().getSession(openSession.sessionId)!!.status)
    val nextSession = backend.startAnonymousSession(AppLanguage.EN)
    assertNotEquals(openSession.sessionId, nextSession.sessionId)
  }

  @Test
  fun `12 journey planner filters inaccessible stations and flags stale data`() {
    val adapter = SyntheticNycTransitDataAdapter()
    val normalRoute = adapter.planJourney("USQ", "BLEECK", accessibleOnly = false)
    assertNotNull(normalRoute)
    val accessibleRoute = adapter.planJourney("USQ", "BLEECK", accessibleOnly = true)
    assertNull(accessibleRoute) // Bleecker St is marked non-accessible in synthetic network

    adapter.setSimulatedStale(true)
    val staleRoute = adapter.planJourney("TSQ", "FUL", accessibleOnly = true)
    assertNotNull(staleRoute)
    assertTrue(staleRoute!!.isStale)
  }
}
