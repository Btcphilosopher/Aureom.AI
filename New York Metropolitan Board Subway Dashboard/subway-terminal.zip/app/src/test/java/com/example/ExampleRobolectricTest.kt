package com.example

import android.app.Application
import android.content.Context
import android.os.Looper
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DatabaseSeeder
import com.example.data.local.TerminalDatabase
import com.example.ui.KioskViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w1280dp-h800dp-land")
class ExampleRobolectricTest {

  @get:Rule
  val composeRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Subway Terminal", appName)
  }

  @Test
  fun `android viewmodel factory instantiates KioskViewModel via single Application arg`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val vm = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
      .create(KioskViewModel::class.java)
    assertTrue(vm.uiState.value.stations.isNotEmpty())
  }

  @Test
  fun `three column kiosk renders 21 dollar purchase flow completes collection and resets session`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val db = TerminalDatabase.createInMemory(app)
    DatabaseSeeder.seedBlocking(db.terminalDao())
    val vm = KioskViewModel(app, customDb = db, simulatedDelayMs = 0L, enableBackgroundTimers = false)

    composeRule.setContent {
      SubwayTerminalAppRoot(vm = vm)
    }

    // Pump Main Looper + Room IO thread until initial session & catalog load
    repeat(100) {
      Shadows.shadowOf(Looper.getMainLooper()).idle()
      if (vm.uiState.value.sessionId.isNotEmpty() && vm.uiState.value.currentQuote != null) return@repeat
      Thread.sleep(25)
    }
    composeRule.waitForIdle()
    assertTrue(vm.uiState.value.sessionId.isNotEmpty())

    val initialSessionId = vm.uiState.value.sessionId
    composeRule.onNodeWithTag("order_summary_total").assertIsDisplayed()
    composeRule.onNodeWithText("$21.00 USD").assertIsDisplayed()
    composeRule.onNodeWithText("Your city. Your next stop.").assertIsDisplayed()

    // Toggle language to Spanish and verify session is preserved
    composeRule.onNodeWithTag("language_toggle_button").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithText("Tu ciudad. Tu próxima parada.").assertIsDisplayed()
    assertEquals(initialSessionId, vm.uiState.value.sessionId)

    // Toggle back to English and complete full payment -> provision -> dispense -> collect -> clear
    composeRule.onNodeWithTag("language_toggle_button").performClick()
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("continue_to_payment_button").performClick()
    repeat(40) {
      Shadows.shadowOf(Looper.getMainLooper()).idle()
      if (vm.uiState.value.activeOrder != null) return@repeat
      Thread.sleep(20)
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("simulate_payment_tap_button").performClick()
    repeat(40) {
      Shadows.shadowOf(Looper.getMainLooper()).idle()
      if (vm.uiState.value.executionOutcome != null) return@repeat
      Thread.sleep(20)
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("demo_receipt_card").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("confirm_collected_button").performScrollTo().performClick()
    repeat(40) {
      Shadows.shadowOf(Looper.getMainLooper()).idle()
      if (vm.uiState.value.checkoutPhase == com.example.ui.CheckoutPhase.COMPLETED) return@repeat
      Thread.sleep(20)
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("finish_clear_session_button").performScrollTo().performClick()
    repeat(40) {
      Shadows.shadowOf(Looper.getMainLooper()).idle()
      if (vm.uiState.value.sessionId != initialSessionId) return@repeat
      Thread.sleep(20)
    }
    composeRule.waitForIdle()

    assertNotEquals(initialSessionId, vm.uiState.value.sessionId)
    assertNull(vm.uiState.value.identifiedCard)

    db.close()
  }
}
