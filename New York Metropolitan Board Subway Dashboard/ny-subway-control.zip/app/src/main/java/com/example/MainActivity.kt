package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      SubwayControlTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = Color(0xFF070B10)
        ) { innerPadding ->
          MissionControlDashboard(modifier = Modifier.padding(innerPadding))
        }
      }
    }
  }
}

@Composable
fun SubwayControlTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = darkColorScheme(
      primary = Color(0xFF00E5FF),
      secondary = Color(0xFF7C4DFF),
      surface = Color(0xFF0F172A),
      background = Color(0xFF070B10),
      onBackground = Color(0xFFE2E8F0)
    ),
    content = content
  )
}

@Composable
fun MissionControlDashboard(modifier: Modifier = Modifier) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      HeaderBanner()
    }
    item {
      Text(
        text = "GRADLE FOUNDATION & ARCHITECTURE STATUS",
        color = Color(0xFF00E5FF),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp,
        fontFamily = FontFamily.Monospace
      )
    }
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        StatusCard(
          title = "Ktor WS Engine",
          status = "Online (3.0.0)",
          color = Color(0xFF00FF66),
          icon = Icons.Default.SignalCellularAlt,
          modifier = Modifier.weight(1f)
        )
        StatusCard(
          title = "Compose Desktop",
          status = "Configured (1.7.0)",
          color = Color(0xFF00E5FF),
          icon = Icons.Default.DirectionsSubway,
          modifier = Modifier.weight(1f)
        )
      }
    }
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        StatusCard(
          title = "Python AI Engine",
          status = "Bridge Ready",
          color = Color(0xFFFFB703),
          icon = Icons.Default.Memory,
          modifier = Modifier.weight(1f)
        )
        StatusCard(
          title = "Rust Sim Engine",
          status = "Bridge Ready",
          color = Color(0xFF7C4DFF),
          icon = Icons.Default.Radar,
          modifier = Modifier.weight(1f)
        )
      }
    }
    item {
      ModuleOverviewCard()
    }
  }
}

@Composable
fun HeaderBanner() {
  Card(
    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1527)),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "NY METROPOLITAN BOARD",
        color = Color(0xFF94A3B8),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Digital Subway Control System",
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.ExtraBold
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "NASA Mission Control Operator Dashboard Foundation",
        color = Color(0xFF00E5FF),
        fontSize = 13.sp
      )
    }
  }
}

@Composable
fun StatusCard(
  title: String,
  status: String,
  color: Color,
  icon: ImageVector,
  modifier: Modifier = Modifier
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
    shape = RoundedCornerShape(8.dp),
    modifier = modifier.border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = title, color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = status, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
fun ModuleOverviewCard() {
  Card(
    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "CONTROL CENTRE ARCHITECTURE",
        color = Color(0xFF00E5FF),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(12.dp))
      ArchitectureItem("frontend/kotlin-control-centre/settings.gradle.kts", "Gradle settings & plugin management")
      ArchitectureItem("frontend/kotlin-control-centre/build.gradle.kts", "Compose Desktop, Ktor WS, Coroutines, Serialization")
      ArchitectureItem("com.nyct.subwaycontrol.MainKt", "Main Compose Desktop entry point")
    }
  }
}

@Composable
fun ArchitectureItem(file: String, desc: String) {
  Column(modifier = Modifier.padding(vertical = 6.dp)) {
    Text(text = file, color = Color(0xFF00FF66), fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    Text(text = desc, color = Color(0xFF94A3B8), fontSize = 11.sp)
  }
}

