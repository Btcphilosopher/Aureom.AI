package com.nyct.subwaycontrol

import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "NYCT Digital Subway Control System - NASA Mission Control Dashboard"
    ) {
        App()
    }
}

@Composable
@Preview
fun App() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00E5FF),
            surface = Color(0xFF0A0E14),
            background = Color(0xFF05070A)
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NEW YORK METROPOLITAN SUBWAY CONTROL SYSTEM",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color(0xFF00E5FF)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "STATUS: MISSION CONTROL GRADLE ENGINE INITIALIZED",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFF00FF66)
                    )
                }
            }
        }
    }
}
