plugins {
    kotlin("jvm") version "2.0.21"
    id("org.jetbrains.compose") version "1.7.0"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
    kotlin("plugin.serialization") version "2.0.21"
    application
}

group = "com.nyct.subwaycontrol"
version = "1.0.0-SNAPSHOT"

repositories {
    google()
    mavenCentral()
}

dependencies {
    // Jetpack Compose Desktop UI
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.materialIconsExtended)
    implementation(compose.components.resources)

    // Kotlin Coroutines for Async Telemetry & Event Streams
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")

    // Kotlinx Serialization & JSON Engine
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    // Ktor Client for HTTP & Real-time WebSockets (Python AI & Rust Sim Engines)
    val ktorVersion = "3.0.0"
    implementation("io.ktor:ktor-client-core:$ktorVersion")
    implementation("io.ktor:ktor-client-cio:$ktorVersion")
    implementation("io.ktor:ktor-client-websockets:$ktorVersion")
    implementation("io.ktor:ktor-client-content-negotiation:$ktorVersion")
    implementation("io.ktor:ktor-serialization-kotlinx-json:$ktorVersion")
    implementation("io.ktor:ktor-client-logging:$ktorVersion")

    // Logging & Observability
    implementation("ch.qos.logback:logback-classic:1.5.11")
    implementation("org.slf4j:slf4j-api:2.0.16")

    // Testing Stack
    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.3")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("io.ktor:ktor-client-mock:$ktorVersion")
}

application {
    mainClass.set("com.nyct.subwaycontrol.MainKt")
}

compose.desktop {
    application {
        mainClass = "com.nyct.subwaycontrol.MainKt"
        nativeDistributions {
            targetFormats(
                org.jetbrains.compose.desktop.application.dsl.TargetFormat.Dmg,
                org.jetbrains.compose.desktop.application.dsl.TargetFormat.Msi,
                org.jetbrains.compose.desktop.application.dsl.TargetFormat.Deb
            )
            packageName = "NYCTSubwayControlCentre"
            packageVersion = "1.0.0"
            description = "New York Metropolitan Board Digital Subway Control System - NASA Mission Control Dashboard"
            copyright = "© 2026 Metropolitan Transportation Authority / Digital Twin Ops"
        }
    }
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xopt-in=kotlinx.coroutines.ExperimentalCoroutinesApi")
    }
}

tasks.test {
    useJUnitPlatform()
}
