package dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.ElectricMeter
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Substation status enum
 */
enum class SubstationStatus(val label: String, val color: Color) {
    OPTIMAL("NOMINAL 750V DC", Color(0xFF30D158)),
    HIGH_LOAD("HIGH DEMAND", Color(0xFFFF9F0A)),
    REDUNDANT_FEED("REDUNDANT FEED", Color(0xFF00F0FF)),
    MAINTENANCE("OFFLINE / YARD", Color(0xFFFF453A))
}

/**
 * Data model for Substation Telemetry
 */
data class SubstationInfo(
    val id: String,
    val name: String,
    val borough: String,
    val outputVoltage: Double = 752.4,
    val currentDrawAmps: Int,
    val temperatureC: Double,
    val status: SubstationStatus = SubstationStatus.OPTIMAL
)

/**
 * Sample dataset for substations
 */
val defaultSubstations = listOf(
    SubstationInfo("SUB-01", "Substation 12 (Times Sq)", "Manhattan", 754.2, 4200, 38.5, SubstationStatus.OPTIMAL),
    SubstationInfo("SUB-02", "Substation 41 (Utica Av)", "Brooklyn", 742.0, 5800, 48.2, SubstationStatus.HIGH_LOAD),
    SubstationInfo("SUB-03", "Substation 07 (Grand Central)", "Manhattan", 751.8, 4900, 41.0, SubstationStatus.OPTIMAL),
    SubstationInfo("SUB-04", "Substation 19 (Queens Plaza)", "Queens", 756.0, 3600, 35.0, SubstationStatus.REDUNDANT_FEED),
    SubstationInfo("SUB-05", "Substation 33 (161st St)", "Bronx", 749.5, 3100, 34.2, SubstationStatus.OPTIMAL),
    SubstationInfo("SUB-06", "Substation 88 (Jamaica Yard)", "Queens", 0.0, 0, 22.0, SubstationStatus.MAINTENANCE)
)

@Composable
fun EnergyKPICard(label: String, value: String, subValue: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = label, fontSize = 10.sp, color = Color(0xFF8B949E), fontFamily = FontFamily.Monospace)
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = FontFamily.Monospace)
            Text(text = subValue, fontSize = 11.sp, color = Color(0xFF8B949E))
        }
    }
}

@Composable
fun SubstationRowItem(substation: SubstationInfo) {
    Surface(
        color = Color(0xFF0D1117),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF21262D))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(substation.status.color)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = substation.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Text(text = "Node ID: ${substation.id} • ${substation.borough}", fontSize = 10.sp, color = Color(0xFF8B949E))
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${substation.outputVoltage} V DC",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${substation.currentDrawAmps} A | ${substation.temperatureC}°C",
                    fontSize = 10.sp,
                    color = Color(0xFF8B949E),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 10.sp, color = Color(0xFF8B949E), fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun PowerTelemetryChartCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Draw horizontal grid lines
        for (i in 1..4) {
            val y = height * (i / 5f)
            drawLine(
                color = Color(0xFF21262D),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
        }

        // Generate synthetic smooth curve points for Total Draw (Cyan)
        val pathDraw = Path()
        val drawPoints = listOf(
            Offset(0f, height * 0.45f),
            Offset(width * 0.2f, height * 0.35f),
            Offset(width * 0.4f, height * 0.25f),
            Offset(width * 0.6f, height * 0.30f),
            Offset(width * 0.8f, height * 0.20f),
            Offset(width, height * 0.38f)
        )

        pathDraw.moveTo(drawPoints[0].x, drawPoints[0].y)
        for (i in 1 until drawPoints.size) {
            val prev = drawPoints[i - 1]
            val curr = drawPoints[i]
            val cx = (prev.x + curr.x) / 2
            pathDraw.cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
        }

        drawPath(
            path = pathDraw,
            color = Color(0xFF00F0FF),
            style = Stroke(width = 3f)
        )

        // Generate smooth curve for Regen Recovery (Green)
        val pathRegen = Path()
        val regenPoints = listOf(
            Offset(0f, height * 0.85f),
            Offset(width * 0.2f, height * 0.75f),
            Offset(width * 0.4f, height * 0.65f),
            Offset(width * 0.6f, height * 0.70f),
            Offset(width * 0.8f, height * 0.60f),
            Offset(width, height * 0.80f)
        )

        pathRegen.moveTo(regenPoints[0].x, regenPoints[0].y)
        for (i in 1 until regenPoints.size) {
            val prev = regenPoints[i - 1]
            val curr = regenPoints[i]
            val cx = (prev.x + curr.x) / 2
            pathRegen.cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
        }

        drawPath(
            path = pathRegen,
            color = Color(0xFF30D158),
            style = Stroke(width = 2.5f)
        )
    }
}

/**
 * EnergyDashboard Component
 */
@Composable
fun EnergyDashboard(
    substations: List<SubstationInfo> = defaultSubstations,
    modifier: Modifier = Modifier
) {
    var ecoModeEnabled by remember { mutableStateOf(true) }

    val totalConsumptionMW = 482.5
    val tractionPowerMW = 384.2
    val regenRecoveryMW = 78.4
    val stationUsageMW = 98.3
    val regenPercentage = (regenRecoveryMW * 100 / totalConsumptionMW)

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0D1117)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "POWER GRID & REGENERATIVE ENERGY DASHBOARD",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF)
                    )
                    Text(
                        text = "750V DC Traction Third-Rail Power, Regen Recovery & Substation Telemetry",
                        fontSize = 12.sp,
                        color = Color(0xFF8B949E)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Eco, contentDescription = null, tint = Color(0xFF30D158), modifier = Modifier.size(18.dp))
                    Text(
                        text = "Eco-Coasting Optimization",
                        fontSize = 12.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = ecoModeEnabled,
                        onCheckedChange = { ecoModeEnabled = it },
                        modifier = Modifier.testTag("eco_mode_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color(0xFF30D158),
                            uncheckedThumbColor = Color(0xFF8B949E),
                            uncheckedTrackColor = Color(0xFF21262D)
                        )
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EnergyKPICard(
                    label = "TOTAL POWER DRAW",
                    value = "$totalConsumptionMW MW",
                    subValue = "Peak Demand Grid Load",
                    color = Color(0xFF00F0FF),
                    modifier = Modifier.weight(1f)
                )
                EnergyKPICard(
                    label = "TRACTION 750V DC",
                    value = "$tractionPowerMW MW",
                    subValue = "79.6% of Total Grid",
                    color = Color(0xFFFF9F0A),
                    modifier = Modifier.weight(1f)
                )
                EnergyKPICard(
                    label = "REGEN HARVESTED",
                    value = "+$regenRecoveryMW MW",
                    subValue = "${String.format("%.1f", regenPercentage)}% Energy Offset",
                    color = Color(0xFF30D158),
                    modifier = Modifier.weight(1f)
                )
                EnergyKPICard(
                    label = "STATION INFRA",
                    value = "$stationUsageMW MW",
                    subValue = "HVAC & Fare Gates",
                    color = Color(0xFFBF5AF2),
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                        .border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "LIVE POWER DRAW vs REGEN RECOVERY (24H TELEMETRY)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                LegendDot("Total Draw", Color(0xFF00F0FF))
                                LegendDot("Regen Recovery", Color(0xFF30D158))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .background(Color(0xFF0D1117), RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF21262D), RoundedCornerShape(6.dp))
                        ) {
                            PowerTelemetryChartCanvas()
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "SUBSTATION GRID NODES (750V DC)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(substations) { sub ->
                                SubstationRowItem(substation = sub)
                            }
                        }
                    }
                }
            }
        }
    }
}
