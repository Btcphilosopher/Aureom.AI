package dashboard

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dashboard Tab Navigation Enum
 */
enum class DashboardTab(val title: String, val testTag: String) {
    OVERVIEW("Master Operations", "tab_overview"),
    NETWORK("Line & Station Monitor", "tab_network"),
    FLEET("Train Telemetry & Fleet", "tab_fleet"),
    INCIDENTS("Incident Command", "tab_incidents"),
    ENERGY("Power Grid & Regen", "tab_energy")
}

@Composable
fun IntegrationStatusBadge(systemName: String, status: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = "$systemName:",
            fontSize = 11.sp,
            color = Color(0xFF8B949E),
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = status,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun IntegrationTelemetryBar() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF0D1117),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF21262D))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                IntegrationStatusBadge("RUST PHYSICS SIM", "ONLINE (60 FPS)", Color(0xFF30D158))
                IntegrationStatusBadge("PYTHON AI OPTIMIZER", "ACTIVE", Color(0xFF00F0FF))
                IntegrationStatusBadge("R STATISTICAL ENGINE", "CONNECTED", Color(0xFFBF5AF2))
                IntegrationStatusBadge("TELEMETRY STREAM", "LIVE (12ms)", Color(0xFF30D158))
            }

            Text(
                text = "NYMB SUBWAY CONTROL v4.2-ENTERPRISE",
                fontSize = 10.sp,
                color = Color(0xFF484F58),
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun MissionControlHeader(
    currentTime: String,
    systemMode: String,
    onModeChange: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF161B22),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Title + Logo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = Color(0xFF00F0FF).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF))
                ) {
                    Icon(
                        Icons.Default.DirectionsSubway,
                        contentDescription = "MTA NYMB Control Logo",
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier
                            .padding(8.dp)
                            .size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "NEW YORK METROPOLITAN BOARD",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B949E),
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "DIGITAL SUBWAY CONTROL SYSTEM",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Center System Mode
            Surface(
                color = Color(0xFF0D1117),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF30D158))
                    )
                    Text(
                        text = "OPERATIONAL MODE: $systemMode",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF30D158),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right Mission Control Clock
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "MISSION CONTROL TIME",
                    fontSize = 10.sp,
                    color = Color(0xFF8B949E),
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = currentTime.ifEmpty { "--:--:--.--- EST" },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun AnnouncementBanner(tickerText: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF1F242C),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color(0xFFFF9F0A).copy(alpha = 0.2f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "SYSTEM BULLETIN",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFF9F0A),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
                text = tickerText,
                fontSize = 12.sp,
                color = Color(0xFFC9D1D9),
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

@Composable
fun MasterKPICard(
    title: String,
    value: String,
    statusText: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8B949E), fontFamily = FontFamily.Monospace)
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
            }

            Text(text = value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
            Text(text = statusText, fontSize = 11.sp, color = accentColor, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun OverviewSectionCard(
    title: String,
    actionText: String,
    onActionClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier.border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                Text(
                    text = actionText,
                    fontSize = 11.sp,
                    color = Color(0xFF8B949E),
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onActionClick() }
                )
            }

            Divider(color = Color(0xFF30363D), modifier = Modifier.padding(vertical = 10.dp))

            content()
        }
    }
}

@Composable
fun MasterOverviewGrid(
    onNavigateToTab: (DashboardTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // KPI Summary Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MasterKPICard(
                title = "ACTIVE NETWORK LINES",
                value = "21 Lines",
                statusText = "98.4% System Health",
                accentColor = Color(0xFF30D158),
                onClick = { onNavigateToTab(DashboardTab.NETWORK) },
                modifier = Modifier.weight(1f)
            )
            MasterKPICard(
                title = "TRAINS IN SERVICE",
                value = "${defaultTrainsList.size} Fleet Units",
                statusText = "Avg Speed: 34.2 mph",
                accentColor = Color(0xFF00F0FF),
                onClick = { onNavigateToTab(DashboardTab.FLEET) },
                modifier = Modifier.weight(1f)
            )
            MasterKPICard(
                title = "INCIDENTS LOGGED",
                value = "${initialIncidentsList.size} Alerts",
                statusText = "2 Critical Action Needed",
                accentColor = Color(0xFFFF453A),
                onClick = { onNavigateToTab(DashboardTab.INCIDENTS) },
                modifier = Modifier.weight(1f)
            )
            MasterKPICard(
                title = "TOTAL POWER LOAD",
                value = "482.5 MW",
                statusText = "+78.4 MW Regen Saved",
                accentColor = Color(0xFFBF5AF2),
                onClick = { onNavigateToTab(DashboardTab.ENERGY) },
                modifier = Modifier.weight(1f)
            )
        }

        // Split Overview Modules
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OverviewSectionCard(
                title = "SUBWAY LINE SYSTEM QUICK-STATUS",
                actionText = "Open Network View →",
                onActionClick = { onNavigateToTab(DashboardTab.NETWORK) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(defaultSubwayLines.take(10)) { line ->
                        LineBadgeCard(line = line, isSelected = false, onClick = { onNavigateToTab(DashboardTab.NETWORK) })
                    }
                }
            }

            OverviewSectionCard(
                title = "CRITICAL ALERTS & EMERGENCY LOGS",
                actionText = "Open Incidents →",
                onActionClick = { onNavigateToTab(DashboardTab.INCIDENTS) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    initialIncidentsList.take(2).forEach { incident ->
                        IncidentCardItem(incident = incident, onUpdateStatus = {}, onDispatchCrew = {})
                    }
                }
            }
        }
    }
}

/**
 * MainDashboard Component
 */
@Composable
fun MainDashboard(
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(DashboardTab.OVERVIEW) }
    var currentSystemTime by remember { mutableStateOf("") }
    var systemMode by remember { mutableStateOf("Standard Peak Service") }
    var activeAlertTicker by remember { mutableStateOf("CBTC Signalling active on Lines 1, 4, 7, A, L. Rust physics engine connected @ 60 FPS.") }

    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'EST'", Locale.US)
        while (true) {
            currentSystemTime = formatter.format(Date())
            delay(100)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFF090D12)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            MissionControlHeader(
                currentTime = currentSystemTime,
                systemMode = systemMode,
                onModeChange = { systemMode = it }
            )

            IntegrationTelemetryBar()

            AnnouncementBanner(tickerText = activeAlertTicker)

            TabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = Color(0xFF161B22),
                contentColor = Color(0xFF00F0FF),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                        color = Color(0xFF00F0FF),
                        height = 3.dp
                    )
                },
                divider = { Divider(color = Color(0xFF30363D)) }
            ) {
                DashboardTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        modifier = Modifier.testTag(tab.testTag),
                        text = {
                            Text(
                                text = tab.title.uppercase(Locale.US),
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                fontFamily = FontFamily.Monospace,
                                color = if (selectedTab == tab) Color(0xFF00F0FF) else Color(0xFF8B949E)
                            )
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF0D1117))
            ) {
                Crossfade(targetState = selectedTab, label = "DashboardTabTransition") { tab ->
                    when (tab) {
                        DashboardTab.OVERVIEW -> MasterOverviewGrid(
                            onNavigateToTab = { selectedTab = it }
                        )
                        DashboardTab.NETWORK -> NetworkOverview()
                        DashboardTab.FLEET -> TrainStatusPanel()
                        DashboardTab.INCIDENTS -> IncidentPanel()
                        DashboardTab.ENERGY -> EnergyDashboard()
                    }
                }
            }
        }
    }
}
