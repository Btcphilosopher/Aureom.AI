package dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Train Condition Enum
 */
enum class TrainCondition(val label: String, val color: Color) {
    CBTC_LOCKED("CBTC ATO Locked", Color(0xFF00F0FF)),
    MANUAL_OVERRIDE("Manual Driver Override", Color(0xFFFF9F0A)),
    SIGNAL_HOLD("Holding at Signal", Color(0xFFFF453A)),
    DEPO_MAINTENANCE("Depot / Yard Maintenance", Color(0xFF8B949E))
}

/**
 * Data model for Train Telemetry
 */
data class TrainStatus(
    val id: String,
    val lineId: String,
    val destination: String,
    val speedMph: Double,
    val targetSpeedMph: Double,
    val passengerLoadPercent: Int,
    val carsCount: Int = 10,
    val currentLocation: String,
    val nextStation: String,
    val delayMinutes: Double = 0.0,
    val condition: TrainCondition = TrainCondition.CBTC_LOCKED,
    val energyRegenKw: Double = 145.0
)

/**
 * Sample dataset for trains
 */
val defaultTrainsList = listOf(
    TrainStatus("TR-1042", "7", "34 St-Hudson Yards", 34.5, 35.0, 84, 11, "Express Track 3 - Queensboro Plaza", "Court Sq", 0.0, TrainCondition.CBTC_LOCKED, 182.0),
    TrainStatus("TR-2189", "A", "Far Rockaway - Mott Av", 42.0, 45.0, 68, 10, "Tunnel Sub-Block 41B (Chambers St)", "Fulton St", 0.0, TrainCondition.CBTC_LOCKED, 210.0),
    TrainStatus("TR-4012", "4", "Crown Hts - Utica Av", 12.5, 35.0, 95, 10, "14 St-Union Sq Approach", "Brooklyn Bridge-City Hall", 4.5, TrainCondition.SIGNAL_HOLD, 45.0),
    TrainStatus("TR-6091", "6", "Pelham Bay Park", 28.0, 30.0, 72, 10, "Local Track 2 - 86th St", "96th St", 0.0, TrainCondition.CBTC_LOCKED, 140.0),
    TrainStatus("TR-L305", "L", "Canarsie - Rockaway Pkwy", 38.2, 40.0, 91, 8, "14 St-8th Ave Interlocking", "6th Ave", 0.0, TrainCondition.CBTC_LOCKED, 195.0),
    TrainStatus("TR-E882", "E", "World Trade Center", 0.0, 30.0, 40, 10, "Jamaica Yard Track 4", "Sutphin Blvd", 12.0, TrainCondition.DEPO_MAINTENANCE, 0.0),
    TrainStatus("TR-D511", "D", "Coney Island - Stillwell Av", 31.0, 35.0, 76, 10, "Manhattan Bridge South Track", "Grand St", 2.0, TrainCondition.MANUAL_OVERRIDE, 115.0),
    TrainStatus("TR-Q723", "Q", "96 St-2nd Ave", 36.4, 38.0, 62, 10, "Lexington Ave-63rd St Cut", "72nd St", 0.0, TrainCondition.CBTC_LOCKED, 168.0)
)

@Composable
fun TrainDetailField(label: String, value: String, color: Color = Color.White) {
    Column {
        Text(text = label, fontSize = 10.sp, color = Color(0xFF8B949E))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun TrainCardItem(
    train: TrainStatus,
    isExpanded: Boolean,
    onClick: () -> Unit,
    onDispatchSpeedCommand: (Double) -> Unit,
    onEmergencyHold: () -> Unit
) {
    val lineObj = defaultSubwayLines.find { it.id == train.lineId }
    val badgeBg = lineObj?.badgeColor ?: Color(0xFF00F0FF)
    val textClr = lineObj?.textColor ?: Color.White

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isExpanded) 1.5.dp else 1.dp,
                color = if (isExpanded) Color(0xFF00F0FF) else Color(0xFF30363D),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .testTag("train_card_${train.id}"),
        colors = CardDefaults.cardColors(containerColor = if (isExpanded) Color(0xFF1F242C) else Color(0xFF161B22))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(badgeBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = train.lineId,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = textClr
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = train.id,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = train.condition.color.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, train.condition.color)
                            ) {
                                Text(
                                    text = train.condition.label,
                                    fontSize = 10.sp,
                                    color = train.condition.color,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "To: ${train.destination} • Loc: ${train.currentLocation}",
                            fontSize = 11.sp,
                            color = Color(0xFF8B949E)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${String.format("%.1f", train.speedMph)} mph",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (train.delayMinutes > 0) "+${train.delayMinutes}m delay" else "ON TIME",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (train.delayMinutes > 0) Color(0xFFFF453A) else Color(0xFF30D158),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Passenger Load (${train.carsCount} Cars):", fontSize = 10.sp, color = Color(0xFF8B949E))
                        Text(text = "${train.passengerLoadPercent}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    LinearProgressIndicator(
                        progress = { train.passengerLoadPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = when {
                            train.passengerLoadPercent > 85 -> Color(0xFFFF453A)
                            train.passengerLoadPercent > 70 -> Color(0xFFFF9F0A)
                            else -> Color(0xFF00F0FF)
                        },
                        trackColor = Color(0xFF21262D)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = Color(0xFF30D158), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Regen: +${train.energyRegenKw} kW", fontSize = 11.sp, color = Color(0xFF30D158), fontFamily = FontFamily.Monospace)
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Divider(color = Color(0xFF30363D), modifier = Modifier.padding(bottom = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TrainDetailField("Next Station Stop", train.nextStation)
                        TrainDetailField("Target Speed Limit", "${train.targetSpeedMph} mph")
                        TrainDetailField("CBTC Communication", "Online (0ms ping)", Color(0xFF30D158))
                        TrainDetailField("Braking Subsystem", "Pneumatic + Regen OK", Color(0xFF00F0FF))
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "CBTC DISPATCH CONTROLS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B949E),
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { onDispatchSpeedCommand(35.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF21262D)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("set_speed_35_btn")
                        ) {
                            Text("Set Speed 35 MPH", fontSize = 11.sp, color = Color(0xFF00F0FF))
                        }

                        Button(
                            onClick = { onDispatchSpeedCommand(45.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF21262D)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("set_speed_45_btn")
                        ) {
                            Text("Express 45 MPH", fontSize = 11.sp, color = Color(0xFF30D158))
                        }

                        Button(
                            onClick = { onEmergencyHold() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF453A)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("emergency_hold_btn")
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EMERGENCY HOLD", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * TrainStatusPanel Component
 */
@Composable
fun TrainStatusPanel(
    trains: List<TrainStatus> = defaultTrainsList,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedTrainId by remember { mutableStateOf<String?>(null) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    val filterOptions = listOf("All", "Delayed Only", "On-Time Only", "CBTC Active", "Manual Control")

    val filteredTrains = remember(searchQuery, selectedFilter, trains) {
        trains.filter { train ->
            val matchesSearch = searchQuery.isEmpty() ||
                train.id.contains(searchQuery, ignoreCase = true) ||
                train.lineId.equals(searchQuery, ignoreCase = true) ||
                train.destination.contains(searchQuery, ignoreCase = true) ||
                train.currentLocation.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "Delayed Only" -> train.delayMinutes > 0.0
                "On-Time Only" -> train.delayMinutes <= 0.0
                "CBTC Active" -> train.condition == TrainCondition.CBTC_LOCKED
                "Manual Control" -> train.condition == TrainCondition.MANUAL_OVERRIDE
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0D1117)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE FLEET RADAR & TRAIN STATUS",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF)
                    )
                    Text(
                        text = "Real-time Telemetry, Speed & CBTC Automated Dispatch",
                        fontSize = 12.sp,
                        color = Color(0xFF8B949E)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniStatChip(label = "Active Fleet", value = "${trains.size}", color = Color(0xFF30D158))
                    MiniStatChip(
                        label = "On-Time",
                        value = "${trains.count { it.delayMinutes <= 0.0 } * 100 / trains.size}%",
                        color = Color(0xFF00F0FF)
                    )
                    MiniStatChip(
                        label = "Avg Fleet Speed",
                        value = "${String.format("%.1f", trains.map { it.speedMph }.average())} mph",
                        color = Color(0xFFBF5AF2)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("train_search_input"),
                    placeholder = { Text("Search Train ID, Line, Destination, or Location...", color = Color(0xFF484F58)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF8B949E)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00F0FF),
                        unfocusedBorderColor = Color(0xFF30363D),
                        focusedContainerColor = Color(0xFF161B22),
                        unfocusedContainerColor = Color(0xFF161B22),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filterOptions) { filter ->
                        BoroughFilterChip(
                            label = filter,
                            isSelected = selectedFilter == filter,
                            onClick = { selectedFilter = filter }
                        )
                    }
                }
            }

            AnimatedVisibility(visible = actionMessage != null) {
                actionMessage?.let { msg ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        color = Color(0xFF1F242C),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "COMMAND DISPATCH: $msg", fontSize = 12.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                            Text(text = "Dismiss", fontSize = 11.sp, color = Color(0xFF8B949E), modifier = Modifier.clickable { actionMessage = null })
                        }
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredTrains) { train ->
                    TrainCardItem(
                        train = train,
                        isExpanded = selectedTrainId == train.id,
                        onClick = {
                            selectedTrainId = if (selectedTrainId == train.id) null else train.id
                        },
                        onDispatchSpeedCommand = { speed ->
                            actionMessage = "Speed override signal [${speed} mph] sent to ${train.id} (${train.lineId} Line)."
                        },
                        onEmergencyHold = {
                            actionMessage = "EMERGENCY HOLD command transmitted to Train ${train.id} at ${train.currentLocation}."
                        }
                    )
                }
            }
        }
    }
}
