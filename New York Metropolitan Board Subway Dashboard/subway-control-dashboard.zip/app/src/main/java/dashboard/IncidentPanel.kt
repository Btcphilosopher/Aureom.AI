package dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Severity enum
 */
enum class IncidentSeverity(val label: String, val color: Color) {
    CRITICAL("CRITICAL", Color(0xFFFF453A)),
    MAJOR("MAJOR", Color(0xFFFF9F0A)),
    MODERATE("MODERATE", Color(0xFFBF5AF2)),
    MINOR("MINOR", Color(0xFF00F0FF))
}

/**
 * Response status enum
 */
enum class ResponseStatus(val label: String, val color: Color) {
    UNASSIGNED("Crew Dispatch Pending", Color(0xFFFF453A)),
    DISPATCHED("Emergency Response En Route", Color(0xFFFF9F0A)),
    ON_SITE("Maintenance Crew On-Site", Color(0xFF00F0FF)),
    RESOLVED("Issue Cleared & Resolved", Color(0xFF30D158))
}

/**
 * Data model for Operational Incidents
 */
data class SubwayIncident(
    val id: String,
    val title: String,
    val lineId: String,
    val affectedLocation: String,
    val severity: IncidentSeverity,
    val timestamp: String,
    val responseStatus: ResponseStatus = ResponseStatus.UNASSIGNED,
    val assignedCrew: String = "Unassigned",
    val impactDetails: String
)

/**
 * Initial sample incidents dataset
 */
val initialIncidentsList = listOf(
    SubwayIncident(
        id = "INC-9042",
        title = "CBTC Interlocking Signal Loss",
        lineId = "D",
        affectedLocation = "Manhattan Bridge South Track (Chambers St - Grand St)",
        severity = IncidentSeverity.CRITICAL,
        timestamp = "14:22:05 EST",
        responseStatus = ResponseStatus.DISPATCHED,
        assignedCrew = "Signal Rapid Response Unit 4",
        impactDetails = "Trains holding at previous signals. Automatic brake override triggered safely."
    ),
    SubwayIncident(
        id = "INC-8891",
        title = "Track Debris & Sparking 3rd Rail",
        lineId = "3",
        affectedLocation = "96th St Interlocking Switch B2",
        severity = IncidentSeverity.MAJOR,
        timestamp = "14:15:40 EST",
        responseStatus = ResponseStatus.ON_SITE,
        assignedCrew = "Track Maintenance Crew 12",
        impactDetails = "Single tracking on express track. 5-7 min delays downstream."
    ),
    SubwayIncident(
        id = "INC-7410",
        title = "Platform Edge Door Malfunction",
        lineId = "7",
        affectedLocation = "Grand Central - 42 St (Track 1)",
        severity = IncidentSeverity.MODERATE,
        timestamp = "13:50:12 EST",
        responseStatus = ResponseStatus.RESOLVED,
        assignedCrew = "Station Systems Tech Team",
        impactDetails = "Door sensor reset complete. Normal operations restored."
    ),
    SubwayIncident(
        id = "INC-6523",
        title = "Substation 41 DC Breaker Trip",
        lineId = "A",
        affectedLocation = "Utica Ave Substation Node",
        severity = IncidentSeverity.CRITICAL,
        timestamp = "13:30:00 EST",
        responseStatus = ResponseStatus.DISPATCHED,
        assignedCrew = "750V Electrical High-Voltage Team",
        impactDetails = "Power automatically rerouted via Substation 42 redundant feeder."
    )
)

@Composable
fun IncidentStatBox(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.border(1.dp, Color(0xFF30363D), RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, fontSize = 10.sp, color = Color(0xFF8B949E), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun IncidentCardItem(
    incident: SubwayIncident,
    onUpdateStatus: (ResponseStatus) -> Unit,
    onDispatchCrew: () -> Unit
) {
    val lineObj = defaultSubwayLines.find { it.id == incident.lineId }
    val badgeBg = lineObj?.badgeColor ?: Color(0xFFFF453A)
    val textClr = lineObj?.textColor ?: Color.White

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, incident.severity.color.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .testTag("incident_card_${incident.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(badgeBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = incident.lineId, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = textClr)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = incident.id,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = incident.severity.color.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, incident.severity.color)
                            ) {
                                Text(
                                    text = incident.severity.label,
                                    fontSize = 10.sp,
                                    color = incident.severity.color,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = incident.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Text(
                    text = incident.timestamp,
                    fontSize = 11.sp,
                    color = Color(0xFF8B949E),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Location: ${incident.affectedLocation}", fontSize = 12.sp, color = Color(0xFFC9D1D9))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(text = "Impact: ${incident.impactDetails}", fontSize = 11.sp, color = Color(0xFF8B949E))

            Divider(color = Color(0xFF30363D), modifier = Modifier.padding(vertical = 10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = incident.responseStatus.color, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status: ${incident.responseStatus.label} (${incident.assignedCrew})",
                        fontSize = 11.sp,
                        color = incident.responseStatus.color,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (incident.responseStatus != ResponseStatus.RESOLVED) {
                        Button(
                            onClick = { onDispatchCrew() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF21262D)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("dispatch_crew_btn_${incident.id}")
                        ) {
                            Text("Dispatch Crew", fontSize = 11.sp, color = Color(0xFF00F0FF))
                        }

                        Button(
                            onClick = { onUpdateStatus(ResponseStatus.RESOLVED) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30D158)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("resolve_incident_btn_${incident.id}")
                        ) {
                            Text("Mark Resolved", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(
                            color = Color(0xFF30D158).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30D158))
                        ) {
                            Text(
                                text = "RESOLVED & VERIFIED",
                                fontSize = 10.sp,
                                color = Color(0xFF30D158),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateIncidentDialog(
    onDismiss: () -> Unit,
    onSubmit: (SubwayIncident) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var lineId by remember { mutableStateOf("1") }
    var location by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf(IncidentSeverity.MAJOR) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF161B22),
        title = {
            Text("REPORT NEW SUBWAY INCIDENT", color = Color(0xFFFF453A), fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Incident Summary / Title", color = Color(0xFF8B949E)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                OutlinedTextField(
                    value = lineId,
                    onValueChange = { lineId = it },
                    label = { Text("Affected Line ID (e.g. 7, A, L)", color = Color(0xFF8B949E)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Exact Track Location / Station", color = Color(0xFF8B949E)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("Impact & Safety Notes", color = Color(0xFF8B949E)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && location.isNotBlank()) {
                        val newIncident = SubwayIncident(
                            id = "INC-${(7000..9999).random()}",
                            title = title,
                            lineId = lineId,
                            affectedLocation = location,
                            severity = severity,
                            timestamp = "JUST NOW",
                            responseStatus = ResponseStatus.UNASSIGNED,
                            assignedCrew = "Dispatch Pending",
                            impactDetails = details.ifBlank { "Operational anomaly logged by Mission Control Operator." }
                        )
                        onSubmit(newIncident)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF453A))
            ) {
                Text("Submit Incident", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF8B949E))
            }
        }
    )
}

/**
 * IncidentPanel Component
 */
@Composable
fun IncidentPanel(
    modifier: Modifier = Modifier
) {
    val incidents = remember { mutableStateListOf(*initialIncidentsList.toTypedArray()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedSeverityFilter by remember { mutableStateOf("All") }
    var showNewIncidentDialog by remember { mutableStateOf(false) }
    var actionToast by remember { mutableStateOf<String?>(null) }

    val severityOptions = listOf("All", "CRITICAL", "MAJOR", "MODERATE", "MINOR")

    val filteredIncidents = remember(searchQuery, selectedSeverityFilter, incidents.toList()) {
        incidents.filter { incident ->
            val matchesSearch = searchQuery.isEmpty() ||
                incident.id.contains(searchQuery, ignoreCase = true) ||
                incident.title.contains(searchQuery, ignoreCase = true) ||
                incident.affectedLocation.contains(searchQuery, ignoreCase = true) ||
                incident.lineId.equals(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedSeverityFilter) {
                "CRITICAL" -> incident.severity == IncidentSeverity.CRITICAL
                "MAJOR" -> incident.severity == IncidentSeverity.MAJOR
                "MODERATE" -> incident.severity == IncidentSeverity.MODERATE
                "MINOR" -> incident.severity == IncidentSeverity.MINOR
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0D1117)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INCIDENT COMMAND & DISPATCH",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF)
                    )
                    Text(
                        text = "Real-time Fault Detection, Emergency Crews & Safety Management",
                        fontSize = 12.sp,
                        color = Color(0xFF8B949E)
                    )
                }

                Button(
                    onClick = { showNewIncidentDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF453A)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("log_incident_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Report Incident", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IncidentStatBox(
                    label = "TOTAL INCIDENTS",
                    value = "${incidents.size}",
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IncidentStatBox(
                    label = "CRITICAL ALERTS",
                    value = "${incidents.count { it.severity == IncidentSeverity.CRITICAL }}",
                    color = Color(0xFFFF453A),
                    modifier = Modifier.weight(1f)
                )
                IncidentStatBox(
                    label = "IN PROGRESS",
                    value = "${incidents.count { it.responseStatus != ResponseStatus.RESOLVED }}",
                    color = Color(0xFFFF9F0A),
                    modifier = Modifier.weight(1f)
                )
                IncidentStatBox(
                    label = "RESOLVED TODAY",
                    value = "${incidents.count { it.responseStatus == ResponseStatus.RESOLVED }}",
                    color = Color(0xFF30D158),
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("incident_search_input"),
                    placeholder = { Text("Filter by ID, Title, Line, or Location...", color = Color(0xFF484F58)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF8B949E)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00F0FF),
                        unfocusedBorderColor = Color(0xFF30363D),
                        focusedContainerColor = Color(0xFF161B22),
                        unfocusedContainerColor = Color(0xFF161B22),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(severityOptions) { filter ->
                        BoroughFilterChip(
                            label = filter,
                            isSelected = selectedSeverityFilter == filter,
                            onClick = { selectedSeverityFilter = filter }
                        )
                    }
                }
            }

            AnimatedVisibility(visible = actionToast != null) {
                actionToast?.let { msg ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        color = Color(0xFF1F242C),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30D158))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "MISSION CONTROL LOG: $msg", fontSize = 12.sp, color = Color(0xFF30D158), fontFamily = FontFamily.Monospace)
                            Text(text = "Dismiss", fontSize = 11.sp, color = Color(0xFF8B949E), modifier = Modifier.clickable { actionToast = null })
                        }
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredIncidents) { incident ->
                    IncidentCardItem(
                        incident = incident,
                        onUpdateStatus = { newStatus ->
                            val idx = incidents.indexOfFirst { it.id == incident.id }
                            if (idx != -1) {
                                incidents[idx] = incidents[idx].copy(responseStatus = newStatus)
                                actionToast = "Incident ${incident.id} status updated to ${newStatus.label}."
                            }
                        },
                        onDispatchCrew = {
                            actionToast = "Emergency Crew dispatched to ${incident.affectedLocation} for ${incident.id}."
                        }
                    )
                }
            }
        }
    }

    if (showNewIncidentDialog) {
        CreateIncidentDialog(
            onDismiss = { showNewIncidentDialog = false },
            onSubmit = { newInc ->
                incidents.add(0, newInc)
                showNewIncidentDialog = false
                actionToast = "New Incident ${newInc.id} registered in System Database."
            }
        )
    }
}
