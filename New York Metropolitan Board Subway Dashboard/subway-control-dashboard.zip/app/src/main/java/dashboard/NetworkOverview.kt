package dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Line Status Enum
 */
enum class LineStatus(val label: String, val color: Color) {
    NORMAL("Normal Service", Color(0xFF30D158)),
    MINOR_DELAYS("Minor Delays", Color(0xFFFF9F0A)),
    SIGNAL_FAULT("Signal Fault", Color(0xFFFF453A)),
    SINGLE_TRACKING("Single Tracking", Color(0xFFBF5AF2))
}

/**
 * Data model for Subway Lines
 */
data class SubwayLine(
    val id: String,
    val name: String,
    val badgeColor: Color,
    val textColor: Color = Color.White,
    val status: LineStatus = LineStatus.NORMAL,
    val activeTrains: Int = 24,
    val headwayMinutes: Double = 3.5,
    val serviceAvailability: Double = 99.2,
    val cbtcEnabled: Boolean = true
)

/**
 * Data model for Station Status
 */
data class StationStatus(
    val id: String,
    val name: String,
    val borough: String,
    val linesServed: List<String>,
    val congestionPercent: Int,
    val passengerCountNow: Int,
    val platformStatus: String = "Normal Operation",
    val elevatorStatus: String = "All Operational"
)

/**
 * Initial sample line dataset
 */
val defaultSubwayLines = listOf(
    SubwayLine("1", "7th Ave Local", Color(0xFFEE352E), Color.White, LineStatus.NORMAL, 28, 3.0, 99.8, true),
    SubwayLine("2", "7th Ave Express", Color(0xFFEE352E), Color.White, LineStatus.NORMAL, 24, 3.5, 99.1, true),
    SubwayLine("3", "7th Ave Express", Color(0xFFEE352E), Color.White, LineStatus.MINOR_DELAYS, 18, 5.0, 94.5, false),
    SubwayLine("4", "Lexington Express", Color(0xFF00933C), Color.White, LineStatus.NORMAL, 32, 2.5, 99.5, true),
    SubwayLine("5", "Lexington Express", Color(0xFF00933C), Color.White, LineStatus.MINOR_DELAYS, 22, 4.0, 96.2, true),
    SubwayLine("6", "Lexington Local", Color(0xFF00933C), Color.White, LineStatus.NORMAL, 30, 3.0, 99.4, true),
    SubwayLine("7", "Flushing Local/Express", Color(0xFFB3519E), Color.White, LineStatus.NORMAL, 36, 2.0, 99.9, true),
    SubwayLine("A", "8th Ave Express", Color(0xFF0039A6), Color.White, LineStatus.NORMAL, 34, 3.2, 98.7, true),
    SubwayLine("C", "8th Ave Local", Color(0xFF0039A6), Color.White, LineStatus.MINOR_DELAYS, 20, 5.5, 95.1, false),
    SubwayLine("E", "8th Ave Local", Color(0xFF0039A6), Color.White, LineStatus.NORMAL, 26, 4.0, 98.9, true),
    SubwayLine("B", "6th Ave Express", Color(0xFFFF6319), Color.White, LineStatus.NORMAL, 22, 4.5, 97.8, false),
    SubwayLine("D", "6th Ave Express", Color(0xFFFF6319), Color.White, LineStatus.SIGNAL_FAULT, 19, 7.0, 89.2, true),
    SubwayLine("F", "6th Ave Local", Color(0xFFFF6319), Color.White, LineStatus.NORMAL, 29, 3.5, 98.4, true),
    SubwayLine("M", "6th Ave Local", Color(0xFFFF6319), Color.White, LineStatus.NORMAL, 16, 6.0, 97.0, false),
    SubwayLine("N", "Broadway Express", Color(0xFFFCCC0A), Color.Black, LineStatus.NORMAL, 24, 4.0, 98.1, true),
    SubwayLine("Q", "Broadway Express", Color(0xFFFCCC0A), Color.Black, LineStatus.NORMAL, 22, 4.2, 98.5, true),
    SubwayLine("R", "Broadway Local", Color(0xFFFCCC0A), Color.Black, LineStatus.MINOR_DELAYS, 25, 5.0, 94.0, false),
    SubwayLine("W", "Broadway Local", Color(0xFFFCCC0A), Color.Black, LineStatus.NORMAL, 14, 7.5, 97.2, false),
    SubwayLine("L", "14th St-Canarsie", Color(0xFFA7A9AC), Color.Black, LineStatus.NORMAL, 28, 2.2, 99.9, true),
    SubwayLine("G", "Brooklyn-Queens Crosstown", Color(0xFF6CBE45), Color.White, LineStatus.NORMAL, 18, 5.5, 98.0, false),
    SubwayLine("S", "42nd St Shuttle", Color(0xFF808183), Color.White, LineStatus.NORMAL, 6, 2.0, 100.0, true)
)

val defaultStations = listOf(
    StationStatus("ST-101", "Times Sq - 42 St", "Manhattan", listOf("1", "2", "3", "7", "N", "Q", "R", "W", "S"), 88, 14250),
    StationStatus("ST-102", "Grand Central - 42 St", "Manhattan", listOf("4", "5", "6", "7", "S"), 92, 16800),
    StationStatus("ST-103", "34 St - Herald Sq", "Manhattan", listOf("B", "D", "F", "M", "N", "Q", "R", "W"), 79, 11400),
    StationStatus("ST-104", "14 St - Union Sq", "Manhattan", listOf("4", "5", "6", "L", "N", "Q", "R", "W"), 82, 12900),
    StationStatus("ST-105", "Fulton St", "Manhattan", listOf("2", "3", "4", "5", "A", "C", "J", "Z"), 74, 9800),
    StationStatus("ST-106", "Atlantic Av - Barclays Ctr", "Brooklyn", listOf("2", "3", "4", "5", "B", "D", "N", "Q", "R"), 85, 13100),
    StationStatus("ST-107", "Queensboro Plaza", "Queens", listOf("7", "N", "W"), 68, 7200),
    StationStatus("ST-108", "161 St - Yankee Stadium", "Bronx", listOf("4", "B", "D"), 62, 5900),
    StationStatus("ST-109", "Jackson Hts - Roosevelt Av", "Queens", listOf("7", "E", "F", "M", "R"), 89, 11200),
    StationStatus("ST-110", "Jay St - MetroTech", "Brooklyn", listOf("A", "C", "F", "R"), 71, 8400)
)

@Composable
fun MiniStatChip(label: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF161B22),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "$label: ", fontSize = 10.sp, color = Color(0xFF8B949E))
            Text(
                text = value,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = color,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun BoroughFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable { onClick() },
        color = if (isSelected) Color(0xFF00F0FF) else Color(0xFF161B22),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) Color(0xFF00F0FF) else Color(0xFF30363D))
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.Black else Color(0xFFC9D1D9)
        )
    }
}

@Composable
fun LineBadgeCard(
    line: SubwayLine,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) Color(0xFF00F0FF) else Color(0xFF30363D)
    val bgColor = if (isSelected) Color(0xFF1F242C) else Color(0xFF161B22)

    Card(
        modifier = Modifier
            .width(135.dp)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("line_card_${line.id}"),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(line.badgeColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = line.id,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = line.textColor
                    )
                }

                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(line.status.color)
                )
            }

            Text(
                text = line.name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                maxLines = 1
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${line.activeTrains} trains",
                    fontSize = 10.sp,
                    color = Color(0xFF8B949E)
                )
                Text(
                    text = "${line.headwayMinutes}m int",
                    fontSize = 10.sp,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun LineDetailMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 10.sp, color = Color(0xFF8B949E))
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SelectedLineDetailCard(
    line: SubwayLine,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .border(1.dp, Color(0xFF00F0FF), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(line.badgeColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = line.id,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = line.textColor
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Line ${line.id} — ${line.name}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Status: ${line.status.label}",
                            fontSize = 12.sp,
                            color = line.status.color,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Text(
                    text = "Close [X]",
                    color = Color(0xFF8B949E),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onClose() }
                )
            }

            Divider(color = Color(0xFF30363D), modifier = Modifier.padding(vertical = 10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                LineDetailMetric("Active Fleet", "${line.activeTrains} Cars")
                LineDetailMetric("Target Headway", "${line.headwayMinutes} min")
                LineDetailMetric("Service Availability", "${line.serviceAvailability}%")
                LineDetailMetric("CBTC Status", if (line.cbtcEnabled) "AUTOMATED" else "MANUAL BLOCK")
            }
        }
    }
}

@Composable
fun StationRowCard(station: StationStatus) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = station.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "Borough: ${station.borough} • ID: ${station.id}",
                    fontSize = 11.sp,
                    color = Color(0xFF8B949E)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    station.linesServed.forEach { lineId ->
                        val lineObj = defaultSubwayLines.find { it.id == lineId }
                        val badgeBg = lineObj?.badgeColor ?: Color(0xFF484F58)
                        val textClr = lineObj?.textColor ?: Color.White

                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(badgeBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lineId,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = textClr
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.End
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Crowd Density:",
                        fontSize = 11.sp,
                        color = Color(0xFF8B949E)
                    )
                    Text(
                        text = "${station.congestionPercent}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            station.congestionPercent > 85 -> Color(0xFFFF453A)
                            station.congestionPercent > 70 -> Color(0xFFFF9F0A)
                            else -> Color(0xFF30D158)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                LinearProgressIndicator(
                    progress = { station.congestionPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = when {
                        station.congestionPercent > 85 -> Color(0xFFFF453A)
                        station.congestionPercent > 70 -> Color(0xFFFF9F0A)
                        else -> Color(0xFF30D158)
                    },
                    trackColor = Color(0xFF21262D)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${station.passengerCountNow} commuters active",
                    fontSize = 10.sp,
                    color = Color(0xFF8B949E),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/**
 * NetworkOverview Component
 */
@Composable
fun NetworkOverview(
    lines: List<SubwayLine> = defaultSubwayLines,
    stations: List<StationStatus> = defaultStations,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedBoroughFilter by remember { mutableStateOf("All") }
    var selectedLineId by remember { mutableStateOf<String?>(null) }

    val boroughs = listOf("All", "Manhattan", "Brooklyn", "Queens", "Bronx")

    val filteredStations = remember(searchQuery, selectedBoroughFilter, stations) {
        stations.filter { station ->
            (selectedBoroughFilter == "All" || station.borough.equals(selectedBoroughFilter, ignoreCase = true)) &&
            (searchQuery.isEmpty() || station.name.contains(searchQuery, ignoreCase = true) || station.linesServed.any { it.equals(searchQuery, ignoreCase = true) })
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0D1117)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SUBWAY NETWORK MONITOR",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF)
                    )
                    Text(
                        text = "Real-time CBTC Signalling, Congestion & Line Health",
                        fontSize = 12.sp,
                        color = Color(0xFF8B949E)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MiniStatChip(label = "Lines Active", value = "${lines.size}/21", color = Color(0xFF30D158))
                    MiniStatChip(
                        label = "Signal Health",
                        value = "${lines.count { it.status == LineStatus.NORMAL } * 100 / lines.size}%",
                        color = Color(0xFF00F0FF)
                    )
                    MiniStatChip(label = "CBTC Coverage", value = "76.4%", color = Color(0xFFBF5AF2))
                }
            }

            Text(
                text = "SUBWAY LINE SYSTEM STATUS",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF8B949E),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                items(lines) { line ->
                    LineBadgeCard(
                        line = line,
                        isSelected = selectedLineId == line.id,
                        onClick = {
                            selectedLineId = if (selectedLineId == line.id) null else line.id
                        }
                    )
                }
            }

            val currentSelectedLine = lines.find { it.id == selectedLineId }
            AnimatedVisibility(visible = currentSelectedLine != null) {
                currentSelectedLine?.let { line ->
                    SelectedLineDetailCard(
                        line = line,
                        onClose = { selectedLineId = null }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STATION CONGESTION & AVAILABILITY",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF8B949E)
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(boroughs) { b ->
                        BoroughFilterChip(
                            label = b,
                            isSelected = selectedBoroughFilter == b,
                            onClick = { selectedBoroughFilter = b }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("station_search_input"),
                placeholder = { Text("Filter stations by name or line (e.g., Grand Central, A, 7)", color = Color(0xFF484F58)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF8B949E)) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00F0FF),
                    unfocusedBorderColor = Color(0xFF30363D),
                    focusedContainerColor = Color(0xFF161B22),
                    unfocusedContainerColor = Color(0xFF161B22),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredStations) { station ->
                    StationRowCard(station = station)
                }
            }
        }
    }
}
