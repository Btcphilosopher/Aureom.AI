package websocket

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Enterprise-grade Telemetry Event Stream for the New York Metropolitan Board Digital Subway Control System.
 *
 * Responsibilities:
 * • Receive telemetry events from LiveTelemetryClient
 * • Publish events using Kotlin Flow and StateFlow
 * • Provide observable streams for UI components
 * • Buffer incoming events safely at thousands of events per second
 * • Dispatch updates asynchronously across multiple subscribers
 * • Support structured filtering by event type, line ID, station ID, train ID, and severity
 * • Maintain a thread-safe historical event replay buffer with adjustable playback speeds
 * • Compute live operational throughput statistics (events/sec, distribution per type)
 */

// ============================================================================
// Telemetry Domain Models
// ============================================================================

enum class TelemetryEventType {
    TRAIN_POSITION,
    STATION_OCCUPANCY,
    SIGNAL_STATE,
    SERVICE_ALERT,
    INCIDENT,
    ENERGY_CONSUMPTION,
    MAINTENANCE,
    AI_RECOMMENDATION,
    SYSTEM_DIAGNOSTIC
}

enum class TrainStatus {
    IN_TRANSIT,
    DWELLING,
    STOPPED,
    EMERGENCY_BRAKE,
    MANUAL_OVERRIDE,
    OUT_OF_SERVICE
}

enum class CongestionLevel {
    LOW,
    MODERATE,
    HIGH,
    CRITICAL,
    OVERFLOW
}

enum class SignalAspect {
    GREEN,
    YELLOW,
    RED,
    FLASHING_RED,
    LUNAR
}

enum class AlertSeverity {
    INFO,
    WARNING,
    SEVERE,
    CRITICAL
}

enum class IncidentPriority {
    P1, // Emergency / System Stop
    P2, // High priority operational delay
    P3, // Minor issue
    P4  // Information / Advisory
}

enum class IncidentType {
    TRACK_OBSTRUCTION,
    SIGNAL_FAILURE,
    POWER_OUTAGE,
    MEDICAL_EMERGENCY,
    UNAUTHORIZED_PERSON,
    DOOR_MALFUNCTION,
    WEATHER_IMPACT
}

enum class AssetType {
    SWITCH,
    THIRD_RAIL,
    CATENARY,
    ESCALATOR,
    ELEVATOR,
    VENTILATION,
    SIGNAL_BOX
}

enum class AssetStatus {
    OK,
    WARNING,
    DEGRADED,
    FAULT,
    OFFLINE
}

enum class RecommendedAction {
    SPEED_RESTRICTION,
    HOLD_AT_STATION,
    REROUTE,
    INCREASE_HEADWAY,
    DISPATCH_BACKUP,
    EMERGENCY_STOP
}

@Serializable
sealed class TelemetryEvent {
    abstract val eventId: String
    abstract val timestampEpochMs: Long
    abstract val sourceId: String
    abstract val eventType: TelemetryEventType

    @Serializable
    @SerialName("TRAIN_POSITION")
    data class TrainPositionEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val trainId: String,
        val lineId: String,
        val routeId: String,
        val currentStationId: String,
        val nextStationId: String,
        val distanceToNextStationMeters: Double,
        val speedKmh: Double,
        val latitude: Double,
        val longitude: Double,
        val headingDegrees: Float,
        val trainStatus: TrainStatus,
        val passengerLoadPercentage: Int = 0
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.TRAIN_POSITION
    }

    @Serializable
    @SerialName("STATION_OCCUPANCY")
    data class StationOccupancyEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val stationId: String,
        val stationName: String,
        val lineId: String,
        val platformId: String,
        val passengerCount: Int,
        val maxCapacity: Int,
        val occupancyPercentage: Float,
        val congestionLevel: CongestionLevel
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.STATION_OCCUPANCY
    }

    @Serializable
    @SerialName("SIGNAL_STATE")
    data class SignalStateEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val signalId: String,
        val lineId: String,
        val stationId: String,
        val currentAspect: SignalAspect,
        val previousAspect: SignalAspect,
        val interlockActive: Boolean,
        val trackSegmentId: String
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.SIGNAL_STATE
    }

    @Serializable
    @SerialName("SERVICE_ALERT")
    data class ServiceAlertEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val alertId: String,
        val lineId: String,
        val severity: AlertSeverity,
        val title: String,
        val description: String,
        val affectedStations: List<String> = emptyList()
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.SERVICE_ALERT
    }

    @Serializable
    @SerialName("INCIDENT")
    data class IncidentEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val incidentId: String,
        val lineId: String,
        val locationId: String,
        val type: IncidentType,
        val priority: IncidentPriority,
        val status: String,
        val summary: String
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.INCIDENT
    }

    @Serializable
    @SerialName("ENERGY_CONSUMPTION")
    data class EnergyConsumptionEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val substationId: String,
        val lineSegmentId: String,
        val currentPowerKw: Double,
        val peakPowerKw: Double,
        val voltageVolts: Double,
        val regenerativeEnergyKw: Double
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.ENERGY_CONSUMPTION
    }

    @Serializable
    @SerialName("MAINTENANCE")
    data class MaintenanceEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val assetId: String,
        val assetType: AssetType,
        val status: AssetStatus,
        val lastInspectionMs: Long,
        val healthScore: Float
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.MAINTENANCE
    }

    @Serializable
    @SerialName("AI_RECOMMENDATION")
    data class AIRecommendationEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val recommendationId: String,
        val targetLineId: String,
        val targetTrainId: String?,
        val confidenceScore: Float,
        val recommendedAction: RecommendedAction,
        val explanation: String
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.AI_RECOMMENDATION
    }

    @Serializable
    @SerialName("SYSTEM_DIAGNOSTIC")
    data class SystemDiagnosticEvent(
        override val eventId: String,
        override val timestampEpochMs: Long,
        override val sourceId: String,
        val systemName: String,
        val cpuUsagePercent: Float,
        val memoryUsageMb: Double,
        val message: String
    ) : TelemetryEvent() {
        override val eventType = TelemetryEventType.SYSTEM_DIAGNOSTIC
    }
}

// ============================================================================
// Event Stream Interface & Implementation
// ============================================================================

interface EventStreamContract {
    /** Main broadcast hot flow for all incoming telemetry events. */
    val events: SharedFlow<TelemetryEvent>

    /** Latest event published to the stream. */
    val lastEvent: StateFlow<TelemetryEvent?>

    /** Lifetime count of telemetry events processed by this stream. */
    val totalEventsProcessed: StateFlow<Long>

    /** Real-time throughput metric (events per second). */
    val eventsPerSecond: StateFlow<Double>

    /** Distribution breakdown of events received per type. */
    val eventTypeDistribution: StateFlow<Map<TelemetryEventType, Long>>

    /** Publishes a new telemetry event into the stream. */
    fun publish(event: TelemetryEvent)

    /** Sub-stream filters */
    fun filterByType(type: TelemetryEventType): Flow<TelemetryEvent>
    fun filterByLine(lineId: String): Flow<TelemetryEvent>
    fun filterByTrain(trainId: String): Flow<TelemetryEvent>
    fun filterByStation(stationId: String): Flow<TelemetryEvent>
    fun filterIncidents(minPriority: IncidentPriority = IncidentPriority.P4): Flow<TelemetryEvent.IncidentEvent>

    /** Historical event replay capability */
    fun getHistoricalBuffer(): List<TelemetryEvent>
    fun replayHistory(speedMultiplier: Double = 1.0): Flow<TelemetryEvent>
    fun clearHistory()
}

class EventStream(
    private val bufferCapacity: Int = 10_000,
    private val historyMaxCapacity: Int = 5_000,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) : EventStreamContract {

    private val scope = CoroutineScope(SupervisorJob() + dispatcher)

    // Primary event hub: replay = 100 to allow new subscribers immediate context,
    // extraBufferCapacity = 10,000 for zero-loss high-speed bursts, DROP_OLDEST to avoid backpressure block.
    private val _events = MutableSharedFlow<TelemetryEvent>(
        replay = 100,
        extraBufferCapacity = bufferCapacity,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val events: SharedFlow<TelemetryEvent> = _events.asSharedFlow()

    private val _lastEvent = MutableStateFlow<TelemetryEvent?>(null)
    override val lastEvent: StateFlow<TelemetryEvent?> = _lastEvent.asStateFlow()

    private val _totalEventsProcessed = MutableStateFlow(0L)
    override val totalEventsProcessed: StateFlow<Long> = _totalEventsProcessed.asStateFlow()

    private val _eventsPerSecond = MutableStateFlow(0.0)
    override val eventsPerSecond: StateFlow<Double> = _eventsPerSecond.asStateFlow()

    private val _eventTypeDistribution = MutableStateFlow<Map<TelemetryEventType, Long>>(emptyMap())
    override val eventTypeDistribution: StateFlow<Map<TelemetryEventType, Long>> = _eventTypeDistribution.asStateFlow()

    // Internal thread-safe circular ring buffer for historical replaying
    private val historyLock = Any()
    private val historyRingBuffer = ArrayDeque<TelemetryEvent>(historyMaxCapacity)

    // Throughput tracking counters
    private val windowEventCount = AtomicLong(0L)
    private val typeCounters = ConcurrentHashMap<TelemetryEventType, AtomicLong>()

    init {
        // Start background throughput calculator task
        scope.launch {
            while (isActive) {
                delay(1000L)
                val countInLastSecond = windowEventCount.getAndSet(0L)
                _eventsPerSecond.value = countInLastSecond.toDouble()

                // Snapshot distribution
                val snapshot = typeCounters.mapValues { it.value.get() }
                _eventTypeDistribution.value = snapshot
            }
        }
    }

    /**
     * Ingest and publish a single telemetry event.
     * Safe to invoke from any thread or high-frequency network thread.
     */
    override fun publish(event: TelemetryEvent) {
        _lastEvent.value = event
        _totalEventsProcessed.value += 1
        windowEventCount.incrementAndGet()

        // Update event type counter
        typeCounters.computeIfAbsent(event.eventType) { AtomicLong(0L) }.incrementAndGet()

        // Add to historical replay buffer
        synchronized(historyLock) {
            if (historyRingBuffer.size >= historyMaxCapacity) {
                historyRingBuffer.pollFirst()
            }
            historyRingBuffer.addLast(event)
        }

        // Emit asynchronously into SharedFlow
        _events.tryEmit(event)
    }

    override fun filterByType(type: TelemetryEventType): Flow<TelemetryEvent> {
        return events.filter { it.eventType == type }
    }

    override fun filterByLine(lineId: String): Flow<TelemetryEvent> {
        return events.filter { event ->
            when (event) {
                is TelemetryEvent.TrainPositionEvent -> event.lineId == lineId
                is TelemetryEvent.StationOccupancyEvent -> event.lineId == lineId
                is TelemetryEvent.SignalStateEvent -> event.lineId == lineId
                is TelemetryEvent.ServiceAlertEvent -> event.lineId == lineId
                is TelemetryEvent.IncidentEvent -> event.lineId == lineId
                is TelemetryEvent.EnergyConsumptionEvent -> event.lineSegmentId.contains(lineId, ignoreCase = true)
                is TelemetryEvent.AIRecommendationEvent -> event.targetLineId == lineId
                else -> false
            }
        }
    }

    override fun filterByTrain(trainId: String): Flow<TelemetryEvent> {
        return events.filter { event ->
            when (event) {
                is TelemetryEvent.TrainPositionEvent -> event.trainId == trainId
                is TelemetryEvent.AIRecommendationEvent -> event.targetTrainId == trainId
                else -> false
            }
        }
    }

    override fun filterByStation(stationId: String): Flow<TelemetryEvent> {
        return events.filter { event ->
            when (event) {
                is TelemetryEvent.StationOccupancyEvent -> event.stationId == stationId
                is TelemetryEvent.TrainPositionEvent -> event.currentStationId == stationId || event.nextStationId == stationId
                is TelemetryEvent.SignalStateEvent -> event.stationId == stationId
                is TelemetryEvent.IncidentEvent -> event.locationId == stationId
                else -> false
            }
        }
    }

    override fun filterIncidents(minPriority: IncidentPriority): Flow<TelemetryEvent.IncidentEvent> {
        return events.filterIsInstance<TelemetryEvent.IncidentEvent>()
            .filter { it.priority.ordinal <= minPriority.ordinal }
    }

    override fun getHistoricalBuffer(): List<TelemetryEvent> {
        synchronized(historyLock) {
            return historyRingBuffer.toList()
        }
    }

    override fun replayHistory(speedMultiplier: Double): Flow<TelemetryEvent> = flow {
        val snapshot = getHistoricalBuffer()
        if (snapshot.isEmpty()) return@flow

        val safeSpeed = speedMultiplier.coerceAtLeast(0.1)
        var previousTimestamp: Long? = null

        for (event in snapshot) {
            previousTimestamp?.let { prev ->
                val timeDelta = event.timestampEpochMs - prev
                if (timeDelta > 0) {
                    val delayMs = (timeDelta / safeSpeed).toLong().coerceIn(1L, 5000L)
                    delay(delayMs)
                }
            }
            previousTimestamp = event.timestampEpochMs
            emit(event)
        }
    }

    override fun clearHistory() {
        synchronized(historyLock) {
            historyRingBuffer.clear()
        }
    }
}
