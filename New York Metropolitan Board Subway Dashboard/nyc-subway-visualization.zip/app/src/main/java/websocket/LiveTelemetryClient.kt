package websocket

import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.client.request.header
import io.ktor.http.HttpMethod
import io.ktor.websocket.CloseReason
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.Closeable
import java.net.URI
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min
import kotlin.random.Random

/**
 * Primary WebSocket Telemetry Client for the New York Metropolitan Board Digital Subway Control System.
 *
 * Responsibilities:
 * • Connects to configurable digital subway WebSocket endpoints (supports wss:// and ws://)
 * • Automatically reconnects with exponential backoff and randomized jitter upon connection loss
 * • Monitors connection state and exposes it via a reactive StateFlow to UI control panels
 * • Receives high-frequency telemetry JSON frames, parses them, and forwards to EventStream
 * • Sends periodic heartbeats and processes WebSocket ping/pong frames
 * • Provides thread-safe asynchronous commands & structured error reporting
 * • Supports graceful shutdown and session telemetry diagnostic logging
 */

// ============================================================================
// Client Configuration & Connection State
// ============================================================================

data class TelemetryClientConfig(
    val endpointUrl: String = "wss://telemetry.subway.mta.info/ws/v1/control-centre",
    val initialReconnectDelayMs: Long = 1000L,
    val maxReconnectDelayMs: Long = 30000L,
    val backoffMultiplier: Double = 1.5,
    val jitterFactor: Double = 0.2,
    val heartbeatIntervalMs: Long = 15_000L,
    val connectionTimeoutMs: Long = 10_000L,
    val operatorId: String = "NYC-CONTROL-OP-409",
    val authToken: String = "Bearer mta-secure-subway-token-2026",
    val headers: Map<String, String> = emptyMap(),
    val autoReconnect: Boolean = true
)

sealed class ConnectionState {
    object Disconnected : ConnectionState()
    data class Connecting(val attempt: Int, val url: String) : ConnectionState()
    data class Connected(val url: String, val connectedAtEpochMs: Long) : ConnectionState()
    data class Reconnecting(val attempt: Int, val nextAttemptMs: Long, val cause: Throwable?) : ConnectionState()
    data class Failed(val cause: Throwable, val isFatal: Boolean) : ConnectionState()
    object Closed : ConnectionState()
}

sealed class TelemetryError : Exception() {
    data class ConnectionFailed(override val message: String, override val cause: Throwable?) : TelemetryError()
    data class SerializationFailed(val rawText: String, override val cause: Throwable?) : TelemetryError()
    data class HeartbeatTimeout(val lastPongAgeMs: Long) : TelemetryError()
    data class SendFailed(val payload: String, override val cause: Throwable?) : TelemetryError()
}

@Serializable
data class HeartbeatPayload(
    val type: String = "HEARTBEAT",
    val timestampMs: Long,
    val operatorId: String,
    val sequenceNumber: Long
)

@Serializable
data class TelemetryCommand(
    val commandId: String,
    val action: String,
    val targetType: String,
    val targetId: String,
    val parameters: Map<String, String> = emptyMap(),
    val timestampMs: Long = System.currentTimeMillis()
)

// ============================================================================
// Live Telemetry Client Implementation
// ============================================================================

class LiveTelemetryClient(
    val config: TelemetryClientConfig = TelemetryClientConfig(),
    private val eventStream: EventStream = EventStream(),
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val customHttpClient: HttpClient? = null
) : Closeable {

    private val scope = CoroutineScope(SupervisorJob() + dispatcher)

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _errors = MutableSharedFlow<TelemetryError>(extraBufferCapacity = 100)
    val errors: SharedFlow<TelemetryError> = _errors.asSharedFlow()

    // Connection Diagnostics & Metrics
    private val _totalMessagesReceived = AtomicLong(0L)
    val totalMessagesReceived: Long get() = _totalMessagesReceived.get()

    private val _totalBytesReceived = AtomicLong(0L)
    val totalBytesReceived: Long get() = _totalBytesReceived.get()

    private val _lastPongTimestampMs = MutableStateFlow(System.currentTimeMillis())
    val lastPongTimestampMs: StateFlow<Long> = _lastPongTimestampMs.asStateFlow()

    private val heartbeatSequence = AtomicLong(0L)

    private var connectionJob: Job? = null
    private var heartbeatJob: Job? = null
    private var activeWebSocketSession: io.ktor.websocket.DefaultWebSocketSession? = null

    // Lenient JSON parser configured for enterprise microservices telemetry format
    val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
        prettyPrint = false
        encodeDefaults = true
        coerceInputValues = true
    }

    private val httpClient: HttpClient = customHttpClient ?: HttpClient(OkHttp) {
        install(WebSockets) {
            pingInterval = config.heartbeatIntervalMs
        }
    }

    /**
     * Initiates connection to the backend telemetry server.
     * Starts the connection supervisor loop in background.
     */
    fun connect() {
        if (_connectionState.value is ConnectionState.Connected || _connectionState.value is ConnectionState.Connecting) {
            return
        }

        connectionJob?.cancel()
        connectionJob = scope.launch {
            connectionLoop()
        }
    }

    private suspend fun connectionLoop() {
        var attemptCount = 0

        while (scope.isActive && config.autoReconnect && _connectionState.value !is ConnectionState.Closed) {
            attemptCount++
            _connectionState.value = ConnectionState.Connecting(attemptCount, config.endpointUrl)

            try {
                val uri = URI(config.endpointUrl)
                val scheme = uri.scheme ?: "wss"
                val host = uri.host ?: "telemetry.subway.mta.info"
                val port = if (uri.port != -1) uri.port else if (scheme == "ws") 80 else 443
                val path = if (uri.rawPath.isNullOrEmpty()) "/ws/v1/control-centre" else uri.rawPath

                httpClient.webSocket(
                    method = HttpMethod.Get,
                    host = host,
                    port = port,
                    path = path,
                    request = {
                        header("Authorization", config.authToken)
                        header("X-Operator-ID", config.operatorId)
                        header("X-Client-Platform", "NYCT-Digital-Subway-Control-Center")
                        config.headers.forEach { (k, v) -> header(k, v) }
                    }
                ) {
                    // Successfully connected
                    activeWebSocketSession = this
                    attemptCount = 0 // Reset attempt counter on success
                    val connectedTime = System.currentTimeMillis()
                    _connectionState.value = ConnectionState.Connected(config.endpointUrl, connectedTime)

                    startHeartbeatLoop(this)

                    // Listen for incoming frames
                    for (frame in incoming) {
                        when (frame) {
                            is Frame.Text -> {
                                val text = frame.readText()
                                _totalMessagesReceived.incrementAndGet()
                                _totalBytesReceived.addAndGet(text.length.toLong())
                                handleIncomingTextFrame(text)
                            }
                            is Frame.Ping -> {
                                // Handled automatically by Ktor WebSockets engine
                                _lastPongTimestampMs.value = System.currentTimeMillis()
                            }
                            is Frame.Pong -> {
                                _lastPongTimestampMs.value = System.currentTimeMillis()
                            }
                            is Frame.Close -> {
                                break
                            }
                            else -> {}
                        }
                    }
                }
            } catch (t: Throwable) {
                if (!scope.isActive || _connectionState.value is ConnectionState.Closed) break

                val error = TelemetryError.ConnectionFailed("WebSocket connection failure: ${t.localizedMessage}", t)
                _errors.tryEmit(error)

                if (config.autoReconnect) {
                    val delayMs = calculateBackoffDelay(attemptCount)
                    _connectionState.value = ConnectionState.Reconnecting(attemptCount, delayMs, t)
                    delay(delayMs)
                } else {
                    _connectionState.value = ConnectionState.Failed(t, isFatal = false)
                    break
                }
            } finally {
                activeWebSocketSession = null
                stopHeartbeatLoop()
            }
        }
    }

    private fun startHeartbeatLoop(session: io.ktor.websocket.DefaultWebSocketSession) {
        stopHeartbeatLoop()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(config.heartbeatIntervalMs)
                val seq = heartbeatSequence.incrementAndGet()
                val heartbeat = HeartbeatPayload(
                    timestampMs = System.currentTimeMillis(),
                    operatorId = config.operatorId,
                    sequenceNumber = seq
                )

                try {
                    val json = jsonParser.encodeToString(heartbeat)
                    session.send(Frame.Text(json))
                } catch (t: Throwable) {
                    _errors.tryEmit(TelemetryError.SendFailed("Heartbeat send failure", t))
                }
            }
        }
    }

    private fun stopHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    private fun handleIncomingTextFrame(jsonText: String) {
        try {
            // Attempt standard TelemetryEvent polymorph parsing
            val event = jsonParser.decodeFromString<TelemetryEvent>(jsonText)
            eventStream.publish(event)
        } catch (e: Exception) {
            // Log fallback error or ignore non-event control frames (e.g., ACK messages)
            if (!jsonText.contains("HEARTBEAT_ACK") && !jsonText.contains("PONG")) {
                _errors.tryEmit(TelemetryError.SerializationFailed(jsonText, e))
            }
        }
    }

    /**
     * Transmits a command to the subway backend control server asynchronously.
     */
    suspend fun sendCommand(command: TelemetryCommand): Boolean {
        val session = activeWebSocketSession ?: return false
        return try {
            val json = jsonParser.encodeToString(command)
            session.send(Frame.Text(json))
            true
        } catch (t: Throwable) {
            _errors.tryEmit(TelemetryError.SendFailed("Failed to send command ${command.commandId}", t))
            false
        }
    }

    /**
     * Sends raw JSON payload directly across the active WebSocket connection.
     */
    suspend fun sendRawJson(rawJson: String): Boolean {
        val session = activeWebSocketSession ?: return false
        return try {
            session.send(Frame.Text(rawJson))
            true
        } catch (t: Throwable) {
            _errors.tryEmit(TelemetryError.SendFailed("Failed to send raw json", t))
            false
        }
    }

    /**
     * Calculates exponential backoff with randomized jitter.
     */
    private fun calculateBackoffDelay(attempt: Int): Long {
        val exponential = config.initialReconnectDelayMs * Math.pow(config.backoffMultiplier, (attempt - 1).toDouble())
        val cappedDelay = min(exponential, config.maxReconnectDelayMs.toDouble())
        val jitter = cappedDelay * config.jitterFactor * (Random.nextDouble() * 2 - 1)
        return (cappedDelay + jitter).toLong().coerceAtLeast(100L)
    }

    /**
     * Gracefully disconnects from the telemetry server.
     */
    suspend fun disconnect(reason: String = "Operator Initiated Disconnect") {
        _connectionState.value = ConnectionState.Closed
        stopHeartbeatLoop()
        connectionJob?.cancel()
        connectionJob = null

        activeWebSocketSession?.close(
            CloseReason(
                CloseReason.Codes.NORMAL,
                reason
            )
        )
        activeWebSocketSession = null
        _connectionState.value = ConnectionState.Disconnected
    }

    override fun close() {
        scope.launch {
            disconnect("Client closed")
        }.invokeOnCompletion {
            scope.cancel()
            if (customHttpClient == null) {
                httpClient.close()
            }
        }
    }
}
