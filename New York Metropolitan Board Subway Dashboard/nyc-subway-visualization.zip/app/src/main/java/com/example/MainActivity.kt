package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import websocket.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainActivity : ComponentActivity() {

    private val eventStream = EventStream()
    private val telemetryClient = LiveTelemetryClient(
        config = TelemetryClientConfig(
            endpointUrl = "wss://subway-telemetry.mta.info/ws/v1/control-centre",
            operatorId = "NYC-CONTROL-OP-409"
        ),
        eventStream = eventStream
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0A0C10) // Immersive UI Deep Dark Canvas
                ) {
                    SubwayControlCenterApp(
                        telemetryClient = telemetryClient,
                        eventStream = eventStream
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        telemetryClient.close()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubwayControlCenterApp(
    telemetryClient: LiveTelemetryClient,
    eventStream: EventStream
) {
    val connectionState by telemetryClient.connectionState.collectAsState()
    val totalProcessed by eventStream.totalEventsProcessed.collectAsState()
    val eventsPerSec by eventStream.eventsPerSecond.collectAsState()
    val typeDistribution by eventStream.eventTypeDistribution.collectAsState()
    val lastEvent by eventStream.lastEvent.collectAsState()

    var selectedFilter by remember { mutableStateOf<TelemetryEventType?>(null) }
    var isSimulatingEngine by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    // Background Telemetry Simulation Loop representing Rust Engine & Python AI Services
    LaunchedEffect(isSimulatingEngine) {
        if (!isSimulatingEngine) return@LaunchedEffect

        val lines = listOf("A", "C", "E", "1", "2", "3", "7", "L", "N", "Q")
        val stations = listOf("Times Sq-42 St", "Grand Central-42 St", "14 St-Union Sq", "Fulton St", "Atlantic Av-Barclays")
        var counter = 1000L

        while (isActive) {
            delay(200L) // 5 telemetry events per second
            counter++
            val line = lines.random()
            val station = stations.random()
            val time = System.currentTimeMillis()

            val generatedEvent: TelemetryEvent = when (counter % 6L) {
                0L -> TelemetryEvent.TrainPositionEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "RUST_SIM_ENGINE",
                    trainId = "TR-$line-${Random.nextInt(100, 999)}",
                    lineId = line,
                    routeId = "ROUTE-$line",
                    currentStationId = station,
                    nextStationId = stations.random(),
                    distanceToNextStationMeters = Random.nextDouble(50.0, 1200.0),
                    speedKmh = Random.nextDouble(20.0, 75.0),
                    latitude = 40.7580 + Random.nextDouble(-0.05, 0.05),
                    longitude = -73.9855 + Random.nextDouble(-0.05, 0.05),
                    headingDegrees = Random.nextFloat() * 360f,
                    trainStatus = TrainStatus.values().random(),
                    passengerLoadPercentage = Random.nextInt(20, 98)
                )
                1L -> TelemetryEvent.SignalStateEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "INTERLOCK_SIGNAL_SRV",
                    signalId = "SIG-$line-${Random.nextInt(1, 20)}",
                    lineId = line,
                    stationId = station,
                    currentAspect = SignalAspect.values().random(),
                    previousAspect = SignalAspect.GREEN,
                    interlockActive = Random.nextBoolean(),
                    trackSegmentId = "TRACK-$line-SEG-04"
                )
                2L -> TelemetryEvent.StationOccupancyEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "STATION_SENSOR_NET",
                    stationId = station,
                    stationName = station,
                    lineId = line,
                    platformId = "PLATFORM-NORTHBOUND",
                    passengerCount = Random.nextInt(150, 2400),
                    maxCapacity = 2500,
                    occupancyPercentage = Random.nextFloat() * 100f,
                    congestionLevel = CongestionLevel.values().random()
                )
                3L -> TelemetryEvent.AIRecommendationEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "PYTHON_AI_PREDICTOR",
                    recommendationId = "AI-REC-$counter",
                    targetLineId = line,
                    targetTrainId = "TR-$line-402",
                    confidenceScore = 0.94f,
                    recommendedAction = RecommendedAction.values().random(),
                    explanation = "AI detected bottleneck at $station. Recommend adjusting headway by +45s."
                )
                4L -> TelemetryEvent.IncidentEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "KAFKA_DISPATCH_STREAM",
                    incidentId = "INC-$counter",
                    lineId = line,
                    locationId = station,
                    type = IncidentType.values().random(),
                    priority = IncidentPriority.values().random(),
                    status = "INVESTIGATING",
                    summary = "Automatic sensor alert reported on Line $line at $station."
                )
                else -> TelemetryEvent.EnergyConsumptionEvent(
                    eventId = "EVT-$counter",
                    timestampEpochMs = time,
                    sourceId = "POWER_GRID_MONITOR",
                    substationId = "SUBSTATION-$line-01",
                    lineSegmentId = "SEG-$line-MAIN",
                    currentPowerKw = Random.nextDouble(1200.0, 4500.0),
                    peakPowerKw = 5000.0,
                    voltageVolts = 750.0,
                    regenerativeEnergyKw = Random.nextDouble(100.0, 800.0)
                )
            }
            eventStream.publish(generatedEvent)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF10B981))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "NYMB • TRANSIT OPS",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFF94A3B8),
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "System Control v4.0",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF161B22)
                ),
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = if (isSimulatingEngine) "SIMULATOR: ON" else "SIMULATOR: OFF",
                            color = if (isSimulatingEngine) Color(0xFF10B981) else Color(0xFFF59E0B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Switch(
                            checked = isSimulatingEngine,
                            onCheckedChange = { isSimulatingEngine = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF10B981)
                            )
                        )
                    }
                }
            )
        },
        containerColor = Color(0xFF0A0C10)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // LiveTelemetryClient Health Card
            ConnectionStatusBar(
                connectionState = connectionState,
                onConnectClick = { telemetryClient.connect() },
                onDisconnectClick = { scope.launch { telemetryClient.disconnect() } }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Metrics Cards Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "EVENTS / S",
                    value = String.format(Locale.US, "%.1f", eventsPerSec),
                    subtitle = "Latency ~14ms",
                    icon = Icons.Default.Speed,
                    accentColor = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "TOTAL INGESTED",
                    value = "$totalProcessed",
                    subtitle = "SharedFlow Hub",
                    icon = Icons.Default.Dataset,
                    accentColor = Color(0xFF818CF8),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "BUFFER LOAD",
                    value = "${String.format(Locale.US, "%.1f", (eventStream.getHistoricalBuffer().size.toDouble() / 5000.0) * 100)}%",
                    subtitle = "Ring Capacity",
                    icon = Icons.Default.CheckCircle,
                    accentColor = Color(0xFF34D399),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Filter Chips
            Text(
                text = "STREAM FILTER:",
                color = Color(0xFF64748B),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    label = { Text("ALL", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF4F46E5),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF161B22),
                        labelColor = Color(0xFF94A3B8)
                    )
                )
                TelemetryEventType.values().take(4).forEach { type ->
                    FilterChip(
                        selected = selectedFilter == type,
                        onClick = { selectedFilter = if (selectedFilter == type) null else type },
                        label = { Text(type.name.take(12), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF4F46E5),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFF161B22),
                            labelColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }

            // Terminal EventStream View
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EventStream.kt / Active Flow",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Replay Buffer: ${eventStream.getHistoricalBuffer().size}",
                            color = Color(0xFF64748B),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val eventList = remember(totalProcessed, selectedFilter) {
                        val history = eventStream.getHistoricalBuffer().reversed()
                        if (selectedFilter == null) history else history.filter { it.eventType == selectedFilter }
                    }

                    val listState = rememberLazyListState()

                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(eventList, key = { it.eventId }) { event ->
                            TelemetryEventRow(event)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConnectionStatusBar(
    connectionState: ConnectionState,
    onConnectClick: () -> Unit,
    onDisconnectClick: () -> Unit
) {
    val (statusText, statusColor, isConnected) = when (connectionState) {
        is ConnectionState.Connected -> Triple("CONNECTED", Color(0xFF10B981), true)
        is ConnectionState.Connecting -> Triple("CONNECTING (${connectionState.attempt})...", Color(0xFFF59E0B), false)
        is ConnectionState.Reconnecting -> Triple("RECONNECTING (${connectionState.attempt})...", Color(0xFFF59E0B), false)
        is ConnectionState.Disconnected -> Triple("DISCONNECTED", Color(0xFFEF4444), false)
        is ConnectionState.Failed -> Triple("FAILED", Color(0xFFEF4444), false)
        is ConnectionState.Closed -> Triple("CLOSED", Color(0xFF64748B), false)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "LiveTelemetryClient",
                        fontSize = 11.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "wss://telemetry.subway.mta.info/ws/v1",
                        color = Color(0xFFCBD5E1),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusText,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = { if (isConnected) onDisconnectClick() else onConnectClick() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) Color(0xFF1A1F26) else Color(0xFF4F46E5)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = if (isConnected) "DISCONNECT STREAM" else "CONNECT WEBSOCKET",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isConnected) Color(0xFFCBD5E1) else Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1117)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B), letterSpacing = 0.5.sp)
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(14.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
            Text(subtitle, fontSize = 10.sp, color = Color(0xFF475569))
        }
    }
}

@Composable
fun TelemetryEventRow(event: TelemetryEvent) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    val formattedTime = dateFormat.format(Date(event.timestampEpochMs))

    val (badgeColor, typeLabel, detailText) = when (event) {
        is TelemetryEvent.TrainPositionEvent -> Triple(
            Color(0xFF38BDF8),
            "TRAIN_POSITION",
            "Train ${event.trainId} | Line ${event.lineId} | ${event.currentStationId} -> ${event.nextStationId} (${String.format(Locale.US, "%.0f", event.distanceToNextStationMeters)}m @ ${String.format(Locale.US, "%.0f", event.speedKmh)}km/h)"
        )
        is TelemetryEvent.SignalStateEvent -> Triple(
            Color(0xFFF59E0B),
            "SIGNAL_STATE",
            "Signal ${event.signalId} [Line ${event.lineId}] | Aspect: ${event.currentAspect} | Track Segment: ${event.trackSegmentId}"
        )
        is TelemetryEvent.StationOccupancyEvent -> Triple(
            Color(0xFF34D399),
            "STATION_OCCUPANCY",
            "${event.stationName} | Load: ${event.passengerCount}/${event.maxCapacity} (${String.format(Locale.US, "%.0f", event.occupancyPercentage)}%) | Level: ${event.congestionLevel}"
        )
        is TelemetryEvent.AIRecommendationEvent -> Triple(
            Color(0xFF818CF8),
            "AI_PREDICTOR",
            "Action: ${event.recommendedAction} on Line ${event.targetLineId} (Conf: ${(event.confidenceScore * 100).toInt()}%)"
        )
        is TelemetryEvent.IncidentEvent -> Triple(
            Color(0xFFF87171),
            "INCIDENT [${event.priority}]",
            "Line ${event.lineId} @ ${event.locationId}: ${event.type} - ${event.summary}"
        )
        is TelemetryEvent.EnergyConsumptionEvent -> Triple(
            Color(0xFF22D3EE),
            "POWER_GRID",
            "${event.substationId} | Current: ${String.format(Locale.US, "%.0f", event.currentPowerKw)} kW | Peak: ${event.peakPowerKw} kW"
        )
        else -> Triple(
            Color(0xFF64748B),
            event.eventType.name,
            "Source: ${event.sourceId} | Event ID: ${event.eventId}"
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0D1117))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "[$formattedTime]",
                    color = Color(0xFF38BDF8),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = typeLabel,
                    color = badgeColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = detailText,
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
