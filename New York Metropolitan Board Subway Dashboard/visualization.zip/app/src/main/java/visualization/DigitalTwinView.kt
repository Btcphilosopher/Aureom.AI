package visualization

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.isActive

/**
 * Top-Level Digital Twin View for the New York Metropolitan Board Subway Control System.
 */
@Composable
fun DigitalTwinView(
    modifier: Modifier = Modifier
) {
    // 1. Core Renderers & Animation Engine
    val mapRenderer = remember { SubwayMapRenderer() }
    val trainEngine = remember { TrainAnimationEngine() }
    val stationRenderer = remember { StationRenderer() }
    val signalRenderer = remember { SignalRenderer() }
    val textMeasurer = rememberTextMeasurer()

    // 2. Viewport State (Zoom & Pan Camera)
    var zoom by remember { mutableFloatStateOf(1.0f) }
    var panX by remember { mutableFloatStateOf(100.0f) }
    var panY by remember { mutableFloatStateOf(80.0f) }

    // 3. Layer Filter Toggles
    var showSignals by remember { mutableStateOf(true) }
    var showStations by remember { mutableStateOf(true) }
    var showTrains by remember { mutableStateOf(true) }
    var showGrid by remember { mutableStateOf(true) }
    var isPaused by remember { mutableStateOf(false) }
    var simulationSpeed by remember { mutableFloatStateOf(1.0f) }

    // 4. Selection State
    var selectedStationId by remember { mutableStateOf<String?>("ST-TIMES-SQ") }
    var selectedTrainId by remember { mutableStateOf<String?>("TR-101") }
    var pulseAnimProgress by remember { mutableFloatStateOf(0f) }

    // 5. Sample NYC Network Data
    val subwayLines = remember { createSampleSubwayLines() }
    val stations = remember { createSampleStations() }
    val trains = remember { createSampleTrains() }
    val trackBlocks = remember { createSampleTrackBlocks() }
    val signals = remember { createSampleSignals() }
    val switches = remember { createSampleSwitches() }

    // 6. Real-Time Telemetry Simulation Clock (60 FPS coroutine loop)
    LaunchedEffect(isPaused, simulationSpeed) {
        var lastTimeNanos = System.nanoTime()
        while (isActive) {
            val now = System.nanoTime()
            val deltaSec = (now - lastTimeNanos) / 1_000_000_000f
            lastTimeNanos = now

            pulseAnimProgress = (pulseAnimProgress + deltaSec * 2f) % 1.0f

            if (!isPaused) {
                trainEngine.tickSimulation(
                    trains = trains,
                    deltaTimeSeconds = deltaSec.coerceAtMost(0.1f),
                    speedFactor = simulationSpeed
                )

                // Sync signals with train positions
                for (block in trackBlocks) {
                    var occupied = false
                    for (tr in trains) {
                        val (pos, _) = tr.calculatePositionAndHeading()
                        val p1 = block.points.firstOrNull() ?: continue
                        val p2 = block.points.lastOrNull() ?: continue
                        val dx = pos.x - (p1.x + p2.x) / 2
                        val dy = pos.y - (p1.y + p2.y) / 2
                        if (dx * dx + dy * dy < 1600f) {
                            occupied = true
                            break
                        }
                    }
                    block.isOccupied = occupied
                    block.activeSignalAspect = if (occupied) SignalAspect.RED_STOP else SignalAspect.GREEN_PROCEED
                }

                for (sig in signals) {
                    val matchingBlock = trackBlocks.find { it.blockId == sig.blockId }
                    if (matchingBlock != null) {
                        sig.aspect = matchingBlock.activeSignalAspect
                    }
                }
            }
            kotlinx.coroutines.delay(16) // ~60 FPS
        }
    }

    val viewport = MapViewport(zoom = zoom, panX = panX, panY = panY)
    val selectedStation = stations.find { it.id == selectedStationId }
    val selectedTrain = trains.find { it.trainId == selectedTrainId }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MTAColors.CanvasBg)
    ) {
        // --- PRIMARY COMPOSE CANVAS DIGITAL TWIN LAYER ---
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoomFactor, _ ->
                        zoom = (zoom * zoomFactor).coerceIn(0.4f, 4.0f)
                        panX += pan.x
                        panY += pan.y
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        val clickedStation = stationRenderer.findStationAtOffset(
                            clickOffset = tapOffset,
                            viewport = viewport,
                            stations = stations
                        )
                        if (clickedStation != null) {
                            selectedStationId = clickedStation.id
                        } else {
                            // Check train click
                            for (tr in trains) {
                                val (pos, _) = tr.calculatePositionAndHeading()
                                val screenPos = viewport.mapToScreen(pos)
                                val dx = tapOffset.x - screenPos.x
                                val dy = tapOffset.y - screenPos.y
                                if (dx * dx + dy * dy <= 900f) {
                                    selectedTrainId = tr.trainId
                                    break
                                }
                            }
                        }
                    }
                }
        ) {
            // Layer 1: Base Map Track Network & Grid
            mapRenderer.renderMap(
                drawScope = this,
                viewport = viewport,
                lines = subwayLines,
                showGrid = showGrid,
                showBoroughs = true,
                textMeasurer = textMeasurer
            )

            // Layer 2: Signaling & Interlocking Layer
            if (showSignals) {
                signalRenderer.renderSignalingLayer(
                    drawScope = this,
                    viewport = viewport,
                    blocks = trackBlocks,
                    signals = signals,
                    switches = switches,
                    textMeasurer = textMeasurer
                )
            }

            // Layer 3: Stations Layer
            if (showStations) {
                stationRenderer.renderStations(
                    drawScope = this,
                    viewport = viewport,
                    stations = stations,
                    selectedStationId = selectedStationId,
                    pulseProgress = pulseAnimProgress,
                    textMeasurer = textMeasurer
                )
            }

            // Layer 4: Animated Trains Layer
            if (showTrains) {
                trainEngine.renderTrainOverlays(
                    drawScope = this,
                    viewport = viewport,
                    trains = trains,
                    selectedTrainId = selectedTrainId,
                    textMeasurer = textMeasurer
                )
            }
        }

        // --- NASA / MTA MISSION CONTROL HUD HEADER BAR ---
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            color = Color(0xFF020617).copy(alpha = 0.92f),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "MTA DIGITAL TWIN CONTROL CENTRE",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "NEW YORK METROPOLITAN OPERATIONS BOARD • LIVE TELEMETRY STREAM",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    TelemetryStatBadge("FLEET IN SERVICE", "${trains.size} CONSISTS", Color(0xFF38BDF8))
                    TelemetryStatBadge("NETWORK LOAD", "78% NOMINAL", Color(0xFF10B981))
                    TelemetryStatBadge("SYSTEM STATUS", "ALL CLEAR", Color(0xFF10B981))
                }
            }
        }

        // --- FLOATING CONTROL PANEL & CAMERA CONTROLS ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Camera & Preset Quick Jump Controls
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.9f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { zoom = (zoom * 1.25f).coerceAtMost(4.0f) }) {
                        Icon(Icons.Filled.Add, contentDescription = "Zoom In", tint = Color.White)
                    }
                    IconButton(onClick = { zoom = (zoom / 1.25f).coerceAtLeast(0.4f) }) {
                        Icon(Icons.Filled.Remove, contentDescription = "Zoom Out", tint = Color.White)
                    }
                    IconButton(onClick = {
                        zoom = 1.0f
                        panX = 100f
                        panY = 80f
                    }) {
                        Icon(Icons.Filled.CenterFocusStrong, contentDescription = "Reset View", tint = MTAColors.AccentCyan)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            panX = -120f
                            panY = -100f
                            zoom = 1.4f
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Times Sq Hub", fontSize = 11.sp, color = Color.White)
                    }

                    Button(
                        onClick = {
                            panX = -320f
                            panY = -120f
                            zoom = 1.4f
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Grand Central", fontSize = 11.sp, color = Color.White)
                    }
                }
            }

            // Playback Controls & Simulation Speed
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.9f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(
                        onClick = { isPaused = !isPaused },
                        modifier = Modifier
                            .size(36.dp)
                            .background(if (isPaused) Color(0xFFEF4444) else Color(0xFF10B981), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                            contentDescription = "Toggle Animation",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = if (isPaused) "PAUSED" else "LIVE SIM",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    listOf(1.0f to "1x", 2.0f to "2x", 5.0f to "5x").forEach { (speed, label) ->
                        FilterChip(
                            selected = simulationSpeed == speed,
                            onClick = { simulationSpeed = speed },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MTAColors.AccentCyan,
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF1E293B),
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // --- RIGHT TELEMETRY INSPECTOR DRAWER ---
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 70.dp, end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Layer Selection Chips
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
                modifier = Modifier
                    .width(280.dp)
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "VISUALIZATION LAYERS",
                        color = MTAColors.AccentCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LayerToggleChip("Signals", showSignals) { showSignals = it }
                        LayerToggleChip("Stations", showStations) { showStations = it }
                        LayerToggleChip("Trains", showTrains) { showTrains = it }
                    }
                }
            }

            // Selected Station Inspection Panel
            if (selectedStation != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
                    modifier = Modifier
                        .width(280.dp)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "STATION TELEMETRY",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(selectedStation.getOccupancyColor().copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${selectedStation.passengerOccupancyPct}% CAPACITY",
                                    color = selectedStation.getOccupancyColor(),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = selectedStation.name,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${selectedStation.borough} Division • ${selectedStation.platformCount} Platforms",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Passenger Load Gauge:", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = selectedStation.passengerOccupancyPct / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = selectedStation.getOccupancyColor(),
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            selectedStation.servingLines.forEach { line ->
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(getLineColor(line)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(line, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Selected Train Inspection Panel
            if (selectedTrain != null) {
                val telemetry = selectedTrain.toTelemetry()
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.95f)),
                    modifier = Modifier
                        .width(280.dp)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "FLEET CONSIST ${telemetry.trainId}",
                                color = MTAColors.AccentCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(telemetry.lineAccentColor)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(telemetry.lineCode, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("SPEED", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                Text("${telemetry.speedMph.toInt()} MPH", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("CONSIST", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                Text("${telemetry.carCount} CARS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("STATUS", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                Text(
                                    text = if (telemetry.status == TrainOperationalStatus.DWELLING_AT_STATION) "DWELLING" else "EN ROUTE",
                                    color = if (telemetry.status == TrainOperationalStatus.DWELLING_AT_STATION) Color(0xFFF59E0B) else Color(0xFF10B981),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryStatBadge(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.End) {
        Text(label, color = Color(0xFF64748B), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun LayerToggleChip(label: String, active: Boolean, onToggle: (Boolean) -> Unit) {
    FilterChip(
        selected = active,
        onClick = { onToggle(!active) },
        label = { Text(label, fontSize = 10.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF1E293B),
            selectedLabelColor = MTAColors.AccentCyan,
            containerColor = Color(0xFF020617),
            labelColor = Color(0xFF64748B)
        )
    )
}

private fun getLineColor(code: String): Color {
    return when (code) {
        "A", "C", "E" -> MTAColors.EighthAve
        "B", "D", "F", "M" -> MTAColors.SixthAve
        "G" -> MTAColors.Crosstown
        "L" -> MTAColors.Canarsie
        "N", "Q", "R", "W" -> MTAColors.Broadway
        "1", "2", "3" -> MTAColors.SeventhAve
        "4", "5", "6" -> MTAColors.Lexington
        "7" -> MTAColors.Flushing
        else -> MTAColors.Shuttle
    }
}

// Sample Data Generators for New York Network
private fun createSampleSubwayLines(): List<SubwayLineModel> {
    return listOf(
        SubwayLineModel(
            id = "LINE-A",
            name = "8th Ave Express",
            code = "A",
            color = MTAColors.EighthAve,
            darkColor = Color(0xFF002266),
            segments = listOf(
                TrackSegmentData("SEG-A1", "LINE-A", listOf(MapPoint(150f, 100f), MapPoint(250f, 180f), MapPoint(350f, 280f), MapPoint(380f, 480f), MapPoint(420f, 650f)), isExpress = true)
            ),
            description = "Inwood to Far Rockaway"
        ),
        SubwayLineModel(
            id = "LINE-7",
            name = "Flushing Local/Express",
            code = "7",
            color = MTAColors.Flushing,
            darkColor = Color(0xFF660066),
            segments = listOf(
                TrackSegmentData("SEG-71", "LINE-7", listOf(MapPoint(220f, 260f), MapPoint(350f, 280f), MapPoint(580f, 270f), MapPoint(780f, 240f)), isExpress = false)
            ),
            description = "34 St Hudson Yards to Main St"
        ),
        SubwayLineModel(
            id = "LINE-4",
            name = "Lexington Express",
            code = "4",
            color = MTAColors.Lexington,
            darkColor = Color(0xFF005522),
            segments = listOf(
                TrackSegmentData("SEG-41", "LINE-4", listOf(MapPoint(420f, 60f), MapPoint(480f, 180f), MapPoint(500f, 320f), MapPoint(490f, 480f), MapPoint(520f, 640f)), isExpress = true)
            ),
            description = "Woodlawn to Crown Heights"
        )
    )
}

private fun createSampleStations(): List<StationNode> {
    return listOf(
        StationNode("ST-TIMES-SQ", "Times Sq - 42 St", MapPoint(350f, 280f), listOf("A", "N", "Q", "R", "1", "2", "3", "7"), isTransferHub = true, passengerOccupancyPct = 88),
        StationNode("ST-GRAND-CENTRAL", "Grand Central - 42 St", MapPoint(500f, 275f), listOf("4", "5", "6", "7", "S"), isTransferHub = true, passengerOccupancyPct = 92),
        StationNode("ST-FULTON", "Fulton Street", MapPoint(490f, 480f), listOf("A", "C", "J", "2", "3", "4", "5"), isTransferHub = true, passengerOccupancyPct = 74),
        StationNode("ST-ATLANTIC", "Atlantic Av - Barclays Ctr", MapPoint(520f, 640f), listOf("B", "D", "N", "Q", "R", "2", "3", "4", "5"), isTransferHub = true, passengerOccupancyPct = 68),
        StationNode("ST-59-COLUMBUS", "59 St - Columbus Circle", MapPoint(250f, 180f), listOf("A", "B", "C", "D", "1"), isTransferHub = true, passengerOccupancyPct = 52),
        StationNode("ST-125-HARLEM", "125 St Harlem", MapPoint(420f, 60f), listOf("4", "5", "6"), isTransferHub = false, passengerOccupancyPct = 44)
    )
}

private fun createSampleTrains(): List<AnimatedTrain> {
    return listOf(
        AnimatedTrain("TR-101", "A", listOf(MapPoint(150f, 100f), MapPoint(250f, 180f), MapPoint(350f, 280f), MapPoint(380f, 480f), MapPoint(420f, 650f)), MTAColors.EighthAve, speedMph = 42f),
        AnimatedTrain("TR-702", "7", listOf(MapPoint(220f, 260f), MapPoint(350f, 280f), MapPoint(580f, 270f), MapPoint(780f, 240f)), MTAColors.Flushing, speedMph = 36f),
        AnimatedTrain("TR-408", "4", listOf(MapPoint(420f, 60f), MapPoint(480f, 180f), MapPoint(500f, 320f), MapPoint(490f, 480f), MapPoint(520f, 640f)), MTAColors.Lexington, speedMph = 48f)
    )
}

private fun createSampleTrackBlocks(): List<TrackBlock> {
    return listOf(
        TrackBlock("BLK-A1", "LINE-A", listOf(MapPoint(150f, 100f), MapPoint(250f, 180f))),
        TrackBlock("BLK-A2", "LINE-A", listOf(MapPoint(250f, 180f), MapPoint(350f, 280f))),
        TrackBlock("BLK-71", "LINE-7", listOf(MapPoint(350f, 280f), MapPoint(580f, 270f)))
    )
}

private fun createSampleSignals(): List<SignalNode> {
    return listOf(
        SignalNode("SIG-A101", "BLK-A1", MapPoint(200f, 140f), SignalAspect.GREEN_PROCEED),
        SignalNode("SIG-A102", "BLK-A2", MapPoint(300f, 230f), SignalAspect.GREEN_PROCEED),
        SignalNode("SIG-7001", "BLK-71", MapPoint(460f, 275f), SignalAspect.YELLOW_APPROACH)
    )
}

private fun createSampleSwitches(): List<InterlockingSwitch> {
    return listOf(
        InterlockingSwitch("SW-101", MapPoint(350f, 280f), MapPoint(380f, 480f), MapPoint(580f, 270f), SwitchPosition.STRAIGHT_MAIN)
    )
}
