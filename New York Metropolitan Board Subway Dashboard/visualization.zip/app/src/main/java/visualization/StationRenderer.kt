package visualization

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlin.math.sqrt

enum class StationOperationalState {
    NORMAL,
    HEAVY_CROWD_DELAY,
    MAINTENANCE,
    EMERGENCY_HOLD,
    TERMINUS
}

/**
 * Model representing an MTA Subway Station Node.
 */
data class StationNode(
    val id: String,
    val name: String,
    val position: MapPoint,
    val servingLines: List<String>,
    val isTransferHub: Boolean = false,
    val isAccessibleADA: Boolean = true,
    val platformCount: Int = 4,
    var passengerOccupancyPct: Int = 42,
    var state: StationOperationalState = StationOperationalState.NORMAL,
    val borough: String = "Manhattan"
) {
    fun getOccupancyColor(): Color {
        return when {
            passengerOccupancyPct > 85 -> Color(0xFFEF4444) // High / Critical (Red)
            passengerOccupancyPct > 65 -> Color(0xFFF59E0B) // Moderate / High (Amber)
            passengerOccupancyPct > 35 -> Color(0xFF10B981) // Normal (Green)
            else -> Color(0xFF3B82F6) // Low (Blue)
        }
    }
}

/**
 * Station Renderer component for visualizing platforms, occupancy gauges,
 * transfer badges, and station inspection states.
 */
class StationRenderer {

    /**
     * Renders all stations onto the Canvas.
     */
    fun renderStations(
        drawScope: DrawScope,
        viewport: MapViewport,
        stations: List<StationNode>,
        selectedStationId: String? = null,
        pulseProgress: Float = 0f,
        textMeasurer: TextMeasurer? = null
    ) {
        drawScope.apply {
            for (station in stations) {
                val screenPos = viewport.mapToScreen(station.position)

                // Viewport Culling
                if (screenPos.x < -80f || screenPos.x > size.width + 80f ||
                    screenPos.y < -80f || screenPos.y > size.height + 80f
                ) {
                    continue
                }

                val isSelected = station.id == selectedStationId
                val baseRadius = if (station.isTransferHub) 10f else 6f
                val radius = (baseRadius * viewport.zoom).coerceIn(4f, 22f)

                // Render Pulse Ring for Selected Station
                if (isSelected) {
                    val pulseRadius = radius + (12f * pulseProgress * viewport.zoom)
                    drawCircle(
                        color = MTAColors.AccentCyan.copy(alpha = (1f - pulseProgress).coerceIn(0f, 1f)),
                        radius = pulseRadius,
                        center = screenPos,
                        style = Stroke(width = 2.5f)
                    )
                    drawCircle(
                        color = MTAColors.AccentCyan,
                        radius = radius + 4f,
                        center = screenPos,
                        style = Stroke(width = 2f)
                    )
                }

                // Station Outer Ring
                val outerColor = when (station.state) {
                    StationOperationalState.NORMAL -> Color.White
                    StationOperationalState.HEAVY_CROWD_DELAY -> Color(0xFFF59E0B)
                    StationOperationalState.MAINTENANCE -> Color(0xFFEAB308)
                    StationOperationalState.EMERGENCY_HOLD -> Color(0xFFEF4444)
                    StationOperationalState.TERMINUS -> Color(0xFF818CF8)
                }

                drawCircle(
                    color = outerColor,
                    radius = radius,
                    center = screenPos
                )

                // Station Core Fill
                drawCircle(
                    color = if (station.isTransferHub) Color(0xFF0F172A) else Color(0xFF1E293B),
                    radius = radius * 0.65f,
                    center = screenPos
                )

                // Transfer Hub Inner Ring
                if (station.isTransferHub) {
                    drawCircle(
                        color = Color.White,
                        radius = radius * 0.35f,
                        center = screenPos
                    )
                }

                // Passenger Occupancy Bar Gauge (above station)
                if (viewport.zoom >= 0.75f) {
                    val barWidth = 24f * viewport.zoom
                    val barHeight = 4f * viewport.zoom
                    val barX = screenPos.x - barWidth / 2
                    val barY = screenPos.y - radius - 10f

                    // Gauge Casing
                    drawRoundRect(
                        color = Color(0xFF1E293B),
                        topLeft = Offset(barX, barY),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(2f, 2f)
                    )

                    // Fill Percentage
                    val fillWidth = (barWidth * (station.passengerOccupancyPct / 100f)).coerceAtMost(barWidth)
                    drawRoundRect(
                        color = station.getOccupancyColor(),
                        topLeft = Offset(barX, barY),
                        size = Size(fillWidth, barHeight),
                        cornerRadius = CornerRadius(2f, 2f)
                    )
                }

                // Station Labels
                if (viewport.zoom >= 0.65f && textMeasurer != null) {
                    val labelOffset = Offset(screenPos.x + radius + 6f, screenPos.y - 8f)

                    // Dark backing pill for text contrast
                    val labelText = station.name
                    val isHub = station.isTransferHub

                    drawRoundRect(
                        color = Color(0xFF0F172A).copy(alpha = 0.85f),
                        topLeft = Offset(labelOffset.x - 2f, labelOffset.y - 2f),
                        size = Size(labelText.length * 7f + 12f, 16f),
                        cornerRadius = CornerRadius(3f, 3f)
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = labelText,
                        topLeft = labelOffset,
                        style = TextStyle(
                            color = if (isHub) Color.White else Color(0xFFE2E8F0),
                            fontSize = (if (isHub) 11 else 10).sp,
                            fontWeight = if (isHub) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
            }
        }
    }

    /**
     * Hit testing utility for finding a clicked station node.
     */
    fun findStationAtOffset(
        clickOffset: Offset,
        viewport: MapViewport,
        stations: List<StationNode>,
        touchRadiusDp: Float = 24f
    ): StationNode? {
        for (station in stations) {
            val screenPos = viewport.mapToScreen(station.position)
            val dx = clickOffset.x - screenPos.x
            val dy = clickOffset.y - screenPos.y
            val dist = sqrt(dx * dx + dy * dy)
            if (dist <= touchRadiusDp) {
                return station
            }
        }
        return null
    }
}
