package visualization

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class DirectionOfTravel {
    UPTOWN_NORTH,
    DOWNTOWN_SOUTH,
    BROOKLYN_BOUND,
    QUEENS_BOUND,
    BRONX_BOUND
}

enum class TrainOperationalStatus {
    IN_TRANSIT,
    APPROACHING_STATION,
    DWELLING_AT_STATION,
    HOLDING_PATTERN,
    EXPRESS_BYPASS,
    MAINTENANCE_SLOW
}

/**
 * Live Telemetry snapshot for an individual train consist.
 */
data class TrainTelemetry(
    val trainId: String,
    val lineCode: String,
    val routeId: String,
    val carType: String = "R160A",
    val carCount: Int = 10,
    val currentPosition: MapPoint,
    val targetStationId: String,
    val headingDegrees: Float,
    val speedMph: Float,
    val targetSpeedMph: Float,
    val status: TrainOperationalStatus,
    val direction: DirectionOfTravel,
    val passengerLoadPct: Int,
    val lineAccentColor: Color,
    val dwellTimerSeconds: Float = 0.0f
)

/**
 * State object representing animated train on track route.
 */
data class AnimatedTrain(
    val trainId: String,
    val lineCode: String,
    val routePoints: List<MapPoint>,
    val routeColor: Color,
    var currentSegmentIndex: Int = 0,
    var segmentProgress: Float = 0.0f, // 0.0 to 1.0 along current track segment
    var speedMph: Float = 38.0f,
    var isPaused: Boolean = false,
    var dwellTimeRemaining: Float = 0.0f,
    var status: TrainOperationalStatus = TrainOperationalStatus.IN_TRANSIT,
    val carCount: Int = 10,
    val passengerLoadPct: Int = 64
) {
    /**
     * Interpolates exact (X, Y) coordinate and rotation angle (degrees).
     */
    fun calculatePositionAndHeading(): Pair<MapPoint, Float> {
        if (routePoints.isEmpty()) return Pair(MapPoint(0f, 0f), 0f)
        if (routePoints.size == 1) return Pair(routePoints[0], 0f)

        val idx = currentSegmentIndex.coerceIn(0, routePoints.size - 2)
        val p1 = routePoints[idx]
        val p2 = routePoints[idx + 1]

        val x = p1.x + (p2.x - p1.x) * segmentProgress
        val y = p1.y + (p2.y - p1.y) * segmentProgress

        val dx = p2.x - p1.x
        val dy = p2.y - p1.y
        val headingRad = atan2(dy.toDouble(), dx.toDouble())
        val headingDeg = Math.toDegrees(headingRad).toFloat()

        return Pair(MapPoint(x, y), headingDeg)
    }

    /**
     * Converts animated state to live Telemetry packet for UI panels.
     */
    fun toTelemetry(): TrainTelemetry {
        val (pos, heading) = calculatePositionAndHeading()
        return TrainTelemetry(
            trainId = trainId,
            lineCode = lineCode,
            routeId = "RT-$lineCode",
            carType = "R211-MTA",
            carCount = carCount,
            currentPosition = pos,
            targetStationId = "ST-NEXT",
            headingDegrees = heading,
            speedMph = if (status == TrainOperationalStatus.DWELLING_AT_STATION) 0f else speedMph,
            targetSpeedMph = 45f,
            status = status,
            direction = if (heading in -90f..90f) DirectionOfTravel.DOWNTOWN_SOUTH else DirectionOfTravel.UPTOWN_NORTH,
            passengerLoadPct = passengerLoadPct,
            lineAccentColor = routeColor,
            dwellTimerSeconds = dwellTimeRemaining
        )
    }
}

/**
 * High-performance frame-based Animation Engine for Subway Trains.
 */
class TrainAnimationEngine {

    /**
     * Advances simulation state by deltaTime seconds.
     */
    fun tickSimulation(
        trains: List<AnimatedTrain>,
        deltaTimeSeconds: Float,
        speedFactor: Float = 1.0f
    ) {
        val effectiveDelta = deltaTimeSeconds * speedFactor

        for (train in trains) {
            if (train.isPaused) continue

            // Handle station dwell countdown
            if (train.dwellTimeRemaining > 0f) {
                train.dwellTimeRemaining -= effectiveDelta
                train.status = TrainOperationalStatus.DWELLING_AT_STATION
                train.speedMph = 0f
                if (train.dwellTimeRemaining <= 0f) {
                    train.dwellTimeRemaining = 0f
                    train.status = TrainOperationalStatus.IN_TRANSIT
                    train.speedMph = 35.0f
                }
                continue
            }

            if (train.routePoints.size < 2) continue

            val idx = train.currentSegmentIndex.coerceIn(0, train.routePoints.size - 2)
            val p1 = train.routePoints[idx]
            val p2 = train.routePoints[idx + 1]

            val dx = p2.x - p1.x
            val dy = p2.y - p1.y
            val segmentLength = sqrt(dx * dx + dy * dy).coerceAtLeast(1.0f)

            // Speed conversion: 1 unit on map ≈ 10 meters. 30 mph ≈ 13.4 m/s
            val travelUnitsPerSecond = (train.speedMph * 1.5f) / segmentLength
            train.segmentProgress += travelUnitsPerSecond * effectiveDelta

            if (train.segmentProgress >= 1.0f) {
                train.segmentProgress = 0.0f
                train.currentSegmentIndex++

                // Loop route or trigger dwell at terminus/station
                if (train.currentSegmentIndex >= train.routePoints.size - 1) {
                    train.currentSegmentIndex = 0
                    train.dwellTimeRemaining = 8.0f // Terminus turnaround dwell
                } else if (train.currentSegmentIndex % 3 == 0) {
                    train.dwellTimeRemaining = 4.0f // Station stop dwell
                }
            }
        }
    }

    /**
     * Draws animated train cars on Canvas with heading rotation, headlight beam,
     * and status indicator overlays.
     */
    fun renderTrainOverlays(
        drawScope: DrawScope,
        viewport: MapViewport,
        trains: List<AnimatedTrain>,
        selectedTrainId: String? = null,
        textMeasurer: TextMeasurer? = null
    ) {
        drawScope.apply {
            for (train in trains) {
                val (pos, headingDeg) = train.calculatePositionAndHeading()
                val screenPos = viewport.mapToScreen(pos)

                // Culling check: only render trains within viewport bounds
                if (screenPos.x < -100f || screenPos.x > size.width + 100f ||
                    screenPos.y < -100f || screenPos.y > size.height + 100f
                ) {
                    continue
                }

                val isSelected = train.trainId == selectedTrainId
                val carWidth = (28f * viewport.zoom).coerceIn(18f, 50f)
                val carHeight = (10f * viewport.zoom).coerceIn(6f, 18f)

                rotate(degrees = headingDeg, pivot = screenPos) {
                    // Headlight Glow Cone
                    val lightPath = Path().apply {
                        moveTo(screenPos.x + carWidth / 2, screenPos.y)
                        lineTo(screenPos.x + carWidth / 2 + 45f * viewport.zoom, screenPos.y - 18f * viewport.zoom)
                        lineTo(screenPos.x + carWidth / 2 + 45f * viewport.zoom, screenPos.y + 18f * viewport.zoom)
                        close()
                    }
                    drawPath(
                        path = lightPath,
                        color = Color(0xFFFEF08A).copy(alpha = if (train.status == TrainOperationalStatus.DWELLING_AT_STATION) 0.15f else 0.35f)
                    )

                    // Train Body Casing
                    drawRoundRect(
                        color = Color(0xFF0F172A),
                        topLeft = Offset(screenPos.x - carWidth / 2, screenPos.y - carHeight / 2),
                        size = Size(carWidth, carHeight),
                        cornerRadius = CornerRadius(4f, 4f)
                    )

                    // Line Route Color Stripe
                    drawRoundRect(
                        color = train.routeColor,
                        topLeft = Offset(screenPos.x - carWidth / 2 + 2f, screenPos.y - carHeight / 2 + 2f),
                        size = Size(carWidth - 4f, carHeight - 4f),
                        cornerRadius = CornerRadius(2f, 2f)
                    )

                    // Selection Pulse Ring
                    if (isSelected) {
                        drawRoundRect(
                            color = MTAColors.AccentCyan,
                            topLeft = Offset(screenPos.x - carWidth / 2 - 4f, screenPos.y - carHeight / 2 - 4f),
                            size = Size(carWidth + 8f, carHeight + 8f),
                            cornerRadius = CornerRadius(6f, 6f),
                            style = Stroke(width = 2.5f)
                        )
                    }

                    // Front White Cab Light
                    drawCircle(
                        color = Color.White,
                        radius = 2.5f * viewport.zoom,
                        center = Offset(screenPos.x + carWidth / 2 - 2f, screenPos.y)
                    )

                    // Rear Red Tail Lights
                    drawCircle(
                        color = Color.Red,
                        radius = 1.8f * viewport.zoom,
                        center = Offset(screenPos.x - carWidth / 2 + 2f, screenPos.y - carHeight / 4)
                    )
                    drawCircle(
                        color = Color.Red,
                        radius = 1.8f * viewport.zoom,
                        center = Offset(screenPos.x - carWidth / 2 + 2f, screenPos.y + carHeight / 4)
                    )
                }

                // Un-rotated Train Identifier Badge
                if (viewport.zoom >= 0.8f) {
                    val badgeX = screenPos.x + 12f
                    val badgeY = screenPos.y - 18f

                    drawCircle(
                        color = train.routeColor,
                        radius = 8f,
                        center = Offset(badgeX, badgeY)
                    )

                    if (textMeasurer != null) {
                        drawText(
                            textMeasurer = textMeasurer,
                            text = train.lineCode,
                            topLeft = Offset(badgeX - 4f, badgeY - 5f),
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif
                            )
                        )

                        val speedText = if (train.status == TrainOperationalStatus.DWELLING_AT_STATION) "STOP" else "${train.speedMph.toInt()} MPH"
                        drawText(
                            textMeasurer = textMeasurer,
                            text = speedText,
                            topLeft = Offset(badgeX + 10f, badgeY - 5f),
                            style = TextStyle(
                                color = if (train.status == TrainOperationalStatus.DWELLING_AT_STATION) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }
            }
        }
    }
}
