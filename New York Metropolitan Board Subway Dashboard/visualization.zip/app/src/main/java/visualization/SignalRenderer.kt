package visualization

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class SignalAspect {
    GREEN_PROCEED,
    YELLOW_APPROACH,
    RED_STOP,
    FLASHING_YELLOW_RESTRICTING
}

enum class SwitchPosition {
    STRAIGHT_MAIN,
    DIVERGING_TURNOUT
}

/**
 * Track Block model representing a signaling block section.
 */
data class TrackBlock(
    val blockId: String,
    val lineId: String,
    val points: List<MapPoint>,
    var isOccupied: Boolean = false,
    var activeSignalAspect: SignalAspect = SignalAspect.GREEN_PROCEED,
    val speedLimitMph: Int = 45
)

/**
 * Signal Head model located along track geometry.
 */
data class SignalNode(
    val signalId: String,
    val blockId: String,
    val position: MapPoint,
    var aspect: SignalAspect = SignalAspect.GREEN_PROCEED,
    val headingDegrees: Float = 0f
)

/**
 * Interlocking Rail Switch model.
 */
data class InterlockingSwitch(
    val switchId: String,
    val junctionPoint: MapPoint,
    val straightPoint: MapPoint,
    val turnoutPoint: MapPoint,
    var position: SwitchPosition = SwitchPosition.STRAIGHT_MAIN,
    var isLocked: Boolean = true
)

/**
 * Signalling Visualization Layer Renderer for Railway Operations.
 */
class SignalRenderer {

    /**
     * Renders track blocks, signal aspect heads, and interlocking switches.
     */
    fun renderSignalingLayer(
        drawScope: DrawScope,
        viewport: MapViewport,
        blocks: List<TrackBlock>,
        signals: List<SignalNode>,
        switches: List<InterlockingSwitch>,
        showBlockOccupancy: Boolean = true,
        showSignalHeads: Boolean = true,
        showSwitches: Boolean = true,
        textMeasurer: TextMeasurer? = null
    ) {
        drawScope.apply {
            // Layer 1: Render Track Block Occupancy Overlays
            if (showBlockOccupancy) {
                renderBlockOccupancy(viewport, blocks)
            }

            // Layer 2: Render Interlocking Switches
            if (showSwitches) {
                renderInterlockingSwitches(viewport, switches, textMeasurer)
            }

            // Layer 3: Render Railway Signal Heads & Lenses
            if (showSignalHeads) {
                renderSignalHeads(viewport, signals, textMeasurer)
            }
        }
    }

    private fun DrawScope.renderBlockOccupancy(viewport: MapViewport, blocks: List<TrackBlock>) {
        for (block in blocks) {
            if (block.points.size < 2) continue

            val path = Path().apply {
                val first = viewport.mapToScreen(block.points.first())
                moveTo(first.x, first.y)
                for (i in 1 until block.points.size) {
                    val pt = viewport.mapToScreen(block.points[i])
                    lineTo(pt.x, pt.y)
                }
            }

            val overlayColor = when {
                block.isOccupied -> Color(0xFFEF4444).copy(alpha = 0.65f) // Red Occupied Block
                block.activeSignalAspect == SignalAspect.YELLOW_APPROACH -> Color(0xFFF59E0B).copy(alpha = 0.4f) // Yellow Caution Block
                else -> Color(0xFF10B981).copy(alpha = 0.15f) // Green Clear Block
            }

            drawPath(
                path = path,
                color = overlayColor,
                style = Stroke(
                    width = 8f * viewport.zoom,
                    cap = StrokeCap.Round,
                    pathEffect = if (block.isOccupied) PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f) else null
                )
            )
        }
    }

    private fun DrawScope.renderSignalHeads(
        viewport: MapViewport,
        signals: List<SignalNode>,
        textMeasurer: TextMeasurer?
    ) {
        for (signal in signals) {
            val screenPos = viewport.mapToScreen(signal.position)

            // Viewport Culling
            if (screenPos.x < -50f || screenPos.x > size.width + 50f ||
                screenPos.y < -50f || screenPos.y > size.height + 50f
            ) {
                continue
            }

            val headWidth = 10f * viewport.zoom
            val headHeight = 22f * viewport.zoom

            // Signal Housing Backplate
            drawRoundRect(
                color = Color(0xFF020617),
                topLeft = Offset(screenPos.x - headWidth / 2, screenPos.y - headHeight / 2),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(3f, 3f)
            )
            drawRoundRect(
                color = Color(0xFF334155),
                topLeft = Offset(screenPos.x - headWidth / 2, screenPos.y - headHeight / 2),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(3f, 3f),
                style = Stroke(width = 1f)
            )

            val aspectColor = when (signal.aspect) {
                SignalAspect.GREEN_PROCEED -> Color(0xFF10B981)
                SignalAspect.YELLOW_APPROACH -> Color(0xFFF59E0B)
                SignalAspect.RED_STOP -> Color(0xFFEF4444)
                SignalAspect.FLASHING_YELLOW_RESTRICTING -> Color(0xFFEAB308)
            }

            // Top Light Lens
            drawCircle(
                color = if (signal.aspect == SignalAspect.RED_STOP) aspectColor else Color(0xFF1E293B),
                radius = 3f * viewport.zoom,
                center = Offset(screenPos.x, screenPos.y - headHeight / 4)
            )

            // Bottom Light Lens
            drawCircle(
                color = if (signal.aspect != SignalAspect.RED_STOP) aspectColor else Color(0xFF1E293B),
                radius = 3f * viewport.zoom,
                center = Offset(screenPos.x, screenPos.y + headHeight / 4)
            )

            // Light Glow Effect
            drawCircle(
                color = aspectColor.copy(alpha = 0.35f),
                radius = 7f * viewport.zoom,
                center = Offset(screenPos.x, screenPos.y + (if (signal.aspect == SignalAspect.RED_STOP) -headHeight / 4 else headHeight / 4))
            )

            // Signal Identifier Tag
            if (viewport.zoom >= 1.1f && textMeasurer != null) {
                drawText(
                    textMeasurer = textMeasurer,
                    text = signal.signalId,
                    topLeft = Offset(screenPos.x + headWidth + 4f, screenPos.y - 6f),
                    style = TextStyle(
                        color = Color(0xFF94A3B8),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }
        }
    }

    private fun DrawScope.renderInterlockingSwitches(
        viewport: MapViewport,
        switches: List<InterlockingSwitch>,
        textMeasurer: TextMeasurer?
    ) {
        for (sw in switches) {
            val junc = viewport.mapToScreen(sw.junctionPoint)
            val straight = viewport.mapToScreen(sw.straightPoint)
            val turnout = viewport.mapToScreen(sw.turnoutPoint)

            val activeTarget = if (sw.position == SwitchPosition.STRAIGHT_MAIN) straight else turnout
            val inactiveTarget = if (sw.position == SwitchPosition.STRAIGHT_MAIN) turnout else straight

            // Draw Inactive Alignment (Dashed Dim Line)
            drawLine(
                color = Color(0xFF475569),
                start = junc,
                end = inactiveTarget,
                strokeWidth = 2f * viewport.zoom,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            )

            // Draw Active Lined Path (Glowing Cyan)
            drawLine(
                color = MTAColors.AccentCyan,
                start = junc,
                end = activeTarget,
                strokeWidth = 4f * viewport.zoom
            )

            // Junction Point Indicator
            drawCircle(
                color = if (sw.isLocked) Color(0xFF38BDF8) else Color(0xFFF59E0B),
                radius = 5f * viewport.zoom,
                center = junc
            )

            if (viewport.zoom >= 1.2f && textMeasurer != null) {
                val statusText = if (sw.position == SwitchPosition.STRAIGHT_MAIN) "MAIN" else "TURNOUT"
                drawText(
                    textMeasurer = textMeasurer,
                    text = "${sw.switchId}: $statusText",
                    topLeft = Offset(junc.x + 8f, junc.y - 12f),
                    style = TextStyle(
                        color = Color(0xFF38BDF8),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }
        }
    }
}
