package visualization

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

/**
 * Data structures for NYC Subway Network Map rendering.
 */
data class MapPoint(val x: Float, val y: Float)

data class TrackSegmentData(
    val id: String,
    val lineId: String,
    val points: List<MapPoint>,
    val isExpress: Boolean = false,
    val trackNumber: Int = 1
)

data class SubwayLineModel(
    val id: String,
    val name: String,
    val code: String,
    val color: Color,
    val darkColor: Color,
    val segments: List<TrackSegmentData>,
    val description: String
)

data class MapViewport(
    val zoom: Float = 1.0f,
    val panX: Float = 0.0f,
    val panY: Float = 0.0f,
    val canvasWidth: Float = 1200.0f,
    val canvasHeight: Float = 800.0f
) {
    fun screenToMap(screenX: Float, screenY: Float): MapPoint {
        val mapX = (screenX - panX) / zoom
        val mapY = (screenY - panY) / zoom
        return MapPoint(mapX, mapY)
    }

    fun mapToScreen(mapPoint: MapPoint): Offset {
        return Offset(
            x = mapPoint.x * zoom + panX,
            y = mapPoint.y * zoom + panY
        )
    }
}

/**
 * MTA Official Subway Line Colors
 */
object MTAColors {
    val EighthAve = Color(0xFF0039A6) // A, C, E - Electric Blue
    val SixthAve = Color(0xFFFF6319)  // B, D, F, M - Bright Orange
    val Crosstown = Color(0xFF6CBE45)  // G - Lime Green
    val Canarsie = Color(0xFFA7A9AC)   // L - Slate Gray
    val Broadway = Color(0xFFFCCC0A)   // N, Q, R, W - Sunflower Yellow
    val SeventhAve = Color(0xFFEE352E) // 1, 2, 3 - Bright Red
    val Lexington = Color(0xFF00933C)  // 4, 5, 6 - Apple Green
    val Flushing = Color(0xFFB933AD)   // 7 - Raspberry Purple
    val Shuttle = Color(0xFF808183)    // S - Dark Gray
    val Nassau = Color(0xFF996633)     // J, Z - Brown

    // Control Room Grid Theme Colors
    val CanvasBg = Color(0xFF0B0F19)
    val GridLine = Color(0xFF1E293B)
    val MajorGridLine = Color(0xFF334155)
    val TrackBed = Color(0xFF1E2430)
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val AccentCyan = Color(0xFF38BDF8)
    val WaterBody = Color(0xFF0F172A)
    val WaterOutline = Color(0xFF1E293B)
}

/**
 * Primary Subway Map Renderer responsible for drawing the track network,
 * geography grid, route colors, and scale transformations.
 */
class SubwayMapRenderer {

    /**
     * Renders the complete subway map layer within the provided DrawScope.
     */
    fun renderMap(
        drawScope: DrawScope,
        viewport: MapViewport,
        lines: List<SubwayLineModel>,
        showGrid: Boolean = true,
        showBoroughs: Boolean = true,
        textMeasurer: TextMeasurer? = null
    ) {
        drawScope.apply {
            // Fill Background
            drawRect(color = MTAColors.CanvasBg, size = size)

            // Render Mission Control Grid & Geographic Background
            if (showGrid) {
                renderControlRoomGrid(viewport)
            }

            if (showBoroughs && textMeasurer != null) {
                renderBoroughOutlines(viewport, textMeasurer)
            }

            // Apply Camera Viewport Transformation (Pan & Zoom)
            withTransform({
                translate(left = viewport.panX, top = viewport.panY)
                scale(scaleX = viewport.zoom, scaleY = viewport.zoom, pivot = Offset.Zero)
            }) {
                // Layer 1: Render Track Beds & Ties
                renderTrackBeds(lines)

                // Layer 2: Render Mainline Track Geometry & Line Colors
                renderSubwayLines(lines)

                // Layer 3: Render Interlockings and Track Labels
                if (viewport.zoom > 1.2f && textMeasurer != null) {
                    renderLineIdentifiers(lines, textMeasurer)
                }
            }
        }
    }

    private fun DrawScope.renderControlRoomGrid(viewport: MapViewport) {
        val gridSize = 60.0f * viewport.zoom
        val width = size.width
        val height = size.height

        val startX = (viewport.panX % gridSize) - gridSize
        val startY = (viewport.panY % gridSize) - gridSize

        var x = startX
        var col = 0
        while (x < width + gridSize) {
            val isMajor = col % 5 == 0
            drawLine(
                color = if (isMajor) MTAColors.MajorGridLine else MTAColors.GridLine,
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = if (isMajor) 1.5f else 0.8f,
                pathEffect = if (!isMajor) PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f) else null
            )
            x += gridSize
            col++
        }

        var y = startY
        var row = 0
        while (y < height + gridSize) {
            val isMajor = row % 5 == 0
            drawLine(
                color = if (isMajor) MTAColors.MajorGridLine else MTAColors.GridLine,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = if (isMajor) 1.5f else 0.8f,
                pathEffect = if (!isMajor) PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f) else null
            )
            y += gridSize
            row++
        }
    }

    private fun DrawScope.renderBoroughOutlines(viewport: MapViewport, textMeasurer: TextMeasurer) {
        val boroughs = listOf(
            Pair("MANHATTAN CENTRAL CORRIDOR", MapPoint(350f, 180f)),
            Pair("BROOKLYN DOWNTOWN DIVISION", MapPoint(380f, 620f)),
            Pair("QUEENS PLAZA EXPRESS LINE", MapPoint(720f, 260f)),
            Pair("BRONX CONCOURSE TRUNK", MapPoint(420f, 60f))
        )

        for ((name, pt) in boroughs) {
            val screenPos = viewport.mapToScreen(pt)
            if (screenPos.x in -100f..size.width + 100f && screenPos.y in -100f..size.height + 100f) {
                drawText(
                    textMeasurer = textMeasurer,
                    text = name,
                    topLeft = screenPos,
                    style = TextStyle(
                        color = Color(0xFF334155),
                        fontSize = (12 * viewport.zoom).coerceIn(9f, 20f).sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                )
            }
        }
    }

    private fun DrawScope.renderTrackBeds(lines: List<SubwayLineModel>) {
        for (line in lines) {
            for (segment in line.segments) {
                if (segment.points.size < 2) continue

                val path = Path().apply {
                    val first = segment.points.first()
                    moveTo(first.x, first.y)
                    for (i in 1 until segment.points.size) {
                        val p = segment.points[i]
                        lineTo(p.x, p.y)
                    }
                }

                // Dark Track Bed casing
                drawPath(
                    path = path,
                    color = MTAColors.TrackBed,
                    style = Stroke(
                        width = if (segment.isExpress) 14f else 10f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
    }

    private fun DrawScope.renderSubwayLines(lines: List<SubwayLineModel>) {
        for (line in lines) {
            for (segment in line.segments) {
                if (segment.points.size < 2) continue

                val path = Path().apply {
                    val first = segment.points.first()
                    moveTo(first.x, first.y)
                    for (i in 1 until segment.points.size) {
                        val p = segment.points[i]
                        lineTo(p.x, p.y)
                    }
                }

                // Outer Line Glow / Core Line
                drawPath(
                    path = path,
                    color = line.color.copy(alpha = 0.3f),
                    style = Stroke(
                        width = if (segment.isExpress) 10f else 7f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                // Inner Main Track Line
                drawPath(
                    path = path,
                    color = line.color,
                    style = Stroke(
                        width = if (segment.isExpress) 5f else 3.5f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                        pathEffect = if (segment.isExpress) PathEffect.dashPathEffect(floatArrayOf(12f, 6f), 0f) else null
                    )
                )
            }
        }
    }

    private fun DrawScope.renderLineIdentifiers(lines: List<SubwayLineModel>, textMeasurer: TextMeasurer) {
        for (line in lines) {
            for (segment in line.segments) {
                if (segment.points.size < 2) continue
                val midIndex = segment.points.size / 2
                val midPoint = segment.points[midIndex]

                val badgeRadius = 10f
                drawCircle(
                    color = line.color,
                    radius = badgeRadius,
                    center = Offset(midPoint.x, midPoint.y)
                )
                drawCircle(
                    color = Color.White,
                    radius = badgeRadius,
                    center = Offset(midPoint.x, midPoint.y),
                    style = Stroke(width = 1.5f)
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = line.code,
                    topLeft = Offset(midPoint.x - 5f, midPoint.y - 6f),
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif
                    )
                )
            }
        }
    }
}
