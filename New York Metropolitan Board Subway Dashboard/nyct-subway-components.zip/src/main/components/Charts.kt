package components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LegendToggle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

/**
 * Enterprise Chart Component Library
 * Designed for New York Metropolitan Board Digital Subway Control System.
 * Supports Line, Bar, Area, and Live Time-Series Charts with dark mode styling,
 * responsive Canvas rendering, interactive tooltips, and decoupled telemetry models.
 */

// ============================================================================
// DATA MODELS
// ============================================================================

data class DataPoint(
    val x: Double,
    val y: Double,
    val label: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap()
)

data class ChartSeries(
    val id: String,
    val name: String,
    val data: List<DataPoint>,
    val color: Color,
    val secondaryColor: Color? = null,
    val strokeWidth: Dp = 2.5.dp,
    val isVisible: Boolean = true,
    val isDashed: Boolean = false
)

data class AxisConfig(
    val xTitle: String? = null,
    val yTitle: String? = null,
    val showGridLines: Boolean = true,
    val gridColor: Color = Color(0xFF334155),
    val yMin: Double? = null,
    val yMax: Double? = null,
    val yStepCount: Int = 5,
    val xLabelFormatter: (Double) -> String = { "%.0f".format(it) },
    val yLabelFormatter: (Double) -> String = { "%.1f".format(it) }
)

enum class BarChartMode {
    SINGLE, GROUPED, STACKED
}

enum class LegendPosition {
    TOP, BOTTOM, NONE
}

data class SelectedPointInfo(
    val seriesName: String,
    val point: DataPoint,
    val color: Color,
    val offset: Offset
)

// ============================================================================
// REUSABLE CONTAINER
// ============================================================================

@Composable
fun ChartContainer(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    isLiveTelemetry: Boolean = false,
    seriesList: List<ChartSeries> = emptyList(),
    onToggleSeries: ((String) -> Unit)? = null,
    legendPosition: LegendPosition = LegendPosition.BOTTOM,
    actionButtons: @Composable RowScope.() -> Unit = {},
    content: @Composable BoxScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F172A),
            contentColor = Color(0xFFF8FAFC)
        ),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8FAFC)
                        )
                        if (isLiveTelemetry) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF22C55E).copy(alpha = 0.15f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22C55E)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "LIVE TELEMETRY",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF22C55E)
                                    )
                                }
                            }
                        }
                    }
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    actionButtons()
                }
            }

            // Top Legend
            if (legendPosition == LegendPosition.TOP && seriesList.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                ChartLegendRow(seriesList = seriesList, onToggleSeries = onToggleSeries)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Chart Canvas Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                content()
            }

            // Bottom Legend
            if (legendPosition == LegendPosition.BOTTOM && seriesList.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                ChartLegendRow(seriesList = seriesList, onToggleSeries = onToggleSeries)
            }
        }
    }
}

@Composable
private fun ChartLegendRow(
    seriesList: List<ChartSeries>,
    onToggleSeries: ((String) -> Unit)?
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        seriesList.forEach { series ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .clickable(enabled = onToggleSeries != null) {
                        onToggleSeries?.invoke(series.id)
                    }
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (series.isVisible) series.color else Color.Gray)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = series.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (series.isVisible) Color(0xFFCBD5E1) else Color(0xFF64748B),
                    textDecoration = if (series.isVisible) null else TextDecoration.LineThrough
                )
            }
        }
    }
}

// ============================================================================
// 1. LINE CHART
// ============================================================================

@Composable
fun LineChart(
    seriesList: List<ChartSeries>,
    modifier: Modifier = Modifier,
    axisConfig: AxisConfig = AxisConfig(),
    thresholdValue: Double? = null,
    thresholdLabel: String? = null
) {
    val visibleSeries = seriesList.filter { it.isVisible && it.data.isNotEmpty() }
    var selectedPointInfo by remember { mutableStateOf<SelectedPointInfo?>(null) }
    val textMeasurer = rememberTextMeasurer()

    val allPoints = visibleSeries.flatMap { it.data }
    if (allPoints.isEmpty()) {
        EmptyChartState("No telemetry data points available")
        return
    }

    val minX = allPoints.minOf { it.x }
    val maxX = max(allPoints.maxOf { it.x }, minX + 1.0)
    val computedMinY = axisConfig.yMin ?: allPoints.minOf { it.y }
    val computedMaxY = axisConfig.yMax ?: allPoints.maxOf { it.y }
    val minY = min(computedMinY, thresholdValue ?: computedMinY)
    val maxY = max(computedMaxY, thresholdValue ?: computedMaxY).let {
        if (it == minY) it + 1.0 else it
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(visibleSeries) {
                    detectTapGestures { tapOffset ->
                        var closestPoint: SelectedPointInfo? = null
                        var minDistance = Float.MAX_VALUE

                        // Canvas measurements mirror draw phase
                        val paddingLeft = 50.dp.toPx()
                        val paddingRight = 16.dp.toPx()
                        val paddingTop = 16.dp.toPx()
                        val paddingBottom = 32.dp.toPx()
                        val chartWidth = size.width - paddingLeft - paddingRight
                        val chartHeight = size.height - paddingTop - paddingBottom

                        visibleSeries.forEach { series ->
                            series.data.forEach { pt ->
                                val xPx = paddingLeft + ((pt.x - minX) / (maxX - minX) * chartWidth).toFloat()
                                val yPx = paddingTop + (chartHeight - ((pt.y - minY) / (maxY - minY) * chartHeight)).toFloat()
                                val pointOffset = Offset(xPx, yPx)
                                val dist = (pointOffset - tapOffset).getDistance()
                                if (dist < minDistance && dist < 40.dp.toPx()) {
                                    minDistance = dist
                                    closestPoint = SelectedPointInfo(series.name, pt, series.color, pointOffset)
                                }
                            }
                        }
                        selectedPointInfo = closestPoint
                    }
                }
        ) {
            val paddingLeft = 50.dp.toPx()
            val paddingRight = 16.dp.toPx()
            val paddingTop = 16.dp.toPx()
            val paddingBottom = 32.dp.toPx()
            val chartWidth = size.width - paddingLeft - paddingRight
            val chartHeight = size.height - paddingTop - paddingBottom

            // 1. Grid lines and Y Axis Labels
            val stepY = (maxY - minY) / axisConfig.yStepCount
            for (i in 0..axisConfig.yStepCount) {
                val valueY = minY + stepY * i
                val yPx = paddingTop + (chartHeight - (i.toFloat() / axisConfig.yStepCount * chartHeight))

                if (axisConfig.showGridLines) {
                    drawLine(
                        color = axisConfig.gridColor,
                        start = Offset(paddingLeft, yPx),
                        end = Offset(size.width - paddingRight, yPx),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                    )
                }

                // Y label
                val labelText = axisConfig.yLabelFormatter(valueY)
                val measuredText = textMeasurer.measure(
                    text = labelText,
                    style = TextStyle(color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                )
                drawText(
                    textLayoutResult = measuredText,
                    topLeft = Offset(paddingLeft - measuredText.size.width - 8.dp.toPx(), yPx - measuredText.size.height / 2f)
                )
            }

            // X Axis Labels (5 intervals)
            val xSteps = 5
            val stepXVal = (maxX - minX) / xSteps
            for (i in 0..xSteps) {
                val valueX = minX + stepXVal * i
                val xPx = paddingLeft + (i.toFloat() / xSteps * chartWidth)

                val labelText = axisConfig.xLabelFormatter(valueX)
                val measuredText = textMeasurer.measure(
                    text = labelText,
                    style = TextStyle(color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                )
                drawText(
                    textLayoutResult = measuredText,
                    topLeft = Offset(xPx - measuredText.size.width / 2f, size.height - paddingBottom + 6.dp.toPx())
                )
            }

            // Threshold line
            if (thresholdValue != null) {
                val tYPx = paddingTop + (chartHeight - ((thresholdValue - minY) / (maxY - minY) * chartHeight)).toFloat()
                drawLine(
                    color = Color(0xFFEF4444),
                    start = Offset(paddingLeft, tYPx),
                    end = Offset(size.width - paddingRight, tYPx),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f))
                )
                if (thresholdLabel != null) {
                    val tMeasured = textMeasurer.measure(
                        text = thresholdLabel,
                        style = TextStyle(color = Color(0xFFEF4444), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                    drawText(
                        textLayoutResult = tMeasured,
                        topLeft = Offset(size.width - paddingRight - tMeasured.size.width, tYPx - tMeasured.size.height - 2.dp.toPx())
                    )
                }
            }

            // 2. Plot Lines & Data Points
            visibleSeries.forEach { series ->
                if (series.data.isEmpty()) return@forEach

                val path = Path()
                series.data.forEachIndexed { index, pt ->
                    val xPx = paddingLeft + ((pt.x - minX) / (maxX - minX) * chartWidth).toFloat()
                    val yPx = paddingTop + (chartHeight - ((pt.y - minY) / (maxY - minY) * chartHeight)).toFloat()

                    if (index == 0) {
                        path.moveTo(xPx, yPx)
                    } else {
                        path.lineTo(xPx, yPx)
                    }
                }

                drawPath(
                    path = path,
                    color = series.color,
                    style = Stroke(
                        width = series.strokeWidth.toPx(),
                        pathEffect = if (series.isDashed) PathEffect.dashPathEffect(floatArrayOf(10f, 6f)) else null,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                // Points
                series.data.forEach { pt ->
                    val xPx = paddingLeft + ((pt.x - minX) / (maxX - minX) * chartWidth).toFloat()
                    val yPx = paddingTop + (chartHeight - ((pt.y - minY) / (maxY - minY) * chartHeight)).toFloat()

                    drawCircle(
                        color = series.color,
                        radius = 3.dp.toPx(),
                        center = Offset(xPx, yPx)
                    )
                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = 1.5.dp.toPx(),
                        center = Offset(xPx, yPx)
                    )
                }
            }

            // Selected Highlight Indicator
            selectedPointInfo?.let { info ->
                drawCircle(
                    color = info.color,
                    radius = 7.dp.toPx(),
                    center = info.offset
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = info.offset
                )
            }
        }

        // Interactive Tooltip Box Overlay
        selectedPointInfo?.let { info ->
            ChartTooltip(info = info, onDismiss = { selectedPointInfo = null })
        }
    }
}

// ============================================================================
// 2. BAR CHART
// ============================================================================

@Composable
fun BarChart(
    seriesList: List<ChartSeries>,
    modifier: Modifier = Modifier,
    mode: BarChartMode = BarChartMode.SINGLE,
    axisConfig: AxisConfig = AxisConfig(),
    targetValue: Double? = null
) {
    val visibleSeries = seriesList.filter { it.isVisible && it.data.isNotEmpty() }
    val textMeasurer = rememberTextMeasurer()
    var selectedPointInfo by remember { mutableStateOf<SelectedPointInfo?>(null) }

    if (visibleSeries.isEmpty()) {
        EmptyChartState("No bar chart data available")
        return
    }

    // Collect category labels
    val categories = visibleSeries.flatMap { it.data }.map { it.label ?: axisConfig.xLabelFormatter(it.x) }.distinct()
    if (categories.isEmpty()) return

    val maxVal = max(
        visibleSeries.flatMap { it.data }.maxOfOrNull { it.y } ?: 1.0,
        targetValue ?: 0.0
    ).let { if (it <= 0) 1.0 else it }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(visibleSeries) {
                    detectTapGestures { tapOffset ->
                        val paddingLeft = 50.dp.toPx()
                        val paddingRight = 16.dp.toPx()
                        val paddingTop = 16.dp.toPx()
                        val paddingBottom = 32.dp.toPx()
                        val chartWidth = size.width - paddingLeft - paddingRight
                        val chartHeight = size.height - paddingTop - paddingBottom

                        val categoryWidth = chartWidth / categories.size

                        categories.forEachIndexed { catIdx, cat ->
                            val catStartX = paddingLeft + catIdx * categoryWidth
                            if (tapOffset.x >= catStartX && tapOffset.x <= catStartX + categoryWidth) {
                                // Find matching data point
                                visibleSeries.firstOrNull()?.data?.firstOrNull {
                                    (it.label ?: axisConfig.xLabelFormatter(it.x)) == cat
                                }?.let { pt ->
                                    val barHPx = (pt.y / maxVal * chartHeight).toFloat()
                                    val yPx = paddingTop + chartHeight - barHPx
                                    selectedPointInfo = SelectedPointInfo(
                                        seriesName = cat,
                                        point = pt,
                                        color = visibleSeries.first().color,
                                        offset = Offset(catStartX + categoryWidth / 2f, yPx)
                                    )
                                }
                            }
                        }
                    }
                }
        ) {
            val paddingLeft = 50.dp.toPx()
            val paddingRight = 16.dp.toPx()
            val paddingTop = 16.dp.toPx()
            val paddingBottom = 32.dp.toPx()
            val chartWidth = size.width - paddingLeft - paddingRight
            val chartHeight = size.height - paddingTop - paddingBottom

            // Grid lines
            val ySteps = axisConfig.yStepCount
            for (i in 0..ySteps) {
                val valueY = (maxVal / ySteps) * i
                val yPx = paddingTop + (chartHeight - (i.toFloat() / ySteps * chartHeight))

                if (axisConfig.showGridLines) {
                    drawLine(
                        color = axisConfig.gridColor,
                        start = Offset(paddingLeft, yPx),
                        end = Offset(size.width - paddingRight, yPx),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                val measuredText = textMeasurer.measure(
                    text = axisConfig.yLabelFormatter(valueY),
                    style = TextStyle(color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                )
                drawText(
                    textLayoutResult = measuredText,
                    topLeft = Offset(paddingLeft - measuredText.size.width - 8.dp.toPx(), yPx - measuredText.size.height / 2f)
                )
            }

            // Target Line
            if (targetValue != null) {
                val tYPx = paddingTop + (chartHeight - (targetValue / maxVal * chartHeight)).toFloat()
                drawLine(
                    color = Color(0xFFF59E0B),
                    start = Offset(paddingLeft, tYPx),
                    end = Offset(size.width - paddingRight, tYPx),
                    strokeWidth = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
            }

            // Draw Bars per category
            val categoryWidth = chartWidth / categories.size
            val groupGap = categoryWidth * 0.2f
            val availableBarArea = categoryWidth - groupGap

            categories.forEachIndexed { catIndex, category ->
                val groupLeft = paddingLeft + (catIndex * categoryWidth) + (groupGap / 2f)

                if (mode == BarChartMode.SINGLE || mode == BarChartMode.GROUPED) {
                    val barWidth = availableBarArea / visibleSeries.size
                    visibleSeries.forEachIndexed { seriesIdx, series ->
                        val pt = series.data.firstOrNull { (it.label ?: axisConfig.xLabelFormatter(it.x)) == category }
                        if (pt != null) {
                            val barHeightPx = (pt.y / maxVal * chartHeight).toFloat()
                            val barLeft = groupLeft + (seriesIdx * barWidth)
                            val barTop = paddingTop + chartHeight - barHeightPx

                            drawRoundRect(
                                color = series.color,
                                topLeft = Offset(barLeft + 2.dp.toPx(), barTop),
                                size = Size(max(barWidth - 4.dp.toPx(), 2f), barHeightPx),
                                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                            )
                        }
                    }
                }

                // X Axis category text
                val textLayout = textMeasurer.measure(
                    text = category,
                    style = TextStyle(color = Color(0xFFCBD5E1), fontSize = 10.sp, fontWeight = FontWeight.Medium)
                )
                drawText(
                    textLayoutResult = textLayout,
                    topLeft = Offset(groupLeft + (availableBarArea / 2f) - (textLayout.size.width / 2f), size.height - paddingBottom + 6.dp.toPx())
                )
            }
        }

        selectedPointInfo?.let { info ->
            ChartTooltip(info = info, onDismiss = { selectedPointInfo = null })
        }
    }
}

// ============================================================================
// 3. AREA CHART
// ============================================================================

@Composable
fun AreaChart(
    seriesList: List<ChartSeries>,
    modifier: Modifier = Modifier,
    axisConfig: AxisConfig = AxisConfig()
) {
    val visibleSeries = seriesList.filter { it.isVisible && it.data.isNotEmpty() }
    val textMeasurer = rememberTextMeasurer()

    if (visibleSeries.isEmpty()) {
        EmptyChartState("No area chart data available")
        return
    }

    val allPoints = visibleSeries.flatMap { it.data }
    val minX = allPoints.minOf { it.x }
    val maxX = max(allPoints.maxOf { it.x }, minX + 1.0)
    val minY = axisConfig.yMin ?: min(0.0, allPoints.minOf { it.y })
    val maxY = axisConfig.yMax ?: allPoints.maxOf { it.y }.let { if (it == minY) it + 1.0 else it }

    Canvas(modifier = modifier.fillMaxSize()) {
        val paddingLeft = 50.dp.toPx()
        val paddingRight = 16.dp.toPx()
        val paddingTop = 16.dp.toPx()
        val paddingBottom = 32.dp.toPx()
        val chartWidth = size.width - paddingLeft - paddingRight
        val chartHeight = size.height - paddingTop - paddingBottom

        // Grid
        val stepY = (maxY - minY) / axisConfig.yStepCount
        for (i in 0..axisConfig.yStepCount) {
            val valueY = minY + stepY * i
            val yPx = paddingTop + (chartHeight - (i.toFloat() / axisConfig.yStepCount * chartHeight))

            if (axisConfig.showGridLines) {
                drawLine(
                    color = axisConfig.gridColor,
                    start = Offset(paddingLeft, yPx),
                    end = Offset(size.width - paddingRight, yPx),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val measuredText = textMeasurer.measure(
                text = axisConfig.yLabelFormatter(valueY),
                style = TextStyle(color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            )
            drawText(
                textLayoutResult = measuredText,
                topLeft = Offset(paddingLeft - measuredText.size.width - 8.dp.toPx(), yPx - measuredText.size.height / 2f)
            )
        }

        // Draw Area Fill + Stroke for each series
        visibleSeries.forEach { series ->
            if (series.data.isEmpty()) return@forEach

            val strokePath = Path()
            val fillPath = Path()

            val zeroYPx = paddingTop + (chartHeight - ((0.0 - minY) / (maxY - minY) * chartHeight)).toFloat().coerceIn(paddingTop, paddingTop + chartHeight)

            series.data.forEachIndexed { index, pt ->
                val xPx = paddingLeft + ((pt.x - minX) / (maxX - minX) * chartWidth).toFloat()
                val yPx = paddingTop + (chartHeight - ((pt.y - minY) / (maxY - minY) * chartHeight)).toFloat()

                if (index == 0) {
                    strokePath.moveTo(xPx, yPx)
                    fillPath.moveTo(xPx, zeroYPx)
                    fillPath.lineTo(xPx, yPx)
                } else {
                    strokePath.lineTo(xPx, yPx)
                    fillPath.lineTo(xPx, yPx)
                }

                if (index == series.data.lastIndex) {
                    fillPath.lineTo(xPx, zeroYPx)
                    fillPath.close()
                }
            }

            // Fill Area Gradient
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        series.color.copy(alpha = 0.45f),
                        series.color.copy(alpha = 0.05f)
                    ),
                    startY = paddingTop,
                    endY = paddingTop + chartHeight
                )
            )

            // Top Line
            drawPath(
                path = strokePath,
                color = series.color,
                style = Stroke(width = series.strokeWidth.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

// ============================================================================
// 4. TIME-SERIES LIVE CHART
// ============================================================================

@Composable
fun TimeSeriesChart(
    telemetrySeries: ChartSeries,
    modifier: Modifier = Modifier,
    windowDurationMs: Long = 60_000L, // 60s window
    unitLabel: String = "mph",
    warningThreshold: Double? = null,
    criticalThreshold: Double? = null
) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    val textMeasurer = rememberTextMeasurer()

    val currentTime = System.currentTimeMillis()
    val startTime = currentTime - windowDurationMs
    val filteredData = telemetrySeries.data.filter { it.timestamp >= startTime }

    val points = if (filteredData.isEmpty()) listOf(DataPoint(currentTime.toDouble(), 0.0, timestamp = currentTime)) else filteredData

    val minY = 0.0
    val maxDataY = points.maxOfOrNull { it.y } ?: 1.0
    val maxY = max(maxDataY, (criticalThreshold ?: warningThreshold ?: maxDataY) * 1.15).let { if (it <= 0) 100.0 else it }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val paddingLeft = 50.dp.toPx()
            val paddingRight = 16.dp.toPx()
            val paddingTop = 20.dp.toPx()
            val paddingBottom = 32.dp.toPx()
            val chartWidth = size.width - paddingLeft - paddingRight
            val chartHeight = size.height - paddingTop - paddingBottom

            // Threshold lines
            warningThreshold?.let { t ->
                val yPx = paddingTop + (chartHeight - ((t - minY) / (maxY - minY) * chartHeight)).toFloat()
                drawLine(
                    color = Color(0xFFF59E0B),
                    start = Offset(paddingLeft, yPx),
                    end = Offset(size.width - paddingRight, yPx),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
            }

            criticalThreshold?.let { t ->
                val yPx = paddingTop + (chartHeight - ((t - minY) / (maxY - minY) * chartHeight)).toFloat()
                drawLine(
                    color = Color(0xFFEF4444),
                    start = Offset(paddingLeft, yPx),
                    end = Offset(size.width - paddingRight, yPx),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
            }

            // Grid
            for (i in 0..4) {
                val valY = (maxY / 4) * i
                val yPx = paddingTop + (chartHeight - (i.toFloat() / 4 * chartHeight))
                drawLine(
                    color = Color(0xFF334155),
                    start = Offset(paddingLeft, yPx),
                    end = Offset(size.width - paddingRight, yPx),
                    strokeWidth = 1.dp.toPx()
                )

                val labelText = "%.0f %s".format(valY, unitLabel)
                val measured = textMeasurer.measure(
                    text = labelText,
                    style = TextStyle(color = Color(0xFF94A3B8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                )
                drawText(
                    textLayoutResult = measured,
                    topLeft = Offset(paddingLeft - measured.size.width - 6.dp.toPx(), yPx - measured.size.height / 2f)
                )
            }

            // Real-time Path
            val path = Path()
            val fillPath = Path()

            points.forEachIndexed { index, pt ->
                val xNorm = ((pt.timestamp - startTime).toDouble() / windowDurationMs).coerceIn(0.0, 1.0)
                val xPx = paddingLeft + (xNorm * chartWidth).toFloat()
                val yPx = paddingTop + (chartHeight - ((pt.y - minY) / (maxY - minY) * chartHeight)).toFloat()

                if (index == 0) {
                    path.moveTo(xPx, yPx)
                    fillPath.moveTo(xPx, paddingTop + chartHeight)
                    fillPath.lineTo(xPx, yPx)
                } else {
                    path.lineTo(xPx, yPx)
                    fillPath.lineTo(xPx, yPx)
                }

                if (index == points.lastIndex) {
                    fillPath.lineTo(xPx, paddingTop + chartHeight)
                    fillPath.close()
                }
            }

            // Fill
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(telemetrySeries.color.copy(alpha = 0.35f), Color.Transparent),
                    startY = paddingTop,
                    endY = paddingTop + chartHeight
                )
            )

            // Line
            drawPath(
                path = path,
                color = telemetrySeries.color,
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Pulse indicator on latest data point
            points.lastOrNull()?.let { lastPt ->
                val xNorm = ((lastPt.timestamp - startTime).toDouble() / windowDurationMs).coerceIn(0.0, 1.0)
                val xPx = paddingLeft + (xNorm * chartWidth).toFloat()
                val yPx = paddingTop + (chartHeight - ((lastPt.y - minY) / (maxY - minY) * chartHeight)).toFloat()

                drawCircle(color = telemetrySeries.color.copy(alpha = 0.3f), radius = 10.dp.toPx(), center = Offset(xPx, yPx))
                drawCircle(color = telemetrySeries.color, radius = 5.dp.toPx(), center = Offset(xPx, yPx))
                drawCircle(color = Color.White, radius = 2.dp.toPx(), center = Offset(xPx, yPx))
            }

            // Time X Axis (4 markers)
            for (i in 0..3) {
                val markTime = startTime + (windowDurationMs / 3 * i)
                val xPx = paddingLeft + (i.toFloat() / 3 * chartWidth)
                val timeStr = dateFormat.format(Date(markTime))

                val measured = textMeasurer.measure(
                    text = timeStr,
                    style = TextStyle(color = Color(0xFF94A3B8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                )
                drawText(
                    textLayoutResult = measured,
                    topLeft = Offset(xPx - measured.size.width / 2f, size.height - paddingBottom + 6.dp.toPx())
                )
            }
        }
    }
}

// ============================================================================
// HELPER COMPONENTS
// ============================================================================

@Composable
private fun ChartTooltip(
    info: SelectedPointInfo,
    onDismiss: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    Surface(
        modifier = Modifier
            .padding(16.dp)
            .border(1.dp, info.color, RoundedCornerShape(8.dp)),
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(8.dp),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(info.color)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = info.seriesName,
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFE2E8F0),
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Value: ${info.point.y} ${info.point.label ?: ""}",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Time: ${dateFormat.format(Date(info.point.timestamp))}",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8)
            )
            if (info.point.metadata.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                info.point.metadata.forEach { (k, v) ->
                    Text(
                        text = "$k: $v",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF38BDF8)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyChartState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF94A3B8)
            )
        }
    }
}
