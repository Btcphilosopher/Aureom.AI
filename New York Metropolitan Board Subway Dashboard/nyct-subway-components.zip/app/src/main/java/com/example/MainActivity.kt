package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import components.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                ControlCenterDashboard()
            }
        }
    }
}

enum class NavigationTab(val label: String) {
    MAP("Map"),
    DATA("Data"),
    ALERTS("Alerts"),
    ADMIN("Admin")
}

@Composable
fun ControlCenterDashboard() {
    var selectedTab by remember { mutableStateOf(NavigationTab.DATA) }
    var clockTime by remember { mutableStateOf("14:20:02:11") }

    // Live clock simulator
    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("HH:mm:ss:SS", Locale.US)
        while (true) {
            clockTime = formatter.format(Date()).take(11)
            kotlinx.coroutines.delay(100)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF1C1B1F),
        bottomBar = {
            M3NavigationBar(
                selectedTab = selectedTab,
                onTabSelect = { selectedTab = it }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color(0xFF1C1B1F))
        ) {
            // System Header
            ControlCenterSystemHeader(clockTime = clockTime)

            // Dynamic Content according to selected tab
            when (selectedTab) {
                NavigationTab.DATA -> MainDataOverviewScreen()
                NavigationTab.ALERTS -> LiveAlertsScreen()
                NavigationTab.MAP -> TelemetryMapScreen()
                NavigationTab.ADMIN -> SystemAdminScreen()
            }
        }
    }
}

// ============================================================================
// SYSTEM HEADER (Design Theme Specs)
// ============================================================================

@Composable
fun ControlCenterSystemHeader(clockTime: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1C1B1F))
            .border(
                width = 1.dp,
                color = Color(0xFF49454F)
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NY-MBDSC CONTROL CENTER",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD0BCFF),
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "SYSTEM_OPS_042",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFE6E1E9)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "WSS: CONNECTED",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = Color(0xFFCAC4D0).copy(alpha = 0.6f)
                    )
                    Text(
                        text = clockTime,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFE6E1E9)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF4ADE80))
                )
            }
        }
    }
}

// ============================================================================
// MAIN DATA OVERVIEW SCREEN
// ============================================================================

@Composable
fun MainDataOverviewScreen() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Critical Alert Banner (M3 Style)
        CriticalAlertBanner()

        // Line Load Distribution (Telemetry Support Chart)
        LineLoadDistributionSection()

        // Live Mission Critical Data Table
        LiveMissionCriticalDataTable()
    }
}

@Composable
fun CriticalAlertBanner() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF8C1D18), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF31111D)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF8C1D18)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CRITICAL ALERT",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF2B8B5)
                    )
                    Text(
                        text = "0.2m ago",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Signal Failure: Sector 7G (Q-Line / Manhattan Bridge)",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE6E1E9),
                    fontWeight = FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun LineLoadDistributionSection() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LINE LOAD DISTRIBUTION",
                style = MaterialTheme.typography.labelMedium,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFD0BCFF),
                letterSpacing = 1.sp
            )
            Text(
                text = "+2.4% NOMINAL",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF4ADE80)
            )
        }

        val sampleBarSeries = remember {
            ChartSeries(
                id = "line_load",
                name = "Capacity %",
                data = listOf(
                    DataPoint(1.0, 40.0, "L-Line"),
                    DataPoint(2.0, 65.0, "Q-Line"),
                    DataPoint(3.0, 90.0, "M-Line"),
                    DataPoint(4.0, 55.0, "R-Line"),
                    DataPoint(5.0, 75.0, "A-Line"),
                    DataPoint(6.0, 30.0, "7-Line")
                ),
                color = Color(0xFFD0BCFF)
            )
        }

        BarChart(
            seriesList = listOf(sampleBarSeries),
            modifier = Modifier.height(220.dp),
            axisConfig = AxisConfig(
                gridColor = Color(0xFF49454F),
                xLabelFormatter = { index ->
                    when (index.toInt()) {
                        1 -> "L"
                        2 -> "Q"
                        3 -> "M"
                        4 -> "R"
                        5 -> "A"
                        6 -> "7"
                        else -> ""
                    }
                },
                yLabelFormatter = { "${it.toInt()}%" }
            )
        )
    }
}

@Composable
fun LiveMissionCriticalDataTable() {
    val columns = remember {
        listOf(
            TableColumn<TrainTelemetry>(
                id = "unit",
                header = "UNIT",
                width = TableColumnWidth.Weight(1f),
                cellContent = { item ->
                    Text(
                        text = item.trainId,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E9)
                    )
                }
            ),
            TableColumn<TrainTelemetry>(
                id = "track",
                header = "TRACK",
                width = TableColumnWidth.Weight(1f),
                cellContent = { item ->
                    Text(
                        text = item.lineId,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFD0BCFF)
                    )
                }
            ),
            TableColumn<TrainTelemetry>(
                id = "speed",
                header = "SPEED",
                width = TableColumnWidth.Weight(1f),
                cellContent = { item ->
                    Text(
                        text = "${item.speedMph.toInt()}km/h",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE6E1E9)
                    )
                }
            ),
            TableColumn<TrainTelemetry>(
                id = "status",
                header = "STATUS",
                width = TableColumnWidth.Weight(1f),
                cellContent = { item ->
                    StatusBadge(status = item.status)
                }
            )
        )
    }

    val telemetryData = remember {
        listOf(
            TrainTelemetry("#4802", "L-02", "14th St-Union Sq", 42.0, 68, StatusBadgeType.OPERATIONAL, 120, "DRV-102"),
            TrainTelemetry("#1154", "Q-07", "Manhattan Bridge", 0.0, 92, StatusBadgeType.DELAYED, 45, "DRV-304"),
            TrainTelemetry("#3391", "M-01", "Delancey St", 55.0, 45, StatusBadgeType.OPERATIONAL, 300, "DRV-882"),
            TrainTelemetry("#9210", "R-14", "36th St", 12.0, 50, StatusBadgeType.MAINTENANCE, 10, "DRV-512"),
            TrainTelemetry("#7033", "A-04", "Jay St-MetroTech", 48.0, 78, StatusBadgeType.OPERATIONAL, 210, "DRV-661"),
            TrainTelemetry("#5520", "7-09", "Grand Central", 35.0, 85, StatusBadgeType.WARNING, 80, "DRV-401")
        )
    }

    EnterpriseTable(
        columns = columns,
        items = telemetryData,
        modifier = Modifier.fillMaxWidth()
    )
}

// ============================================================================
// LIVE ALERTS SCREEN
// ============================================================================

@Composable
fun LiveAlertsScreen() {
    val sampleAlerts = remember {
        mutableStateListOf(
            AlertItem(
                id = "ALT-101",
                title = "Signal Failure: Sector 7G",
                message = "Interlocking signal 44B uncommunicative. Q-Line holding on Manhattan Bridge.",
                severity = AlertSeverity.EMERGENCY,
                category = AlertCategory.SIGNAL,
                location = "Manhattan Bridge Cut",
                lineId = "Q",
                incidentId = "7749"
            ),
            AlertItem(
                id = "ALT-102",
                title = "Substation Power Surge",
                message = "Feeder 12B voltage spiked +14%. Automatic breaker engaged at 14th St Substation.",
                severity = AlertSeverity.CRITICAL,
                category = AlertCategory.POWER,
                location = "14th St Substation",
                lineId = "L"
            ),
            AlertItem(
                id = "ALT-103",
                title = "High Turnstile Density",
                message = "Passenger flow exceeded 450 persons/min at Times Sq 42nd St.",
                severity = AlertSeverity.WARNING,
                category = AlertCategory.STATION,
                location = "Times Sq - 42 St",
                lineId = "N/Q/R/W"
            ),
            AlertItem(
                id = "ALT-104",
                title = "AI Schedule Alignment Complete",
                message = "Headway optimization applied to 7-Express. Dwell times reduced by 14s.",
                severity = AlertSeverity.SUCCESS,
                category = AlertCategory.AI_OPTIMIZATION,
                lineId = "7"
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        AlertFeedPanel(
            alerts = sampleAlerts,
            onAcknowledgeAlert = { alert ->
                val index = sampleAlerts.indexOfFirst { it.id == alert.id }
                if (index != -1) {
                    sampleAlerts[index] = sampleAlerts[index].copy(
                        isAcknowledged = true,
                        acknowledgedBy = "DISPATCH-042"
                    )
                }
            }
        )
    }
}

// ============================================================================
// TELEMETRY MAP / SYSTEM SCREEN
// ============================================================================

@Composable
fun TelemetryMapScreen() {
    val sampleLineSeries = remember {
        listOf(
            ChartSeries("q_line", "Q-Line Flow", listOf(
                DataPoint(1.0, 20.0), DataPoint(2.0, 45.0), DataPoint(3.0, 85.0), DataPoint(4.0, 95.0), DataPoint(5.0, 60.0)
            ), Color(0xFFF59E0B)),
            ChartSeries("l_line", "L-Line Flow", listOf(
                DataPoint(1.0, 30.0), DataPoint(2.0, 50.0), DataPoint(3.0, 55.0), DataPoint(4.0, 70.0), DataPoint(5.0, 65.0)
            ), Color(0xFFD0BCFF))
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "TELEMETRY MAP & REAL-TIME FLOW",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE6E1E9)
        )

        LineChart(
            seriesList = sampleLineSeries,
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            axisConfig = AxisConfig(
                gridColor = Color(0xFF49454F),
                xTitle = "Station Stops",
                yTitle = "Passenger Load %"
            )
        )
    }
}

// ============================================================================
// SYSTEM ADMIN SCREEN
// ============================================================================

@Composable
fun SystemAdminScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "CONTROL SYSTEM CONFIGURATION",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE6E1E9)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF49454F), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Automated Dispatch Parameters",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFFD0BCFF),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "AI Headway Auto-Balancing: ACTIVE",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF4ADE80)
                )
                Text(
                    text = "Substation Peak Load Capping: 85%",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE6E1E9)
                )
                Text(
                    text = "Interlocking Safety Distance: 450 meters",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE6E1E9)
                )
            }
        }
    }
}

// ============================================================================
// NAVIGATION BAR (Design Theme Specs)
// ============================================================================

@Composable
fun M3NavigationBar(
    selectedTab: NavigationTab,
    onTabSelect: (NavigationTab) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF211F26),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavigationTab.values().forEach { tab ->
                val isSelected = tab == selectedTab

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onTabSelect(tab) }
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) Color(0xFF49454F) else Color.Transparent
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (tab) {
                                NavigationTab.MAP -> Icons.Default.Map
                                NavigationTab.DATA -> Icons.Default.TableChart
                                NavigationTab.ALERTS -> Icons.Default.Warning
                                NavigationTab.ADMIN -> Icons.Default.Settings
                            },
                            contentDescription = tab.label,
                            tint = if (isSelected) Color(0xFFD0BCFF) else Color(0xFFE6E1E9).copy(alpha = 0.6f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
                        color = if (isSelected) Color(0xFFD0BCFF) else Color(0xFFE6E1E9).copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}
