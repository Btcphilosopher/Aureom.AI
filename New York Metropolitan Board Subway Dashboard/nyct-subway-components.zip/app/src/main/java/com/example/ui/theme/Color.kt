package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette (Material 3 Dark)
val ElegantBackground = Color(0xFF1C1B1F)
val ElegantSurface = Color(0xFF2B2930)
val ElegantSurfaceHeader = Color(0xFF211F26)
val ElegantPrimary = Color(0xFFD0BCFF)
val ElegantOnPrimary = Color(0xFF381E72)
val ElegantPrimaryContainer = Color(0xFF4F378B)
val ElegantBorder = Color(0xFF49454F)
val ElegantTextPrimary = Color(0xFFE6E1E9)
val ElegantTextSecondary = Color(0xFFCAC4D0)

// Alert colors
val CriticalAlertBackground = Color(0xFF31111D)
val CriticalAlertBorder = Color(0xFF8C1D18)
val CriticalAlertText = Color(0xFFF2B8B5)

// Status colors
val StatusAutoGreen = Color(0xFF4ADE80)
val StatusHoldAmber = Color(0xFFF59E0B)
val StatusManualBlue = Color(0xFF38BDF8)

