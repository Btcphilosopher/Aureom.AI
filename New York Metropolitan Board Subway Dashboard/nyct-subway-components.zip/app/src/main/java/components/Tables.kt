package components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Enterprise Data Table Component Library
 * Designed for New York Metropolitan Board Digital Subway Control System.
 * Supports sortable columns, sticky headers, horizontal/vertical scrolling, status badges,
 * row selection, pagination, loading/empty states, search filtering, and domain data models.
 */

// ============================================================================
// STATUS BADGES & ENUMS
// ============================================================================

enum class StatusBadgeType(val label: String, val color: Color, val backgroundColor: Color) {
    OPERATIONAL("OPERATIONAL", Color(0xFF22C55E), Color(0xFF14532D)),
    DELAYED("DELAYED", Color(0xFFF59E0B), Color(0xFF78350F)),
    CRITICAL("CRITICAL", Color(0xFFEF4444), Color(0xFF7F1D1D)),
    WARNING("WARNING", Color(0xFFEAB308), Color(0xFF713F12)),
    MAINTENANCE("MAINTENANCE", Color(0xFF38BDF8), Color(0xFF0C4A6E)),
    OFFLINE("OFFLINE", Color(0xFF94A3B8), Color(0xFF334155)),
    INFO("INFO", Color(0xFFA855F7), Color(0xFF581C87))
}

@Composable
fun StatusBadge(
    status: StatusBadgeType,
    modifier: Modifier = Modifier,
    customText: String? = null
) {
    Surface(
        modifier = modifier,
        color = status.backgroundColor.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, status.color.copy(alpha = 0.8f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(status.color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = (customText ?: status.label).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = status.color,
                letterSpacing = 0.5.sp
            )
        }
    }
}

// ============================================================================
// TABLE DATA & COLUMN DEFINITIONS
// ============================================================================

enum class SortOrder { ASCENDING, DESCENDING, NONE }

data class SortState(
    val columnId: String? = null,
    val order: SortOrder = SortOrder.NONE
)

sealed class TableColumnWidth {
    data class Fixed(val width: Dp) : TableColumnWidth()
    data class Weight(val weight: Float) : TableColumnWidth()
    object Wrap : TableColumnWidth()
}

data class TableColumn<T>(
    val id: String,
    val header: String,
    val width: TableColumnWidth = TableColumnWidth.Weight(1f),
    val alignment: Alignment.Horizontal = Alignment.Start,
    val sortable: Boolean = true,
    val sortSelector: ((T) -> Comparable<*>?)? = null,
    val cellContent: @Composable (T) -> Unit
)

data class TablePaginationState(
    val currentPage: Int = 1,
    val pageSize: Int = 10,
    val totalItems: Int = 0
) {
    val totalPages: Int get() = kotlin.math.max(1, kotlin.math.ceil(totalItems.toDouble() / pageSize).toInt())
    val startIndex: Int get() = (currentPage - 1) * pageSize
    val endIndex: Int get() = kotlin.math.min(startIndex + pageSize, totalItems)
}

// ============================================================================
// DOMAIN MODELS
// ============================================================================

data class TrainTelemetry(
    val trainId: String,
    val lineId: String,
    val currentStation: String,
    val speedMph: Double,
    val passengerLoadPercent: Int,
    val status: StatusBadgeType,
    val nextMaintenanceKm: Int,
    val driverId: String
)

data class StationInfo(
    val stationId: String,
    val name: String,
    val borough: String,
    val activePlatforms: Int,
    val turnstileFlowPerMin: Int,
    val powerConsumptionKw: Double,
    val status: StatusBadgeType,
    val elevatorStatus: String
)

data class IncidentReport(
    val incidentId: String,
    val timestamp: String,
    val line: String,
    val location: String,
    val severity: StatusBadgeType,
    val description: String,
    val assignedUnit: String,
    val isResolved: Boolean
)

data class MaintenanceSchedule(
    val taskId: String,
    val trackSegment: String,
    val type: String,
    val scheduledTime: String,
    val assignedTeam: String,
    val status: StatusBadgeType,
    val estimatedHours: Double
)

data class AIRecommendation(
    val recId: String,
    val category: String,
    val targetSystem: String,
    val recommendationText: String,
    val expectedImpact: String,
    val confidenceScore: Float,
    val status: StatusBadgeType
)

data class PassengerStats(
    val lineId: String,
    val hourlyVolume: Int,
    val peakCapacityPercent: Int,
    val delayAvgMinutes: Double,
    val fareRevenueUsd: Double,
    val status: StatusBadgeType
)

// ============================================================================
// GENERIC REUSABLE ENTERPRISE TABLE
// ============================================================================

@Composable
fun <T> EnterpriseTable(
    columns: List<TableColumn<T>>,
    items: List<T>,
    modifier: Modifier = Modifier,
    keySelector: ((T) -> Any)? = null,
    selectedItems: Set<T> = emptySet(),
    onRowClick: ((T) -> Unit)? = null,
    isLoading: Boolean = false,
    emptyMessage: String = "No data records found",
    searchQuery: String = "",
    onSearchQueryChange: ((String) -> Unit)? = null,
    paginationState: TablePaginationState? = null,
    onPageChange: ((Int) -> Unit)? = null,
    onPageSizeChange: ((Int) -> Unit)? = null,
    highlightPredicate: ((T) -> Boolean)? = null
) {
    var sortState by remember { mutableStateOf(SortState()) }

    // Filter items if search query provided
    val filteredItems = remember(items, searchQuery) {
        if (searchQuery.isBlank()) items
        else items.filter { item ->
            item.toString().contains(searchQuery, ignoreCase = true)
        }
    }

    // Sort items
    val sortedItems = remember(filteredItems, sortState) {
        val col = columns.firstOrNull { it.id == sortState.columnId }
        val selector = col?.sortSelector
        if (selector == null || sortState.order == SortOrder.NONE) {
            filteredItems
        } else {
            val comparator = Comparator<T> { a, b ->
                val valA = selector(a)
                val valB = selector(b)
                if (valA == null && valB == null) 0
                else if (valA == null) -1
                else if (valB == null) 1
                else @Suppress("UNCHECKED_CAST") (valA as Comparable<Any>).compareTo(valB)
            }
            if (sortState.order == SortOrder.ASCENDING) filteredItems.sortedWith(comparator)
            else filteredItems.sortedWith(comparator.reversed())
        }
    }

    // Paginated subset
    val paginatedItems = remember(sortedItems, paginationState) {
        if (paginationState == null) sortedItems
        else {
            val start = paginationState.startIndex.coerceIn(0, maxOf(0, sortedItems.size - 1))
            val end = (start + paginationState.pageSize).coerceAtMost(sortedItems.size)
            if (start < sortedItems.size) sortedItems.subList(start, end) else emptyList()
        }
    }

    val horizontalScrollState = rememberScrollState()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF49454F), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2B2930),
            contentColor = Color(0xFFE6E1E9)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Search / Filter Header
            if (onSearchQueryChange != null) {
                TableSearchFilterHeader(
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    totalCount = sortedItems.size
                )
                HorizontalDivider(color = Color(0xFF49454F))
            }

            // Scrollable Table Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(horizontalScrollState)
                ) {
                    // Sticky Header Row
                    TableHeaderRow(
                        columns = columns,
                        sortState = sortState,
                        onSortChange = { colId ->
                            sortState = if (sortState.columnId == colId) {
                                when (sortState.order) {
                                    SortOrder.NONE -> SortState(colId, SortOrder.ASCENDING)
                                    SortOrder.ASCENDING -> SortState(colId, SortOrder.DESCENDING)
                                    SortOrder.DESCENDING -> SortState(null, SortOrder.NONE)
                                }
                            } else {
                                SortState(colId, SortOrder.ASCENDING)
                            }
                        }
                    )

                    HorizontalDivider(color = Color(0xFF49454F), thickness = 1.dp)

                    // Content Rows / Loading / Empty
                    if (isLoading) {
                        TableLoadingState(columns = columns)
                    } else if (paginatedItems.isEmpty()) {
                        TableEmptyState(message = emptyMessage, columnsCount = columns.size)
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsIndexed(
                                items = paginatedItems,
                                key = { index, item -> keySelector?.invoke(item) ?: index }
                            ) { index, item ->
                                val isSelected = selectedItems.contains(item)
                                val isHighlighted = highlightPredicate?.invoke(item) == true
                                val isEven = index % 2 == 0

                                TableDataRow(
                                    columns = columns,
                                    item = item,
                                    isSelected = isSelected,
                                    isHighlighted = isHighlighted,
                                    isEven = isEven,
                                    onClick = if (onRowClick != null) { { onRowClick(item) } } else null
                                )
                                HorizontalDivider(color = Color(0xFF49454F), thickness = 0.5.dp)
                            }
                        }
                    }
                }
            }

            // Pagination Controls Footer
            if (paginationState != null && onPageChange != null) {
                HorizontalDivider(color = Color(0xFF49454F))
                TablePaginationFooter(
                    state = paginationState.copy(totalItems = sortedItems.size),
                    onPageChange = onPageChange,
                    onPageSizeChange = onPageSizeChange
                )
            }
        }
    }
}

// ============================================================================
// INTERNAL TABLE ROW COMPONENTS
// ============================================================================

@Composable
private fun <T> TableHeaderRow(
    columns: List<TableColumn<T>>,
    sortState: SortState,
    onSortChange: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .background(Color(0xFF211F26))
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        columns.forEach { col ->
            val isSortedThisCol = sortState.columnId == col.id
            Row(
                modifier = colModifier(col.width)
                    .clip(RoundedCornerShape(4.dp))
                    .then(
                        if (col.sortable) Modifier.clickable { onSortChange(col.id) }
                        else Modifier
                    )
                    .padding(vertical = 2.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = when (col.alignment) {
                    Alignment.End -> Arrangement.End
                    Alignment.CenterHorizontally -> Arrangement.Center
                    else -> Arrangement.Start
                }
            ) {
                Text(
                    text = col.header.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isSortedThisCol) Color(0xFFD0BCFF) else Color(0xFFCAC4D0),
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (col.sortable) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = when {
                            isSortedThisCol && sortState.order == SortOrder.ASCENDING -> Icons.Default.ArrowUpward
                            isSortedThisCol && sortState.order == SortOrder.DESCENDING -> Icons.Default.ArrowDownward
                            else -> Icons.Default.UnfoldMore
                        },
                        contentDescription = "Sort",
                        tint = if (isSortedThisCol) Color(0xFFD0BCFF) else Color(0xFF938F99),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun <T> TableDataRow(
    columns: List<TableColumn<T>>,
    item: T,
    isSelected: Boolean,
    isHighlighted: Boolean,
    isEven: Boolean,
    onClick: (() -> Unit)?
) {
    val backgroundColor = when {
        isSelected -> Color(0xFF4F378B).copy(alpha = 0.4f)
        isHighlighted -> Color(0xFF8C1D18).copy(alpha = 0.3f)
        isEven -> Color(0xFF2B2930)
        else -> Color(0xFF211F26)
    }

    Row(
        modifier = Modifier
            .background(backgroundColor)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        columns.forEach { col ->
            Box(
                modifier = colModifier(col.width),
                contentAlignment = when (col.alignment) {
                    Alignment.End -> Alignment.CenterEnd
                    Alignment.CenterHorizontally -> Alignment.Center
                    else -> Alignment.CenterStart
                }
            ) {
                col.cellContent(item)
            }
        }
    }
}

private fun colModifier(width: TableColumnWidth): Modifier = when (width) {
    is TableColumnWidth.Fixed -> Modifier.width(width.width)
    is TableColumnWidth.Weight -> Modifier.width(160.dp) // Minimum width for wide columns in horizontal scroll
    TableColumnWidth.Wrap -> Modifier.wrapContentWidth()
}

// ============================================================================
// SEARCH & PAGINATION & STATES
// ============================================================================

@Composable
fun TableSearchFilterHeader(
    query: String,
    onQueryChange: (String) -> Unit,
    totalCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("Filter table records...", fontSize = 12.sp, color = Color(0xFF64748B)) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp)) },
            trailingIcon = if (query.isNotEmpty()) {
                { IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp)) } }
            } else null,
            singleLine = true,
            modifier = Modifier
                .width(280.dp)
                .height(44.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF38BDF8),
                unfocusedBorderColor = Color(0xFF334155),
                focusedContainerColor = Color(0xFF1E293B),
                unfocusedContainerColor = Color(0xFF1E293B),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color(0xFFE2E8F0)
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Text(
            text = "Total Records: $totalCount",
            style = MaterialTheme.typography.labelMedium,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF94A3B8)
        )
    }
}

@Composable
private fun TablePaginationFooter(
    state: TablePaginationState,
    onPageChange: (Int) -> Unit,
    onPageSizeChange: ((Int) -> Unit)?
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (state.totalItems == 0) "Showing 0 items"
            else "Showing ${state.startIndex + 1}-${state.endIndex} of ${state.totalItems}",
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF94A3B8)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { onPageChange(state.currentPage - 1) },
                enabled = state.currentPage > 1
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Previous Page",
                    tint = if (state.currentPage > 1) Color(0xFFF8FAFC) else Color(0xFF475569)
                )
            }

            Text(
                text = "Page ${state.currentPage} of ${state.totalPages}",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFFE2E8F0),
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            IconButton(
                onClick = { onPageChange(state.currentPage + 1) },
                enabled = state.currentPage < state.totalPages
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Next Page",
                    tint = if (state.currentPage < state.totalPages) Color(0xFFF8FAFC) else Color(0xFF475569)
                )
            }
        }
    }
}

@Composable
private fun <T> TableLoadingState(columns: List<TableColumn<T>>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = Color(0xFF38BDF8), modifier = Modifier.size(32.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Loading telemetry data feed...",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF94A3B8)
        )
    }
}

@Composable
private fun TableEmptyState(message: String, columnsCount: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Inbox,
            contentDescription = null,
            tint = Color(0xFF64748B),
            modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF94A3B8),
            textAlign = TextAlign.Center
        )
    }
}
