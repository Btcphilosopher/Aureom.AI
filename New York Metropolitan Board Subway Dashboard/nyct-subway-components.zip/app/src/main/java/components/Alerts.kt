package components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

/**
 * Enterprise Alert & Notification System
 * Designed for New York Metropolitan Board Digital Subway Control System.
 * Supports Emergency, Critical, Warning, Info, and Success alert levels with priority sorting,
 * acknowledgement workflows, live tickers, category filtering, and incident management actions.
 */

// ============================================================================
// ENUMS & DATA MODELS
// ============================================================================

enum class AlertSeverity(
    val label: String,
    val priority: Int,
    val primaryColor: Color,
    val backgroundColor: Color,
    val borderColor: Color,
    val defaultIcon: ImageVector
) {
    EMERGENCY(
        label = "EMERGENCY",
        priority = 4,
        primaryColor = Color(0xFFF87171),
        backgroundColor = Color(0xFF450A0A),
        borderColor = Color(0xFFEF4444),
        defaultIcon = Icons.Default.Dangerous
    ),
    CRITICAL(
        label = "CRITICAL",
        priority = 3,
        primaryColor = Color(0xFFF97316),
        backgroundColor = Color(0xFF431407),
        borderColor = Color(0xFFEA580C),
        defaultIcon = Icons.Default.Warning
    ),
    WARNING(
        label = "WARNING",
        priority = 2,
        primaryColor = Color(0xFFFBBF24),
        backgroundColor = Color(0xFF451A03),
        borderColor = Color(0xFFD97706),
        defaultIcon = Icons.Default.ReportProblem
    ),
    INFO(
        label = "INFO",
        priority = 1,
        primaryColor = Color(0xFF38BDF8),
        backgroundColor = Color(0xFF082F49),
        borderColor = Color(0xFF0284C7),
        defaultIcon = Icons.Default.Info
    ),
    SUCCESS(
        label = "SUCCESS",
        priority = 0,
        primaryColor = Color(0xFF4ADE80),
        backgroundColor = Color(0xFF052E16),
        borderColor = Color(0xFF16A34A),
        defaultIcon = Icons.Default.CheckCircle
    )
}

enum class AlertCategory(val label: String, val icon: ImageVector) {
    SIGNAL("SIGNAL", Icons.Default.Traffic),
    POWER("POWER", Icons.Default.Bolt),
    TRACK("TRACK", Icons.Default.AltRoute),
    STATION("STATION", Icons.Default.Storefront),
    TRAIN("TRAIN", Icons.Default.Train),
    SECURITY("SECURITY", Icons.Default.Shield),
    WEATHER("WEATHER", Icons.Default.Thunderstorm),
    AI_OPTIMIZATION("AI OPTIMIZATION", Icons.Default.Psychology),
    SYSTEM("SYSTEM", Icons.Default.Computer)
}

data class AlertAction(
    val actionId: String,
    val label: String,
    val isPrimary: Boolean = false
)

data class AlertItem(
    val id: String,
    val title: String,
    val message: String,
    val severity: AlertSeverity,
    val category: AlertCategory,
    val timestamp: Long = System.currentTimeMillis(),
    val location: String? = null,
    val lineId: String? = null,
    val incidentId: String? = null,
    val isPersistent: Boolean = false,
    val isAcknowledged: Boolean = false,
    val acknowledgedBy: String? = null,
    val acknowledgedTimestamp: Long? = null,
    val actions: List<AlertAction> = emptyList()
)

// ============================================================================
// ALERT CARD COMPOSABLE
// ============================================================================

@Composable
fun AlertCard(
    alert: AlertItem,
    modifier: Modifier = Modifier,
    onAcknowledgeClick: ((AlertItem) -> Unit)? = null,
    onDismissClick: ((AlertItem) -> Unit)? = null,
    onActionClick: ((AlertItem, AlertAction) -> Unit)? = null
) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss 'EST'", Locale.US) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, alert.severity.borderColor, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(
            containerColor = alert.severity.backgroundColor,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth()
        ) {
            // Top Row: Severity badge, category, timestamp, dismiss button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = alert.category.icon,
                        contentDescription = alert.category.label,
                        tint = alert.severity.primaryColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = alert.severity.borderColor.copy(alpha = 0.3f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, alert.severity.primaryColor),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = alert.severity.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = alert.severity.primaryColor,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = alert.category.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFCBD5E1)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dateFormat.format(Date(alert.timestamp)),
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8)
                    )

                    if (!alert.isPersistent && onDismissClick != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { onDismissClick(alert) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss Alert",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Alert Title
            Text(
                text = alert.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            // Alert Message
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = alert.message,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFE2E8F0)
            )

            // Metadata Chips: Location / Line / Incident ID
            if (alert.location != null || alert.lineId != null || alert.incidentId != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    alert.lineId?.let { line ->
                        Surface(
                            color = Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
                            shape = CircleShape
                        ) {
                            Text(
                                text = "Line $line",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    alert.location?.let { loc ->
                        Text(
                            text = "📍 $loc",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    alert.incidentId?.let { inc ->
                        Text(
                            text = "INCIDENT: #$inc",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFF59E0B)
                        )
                    }
                }
            }

            // Acknowledged Status or Action Buttons
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (alert.isAcknowledged) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color(0xFF22C55E),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ACKNOWLEDGED BY ${alert.acknowledgedBy ?: "OPERATOR"}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF22C55E),
                            fontSize = 10.sp
                        )
                    }
                } else if (onAcknowledgeClick != null && (alert.severity == AlertSeverity.EMERGENCY || alert.severity == AlertSeverity.CRITICAL || alert.severity == AlertSeverity.WARNING)) {
                    Button(
                        onClick = { onAcknowledgeClick(alert) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = alert.severity.borderColor,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ACKNOWLEDGE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                // Custom Actions
                if (alert.actions.isNotEmpty() && onActionClick != null) {
                    Row {
                        alert.actions.forEach { act ->
                            OutlinedButton(
                                onClick = { onActionClick(alert, act) },
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .padding(start = 6.dp)
                                    .height(32.dp)
                            ) {
                                Text(act.label, fontSize = 11.sp, color = Color(0xFF38BDF8))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// ALERT FEED PANEL & CATEGORY FILTERS
// ============================================================================

@Composable
fun AlertFeedPanel(
    alerts: List<AlertItem>,
    modifier: Modifier = Modifier,
    onAcknowledgeAlert: ((AlertItem) -> Unit)? = null,
    onDismissAlert: ((AlertItem) -> Unit)? = null,
    onActionClick: ((AlertItem, AlertAction) -> Unit)? = null
) {
    var selectedSeverityFilter by remember { mutableStateOf<AlertSeverity?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf<AlertCategory?>(null) }
    var showOnlyUnacknowledged by remember { mutableStateOf(false) }

    // Priority order sort: Emergency (4) -> Critical (3) -> Warning (2) -> Info (1) -> Success (0), then newest first
    val sortedFilteredAlerts = remember(alerts, selectedSeverityFilter, selectedCategoryFilter, showOnlyUnacknowledged) {
        alerts.filter { item ->
            (selectedSeverityFilter == null || item.severity == selectedSeverityFilter) &&
            (selectedCategoryFilter == null || item.category == selectedCategoryFilter) &&
            (!showOnlyUnacknowledged || !item.isAcknowledged)
        }.sortedWith(
            compareByDescending<AlertItem> { it.severity.priority }
                .thenByDescending { it.timestamp }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF49454F), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Stats & Filter Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE SYSTEM ALERTS & INCIDENTS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Summary Badge Counters
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val emergencyCount = alerts.count { it.severity == AlertSeverity.EMERGENCY && !it.isAcknowledged }
                    val criticalCount = alerts.count { it.severity == AlertSeverity.CRITICAL && !it.isAcknowledged }

                    if (emergencyCount > 0) {
                        Surface(
                            color = Color(0xFFEF4444),
                            shape = CircleShape
                        ) {
                            Text(
                                text = "$emergencyCount EMERGENCY",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    if (criticalCount > 0) {
                        Surface(
                            color = Color(0xFFEA580C),
                            shape = CircleShape
                        ) {
                            Text(
                                text = "$criticalCount CRITICAL",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Severity Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedSeverityFilter == null,
                    onClick = { selectedSeverityFilter = null },
                    label = { Text("ALL (${alerts.size})", fontSize = 11.sp) }
                )
                Spacer(modifier = Modifier.width(6.dp))
                AlertSeverity.values().forEach { severity ->
                    val count = alerts.count { it.severity == severity }
                    if (count > 0) {
                        FilterChip(
                            selected = selectedSeverityFilter == severity,
                            onClick = { selectedSeverityFilter = if (selectedSeverityFilter == severity) null else severity },
                            label = { Text("${severity.label} ($count)", fontSize = 11.sp, color = severity.primaryColor) }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Alert Feed List
            if (sortedFilteredAlerts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFF1E293B), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("ALL SYSTEMS NORMAL", style = MaterialTheme.typography.titleSmall, color = Color(0xFF22C55E), fontWeight = FontWeight.Bold)
                        Text("No active infrastructure alerts matching current filters", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 500.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sortedFilteredAlerts, key = { it.id }) { alert ->
                        AlertCard(
                            alert = alert,
                            onAcknowledgeClick = onAcknowledgeAlert,
                            onDismissClick = onDismissAlert,
                            onActionClick = onActionClick
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// TOP TICKER BANNER FOR CRITICAL EMERGENCIES
// ============================================================================

@Composable
fun EmergencyAlertTicker(
    criticalAlerts: List<AlertItem>,
    modifier: Modifier = Modifier,
    onAlertClick: ((AlertItem) -> Unit)? = null
) {
    val activeEmergencies = criticalAlerts.filter {
        (it.severity == AlertSeverity.EMERGENCY || it.severity == AlertSeverity.CRITICAL) && !it.isAcknowledged
    }

    if (activeEmergencies.isEmpty()) return

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xFF7F1D1D),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444))
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEF4444))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "MISSION CRITICAL NOTICE:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))

            val currentAlert = activeEmergencies.first()
            Text(
                text = "${currentAlert.category.label}: ${currentAlert.title} — ${currentAlert.message}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFCA5A5),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .then(if (onAlertClick != null) Modifier.clickable { onAlertClick(currentAlert) } else Modifier)
            )
        }
    }
}

// ============================================================================
// ACKNOWLEDGEMENT WORKFLOW DIALOG
// ============================================================================

@Composable
fun AlertAcknowledgementDialog(
    alert: AlertItem,
    onConfirmAcknowledge: (alertId: String, operatorId: String, notes: String) -> Unit,
    onDismiss: () -> Unit
) {
    var operatorId by remember { mutableStateOf("OP-8842") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        titleContentColor = Color.White,
        icon = {
            Icon(
                imageVector = Icons.Default.Gavel,
                contentDescription = null,
                tint = alert.severity.primaryColor,
                modifier = Modifier.size(28.dp)
            )
        },
        title = {
            Text(
                text = "ACKNOWLEDGE INCIDENT",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = alert.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFFF8FAFC)
                )
                Text(
                    text = alert.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = operatorId,
                    onValueChange = { operatorId = it },
                    label = { Text("Operator ID / Badge", color = Color(0xFF94A3B8)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color(0xFFE2E8F0)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Action Taken / Resolution Notes", color = Color(0xFF94A3B8)) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color(0xFFE2E8F0)
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmAcknowledge(alert.id, operatorId, notes) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("RECORD ACKNOWLEDGEMENT", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = Color(0xFF94A3B8))
            }
        }
    )
}
