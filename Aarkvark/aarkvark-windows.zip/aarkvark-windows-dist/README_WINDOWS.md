# Aarkvark - Windows Distribution & Packaging Guide

This package provides the structured source code and build tools required to run Aarkvark on Windows, or package it into a standalone **Microsoft Windows Application (`.exe`)**.

---

## 🚀 Option 1: Run Natively on Windows

To run the application locally on Windows without compiling it:

1. Copy this `aarkvark-windows-dist` folder to your Windows machine.
2. Right-click `setup_windows.ps1` and select **Run with PowerShell** (or run it from a PowerShell terminal). This script will:
   * Download and install Python if you don't have it.
   * Install all graphical framework requirements (`PySide6`, `matplotlib`, `numpy`).
   * Create a double-clickable **Aarkvark Shortcut** on your Windows Desktop.
3. Double-click the newly generated **Aarkvark** shortcut on your Desktop, or run `Aarkvark.bat` directly!

---

## 📦 Option 2: Build a Standalone Executable (`.exe`)

For commercial distribution, you will want a single, compiled `.exe` file that runs on Windows without requiring users to install Python or dependencies.

### Method A: Automated Cloud Build via GitHub Actions (Recommended)
This distribution folder includes a pre-configured GitHub Actions pipeline inside `.github/workflows/build-windows.yml`.

1. Host this project in a repository on **GitHub**.
2. Every time you push updates or trigger the workflow, GitHub's Windows cloud runners will automatically:
   * Spin up a native Windows runtime.
   * Install graphical frameworks and Python dependencies.
   * Compile a single-file, standalone, high-performance `Aarkvark.exe` package.
   * Upload the compiled executable as an artifact, ready for distribution or sale!

### Method B: Build Locally on a Windows Machine
If you have access to a Windows computer, you can build the `.exe` locally:

1. Open a Command Prompt or PowerShell in this directory.
2. Install `pyinstaller` and dependencies:
   ```cmd
   pip install -r src/requirements.txt
   pip install pyinstaller
   ```
3. Run the compiler:
   ```cmd
   pyinstaller --onefile --noconsole --name="Aarkvark" src/main.py
   ```
4. Find your single-file **`Aarkvark.exe`** inside the `dist/` directory!

---
*Copyright © 2026 Aarkvark Software. All rights reserved.*
