"""
engine/cells.py — Cell model for the Abacus computation graph.
"""
from __future__ import annotations
import re
from enum import Enum, auto
from typing import Any, Optional


class CellType(Enum):
    EMPTY   = auto()
    VALUE   = auto()   # literal number / string
    FORMULA = auto()   # = expression
    ERROR   = auto()


class Cell:
    """A single cell node in the computation graph."""

    __slots__ = (
        "sheet", "row", "col",
        "raw",          # raw user input
        "value",        # evaluated value
        "cell_type",
        "error",        # error message if any
        "dependents",   # cells that depend on ME  (downstream)
        "dependencies", # cells that I depend on   (upstream)
        "format_code",  # display format string
        "style",        # dict of style overrides
    )

    def __init__(self, sheet: str, row: int, col: int):
        self.sheet       = sheet
        self.row         = row
        self.col         = col
        self.raw         = ""
        self.value: Any  = None
        self.cell_type   = CellType.EMPTY
        self.error: Optional[str] = None
        self.dependents: set[tuple]   = set()   # (sheet, r, c)
        self.dependencies: set[tuple] = set()   # (sheet, r, c)
        self.format_code = "general"
        self.style: dict = {}

    # ── address ──────────────────────────────────────────────────────────────
    @property
    def address(self) -> str:
        return f"{col_to_letter(self.col)}{self.row + 1}"

    @property
    def full_address(self) -> str:
        return f"{self.sheet}!{self.address}"

    # ── display ──────────────────────────────────────────────────────────────
    def display_value(self) -> str:
        if self.cell_type == CellType.EMPTY:
            return ""
        if self.cell_type == CellType.ERROR:
            return f"#{self.error}"
        if self.value is None:
            return ""
        if isinstance(self.value, float):
            if self.value == int(self.value):
                return str(int(self.value))
            return f"{self.value:.4g}"
        return str(self.value)

    def is_formula(self) -> bool:
        return isinstance(self.raw, str) and self.raw.startswith("=")

    def __repr__(self):
        return f"Cell({self.full_address}, raw={self.raw!r}, val={self.value!r})"


# ── helpers ───────────────────────────────────────────────────────────────────
def col_to_letter(col: int) -> str:
    """0-based col index → A, B, …, Z, AA, AB, …"""
    result = ""
    col += 1
    while col:
        col, rem = divmod(col - 1, 26)
        result = chr(65 + rem) + result
    return result


def letter_to_col(letters: str) -> int:
    """A → 0, B → 1, Z → 25, AA → 26, …"""
    result = 0
    for ch in letters.upper():
        result = result * 26 + (ord(ch) - 64)
    return result - 1


# A1 reference pattern (optional sheet prefix)
REF_RE = re.compile(
    r"(?:([A-Za-z_]\w*)!)?"   # optional sheet name
    r"([A-Z]+)(\d+)",          # col letters + row number
    re.IGNORECASE
)

RANGE_RE = re.compile(
    r"(?:([A-Za-z_]\w*)!)?"
    r"([A-Z]+)(\d+):([A-Z]+)(\d+)",
    re.IGNORECASE
)


def parse_ref(ref: str, default_sheet: str) -> tuple[str, int, int]:
    """Parse 'Sheet2!B3' → (sheet, row, col) with 0-based indices."""
    m = REF_RE.fullmatch(ref.strip())
    if not m:
        raise ValueError(f"Bad cell reference: {ref!r}")
    sheet   = m.group(1) or default_sheet
    col     = letter_to_col(m.group(2))
    row     = int(m.group(3)) - 1
    return sheet, row, col


def parse_range(rng: str, default_sheet: str) -> list[tuple[str, int, int]]:
    """Parse 'A1:C3' → list of (sheet, row, col)."""
    m = RANGE_RE.fullmatch(rng.strip())
    if not m:
        raise ValueError(f"Bad range: {rng!r}")
    sheet  = m.group(1) or default_sheet
    c1, r1 = letter_to_col(m.group(2)), int(m.group(3)) - 1
    c2, r2 = letter_to_col(m.group(4)), int(m.group(5)) - 1
    cells  = []
    for r in range(min(r1, r2), max(r1, r2) + 1):
        for c in range(min(c1, c2), max(c1, c2) + 1):
            cells.append((sheet, r, c))
    return cells
