"""
engine/evaluator.py — Formula parser & evaluator.
Supports: literals, cell refs, ranges, built-in functions, arithmetic.
"""
from __future__ import annotations
import re
import math
import statistics
from typing import Any, Callable, TYPE_CHECKING

from engine.cells import (
    Cell, CellType, REF_RE, RANGE_RE,
    parse_ref, parse_range, letter_to_col
)

if TYPE_CHECKING:
    from engine.workbook import Workbook


# ── built-in functions ────────────────────────────────────────────────────────
def _nums(vals):
    return [v for v in vals if isinstance(v, (int, float))]


BUILTINS: dict[str, Callable] = {
    # aggregates
    "SUM":    lambda *a: sum(_nums(a)),
    "AVERAGE":lambda *a: statistics.mean(_nums(a)) if _nums(a) else 0,
    "AVG":    lambda *a: statistics.mean(_nums(a)) if _nums(a) else 0,
    "MIN":    lambda *a: min(_nums(a)) if _nums(a) else 0,
    "MAX":    lambda *a: max(_nums(a)) if _nums(a) else 0,
    "COUNT":  lambda *a: len(_nums(a)),
    "COUNTA": lambda *a: sum(1 for v in a if v not in (None, "")),
    "MEDIAN": lambda *a: statistics.median(_nums(a)) if _nums(a) else 0,
    "STDEV":  lambda *a: statistics.stdev(_nums(a)) if len(_nums(a)) > 1 else 0,
    "VAR":    lambda *a: statistics.variance(_nums(a)) if len(_nums(a)) > 1 else 0,
    # math
    "ABS":    lambda x: abs(x),
    "SQRT":   lambda x: math.sqrt(x),
    "POWER":  lambda x, n: x ** n,
    "ROUND":  lambda x, n=0: round(x, int(n)),
    "FLOOR":  lambda x, n=1: math.floor(x / n) * n,
    "CEIL":   lambda x, n=1: math.ceil(x / n) * n,
    "MOD":    lambda x, y: x % y,
    "LOG":    lambda x, base=10: math.log(x, base),
    "LN":     lambda x: math.log(x),
    "EXP":    lambda x: math.exp(x),
    "PI":     lambda: math.pi,
    "E":      lambda: math.e,
    # logic
    "IF":     lambda cond, t, f=0: t if cond else f,
    "AND":    lambda *a: all(bool(v) for v in a),
    "OR":     lambda *a: any(bool(v) for v in a),
    "NOT":    lambda x: not x,
    "ISNUMBER": lambda x: isinstance(x, (int, float)),
    "ISBLANK":  lambda x: x in (None, ""),
    "IFERROR":  lambda x, e=0: e if isinstance(x, str) and x.startswith("#") else x,
    # text
    "LEN":    lambda x: len(str(x)) if x is not None else 0,
    "UPPER":  lambda x: str(x).upper(),
    "LOWER":  lambda x: str(x).lower(),
    "CONCAT": lambda *a: "".join(str(v) for v in a if v is not None),
    "TEXT":   lambda x, _fmt="": str(x),
    "LEFT":   lambda x, n=1: str(x)[:int(n)],
    "RIGHT":  lambda x, n=1: str(x)[-int(n):],
    "MID":    lambda x, s, n: str(x)[int(s)-1:int(s)-1+int(n)],
    "TRIM":   lambda x: str(x).strip(),
    # finance helpers
    "GROWTH": lambda start, end, n=1: ((end / start) ** (1 / n) - 1) if start else 0,
    "CAGR":   lambda start, end, n: ((end / start) ** (1 / n) - 1) if start else 0,
    # lookup stubs
    "ROW":    lambda: 0,
    "COLUMN": lambda: 0,
}


# ── tokeniser ─────────────────────────────────────────────────────────────────
_TOK = re.compile(
    r'(?P<RANGE>[A-Z]+\d+:[A-Z]+\d+)'
    r'|(?P<SHRANGE>[A-Za-z_]\w*![A-Z]+\d+:[A-Z]+\d+)'
    r'|(?P<SHREF>[A-Za-z_]\w*![A-Z]+\d+)'
    r'|(?P<REF>[A-Z]+\d+)'
    r'|(?P<FLOAT>\d+\.\d*|\.\d+)'
    r'|(?P<INT>\d+)'
    r'|(?P<STRING>"[^"]*")'
    r'|(?P<BOOL>TRUE|FALSE)'
    r'|(?P<FUNC>[A-Z_][A-Z0-9_]*(?=\s*\())'
    r'|(?P<NAME>[A-Z_][A-Z0-9_]*)'
    r'|(?P<OP>[+\-*/^%<>=!&|,()])'
    r'|(?P<WS>\s+)',
    re.IGNORECASE
)


class Evaluator:
    """Evaluates a formula string given a Workbook context."""

    def __init__(self, workbook: "Workbook"):
        self.wb = workbook

    def evaluate(self, cell: Cell) -> tuple[Any, set]:
        """
        Evaluate cell.raw.
        Returns (value, dependency_keys).
        Raises EvalError on formula errors.
        """
        raw = cell.raw.strip()
        if not raw:
            return None, set()
        if not raw.startswith("="):
            return self._coerce(raw), set()
        expr = raw[1:]
        deps: set = set()
        val = self._eval_expr(expr, cell.sheet, deps)
        return val, deps

    # ── internal expression evaluator ─────────────────────────────────────────
    def _eval_expr(self, expr: str, sheet: str, deps: set) -> Any:
        tokens = self._tokenise(expr, sheet, deps)
        parser = _Parser(tokens, sheet, self, deps)
        return parser.parse()

    def _tokenise(self, expr: str, sheet: str, deps: set) -> list:
        tokens = []
        for m in _TOK.finditer(expr):
            kind = m.lastgroup
            val  = m.group()
            if kind == "WS":
                continue
            elif kind in ("RANGE", "SHRANGE"):
                tokens.append(("RANGE_LITERAL", val))
            elif kind in ("REF", "SHREF"):
                tokens.append(("REF_LITERAL", val))
            elif kind == "FLOAT":
                tokens.append(("NUM", float(val)))
            elif kind == "INT":
                tokens.append(("NUM", float(val)))
            elif kind == "STRING":
                tokens.append(("STR", val[1:-1]))
            elif kind == "BOOL":
                tokens.append(("BOOL", val.upper() == "TRUE"))
            elif kind == "FUNC":
                tokens.append(("FUNC", val.upper()))
            elif kind == "NAME":
                tokens.append(("NAME", val.upper()))
            else:
                tokens.append((kind, val))
        tokens.append(("EOF", None))
        return tokens

    def resolve_ref(self, ref: str, sheet: str, deps: set) -> Any:
        try:
            s, r, c = parse_ref(ref, sheet)
            deps.add((s, r, c))
            cell = self.wb.get_cell(s, r, c)
            if cell.cell_type == CellType.ERROR:
                raise EvalError(cell.error or "REF")
            return cell.value
        except ValueError as e:
            raise EvalError(str(e))

    def resolve_range(self, rng: str, sheet: str, deps: set) -> list:
        try:
            keys = parse_range(rng, sheet)
            vals = []
            for s, r, c in keys:
                deps.add((s, r, c))
                cell = self.wb.get_cell(s, r, c)
                if cell.value is not None:
                    vals.append(cell.value)
            return vals
        except ValueError as e:
            raise EvalError(str(e))

    def _coerce(self, raw: str) -> Any:
        try:
            v = float(raw)
            return int(v) if v == int(v) else v
        except ValueError:
            return raw


# ── recursive descent parser ──────────────────────────────────────────────────
class _Parser:
    def __init__(self, tokens, sheet, ev: Evaluator, deps: set):
        self.tokens = tokens
        self.pos    = 0
        self.sheet  = sheet
        self.ev     = ev
        self.deps   = deps

    def peek(self):
        return self.tokens[self.pos]

    def consume(self, kind=None):
        tok = self.tokens[self.pos]
        if kind and tok[0] != kind:
            raise EvalError(f"Expected {kind}, got {tok[0]}")
        self.pos += 1
        return tok

    def parse(self):
        val = self.expr()
        self.consume("EOF")
        return val

    def expr(self):
        return self.comparison()

    def comparison(self):
        left = self.addition()
        while self.peek()[0] == "OP" and self.peek()[1] in ("<", ">", "<=", ">=", "=", "<>"):
            op = self.consume()[1]
            right = self.addition()
            if op == "<":   left = left < right
            elif op == ">": left = left > right
            elif op == "<=":left = left <= right
            elif op == ">=":left = left >= right
            elif op == "=": left = left == right
            elif op == "<>":left = left != right
        return left

    def addition(self):
        left = self.multiplication()
        while self.peek()[0] == "OP" and self.peek()[1] in ("+", "-", "&"):
            op = self.consume()[1]
            right = self.multiplication()
            if op == "+":  left = (left or 0) + (right or 0)
            elif op == "-":left = (left or 0) - (right or 0)
            elif op == "&":left = str(left or "") + str(right or "")
        return left

    def multiplication(self):
        left = self.power()
        while self.peek()[0] == "OP" and self.peek()[1] in ("*", "/", "%"):
            op = self.consume()[1]
            right = self.power()
            if op == "*":  left = (left or 0) * (right or 0)
            elif op == "/":
                if (right or 0) == 0: raise EvalError("DIV/0")
                left = (left or 0) / right
            elif op == "%":left = (left or 0) % (right or 0)
        return left

    def power(self):
        left = self.unary()
        while self.peek()[0] == "OP" and self.peek()[1] == "^":
            self.consume()
            right = self.unary()
            left = left ** right
        return left

    def unary(self):
        if self.peek()[0] == "OP" and self.peek()[1] == "-":
            self.consume()
            return -(self.primary() or 0)
        if self.peek()[0] == "OP" and self.peek()[1] == "+":
            self.consume()
        return self.primary()

    def primary(self):
        tok = self.peek()

        if tok[0] == "NUM":
            self.consume()
            v = tok[1]
            return int(v) if v == int(v) else v

        if tok[0] == "STR":
            self.consume()
            return tok[1]

        if tok[0] == "BOOL":
            self.consume()
            return tok[1]

        if tok[0] == "RANGE_LITERAL":
            self.consume()
            vals = self.ev.resolve_range(tok[1], self.sheet, self.deps)
            return vals   # list – used by functions

        if tok[0] == "REF_LITERAL":
            self.consume()
            return self.ev.resolve_ref(tok[1], self.sheet, self.deps)

        if tok[0] == "FUNC":
            name = self.consume()[1]
            self.consume("OP")  # (
            args = []
            if not (self.peek()[0] == "OP" and self.peek()[1] == ")"):
                args.append(self._arg())
                while self.peek()[0] == "OP" and self.peek()[1] == ",":
                    self.consume()
                    args.append(self._arg())
            self.consume("OP")  # )
            return self._call(name, args)

        if tok[0] == "NAME":
            self.consume()
            name = tok[1]
            if name in BUILTINS:
                return BUILTINS[name]()
            raise EvalError(f"NAME: {name}")

        if tok[0] == "OP" and tok[1] == "(":
            self.consume()
            val = self.expr()
            self.consume("OP")
            return val

        raise EvalError(f"Unexpected token: {tok}")

    def _arg(self):
        """An argument can be a range (returns list) or expr."""
        return self.expr()

    def _call(self, name: str, raw_args: list) -> Any:
        fn = BUILTINS.get(name)
        if fn is None:
            raise EvalError(f"Unknown function: {name}")
        # flatten list args
        flat = []
        for a in raw_args:
            if isinstance(a, list):
                flat.extend(a)
            else:
                flat.append(a)
        try:
            return fn(*flat)
        except EvalError:
            raise
        except Exception as e:
            raise EvalError(str(e))


class EvalError(Exception):
    pass
