"""
engine/workbook.py — Central data model.
Manages sheets, cells, dependency graph and reactive evaluation.
"""
from __future__ import annotations
import json
from typing import Any, Callable, Optional

from engine.cells import Cell, CellType, parse_ref, parse_range
from engine.graph  import DependencyGraph, CycleError
from engine.evaluator import Evaluator, EvalError


class Sheet:
    def __init__(self, name: str):
        self.name   = name
        self.cells: dict[tuple[int, int], Cell] = {}

    def get_cell(self, row: int, col: int) -> Cell:
        key = (row, col)
        if key not in self.cells:
            c = Cell(self.name, row, col)
            self.cells[key] = c
        return self.cells[key]

    def non_empty_cells(self) -> list[Cell]:
        return [c for c in self.cells.values() if c.cell_type != CellType.EMPTY]

    @property
    def max_row(self) -> int:
        if not self.cells:
            return 0
        return max(r for r, _ in self.cells) + 1

    @property
    def max_col(self) -> int:
        if not self.cells:
            return 0
        return max(c for _, c in self.cells) + 1


class Workbook:
    """
    The full document: multiple sheets + shared computation graph.
    """

    def __init__(self):
        self.sheets: dict[str, Sheet] = {}
        self.sheet_order: list[str]   = []
        self.graph                    = DependencyGraph()
        self._evaluator               = Evaluator(self)
        self._on_cell_changed: list[Callable] = []
        self._on_sheet_changed: list[Callable] = []

        # Create default sheet
        self.add_sheet("Sheet1")

    # ── sheet management ──────────────────────────────────────────────────────
    def add_sheet(self, name: str | None = None) -> Sheet:
        if name is None:
            i = 1
            while f"Sheet{i}" in self.sheets:
                i += 1
            name = f"Sheet{i}"
        if name in self.sheets:
            raise ValueError(f"Sheet '{name}' already exists")
        sheet = Sheet(name)
        self.sheets[name] = sheet
        self.sheet_order.append(name)
        self._fire_sheet_changed()
        return sheet

    def rename_sheet(self, old: str, new: str):
        if old not in self.sheets:
            raise KeyError(old)
        if new in self.sheets and new != old:
            raise ValueError(f"Sheet '{new}' already exists")
        sheet = self.sheets.pop(old)
        sheet.name = new
        self.sheets[new] = sheet
        idx = self.sheet_order.index(old)
        self.sheet_order[idx] = new
        self.graph.rename_sheet(old, new)
        # Fix cell references
        for cell in sheet.cells.values():
            cell.sheet = new
        self._fire_sheet_changed()

    def delete_sheet(self, name: str):
        if len(self.sheet_order) <= 1:
            raise ValueError("Cannot delete the last sheet")
        self.sheets.pop(name)
        self.sheet_order.remove(name)
        self._fire_sheet_changed()

    # ── cell access ───────────────────────────────────────────────────────────
    def get_cell(self, sheet: str, row: int, col: int) -> Cell:
        if sheet not in self.sheets:
            raise KeyError(f"Unknown sheet: {sheet!r}")
        return self.sheets[sheet].get_cell(row, col)

    def get_cell_by_addr(self, sheet: str, address: str) -> Cell:
        s, r, c = parse_ref(address, sheet)
        return self.get_cell(s, r, c)

    # ── cell editing ──────────────────────────────────────────────────────────
    def set_cell(self, sheet: str, row: int, col: int, raw: str):
        """Set cell raw value and trigger reactive re-evaluation."""
        cell = self.get_cell(sheet, row, col)
        cell.raw = raw.strip()

        if not cell.raw:
            cell.value     = None
            cell.cell_type = CellType.EMPTY
            cell.error     = None
            self.graph.remove_cell((sheet, row, col))
        else:
            self._eval_cell(cell)

        # Propagate to dependents
        dirty = {(sheet, row, col)}
        try:
            order = self.graph.propagation_order(dirty)
        except CycleError:
            cell.cell_type = CellType.ERROR
            cell.error     = "CIRCULAR"
            order          = []

        for key in order:
            if key == (sheet, row, col):
                continue
            dep_cell = self.get_cell(*key)
            self._eval_cell(dep_cell)

        self._fire_cell_changed(sheet, row, col)

    def _eval_cell(self, cell: Cell):
        try:
            value, deps = self._evaluator.evaluate(cell)
            cell.value     = value
            cell.cell_type = CellType.FORMULA if cell.is_formula() else (
                CellType.VALUE if cell.raw else CellType.EMPTY
            )
            cell.error = None
            self.graph.set_dependencies(
                (cell.sheet, cell.row, cell.col), deps
            )
            # back-link dependents info onto the cell objects (cosmetic)
            cell.dependencies = deps
        except EvalError as e:
            cell.cell_type = CellType.ERROR
            cell.error     = str(e)
            cell.value     = None

    def recalculate_all(self):
        """Full workbook recalculation (e.g. after load)."""
        for sheet in self.sheets.values():
            for cell in sheet.non_empty_cells():
                self._eval_cell(cell)
        # now propagate in topo order
        all_keys = set()
        for sheet in self.sheets.values():
            for r, c in sheet.cells:
                all_keys.add((sheet.name, r, c))
        try:
            order = self.graph.propagation_order(all_keys)
            for key in order:
                self._eval_cell(self.get_cell(*key))
        except CycleError:
            pass

    # ── events ────────────────────────────────────────────────────────────────
    def on_cell_changed(self, fn: Callable):
        self._on_cell_changed.append(fn)

    def on_sheet_changed(self, fn: Callable):
        self._on_sheet_changed.append(fn)

    def _fire_cell_changed(self, sheet, row, col):
        for fn in self._on_cell_changed:
            fn(sheet, row, col)

    def _fire_sheet_changed(self):
        for fn in self._on_sheet_changed:
            fn()

    # ── serialisation ─────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        data: dict = {"version": 1, "sheets": [], "sheet_order": self.sheet_order}
        for name in self.sheet_order:
            sheet = self.sheets[name]
            cells = []
            for (r, c), cell in sheet.cells.items():
                if cell.cell_type != CellType.EMPTY:
                    cells.append({
                        "r": r, "c": c,
                        "raw": cell.raw,
                        "style": cell.style,
                        "format": cell.format_code,
                    })
            data["sheets"].append({"name": name, "cells": cells})
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "Workbook":
        wb = cls()
        # remove default sheet
        wb.sheets.clear()
        wb.sheet_order.clear()

        for sh_data in data.get("sheets", []):
            name  = sh_data["name"]
            sheet = Sheet(name)
            wb.sheets[name]  = sheet
            wb.sheet_order.append(name)
            for cd in sh_data.get("cells", []):
                cell = sheet.get_cell(cd["r"], cd["c"])
                cell.raw         = cd.get("raw", "")
                cell.style       = cd.get("style", {})
                cell.format_code = cd.get("format", "general")

        wb.recalculate_all()
        return wb

    def save_json(self, path: str):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_json(cls, path: str) -> "Workbook":
        with open(path) as f:
            return cls.from_dict(json.load(f))

    # ── utility ───────────────────────────────────────────────────────────────
    def active_sheet_name(self) -> str:
        return self.sheet_order[0] if self.sheet_order else ""

    def get_range_values(self, sheet: str, r1, c1, r2, c2) -> list[list[Any]]:
        """Return a 2-D list of display values for a rectangular range."""
        rows = []
        for r in range(r1, r2 + 1):
            row = []
            for c in range(c1, c2 + 1):
                cell = self.get_cell(sheet, r, c)
                row.append(cell.value)
            rows.append(row)
        return rows
