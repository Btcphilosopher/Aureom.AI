"""
demo.py — Seed data for Abacus demo workbook.
Creates a realistic financial workbook showcasing computation graph features.
"""
from engine.workbook import Workbook


def create_demo_workbook() -> Workbook:
    wb = Workbook()

    # ── Sheet 1: Quarterly Revenue ────────────────────────────────────────────
    s = "Sheet1"
    wb.sheets[s].name  # rename not needed, already Sheet1

    # Headers
    data = [
        # row, col, value
        (0, 0, "Quarter"),
        (0, 1, "Revenue"),
        (0, 2, "Costs"),
        (0, 3, "Gross Profit"),
        (0, 4, "Margin %"),
        (0, 5, "YoY Growth"),

        # Q1 2023
        (1, 0, "Q1 2023"), (1, 1, "842000"), (1, 2, "511000"),
        # Q2 2023
        (2, 0, "Q2 2023"), (2, 1, "967000"), (2, 2, "548000"),
        # Q3 2023
        (3, 0, "Q3 2023"), (3, 1, "1124000"), (3, 2, "612000"),
        # Q4 2023
        (4, 0, "Q4 2023"), (4, 1, "1388000"), (4, 2, "699000"),
        # Q1 2024
        (5, 0, "Q1 2024"), (5, 1, "1042000"), (5, 2, "571000"),
        # Q2 2024
        (6, 0, "Q2 2024"), (6, 1, "1213000"), (6, 2, "631000"),
        # Q3 2024
        (7, 0, "Q3 2024"), (7, 1, "1419000"), (7, 2, "718000"),
        # Q4 2024
        (8, 0, "Q4 2024"), (8, 1, "1776000"), (8, 2, "872000"),
    ]
    for r, c, v in data:
        wb.set_cell(s, r, c, v)

    # Gross Profit formulas
    for r in range(1, 9):
        wb.set_cell(s, r, 3, f"=B{r+1}-C{r+1}")
        wb.set_cell(s, r, 4, f"=ROUND(D{r+1}/B{r+1}*100,1)")

    # YoY Growth (Q1 2024 vs Q1 2023 etc)
    for r in range(5, 9):
        wb.set_cell(s, r, 5, f"=ROUND((B{r+1}-B{r-3})/B{r-3}*100,1)")

    # Summary row
    wb.set_cell(s, 10, 0, "TOTAL 2023")
    wb.set_cell(s, 10, 1, "=SUM(B2:B5)")
    wb.set_cell(s, 10, 2, "=SUM(C2:C5)")
    wb.set_cell(s, 10, 3, "=SUM(D2:D5)")
    wb.set_cell(s, 10, 4, "=ROUND(D11/B11*100,1)")

    wb.set_cell(s, 11, 0, "TOTAL 2024")
    wb.set_cell(s, 11, 1, "=SUM(B6:B9)")
    wb.set_cell(s, 11, 2, "=SUM(C6:C9)")
    wb.set_cell(s, 11, 3, "=SUM(D6:D9)")
    wb.set_cell(s, 11, 4, "=ROUND(D12/B12*100,1)")

    wb.set_cell(s, 12, 0, "YoY GROWTH")
    wb.set_cell(s, 12, 1, "=ROUND((B12-B11)/B11*100,1)")

    # ── Sheet 2: Metrics ──────────────────────────────────────────────────────
    wb.add_sheet("Metrics")
    m = "Metrics"

    wb.set_cell(m, 0, 0, "Metric")
    wb.set_cell(m, 0, 1, "Value")
    wb.set_cell(m, 0, 2, "Source")

    metrics = [
        (1, "Total 2023 Revenue",   "=Sheet1!B11"),
        (2, "Total 2024 Revenue",   "=Sheet1!B12"),
        (3, "Revenue Growth %",     "=Sheet1!B13"),
        (4, "Avg Quarterly Margin", "=AVERAGE(Sheet1!E2:E9)"),
        (5, "Best Quarter Revenue", "=MAX(Sheet1!B2:B9)"),
        (6, "Best Quarter Margin",  "=MAX(Sheet1!E2:E9)"),
        (7, "Total Headcount Cost", "=Sheet1!C11+Sheet1!C12"),
    ]
    for r, label, formula in metrics:
        wb.set_cell(m, r, 0, label)
        wb.set_cell(m, r, 1, formula)
        wb.set_cell(m, r, 2, "Sheet1")

    # ── Sheet 3: Forecast ─────────────────────────────────────────────────────
    wb.add_sheet("Forecast")
    f = "Forecast"

    wb.set_cell(f, 0, 0, "Quarter")
    wb.set_cell(f, 0, 1, "Forecast")
    wb.set_cell(f, 0, 2, "Low (-10%)")
    wb.set_cell(f, 0, 3, "High (+10%)")

    # Growth rate from metrics
    wb.set_cell(f, 1, 0, "Q1 2025")
    wb.set_cell(f, 1, 1, "=ROUND(Sheet1!B6*(1+Metrics!B4/100),0)")
    wb.set_cell(f, 1, 2, "=ROUND(B2*0.9,0)")
    wb.set_cell(f, 1, 3, "=ROUND(B2*1.1,0)")

    wb.set_cell(f, 2, 0, "Q2 2025")
    wb.set_cell(f, 2, 1, "=ROUND(Sheet1!B7*(1+Metrics!B4/100),0)")
    wb.set_cell(f, 2, 2, "=ROUND(B3*0.9,0)")
    wb.set_cell(f, 2, 3, "=ROUND(B3*1.1,0)")

    wb.set_cell(f, 3, 0, "Q3 2025")
    wb.set_cell(f, 3, 1, "=ROUND(Sheet1!B8*(1+Metrics!B4/100),0)")
    wb.set_cell(f, 3, 2, "=ROUND(B4*0.9,0)")
    wb.set_cell(f, 3, 3, "=ROUND(B4*1.1,0)")

    wb.set_cell(f, 4, 0, "Q4 2025")
    wb.set_cell(f, 4, 1, "=ROUND(Sheet1!B9*(1+Metrics!B4/100),0)")
    wb.set_cell(f, 4, 2, "=ROUND(B5*0.9,0)")
    wb.set_cell(f, 4, 3, "=ROUND(B5*1.1,0)")

    wb.set_cell(f, 5, 0, "TOTAL 2025")
    wb.set_cell(f, 5, 1, "=SUM(B2:B5)")
    wb.set_cell(f, 5, 2, "=SUM(C2:C5)")
    wb.set_cell(f, 5, 3, "=SUM(D2:D5)")

    return wb
