"""
ui/graph_view.py — Computation graph visualiser.
Renders cells as nodes and dependencies as directed edges.
"""
from __future__ import annotations
import math
from typing import Optional

from PySide6.QtWidgets import QWidget, QToolTip
from PySide6.QtCore    import Qt, QPoint, QPointF, QRect, QRectF, QTimer, Signal
from PySide6.QtGui     import (
    QPainter, QColor, QPen, QBrush, QFont, QFontMetrics,
    QMouseEvent, QWheelEvent, QRadialGradient, QLinearGradient
)

from config          import COLORS as C, FONT_MONO, FONT_UI, FONT_SIZE
from engine.cells    import col_to_letter, CellType
from engine.workbook import Workbook

_COL = {k: QColor(v) for k, v in C.items()}


class GraphNode:
    def __init__(self, key, x: float, y: float, label: str, display: str, ctype):
        self.key     = key     # (sheet, row, col)
        self.x       = x
        self.y       = y
        self.label   = label  # e.g. "A1"
        self.display = display
        self.ctype   = ctype
        self.vx      = 0.0    # for force layout
        self.vy      = 0.0
        self.pinned  = False

    @property
    def rect(self) -> QRectF:
        w, h = 90, 40
        return QRectF(self.x - w / 2, self.y - h / 2, w, h)


class GraphView(QWidget):
    """
    Force-directed computation graph.
    Nodes = cells, edges = dependencies.
    """
    node_selected = Signal(str, int, int)  # sheet, row, col

    def __init__(self, workbook: Workbook, sheet_name: str, parent=None):
        super().__init__(parent)
        self.wb         = workbook
        self.sheet_name = sheet_name
        self.setObjectName("graph_view")
        self.setMinimumSize(300, 300)

        self._nodes: dict[tuple, GraphNode] = {}
        self._scale    = 1.0
        self._offset   = QPointF(0, 0)
        self._dragging: Optional[GraphNode] = None
        self._pan_last: Optional[QPoint]    = None
        self._selected_key: Optional[tuple] = None

        self.setMouseTracking(True)

        # Force simulation timer
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

        self.rebuild()

    # ── public ────────────────────────────────────────────────────────────────
    def set_sheet(self, name: str):
        self.sheet_name = name
        self.rebuild()

    def rebuild(self):
        """Rebuild nodes from the current workbook state."""
        self._nodes.clear()
        sheet = self.wb.sheets.get(self.sheet_name)
        if not sheet:
            self.update()
            return

        # Collect all non-empty cells as nodes
        for (r, c), cell in sheet.cells.items():
            if cell.cell_type == CellType.EMPTY:
                continue
            key   = (self.sheet_name, r, c)
            label = f"{col_to_letter(c)}{r+1}"
            disp  = cell.display_value()[:12]
            # Initial position: grid-like
            x = 100 + c * 120 + (r % 3) * 20
            y = 80  + r * 90
            self._nodes[key] = GraphNode(key, x, y, label, disp, cell.cell_type)

        self._layout_initial()
        self._timer.start(30)
        self.update()

    def _layout_initial(self):
        """Place nodes in a rough topo-sort layout."""
        graph    = self.wb.graph
        nodes    = list(self._nodes.keys())
        levels: dict[tuple, int] = {}

        def depth(k):
            if k in levels:
                return levels[k]
            ups = graph.upstream(k)
            if not ups:
                levels[k] = 0
                return 0
            d = max(depth(u) for u in ups if u in self._nodes) + 1
            levels[k] = d
            return d

        for k in nodes:
            depth(k)

        # Group by level
        from collections import defaultdict
        by_level: dict[int, list] = defaultdict(list)
        for k, lvl in levels.items():
            by_level[lvl].append(k)

        cx = self.width() / 2 if self.width() > 0 else 400
        cy = self.height() / 2 if self.height() > 0 else 300

        for lvl, ks in by_level.items():
            n = len(ks)
            for i, k in enumerate(ks):
                if k in self._nodes:
                    self._nodes[k].x = 150 * lvl + 100
                    self._nodes[k].y = (i - n / 2) * 100 + cy

    # ── force simulation ──────────────────────────────────────────────────────
    def _tick(self):
        nodes  = list(self._nodes.values())
        graph  = self.wb.graph
        damp   = 0.7
        moved  = False

        for node in nodes:
            if node.pinned:
                continue
            fx = fy = 0.0

            # repulsion between all pairs
            for other in nodes:
                if other is node:
                    continue
                dx = node.x - other.x
                dy = node.y - other.y
                d  = max(math.hypot(dx, dy), 1)
                if d < 200:
                    f  = 3000 / (d * d)
                    fx += f * dx / d
                    fy += f * dy / d

            # spring attraction for edges
            for src in graph.upstream(node.key):
                if src in self._nodes:
                    other = self._nodes[src]
                    dx = other.x - node.x
                    dy = other.y - node.y
                    d  = max(math.hypot(dx, dy), 1)
                    ideal = 160
                    f = (d - ideal) * 0.05
                    fx += f * dx / d
                    fy += f * dy / d

            # gravity towards centre
            cx = self.width() / 2
            cy = self.height() / 2
            fx += (cx - node.x) * 0.003
            fy += (cy - node.y) * 0.003

            node.vx = (node.vx + fx) * damp
            node.vy = (node.vy + fy) * damp
            if abs(node.vx) + abs(node.vy) > 0.1:
                moved = True
            node.x += node.vx
            node.y += node.vy

        if not moved:
            self._timer.stop()
        self.update()

    # ── painting ──────────────────────────────────────────────────────────────
    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._draw(p)
        p.end()

    def _draw(self, p: QPainter):
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, _COL["bg_deep"])

        if not self._nodes:
            p.setPen(_COL["text_muted"])
            p.setFont(QFont(FONT_UI.split(",")[0], 13))
            p.drawText(QRect(0, 0, w, h), Qt.AlignmentFlag.AlignCenter,
                       "No formula dependencies to visualise.\nAdd formulas to see the computation graph.")
            return

        # grid dots
        p.setPen(QPen(QColor(C["border"]), 0.5))
        step = int(40 * self._scale)
        if step > 10:
            for gx in range(0, w, step):
                for gy in range(0, h, step):
                    p.drawPoint(gx, gy)

        p.save()
        # (no transform — nodes store world coords directly)

        graph = self.wb.graph

        # ── draw edges ────────────────────────────────────────────────────
        for key, node in self._nodes.items():
            for src_key in graph.upstream(key):
                if src_key not in self._nodes:
                    continue
                src = self._nodes[src_key]
                self._draw_edge(p, src, node)

        # ── draw nodes ────────────────────────────────────────────────────
        for key, node in self._nodes.items():
            self._draw_node(p, node, key == self._selected_key)

        p.restore()

        # legend
        self._draw_legend(p)

    def _draw_edge(self, p: QPainter, src: GraphNode, dst: GraphNode):
        x1, y1 = src.x, src.y
        x2, y2 = dst.x, dst.y
        dx, dy = x2 - x1, y2 - y1
        d = max(math.hypot(dx, dy), 1)

        # arrow colour gradient
        pen = QPen(QColor(C["graph_edge"]), 1.5)
        pen.setStyle(Qt.PenStyle.SolidLine)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)

        # cubic bezier for curved edges
        from PySide6.QtCore import QPointF
        from PySide6.QtGui  import QPainterPath
        ctrl_offset = min(80, d * 0.4)
        path = QPainterPath()
        path.moveTo(x1, y1)
        path.cubicTo(x1 + ctrl_offset, y1,
                     x2 - ctrl_offset, y2,
                     x2, y2)
        p.drawPath(path)

        # arrowhead
        angle = math.atan2(y2 - (y2 + (y1 - ctrl_offset)), x2 - (x2 + (x1 - ctrl_offset)))
        angle = math.atan2(dy, dx)
        ax = x2 - 45 * dx / d
        ay = y2 - 45 * dy / d
        alen = 8
        a1x = ax + alen * math.cos(angle + 2.5)
        a1y = ay + alen * math.sin(angle + 2.5)
        a2x = ax + alen * math.cos(angle - 2.5)
        a2y = ay + alen * math.sin(angle - 2.5)
        p.setPen(QPen(QColor(C["graph_edge"]), 1.5))
        p.drawLine(QPointF(x2 - 45 * dx / d, y2 - 45 * dy / d), QPointF(a1x, a1y))
        p.drawLine(QPointF(x2 - 45 * dx / d, y2 - 45 * dy / d), QPointF(a2x, a2y))

    def _draw_node(self, p: QPainter, node: GraphNode, selected: bool):
        rect = node.rect

        # background
        if selected:
            bg = QColor(C["graph_node_sel"])
            border = QColor(C["accent_blue"])
            bw = 2.0
        elif node.ctype == CellType.FORMULA:
            bg = QColor(C["cell_formula"])
            border = QColor(C["accent_cyan"])
            bw = 1.0
        elif node.ctype == CellType.ERROR:
            bg = QColor(C["cell_error"])
            border = QColor(C["text_red"])
            bw = 1.0
        else:
            bg = QColor(C["graph_node"])
            border = QColor(C["border_light"])
            bw = 1.0

        # glow for selected
        if selected:
            glow = QColor(C["accent_blue"])
            glow.setAlpha(40)
            p.setBrush(QBrush(glow))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(rect.adjusted(-5, -5, 5, 5), 8, 8)

        p.setBrush(QBrush(bg))
        p.setPen(QPen(border, bw))
        p.drawRoundedRect(rect, 6, 6)

        # label (cell address)
        font_lbl = QFont(FONT_MONO.split(",")[0], FONT_SIZE - 2)
        font_lbl.setBold(True)
        p.setFont(font_lbl)
        lbl_rect = QRectF(rect.x(), rect.y(), rect.width(), rect.height() * 0.45)
        p.setPen(_COL["text_accent"] if selected else _COL["text_gold"])
        p.drawText(lbl_rect, Qt.AlignmentFlag.AlignCenter, node.label)

        # value
        font_val = QFont(FONT_MONO.split(",")[0], FONT_SIZE - 2)
        p.setFont(font_val)
        val_rect = QRectF(rect.x(), rect.y() + rect.height() * 0.45,
                          rect.width(), rect.height() * 0.55)
        p.setPen(_COL["text_secondary"])
        p.drawText(val_rect, Qt.AlignmentFlag.AlignCenter,
                   node.display[:10] if node.display else "—")

    def _draw_legend(self, p: QPainter):
        items = [
            (QColor(C["cell_formula"]), QColor(C["accent_cyan"]), "Formula cell"),
            (QColor(C["graph_node"]),   QColor(C["border_light"]), "Value cell"),
            (QColor(C["cell_error"]),   QColor(C["text_red"]),   "Error cell"),
        ]
        x, y = 16, self.height() - 16 - len(items) * 24
        for bg, border, label in items:
            p.setBrush(QBrush(bg))
            p.setPen(QPen(border, 1))
            p.drawRoundedRect(x, y, 14, 14, 3, 3)
            p.setPen(_COL["text_muted"])
            p.setFont(QFont(FONT_UI.split(",")[0], 9))
            p.drawText(x + 20, y + 11, label)
            y += 22

    # ── interaction ───────────────────────────────────────────────────────────
    def mousePressEvent(self, event: QMouseEvent):
        pos = event.position()
        hit = self._hit_test(pos.x(), pos.y())
        if hit:
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging      = hit
                self._selected_key  = hit.key
                hit.pinned          = True
                self.node_selected.emit(*hit.key)
        else:
            if event.button() == Qt.MouseButton.MiddleButton or (
               event.button() == Qt.MouseButton.LeftButton and not hit):
                self._pan_last = event.pos()
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if self._dragging:
            self._dragging.pinned = False
            self._dragging = None
        self._pan_last = None

    def mouseMoveEvent(self, event: QMouseEvent):
        pos = event.position()
        if self._dragging:
            self._dragging.x = pos.x()
            self._dragging.y = pos.y()
            self._dragging.vx = self._dragging.vy = 0
            self.update()
        elif self._pan_last and event.buttons() & Qt.MouseButton.LeftButton:
            delta = event.pos() - self._pan_last
            self._pan_last = event.pos()
            for node in self._nodes.values():
                node.x += delta.x()
                node.y += delta.y()
            self.update()
        else:
            hit = self._hit_test(pos.x(), pos.y())
            if hit:
                QToolTip.showText(event.globalPosition().toPoint(),
                                  f"{hit.label}\n{hit.display}", self)

    def wheelEvent(self, event: QWheelEvent):
        # zoom nodes around cursor
        factor = 1.12 if event.angleDelta().y() > 0 else 1 / 1.12
        cx = event.position().x()
        cy = event.position().y()
        for node in self._nodes.values():
            node.x = cx + (node.x - cx) * factor
            node.y = cy + (node.y - cy) * factor
        self.update()

    def _hit_test(self, x: float, y: float) -> Optional[GraphNode]:
        for node in self._nodes.values():
            if node.rect.contains(x, y):
                return node
        return None

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._nodes:
            self._layout_initial()
            self.update()
