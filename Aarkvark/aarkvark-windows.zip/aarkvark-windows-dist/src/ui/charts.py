"""
ui/charts.py — Chart panel: line, bar, scatter, heatmap.
Uses matplotlib embedded in Qt.
"""
from __future__ import annotations
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QComboBox,
    QPushButton, QLabel, QSizePolicy
)
from PySide6.QtCore    import Qt, Signal
from PySide6.QtGui     import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    import numpy as np
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

from config          import COLORS as C, FONT_UI, FONT_SIZE
from engine.workbook import Workbook
from engine.cells    import CellType


class ChartPanel(QWidget):
    """Chart builder panel."""

    def __init__(self, workbook: Workbook, parent=None):
        super().__init__(parent)
        self.wb = workbook
        self._sheet_name  = workbook.active_sheet_name()
        self._data: list  = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # ── Controls ──
        ctrl = QHBoxLayout()
        ctrl.setSpacing(6)

        self._type_cb = QComboBox()
        self._type_cb.addItems(["Line", "Bar", "Scatter", "Area", "Heatmap"])
        self._type_cb.setFixedWidth(100)
        ctrl.addWidget(QLabel("Type:"))
        ctrl.addWidget(self._type_cb)

        self._draw_btn = QPushButton("Draw")
        self._draw_btn.setObjectName("primary_btn")
        self._draw_btn.setFixedWidth(70)
        ctrl.addWidget(self._draw_btn)
        ctrl.addStretch()

        layout.addLayout(ctrl)

        if HAS_MPL:
            self._fig = Figure(facecolor=C["bg_panel"], tight_layout=True)
            self._canvas = FigureCanvas(self._fig)
            self._canvas.setSizePolicy(QSizePolicy.Policy.Expanding,
                                       QSizePolicy.Policy.Expanding)
            layout.addWidget(self._canvas)
            self._draw_btn.clicked.connect(self._redraw)
            self._type_cb.currentIndexChanged.connect(self._redraw)
        else:
            lbl = QLabel("matplotlib not installed.\npip install matplotlib")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet(f"color: {C['text_muted']}; font-size: 12px;")
            layout.addWidget(lbl)

    # ── public ───────────────────────────────────────────────────────────────
    def set_sheet(self, name: str):
        self._sheet_name = name
        self.set_data_from_sheet()

    def set_data_from_sheet(self):
        """Auto-extract numeric data from active sheet."""
        sheet = self.wb.sheets.get(self._sheet_name)
        if not sheet:
            return
        # Collect numeric values column by column
        cols: dict[int, list] = {}
        for (r, c), cell in sheet.cells.items():
            if isinstance(cell.value, (int, float)):
                if c not in cols:
                    cols[c] = []
                while len(cols[c]) < r:
                    cols[c].append(None)
                cols[c].append(cell.value)

        self._data = [v for v in cols.values() if any(x is not None for x in v)]
        if HAS_MPL:
            self._redraw()

    def set_selection_data(self, wb: Workbook, sheet: str, r1, c1, r2, c2):
        """Draw chart from a cell selection."""
        self._sheet_name = sheet
        rows = wb.get_range_values(sheet, r1, c1, r2, c2)
        # Transpose: each column is a series
        cols = [[rows[r][c] for r in range(len(rows))] for c in range(len(rows[0]))]
        self._data = [[v for v in col if isinstance(v, (int, float))] for col in cols]
        self._data = [d for d in self._data if d]
        if HAS_MPL:
            self._redraw()

    # ── drawing ──────────────────────────────────────────────────────────────
    def _redraw(self):
        if not HAS_MPL:
            return
        self._fig.clear()
        ax = self._fig.add_subplot(111)
        _style_ax(ax)

        chart_type = self._type_cb.currentText()
        data       = self._data

        if not data:
            ax.text(0.5, 0.5, "Select a range and click Draw",
                    ha="center", va="center", color=C["text_muted"],
                    transform=ax.transAxes, fontsize=11)
            self._canvas.draw()
            return

        colors = [C["accent_blue"], C["accent_cyan"], C["accent_gold"],
                  C["text_green"], C["text_red"]]

        try:
            import numpy as np
            if chart_type == "Line":
                for i, series in enumerate(data):
                    ax.plot(series, color=colors[i % len(colors)],
                            linewidth=1.8, marker="o", markersize=3,
                            label=f"Series {i+1}")
            elif chart_type == "Bar":
                xs = list(range(max(len(s) for s in data)))
                w  = 0.8 / max(len(data), 1)
                for i, series in enumerate(data):
                    offset = (i - len(data) / 2) * w + w / 2
                    ax.bar([x + offset for x in range(len(series))],
                           series, width=w * 0.9,
                           color=colors[i % len(colors)],
                           alpha=0.85, label=f"Series {i+1}")
            elif chart_type == "Scatter":
                if len(data) >= 2:
                    xs = data[0]
                    ys = data[1]
                    n  = min(len(xs), len(ys))
                    ax.scatter(xs[:n], ys[:n], color=C["accent_blue"],
                               alpha=0.7, s=40)
                else:
                    xs = list(range(len(data[0])))
                    ax.scatter(xs, data[0], color=C["accent_blue"], s=40)
            elif chart_type == "Area":
                for i, series in enumerate(data):
                    ax.fill_between(range(len(series)), series,
                                    alpha=0.35, color=colors[i % len(colors)],
                                    label=f"Series {i+1}")
                    ax.plot(series, color=colors[i % len(colors)],
                            linewidth=1.5)
            elif chart_type == "Heatmap":
                matrix = np.array([s for s in data if s])
                if matrix.ndim == 2 and matrix.size:
                    im = ax.imshow(matrix, aspect="auto",
                                   cmap="Blues", interpolation="nearest")
                    self._fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

            if chart_type not in ("Heatmap",):
                ax.legend(fontsize=8, facecolor=C["bg_elevated"],
                          edgecolor=C["border"], labelcolor=C["text_secondary"])
        except Exception as e:
            ax.text(0.5, 0.5, f"Chart error:\n{e}",
                    ha="center", va="center", color=C["text_red"],
                    transform=ax.transAxes)

        self._canvas.draw()


def _style_ax(ax):
    """Apply Anglo-futurist dark theme to a matplotlib axes."""
    bg = C["bg_panel"]
    ax.set_facecolor(bg)
    ax.tick_params(colors=C["text_muted"], labelsize=8)
    ax.spines["bottom"].set_color(C["border_light"])
    ax.spines["left"].set_color(C["border_light"])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.xaxis.label.set_color(C["text_muted"])
    ax.yaxis.label.set_color(C["text_muted"])
    ax.grid(True, color=C["border"], linewidth=0.5, alpha=0.6)
