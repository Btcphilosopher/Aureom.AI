"""
main.py — Abacus entry point.
"""
import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(__file__))

from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import Qt, QCoreApplication
from PySide6.QtGui     import QFont

from config          import APP_NAME, FONT_UI, FONT_SIZE
from ui.theme        import apply_theme
from ui.main_window  import MainWindow
from demo            import create_demo_workbook


def main():
    QCoreApplication.setApplicationName(APP_NAME)
    QCoreApplication.setOrganizationName("Aarkvark")

    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Base font
    font = QFont(FONT_UI.split(",")[0].strip(), FONT_SIZE)
    app.setFont(font)

    apply_theme(app)

    win = MainWindow()

    # Load demo workbook
    demo_wb = create_demo_workbook()
    win.wb  = demo_wb
    demo_wb.on_cell_changed(win._on_cell_changed)
    demo_wb.on_sheet_changed(win._on_sheet_changed)

    win._active_sheet = demo_wb.sheet_order[0]
    win._grid_widget.wb  = demo_wb
    win._graph_widget.wb = demo_wb
    win._chart_widget.wb = demo_wb
    win._ai_panel.wb     = demo_wb

    win._grid_widget.set_sheet(win._active_sheet)
    win._graph_widget.set_sheet(win._active_sheet)
    win._chart_widget.set_data_from_sheet()
    win._populate_sheet_tabs()
    win._sync_formula_bar()

    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
