# Aarkvark Windows Setup & Dependencies Installer
# Run this script in PowerShell to configure and optimize your Windows environment

$ErrorActionPreference = "Stop"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Aarkvark Windows Environment Configurator" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host

# 1. Check for Python Installation
Write-Host "[1/3] Checking for Python installation..." -ForegroundColor Yellow
$pythonCheck = Get-Command python -ErrorAction SilentlyContinue

if (-not $pythonCheck) {
    Write-Host "[WARNING] Python is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Downloading and launching Python installer..." -ForegroundColor Green
    $installerPath = "$env:TEMP\python-installer.exe"
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe" -OutFile $installerPath
    Write-Host "Starting Python installer. Please make sure to check 'Add Python to PATH' during installation!" -ForegroundColor Cyan
    Start-Process -FilePath $installerPath -ArgumentList "/passive PrependPath=1" -Wait
    Write-Host "Python installer finished. Please restart your PowerShell terminal and re-run this script." -ForegroundColor Green
    Exit
} else {
    Write-Host "✔ Python found at: $($pythonCheck.Source)" -ForegroundColor Green
}

# 2. Install Python Dependencies
Write-Host ""
Write-Host "[2/3] Installing application dependencies via pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip
python -m pip install -r "$PSScriptRoot\src\requirements.txt"

if ($LASTEXITCODE -eq 0) {
    Write-Host "✔ Dependencies successfully installed!" -ForegroundColor Green
} else {
    Write-Host "[ERROR] Failed to install dependencies. Please run PowerShell as Administrator." -ForegroundColor Red
    Exit 1
}

# 3. Create Windows Desktop Shortcut
Write-Host ""
Write-Host "[3/3] Creating Desktop Shortcut..." -ForegroundColor Yellow

$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('Desktop'), "Aarkvark.lnk")
$Shortcut = $WshShell.CreateShortcut($DesktopPath)

$Shortcut.TargetPath = "cmd.exe"
$Shortcut.Arguments = "/c `"$PSScriptRoot\Aarkvark.bat`""
$Shortcut.WorkingDirectory = $PSScriptRoot
$Shortcut.Description = "Aarkvark - Hyper-modern AI-Assisted Spreadsheet"
$Shortcut.Save()

Write-Host "✔ Shortcut successfully created on your Desktop!" -ForegroundColor Green
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "✔ Aarkvark is ready to run!" -ForegroundColor Green
Write-Host "Double-click the 'Aarkvark' shortcut on your Desktop to launch." -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
