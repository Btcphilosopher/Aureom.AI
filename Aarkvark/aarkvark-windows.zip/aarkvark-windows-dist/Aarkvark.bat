@echo off
:: Aarkvark Windows Launcher
:: Launches the spreadsheet application using the local python environment

title Aarkvark

:: Check if Python is installed locally or in PATH
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python was not found in your system PATH.
    echo Please run 'setup_windows.ps1' or install Python from https://python.org
    pause
    exit /b 1
)

:: Run the application silently in the background using pythonw (no console window)
start "" pythonw "%~dp0src\main.py" %*
