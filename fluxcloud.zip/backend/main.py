"""
FluxCloud Control Plane API
FastAPI Implementation for Compute Orchestration, FluxMeter Engine & FluxBilling.
"""

from fastapi import FastAPI, Header, HTTPException, Depends, status
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
import time
import uuid

app = FastAPI(
    title="FluxCloud Infrastructure API",
    version="1.0.0",
    description="Programmable Metered Compute Utility Platform API"
)

# In-memory tenant isolation state for local development mode
DB = {
    "instances": {},
    "workloads": {},
    "balances": {
        "org_acorn_ai": {"credit": 150.00, "reserved": 12.50},
        "org_finscale": {"credit": 840.50, "reserved": 38.20}
    },
    "idempotency_cache": {}
}

class InstanceCreateRequest(BaseModel):
    name: str = Field(..., example="research-worker")
    instance_type: str = Field("flux-standard", example="flux-standard")
    region: str = Field("us-east-local", example="us-east-local")
    billing_mode: str = Field("prepaid", example="prepaid")
    max_hourly_cost: Optional[float] = 0.20
    auto_stop_minutes: Optional[int] = 30

class WorkloadCreateRequest(BaseModel):
    name: str = Field(..., example="data-processing-job")
    image: str = Field(..., example="fluxcloud/python:3.11-slim")
    cpu: int = Field(2, ge=1, le=8)
    memory_gb: int = Field(4, ge=1, le=16)
    max_runtime_seconds: int = Field(300, le=3600)
    max_cost: float = Field(0.10, gt=0)
    env_vars: Optional[Dict[str, str]] = {}

def get_tenant_org_id(authorization: Optional[str] = Header(None)) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key or Authorization header")
    token = authorization.split(" ")[1]
    if "finscale" in token:
        return "org_finscale"
    return "org_acorn_ai"

@app.get("/health")
def health_check():
    return {
        "status": "HEALTHY",
        "cluster_orchestrator": "FluxEngine Local Container Adapter",
        "metering_engine": "FluxMeter v2026.10",
        "timestamp": int(time.time() * 1000)
    }

@app.get("/api/v1/compute/instances")
def list_instances(org_id: str = Depends(get_tenant_org_id)):
    return [inst for inst in DB["instances"].values() if inst["org_id"] == org_id]

@app.post("/api/v1/compute/instances", status_code=status.HTTP_201_CREATED)
def create_instance(
    req: InstanceCreateRequest,
    idempotency_key: Optional[str] = Header(None),
    org_id: str = Depends(get_tenant_org_id)
):
    if idempotency_key and idempotency_key in DB["idempotency_cache"]:
        return DB["idempotency_cache"][idempotency_key]

    # Check funds
    bal = DB["balances"].get(org_id, {"credit": 0.0, "reserved": 0.0})
    available = bal["credit"] - bal["reserved"]
    if available < 0.04:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail="Insufficient prepaid balance")

    inst_id = f"inst_{uuid.uuid4().hex[:8]}"
    instance = {
        "id": inst_id,
        "org_id": org_id,
        "name": req.name,
        "instance_type": req.instance_type,
        "region": req.region,
        "status": "RUNNING",
        "public_ip": "198.51.100.24",
        "private_ip": "10.0.1.14",
        "hourly_rate": 0.0400,
        "created_at": int(time.time() * 1000)
    }
    DB["instances"][inst_id] = instance
    bal["reserved"] += 0.04
    if idempotency_key:
        DB["idempotency_cache"][idempotency_key] = instance
    return instance

@app.post("/api/v1/compute/instances/{instance_id}/stop")
def stop_instance(instance_id: str, org_id: str = Depends(get_tenant_org_id)):
    inst = DB["instances"].get(instance_id)
    if not inst or inst["org_id"] != org_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Instance not found or access denied")
    inst["status"] = "STOPPED"
    return inst

@app.post("/api/v1/compute/instances/{instance_id}/terminate")
def terminate_instance(instance_id: str, org_id: str = Depends(get_tenant_org_id)):
    inst = DB["instances"].get(instance_id)
    if not inst or inst["org_id"] != org_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Instance not found or access denied")
    inst["status"] = "TERMINATED"
    return {"status": "terminated", "id": instance_id}

@app.post("/api/v1/workloads", status_code=status.HTTP_201_CREATED)
def submit_workload(
    req: WorkloadCreateRequest,
    idempotency_key: Optional[str] = Header(None),
    org_id: str = Depends(get_tenant_org_id)
):
    if idempotency_key and idempotency_key in DB["idempotency_cache"]:
        return DB["idempotency_cache"][idempotency_key]

    job_id = f"job_{uuid.uuid4().hex[:8]}"
    workload = {
        "id": job_id,
        "org_id": org_id,
        "name": req.name,
        "image": req.image,
        "status": "RUNNING",
        "cpu_limit": req.cpu,
        "memory_limit_gb": req.memory_gb,
        "max_runtime_seconds": req.max_runtime_seconds,
        "max_cost": req.max_cost,
        "created_at": int(time.time() * 1000),
        "logs": [
            f"[FluxRunner] Initialized cgroup sandbox for {job_id}",
            f"[FluxRunner] Pulling approved image {req.image}",
            "[FluxRunner] Task running in isolated namespace."
        ]
    }
    DB["workloads"][job_id] = workload
    if idempotency_key:
        DB["idempotency_cache"][idempotency_key] = workload
    return workload

@app.get("/api/v1/billing/balance")
def get_balance(org_id: str = Depends(get_tenant_org_id)):
    bal = DB["balances"].get(org_id, {"credit": 0.0, "reserved": 0.0})
    return {
        "org_id": org_id,
        "credit_balance": bal["credit"],
        "reserved_balance": bal["reserved"],
        "available_balance": max(0.0, bal["credit"] - bal["reserved"])
    }
