package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.fluxcloud.ui.components.*
import com.example.fluxcloud.ui.screens.*
import com.example.fluxcloud.ui.theme.*
import com.example.fluxcloud.viewmodel.FluxCloudViewModel
import com.example.fluxcloud.viewmodel.NavigationSection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                FluxCloudApp()
            }
        }
    }
}

@Composable
fun FluxCloudApp(viewModel: FluxCloudViewModel = viewModel()) {
    val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
    val activeOrg by viewModel.activeOrg.collectAsStateWithLifecycle()
    val organisations by viewModel.organisations.collectAsStateWithLifecycle()
    val instances by viewModel.instances.collectAsStateWithLifecycle()
    val workloads by viewModel.workloads.collectAsStateWithLifecycle()
    val gpuResources by viewModel.gpuResources.collectAsStateWithLifecycle()
    val storageBuckets by viewModel.storageBuckets.collectAsStateWithLifecycle()
    val networkVpcs by viewModel.networkVpcs.collectAsStateWithLifecycle()
    val usageEvents by viewModel.usageEvents.collectAsStateWithLifecycle()
    val ledgerTransactions by viewModel.ledgerTransactions.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val apiKeys by viewModel.apiKeys.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val health by viewModel.health.collectAsStateWithLifecycle()

    // Dialog states
    val showProvisionDialog by viewModel.showProvisionDialog.collectAsStateWithLifecycle()
    val showWorkloadDialog by viewModel.showWorkloadDialog.collectAsStateWithLifecycle()
    val showTopUpDialog by viewModel.showTopUpDialog.collectAsStateWithLifecycle()
    val showApiKeyDialog by viewModel.showApiKeyDialog.collectAsStateWithLifecycle()
    val showCreateBucketDialog by viewModel.showCreateBucketDialog.collectAsStateWithLifecycle()
    val selectedInvoice by viewModel.selectedInvoice.collectAsStateWithLifecycle()
    val csvExportData by viewModel.csvExportData.collectAsStateWithLifecycle()
    val auditSecurityResult by viewModel.auditSecurityMessage.collectAsStateWithLifecycle()
    val userFeedback by viewModel.userFeedback.collectAsStateWithLifecycle()

    // BackHandler to return to Overview if on a secondary section
    BackHandler(enabled = selectedSection != NavigationSection.OVERVIEW) {
        viewModel.selectSection(NavigationSection.OVERVIEW)
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userFeedback) {
        userFeedback?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = FluxNavy900,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            FluxHeader(
                activeOrg = activeOrg,
                organisations = organisations,
                onSwitchOrg = { viewModel.switchOrganisation(it) },
                onToggleEnv = { viewModel.toggleEnvironment() },
                onTopUpClick = { viewModel.showTopUpDialog.value = true }
            )
        },
        bottomBar = {
            FluxNavigationBar(
                selectedSection = selectedSection,
                onSelectSection = { viewModel.selectSection(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedSection) {
                NavigationSection.OVERVIEW -> {
                    OverviewScreen(
                        activeOrg = activeOrg,
                        instances = instances,
                        workloads = workloads,
                        health = health,
                        onNavigate = { viewModel.selectSection(it) },
                        onOpenProvisionDialog = { viewModel.showProvisionDialog.value = true },
                        onOpenWorkloadDialog = { viewModel.showWorkloadDialog.value = true },
                        onOpenTopUpDialog = { viewModel.showTopUpDialog.value = true },
                        onRunSecurityAudit = { viewModel.runSecurityAudit() }
                    )
                }
                NavigationSection.COMPUTE -> {
                    ComputeScreen(
                        instances = instances,
                        products = viewModel.computeProducts,
                        activeOrg = activeOrg,
                        onStartInstance = { viewModel.startInstance(it) },
                        onStopInstance = { viewModel.stopInstance(it) },
                        onTerminateInstance = { viewModel.terminateInstance(it) },
                        onOpenProvisionDialog = { viewModel.showProvisionDialog.value = true }
                    )
                }
                NavigationSection.WORKLOADS -> {
                    WorkloadsScreen(
                        workloads = workloads,
                        activeOrg = activeOrg,
                        onSubmitWorkloadClick = { viewModel.showWorkloadDialog.value = true },
                        onCancelWorkload = { viewModel.cancelWorkload(it) }
                    )
                }
                NavigationSection.GPU -> {
                    GpuScreen(gpuResources = gpuResources)
                }
                NavigationSection.STORAGE -> {
                    StorageScreen(
                        buckets = storageBuckets,
                        activeOrg = activeOrg,
                        onCreateBucketClick = { viewModel.showCreateBucketDialog.value = true }
                    )
                }
                NavigationSection.NETWORKING -> {
                    NetworkingScreen(vpcs = networkVpcs, activeOrg = activeOrg)
                }
                NavigationSection.METERING -> {
                    MeteringScreen(
                        usageEvents = usageEvents,
                        activeOrg = activeOrg,
                        onExportCsv = { viewModel.exportCsv() }
                    )
                }
                NavigationSection.BILLING -> {
                    BillingScreen(
                        activeOrg = activeOrg,
                        ledgerTransactions = ledgerTransactions,
                        invoices = invoices,
                        onTopUpClick = { viewModel.showTopUpDialog.value = true },
                        onSelectInvoice = { viewModel.selectedInvoice.value = it },
                        onUpdateSpendingLimits = { limit, thresh -> viewModel.updateSpendingLimits(limit, thresh) }
                    )
                }
                NavigationSection.DEVELOPERS -> {
                    DevelopersScreen(
                        apiKeys = apiKeys,
                        activeOrg = activeOrg,
                        onCreateApiKeyClick = { viewModel.showApiKeyDialog.value = true },
                        onRevokeApiKey = { viewModel.revokeApiKey(it) }
                    )
                }
                NavigationSection.LOGS_MONITORING -> {
                    LogsMonitoringScreen(
                        health = health,
                        auditLogs = auditLogs,
                        activeOrg = activeOrg
                    )
                }
                NavigationSection.ORG_SETTINGS -> {
                    OrgSettingsScreen(
                        activeOrg = activeOrg,
                        organisations = organisations,
                        onSwitchOrg = { viewModel.switchOrganisation(it) },
                        onToggleEnvironment = { viewModel.toggleEnvironment() },
                        onRunSecurityAudit = { viewModel.runSecurityAudit() }
                    )
                }
            }
        }
    }

    // Active Dialogs
    if (showProvisionDialog) {
        ProvisionInstanceDialog(
            products = viewModel.computeProducts,
            activeOrg = activeOrg,
            onDismiss = { viewModel.showProvisionDialog.value = false },
            onConfirm = { name, type, region, maxCost, autoStop ->
                viewModel.provisionInstance(name, type, region, maxCost, autoStop)
            }
        )
    }

    if (showWorkloadDialog) {
        SubmitWorkloadDialog(
            activeOrg = activeOrg,
            onDismiss = { viewModel.showWorkloadDialog.value = false },
            onConfirm = { name, img, cpu, mem, timeout, maxCost ->
                viewModel.submitWorkload(name, img, cpu, mem, timeout, maxCost)
            }
        )
    }

    if (showTopUpDialog) {
        TopUpDialog(
            onDismiss = { viewModel.showTopUpDialog.value = false },
            onConfirm = { amount -> viewModel.topUpBalance(amount) }
        )
    }

    if (showApiKeyDialog) {
        CreateApiKeyDialog(
            onDismiss = { viewModel.showApiKeyDialog.value = false },
            onConfirm = { name, role -> viewModel.createApiKey(name, role) }
        )
    }

    if (showCreateBucketDialog) {
        CreateBucketDialog(
            onDismiss = { viewModel.showCreateBucketDialog.value = false },
            onConfirm = { name, region -> viewModel.createBucket(name, region) }
        )
    }

    selectedInvoice?.let { inv ->
        InvoiceDetailDialog(invoice = inv, onDismiss = { viewModel.selectedInvoice.value = null })
    }

    auditSecurityResult?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.auditSecurityMessage.value = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = FluxGreenSuccess)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Security Audit Verification Passed")
                }
            },
            text = {
                Column {
                    Text(
                        text = "TENANT BOUNDARY STRICTLY ENFORCED:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = FluxCyanLive
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = msg, style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.auditSecurityMessage.value = null }) {
                    Text("Acknowledge")
                }
            }
        )
    }

    csvExportData?.let { csv ->
        AlertDialog(
            onDismissRequest = { viewModel.csvExportData.value = null },
            title = { Text("Exported Usage Events (CSV)") },
            text = {
                Surface(
                    color = FluxTerminalBg,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp)
                ) {
                    Text(
                        text = csv,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 9.sp),
                        color = FluxTerminalText,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.csvExportData.value = null }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
fun FluxNavigationBar(
    selectedSection: NavigationSection,
    onSelectSection: (NavigationSection) -> Unit
) {
    Surface(
        color = FluxNavy950,
        border = BorderStroke(1.dp, FluxBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavigationSection.entries.forEach { section ->
                val isSelected = section == selectedSection
                val icon = getSectionIcon(section)

                Surface(
                    color = if (isSelected) FluxNavy800 else Color.Transparent,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) FluxCyanGlow else Color.Transparent
                    ),
                    modifier = Modifier
                        .clickable { onSelectSection(section) }
                        .testTag("nav_tab_${section.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = section.title,
                            tint = if (isSelected) FluxCyanLive else FluxTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = section.title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp
                            ),
                            color = if (isSelected) Color.White else FluxTextMuted
                        )
                    }
                }
            }
        }
    }
}

fun getSectionIcon(section: NavigationSection): ImageVector {
    return when (section) {
        NavigationSection.OVERVIEW -> Icons.Default.Dashboard
        NavigationSection.COMPUTE -> Icons.Default.Dns
        NavigationSection.WORKLOADS -> Icons.Default.Terminal
        NavigationSection.GPU -> Icons.Default.Memory
        NavigationSection.STORAGE -> Icons.Default.Folder
        NavigationSection.NETWORKING -> Icons.Default.Lan
        NavigationSection.METERING -> Icons.Default.Speed
        NavigationSection.BILLING -> Icons.Default.ReceiptLong
        NavigationSection.DEVELOPERS -> Icons.Default.Code
        NavigationSection.LOGS_MONITORING -> Icons.Default.Insights
        NavigationSection.ORG_SETTINGS -> Icons.Default.Tune
    }
}
