package com.example.fluxcloud.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.theme.*

@Composable
fun FluxHeader(
    activeOrg: Organisation,
    organisations: List<Organisation>,
    onSwitchOrg: (String) -> Unit,
    onToggleEnv: () -> Unit,
    onTopUpClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        color = FluxNavy950,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = FluxBorderSubtle)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Logo & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.testTag("app_logo_row")
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(FluxBlueElectric, FluxCyanGlow)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = "FluxCloud Logo",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FLUX",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = Color.White
                            )
                            Text(
                                text = "CLOUD",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = FluxCyanLive
                            )
                        }
                        Text(
                            text = "Metered Compute Utility",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = FluxTextMuted
                        )
                    }
                }

                // Balance Pill
                Surface(
                    color = FluxNavy850,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, FluxBorderActive),
                    modifier = Modifier
                        .clickable { onTopUpClick() }
                        .testTag("balance_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(FluxGreenSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = formatCurrency2(activeOrg.availableBalance),
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                ),
                                color = FluxGreenSuccess
                            )
                            if (activeOrg.reservedBalance > 0) {
                                Text(
                                    text = "Hold: ${formatCurrency2(activeOrg.reservedBalance)}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = FluxAmberWarning
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Organisation selector & Environment toggle row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Org Dropdown Trigger
                Box {
                    Surface(
                        color = FluxNavy800,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, FluxBorderSubtle),
                        modifier = Modifier
                            .clickable { expanded = true }
                            .testTag("org_selector_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = "Org",
                                tint = FluxBluePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = activeOrg.name,
                                style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                                color = FluxTextPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select Org",
                                tint = FluxTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier
                            .background(FluxNavy800)
                            .border(1.dp, FluxBorderActive, RoundedCornerShape(8.dp))
                    ) {
                        organisations.forEach { org ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = org.name,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontWeight = if (org.id == activeOrg.id) FontWeight.Bold else FontWeight.Normal
                                            ),
                                            color = if (org.id == activeOrg.id) FluxCyanLive else FluxTextPrimary
                                        )
                                        Text(
                                            text = "Role: ${org.currentRole.label} • Balance: ${formatCurrency2(org.availableBalance)}",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                                            color = FluxTextMuted
                                        )
                                    }
                                },
                                onClick = {
                                    onSwitchOrg(org.id)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Environment & Role badges
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Environment Pill Toggle
                    Surface(
                        color = if (activeOrg.activeEnvironment == EnvironmentType.PRODUCTION) FluxNavy750 else FluxNavy800,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(
                            1.dp,
                            if (activeOrg.activeEnvironment == EnvironmentType.PRODUCTION) FluxCyanGlow else FluxAmberWarning
                        ),
                        modifier = Modifier
                            .clickable { onToggleEnv() }
                            .testTag("env_toggle_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (activeOrg.activeEnvironment == EnvironmentType.PRODUCTION) FluxCyanLive else FluxAmberWarning)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = activeOrg.activeEnvironment.label.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = if (activeOrg.activeEnvironment == EnvironmentType.PRODUCTION) FluxCyanLive else FluxAmberWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Role Chip
                    Surface(
                        color = FluxNavy800,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, FluxBorderSubtle)
                    ) {
                        Text(
                            text = activeOrg.currentRole.label,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = FluxTextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                ),
                color = color
            )
        }
    }
}

@Composable
fun MetricStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = FluxNavy800,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, FluxBorderSubtle),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    ),
                    color = FluxTextMuted
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(iconColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = FluxTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                color = FluxTextSecondary
            )
        }
    }
}

@Composable
fun MonospaceTerminalBox(
    logs: List<String>,
    modifier: Modifier = Modifier,
    emptyMessage: String = "No console output recorded."
) {
    Surface(
        color = FluxTerminalBg,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, FluxBorderActive),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(FluxRedDanger))
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(FluxAmberWarning))
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(FluxGreenSuccess))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "flux-runner-isolation.log",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = FluxTextMuted
                    )
                }
                Text(
                    text = "SANDBOX: ISOLATED",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                    color = FluxCyanLive
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = FluxBorderSubtle)
            Spacer(modifier = Modifier.height(8.dp))

            if (logs.isEmpty()) {
                Text(
                    text = emptyMessage,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                    color = FluxTextMuted
                )
            } else {
                logs.forEach { line ->
                    val textColor = when {
                        line.contains("error", ignoreCase = true) || line.contains("failed", ignoreCase = true) -> FluxTerminalError
                        line.contains("exit 0", ignoreCase = true) || line.contains("complete", ignoreCase = true) -> FluxTerminalSuccess
                        line.contains("FluxRunner", ignoreCase = true) -> FluxTerminalPrompt
                        else -> FluxTerminalText
                    }
                    Text(
                        text = line,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        ),
                        color = textColor
                    )
                }
            }
        }
    }
}
