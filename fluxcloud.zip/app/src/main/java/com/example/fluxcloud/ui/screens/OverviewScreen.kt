package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.*
import com.example.fluxcloud.ui.theme.*
import com.example.fluxcloud.viewmodel.NavigationSection

@Composable
fun OverviewScreen(
    activeOrg: Organisation,
    instances: List<ComputeInstance>,
    workloads: List<Workload>,
    health: PlatformHealthMetric,
    onNavigate: (NavigationSection) -> Unit,
    onOpenProvisionDialog: () -> Unit,
    onOpenWorkloadDialog: () -> Unit,
    onOpenTopUpDialog: () -> Unit,
    onRunSecurityAudit: () -> Unit
) {
    val runningInstances = instances.count { it.status == InstanceStatus.RUNNING }
    val runningWorkloads = workloads.count { it.status == WorkloadStatus.RUNNING }
    val avgCpu = if (instances.isNotEmpty()) instances.map { it.cpuUsagePercent }.average().toFloat() else 0f
    val avgMem = if (instances.isNotEmpty()) instances.map { it.memUsagePercent }.average().toFloat() else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(FluxNavy800, FluxNavy850)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(FluxCyanLive)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "PROGRAMMABLE CLOUD UTILITY",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        letterSpacing = 1.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = FluxCyanLive
                                )
                            }
                            StatusBadge(
                                text = "${health.apiLatencyMs}ms • 99.99% UP",
                                color = FluxGreenSuccess
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Compute at the speed of code.",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black
                            ),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Provision instantly. Measure precisely. Pay for what you use.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = FluxTextSecondary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenProvisionDialog,
                                colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("overview_provision_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Node", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            FilledTonalButton(
                                onClick = onOpenWorkloadDialog,
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = FluxNavy700, contentColor = FluxCyanLive),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("overview_workload_btn")
                            ) {
                                Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Run Job", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onOpenTopUpDialog,
                                border = BorderStroke(1.dp, FluxBorderActive),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("overview_funds_btn")
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = FluxGreenSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Funds", fontSize = 12.sp, color = FluxGreenSuccess, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Metrics 2x2 Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricStatCard(
                    title = "Active Instances",
                    value = "$runningInstances",
                    subtitle = "${instances.size} provisioned total",
                    icon = Icons.Default.Dns,
                    iconColor = FluxCyanLive,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(NavigationSection.COMPUTE) }
                        .testTag("card_instances")
                )
                MetricStatCard(
                    title = "Workload Jobs",
                    value = "$runningWorkloads",
                    subtitle = "${workloads.size} jobs executed",
                    icon = Icons.Default.Terminal,
                    iconColor = FluxPurpleCompute,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(NavigationSection.WORKLOADS) }
                        .testTag("card_workloads")
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricStatCard(
                    title = "Available Credit",
                    value = formatCurrency2(activeOrg.availableBalance),
                    subtitle = "Hold: ${formatCurrency2(activeOrg.reservedBalance)}",
                    icon = Icons.Default.AccountBalanceWallet,
                    iconColor = FluxGreenSuccess,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(NavigationSection.BILLING) }
                        .testTag("card_balance")
                )
                MetricStatCard(
                    title = "Platform Health",
                    value = "${health.apiLatencyMs} ms",
                    subtitle = health.providerHealth.take(18) + "...",
                    icon = Icons.Default.CheckCircle,
                    iconColor = FluxBluePrimary,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(NavigationSection.LOGS_MONITORING) }
                        .testTag("card_health")
                )
            }
        }

        // Live Telemetry Load Gauge Card
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE CLUSTER TELEMETRY",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(FluxCyanLive)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "STREAMING (2s interval)",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = FluxCyanLive
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // CPU Usage Bar
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Aggregated CPU Allocation", style = MaterialTheme.typography.bodyMedium, color = FluxTextSecondary)
                            Text("${String.format("%.1f", avgCpu)}%", style = MaterialTheme.typography.labelLarge, color = FluxCyanLive)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (avgCpu / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = FluxCyanLive,
                            trackColor = FluxNavy900
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Memory Usage Bar
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Aggregated Memory Allocation", style = MaterialTheme.typography.bodyMedium, color = FluxTextSecondary)
                            Text("${String.format("%.1f", avgMem)}%", style = MaterialTheme.typography.labelLarge, color = FluxPurpleCompute)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (avgMem / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = FluxPurpleCompute,
                            trackColor = FluxNavy900
                        )
                    }
                }
            }
        }

        // Active Compute Instances Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE COMPUTE NODES",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                TextButton(onClick = { onNavigate(NavigationSection.COMPUTE) }) {
                    Text("View All (${instances.size})", color = FluxCyanLive, fontSize = 12.sp)
                }
            }

            if (instances.isEmpty()) {
                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Dns, contentDescription = null, tint = FluxTextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No active compute instances in ${activeOrg.name}.", style = MaterialTheme.typography.bodyMedium, color = FluxTextMuted)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onOpenProvisionDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary)
                        ) {
                            Text("Provision First Instance")
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    instances.take(3).forEach { inst ->
                        Surface(
                            color = FluxNavy800,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, FluxBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(NavigationSection.COMPUTE) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(if (inst.status == InstanceStatus.RUNNING) FluxGreenSuccess else FluxAmberWarning)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(inst.name, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                        Text("${inst.instanceType} • ${inst.region}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxTextSecondary)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = formatCurrency(inst.totalCostSoFar),
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = FluxCyanLive
                                    )
                                    Text(
                                        text = "${inst.uptimeSeconds / 60}m uptime",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = FluxTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Workload Jobs Preview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CONTAINER WORKLOADS",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                TextButton(onClick = { onNavigate(NavigationSection.WORKLOADS) }) {
                    Text("Inspect (${workloads.size})", color = FluxCyanLive, fontSize = 12.sp)
                }
            }

            if (workloads.isEmpty()) {
                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No workloads queued or running.", style = MaterialTheme.typography.bodyMedium, color = FluxTextMuted)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    workloads.take(2).forEach { wl ->
                        Surface(
                            color = FluxNavy800,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, FluxBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(NavigationSection.WORKLOADS) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(wl.name, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                    StatusBadge(
                                        text = wl.status.label,
                                        color = when (wl.status) {
                                            WorkloadStatus.RUNNING -> FluxCyanLive
                                            WorkloadStatus.COMPLETED -> FluxGreenSuccess
                                            WorkloadStatus.FAILED -> FluxRedDanger
                                            else -> FluxAmberWarning
                                        }
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(wl.image, style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), color = FluxTextSecondary)

                                if (wl.status == WorkloadStatus.RUNNING) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { wl.progress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = FluxCyanLive,
                                        trackColor = FluxNavy900
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Multi-Tenant Isolation Security Check Button
        item {
            Surface(
                color = FluxNavy850,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tenant Isolation Guard", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        }
                        Text(
                            "Audit cross-tenant boundary verification in real-time.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = FluxTextSecondary
                        )
                    }
                    Button(
                        onClick = onRunSecurityAudit,
                        colors = ButtonDefaults.buttonColors(containerColor = FluxNavy700),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("run_security_audit_btn")
                    ) {
                        Text("Audit Test", fontSize = 11.sp, color = FluxCyanLive)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
