package com.example.fluxcloud.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fluxcloud.data.FluxCloudRepository
import com.example.fluxcloud.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class NavigationSection(val title: String, val iconName: String) {
    OVERVIEW("Overview", "Dashboard"),
    COMPUTE("Compute", "Dns"),
    WORKLOADS("Workloads", "Terminal"),
    GPU("GPU Resources", "Memory"),
    STORAGE("Storage", "Folder"),
    NETWORKING("Networking", "Lan"),
    METERING("Usage Metering", "Speed"),
    BILLING("Billing & Ledger", "ReceiptLong"),
    DEVELOPERS("API & SDK", "Code"),
    LOGS_MONITORING("Health & Logs", "Insights"),
    ORG_SETTINGS("Organisation", "Tune")
}

class FluxCloudViewModel(
    private val repository: FluxCloudRepository = FluxCloudRepository()
) : ViewModel() {

    private val _selectedSection = MutableStateFlow(NavigationSection.OVERVIEW)
    val selectedSection: StateFlow<NavigationSection> = _selectedSection.asStateFlow()

    val activeOrg: StateFlow<Organisation> = repository.activeOrg
    val organisations: StateFlow<List<Organisation>> = repository.organisations

    val instances: StateFlow<List<ComputeInstance>> = combine(repository.instances, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workloads: StateFlow<List<Workload>> = combine(repository.workloads, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val gpuResources: StateFlow<List<GpuResource>> = repository.gpuResources
    val computeProducts: List<ComputeProduct> = repository.computeProducts

    val storageBuckets: StateFlow<List<StorageBucket>> = combine(repository.storageBuckets, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val networkVpcs: StateFlow<List<NetworkVpc>> = combine(repository.networkVpcs, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val usageEvents: StateFlow<List<UsageEvent>> = combine(repository.usageEvents, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerTransactions: StateFlow<List<LedgerTransaction>> = combine(repository.ledgerTransactions, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices: StateFlow<List<Invoice>> = combine(repository.invoices, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val apiKeys: StateFlow<List<ApiKey>> = combine(repository.apiKeys, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = combine(repository.auditLogs, repository.activeOrg) { list, org ->
        list.filter { it.orgId == org.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val health: StateFlow<PlatformHealthMetric> = repository.health

    // Dialog & Interaction states
    var showProvisionDialog = MutableStateFlow(false)
    var showWorkloadDialog = MutableStateFlow(false)
    var showTopUpDialog = MutableStateFlow(false)
    var showApiKeyDialog = MutableStateFlow(false)
    var showCreateBucketDialog = MutableStateFlow(false)

    var selectedInvoice = MutableStateFlow<Invoice?>(null)
    var selectedWorkloadDetail = MutableStateFlow<Workload?>(null)
    var csvExportData = MutableStateFlow<String?>(null)
    var auditSecurityMessage = MutableStateFlow<String?>(null)
    var userFeedback = MutableStateFlow<String?>(null)

    fun selectSection(section: NavigationSection) {
        _selectedSection.value = section
    }

    fun switchOrganisation(orgId: String) {
        repository.switchOrganisation(orgId)
    }

    fun toggleEnvironment() {
        repository.toggleEnvironment()
    }

    fun provisionInstance(
        name: String,
        instanceType: String,
        region: String,
        maxHourlyCost: Double,
        autoStopMinutes: Int
    ) {
        val result = repository.provisionInstance(name, instanceType, region, maxHourlyCost, autoStopMinutes)
        result.onSuccess {
            userFeedback.value = "Instance '${it.name}' successfully provisioned."
            showProvisionDialog.value = false
        }.onFailure {
            userFeedback.value = "Provisioning error: ${it.message}"
        }
    }

    fun stopInstance(instanceId: String) {
        repository.stopInstance(instanceId)
        userFeedback.value = "Instance $instanceId stopped."
    }

    fun startInstance(instanceId: String) {
        repository.startInstance(instanceId)
        userFeedback.value = "Instance $instanceId started."
    }

    fun terminateInstance(instanceId: String) {
        repository.terminateInstance(instanceId)
        userFeedback.value = "Instance $instanceId terminated."
    }

    fun submitWorkload(
        name: String,
        image: String,
        cpu: Int,
        memoryGb: Int,
        maxRuntimeSeconds: Int,
        maxCost: Double,
        envVars: Map<String, String> = emptyMap(),
        idempotencyKey: String = ""
    ) {
        val key = idempotencyKey.ifBlank { "idemp_${System.currentTimeMillis()}" }
        val res = repository.submitWorkload(name, image, cpu, memoryGb, maxRuntimeSeconds, maxCost, envVars, key)
        res.onSuccess {
            userFeedback.value = "Workload '${it.name}' submitted to container sandbox."
            showWorkloadDialog.value = false
        }.onFailure {
            userFeedback.value = "Workload submission error: ${it.message}"
        }
    }

    fun cancelWorkload(workloadId: String) {
        repository.cancelWorkload(workloadId)
        userFeedback.value = "Workload $workloadId cancelled."
    }

    fun topUpBalance(amount: Double) {
        repository.topUpBalance(amount)
        userFeedback.value = "Prepaid balance credited with ${formatCurrency(amount)}."
        showTopUpDialog.value = false
    }

    fun updateSpendingLimits(spendingLimit: Double, autoShutdownThreshold: Double) {
        repository.updateSpendingLimits(spendingLimit, autoShutdownThreshold)
        userFeedback.value = "Updated spending limit & auto-shutdown thresholds."
    }

    fun createApiKey(name: String, role: OrgRole) {
        val key = repository.createApiKey(name, role)
        userFeedback.value = "Generated API Key: ${key.keyPrefix}"
        showApiKeyDialog.value = false
    }

    fun revokeApiKey(keyId: String) {
        repository.revokeApiKey(keyId)
        userFeedback.value = "API Key revoked."
    }

    fun createBucket(name: String, region: String) {
        repository.createBucket(name, region)
        userFeedback.value = "Bucket created."
        showCreateBucketDialog.value = false
    }

    fun runSecurityAudit() {
        val res = repository.runCrossTenantSecurityAudit()
        auditSecurityMessage.value = res
    }

    fun exportCsv() {
        csvExportData.value = repository.generateCsvExport()
    }

    fun clearFeedback() {
        userFeedback.value = null
    }
}
