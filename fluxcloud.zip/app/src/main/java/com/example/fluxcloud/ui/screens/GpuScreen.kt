package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun GpuScreen(
    gpuResources: List<GpuResource>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "GPU ACCELERATED COMPUTE",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "High-density accelerators for LLM training, fine-tuning, and batch inference.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FluxTextSecondary
                )
            }
        }

        // Hardware isolation & transparency banner
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Hardware Verification: In local development, physical GPU clusters are reported transparently as remote or unavailable when no physical accelerator is mounted to avoid misleading claims.",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = FluxTextSecondary
                    )
                }
            }
        }

        item {
            Text(
                text = "GPU HARDWARE INVENTORY",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(gpuResources) { res ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Memory, contentDescription = null, tint = FluxPurpleCompute, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(res.model, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text("Provider: ${res.provider}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                            }
                        }

                        StatusBadge(
                            text = if (res.isAvailable) "ONLINE (${res.availableCount} Avail)" else "UNAVAILABLE",
                            color = if (res.isAvailable) FluxGreenSuccess else FluxAmberWarning
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("VRAM ALLOCATION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${res.memoryGb} GB HBM3/GDDR6", style = MaterialTheme.typography.bodyMedium, color = FluxCyanLive)
                        }
                        Column {
                            Text("HOURLY RATE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${formatCurrency(res.pricePerHour)} / hr", style = MaterialTheme.typography.bodyMedium, color = FluxGreenSuccess)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("PER-SECOND RATE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${String.format("%.7f", res.pricePerSecond)} / s", style = MaterialTheme.typography.labelSmall, color = FluxTextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Capacity: ${res.availableCount} of ${res.totalCount} cards available in cluster",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = FluxTextMuted
                        )
                        Button(
                            onClick = { },
                            enabled = res.isAvailable,
                            colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) {
                            Text("Allocate GPU", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
