package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun OrgSettingsScreen(
    activeOrg: Organisation,
    organisations: List<Organisation>,
    onSwitchOrg: (String) -> Unit,
    onToggleEnvironment: () -> Unit,
    onRunSecurityAudit: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "ORGANISATION SETTINGS",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Multi-tenant isolation, role-based access control, and environment switching.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FluxTextSecondary
                )
            }
        }

        // Active Org Card
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(activeOrg.name, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text("Tenant Slug: ${activeOrg.slug} • ID: ${activeOrg.id}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                        }
                        StatusBadge(
                            text = activeOrg.activeEnvironment.label.uppercase(),
                            color = if (activeOrg.activeEnvironment == EnvironmentType.PRODUCTION) FluxCyanLive else FluxAmberWarning
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Current Session Role", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                            Text(activeOrg.currentRole.label, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = FluxCyanLive)
                        }

                        Button(
                            onClick = onToggleEnvironment,
                            colors = ButtonDefaults.buttonColors(containerColor = FluxNavy700),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Toggle Env (${if (activeOrg.activeEnvironment == EnvironmentType.TEST) "Prod" else "Test"})", fontSize = 11.sp, color = FluxCyanLive)
                        }
                    }
                }
            }
        }

        // Cross-Tenant Security Audit Card
        item {
            Surface(
                color = FluxNavy850,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cross-Tenant Isolation Enforcement", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "FluxCloud enforces zero cross-tenant leakage. Test an unauthenticated or cross-boundary resource query against another organisation to verify that the security boundary returns HTTP 403 Forbidden.",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = FluxTextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onRunSecurityAudit,
                        colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("execute_security_audit_button")
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Execute Cross-Tenant Penetration Test", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Role-Based Access Control (RBAC) Matrix
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ROLE-BASED ACCESS CONTROL (RBAC) MATRIX", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    Spacer(modifier = Modifier.height(10.dp))

                    val roles = listOf(
                        Triple("Owner", "Full compute, billing, members, and keys", "YES"),
                        Triple("Administrator", "Full compute, billing, and API keys", "YES"),
                        Triple("Developer", "Provision compute, submit workloads, API keys", "READ/WRITE"),
                        Triple("Finance Manager", "Ledger, billing top-up, invoices, limits", "BILLING ONLY"),
                        Triple("Read-Only Analyst", "Telemetry, logs, usage reports", "AUDIT ONLY")
                    )

                    roles.forEach { (role, scope, perm) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(role, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text(scope, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                            }
                            StatusBadge(text = perm, color = FluxCyanLive)
                        }
                        HorizontalDivider(color = FluxBorderSubtle.copy(alpha = 0.5f))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
