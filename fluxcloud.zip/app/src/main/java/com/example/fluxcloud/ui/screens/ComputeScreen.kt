package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun ComputeScreen(
    instances: List<ComputeInstance>,
    products: List<ComputeProduct>,
    activeOrg: Organisation,
    onStartInstance: (String) -> Unit,
    onStopInstance: (String) -> Unit,
    onTerminateInstance: (String) -> Unit,
    onOpenProvisionDialog: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top action bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COMPUTE INSTANCES",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Isolated Linux container instances with metered capacity.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FluxTextSecondary
                    )
                }

                Button(
                    onClick = onOpenProvisionDialog,
                    colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("provision_instance_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Provision", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Instance Classes Catalogue Banner
        item {
            Text(
                text = "AVAILABLE INSTANCE CLASSES",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = FluxCyanLive
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(products.filter { !it.isGpu }) { prod ->
                    Surface(
                        color = FluxNavy800,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, FluxBorderSubtle),
                        modifier = Modifier.width(180.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(prod.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text("${prod.vCpu} vCPU • ${prod.ramGb} GB RAM", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxCyanLive)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${formatCurrency(prod.hourlyRateUsd)} / hr",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = FluxGreenSuccess
                            )
                            Text(
                                text = if (prod.isDedicatedCpu) "Dedicated CPU" else "Shared Burstable",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = FluxTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Instances list header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PROVISIONED NODES (${instances.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
        }

        if (instances.isEmpty()) {
            item {
                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Dns, contentDescription = null, tint = FluxTextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No compute instances in ${activeOrg.name}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text("Launch a new compute node to begin running services.", style = MaterialTheme.typography.bodyMedium, color = FluxTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onOpenProvisionDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary)
                        ) {
                            Text("Provision Instance Now")
                        }
                    }
                }
            }
        } else {
            items(instances) { inst ->
                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (inst.status == InstanceStatus.RUNNING) FluxBorderActive else FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Title row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Dns, contentDescription = null, tint = FluxBluePrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(inst.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                    Text("ID: ${inst.id} • ${inst.provider}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                }
                            }
                            StatusBadge(
                                text = inst.status.label,
                                color = when (inst.status) {
                                    InstanceStatus.RUNNING -> FluxGreenSuccess
                                    InstanceStatus.STOPPED -> FluxAmberWarning
                                    InstanceStatus.TERMINATED -> FluxRedDanger
                                    else -> FluxCyanLive
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Specs & Network details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("TYPE / REGION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                Text("${inst.instanceType} (${inst.region})", style = MaterialTheme.typography.bodyMedium, color = FluxTextPrimary)
                            }
                            Column {
                                Text("IP ASSIGNMENT", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                Text("${inst.publicIp} (pub) / ${inst.privateIp}", style = MaterialTheme.typography.bodyMedium, color = FluxCyanLive)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Telemetry meters (if running)
                        if (inst.status == InstanceStatus.RUNNING) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("CPU", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                        Text("${String.format("%.1f", inst.cpuUsagePercent)}%", style = MaterialTheme.typography.labelSmall, color = FluxCyanLive)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { (inst.cpuUsagePercent / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = FluxCyanLive,
                                        trackColor = FluxNavy900
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("RAM", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                        Text("${String.format("%.1f", inst.memUsagePercent)}%", style = MaterialTheme.typography.labelSmall, color = FluxPurpleCompute)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { (inst.memUsagePercent / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = FluxPurpleCompute,
                                        trackColor = FluxNavy900
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = FluxBorderSubtle)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Financial cost & Action buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("METERED CHARGE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                                Text(
                                    text = formatCurrency(inst.totalCostSoFar),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = FluxGreenSuccess
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (inst.status == InstanceStatus.RUNNING) {
                                    OutlinedButton(
                                        onClick = { onStopInstance(inst.id) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        border = BorderStroke(1.dp, FluxBorderActive)
                                    ) {
                                        Icon(Icons.Default.Pause, contentDescription = null, tint = FluxAmberWarning, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Stop", fontSize = 11.sp, color = FluxAmberWarning)
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = { onStartInstance(inst.id) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        border = BorderStroke(1.dp, FluxBorderActive)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = FluxGreenSuccess, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Start", fontSize = 11.sp, color = FluxGreenSuccess)
                                    }
                                }

                                Button(
                                    onClick = { onTerminateInstance(inst.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FluxRedDanger.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = FluxRedDanger, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Terminate", fontSize = 11.sp, color = FluxRedDanger)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
