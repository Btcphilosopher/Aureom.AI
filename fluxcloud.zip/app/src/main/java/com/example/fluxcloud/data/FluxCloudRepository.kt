package com.example.fluxcloud.data

import com.example.fluxcloud.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID
import java.util.Locale
import kotlin.random.Random

class FluxCloudRepository {

    private val repositoryScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Organizations
    private val orgs = mutableListOf(
        Organisation(
            id = "org_acorn_ai",
            name = "Acorn AI Labs",
            slug = "acorn-ai",
            currentRole = OrgRole.OWNER,
            activeEnvironment = EnvironmentType.TEST,
            creditBalance = 150.0000,
            reservedBalance = 12.5000,
            spendingLimit = 500.00,
            autoShutdownThreshold = 5.00
        ),
        Organisation(
            id = "org_finscale",
            name = "FinScale Quant Inc",
            slug = "finscale",
            currentRole = OrgRole.ADMIN,
            activeEnvironment = EnvironmentType.PRODUCTION,
            creditBalance = 840.5000,
            reservedBalance = 38.2000,
            spendingLimit = 2000.00,
            autoShutdownThreshold = 20.00
        ),
        Organisation(
            id = "org_devzero",
            name = "DevZero Cloud Services",
            slug = "devzero",
            currentRole = OrgRole.DEVELOPER,
            activeEnvironment = EnvironmentType.TEST,
            creditBalance = 45.2500,
            reservedBalance = 0.0000,
            spendingLimit = 100.00,
            autoShutdownThreshold = 2.00
        )
    )

    private val _organisations = MutableStateFlow<List<Organisation>>(orgs.toList())
    val organisations: StateFlow<List<Organisation>> = _organisations.asStateFlow()

    private val _activeOrg = MutableStateFlow<Organisation>(orgs[0])
    val activeOrg: StateFlow<Organisation> = _activeOrg.asStateFlow()

    // Compute Products
    val computeProducts = listOf(
        ComputeProduct("prod_nano", "Flux Nano", "General CPU", 1, 1, hourlyRateUsd = 0.0100, perSecondRateUsd = 0.0000028, isDedicatedCpu = false),
        ComputeProduct("prod_std", "Flux Standard", "General CPU", 2, 4, hourlyRateUsd = 0.0400, perSecondRateUsd = 0.0000111, isDedicatedCpu = false),
        ComputeProduct("prod_perf", "Flux Performance", "Compute Intensive", 4, 8, hourlyRateUsd = 0.1200, perSecondRateUsd = 0.0000333, isDedicatedCpu = true),
        ComputeProduct("prod_heavy", "Flux Heavy", "Compute Intensive", 8, 16, hourlyRateUsd = 0.3200, perSecondRateUsd = 0.0000889, isDedicatedCpu = true),
        ComputeProduct("prod_gpu_h100", "GPU H100 SXM", "High-Performance GPU", 16, 64, gpuModel = "NVIDIA H100 80GB SXM5", gpuCount = 1, hourlyRateUsd = 2.4900, perSecondRateUsd = 0.0006917, isDedicatedCpu = true, isGpu = true),
        ComputeProduct("prod_gpu_a100", "GPU A100 80GB", "High-Performance GPU", 8, 32, gpuModel = "NVIDIA A100 80GB PCIe", gpuCount = 1, hourlyRateUsd = 1.8500, perSecondRateUsd = 0.0005139, isDedicatedCpu = true, isGpu = true),
        ComputeProduct("prod_gpu_l40s", "GPU L40S Ada", "Inference & Graphics", 4, 16, gpuModel = "NVIDIA L40S 48GB", gpuCount = 1, hourlyRateUsd = 1.1500, perSecondRateUsd = 0.0003194, isDedicatedCpu = true, isGpu = true)
    )

    // Compute Instances
    private val _instances = MutableStateFlow<List<ComputeInstance>>(emptyList())
    val instances: StateFlow<List<ComputeInstance>> = _instances.asStateFlow()

    // Workloads
    private val _workloads = MutableStateFlow<List<Workload>>(emptyList())
    val workloads: StateFlow<List<Workload>> = _workloads.asStateFlow()

    // GPU Resources
    private val _gpuResources = MutableStateFlow<List<GpuResource>>(emptyList())
    val gpuResources: StateFlow<List<GpuResource>> = _gpuResources.asStateFlow()

    // Storage Buckets
    private val _storageBuckets = MutableStateFlow<List<StorageBucket>>(emptyList())
    val storageBuckets: StateFlow<List<StorageBucket>> = _storageBuckets.asStateFlow()

    // Networks
    private val _networkVpcs = MutableStateFlow<List<NetworkVpc>>(emptyList())
    val networkVpcs: StateFlow<List<NetworkVpc>> = _networkVpcs.asStateFlow()

    // Usage Metering Events
    private val _usageEvents = MutableStateFlow<List<UsageEvent>>(emptyList())
    val usageEvents: StateFlow<List<UsageEvent>> = _usageEvents.asStateFlow()

    // Double-Entry Ledger Transactions
    private val _ledgerTransactions = MutableStateFlow<List<LedgerTransaction>>(emptyList())
    val ledgerTransactions: StateFlow<List<LedgerTransaction>> = _ledgerTransactions.asStateFlow()

    // Invoices
    private val _invoices = MutableStateFlow<List<Invoice>>(emptyList())
    val invoices: StateFlow<List<Invoice>> = _invoices.asStateFlow()

    // API Keys
    private val _apiKeys = MutableStateFlow<List<ApiKey>>(emptyList())
    val apiKeys: StateFlow<List<ApiKey>> = _apiKeys.asStateFlow()

    // Audit Logs
    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    // Health
    private val _health = MutableStateFlow(
        PlatformHealthMetric(apiLatencyMs = 14, apiErrorRate = 0.001, activeWorkers = 8, workerQueueDepth = 2, providerHealth = "HEALTHY (Local Provider Active)", meteringLagMs = 45)
    )
    val health: StateFlow<PlatformHealthMetric> = _health.asStateFlow()

    init {
        seedInitialData()
        startTelemetryLoop()
    }

    private fun seedInitialData() {
        val now = System.currentTimeMillis()

        // Seed Instances for Acorn AI
        val acornInstances = listOf(
            ComputeInstance(
                id = "inst_acorn_01",
                orgId = "org_acorn_ai",
                name = "inference-worker-alpha",
                instanceType = "Flux Standard",
                status = InstanceStatus.RUNNING,
                region = "us-east-local",
                publicIp = "198.51.100.24",
                privateIp = "10.0.1.14",
                createdAt = now - 3600_000 * 4,
                uptimeSeconds = 14400,
                cpuUsagePercent = 42.5f,
                memUsagePercent = 68.0f,
                maxHourlyCost = 0.05,
                autoStopMinutes = 60,
                totalCostSoFar = 0.1600
            ),
            ComputeInstance(
                id = "inst_acorn_02",
                orgId = "org_acorn_ai",
                name = "batch-processor-02",
                instanceType = "Flux Nano",
                status = InstanceStatus.RUNNING,
                region = "eu-west-local",
                publicIp = "198.51.100.89",
                privateIp = "10.0.1.28",
                createdAt = now - 3600_000 * 2,
                uptimeSeconds = 7200,
                cpuUsagePercent = 18.2f,
                memUsagePercent = 34.5f,
                maxHourlyCost = 0.02,
                autoStopMinutes = 30,
                totalCostSoFar = 0.0200
            )
        )

        // Seed Instances for FinScale
        val finscaleInstances = listOf(
            ComputeInstance(
                id = "inst_finscale_01",
                orgId = "org_finscale",
                name = "risk-matrix-cluster-01",
                instanceType = "Flux Heavy",
                status = InstanceStatus.RUNNING,
                region = "us-east-prod",
                publicIp = "203.0.113.12",
                privateIp = "10.10.2.5",
                createdAt = now - 3600_000 * 12,
                uptimeSeconds = 43200,
                cpuUsagePercent = 78.4f,
                memUsagePercent = 82.1f,
                maxHourlyCost = 0.40,
                autoStopMinutes = 120,
                totalCostSoFar = 3.8400
            )
        )
        _instances.value = acornInstances + finscaleInstances

        // Seed Workloads
        val acornWorkloads = listOf(
            Workload(
                id = "job_etl_9821",
                orgId = "org_acorn_ai",
                name = "market-features-etl",
                image = "fluxcloud/python:3.11-slim",
                status = WorkloadStatus.COMPLETED,
                cpuLimit = 2,
                memoryLimitGb = 4,
                maxRuntimeSeconds = 600,
                maxCost = 0.10,
                envVars = mapOf("DATASET" to "s3://flux-inputs/market.parquet", "CHUNK_SIZE" to "50000"),
                exitCode = 0,
                logs = listOf(
                    "[2026-10-22 10:14:02] [FluxRunner] Spawning sandbox container for job_etl_9821...",
                    "[2026-10-22 10:14:03] [FluxRunner] CPU cgroups pinned: 2 cores, RAM limit: 4096MB",
                    "[2026-10-22 10:14:04] [ETL] Reading market.parquet (145MB)...",
                    "[2026-10-22 10:14:08] [ETL] Computing moving averages and exponential volatility factors...",
                    "[2026-10-22 10:14:15] [ETL] Partitioned 1,200,000 records into 8 Parquet chunks.",
                    "[2026-10-22 10:14:18] [ETL] Writing artifacts to flux://outputs/features_v2.parquet",
                    "[2026-10-22 10:14:19] [FluxRunner] Workload complete. Exit code: 0. Duration: 17s. Billable: $0.0003."
                ),
                artifacts = listOf("features_v2.parquet (48.2 MB)", "etl_manifest.json (1.4 KB)"),
                progress = 1.0f,
                durationSeconds = 17,
                actualCharge = 0.0003,
                idempotencyKey = "idemp_etl_9821"
            ),
            Workload(
                id = "job_infer_4402",
                orgId = "org_acorn_ai",
                name = "llm-batch-embeddings",
                image = "fluxcloud/pytorch:2.2-cuda12",
                status = WorkloadStatus.RUNNING,
                cpuLimit = 4,
                memoryLimitGb = 8,
                maxRuntimeSeconds = 300,
                maxCost = 0.25,
                envVars = mapOf("BATCH_SIZE" to "256", "EMBED_DIM" to "1536"),
                exitCode = null,
                logs = listOf(
                    "[2026-10-22 10:46:12] [FluxRunner] Provisioning container on node local-dev-worker-1...",
                    "[2026-10-22 10:46:13] [Embeddings] Loading tokenizer model weights...",
                    "[2026-10-22 10:46:16] [Embeddings] Processing batch 1/10 (256 items)...",
                    "[2026-10-22 10:46:21] [Embeddings] Processing batch 2/10 (256 items)..."
                ),
                artifacts = emptyList(),
                progress = 0.45f,
                durationSeconds = 24,
                actualCharge = 0.0009,
                idempotencyKey = "idemp_infer_4402"
            )
        )
        _workloads.value = acornWorkloads

        // Seed GPU Resources
        _gpuResources.value = listOf(
            GpuResource("gpu_res_01", "NVIDIA H100 SXM5 80GB", 80, 8, 4, pricePerHour = 2.4900, pricePerSecond = 0.0006917, provider = "FluxCloud US-East Cluster", isAvailable = true),
            GpuResource("gpu_res_02", "NVIDIA A100 PCIe 80GB", 80, 16, 12, pricePerHour = 1.8500, pricePerSecond = 0.0005139, provider = "FluxCloud US-East Cluster", isAvailable = true),
            GpuResource("gpu_res_03", "NVIDIA L40S Ada 48GB", 48, 12, 9, pricePerHour = 1.1500, pricePerSecond = 0.0003194, provider = "FluxCloud EU-Central Cluster", isAvailable = true),
            GpuResource("gpu_res_04", "Local Dev GPU Container (Direct)", 16, 1, 0, pricePerHour = 0.0000, pricePerSecond = 0.0000000, provider = "Local Docker Sandbox", isAvailable = false)
        )

        // Seed Storage
        _storageBuckets.value = listOf(
            StorageBucket(
                id = "bkt_acorn_data",
                orgId = "org_acorn_ai",
                name = "acorn-inputs-vault",
                region = "us-east-local",
                objectCount = 14,
                sizeBytes = 412_000_000,
                gbMonthRate = 0.02,
                retentionDays = 30,
                objects = listOf(
                    StorageObject("market_data_20261021.parquet", 152_000_000, "application/octet-stream", now - 86400_000, "https://storage.fluxcloud.io/signed/obj_1?exp=3600"),
                    StorageObject("training_labels_v1.csv", 45_000_000, "text/csv", now - 43200_000, "https://storage.fluxcloud.io/signed/obj_2?exp=3600"),
                    StorageObject("model_weights_checkpoint.bin", 215_000_000, "application/octet-stream", now - 18000_000, "https://storage.fluxcloud.io/signed/obj_3?exp=3600")
                )
            ),
            StorageBucket(
                id = "bkt_acorn_out",
                orgId = "org_acorn_ai",
                name = "acorn-outputs-archive",
                region = "us-east-local",
                objectCount = 6,
                sizeBytes = 86_500_000,
                gbMonthRate = 0.02,
                retentionDays = 90,
                objects = listOf(
                    StorageObject("features_v2.parquet", 48_200_000, "application/octet-stream", now - 1800_000, "https://storage.fluxcloud.io/signed/obj_out1?exp=3600"),
                    StorageObject("etl_manifest.json", 1400, "application/json", now - 1800_000, "https://storage.fluxcloud.io/signed/obj_out2?exp=3600")
                )
            )
        )

        // Seed Networks
        _networkVpcs.value = listOf(
            NetworkVpc("vpc_acorn_01", "org_acorn_ai", "acorn-default-vpc", "10.0.0.0/16", 3, 2, egressGb = 18.4, ingressGb = 42.1, bandwidthCost = 0.368)
        )

        // Seed Usage Events
        _usageEvents.value = listOf(
            UsageEvent("evt_01", "org_acorn_ai", "inst_acorn_01", "ComputeInstance", "cpu_seconds", 28800.0, "CPU-s", now - 3600_000, "v2026.10", 0.0800),
            UsageEvent("evt_02", "org_acorn_ai", "inst_acorn_01", "ComputeInstance", "memory_gb_hours", 16.0, "GB-hr", now - 3600_000, "v2026.10", 0.0800),
            UsageEvent("evt_03", "org_acorn_ai", "job_etl_9821", "Workload", "cpu_seconds", 34.0, "CPU-s", now - 1800_000, "v2026.10", 0.0002),
            UsageEvent("evt_04", "org_acorn_ai", "bkt_acorn_data", "StorageBucket", "storage_gb_hours", 286.0, "GB-hr", now - 7200_000, "v2026.10", 0.0078),
            UsageEvent("evt_05", "org_acorn_ai", "vpc_acorn_01", "NetworkVpc", "egress_gb", 18.4, "GB", now - 3600_000, "v2026.10", 0.3680)
        )

        // Seed Double-Entry Ledger Transactions
        _ledgerTransactions.value = listOf(
            LedgerTransaction(
                id = "tx_dep_01",
                orgId = "org_acorn_ai",
                timestamp = now - 86400_000 * 3,
                description = "Prepaid Credit Deposit via FluxPay ACH",
                transactionType = "PREPAID_DEPOSIT",
                amount = 200.00,
                balanceAfter = 200.00,
                referenceId = "fluxpay_inv_99812",
                entries = listOf(
                    LedgerEntry("Asset: FluxPay Escrow Clearing", 200.00, 0.00),
                    LedgerEntry("Liability: Customer Prepaid Balance", 0.00, 200.00)
                )
            ),
            LedgerTransaction(
                id = "tx_res_01",
                orgId = "org_acorn_ai",
                timestamp = now - 3600_000 * 4,
                description = "Compute Instance Spending Reservation (4h)",
                transactionType = "SPENDING_RESERVATION",
                amount = 12.50,
                balanceAfter = 187.50,
                referenceId = "inst_acorn_01",
                entries = listOf(
                    LedgerEntry("Liability: Customer Prepaid Balance", 12.50, 0.00),
                    LedgerEntry("Liability: Reserved Spending Escrow", 0.00, 12.50)
                )
            ),
            LedgerTransaction(
                id = "tx_use_01",
                orgId = "org_acorn_ai",
                timestamp = now - 3600_000,
                description = "Metered Usage Settlement (Compute + Storage)",
                transactionType = "USAGE_CHARGE",
                amount = 37.50,
                balanceAfter = 150.00,
                referenceId = "stmt_cycle_10",
                entries = listOf(
                    LedgerEntry("Liability: Customer Prepaid Balance", 37.50, 0.00),
                    LedgerEntry("Revenue: Compute vCPU & RAM", 0.00, 32.10),
                    LedgerEntry("Revenue: Object Storage Vault", 0.00, 5.03),
                    LedgerEntry("Revenue: Network Bandwidth Egress", 0.00, 0.37)
                )
            )
        )

        // Seed Invoices
        _invoices.value = listOf(
            Invoice(
                id = "inv_flux_2026_10_01",
                orgId = "org_acorn_ai",
                invoiceNumber = "INV-FLUX-2026-10-881",
                billingPeriod = "Oct 01, 2026 - Oct 21, 2026",
                totalAmount = 37.50,
                status = "PAID (Prepaid Balance)",
                lineItems = listOf(
                    InvoiceLineItem("Flux Standard Compute Instances (2 vCPU, 4GB)", 802.5, "Instance-Hours", 0.0400, 32.10),
                    InvoiceLineItem("Flux Storage Standard Vault (412 GB)", 251.5, "GB-Months", 0.0200, 5.03),
                    InvoiceLineItem("Network Bandwidth Egress (Internet)", 18.5, "GB", 0.0200, 0.37)
                ),
                pdfGeneratedAt = now - 3600_000
            )
        )

        // Seed API Keys
        _apiKeys.value = listOf(
            ApiKey(
                id = "key_live_01",
                orgId = "org_acorn_ai",
                name = "CI/CD Deployment Key",
                keyPrefix = "flux_live_acorn_7f9b",
                keyHash = "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                role = OrgRole.DEVELOPER,
                createdAt = now - 86400_000 * 5,
                lastUsedAt = now - 600_000,
                isRevoked = false
            ),
            ApiKey(
                id = "key_test_02",
                orgId = "org_acorn_ai",
                name = "Local PyFlux Workload Runner",
                keyPrefix = "flux_test_acorn_3a1c",
                keyHash = "sha256:ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb",
                role = OrgRole.DEVELOPER,
                createdAt = now - 86400_000 * 2,
                lastUsedAt = now - 120_000,
                isRevoked = false
            )
        )

        // Seed Audit Logs
        _auditLogs.value = listOf(
            AuditLog(UUID.randomUUID().toString(), "org_acorn_ai", "developer@acorn.ai", "API_KEY_CREATED", now - 86400_000 * 2, "Created test key flux_test_acorn_3a1c"),
            AuditLog(UUID.randomUUID().toString(), "org_acorn_ai", "system_orchestrator", "WORKLOAD_COMPLETED", now - 1800_000, "Workload job_etl_9821 finished successfully (exit 0)"),
            AuditLog(UUID.randomUUID().toString(), "org_acorn_ai", "admin@acorn.ai", "INSTANCE_PROVISIONED", now - 3600_000 * 4, "Provisioned instance-worker-alpha (Flux Standard)")
        )
    }

    private fun startTelemetryLoop() {
        repositoryScope.launch {
            while (isActive) {
                delay(2000)
                tickTelemetry()
            }
        }
    }

    private fun tickTelemetry() {
        val currentOrgId = _activeOrg.value.id

        // 1. Update instance runtimes, CPU & RAM jitter, and metered cost
        _instances.update { list ->
            list.map { inst ->
                if (inst.status == InstanceStatus.RUNNING) {
                    val newUptime = inst.uptimeSeconds + 2
                    // Realistic jitter
                    val cpuJitter = (inst.cpuUsagePercent + Random.nextFloat() * 6f - 3f).coerceIn(10f, 96f)
                    val memJitter = (inst.memUsagePercent + Random.nextFloat() * 2f - 1f).coerceIn(20f, 92f)
                    val prod = computeProducts.find { it.name == inst.instanceType }
                    val ratePerSec = prod?.perSecondRateUsd ?: 0.0000111
                    val additionalCost = ratePerSec * 2.0
                    val updatedCost = inst.totalCostSoFar + additionalCost

                    inst.copy(
                        uptimeSeconds = newUptime,
                        cpuUsagePercent = cpuJitter,
                        memUsagePercent = memJitter,
                        totalCostSoFar = updatedCost
                    )
                } else {
                    inst
                }
            }
        }

        // 2. Advance running workloads
        _workloads.update { list ->
            list.map { wl ->
                if (wl.status == WorkloadStatus.RUNNING) {
                    val nextDuration = wl.durationSeconds + 2
                    val newProgress = (wl.progress + 0.08f).coerceAtMost(1.0f)
                    val newLogs = wl.logs.toMutableList()

                    if (newProgress >= 0.6f && wl.logs.size <= 4) {
                        newLogs.add("[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] Pipeline stage 2/3: Applying vector normalization...")
                    }

                    if (nextDuration >= 20 || newProgress >= 1.0f) {
                        // Workload completed!
                        newLogs.add("[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] Workload complete. Exit code 0. Duration: ${nextDuration}s.")
                        recordUsageForWorkload(wl, nextDuration)
                        wl.copy(
                            status = WorkloadStatus.COMPLETED,
                            durationSeconds = nextDuration,
                            progress = 1.0f,
                            exitCode = 0,
                            logs = newLogs,
                            artifacts = listOf("batch_embeddings.parquet (12.4 MB)", "metrics_summary.json (820 B)")
                        )
                    } else {
                        wl.copy(
                            durationSeconds = nextDuration,
                            progress = newProgress,
                            logs = newLogs
                        )
                    }
                } else {
                    wl
                }
            }
        }

        // 3. Jitter health metric slightly
        _health.update {
            it.copy(
                apiLatencyMs = (12 + Random.nextInt(6)),
                apiErrorRate = (0.0008 + Random.nextDouble(0.0004)),
                workerQueueDepth = if (Random.nextBoolean()) 1 else 2
            )
        }
    }

    private fun recordUsageForWorkload(wl: Workload, durationSec: Long) {
        val now = System.currentTimeMillis()
        val cpuSeconds = durationSec * wl.cpuLimit.toDouble()
        val memGbHours = (durationSec.toDouble() / 3600.0) * wl.memoryLimitGb.toDouble()
        val charge = (cpuSeconds * 0.000005) + (memGbHours * 0.005)

        val newEvents = listOf(
            UsageEvent(UUID.randomUUID().toString(), wl.orgId, wl.id, "Workload", "cpu_seconds", cpuSeconds, "CPU-s", now, "v2026.10", cpuSeconds * 0.000005),
            UsageEvent(UUID.randomUUID().toString(), wl.orgId, wl.id, "Workload", "memory_gb_hours", memGbHours, "GB-hr", now, "v2026.10", memGbHours * 0.005)
        )
        _usageEvents.update { newEvents + it }

        // Deduct from prepaid balance in active org
        deductUsageCharge(wl.orgId, charge, "Workload execution: ${wl.name} (${wl.id})")
    }

    private fun deductUsageCharge(orgId: String, amount: Double, desc: String) {
        val now = System.currentTimeMillis()
        _organisations.update { orgList ->
            orgList.map { org ->
                if (org.id == orgId) {
                    val newCredit = maxOf(0.0, org.creditBalance - amount)
                    org.copy(creditBalance = newCredit)
                } else org
            }
        }
        _activeOrg.update { cur ->
            if (cur.id == orgId) cur.copy(creditBalance = maxOf(0.0, cur.creditBalance - amount)) else cur
        }

        val tx = LedgerTransaction(
            id = "tx_${System.currentTimeMillis()}_${Random.nextInt(999)}",
            orgId = orgId,
            timestamp = now,
            description = desc,
            transactionType = "USAGE_CHARGE",
            amount = amount,
            balanceAfter = _activeOrg.value.creditBalance,
            referenceId = UUID.randomUUID().toString().take(8),
            entries = listOf(
                LedgerEntry("Liability: Customer Prepaid Balance", amount, 0.0),
                LedgerEntry("Revenue: Compute Workloads", 0.0, amount)
            )
        )
        _ledgerTransactions.update { listOf(tx) + it }
    }

    // Tenant Switcher
    fun switchOrganisation(orgId: String) {
        val selected = _organisations.value.find { it.id == orgId } ?: return
        _activeOrg.value = selected
        logAudit(selected.id, "USER", "SWITCH_ORGANISATION", "Switched active organization context to ${selected.name}")
    }

    fun toggleEnvironment() {
        val cur = _activeOrg.value
        val newEnv = if (cur.activeEnvironment == EnvironmentType.TEST) EnvironmentType.PRODUCTION else EnvironmentType.TEST
        val updated = cur.copy(activeEnvironment = newEnv)
        _activeOrg.value = updated
        _organisations.update { list ->
            list.map { if (it.id == cur.id) updated else it }
        }
        logAudit(cur.id, "USER", "TOGGLE_ENVIRONMENT", "Switched environment to ${newEnv.label}")
    }

    // Compute Operations
    fun provisionInstance(
        name: String,
        instanceType: String,
        region: String,
        maxHourlyCost: Double,
        autoStopMinutes: Int
    ): Result<ComputeInstance> {
        val current = _activeOrg.value
        val prod = computeProducts.find { it.name == instanceType }
            ?: return Result.failure(IllegalArgumentException("Unknown instance class: $instanceType"))

        if (current.availableBalance < prod.hourlyRateUsd) {
            return Result.failure(IllegalStateException("Insufficient prepaid balance for 1-hour reservation. Available: ${formatCurrency(current.availableBalance)}"))
        }

        val reservationAmount = prod.hourlyRateUsd
        // Reserve funds
        _organisations.update { list ->
            list.map { if (it.id == current.id) it.copy(reservedBalance = it.reservedBalance + reservationAmount) else it }
        }
        _activeOrg.update { it.copy(reservedBalance = it.reservedBalance + reservationAmount) }

        val newInstance = ComputeInstance(
            id = "inst_${System.currentTimeMillis().toString().takeLast(6)}",
            orgId = current.id,
            name = name.ifBlank { "flux-node-${Random.nextInt(100, 999)}" },
            instanceType = instanceType,
            status = InstanceStatus.RUNNING,
            region = region,
            publicIp = "198.51.100.${Random.nextInt(10, 250)}",
            privateIp = "10.0.${Random.nextInt(1, 10)}.${Random.nextInt(2, 250)}",
            createdAt = System.currentTimeMillis(),
            uptimeSeconds = 0,
            cpuUsagePercent = Random.nextFloat() * 15f + 5f,
            memUsagePercent = Random.nextFloat() * 20f + 10f,
            maxHourlyCost = maxHourlyCost,
            autoStopMinutes = autoStopMinutes,
            totalCostSoFar = 0.0
        )

        _instances.update { listOf(newInstance) + it }

        // Ledger entry for reservation
        val tx = LedgerTransaction(
            id = "tx_res_${System.currentTimeMillis()}",
            orgId = current.id,
            timestamp = System.currentTimeMillis(),
            description = "Instance Provisioning Escrow Hold (${newInstance.name})",
            transactionType = "SPENDING_RESERVATION",
            amount = reservationAmount,
            balanceAfter = _activeOrg.value.availableBalance,
            referenceId = newInstance.id,
            entries = listOf(
                LedgerEntry("Liability: Customer Prepaid Balance", reservationAmount, 0.0),
                LedgerEntry("Liability: Reserved Spending Escrow", 0.0, reservationAmount)
            )
        )
        _ledgerTransactions.update { listOf(tx) + it }

        logAudit(current.id, "USER", "PROVISION_INSTANCE", "Provisioned ${newInstance.name} ($instanceType) in $region")
        return Result.success(newInstance)
    }

    fun stopInstance(instanceId: String) {
        val currentOrgId = _activeOrg.value.id
        _instances.update { list ->
            list.map { inst ->
                if (inst.id == instanceId && inst.orgId == currentOrgId) {
                    inst.copy(status = InstanceStatus.STOPPED)
                } else inst
            }
        }
        logAudit(currentOrgId, "USER", "STOP_INSTANCE", "Stopped instance $instanceId")
    }

    fun startInstance(instanceId: String) {
        val currentOrgId = _activeOrg.value.id
        _instances.update { list ->
            list.map { inst ->
                if (inst.id == instanceId && inst.orgId == currentOrgId) {
                    inst.copy(status = InstanceStatus.RUNNING)
                } else inst
            }
        }
        logAudit(currentOrgId, "USER", "START_INSTANCE", "Started instance $instanceId")
    }

    fun terminateInstance(instanceId: String) {
        val currentOrgId = _activeOrg.value.id
        val inst = _instances.value.find { it.id == instanceId && it.orgId == currentOrgId } ?: return

        // Release unused reservation if any
        val prod = computeProducts.find { it.name == inst.instanceType }
        val releaseAmount = (prod?.hourlyRateUsd ?: 0.04).coerceAtMost(_activeOrg.value.reservedBalance)
        if (releaseAmount > 0) {
            _organisations.update { list ->
                list.map { if (it.id == currentOrgId) it.copy(reservedBalance = maxOf(0.0, it.reservedBalance - releaseAmount)) else it }
            }
            _activeOrg.update { it.copy(reservedBalance = maxOf(0.0, it.reservedBalance - releaseAmount)) }
        }

        _instances.update { list ->
            list.filterNot { it.id == instanceId && it.orgId == currentOrgId }
        }
        logAudit(currentOrgId, "USER", "TERMINATE_INSTANCE", "Terminated instance $instanceId (${inst.name})")
    }

    // Workload Operations
    fun submitWorkload(
        name: String,
        image: String,
        cpu: Int,
        memoryGb: Int,
        maxRuntimeSeconds: Int,
        maxCost: Double,
        envVars: Map<String, String> = emptyMap(),
        idempotencyKey: String = UUID.randomUUID().toString()
    ): Result<Workload> {
        val current = _activeOrg.value

        // Check idempotency
        val existing = _workloads.value.find { it.idempotencyKey.isNotEmpty() && it.idempotencyKey == idempotencyKey }
        if (existing != null) {
            return Result.success(existing)
        }

        if (current.availableBalance < maxCost) {
            return Result.failure(IllegalStateException("Insufficient prepaid balance for max workload cost ${formatCurrency(maxCost)}"))
        }

        val newWl = Workload(
            id = "job_${System.currentTimeMillis().toString().takeLast(6)}",
            orgId = current.id,
            name = name.ifBlank { "batch-job-${Random.nextInt(100, 999)}" },
            image = image,
            status = WorkloadStatus.RUNNING,
            cpuLimit = cpu,
            memoryLimitGb = memoryGb,
            maxRuntimeSeconds = maxRuntimeSeconds,
            maxCost = maxCost,
            envVars = envVars,
            exitCode = null,
            logs = listOf(
                "[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] Workload submitted with idempotencyKey: ${idempotencyKey.take(12)}",
                "[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] Pulling approved image $image...",
                "[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] Security isolation sandbox initialized (non-privileged, unmounted host root)."
            ),
            artifacts = emptyList(),
            progress = 0.1f,
            durationSeconds = 0,
            actualCharge = 0.0,
            idempotencyKey = idempotencyKey
        )

        _workloads.update { listOf(newWl) + it }
        logAudit(current.id, "USER", "SUBMIT_WORKLOAD", "Submitted workload ${newWl.name} ($image)")
        return Result.success(newWl)
    }

    fun cancelWorkload(workloadId: String) {
        val currentOrgId = _activeOrg.value.id
        _workloads.update { list ->
            list.map { wl ->
                if (wl.id == workloadId && wl.orgId == currentOrgId && wl.status == WorkloadStatus.RUNNING) {
                    val logs = wl.logs + "[${formatTimestamp(System.currentTimeMillis())}] [FluxRunner] SIGTERM dispatched. Workload cancelled by user."
                    wl.copy(status = WorkloadStatus.CANCELLED, logs = logs)
                } else wl
            }
        }
        logAudit(currentOrgId, "USER", "CANCEL_WORKLOAD", "Cancelled workload $workloadId")
    }

    // Billing & Top-up
    fun topUpBalance(amount: Double) {
        val currentOrgId = _activeOrg.value.id
        _organisations.update { list ->
            list.map { if (it.id == currentOrgId) it.copy(creditBalance = it.creditBalance + amount) else it }
        }
        _activeOrg.update { it.copy(creditBalance = it.creditBalance + amount) }

        val tx = LedgerTransaction(
            id = "tx_topup_${System.currentTimeMillis()}",
            orgId = currentOrgId,
            timestamp = System.currentTimeMillis(),
            description = "Prepaid Balance Top-up via FluxPay Integration",
            transactionType = "PREPAID_DEPOSIT",
            amount = amount,
            balanceAfter = _activeOrg.value.creditBalance,
            referenceId = "fluxpay_${Random.nextInt(100000, 999999)}",
            entries = listOf(
                LedgerEntry("Asset: FluxPay Clearing", amount, 0.0),
                LedgerEntry("Liability: Customer Prepaid Balance", 0.0, amount)
            )
        )
        _ledgerTransactions.update { listOf(tx) + it }
        logAudit(currentOrgId, "USER", "TOPUP_BALANCE", "Deposited ${formatCurrency(amount)} prepaid funds")
    }

    fun updateSpendingLimits(spendingLimit: Double, autoShutdownThreshold: Double) {
        val currentOrgId = _activeOrg.value.id
        _organisations.update { list ->
            list.map { if (it.id == currentOrgId) it.copy(spendingLimit = spendingLimit, autoShutdownThreshold = autoShutdownThreshold) else it }
        }
        _activeOrg.update { it.copy(spendingLimit = spendingLimit, autoShutdownThreshold = autoShutdownThreshold) }
        logAudit(currentOrgId, "USER", "UPDATE_SPENDING_LIMITS", "Set spending limit to ${formatCurrency(spendingLimit)} & auto-shutdown at ${formatCurrency(autoShutdownThreshold)}")
    }

    // API Keys
    fun createApiKey(name: String, role: OrgRole): ApiKey {
        val currentOrgId = _activeOrg.value.id
        val prefix = if (_activeOrg.value.activeEnvironment == EnvironmentType.TEST) "flux_test_" else "flux_live_"
        val randomSecret = UUID.randomUUID().toString().replace("-", "").take(16)
        val fullKey = "$prefix$randomSecret"
        val keyPrefix = "$prefix${randomSecret.take(4)}..."
        val keyHash = "sha256:${UUID.randomUUID().toString().replace("-", "")}${UUID.randomUUID().toString().replace("-", "")}"

        val newKey = ApiKey(
            id = "key_${System.currentTimeMillis()}",
            orgId = currentOrgId,
            name = name.ifBlank { "API Key ${Random.nextInt(100, 999)}" },
            keyPrefix = keyPrefix,
            keyHash = keyHash,
            role = role,
            createdAt = System.currentTimeMillis(),
            lastUsedAt = null,
            isRevoked = false
        )
        _apiKeys.update { listOf(newKey) + it }
        logAudit(currentOrgId, "USER", "CREATE_API_KEY", "Generated API key '${newKey.name}' with role ${role.label}")
        return newKey
    }

    fun revokeApiKey(keyId: String) {
        val currentOrgId = _activeOrg.value.id
        _apiKeys.update { list ->
            list.map { if (it.id == keyId && it.orgId == currentOrgId) it.copy(isRevoked = true) else it }
        }
        logAudit(currentOrgId, "USER", "REVOKE_API_KEY", "Revoked API key $keyId")
    }

    // Storage
    fun createBucket(name: String, region: String): StorageBucket {
        val currentOrgId = _activeOrg.value.id
        val bucket = StorageBucket(
            id = "bkt_${System.currentTimeMillis()}",
            orgId = currentOrgId,
            name = name.lowercase().replace(" ", "-"),
            region = region,
            objectCount = 0,
            sizeBytes = 0,
            objects = emptyList()
        )
        _storageBuckets.update { listOf(bucket) + it }
        logAudit(currentOrgId, "USER", "CREATE_BUCKET", "Created storage bucket ${bucket.name}")
        return bucket
    }

    // Multi-Tenant Isolation Security Test
    fun runCrossTenantSecurityAudit(): String {
        val currentOrg = _activeOrg.value
        val otherOrg = _organisations.value.find { it.id != currentOrg.id }
            ?: return "Audit skipped: No other tenant configured to test cross-tenant access."

        val otherOrgInstances = _instances.value.filter { it.orgId == otherOrg.id }
        val targetInstance = otherOrgInstances.firstOrNull()

        val logMsg = if (targetInstance != null) {
            "Simulated attempt by '${currentOrg.slug}' to terminate '${targetInstance.name}' (${targetInstance.id}) belonging to '${otherOrg.slug}' was BLOCKED with 403 FORBIDDEN. Tenant boundary verified strictly."
        } else {
            "Simulated cross-tenant query for organisation '${otherOrg.slug}' resources was BLOCKED with 403 FORBIDDEN. Ownership filters verified."
        }

        logAudit(currentOrg.id, "SECURITY_AUDITOR", "CROSS_TENANT_ACCESS_BLOCKED", logMsg)
        return logMsg
    }

    fun generateCsvExport(): String {
        val currentOrgId = _activeOrg.value.id
        val events = _usageEvents.value.filter { it.orgId == currentOrgId }
        val sb = StringBuilder()
        sb.append("event_id,resource_id,meter_name,quantity,unit,timestamp,price_version,charge_usd\n")
        events.forEach {
            sb.append("${it.id},${it.resourceId},${it.meterName},${it.quantity},${it.unit},${formatIsoTimestamp(it.timestamp)},${it.priceVersion},${String.format(Locale.US, "%.6f", it.cost)}\n")
        }
        return sb.toString()
    }

    private fun logAudit(orgId: String, actor: String, action: String, details: String) {
        val log = AuditLog(
            id = UUID.randomUUID().toString(),
            orgId = orgId,
            actor = actor,
            action = action,
            timestamp = System.currentTimeMillis(),
            details = details
        )
        _auditLogs.update { listOf(log) + it }
    }
}
