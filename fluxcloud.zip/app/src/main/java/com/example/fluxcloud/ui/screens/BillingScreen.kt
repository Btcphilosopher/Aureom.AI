package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.theme.*

@Composable
fun BillingScreen(
    activeOrg: Organisation,
    ledgerTransactions: List<LedgerTransaction>,
    invoices: List<Invoice>,
    onTopUpClick: () -> Unit,
    onSelectInvoice: (Invoice) -> Unit,
    onUpdateSpendingLimits: (Double, Double) -> Unit
) {
    var showLimitsDialog by remember { mutableStateOf(false) }
    var spendingLimitText by remember { mutableStateOf(activeOrg.spendingLimit.toString()) }
    var autoShutdownText by remember { mutableStateOf(activeOrg.autoShutdownThreshold.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BILLING & LEDGER",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "FluxBilling double-entry accounting engine & FluxPay settlement.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FluxTextSecondary
                    )
                }

                Button(
                    onClick = onTopUpClick,
                    colors = ButtonDefaults.buttonColors(containerColor = FluxGreenSuccess),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("top_up_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Top Up", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Account Balances Card
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PREPAID ACCOUNT BALANCES", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = FluxTextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = formatCurrency2(activeOrg.availableBalance),
                                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                                color = FluxGreenSuccess
                            )
                            Text("Available to Spend", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), color = FluxTextSecondary)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Total Credit: ${formatCurrency2(activeOrg.creditBalance)}",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White
                            )
                            Text(
                                text = "Reserved Escrow: ${formatCurrency2(activeOrg.reservedBalance)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = FluxAmberWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Controls summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Hard Spending Cap: ${formatCurrency2(activeOrg.spendingLimit)}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxTextSecondary)
                            Text("Auto-Shutdown Threshold: ${formatCurrency2(activeOrg.autoShutdownThreshold)}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxAmberWarning)
                        }

                        TextButton(onClick = { showLimitsDialog = true }) {
                            Text("Adjust Limits", fontSize = 11.sp, color = FluxCyanLive)
                        }
                    }
                }
            }
        }

        // Invoices Section
        item {
            Text(
                text = "INVOICES & STATEMENTS (${invoices.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(invoices) { inv ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectInvoice(inv) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(inv.invoiceNumber, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        }
                        Text(inv.billingPeriod, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxTextSecondary)
                        Text(inv.status, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxGreenSuccess)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(formatCurrency2(inv.totalAmount), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text("View Itemized PDF >", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxCyanLive)
                    }
                }
            }
        }

        // Double-entry accounting ledger section
        item {
            Text(
                text = "IMMUTABLE DOUBLE-ENTRY LEDGER JOURNAL (${ledgerTransactions.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(ledgerTransactions) { tx ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(tx.description, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text("TX: ${tx.id} • ${formatTimestamp(tx.timestamp)}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                        }

                        Text(
                            text = formatCurrency(tx.amount),
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = when (tx.transactionType) {
                                "PREPAID_DEPOSIT" -> FluxGreenSuccess
                                "SPENDING_RESERVATION" -> FluxAmberWarning
                                else -> FluxCyanLive
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(6.dp))

                    Text("POSTED JOURNAL ENTRIES:", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold), color = FluxTextMuted)
                    Spacer(modifier = Modifier.height(4.dp))

                    tx.entries.forEach { entry ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = entry.accountName,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                                color = FluxTextSecondary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                if (entry.debit > 0) {
                                    Text("DR: ${formatCurrency(entry.debit)}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp), color = FluxCyanLive)
                                }
                                if (entry.credit > 0) {
                                    Text("CR: ${formatCurrency(entry.credit)}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp), color = FluxPurpleCompute)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }

    if (showLimitsDialog) {
        AlertDialog(
            onDismissRequest = { showLimitsDialog = false },
            title = { Text("Configure Spending Limits & Auto-Stop") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = spendingLimitText,
                        onValueChange = { spendingLimitText = it },
                        label = { Text("Max Monthly Budget ($)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = autoShutdownText,
                        onValueChange = { autoShutdownText = it },
                        label = { Text("Auto-Shutdown Threshold ($)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val limit = spendingLimitText.toDoubleOrNull() ?: activeOrg.spendingLimit
                        val thresh = autoShutdownText.toDoubleOrNull() ?: activeOrg.autoShutdownThreshold
                        onUpdateSpendingLimits(limit, thresh)
                        showLimitsDialog = false
                    }
                ) {
                    Text("Save Limits")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLimitsDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
