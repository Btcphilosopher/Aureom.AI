package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun DevelopersScreen(
    apiKeys: List<ApiKey>,
    activeOrg: Organisation,
    onCreateApiKeyClick: () -> Unit,
    onRevokeApiKey: (String) -> Unit
) {
    var selectedEndpoint by remember { mutableStateOf("POST /api/v1/compute/instances") }
    var simulatedResponse by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "API & DEVELOPERS",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "API credentials, interactive OpenAPI client, and Python SDK integration.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FluxTextSecondary
                    )
                }

                Button(
                    onClick = onCreateApiKeyClick,
                    colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("create_api_key_btn")
                ) {
                    Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Key", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // API Keys List
        item {
            Text(
                text = "ORGANISATION API KEYS (${apiKeys.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(apiKeys) { key ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, if (key.isRevoked) FluxBorderSubtle else FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(key.name, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusBadge(
                                text = if (key.isRevoked) "REVOKED" else key.role.label.uppercase(),
                                color = if (key.isRevoked) FluxRedDanger else FluxCyanLive
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Key: ${key.keyPrefix}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                            color = FluxCyanLive
                        )
                        Text(
                            text = "Hash: ${key.keyHash.take(28)}...",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 9.sp),
                            color = FluxTextMuted
                        )
                    }

                    if (!key.isRevoked) {
                        OutlinedButton(
                            onClick = { onRevokeApiKey(key.id) },
                            border = BorderStroke(1.dp, FluxRedDanger.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Revoke", fontSize = 11.sp, color = FluxRedDanger)
                        }
                    }
                }
            }
        }

        // Interactive API Request & Response Explorer
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("INTERACTIVE API EXPLORER", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    Text("Test real versioned REST endpoints against the FluxCloud API engine.", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxTextSecondary)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Endpoints Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedEndpoint.startsWith("POST /api/v1/compute"),
                            onClick = {
                                selectedEndpoint = "POST /api/v1/compute/instances"
                                simulatedResponse = null
                            },
                            label = { Text("POST /instances", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FluxNavy700, selectedLabelColor = FluxCyanLive)
                        )
                        FilterChip(
                            selected = selectedEndpoint.startsWith("POST /api/v1/workloads"),
                            onClick = {
                                selectedEndpoint = "POST /api/v1/workloads"
                                simulatedResponse = null
                            },
                            label = { Text("POST /workloads", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FluxNavy700, selectedLabelColor = FluxCyanLive)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = FluxTerminalBg,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (selectedEndpoint.contains("compute")) {
                                """curl -X POST "https://api.fluxcloud.io/v1/compute/instances" \
  -H "Authorization: Bearer ${apiKeys.firstOrNull()?.keyPrefix ?: "flux_live_..."}" \
  -H "Content-Type: application/json" \
  -d '{"name": "worker-prod-1", "instance_type": "flux-standard", "region": "local"}'"""
                            } else {
                                """curl -X POST "https://api.fluxcloud.io/v1/workloads" \
  -H "Authorization: Bearer ${apiKeys.firstOrNull()?.keyPrefix ?: "flux_live_..."}" \
  -H "Content-Type: application/json" \
  -d '{"name": "etl-job", "image": "fluxcloud/python:3.11", "cpu": 2, "memory_gb": 4}'"""
                            },
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                            color = FluxTerminalText,
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            simulatedResponse = if (selectedEndpoint.contains("compute")) {
                                """{
  "status": "success",
  "data": {
    "instance_id": "inst_78201",
    "name": "worker-prod-1",
    "status": "RUNNING",
    "public_ip": "198.51.100.92",
    "hourly_rate": 0.0400,
    "metering_state": "ACTIVE"
  }
}"""
                            } else {
                                """{
  "status": "success",
  "data": {
    "workload_id": "job_94102",
    "status": "QUEUED",
    "image": "fluxcloud/python:3.11",
    "isolation_mode": "cgroup_sandbox",
    "idempotency_key": "idemp_5591"
  }
}"""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Execute API Request", fontSize = 11.sp)
                    }

                    if (simulatedResponse != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("HTTP 201 CREATED RESPONSE:", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold), color = FluxGreenSuccess)
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = FluxTerminalBg,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = simulatedResponse!!,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                                color = FluxTerminalSuccess,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Python SDK Quickstart
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PYTHON SDK (fluxcloud)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "pip install fluxcloud",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = FluxGreenSuccess
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = FluxTerminalBg,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = """from fluxcloud import FluxCloudClient

client = FluxCloudClient(
    api_key="${apiKeys.firstOrNull()?.keyPrefix ?: "YOUR_API_KEY"}",
    base_url="https://api.fluxcloud.io/v1"
)

# Launch isolated batch job
job = client.workloads.create(
    name="data-processing-job",
    image="fluxcloud/python:3.11-slim",
    cpu=2,
    memory_gb=4,
    max_cost=0.10,
    idempotency_key="unique_task_001"
)
print(f"Launched: {job.id} Status: {job.status}")""",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                            color = FluxTerminalText,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
