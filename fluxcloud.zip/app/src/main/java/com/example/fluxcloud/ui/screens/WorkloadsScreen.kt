package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.MonospaceTerminalBox
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun WorkloadsScreen(
    workloads: List<Workload>,
    activeOrg: Organisation,
    onSubmitWorkloadClick: () -> Unit,
    onCancelWorkload: (String) -> Unit
) {
    var expandedJobId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CONTAINER WORKLOADS",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Short-lived batch jobs & pipelines executed in isolated sandboxes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FluxTextSecondary
                    )
                }

                Button(
                    onClick = onSubmitWorkloadClick,
                    colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("submit_workload_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Run Job", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Sandbox Security Guarantee Banner
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Isolation Guarantee", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text(
                            "Workloads run in non-privileged cgroup namespaces with strict memory caps, no host mounts, and blocked Docker socket access.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = FluxTextSecondary
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "JOB QUEUE & HISTORY (${workloads.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        if (workloads.isEmpty()) {
            item {
                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = FluxTextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No workloads registered in ${activeOrg.name}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text("Submit an ETL, model inference, or data transformation job.", style = MaterialTheme.typography.bodyMedium, color = FluxTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onSubmitWorkloadClick,
                            colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary)
                        ) {
                            Text("Submit Batch Job")
                        }
                    }
                }
            }
        } else {
            items(workloads) { wl ->
                val isExpanded = expandedJobId == wl.id

                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (wl.status == WorkloadStatus.RUNNING) FluxBorderActive else FluxBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terminal, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(wl.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                    Text("Job ID: ${wl.id} • ${wl.image}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                                }
                            }
                            StatusBadge(
                                text = wl.status.label,
                                color = when (wl.status) {
                                    WorkloadStatus.RUNNING -> FluxCyanLive
                                    WorkloadStatus.COMPLETED -> FluxGreenSuccess
                                    WorkloadStatus.FAILED -> FluxRedDanger
                                    WorkloadStatus.CANCELLED -> FluxAmberWarning
                                    else -> FluxBluePrimary
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Resource allocation & duration
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("ALLOCATION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                                Text("${wl.cpuLimit} vCPU • ${wl.memoryLimitGb} GB RAM", style = MaterialTheme.typography.bodyMedium, color = FluxTextPrimary)
                            }
                            Column {
                                Text("DURATION / MAX", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                                Text("${wl.durationSeconds}s / ${wl.maxRuntimeSeconds}s", style = MaterialTheme.typography.bodyMedium, color = FluxCyanLive)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("METERED COST", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                                Text(formatCurrency(wl.actualCharge), style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxGreenSuccess)
                            }
                        }

                        // Progress bar if running
                        if (wl.status == WorkloadStatus.RUNNING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { wl.progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = FluxCyanLive,
                                trackColor = FluxNavy900
                            )
                        }

                        // Exit code & Artifacts if completed
                        if (wl.exitCode != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Exit Code: ", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                                Text(
                                    text = if (wl.exitCode == 0) "0 (Success)" else "${wl.exitCode} (Failed)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (wl.exitCode == 0) FluxGreenSuccess else FluxRedDanger
                                )
                            }
                        }

                        if (wl.artifacts.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Output Artifacts:", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                            Spacer(modifier = Modifier.height(2.dp))
                            wl.artifacts.forEach { artifact ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.FilePresent, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(artifact, style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), color = FluxCyanLive)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = FluxBorderSubtle)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Expand Logs Toggle & Cancel button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = { expandedJobId = if (isExpanded) null else wl.id },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(
                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = FluxCyanLive,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isExpanded) "Hide Console Logs" else "Inspect Console Logs (${wl.logs.size})",
                                    color = FluxCyanLive,
                                    fontSize = 11.sp
                                )
                            }

                            if (wl.status == WorkloadStatus.RUNNING) {
                                Button(
                                    onClick = { onCancelWorkload(wl.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FluxRedDanger.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = FluxRedDanger, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Cancel Job", fontSize = 11.sp, color = FluxRedDanger)
                                }
                            }
                        }

                        if (isExpanded) {
                            Spacer(modifier = Modifier.height(8.dp))
                            MonospaceTerminalBox(logs = wl.logs)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
