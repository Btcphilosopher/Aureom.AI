package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.theme.*

@Composable
fun MeteringScreen(
    usageEvents: List<UsageEvent>,
    activeOrg: Organisation,
    onExportCsv: () -> Unit
) {
    val totalCost = usageEvents.sumOf { it.cost }
    val cpuSeconds = usageEvents.filter { it.meterName == "cpu_seconds" }.sumOf { it.quantity }
    val memGbHours = usageEvents.filter { it.meterName == "memory_gb_hours" }.sumOf { it.quantity }
    val storageGbHours = usageEvents.filter { it.meterName == "storage_gb_hours" }.sumOf { it.quantity }
    val egressGb = usageEvents.filter { it.meterName == "egress_gb" }.sumOf { it.quantity }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FLUXMETER ENGINE",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Auditable, immutable high-resolution telemetry consumption ledger.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FluxTextSecondary
                    )
                }

                OutlinedButton(
                    onClick = onExportCsv,
                    border = BorderStroke(1.dp, FluxCyanLive),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_csv_btn")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = FluxCyanLive, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export CSV", fontSize = 11.sp, color = FluxCyanLive, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Summary Aggregates Card
        item {
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderActive),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CURRENT CYCLE CONSUMPTION", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = FluxTextMuted)
                        Text("PRICING VER: v2026.10", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = FluxCyanLive)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatCurrency(totalCost),
                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                        color = FluxGreenSuccess
                    )
                    Text("Total Authoritative Recorded Usage Charges", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = FluxTextSecondary)

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(12.dp))

                    // 4-Column Breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CPU TIME", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${String.format("%.1f", cpuSeconds)} s", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxCyanLive)
                        }
                        Column {
                            Text("MEMORY", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${String.format("%.2f", memGbHours)} GB-h", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxPurpleCompute)
                        }
                        Column {
                            Text("STORAGE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${String.format("%.1f", storageGbHours)} GB-h", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("EGRESS", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${String.format("%.1f", egressGb)} GB", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxAmberWarning)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "AUDITABLE USAGE EVENTS STREAM (${usageEvents.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(usageEvents) { evt ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = evt.meterName.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                ),
                                color = FluxCyanLive
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${evt.resourceType}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = FluxTextMuted
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Ref: ${evt.resourceId} • ${formatTimestamp(evt.timestamp)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = FluxTextSecondary
                        )
                        Text(
                            text = "Quantity: ${String.format("%.2f", evt.quantity)} ${evt.unit}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = FluxTextPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = formatCurrency(evt.cost),
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = FluxGreenSuccess
                        )
                        Text(
                            text = evt.priceVersion,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = FluxTextMuted
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
