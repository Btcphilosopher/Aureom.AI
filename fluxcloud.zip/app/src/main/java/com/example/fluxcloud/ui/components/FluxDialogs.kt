package com.example.fluxcloud.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.theme.*

@Composable
fun ProvisionInstanceDialog(
    products: List<ComputeProduct>,
    activeOrg: Organisation,
    onDismiss: () -> Unit,
    onConfirm: (name: String, instanceType: String, region: String, maxCost: Double, autoStopMin: Int) -> Unit
) {
    var name by remember { mutableStateOf("worker-${(100..999).random()}") }
    var selectedProduct by remember { mutableStateOf(products.first { !it.isGpu }) }
    var region by remember { mutableStateOf("us-east-local") }
    var autoStopMinutes by remember { mutableStateOf(60) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Dns, contentDescription = null, tint = FluxBluePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Provision Compute Node", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Instance Name") },
                    modifier = Modifier.fillMaxWidth().testTag("provision_name_input")
                )

                Text("Select Instance Class", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    products.filter { !it.isGpu }.forEach { prod ->
                        Surface(
                            color = if (selectedProduct.id == prod.id) FluxNavy750 else FluxNavy850,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (selectedProduct.id == prod.id) FluxCyanLive else FluxBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedProduct = prod }
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(prod.name, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                    Text("${prod.vCpu} vCPU • ${prod.ramGb} GB RAM", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextSecondary)
                                }
                                Text("${formatCurrency(prod.hourlyRateUsd)}/hr", style = MaterialTheme.typography.labelLarge, color = FluxGreenSuccess)
                            }
                        }
                    }
                }

                Text("Region & Placement", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("us-east-local", "eu-west-local", "ap-south-local").forEach { reg ->
                        FilterChip(
                            selected = region == reg,
                            onClick = { region = reg },
                            label = { Text(reg, fontSize = 10.sp) }
                        )
                    }
                }

                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Hold Escrow: ${formatCurrency(selectedProduct.hourlyRateUsd)} (1-hour buffer)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxAmberWarning)
                        Text("Available funds: ${formatCurrency(activeOrg.availableBalance)}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextSecondary)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(name, selectedProduct.name, region, selectedProduct.hourlyRateUsd * 2, autoStopMinutes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                modifier = Modifier.testTag("confirm_provision_btn")
            ) {
                Text("Provision Node")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SubmitWorkloadDialog(
    activeOrg: Organisation,
    onDismiss: () -> Unit,
    onConfirm: (name: String, image: String, cpu: Int, mem: Int, timeout: Int, maxCost: Double) -> Unit
) {
    val approvedImages = listOf(
        "fluxcloud/python:3.11-slim",
        "fluxcloud/pytorch:2.2-cuda12",
        "fluxcloud/node:20-alpine",
        "fluxcloud/ffmpeg:6.0",
        "fluxcloud/quant-sim:v1"
    )

    var name by remember { mutableStateOf("batch-job-${(100..999).random()}") }
    var selectedImage by remember { mutableStateOf(approvedImages[0]) }
    var cpu by remember { mutableStateOf(2) }
    var memoryGb by remember { mutableStateOf(4) }
    var timeoutSeconds by remember { mutableStateOf(300) }
    var maxCost by remember { mutableStateOf(0.10) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = FluxCyanLive)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Submit Container Workload", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Job Name") },
                    modifier = Modifier.fillMaxWidth().testTag("workload_name_input")
                )

                Text("Approved Container Image", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    approvedImages.forEach { img ->
                        Surface(
                            color = if (selectedImage == img) FluxNavy750 else FluxNavy850,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (selectedImage == img) FluxCyanLive else FluxBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedImage = img }
                        ) {
                            Text(
                                text = img,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                ),
                                color = if (selectedImage == img) FluxCyanLive else FluxTextPrimary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CPU limit: $cpu vCPU", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                        Slider(value = cpu.toFloat(), onValueChange = { cpu = it.toInt() }, valueRange = 1f..8f, steps = 6)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("RAM limit: $memoryGb GB", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                        Slider(value = memoryGb.toFloat(), onValueChange = { memoryGb = it.toInt() }, valueRange = 1f..16f, steps = 14)
                    }
                }

                Surface(
                    color = FluxNavy800,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Max spending cap: ${formatCurrency(maxCost)}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxGreenSuccess)
                        Text("Execution timeout: ${timeoutSeconds}s (SIGKILL upon expiry)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextSecondary)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name, selectedImage, cpu, memoryGb, timeoutSeconds, maxCost) },
                colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary),
                modifier = Modifier.testTag("confirm_submit_workload_btn")
            ) {
                Text("Launch Job")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun TopUpDialog(
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var selectedAmount by remember { mutableStateOf(50.0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Top Up Prepaid Balance (FluxPay)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Select prepaid deposit amount. Settlement is authorized and posted to the double-entry ledger instantly.")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(25.0, 50.0, 100.0, 250.0).forEach { amt ->
                        FilterChip(
                            selected = selectedAmount == amt,
                            onClick = { selectedAmount = amt },
                            label = { Text("$$amt", fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedAmount) },
                colors = ButtonDefaults.buttonColors(containerColor = FluxGreenSuccess),
                modifier = Modifier.testTag("confirm_topup_btn")
            ) {
                Text("Deposit ${formatCurrency2(selectedAmount)}", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateApiKeyDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, role: OrgRole) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(OrgRole.DEVELOPER) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generate API Key") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Key Description / Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Assigned Role & Permissions Scope", style = MaterialTheme.typography.labelSmall, color = FluxTextMuted)
                listOf(OrgRole.DEVELOPER, OrgRole.ADMIN, OrgRole.FINANCE, OrgRole.ANALYST).forEach { role ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedRole = role }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selectedRole == role, onClick = { selectedRole = role })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(role.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name.ifBlank { "API Key" }, selectedRole) },
                colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary)
            ) {
                Text("Generate Key")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateBucketDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, region: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("us-east-local") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create S3-Compatible Storage Vault") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Bucket Name (e.g. models-vault)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Region: $region", style = MaterialTheme.typography.bodyMedium, color = FluxCyanLive)
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name.ifBlank { "vault-${(100..999).random()}" }, region) },
                colors = ButtonDefaults.buttonColors(containerColor = FluxBluePrimary)
            ) {
                Text("Create Vault")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun InvoiceDetailDialog(
    invoice: Invoice,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(invoice.invoiceNumber, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Text("Period: ${invoice.billingPeriod}", style = MaterialTheme.typography.bodyMedium, color = FluxTextMuted)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HorizontalDivider(color = FluxBorderSubtle)
                invoice.lineItems.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.description, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text("${String.format("%.1f", item.quantity)} ${item.unit} @ ${formatCurrency(item.unitPrice)}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                        }
                        Text(formatCurrency2(item.amount), style = MaterialTheme.typography.labelLarge, color = FluxGreenSuccess)
                    }
                    HorizontalDivider(color = FluxBorderSubtle.copy(alpha = 0.5f))
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL SETTLED", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    Text(formatCurrency2(invoice.totalAmount), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = FluxGreenSuccess)
                }
                Text("Settled via ${invoice.status}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxCyanLive)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
