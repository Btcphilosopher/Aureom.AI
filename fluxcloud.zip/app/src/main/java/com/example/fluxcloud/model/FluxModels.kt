package com.example.fluxcloud.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class EnvironmentType(val label: String) {
    TEST("Test"),
    PRODUCTION("Production")
}

enum class OrgRole(val label: String, val canManageBilling: Boolean, val canProvision: Boolean) {
    OWNER("Owner", true, true),
    ADMIN("Administrator", true, true),
    DEVELOPER("Developer", false, true),
    FINANCE("Finance Manager", true, false),
    ANALYST("Read-Only Analyst", false, false)
}

data class Organisation(
    val id: String,
    val name: String,
    val slug: String,
    val currentRole: OrgRole,
    val activeEnvironment: EnvironmentType,
    val creditBalance: Double,
    val reservedBalance: Double,
    val spendingLimit: Double,
    val autoShutdownThreshold: Double
) {
    val availableBalance: Double
        get() = maxOf(0.0, creditBalance - reservedBalance)
}

data class ComputeProduct(
    val id: String,
    val name: String,
    val category: String,
    val vCpu: Int,
    val ramGb: Int,
    val gpuModel: String? = null,
    val gpuCount: Int = 0,
    val hourlyRateUsd: Double,
    val perSecondRateUsd: Double,
    val isDedicatedCpu: Boolean,
    val isGpu: Boolean = false,
    val isAvailable: Boolean = true
)

enum class InstanceStatus(val label: String) {
    REQUESTED("Requested"),
    PROVISIONING("Provisioning"),
    RUNNING("Running"),
    STOPPING("Stopping"),
    STOPPED("Stopped"),
    FAILED("Failed"),
    TERMINATED("Terminated")
}

data class ComputeInstance(
    val id: String,
    val orgId: String,
    val name: String,
    val instanceType: String,
    val status: InstanceStatus,
    val region: String,
    val publicIp: String,
    val privateIp: String,
    val createdAt: Long,
    val uptimeSeconds: Long,
    val cpuUsagePercent: Float,
    val memUsagePercent: Float,
    val maxHourlyCost: Double,
    val autoStopMinutes: Int,
    val totalCostSoFar: Double,
    val provider: String = "FluxEngine Local Container"
)

enum class WorkloadStatus(val label: String) {
    QUEUED("Queued"),
    SCHEDULED("Scheduled"),
    RUNNING("Running"),
    COMPLETED("Completed"),
    FAILED("Failed"),
    CANCELLED("Cancelled"),
    TIMED_OUT("Timed Out")
}

data class Workload(
    val id: String,
    val orgId: String,
    val name: String,
    val image: String,
    val status: WorkloadStatus,
    val cpuLimit: Int,
    val memoryLimitGb: Int,
    val maxRuntimeSeconds: Int,
    val maxCost: Double,
    val envVars: Map<String, String> = emptyMap(),
    val exitCode: Int? = null,
    val logs: List<String> = emptyList(),
    val artifacts: List<String> = emptyList(),
    val progress: Float = 0f,
    val durationSeconds: Long = 0,
    val actualCharge: Double = 0.0,
    val idempotencyKey: String = ""
)

data class GpuResource(
    val id: String,
    val model: String,
    val memoryGb: Int,
    val totalCount: Int,
    val availableCount: Int,
    val pricePerHour: Double,
    val pricePerSecond: Double,
    val provider: String,
    val isAvailable: Boolean
)

data class StorageObject(
    val key: String,
    val sizeBytes: Long,
    val mimeType: String,
    val updatedAt: Long,
    val signedDownloadUrl: String
)

data class StorageBucket(
    val id: String,
    val orgId: String,
    val name: String,
    val region: String,
    val objectCount: Int,
    val sizeBytes: Long,
    val gbMonthRate: Double = 0.02,
    val retentionDays: Int = 30,
    val objects: List<StorageObject> = emptyList()
)

data class NetworkVpc(
    val id: String,
    val orgId: String,
    val name: String,
    val cidr: String,
    val subnetsCount: Int,
    val activeInstancesCount: Int,
    val egressGb: Double,
    val ingressGb: Double,
    val bandwidthCost: Double
)

data class UsageEvent(
    val id: String,
    val orgId: String,
    val resourceId: String,
    val resourceType: String,
    val meterName: String,
    val quantity: Double,
    val unit: String,
    val timestamp: Long,
    val priceVersion: String,
    val cost: Double
)

data class LedgerEntry(
    val accountName: String,
    val debit: Double,
    val credit: Double
)

data class LedgerTransaction(
    val id: String,
    val orgId: String,
    val timestamp: Long,
    val description: String,
    val transactionType: String,
    val amount: Double,
    val balanceAfter: Double,
    val referenceId: String,
    val entries: List<LedgerEntry>
)

data class InvoiceLineItem(
    val description: String,
    val quantity: Double,
    val unit: String,
    val unitPrice: Double,
    val amount: Double
)

data class Invoice(
    val id: String,
    val orgId: String,
    val invoiceNumber: String,
    val billingPeriod: String,
    val totalAmount: Double,
    val status: String,
    val lineItems: List<InvoiceLineItem>,
    val pdfGeneratedAt: Long
)

data class ApiKey(
    val id: String,
    val orgId: String,
    val name: String,
    val keyPrefix: String,
    val keyHash: String,
    val role: OrgRole,
    val createdAt: Long,
    val lastUsedAt: Long?,
    val isRevoked: Boolean
)

data class AuditLog(
    val id: String,
    val orgId: String,
    val actor: String,
    val action: String,
    val timestamp: Long,
    val details: String
)

data class PlatformHealthMetric(
    val apiLatencyMs: Int,
    val apiErrorRate: Double,
    val activeWorkers: Int,
    val workerQueueDepth: Int,
    val providerHealth: String,
    val meteringLagMs: Int
)

fun formatTimestamp(epochMs: Long): String {
    val sdf = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US)
    return sdf.format(Date(epochMs))
}

fun formatIsoTimestamp(epochMs: Long): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
    return sdf.format(Date(epochMs))
}

fun formatCurrency(amount: Double): String {
    return String.format(Locale.US, "$%.4f", amount)
}

fun formatCurrency2(amount: Double): String {
    return String.format(Locale.US, "$%.2f", amount)
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
    val pre = "KMGTPE"[exp - 1]
    return String.format(Locale.US, "%.1f %sB", bytes / Math.pow(1024.0, exp.toDouble()), pre)
}
