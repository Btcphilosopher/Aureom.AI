package com.example.fluxcloud.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fluxcloud.model.*
import com.example.fluxcloud.ui.components.StatusBadge
import com.example.fluxcloud.ui.theme.*

@Composable
fun NetworkingScreen(
    vpcs: List<NetworkVpc>,
    activeOrg: Organisation
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxNavy900)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "VIRTUAL PRIVATE CLOUD (VPC)",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Isolated tenant networks, automated IPAM, and egress data transfer metering.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FluxTextSecondary
                )
            }
        }

        item {
            Text(
                text = "CONFIGURED NETWORKS (${vpcs.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        items(vpcs) { vpc ->
            Surface(
                color = FluxNavy800,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, FluxBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lan, contentDescription = null, tint = FluxBluePrimary, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(vpc.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text("CIDR: ${vpc.cidr} • ID: ${vpc.id}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextMuted)
                            }
                        }
                        StatusBadge(text = "ACTIVE", color = FluxGreenSuccess)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SUBNETS / ATTACHMENTS", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text("${vpc.subnetsCount} Subnets • ${vpc.activeInstancesCount} Nodes Attached", style = MaterialTheme.typography.bodyMedium, color = FluxTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("BANDWIDTH COST", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = FluxTextMuted)
                            Text(formatCurrency(vpc.bandwidthCost), style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = FluxGreenSuccess)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = FluxBorderSubtle)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ingress Transfer: ${vpc.ingressGb} GB (Free)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxTextSecondary)
                        Text("Egress Transfer: ${vpc.egressGb} GB ($0.02/GB)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = FluxCyanLive)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
