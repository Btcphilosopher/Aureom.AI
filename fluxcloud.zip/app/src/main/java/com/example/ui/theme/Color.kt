package com.example.fluxcloud.ui.theme

import androidx.compose.ui.graphics.Color

// FluxCloud Midnight Navy & Deep Space Palette
val FluxNavy950 = Color(0xFF070B14)
val FluxNavy900 = Color(0xFF0A0F1D)
val FluxNavy850 = Color(0xFF0D1527)
val FluxNavy800 = Color(0xFF131F38)
val FluxNavy750 = Color(0xFF182645)
val FluxNavy700 = Color(0xFF1E3159)

// Accents & Indicators
val FluxBluePrimary = Color(0xFF3B82F6)
val FluxBlueElectric = Color(0xFF2563EB)
val FluxCyanLive = Color(0xFF22D3EE)
val FluxCyanGlow = Color(0xFF06B6D4)

// Semantic State Colors
val FluxGreenSuccess = Color(0xFF10B981)
val FluxAmberWarning = Color(0xFFF59E0B)
val FluxRedDanger = Color(0xFFEF4444)
val FluxPurpleCompute = Color(0xFF8B5CF6)

// Borders & Dividers
val FluxBorderSubtle = Color(0xFF1E293B)
val FluxBorderActive = Color(0xFF2E4369)
val FluxBorderHighlight = Color(0xFF38BDF8)

// Typography & Text
val FluxTextPrimary = Color(0xFFF8FAFC)
val FluxTextSecondary = Color(0xFF94A3B8)
val FluxTextMuted = Color(0xFF64748B)

// Terminal
val FluxTerminalBg = Color(0xFF060911)
val FluxTerminalText = Color(0xFFE2E8F0)
val FluxTerminalPrompt = Color(0xFF22D3EE)
val FluxTerminalSuccess = Color(0xFF34D399)
val FluxTerminalError = Color(0xFFF87171)
