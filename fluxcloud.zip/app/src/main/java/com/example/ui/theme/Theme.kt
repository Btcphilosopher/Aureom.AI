package com.example.fluxcloud.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FluxColorScheme = darkColorScheme(
    primary = FluxBluePrimary,
    onPrimary = Color.White,
    primaryContainer = FluxNavy800,
    onPrimaryContainer = FluxCyanLive,
    secondary = FluxCyanLive,
    onSecondary = FluxNavy950,
    secondaryContainer = FluxNavy750,
    onSecondaryContainer = FluxCyanLive,
    tertiary = FluxPurpleCompute,
    onTertiary = Color.White,
    background = FluxNavy900,
    onBackground = FluxTextPrimary,
    surface = FluxNavy850,
    onSurface = FluxTextPrimary,
    surfaceVariant = FluxNavy800,
    onSurfaceVariant = FluxTextSecondary,
    outline = FluxBorderActive,
    outlineVariant = FluxBorderSubtle,
    error = FluxRedDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use intentional FluxCloud theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FluxColorScheme,
        typography = Typography,
        content = content
    )
}
