package com.example

import com.example.fluxcloud.data.FluxCloudRepository
import com.example.fluxcloud.model.EnvironmentType
import com.example.fluxcloud.model.InstanceStatus
import com.example.fluxcloud.model.OrgRole
import com.example.fluxcloud.model.WorkloadStatus
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class FluxCloudUnitTest {

    private lateinit var repository: FluxCloudRepository

    @Before
    fun setUp() {
        repository = FluxCloudRepository()
    }

    @Test
    fun testInitialTenantState() {
        val activeOrg = repository.activeOrg.value
        assertEquals("Acorn AI Labs", activeOrg.name)
        assertEquals("org_acorn_ai", activeOrg.id)
        assertEquals(150.00, activeOrg.creditBalance, 0.001)
        assertEquals(12.50, activeOrg.reservedBalance, 0.001)
        assertEquals(137.50, activeOrg.availableBalance, 0.001)
    }

    @Test
    fun testInstanceProvisioningWithFundReservation() {
        val initialAvailable = repository.activeOrg.value.availableBalance
        val result = repository.provisionInstance(
            name = "test-node-01",
            instanceType = "Flux Standard",
            region = "us-east-local",
            maxHourlyCost = 0.08,
            autoStopMinutes = 30
        )

        assertTrue(result.isSuccess)
        val instance = result.getOrNull()
        assertNotNull(instance)
        assertEquals("test-node-01", instance?.name)
        assertEquals(InstanceStatus.RUNNING, instance?.status)

        // Verify reserved balance increased by $0.04 (1-hr rate for Flux Standard)
        val updatedOrg = repository.activeOrg.value
        assertEquals(12.50 + 0.04, updatedOrg.reservedBalance, 0.001)
        assertEquals(initialAvailable - 0.04, updatedOrg.availableBalance, 0.001)
    }

    @Test
    fun testWorkloadSubmissionAndIdempotency() {
        val idempotencyKey = "idemp_test_unique_key_123"
        val res1 = repository.submitWorkload(
            name = "data-cleaner",
            image = "fluxcloud/python:3.11-slim",
            cpu = 2,
            memoryGb = 4,
            maxRuntimeSeconds = 120,
            maxCost = 0.05,
            idempotencyKey = idempotencyKey
        )
        assertTrue(res1.isSuccess)
        val workload1 = res1.getOrNull()!!

        // Repeat with identical idempotency key -> Must return existing workload, never duplicate
        val res2 = repository.submitWorkload(
            name = "data-cleaner",
            image = "fluxcloud/python:3.11-slim",
            cpu = 2,
            memoryGb = 4,
            maxRuntimeSeconds = 120,
            maxCost = 0.05,
            idempotencyKey = idempotencyKey
        )
        assertTrue(res2.isSuccess)
        val workload2 = res2.getOrNull()!!

        assertEquals(workload1.id, workload2.id)
    }

    @Test
    fun testCrossTenantSecurityAudit() {
        val auditResult = repository.runCrossTenantSecurityAudit()
        assertTrue(auditResult.contains("403 FORBIDDEN") || auditResult.contains("BLOCKED"))

        val auditLogs = repository.auditLogs.value
        val securityLog = auditLogs.find { it.action == "CROSS_TENANT_ACCESS_BLOCKED" }
        assertNotNull(securityLog)
        assertEquals("SECURITY_AUDITOR", securityLog?.actor)
    }

    @Test
    fun testDoubleEntryLedgerBalanceIntegrity() {
        repository.topUpBalance(100.0)
        val txs = repository.ledgerTransactions.value
        val topUpTx = txs.find { it.transactionType == "PREPAID_DEPOSIT" && it.amount == 100.0 }
        assertNotNull(topUpTx)

        val totalDebit = topUpTx!!.entries.sumOf { it.debit }
        val totalCredit = topUpTx.entries.sumOf { it.credit }
        // Double-entry rule: debits must equal credits
        assertEquals(totalDebit, totalCredit, 0.0001)
    }

    @Test
    fun testEnvironmentToggle() {
        val initialEnv = repository.activeOrg.value.activeEnvironment
        assertEquals(EnvironmentType.TEST, initialEnv)

        repository.toggleEnvironment()
        assertEquals(EnvironmentType.PRODUCTION, repository.activeOrg.value.activeEnvironment)

        repository.toggleEnvironment()
        assertEquals(EnvironmentType.TEST, repository.activeOrg.value.activeEnvironment)
    }

    @Test
    fun testApiKeyCreationAndRevocation() {
        val key = repository.createApiKey("Test Key", OrgRole.DEVELOPER)
        assertFalse(key.isRevoked)
        assertTrue(key.keyPrefix.startsWith("flux_"))

        repository.revokeApiKey(key.id)
        val updated = repository.apiKeys.value.find { it.id == key.id }
        assertTrue(updated?.isRevoked == true)
    }

    @Test
    fun testCsvExportFormat() {
        val csv = repository.generateCsvExport()
        assertTrue(csv.startsWith("event_id,resource_id,meter_name,quantity,unit,timestamp,price_version,charge_usd"))
        assertTrue(csv.contains("cpu_seconds") || csv.contains("storage_gb_hours"))
    }
}
