from setuptools import setup, find_packages

setup(
    name="fluxcloud",
    version="1.0.0",
    description="Python client SDK for the FluxCloud Metered Compute Utility Platform",
    author="FluxCloud Platform Architecture Team",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
