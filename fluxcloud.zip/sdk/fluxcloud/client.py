import json
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, List

class FluxCloudError(Exception):
    """Base exception for all FluxCloud SDK errors."""
    pass

class AuthenticationError(FluxCloudError):
    """Raised when API key or organisation access is invalid."""
    pass

class InsufficientFundsError(FluxCloudError):
    """Raised when prepaid balance is insufficient to authorize resource reservation."""
    pass

class ComputeClient:
    def __init__(self, client: "FluxCloudClient"):
        self._client = client

    def list_instances(self) -> List[Dict[str, Any]]:
        return self._client._request("GET", "/compute/instances")

    def create(
        self,
        name: str,
        instance_type: str = "flux-standard",
        region: str = "us-east-local",
        billing_mode: str = "prepaid",
        max_hourly_cost: Optional[float] = None,
        auto_stop_minutes: int = 60,
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        payload = {
            "name": name,
            "instance_type": instance_type,
            "region": region,
            "billing_mode": billing_mode,
            "max_hourly_cost": max_hourly_cost,
            "auto_stop_minutes": auto_stop_minutes
        }
        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return self._client._request("POST", "/compute/instances", payload=payload, extra_headers=headers)

    def stop(self, instance_id: str) -> Dict[str, Any]:
        return self._client._request("POST", f"/compute/instances/{instance_id}/stop")

    def start(self, instance_id: str) -> Dict[str, Any]:
        return self._client._request("POST", f"/compute/instances/{instance_id}/start")

    def terminate(self, instance_id: str) -> Dict[str, Any]:
        return self._client._request("POST", f"/compute/instances/{instance_id}/terminate")

class WorkloadsClient:
    def __init__(self, client: "FluxCloudClient"):
        self._client = client

    def list(self) -> List[Dict[str, Any]]:
        return self._client._request("GET", "/workloads")

    def create(
        self,
        name: str,
        image: str,
        cpu: int = 2,
        memory_gb: int = 4,
        max_runtime_seconds: int = 300,
        max_cost: float = 0.10,
        env_vars: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        payload = {
            "name": name,
            "image": image,
            "cpu": cpu,
            "memory_gb": memory_gb,
            "max_runtime_seconds": max_runtime_seconds,
            "max_cost": max_cost,
            "env_vars": env_vars or {}
        }
        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return self._client._request("POST", "/workloads", payload=payload, extra_headers=headers)

    def cancel(self, workload_id: str) -> Dict[str, Any]:
        return self._client._request("POST", f"/workloads/{workload_id}/cancel")

    def logs(self, workload_id: str) -> List[str]:
        res = self._client._request("GET", f"/workloads/{workload_id}/logs")
        return res.get("logs", [])

class BillingClient:
    def __init__(self, client: "FluxCloudClient"):
        self._client = client

    def get_balance(self) -> Dict[str, Any]:
        return self._client._request("GET", "/billing/balance")

    def list_invoices(self) -> List[Dict[str, Any]]:
        return self._client._request("GET", "/billing/invoices")

class FluxCloudClient:
    """Official FluxCloud API Client."""
    def __init__(self, api_key: str, base_url: str = "https://api.fluxcloud.io/v1"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.compute = ComputeClient(self)
        self.workloads = WorkloadsClient(self)
        self.billing = BillingClient(self)

    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None
    ) -> Any:
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "FluxCloud-Python-SDK/1.0.0"
        }
        if extra_headers:
            headers.update(extra_headers)

        data = json.dumps(payload).encode("utf-8") if payload else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8")
            if e.code == 401 or e.code == 403:
                raise AuthenticationError(f"HTTP {e.code}: {body}")
            elif e.code == 402:
                raise InsufficientFundsError(f"HTTP 402 Insufficient Funds: {body}")
            else:
                raise FluxCloudError(f"HTTP {e.code}: {body}")
        except Exception as e:
            raise FluxCloudError(f"Connection failed: {str(e)}")
