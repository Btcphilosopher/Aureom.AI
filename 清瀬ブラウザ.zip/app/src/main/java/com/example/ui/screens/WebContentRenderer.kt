package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.BrowserTab
import com.example.model.JapaneseWebMode
import com.example.model.ReaderArticle
import com.example.ui.theme.KiyoseBorder
import com.example.ui.theme.KiyoseVermilion
import com.example.ui.theme.NotoSansJpFamily
import com.example.ui.theme.NotoSerifJpFamily
import com.example.viewmodel.ReaderSettings
import com.example.viewmodel.ReaderTheme

@Composable
fun WebContentRenderer(
    tab: BrowserTab,
    isCrashed: Boolean,
    readerSettings: ReaderSettings,
    onReload: () -> Unit,
    onRecoverCrash: () -> Unit,
    onToggleReaderMode: () -> Unit,
    onToggleVerticalWriting: () -> Unit,
    onUpdateReaderSettings: ((ReaderSettings) -> ReaderSettings) -> Unit,
    onSaveToReadingList: () -> Unit,
    onAddNoteToWorkspace: (String, String) -> Unit,
    onTriggerAI: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when {
            // Section 55: Renderer Crash State
            isCrashed -> {
                RendererCrashView(
                    tabTitle = tab.title,
                    onReload = onRecoverCrash
                )
            }

            // Section 15 & 16: Reader Mode & Vertical Writing Mode
            tab.isReaderMode -> {
                val article = tab.readerArticle
                if (article != null) {
                    if (readerSettings.isVerticalWriting) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            ReaderControlsBar(
                                readerSettings = readerSettings,
                                onUpdateSettings = onUpdateReaderSettings,
                                onToggleVertical = onToggleVerticalWriting,
                                onExitReader = onToggleReaderMode,
                                onSaveToReadingList = onSaveToReadingList,
                                onTriggerAI = onTriggerAI
                            )
                            VerticalWritingReader(
                                article = article,
                                readerSettings = readerSettings,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            ReaderControlsBar(
                                readerSettings = readerSettings,
                                onUpdateSettings = onUpdateReaderSettings,
                                onToggleVertical = onToggleVerticalWriting,
                                onExitReader = onToggleReaderMode,
                                onSaveToReadingList = onSaveToReadingList,
                                onTriggerAI = onTriggerAI
                            )
                            HorizontalReaderView(
                                article = article,
                                readerSettings = readerSettings,
                                onAddNote = { quote ->
                                    onAddNoteToWorkspace(quote, "リーダーモードからの引用")
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    NormalWebPageView(
                        tab = tab,
                        onToggleReaderMode = onToggleReaderMode,
                        onAddNoteToWorkspace = onAddNoteToWorkspace
                    )
                }
            }

            else -> {
                NormalWebPageView(
                    tab = tab,
                    onToggleReaderMode = onToggleReaderMode,
                    onAddNoteToWorkspace = onAddNoteToWorkspace
                )
            }
        }
    }
}

@Composable
fun RendererCrashView(
    tabTitle: String,
    onReload: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(2.dp))
                .border(width = 0.5.dp, color = KiyoseBorder, shape = RoundedCornerShape(2.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "レンダラー異常終了",
                tint = KiyoseVermilion,
                modifier = Modifier.size(32.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "このページで問題が発生しました",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "「$tabTitle」のレンダラープロセスが予期せず終了しました。清瀬ブラウザのマルチプロセス設計により、他のタブは正常に動作し続けています。",
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onReload,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.testTag("reload_crashed_tab_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("再読み込み", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun ReaderControlsBar(
    readerSettings: ReaderSettings,
    onUpdateSettings: ((ReaderSettings) -> ReaderSettings) -> Unit,
    onToggleVertical: () -> Unit,
    onExitReader: () -> Unit,
    onSaveToReadingList: () -> Unit,
    onTriggerAI: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(MaterialTheme.colorScheme.surface)
            .border(width = 0.5.dp, color = KiyoseBorder)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Exit Reader
            Text(
                text = "← 通常表示",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier
                    .clickable { onExitReader() }
                    .padding(4.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Font switch (Serif vs Sans)
            Text(
                text = if (readerSettings.useSerif) "明朝体" else "ゴシック",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier
                    .clickable {
                        onUpdateSettings { it.copy(useSerif = !it.useSerif) }
                    }
                    .padding(4.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            // Font size controls
            Text(
                text = "小",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                modifier = Modifier
                    .clickable {
                        if (readerSettings.fontSizeSp > 13) {
                            onUpdateSettings { it.copy(fontSizeSp = it.fontSizeSp - 1) }
                        }
                    }
                    .padding(4.dp)
            )
            Text(
                text = "${readerSettings.fontSizeSp}pt",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant),
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Text(
                text = "大",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                modifier = Modifier
                    .clickable {
                        if (readerSettings.fontSizeSp < 24) {
                            onUpdateSettings { it.copy(fontSizeSp = it.fontSizeSp + 1) }
                        }
                    }
                    .padding(4.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Vertical / Horizontal switch
            Row(
                modifier = Modifier
                    .clickable { onToggleVertical() }
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (readerSettings.isVerticalWriting) Icons.Default.FormatAlignRight else Icons.Default.FormatAlignLeft,
                    contentDescription = "縦書き/横書き切替",
                    tint = if (readerSettings.isVerticalWriting) KiyoseVermilion else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (readerSettings.isVerticalWriting) "縦書き中" else "横書き",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp,
                        color = if (readerSettings.isVerticalWriting) KiyoseVermilion else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Tone / theme toggle (和紙白 / 薄青磁 / 夜間墨)
            Text(
                text = readerSettings.theme.label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier
                    .clickable {
                        val next = when (readerSettings.theme) {
                            ReaderTheme.WARM_WHITE -> ReaderTheme.SEIJI_MIST
                            ReaderTheme.SEIJI_MIST -> ReaderTheme.QUIET_DARK
                            ReaderTheme.QUIET_DARK -> ReaderTheme.WARM_WHITE
                        }
                        onUpdateSettings { it.copy(theme = next) }
                    }
                    .padding(4.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Save to Reading list
            IconButton(
                onClick = onSaveToReadingList,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = "後で読むに保存",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(15.dp)
                )
            }

            // AI Analyze
            IconButton(
                onClick = onTriggerAI,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI要約",
                    tint = KiyoseVermilion,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun HorizontalReaderView(
    article: ReaderArticle,
    readerSettings: ReaderSettings,
    onAddNote: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val fontFamily = if (readerSettings.useSerif) NotoSerifJpFamily else NotoSansJpFamily
    val bgColor = Color(readerSettings.theme.bgHex)
    val textColor = Color(readerSettings.theme.textHex)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
            .verticalScroll(scrollState),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .padding(horizontal = 28.dp, vertical = 36.dp)
        ) {
            // Site Name Badge
            Text(
                text = article.siteName,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 11.sp,
                    color = textColor.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Article Title
            Text(
                text = article.title,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontSize = (readerSettings.fontSizeSp + 8).sp,
                    fontFamily = fontFamily,
                    fontWeight = FontWeight.Medium,
                    lineHeight = (readerSettings.fontSizeSp + 16).sp,
                    color = textColor
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Meta line: Author & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = article.author,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 12.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                )
                Text(
                    text = article.date,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 12.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            HorizontalDivider(
                color = textColor.copy(alpha = 0.15f),
                thickness = 0.5.dp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Lead text
            Text(
                text = article.leadText,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = (readerSettings.fontSizeSp + 1).sp,
                    fontFamily = fontFamily,
                    fontWeight = FontWeight.Medium,
                    lineHeight = ((readerSettings.fontSizeSp + 1) * readerSettings.lineHeightMultiplier).sp,
                    color = textColor
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Paragraphs
            article.paragraphs.forEach { paragraph ->
                Text(
                    text = "　$paragraph",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = readerSettings.fontSizeSp.sp,
                        fontFamily = fontFamily,
                        lineHeight = (readerSettings.fontSizeSp * readerSettings.lineHeightMultiplier).sp,
                        color = textColor,
                        letterSpacing = 0.4.sp
                    )
                )
                Spacer(modifier = Modifier.height(18.dp))
            }

            // Quotes
            if (article.quotes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                article.quotes.forEach { quote ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(textColor.copy(alpha = 0.04f))
                            .border(width = 0.5.dp, color = textColor.copy(alpha = 0.15f))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = quote,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontSize = readerSettings.fontSizeSp.sp,
                                    fontFamily = fontFamily,
                                    fontWeight = FontWeight.Medium,
                                    color = textColor,
                                    lineHeight = (readerSettings.fontSizeSp * 1.6).sp
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Text(
                                    text = "＋ この文章をメモに追加",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        color = KiyoseVermilion
                                    ),
                                    modifier = Modifier.clickable { onAddNote(quote) }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Key metrics box
            if (article.keyMetrics.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "主要データ",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 13.sp,
                        color = textColor,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 0.5.dp, color = textColor.copy(alpha = 0.2f))
                ) {
                    article.keyMetrics.forEachIndexed { idx, pair ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) Color.Transparent else textColor.copy(alpha = 0.03f))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = pair.first,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 12.sp,
                                    color = textColor.copy(alpha = 0.8f)
                                )
                            )
                            Text(
                                text = pair.second,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textColor
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
fun NormalWebPageView(
    tab: BrowserTab,
    onToggleReaderMode: () -> Unit,
    onAddNoteToWorkspace: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val article = tab.readerArticle
    val isExternalUrl = tab.url.startsWith("http://") || tab.url.startsWith("https://")

    if (isExternalUrl && article == null) {
        // Live WebView integration
        AndroidView(
            modifier = modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    @SuppressLint("SetJavaScriptEnabled")
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    settings.userAgentString = "Mozilla/5.0 (Linux; Android 14; KiyoseBrowser/1.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                    webViewClient = WebViewClient()
                    loadUrl(tab.url)
                }
            },
            update = { webView ->
                if (webView.url != tab.url) {
                    webView.loadUrl(tab.url)
                }
            }
        )
    } else {
        // High fidelity structured Web Content for Japanese reading & research
        val scrollState = rememberScrollState()

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(scrollState),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp)
            ) {
                // Japanese Web Mode banner
                if (tab.webMode != JapaneseWebMode.STANDARD) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "【${tab.webMode.label}表示モード】${tab.webMode.description}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Page Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = article?.siteName ?: tab.url,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    OutlinedButton(
                        onClick = onToggleReaderMode,
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = KiyoseVermilion
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "リーダーモードで読む",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = article?.title ?: tab.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                HorizontalDivider(color = KiyoseBorder, thickness = 0.5.dp)

                Spacer(modifier = Modifier.height(16.dp))

                if (article != null) {
                    Text(
                        text = article.leadText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    article.paragraphs.forEach { para ->
                        Text(
                            text = "　$para",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 13.sp,
                                lineHeight = 22.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (article.quotes.isNotEmpty()) {
                        article.quotes.forEach { quote ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(width = 0.5.dp, color = KiyoseBorder)
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Text(
                                        text = quote,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "＋ 研究スペースへ引用",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 11.sp,
                                            color = KiyoseVermilion
                                        ),
                                        modifier = Modifier.clickable {
                                            onAddNoteToWorkspace(quote, "Webページより抜粋")
                                        }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
