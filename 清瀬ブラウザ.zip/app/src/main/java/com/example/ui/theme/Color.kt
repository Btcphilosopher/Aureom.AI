package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kiyose Warm Palette - Light
val KiyoseBgWarm = Color(0xFFF7F6F2)
val KiyoseBgWarmSubtle = Color(0xFFF3F3EF)
val KiyoseBgWarmMuted = Color(0xFFECECE8)

val KiyoseSurfaceLight = Color(0xFFFFFFFF)
val KiyoseSurfaceAlt = Color(0xFFF8F8F5)

val KiyoseTextPrimary = Color(0xFF202322)
val KiyoseTextSecondary = Color(0xFF353836)
val KiyoseTextMuted = Color(0xFF666A67)

val KiyoseBorder = Color(0xFFD9DAD6)
val KiyoseBorderLight = Color(0xFFE4E5E1)

// Kiyose Vermilion Accent (Used sparingly for state/focus/action)
val KiyoseVermilion = Color(0xFFB83B32)
val KiyoseVermilionLight = Color(0xFFFDF0EF)

// Secondary Japanese Atmospheric Accents
val KiyoseRikyuGreen = Color(0xFF536B64)
val KiyoseAiSlate = Color(0xFF536978)

// Kiyose Quiet Dark & Private Browsing Palette (Warm Dark Charcoal, never pitch black)
val KiyoseDarkBg = Color(0xFF161817)
val KiyoseDarkSurface = Color(0xFF202321)
val KiyoseDarkSurfaceAlt = Color(0xFF282B29)
val KiyoseDarkBorder = Color(0xFF383B39)
val KiyoseDarkTextPrimary = Color(0xFFECECE8)
val KiyoseDarkTextSecondary = Color(0xFFB8BBB6)
val KiyoseDarkTextMuted = Color(0xFF868A85)
