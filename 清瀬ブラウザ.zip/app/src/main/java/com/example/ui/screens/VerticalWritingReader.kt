package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ReaderArticle
import com.example.ui.theme.KiyoseBorder
import com.example.ui.theme.NotoSerifJpFamily
import com.example.viewmodel.ReaderSettings

/**
 * Japanese Vertical Writing Reader (縦書き読書モード)
 * Traditional right-to-left column progression and top-to-bottom character flow.
 */
@Composable
fun VerticalWritingReader(
    article: ReaderArticle,
    readerSettings: ReaderSettings,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // In Japanese traditional vertical writing, reading starts at the far right.
    // Ensure scroll starts at the rightmost position.
    LaunchedEffect(article.title) {
        scrollState.scrollTo(scrollState.maxValue)
    }

    val bgColor = Color(readerSettings.theme.bgHex)
    val textColor = Color(readerSettings.theme.textHex)

    // RTL composition so columns flow from Right to Left!
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(bgColor)
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxHeight()
                    .horizontalScroll(scrollState),
                verticalAlignment = Alignment.Top
            ) {
                // Title column (first on the right in RTL)
                VerticalTextColumn(
                    text = article.title,
                    fontSizeSp = readerSettings.fontSizeSp + 4,
                    isBold = true,
                    textColor = textColor,
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                // Thin divider
                Box(
                    modifier = Modifier
                        .fillMaxHeight(0.85f)
                        .width(1.dp)
                        .background(KiyoseBorder.copy(alpha = 0.5f))
                )

                Spacer(modifier = Modifier.width(16.dp))

                // Author & Date column
                VerticalTextColumn(
                    text = "${article.siteName} ── ${article.author} 記 ── ${article.date}",
                    fontSizeSp = readerSettings.fontSizeSp - 3,
                    isBold = false,
                    textColor = textColor.copy(alpha = 0.7f),
                    modifier = Modifier.padding(horizontal = 10.dp)
                )

                Spacer(modifier = Modifier.width(20.dp))

                // Lead paragraph
                VerticalTextColumn(
                    text = "【概要】${article.leadText}",
                    fontSizeSp = readerSettings.fontSizeSp,
                    isBold = false,
                    textColor = textColor,
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                Spacer(modifier = Modifier.width(24.dp))

                // Body paragraphs
                article.paragraphs.forEach { paragraph ->
                    VerticalTextColumn(
                        text = "　$paragraph",
                        fontSizeSp = readerSettings.fontSizeSp,
                        isBold = false,
                        textColor = textColor,
                        modifier = Modifier.padding(horizontal = 14.dp)
                    )
                    Spacer(modifier = Modifier.width(20.dp))
                }

                // Quotes and key metrics
                if (article.quotes.isNotEmpty()) {
                    article.quotes.forEach { quote ->
                        VerticalTextColumn(
                            text = quote,
                            fontSizeSp = readerSettings.fontSizeSp,
                            isBold = true,
                            textColor = textColor,
                            modifier = Modifier
                                .border(width = 0.5.dp, color = KiyoseBorder)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                        Spacer(modifier = Modifier.width(20.dp))
                    }
                }

                // Left margin / end of document marker
                VerticalTextColumn(
                    text = "（了）",
                    fontSizeSp = readerSettings.fontSizeSp - 2,
                    isBold = false,
                    textColor = textColor.copy(alpha = 0.5f),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}

/**
 * Transforms a Japanese string into a vertical column where each character
 * is placed top-to-bottom. Handles Japanese punctuation (、。・ー) and line breaks.
 */
@Composable
private fun VerticalTextColumn(
    text: String,
    fontSizeSp: Int,
    isBold: Boolean,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    // In vertical Japanese layout, text is split into columns when exceeding column height
    // For clean rendering, we split into vertical character streams
    val lines = text.chunked(32) // ~32 characters per vertical line

    Row(modifier = modifier, verticalAlignment = Alignment.Top) {
        lines.forEach { line ->
            Column(
                modifier = Modifier
                    .padding(horizontal = 6.dp)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                line.forEach { char ->
                    val displayChar = when (char) {
                        'ー' -> '丨' // Rotate chouonpu for vertical
                        '（' -> '︵'
                        '）' -> '︶'
                        '「' -> '﹁'
                        '」' -> '﹂'
                        '『' -> '﹃'
                        '』' -> '﹄'
                        else -> char
                    }

                    Text(
                        text = displayChar.toString(),
                        fontFamily = NotoSerifJpFamily,
                        fontSize = fontSizeSp.sp,
                        lineHeight = (fontSizeSp + 4).sp,
                        fontWeight = if (isBold) FontWeight.Medium else FontWeight.Normal,
                        color = textColor,
                        modifier = Modifier.padding(vertical = 0.5.dp)
                    )
                }
            }
        }
    }
}
