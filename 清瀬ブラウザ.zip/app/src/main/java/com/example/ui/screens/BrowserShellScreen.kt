package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.ui.components.BrowserAddressBar
import com.example.ui.components.BrowserTabBar
import com.example.ui.sheets.AIPanelSheet
import com.example.ui.sheets.BookmarksSheet
import com.example.ui.sheets.DevToolsSheet
import com.example.ui.sheets.DownloadsSheet
import com.example.ui.sheets.HistorySheet
import com.example.ui.sheets.OverflowMenuSheet
import com.example.ui.sheets.PrivacyCenterSheet
import com.example.ui.sheets.ReadingListSheet
import com.example.ui.sheets.ResearchWorkspaceSheet
import com.example.ui.sheets.SearchSuggestionsOverlay
import com.example.ui.sheets.SecurityInfoSheet
import com.example.ui.sheets.SettingsSheet
import com.example.ui.sheets.TabSwitcherSheet
import com.example.ui.sheets.TaskManagerSheet
import com.example.ui.theme.KiyoseBorder
import com.example.ui.theme.KiyoseVermilion
import com.example.viewmodel.ActiveSheet
import com.example.viewmodel.BrowserViewModel

@Composable
fun BrowserShellScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    val activeTab = viewModel.activeTab
    val urlInputText by viewModel.urlInputText.collectAsState()
    val isAddressBarFocused by viewModel.isAddressBarFocused.collectAsState()
    val suggestions by viewModel.suggestions.collectAsState()
    val currentSearchEngine by viewModel.currentSearchEngine.collectAsState()
    val readerSettings by viewModel.readerSettings.collectAsState()
    val activeSheet by viewModel.activeSheet.collectAsState()
    val statusNotice by viewModel.statusNotice.collectAsState()
    val isCrashed = viewModel.crashedTabId.collectAsState().value == activeTabId
    val isPrivateMode by viewModel.isPrivateMode.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val uiDensity by viewModel.uiDensity.collectAsState()
    val selectedForCompare by viewModel.selectedTabIdsForCompare.collectAsState()

    // Back handling
    BackHandler {
        if (activeSheet != ActiveSheet.NONE) {
            viewModel.closeSheet()
        } else if (isAddressBarFocused) {
            viewModel.setAddressBarFocused(false)
        } else if (activeTab.isReaderMode) {
            viewModel.toggleReaderMode()
        } else if (activeTab.canGoBack) {
            viewModel.goBackActiveTab()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Section 06 & 07: Browser Tab Bar
                BrowserTabBar(
                    tabs = tabs,
                    activeTabId = activeTabId,
                    onTabSelected = { viewModel.selectTab(it) },
                    onTabClosed = { viewModel.closeTab(it) },
                    onNewTabClick = { viewModel.openTab() }
                )

                // Section 06 & 09: Universal Address Bar
                BrowserAddressBar(
                    tab = activeTab,
                    inputText = urlInputText,
                    searchEngine = currentSearchEngine,
                    onInputChanged = { viewModel.updateUrlInput(it) },
                    onSubmit = { viewModel.submitAddressBar(it) },
                    onFocusChanged = { viewModel.setAddressBarFocused(it) },
                    onBackClick = { viewModel.goBackActiveTab() },
                    onForwardClick = { viewModel.goForwardActiveTab() },
                    onReloadClick = { viewModel.reloadActiveTab() },
                    onToggleReaderMode = { viewModel.toggleReaderMode() },
                    onToggleAI = { viewModel.openSheet(ActiveSheet.AI_PANEL) },
                    onMenuClick = {
                        if (activeSheet == ActiveSheet.NONE) viewModel.openSheet(ActiveSheet.TAB_SWITCHER)
                        else viewModel.closeSheet()
                    },
                    onSecurityClick = { viewModel.openSheet(ActiveSheet.SECURITY_INFO) }
                )

                // Web Content or New Tab Home
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (activeTab.url == "about:home") {
                        NewTabContent(
                            onNavigate = { viewModel.loadUrl(it) },
                            onActivateSearch = { viewModel.setAddressBarFocused(true) }
                        )
                    } else {
                        WebContentRenderer(
                            tab = activeTab,
                            isCrashed = isCrashed,
                            readerSettings = readerSettings,
                            onReload = { viewModel.reloadActiveTab() },
                            onRecoverCrash = { viewModel.recoverCrashedTab() },
                            onToggleReaderMode = { viewModel.toggleReaderMode() },
                            onToggleVerticalWriting = { viewModel.toggleVerticalWriting() },
                            onUpdateReaderSettings = { viewModel.updateReaderSettings(it) },
                            onSaveToReadingList = { viewModel.saveCurrentToReadingList() },
                            onAddNoteToWorkspace = { quote, note ->
                                val defaultWsId = viewModel.workspaces.value.firstOrNull()?.id ?: "w1"
                                viewModel.addNoteToWorkspace(defaultWsId, quote, note)
                            },
                            onTriggerAI = { viewModel.triggerAISummary() }
                        )
                    }

                    // Suggestions Overlay (Prompt 12)
                    if (isAddressBarFocused && suggestions.isNotEmpty()) {
                        SearchSuggestionsOverlay(
                            suggestions = suggestions,
                            onSelectSuggestion = { suggestion ->
                                viewModel.submitAddressBar(suggestion)
                            },
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                        )
                    }
                }
            }

            // Status Notice Toast (Section 02: アニメーションを減らし、不要な通知を減らす。必要な時だけ静かに表示)
            AnimatedVisibility(
                visible = statusNotice != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
            ) {
                statusNotice?.let { notice ->
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(2.dp))
                            .border(width = 0.5.dp, color = KiyoseBorder, shape = RoundedCornerShape(2.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = notice,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            // Modal Sheets based on activeSheet state
            when (activeSheet) {
                ActiveSheet.TAB_SWITCHER -> {
                    TabSwitcherSheet(
                        tabs = tabs,
                        activeTabId = activeTabId,
                        selectedForCompare = selectedForCompare,
                        onSelectTab = { viewModel.selectTab(it) },
                        onCloseTab = { viewModel.closeTab(it) },
                        onNewTab = { viewModel.openTab() },
                        onToggleCompareSelection = { viewModel.toggleTabComparisonSelection(it) },
                        onTriggerCompare = { viewModel.triggerAICompareSelectedTabs() },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.AI_PANEL -> {
                    val aiResult by viewModel.aiResult.collectAsState()
                    val aiIsLoading by viewModel.aiIsLoading.collectAsState()
                    val qnaHistory by viewModel.aiQnaHistory.collectAsState()

                    AIPanelSheet(
                        isLoading = aiIsLoading,
                        analysisResult = aiResult,
                        qnaHistory = qnaHistory,
                        onTriggerSummary = { viewModel.triggerAISummary() },
                        onTriggerMetrics = { viewModel.triggerAIMetricsExtraction() },
                        onTriggerTranslation = { viewModel.triggerAITranslation(it) },
                        onAskQuestion = { viewModel.askAIQuestion(it) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.RESEARCH_WORKSPACE -> {
                    val workspaces by viewModel.workspaces.collectAsState()
                    ResearchWorkspaceSheet(
                        workspaces = workspaces,
                        onCreateWorkspace = { title, desc -> viewModel.repository.createWorkspace(title, desc) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.BOOKMARKS -> {
                    val bookmarks by viewModel.bookmarks.collectAsState()
                    BookmarksSheet(
                        bookmarks = bookmarks,
                        onSelectBookmark = { viewModel.loadUrl(it); viewModel.closeSheet() },
                        onDeleteBookmark = { viewModel.repository.removeBookmark(it) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.HISTORY -> {
                    val history by viewModel.history.collectAsState()
                    HistorySheet(
                        history = history,
                        onSelectHistory = { viewModel.loadUrl(it); viewModel.closeSheet() },
                        onClearHistory = { viewModel.repository.clearHistory() },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.READING_LIST -> {
                    val readingList by viewModel.readingList.collectAsState()
                    ReadingListSheet(
                        readingList = readingList,
                        onSelectArticle = { viewModel.loadUrl(it); viewModel.closeSheet() },
                        onRemoveItem = { viewModel.repository.removeReadingListItem(it) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.DOWNLOADS -> {
                    val downloads by viewModel.downloads.collectAsState()
                    DownloadsSheet(
                        downloads = downloads,
                        onToggleStatus = { viewModel.repository.toggleDownloadStatus(it) },
                        onRemove = { viewModel.repository.removeDownload(it) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.PRIVACY_CENTER -> {
                    val permissions by viewModel.sitePermissions.collectAsState()
                    val extensions by viewModel.extensions.collectAsState()
                    PrivacyCenterSheet(
                        permissions = permissions,
                        extensions = extensions,
                        onToggleExtension = { viewModel.repository.toggleExtension(it) },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.SECURITY_INFO -> {
                    SecurityInfoSheet(
                        url = activeTab.url,
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.SETTINGS -> {
                    SettingsSheet(
                        isDarkTheme = isDarkTheme,
                        uiDensity = uiDensity,
                        currentSearchEngine = currentSearchEngine,
                        onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                        onSelectUiDensity = { viewModel.setUiDensity(it) },
                        onSelectSearchEngine = { viewModel.setSearchEngine(it) },
                        onSimulateCrash = { viewModel.simulateRendererCrash(); viewModel.closeSheet() },
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.TASK_MANAGER -> {
                    TaskManagerSheet(
                        tabs = tabs,
                        onClose = { viewModel.closeSheet() }
                    )
                }
                ActiveSheet.DEV_TOOLS -> {
                    val devToolsLogs by viewModel.devToolsLogs.collectAsState()
                    DevToolsSheet(
                        logs = devToolsLogs,
                        onClose = { viewModel.closeSheet() }
                    )
                }
                else -> Unit
            }
        }
    }
}
