package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KiyoseLightColorScheme = lightColorScheme(
    primary = KiyoseTextPrimary,
    onPrimary = KiyoseSurfaceLight,
    primaryContainer = KiyoseBgWarmMuted,
    onPrimaryContainer = KiyoseTextPrimary,
    secondary = KiyoseVermilion,
    onSecondary = KiyoseSurfaceLight,
    secondaryContainer = KiyoseVermilionLight,
    onSecondaryContainer = KiyoseVermilion,
    tertiary = KiyoseRikyuGreen,
    background = KiyoseBgWarm,
    onBackground = KiyoseTextPrimary,
    surface = KiyoseSurfaceLight,
    onSurface = KiyoseTextPrimary,
    surfaceVariant = KiyoseBgWarmSubtle,
    onSurfaceVariant = KiyoseTextMuted,
    outline = KiyoseBorder,
    outlineVariant = KiyoseBorderLight
)

private val KiyoseDarkColorScheme = darkColorScheme(
    primary = KiyoseDarkTextPrimary,
    onPrimary = KiyoseDarkBg,
    primaryContainer = KiyoseDarkSurfaceAlt,
    onPrimaryContainer = KiyoseDarkTextPrimary,
    secondary = KiyoseVermilion,
    onSecondary = KiyoseSurfaceLight,
    secondaryContainer = KiyoseDarkSurfaceAlt,
    onSecondaryContainer = KiyoseVermilion,
    tertiary = KiyoseRikyuGreen,
    background = KiyoseDarkBg,
    onBackground = KiyoseDarkTextPrimary,
    surface = KiyoseDarkSurface,
    onSurface = KiyoseDarkTextPrimary,
    surfaceVariant = KiyoseDarkSurfaceAlt,
    onSurfaceVariant = KiyoseDarkTextMuted,
    outline = KiyoseDarkBorder,
    outlineVariant = KiyoseDarkBorder
)

@Composable
fun KiyoseTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KiyoseDarkColorScheme else KiyoseLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = KiyoseTypography,
        content = content
    )
}
