package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AIAnalysisResult
import com.example.model.BookmarkCategory
import com.example.model.BookmarkItem
import com.example.model.BrowserExtension
import com.example.model.BrowserTab
import com.example.model.DevToolsEntry
import com.example.model.DownloadItem
import com.example.model.DownloadStatus
import com.example.model.HistoryItem
import com.example.model.JapaneseWebMode
import com.example.model.PermissionState
import com.example.model.ReadingListItem
import com.example.model.ResearchWorkspace
import com.example.model.SearchEngine
import com.example.model.SitePermission
import com.example.model.TaskManagerProcess
import com.example.ui.theme.KiyoseBorder
import com.example.ui.theme.KiyoseRikyuGreen
import com.example.ui.theme.KiyoseVermilion
import com.example.viewmodel.ActiveSheet
import com.example.viewmodel.UiDensity

@Composable
fun SheetModalContainer(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .clickable(enabled = false) {},
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(width = 0.5.dp, color = KiyoseBorder)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp).testTag("close_sheet_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "閉じる",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                content()
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 1. Search Suggestions Overlay
// ----------------------------------------------------------------------------
@Composable
fun SearchSuggestionsOverlay(
    suggestions: List<String>,
    onSelectSuggestion: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(width = 0.5.dp, color = KiyoseBorder),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            suggestions.forEach { suggestion ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSuggestion(suggestion) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = suggestion,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
                HorizontalDivider(color = KiyoseBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 2. Tab Switcher Sheet & Compare Selector
// ----------------------------------------------------------------------------
@Composable
fun TabSwitcherSheet(
    tabs: List<BrowserTab>,
    activeTabId: String,
    selectedForCompare: Set<String>,
    onSelectTab: (String) -> Unit,
    onCloseTab: (String) -> Unit,
    onNewTab: () -> Unit,
    onToggleCompareSelection: (String) -> Unit,
    onTriggerCompare: () -> Unit,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "タブ一覧 (${tabs.size})", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            // Action header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onNewTab,
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("＋ 新しいタブ", style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp))
                }

                if (tabs.size >= 2) {
                    Button(
                        onClick = onTriggerCompare,
                        colors = ButtonDefaults.buttonColors(containerColor = KiyoseVermilion),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = "選択したタブをAI比較 (${if (selectedForCompare.isEmpty()) tabs.take(3).size else selectedForCompare.size})",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(tabs) { tab ->
                    val isActive = tab.id == activeTabId
                    val isCheckedForCompare = selectedForCompare.contains(tab.id)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                if (isActive) MaterialTheme.colorScheme.surface
                                else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(2.dp)
                            )
                            .border(
                                width = if (isActive) 1.dp else 0.5.dp,
                                color = if (isActive) KiyoseVermilion else KiyoseBorder,
                                shape = RoundedCornerShape(2.dp)
                            )
                            .clickable { onSelectTab(tab.id) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Checkbox for comparison
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .border(width = 0.8.dp, color = KiyoseBorder)
                                .background(if (isCheckedForCompare) KiyoseVermilion else Color.Transparent)
                                .clickable { onToggleCompareSelection(tab.id) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCheckedForCompare) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = tab.url,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(
                            onClick = { onCloseTab(tab.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "閉じる",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 3. AI Panel Sheet (清瀬 AI)
// ----------------------------------------------------------------------------
@Composable
fun AIPanelSheet(
    isLoading: Boolean,
    analysisResult: AIAnalysisResult?,
    qnaHistory: List<Pair<String, String>>,
    onTriggerSummary: () -> Unit,
    onTriggerMetrics: () -> Unit,
    onTriggerTranslation: (String) -> Unit,
    onAskQuestion: (String) -> Unit,
    onClose: () -> Unit
) {
    var questionInput by remember { mutableStateOf("") }

    SheetModalContainer(title = "清瀬 AI ── 文脈解析・要約", onClose = onClose) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Quick action chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onTriggerSummary,
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("このページを要約", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp))
                }

                OutlinedButton(
                    onClick = onTriggerMetrics,
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("重要数値を抽出", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp))
                }

                OutlinedButton(
                    onClick = { onTriggerTranslation("英語") },
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("日英翻訳", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            HorizontalDivider(color = KiyoseBorder, thickness = 0.5.dp)

            Spacer(modifier = Modifier.height(14.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = KiyoseVermilion, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "文書の構造と文脈を静かに抽出中…",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    if (analysisResult != null) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface)
                                    .border(width = 0.5.dp, color = KiyoseBorder)
                                    .padding(16.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = analysisResult.actionType,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontSize = 11.sp,
                                                color = KiyoseVermilion,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                        Text(
                                            text = analysisResult.sourceTitle,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = analysisResult.title,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Summary Points
                                    if (analysisResult.summaryPoints.isNotEmpty()) {
                                        analysisResult.summaryPoints.forEach { point ->
                                            Text(
                                                text = point,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontSize = 12.sp,
                                                    lineHeight = 18.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                ),
                                                modifier = Modifier.padding(vertical = 3.dp)
                                            )
                                        }
                                    }

                                    // Translation Original vs Target
                                    if (analysisResult.translationOriginal != null && analysisResult.translationTarget != null) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text("【原文】", style = MaterialTheme.typography.labelSmall.copy(color = KiyoseRikyuGreen))
                                        Text(analysisResult.translationOriginal, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp))
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("【翻訳】", style = MaterialTheme.typography.labelSmall.copy(color = KiyoseVermilion))
                                        Text(analysisResult.translationTarget, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp))
                                    }

                                    // Key Data Points
                                    if (analysisResult.keyDataPoints.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "主要数値",
                                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        analysisResult.keyDataPoints.forEach { (metric, value) ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(metric, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
                                                Text(value, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium))
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = "参照元: ${analysisResult.sourceUrl}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Q&A History
                    if (qnaHistory.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "質問と回答",
                                style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp)
                            )
                        }
                        items(qnaHistory) { (q, a) ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp)
                            ) {
                                Text("問：$q", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, fontWeight = FontWeight.Medium))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("答：$a", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 16.sp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Ask Question Input Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = questionInput,
                    onValueChange = { questionInput = it },
                    placeholder = { Text("このページについて質問…", style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)) },
                    modifier = Modifier.weight(1f).height(46.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = KiyoseVermilion,
                        unfocusedBorderColor = KiyoseBorder
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (questionInput.isNotBlank()) {
                            onAskQuestion(questionInput.trim())
                            questionInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(46.dp)
                ) {
                    Text("送信", style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp))
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 4. Research Workspace Sheet (研究スペース)
// ----------------------------------------------------------------------------
@Composable
fun ResearchWorkspaceSheet(
    workspaces: List<ResearchWorkspace>,
    onCreateWorkspace: (String, String) -> Unit,
    onClose: () -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }

    SheetModalContainer(title = "研究スペース (Research Workspaces)", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "プロジェクト一覧",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                )

                OutlinedButton(
                    onClick = { showCreateDialog = true },
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("＋ 新規スペース作成", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp))
                }
            }

            if (showCreateDialog) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                        .padding(12.dp)
                ) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("プロジェクト名 (例: 日本の半導体産業)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newDesc,
                        onValueChange = { newDesc = it },
                        label = { Text("調査目的・概要") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showCreateDialog = false }) { Text("キャンセル") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    onCreateWorkspace(newTitle.trim(), newDesc.trim())
                                    newTitle = ""
                                    newDesc = ""
                                    showCreateDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = KiyoseVermilion)
                        ) {
                            Text("作成")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(workspaces) { ws ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(width = 0.5.dp, color = KiyoseBorder)
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = ws.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                                Text(
                                    text = ws.createdAt,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = ws.description,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )

                            if (ws.notes.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("【引用ノート】", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = KiyoseVermilion))
                                ws.notes.forEach { note ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .background(MaterialTheme.colorScheme.background)
                                            .padding(8.dp)
                                    ) {
                                        Column {
                                            Text("「${note.quote}」", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic))
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text("メモ：${note.userComment}", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium))
                                        }
                                    }
                                }
                            }

                            if (ws.aiSynthesis != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(KiyoseVermilion.copy(alpha = 0.04f))
                                        .border(width = 0.5.dp, color = KiyoseVermilion.copy(alpha = 0.3f))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = ws.aiSynthesis,
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 5. Bookmarks Sheet (ブックマーク)
// ----------------------------------------------------------------------------
@Composable
fun BookmarksSheet(
    bookmarks: List<BookmarkItem>,
    onSelectBookmark: (String) -> Unit,
    onDeleteBookmark: (String) -> Unit,
    onClose: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf(BookmarkCategory.ALL) }

    val filtered = remember(bookmarks, selectedCategory) {
        if (selectedCategory == BookmarkCategory.ALL) bookmarks
        else bookmarks.filter { it.category == selectedCategory }
    }

    SheetModalContainer(title = "ブックマーク", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            // Category filter chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(BookmarkCategory.values()) { category ->
                    val isSelected = category == selectedCategory
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(2.dp)
                            )
                            .border(width = 0.5.dp, color = KiyoseBorder, shape = RoundedCornerShape(2.dp))
                            .clickable { selectedCategory = category }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = category.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filtered) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(width = 0.5.dp, color = KiyoseBorder)
                            .clickable { onSelectBookmark(item.url) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.iconEmoji,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 13.sp,
                                color = KiyoseVermilion,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.url,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { onDeleteBookmark(item.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "削除",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 6. History Sheet (履歴)
// ----------------------------------------------------------------------------
@Composable
fun HistorySheet(
    history: List<HistoryItem>,
    onSelectHistory: (String) -> Unit,
    onClearHistory: () -> Unit,
    onClose: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(history, searchQuery) {
        if (searchQuery.isBlank()) history
        else history.filter { it.title.contains(searchQuery, ignoreCase = true) || it.url.contains(searchQuery, ignoreCase = true) }
    }

    SheetModalContainer(title = "履歴", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("履歴を検索…", style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)) },
                    modifier = Modifier.weight(1f).height(44.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                    onClick = onClearHistory,
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(44.dp)
                ) {
                    Text("消去", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filtered) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectHistory(item.url) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.formattedTime,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.width(60.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.url,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    HorizontalDivider(color = KiyoseBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 7. Reading List (後で読む)
// ----------------------------------------------------------------------------
@Composable
fun ReadingListSheet(
    readingList: List<ReadingListItem>,
    onSelectArticle: (String) -> Unit,
    onRemoveItem: (String) -> Unit,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "後で読む (オフライン保存)", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "保存された記事は通信環境がない場所でも静かに読了できます。",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(readingList) { item ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(width = 0.5.dp, color = KiyoseBorder)
                            .clickable { onSelectArticle(item.url) }
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = item.savedTime,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = item.excerpt,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (item.isOfflineSaved) "● オフライン保存完了" else "オンラインのみ",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        color = if (item.isOfflineSaved) KiyoseRikyuGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Text(
                                    text = "削除",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = KiyoseVermilion),
                                    modifier = Modifier.clickable { onRemoveItem(item.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 8. Downloads Sheet (ダウンロード)
// ----------------------------------------------------------------------------
@Composable
fun DownloadsSheet(
    downloads: List<DownloadItem>,
    onToggleStatus: (String) -> Unit,
    onRemove: (String) -> Unit,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "ダウンロード", onClose = onClose) {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            items(downloads) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.fileName,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${item.sizeText} ── ${item.status.label}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = if (item.status == DownloadStatus.COMPLETED) KiyoseRikyuGreen else KiyoseVermilion
                                )
                            )
                        }
                    }

                    if (item.status == DownloadStatus.IN_PROGRESS || item.status == DownloadStatus.PAUSED) {
                        IconButton(onClick = { onToggleStatus(item.id) }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = if (item.status == DownloadStatus.IN_PROGRESS) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "一時停止/再開",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    IconButton(onClick = { onRemove(item.id) }, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "削除", modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 9. Privacy Center & サイト権限 (Section 28, 29)
// ----------------------------------------------------------------------------
@Composable
fun PrivacyCenterSheet(
    permissions: Map<String, SitePermission>,
    extensions: List<BrowserExtension>,
    onToggleExtension: (String) -> Unit,
    onClose: () -> Unit
) {
    var trackingProtection by remember { mutableStateOf(true) }
    var thirdPartyCookies by remember { mutableStateOf(false) }
    var safeBrowsing by remember { mutableStateOf(true) }

    SheetModalContainer(title = "プライバシーとセキュリティ", onClose = onClose) {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            item {
                Text(
                    text = "ブラウザ保護状態",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("トラッキング防止", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp))
                                Text("広告・解析トラッカーを遮断", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                            Switch(
                                checked = trackingProtection,
                                onCheckedChange = { trackingProtection = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = KiyoseVermilion, checkedTrackColor = KiyoseVermilion.copy(alpha = 0.3f))
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = KiyoseBorder.copy(alpha = 0.3f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("危険サイト保護", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp))
                                Text("フィッシングおよび詐欺サイトを検知", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                            Switch(
                                checked = safeBrowsing,
                                onCheckedChange = { safeBrowsing = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = KiyoseVermilion, checkedTrackColor = KiyoseVermilion.copy(alpha = 0.3f))
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "拡張機能 (Extensions)",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium)
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            items(extensions) { ext ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(ext.name, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(ext.description, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("権限：${ext.permissions.joinToString("、")}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                        }
                        Switch(
                            checked = ext.isEnabled,
                            onCheckedChange = { onToggleExtension(ext.id) },
                            colors = SwitchDefaults.colors(checkedThumbColor = KiyoseVermilion, checkedTrackColor = KiyoseVermilion.copy(alpha = 0.3f))
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 10. Settings Sheet (外観・検索・フォント・UI密度)
// ----------------------------------------------------------------------------
@Composable
fun SettingsSheet(
    isDarkTheme: Boolean,
    uiDensity: UiDensity,
    currentSearchEngine: SearchEngine,
    onToggleDarkTheme: () -> Unit,
    onSelectUiDensity: (UiDensity) -> Unit,
    onSelectSearchEngine: (SearchEngine) -> Unit,
    onSimulateCrash: () -> Unit,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "設定 (Settings)", onClose = onClose) {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            item {
                Text("外観と配色", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ダークテーマ / 夜間墨", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp))
                            Text("温かみのある暗色パレット", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        }
                        Switch(
                            checked = isDarkTheme,
                            onCheckedChange = { onToggleDarkTheme() },
                            colors = SwitchDefaults.colors(checkedThumbColor = KiyoseVermilion, checkedTrackColor = KiyoseVermilion.copy(alpha = 0.3f))
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(18.dp))
                Text("UI密度 (Japanese UI density)", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    UiDensity.values().forEach { d ->
                        val isSelected = d == uiDensity
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                .border(width = 0.5.dp, color = KiyoseBorder)
                                .clickable { onSelectUiDensity(d) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = d.label,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 12.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(18.dp))
                Text("検索プロバイダー", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .border(width = 0.5.dp, color = KiyoseBorder)
                ) {
                    SearchEngine.values().forEach { engine ->
                        val isSelected = engine == currentSearchEngine
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectSearchEngine(engine) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(engine.displayName, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp))
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = KiyoseVermilion, modifier = Modifier.size(16.dp))
                            }
                        }
                        HorizontalDivider(color = KiyoseBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("診断と耐障害性テスト (Section 55)", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onSimulateCrash,
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("レンダラークラッシュをシミュレート (障害復元検証)", style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp, color = KiyoseVermilion))
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 11. Task Manager Sheet (ブラウザタスクマネージャー: Section 36)
// ----------------------------------------------------------------------------
@Composable
fun TaskManagerSheet(
    tabs: List<BrowserTab>,
    onClose: () -> Unit
) {
    val processes = remember(tabs) {
        val list = mutableListOf<TaskManagerProcess>()
        list.add(TaskManagerProcess("Browser (清瀬コアプロセス)", "Core", "1.2%", "142 MB"))
        list.add(TaskManagerProcess("GPU Process (グラフィックス)", "GPU", "2.8%", "196 MB"))
        list.add(TaskManagerProcess("Network Service (通信・暗号化)", "Network", "0.4%", "58 MB"))
        list.add(TaskManagerProcess("Extension: 静寂シールド", "Extension", "0.2%", "34 MB"))
        tabs.forEach { tab ->
            list.add(TaskManagerProcess("Tab: ${tab.title}", "Renderer", "${tab.cpuUsage}%", "${tab.memoryMb} MB", true, tab.id))
        }
        list
    }

    SheetModalContainer(title = "ブラウザタスクマネージャー", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("プロセス名", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), modifier = Modifier.weight(1f))
                Text("CPU", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), modifier = Modifier.width(50.dp))
                Text("メモリ", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), modifier = Modifier.width(60.dp))
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(processes) { p ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(p.type, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                        }
                        Text(p.cpuPercent, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp), modifier = Modifier.width(50.dp))
                        Text(p.memoryMb, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium), modifier = Modifier.width(60.dp))
                    }
                    HorizontalDivider(color = KiyoseBorder.copy(alpha = 0.2f), thickness = 0.5.dp)
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 12. Developer Tools Sheet (開発者ツール: Section 48)
// ----------------------------------------------------------------------------
@Composable
fun DevToolsSheet(
    logs: List<DevToolsEntry>,
    onClose: () -> Unit
) {
    var activeCategory by remember { mutableStateOf("すべて") }

    val filtered = remember(logs, activeCategory) {
        if (activeCategory == "すべて") logs
        else logs.filter { it.category == activeCategory }
    }

    SheetModalContainer(title = "開発者ツール (F12 Shell)", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("すべて", "コンソール", "ネットワーク", "セキュリティ", "パフォーマンス")) { cat ->
                    val isSelected = cat == activeCategory
                    Box(
                        modifier = Modifier
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                            .border(width = 0.5.dp, color = KiyoseBorder)
                            .clickable { activeCategory = cat }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            cat,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF141514))
                    .padding(8.dp)
            ) {
                items(filtered) { entry ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(
                            text = "[${entry.timestamp}]",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = Color(0xFF7A807C)),
                            modifier = Modifier.width(65.dp)
                        )
                        Text(
                            text = "[${entry.category}]",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = Color(0xFF4CA086)),
                            modifier = Modifier.width(75.dp)
                        )
                        Text(
                            text = entry.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                color = if (entry.level == "ERROR") Color(0xFFE56A60) else Color(0xFFD6DAD7)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 13. Security Info Sheet
// ----------------------------------------------------------------------------
@Composable
fun SecurityInfoSheet(
    url: String,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "ページのセキュリティ状態", onClose = onClose) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = KiyoseRikyuGreen, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("安全な接続 (TLS 1.3)", style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium))
                    Text("送信データは強力に暗号化されています", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = KiyoseBorder, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(16.dp))

            Text("証明書情報", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("発行先: ${url.substringAfter("://").substringBefore("/")}", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
            Text("暗号化方式: AES-256-GCM / SHA-384", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
            Text("トラッカー検出: 0件 (完全遮断中)", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
        }
    }
}

// ----------------------------------------------------------------------------
// 14. Overflow Menu Sheet (⋮ メニュー)
// ----------------------------------------------------------------------------
@Composable
fun OverflowMenuSheet(
    tab: BrowserTab,
    isPrivateMode: Boolean,
    isDarkTheme: Boolean,
    onOpenSheet: (ActiveSheet) -> Unit,
    onToggleBookmark: () -> Unit,
    onSaveReadingList: () -> Unit,
    onToggleReaderMode: () -> Unit,
    onToggleVerticalWriting: () -> Unit,
    onTogglePrivate: () -> Unit,
    onCaptureScreenshot: () -> Unit,
    onSelectWebMode: (JapaneseWebMode) -> Unit,
    onClose: () -> Unit
) {
    SheetModalContainer(title = "清瀬 メニュー", onClose = onClose) {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            item {
                // Quick actions grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MenuItemCard(
                        title = "ブックマーク追加",
                        icon = Icons.Default.Bookmark,
                        onClick = { onToggleBookmark(); onClose() },
                        modifier = Modifier.weight(1f)
                    )
                    MenuItemCard(
                        title = "後で読む",
                        icon = Icons.Default.MenuBook,
                        onClick = { onSaveReadingList(); onClose() },
                        modifier = Modifier.weight(1f)
                    )
                    MenuItemCard(
                        title = if (tab.isReaderMode) "通常表示" else "リーダー表示",
                        icon = Icons.Default.Visibility,
                        onClick = { onToggleReaderMode(); onClose() },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = KiyoseBorder, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))
            }

            item {
                Text("日本語 Web モード", style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp))
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    JapaneseWebMode.values().take(4).forEach { mode ->
                        val isCurrent = tab.webMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                .border(width = 0.5.dp, color = KiyoseBorder)
                                .clickable { onSelectWebMode(mode); onClose() }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                mode.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = KiyoseBorder, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(10.dp))
            }

            item {
                MenuRowItem(title = "研究スペース (Workspaces)", onClick = { onOpenSheet(ActiveSheet.RESEARCH_WORKSPACE) })
                MenuRowItem(title = "ブックマーク一覧", onClick = { onOpenSheet(ActiveSheet.BOOKMARKS) })
                MenuRowItem(title = "履歴", onClick = { onOpenSheet(ActiveSheet.HISTORY) })
                MenuRowItem(title = "後で読むリスト", onClick = { onOpenSheet(ActiveSheet.READING_LIST) })
                MenuRowItem(title = "ダウンロード", onClick = { onOpenSheet(ActiveSheet.DOWNLOADS) })
                MenuRowItem(title = "プライバシー・拡張機能", onClick = { onOpenSheet(ActiveSheet.PRIVACY_CENTER) })
                MenuRowItem(title = "ブラウザタスクマネージャー", onClick = { onOpenSheet(ActiveSheet.TASK_MANAGER) })
                MenuRowItem(title = "開発者ツール (F12)", onClick = { onOpenSheet(ActiveSheet.DEV_TOOLS) })
                MenuRowItem(title = "スクリーンショット撮影", onClick = { onCaptureScreenshot(); onClose() })
                MenuRowItem(
                    title = if (isPrivateMode) "通常ブラウジングに戻る" else "プライベートブラウジング",
                    onClick = { onTogglePrivate(); onClose() },
                    isAccent = isPrivateMode
                )
                MenuRowItem(title = "設定", onClick = { onOpenSheet(ActiveSheet.SETTINGS) })
            }
        }
    }
}

@Composable
private fun MenuItemCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(2.dp))
            .border(width = 0.5.dp, color = KiyoseBorder, shape = RoundedCornerShape(2.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = null, tint = KiyoseVermilion, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), maxLines = 1)
        }
    }
}

@Composable
private fun MenuRowItem(
    title: String,
    onClick: () -> Unit,
    isAccent: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                color = if (isAccent) KiyoseVermilion else MaterialTheme.colorScheme.onSurface
            )
        )
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(12.dp)
        )
    }
    HorizontalDivider(color = KiyoseBorder.copy(alpha = 0.2f), thickness = 0.5.dp)
}
