package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.model.SearchEngine
import com.example.ui.theme.KiyoseBorder
import com.example.ui.theme.KiyoseVermilion

@Composable
fun BrowserAddressBar(
    tab: BrowserTab,
    inputText: String,
    searchEngine: SearchEngine,
    onInputChanged: (String) -> Unit,
    onSubmit: (String) -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onBackClick: () -> Unit,
    onForwardClick: () -> Unit,
    onReloadClick: () -> Unit,
    onToggleReaderMode: () -> Unit,
    onToggleAI: () -> Unit,
    onMenuClick: () -> Unit,
    onSecurityClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .border(width = 0.5.dp, color = KiyoseBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Navigation: Back
            IconButton(
                onClick = onBackClick,
                enabled = tab.canGoBack,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "戻る",
                    tint = if (tab.canGoBack) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                    modifier = Modifier.size(16.dp)
                )
            }

            // Navigation: Forward
            IconButton(
                onClick = onForwardClick,
                enabled = tab.canGoForward,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_forward_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "進む",
                    tint = if (tab.canGoForward) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                    modifier = Modifier.size(16.dp)
                )
            }

            // Navigation: Reload
            IconButton(
                onClick = onReloadClick,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_reload_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "再読み込み",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Universal Address Bar Field
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .background(
                        MaterialTheme.colorScheme.background,
                        shape = RoundedCornerShape(2.dp) // Very gentle corner, precision instrument style
                    )
                    .border(
                        width = 0.8.dp,
                        color = KiyoseBorder,
                        shape = RoundedCornerShape(2.dp)
                    )
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Security indicator
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "安全な接続",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier
                            .size(13.dp)
                            .clickable { onSecurityClick() }
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Input Text Field with full Japanese IME support
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (inputText.isEmpty()) {
                            Text(
                                text = "検索またはURLを入力",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                ),
                                maxLines = 1
                            )
                        }

                        BasicTextField(
                            value = inputText,
                            onValueChange = onInputChanged,
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { state -> onFocusChanged(state.isFocused) }
                                .testTag("universal_address_input"),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Normal
                            ),
                            cursorBrush = SolidColor(KiyoseVermilion),
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Go,
                                autoCorrectEnabled = false
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = { onSubmit(inputText) }
                            )
                        )
                    }

                    // Clear button when typing
                    if (inputText.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "入力を消去",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onInputChanged("") }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    // Reader Mode Quick Toggle inside address bar
                    if (tab.url != "about:home") {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "リーダーモード切替",
                            tint = if (tab.isReaderMode) KiyoseVermilion
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(15.dp)
                                .clickable { onToggleReaderMode() }
                                .testTag("address_bar_reader_toggle")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // AI Trigger Button (Ctrl+Space equivalent)
            IconButton(
                onClick = onToggleAI,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("ai_trigger_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "清瀬 AI",
                    tint = KiyoseVermilion,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Overflow Menu Button
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("browser_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "メニュー",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(17.dp)
                )
            }
        }

        // Thin loading bar at the very bottom of address bar
        if (tab.isLoading) {
            LinearProgressIndicator(
                progress = { tab.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.5.dp)
                    .align(Alignment.BottomCenter),
                color = KiyoseVermilion,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
