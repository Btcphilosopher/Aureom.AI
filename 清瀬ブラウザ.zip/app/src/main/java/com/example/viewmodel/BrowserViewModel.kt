package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AIProvider
import com.example.ai.QuietLocalAIProvider
import com.example.data.BrowserRepository
import com.example.engine.JapaneseContentLibrary
import com.example.model.AIAnalysisResult
import com.example.model.BookmarkCategory
import com.example.model.BookmarkItem
import com.example.model.BrowserExtension
import com.example.model.BrowserTab
import com.example.model.DevToolsEntry
import com.example.model.DownloadItem
import com.example.model.HistoryItem
import com.example.model.JapaneseWebMode
import com.example.model.ReaderArticle
import com.example.model.ReadingListItem
import com.example.model.ResearchWorkspace
import com.example.model.SearchEngine
import com.example.model.SitePermission
import com.example.model.TaskManagerProcess
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.UUID

enum class ActiveSheet {
    NONE,
    TAB_SWITCHER,
    BOOKMARKS,
    HISTORY,
    READING_LIST,
    DOWNLOADS,
    PRIVACY_CENTER,
    SECURITY_INFO,
    SETTINGS,
    TASK_MANAGER,
    DEV_TOOLS,
    RESEARCH_WORKSPACE,
    AI_PANEL,
    SEARCH_SUGGESTIONS
}

enum class UiDensity(val label: String) {
    STANDARD("標準"),
    COMPACT("コンパクト"),
    SPACIOUS("ゆったり")
}

enum class ReaderTheme(val label: String, val bgHex: Long, val textHex: Long) {
    WARM_WHITE("和紙白", 0xFFF7F6F2, 0xFF202322),
    SEIJI_MIST("薄青磁", 0xFFEFF3F1, 0xFF1E2824),
    QUIET_DARK("夜間墨", 0xFF1A1C1B, 0xFFE0E2DE)
}

data class ReaderSettings(
    val fontSizeSp: Int = 16,
    val lineHeightMultiplier: Float = 1.8f,
    val useSerif: Boolean = true, // Noto Serif JP
    val isVerticalWriting: Boolean = false,
    val theme: ReaderTheme = ReaderTheme.WARM_WHITE
)

class BrowserViewModel(
    val repository: BrowserRepository = BrowserRepository(),
    val aiProvider: AIProvider = QuietLocalAIProvider()
) : ViewModel() {

    // Tabs
    private val initialTab = BrowserTab(
        id = UUID.randomUUID().toString(),
        title = "清瀬",
        url = "about:home",
        webMode = JapaneseWebMode.STANDARD
    )
    private val _tabs = MutableStateFlow<List<BrowserTab>>(listOf(initialTab))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(initialTab.id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    // Closed tabs stack for recovery
    private val closedTabsStack = mutableListOf<BrowserTab>()

    // Current search engine
    private val _currentSearchEngine = MutableStateFlow(SearchEngine.YAHOO_JAPAN)
    val currentSearchEngine: StateFlow<SearchEngine> = _currentSearchEngine.asStateFlow()

    // Address Bar input
    private val _urlInputText = MutableStateFlow("")
    val urlInputText: StateFlow<String> = _urlInputText.asStateFlow()

    private val _isAddressBarFocused = MutableStateFlow(false)
    val isAddressBarFocused: StateFlow<Boolean> = _isAddressBarFocused.asStateFlow()

    // Reader Mode settings
    private val _readerSettings = MutableStateFlow(ReaderSettings())
    val readerSettings: StateFlow<ReaderSettings> = _readerSettings.asStateFlow()

    // Sheets / Dialogs
    private val _activeSheet = MutableStateFlow(ActiveSheet.NONE)
    val activeSheet: StateFlow<ActiveSheet> = _activeSheet.asStateFlow()

    // Settings
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _uiDensity = MutableStateFlow(UiDensity.STANDARD)
    val uiDensity: StateFlow<UiDensity> = _uiDensity.asStateFlow()

    private val _isPrivateMode = MutableStateFlow(false)
    val isPrivateMode: StateFlow<Boolean> = _isPrivateMode.asStateFlow()

    // AI State
    private val _aiResult = MutableStateFlow<AIAnalysisResult?>(null)
    val aiResult: StateFlow<AIAnalysisResult?> = _aiResult.asStateFlow()

    private val _aiIsLoading = MutableStateFlow(false)
    val aiIsLoading: StateFlow<Boolean> = _aiIsLoading.asStateFlow()

    private val _aiQnaHistory = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val aiQnaHistory: StateFlow<List<Pair<String, String>>> = _aiQnaHistory.asStateFlow()

    // Crash Simulation state
    private val _crashedTabId = MutableStateFlow<String?>(null)
    val crashedTabId: StateFlow<String?> = _crashedTabId.asStateFlow()

    private val _browserCrashModal = MutableStateFlow(false)
    val browserCrashModal: StateFlow<Boolean> = _browserCrashModal.asStateFlow()

    // Selected tabs for multi-page comparison
    private val _selectedTabIdsForCompare = MutableStateFlow<Set<String>>(emptySet())
    val selectedTabIdsForCompare: StateFlow<Set<String>> = _selectedTabIdsForCompare.asStateFlow()

    // Toast notification
    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    // Repository flows
    val bookmarks = repository.bookmarks
    val history = repository.history
    val readingList = repository.readingList
    val downloads = repository.downloads
    val workspaces = repository.workspaces
    val extensions = repository.extensions
    val sitePermissions = repository.sitePermissions
    val devToolsLogs = repository.devToolsLogs

    // Search query suggestions candidates
    val suggestions: StateFlow<List<String>> = combine(_urlInputText, _isAddressBarFocused) { text, focused ->
        if (!focused || text.isBlank()) {
            emptyList()
        } else {
            val q = text.trim()
            val baseList = listOf(
                q,
                "$q 天気",
                "$q ニュース",
                "$q 最新動向",
                "$q 概要",
                "$q 比較",
                "$q 公式"
            )
            baseList.take(5)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeTab: BrowserTab
        get() = _tabs.value.find { it.id == _activeTabId.value } ?: _tabs.value.first()

    private var navigationJob: Job? = null

    init {
        // Initial sync of url
        _urlInputText.value = if (activeTab.url == "about:home") "" else activeTab.url
    }

    fun showNotice(msg: String) {
        _statusNotice.value = msg
        viewModelScope.launch {
            delay(2400)
            if (_statusNotice.value == msg) {
                _statusNotice.value = null
            }
        }
    }

    fun openSheet(sheet: ActiveSheet) {
        _activeSheet.value = sheet
    }

    fun closeSheet() {
        _activeSheet.value = ActiveSheet.NONE
    }

    fun setAddressBarFocused(focused: Boolean) {
        _isAddressBarFocused.value = focused
        if (focused && activeTab.url != "about:home") {
            _urlInputText.value = activeTab.url
        }
    }

    fun updateUrlInput(text: String) {
        _urlInputText.value = text
    }

    fun openTab(url: String = "about:home", title: String = "清瀬", isPrivate: Boolean = _isPrivateMode.value) {
        val newTab = BrowserTab(
            id = UUID.randomUUID().toString(),
            title = title,
            url = url,
            isPrivate = isPrivate,
            memoryMb = 135
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
        _urlInputText.value = if (url == "about:home") "" else url
        if (url != "about:home") {
            loadUrl(url)
        }
        closeSheet()
    }

    fun selectTab(tabId: String) {
        _activeTabId.value = tabId
        val tab = _tabs.value.find { it.id == tabId } ?: return
        _urlInputText.value = if (tab.url == "about:home") "" else tab.url
        closeSheet()
    }

    fun closeTab(tabId: String) {
        val currentList = _tabs.value
        val tabToClose = currentList.find { it.id == tabId }
        if (tabToClose != null) {
            closedTabsStack.add(tabToClose)
        }

        if (currentList.size <= 1) {
            // Keep at least one tab
            val fresh = BrowserTab(
                id = UUID.randomUUID().toString(),
                title = "清瀬",
                url = "about:home",
                isPrivate = _isPrivateMode.value
            )
            _tabs.value = listOf(fresh)
            _activeTabId.value = fresh.id
            _urlInputText.value = ""
            return
        }

        val filtered = currentList.filter { it.id != tabId }
        _tabs.value = filtered
        if (_activeTabId.value == tabId) {
            val nextTab = filtered.last()
            _activeTabId.value = nextTab.id
            _urlInputText.value = if (nextTab.url == "about:home") "" else nextTab.url
        }
    }

    fun restoreClosedTab() {
        if (closedTabsStack.isNotEmpty()) {
            val restored = closedTabsStack.removeAt(closedTabsStack.size - 1)
            _tabs.value = _tabs.value + restored
            _activeTabId.value = restored.id
            showNotice("閉じたタブを復元しました：${restored.title}")
        }
    }

    fun submitAddressBar(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        setAddressBarFocused(false)

        val targetUrl = resolveInputToUrl(trimmed)
        loadUrl(targetUrl)
    }

    private fun resolveInputToUrl(input: String): String {
        // Quick bang commands
        if (input.startsWith("!ニュース") || input.startsWith("!n")) {
            val query = input.substringAfter(" ").trim()
            return "https://news.yahoo.co.jp/search?p=${urlEncode(query)}"
        }
        if (input.startsWith("!w") || input.startsWith("!wiki")) {
            val query = input.substringAfter(" ").trim()
            return "https://ja.wikipedia.org/wiki/${urlEncode(query)}"
        }
        if (input.startsWith("!g")) {
            val query = input.substringAfter(" ").trim()
            return "https://www.google.com/search?q=${urlEncode(query)}"
        }

        // Check if looks like a valid URL
        val hasScheme = input.startsWith("http://") || input.startsWith("https://")
        val looksLikeDomain = input.contains(".") && !input.contains(" ") && !input.contains("　")

        return when {
            hasScheme -> input
            looksLikeDomain -> "https://$input"
            else -> {
                val encoded = urlEncode(input)
                String.format(_currentSearchEngine.value.queryUrl, encoded)
            }
        }
    }

    private fun urlEncode(str: String): String {
        return try {
            URLEncoder.encode(str, "UTF-8")
        } catch (e: Exception) {
            str
        }
    }

    fun loadUrl(url: String) {
        val currentId = _activeTabId.value
        navigationJob?.cancel()

        val resolvedArticle = JapaneseContentLibrary.getArticleForUrl(url)
        val title = resolvedArticle.title

        // Update tab immediately to loading
        updateTab(currentId) {
            it.copy(
                url = url,
                title = title,
                isLoading = true,
                progress = 0.2f,
                canGoBack = true,
                readerArticle = resolvedArticle
            )
        }
        _urlInputText.value = url

        // Log DevTools Network
        repository.logDevTools("ネットワーク", "INFO", "ナビゲーション開始: $url")

        navigationJob = viewModelScope.launch {
            delay(150)
            updateTab(currentId) { it.copy(progress = 0.65f) }
            delay(200)
            updateTab(currentId) {
                it.copy(
                    isLoading = false,
                    progress = 1.0f,
                    title = resolvedArticle.title,
                    readerArticle = resolvedArticle
                )
            }

            // Save to history if not in private mode
            if (!_isPrivateMode.value) {
                repository.addHistory(title, url)
            }
            repository.logDevTools("ネットワーク", "INFO", "ページ読み込み完了: 200 OK (220ms)")
        }
    }

    fun reloadActiveTab() {
        val tab = activeTab
        if (tab.url != "about:home") {
            loadUrl(tab.url)
        }
    }

    fun goBackActiveTab() {
        val tab = activeTab
        if (tab.canGoBack) {
            updateTab(tab.id) {
                it.copy(
                    url = "about:home",
                    title = "清瀬",
                    canGoBack = false,
                    canGoForward = true
                )
            }
            _urlInputText.value = ""
        }
    }

    fun goForwardActiveTab() {
        // Simple return forward
        val tab = activeTab
        if (tab.canGoForward && tab.readerArticle != null) {
            loadUrl(tab.readerArticle.siteName)
        }
    }

    fun toggleReaderMode() {
        val tab = activeTab
        val newMode = !tab.isReaderMode
        updateTab(tab.id) {
            it.copy(isReaderMode = newMode)
        }
        showNotice(if (newMode) "リーダーモードを開始しました" else "通常表示に戻りました")
    }

    fun toggleVerticalWriting() {
        val current = _readerSettings.value.isVerticalWriting
        _readerSettings.value = _readerSettings.value.copy(isVerticalWriting = !current)
        showNotice(if (!current) "縦書き組版モードに切り替えました" else "横書き組版モードに切り替えました")
    }

    fun updateReaderSettings(transform: (ReaderSettings) -> ReaderSettings) {
        _readerSettings.value = transform(_readerSettings.value)
    }

    fun setJapaneseWebMode(mode: JapaneseWebMode) {
        val tab = activeTab
        updateTab(tab.id) { it.copy(webMode = mode) }
        showNotice("表示モード：${mode.label} を適用しました")
    }

    // AI actions
    fun triggerAISummary() {
        val tab = activeTab
        val article = tab.readerArticle ?: JapaneseContentLibrary.getArticleForUrl(tab.url)
        _aiIsLoading.value = true
        _activeSheet.value = ActiveSheet.AI_PANEL

        viewModelScope.launch {
            try {
                val res = aiProvider.summarizeArticle(tab, article)
                _aiResult.value = res
            } catch (e: Exception) {
                showNotice("AI処理中にエラーが発生しました")
            } finally {
                _aiIsLoading.value = false
            }
        }
    }

    fun triggerAIMetricsExtraction() {
        val tab = activeTab
        val article = tab.readerArticle ?: JapaneseContentLibrary.getArticleForUrl(tab.url)
        _aiIsLoading.value = true
        _activeSheet.value = ActiveSheet.AI_PANEL

        viewModelScope.launch {
            try {
                val res = aiProvider.extractKeyMetrics(tab, article)
                _aiResult.value = res
            } finally {
                _aiIsLoading.value = false
            }
        }
    }

    fun triggerAITranslation(targetLanguage: String = "英語") {
        val tab = activeTab
        val article = tab.readerArticle ?: JapaneseContentLibrary.getArticleForUrl(tab.url)
        _aiIsLoading.value = true
        _activeSheet.value = ActiveSheet.AI_PANEL

        viewModelScope.launch {
            try {
                val pair = aiProvider.translateText(article.paragraphs.firstOrNull() ?: article.title, targetLanguage)
                _aiResult.value = AIAnalysisResult(
                    actionType = "二言語対訳 ($targetLanguage)",
                    title = "対訳：${article.title}",
                    summaryPoints = listOf("原文と翻訳を上下に並置して表示しています。"),
                    keyDataPoints = emptyList(),
                    sourceTitle = article.siteName,
                    sourceUrl = tab.url,
                    translationOriginal = pair.first,
                    translationTarget = pair.second
                )
            } finally {
                _aiIsLoading.value = false
            }
        }
    }

    fun triggerAICompareSelectedTabs() {
        val selected = _tabs.value.filter { _selectedTabIdsForCompare.value.contains(it.id) }
        val targets = if (selected.size >= 2) selected else _tabs.value.take(3)
        val tabPairs = targets.map { tab ->
            Pair(tab, tab.readerArticle ?: JapaneseContentLibrary.getArticleForUrl(tab.url))
        }

        _aiIsLoading.value = true
        _activeSheet.value = ActiveSheet.AI_PANEL

        viewModelScope.launch {
            try {
                val res = aiProvider.compareTabs(tabPairs)
                _aiResult.value = res
            } finally {
                _aiIsLoading.value = false
            }
        }
    }

    fun askAIQuestion(question: String) {
        val tab = activeTab
        val article = tab.readerArticle ?: JapaneseContentLibrary.getArticleForUrl(tab.url)
        _aiIsLoading.value = true

        viewModelScope.launch {
            try {
                val ans = aiProvider.askQuestion(article, question)
                _aiQnaHistory.value = _aiQnaHistory.value + Pair(question, ans)
            } finally {
                _aiIsLoading.value = false
            }
        }
    }

    fun toggleTabComparisonSelection(tabId: String) {
        val current = _selectedTabIdsForCompare.value.toMutableSet()
        if (current.contains(tabId)) current.remove(tabId) else current.add(tabId)
        _selectedTabIdsForCompare.value = current
    }

    fun bookmarkCurrentTab() {
        val tab = activeTab
        repository.addBookmark(tab.title, tab.url, BookmarkCategory.WORK)
        showNotice("ブックマークに登録しました")
    }

    fun saveCurrentToReadingList() {
        val tab = activeTab
        val excerpt = tab.readerArticle?.leadText ?: "保存済みWebページ"
        repository.addToReadingList(tab.title, tab.url, excerpt)
        showNotice("後で読むリストに追加しました")
    }

    fun addNoteToWorkspace(workspaceId: String, quote: String, comment: String) {
        val tab = activeTab
        repository.addWorkspaceNote(workspaceId, tab.title, tab.url, quote, comment)
        showNotice("研究スペースに引用メモを記録しました")
    }

    fun togglePrivateMode() {
        val newMode = !_isPrivateMode.value
        _isPrivateMode.value = newMode
        showNotice(if (newMode) "プライベートブラウジングを開始しました" else "通常ブラウジングに戻りました")
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setUiDensity(density: UiDensity) {
        _uiDensity.value = density
    }

    fun setSearchEngine(engine: SearchEngine) {
        _currentSearchEngine.value = engine
        showNotice("検索プロバイダーを ${engine.displayName} に設定しました")
    }

    // Crash simulation (Section 55)
    fun simulateRendererCrash() {
        _crashedTabId.value = activeTab.id
        repository.logDevTools("システム", "ERROR", "Rendererプロセス異常終了 (SIGSEGVシミュレーション)")
    }

    fun recoverCrashedTab() {
        val id = _crashedTabId.value
        if (id != null) {
            _crashedTabId.value = null
            reloadActiveTab()
            showNotice("タブのレンダラープロセスを再起動しました")
        }
    }

    fun simulateBrowserCrash() {
        _browserCrashModal.value = true
    }

    fun restoreFullSession() {
        _browserCrashModal.value = false
        showNotice("前回のセッション（${_tabs.value.size}個のタブ）を復元しました")
    }

    fun captureScreenshot() {
        showNotice("画面の精密スクリーンショットを撮影しました")
    }

    private fun updateTab(tabId: String, transform: (BrowserTab) -> BrowserTab) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == tabId) transform(tab) else tab
        }
    }
}
