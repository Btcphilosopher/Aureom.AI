package com.example.engine

import com.example.model.BrowserTab
import com.example.model.DevToolsEntry
import com.example.model.JapaneseWebMode
import com.example.model.ReaderArticle
import kotlinx.coroutines.flow.StateFlow

interface BrowserEngine {
    val engineName: String
    val version: String
    
    fun navigateTo(tabId: String, url: String)
    fun reload(tabId: String)
    fun stopLoading(tabId: String)
    fun goBack(tabId: String)
    fun goForward(tabId: String)
    fun setWebMode(tabId: String, mode: JapaneseWebMode)
    fun extractReaderArticle(tabId: String): ReaderArticle?
    fun simulateCrash(tabId: String)
}

/**
 * Japanese Knowledge Base & Built-in High-Fidelity Content Library
 * Supports offline-first deep reading, typography inspection, and vertical layout.
 */
object JapaneseContentLibrary {
    val ARTICLES = mapOf(
        "https://www.boj.or.jp" to ReaderArticle(
            title = "日本銀行：金融政策決定会合における声明と展望",
            author = "日本銀行 企画局",
            date = "2026年10月6日",
            siteName = "日本銀行 (Bank of Japan)",
            leadText = "わが国の経済は、所得から支出への前向きな循環メカニズムが徐々に強まるもとで、緩やかに回復している。",
            paragraphs = listOf(
                "日本銀行は本日、政策委員会・金融政策決定会合において、次回金融政策決定会合までの金融市場調節方針を決定した。無担保コールレート（オーバーナイト物）を0.50％程度で推移するよう促す。",
                "わが国の景気は、一部に弱めの動きも見られるが、緩やかに回復している。海外経済は、成長ペースの鈍化が続いているものの、全体として持ち直しの動きがみられる。",
                "設備投資は、企業収益の改善や脱炭素・デジタル関連投資の増加を背景に、緩やかな増加傾向にある。個人消費は、物価高の影響を受けつつも、賃上げの定着を反映して底堅く推移している。",
                "消費者物価（除く生鮮食品）の前年比は、政府によるエネルギー価格激変緩和対策の縮小や、原材料費・人件費の価格転嫁の進展により、2％程度で推移している。中長期的な予想物価上昇率は高まっている。"
            ),
            quotes = listOf(
                "「物価安定の目標のもとで、持続的・安定的な2％の実現を見極めつつ、適切な金融政策運営を行う」"
            ),
            keyMetrics = listOf(
                "政策金利誘導目標" to "0.50% 程度",
                "コアCPI見通し" to "+2.1%",
                "実質GDP成長率" to "+0.9%",
                "賃上げ率（春闘）" to "+5.2%"
            )
        ),
        "https://www.u-tokyo.ac.jp" to ReaderArticle(
            title = "東京大学：次世代量子コンピューティングと物性科学の融合",
            author = "先端科学技術研究センター 量子情報工学研究室",
            date = "2026年9月28日",
            siteName = "東京大学 (The University of Tokyo)",
            leadText = "超伝導量子ビットの集積化におけるコヒーレンス時間の大幅な延伸に成功。実用化に向けた新たな道筋を示す。",
            paragraphs = listOf(
                "東京大学先端科学技術研究センターの研究グループは、極低温希釈冷凍機内におけるノイズ抑制材料を新設計し、超伝導量子ビットのエラー率を従来比で1桁低減することに成功した。",
                "本成果は、誤り訂正機能付き量子コンピュータ（FTQC）の早期実現に向けた決定的な進展である。シリコン量子ドット技術とのハイブリッド化も視野に入れ、多ビット制御回路の集積を進めている。",
                "計算機科学と物性物理学の境界領域において、日本の精密加工技術と材料科学の強みが発揮された例と言える。国内外の研究機関とのオープンコラボレーションを推進していく。"
            ),
            quotes = listOf(
                "「物理的限界とされてきた熱雑音の制御を、ナノスケール構造の最適化で乗り越えた」"
            ),
            keyMetrics = listOf(
                "コヒーレンス時間" to "1.2 ms (従来比4倍)",
                "ゲート忠実度" to "99.94%",
                "動作温度" to "15 mK"
            )
        ),
        "https://www.nikkei.com" to ReaderArticle(
            title = "日本の半導体産業：後工程の自動化と先端パッケージング戦略",
            author = "日本経済新聞 産業部 特別取材班",
            date = "2026年10月5日",
            siteName = "日本経済新聞 (Nikkei)",
            leadText = "前工程の微細化限界が迫る中、チップレット技術と日本の素材・製造装置産業の集積が世界から再評価されている。",
            paragraphs = listOf(
                "AI半導体の急激な需要拡大により、複数の異なる半導体チップを基板上に高密度配置する「先端パッケージング（後工程）」が覇権を握る鍵となっている。",
                "日本企業は、封止材、感光性フィルム、ダイシングソーなどの後工程部材・装置市場において世界シェアの7割超を占める。北海道や熊本での量産拠点新設に伴い、国内サプライチェーンの再構築が加速している。",
                "政府は次世代半導体基盤の整備に向けて大規模な補助金を投じており、研究開発コンソーシアムの活動も本格化している。今後の焦点は設計人材の育成と電力インフラの確保である。"
            ),
            quotes = listOf(
                "「後工程こそが、ムーアの法則を超えた性能向上をもたらす主戦場である」"
            ),
            keyMetrics = listOf(
                "先端パッケージ市場予測" to "2030年 12兆円",
                "日本企業の部材シェア" to "約 72%",
                "官民投資総額" to "4.8 兆円"
            )
        ),
        "https://github.com" to ReaderArticle(
            title = "オープンソース開発と現代ソフトウェア工学の潮流",
            author = "オープンイノベーション推進協議会",
            date = "2026年10月2日",
            siteName = "GitHub Japan (GitHub)",
            leadText = "ソフトウェアサプライチェーンの安全保障と、開発者体験（DX）を最優先にしたアーキテクチャの革新。",
            paragraphs = listOf(
                "現代のソフトウェア開発において、OSSの利用率は90%を超えている。一方で依存関係の深層化に伴うセキュリティリスクも顕在化しており、SBOM（ソフトウェア部品表）の自動化が国際標準となっている。",
                "静的型付け言語（Rust, Kotlin, TypeScript）の普及と、メモリ安全性への意識の高まりが、オペレーティングシステムからブラウザ、分散データベースに至る基幹ソフトウェアの再設計を促している。",
                "チーム開発における予測可能性とコード品質の担保は、自動化されたテスト体系とレビュー文化によって支えられている。"
            ),
            quotes = listOf(
                "「速く動かすこと以上に、安全に持続できる設計がプロフェッショナルの条件である」"
            ),
            keyMetrics = listOf(
                "利用OSS依存度" to "94%",
                "メモリ安全言語採用率" to "78%",
                "CI/CD自動化率" to "92%"
            )
        ),
        "https://ja.wikipedia.org" to ReaderArticle(
            title = "清瀬市：武蔵野の雑木林と近郊農業の歴史",
            author = "ウィキペディア日本語版 編纂委員会",
            date = "2026年9月15日",
            siteName = "Wikipedia 日本語版",
            leadText = "東京都多摩地域北東部に位置し、柳瀬川の清流と武蔵野の豊かな自然を残す緑豊かな都市。",
            paragraphs = listOf(
                "清瀬（きよせ）の地名は、市内を流れる柳瀬川の「清らかな流れの瀬」に由来するとされる。かつては結核療養のサナトリウムが多く置かれ、清澄な空気と緑地が医学的にも評価された。",
                "武蔵野台地の北部に位置し、人参やホウレンソウなどの近郊農業が盛んである。台地特有の関東ローム層に覆われ、平坦で住みやすい地形を形成している。",
                "現在では、静かな住環境と都心へのアクセス性を兼ね備えた住宅都市として発展しつつ、雑木林の保全活動など自然との共生が図られている。"
            ),
            quotes = listOf(
                "「清き瀬の水の流れの末遠く、緑の森に鳥の音すなり」"
            ),
            keyMetrics = listOf(
                "面積" to "10.23 km²",
                "緑被率" to "約 31%",
                "標高" to "約 45 - 65 m"
            )
        )
    )

    fun getArticleForUrl(url: String): ReaderArticle {
        // Match base domain or provide dynamic simulated Japanese article
        val cleanUrl = url.lowercase()
        return when {
            cleanUrl.contains("boj.or.jp") || cleanUrl.contains("日本銀行") -> ARTICLES["https://www.boj.or.jp"]!!
            cleanUrl.contains("u-tokyo.ac.jp") || cleanUrl.contains("東京大学") -> ARTICLES["https://www.u-tokyo.ac.jp"]!!
            cleanUrl.contains("nikkei.com") || cleanUrl.contains("日経") -> ARTICLES["https://www.nikkei.com"]!!
            cleanUrl.contains("github.com") -> ARTICLES["https://github.com"]!!
            cleanUrl.contains("wikipedia.org") || cleanUrl.contains("清瀬") -> ARTICLES["https://ja.wikipedia.org"]!!
            else -> {
                val host = url.substringAfter("://").substringBefore("/")
                ReaderArticle(
                    title = "Web ドキュメント：${if (host.isNotEmpty()) host else "閲覧ページ"}",
                    author = "清瀬ブラウザ リーダーエンジン",
                    date = "2026年10月9日",
                    siteName = if (host.isNotEmpty()) host else "ウェブドキュメント",
                    leadText = "日本語の可読性と静寂を優先し、本文テキストを美しく再構成しました。",
                    paragraphs = listOf(
                        "インターネット上の情報は、余白と適切な組版によってその真価を発揮します。過剰なバナーや広告を排し、内容そのものと静かに向き合う時間を提供します。",
                        "清瀬ブラウザは、Noto Sans JP と Noto Serif JP による禁則処理および文字間隔の最適化を実施しています。縦書きモードにもワンタップで切り替えることが可能です。",
                        "情報源のURL: $url を安全に保持し、研究スペースや読書リストに蓄積できます。"
                    ),
                    quotes = listOf("「機能そのものの精度によって高級感を作る」"),
                    keyMetrics = listOf(
                        "読みやすさ指標" to "99.8%",
                        "広告・トラッカー遮断" to "100%",
                        "フォント" to "Noto Serif JP"
                    )
                )
            }
        }
    }
}
