package com.example.model

enum class SearchEngine(val displayName: String, val queryUrl: String) {
    YAHOO_JAPAN("Yahoo! JAPAN", "https://search.yahoo.co.jp/search?p=%s"),
    GOOGLE("Google", "https://www.google.com/search?q=%s"),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
    BING("Bing", "https://www.bing.com/search?q=%s"),
    BRAVE("Brave Search", "https://search.brave.com/search?q=%s")
}

enum class JapaneseWebMode(val label: String, val description: String) {
    STANDARD("標準", "通常のWeb表示"),
    NEWS("ニュース", "記事本文と見出しを優先抽出"),
    SHOPPING("買い物", "価格と仕様を整理"),
    GOVERNMENT("政府・行政", "法令・公文書の読みやすさ向上"),
    RESEARCH("研究", "引用・メモ・比較に特化"),
    PDF("PDF", "文書閲覧と要約")
}

enum class PermissionState(val label: String) {
    DENIED("許可しない"),
    ASK("毎回確認"),
    ALLOWED("許可")
}

data class SitePermission(
    val host: String,
    val camera: PermissionState = PermissionState.DENIED,
    val microphone: PermissionState = PermissionState.DENIED,
    val location: PermissionState = PermissionState.ASK,
    val notifications: PermissionState = PermissionState.DENIED
)

data class BrowserTab(
    val id: String,
    val title: String = "新しいタブ",
    val url: String = "about:blank",
    val isLoading: Boolean = false,
    val progress: Float = 0f,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isPrivate: Boolean = false,
    val isReaderMode: Boolean = false,
    val isVerticalWriting: Boolean = false,
    val webMode: JapaneseWebMode = JapaneseWebMode.STANDARD,
    val cpuUsage: Float = 0.5f,
    val memoryMb: Int = 120,
    val readerArticle: ReaderArticle? = null
)

data class ReaderArticle(
    val title: String,
    val author: String,
    val date: String,
    val siteName: String,
    val leadText: String,
    val paragraphs: List<String>,
    val quotes: List<String> = emptyList(),
    val keyMetrics: List<Pair<String, String>> = emptyList()
)

data class HistoryItem(
    val id: String,
    val title: String,
    val url: String,
    val timestamp: Long,
    val formattedTime: String,
    val isToday: Boolean
)

enum class BookmarkCategory(val label: String) {
    ALL("すべて"),
    WORK("仕事"),
    RESEARCH("研究"),
    NEWS("ニュース"),
    READING("読書"),
    TRAVEL("旅行"),
    SHOPPING("買い物"),
    DEVELOPMENT("開発"),
    FINANCE("金融")
}

data class BookmarkItem(
    val id: String,
    val title: String,
    val url: String,
    val category: BookmarkCategory = BookmarkCategory.ALL,
    val dateAdded: String,
    val iconEmoji: String = "・"
)

data class ReadingListItem(
    val id: String,
    val title: String,
    val url: String,
    val savedTime: String,
    val excerpt: String,
    val isOfflineSaved: Boolean = true,
    val isRead: Boolean = false
)

enum class DownloadStatus(val label: String) {
    IN_PROGRESS("進行中"),
    COMPLETED("完了"),
    PAUSED("一時停止"),
    FAILED("エラー")
}

data class DownloadItem(
    val id: String,
    val fileName: String,
    val sizeText: String,
    val progress: Float,
    val status: DownloadStatus,
    val date: String
)

data class ResearchWorkspace(
    val id: String,
    val title: String,
    val description: String,
    val createdAt: String,
    val pages: List<WorkspacePage> = emptyList(),
    val notes: List<WorkspaceNote> = emptyList(),
    val aiSynthesis: String? = null
)

data class WorkspacePage(
    val id: String,
    val title: String,
    val url: String,
    val snippet: String
)

data class WorkspaceNote(
    val id: String,
    val pageTitle: String,
    val pageUrl: String,
    val quote: String,
    val userComment: String,
    val createdAt: String
)

data class TaskManagerProcess(
    val name: String,
    val type: String,
    val cpuPercent: String,
    val memoryMb: String,
    val isTab: Boolean = false,
    val tabId: String? = null
)

data class DevToolsEntry(
    val category: String, // コンソール, ネットワーク, セキュリティ, パフォーマンス
    val level: String,    // INFO, WARN, ERROR, LOG
    val timestamp: String,
    val message: String
)

data class BrowserExtension(
    val id: String,
    val name: String,
    val description: String,
    val version: String,
    val isEnabled: Boolean,
    val permissions: List<String>
)

data class AIAnalysisResult(
    val actionType: String,
    val title: String,
    val summaryPoints: List<String>,
    val keyDataPoints: List<Pair<String, String>>,
    val sourceTitle: String,
    val sourceUrl: String,
    val translationOriginal: String? = null,
    val translationTarget: String? = null
)
