package com.example.data

import com.example.model.BookmarkCategory
import com.example.model.BookmarkItem
import com.example.model.BrowserExtension
import com.example.model.DevToolsEntry
import com.example.model.DownloadItem
import com.example.model.DownloadStatus
import com.example.model.HistoryItem
import com.example.model.PermissionState
import com.example.model.ReadingListItem
import com.example.model.ResearchWorkspace
import com.example.model.SitePermission
import com.example.model.TaskManagerProcess
import com.example.model.WorkspaceNote
import com.example.model.WorkspacePage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BrowserRepository {

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.JAPAN)
    private val dateFormat = SimpleDateFormat("yyyy年MM月dd日", Locale.JAPAN)

    // Bookmarks
    private val _bookmarks = MutableStateFlow<List<BookmarkItem>>(
        listOf(
            BookmarkItem("b1", "日本銀行 金融政策", "https://www.boj.or.jp", BookmarkCategory.FINANCE, "2026/10/06", "日"),
            BookmarkItem("b2", "東京大学 先端科学技術", "https://www.u-tokyo.ac.jp", BookmarkCategory.RESEARCH, "2026/10/05", "東"),
            BookmarkItem("b3", "日本経済新聞 半導体", "https://www.nikkei.com", BookmarkCategory.NEWS, "2026/10/05", "経"),
            BookmarkItem("b4", "GitHub Japan", "https://github.com", BookmarkCategory.DEVELOPMENT, "2026/10/04", "G"),
            BookmarkItem("b5", "Wikipedia 清瀬市", "https://ja.wikipedia.org", BookmarkCategory.READING, "2026/10/03", "W"),
            BookmarkItem("b6", "Amazon Japan", "https://www.amazon.co.jp", BookmarkCategory.SHOPPING, "2026/10/02", "A"),
            BookmarkItem("b7", "国土交通省 都市計画", "https://www.mlit.go.jp", BookmarkCategory.WORK, "2026/10/01", "国"),
            BookmarkItem("b8", "JR東日本 列車運行情報", "https://www.jreast.co.jp", BookmarkCategory.TRAVEL, "2026/09/30", "鉄")
        )
    )
    val bookmarks: StateFlow<List<BookmarkItem>> = _bookmarks.asStateFlow()

    // History
    private val _history = MutableStateFlow<List<HistoryItem>>(
        listOf(
            HistoryItem("h1", "日本銀行：金融政策決定会合における声明と展望", "https://www.boj.or.jp", System.currentTimeMillis() - 1000 * 60 * 15, "10:42", true),
            HistoryItem("h2", "GitHub：現代ソフトウェア工学の潮流", "https://github.com", System.currentTimeMillis() - 1000 * 60 * 45, "10:18", true),
            HistoryItem("h3", "Wikipedia：清瀬市と武蔵野の歴史", "https://ja.wikipedia.org", System.currentTimeMillis() - 1000 * 60 * 80, "09:56", true),
            HistoryItem("h4", "東京大学：次世代量子コンピューティング研究", "https://www.u-tokyo.ac.jp", System.currentTimeMillis() - 1000 * 60 * 120, "09:20", true),
            HistoryItem("h5", "日本経済新聞：半導体先端パッケージング戦略", "https://www.nikkei.com", System.currentTimeMillis() - 1000 * 60 * 60 * 24, "昨日 17:30", false),
            HistoryItem("h6", "Yahoo! JAPAN 天気・ニュース", "https://www.yahoo.co.jp", System.currentTimeMillis() - 1000 * 60 * 60 * 25, "昨日 14:15", false)
        )
    )
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // Reading List (後で読む)
    private val _readingList = MutableStateFlow<List<ReadingListItem>>(
        listOf(
            ReadingListItem(
                id = "r1",
                title = "日本銀行 金融政策の行方と物価目標",
                url = "https://www.boj.or.jp",
                savedTime = "今日 10:42",
                excerpt = "所得から支出への前向きな循環メカニズムが徐々に強まるもとで…",
                isOfflineSaved = true
            ),
            ReadingListItem(
                id = "r2",
                title = "日本の先端パッケージング半導体市場 2030年予測",
                url = "https://www.nikkei.com",
                savedTime = "今日 09:12",
                excerpt = "後工程部材における日本企業のシェア7割。官民支援策の最新動向…",
                isOfflineSaved = true
            )
        )
    )
    val readingList: StateFlow<List<ReadingListItem>> = _readingList.asStateFlow()

    // Downloads
    private val _downloads = MutableStateFlow<List<DownloadItem>>(
        listOf(
            DownloadItem("d1", "boj_monetary_policy_2026.pdf", "2.4 MB", 1.0f, DownloadStatus.COMPLETED, "10:45"),
            DownloadItem("d2", "quantum_research_utokyo.pdf", "14.8 MB", 1.0f, DownloadStatus.COMPLETED, "09:25"),
            DownloadItem("d3", "kiyose_browser_source_linux.tar.gz", "85.2 MB", 0.65f, DownloadStatus.IN_PROGRESS, "10:50")
        )
    )
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    // Research Workspaces (研究スペース)
    private val _workspaces = MutableStateFlow<List<ResearchWorkspace>>(
        listOf(
            ResearchWorkspace(
                id = "w1",
                title = "日本のAI・半導体産業基盤",
                description = "半導体素材、先端パッケージング、量子計算の複合調査プロジェクト",
                createdAt = "2026年10月6日 作成",
                pages = listOf(
                    WorkspacePage("p1", "日本の半導体産業：後工程の自動化戦略", "https://www.nikkei.com", "封止材・ダイシングソー等で世界シェア70%超を維持"),
                    WorkspacePage("p2", "東京大学 量子情報工学研究成果", "https://www.u-tokyo.ac.jp", "超伝導量子ビットのコヒーレンス時間1.2ms達成")
                ),
                notes = listOf(
                    WorkspaceNote(
                        id = "n1",
                        pageTitle = "日本の半導体産業",
                        pageUrl = "https://www.nikkei.com",
                        quote = "後工程こそが、ムーアの法則を超えた性能向上をもたらす主戦場である",
                        userComment = "チップレット集積と北海道・熊本のサプライチェーン連携が要点",
                        createdAt = "10:14"
                    )
                ),
                aiSynthesis = "【論点抽出】前工程微細化の物理的限界に対し、日本の素材・後工程技術の強みをテコにしたエコシステム形成が核心。量子技術とのハイブリッド化も長期的な優位性に寄与する。"
            )
        )
    )
    val workspaces: StateFlow<List<ResearchWorkspace>> = _workspaces.asStateFlow()

    // Extensions
    private val _extensions = MutableStateFlow<List<BrowserExtension>>(
        listOf(
            BrowserExtension(
                id = "ext_adblock",
                name = "清瀬 静寂シールド (Ad & Tracker Block)",
                description = "煩雑な広告、トラッカー、自動再生動画を静かに遮断します。",
                version = "2.4.0",
                isEnabled = true,
                permissions = listOf("ネットワーク要求の検証", "危険スクリプトの遮断")
            ),
            BrowserExtension(
                id = "ext_typography",
                name = "日本語組版オプティマイザ",
                description = "Web上の日本語フォントを Noto Sans JP / Noto Serif JP で美しく統一します。",
                version = "1.8.2",
                isEnabled = true,
                permissions = listOf("ページのスタイルシート調整")
            ),
            BrowserExtension(
                id = "ext_furigana",
                name = "清瀬 現代国語辞書 & ルビ表示",
                description = "選択した日本語単語の語源、意味、読み仮名を控えめに表示します。",
                version = "1.1.0",
                isEnabled = false,
                permissions = listOf("選択テキストの読み取り")
            )
        )
    )
    val extensions: StateFlow<List<BrowserExtension>> = _extensions.asStateFlow()

    // Site Permissions
    private val _sitePermissions = MutableStateFlow<Map<String, SitePermission>>(
        mapOf(
            "boj.or.jp" to SitePermission("boj.or.jp"),
            "u-tokyo.ac.jp" to SitePermission("u-tokyo.ac.jp"),
            "google.com" to SitePermission("google.com", location = PermissionState.ASK),
            "yahoo.co.jp" to SitePermission("yahoo.co.jp", location = PermissionState.ASK)
        )
    )
    val sitePermissions: StateFlow<Map<String, SitePermission>> = _sitePermissions.asStateFlow()

    // DevTools Logs
    private val _devToolsLogs = MutableStateFlow<List<DevToolsEntry>>(
        listOf(
            DevToolsEntry("ネットワーク", "INFO", "10:42:01", "GET https://www.boj.or.jp/ HTTP/2 200 OK (38ms) TLS 1.3"),
            DevToolsEntry("セキュリティ", "INFO", "10:42:01", "証明書検証正常: DigiCert Global Root G2 (有効期限: 2028年)"),
            DevToolsEntry("コンソール", "LOG", "10:42:02", "[Kiyose Engine] 日本語組版エンジン初期化: Noto Sans JP 適用完了"),
            DevToolsEntry("パフォーマンス", "INFO", "10:42:02", "First Contentful Paint: 210ms / DOM Ready: 380ms")
        )
    )
    val devToolsLogs: StateFlow<List<DevToolsEntry>> = _devToolsLogs.asStateFlow()

    fun addBookmark(title: String, url: String, category: BookmarkCategory = BookmarkCategory.WORK) {
        val newItem = BookmarkItem(
            id = UUID.randomUUID().toString(),
            title = title,
            url = url,
            category = category,
            dateAdded = dateFormat.format(Date()),
            iconEmoji = title.take(1)
        )
        _bookmarks.value = listOf(newItem) + _bookmarks.value
    }

    fun removeBookmark(id: String) {
        _bookmarks.value = _bookmarks.value.filter { it.id != id }
    }

    fun addHistory(title: String, url: String) {
        val now = System.currentTimeMillis()
        val newItem = HistoryItem(
            id = UUID.randomUUID().toString(),
            title = title,
            url = url,
            timestamp = now,
            formattedTime = timeFormat.format(Date(now)),
            isToday = true
        )
        _history.value = listOf(newItem) + _history.value.filter { it.url != url }
    }

    fun clearHistory() {
        _history.value = emptyList()
    }

    fun addToReadingList(title: String, url: String, excerpt: String) {
        val item = ReadingListItem(
            id = UUID.randomUUID().toString(),
            title = title,
            url = url,
            savedTime = timeFormat.format(Date()),
            excerpt = excerpt,
            isOfflineSaved = true
        )
        _readingList.value = listOf(item) + _readingList.value
    }

    fun removeReadingListItem(id: String) {
        _readingList.value = _readingList.value.filter { it.id != id }
    }

    fun toggleDownloadStatus(id: String) {
        _downloads.value = _downloads.value.map { item ->
            if (item.id == id) {
                when (item.status) {
                    DownloadStatus.IN_PROGRESS -> item.copy(status = DownloadStatus.PAUSED)
                    DownloadStatus.PAUSED -> item.copy(status = DownloadStatus.IN_PROGRESS)
                    else -> item
                }
            } else item
        }
    }

    fun removeDownload(id: String) {
        _downloads.value = _downloads.value.filter { it.id != id }
    }

    fun addWorkspaceNote(workspaceId: String, pageTitle: String, pageUrl: String, quote: String, comment: String) {
        val note = WorkspaceNote(
            id = UUID.randomUUID().toString(),
            pageTitle = pageTitle,
            pageUrl = pageUrl,
            quote = quote,
            userComment = comment,
            createdAt = timeFormat.format(Date())
        )
        _workspaces.value = _workspaces.value.map { ws ->
            if (ws.id == workspaceId) {
                ws.copy(notes = listOf(note) + ws.notes)
            } else ws
        }
    }

    fun createWorkspace(title: String, description: String) {
        val ws = ResearchWorkspace(
            id = UUID.randomUUID().toString(),
            title = title,
            description = description,
            createdAt = "${dateFormat.format(Date())} 作成"
        )
        _workspaces.value = listOf(ws) + _workspaces.value
    }

    fun toggleExtension(id: String) {
        _extensions.value = _extensions.value.map { ext ->
            if (ext.id == id) ext.copy(isEnabled = !ext.isEnabled) else ext
        }
    }

    fun updateSitePermission(host: String, permission: SitePermission) {
        val map = _sitePermissions.value.toMutableMap()
        map[host] = permission
        _sitePermissions.value = map
    }

    fun logDevTools(category: String, level: String, message: String) {
        val entry = DevToolsEntry(category, level, timeFormat.format(Date()), message)
        _devToolsLogs.value = listOf(entry) + _devToolsLogs.value.take(49)
    }
}
