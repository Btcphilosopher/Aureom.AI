package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.BrowserShellScreen
import com.example.ui.theme.KiyoseTheme
import com.example.viewmodel.BrowserViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val isPrivateMode by viewModel.isPrivateMode.collectAsState()

            // In Private Browsing mode, use quiet dark palette
            val effectiveDark = isDarkTheme || isPrivateMode

            KiyoseTheme(darkTheme = effectiveDark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BrowserShellScreen(viewModel = viewModel)
                }
            }
        }
    }
}
