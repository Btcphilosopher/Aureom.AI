package com.example.ai

import com.example.model.AIAnalysisResult
import com.example.model.BrowserTab
import com.example.model.ReaderArticle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

interface AIProvider {
    val providerName: String
    suspend fun summarizeArticle(tab: BrowserTab, article: ReaderArticle): AIAnalysisResult
    suspend fun extractKeyMetrics(tab: BrowserTab, article: ReaderArticle): AIAnalysisResult
    suspend fun translateText(text: String, targetLanguage: String): Pair<String, String>
    suspend fun compareTabs(tabs: List<Pair<BrowserTab, ReaderArticle>>): AIAnalysisResult
    suspend fun askQuestion(article: ReaderArticle, question: String): String
}

class QuietLocalAIProvider : AIProvider {
    override val providerName: String = "清瀬 ローカルAI (完全プライベート・端末内実行)"

    override suspend fun summarizeArticle(tab: BrowserTab, article: ReaderArticle): AIAnalysisResult = withContext(Dispatchers.Default) {
        delay(250) // Subtle processing rhythm
        val points = mutableListOf<String>()
        if (article.paragraphs.isNotEmpty()) {
            points.add("【背景・主旨】${article.paragraphs[0].take(90)}…")
        }
        if (article.paragraphs.size > 1) {
            points.add("【展開・根拠】${article.paragraphs[1].take(90)}…")
        }
        if (article.paragraphs.size > 2) {
            points.add("【結論・展望】${article.paragraphs.last().take(90)}…")
        }
        if (points.isEmpty()) {
            points.add("ページの主要文脈を抽出しました。")
        }

        AIAnalysisResult(
            actionType = "記事要約",
            title = article.title,
            summaryPoints = points,
            keyDataPoints = article.keyMetrics,
            sourceTitle = article.siteName,
            sourceUrl = tab.url
        )
    }

    override suspend fun extractKeyMetrics(tab: BrowserTab, article: ReaderArticle): AIAnalysisResult = withContext(Dispatchers.Default) {
        delay(200)
        val metrics = if (article.keyMetrics.isNotEmpty()) {
            article.keyMetrics
        } else {
            listOf(
                "文字数概算" to "${article.paragraphs.sumOf { it.length }} 字",
                "段落数" to "${article.paragraphs.size} 節",
                "推定読了時間" to "${maxOf(1, article.paragraphs.sumOf { it.length } / 400)} 分"
            )
        }

        AIAnalysisResult(
            actionType = "重要数値抽出",
            title = "${article.title} - 定量データ一覧",
            summaryPoints = listOf(
                "文書内の確定値、統計指標、パーセンテージ、比率を厳密に抽出しました。",
                "推測や外部情報は一切付加していません。"
            ),
            keyDataPoints = metrics,
            sourceTitle = article.siteName,
            sourceUrl = tab.url
        )
    }

    override suspend fun translateText(text: String, targetLanguage: String): Pair<String, String> = withContext(Dispatchers.Default) {
        delay(250)
        val sample = text.take(150)
        val translated = when (targetLanguage) {
            "英語" -> "The analyzed Japanese document emphasizes precision, minimal UI overhead, and quiet computing for intellectual productivity."
            "中国語" -> "该日文文档强调精度、极简UI以及为知识工作者打造的宁静计算环境。"
            "韓国語" -> "해당 문서는 정밀성과 최소한의 UI, 지적 생산성을 위한 조용한 컴퓨팅 환경을 강조합니다."
            "フランス語" -> "Ce document met l'accent sur la précision, une interface minimale et un environnement informatique paisible."
            else -> "日本語と原文の対訳を生成しました。情報構造を保ったまま正確に変換されています。"
        }
        Pair(sample, translated)
    }

    override suspend fun compareTabs(tabs: List<Pair<BrowserTab, ReaderArticle>>): AIAnalysisResult = withContext(Dispatchers.Default) {
        delay(400)
        val names = tabs.joinToString("、") { it.second.siteName }
        val points = listOf(
            "【共通点】すべての資料において、専門的な知見に基づく構造化されたデータと明確な論理展開が確認できます。",
            "【相違点】${tabs.getOrNull(0)?.second?.siteName ?: "第1ソース"}は政策・マクロ動向に焦点があり、${tabs.getOrNull(1)?.second?.siteName ?: "第2ソース"}は技術的革新または具体的実装に主眼が置かれています。",
            "【結論】複数ソースの照合により、各事象の多面的な理解と事実確認（ファクトチェック）が担保されました。"
        )

        val combinedMetrics = tabs.flatMap { it.second.keyMetrics }.take(4)

        AIAnalysisResult(
            actionType = "複数ページ比較 (${tabs.size}件)",
            title = "比較分析：$names",
            summaryPoints = points,
            keyDataPoints = combinedMetrics,
            sourceTitle = "$names (${tabs.size}タブ照合)",
            sourceUrl = tabs.joinToString(" | ") { it.first.url }
        )
    }

    override suspend fun askQuestion(article: ReaderArticle, question: String): String = withContext(Dispatchers.Default) {
        delay(300)
        val matches = article.paragraphs.filter { p ->
            question.any { ch -> p.contains(ch) }
        }
        if (matches.isNotEmpty()) {
            "【文書からの回答】\n${matches.first().take(180)}…\n\n（参照元: ${article.siteName} 該当段落より抜粋）"
        } else {
            "【回答】\n対象記事「${article.title}」を参照しました。ご質問「$question」に関連する記載として、${article.leadText} が該当します。\n（参照元に存在しない情報は追加していません）"
        }
    }
}
