package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.BrowserRepository
import com.example.model.BookmarkCategory
import com.example.viewmodel.BrowserViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("清瀬ブラウザ", appName)
    }

    @Test
    fun `test repository and initial state`() {
        val repo = BrowserRepository()
        assertTrue(repo.bookmarks.value.isNotEmpty())
        assertTrue(repo.history.value.isNotEmpty())
        assertTrue(repo.workspaces.value.isNotEmpty())

        val viewModel = BrowserViewModel(repo)
        assertEquals(1, viewModel.tabs.value.size)
        assertEquals("清瀬", viewModel.activeTab.title)
    }

    @Test
    fun `test tab navigation and reader mode toggle`() {
        val viewModel = BrowserViewModel()
        viewModel.openTab("https://www.boj.or.jp", "日本銀行")
        assertEquals(2, viewModel.tabs.value.size)
        assertTrue(viewModel.activeTab.title.contains("日本銀行"))

        viewModel.toggleReaderMode()
        assertTrue(viewModel.activeTab.isReaderMode)
        assertNotNull(viewModel.activeTab.readerArticle)
    }
}
