export interface EconomicAssumptions {
  jetAFuelPriceUsdGal: number; // e.g. 2.75 USD/gallon
  safPriceUsdGal: number; // e.g. 6.50 USD/gallon
  safBlendRatio: number; // 0 to 1.0 (e.g. 1.0 = 100% SAF)
  carbonPriceUsdPerTonne: number; // e.g. 85 USD/tonne CO2
  aircraftUtilizationHoursPerYear: number; // e.g. 3600 hrs/yr
  averageFlightStageLengthNm: number; // e.g. 3800 nm
  loadFactor: number; // e.g. 0.78 (78%)
  
  // Fare structure
  fareFirstClassUsd: number; // e.g. $8,500
  fareBusinessClassUsd: number; // e.g. $5,200
  farePremiumEconomyUsd: number; // e.g. $3,400
  firstClassSeatFraction: number; // e.g. 0.20
  businessClassSeatFraction: number; // e.g. 0.60
  premiumEconomySeatFraction: number; // e.g. 0.20
  
  cargoYieldUsdPerKg: number; // e.g. $3.20/kg
  cargoLoadFactor: number; // e.g. 0.65
  ancillaryRevenuePerPaxUsd: number; // e.g. $150
  
  // Cost factors
  flightCrewHourlyCostUsd: number; // e.g. $1,400/hr (Captain, First Officer, relief)
  cabinCrewHourlyCostUsd: number; // e.g. $600/hr
  airframeMaintenancePerFlightHourUsd: number; // e.g. $950/hr
  engineMaintenancePerFlightHourPerEngineUsd: number; // e.g. $420/hr/engine
  landingFeePerTonneUsd: number; // e.g. $18/tonne MTOW
  navigationFeePerKmUsd: number; // e.g. $0.95/km
  groundHandlingPerFlightUsd: number; // e.g. $3,800/flight
  cateringPerPaxUsd: number; // e.g. $110/pax
  hullInsuranceAnnualFraction: number; // e.g. 0.0075 (0.75% of hull value)
  
  // Financial parameters
  aircraftUsefulLifeYears: number; // e.g. 16 years
  aircraftResidualValueFraction: number; // e.g. 0.10 (10%)
  waccDiscountRate: number; // e.g. 0.085 (8.5%)
  debtFraction: number; // e.g. 0.70
  interestRate: number; // e.g. 0.065 (6.5%)
  corporateTaxRate: number; // e.g. 0.21 (21%)
}

export interface FlightEconomicsResult {
  // Direct Operating Costs (DOC) per flight
  fuelCostUsd: number;
  safCostUsd: number;
  totalFuelCostUsd: number;
  carbonEmissionCostUsd: number;
  flightCrewCostUsd: number;
  cabinCrewCostUsd: number;
  airframeMaintenanceCostUsd: number;
  engineMaintenanceCostUsd: number;
  totalMaintenanceCostUsd: number;
  landingFeesUsd: number;
  navigationFeesUsd: number;
  groundHandlingFeesUsd: number;
  cateringCostUsd: number;
  directOperatingCostPerFlightUsd: number;
  
  // Ownership & Fixed Costs per flight
  depreciationCostPerFlightUsd: number;
  financingInterestPerFlightUsd: number;
  hullInsurancePerFlightUsd: number;
  totalOperatingCostPerFlightUsd: number;
  
  // Revenue per flight
  passengerRevenueUsd: number;
  cargoRevenueUsd: number;
  ancillaryRevenueUsd: number;
  totalRevenuePerFlightUsd: number;
  
  // Margins & Unit Economics
  operatingProfitPerFlightUsd: number;
  operatingMarginPercent: number;
  costPerSeatUsd: number;
  costPerPassengerUsd: number;
  costPerSeatKmUsd: number; // CASM
  costPerSeatNmUsd: number;
  revenuePerSeatKmUsd: number; // RASM
  revenuePerSeatNmUsd: number;
  breakEvenLoadFactor: number;
  breakEvenAverageFareUsd: number;
}

export interface FleetFinancials {
  fleetSize: number; // 10, 25, 50, 100, 250
  fleetCapexUsdMillion: number;
  annualFleetFlights: number;
  annualFleetBlockHours: number;
  annualRevenueUsdMillion: number;
  annualOpexUsdMillion: number;
  annualEbitdaUsdMillion: number;
  annualNetIncomeUsdMillion: number;
  npv15YearsUsdMillion: number;
  irrPercent: number;
  paybackPeriodYears: number;
  yearlyCashFlows: {
    year: number;
    capex: number;
    revenue: number;
    opex: number;
    ebitda: number;
    depreciation: number;
    tax: number;
    freeCashFlow: number;
    cumulativeCashFlow: number;
  }[];
}
