import { EngineCycleType } from './aircraft';

export type ConfigurationFeasibility =
  | 'Technically Feasible'
  | 'Economically Attractive'
  | 'Technically Marginal'
  | 'Dominated Design'
  | 'Unacceptable Risk'
  | 'Technological Breakthrough Required';

export interface DesignPoint {
  id: string;
  name: string;
  mach: number;
  designRangeNm: number;
  passengers: number;
  engineCycle: EngineCycleType;
  wingAreaM2: number;
  aspectRatio: number;
  sweepDeg: number;
  liftToDragCruise: number;
  tsfcCruise: number;
  mtowKg: number;
  oewKg: number;
  blockFuelKg: number;
  fuelPerPaxKg: number;
  co2PerPaxKmG: number;
  casmUsdPerSeatKm: number;
  operatingProfitFlightUsd: number;
  operatingMarginPercent: number;
  npvUsdMillion: number;
  irrPercent: number;
  breakEvenLoadFactorPercent: number;
  compositeFraction: number;
  skinTempC: number;
  boomOverpressurePsf: number;
  classification: ConfigurationFeasibility;
  riskScore: number; // 0 to 100
  isParetoOptimal: boolean;
  paretoFronts: string[]; // e.g. ['Fuel-Speed', 'Range-Payload', 'Speed-CASM']
}

export interface SensitivityMetric {
  parameterName: string;
  category: 'Aerodynamics' | 'Propulsion' | 'Operations' | 'Market' | 'Economics';
  pearsonCorrelation: number; // -1 to +1
  spearmanRankCorrelation: number;
  regressionCoefficient: number; // Standardized beta
  sobolFirstOrderIndex: number; // 0 to 1
  sobolTotalEffectIndex: number; // 0 to 1
  lowCaseDeltaProfit: number;
  highCaseDeltaProfit: number;
  impactRank: number;
}

export interface DecisionCriteriaWeights {
  technicalFeasibility: number; // 0 to 100 (normalized)
  economicViability: number;
  environmentalPerformance: number;
  regulatoryExposure: number;
  developmentRisk: number;
  manufacturingComplexity: number;
  supplyChainRisk: number;
  operationalReliability: number;
  marketAttractiveness: number;
}

export interface DecisionScoreBreakdown {
  aircraftId: string;
  aircraftName: string;
  overallScore: number; // 0 to 100
  technicalScore: number;
  economicScore: number;
  environmentalScore: number;
  regulatoryScore: number;
  developmentRiskScore: number;
  manufacturingScore: number;
  supplyChainScore: number;
  reliabilityScore: number;
  marketScore: number;
  radarScores: {
    criteria: string;
    score: number;
    benchmarkScore: number;
    weight: number;
  }[];
  keyPros: string[];
  keyCons: string[];
  recommendation: string;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  fuelPriceMultiplier: number;
  safPriceMultiplier: number;
  safMandateRatio: number;
  carbonPriceUsdPerTonne: number;
  yieldMultiplier: number;
  demandFactor: number;
  loadFactor: number;
  lowBoomOverlandPermitted: boolean;
  developmentCostMultiplier: number;
  maintenanceCostMultiplier: number;
  isCustom?: boolean;
}
