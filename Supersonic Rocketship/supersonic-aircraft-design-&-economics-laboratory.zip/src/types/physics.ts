export interface AtmosphereState {
  altitudeM: number; // m
  altitudeFt: number; // ft
  temperatureK: number; // K
  temperatureC: number; // °C
  pressurePa: number; // Pa
  densityKgM3: number; // kg/m³
  speedOfSoundMS: number; // m/s
  speedOfSoundKts: number; // knots
  viscosityPaS: number; // Pa*s
}

export interface AerodynamicState {
  mach: number;
  altitudeM: number;
  qInfPa: number; // Dynamic pressure 0.5 * rho * V^2
  velocityMS: number;
  cl: number;
  cdParasite: number;
  cdInduced: number;
  cdWave: number;
  cdTotal: number;
  liftToDrag: number;
  liftN: number;
  dragN: number;
  thrustRequiredN: number;
  regime: 'Takeoff' | 'Climb' | 'Transonic' | 'Supersonic' | 'Descent' | 'Approach';
}

export interface PropulsionState {
  mach: number;
  altitudeM: number;
  inletPressureRecovery: number;
  inletDragN: number;
  grossThrustN: number;
  netThrustN: number;
  fuelFlowKgS: number;
  tsfcKgNH: number;
  tsfcLbLbfH: number;
  nozzleExpansionRatio: number;
  thermalEfficiency: number;
  propulsiveEfficiency: number;
  overallEfficiency: number;
}

export interface ThermalState {
  mach: number;
  ambientTempC: number;
  stagnationTempC: number;
  recoveryTempC: number;
  skinTempNoseC: number;
  skinTempWingLeadingEdgeC: number;
  skinTempFuselageMidC: number;
  materialLimitC: number;
  thermalMarginC: number;
  isThermalExceeded: boolean;
}

export interface StructuralBuildUp {
  wingMassKg: number;
  fuselageMassKg: number;
  empennageMassKg: number;
  landingGearMassKg: number;
  nacellePylonMassKg: number;
  enginesTotalMassKg: number;
  flightControlsMassKg: number;
  systemsMassKg: number;
  thermalProtectionMassKg: number;
  cabinInteriorsMassKg: number;
  contingencyMassKg: number;
  totalOewKg: number;
  payloadKg: number;
  maxFuelMassKg: number;
  totalMtowKg: number;
}

export interface SonicBoomSignature {
  mach: number;
  cruiseAltitudeFt: number;
  overpressurePsf: number;
  perceivedLoudnessPLdB: number;
  faaStandardAllowedPsf: number; // 0.11 psf
  isOverlandAllowed: boolean;
  groundFootprintWidthNm: number;
}

export interface FlightMissionPhase {
  phaseName: string;
  startAltitudeM: number;
  endAltitudeM: number;
  startMach: number;
  endMach: number;
  distanceKm: number;
  distanceNm: number;
  timeMinutes: number;
  fuelBurnKg: number;
  startWeightKg: number;
  endWeightKg: number;
  avgThrustN: number;
  avgTsfc: number;
  avgLD: number;
}

export interface FlightRoute {
  id: string;
  name: string;
  origin: string;
  originIata: string;
  destination: string;
  destinationIata: string;
  greatCircleDistanceKm: number;
  greatCircleDistanceNm: number;
  overwaterFraction: number; // 0.0 to 1.0 (water vs land for boom restrictions)
}

export interface MissionProfileResult {
  route: FlightRoute;
  phases: FlightMissionPhase[];
  totalDistanceKm: number;
  totalDistanceNm: number;
  blockTimeHours: number;
  flightTimeHours: number;
  blockFuelKg: number;
  tripFuelKg: number;
  contingencyFuelKg: number;
  diversionFuelKg: number;
  holdingFuelKg: number;
  totalReserveFuelKg: number;
  takeoffWeightKg: number;
  landingWeightKg: number;
  payloadCarriedKg: number;
  fuelPerPassengerKg: number;
  fuelPerPaxKmGrams: number;
  co2PerPaxKmGrams: number;
  isMissionFeasible: boolean;
  feasibilityNotes: string[];
}
