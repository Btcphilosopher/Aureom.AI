export type DistributionType = 'normal' | 'lognormal' | 'triangular' | 'uniform' | 'beta';

export interface DistributionParam {
  type: DistributionType;
  mean?: number;
  stdDev?: number;
  min?: number;
  max?: number;
  mode?: number;
  alpha?: number;
  beta?: number;
}

export interface MonteCarloConfig {
  iterations: number; // e.g. 10000, 50000, 100000
  seed: number;
  variables: {
    tsfcMultiplier: DistributionParam;
    liftToDragMultiplier: DistributionParam;
    mtowMultiplier: DistributionParam;
    oewMultiplier: DistributionParam;
    fuelPriceUsdGal: DistributionParam;
    safPricePremiumMultiplier: DistributionParam;
    loadFactor: DistributionParam;
    ticketYieldMultiplier: DistributionParam;
    annualUtilHours: DistributionParam;
    maintenanceCostMultiplier: DistributionParam;
    aircraftPriceMultiplier: DistributionParam;
    programDevCostMultiplier: DistributionParam;
  };
}

export interface MonteCarloIterationResult {
  iterationIndex: number;
  tsfcMultiplier: number;
  ldMultiplier: number;
  mtow: number;
  fuelPrice: number;
  loadFactor: number;
  operatingProfitFlightUsd: number;
  operatingMarginPercent: number;
  casmUsdPerSeatKm: number;
  npvUsdMillion: number;
  irrPercent: number;
  breakEvenLoadFactor: number;
  isProfitable: boolean;
}

export interface DistributionStatistics {
  mean: number;
  median: number;
  stdDev: number;
  min: number;
  max: number;
  p5: number;
  p10: number;
  p25: number;
  p75: number;
  p90: number;
  p95: number;
  var95: number; // Value at Risk 95%
  cvar95: number; // Conditional VaR / Expected Shortfall
}

export interface HistogramBin {
  binStart: number;
  binEnd: number;
  binMid: number;
  count: number;
  frequency: number;
  cumulativeProbability: number;
}

export interface MonteCarloSummary {
  totalIterations: number;
  probabilityOfProfitPercent: number;
  profitDistribution: DistributionStatistics;
  marginDistribution: DistributionStatistics;
  npvDistribution: DistributionStatistics;
  irrDistribution: DistributionStatistics;
  casmDistribution: DistributionStatistics;
  breakEvenLoadFactorDistribution: DistributionStatistics;
  profitHistogram: HistogramBin[];
  npvHistogram: HistogramBin[];
  casmHistogram: HistogramBin[];
}
