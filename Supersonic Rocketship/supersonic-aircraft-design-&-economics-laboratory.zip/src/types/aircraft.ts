export type UnitSystem = 'SI' | 'Aviation';

export interface ParameterMetadata<T = number> {
  value: T;
  unit: string;
  aviationUnit?: string;
  aviationValue?: number;
  source: string;
  assumption: string;
  uncertaintyPercent: number; // e.g. 5 for +/-5%
  confidence: 'High' | 'Medium' | 'Low';
  modelVersion: string;
}

export type EngineCycleType =
  | 'turbojet'
  | 'low_bypass_turbofan'
  | 'medium_bypass_turbofan'
  | 'variable_cycle'
  | 'afterburning_turbojet'
  | 'afterburning_turbofan';

export type PrimaryMaterial =
  | 'cfrp'
  | 'titanium'
  | 'aluminum_lithium'
  | 'aluminum_conventional'
  | 'ceramic_matrix_composite';

export interface AircraftConfiguration {
  id: string;
  name: string;
  description: string;
  configId: string;
  modelVersion: string;
  
  // Core Operational Requirements
  machCruise: ParameterMetadata<number>; // Mach number
  cruiseAltitude: ParameterMetadata<number>; // m (SI) or ft (Aviation)
  designRange: ParameterMetadata<number>; // km (SI) or nm (Aviation)
  passengerCapacity: ParameterMetadata<number>; // count
  cargoCapacity: ParameterMetadata<number>; // kg
  
  // Weight Breakdown
  mtow: ParameterMetadata<number>; // kg
  oew: ParameterMetadata<number>; // kg
  payload: ParameterMetadata<number>; // kg
  fuelCapacity: ParameterMetadata<number>; // kg
  structuralMass: ParameterMetadata<number>; // kg
  landingGearMass: ParameterMetadata<number>; // kg
  engineMass: ParameterMetadata<number>; // kg (total engines)
  systemsMass: ParameterMetadata<number>; // kg
  interiorFurnishingMass: ParameterMetadata<number>; // kg
  thermalProtectionMass: ParameterMetadata<number>; // kg
  contingencyMass: ParameterMetadata<number>; // kg
  
  // Geometry & Aerodynamics
  wingArea: ParameterMetadata<number>; // m²
  wingSpan: ParameterMetadata<number>; // m
  aspectRatio: ParameterMetadata<number>; // dimensionless
  sweepAngle: ParameterMetadata<number>; // deg (quarter-chord)
  thicknessChordRatio: ParameterMetadata<number>; // e.g. 0.04 (4%)
  fuselageLength: ParameterMetadata<number>; // m
  fuselageDiameter: ParameterMetadata<number>; // m
  wettedArea: ParameterMetadata<number>; // m²
  tailConfiguration: ParameterMetadata<string>; // 'T-tail', 'Cruciform', 'Canard-Delta', 'Tailless'
  areaRulingQuality: ParameterMetadata<number>; // 0.0 to 1.0 (anti-shock coke-bottle effectiveness)
  oswaldEfficiency: ParameterMetadata<number>; // e.g. 0.82
  
  // Propulsion
  engineCycle: ParameterMetadata<EngineCycleType>;
  numEngines: ParameterMetadata<number>;
  staticThrustPerEngine: ParameterMetadata<number>; // N (SI) or lbf (Aviation)
  cruiseThrustPerEngine: ParameterMetadata<number>; // N (SI) or lbf (Aviation)
  bypassRatio: ParameterMetadata<number>; // dimensionless
  overallPressureRatio: ParameterMetadata<number>; // dimensionless
  turbineInletTemp: ParameterMetadata<number>; // K
  inletEfficiency: ParameterMetadata<number>; // recovery factor (e.g. 0.95)
  nozzleEfficiency: ParameterMetadata<number>; // e.g. 0.97
  hasAfterburner: ParameterMetadata<boolean>;
  afterburnerThrustBoost: ParameterMetadata<number>; // multiplier e.g. 1.4
  tsfcCruise: ParameterMetadata<number>; // kg/(N*h) (SI) or lb/(lbf*h) (Aviation)
  tsfcTakeoff: ParameterMetadata<number>; // kg/(N*h)
  safBlendRatio: ParameterMetadata<number>; // 0.0 to 1.0 (100% SAF)
  
  // Aerodynamic Performance Targets
  liftToDragCruise: ParameterMetadata<number>; // L/D (e.g. 8.8)
  liftToDragSubsonic: ParameterMetadata<number>; // L/D (e.g. 14.5)
  cd0Subsonic: ParameterMetadata<number>; // Parasite drag coeff
  cd0Supersonic: ParameterMetadata<number>; // Wave + parasite drag coeff
  clCruise: ParameterMetadata<number>; // Cruise lift coeff
  
  // Materials & Thermal
  primaryMaterial: ParameterMetadata<PrimaryMaterial>;
  materialMaxTempLimit: ParameterMetadata<number>; // °C (or K)
  thermalExpansionCoeff: ParameterMetadata<number>; // 10^-6 / K
  compositeWeightFraction: ParameterMetadata<number>; // e.g. 0.72 (72%)
  titaniumWeightFraction: ParameterMetadata<number>; // e.g. 0.20
  aluminumLithiumWeightFraction: ParameterMetadata<number>; // e.g. 0.08
  
  // Sonic Boom
  boomTargetOverpressure: ParameterMetadata<number>; // psf (e.g. 0.11 psf)
  perceivedLoudness: ParameterMetadata<number>; // PLdB (e.g. 75 PLdB)
  isLowBoomShaped: ParameterMetadata<boolean>;
  
  // Program & Economics Parameters
  aircraftUnitPrice: ParameterMetadata<number>; // USD million
  programDevCost: ParameterMetadata<number>; // USD billion
  targetServiceLifeHours: ParameterMetadata<number>; // e.g. 60,000 hrs
  annualFlightHours: ParameterMetadata<number>; // e.g. 3,600 hrs/yr
}
