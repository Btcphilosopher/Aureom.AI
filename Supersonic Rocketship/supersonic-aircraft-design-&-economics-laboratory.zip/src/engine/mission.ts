import { AircraftConfiguration } from '../types/aircraft';
import { FlightMissionPhase, FlightRoute, MissionProfileResult } from '../types/physics';
import { calculateAerodynamics } from './aerodynamics';
import { calculatePropulsion } from './propulsion';
import { calculateStructuralMassBuildup } from './structures';

export const PRESET_ROUTES: FlightRoute[] = [
  {
    id: 'lhr-jfk',
    name: 'London (LHR) → New York (JFK)',
    origin: 'London Heathrow',
    originIata: 'LHR',
    destination: 'New York JFK',
    destinationIata: 'JFK',
    greatCircleDistanceKm: 5585,
    greatCircleDistanceNm: 3016,
    overwaterFraction: 0.94,
  },
  {
    id: 'cdg-jfk',
    name: 'Paris (CDG) → New York (JFK)',
    origin: 'Paris Charles de Gaulle',
    originIata: 'CDG',
    destination: 'New York JFK',
    destinationIata: 'JFK',
    greatCircleDistanceKm: 5835,
    greatCircleDistanceNm: 3151,
    overwaterFraction: 0.92,
  },
  {
    id: 'lhr-dxb',
    name: 'London (LHR) → Dubai (DXB)',
    origin: 'London Heathrow',
    originIata: 'LHR',
    destination: 'Dubai International',
    destinationIata: 'DXB',
    greatCircleDistanceKm: 5470,
    greatCircleDistanceNm: 2954,
    overwaterFraction: 0.35, // significant overland routing
  },
  {
    id: 'lhr-lax',
    name: 'London (LHR) → Los Angeles (LAX)',
    origin: 'London Heathrow',
    originIata: 'LHR',
    destination: 'Los Angeles International',
    destinationIata: 'LAX',
    greatCircleDistanceKm: 8780,
    greatCircleDistanceNm: 4741,
    overwaterFraction: 0.65,
  },
  {
    id: 'hnd-lax',
    name: 'Tokyo (HND) → Los Angeles (LAX)',
    origin: 'Tokyo Haneda',
    originIata: 'HND',
    destination: 'Los Angeles International',
    destinationIata: 'LAX',
    greatCircleDistanceKm: 8815,
    greatCircleDistanceNm: 4760,
    overwaterFraction: 0.98,
  },
  {
    id: 'sin-syd',
    name: 'Singapore (SIN) → Sydney (SYD)',
    origin: 'Singapore Changi',
    originIata: 'SIN',
    destination: 'Sydney Kingsford Smith',
    destinationIata: 'SYD',
    greatCircleDistanceKm: 6300,
    greatCircleDistanceNm: 3402,
    overwaterFraction: 0.88,
  },
];

/**
 * Numerical 7-Phase Mission Integration Engine
 */
export function simulateMission(
  config: AircraftConfiguration,
  route: FlightRoute,
  paxCount?: number
): MissionProfileResult {
  const structure = calculateStructuralMassBuildup(config);
  const actualPax = paxCount !== undefined ? paxCount : config.passengerCapacity.value;
  const payloadCarriedKg = actualPax * 100 + config.cargoCapacity.value;
  const oewKg = structure.totalOewKg;
  const maxFuelKg = config.fuelCapacity.value;
  const mtowLimitKg = config.mtow.value;

  const cruiseMach = config.machCruise.value;
  const cruiseAltM = config.cruiseAltitude.value;
  const routeDistNm = route.greatCircleDistanceNm;
  const routeDistKm = route.greatCircleDistanceKm;

  // 1. Estimate initial fuel burn to size starting Takeoff Weight
  let currentWeightKg = oewKg + payloadCarriedKg + maxFuelKg * 0.85;
  if (currentWeightKg > mtowLimitKg) {
    currentWeightKg = mtowLimitKg;
  }
  const takeoffWeightKg = currentWeightKg;

  const phases: FlightMissionPhase[] = [];

  // PHASE 1: Takeoff & Initial Climb (0 to 1,500 ft / 457 m, Mach 0.25 -> 0.35)
  const p1DistNm = 12.0;
  const p1TimeMin = 4.0;
  const p1Aero = calculateAerodynamics(config, 0.30, 250, currentWeightKg, 'Takeoff');
  const p1Prop = calculatePropulsion(config, 0.30, 250, 1.0, config.hasAfterburner.value);
  const p1FuelBurnKg = (p1Prop.fuelFlowKgS * p1TimeMin * 60) * 0.85;
  const p1StartWeight = currentWeightKg;
  currentWeightKg -= p1FuelBurnKg;
  phases.push({
    phaseName: 'Takeoff & Initial Climb',
    startAltitudeM: 0,
    endAltitudeM: 457,
    startMach: 0.25,
    endMach: 0.35,
    distanceKm: p1DistNm * 1.852,
    distanceNm: p1DistNm,
    timeMinutes: p1TimeMin,
    fuelBurnKg: p1FuelBurnKg,
    startWeightKg: p1StartWeight,
    endWeightKg: currentWeightKg,
    avgThrustN: p1Prop.netThrustN,
    avgTsfc: p1Prop.tsfcKgNH,
    avgLD: p1Aero.liftToDrag,
  });

  // PHASE 2: Subsonic Climb (1,500 ft to 30,000 ft / 9,144 m, Mach 0.35 -> 0.92)
  const p2DistNm = 110.0;
  const p2TimeMin = 14.0;
  const p2Aero = calculateAerodynamics(config, 0.75, 5000, currentWeightKg, 'Climb');
  const p2Prop = calculatePropulsion(config, 0.75, 5000, 0.95);
  const p2FuelBurnKg = p2Prop.fuelFlowKgS * p2TimeMin * 60;
  const p2StartWeight = currentWeightKg;
  currentWeightKg -= p2FuelBurnKg;
  phases.push({
    phaseName: 'Subsonic Climb',
    startAltitudeM: 457,
    endAltitudeM: 9144,
    startMach: 0.35,
    endMach: 0.92,
    distanceKm: p2DistNm * 1.852,
    distanceNm: p2DistNm,
    timeMinutes: p2TimeMin,
    fuelBurnKg: p2FuelBurnKg,
    startWeightKg: p2StartWeight,
    endWeightKg: currentWeightKg,
    avgThrustN: p2Prop.netThrustN,
    avgTsfc: p2Prop.tsfcKgNH,
    avgLD: p2Aero.liftToDrag,
  });

  // PHASE 3: Transonic Acceleration & Climb (30,000 ft to 48,000 ft / 14,630 m, Mach 0.92 -> cruiseMach)
  const p3DistNm = 140.0;
  const p3TimeMin = 10.0;
  const p3Aero = calculateAerodynamics(config, 1.15, 12000, currentWeightKg, 'Transonic');
  const p3Prop = calculatePropulsion(config, 1.15, 12000, 1.0, config.hasAfterburner.value);
  const p3FuelBurnKg = p3Prop.fuelFlowKgS * p3TimeMin * 60;
  const p3StartWeight = currentWeightKg;
  currentWeightKg -= p3FuelBurnKg;
  phases.push({
    phaseName: 'Transonic Acceleration',
    startAltitudeM: 9144,
    endAltitudeM: 14630,
    startMach: 0.92,
    endMach: cruiseMach,
    distanceKm: p3DistNm * 1.852,
    distanceNm: p3DistNm,
    timeMinutes: p3TimeMin,
    fuelBurnKg: p3FuelBurnKg,
    startWeightKg: p3StartWeight,
    endWeightKg: currentWeightKg,
    avgThrustN: p3Prop.netThrustN,
    avgTsfc: p3Prop.tsfcKgNH,
    avgLD: p3Aero.liftToDrag,
  });

  // PHASE 4: Supersonic Cruise (Cruise-climb 48,000 ft to cruiseAltM, Mach cruiseMach)
  // Distance remaining for cruise
  const climbDescentDistNm = p1DistNm + p2DistNm + p3DistNm + 160.0; // 160 nm descent/approach
  const cruiseDistNm = Math.max(100.0, routeDistNm - climbDescentDistNm);
  const cruiseDistKm = cruiseDistNm * 1.852;

  const cruiseAero = calculateAerodynamics(config, cruiseMach, cruiseAltM, currentWeightKg, 'Supersonic');
  const cruiseProp = calculatePropulsion(config, cruiseMach, cruiseAltM, 0.85);

  // Breguet Range Equation integration for cruise fuel:
  // R = (V * L/D) / (g * TSFC) * ln(W_start / W_end)
  // W_end = W_start * exp(- (R * g * TSFC) / (V * L/D))
  const cruiseSpeedMS = cruiseAero.velocityMS;
  const g0 = 9.80665;
  const cruiseTsfcSI = cruiseProp.tsfcKgNH / 3600.0; // kg/(N*s)
  const breguetExponent = (cruiseDistKm * 1000.0 * g0 * cruiseTsfcSI) / Math.max(1.0, cruiseSpeedMS * cruiseAero.liftToDrag);
  
  const p4StartWeight = currentWeightKg;
  const p4EndWeight = p4StartWeight * Math.exp(-breguetExponent);
  const p4FuelBurnKg = p4StartWeight - p4EndWeight;
  const cruiseSpeedKts = cruiseSpeedMS * 1.94384;
  const p4TimeMin = (cruiseDistNm / cruiseSpeedKts) * 60.0;

  currentWeightKg = p4EndWeight;
  phases.push({
    phaseName: 'Supersonic Cruise',
    startAltitudeM: 14630,
    endAltitudeM: cruiseAltM,
    startMach: cruiseMach,
    endMach: cruiseMach,
    distanceKm: cruiseDistKm,
    distanceNm: cruiseDistNm,
    timeMinutes: p4TimeMin,
    fuelBurnKg: p4FuelBurnKg,
    startWeightKg: p4StartWeight,
    endWeightKg: p4EndWeight,
    avgThrustN: cruiseAero.thrustRequiredN,
    avgTsfc: cruiseProp.tsfcKgNH,
    avgLD: cruiseAero.liftToDrag,
  });

  // PHASE 5: Supersonic & Subsonic Descent (cruiseAltM to 3,000 m, Mach cruiseMach -> 0.45)
  const p5DistNm = 120.0;
  const p5TimeMin = 16.0;
  const p5Aero = calculateAerodynamics(config, 0.80, 8000, currentWeightKg, 'Descent');
  const p5Prop = calculatePropulsion(config, 0.80, 8000, 0.15); // Flight idle throttle
  const p5FuelBurnKg = p5Prop.fuelFlowKgS * p5TimeMin * 60 * 0.35;
  const p5StartWeight = currentWeightKg;
  currentWeightKg -= p5FuelBurnKg;
  phases.push({
    phaseName: 'Descent & Deceleration',
    startAltitudeM: cruiseAltM,
    endAltitudeM: 3000,
    startMach: cruiseMach,
    endMach: 0.45,
    distanceKm: p5DistNm * 1.852,
    distanceNm: p5DistNm,
    timeMinutes: p5TimeMin,
    fuelBurnKg: p5FuelBurnKg,
    startWeightKg: p5StartWeight,
    endWeightKg: currentWeightKg,
    avgThrustN: p5Prop.netThrustN * 0.2,
    avgTsfc: p5Prop.tsfcKgNH,
    avgLD: p5Aero.liftToDrag,
  });

  // PHASE 6: Approach, Landing & Taxi (3,000 m to 0 m, Mach 0.45 -> 0.22)
  const p6DistNm = 40.0;
  const p6TimeMin = 12.0;
  const p6Aero = calculateAerodynamics(config, 0.28, 500, currentWeightKg, 'Approach');
  const p6Prop = calculatePropulsion(config, 0.28, 500, 0.45);
  const p6FuelBurnKg = p6Prop.fuelFlowKgS * p6TimeMin * 60 * 0.5;
  const p6StartWeight = currentWeightKg;
  currentWeightKg -= p6FuelBurnKg;
  phases.push({
    phaseName: 'Approach, Landing & Taxi',
    startAltitudeM: 3000,
    endAltitudeM: 0,
    startMach: 0.45,
    endMach: 0.22,
    distanceKm: p6DistNm * 1.852,
    distanceNm: p6DistNm,
    timeMinutes: p6TimeMin,
    fuelBurnKg: p6FuelBurnKg,
    startWeightKg: p6StartWeight,
    endWeightKg: currentWeightKg,
    avgThrustN: p6Prop.netThrustN,
    avgTsfc: p6Prop.tsfcKgNH,
    avgLD: p6Aero.liftToDrag,
  });

  // Totals
  const tripFuelKg = phases.reduce((sum, p) => sum + p.fuelBurnKg, 0);
  const totalFlightTimeMin = phases.reduce((sum, p) => sum + p.timeMinutes, 0);
  const flightTimeHours = totalFlightTimeMin / 60.0;
  const blockTimeHours = flightTimeHours + 0.35; // 21 min taxi in/out & ground maneuvering

  // RESERVES per FAA FAR Part 25 / ICAO SST Rules:
  // 1. 5% contingency fuel on trip fuel
  const contingencyFuelKg = tripFuelKg * 0.05;
  // 2. 200 nm diversion at subsonic speed (M 0.78, 25,000 ft)
  const diversionFuelKg = (200.0 / 450.0) * (cruiseProp.fuelFlowKgS * 3600 * 0.65);
  // 3. 30 minutes holding at 1,500 ft (M 0.30)
  const holdingFuelKg = (30.0 / 60.0) * (p1Prop.fuelFlowKgS * 3600 * 0.45);
  const totalReserveFuelKg = contingencyFuelKg + diversionFuelKg + holdingFuelKg;

  const blockFuelKg = tripFuelKg + totalReserveFuelKg + 350.0; // 350 kg taxi fuel
  const landingWeightKg = currentWeightKg;

  // Environmental Metrics
  const safRatio = config.safBlendRatio.value;
  // Standard Jet-A emits 3.16 kg CO2 / kg fuel
  // SAF lifecycle reduction ~80%
  const effectiveCo2PerKgFuel = 3.16 * (1.0 - 0.80 * safRatio);
  const totalCo2Kg = tripFuelKg * effectiveCo2PerKgFuel;

  const fuelPerPassengerKg = tripFuelKg / Math.max(1, actualPax);
  const totalPaxKm = actualPax * routeDistKm;
  const fuelPerPaxKmGrams = (tripFuelKg * 1000.0) / Math.max(1, totalPaxKm);
  const co2PerPaxKmGrams = (totalCo2Kg * 1000.0) / Math.max(1, totalPaxKm);

  // Feasibility evaluation
  const feasibilityNotes: string[] = [];
  let isMissionFeasible = true;

  if (blockFuelKg > maxFuelKg) {
    isMissionFeasible = false;
    feasibilityNotes.push(`Required fuel (${Math.round(blockFuelKg).toLocaleString()} kg) exceeds tank capacity (${Math.round(maxFuelKg).toLocaleString()} kg).`);
  }
  if (takeoffWeightKg > mtowLimitKg) {
    isMissionFeasible = false;
    feasibilityNotes.push(`Takeoff weight (${Math.round(takeoffWeightKg).toLocaleString()} kg) exceeds structural MTOW (${Math.round(mtowLimitKg).toLocaleString()} kg).`);
  }
  if (routeDistNm > config.designRange.value) {
    feasibilityNotes.push(`Route length (${Math.round(routeDistNm)} nm) exceeds baseline design range (${Math.round(config.designRange.value)} nm).`);
  }
  if (isMissionFeasible) {
    feasibilityNotes.push(`Mission feasible with full FAA Part 25 reserves (${Math.round(totalReserveFuelKg).toLocaleString()} kg).`);
  }

  return {
    route,
    phases,
    totalDistanceKm: routeDistKm,
    totalDistanceNm: routeDistNm,
    blockTimeHours,
    flightTimeHours,
    blockFuelKg,
    tripFuelKg,
    contingencyFuelKg,
    diversionFuelKg,
    holdingFuelKg,
    totalReserveFuelKg,
    takeoffWeightKg,
    landingWeightKg,
    payloadCarriedKg,
    fuelPerPassengerKg,
    fuelPerPaxKmGrams,
    co2PerPaxKmGrams,
    isMissionFeasible,
    feasibilityNotes,
  };
}
