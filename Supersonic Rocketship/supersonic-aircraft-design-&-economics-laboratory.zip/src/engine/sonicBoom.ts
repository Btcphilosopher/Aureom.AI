import { AircraftConfiguration } from '../types/aircraft';
import { SonicBoomSignature } from '../types/physics';
import { getAtmosphere } from './atmosphere';

/**
 * Supersonic Sonic Boom Overpressure & Perceived Loudness Engine
 * Based on Whitham-Carlson near-to-far field wave propagation and
 * NASA Quesst / X-59 low-boom shaping metrics.
 */

export function calculateSonicBoom(
  config: AircraftConfiguration,
  mach: number,
  cruiseAltitudeM: number,
  weightKg: number
): SonicBoomSignature {
  const atmosCruise = getAtmosphere(cruiseAltitudeM);
  const atmosSL = getAtmosphere(0);

  const altitudeFt = cruiseAltitudeM * 3.28084;
  const weightLbs = weightKg * 2.20462;
  const lengthFt = config.fuselageLength.value * 3.28084;
  const isShaped = config.isLowBoomShaped.value;

  // If Mach is subsonic or near 1.0, no ground shock reaches ground
  if (mach <= 1.05) {
    return {
      mach,
      cruiseAltitudeFt: altitudeFt,
      overpressurePsf: 0.0,
      perceivedLoudnessPLdB: 0.0,
      faaStandardAllowedPsf: 0.11,
      isOverlandAllowed: true,
      groundFootprintWidthNm: 0.0,
    };
  }

  const beta = Math.sqrt(mach * mach - 1.0);
  const pCruisePsf = atmosCruise.pressurePa * 0.0208854; // Pa to psf
  const pGroundPsf = atmosSL.pressurePa * 0.0208854;

  // Carlson shock overpressure factor (Kp)
  // Conventional N-wave aircraft (like Concorde): Kp ~ 0.55 - 0.70
  // Low-boom shaped airframe (Lockheed X-59 style / area-ruled): Kp ~ 0.12 - 0.22
  let kp = isShaped ? 0.18 : 0.62;
  
  // Area ruling and coke-bottle shaping attenuate overpressure
  const areaRuling = config.areaRulingQuality.value;
  kp *= 1.0 - 0.35 * areaRuling;

  // Whitham-Carlson ground overpressure formula
  // Delta_P = Kp * sqrt(P_ground * P_alt) / (h_ft ^ 0.75) * (M^2 - 1)^0.125 * (W / L)^0.5
  const altTerm = Math.pow(Math.max(10000, altitudeFt), 0.75);
  const machTerm = Math.pow(beta, 0.25);
  const wlTerm = Math.sqrt(weightLbs / Math.max(50.0, lengthFt));
  const pressureProduct = Math.sqrt(pGroundPsf * pCruisePsf);

  let overpressurePsf = (kp * pressureProduct * machTerm * wlTerm) / altTerm;

  // Boom perceived loudness PLdB empirical calibration:
  // Concorde ~ 105 PLdB (approx 2.0 - 2.2 psf)
  // Low-boom target ~ 75 PLdB (approx 0.11 psf)
  let perceivedLoudnessPLdB = 94.0 + 20.0 * Math.log10(Math.max(0.01, overpressurePsf));
  if (isShaped) {
    perceivedLoudnessPLdB -= 12.0; // Shaped signature avoids sharp N-wave pressure spikes
  }

  // FAA 2026 NPRM Low-Boom overland standard: <= 0.11 psf or ~75 PLdB
  const faaAllowedPsf = 0.11;
  const isOverlandAllowed = overpressurePsf <= faaAllowedPsf;

  // Ground carpet footprint width across the flight path:
  // W_carpet ~ 2 * h * tan(mu) where sin(mu) = 1/M
  const machAngleRad = Math.asin(1.0 / mach);
  const carpetWidthM = 2.0 * cruiseAltitudeM * Math.tan(machAngleRad) * 1.8;
  const groundFootprintWidthNm = carpetWidthM / 1852.0;

  return {
    mach,
    cruiseAltitudeFt: altitudeFt,
    overpressurePsf: Math.round(overpressurePsf * 1000) / 1000,
    perceivedLoudnessPLdB: Math.round(perceivedLoudnessPLdB * 10) / 10,
    faaStandardAllowedPsf: faaAllowedPsf,
    isOverlandAllowed,
    groundFootprintWidthNm: Math.round(groundFootprintWidthNm * 10) / 10,
  };
}
