import { AtmosphereState } from '../types/physics';

/**
 * 1976 U.S. Standard Atmosphere (ISA) Model
 * Valid from Sea Level (0 m) to Stratosphere (32,000 m / 105,000 ft)
 * Governing equations:
 * Hydrostatic: dP = -rho * g * dh
 * Ideal Gas: P = rho * R * T
 * Temperature lapse rate: T(h) = T_base + L * (h - h_base)
 */

const G0 = 9.80665; // m/s²
const R_AIR = 287.05287; // J/(kg*K)
const GAMMA = 1.4; // Specific heat ratio for air
const SUTHERLAND_C = 120.0; // K
const SUTHERLAND_T0 = 291.15; // K
const SUTHERLAND_MU0 = 1.827e-5; // Pa*s

interface AtmosphericLayer {
  baseAltM: number;
  lapseRateKPerM: number;
  baseTempK: number;
  basePressurePa: number;
}

const LAYERS: AtmosphericLayer[] = [
  { baseAltM: 0, lapseRateKPerM: -0.0065, baseTempK: 288.15, basePressurePa: 101325.0 }, // Troposphere (0 - 11,000 m)
  { baseAltM: 11000, lapseRateKPerM: 0.0, baseTempK: 216.65, basePressurePa: 22632.1 }, // Tropopause (11,000 - 20,000 m)
  { baseAltM: 20000, lapseRateKPerM: 0.0010, baseTempK: 216.65, basePressurePa: 5474.89 }, // Stratosphere 1 (20,000 - 32,000 m)
];

export function getAtmosphere(altitudeM: number): AtmosphereState {
  const h = Math.max(0, Math.min(32000, altitudeM));
  
  let layer = LAYERS[0];
  if (h >= 20000) {
    layer = LAYERS[2];
  } else if (h >= 11000) {
    layer = LAYERS[1];
  }

  const dh = h - layer.baseAltM;
  let tempK: number;
  let pressurePa: number;

  if (Math.abs(layer.lapseRateKPerM) < 1e-8) {
    // Isothermal layer
    tempK = layer.baseTempK;
    pressurePa = layer.basePressurePa * Math.exp((-G0 * dh) / (R_AIR * tempK));
  } else {
    // Gradient layer
    tempK = layer.baseTempK + layer.lapseRateKPerM * dh;
    const exponent = -G0 / (layer.lapseRateKPerM * R_AIR);
    pressurePa = layer.basePressurePa * Math.pow(tempK / layer.baseTempK, exponent);
  }

  const densityKgM3 = pressurePa / (R_AIR * tempK);
  const speedOfSoundMS = Math.sqrt(GAMMA * R_AIR * tempK);
  const speedOfSoundKts = speedOfSoundMS * 1.94384;
  
  // Sutherland's law for dynamic viscosity
  const viscosityPaS =
    SUTHERLAND_MU0 *
    Math.pow(tempK / SUTHERLAND_T0, 1.5) *
    ((SUTHERLAND_T0 + SUTHERLAND_C) / (tempK + SUTHERLAND_C));

  return {
    altitudeM: h,
    altitudeFt: h * 3.28084,
    temperatureK: tempK,
    temperatureC: tempK - 273.15,
    pressurePa,
    densityKgM3,
    speedOfSoundMS,
    speedOfSoundKts,
    viscosityPaS,
  };
}

export function altitudeFtToM(ft: number): number {
  return ft * 0.3048;
}

export function altitudeMToFt(m: number): number {
  return m * 3.28084;
}
