import { AircraftConfiguration } from '../types/aircraft';
import { PropulsionState } from '../types/physics';
import { getAtmosphere } from './atmosphere';

/**
 * Supersonic Propulsion Engine
 * Models thermodynamic cycle, inlet pressure recovery, nozzle expansion,
 * thrust lapse vs Mach/altitude, TSFC, and SAF fuel consumption.
 */

export function calculateInletPressureRecovery(mach: number, inletEfficiencyBase: number = 0.96): number {
  if (mach <= 1.0) {
    return inletEfficiencyBase * (1.0 - 0.02 * mach);
  }
  // MIL-E-5007D Standard supersonic inlet pressure recovery with variable ramps
  const milLoss = 0.075 * Math.pow(mach - 1.0, 1.35);
  const recovery = inletEfficiencyBase * (1.0 - milLoss);
  return Math.max(0.70, Math.min(0.98, recovery));
}

export function calculatePropulsion(
  config: AircraftConfiguration,
  mach: number,
  altitudeM: number,
  throttle: number = 1.0, // 0.0 to 1.0
  isAfterburnerActive: boolean = false
): PropulsionState {
  const atmos = getAtmosphere(altitudeM);
  const atmosSL = getAtmosphere(0);
  const densityRatio = atmos.densityKgM3 / atmosSL.densityKgM3;
  const tempRatio = atmos.temperatureK / atmosSL.temperatureK;
  const velocityMS = mach * atmos.speedOfSoundMS;

  const cycle = config.engineCycle.value;
  const bpr = config.bypassRatio.value;
  const opr = config.overallPressureRatio.value;
  const titK = config.turbineInletTemp.value;
  const numEngines = config.numEngines.value;
  const staticThrustTotalN = config.staticThrustPerEngine.value * numEngines;
  const baseTsfcKgNH = config.tsfcCruise.value; // kg/(N*h)
  const safRatio = config.safBlendRatio.value;

  // Inlet pressure recovery
  const inletRecovery = calculateInletPressureRecovery(mach, config.inletEfficiency.value);

  // Density and dynamic pressure thrust lapse
  // Supersonic ram compression effect increases airflow, but high thermal backpressure limits thrust
  let ramFactor = 1.0 + 0.2 * mach * mach;
  if (cycle === 'turbojet' || cycle === 'afterburning_turbojet') {
    ramFactor = 1.0 + 0.35 * Math.pow(mach, 1.8);
  } else if (cycle === 'variable_cycle') {
    ramFactor = 1.0 + 0.28 * Math.pow(mach, 1.6);
  } else {
    // Turbofan
    ramFactor = 1.0 + 0.18 * Math.pow(mach, 1.4);
  }

  const altitudeLapse = Math.pow(densityRatio, 0.85) * Math.pow(tempRatio, -0.2);
  let availableThrustN = staticThrustTotalN * altitudeLapse * (ramFactor / 1.5) * inletRecovery * throttle;

  if (isAfterburnerActive && config.hasAfterburner.value) {
    availableThrustN *= config.afterburnerThrustBoost.value;
  }

  // TSFC variation with Mach and altitude
  // TSFC increases with Mach due to ram temperature rise: TSFC_M = TSFC_0 * sqrt(T_tot / T_amb)
  const totalTempRatio = 1.0 + 0.2 * mach * mach;
  let cycleTsfcMultiplier = 1.0;
  if (cycle === 'turbojet') {
    cycleTsfcMultiplier = 0.90 + 0.15 * mach;
  } else if (cycle === 'medium_bypass_turbofan') {
    cycleTsfcMultiplier = 0.82 + 0.22 * mach;
  } else if (cycle === 'variable_cycle') {
    cycleTsfcMultiplier = 0.76 + 0.18 * mach;
  }

  // Higher TIT and OPR improve thermal efficiency, reducing TSFC
  const titFactor = Math.pow(1650.0 / Math.max(1200, titK), 0.35);
  const oprFactor = Math.pow(25.0 / Math.max(10, opr), 0.25);

  let currentTsfcKgNH = baseTsfcKgNH * Math.sqrt(totalTempRatio) * cycleTsfcMultiplier * titFactor * oprFactor;
  
  if (isAfterburnerActive && config.hasAfterburner.value) {
    currentTsfcKgNH *= 1.85; // Massive TSFC increase with reheat
  }

  // 100% SAF has ~1.8% higher Lower Heating Value (LHV) than Jet-A (43.8 MJ/kg vs 43.0 MJ/kg)
  // which reduces fuel mass consumption rate
  const safMassSavingFactor = 1.0 - 0.018 * safRatio;
  currentTsfcKgNH *= safMassSavingFactor;

  const currentTsfcLbLbfH = currentTsfcKgNH * 9.80665 * 0.10197; // conversion to standard lb/(lbf*h)

  // Net fuel flow rate: kg/s = (TSFC [kg/(N*h)] * Thrust [N]) / 3600
  const fuelFlowKgS = (currentTsfcKgNH * availableThrustN) / 3600.0;

  // Efficiencies
  const jetVelocityMS = velocityMS + (availableThrustN / Math.max(10.0, fuelFlowKgS * 50.0));
  const propulsiveEfficiency = (2.0 * velocityMS) / Math.max(velocityMS + 1.0, velocityMS + jetVelocityMS);
  const thermalEfficiency = 0.42 * (1.0 - 1.0 / Math.pow(Math.max(5, opr), 0.286));
  const overallEfficiency = propulsiveEfficiency * thermalEfficiency;

  const inletDragN = 0.02 * availableThrustN * (mach > 1.0 ? mach : 0.0);

  return {
    mach,
    altitudeM,
    inletPressureRecovery: inletRecovery,
    inletDragN,
    grossThrustN: availableThrustN + inletDragN,
    netThrustN: availableThrustN,
    fuelFlowKgS,
    tsfcKgNH: currentTsfcKgNH,
    tsfcLbLbfH: currentTsfcLbLbfH,
    nozzleExpansionRatio: Math.max(1.0, 1.2 * mach),
    thermalEfficiency,
    propulsiveEfficiency,
    overallEfficiency,
  };
}
