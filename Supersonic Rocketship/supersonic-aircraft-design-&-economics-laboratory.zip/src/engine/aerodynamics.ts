import { AircraftConfiguration } from '../types/aircraft';
import { AerodynamicState } from '../types/physics';
import { getAtmosphere } from './atmosphere';

/**
 * Supersonic Conceptual Aerodynamics Engine
 * 
 * Equations:
 * 1. Dynamic Pressure: q = 0.5 * rho * V^2
 * 2. Parasite Drag: Cd0 = Cf * (Swet / Swing) * FF
 *    where turbulent flat plate Cf = 0.455 / (log10(Re)^2.58 * (1 + 0.144 * M^2)^0.65)
 * 3. Induced Drag: Cdi = Cl^2 / (pi * AR * e)
 *    where supersonic Oswald efficiency e_supersonic is modified for supersonic leading edge
 * 4. Wave Drag: Cdw = Cdw_vol + Cdw_wing
 *    Cdw_wing = 4 * (t/c)^2 / sqrt(M^2 - 1) * cos^2(sweep) * (1 - 0.45 * areaRulingQuality)
 *    Cdw_fuselage = 128 / (pi * (L_fuse/D_fuse)^2) * (1 - 0.6 * areaRulingQuality) / sqrt(M^2 - 1)
 * 5. Transonic Drag Rise: Modeled with cubic spline transition from M_crit (~0.88) to M 1.15
 */

export function calculateAerodynamics(
  config: AircraftConfiguration,
  mach: number,
  altitudeM: number,
  weightKg: number,
  regime: 'Takeoff' | 'Climb' | 'Transonic' | 'Supersonic' | 'Descent' | 'Approach' = 'Supersonic'
): AerodynamicState {
  const atmos = getAtmosphere(altitudeM);
  const velocityMS = mach * atmos.speedOfSoundMS;
  const qInfPa = 0.5 * atmos.densityKgM3 * velocityMS * velocityMS;

  const wingArea = config.wingArea.value;
  const aspectRatio = config.aspectRatio.value;
  const sweepRad = (config.sweepAngle.value * Math.PI) / 180;
  const tcRatio = config.thicknessChordRatio.value;
  const areaRuling = config.areaRulingQuality.value;
  const oswaldBase = config.oswaldEfficiency.value;
  const wettedArea = config.wettedArea.value;
  const fuseLength = config.fuselageLength.value;
  const fuseDia = config.fuselageDiameter.value;

  // Weight force in Newtons
  const weightN = weightKg * 9.80665;

  // Required Lift Coefficient (1g level flight)
  let cl = weightN / Math.max(1.0, qInfPa * wingArea);
  // Clamp CL to realistic physical limits for regime
  if (regime === 'Takeoff' || regime === 'Approach') {
    cl = Math.min(1.6, Math.max(0.4, cl));
  } else {
    cl = Math.min(0.6, Math.max(0.04, cl));
  }

  // 1. Parasite Drag (Skin Friction)
  const charLength = wingArea / config.wingSpan.value; // Mean aerodynamic chord
  const reynolds = (atmos.densityKgM3 * velocityMS * charLength) / Math.max(1e-7, atmos.viscosityPaS);
  
  // Compressible turbulent skin friction coefficient
  const logRe = Math.max(4.0, Math.log10(reynolds));
  const cfIncompressible = 0.455 / Math.pow(logRe, 2.58);
  const compressibilityCorrection = Math.pow(1 + 0.144 * mach * mach, 0.65);
  const cf = cfIncompressible / compressibilityCorrection;
  
  // Form factor for slender delta / supersonic fuselage
  const formFactor = 1.0 + 2.0 * tcRatio + 60.0 * Math.pow(tcRatio, 4);
  const cdParasite = cf * formFactor * (wettedArea / wingArea);

  // 2. Induced Drag (Lift-dependent drag)
  let oswaldEff = oswaldBase;
  if (mach > 1.0) {
    // Supersonic induced drag degrades as Mach increases
    const beta = Math.sqrt(mach * mach - 1.0);
    const supersonicInducedCorrection = 1.0 / (1.0 + 0.35 * beta);
    oswaldEff = oswaldBase * supersonicInducedCorrection;
  }
  const cdInduced = (cl * cl) / (Math.PI * aspectRatio * Math.max(0.3, oswaldEff));

  // 3. Wave Drag (Pressure drag due to shocks)
  let cdWave = 0.0;
  if (mach > 0.95) {
    if (mach < 1.15) {
      // Transonic peak region
      const tPeak = (mach - 0.95) / 0.20; // 0 to 1
      const wavePeak = 0.014 * (1.0 - 0.4 * areaRuling) * (tcRatio / 0.04);
      cdWave = wavePeak * Math.sin(tPeak * Math.PI);
    } else {
      // Supersonic regime
      const beta = Math.sqrt(mach * mach - 1.0);
      const finenessRatio = fuseLength / fuseDia;
      
      // Fuselage volume wave drag (modified Sears-Haack with area ruling attenuation)
      const cdWaveFuse = (128.0 / (Math.PI * Math.pow(finenessRatio, 2))) * (1.0 - 0.55 * areaRuling) * (1.0 / beta);
      
      // Wing thickness wave drag
      const sweepCos = Math.cos(sweepRad);
      const cdWaveWing = 4.0 * Math.pow(tcRatio, 2) * Math.pow(sweepCos, 2) * (1.0 / beta) * (1.0 - 0.35 * areaRuling);
      
      cdWave = (cdWaveFuse * 0.4 + cdWaveWing * 1.6) * 0.016;
    }
  }

  const cdTotal = cdParasite + cdInduced + cdWave;
  const liftToDrag = cl / Math.max(0.001, cdTotal);
  const liftN = cl * qInfPa * wingArea;
  const dragN = cdTotal * qInfPa * wingArea;
  const thrustRequiredN = dragN;

  return {
    mach,
    altitudeM,
    qInfPa,
    velocityMS,
    cl,
    cdParasite,
    cdInduced,
    cdWave,
    cdTotal,
    liftToDrag,
    liftN,
    dragN,
    thrustRequiredN,
    regime,
  };
}

export function generateMachDragPolar(
  config: AircraftConfiguration,
  altitudeM: number,
  weightKg: number,
  machSteps: number[] = [0.4, 0.6, 0.8, 0.95, 1.05, 1.2, 1.4, 1.6, 1.7, 1.8, 2.0, 2.2]
): AerodynamicState[] {
  return machSteps.map((m) => {
    let regime: 'Takeoff' | 'Climb' | 'Transonic' | 'Supersonic' | 'Descent' = 'Supersonic';
    if (m < 0.5) regime = 'Takeoff';
    else if (m < 0.9) regime = 'Climb';
    else if (m <= 1.15) regime = 'Transonic';
    return calculateAerodynamics(config, m, altitudeM, weightKg, regime);
  });
}
