import { AircraftConfiguration } from '../types/aircraft';
import { DesignPoint } from '../types/designSpace';

/**
 * Generates standalone, compilable, professional Rust Physics Engine source code
 */
export function generateRustCode(config: AircraftConfiguration): string {
  return `//! ==============================================================================
//! SUPERSONIC AIRCRAFT DESIGN LABORATORY - DETERMINISTIC PHYSICS ENGINE
//! Crate: supersonic_physics_engine
//! Model Version: ${config.modelVersion}
//! Architecture: SI Units Internal Representation with Strict Type Safety
//! ==============================================================================

pub mod units {
    pub const G0: f64 = 9.80665; // m/s^2
    pub const R_AIR: f64 = 287.05287; // J/(kg*K)
    pub const GAMMA: f64 = 1.4; // Specific heat ratio
    pub const SUTHERLAND_C: f64 = 120.0; // K
    pub const SUTHERLAND_T0: f64 = 291.15; // K
    pub const SUTHERLAND_MU0: f64 = 1.827e-5; // Pa*s
}

pub mod atmosphere {
    use super::units::*;

    #[derive(Debug, Clone, Copy)]
    pub struct AtmosphereState {
        pub altitude_m: f64,
        pub temperature_k: f64,
        pub pressure_pa: f64,
        pub density_kg_m3: f64,
        pub speed_of_sound_ms: f64,
        pub viscosity_pa_s: f64,
    }

    pub fn get_isa_atmosphere(altitude_m: f64) -> AtmosphereState {
        let h = altitude_m.max(0.0).min(32000.0);
        let (base_alt, lapse_rate, base_temp, base_press) = if h >= 20000.0 {
            (20000.0, 0.0010, 216.65, 5474.89)
        } else if h >= 11000.0 {
            (11000.0, 0.0, 216.65, 22632.1)
        } else {
            (0.0, -0.0065, 288.15, 101325.0)
        };

        let dh = h - base_alt;
        let (temp_k, pressure_pa) = if lapse_rate.abs() < 1e-9 {
            let p = base_press * (-G0 * dh / (R_AIR * base_temp)).exp();
            (base_temp, p)
        } else {
            let t = base_temp + lapse_rate * dh;
            let exponent = -G0 / (lapse_rate * R_AIR);
            let p = base_press * (t / base_temp).powf(exponent);
            (t, p)
        };

        let density_kg_m3 = pressure_pa / (R_AIR * temp_k);
        let speed_of_sound_ms = (GAMMA * R_AIR * temp_k).sqrt();
        let viscosity_pa_s = SUTHERLAND_MU0 * (temp_k / SUTHERLAND_T0).powf(1.5)
            * ((SUTHERLAND_T0 + SUTHERLAND_C) / (temp_k + SUTHERLAND_C));

        AtmosphereState {
            altitude_m: h,
            temperature_k: temp_k,
            pressure_pa,
            density_kg_m3,
            speed_of_sound_ms,
            viscosity_pa_s,
        }
    }
}

pub mod aerodynamics {
    use super::atmosphere::get_isa_atmosphere;
    use super::units::G0;

    #[derive(Debug, Clone)]
    pub struct AerodynamicResult {
        pub mach: f64,
        pub dynamic_pressure_pa: f64,
        pub cl: f64,
        pub cd_parasite: f64,
        pub cd_induced: f64,
        pub cd_wave: f64,
        pub cd_total: f64,
        pub lift_to_drag: f64,
        pub drag_n: f64,
    }

    pub fn calculate_aerodynamics(
        mach: f64,
        altitude_m: f64,
        weight_kg: f64,
        wing_area_m2: f64,
        wing_span_m: f64,
        aspect_ratio: f64,
        sweep_deg: f64,
        tc_ratio: f64,
        wetted_area_m2: f64,
        fuselage_len_m: f64,
        fuselage_dia_m: f64,
        area_ruling_quality: f64,
        oswald_base: f64,
    ) -> AerodynamicResult {
        let atmos = get_isa_atmosphere(altitude_m);
        let velocity_ms = mach * atmos.speed_of_sound_ms;
        let q_inf = 0.5 * atmos.density_kg_m3 * velocity_ms * velocity_ms;

        let weight_n = weight_kg * G0;
        let cl = (weight_n / (q_inf * wing_area_m2).max(1.0)).max(0.04).min(0.60);

        // Parasite drag
        let mac = wing_area_m2 / wing_span_m;
        let reynolds = (atmos.density_kg_m3 * velocity_ms * mac) / atmos.viscosity_pa_s.max(1e-7);
        let log_re = reynolds.log10().max(4.0);
        let cf_incomp = 0.455 / log_re.powf(2.58);
        let cf = cf_incomp / (1.0 + 0.144 * mach * mach).powf(0.65);
        let form_factor = 1.0 + 2.0 * tc_ratio + 60.0 * tc_ratio.powi(4);
        let cd_parasite = cf * form_factor * (wetted_area_m2 / wing_area_m2);

        // Induced drag
        let oswald_eff = if mach > 1.0 {
            let beta = (mach * mach - 1.0).sqrt();
            oswald_base / (1.0 + 0.35 * beta)
        } else {
            oswald_base
        };
        let cd_induced = (cl * cl) / (std::f64::consts::PI * aspect_ratio * oswald_eff.max(0.3));

        // Wave drag
        let cd_wave = if mach > 0.95 {
            let beta = (mach * mach - 1.0).max(0.05).sqrt();
            let fineness = fuselage_len_m / fuselage_dia_m;
            let cd_wave_fuse = (128.0 / (std::f64::consts::PI * fineness.powi(2)))
                * (1.0 - 0.55 * area_ruling_quality) / beta;
            let sweep_rad = sweep_deg.to_radians();
            let cd_wave_wing = 4.0 * tc_ratio.powi(2) * sweep_rad.cos().powi(2)
                * (1.0 - 0.35 * area_ruling_quality) / beta;
            (cd_wave_fuse * 0.4 + cd_wave_wing * 1.6) * 0.016
        } else {
            0.0
        };

        let cd_total = cd_parasite + cd_induced + cd_wave;
        let lift_to_drag = cl / cd_total.max(1e-4);
        let drag_n = cd_total * q_inf * wing_area_m2;

        AerodynamicResult {
            mach,
            dynamic_pressure_pa: q_inf,
            cl,
            cd_parasite,
            cd_induced,
            cd_wave,
            cd_total,
            lift_to_drag,
            drag_n,
        }
    }
}

pub mod propulsion {
    #[derive(Debug, Clone)]
    pub struct PropulsionResult {
        pub net_thrust_n: f64,
        pub tsfc_kg_n_h: f64,
        pub fuel_flow_kg_s: f64,
        pub inlet_recovery: f64,
    }

    pub fn calculate_propulsion(
        mach: f64,
        altitude_m: f64,
        num_engines: usize,
        static_thrust_per_engine_n: f64,
        base_tsfc_cruise: f64,
        saf_blend_ratio: f64,
    ) -> PropulsionResult {
        let atmos = super::atmosphere::get_isa_atmosphere(altitude_m);
        let density_ratio = atmos.density_kg_m3 / 1.225;
        let temp_ratio = atmos.temperature_k / 288.15;

        // MIL-E-5007D inlet recovery
        let inlet_recovery = if mach <= 1.0 {
            0.965 * (1.0 - 0.02 * mach)
        } else {
            0.965 * (1.0 - 0.075 * (mach - 1.0).powf(1.35)).max(0.75)
        };

        let total_static_thrust = (num_engines as f64) * static_thrust_per_engine_n;
        let ram_factor = 1.0 + 0.18 * mach.powf(1.4);
        let altitude_lapse = density_ratio.powf(0.85) * temp_ratio.powf(-0.2);
        let net_thrust_n = total_static_thrust * altitude_lapse * (ram_factor / 1.5) * inlet_recovery;

        let total_temp_ratio = 1.0 + 0.2 * mach * mach;
        let saf_benefit = 1.0 - 0.018 * saf_blend_ratio;
        let tsfc_kg_n_h = base_tsfc_cruise * total_temp_ratio.sqrt() * saf_benefit;
        let fuel_flow_kg_s = (tsfc_kg_n_h * net_thrust_n) / 3600.0;

        PropulsionResult {
            net_thrust_n,
            tsfc_kg_n_h,
            fuel_flow_kg_s,
            inlet_recovery,
        }
    }
}

pub mod mission {
    use super::aerodynamics::calculate_aerodynamics;
    use super::propulsion::calculate_propulsion;

    pub fn simulate_breguet_cruise(
        initial_weight_kg: f64,
        mach: f64,
        altitude_m: f64,
        distance_km: f64,
        ld: f64,
        tsfc_kg_n_h: f64,
    ) -> (f64, f64) {
        let speed_ms = mach * super::atmosphere::get_isa_atmosphere(altitude_m).speed_of_sound_ms;
        let tsfc_si = tsfc_kg_n_h / 3600.0; // kg/(N*s)
        let exponent = (distance_km * 1000.0 * super::units::G0 * tsfc_si) / (speed_ms * ld);
        let final_weight_kg = initial_weight_kg * (-exponent).exp();
        let fuel_burned_kg = initial_weight_kg - final_weight_kg;
        (final_weight_kg, fuel_burned_kg)
    }
}

fn main() {
    println!("--------------------------------------------------");
    println!("SUPERSONIC AIRLINER PHYSICS ENGINE (RUST KERNEL)");
    println!("Aircraft: {}", "${config.name}");
    println!("Cruise Mach: {}", ${config.machCruise.value});
    println!("MTOW: {} kg", ${config.mtow.value});
    println!("--------------------------------------------------");

    let aero = aerodynamics::calculate_aerodynamics(
        ${config.machCruise.value},
        ${config.cruiseAltitude.value},
        ${config.mtow.value},
        ${config.wingArea.value},
        ${config.wingSpan.value},
        ${config.aspectRatio.value},
        ${config.sweepAngle.value},
        ${config.thicknessChordRatio.value},
        ${config.wettedArea.value},
        ${config.fuselageLength.value},
        ${config.fuselageDiameter.value},
        ${config.areaRulingQuality.value},
        ${config.oswaldEfficiency.value},
    );

    println!("Aerodynamics evaluated at FL600 M{:.2}:", aero.mach);
    println!("  L/D Ratio: {:.2}", aero.lift_to_drag);
    println!("  Total Cd:  {:.5}", aero.cd_total);
    println!("  Drag:      {:.0} N", aero.drag_n);

    let prop = propulsion::calculate_propulsion(
        ${config.machCruise.value},
        ${config.cruiseAltitude.value},
        ${config.numEngines.value},
        ${config.staticThrustPerEngine.value},
        ${config.tsfcCruise.value},
        ${config.safBlendRatio.value},
    );

    println!("Propulsion Cycle:");
    println!("  Net Installed Thrust: {:.0} N", prop.net_thrust_n);
    println!("  Cruise TSFC:          {:.4} kg/(N*h)", prop.tsfc_kg_n_h);
    println!("  Fuel Flow:            {:.2} kg/s", prop.fuel_flow_kg_s);

    let (end_wt, fuel_burn) = mission::simulate_breguet_cruise(
        ${config.mtow.value},
        ${config.machCruise.value},
        ${config.cruiseAltitude.value},
        ${config.designRange.value * 1.852},
        aero.lift_to_drag,
        prop.tsfc_kg_n_h,
    );

    println!("Breguet Range Integration for {} km:", ${config.designRange.value * 1.852});
    println!("  Final Landing Weight: {:.0} kg", end_wt);
    println!("  Total Trip Fuel Burn: {:.0} kg", fuel_burn);
    println!("--------------------------------------------------");
}
`;
}

/**
 * Generates standalone, executable R economics and Monte Carlo script
 */
export function generateRScript(config: AircraftConfiguration): string {
  return `################################################################################
# SUPERSONIC AIRCRAFT AIRLINE ECONOMICS & MONTE CARLO SIMULATOR
# R Statistical Computing Script
# Aircraft: ${config.name} (Mach ${config.machCruise.value})
################################################################################

suppressPackageStartupMessages({
  # Base R statistical functions are utilized for 100% reproducible execution
})

set.seed(2026)

# ------------------------------------------------------------------------------
# 1. PARAMETERS & INPUT DISTRIBUTIONS
# ------------------------------------------------------------------------------
N_SIM <- 50000 # 50,000 Monte Carlo iterations

aircraft_price_M <- ${config.aircraftUnitPrice.value}
pax_capacity <- ${config.passengerCapacity.value}
block_hours <- 3.75
stage_length_km <- 5585 # London -> New York (3016 nm)

# Uncertain Distributions
tsfc_mult <- rnorm(N_SIM, mean = 1.0, sd = 0.06)
ld_mult <- pmax(0.85, pmin(1.15, rnorm(N_SIM, mean = 1.0, sd = 0.07)))
fuel_price_gal <- rlnorm(N_SIM, meanlog = log(5.80), sdlog = 0.18)
load_factor <- rbeta(N_SIM, shape1 = 3.2, shape2 = 2.2) * 0.32 + 0.62 # [62%, 94%]
ticket_yield_mult <- rnorm(N_SIM, mean = 1.0, sd = 0.08)
maint_mult <- rlnorm(N_SIM, meanlog = log(1.0), sdlog = 0.12)

# ------------------------------------------------------------------------------
# 2. VECTORIZED PER-FLIGHT OPERATING ECONOMICS
# ------------------------------------------------------------------------------
trip_fuel_kg <- 30800 * (tsfc_mult / ld_mult)
trip_fuel_gal <- trip_fuel_kg / 3.04

fuel_cost_usd <- trip_fuel_gal * fuel_price_gal
crew_cost_usd <- block_hours * 2100
maint_cost_usd <- (block_hours - 0.35) * (980 + 4 * 420) * maint_mult
fees_usd <- (95000 / 1000) * 18.50 + stage_length_km * 0.92 + 3900
catering_usd <- pax_capacity * load_factor * 125

doc_flight_usd <- fuel_cost_usd + crew_cost_usd + maint_cost_usd + fees_usd + catering_usd

# Capital ownership per flight (16-yr SL depreciation, 3,650 annual hours)
annual_flights <- 3650 / block_hours
depr_flight_usd <- (aircraft_price_M * 1e6 * 0.90) / 16 / annual_flights
toc_flight_usd <- doc_flight_usd + depr_flight_usd

# Revenue Modeling
avg_fare_usd <- (0.20 * 8200 + 0.80 * 4900) * ticket_yield_mult
pax_rev_usd <- pax_capacity * load_factor * avg_fare_usd
cargo_ancillary_usd <- 4500
total_rev_usd <- pax_rev_usd + cargo_ancillary_usd

operating_profit_flight <- total_rev_usd - toc_flight_usd
operating_margin_pct <- (operating_profit_flight / total_rev_usd) * 100
casm_usd <- toc_flight_usd / (pax_capacity * stage_length_km)
break_even_load_factor <- pmin(1.2, pmax(0.1, (toc_flight_usd - cargo_ancillary_usd) / (pax_capacity * avg_fare_usd)))

# ------------------------------------------------------------------------------
# 3. 15-YEAR FLEET DISCOUNTED CASH FLOW (DCF - 25 AIRCRAFT)
# ------------------------------------------------------------------------------
fleet_size <- 25
annual_fleet_rev_M <- (annual_flights * fleet_size * total_rev_usd) / 1e6
annual_fleet_opex_M <- (annual_flights * fleet_size * doc_flight_usd) / 1e6
annual_ebitda_M <- annual_fleet_rev_M - annual_fleet_opex_M
fleet_capex_M <- fleet_size * aircraft_price_M * 1.12

# 15-Year NPV at 8.5% WACC
wacc <- 0.085
npv_15yr_M <- annual_ebitda_M * ((1 - (1 + wacc)^(-15)) / wacc) - fleet_capex_M

# ------------------------------------------------------------------------------
# 4. STATISTICAL SUMMARY & QUANTILE ANALYSIS
# ------------------------------------------------------------------------------
prob_profit <- mean(operating_profit_flight > 0) * 100

cat("========================================================================\\n")
cat("SUPERSONIC AIRLINE ECONOMICS SIMULATION RESULTS (N =", N_SIM, ")\\n")
cat("========================================================================\\n")
cat(sprintf("Probability of Flight Profitability: %.1f%%\\n", prob_profit))
cat(sprintf("Mean Operating Profit / Flight:     $%.0f\\n", mean(operating_profit_flight)))
cat(sprintf("Median Operating Margin:            %.1f%%\\n", median(operating_margin_pct)))
cat(sprintf("Mean CASM (Cost / Available Seat-km): $%.4f\\n", mean(casm_usd)))
cat(sprintf("Mean Break-Even Load Factor:        %.1f%%\\n", mean(break_even_load_factor) * 100))
cat("------------------------------------------------------------------------\\n")
cat("15-YEAR FLEET NPV (25 AIRCRAFT) PERCENTILES:\\n")
cat(sprintf("  P10 (Pessimistic):  $%.1f Million\\n", quantile(npv_15yr_M, 0.10)))
cat(sprintf("  P50 (Median):       $%.1f Million\\n", quantile(npv_15yr_M, 0.50)))
cat(sprintf("  P90 (Optimistic):   $%.1f Million\\n", quantile(npv_15yr_M, 0.90)))
cat(sprintf("  Value at Risk (95%%): $%.1f Million\\n", quantile(npv_15yr_M, 0.05)))
cat("========================================================================\\n")
`;
}

/**
 * Generates CSV dataset of design space points
 */
export function generateDesignSpaceCsv(points: DesignPoint[]): string {
  const headers = [
    'ID',
    'Name',
    'Mach',
    'Passengers',
    'Range_nm',
    'Engine_Cycle',
    'Aspect_Ratio',
    'Sweep_deg',
    'LD_Cruise',
    'TSFC_kg_N_h',
    'MTOW_kg',
    'OEW_kg',
    'BlockFuel_kg',
    'Fuel_Per_Pax_kg',
    'CASM_USD_seat_km',
    'Profit_Per_Flight_USD',
    'Operating_Margin_Pct',
    'NPV_15Yr_USD_M',
    'BreakEven_LoadFactor_Pct',
    'Classification',
    'Risk_Score',
    'Pareto_Optimal',
  ];

  const rows = points.map((p) => [
    p.id,
    `"${p.name}"`,
    p.mach,
    p.passengers,
    p.designRangeNm,
    p.engineCycle,
    p.aspectRatio,
    p.sweepDeg,
    p.liftToDragCruise,
    p.tsfcCruise,
    p.mtowKg,
    p.oewKg,
    p.blockFuelKg,
    p.fuelPerPaxKg,
    p.casmUsdPerSeatKm,
    p.operatingProfitFlightUsd,
    p.operatingMarginPercent,
    p.npvUsdMillion,
    p.breakEvenLoadFactorPercent,
    `"${p.classification}"`,
    p.riskScore,
    p.isParetoOptimal ? 'TRUE' : 'FALSE',
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}
