import { AircraftConfiguration } from '../types/aircraft';
import { EconomicAssumptions, FleetFinancials, FlightEconomicsResult } from '../types/economics';
import { MissionProfileResult } from '../types/physics';

/**
 * Calculates Fleet-level 15-Year Financials, EBITDA, DCF, NPV, IRR, and Payback
 */
export function calculateFleetFinancials(
  config: AircraftConfiguration,
  mission: MissionProfileResult,
  flightEcon: FlightEconomicsResult,
  fleetSize: number = 25,
  assumptions: EconomicAssumptions
): FleetFinancials {
  const aircraftPriceM = config.aircraftUnitPrice.value;
  // Volume discount for larger fleet purchases (e.g. 5% at 50, 12% at 250)
  let volumeDiscount = 0.0;
  if (fleetSize >= 250) volumeDiscount = 0.15;
  else if (fleetSize >= 100) volumeDiscount = 0.10;
  else if (fleetSize >= 50) volumeDiscount = 0.06;
  else if (fleetSize >= 25) volumeDiscount = 0.03;

  const effectiveUnitCapexM = aircraftPriceM * (1.0 - volumeDiscount);
  // Spares & ground tooling: 12% of aircraft capex
  const fleetCapexUsdMillion = fleetSize * effectiveUnitCapexM * 1.12;

  const annualHoursPerPlane = assumptions.aircraftUtilizationHoursPerYear;
  const annualFlightsPerPlane = annualHoursPerPlane / Math.max(1.0, mission.blockTimeHours);
  const annualFleetFlights = annualFlightsPerPlane * fleetSize;
  const annualFleetBlockHours = annualHoursPerPlane * fleetSize;

  const annualRevenueUsdMillion = (annualFleetFlights * flightEcon.totalRevenuePerFlightUsd) / 1e6;
  // OPEX before depreciation and interest
  const annualOpexUsdMillion = (annualFleetFlights * flightEcon.directOperatingCostPerFlightUsd) / 1e6;
  const annualEbitdaUsdMillion = annualRevenueUsdMillion - annualOpexUsdMillion;

  const annualDepreciationM = (fleetCapexUsdMillion * (1.0 - assumptions.aircraftResidualValueFraction)) / assumptions.aircraftUsefulLifeYears;
  const annualInterestM = fleetCapexUsdMillion * assumptions.debtFraction * assumptions.interestRate;
  
  const annualEbtM = annualEbitdaUsdMillion - annualDepreciationM - annualInterestM;
  const annualTaxM = Math.max(0, annualEbtM * assumptions.corporateTaxRate);
  const annualNetIncomeUsdMillion = annualEbtM - annualTaxM;

  // 15-Year DCF Projection
  const yearlyCashFlows: FleetFinancials['yearlyCashFlows'] = [];
  const years = 15;
  const wacc = assumptions.waccDiscountRate;

  // Year 0: Initial CAPEX outflow (staged delivery over years 0 and 1)
  let cumulativeCash = -fleetCapexUsdMillion * 0.60;
  yearlyCashFlows.push({
    year: 0,
    capex: fleetCapexUsdMillion * 0.60,
    revenue: 0,
    opex: 0,
    ebitda: 0,
    depreciation: 0,
    tax: 0,
    freeCashFlow: -fleetCapexUsdMillion * 0.60,
    cumulativeCashFlow: cumulativeCash,
  });

  // Year 1: Delivery ramp (50% fleet operational)
  const y1Capex = fleetCapexUsdMillion * 0.40;
  const y1Rev = annualRevenueUsdMillion * 0.50;
  const y1Opex = annualOpexUsdMillion * 0.50;
  const y1Ebitda = y1Rev - y1Opex;
  const y1Depr = annualDepreciationM * 0.50;
  const y1Tax = Math.max(0, (y1Ebitda - y1Depr) * assumptions.corporateTaxRate);
  const y1Fcf = y1Ebitda - y1Tax - y1Capex;
  cumulativeCash += y1Fcf;

  yearlyCashFlows.push({
    year: 1,
    capex: y1Capex,
    revenue: y1Rev,
    opex: y1Opex,
    ebitda: y1Ebitda,
    depreciation: y1Depr,
    tax: y1Tax,
    freeCashFlow: y1Fcf,
    cumulativeCashFlow: cumulativeCash,
  });

  let paybackPeriodYears = 15.0;
  let hasPaidBack = false;

  for (let yr = 2; yr <= years; yr++) {
    // Slight efficiency improvement / inflation growth
    const inflationFactor = Math.pow(1.015, yr - 2);
    const yrRev = annualRevenueUsdMillion * inflationFactor;
    const yrOpex = annualOpexUsdMillion * inflationFactor;
    const yrEbitda = yrRev - yrOpex;
    const yrDepr = annualDepreciationM;
    const yrTax = Math.max(0, (yrEbitda - yrDepr) * assumptions.corporateTaxRate);
    
    // Minor ongoing maintenance capex (2% per year)
    const yrMaintCapex = fleetCapexUsdMillion * 0.02;
    
    let yrFcf = yrEbitda - yrTax - yrMaintCapex;
    
    // Residual salvage value in year 15
    if (yr === years) {
      yrFcf += fleetCapexUsdMillion * assumptions.aircraftResidualValueFraction;
    }

    const prevCum = cumulativeCash;
    cumulativeCash += yrFcf;

    if (!hasPaidBack && cumulativeCash >= 0) {
      hasPaidBack = true;
      const fraction = -prevCum / Math.max(0.1, yrFcf);
      paybackPeriodYears = (yr - 1) + Math.min(1.0, Math.max(0.0, fraction));
    }

    yearlyCashFlows.push({
      year: yr,
      capex: yrMaintCapex,
      revenue: yrRev,
      opex: yrOpex,
      ebitda: yrEbitda,
      depreciation: yrDepr,
      tax: yrTax,
      freeCashFlow: yrFcf,
      cumulativeCashFlow: cumulativeCash,
    });
  }

  // NPV calculation: sum(FCF_t / (1 + wacc)^t)
  const npv15YearsUsdMillion = yearlyCashFlows.reduce((acc, row) => {
    return acc + row.freeCashFlow / Math.pow(1.0 + wacc, row.year);
  }, 0);

  // IRR Calculation using Bisection root finder
  const irrPercent = calculateIrr(yearlyCashFlows.map((c) => c.freeCashFlow)) * 100.0;

  return {
    fleetSize,
    fleetCapexUsdMillion,
    annualFleetFlights,
    annualFleetBlockHours,
    annualRevenueUsdMillion,
    annualOpexUsdMillion,
    annualEbitdaUsdMillion,
    annualNetIncomeUsdMillion,
    npv15YearsUsdMillion,
    irrPercent,
    paybackPeriodYears: Math.round(paybackPeriodYears * 10) / 10,
    yearlyCashFlows,
  };
}

/**
 * Robust Bisection IRR solver
 */
function calculateIrr(cashFlows: number[]): number {
  let lowRate = -0.50;
  let highRate = 1.50;
  const maxIter = 80;
  const tol = 1e-4;

  const npvAt = (r: number) => {
    return cashFlows.reduce((sum, cf, t) => sum + cf / Math.pow(1.0 + r, t), 0);
  };

  const npvLow = npvAt(lowRate);
  const npvHigh = npvAt(highRate);

  if (npvLow * npvHigh > 0) {
    // No sign change found in standard bracket
    return npvLow > 0 ? 0.35 : -0.15;
  }

  for (let i = 0; i < maxIter; i++) {
    const midRate = (lowRate + highRate) / 2.0;
    const npvMid = npvAt(midRate);

    if (Math.abs(npvMid) < tol || (highRate - lowRate) / 2 < tol) {
      return midRate;
    }

    if (npvAt(lowRate) * npvMid < 0) {
      highRate = midRate;
    } else {
      lowRate = midRate;
    }
  }

  return (lowRate + highRate) / 2.0;
}
