import { EngineCycleType } from '../types/aircraft';
import { ConfigurationFeasibility, DesignPoint } from '../types/designSpace';
import { EconomicAssumptions } from '../types/economics';
import { FlightRoute } from '../types/physics';
import { calculateAerodynamics } from './aerodynamics';
import { DEFAULT_ECONOMIC_ASSUMPTIONS } from './economics';
import { PRESET_ROUTES } from './mission';
import { calculatePropulsion } from './propulsion';
import { calculateSonicBoom } from './sonicBoom';
import { calculateThermalState } from './thermal';

/**
 * High-Density Design Space Exploration Engine
 * Generates and evaluates candidate supersonic airliner configurations
 */
export function generateDesignSpace(
  baseAssumptions: EconomicAssumptions = DEFAULT_ECONOMIC_ASSUMPTIONS,
  sampleRoute: FlightRoute = PRESET_ROUTES[0]
): DesignPoint[] {
  const machs = [1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2];
  const paxOptions = [50, 65, 80, 100];
  const rangeOptions = [3500, 4200, 4800]; // nm
  const cycles: EngineCycleType[] = ['medium_bypass_turbofan', 'variable_cycle', 'turbojet'];

  const points: DesignPoint[] = [];
  let counter = 1;

  for (const m of machs) {
    for (const pax of paxOptions) {
      for (const rng of rangeOptions) {
        for (const cyc of cycles) {
          // Rule out physically inconsistent pairings (e.g. pure turbojet at low Mach or standard turbofan at M2.2)
          if (m >= 2.1 && cyc === 'medium_bypass_turbofan') continue;
          if (m <= 1.6 && cyc === 'turbojet') continue;

          const dp = evaluateSingleDesignPoint(counter++, m, pax, rng, cyc, baseAssumptions, sampleRoute);
          points.push(dp);
        }
      }
    }
  }

  // Identify dominated designs and Pareto fronts
  identifyParetoAndDominance(points);

  return points;
}

function evaluateSingleDesignPoint(
  idNum: number,
  mach: number,
  passengers: number,
  designRangeNm: number,
  engineCycle: EngineCycleType,
  assumptions: EconomicAssumptions,
  route: FlightRoute
): DesignPoint {
  // Sizing physics based on Mach, passenger count, and range
  const sweepDeg = mach < 1.7 ? 58.0 : mach <= 1.9 ? 62.0 : 66.0;
  const aspectRatio = mach < 1.7 ? 3.8 : mach <= 1.9 ? 3.4 : 2.8;
  const tcRatio = mach < 1.7 ? 0.045 : mach <= 1.9 ? 0.040 : 0.034;
  const areaRuling = 0.88;

  // Approximate MTOW and Wing Area scaling
  const payloadKg = passengers * 100 + 2000;
  const rangeFactor = designRangeNm / 4000.0;
  const paxFactor = passengers / 80.0;

  let baseOewKg = 43500 * Math.pow(paxFactor, 0.82) * Math.pow(mach / 1.7, 0.6);
  if (engineCycle === 'variable_cycle') baseOewKg *= 1.05; // heavier ducting
  if (mach >= 2.1) baseOewKg *= 1.14; // titanium thermal requirement

  // Aerodynamic Cruise L/D target
  let ldCruise = (14.5 / (1.0 + 0.38 * (mach - 0.85))) * (1.0 + 0.05 * (areaRuling - 0.8));
  if (aspectRatio > 3.5) ldCruise *= 1.04;
  if (mach >= 2.0) ldCruise = Math.min(8.2, ldCruise);

  // TSFC
  let tsfc = 0.082; // kg/(N*h)
  if (engineCycle === 'turbojet') {
    tsfc = 0.105 + 0.012 * (mach - 1.7);
  } else if (engineCycle === 'medium_bypass_turbofan') {
    tsfc = 0.078 + 0.024 * (mach - 1.5);
  } else if (engineCycle === 'variable_cycle') {
    tsfc = 0.074 + 0.016 * (mach - 1.5);
  }

  // Breguet fuel calculation: W_fuel = MTOW * (1 - exp(-R*g*TSFC / (V * L/D)))
  const cruiseAltM = mach < 1.8 ? 18000 : 19500;
  const speedMS = mach * 295.0;
  const g0 = 9.80665;
  const cruiseDistKm = designRangeNm * 1.852;
  const tsfcSI = tsfc / 3600.0;
  const breguetExp = (cruiseDistKm * 1000.0 * g0 * tsfcSI) / (speedMS * ldCruise);
  
  const fuelFraction = 1.0 - Math.exp(-breguetExp * 1.18); // 1.18 includes climb/descent/reserves
  const mtowKg = (baseOewKg + payloadKg) / Math.max(0.2, 1.0 - fuelFraction);
  const blockFuelKg = mtowKg * fuelFraction;
  const oewKg = baseOewKg;
  const wingAreaM2 = (mtowKg * 9.81) / (0.5 * 0.12 * Math.pow(speedMS, 2) * 0.15);

  // Thermal evaluation
  const ambientC = -56.5;
  const stagC = (ambientC + 273.15) * (1.0 + 0.2 * mach * mach) - 273.15;
  const recoveryC = (ambientC + 273.15) * (1.0 + 0.89 * 0.2 * mach * mach) - 273.15;
  const skinTempC = recoveryC - 15.0;

  // Composite vs Titanium
  let compositeFraction = 0.74;
  let materialLimitC = 125.0;
  if (mach >= 2.0) {
    compositeFraction = 0.40; // Titanium heavy
    materialLimitC = 190.0;
  }

  // Sonic Boom
  const isShaped = mach <= 1.8;
  const kp = isShaped ? 0.19 : 0.58;
  const boomOverpressurePsf = (kp * 1.4 * Math.pow(mach * mach - 1, 0.125) * Math.sqrt((mtowKg * 2.2) / 200)) / 110.0;

  // Economics
  const flightTimeHours = (route.greatCircleDistanceNm / (mach * 580)) + 0.4;
  const blockTimeHours = flightTimeHours + 0.35;
  const tripFuelKg = blockFuelKg * (route.greatCircleDistanceNm / designRangeNm);
  const fuelPricePerGal = assumptions.safPriceUsdGal;
  const tripFuelGal = tripFuelKg / 3.04;
  const totalFuelCostUsd = tripFuelGal * fuelPricePerGal;

  const crewCost = blockTimeHours * 2100;
  const maintCost = flightTimeHours * (950 + 4 * 420);
  const fees = (mtowKg / 1000) * 18.5 + route.greatCircleDistanceKm * 0.92 + 3900;
  const catering = passengers * assumptions.loadFactor * 125;
  const docFlight = totalFuelCostUsd + crewCost + maintCost + fees + catering;

  // Ownership cost
  const acPriceM = 160 + (passengers - 50) * 0.9 + (mach - 1.5) * 45 + (engineCycle === 'variable_cycle' ? 25 : 0);
  const annualFlights = assumptions.aircraftUtilizationHoursPerYear / blockTimeHours;
  const deprFlight = (acPriceM * 1e6 * 0.9) / 16 / annualFlights;
  const tocFlight = docFlight + deprFlight;

  // Revenue
  const avgFare = 5400 * (1.0 + 0.08 * (mach - 1.7));
  const paxRev = passengers * assumptions.loadFactor * avgFare;
  const totalRev = paxRev + 4500; // cargo + ancillary
  const opProfit = totalRev - tocFlight;
  const opMargin = (opProfit / Math.max(1, totalRev)) * 100;

  const casm = tocFlight / Math.max(1, passengers * route.greatCircleDistanceKm);
  const breakEvenLoadFactor = Math.min(120, Math.max(20, (tocFlight / (passengers * avgFare)) * 100));

  // 15-Year Fleet NPV (25 aircraft)
  const fleetRev = (annualFlights * 25 * totalRev) / 1e6;
  const fleetOpex = (annualFlights * 25 * docFlight) / 1e6;
  const fleetEbitda = fleetRev - fleetOpex;
  const fleetCapex = 25 * acPriceM * 1.1;
  const npvUsdMillion = fleetEbitda * 6.5 - fleetCapex * 0.85;
  const irrPercent = Math.min(45, Math.max(-20, (fleetEbitda / Math.max(10, fleetCapex)) * 100 - 4));

  // Classification & Risk Score
  let classification: ConfigurationFeasibility = 'Technically Feasible';
  let riskScore = 25;

  if (mach >= 2.1 && engineCycle === 'variable_cycle') {
    classification = 'Technological Breakthrough Required';
    riskScore = 82;
  } else if (skinTempC > materialLimitC) {
    classification = 'Unacceptable Risk';
    riskScore = 95;
  } else if (opMargin > 16 && npvUsdMillion > 400) {
    classification = 'Economically Attractive';
    riskScore = 30 + (mach - 1.5) * 15;
  } else if (opMargin < 2 || mtowKg > 150000) {
    classification = 'Technically Marginal';
    riskScore = 65;
  }

  const fuelPerPaxKg = tripFuelKg / Math.max(1, passengers * assumptions.loadFactor);
  const co2PerPaxKmG = (tripFuelKg * 3.16 * 0.20 * 1000) / (passengers * assumptions.loadFactor * route.greatCircleDistanceKm);

  return {
    id: `DP-${idNum.toString().padStart(4, '0')}`,
    name: `M${mach.toFixed(1)} / ${passengers} Pax / ${designRangeNm}nm (${engineCycle.replace(/_/g, ' ')})`,
    mach,
    designRangeNm,
    passengers,
    engineCycle,
    wingAreaM2: Math.round(wingAreaM2),
    aspectRatio: Math.round(aspectRatio * 100) / 100,
    sweepDeg,
    liftToDragCruise: Math.round(ldCruise * 10) / 10,
    tsfcCruise: Math.round(tsfc * 1000) / 1000,
    mtowKg: Math.round(mtowKg),
    oewKg: Math.round(oewKg),
    blockFuelKg: Math.round(blockFuelKg),
    fuelPerPaxKg: Math.round(fuelPerPaxKg),
    co2PerPaxKmG: Math.round(co2PerPaxKmG),
    casmUsdPerSeatKm: Math.round(casm * 1000) / 1000,
    operatingProfitFlightUsd: Math.round(opProfit),
    operatingMarginPercent: Math.round(opMargin * 10) / 10,
    npvUsdMillion: Math.round(npvUsdMillion),
    irrPercent: Math.round(irrPercent * 10) / 10,
    breakEvenLoadFactorPercent: Math.round(breakEvenLoadFactor * 10) / 10,
    compositeFraction,
    skinTempC: Math.round(skinTempC * 10) / 10,
    boomOverpressurePsf: Math.round(boomOverpressurePsf * 100) / 100,
    classification,
    riskScore: Math.round(riskScore),
    isParetoOptimal: false,
    paretoFronts: [],
  };
}

/**
 * Non-Dominated Sorting for Pareto Frontier Discovery
 */
function identifyParetoAndDominance(points: DesignPoint[]): void {
  for (let i = 0; i < points.length; i++) {
    const p1 = points[i];
    let isDominated = false;
    const fronts: string[] = [];

    // Fuel vs Speed Pareto: lower fuel & higher speed
    let isParetoFuelSpeed = true;
    // Range vs Payload: higher range & higher passengers
    let isParetoRangePayload = true;
    // Speed vs CASM: higher speed & lower CASM
    let isParetoSpeedCasm = true;

    for (let j = 0; j < points.length; j++) {
      if (i === j) continue;
      const p2 = points[j];

      // Strict dominance: p2 is better in both profit and risk
      if (
        p2.operatingProfitFlightUsd >= p1.operatingProfitFlightUsd &&
        p2.casmUsdPerSeatKm <= p1.casmUsdPerSeatKm &&
        p2.fuelPerPaxKg <= p1.fuelPerPaxKg &&
        p2.riskScore <= p1.riskScore &&
        (p2.operatingProfitFlightUsd > p1.operatingProfitFlightUsd || p2.casmUsdPerSeatKm < p1.casmUsdPerSeatKm)
      ) {
        if (p1.classification !== 'Technological Breakthrough Required' && p1.classification !== 'Unacceptable Risk') {
          p1.classification = 'Dominated Design';
        }
        isDominated = true;
      }

      // Check Fuel vs Speed
      if (p2.mach >= p1.mach && p2.fuelPerPaxKg <= p1.fuelPerPaxKg && (p2.mach > p1.mach || p2.fuelPerPaxKg < p1.fuelPerPaxKg)) {
        isParetoFuelSpeed = false;
      }

      // Check Range vs Payload
      if (p2.designRangeNm >= p1.designRangeNm && p2.passengers >= p1.passengers && (p2.designRangeNm > p1.designRangeNm || p2.passengers > p1.passengers)) {
        isParetoRangePayload = false;
      }

      // Check Speed vs CASM
      if (p2.mach >= p1.mach && p2.casmUsdPerSeatKm <= p1.casmUsdPerSeatKm && (p2.mach > p1.mach || p2.casmUsdPerSeatKm < p1.casmUsdPerSeatKm)) {
        isParetoSpeedCasm = false;
      }
    }

    if (isParetoFuelSpeed) fronts.push('Fuel-Speed');
    if (isParetoRangePayload) fronts.push('Range-Payload');
    if (isParetoSpeedCasm) fronts.push('Speed-CASM');

    p1.paretoFronts = fronts;
    p1.isParetoOptimal = fronts.length > 0 && !isDominated;
  }
}
