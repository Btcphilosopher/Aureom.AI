import { AircraftConfiguration } from '../types/aircraft';
import { ThermalState } from '../types/physics';
import { getAtmosphere } from './atmosphere';

/**
 * Supersonic Aerodynamic Heating and Thermal Engine
 * Evaluates stagnation temperature, turbulent recovery temperature,
 * radiative equilibrium skin temperatures, and material thermal margins.
 */

export function calculateThermalState(
  config: AircraftConfiguration,
  mach: number,
  altitudeM: number
): ThermalState {
  const atmos = getAtmosphere(altitudeM);
  const tAmbK = atmos.temperatureK;
  const gamma = 1.4;

  // Stagnation (Total) Temperature: T0 = T_amb * (1 + (gamma-1)/2 * M^2)
  const t0K = tAmbK * (1.0 + ((gamma - 1.0) / 2.0) * mach * mach);

  // Recovery Factor for turbulent boundary layer: r = Pr^(1/3) ~ 0.89
  const recoveryFactor = 0.89;
  const tRecoveryK = tAmbK * (1.0 + recoveryFactor * ((gamma - 1.0) / 2.0) * mach * mach);

  // Radiative equilibrium surface temperatures
  // Emissivity of high-emissivity aerospace coating: epsilon ~ 0.85
  // Nose stagnation point experiences near-total temperature
  const skinTempNoseK = t0K - 12.0; // slight radiative cooling
  
  // Wing leading edge (high convective heat transfer, high recovery)
  const skinTempWingLEK = tRecoveryK - 8.0;

  // Mid fuselage (developed turbulent boundary layer with radiative equilibrium balance)
  const skinTempMidFuselageK = tRecoveryK - 18.0;

  const skinTempNoseC = skinTempNoseK - 273.15;
  const skinTempWingLEC = skinTempWingLEK - 273.15;
  const skinTempFuselageMidC = skinTempMidFuselageK - 273.15;

  const materialLimitC = config.materialMaxTempLimit.value;
  const maxSkinC = Math.max(skinTempNoseC, skinTempWingLEC, skinTempFuselageMidC);
  const thermalMarginC = materialLimitC - maxSkinC;
  const isThermalExceeded = thermalMarginC < 0;

  return {
    mach,
    ambientTempC: tAmbK - 273.15,
    stagnationTempC: t0K - 273.15,
    recoveryTempC: tRecoveryK - 273.15,
    skinTempNoseC,
    skinTempWingLeadingEdgeC: skinTempWingLEC,
    skinTempFuselageMidC,
    materialLimitC,
    thermalMarginC,
    isThermalExceeded,
  };
}

export function generateThermalCurve(
  config: AircraftConfiguration,
  altitudeM: number = 18000,
  machRange: number[] = [1.2, 1.4, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.4]
): ThermalState[] {
  return machRange.map((m) => calculateThermalState(config, m, altitudeM));
}
