import { AircraftConfiguration } from '../types/aircraft';
import { EconomicAssumptions } from '../types/economics';
import {
  DistributionParam,
  DistributionStatistics,
  HistogramBin,
  MonteCarloConfig,
  MonteCarloIterationResult,
  MonteCarloSummary,
} from '../types/monteCarlo';
import { FlightRoute } from '../types/physics';
import { calculateFlightEconomics, DEFAULT_ECONOMIC_ASSUMPTIONS } from './economics';
import { calculateFleetFinancials } from './fleetEconomics';
import { simulateMission } from './mission';

/**
 * Seedable Pseudo-Random Number Generator (Mulberry32)
 */
export class SeededRNG {
  private state: number;

  constructor(seed: number = 42) {
    this.state = seed | 0;
  }

  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  // Standard Normal via Box-Muller
  public nextGaussian(mean: number = 0, stdDev: number = 1): number {
    let u1 = this.next();
    let u2 = this.next();
    while (u1 <= 1e-15) u1 = this.next();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z0 * stdDev;
  }

  public nextLognormal(mean: number = 1.0, stdDev: number = 0.1): number {
    const variance = stdDev * stdDev;
    const mu = Math.log((mean * mean) / Math.sqrt(variance + mean * mean));
    const sigma = Math.sqrt(Math.log(1.0 + variance / (mean * mean)));
    const z = this.nextGaussian(0, 1);
    return Math.exp(mu + sigma * z);
  }

  public nextTriangular(min: number, mode: number, max: number): number {
    const u = this.next();
    const fc = (mode - min) / (max - min);
    if (u < fc) {
      return min + Math.sqrt(u * (max - min) * (mode - min));
    } else {
      return max - Math.sqrt((1 - u) * (max - min) * (max - mode));
    }
  }

  public nextUniform(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  public nextBeta(alpha: number = 2, beta: number = 2): number {
    // Johnk's generator or gamma ratio approximation
    const u1 = Math.pow(this.next(), 1 / alpha);
    const u2 = Math.pow(this.next(), 1 / beta);
    if (u1 + u2 <= 1.0) {
      return u1 / (u1 + u2);
    }
    return (this.next() + this.next()) / 2.0; // fallback smooth
  }

  public sample(param: DistributionParam): number {
    switch (param.type) {
      case 'normal':
        return this.nextGaussian(param.mean ?? 1.0, param.stdDev ?? 0.08);
      case 'lognormal':
        return this.nextLognormal(param.mean ?? 1.0, param.stdDev ?? 0.10);
      case 'triangular':
        return this.nextTriangular(param.min ?? 0.85, param.mode ?? 1.0, param.max ?? 1.18);
      case 'uniform':
        return this.nextUniform(param.min ?? 0.85, param.max ?? 1.15);
      case 'beta':
        const b = this.nextBeta(param.alpha ?? 2.5, param.beta ?? 2.5);
        const min = param.min ?? 0.8;
        const max = param.max ?? 1.2;
        return min + b * (max - min);
      default:
        return param.mean ?? 1.0;
    }
  }
}

export const DEFAULT_MONTE_CARLO_CONFIG: MonteCarloConfig = {
  iterations: 10000,
  seed: 2026,
  variables: {
    tsfcMultiplier: { type: 'normal', mean: 1.0, stdDev: 0.06 },
    liftToDragMultiplier: { type: 'triangular', min: 0.90, mode: 1.0, max: 1.08 },
    mtowMultiplier: { type: 'normal', mean: 1.0, stdDev: 0.04 },
    oewMultiplier: { type: 'normal', mean: 1.0, stdDev: 0.05 },
    fuelPriceUsdGal: { type: 'lognormal', mean: 2.85, stdDev: 0.55 },
    safPricePremiumMultiplier: { type: 'triangular', min: 1.6, mode: 2.0, max: 2.8 },
    loadFactor: { type: 'beta', min: 0.60, max: 0.92, alpha: 3.2, beta: 2.2 },
    ticketYieldMultiplier: { type: 'triangular', min: 0.85, mode: 1.0, max: 1.20 },
    annualUtilHours: { type: 'normal', mean: 3650, stdDev: 250 },
    maintenanceCostMultiplier: { type: 'lognormal', mean: 1.0, stdDev: 0.15 },
    aircraftPriceMultiplier: { type: 'triangular', min: 0.90, mode: 1.0, max: 1.22 },
    programDevCostMultiplier: { type: 'triangular', min: 0.95, mode: 1.10, max: 1.45 },
  },
};

/**
 * Executes high-performance Monte Carlo simulation
 */
export function runMonteCarloSimulation(
  baseConfig: AircraftConfiguration,
  route: FlightRoute,
  baseAssumptions: EconomicAssumptions = DEFAULT_ECONOMIC_ASSUMPTIONS,
  config: MonteCarloConfig = DEFAULT_MONTE_CARLO_CONFIG
): MonteCarloSummary {
  const rng = new SeededRNG(config.seed);
  const n = Math.min(100000, Math.max(1000, config.iterations));
  const results: MonteCarloIterationResult[] = [];

  const profits: number[] = [];
  const margins: number[] = [];
  const npvs: number[] = [];
  const irrs: number[] = [];
  const casms: number[] = [];
  const beLoads: number[] = [];

  for (let i = 0; i < n; i++) {
    // Sample uncertain parameters
    const tsfcMult = rng.sample(config.variables.tsfcMultiplier);
    const ldMult = rng.sample(config.variables.liftToDragMultiplier);
    const fuelPrice = rng.sample(config.variables.fuelPriceUsdGal);
    const safPremiumMult = rng.sample(config.variables.safPricePremiumMultiplier);
    const loadFactor = rng.sample(config.variables.loadFactor);
    const yieldMult = rng.sample(config.variables.ticketYieldMultiplier);
    const maintMult = rng.sample(config.variables.maintenanceCostMultiplier);
    const acPriceMult = rng.sample(config.variables.aircraftPriceMultiplier);

    // Perturbed config for iteration
    const simConfig: AircraftConfiguration = {
      ...baseConfig,
      tsfcCruise: { ...baseConfig.tsfcCruise, value: baseConfig.tsfcCruise.value * tsfcMult },
      liftToDragCruise: { ...baseConfig.liftToDragCruise, value: baseConfig.liftToDragCruise.value * ldMult },
      aircraftUnitPrice: { ...baseConfig.aircraftUnitPrice, value: baseConfig.aircraftUnitPrice.value * acPriceMult },
    };

    // Perturbed economic assumptions
    const simAssumptions: EconomicAssumptions = {
      ...baseAssumptions,
      jetAFuelPriceUsdGal: fuelPrice,
      safPriceUsdGal: fuelPrice * safPremiumMult,
      loadFactor: Math.min(0.98, Math.max(0.40, loadFactor)),
      fareFirstClassUsd: baseAssumptions.fareFirstClassUsd * yieldMult,
      fareBusinessClassUsd: baseAssumptions.fareBusinessClassUsd * yieldMult,
      farePremiumEconomyUsd: baseAssumptions.farePremiumEconomyUsd * yieldMult,
      airframeMaintenancePerFlightHourUsd: baseAssumptions.airframeMaintenancePerFlightHourUsd * maintMult,
      engineMaintenancePerFlightHourPerEngineUsd: baseAssumptions.engineMaintenancePerFlightHourPerEngineUsd * maintMult,
    };

    const mission = simulateMission(simConfig, route);
    const flightEcon = calculateFlightEconomics(simConfig, mission, simAssumptions);
    const fleetEcon = calculateFleetFinancials(simConfig, mission, flightEcon, 25, simAssumptions);

    const isProf = flightEcon.operatingProfitPerFlightUsd > 0;
    
    profits.push(flightEcon.operatingProfitPerFlightUsd);
    margins.push(flightEcon.operatingMarginPercent);
    npvs.push(fleetEcon.npv15YearsUsdMillion);
    irrs.push(fleetEcon.irrPercent);
    casms.push(flightEcon.costPerSeatKmUsd);
    beLoads.push(flightEcon.breakEvenLoadFactor * 100);

    if (i < 2000) {
      results.push({
        iterationIndex: i + 1,
        tsfcMultiplier: tsfcMult,
        ldMultiplier: ldMult,
        mtow: simConfig.mtow.value,
        fuelPrice,
        loadFactor: simAssumptions.loadFactor,
        operatingProfitFlightUsd: flightEcon.operatingProfitPerFlightUsd,
        operatingMarginPercent: flightEcon.operatingMarginPercent,
        casmUsdPerSeatKm: flightEcon.costPerSeatKmUsd,
        npvUsdMillion: fleetEcon.npv15YearsUsdMillion,
        irrPercent: fleetEcon.irrPercent,
        breakEvenLoadFactor: flightEcon.breakEvenLoadFactor * 100,
        isProfitable: isProf,
      });
    }
  }

  const profitableCount = profits.filter((p) => p > 0).length;
  const probabilityOfProfitPercent = (profitableCount / n) * 100.0;

  const profitDist = calculateDistributionStats(profits);
  const marginDist = calculateDistributionStats(margins);
  const npvDist = calculateDistributionStats(npvs);
  const irrDist = calculateDistributionStats(irrs);
  const casmDist = calculateDistributionStats(casms);
  const beLoadDist = calculateDistributionStats(beLoads);

  return {
    totalIterations: n,
    probabilityOfProfitPercent: Math.round(probabilityOfProfitPercent * 10) / 10,
    profitDistribution: profitDist,
    marginDistribution: marginDist,
    npvDistribution: npvDist,
    irrDistribution: irrDist,
    casmDistribution: casmDist,
    breakEvenLoadFactorDistribution: beLoadDist,
    profitHistogram: createHistogram(profits, 24),
    npvHistogram: createHistogram(npvs, 24),
    casmHistogram: createHistogram(casms, 24),
  };
}

export function calculateDistributionStats(values: number[]): DistributionStatistics {
  const sorted = [...values].sort((a, b) => a - b);
  const len = sorted.length;
  if (len === 0) {
    return { mean: 0, median: 0, stdDev: 0, min: 0, max: 0, p5: 0, p10: 0, p25: 0, p75: 0, p90: 0, p95: 0, var95: 0, cvar95: 0 };
  }

  const sum = sorted.reduce((acc, v) => acc + v, 0);
  const mean = sum / len;
  const variance = sorted.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / len;
  const stdDev = Math.sqrt(variance);

  const getP = (p: number) => sorted[Math.min(len - 1, Math.max(0, Math.floor(p * len)))];

  const p5 = getP(0.05);
  const p10 = getP(0.10);
  const p25 = getP(0.25);
  const median = getP(0.50);
  const p75 = getP(0.75);
  const p90 = getP(0.90);
  const p95 = getP(0.95);
  const min = sorted[0];
  const max = sorted[len - 1];

  // Value at Risk at 95% confidence (5th percentile threshold)
  const var95 = p5;
  
  // Conditional VaR (Expected Shortfall): Mean of worst 5%
  const tailCount = Math.max(1, Math.floor(0.05 * len));
  const tailSum = sorted.slice(0, tailCount).reduce((acc, v) => acc + v, 0);
  const cvar95 = tailSum / tailCount;

  return {
    mean: Math.round(mean * 100) / 100,
    median: Math.round(median * 100) / 100,
    stdDev: Math.round(stdDev * 100) / 100,
    min: Math.round(min * 100) / 100,
    max: Math.round(max * 100) / 100,
    p5: Math.round(p5 * 100) / 100,
    p10: Math.round(p10 * 100) / 100,
    p25: Math.round(p25 * 100) / 100,
    p75: Math.round(p75 * 100) / 100,
    p90: Math.round(p90 * 100) / 100,
    p95: Math.round(p95 * 100) / 100,
    var95: Math.round(var95 * 100) / 100,
    cvar95: Math.round(cvar95 * 100) / 100,
  };
}

export function createHistogram(values: number[], numBins: number = 20): HistogramBin[] {
  if (values.length === 0) return [];
  const sorted = [...values].sort((a, b) => a - b);
  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  const span = Math.max(1e-5, max - min);
  const binWidth = span / numBins;

  const bins: HistogramBin[] = [];
  for (let i = 0; i < numBins; i++) {
    const binStart = min + i * binWidth;
    const binEnd = binStart + binWidth;
    bins.push({
      binStart,
      binEnd,
      binMid: (binStart + binEnd) / 2.0,
      count: 0,
      frequency: 0,
      cumulativeProbability: 0,
    });
  }

  for (const v of sorted) {
    let idx = Math.floor((v - min) / binWidth);
    if (idx >= numBins) idx = numBins - 1;
    if (idx < 0) idx = 0;
    bins[idx].count++;
  }

  let cumulative = 0;
  for (const b of bins) {
    b.frequency = b.count / values.length;
    cumulative += b.frequency;
    b.cumulativeProbability = Math.min(1.0, cumulative);
  }

  return bins;
}
