import { AircraftConfiguration } from '../types/aircraft';
import { EconomicAssumptions, FlightEconomicsResult } from '../types/economics';
import { MissionProfileResult } from '../types/physics';

export const DEFAULT_ECONOMIC_ASSUMPTIONS: EconomicAssumptions = {
  jetAFuelPriceUsdGal: 2.85, // $2.85/gal
  safPriceUsdGal: 5.80, // $5.80/gal
  safBlendRatio: 1.0, // 100% SAF
  carbonPriceUsdPerTonne: 85.0, // $85/tonne CO2
  aircraftUtilizationHoursPerYear: 3650, // 10 hrs/day
  averageFlightStageLengthNm: 3600,
  loadFactor: 0.78, // 78% average load factor
  
  // Fare structure (Premium supersonic positioning)
  fareFirstClassUsd: 8200,
  fareBusinessClassUsd: 4900,
  farePremiumEconomyUsd: 3100,
  firstClassSeatFraction: 0.20,
  businessClassSeatFraction: 0.80,
  premiumEconomySeatFraction: 0.0,
  
  cargoYieldUsdPerKg: 3.50, // $3.50/kg
  cargoLoadFactor: 0.60,
  ancillaryRevenuePerPaxUsd: 180, // High-end connectivity, lounge, transfers
  
  flightCrewHourlyCostUsd: 1450, // Captain, First Officer, Relief Pilot
  cabinCrewHourlyCostUsd: 580,
  airframeMaintenancePerFlightHourUsd: 980,
  engineMaintenancePerFlightHourPerEngineUsd: 420,
  landingFeePerTonneUsd: 18.50,
  navigationFeePerKmUsd: 0.92,
  groundHandlingPerFlightUsd: 3900,
  cateringPerPaxUsd: 125,
  hullInsuranceAnnualFraction: 0.0075, // 0.75% of hull value
  
  aircraftUsefulLifeYears: 16,
  aircraftResidualValueFraction: 0.10,
  waccDiscountRate: 0.085,
  debtFraction: 0.70,
  interestRate: 0.065,
  corporateTaxRate: 0.21,
};

/**
 * Calculates detailed operating economics per flight
 */
export function calculateFlightEconomics(
  config: AircraftConfiguration,
  mission: MissionProfileResult,
  assumptions: EconomicAssumptions = DEFAULT_ECONOMIC_ASSUMPTIONS
): FlightEconomicsResult {
  const totalPaxCapacity = config.passengerCapacity.value;
  const actualPax = totalPaxCapacity * assumptions.loadFactor;
  const numEngines = config.numEngines.value;
  const blockTimeHours = mission.blockTimeHours;
  const flightTimeHours = mission.flightTimeHours;
  const stageLengthKm = mission.totalDistanceKm;
  const stageLengthNm = mission.totalDistanceNm;
  const mtowTonnes = config.mtow.value / 1000.0;
  const aircraftPriceUsd = config.aircraftUnitPrice.value * 1e6;

  // 1. Fuel & SAF Cost
  // Density of Jet-A / SAF ~ 3.04 kg/gallon (0.804 kg/L)
  const kgPerGallon = 3.04;
  const tripFuelGallons = mission.tripFuelKg / kgPerGallon;
  const safRatio = assumptions.safBlendRatio;
  const blendedFuelPricePerGal = (1.0 - safRatio) * assumptions.jetAFuelPriceUsdGal + safRatio * assumptions.safPriceUsdGal;
  
  const fuelCostUsd = (1.0 - safRatio) * tripFuelGallons * assumptions.jetAFuelPriceUsdGal;
  const safCostUsd = safRatio * tripFuelGallons * assumptions.safPriceUsdGal;
  const totalFuelCostUsd = tripFuelGallons * blendedFuelPricePerGal;

  // 2. Carbon Offset / ETS Cost
  // Standard Jet-A emits 3.16 kg CO2/kg fuel. SAF avoids ~80% of fossil CO2 emissions.
  const netCo2Tonnes = (mission.tripFuelKg * 3.16 * (1.0 - 0.80 * safRatio)) / 1000.0;
  const carbonEmissionCostUsd = netCo2Tonnes * assumptions.carbonPriceUsdPerTonne;

  // 3. Crew Costs
  const flightCrewCostUsd = blockTimeHours * assumptions.flightCrewHourlyCostUsd;
  // Cabin crew sized ~ 1 flight attendant per 20 premium pax
  const numCabinCrew = Math.max(3, Math.ceil(totalPaxCapacity / 20));
  const cabinCrewCostUsd = blockTimeHours * (assumptions.cabinCrewHourlyCostUsd * (numCabinCrew / 3.0));

  // 4. Maintenance Costs
  const airframeMaintenanceCostUsd = flightTimeHours * assumptions.airframeMaintenancePerFlightHourUsd;
  const engineMaintenanceCostUsd = flightTimeHours * (assumptions.engineMaintenancePerFlightHourPerEngineUsd * numEngines);
  const totalMaintenanceCostUsd = airframeMaintenanceCostUsd + engineMaintenanceCostUsd;

  // 5. Direct Operating Fees
  const landingFeesUsd = mtowTonnes * assumptions.landingFeePerTonneUsd;
  const navigationFeesUsd = stageLengthKm * assumptions.navigationFeePerKmUsd;
  const groundHandlingFeesUsd = assumptions.groundHandlingPerFlightUsd;
  const cateringCostUsd = actualPax * assumptions.cateringPerPaxUsd;

  const directOperatingCostPerFlightUsd =
    totalFuelCostUsd +
    carbonEmissionCostUsd +
    flightCrewCostUsd +
    cabinCrewCostUsd +
    totalMaintenanceCostUsd +
    landingFeesUsd +
    navigationFeesUsd +
    groundHandlingFeesUsd +
    cateringCostUsd;

  // 6. Ownership & Capital Costs per flight
  const annualHours = assumptions.aircraftUtilizationHoursPerYear;
  const annualFlights = annualHours / Math.max(1.0, blockTimeHours);

  // Depreciation: Straight-line over useful life to residual value
  const depreciableBase = aircraftPriceUsd * (1.0 - assumptions.aircraftResidualValueFraction);
  const annualDepreciation = depreciableBase / assumptions.aircraftUsefulLifeYears;
  const depreciationCostPerFlightUsd = annualDepreciation / annualFlights;

  // Financing Interest: Debt portion interest
  const annualInterest = aircraftPriceUsd * assumptions.debtFraction * assumptions.interestRate;
  const financingInterestPerFlightUsd = annualInterest / annualFlights;

  // Hull Insurance
  const annualInsurance = aircraftPriceUsd * assumptions.hullInsuranceAnnualFraction;
  const hullInsurancePerFlightUsd = annualInsurance / annualFlights;

  const totalOperatingCostPerFlightUsd =
    directOperatingCostPerFlightUsd +
    depreciationCostPerFlightUsd +
    financingInterestPerFlightUsd +
    hullInsurancePerFlightUsd;

  // 7. Revenue Modeling
  const firstClassSeats = totalPaxCapacity * assumptions.firstClassSeatFraction;
  const businessClassSeats = totalPaxCapacity * assumptions.businessClassSeatFraction;
  const premiumEcoSeats = totalPaxCapacity * assumptions.premiumEconomySeatFraction;

  const firstClassPax = firstClassSeats * assumptions.loadFactor;
  const businessClassPax = businessClassSeats * assumptions.loadFactor;
  const premiumEcoPax = premiumEcoSeats * assumptions.loadFactor;

  const passengerRevenueUsd =
    firstClassPax * assumptions.fareFirstClassUsd +
    businessClassPax * assumptions.fareBusinessClassUsd +
    premiumEcoPax * assumptions.farePremiumEconomyUsd;

  const cargoCarriedKg = config.cargoCapacity.value * assumptions.cargoLoadFactor;
  const cargoRevenueUsd = cargoCarriedKg * assumptions.cargoYieldUsdPerKg;
  const ancillaryRevenueUsd = actualPax * assumptions.ancillaryRevenuePerPaxUsd;

  const totalRevenuePerFlightUsd = passengerRevenueUsd + cargoRevenueUsd + ancillaryRevenueUsd;

  // 8. Margins & Unit Metrics
  const operatingProfitPerFlightUsd = totalRevenuePerFlightUsd - totalOperatingCostPerFlightUsd;
  const operatingMarginPercent = (operatingProfitPerFlightUsd / Math.max(1.0, totalRevenuePerFlightUsd)) * 100.0;

  const costPerSeatUsd = totalOperatingCostPerFlightUsd / Math.max(1, totalPaxCapacity);
  const costPerPassengerUsd = totalOperatingCostPerFlightUsd / Math.max(1, actualPax);
  
  const availableSeatKm = totalPaxCapacity * stageLengthKm;
  const availableSeatNm = totalPaxCapacity * stageLengthNm;
  
  const costPerSeatKmUsd = totalOperatingCostPerFlightUsd / Math.max(1, availableSeatKm); // CASM
  const costPerSeatNmUsd = totalOperatingCostPerFlightUsd / Math.max(1, availableSeatNm);
  const revenuePerSeatKmUsd = totalRevenuePerFlightUsd / Math.max(1, availableSeatKm); // RASM
  const revenuePerSeatNmUsd = totalRevenuePerFlightUsd / Math.max(1, availableSeatNm);

  // Break-even metrics
  const avgFare = (passengerRevenueUsd / Math.max(1, actualPax)) + assumptions.ancillaryRevenuePerPaxUsd;
  const netRevenueRequiredForBreakEven = totalOperatingCostPerFlightUsd - cargoRevenueUsd;
  const breakEvenPax = netRevenueRequiredForBreakEven / Math.max(1.0, avgFare);
  const breakEvenLoadFactor = Math.min(1.5, Math.max(0.1, breakEvenPax / totalPaxCapacity));
  
  const breakEvenAverageFareUsd = (netRevenueRequiredForBreakEven / Math.max(1, actualPax));

  return {
    fuelCostUsd,
    safCostUsd,
    totalFuelCostUsd,
    carbonEmissionCostUsd,
    flightCrewCostUsd,
    cabinCrewCostUsd,
    airframeMaintenanceCostUsd,
    engineMaintenanceCostUsd,
    totalMaintenanceCostUsd,
    landingFeesUsd,
    navigationFeesUsd,
    groundHandlingFeesUsd,
    cateringCostUsd,
    directOperatingCostPerFlightUsd,
    depreciationCostPerFlightUsd,
    financingInterestPerFlightUsd,
    hullInsurancePerFlightUsd,
    totalOperatingCostPerFlightUsd,
    passengerRevenueUsd,
    cargoRevenueUsd,
    ancillaryRevenueUsd,
    totalRevenuePerFlightUsd,
    operatingProfitPerFlightUsd,
    operatingMarginPercent,
    costPerSeatUsd,
    costPerPassengerUsd,
    costPerSeatKmUsd,
    costPerSeatNmUsd,
    revenuePerSeatKmUsd,
    revenuePerSeatNmUsd,
    breakEvenLoadFactor,
    breakEvenAverageFareUsd,
  };
}
