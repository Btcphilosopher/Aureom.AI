import { AircraftConfiguration } from '../types/aircraft';
import { StructuralBuildUp } from '../types/physics';

/**
 * Supersonic Conceptual Structures & Mass Buildup Engine
 * Implements modified Raymer/Roskam supersonic transport mass equations
 * incorporating advanced composite laminates, titanium bulkheads, and thermal cycling.
 */

export function calculateStructuralMassBuildup(config: AircraftConfiguration): StructuralBuildUp {
  const pax = config.passengerCapacity.value;
  const cargoKg = config.cargoCapacity.value;
  const wingArea = config.wingArea.value;
  const fuseLen = config.fuselageLength.value;
  const fuseDia = config.fuselageDiameter.value;
  const sweepDeg = config.sweepAngle.value;
  const numEngines = config.numEngines.value;
  const staticThrustN = config.staticThrustPerEngine.value;
  const mach = config.machCruise.value;

  // Material weight reduction factors relative to conventional aluminum
  const compositeFraction = config.compositeWeightFraction.value;
  const titaniumFraction = config.titaniumWeightFraction.value;
  const alLiFraction = config.aluminumLithiumWeightFraction.value;
  
  // Advanced CFRP reduces airframe weight by ~22%, Al-Li by ~10%, Titanium adds stiffness & high-temp strength
  const materialEfficiency = 1.0 - (0.22 * compositeFraction + 0.10 * alLiFraction);

  // Payload: standard 100 kg/passenger (84 kg pax + 16 kg checked/carry-on luggage) + cargo
  const payloadKg = pax * 100 + cargoKg;

  // 1. Wing Mass: High sweep, thin airfoil (t/c ~4%), slender delta
  const sweepFactor = 1.0 + 0.005 * (sweepDeg - 45);
  const wingMassKg = 38.0 * Math.pow(wingArea, 1.15) * sweepFactor * materialEfficiency * (1.0 + 0.12 * (mach - 1.5));

  // 2. Fuselage Mass: Slender area-ruled fuselage with cabin pressurization differential (0.75 atm delta)
  const fuseSurfaceArea = Math.PI * fuseDia * fuseLen * 0.82;
  const fuselageMassKg = 24.0 * Math.pow(fuseSurfaceArea, 1.08) * materialEfficiency * (1.0 + 0.08 * (mach - 1.5));

  // 3. Empennage (Vertical Fin / Canards / Rudder)
  const empennageMassKg = 0.12 * wingMassKg;

  // 4. Landing Gear (Bogie configuration sized for supersonic high-speed rotation and sink rate)
  // Sized at ~3.8% of expected MTOW
  const approxMtow = config.mtow.value;
  const landingGearMassKg = approxMtow * 0.038;

  // 5. Engine Nacelles & Pylons (Titanium high-temperature structures)
  const nacellePylonMassKg = numEngines * (140.0 + 0.0028 * staticThrustN);

  // 6. Installed Engines Mass (Total)
  const engineDryMassTotal = config.engineMass.value;

  // 7. Flight Controls & Actuation (Triple redundant fly-by-wire with high-rate hydraulic/electromechanical actuators)
  const flightControlsMassKg = 0.016 * approxMtow;

  // 8. Aircraft Systems (Avionics, High-altitude ECS, Oxygen, High-voltage Electrical, Hydraulics)
  const systemsMassKg = 3200 + 42.0 * pax + 0.02 * approxMtow;

  // 9. Cabin Interiors & Accommodations (Lie-flat / premium seating, galleys, lavatories, emergency gear)
  const cabinInteriorsMassKg = pax * 52.0 + 800.0;

  // 10. Thermal Protection & Leading Edge Insulation
  const thermalProtectionMassKg = (mach > 1.6 ? (mach - 1.6) * 1200 : 200) * (1.0 + 0.5 * titaniumFraction);

  // 11. Structural Contingency (5% engineering reserve)
  const subtotalStructure =
    wingMassKg +
    fuselageMassKg +
    empennageMassKg +
    landingGearMassKg +
    nacellePylonMassKg +
    engineDryMassTotal +
    flightControlsMassKg +
    systemsMassKg +
    cabinInteriorsMassKg +
    thermalProtectionMassKg;

  const contingencyMassKg = subtotalStructure * 0.05;

  // Total Operating Empty Weight (OEW)
  const totalOewKg = subtotalStructure + contingencyMassKg;

  // Max Fuel Capacity
  const maxFuelMassKg = config.fuelCapacity.value;

  // Total MTOW
  const totalMtowKg = totalOewKg + payloadKg + maxFuelMassKg;

  return {
    wingMassKg,
    fuselageMassKg,
    empennageMassKg,
    landingGearMassKg,
    nacellePylonMassKg,
    enginesTotalMassKg: engineDryMassTotal,
    flightControlsMassKg,
    systemsMassKg,
    thermalProtectionMassKg,
    cabinInteriorsMassKg,
    contingencyMassKg,
    totalOewKg,
    payloadKg,
    maxFuelMassKg,
    totalMtowKg,
  };
}
