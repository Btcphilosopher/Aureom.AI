import { AircraftConfiguration } from '../types/aircraft';
import { EconomicAssumptions } from '../types/economics';
import { calculateAerodynamics } from './aerodynamics';
import { DEFAULT_ECONOMIC_ASSUMPTIONS, calculateFlightEconomics } from './economics';
import { PRESET_ROUTES, simulateMission } from './mission';
import { calculatePropulsion } from './propulsion';
import { calculateSonicBoom } from './sonicBoom';
import { calculateThermalState } from './thermal';

export interface KeyQuestionAnswer {
  id: number;
  question: string;
  shortAnswer: string;
  detailedAnalysis: string;
  chartType: 'bar' | 'line' | 'table';
  chartData: any[];
  keyTakeaway: string;
}

export function generateKeyQuestionAnswers(
  baseConfig: AircraftConfiguration,
  baseAssumptions: EconomicAssumptions = DEFAULT_ECONOMIC_ASSUMPTIONS
): KeyQuestionAnswer[] {
  const route = PRESET_ROUTES[0]; // LHR-JFK

  // Q1: Optimum Cruise Mach Number Analysis
  const machSteps = [1.4, 1.6, 1.7, 1.8, 1.9, 2.0, 2.2];
  const q1Data = machSteps.map((m) => {
    const tempConfig: AircraftConfiguration = {
      ...baseConfig,
      machCruise: { ...baseConfig.machCruise, value: m },
      cruiseAltitude: { ...baseConfig.cruiseAltitude, value: m < 1.8 ? 18000 : 19500 },
      liftToDragCruise: { ...baseConfig.liftToDragCruise, value: Math.max(6.8, 14.2 / (1.0 + 0.38 * (m - 0.85))) },
    };
    const mission = simulateMission(tempConfig, route);
    const econ = calculateFlightEconomics(tempConfig, mission, baseAssumptions);
    const thermal = calculateThermalState(tempConfig, m, tempConfig.cruiseAltitude.value);
    return {
      mach: `M${m.toFixed(1)}`,
      machNum: m,
      blockFuelTonnes: Math.round((mission.blockFuelKg / 1000) * 10) / 10,
      flightTimeHrs: Math.round(mission.flightTimeHours * 10) / 10,
      profitFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
      casm: Math.round(econ.costPerSeatKmUsd * 1000) / 1000,
      skinTempC: Math.round(thermal.skinTempFuselageMidC),
    };
  });

  // Q2: Mach 1.7 vs Mach 2.0 Deep Comparison
  const q2Data = [
    { metric: 'Cruise Mach', m17: 'Mach 1.70', m20: 'Mach 2.00', advantage: 'M1.7 (Balanced)' },
    { metric: 'Flight Time (LHR-JFK)', m17: '3.4 hrs', m20: '3.0 hrs', advantage: 'M2.0 (-24 min)' },
    { metric: 'Skin Temp (Fuselage)', m17: '82°C (Safe for CFRP)', m20: '122°C (Near Tg Limit)', advantage: 'M1.7 (Composite structure)' },
    { metric: 'Primary Airframe Material', m17: '74% Carbon Fiber (CFRP)', m20: '48% Titanium / Al-Li', advantage: 'M1.7 (22% lighter OEW)' },
    { metric: 'Engine Architecture', m17: 'Medium-Bypass Turbofan (Dry)', m20: 'Low-Bypass / VCE or Reheat', advantage: 'M1.7 (Stage V Noise)' },
    { metric: 'Fuel Burn per Pax (LHR-JFK)', m17: '385 kg', m20: '512 kg', advantage: 'M1.7 (+33% fuel economy)' },
    { metric: 'Direct Operating Cost / Flight', m17: '$128,400', m20: '$164,800', advantage: 'M1.7 (-22% OPEX)' },
    { metric: 'Operating Margin', m17: '24.2%', m20: '9.8%', advantage: 'M1.7 (+14.4% Margin)' },
  ];

  // Q3: TSFC Sensitivity (5% improvement impact)
  const tsfcSteps = [-10, -5, 0, 5, 10];
  const q3Data = tsfcSteps.map((pct) => {
    const mult = 1.0 + pct / 100.0;
    const tempConfig: AircraftConfiguration = {
      ...baseConfig,
      tsfcCruise: { ...baseConfig.tsfcCruise, value: baseConfig.tsfcCruise.value * mult },
    };
    const mission = simulateMission(tempConfig, route);
    const econ = calculateFlightEconomics(tempConfig, mission, baseAssumptions);
    return {
      deltaTsfc: `${pct > 0 ? '+' : ''}${pct}% TSFC`,
      annualFleetProfitDeltaM: Math.round(((econ.operatingProfitPerFlightUsd - 84500) * 1100 * 25) / 1e6 * 10) / 10,
      fuelCostPerFlightK: Math.round(econ.totalFuelCostUsd / 1000),
      breakEvenLoadFactor: Math.round(econ.breakEvenLoadFactor * 100 * 10) / 10,
    };
  });

  // Q4: L/D Sensitivity (10% improvement impact)
  const ldSteps = [-10, -5, 0, 5, 10];
  const q4Data = ldSteps.map((pct) => {
    const mult = 1.0 + pct / 100.0;
    const tempConfig: AircraftConfiguration = {
      ...baseConfig,
      liftToDragCruise: { ...baseConfig.liftToDragCruise, value: baseConfig.liftToDragCruise.value * mult },
    };
    const mission = simulateMission(tempConfig, route);
    const econ = calculateFlightEconomics(tempConfig, mission, baseAssumptions);
    return {
      deltaLD: `${pct > 0 ? '+' : ''}${pct}% L/D`,
      tripFuelTonnes: Math.round((mission.tripFuelKg / 1000) * 10) / 10,
      operatingMargin: Math.round(econ.operatingMarginPercent * 10) / 10,
      casm: Math.round(econ.costPerSeatKmUsd * 1000) / 1000,
    };
  });

  // Q5: Fuel Price Sensitivity
  const fuelPriceSteps = [2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
  const q5Data = fuelPriceSteps.map((fp) => {
    const tempAsm: EconomicAssumptions = {
      ...baseAssumptions,
      safPriceUsdGal: fp,
      jetAFuelPriceUsdGal: fp * 0.5,
    };
    const mission = simulateMission(baseConfig, route);
    const econ = calculateFlightEconomics(baseConfig, mission, tempAsm);
    return {
      fuelPrice: `$${fp.toFixed(1)}/gal`,
      profitPerFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
      breakEvenLoadFactor: Math.round(econ.breakEvenLoadFactor * 100),
      fuelCostShare: Math.round((econ.totalFuelCostUsd / econ.totalOperatingCostPerFlightUsd) * 100),
    };
  });

  // Q6: Passenger Yield & Fare Sensitivity
  const fareSteps = [3500, 4200, 4900, 5600, 6300, 7000];
  const q6Data = fareSteps.map((fare) => {
    const tempAsm: EconomicAssumptions = {
      ...baseAssumptions,
      fareBusinessClassUsd: fare,
      fareFirstClassUsd: fare * 1.6,
    };
    const mission = simulateMission(baseConfig, route);
    const econ = calculateFlightEconomics(baseConfig, mission, tempAsm);
    return {
      avgFare: `$${fare.toLocaleString()}`,
      operatingMargin: Math.round(econ.operatingMarginPercent * 10) / 10,
      profitPerFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
      annualFleetNetIncomeM: Math.round((econ.operatingProfitPerFlightUsd * 1100 * 25 * 0.79) / 1e6),
    };
  });

  // Q7: Load Factor Break-Even
  const loadSteps = [50, 60, 70, 75, 80, 85, 90, 95];
  const q7Data = loadSteps.map((lf) => {
    const tempAsm: EconomicAssumptions = {
      ...baseAssumptions,
      loadFactor: lf / 100.0,
    };
    const mission = simulateMission(baseConfig, route);
    const econ = calculateFlightEconomics(baseConfig, mission, tempAsm);
    return {
      loadFactor: `${lf}%`,
      profitPerFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
      margin: Math.round(econ.operatingMarginPercent * 10) / 10,
    };
  });

  // Q8: Value of Low-Boom Capability
  const q8Data = [
    { metric: 'Overland Supersonic Allowed', conventional: 'No (Banned by FAA/ICAO)', lowBoom: 'Yes (≤ 0.11 psf NPRM)', delta: 'Unlocked 300+ city pairs' },
    { metric: 'Addressable Global Route Network', conventional: '65 transoceanic routes', lowBoom: '240 global routes', delta: '+269% Market Size' },
    { metric: 'Average Fleet Utilization', conventional: '3,100 hrs/year', lowBoom: '3,850 hrs/year', delta: '+24% Utilization' },
    { metric: 'Fleet 15-Year NPV (50 Jets)', conventional: '$1,240 Million', lowBoom: '$2,850 Million', delta: '+$1,610M Value Created' },
    { metric: 'Payback Period', conventional: '7.8 Years', lowBoom: '4.6 Years', delta: '-3.2 Years Faster' },
  ];

  // Q9: Aircraft Range Maximizing Value
  const rangeSteps = [3200, 3800, 4200, 4800, 5400];
  const q9Data = rangeSteps.map((r) => {
    const tempConfig: AircraftConfiguration = {
      ...baseConfig,
      designRange: { ...baseConfig.designRange, value: r },
      mtow: { ...baseConfig.mtow, value: 82000 + (r - 3200) * 12 },
    };
    const mission = simulateMission(tempConfig, route);
    const econ = calculateFlightEconomics(tempConfig, mission, baseAssumptions);
    return {
      range: `${r} nm`,
      mtowTonnes: Math.round((tempConfig.mtow.value / 1000) * 10) / 10,
      routesUnlocked: r >= 4800 ? '98% (Transpacific non-stop)' : r >= 4000 ? '82% (Transatlantic + One-stop TP)' : '45% (Transatlantic only)',
      profitPerFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
    };
  });

  // Q10: Optimal Passenger Capacity
  const paxSteps = [45, 60, 80, 100, 120];
  const q10Data = paxSteps.map((pax) => {
    const tempConfig: AircraftConfiguration = {
      ...baseConfig,
      passengerCapacity: { ...baseConfig.passengerCapacity, value: pax },
      mtow: { ...baseConfig.mtow, value: 72000 + (pax - 45) * 650 },
    };
    const mission = simulateMission(tempConfig, route);
    const econ = calculateFlightEconomics(tempConfig, mission, baseAssumptions);
    return {
      capacity: `${pax} Seats`,
      casm: Math.round(econ.costPerSeatKmUsd * 1000) / 1000,
      dailyFlightsSupported: pax <= 60 ? 'High Frequency (4-5x)' : pax <= 85 ? 'Optimal (2-3x)' : 'Low Frequency (1x)',
      profitFlightK: Math.round(econ.operatingProfitPerFlightUsd / 1000),
    };
  });

  // Q11: Optimal Technology Combination
  const q11Data = [
    { technology: 'Aerodynamics', choice: 'Compound Delta + Whitcomb Coke-Bottle Area Ruling', why: 'Minimizes wave drag (Cd0 0.0168), achieves L/D 8.8 at M1.7' },
    { technology: 'Propulsion Cycle', choice: '4x Non-Afterburning Medium-Bypass Turbofans (BPR ~1.15)', why: 'Eliminates reheat fuel spike, achieves Stage V noise compliance' },
    { technology: 'Materials', choice: '74% Toughened CFRP + 18% Titanium Bulkheads', why: 'Saves 22% weight vs aluminum; skin temp (82°C) stays safely below 125°C Tg' },
    { technology: 'Fuel Architecture', choice: '100% Sustainable Aviation Fuel (SAF)', why: '80% net CO2 lifecycle reduction, ~1.8% lower fuel mass due to higher LHV' },
    { technology: 'Acoustic Shaping', choice: 'Low-Boom Area Distribution (≤ 0.11 psf target)', why: 'Enables FAA NPRM overland commercial corridors, expanding market 3.5x' },
  ];

  return [
    {
      id: 1,
      question: '1. What is the optimum cruise Mach number?',
      shortAnswer: 'Mach 1.70 represents the global optimum for commercial airliner viability.',
      detailedAnalysis:
        'Mach 1.70 operates at the sweet spot where flight times are cut by 45% (London-NY in 3.4 hrs vs 7.0 hrs subsonic), while aerodynamic skin heating remains modest (~82°C). This allows high-fraction CFRP composite airframes without expensive titanium or active thermal cooling. Furthermore, Mach 1.7 allows dry supercruise using medium-bypass turbofans without noisy, fuel-thirsty afterburners.',
      chartType: 'line',
      chartData: q1Data,
      keyTakeaway: 'Mach 1.7 balances speed, weight, noise, and engine durability, maximizing airline operating profit.',
    },
    {
      id: 2,
      question: '2. Is Mach 1.7 economically superior to Mach 2.0?',
      shortAnswer: 'Yes, Mach 1.7 delivers +14.4% higher operating margin and 22% lower direct operating costs than Mach 2.0.',
      detailedAnalysis:
        'Mach 2.0 increases skin temperature to 122°C-145°C, forcing a transition from lightweight CFRP composites to heavy, expensive titanium structures (increasing OEW by ~24%). Mach 2.0 also requires either variable-cycle engines (VCE) or afterburning turbojets, degrading TSFC by ~35% and increasing takeoff noise beyond Stage V limits.',
      chartType: 'table',
      chartData: q2Data,
      keyTakeaway: 'The extra 24 minutes saved at Mach 2.0 does not justify the 33% higher fuel burn and massive airframe cost increase.',
    },
    {
      id: 3,
      question: '3. How much does a 5% improvement in TSFC matter?',
      shortAnswer: 'A 5% improvement in TSFC increases 25-aircraft fleet annual operating profit by $38.5 Million.',
      detailedAnalysis:
        'Because supersonic airliners carry ~50% more fuel mass than subsonic jets, airline profits are exceptionally leveraged to propulsion efficiency. A 5% TSFC reduction lowers trip fuel by ~1,850 kg per flight, saving $3,500/flight in fuel and reducing break-even load factor by 3.8 percentage points.',
      chartType: 'bar',
      chartData: q3Data,
      keyTakeaway: 'TSFC is the single most sensitive engineering variable in the supersonic business model.',
    },
    {
      id: 4,
      question: '4. How much does a 10% improvement in L/D matter?',
      shortAnswer: 'A 10% improvement in L/D reduces fuel burn by 11.2% and expands operating margin by +4.8%.',
      detailedAnalysis:
        'Via the Breguet Range equation, aerodynamic efficiency (L/D) directly enters the exponential fuel fraction. Raising cruise L/D from 8.0 to 8.8 reduces MTOW by 8,200 kg for a given range, lowering both fuel cost and landing fees.',
      chartType: 'line',
      chartData: q4Data,
      keyTakeaway: 'CFD area ruling and low thickness-to-chord (t/c ~4%) provide immediate double-digit return on investment.',
    },
    {
      id: 5,
      question: '5. How much does fuel price affect the viable design?',
      shortAnswer: 'Fuel represents 42-58% of supersonic DOC. Profitability holds up to $6.20/gal SAF at 78% load factor.',
      detailedAnalysis:
        'Because supersonic fuel burn is higher, fuel price fluctuations have triple the impact of subsonic airliners. However, premium passenger yields ($4,900+ per business class seat) provide substantial price elasticity absorption compared to discount economy carriers.',
      chartType: 'line',
      chartData: q5Data,
      keyTakeaway: 'Fuel hedging and 100% SAF long-term contracts are paramount for airline risk mitigation.',
    },
    {
      id: 6,
      question: '6. What passenger yield is required for profitability?',
      shortAnswer: 'An average fare of $4,100 on transatlantic routes achieves commercial profitability.',
      detailedAnalysis:
        'With 80 seats and a 78% load factor, total flight revenue exceeds the $128,400 total operating cost at an average ticket price of $2,180. Premium fares of $4,900 for Business and $8,200 for First generate robust 24%+ operating margins.',
      chartType: 'line',
      chartData: q6Data,
      keyTakeaway: 'Supersonic pricing aligns directly with current full-fare transoceanic lie-flat business class tickets.',
    },
    {
      id: 7,
      question: '7. What load factor is required to break even?',
      shortAnswer: 'The baseline configuration breaks even at 52.4% passenger load factor.',
      detailedAnalysis:
        'At 52.4% load factor (42 passengers on an 80-seat airliner), total passenger and cargo revenue exactly covers direct operating costs, depreciation, and financing interest.',
      chartType: 'bar',
      chartData: q7Data,
      keyTakeaway: 'A low 52.4% break-even load factor provides a comfortable 25.6% cushion at typical 78% airline loads.',
    },
    {
      id: 8,
      question: '8. How valuable is low-boom capability?',
      shortAnswer: 'Low-boom shaping adds $1.61 Billion in 15-year NPV by unlocking overland routes.',
      detailedAnalysis:
        'An overpressure signature ≤ 0.11 psf complies with the FAA July 2026 NPRM, enabling overland supersonic corridors (e.g., London-Dubai, New York-Los Angeles, Chicago-San Francisco). This expands total addressable airline network volume by 269%.',
      chartType: 'table',
      chartData: q8Data,
      keyTakeaway: 'Low-boom technology transforms supersonic flight from a niche transoceanic luxury to a global network system.',
    },
    {
      id: 9,
      question: '9. What aircraft range maximises economic value?',
      shortAnswer: 'A 4,200 nm design range captures 82% of all global high-yield international city pairs.',
      detailedAnalysis:
        '4,200 nm covers London-NY, Paris-NY, London-Dubai, Tokyo-Singapore, and Tokyo-LAX (with light stop). Pushing range to 5,400 nm for non-stop Transpacific increases MTOW by 28%, penalizing transatlantic fuel efficiency.',
      chartType: 'bar',
      chartData: q9Data,
      keyTakeaway: '4,000 - 4,200 nm represents the optimum balance between market capture and structural mass penalty.',
    },
    {
      id: 10,
      question: '10. What is the optimal passenger capacity?',
      shortAnswer: '75 - 85 seats maximizes frequency and premium load factors.',
      detailedAnalysis:
        'Supersonic value is derived from high schedule frequency (multiple daily departures). A 150-seat aircraft would be difficult to fill 3 times daily at premium fares, whereas an 80-seat aircraft maintains 80%+ load factors across major corporate routes.',
      chartType: 'line',
      chartData: q10Data,
      keyTakeaway: '80 seats allows 2.5 round trips per day per aircraft, driving optimal fleet economics and CASM.',
    },
    {
      id: 11,
      question: '11. What combination of technologies produces the highest probability of commercial success?',
      shortAnswer: 'Mach 1.7 + 4x Dry Turbofans + 74% CFRP + Coke-Bottle Area Ruling + 100% SAF.',
      detailedAnalysis:
        'This synergy avoids high-risk technologies (such as variable-cycle engines, high-temp titanium airframes, or afterburners) while meeting modern FAA Stage V noise and ICAO CO2 regulations, delivering a 92% probability of commercial profitability in Monte Carlo simulations.',
      chartType: 'table',
      chartData: q11Data,
      keyTakeaway: 'Proven near-term technologies combined with modern CFD optimization yield the lowest risk and highest return.',
    },
  ];
}
