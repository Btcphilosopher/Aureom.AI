import { AircraftConfiguration } from '../types/aircraft';
import { DecisionCriteriaWeights, DecisionScoreBreakdown } from '../types/designSpace';
import { EconomicAssumptions, FlightEconomicsResult } from '../types/economics';
import { MissionProfileResult } from '../types/physics';
import { calculateFlightEconomics, DEFAULT_ECONOMIC_ASSUMPTIONS } from './economics';
import { simulateMission } from './mission';
import { calculateSonicBoom } from './sonicBoom';
import { calculateThermalState } from './thermal';

export const DEFAULT_DECISION_WEIGHTS: DecisionCriteriaWeights = {
  technicalFeasibility: 15,
  economicViability: 20,
  environmentalPerformance: 15,
  regulatoryExposure: 10,
  developmentRisk: 10,
  manufacturingComplexity: 8,
  supplyChainRisk: 7,
  operationalReliability: 8,
  marketAttractiveness: 7,
};

export function evaluateDecisionModel(
  config: AircraftConfiguration,
  routeMission: MissionProfileResult,
  flightEconomics: FlightEconomicsResult,
  weights: DecisionCriteriaWeights = DEFAULT_DECISION_WEIGHTS
): DecisionScoreBreakdown {
  const mach = config.machCruise.value;
  const pax = config.passengerCapacity.value;
  const rangeNm = config.designRange.value;
  const cycle = config.engineCycle.value;
  const safRatio = config.safBlendRatio.value;

  const thermal = calculateThermalState(config, mach, config.cruiseAltitude.value);
  const boom = calculateSonicBoom(config, mach, config.cruiseAltitude.value, config.mtow.value);

  // 1. Technical Feasibility (0-100)
  let techScore = 90;
  if (mach > 2.0) techScore -= 18; // Thermal & inlet complexity
  if (thermal.isThermalExceeded) techScore -= 35;
  else if (thermal.thermalMarginC < 15) techScore -= 12;
  if (cycle === 'variable_cycle') techScore -= 14; // High development TRL hurdle
  if (config.liftToDragCruise.value > 9.2) techScore -= 10; // High aerodynamic risk
  techScore = Math.min(100, Math.max(10, techScore));

  // 2. Economic Viability (0-100)
  let econScore = 50;
  if (flightEconomics.operatingMarginPercent > 20) econScore += 35;
  else if (flightEconomics.operatingMarginPercent > 10) econScore += 22;
  else if (flightEconomics.operatingMarginPercent > 0) econScore += 10;
  else econScore -= 25;

  if (flightEconomics.breakEvenLoadFactor < 0.65) econScore += 15;
  else if (flightEconomics.breakEvenLoadFactor > 0.85) econScore -= 20;

  if (config.aircraftUnitPrice.value > 220) econScore -= 10;
  econScore = Math.min(100, Math.max(10, econScore));

  // 3. Environmental Performance (0-100)
  let envScore = 40;
  if (safRatio >= 0.99) envScore += 35; // 100% SAF
  else envScore += safRatio * 25;

  if (cycle !== 'afterburning_turbojet' && !config.hasAfterburner.value) envScore += 15; // Stage V noise compliant
  if (boom.isOverlandAllowed) envScore += 10;
  envScore = Math.min(100, Math.max(10, envScore));

  // 4. Regulatory Exposure (0-100)
  let regScore = 50;
  if (boom.overpressurePsf <= 0.11) regScore += 35; // Passes FAA 2026 NPRM
  else if (boom.overpressurePsf <= 0.25) regScore += 10;
  else regScore -= 30; // Banned overland

  if (config.hasAfterburner.value) regScore -= 25; // LTO noise failure risk
  regScore = Math.min(100, Math.max(10, regScore));

  // 5. Development Risk (0-100, higher score = lower risk)
  let devScore = 80;
  if (config.programDevCost.value > 10.0) devScore -= 25;
  if (cycle === 'variable_cycle') devScore -= 25;
  if (mach > 2.0) devScore -= 20;
  if (config.isLowBoomShaped.value) devScore -= 8; // Shaping risk
  devScore = Math.min(100, Math.max(10, devScore));

  // 6. Manufacturing Complexity (0-100, higher score = simpler manufacturing)
  let mfgScore = 75;
  if (config.titaniumWeightFraction.value > 0.35) mfgScore -= 22; // High titanium machining/forming
  if (config.compositeWeightFraction.value > 0.70) mfgScore += 8; // Automated Fiber Placement (AFP) Superfactory
  if (config.thicknessChordRatio.value < 0.035) mfgScore -= 12; // Ultra-thin wing internal tolerances
  mfgScore = Math.min(100, Math.max(10, mfgScore));

  // 7. Supply Chain Risk (0-100, higher score = secure supply chain)
  let scScore = 78;
  if (cycle === 'variable_cycle') scScore -= 20;
  if (config.numEngines.value === 4) scScore += 5; // Standard 4-engine sourcing
  if (config.primaryMaterial.value === 'ceramic_matrix_composite') scScore -= 18;
  scScore = Math.min(100, Math.max(10, scScore));

  // 8. Operational Reliability (0-100)
  let relScore = 75;
  if (config.engineCycle.value === 'medium_bypass_turbofan') relScore += 15; // Built on proven commercial turbofan cores
  if (config.hasAfterburner.value) relScore -= 25; // Reheat increases engine shop visit frequency 3x
  if (mach <= 1.7) relScore += 8; // Lower thermal cycling stress
  relScore = Math.min(100, Math.max(10, relScore));

  // 9. Market Attractiveness (0-100)
  let mktScore = 65;
  if (pax >= 65 && pax <= 85) mktScore += 20; // Sweet spot for premium transoceanic demand
  if (rangeNm >= 4000) mktScore += 15;
  if (mach >= 1.7) mktScore += 10;
  mktScore = Math.min(100, Math.max(10, mktScore));

  // Weighted score calculation
  const totalWeight =
    weights.technicalFeasibility +
    weights.economicViability +
    weights.environmentalPerformance +
    weights.regulatoryExposure +
    weights.developmentRisk +
    weights.manufacturingComplexity +
    weights.supplyChainRisk +
    weights.operationalReliability +
    weights.marketAttractiveness;

  const overallScore =
    (techScore * weights.technicalFeasibility +
      econScore * weights.economicViability +
      envScore * weights.environmentalPerformance +
      regScore * weights.regulatoryExposure +
      devScore * weights.developmentRisk +
      mfgScore * weights.manufacturingComplexity +
      scScore * weights.supplyChainRisk +
      relScore * weights.operationalReliability +
      mktScore * weights.marketAttractiveness) /
    Math.max(1, totalWeight);

  // Radar scores
  const radarScores = [
    { criteria: 'Technical Feasibility', score: techScore, benchmarkScore: 68, weight: weights.technicalFeasibility },
    { criteria: 'Economic Viability', score: econScore, benchmarkScore: 45, weight: weights.economicViability },
    { criteria: 'Environmental Performance', score: envScore, benchmarkScore: 30, weight: weights.environmentalPerformance },
    { criteria: 'Regulatory Exposure', score: regScore, benchmarkScore: 40, weight: weights.regulatoryExposure },
    { criteria: 'Development Risk', score: devScore, benchmarkScore: 50, weight: weights.developmentRisk },
    { criteria: 'Manufacturing Complexity', score: mfgScore, benchmarkScore: 55, weight: weights.manufacturingComplexity },
    { criteria: 'Supply Chain Risk', score: scScore, benchmarkScore: 60, weight: weights.supplyChainRisk },
    { criteria: 'Operational Reliability', score: relScore, benchmarkScore: 52, weight: weights.operationalReliability },
    { criteria: 'Market Attractiveness', score: mktScore, benchmarkScore: 70, weight: weights.marketAttractiveness },
  ];

  const keyPros: string[] = [];
  const keyCons: string[] = [];

  if (techScore >= 80) keyPros.push('High technical feasibility with manageable aero-thermal risk.');
  if (econScore >= 75) keyPros.push(`Strong operating margin (${flightEconomics.operatingMarginPercent.toFixed(1)}%) and low break-even load factor.`);
  if (envScore >= 75) keyPros.push('100% SAF compatibility and Stage V noise compliance without reheat.');
  if (regScore >= 75) keyPros.push(`Low-boom signature (${boom.overpressurePsf} psf) compliant with FAA NPRM overland standards.`);
  if (relScore >= 80) keyPros.push('Commercial turbofan derivative propulsion ensures high dispatch reliability.');

  if (techScore < 70) keyCons.push('Significant technical hurdles in aero-thermal management or propulsion cycle.');
  if (econScore < 60) keyCons.push(`Challenging unit economics: CASM is $${flightEconomics.costPerSeatKmUsd.toFixed(3)}/seat-km.`);
  if (regScore < 60) keyCons.push(`High sonic boom overpressure (${boom.overpressurePsf} psf) restricts overland flight.`);
  if (devScore < 65) keyCons.push(`High development budget ($${config.programDevCost.value}B) and certification risk.`);

  let recommendation = '';
  if (overallScore >= 80) {
    recommendation = 'OPTIMAL CONFIGURATION: High probability of commercial and technical success. Recommended for detailed preliminary design and prototype development.';
  } else if (overallScore >= 65) {
    recommendation = 'VIABLE WITH TARGETED RISK MITIGATION: Economically attractive but requires targeted R&D on inlet recovery, noise reduction, or composite curing.';
  } else {
    recommendation = 'HIGH RISK / DOMINATED: Consider re-scoping speed or passenger capacity to avoid prohibitive thermal or engine development costs.';
  }

  return {
    aircraftId: config.id,
    aircraftName: config.name,
    overallScore: Math.round(overallScore * 10) / 10,
    technicalScore: Math.round(techScore),
    economicScore: Math.round(econScore),
    environmentalScore: Math.round(envScore),
    regulatoryScore: Math.round(regScore),
    developmentRiskScore: Math.round(devScore),
    manufacturingScore: Math.round(mfgScore),
    supplyChainScore: Math.round(scScore),
    reliabilityScore: Math.round(relScore),
    marketScore: Math.round(mktScore),
    radarScores,
    keyPros,
    keyCons,
    recommendation,
  };
}
