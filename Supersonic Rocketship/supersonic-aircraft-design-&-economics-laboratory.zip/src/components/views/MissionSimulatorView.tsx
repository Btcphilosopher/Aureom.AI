import React from 'react';
import { Plane, Clock, Gauge, Fuel, Route, AlertCircle } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { FlightRoute, MissionProfileResult } from '../../types/physics';
import { simulateMission, PRESET_ROUTES } from '../../engine/mission';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from 'recharts';

interface MissionSimulatorViewProps {
  config: AircraftConfiguration;
  mission: MissionProfileResult;
  selectedRouteIndex: number;
  onSelectRoute: (idx: number) => void;
  unitSystem: 'SI' | 'Imperial';
}

export const MissionSimulatorView: React.FC<MissionSimulatorViewProps> = ({
  config,
  mission,
  selectedRouteIndex,
  onSelectRoute,
  unitSystem,
}) => {
  const isSI = unitSystem === 'SI';
  const route = PRESET_ROUTES[selectedRouteIndex] || PRESET_ROUTES[0];

  // Subsonic comparison: M0.82 standard widebody ~450 kts
  const subsonicFlightTimeHours = route.greatCircleDistanceNm / 450;
  const timeSavedHours = Math.max(0, subsonicFlightTimeHours - mission.flightTimeHours);
  const blockSpeedKnots = mission.totalDistanceNm / Math.max(0.1, mission.blockTimeHours);
  const co2Tonnes = (mission.blockFuelKg * (config.safBlendRatio.value > 0 ? 0.6 : 3.16)) / 1000;

  // Altitude Trajectory & Fuel burn step profile data
  const trajectoryData = mission.phases.map((p) => ({
    phaseName: p.phaseName,
    distanceNm: Math.round(p.distanceNm),
    distanceKm: Math.round(p.distanceKm),
    altitudeFt: Math.round(p.endAltitudeM * 3.28084),
    altitudeM: Math.round(p.endAltitudeM),
    mach: p.endMach,
    fuelBurnedKg: Math.round(p.fuelBurnKg),
    remainingMassKg: Math.round(p.endWeightKg),
    durationMin: Math.round(p.timeMinutes),
    avgThrustKn: Math.round(p.avgThrustN / 1000),
  }));

  // Payload-Range Envelope data
  const maxPaxKg = config.passengerCapacity.value * 100 + config.cargoCapacity.value;
  const mtow = config.mtow.value;
  const oew = config.oew.value;
  const maxFuel = config.maxFuelCapacity.value;

  const payloadRangeData = [
    { rangeNm: 0, payloadKg: maxPaxKg, fuelKg: 0, label: 'Max Payload' },
    { rangeNm: Math.round(config.designRange.value * 0.75), payloadKg: maxPaxKg, fuelKg: mtow - oew - maxPaxKg, label: 'Max Payload Range' },
    { rangeNm: config.designRange.value, payloadKg: maxPaxKg * 0.82, fuelKg: maxFuel, label: 'Design Range' },
    { rangeNm: Math.round(config.designRange.value * 1.35), payloadKg: 0, fuelKg: maxFuel, label: 'Ferry Range (Zero Payload)' },
  ];

  return (
    <div className="space-y-6">
      {/* Route Selector & Mission Summary Card */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1f1f2e]">
          <div>
            <div className="flex items-center gap-2">
              <Route className="w-5 h-5 text-sky-400" />
              <h2 className="text-base font-bold text-zinc-100 tracking-tight">
                MISSION PROFILE: {route.name}
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {route.originIata} ({route.origin}) → {route.destinationIata} ({route.destination}) | Great Circle: {route.greatCircleDistanceNm} nm ({route.greatCircleDistanceKm} km) | Overwater: {(route.overwaterFraction * 100).toFixed(0)}%
            </p>
          </div>

          {/* Route Quick Switcher Pills */}
          <div className="flex flex-wrap gap-1.5">
            {PRESET_ROUTES.map((rt, idx) => (
              <button
                key={rt.id}
                onClick={() => onSelectRoute(idx)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  selectedRouteIndex === idx
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
                    : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
                }`}
              >
                {rt.originIata}-{rt.destinationIata}
              </button>
            ))}
          </div>
        </div>

        {/* Mission Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">FLIGHT TIME</div>
            <div className="text-base font-bold text-sky-400 mt-0.5">
              {mission.flightTimeHours.toFixed(2)} hrs
            </div>
            <div className="text-[10px] text-zinc-500">Block: {mission.blockTimeHours.toFixed(2)} hrs</div>
          </div>

          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">SUBSONIC SAVINGS</div>
            <div className="text-base font-bold text-emerald-400 mt-0.5">
              -{timeSavedHours.toFixed(1)} hrs
            </div>
            <div className="text-[10px] text-zinc-500">Subsonic: {subsonicFlightTimeHours.toFixed(1)} hrs</div>
          </div>

          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">TRIP FUEL BURN</div>
            <div className="text-base font-bold text-amber-400 mt-0.5">
              {isSI
                ? `${Math.round(mission.tripFuelKg).toLocaleString()} kg`
                : `${Math.round(mission.tripFuelKg * 2.20462).toLocaleString()} lb`}
            </div>
            <div className="text-[10px] text-zinc-500">Reserves: {Math.round(mission.totalReserveFuelKg).toLocaleString()} kg</div>
          </div>

          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">AVERAGE SPEED</div>
            <div className="text-base font-bold text-indigo-400 mt-0.5">
              {Math.round(blockSpeedKnots)} kts
            </div>
            <div className="text-[10px] text-zinc-500">{Math.round(blockSpeedKnots * 1.852)} km/h</div>
          </div>

          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">FUEL PER SEAT</div>
            <div className="text-base font-bold text-sky-400 mt-0.5">
              {Math.round(mission.tripFuelKg / config.passengerCapacity.value)} kg
            </div>
            <div className="text-[10px] text-zinc-500">at 100% capacity</div>
          </div>

          <div className="bg-[#13131e] p-3 rounded-lg border border-[#222232]">
            <div className="text-[10px] text-zinc-400 font-medium uppercase">NET CO2 EMISSIONS</div>
            <div className="text-base font-bold text-teal-400 mt-0.5">
              {co2Tonnes.toFixed(1)} t
            </div>
            <div className="text-[10px] text-zinc-500">100% SAF lifecycle</div>
          </div>
        </div>
      </div>

      {/* Trajectory Profile Chart & Payload-Range Diagram */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 7-Phase Trajectory Altitude Profile */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              MISSION ALTITUDE & MACH PROFILE
            </h3>
            <span className="text-[11px] text-sky-400">FL600 Supercruise</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trajectoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="phaseName" stroke="#525266" tick={{ fontSize: 10 }} />
                <YAxis yAxisId="alt" stroke="#38bdf8" domain={[0, 65000]} tickFormatter={(v) => `${v / 1000}k ft`} />
                <YAxis yAxisId="mach" orientation="right" stroke="#f59e0b" domain={[0, 2.5]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line yAxisId="alt" type="monotone" dataKey="altitudeFt" name="Altitude (ft)" stroke="#38bdf8" strokeWidth={2.5} />
                <Line yAxisId="mach" type="stepAfter" dataKey="mach" name="Mach Number" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Payload-Range Diagram */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              PAYLOAD-RANGE ENVELOPE (MTOW & FUEL CAPACITY)
            </h3>
            <span className="text-[11px] text-emerald-400">Max Range: {config.designRange.value} nm</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={payloadRangeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="rangeNm" stroke="#525266" tickFormatter={(v) => `${v} nm`} />
                <YAxis stroke="#525266" domain={[0, 14000]} tickFormatter={(v) => `${v / 1000}k kg`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Area type="linear" dataKey="payloadKg" name="Payload Capacity (kg)" stroke="#10b981" fill="#10b981" fillOpacity={0.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* 7-Phase Numerical Integration Data Table */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
          7-PHASE NUMERICAL MISSION INTEGRATION LOG
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Phase Name</th>
                <th className="py-2.5 px-3">Mach</th>
                <th className="py-2.5 px-3">Start Alt</th>
                <th className="py-2.5 px-3">End Alt</th>
                <th className="py-2.5 px-3">Distance</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Fuel Burned</th>
                <th className="py-2.5 px-3">Avg L/D</th>
                <th className="py-2.5 px-3">End Weight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181826] font-mono text-zinc-300 text-[11px]">
              {mission.phases.map((p, idx) => (
                <tr key={idx} className="hover:bg-[#12121c] transition-colors">
                  <td className="py-2 px-3 font-sans font-semibold text-zinc-100">{p.phaseName}</td>
                  <td className="py-2 px-3 text-sky-400">M {p.endMach.toFixed(2)}</td>
                  <td className="py-2 px-3">{Math.round(p.startAltitudeM)} m</td>
                  <td className="py-2 px-3">{Math.round(p.endAltitudeM)} m</td>
                  <td className="py-2 px-3">{Math.round(p.distanceNm)} nm</td>
                  <td className="py-2 px-3">{Math.round(p.timeMinutes)} min</td>
                  <td className="py-2 px-3 font-semibold text-amber-400">{Math.round(p.fuelBurnKg).toLocaleString()} kg</td>
                  <td className="py-2 px-3">{p.avgLD.toFixed(1)}</td>
                  <td className="py-2 px-3">{Math.round(p.endWeightKg).toLocaleString()} kg</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
