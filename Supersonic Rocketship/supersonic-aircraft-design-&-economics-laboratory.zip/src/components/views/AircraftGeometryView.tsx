import React from 'react';
import { Sliders, Activity, Info, ShieldAlert, Cpu } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { StructuralBuildUp } from '../../types/physics';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';

interface AircraftGeometryViewProps {
  config: AircraftConfiguration;
  structure: StructuralBuildUp;
  unitSystem: 'SI' | 'Imperial';
  onUpdateConfig: (newConfig: AircraftConfiguration) => void;
}

export const AircraftGeometryView: React.FC<AircraftGeometryViewProps> = ({
  config,
  structure,
  unitSystem,
  onUpdateConfig,
}) => {
  const isSI = unitSystem === 'SI';

  const updateParam = (key: keyof AircraftConfiguration, val: number | string | boolean) => {
    const current = config[key];
    if (typeof current === 'object' && current !== null && 'value' in current) {
      onUpdateConfig({
        ...config,
        [key]: {
          ...(current as any),
          value: val,
        },
      });
    } else {
      onUpdateConfig({
        ...config,
        [key]: val,
      });
    }
  };

  // Mass breakdown data for Pie Chart
  const massData = [
    { name: 'Wing Structure', value: Math.round(structure.wingMassKg), color: '#38bdf8' },
    { name: 'Fuselage Structure', value: Math.round(structure.fuselageMassKg), color: '#818cf8' },
    { name: 'Empennage / Tails', value: Math.round(structure.empennageMassKg), color: '#c084fc' },
    { name: 'Landing Gear', value: Math.round(structure.landingGearMassKg), color: '#fb7185' },
    { name: 'Engines & Nacelles', value: Math.round(structure.enginesTotalMassKg + structure.nacellePylonMassKg), color: '#f59e0b' },
    { name: 'Systems & Avionics', value: Math.round(structure.systemsMassKg), color: '#34d399' },
    { name: 'Payload (Pax+Cargo)', value: Math.round(structure.payloadKg), color: '#10b981' },
    { name: 'Max Usable Fuel', value: Math.round(structure.maxFuelMassKg), color: '#ef4444' },
  ];

  // Material composition data
  const materialData = [
    { name: 'CFRP Carbon Composite', pct: Math.round(config.compositeWeightFraction.value * 100), color: '#0284c7' },
    { name: 'Titanium Alloys', pct: Math.round(config.titaniumWeightFraction.value * 100), color: '#64748b' },
    { name: 'Aluminum-Lithium', pct: Math.round(config.aluminumWeightFraction.value * 100), color: '#94a3b8' },
    { name: 'High-Temp Steel/Other', pct: Math.round(config.otherMaterialsWeightFraction.value * 100), color: '#f59e0b' },
  ];

  // SVG Planform coordinates based on geometry
  const sweep = config.sweepAngle.value;
  const span = config.wingSpan.value;
  const length = config.fuselageLength.value;
  const areaRuling = config.areaRulingQuality.value;
  const numEngines = config.numEngines.value;

  // Normalized visual sizing
  const scale = 2.4;
  const centerW = 200;
  const noseY = 20;
  const tailY = noseY + length * scale;
  const halfSpan = (span / 2) * scale;
  const rootChord = 24 * scale;
  const tipChord = 2.5 * scale;
  const wingRootY = noseY + 28 * scale;
  const sweepOffset = halfSpan * Math.tan((sweep * Math.PI) / 180);
  const wingTipY = wingRootY + sweepOffset * 0.55;

  // Waist indentation for area ruling
  const waistDepth = areaRuling * 6.5;

  return (
    <div className="space-y-6">
      {/* Top Banner Overview */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-bold bg-sky-500/10 text-sky-400 border border-sky-500/30 rounded">
              {config.modelVersion}
            </span>
            <h2 className="text-lg font-bold text-zinc-100 tracking-tight">{config.name}</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 max-w-2xl">{config.description}</p>
        </div>

        {/* Quick Sizing KPIs */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-[#14141e] border border-[#242434] rounded-lg px-3.5 py-2 text-center shadow-sm">
            <div className="text-[10px] text-zinc-400 font-medium tracking-wide">MAX TAKEOFF WEIGHT</div>
            <div className="text-sm font-bold text-sky-400 font-mono">
              {isSI
                ? `${Math.round(config.mtow.value).toLocaleString()} kg`
                : `${Math.round(config.mtow.value * 2.20462).toLocaleString()} lb`}
            </div>
          </div>
          <div className="bg-[#14141e] border border-[#242434] rounded-lg px-3.5 py-2 text-center shadow-sm">
            <div className="text-[10px] text-zinc-400 font-medium tracking-wide">OPERATING EMPTY WEIGHT</div>
            <div className="text-sm font-bold text-indigo-400 font-mono">
              {isSI
                ? `${Math.round(structure.totalOewKg).toLocaleString()} kg`
                : `${Math.round(structure.totalOewKg * 2.20462).toLocaleString()} lb`}
            </div>
          </div>
          <div className="bg-[#14141e] border border-[#242434] rounded-lg px-3.5 py-2 text-center shadow-sm">
            <div className="text-[10px] text-zinc-400 font-medium tracking-wide">PASSENGER CAPACITY</div>
            <div className="text-sm font-bold text-emerald-400 font-mono">
              {config.passengerCapacity.value} Pax
            </div>
          </div>
          <div className="bg-[#14141e] border border-[#242434] rounded-lg px-3.5 py-2 text-center shadow-sm">
            <div className="text-[10px] text-zinc-400 font-medium tracking-wide">DESIGN RANGE</div>
            <div className="text-sm font-bold text-amber-400 font-mono">
              {isSI
                ? `${Math.round(config.designRange.value * 1.852).toLocaleString()} km`
                : `${config.designRange.value.toLocaleString()} nm`}
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Layout: Planform Viewer & Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive 2D Planform Schematic (5 Cols) */}
        <div className="lg:col-span-5 bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e]">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                AERODYNAMIC PLANFORM SCHEMATIC
              </h3>
            </div>
            <span className="text-[11px] text-zinc-400">
              Sweep: <strong className="text-sky-300">{sweep}°</strong> | AR: <strong className="text-sky-300">{config.aspectRatio.value}</strong>
            </span>
          </div>

          {/* SVG Canvas */}
          <div className="my-4 flex items-center justify-center bg-[#06060a] border border-[#1a1a28] rounded-lg p-2 relative h-96 overflow-hidden">
            {/* Grid lines */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#161622_1px,transparent_1px),linear-gradient(to_bottom,#161622_1px,transparent_1px)] bg-[size:20px_20px] opacity-40 pointer-events-none" />

            <svg viewBox="0 0 400 320" className="w-full h-full max-h-84 select-none">
              <defs>
                <linearGradient id="fuselageGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#14141e" />
                  <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#14141e" />
                </linearGradient>
                <linearGradient id="wingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0284c7" stopOpacity="0.75" />
                  <stop offset="100%" stopColor="#0369a1" stopOpacity="0.35" />
                </linearGradient>
              </defs>

              {/* Left Wing */}
              <polygon
                points={`
                  ${centerW},${wingRootY} 
                  ${centerW - halfSpan},${wingTipY} 
                  ${centerW - halfSpan + tipChord},${wingTipY + tipChord * 0.8} 
                  ${centerW},${wingRootY + rootChord}
                `}
                fill="url(#wingGrad)"
                stroke="#38bdf8"
                strokeWidth="1.5"
              />

              {/* Right Wing */}
              <polygon
                points={`
                  ${centerW},${wingRootY} 
                  ${centerW + halfSpan},${wingTipY} 
                  ${centerW + halfSpan - tipChord},${wingTipY + tipChord * 0.8} 
                  ${centerW},${wingRootY + rootChord}
                `}
                fill="url(#wingGrad)"
                stroke="#38bdf8"
                strokeWidth="1.5"
              />

              {/* Engine Nacelles */}
              {numEngines === 4 && (
                <>
                  {/* Left Inboard */}
                  <rect x={centerW - halfSpan * 0.42 - 4} y={wingRootY + rootChord * 0.4} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                  {/* Left Outboard */}
                  <rect x={centerW - halfSpan * 0.72 - 4} y={wingRootY + rootChord * 0.55} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                  {/* Right Inboard */}
                  <rect x={centerW + halfSpan * 0.42 - 4} y={wingRootY + rootChord * 0.4} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                  {/* Right Outboard */}
                  <rect x={centerW + halfSpan * 0.72 - 4} y={wingRootY + rootChord * 0.55} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                </>
              )}
              {numEngines === 3 && (
                <>
                  <rect x={centerW - halfSpan * 0.5 - 4} y={wingRootY + rootChord * 0.45} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                  <rect x={centerW + halfSpan * 0.5 - 4} y={wingRootY + rootChord * 0.45} width="8" height="24" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                  <rect x={centerW - 4} y={tailY - 20} width="8" height="26" rx="3" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                </>
              )}

              {/* Fuselage with Whitcomb Area-Ruling Waist */}
              <path
                d={`
                  M ${centerW},${noseY}
                  C ${centerW + 8},${noseY + 20} ${centerW + 10},${noseY + 40} ${centerW + 9},${noseY + 70}
                  C ${centerW + 9 - waistDepth},${noseY + 110} ${centerW + 9 - waistDepth},${noseY + 140} ${centerW + 9},${noseY + 170}
                  L ${centerW + 6},${tailY}
                  L ${centerW - 6},${tailY}
                  C ${centerW - 9},${noseY + 170} ${centerW - 9 + waistDepth},${noseY + 140} ${centerW - 9 + waistDepth},${noseY + 110}
                  C ${centerW - 9},${noseY + 70} ${centerW - 10},${noseY + 40} ${centerW - 8},${noseY + 20}
                  Z
                `}
                fill="url(#fuselageGrad)"
                stroke="#60a5fa"
                strokeWidth="1.5"
              />

              {/* Cockpit Canopy */}
              <ellipse cx={centerW} cy={noseY + 24} rx="3.5" ry="8" fill="#38bdf8" />

              {/* Vertical Stabilizer / Tail */}
              <polygon
                points={`
                  ${centerW - 2},${tailY - 28}
                  ${centerW + 2},${tailY - 28}
                  ${centerW + 1.5},${tailY}
                  ${centerW - 1.5},${tailY}
                `}
                fill="#c084fc"
                stroke="#a855f7"
                strokeWidth="1"
              />

              {/* Dimension Callouts */}
              <text x={centerW} y={noseY - 6} fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="monospace">
                Length: {config.fuselageLength.value} m
              </text>
              <line x1={centerW - halfSpan} y1={wingTipY - 8} x2={centerW + halfSpan} y2={wingTipY - 8} stroke="#475569" strokeDasharray="3 3" />
              <text x={centerW} y={wingTipY - 12} fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="monospace">
                Wingspan: {config.wingSpan.value} m
              </text>
            </svg>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 bg-[#12121c] rounded border border-[#202030]">
              <span className="text-zinc-400">Wing Area:</span>{' '}
              <strong className="text-zinc-100 font-mono">{config.wingArea.value} m²</strong>
            </div>
            <div className="p-2 bg-[#12121c] rounded border border-[#202030]">
              <span className="text-zinc-400">Thickness/Chord (t/c):</span>{' '}
              <strong className="text-zinc-100 font-mono">{(config.thicknessChordRatio.value * 100).toFixed(1)}%</strong>
            </div>
            <div className="p-2 bg-[#12121c] rounded border border-[#202030]">
              <span className="text-zinc-400">Area Ruling (Coke):</span>{' '}
              <strong className="text-zinc-100 font-mono">{(config.areaRulingQuality.value * 100).toFixed(0)}% Eff.</strong>
            </div>
            <div className="p-2 bg-[#12121c] rounded border border-[#202030]">
              <span className="text-zinc-400">Fuel Vol. Capacity:</span>{' '}
              <strong className="text-zinc-100 font-mono">{Math.round(structure.maxFuelMassKg).toLocaleString()} kg</strong>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Parameter Tuning Sliders (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1f1f2e] mb-4">
              <Sliders className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                AIRCRAFT DESIGN & MISSION PARAMETERS
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Cruise Mach Slider */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="mach-slider" className="font-semibold text-zinc-300">Cruise Mach Number</label>
                  <span className="font-bold text-sky-400 font-mono">M {config.machCruise.value.toFixed(2)}</span>
                </div>
                <input
                  id="mach-slider"
                  type="range"
                  min="1.4"
                  max="2.4"
                  step="0.05"
                  value={config.machCruise.value}
                  onChange={(e) => updateParam('machCruise', Number(e.target.value))}
                  className="w-full accent-sky-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>M 1.4 (Low Shock)</span>
                  <span>M 1.7 (Optimum)</span>
                  <span>M 2.4 (High Thermal)</span>
                </div>
              </div>

              {/* Passenger Capacity Slider */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="pax-slider" className="font-semibold text-zinc-300">Passenger Capacity</label>
                  <span className="font-bold text-emerald-400 font-mono">{config.passengerCapacity.value} Seats</span>
                </div>
                <input
                  id="pax-slider"
                  type="range"
                  min="40"
                  max="120"
                  step="5"
                  value={config.passengerCapacity.value}
                  onChange={(e) => updateParam('passengerCapacity', Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>40 (Boutique)</span>
                  <span>80 (Sweet Spot)</span>
                  <span>120 (High Density)</span>
                </div>
              </div>

              {/* Design Range Slider */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="range-slider" className="font-semibold text-zinc-300">Design Range (nm)</label>
                  <span className="font-bold text-amber-400 font-mono">{config.designRange.value} nm</span>
                </div>
                <input
                  id="range-slider"
                  type="range"
                  min="3000"
                  max="5500"
                  step="100"
                  value={config.designRange.value}
                  onChange={(e) => updateParam('designRange', Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>3,000 nm (Transat)</span>
                  <span>4,200 nm (Optimum)</span>
                  <span>5,500 nm (Transpac)</span>
                </div>
              </div>

              {/* Wing Sweep Angle */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="sweep-slider" className="font-semibold text-zinc-300">Wing Leading Edge Sweep</label>
                  <span className="font-bold text-indigo-400 font-mono">{config.sweepAngle.value}°</span>
                </div>
                <input
                  id="sweep-slider"
                  type="range"
                  min="50"
                  max="70"
                  step="1"
                  value={config.sweepAngle.value}
                  onChange={(e) => updateParam('sweepAngle', Number(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>50° (Transonic)</span>
                  <span>62° (Compound)</span>
                  <span>70° (Delta)</span>
                </div>
              </div>

              {/* Area Ruling Quality */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="area-ruling-slider" className="font-semibold text-zinc-300">Whitcomb Area Ruling</label>
                  <span className="font-bold text-sky-400 font-mono">
                    {(config.areaRulingQuality.value * 100).toFixed(0)}%
                  </span>
                </div>
                <input
                  id="area-ruling-slider"
                  type="range"
                  min="0.5"
                  max="0.98"
                  step="0.02"
                  value={config.areaRulingQuality.value}
                  onChange={(e) => updateParam('areaRulingQuality', Number(e.target.value))}
                  className="w-full accent-sky-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>50% (Standard)</span>
                  <span>88% (Coke Bottle)</span>
                  <span>98% (CFD Inverse)</span>
                </div>
              </div>

              {/* SAF Blend Ratio */}
              <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
                <div className="flex justify-between items-center">
                  <label htmlFor="saf-blend-slider" className="font-semibold text-zinc-300">SAF Blend Fraction</label>
                  <span className="font-bold text-emerald-400 font-mono">
                    {(config.safBlendRatio.value * 100).toFixed(0)}% SAF
                  </span>
                </div>
                <input
                  id="saf-blend-slider"
                  type="range"
                  min="0"
                  max="1.0"
                  step="0.05"
                  value={config.safBlendRatio.value}
                  onChange={(e) => updateParam('safBlendRatio', Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>0% (Fossil Jet-A)</span>
                  <span>50% Blend</span>
                  <span>100% Drop-in SAF</span>
                </div>
              </div>
            </div>
          </div>

          {/* Mass Buildup & Materials Split (2 mini cards) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Mass Pie */}
            <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
              <h4 className="text-xs font-bold text-zinc-200 mb-2 uppercase tracking-wider">
                Mass Buildup Fraction (MTOW)
              </h4>
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={massData}
                      cx="50%"
                      cy="50%"
                      innerRadius={36}
                      outerRadius={65}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {massData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: any) => [`${Number(val).toLocaleString()} kg`, 'Mass']}
                      contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Material Bars */}
            <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 flex flex-col justify-between shadow-sm">
              <h4 className="text-xs font-bold text-zinc-200 mb-2 uppercase tracking-wider">
                Structural Materials Breakdown
              </h4>
              <div className="space-y-2 text-xs">
                {materialData.map((mat) => (
                  <div key={mat.name} className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-zinc-300">{mat.name}</span>
                      <span className="font-bold text-zinc-100 font-mono">{mat.pct}%</span>
                    </div>
                    <div className="w-full bg-[#161622] rounded-full h-1.5 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${mat.pct}%`, backgroundColor: mat.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-3 p-2 bg-[#12121c] rounded border border-[#202030] text-[11px] text-zinc-400">
                {config.machCruise.value <= 1.8 ? (
                  <span className="text-sky-300">
                    ✓ Mach ≤ 1.8 enables 74%+ lightweight Toughened CFRP airframe structure.
                  </span>
                ) : (
                  <span className="text-amber-300">
                    ⚠ Mach &gt; 1.8 aerodynamic heating forces higher Titanium &amp; Al-Li fractions.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
