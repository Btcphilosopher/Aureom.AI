import React from 'react';
import { Crosshair, Sliders, CheckCircle, AlertTriangle, ArrowUpDown, ShieldCheck } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { DecisionCriteriaWeights, DecisionScoreBreakdown, SensitivityMetric } from '../../types/designSpace';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Cell,
} from 'recharts';

interface SensitivityDecisionViewProps {
  config: AircraftConfiguration;
  sensitivityMetrics: SensitivityMetric[];
  decisionScore: DecisionScoreBreakdown;
  decisionWeights: DecisionCriteriaWeights;
  onUpdateWeights: (newWeights: DecisionCriteriaWeights) => void;
}

export const SensitivityDecisionView: React.FC<SensitivityDecisionViewProps> = ({
  config,
  sensitivityMetrics,
  decisionScore,
  decisionWeights,
  onUpdateWeights,
}) => {
  // Tornado chart formatted data
  const tornadoData = sensitivityMetrics.map((m) => ({
    name: m.parameterName.replace(/\s\(.*\)/, ''),
    category: m.category,
    lowDelta: Math.round(m.lowCaseDeltaProfit / 1000),
    highDelta: Math.round(m.highCaseDeltaProfit / 1000),
    sobol: m.sobolFirstOrderIndex,
  }));

  const radarData = decisionScore.radarScores.map((r) => ({
    criteria: r.criteria,
    score: r.score,
    benchmark: r.benchmarkScore,
  }));

  const updateWeight = (key: keyof DecisionCriteriaWeights, val: number) => {
    onUpdateWeights({
      ...decisionWeights,
      [key]: val,
    });
  };

  return (
    <div className="space-y-6">
      {/* 9-Pillar Decision Recommendation Banner */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1f1f2e]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-600 rounded-xl text-white shadow-md shadow-sky-950/40">
              <Crosshair className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-zinc-100 tracking-tight">
                  9-PILLAR MULTI-CRITERIA DECISION MATRIX
                </h2>
                <span className="px-2 py-0.5 text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded">
                  Score: {decisionScore.overallScore} / 100
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Integrated Technical, Economic, Environmental, Regulatory & Manufacturing Evaluation
              </p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-[10px] text-zinc-400 font-semibold uppercase">RECOMMENDATION STATUS</div>
            <div className="text-xs font-bold text-emerald-400 mt-0.5">
              {decisionScore.overallScore >= 80 ? '✓ HIGH CONFIDENCE CANDIDATE' : '⚠ CONDITIONAL VIABILITY'}
            </div>
          </div>
        </div>

        {/* Recommendation Narrative */}
        <div className="mt-4 p-3 bg-[#13131e] rounded-lg border border-[#222232] text-xs text-zinc-300">
          <strong className="text-zinc-100">Engineering Decision Assessment: </strong>
          {decisionScore.recommendation}
        </div>
      </div>

      {/* Row 1: Tornado Sensitivity Chart & 9-Pillar Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tornado Chart (7 Cols) */}
        <div className="lg:col-span-7 bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              TORNADO CHART: OPERATING PROFIT IMPACT (±% PARAMETER SWING)
            </h3>
            <span className="text-[11px] text-sky-400">$ Thousands / Flight</span>
          </div>

          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tornadoData} layout="vertical" margin={{ left: 80, right: 30 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis type="number" stroke="#525266" tickFormatter={(v) => `$${v}k`} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}k`, 'Profit Delta']}
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="lowDelta" name="Low Parameter Case" fill="#f43f5e" radius={[2, 0, 0, 2]} />
                <Bar dataKey="highDelta" name="High Parameter Case" fill="#10b981" radius={[0, 2, 2, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            * Parameter ranking strictly dominated by <strong>TSFC</strong> (28% Sobol variance share) and <strong>Passenger Load Factor</strong> (24% share).
          </p>
        </div>

        {/* 9-Pillar Radar Chart (5 Cols) */}
        <div className="lg:col-span-5 bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              9-PILLAR MULTI-OBJECTIVE RADAR
            </h3>
            <span className="text-[11px] text-indigo-400">vs Benchmark</span>
          </div>

          <div className="h-64 my-2">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#161624" />
                <PolarAngleAxis dataKey="criteria" stroke="#64748b" tick={{ fontSize: 9 }} />
                <PolarRadiusAxis domain={[0, 100]} stroke="#262638" />
                <Radar name="Current Aircraft" dataKey="score" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.4} />
                <Radar name="Historical Baseline" dataKey="benchmark" stroke="#64748b" fill="#64748b" fillOpacity={0.2} />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Tooltip contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] text-zinc-300">
            <div className="p-2 bg-[#13131e] rounded border border-[#222232]">
              <span className="text-zinc-400">Tech Score:</span> <strong className="text-zinc-100">{decisionScore.technicalScore}/100</strong>
            </div>
            <div className="p-2 bg-[#13131e] rounded border border-[#222232]">
              <span className="text-zinc-400">Econ Score:</span> <strong className="text-zinc-100">{decisionScore.economicScore}/100</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Sensitivity Correlation Matrix & Sobol Indices Table */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
          GLOBAL SENSITIVITY MATRIX & SOBOL VARIANCE DECOMPOSITION
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                <th className="py-2 px-3">Rank</th>
                <th className="py-2 px-3">Parameter Name</th>
                <th className="py-2 px-3">Category</th>
                <th className="py-2 px-3">Pearson r</th>
                <th className="py-2 px-3">Spearman rho</th>
                <th className="py-2 px-3">Regression Beta</th>
                <th className="py-2 px-3">Sobol Index (S_i)</th>
                <th className="py-2 px-3">Total Effect (S_Ti)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
              {sensitivityMetrics.map((m) => (
                <tr key={m.parameterName} className="hover:bg-[#12121c]">
                  <td className="py-2 px-3 font-sans font-bold text-sky-400">#{m.impactRank}</td>
                  <td className="py-2 px-3 font-sans font-semibold text-zinc-100">{m.parameterName}</td>
                  <td className="py-2 px-3 font-sans text-zinc-400">{m.category}</td>
                  <td className={`py-2 px-3 font-bold ${m.pearsonCorrelation >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {m.pearsonCorrelation > 0 ? '+' : ''}{m.pearsonCorrelation.toFixed(2)}
                  </td>
                  <td className="py-2 px-3">{m.spearmanRankCorrelation > 0 ? '+' : ''}{m.spearmanRankCorrelation.toFixed(2)}</td>
                  <td className="py-2 px-3">{m.regressionCoefficient > 0 ? '+' : ''}{m.regressionCoefficient.toFixed(2)}</td>
                  <td className="py-2 px-3 font-bold text-amber-400">{m.sobolFirstOrderIndex.toFixed(2)}</td>
                  <td className="py-2 px-3 font-bold text-indigo-400">{m.sobolTotalEffectIndex.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Row 3: Decision Weights Tuner */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2 pb-3 border-b border-[#1f1f2e] mb-4">
          <Sliders className="w-4 h-4 text-sky-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
            CONFIGURE 9-PILLAR DECISION MATRIX WEIGHTS
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          {Object.entries(decisionWeights).map(([k, v]) => (
            <div key={k} className="p-3 bg-[#13131e] rounded-lg border border-[#222232] space-y-1">
              <div className="flex justify-between text-[11px] font-semibold text-zinc-300">
                <span className="capitalize">{k.replace(/([A-Z])/g, ' $1')}</span>
                <span className="text-sky-400 font-bold">{v}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                step="1"
                value={v}
                onChange={(e) => updateWeight(k as keyof DecisionCriteriaWeights, Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
