import React, { useState } from 'react';
import { BarChart3, Play, RefreshCw, ShieldCheck, AlertCircle, Percent, TrendingDown } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { EconomicAssumptions } from '../../types/economics';
import { MonteCarloConfig, MonteCarloSummary } from '../../types/monteCarlo';
import { FlightRoute } from '../../types/physics';
import { DEFAULT_MONTE_CARLO_CONFIG, runMonteCarloSimulation } from '../../engine/monteCarlo';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  ComposedChart,
} from 'recharts';

interface MonteCarloViewProps {
  config: AircraftConfiguration;
  route: FlightRoute;
  assumptions: EconomicAssumptions;
  monteCarloSummary: MonteCarloSummary;
  onRunSimulation: (newSummary: MonteCarloSummary) => void;
}

export const MonteCarloView: React.FC<MonteCarloViewProps> = ({
  config,
  route,
  assumptions,
  monteCarloSummary,
  onRunSimulation,
}) => {
  const [iterations, setIterations] = useState<number>(10000);
  const [seed, setSeed] = useState<number>(2026);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [activeMetric, setActiveMetric] = useState<'profit' | 'npv' | 'casm'>('profit');

  const handleExecuteSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const simConfig: MonteCarloConfig = {
        ...DEFAULT_MONTE_CARLO_CONFIG,
        iterations,
        seed,
      };
      const result = runMonteCarloSimulation(config, route, assumptions, simConfig);
      onRunSimulation(result);
      setIsRunning(false);
    }, 50);
  };

  const getActiveHistogram = () => {
    switch (activeMetric) {
      case 'profit':
        return monteCarloSummary.profitHistogram.map((b) => ({
          binLabel: `$${Math.round(b.binMid / 1000)}k`,
          frequency: Math.round(b.frequency * 1000) / 10,
          cumulativePct: Math.round(b.cumulativeProbability * 100),
        }));
      case 'npv':
        return monteCarloSummary.npvHistogram.map((b) => ({
          binLabel: `$${Math.round(b.binMid)}M`,
          frequency: Math.round(b.frequency * 1000) / 10,
          cumulativePct: Math.round(b.cumulativeProbability * 100),
        }));
      case 'casm':
        return monteCarloSummary.casmHistogram.map((b) => ({
          binLabel: `$${b.binMid.toFixed(3)}`,
          frequency: Math.round(b.frequency * 1000) / 10,
          cumulativePct: Math.round(b.cumulativeProbability * 100),
        }));
    }
  };

  const profitStats = monteCarloSummary.profitDistribution;
  const npvStats = monteCarloSummary.npvDistribution;

  return (
    <div className="space-y-6">
      {/* Top Controls Ribbon */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold text-zinc-100 tracking-tight">
              PROBABILISTIC MONTE CARLO RISK SIMULATION
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            10,000 - 50,000 Vector Evaluations Across 12 Engineering & Economic Uncertainties
          </p>
        </div>

        {/* Configuration Triggers */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-[#13131e] px-3 py-1.5 rounded-lg border border-[#222232] text-xs">
            <span className="text-zinc-400">Iterations:</span>
            <select
              value={iterations}
              onChange={(e) => setIterations(Number(e.target.value))}
              aria-label="Monte Carlo Iteration Count"
              className="bg-transparent text-zinc-100 font-bold outline-none cursor-pointer"
            >
              <option value={10000} className="bg-[#0e0e14]">10,000 runs</option>
              <option value={25000} className="bg-[#0e0e14]">25,000 runs</option>
              <option value={50000} className="bg-[#0e0e14]">50,000 runs</option>
            </select>
          </div>

          <div className="flex items-center gap-2 bg-[#13131e] px-3 py-1.5 rounded-lg border border-[#222232] text-xs">
            <span className="text-zinc-400">Seed:</span>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(Number(e.target.value))}
              aria-label="Random Number Generator Seed"
              className="w-16 bg-transparent text-sky-400 font-mono font-bold outline-none"
            />
          </div>

          <button
            onClick={handleExecuteSimulation}
            disabled={isRunning}
            className="flex items-center gap-2 px-4 py-1.5 text-xs font-bold bg-sky-600 hover:bg-sky-500 text-white rounded-lg shadow-md shadow-sky-950/40 transition-all cursor-pointer"
          >
            {isRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isRunning ? 'Simulating...' : 'Run Simulation'}</span>
          </button>
        </div>
      </div>

      {/* 4 Risk KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Probability of Profit */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">PROBABILITY OF PROFIT</span>
            <Percent className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-2">
            {monteCarloSummary.probabilityOfProfitPercent.toFixed(1)}%
          </div>
          <div className="text-xs text-zinc-400 mt-1">
            Over {monteCarloSummary.totalIterations.toLocaleString()} iterations
          </div>
        </div>

        {/* Median Operating Profit */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">MEDIAN PROFIT / FLIGHT</span>
            <ShieldCheck className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 mt-2">
            ${Math.round(profitStats.median).toLocaleString()}
          </div>
          <div className="text-xs text-zinc-400 mt-1">
            Mean: ${Math.round(profitStats.mean).toLocaleString()}
          </div>
        </div>

        {/* Value at Risk (VaR 95%) */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">VALUE AT RISK (VaR 95%)</span>
            <TrendingDown className="w-4 h-4 text-amber-400" />
          </div>
          <div className={`text-2xl font-black mt-2 ${profitStats.var95 >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
            ${Math.round(profitStats.var95).toLocaleString()}
          </div>
          <div className="text-xs text-zinc-400 mt-1">
            Worst 5% Threshold (P5)
          </div>
        </div>

        {/* Expected Shortfall (CVaR 95%) */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">EXPECTED SHORTFALL (CVaR)</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className={`text-2xl font-black mt-2 ${profitStats.cvar95 >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${Math.round(profitStats.cvar95).toLocaleString()}
          </div>
          <div className="text-xs text-zinc-400 mt-1">
            Mean of worst 5% tail events
          </div>
        </div>
      </div>

      {/* Probability Distribution Histogram & CDF Chart */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#1f1f2e] mb-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
            PROBABILITY DENSITY FUNCTION (PDF) & CUMULATIVE DISTRIBUTION (CDF)
          </h3>
          <div className="flex gap-1.5 text-xs">
            <button
              onClick={() => setActiveMetric('profit')}
              className={`px-3 py-1 font-semibold rounded cursor-pointer transition-all ${
                activeMetric === 'profit' ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40' : 'bg-[#151522] text-zinc-400 hover:text-white border border-[#262638]'
              }`}
            >
              Operating Profit ($)
            </button>
            <button
              onClick={() => setActiveMetric('npv')}
              className={`px-3 py-1 font-semibold rounded cursor-pointer transition-all ${
                activeMetric === 'npv' ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40' : 'bg-[#151522] text-zinc-400 hover:text-white border border-[#262638]'
              }`}
            >
              15-Year Fleet NPV ($M)
            </button>
            <button
              onClick={() => setActiveMetric('casm')}
              className={`px-3 py-1 font-semibold rounded cursor-pointer transition-all ${
                activeMetric === 'casm' ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40' : 'bg-[#151522] text-zinc-400 hover:text-white border border-[#262638]'
              }`}
            >
              Unit CASM ($/ASK)
            </button>
          </div>
        </div>

        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={getActiveHistogram()}>
              <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
              <XAxis dataKey="binLabel" stroke="#525266" tick={{ fontSize: 10 }} />
              <YAxis yAxisId="freq" stroke="#38bdf8" label={{ value: 'Frequency (%)', angle: -90, position: 'insideLeft', fill: '#38bdf8', fontSize: 10 }} />
              <YAxis yAxisId="cdf" orientation="right" stroke="#f59e0b" domain={[0, 100]} label={{ value: 'Cumulative Probability (%)', angle: 90, position: 'insideRight', fill: '#f59e0b', fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }} />
              <Legend wrapperStyle={{ fontSize: '11px' }} />
              <Bar yAxisId="freq" dataKey="frequency" name="Probability Density" fill="#38bdf8" radius={[3, 3, 0, 0]} />
              <Line yAxisId="cdf" type="monotone" dataKey="cumulativePct" name="Cumulative CDF %" stroke="#f59e0b" strokeWidth={2.5} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quantile & Percentile Risk Table */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
          STATISTICAL QUANTILES & RISK METRICS BREAKDOWN
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                <th className="py-2 px-3">Metric</th>
                <th className="py-2 px-3">Mean</th>
                <th className="py-2 px-3">StdDev</th>
                <th className="py-2 px-3">P5 (VaR 95%)</th>
                <th className="py-2 px-3">P25</th>
                <th className="py-2 px-3">P50 (Median)</th>
                <th className="py-2 px-3">P75</th>
                <th className="py-2 px-3">P95</th>
                <th className="py-2 px-3">CVaR 95%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
              <tr className="hover:bg-[#12121c]">
                <td className="py-2 px-3 font-sans font-bold text-zinc-100">Profit / Flight</td>
                <td className="py-2 px-3 text-emerald-400">${Math.round(profitStats.mean).toLocaleString()}</td>
                <td className="py-2 px-3 text-zinc-400">±${Math.round(profitStats.stdDev).toLocaleString()}</td>
                <td className="py-2 px-3 text-amber-400">${Math.round(profitStats.p5).toLocaleString()}</td>
                <td className="py-2 px-3">${Math.round(profitStats.p25).toLocaleString()}</td>
                <td className="py-2 px-3 font-bold text-sky-400">${Math.round(profitStats.median).toLocaleString()}</td>
                <td className="py-2 px-3">${Math.round(profitStats.p75).toLocaleString()}</td>
                <td className="py-2 px-3 text-emerald-400">${Math.round(profitStats.p95).toLocaleString()}</td>
                <td className="py-2 px-3 font-bold text-rose-400">${Math.round(profitStats.cvar95).toLocaleString()}</td>
              </tr>
              <tr className="hover:bg-[#12121c]">
                <td className="py-2 px-3 font-sans font-bold text-zinc-100">15-Yr Fleet NPV</td>
                <td className="py-2 px-3 text-emerald-400">${Math.round(npvStats.mean).toLocaleString()}M</td>
                <td className="py-2 px-3 text-zinc-400">±${Math.round(npvStats.stdDev).toLocaleString()}M</td>
                <td className="py-2 px-3 text-amber-400">${Math.round(npvStats.p5).toLocaleString()}M</td>
                <td className="py-2 px-3">${Math.round(npvStats.p25).toLocaleString()}M</td>
                <td className="py-2 px-3 font-bold text-sky-400">${Math.round(npvStats.median).toLocaleString()}M</td>
                <td className="py-2 px-3">${Math.round(npvStats.p75).toLocaleString()}M</td>
                <td className="py-2 px-3 text-emerald-400">${Math.round(npvStats.p95).toLocaleString()}M</td>
                <td className="py-2 px-3 font-bold text-rose-400">${Math.round(npvStats.cvar95).toLocaleString()}M</td>
              </tr>
              <tr className="hover:bg-[#12121c]">
                <td className="py-2 px-3 font-sans font-bold text-zinc-100">Unit CASM ($/ASK)</td>
                <td className="py-2 px-3 text-sky-400">${monteCarloSummary.casmDistribution.mean.toFixed(3)}</td>
                <td className="py-2 px-3 text-zinc-400">±${monteCarloSummary.casmDistribution.stdDev.toFixed(3)}</td>
                <td className="py-2 px-3">${monteCarloSummary.casmDistribution.p5.toFixed(3)}</td>
                <td className="py-2 px-3">${monteCarloSummary.casmDistribution.p25.toFixed(3)}</td>
                <td className="py-2 px-3 font-bold text-zinc-100">${monteCarloSummary.casmDistribution.median.toFixed(3)}</td>
                <td className="py-2 px-3">${monteCarloSummary.casmDistribution.p75.toFixed(3)}</td>
                <td className="py-2 px-3 text-rose-400">${monteCarloSummary.casmDistribution.p95.toFixed(3)}</td>
                <td className="py-2 px-3 text-rose-400">${monteCarloSummary.casmDistribution.cvar95.toFixed(3)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
