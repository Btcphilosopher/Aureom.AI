import React, { useState } from 'react';
import { BookOpen, CheckCircle, HelpCircle, FileCheck, Layers, ChevronRight, ChevronDown } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { generateKeyQuestionAnswers, KeyQuestionAnswer } from '../../engine/keyQuestions';
import { FORMULA_TRACEABILITY_CATALOG, getConcordeValidationSuite, ValidationItem } from '../../engine/validation';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
} from 'recharts';

interface ResearchAnswersViewProps {
  config: AircraftConfiguration;
}

export const ResearchAnswersView: React.FC<ResearchAnswersViewProps> = ({ config }) => {
  const [activeSection, setActiveSection] = useState<'questions' | 'validation' | 'formulas'>('questions');
  const [selectedQuestionId, setSelectedQuestionId] = useState<number>(1);
  const [expandedFormulaId, setExpandedFormulaId] = useState<string | null>(null);

  const questions = generateKeyQuestionAnswers(config);
  const concordeValidation = getConcordeValidationSuite();
  const currentQ = questions.find((q) => q.id === selectedQuestionId) || questions[0];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1f1f2e]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-sky-600 to-indigo-600 rounded-xl text-white shadow-md shadow-sky-950/40">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-100 tracking-tight">
                RESEARCH LAB: 11 PIVOTAL QUESTIONS & VALIDATION SUITE
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Traceable Computational Engineering Answers, Concorde Flight Data Benchmark & Formula Catalog
              </p>
            </div>
          </div>

          {/* Section Selector */}
          <div className="flex gap-2">
            <button
              onClick={() => setActiveSection('questions')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSection === 'questions'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
                  : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
              }`}
            >
              11 Key Questions
            </button>
            <button
              onClick={() => setActiveSection('validation')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSection === 'validation'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
                  : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
              }`}
            >
              Concorde Benchmark
            </button>
            <button
              onClick={() => setActiveSection('formulas')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSection === 'formulas'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
                  : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
              }`}
            >
              Formula Traceability
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: 11 KEY QUESTIONS */}
      {activeSection === 'questions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: 11 Questions List (4 Cols) */}
          <div className="lg:col-span-4 bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-3 space-y-1 overflow-y-auto max-h-[620px]">
            {questions.map((q) => {
              const isSelected = q.id === selectedQuestionId;
              return (
                <button
                  key={q.id}
                  onClick={() => setSelectedQuestionId(q.id)}
                  className={`w-full text-left p-3 rounded-lg text-xs font-semibold transition-all flex items-start justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
                      : 'text-zinc-300 hover:bg-[#151522] hover:text-white'
                  }`}
                >
                  <span>{q.question}</span>
                  <ChevronRight className={`w-4 h-4 shrink-0 mt-0.5 ${isSelected ? 'text-white' : 'text-zinc-500'}`} />
                </button>
              );
            })}
          </div>

          {/* Right Column: Selected Question Deep Dive (8 Cols) */}
          <div className="lg:col-span-8 bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-6 shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-sky-400 text-xs font-bold uppercase tracking-wider mb-1">
                <HelpCircle className="w-4 h-4" />
                <span>Executive Engineering Decision Analysis</span>
              </div>
              <h3 className="text-base font-bold text-zinc-100 mb-2">{currentQ.question}</h3>

              <div className="p-3 bg-[#13131e] rounded-lg border border-[#222232] text-xs text-sky-200 font-semibold mb-4">
                <strong className="text-sky-300">Executive Summary: </strong>
                {currentQ.shortAnswer}
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                {currentQ.detailedAnalysis}
              </p>

              {/* Dynamic Question Visualizer Chart or Table */}
              <div className="bg-[#06060a] p-4 rounded-xl border border-[#1a1a28] mb-4">
                {currentQ.chartType === 'line' && (
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={currentQ.chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                        <XAxis dataKey={Object.keys(currentQ.chartData[0])[0]} stroke="#525266" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#525266" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }} />
                        <Legend wrapperStyle={{ fontSize: '10px' }} />
                        {Object.keys(currentQ.chartData[0]).slice(1, 3).map((k, idx) => (
                          <Line
                            key={k}
                            type="monotone"
                            dataKey={k}
                            stroke={idx === 0 ? '#38bdf8' : '#f59e0b'}
                            strokeWidth={2}
                          />
                        ))}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}

                {currentQ.chartType === 'bar' && (
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={currentQ.chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                        <XAxis dataKey={Object.keys(currentQ.chartData[0])[0]} stroke="#525266" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#525266" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }} />
                        <Legend wrapperStyle={{ fontSize: '10px' }} />
                        {Object.keys(currentQ.chartData[0]).slice(1, 3).map((k, idx) => (
                          <Bar
                            key={k}
                            dataKey={k}
                            fill={idx === 0 ? '#38bdf8' : '#10b981'}
                            radius={[3, 3, 0, 0]}
                          />
                        ))}
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}

                {currentQ.chartType === 'table' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse font-mono">
                      <thead>
                        <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                          {Object.keys(currentQ.chartData[0]).map((h) => (
                            <th key={h} className="py-2 px-3">{h.toUpperCase()}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
                        {currentQ.chartData.map((row, idx) => (
                          <tr key={idx} className="hover:bg-[#12121c]">
                            {Object.values(row).map((val: any, cidx) => (
                              <td key={cidx} className={`py-1.5 px-3 ${cidx === 0 ? 'font-sans font-bold text-zinc-100' : ''}`}>
                                {val}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            <div className="p-3 bg-emerald-950/20 border border-emerald-800/40 rounded-lg text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
              <div>
                <strong className="text-emerald-200">Key Takeaway: </strong> {currentQ.keyTakeaway}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: CONCORDE VALIDATION BENCHMARK */}
      {activeSection === 'validation' && (
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e]">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-200">
                AEROSPATIALE/BAC CONCORDE HISTORICAL FLIGHT MANUAL VALIDATION
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                Model predictions vs historical flight test data for Mach 2.04 transoceanic mission
              </p>
            </div>
            <span className="px-2.5 py-1 text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
              ✓ Validated to ±2.8% Mean Error
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                  <th className="py-2.5 px-3">Flight Parameter</th>
                  <th className="py-2.5 px-3">Concorde Historical Data</th>
                  <th className="py-2.5 px-3">Laboratory Prediction</th>
                  <th className="py-2.5 px-3">Variance</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 font-sans">Engineering Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
                {concordeValidation.map((item) => (
                  <tr key={item.parameter} className="hover:bg-[#12121c]">
                    <td className="py-2 px-3 font-sans font-bold text-zinc-100">{item.parameter}</td>
                    <td className="py-2 px-3 text-zinc-300">{item.concordeHistorical}</td>
                    <td className="py-2 px-3 font-bold text-sky-400">{item.modelPrediction}</td>
                    <td className="py-2 px-3 font-bold text-emerald-400">{item.errorPercent}</td>
                    <td className="py-2 px-3 font-sans">
                      <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                        {item.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans text-zinc-400">{item.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 3: FORMULA & MATHEMATICAL TRACEABILITY CATALOG */}
      {activeSection === 'formulas' && (
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm space-y-4">
          <div className="pb-3 border-b border-[#1f1f2e]">
            <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-200">
              MATHEMATICAL EQUATIONS & AEROSPACE LITERATURE TRACEABILITY
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Governing differential equations, aerodynamic correlations, and unit dimensional analysis
            </p>
          </div>

          <div className="space-y-3">
            {FORMULA_TRACEABILITY_CATALOG.map((f) => {
              const isExpanded = expandedFormulaId === f.id;
              return (
                <div
                  key={f.id}
                  className="bg-[#13131e] border border-[#222232] rounded-xl p-4 transition-all"
                >
                  <div
                    onClick={() => setExpandedFormulaId(isExpanded ? null : f.id)}
                    className="flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <span className="px-2 py-0.5 bg-sky-500/10 text-sky-400 border border-sky-500/30 rounded text-[10px] font-bold">
                        {f.category}
                      </span>
                      <h4 className="text-xs font-bold text-zinc-100">{f.name}</h4>
                    </div>
                    {isExpanded ? <ChevronDown className="w-4 h-4 text-zinc-400" /> : <ChevronRight className="w-4 h-4 text-zinc-400" />}
                  </div>

                  <div className="mt-3 p-3 bg-[#06060a] rounded-lg border border-[#1a1a28] font-mono text-xs text-sky-300 overflow-x-auto">
                    {f.latexFormula}
                  </div>

                  {isExpanded && (
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-3 border-t border-[#1f1f2e] text-zinc-300">
                      <div>
                        <strong className="text-zinc-400">Description:</strong> {f.description}
                      </div>
                      <div>
                        <strong className="text-zinc-400">Assumptions:</strong> {f.assumptions}
                      </div>
                      <div>
                        <strong className="text-zinc-400">Inputs:</strong> {f.inputs.join(', ')}
                      </div>
                      <div>
                        <strong className="text-zinc-400">Source:</strong> <span className="text-sky-400">{f.sourceReference}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
