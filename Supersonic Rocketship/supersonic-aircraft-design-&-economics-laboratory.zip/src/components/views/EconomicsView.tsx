import React, { useState } from 'react';
import { DollarSign, TrendingUp, PieChart as PieIcon, BarChart2, ShieldCheck, CreditCard, Building } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { EconomicAssumptions, FleetFinancials, FlightEconomicsResult } from '../../types/economics';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

interface EconomicsViewProps {
  config: AircraftConfiguration;
  flightEconomics: FlightEconomicsResult;
  fleetEconomics: FleetFinancials;
  assumptions: EconomicAssumptions;
  onUpdateAssumptions: (newAssumptions: EconomicAssumptions) => void;
  fleetSize: number;
  onChangeFleetSize: (size: number) => void;
  unitSystem: 'SI' | 'Imperial';
}

export const EconomicsView: React.FC<EconomicsViewProps> = ({
  config,
  flightEconomics,
  fleetEconomics,
  assumptions,
  onUpdateAssumptions,
  fleetSize,
  onChangeFleetSize,
  unitSystem,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'flight' | 'fleet' | 'assumptions'>('flight');

  // Flight DOC Breakdown data
  const flightCostData = [
    { name: 'Aviation Fuel & SAF', value: Math.round(flightEconomics.totalFuelCostUsd), color: '#f59e0b' },
    { name: 'Carbon Offsets (ETS)', value: Math.round(flightEconomics.carbonEmissionCostUsd), color: '#10b981' },
    { name: 'Flight & Cabin Crew', value: Math.round(flightEconomics.flightCrewCostUsd + flightEconomics.cabinCrewCostUsd), color: '#38bdf8' },
    { name: 'Airframe & Engine Maint.', value: Math.round(flightEconomics.totalMaintenanceCostUsd), color: '#818cf8' },
    { name: 'Landing, ATC & Ground', value: Math.round(flightEconomics.landingFeesUsd + flightEconomics.navigationFeesUsd + flightEconomics.groundHandlingFeesUsd), color: '#c084fc' },
    { name: 'Catering & Passenger Svc', value: Math.round(flightEconomics.cateringCostUsd), color: '#fb7185' },
    { name: 'Depreciation & Capital', value: Math.round(flightEconomics.depreciationCostPerFlightUsd + flightEconomics.financingInterestPerFlightUsd + flightEconomics.hullInsurancePerFlightUsd), color: '#64748b' },
  ];

  // Revenue vs Cost comparison
  const comparisonData = [
    {
      category: 'Per-Flight Financials',
      Revenue: Math.round(flightEconomics.totalRevenuePerFlightUsd),
      OperatingCost: Math.round(flightEconomics.totalOperatingCostPerFlightUsd),
      OperatingProfit: Math.round(flightEconomics.operatingProfitPerFlightUsd),
    },
  ];

  // Cash Flow Trajectory for 15-Year Fleet DCF
  const cashFlowChartData = fleetEconomics.yearlyCashFlows.map((cf) => ({
    year: `Y${cf.year}`,
    freeCashFlow: Math.round(cf.freeCashFlow),
    cumulativeCashFlow: Math.round(cf.cumulativeCashFlow),
    revenue: Math.round(cf.revenue),
    ebitda: Math.round(cf.ebitda),
  }));

  return (
    <div className="space-y-6">
      {/* 4 Key Airline Profitability Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Operating Margin */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">OPERATING MARGIN</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className={`text-2xl font-black mt-2 ${flightEconomics.operatingMarginPercent >= 15 ? 'text-emerald-400' : flightEconomics.operatingMarginPercent > 0 ? 'text-sky-400' : 'text-rose-400'}`}>
            {flightEconomics.operatingMarginPercent.toFixed(1)}%
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>Profit/Flight: ${Math.round(flightEconomics.operatingProfitPerFlightUsd).toLocaleString()}</span>
            <span>Rev: ${Math.round(flightEconomics.totalRevenuePerFlightUsd).toLocaleString()}</span>
          </div>
        </div>

        {/* CASM / CASK */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">UNIT CASM (COST/SEAT-KM)</span>
            <DollarSign className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 mt-2">
            ${flightEconomics.costPerSeatKmUsd.toFixed(4)}{' '}
            <span className="text-xs font-normal text-zinc-400">/ ASK</span>
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>RASM: ${flightEconomics.revenuePerSeatKmUsd.toFixed(4)}</span>
            <span>Cost/Pax: ${Math.round(flightEconomics.costPerPassengerUsd).toLocaleString()}</span>
          </div>
        </div>

        {/* Break-Even Load Factor */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">BREAK-EVEN LOAD FACTOR</span>
            <CreditCard className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-2">
            {(flightEconomics.breakEvenLoadFactor * 100).toFixed(1)}%
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>Assumed Load: {(assumptions.loadFactor * 100).toFixed(0)}%</span>
            <span>BE Fare: ${Math.round(flightEconomics.breakEvenAverageFareUsd).toLocaleString()}</span>
          </div>
        </div>

        {/* 15-Year Fleet NPV */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">15-YR FLEET NPV ({fleetSize} JETS)</span>
            <Building className="w-4 h-4 text-indigo-400" />
          </div>
          <div className={`text-2xl font-black mt-2 ${fleetEconomics.npv15YearsUsdMillion >= 0 ? 'text-indigo-400' : 'text-rose-400'}`}>
            ${Math.round(fleetEconomics.npv15YearsUsdMillion).toLocaleString()} M
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>IRR: {fleetEconomics.irrPercent.toFixed(1)}%</span>
            <span>Payback: {fleetEconomics.paybackPeriodYears} Yrs</span>
          </div>
        </div>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex gap-2 border-b border-[#1f1f2e] pb-2">
        <button
          onClick={() => setActiveSubTab('flight')}
          className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeSubTab === 'flight'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
              : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
          }`}
        >
          Flight Operating Costs (DOC & TOC)
        </button>
        <button
          onClick={() => setActiveSubTab('fleet')}
          className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeSubTab === 'fleet'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
              : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
          }`}
        >
          15-Year Fleet DCF & Investment Analysis
        </button>
        <button
          onClick={() => setActiveSubTab('assumptions')}
          className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeSubTab === 'assumptions'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-950/40'
              : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
          }`}
        >
          Economic Assumptions & Fares
        </button>
      </div>

      {/* Sub-Tab 1: Flight DOC Breakdown */}
      {activeSubTab === 'flight' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Flight Cost Pie */}
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-2">
              COST BREAKDOWN PER FLIGHT (TOC)
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={flightCostData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {flightCostData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Cost']}
                    contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="text-center text-xs text-zinc-400 mt-2">
              Total Operating Cost: <strong className="text-zinc-100">${Math.round(flightEconomics.totalOperatingCostPerFlightUsd).toLocaleString()}</strong> / flight
            </div>
          </div>

          {/* Detailed Flight Cost Itemized Table */}
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm flex flex-col justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-2">
              PER-FLIGHT FINANCIAL STATEMENT
            </h3>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-300">
                <span>Passenger Ticket Revenue (First + Business)</span>
                <span className="font-semibold text-emerald-400">+${Math.round(flightEconomics.passengerRevenueUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-300">
                <span>Cargo & Ancillary Revenue</span>
                <span className="font-semibold text-emerald-400">+${Math.round(flightEconomics.cargoRevenueUsd + flightEconomics.ancillaryRevenueUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 font-bold bg-[#141420] px-2 rounded text-zinc-100">
                <span>TOTAL FLIGHT REVENUE</span>
                <span className="text-emerald-400">${Math.round(flightEconomics.totalRevenuePerFlightUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-400">
                <span>Aviation Fuel / SAF Consumption</span>
                <span className="text-rose-400">-${Math.round(flightEconomics.totalFuelCostUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-400">
                <span>Flight Crew & Cabin Crew</span>
                <span className="text-rose-400">-${Math.round(flightEconomics.flightCrewCostUsd + flightEconomics.cabinCrewCostUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-400">
                <span>Airframe & Engine Direct Maintenance</span>
                <span className="text-rose-400">-${Math.round(flightEconomics.totalMaintenanceCostUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-400">
                <span>Airport Landing, ATC Nav & Ground Handling</span>
                <span className="text-rose-400">-${Math.round(flightEconomics.landingFeesUsd + flightEconomics.navigationFeesUsd + flightEconomics.groundHandlingFeesUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f1f2e] text-zinc-400">
                <span>Capital Depreciation & Debt Financing</span>
                <span className="text-rose-400">-${Math.round(flightEconomics.depreciationCostPerFlightUsd + flightEconomics.financingInterestPerFlightUsd + flightEconomics.hullInsurancePerFlightUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1.5 font-black bg-sky-950/40 border border-sky-800/40 px-2.5 rounded text-sm text-zinc-100">
                <span>NET OPERATING PROFIT</span>
                <span className={flightEconomics.operatingProfitPerFlightUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  ${Math.round(flightEconomics.operatingProfitPerFlightUsd).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: 15-Year Fleet DCF */}
      {activeSubTab === 'fleet' && (
        <div className="space-y-6">
          {/* Fleet Controls */}
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-zinc-300 uppercase">Fleet Size Selection:</span>
              <div className="flex gap-1.5">
                {[10, 25, 50, 100, 250].map((sz) => (
                  <button
                    key={sz}
                    onClick={() => onChangeFleetSize(sz)}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                      fleetSize === sz
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                        : 'bg-[#151522] text-zinc-300 hover:bg-[#1e1e2e] border border-[#262638]'
                    }`}
                  >
                    {sz} Aircraft
                  </button>
                ))}
              </div>
            </div>
            <div className="text-xs text-zinc-400">
              Fleet CAPEX: <strong className="text-zinc-100">${Math.round(fleetEconomics.fleetCapexUsdMillion)}M</strong> | Annual EBITDA: <strong className="text-emerald-400">${Math.round(fleetEconomics.annualEbitdaUsdMillion)}M</strong>
            </div>
          </div>

          {/* Cumulative Cash Flow Trajectory Chart */}
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
              15-YEAR CUMULATIVE CASH FLOW WATERFALL & DCF PROJECTION ($M)
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={cashFlowChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                  <XAxis dataKey="year" stroke="#525266" />
                  <YAxis stroke="#525266" tickFormatter={(v) => `$${v}M`} />
                  <Tooltip
                    formatter={(val: any) => [`$${Number(val).toLocaleString()} M`, 'Cash Flow']}
                    contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line type="monotone" dataKey="cumulativeCashFlow" name="Cumulative Cash Flow ($M)" stroke="#818cf8" strokeWidth={3} dot={{ r: 3 }} />
                  <Line type="monotone" dataKey="freeCashFlow" name="Annual Free Cash Flow ($M)" stroke="#34d399" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Year-by-Year Financial Statement Table */}
          <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
              15-YEAR FLEET CASH FLOW STATEMENT ($ MILLION)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse font-mono">
                <thead>
                  <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                    <th className="py-2 px-3">Year</th>
                    <th className="py-2 px-3">CAPEX</th>
                    <th className="py-2 px-3">Revenue</th>
                    <th className="py-2 px-3">OPEX</th>
                    <th className="py-2 px-3">EBITDA</th>
                    <th className="py-2 px-3">Deprec.</th>
                    <th className="py-2 px-3">Tax</th>
                    <th className="py-2 px-3">Free Cash Flow</th>
                    <th className="py-2 px-3">Cumulative</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
                  {fleetEconomics.yearlyCashFlows.map((row) => (
                    <tr key={row.year} className="hover:bg-[#12121c]">
                      <td className="py-1.5 px-3 font-sans font-bold text-zinc-100">Year {row.year}</td>
                      <td className="py-1.5 px-3 text-rose-400">${Math.round(row.capex)}M</td>
                      <td className="py-1.5 px-3 text-emerald-400">${Math.round(row.revenue)}M</td>
                      <td className="py-1.5 px-3 text-zinc-400">${Math.round(row.opex)}M</td>
                      <td className="py-1.5 px-3 font-semibold text-sky-400">${Math.round(row.ebitda)}M</td>
                      <td className="py-1.5 px-3 text-zinc-500">${Math.round(row.depreciation)}M</td>
                      <td className="py-1.5 px-3 text-zinc-500">${Math.round(row.tax)}M</td>
                      <td className={`py-1.5 px-3 font-bold ${row.freeCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        ${Math.round(row.freeCashFlow)}M
                      </td>
                      <td className={`py-1.5 px-3 font-bold ${row.cumulativeCashFlow >= 0 ? 'text-indigo-400' : 'text-amber-400'}`}>
                        ${Math.round(row.cumulativeCashFlow)}M
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Economic Assumptions Tuning */}
      {activeSubTab === 'assumptions' && (
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-4">
            AIRLINE REVENUE, FARE STRUCTURE & OPERATING COST ASSUMPTIONS
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* SAF Price */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">SAF Price ($/gallon)</label>
              <input
                type="number"
                step="0.1"
                value={assumptions.safPriceUsdGal}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, safPriceUsdGal: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>

            {/* Jet-A Price */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">Jet-A Fuel Price ($/gallon)</label>
              <input
                type="number"
                step="0.1"
                value={assumptions.jetAFuelPriceUsdGal}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, jetAFuelPriceUsdGal: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>

            {/* Carbon Offset Price */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">Carbon Price ($/tonne CO2)</label>
              <input
                type="number"
                step="5"
                value={assumptions.carbonPriceUsdPerTonne}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, carbonPriceUsdPerTonne: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>

            {/* Business Class Fare */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">Business Class Fare ($)</label>
              <input
                type="number"
                step="100"
                value={assumptions.fareBusinessClassUsd}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, fareBusinessClassUsd: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>

            {/* First Class Fare */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">First Class Fare ($)</label>
              <input
                type="number"
                step="100"
                value={assumptions.fareFirstClassUsd}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, fareFirstClassUsd: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>

            {/* Load Factor */}
            <div className="space-y-1.5 p-3 bg-[#13131e] rounded-lg border border-[#222232]">
              <label className="font-semibold text-zinc-300">Passenger Load Factor (0.0 - 1.0)</label>
              <input
                type="number"
                step="0.02"
                min="0.3"
                max="1.0"
                value={assumptions.loadFactor}
                onChange={(e) => onUpdateAssumptions({ ...assumptions, loadFactor: Number(e.target.value) })}
                className="w-full bg-[#0a0a10] border border-[#262638] rounded px-2.5 py-1 text-zinc-100 font-mono"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
