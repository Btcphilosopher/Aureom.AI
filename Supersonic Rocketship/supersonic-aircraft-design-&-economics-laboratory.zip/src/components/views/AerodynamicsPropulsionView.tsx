import React from 'react';
import { Wind, Flame, ShieldAlert, Volume2, Gauge, CheckCircle2, AlertTriangle } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { calculateAerodynamics } from '../../engine/aerodynamics';
import { calculatePropulsion } from '../../engine/propulsion';
import { calculateThermalState } from '../../engine/thermal';
import { calculateSonicBoom } from '../../engine/sonicBoom';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from 'recharts';

interface AerodynamicsPropulsionViewProps {
  config: AircraftConfiguration;
  unitSystem: 'SI' | 'Imperial';
}

export const AerodynamicsPropulsionView: React.FC<AerodynamicsPropulsionViewProps> = ({
  config,
  unitSystem,
}) => {
  const isSI = unitSystem === 'SI';
  const mach = config.machCruise.value;
  const altitudeM = config.cruiseAltitude.value;
  const mtowKg = config.mtow.value;

  // Single-point evaluations
  const currentAero = calculateAerodynamics(config, mach, altitudeM, mtowKg, 'Supersonic');
  const currentProp = calculatePropulsion(config, mach, altitudeM, 0.95);
  const currentThermal = calculateThermalState(config, mach, altitudeM);
  const currentBoom = calculateSonicBoom(config, mach, altitudeM, mtowKg);

  // Sweep Mach from 0.4 to 2.4 for Drag Polars & L/D
  const machSweepData = [];
  for (let m = 0.4; m <= 2.4; m += 0.1) {
    const roundedM = Math.round(m * 10) / 10;
    const regime = roundedM < 0.85 ? 'Climb' : roundedM <= 1.2 ? 'Transonic' : 'Supersonic';
    const aero = calculateAerodynamics(config, roundedM, altitudeM, mtowKg * 0.85, regime);
    const prop = calculatePropulsion(config, roundedM, altitudeM, 0.95);
    const therm = calculateThermalState(config, roundedM, altitudeM);
    const boom = calculateSonicBoom(config, roundedM, altitudeM, mtowKg);

    machSweepData.push({
      mach: roundedM,
      cdParasite: Math.round(aero.cdParasite * 10000) / 10000,
      cdInduced: Math.round(aero.cdInduced * 10000) / 10000,
      cdWave: Math.round(aero.cdWave * 10000) / 10000,
      cdTotal: Math.round(aero.cdTotal * 10000) / 10000,
      liftToDrag: Math.round(aero.liftToDrag * 10) / 10,
      tsfc: Math.round(prop.tsfcKgNH * 1000) / 1000,
      inletRecoveryPct: Math.round(prop.inletPressureRecovery * 1000) / 10,
      skinTempC: Math.round(therm.skinTempFuselageMidC),
      boomPsf: roundedM > 1.0 ? Math.round(boom.overpressurePsf * 100) / 100 : 0,
    });
  }

  const boomOverpressurePa = currentBoom.overpressurePsf * 47.8803;

  return (
    <div className="space-y-6">
      {/* 4 Multi-Discipline Physics KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Aero KPI */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">CRUISE LIFT-TO-DRAG (L/D)</span>
            <Wind className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 mt-2">
            {currentAero.liftToDrag.toFixed(2)}
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>Wave Drag Cd: {currentAero.cdWave.toFixed(4)}</span>
            <span>Total Cd: {currentAero.cdTotal.toFixed(4)}</span>
          </div>
        </div>

        {/* Propulsion KPI */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">CRUISE TSFC (FUEL FLOW)</span>
            <Gauge className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-2">
            {currentProp.tsfcKgNH.toFixed(4)}{' '}
            <span className="text-xs font-normal text-zinc-400">kg/(N·h)</span>
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>Inlet Recovery: {(currentProp.inletPressureRecovery * 100).toFixed(1)}%</span>
            <span>Thrust: {Math.round(currentProp.netThrustN / 1000)} kN</span>
          </div>
        </div>

        {/* Thermal KPI */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">SKIN EQUILIBRIUM TEMP</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 mt-2">
            {currentThermal.skinTempFuselageMidC.toFixed(1)}°C{' '}
            <span className="text-xs font-normal text-zinc-400">
              ({(currentThermal.skinTempFuselageMidC * 1.8 + 32).toFixed(1)}°F)
            </span>
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>Limit: {currentThermal.materialLimitC}°C</span>
            <span className={currentThermal.thermalMarginC > 15 ? 'text-emerald-400' : 'text-amber-400'}>
              Margin: +{currentThermal.thermalMarginC.toFixed(0)}°C
            </span>
          </div>
        </div>

        {/* Sonic Boom KPI */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">GROUND BOOM OVERPRESSURE</span>
            <Volume2 className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-black text-indigo-400 mt-2">
            {currentBoom.overpressurePsf.toFixed(2)}{' '}
            <span className="text-xs font-normal text-zinc-400">psf ({Math.round(boomOverpressurePa)} Pa)</span>
          </div>
          <div className="text-xs text-zinc-400 mt-1 flex justify-between">
            <span>PLdB: {currentBoom.perceivedLoudnessPLdB.toFixed(0)} dB</span>
            <span className={currentBoom.isOverlandAllowed ? 'text-emerald-400 font-bold' : 'text-rose-400'}>
              {currentBoom.isOverlandAllowed ? '✓ Overland Allowed' : '✗ Overland Ban'}
            </span>
          </div>
        </div>
      </div>

      {/* Row 1: Drag Breakdown Stacked Area & Lift-to-Drag Polar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Drag Breakdown across Mach */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              MULTI-REGIME DRAG BREAKDOWN (CD VS MACH)
            </h3>
            <span className="text-[11px] text-zinc-400">FL600 Cruise Altitude</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={machSweepData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="mach" stroke="#525266" tickFormatter={(v) => `M${v}`} />
                <YAxis stroke="#525266" domain={[0, 0.05]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Area type="monotone" dataKey="cdParasite" name="Parasite Drag (Cdp)" stackId="1" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.6} />
                <Area type="monotone" dataKey="cdInduced" name="Induced Drag (Cdi)" stackId="1" stroke="#818cf8" fill="#818cf8" fillOpacity={0.6} />
                <Area type="monotone" dataKey="cdWave" name="Supersonic Wave Drag (Cdw)" stackId="1" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.7} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            * Wave drag rises sharply beyond Mach 1.0 (transonic pinch), mitigated by Whitcomb area-ruling coke-bottling.
          </p>
        </div>

        {/* L/D & TSFC Curves */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
              LIFT-TO-DRAG EFFICIENCY (L/D) VS MACH
            </h3>
            <span className="text-[11px] text-sky-400 font-semibold">Current M{mach}: L/D = {currentAero.liftToDrag.toFixed(1)}</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={machSweepData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="mach" stroke="#525266" tickFormatter={(v) => `M${v}`} />
                <YAxis yAxisId="left" stroke="#38bdf8" domain={[4, 18]} />
                <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" domain={[0.06, 0.12]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line yAxisId="left" type="monotone" dataKey="liftToDrag" name="Lift-to-Drag (L/D)" stroke="#38bdf8" strokeWidth={2.5} dot={{ r: 2 }} />
                <Line yAxisId="right" type="monotone" dataKey="tsfc" name="Cruise TSFC kg/(N*h)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            * Subsonic L/D reaches ~15.2; at M1.7 supercruise, optimized swept delta maintains L/D = 8.8.
          </p>
        </div>
      </div>

      {/* Row 2: Aero-Thermal Heating & Sonic Boom Carpet */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Thermal Limits Chart */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                AERODYNAMIC SKIN HEATING & MATERIAL LIMITS
              </h3>
            </div>
            <span className="text-[11px] text-zinc-400">Tg Limit: {currentThermal.materialLimitC}°C</span>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={machSweepData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="mach" stroke="#525266" tickFormatter={(v) => `M${v}`} />
                <YAxis stroke="#525266" domain={[-60, 200]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="skinTempC" name="Fuselage Skin Temp (°C)" stroke="#f43f5e" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-3 p-2.5 bg-[#13131e] rounded-lg border border-[#222232] flex items-start gap-2.5 text-xs">
            {currentThermal.isThermalExceeded ? (
              <>
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="text-rose-300">
                  <strong>THERMAL LIMIT EXCEEDED:</strong> Skin equilibrium temperature ({currentThermal.skinTempFuselageMidC.toFixed(0)}°C) exceeds epoxy resin composite limits. Transition to Titanium / BMI required.
                </div>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-zinc-300">
                  <strong>AERO-THERMAL SAFE:</strong> At Mach {mach.toFixed(2)}, fuselage skin reaches {currentThermal.skinTempFuselageMidC.toFixed(0)}°C, maintaining a comfortable +{currentThermal.thermalMarginC.toFixed(0)}°C safety margin below {currentThermal.materialLimitC}°C CFRP limit.
                </div>
              </>
            )}
          </div>
        </div>

        {/* Sonic Boom Signature */}
        <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-3">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-indigo-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                WHITHAM GROUND SONIC BOOM OVERPRESSURE
              </h3>
            </div>
            <span className="text-[11px] text-indigo-400">FAA NPRM Limit: 0.11 psf</span>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={machSweepData.filter((d) => d.mach >= 1.0)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
                <XAxis dataKey="mach" stroke="#525266" tickFormatter={(v) => `M${v}`} />
                <YAxis stroke="#525266" domain={[0, 2.5]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#07070a', borderColor: '#222232', borderRadius: '8px', fontSize: '11px', color: '#f4f4f5' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="boomPsf" name="Overpressure Δp (psf)" stroke="#818cf8" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-3 p-2.5 bg-[#13131e] rounded-lg border border-[#222232] flex items-start gap-2.5 text-xs">
            <ShieldAlert className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <div className="text-zinc-300">
              Ground Footprint Width: <strong>{currentBoom.groundFootprintWidthNm.toFixed(0)} nm</strong> | Perceived Loudness: <strong>{currentBoom.perceivedLoudnessPLdB.toFixed(0)} PLdB</strong>. {config.isLowBoomShaped.value ? 'Low-boom area distribution active.' : 'Conventional N-wave signature.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

