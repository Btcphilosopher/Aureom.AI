import React, { useState } from 'react';
import { Layers, CheckCircle2, AlertTriangle, XCircle, Sparkles, Filter, Eye, ArrowUpRight } from 'lucide-react';
import { AircraftConfiguration } from '../../types/aircraft';
import { ConfigurationFeasibility, DesignPoint } from '../../types/designSpace';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';

interface DesignSpaceViewProps {
  designPoints: DesignPoint[];
  currentConfig: AircraftConfiguration;
  onSelectDesignPoint: (dp: DesignPoint) => void;
}

export const DesignSpaceView: React.FC<DesignSpaceViewProps> = ({
  designPoints,
  currentConfig,
  onSelectDesignPoint,
}) => {
  const [filterClassification, setFilterClassification] = useState<string>('all');
  const [filterCycle, setFilterCycle] = useState<string>('all');
  const [onlyPareto, setOnlyPareto] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPoint, setSelectedPoint] = useState<DesignPoint | null>(null);

  const getTierColor = (classification: ConfigurationFeasibility) => {
    switch (classification) {
      case 'Economically Attractive':
        return '#10b981'; // emerald
      case 'Technically Feasible':
        return '#0284c7'; // blue
      case 'Technically Marginal':
        return '#f59e0b'; // amber
      case 'Dominated Design':
        return '#64748b'; // slate
      case 'Technological Breakthrough Required':
        return '#a855f7'; // purple
      case 'Unacceptable Risk':
        return '#ef4444'; // red
    }
  };

  const filteredPoints = designPoints.filter((p) => {
    if (filterClassification !== 'all' && p.classification !== filterClassification) return false;
    if (filterCycle !== 'all' && p.engineCycle !== filterCycle) return false;
    if (onlyPareto && !p.isParetoOptimal) return false;
    if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const scatterData = filteredPoints.map((p) => ({
    id: p.id,
    name: p.name,
    mach: p.mach,
    casm: p.casmUsdPerSeatKm,
    fuelPerPax: p.fuelPerPaxKg,
    profit: p.operatingProfitFlightUsd,
    margin: p.operatingMarginPercent,
    npv: p.npvUsdMillion,
    passengers: p.passengers,
    range: p.designRangeNm,
    classification: p.classification,
    isPareto: p.isParetoOptimal,
    color: getTierColor(p.classification),
    raw: p,
  }));

  const classificationCounts = {
    attractive: designPoints.filter((p) => p.classification === 'Economically Attractive').length,
    feasible: designPoints.filter((p) => p.classification === 'Technically Feasible').length,
    marginal: designPoints.filter((p) => p.classification === 'Technically Marginal').length,
    dominated: designPoints.filter((p) => p.classification === 'Dominated Design').length,
    breakthrough: designPoints.filter((p) => p.classification === 'Technological Breakthrough Required').length,
    risk: designPoints.filter((p) => p.classification === 'Unacceptable Risk').length,
    pareto: designPoints.filter((p) => p.isParetoOptimal).length,
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Overview */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1f1f2e]">
          <div>
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-sky-400" />
              <h2 className="text-base font-bold text-zinc-100 tracking-tight">
                HIGH-DENSITY DESIGN SPACE EXPLORATION & PARETO FRONTIER
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Multi-Objective Trades: Speed (Mach) vs CASM vs Fuel Burn vs Aero-Thermal Feasibility
            </p>
          </div>

          {/* Classification Stats Badges */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              {classificationCounts.attractive} Economically Attractive
            </span>
            <span className="px-2.5 py-1 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold">
              {classificationCounts.feasible} Feasible
            </span>
            <span className="px-2.5 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-semibold">
              {classificationCounts.pareto} Pareto Optimal
            </span>
            <span className="px-2.5 py-1 rounded bg-[#13131e] text-zinc-400 border border-[#222232]">
              Total {designPoints.length} Evaluated
            </span>
          </div>
        </div>

        {/* Filter Controls Ribbon */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-[#13131e] px-3 py-1.5 rounded-lg border border-[#222232]">
              <Filter className="w-3.5 h-3.5 text-zinc-400" />
              <span className="text-zinc-400">Classification:</span>
              <select
                value={filterClassification}
                onChange={(e) => setFilterClassification(e.target.value)}
                aria-label="Filter by Classification"
                className="bg-transparent text-zinc-100 font-bold outline-none cursor-pointer"
              >
                <option value="all" className="bg-[#0e0e14]">All Tiers</option>
                <option value="Economically Attractive" className="bg-[#0e0e14]">Economically Attractive</option>
                <option value="Technically Feasible" className="bg-[#0e0e14]">Technically Feasible</option>
                <option value="Technically Marginal" className="bg-[#0e0e14]">Technically Marginal</option>
                <option value="Dominated Design" className="bg-[#0e0e14]">Dominated Design</option>
                <option value="Technological Breakthrough Required" className="bg-[#0e0e14]">Breakthrough Required</option>
                <option value="Unacceptable Risk" className="bg-[#0e0e14]">Unacceptable Risk</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-[#13131e] px-3 py-1.5 rounded-lg border border-[#222232]">
              <span className="text-zinc-400">Cycle:</span>
              <select
                value={filterCycle}
                onChange={(e) => setFilterCycle(e.target.value)}
                aria-label="Filter by Engine Cycle"
                className="bg-transparent text-zinc-100 font-bold outline-none cursor-pointer"
              >
                <option value="all" className="bg-[#0e0e14]">All Cycles</option>
                <option value="medium_bypass_turbofan" className="bg-[#0e0e14]">Medium Turbofan</option>
                <option value="variable_cycle" className="bg-[#0e0e14]">Variable-Cycle (VCE)</option>
                <option value="turbojet" className="bg-[#0e0e14]">Dry Turbojet</option>
              </select>
            </div>

            <button
              onClick={() => setOnlyPareto(!onlyPareto)}
              className={`px-3 py-1.5 font-bold rounded-lg transition-all cursor-pointer ${
                onlyPareto
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-950/40'
                  : 'bg-[#151522] text-zinc-300 hover:bg-[#1a1a2c] border border-[#262638]'
              }`}
            >
              ★ Pareto Frontier Only
            </button>
          </div>

          <input
            type="text"
            placeholder="Search candidate designs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-[#13131e] border border-[#222232] rounded-lg px-3 py-1.5 text-zinc-100 placeholder-zinc-500 w-56 outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Main Scatter Plot: Mach vs Unit CASM ($/seat-km) */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-[#1f1f2e] mb-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
            DESIGN SPACE MAP: CRUISE MACH VS UNIT CASM ($/SEAT-KM)
          </h3>
          <span className="text-[11px] text-zinc-400">
            Showing {filteredPoints.length} candidates
          </span>
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#161624" />
              <XAxis
                dataKey="mach"
                name="Cruise Mach"
                stroke="#525266"
                domain={[1.4, 2.3]}
                tickFormatter={(v) => `M${v}`}
                label={{ value: 'Cruise Mach Number (Speed)', position: 'insideBottom', offset: -10, fill: '#64748b', fontSize: 11 }}
              />
              <YAxis
                dataKey="casm"
                name="CASM"
                stroke="#525266"
                domain={[0.08, 0.28]}
                tickFormatter={(v) => `$${v}`}
                label={{ value: 'CASM ($/Seat-km)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 11 }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-[#07070a] border border-[#222232] p-3 rounded-lg text-xs shadow-xl space-y-1">
                        <div className="font-bold text-zinc-100">{data.name}</div>
                        <div className="text-sky-400">Mach {data.mach} | {data.passengers} Pax | {data.range} nm</div>
                        <div className="text-zinc-300">CASM: <strong className="text-white">${data.casm.toFixed(4)}</strong>/seat-km</div>
                        <div className="text-zinc-300">Profit/Flight: <strong className="text-emerald-400">${Math.round(data.profit).toLocaleString()}</strong></div>
                        <div className="text-zinc-300">15-Yr NPV: <strong className="text-indigo-400">${data.npv}M</strong></div>
                        <div className="text-xs font-semibold" style={{ color: data.color }}>
                          {data.classification} {data.isPareto ? '★ Pareto Optimal' : ''}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Design Points" data={scatterData} onClick={(entry) => setSelectedPoint(entry.raw)}>
                {scatterData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    stroke={entry.isPareto ? '#f8fafc' : undefined}
                    strokeWidth={entry.isPareto ? 1.5 : 0}
                  />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-3 pt-3 border-t border-[#1f1f2e] text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span className="text-zinc-300">Economically Attractive (M1.6-1.8)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-sky-500" />
            <span className="text-zinc-300">Technically Feasible</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-purple-500" />
            <span className="text-zinc-300">Breakthrough Required (M2.1+ VCE)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span className="text-zinc-300">Technically Marginal</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-zinc-500" />
            <span className="text-zinc-300">Dominated</span>
          </div>
        </div>
      </div>

      {/* Candidate Design Points Table */}
      <div className="bg-[#0e0e14] border border-[#1e1e2c] rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200 mb-3">
          CANDIDATE CONFIGURATIONS DATABASE ({filteredPoints.length} RECORDS)
        </h3>
        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead className="sticky top-0 bg-[#07070a] backdrop-blur-sm z-10">
              <tr className="border-b border-[#1f1f2e] text-zinc-400 uppercase text-[10px] tracking-wider font-sans">
                <th className="py-2.5 px-3">ID</th>
                <th className="py-2.5 px-3">Configuration Name</th>
                <th className="py-2.5 px-3">Mach</th>
                <th className="py-2.5 px-3">Pax</th>
                <th className="py-2.5 px-3">Range</th>
                <th className="py-2.5 px-3">CASM</th>
                <th className="py-2.5 px-3">Profit/Flt</th>
                <th className="py-2.5 px-3">Margin</th>
                <th className="py-2.5 px-3">15-Yr NPV</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181826] text-zinc-300 text-[11px]">
              {filteredPoints.slice(0, 50).map((dp) => (
                <tr key={dp.id} className="hover:bg-[#12121c] transition-colors">
                  <td className="py-2 px-3 font-semibold text-zinc-400">{dp.id}</td>
                  <td className="py-2 px-3 font-sans font-medium text-zinc-100 flex items-center gap-1.5">
                    {dp.name}
                    {dp.isParetoOptimal && <span className="text-[10px] text-purple-400 font-bold">★ Pareto</span>}
                  </td>
                  <td className="py-2 px-3 text-sky-400 font-bold">M{dp.mach.toFixed(1)}</td>
                  <td className="py-2 px-3">{dp.passengers}</td>
                  <td className="py-2 px-3">{dp.designRangeNm} nm</td>
                  <td className="py-2 px-3 font-semibold">${dp.casmUsdPerSeatKm.toFixed(4)}</td>
                  <td className={`py-2 px-3 font-bold ${dp.operatingProfitFlightUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${Math.round(dp.operatingProfitFlightUsd).toLocaleString()}
                  </td>
                  <td className="py-2 px-3">{dp.operatingMarginPercent.toFixed(1)}%</td>
                  <td className="py-2 px-3 font-bold text-indigo-400">${dp.npvUsdMillion}M</td>
                  <td className="py-2 px-3 font-sans">
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-bold"
                      style={{
                        backgroundColor: `${getTierColor(dp.classification)}20`,
                        color: getTierColor(dp.classification),
                        border: `1px solid ${getTierColor(dp.classification)}40`,
                      }}
                    >
                      {dp.classification}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-right font-sans">
                    <button
                      onClick={() => onSelectDesignPoint(dp)}
                      className="px-2.5 py-1 text-[10px] font-bold bg-sky-600 hover:bg-sky-500 text-white rounded transition-colors cursor-pointer"
                    >
                      Load Design
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
