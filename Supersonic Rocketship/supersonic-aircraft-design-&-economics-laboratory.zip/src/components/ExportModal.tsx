import React, { useState } from 'react';
import { X, Copy, Check, Download, Code, FileText, Database, ShieldCheck } from 'lucide-react';
import { AircraftConfiguration } from '../types/aircraft';
import { DesignPoint } from '../types/designSpace';
import { generateDesignSpaceCsv, generateRScript, generateRustCode } from '../engine/exportUtils';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AircraftConfiguration;
  designPoints: DesignPoint[];
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  config,
  designPoints,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'rust' | 'r' | 'json' | 'csv'>('rust');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const rustCode = generateRustCode(config);
  const rScript = generateRScript(config);
  const jsonConfig = JSON.stringify(config, null, 2);
  const csvData = generateDesignSpaceCsv(designPoints);

  const getCurrentContent = () => {
    switch (activeSubTab) {
      case 'rust':
        return rustCode;
      case 'r':
        return rScript;
      case 'json':
        return jsonConfig;
      case 'csv':
        return csvData;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCurrentContent());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    let filename = 'export.txt';
    let mimeType = 'text/plain';

    if (activeSubTab === 'rust') {
      filename = `${config.id}_physics_engine.rs`;
      mimeType = 'text/rust';
    } else if (activeSubTab === 'r') {
      filename = `${config.id}_economics_monte_carlo.R`;
      mimeType = 'text/x-r-source';
    } else if (activeSubTab === 'json') {
      filename = `${config.id}_config.json`;
      mimeType = 'application/json';
    } else if (activeSubTab === 'csv') {
      filename = `supersonic_design_space_${designPoints.length}_points.csv`;
      mimeType = 'text/csv';
    }

    const blob = new Blob([getCurrentContent()], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div id="export-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="bg-[#0d0d14] border border-[#222230] rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden text-zinc-100">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#1f1f2c] flex items-center justify-between bg-[#12121c]/80">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-500/10 text-sky-400 rounded-lg border border-sky-500/20">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-100">
                Standalone Computational Engine Exporter
              </h2>
              <p className="text-xs text-zinc-400">
                Deterministic Rust Physics Crate & R Statistical Economics Platform
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close export modal"
            className="p-1.5 text-zinc-400 hover:text-white hover:bg-[#1a1a26] rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-tabs */}
        <div className="px-6 pt-3 flex gap-2 border-b border-[#1f1f2c] bg-[#09090f]">
          <button
            onClick={() => setActiveSubTab('rust')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-all cursor-pointer ${
              activeSubTab === 'rust'
                ? 'bg-[#181824] text-sky-400 border-t border-x border-[#282838]'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-orange-400" />
            Rust Physics Engine (.rs)
          </button>
          <button
            onClick={() => setActiveSubTab('r')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-all cursor-pointer ${
              activeSubTab === 'r'
                ? 'bg-[#181824] text-sky-400 border-t border-x border-[#282838]'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-blue-400" />
            R Economics & Monte Carlo (.R)
          </button>
          <button
            onClick={() => setActiveSubTab('json')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-all cursor-pointer ${
              activeSubTab === 'json'
                ? 'bg-[#181824] text-sky-400 border-t border-x border-[#282838]'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            Configuration JSON
          </button>
          <button
            onClick={() => setActiveSubTab('csv')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-all cursor-pointer ${
              activeSubTab === 'csv'
                ? 'bg-[#181824] text-sky-400 border-t border-x border-[#282838]'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-purple-400" />
            Design Space Dataset (.csv)
          </button>
        </div>

        {/* Code View Area */}
        <div className="flex-1 p-4 bg-[#050508] overflow-auto font-mono text-xs text-zinc-300 relative">
          <pre className="whitespace-pre">{getCurrentContent()}</pre>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3 border-t border-[#1f1f2c] bg-[#0c0c14] flex items-center justify-between">
          <div className="text-xs text-zinc-400">
            {activeSubTab === 'rust' && 'Compiles with rustc --crate-type bin or as a Cargo library.'}
            {activeSubTab === 'r' && 'Runs with standard Rscript or inside RStudio.'}
            {activeSubTab === 'json' && 'Complete serializable configuration schema.'}
            {activeSubTab === 'csv' && `Contains ${designPoints.length} evaluated candidate aircraft configurations.`}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-[#161622] hover:bg-[#202030] text-zinc-200 border border-[#28283a] rounded-lg transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-lg transition-colors shadow-md shadow-sky-950/40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
