import React from 'react';
import {
  Plane,
  Sliders,
  Wind,
  Gauge,
  DollarSign,
  BarChart3,
  Layers,
  Crosshair,
  BookOpen,
  Code2,
  FileSpreadsheet,
  Globe,
  Settings2,
} from 'lucide-react';
import { AircraftConfiguration } from '../types/aircraft';
import { PRESET_SCENARIOS } from '../engine/scenarioEngine';
import { PRESET_ROUTES } from '../engine/mission';

export type ActiveTab =
  | 'geometry'
  | 'aerodynamics'
  | 'mission'
  | 'economics'
  | 'monteCarlo'
  | 'designSpace'
  | 'decision'
  | 'research';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  aircraftList: AircraftConfiguration[];
  selectedAircraftId: string;
  onSelectAircraft: (id: string) => void;
  selectedRouteIndex: number;
  onSelectRoute: (idx: number) => void;
  selectedScenarioId: string;
  onSelectScenario: (id: string) => void;
  unitSystem: 'SI' | 'Imperial';
  onToggleUnitSystem: () => void;
  onOpenExportModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  aircraftList,
  selectedAircraftId,
  onSelectAircraft,
  selectedRouteIndex,
  onSelectRoute,
  selectedScenarioId,
  onSelectScenario,
  unitSystem,
  onToggleUnitSystem,
  onOpenExportModal,
}) => {
  const tabs = [
    { id: 'geometry', label: '1. Sizing & Geometry', icon: Sliders },
    { id: 'aerodynamics', label: '2. Aero-Thermal & Cycle', icon: Wind },
    { id: 'mission', label: '3. Flight Profile', icon: Plane },
    { id: 'economics', label: '4. Airline & Fleet Economics', icon: DollarSign },
    { id: 'monteCarlo', label: '5. Monte Carlo Risk', icon: BarChart3 },
    { id: 'designSpace', label: '6. Design Space & Pareto', icon: Layers },
    { id: 'decision', label: '7. Sensitivity & Decision', icon: Crosshair },
    { id: 'research', label: '8. Research & Validation', icon: BookOpen },
  ];

  return (
    <header id="lab-header" className="bg-[#07070a] text-slate-100 border-b border-[#1a1a24] sticky top-0 z-40 shadow-xl backdrop-blur-md">
      {/* Top Bar: Title & Global Control Ribbon */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Badge */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-tr from-sky-600 to-indigo-600 rounded-lg text-white shadow-md shadow-sky-950/40">
            <Plane className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-zinc-100">
                SUPERSONIC DESIGN & ECONOMICS LAB
              </h1>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-sky-500/10 text-sky-300 border border-sky-500/30 rounded">
                Rust / R / TS v2.4
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Computational Engineering, Aerothermal Propulsion & Fleet Decision Laboratory
            </p>
          </div>
        </div>

        {/* Global Selectors */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Aircraft Presets */}
          <div className="flex items-center gap-1.5 bg-[#121218] border border-[#22222e] rounded-md px-2.5 py-1 text-xs">
            <span className="text-zinc-400 font-medium">Aircraft:</span>
            <select
              id="aircraft-selector"
              value={selectedAircraftId}
              onChange={(e) => onSelectAircraft(e.target.value)}
              aria-label="Select Aircraft Configuration"
              className="bg-transparent text-zinc-100 font-semibold outline-none cursor-pointer pr-2"
            >
              {aircraftList.map((ac) => (
                <option key={ac.id} value={ac.id} className="bg-[#0e0e14] text-zinc-100">
                  {ac.name} (M{ac.machCruise.value.toFixed(2)})
                </option>
              ))}
            </select>
          </div>

          {/* Route Selector */}
          <div className="flex items-center gap-1.5 bg-[#121218] border border-[#22222e] rounded-md px-2.5 py-1 text-xs">
            <Globe className="w-3.5 h-3.5 text-sky-400" />
            <select
              id="route-selector"
              value={selectedRouteIndex}
              onChange={(e) => onSelectRoute(Number(e.target.value))}
              aria-label="Select Mission Route"
              className="bg-transparent text-zinc-100 font-semibold outline-none cursor-pointer pr-2"
            >
              {PRESET_ROUTES.map((rt, idx) => (
                <option key={rt.id} value={idx} className="bg-[#0e0e14] text-zinc-100">
                  {rt.name} ({rt.greatCircleDistanceNm} nm)
                </option>
              ))}
            </select>
          </div>

          {/* Scenario Selector */}
          <div className="flex items-center gap-1.5 bg-[#121218] border border-[#22222e] rounded-md px-2.5 py-1 text-xs">
            <Settings2 className="w-3.5 h-3.5 text-amber-400" />
            <select
              id="scenario-selector"
              value={selectedScenarioId}
              onChange={(e) => onSelectScenario(e.target.value)}
              aria-label="Select Operating Scenario"
              className="bg-transparent text-zinc-100 font-semibold outline-none cursor-pointer pr-2"
            >
              {PRESET_SCENARIOS.map((sc) => (
                <option key={sc.id} value={sc.id} className="bg-[#0e0e14] text-zinc-100">
                  {sc.name}
                </option>
              ))}
            </select>
          </div>

          {/* Units Toggle */}
          <button
            id="units-toggle-btn"
            onClick={onToggleUnitSystem}
            title="Toggle between SI and Imperial units"
            className="px-2.5 py-1 text-xs font-semibold bg-[#121218] hover:bg-[#1a1a24] text-zinc-200 border border-[#22222e] rounded-md transition-colors"
          >
            Units: <span className="text-sky-400">{unitSystem}</span>
          </button>

          {/* Export Code Modal */}
          <button
            id="export-code-btn"
            onClick={onOpenExportModal}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white rounded-md transition-all shadow-md shadow-sky-950/30"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Rust / R Export</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav aria-label="Laboratory Sections" className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto no-scrollbar gap-1 border-t border-[#1a1a24] pt-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              id={`tab-${tab.id}`}
              key={tab.id}
              onClick={() => setActiveTab(tab.id as ActiveTab)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                isActive
                  ? 'border-sky-400 text-sky-300 bg-[#14141e]'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-[#121218]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-400' : 'text-zinc-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
