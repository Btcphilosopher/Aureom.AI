import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { ExportModal } from './components/ExportModal';
import { AircraftGeometryView } from './components/views/AircraftGeometryView';
import { AerodynamicsPropulsionView } from './components/views/AerodynamicsPropulsionView';
import { MissionSimulatorView } from './components/views/MissionSimulatorView';
import { EconomicsView } from './components/views/EconomicsView';
import { MonteCarloView } from './components/views/MonteCarloView';
import { DesignSpaceView } from './components/views/DesignSpaceView';
import { SensitivityDecisionView } from './components/views/SensitivityDecisionView';
import { ResearchAnswersView } from './components/views/ResearchAnswersView';

import { AircraftConfiguration } from './types/aircraft';
import { EconomicAssumptions } from './types/economics';
import { DecisionCriteriaWeights, DesignPoint } from './types/designSpace';

import { DEFAULT_AIRCRAFTS } from './engine/aircraftDefaults';
import { PRESET_ROUTES, simulateMission } from './engine/mission';
import { DEFAULT_ECONOMIC_ASSUMPTIONS, calculateFlightEconomics } from './engine/economics';
import { calculateFleetFinancials } from './engine/fleetEconomics';
import { calculateStructuralMassBuildup } from './engine/structures';
import { generateDesignSpace } from './engine/designSpace';
import { calculateSensitivityAnalysis } from './engine/sensitivity';
import { DEFAULT_DECISION_WEIGHTS, evaluateDecisionModel } from './engine/decisionModel';
import { DEFAULT_MONTE_CARLO_CONFIG, runMonteCarloSimulation } from './engine/monteCarlo';

export default function App() {
  // Navigation & Preferences State
  const [activeTab, setActiveTab] = useState<string>('geometry');
  const [unitSystem, setUnitSystem] = useState<'SI' | 'Imperial'>('SI');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Aircraft & Mission State
  const [aircraftList, setAircraftList] = useState<AircraftConfiguration[]>(DEFAULT_AIRCRAFTS);
  const [selectedAircraftId, setSelectedAircraftId] = useState<string>(DEFAULT_AIRCRAFTS[0].id);
  const [selectedRouteIndex, setSelectedRouteIndex] = useState<number>(0);

  // Economics & Fleet State
  const [assumptions, setAssumptions] = useState<EconomicAssumptions>(DEFAULT_ECONOMIC_ASSUMPTIONS);
  const [fleetSize, setFleetSize] = useState<number>(25);

  // Multi-Criteria Decision Weights
  const [decisionWeights, setDecisionWeights] = useState<DecisionCriteriaWeights>(DEFAULT_DECISION_WEIGHTS);

  // Find currently active aircraft
  const currentAircraft = useMemo(() => {
    return aircraftList.find((a) => a.id === selectedAircraftId) || aircraftList[0];
  }, [aircraftList, selectedAircraftId]);

  // Current active flight route
  const currentRoute = useMemo(() => {
    return PRESET_ROUTES[selectedRouteIndex] || PRESET_ROUTES[0];
  }, [selectedRouteIndex]);

  // Design Space Generation (Sampled candidate points across Mach 1.5-2.2, Aspect Ratios, etc.)
  const designPoints = useMemo<DesignPoint[]>(() => {
    return generateDesignSpace(DEFAULT_ECONOMIC_ASSUMPTIONS, PRESET_ROUTES[0]);
  }, []);

  // Structural Mass Buildup
  const structure = useMemo(() => {
    return calculateStructuralMassBuildup(currentAircraft);
  }, [currentAircraft]);

  // Mission Simulator Result
  const missionResult = useMemo(() => {
    return simulateMission(currentAircraft, currentRoute);
  }, [currentAircraft, currentRoute]);

  // Flight-Level Direct Operating Economics
  const flightEconomics = useMemo(() => {
    return calculateFlightEconomics(currentAircraft, missionResult, assumptions);
  }, [currentAircraft, missionResult, assumptions]);

  // Fleet 15-Year Financial & DCF Engine
  const fleetEconomics = useMemo(() => {
    return calculateFleetFinancials(currentAircraft, missionResult, flightEconomics, fleetSize, assumptions);
  }, [currentAircraft, missionResult, flightEconomics, fleetSize, assumptions]);

  // Sensitivity Analysis Metrics
  const sensitivityMetrics = useMemo(() => {
    return calculateSensitivityAnalysis(currentAircraft, currentRoute, assumptions);
  }, [currentAircraft, currentRoute, assumptions]);

  // Decision Score Model
  const decisionScore = useMemo(() => {
    return evaluateDecisionModel(currentAircraft, missionResult, flightEconomics, decisionWeights);
  }, [currentAircraft, missionResult, flightEconomics, decisionWeights]);

  // Monte Carlo Statistical Risk Engine State
  const [monteCarloSummary, setMonteCarloSummary] = useState(() => {
    return runMonteCarloSimulation(currentAircraft, currentRoute, assumptions, DEFAULT_MONTE_CARLO_CONFIG);
  });

  // Handle updates to the active aircraft configuration parameters
  const handleUpdateConfig = (newConfig: AircraftConfiguration) => {
    setAircraftList((prev) =>
      prev.map((a) => (a.id === newConfig.id ? newConfig : a))
    );
  };

  // Reset all aircraft to technical report defaults
  const handleResetDefaults = () => {
    setAircraftList(DEFAULT_AIRCRAFTS);
    setAssumptions(DEFAULT_ECONOMIC_ASSUMPTIONS);
    setDecisionWeights(DEFAULT_DECISION_WEIGHTS);
  };

  // Select design point from Design Space Pareto Frontier
  const handleSelectDesignPoint = (point: DesignPoint) => {
    const matched = aircraftList.find((a) => a.id === point.id || a.configId === point.id);
    if (matched) {
      setSelectedAircraftId(matched.id);
    } else {
      // Modify current aircraft to match design point parameters
      const updated: AircraftConfiguration = {
        ...currentAircraft,
        id: `custom-${point.id.toLowerCase()}`,
        name: point.name,
        configId: point.id,
        machCruise: { ...currentAircraft.machCruise, value: point.mach },
        aspectRatio: { ...currentAircraft.aspectRatio, value: point.aspectRatio },
        sweepAngle: { ...currentAircraft.sweepAngle, value: point.sweepDeg },
        wingArea: { ...currentAircraft.wingArea, value: point.wingAreaM2 },
        passengerCapacity: { ...currentAircraft.passengerCapacity, value: point.passengers },
        engineCycle: { ...currentAircraft.engineCycle, value: point.engineCycle },
      };
      setAircraftList((prev) => [updated, ...prev]);
      setSelectedAircraftId(updated.id);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#e5e5e5] flex flex-col font-sans selection:bg-sky-500/30 selection:text-sky-200">
      {/* Top Application Navigation */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        unitSystem={unitSystem}
        onToggleUnitSystem={() => setUnitSystem((prev) => (prev === 'SI' ? 'Imperial' : 'SI'))}
        selectedAircraftId={selectedAircraftId}
        aircraftList={aircraftList}
        onSelectAircraft={setSelectedAircraftId}
        onOpenExport={() => setIsExportModalOpen(true)}
        onResetDefaults={handleResetDefaults}
      />

      {/* Main Computational View Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 overflow-y-auto">
        {activeTab === 'geometry' && (
          <AircraftGeometryView
            config={currentAircraft}
            structure={structure}
            unitSystem={unitSystem}
            onUpdateConfig={handleUpdateConfig}
          />
        )}

        {activeTab === 'aeroprop' && (
          <AerodynamicsPropulsionView
            config={currentAircraft}
            unitSystem={unitSystem}
          />
        )}

        {activeTab === 'mission' && (
          <MissionSimulatorView
            config={currentAircraft}
            mission={missionResult}
            selectedRouteIndex={selectedRouteIndex}
            onSelectRoute={setSelectedRouteIndex}
            unitSystem={unitSystem}
          />
        )}

        {activeTab === 'economics' && (
          <EconomicsView
            config={currentAircraft}
            flightEconomics={flightEconomics}
            fleetEconomics={fleetEconomics}
            assumptions={assumptions}
            onUpdateAssumptions={setAssumptions}
            fleetSize={fleetSize}
            onChangeFleetSize={setFleetSize}
            unitSystem={unitSystem}
          />
        )}

        {activeTab === 'montecarlo' && (
          <MonteCarloView
            config={currentAircraft}
            route={currentRoute}
            assumptions={assumptions}
            monteCarloSummary={monteCarloSummary}
            onRunSimulation={setMonteCarloSummary}
          />
        )}

        {activeTab === 'designspace' && (
          <DesignSpaceView
            designPoints={designPoints}
            currentConfig={currentAircraft}
            onSelectDesignPoint={handleSelectDesignPoint}
          />
        )}

        {activeTab === 'sensitivity' && (
          <SensitivityDecisionView
            config={currentAircraft}
            sensitivityMetrics={sensitivityMetrics}
            decisionScore={decisionScore}
            decisionWeights={decisionWeights}
            onUpdateWeights={setDecisionWeights}
          />
        )}

        {activeTab === 'research' && (
          <ResearchAnswersView config={currentAircraft} />
        )}
      </main>

      {/* Standalone Rust / R / JSON / CSV Exporter Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={currentAircraft}
        designPoints={designPoints}
      />
    </div>
  );
}
