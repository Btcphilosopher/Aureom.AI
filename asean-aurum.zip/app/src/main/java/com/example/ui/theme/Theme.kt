package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = BrushedGold,
    secondary = MutedBronze,
    tertiary = SilverMetallic,
    background = BlackBg,
    surface = Graphite,
    onPrimary = BlackBg,
    onSecondary = OffWhiteText,
    onTertiary = Graphite,
    onBackground = OffWhiteText,
    onSurface = OffWhiteText,
    surfaceVariant = DarkSteel,
    onSurfaceVariant = OffWhiteText,
    outline = MediumSteel,
    error = RestrainedRed
)

private val LightColorScheme = lightColorScheme(
    primary = MutedBronze,
    secondary = BrushedGold,
    tertiary = DarkSteel,
    background = Parchment,
    surface = WarmWhite,
    onPrimary = Graphite,
    onSecondary = BlackBg,
    onTertiary = WarmWhite,
    onBackground = Graphite,
    onSurface = Graphite,
    surfaceVariant = Parchment,
    onSurfaceVariant = Graphite,
    outline = MediumSteel,
    error = RestrainedRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark theme for Swiss-vault, high-end bullion dealer feel
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
