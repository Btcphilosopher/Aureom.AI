package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.math.BigDecimal
import java.math.RoundingMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyStepperScreen() {
    var selectedJourney by remember { mutableStateOf("RETAIL") } // "RETAIL" or "INSTITUTIONAL"

    // Retail Journey Stepper Index
    var retailStep by remember { mutableStateOf(1) }
    // Institutional Journey Stepper Index
    var institutionalStep by remember { mutableStateOf(1) }

    val goldAccount by SimulationEngine.clientGoldAccount.collectAsState()
    val cashAccounts by SimulationEngine.clientCashAccounts.collectAsState()
    val bars by SimulationEngine.bars.collectAsState()
    val shipments by SimulationEngine.activeShipments.collectAsState()
    val rfqs by SimulationEngine.rfqs.collectAsState()

    var statusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Route, "Workflow", tint = BrushedGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "INTERACTIVE PLATFORM DEMONSTRATION JOURNEYS",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrushedGold,
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Graphite)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(BlackBg)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Journey Selector
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selectedJourney == "RETAIL") BrushedGold else Graphite)
                        .clickable { selectedJourney = "RETAIL" }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "1. KUALA LUMPUR CONSUMER JOURNEY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedJourney == "RETAIL") BlackBg else OffWhiteText,
                        textAlign = TextAlign.Center
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selectedJourney == "INSTITUTIONAL") BrushedGold else Graphite)
                        .clickable { selectedJourney = "INSTITUTIONAL" }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "2. BANGKOK INSTITUTIONAL RFQ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedJourney == "INSTITUTIONAL") BlackBg else OffWhiteText,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Real State Inspector Panel (Shows updates in real-time as steps are executed!)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Graphite)
                    .border(1.dp, MediumSteel, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Text("ACTIVE SIMULATION DATABASE REGISTRY (REAL-TIME STATE)", fontSize = 9.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("USER GOLD BALANCE", fontSize = 9.sp, color = TextGray)
                            Text("${goldAccount.totalWeightG} g", fontSize = 11.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CASH WALLETS", fontSize = 9.sp, color = TextGray)
                            val myr = cashAccounts["MYR"]?.totalBalance ?: BigDecimal.ZERO
                            val sgd = cashAccounts["SGD"]?.totalBalance ?: BigDecimal.ZERO
                            Text("RM $myr | SGD $sgd", fontSize = 11.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("USER PHYSICAL BARS", fontSize = 9.sp, color = TextGray)
                            Text("${bars.filter { it.ownerId == "user" }.size} Bars", fontSize = 11.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (selectedJourney == "RETAIL") {
                // RETAIL JOURNEY STEPPER
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(
                            text = "KUALA LUMPUR CLIENT PHYSICAL INFRASTRUCTURE PIPELINE",
                            fontSize = 12.sp,
                            color = BrushedGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // STEP 1: View prices
                    item {
                        StepCard(
                            stepNum = 1,
                            title = "Open ASEAN AURUM & Inspect Live MYR Price",
                            description = "Kuala Lumpur retail client connects to Singapore central clearing rates. Spot price is dynamically converted to MYR with added Malaysia premiums.",
                            isActive = retailStep == 1,
                            isCompleted = retailStep > 1,
                            actionText = "VIEW PRICE INVOICE",
                            onAction = {
                                val pricing = SimulationEngine.calculateLocalPrice(Metal.GOLD, "MYR", "Malaysia", BigDecimal("100.00"))
                                statusMessage = "MYR Live Gold Gold 999.9 Rate: RM ${pricing["finalPricePerGram"]}/g. Calculated premium & spreads included."
                                retailStep = 2
                            }
                        )
                    }

                    // STEP 2: Buy 100g
                    item {
                        StepCard(
                            stepNum = 2,
                            title = "Purchase 100g Physical Gold in Singapore Vault",
                            description = "User buys a certified 100g 999.9 bar. System screens AML compliance thresholds, executes ledger debit from MYR wallet, and performs book-entry allocation.",
                            isActive = retailStep == 2,
                            isCompleted = retailStep > 2,
                            actionText = "BUY 100G GOLD IN SG CUSTODY",
                            onAction = {
                                val (success, msg) = SimulationEngine.executeBuy(
                                    metal = Metal.GOLD,
                                    country = "Malaysia",
                                    weightG = BigDecimal("100.00"),
                                    currency = "MYR",
                                    vaultId = "SG-01"
                                )
                                statusMessage = msg
                                if (success) retailStep = 3
                            }
                        )
                    }

                    // STEP 3: View Passport
                    item {
                        StepCard(
                            stepNum = 3,
                            title = "Assign Specific Physical Bar & View Metal Passport",
                            description = "The client receives true allocated ownership of a specific synthetic bar (assigned serial number) minted by Metalor. View the secure blockchain-style Metal Passport.",
                            isActive = retailStep == 3,
                            isCompleted = retailStep > 3,
                            actionText = "VERIFY ASSIGNED BAR PASSPORT",
                            onAction = {
                                val userBars = bars.filter { it.ownerId == "user" && it.grossWeightG.compareTo(BigDecimal("100.00")) == 0 }
                                if (userBars.isNotEmpty()) {
                                    val bar = userBars.last()
                                    statusMessage = "PASSPORT RECORD: Serial: ${bar.serialNumber} | Refiner: ${bar.refiner} | Assay Ref: ${bar.assayReference} | Facility: ${bar.currentVaultId}"
                                    retailStep = 4
                                } else {
                                    statusMessage = "Please ensure the 100g bar is purchased in Step 2 first."
                                }
                            }
                        )
                    }

                    // STEP 4: Request Vault Transfer
                    item {
                        StepCard(
                            stepNum = 4,
                            title = "Initiate Secure Vault Transfer from SG to KL",
                            description = "Client requests physical relocation of their allocated bar from Singapore Central Vault to Kuala Lumpur Vault. Secure Brinks flight transit begins.",
                            isActive = retailStep == 4,
                            isCompleted = retailStep > 4,
                            actionText = "INITIATE SG -> KL FLIGHT TRANSIT",
                            onAction = {
                                val userBars = bars.filter { it.ownerId == "user" && it.currentVaultId == "SG-01" }
                                if (userBars.isNotEmpty()) {
                                    val bar = userBars.last()
                                    val (success, msg) = SimulationEngine.requestVaultTransfer(bar.barId, "MY-01")
                                    statusMessage = msg
                                    if (success) retailStep = 5
                                } else {
                                    statusMessage = "No user-owned bars located in Singapore vault. Re-execute Step 2."
                                }
                            }
                        )
                    }

                    // STEP 5: Complete Transit
                    item {
                        StepCard(
                            stepNum = 5,
                            title = "Kuala Lumpur Vault Receives and Audits Bar",
                            description = "The secure transit arrives. KL Vault operator verifies RFID tag and signs off custody. Bar ownership remains strictly with the user, stored locally in KL.",
                            isActive = retailStep == 5,
                            isCompleted = retailStep > 5,
                            actionText = "CONFIRM RECEIPT AT KL VAULT",
                            onAction = {
                                val active = shipments.find { it.toVaultId == "MY-01" }
                                if (active != null) {
                                    SimulationEngine.completeTransferShipment(active.movementId)
                                    statusMessage = "Secure transit finalized. Bar received and logged in Kuala Lumpur vault inventory."
                                    retailStep = 6
                                } else {
                                    statusMessage = "No active transit found. Re-execute Step 4."
                                }
                            }
                        )
                    }

                    // STEP 6: Partial Sell back
                    item {
                        StepCard(
                            stepNum = 6,
                            title = "Liquidate & Sell 50g Back to Dealer Terminal",
                            description = "Client partial-liquidates. 50g is deallocated, ownership moves back to dealer liquid stock, and client receives instant settled MYR currency in their wallet.",
                            isActive = retailStep == 6,
                            isCompleted = retailStep > 6,
                            actionText = "SELL BACK 50G GOLD IN MYR",
                            onAction = {
                                val userBars = bars.filter { it.ownerId == "user" && it.currentVaultId == "MY-01" }
                                if (userBars.isNotEmpty()) {
                                    val bar = userBars.last()
                                    val (success, msg) = SimulationEngine.executeSell(bar.barId, "MYR", "Malaysia")
                                    statusMessage = msg
                                    if (success) retailStep = 7
                                } else {
                                    statusMessage = "No user-owned bars found in Kuala Lumpur Vault. Run previous steps."
                                }
                            }
                        )
                    }

                    // Completed Banner
                    if (retailStep == 7) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SafeGreen.copy(alpha = 0.2f))
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Text("🎉 RETAIL DEMO JOURNEY COMPLETED!", color = BrushedGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("You have fully demonstrated the physical-to-digital precious metals custody lifecycle. Tap reset below to replay.", color = OffWhiteText, fontSize = 11.sp)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(onClick = { retailStep = 1; statusMessage = null }, colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)) {
                                        Text("RESET WALKTHROUGH", color = BlackBg, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // INSTITUTIONAL JOURNEY STEPPER
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(
                            text = "BANGKOK INSTITUTIONAL PRECIOUS-METALS RFQ WORKFLOW",
                            fontSize = 12.sp,
                            color = BrushedGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // STEP 1: Client RFQ request
                    item {
                        StepCard(
                            stepNum = 1,
                            title = "Bangkok Client Initiates 2,000 Kg Silver RFQ",
                            description = "An institutional client in Bangkok requests a rapid quotation for 2,000 kg silver. Spot indices, physical delivery fees, and vaulting margins are loaded.",
                            isActive = institutionalStep == 1,
                            isCompleted = institutionalStep > 1,
                            actionText = "TRIGGER 2,000KG SILVER RFQ",
                            onAction = {
                                val rfq = SimulationEngine.requestInstitutionalRfq(
                                    clientName = "Bangkok Bank Bullion Corp",
                                    metal = Metal.SILVER,
                                    weightKg = BigDecimal("2000.00"),
                                    currency = "USD",
                                    vaultId = "SG-01"
                                )
                                statusMessage = "Quoted institutional rate: USD ${rfq.quotePricePerKg}/Kg. Total quote value: USD ${rfq.totalQuoteAmount}."
                                institutionalStep = 2
                            }
                        )
                    }

                    // STEP 2: Quote verification
                    item {
                        StepCard(
                            stepNum = 2,
                            title = "Dealer Verification within 30s Validity Window",
                            description = "The institutional dealer reviews open risk, checks Singapore Central Vault volumetric storage bounds, and accepts the execution parameters.",
                            isActive = institutionalStep == 2,
                            isCompleted = institutionalStep > 2,
                            actionText = "EXECUTE AND ALLOCATE QUOTE",
                            onAction = {
                                val active = rfqs.find { it.clientName.contains("Bangkok") && it.status == RfqStatus.QUOTED }
                                if (active != null) {
                                    val (success, msg) = SimulationEngine.acceptRfqQuote(active.rfqId)
                                    statusMessage = msg
                                    if (success) institutionalStep = 3
                                } else {
                                    statusMessage = "No active quoted RFQ found. Re-execute Step 1."
                                }
                            }
                        )
                    }

                    // STEP 3: Verification & Audit
                    item {
                        StepCard(
                            stepNum = 3,
                            title = "Post-Trade Ledger Reconciliation & Audit Check",
                            description = "Runs the dual-ledger reconciler across Singapore vaults to verify that the newly-allocated institutional bar records match the underlying financial bookkeeping perfectly.",
                            isActive = institutionalStep == 3,
                            isCompleted = institutionalStep > 3,
                            actionText = "RUN SYSTEM RECONCILIATION AUDIT",
                            onAction = {
                                val exceptions = SimulationEngine.runReconciliation()
                                if (exceptions.isEmpty()) {
                                    statusMessage = "Audit passed. Total vault silver balances reconcile 100% against client allocation registers."
                                    institutionalStep = 4
                                } else {
                                    statusMessage = "Exception Alarm: ${exceptions.first()}"
                                }
                            }
                        )
                    }

                    // Completed Banner
                    if (institutionalStep == 4) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SafeGreen.copy(alpha = 0.2f))
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Text("🎉 INSTITUTIONAL DEMO JOURNEY COMPLETED!", color = BrushedGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("You have executed a high-throughput institutional trading lifecycle. Tap reset to replay.", color = OffWhiteText, fontSize = 11.sp)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(onClick = { institutionalStep = 1; statusMessage = null }, colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)) {
                                        Text("RESET WALKTHROUGH", color = BlackBg, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Interactive Feedback Message Panel
            statusMessage?.let { msg ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSteel)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, "Status", tint = BrushedGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("EXECUTION FEEDBACK LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = msg,
                            color = OffWhiteText,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StepCard(
    stepNum: Int,
    title: String,
    description: String,
    isActive: Boolean,
    isCompleted: Boolean,
    actionText: String,
    onAction: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) Graphite else DarkSteel.copy(alpha = 0.5f))
            .border(
                1.dp,
                if (isActive) BrushedGold else if (isCompleted) SafeGreen else Color.Transparent,
                RoundedCornerShape(8.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isCompleted) SafeGreen else if (isActive) BrushedGold else MediumSteel),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            stepNum.toString(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted || isActive) BlackBg else TextGray
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive || isCompleted) WarmWhite else TextGray
                    )
                }

                if (isCompleted) {
                    Icon(Icons.Default.CheckCircle, "Completed", tint = SafeGreen, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(description, fontSize = 11.sp, color = TextGray, lineHeight = 15.sp)

            if (isActive) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAction,
                    modifier = Modifier.fillMaxWidth().testTag("journey_step_btn_$stepNum"),
                    colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                ) {
                    Text(actionText, color = BlackBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
