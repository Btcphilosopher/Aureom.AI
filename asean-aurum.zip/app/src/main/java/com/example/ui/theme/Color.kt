package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Luxury Color Palette for ASEAN AURUM (Singapore Wealth Hub, Swiss Precision)
val Graphite = Color(0xFF151719)
val BlackBg = Color(0xFF0E0F10)
val DarkSteel = Color(0xFF23262A)
val MediumSteel = Color(0xFF3B4148)
val BrushedGold = Color(0xFFD4AF37)
val MutedBronze = Color(0xFF9E7E38)
val WarmWhite = Color(0xFFFBF9F4)
val Parchment = Color(0xFFF4EFE2)
val RestrainedRed = Color(0xFF9E2A2B)
val SafeGreen = Color(0xFF2A593E)
val OffWhiteText = Color(0xFFECEAE4)
val TextGray = Color(0xFF9CA3AF)
val SilverMetallic = Color(0xFFC0C0C0)
val DeepGold = Color(0xFFB8860B)
