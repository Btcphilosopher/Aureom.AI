package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.math.BigDecimal
import java.math.RoundingMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerAppScreen() {
    var selectedLanguage by remember { mutableStateOf("en") }
    val dict = MockData.i18n[selectedLanguage] ?: MockData.i18n["en"]!!

    val goldAccount by SimulationEngine.clientGoldAccount.collectAsState()
    val silverAccount by SimulationEngine.clientSilverAccount.collectAsState()
    val cashAccounts by SimulationEngine.clientCashAccounts.collectAsState()
    val bars by SimulationEngine.bars.collectAsState()
    val vaults by SimulationEngine.vaults.collectAsState()
    val activeShipments by SimulationEngine.activeShipments.collectAsState()
    val scrapCases by SimulationEngine.scrapCases.collectAsState()

    // UI state
    var selectedTab by remember { mutableStateOf("PORTFOLIO") } // "PORTFOLIO", "TRADE", "VAULTS", "SCRAP"
    var showPassportBar by remember { mutableStateOf<MetalObject?>(null) }
    var notificationMessage by remember { mutableStateOf<String?>(null) }

    // Multi-currency calculation (SGD-based wealth)
    val liveGoldPriceSgd = SimulationEngine.calculateLocalPrice(Metal.GOLD, "SGD", "Singapore", BigDecimal.ONE)["spotGram"] ?: BigDecimal("98.15")
    val liveSilverPriceSgd = SimulationEngine.calculateLocalPrice(Metal.SILVER, "SGD", "Singapore", BigDecimal.ONE)["spotGram"] ?: BigDecimal("1.12")

    val goldValSgd = goldAccount.currentValuation(liveGoldPriceSgd)
    val silverValSgd = silverAccount.currentValuation(liveSilverPriceSgd)

    val cashValSgd = cashAccounts.values.fold(BigDecimal.ZERO) { acc, wallet ->
        val fxRate = SimulationEngine.fxRates[wallet.currency] ?: BigDecimal.ONE
        val amountInUsd = wallet.totalBalance.divide(fxRate, 6, RoundingMode.HALF_UP)
        val amountInSgd = amountInUsd.multiply(SimulationEngine.fxRates["SGD"]!!)
        acc.add(amountInSgd)
    }.setScale(2, RoundingMode.HALF_UP)

    val totalWealthSgd = goldValSgd.add(silverValSgd).add(cashValSgd)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ASEAN AURUM",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            color = BrushedGold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = dict["app_subtitle"] ?: "SOUTHEAST ASIAN GOLD & SILVER",
                            fontSize = 10.sp,
                            color = TextGray,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                actions = {
                    // Language Selector Dropdown Row
                    Row(
                        modifier = Modifier.padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language Selector",
                            tint = BrushedGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        listOf("en", "zh", "ms", "id", "th", "vi", "fil").forEach { lang ->
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedLanguage == lang) BrushedGold else DarkSteel)
                                    .clickable { selectedLanguage = lang }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = lang.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedLanguage == lang) BlackBg else OffWhiteText
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Graphite)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Graphite,
                modifier = Modifier.navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = selectedTab == "PORTFOLIO",
                    onClick = { selectedTab = "PORTFOLIO" },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, "Portfolio") },
                    label = { Text(dict["tab_home"] ?: "Home", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BlackBg,
                        selectedTextColor = BrushedGold,
                        indicatorColor = BrushedGold,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    modifier = Modifier.testTag("nav_portfolio")
                )
                NavigationBarItem(
                    selected = selectedTab == "TRADE",
                    onClick = { selectedTab = "TRADE" },
                    icon = { Icon(Icons.Default.CurrencyExchange, "Trade") },
                    label = { Text(dict["tab_buy_sell"] ?: "Trade", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BlackBg,
                        selectedTextColor = BrushedGold,
                        indicatorColor = BrushedGold,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    modifier = Modifier.testTag("nav_trade")
                )
                NavigationBarItem(
                    selected = selectedTab == "VAULTS",
                    onClick = { selectedTab = "VAULTS" },
                    icon = { Icon(Icons.Default.HomeWork, "Vaults") },
                    label = { Text(dict["tab_vaults"] ?: "Vaults", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BlackBg,
                        selectedTextColor = BrushedGold,
                        indicatorColor = BrushedGold,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    modifier = Modifier.testTag("nav_vaults")
                )
                NavigationBarItem(
                    selected = selectedTab == "SCRAP",
                    onClick = { selectedTab = "SCRAP" },
                    icon = { Icon(Icons.Default.Autorenew, "Scrap") },
                    label = { Text(dict["tab_scrap"] ?: "Scrap", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BlackBg,
                        selectedTextColor = BrushedGold,
                        indicatorColor = BrushedGold,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    modifier = Modifier.testTag("nav_scrap")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(BlackBg)
        ) {
            // Notification Banner
            AnimatedVisibility(visible = notificationMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SafeGreen)
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, "Success", tint = WarmWhite, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = notificationMessage ?: "",
                            color = WarmWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { notificationMessage = null }) {
                            Icon(Icons.Default.Close, "Dismiss", tint = WarmWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Main Content Area based on Selected Tab
            when (selectedTab) {
                "PORTFOLIO" -> PortfolioTab(
                    dict = dict,
                    totalWealthSgd = totalWealthSgd,
                    goldAccount = goldAccount,
                    silverAccount = silverAccount,
                    cashAccounts = cashAccounts,
                    bars = bars.filter { it.ownerId == "user" },
                    onBarSelect = { showPassportBar = it }
                )
                "TRADE" -> TradeTab(
                    dict = dict,
                    vaults = vaults,
                    cashAccounts = cashAccounts,
                    onExecuteSuccess = { msg ->
                        notificationMessage = msg
                        selectedTab = "PORTFOLIO"
                    }
                )
                "VAULTS" -> VaultsTab(
                    dict = dict,
                    vaults = vaults,
                    bars = bars.filter { it.ownerId == "user" },
                    activeShipments = activeShipments,
                    onActionSuccess = { msg ->
                        notificationMessage = msg
                    }
                )
                "SCRAP" -> ScrapBuybackTab(
                    dict = dict,
                    scrapCases = scrapCases,
                    onActionSuccess = { msg ->
                        notificationMessage = msg
                    }
                )
            }
        }

        // --- Custom Asset Passport Popover Dialog ---
        showPassportBar?.let { bar ->
            AlertDialog(
                onDismissRequest = { showPassportBar = null },
                containerColor = Graphite,
                shape = RoundedCornerShape(12.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, "Shield", tint = BrushedGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SECURE METAL PASSPORT",
                            color = BrushedGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSteel)
                                .border(1.dp, BrushedGold, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("UNIQUE REGISTERED ASSET ID", fontSize = 9.sp, color = TextGray)
                                Text(bar.barId, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("SERIAL REGISTRY NUMBER", fontSize = 9.sp, color = TextGray)
                                Text(bar.serialNumber, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = BrushedGold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val labelValuePairs = listOf(
                            "Metal Classification" to bar.metal.name,
                            "Fineness / Purity" to "${bar.purity} PPT (${if (bar.purity >= BigDecimal("999")) "Fine Bullion" else "Alloy"})",
                            "Gross Weight" to "${bar.grossWeightG} g",
                            "Calculated Fine Metal" to "${bar.fineWeightG} g",
                            "Certified Refiner" to bar.refiner,
                            "Mint Brand" to bar.brand,
                            "Manufacture Year" to bar.manufactureYear.toString(),
                            "Assay Authority Certificate" to bar.assayReference,
                            "Ore Origin Location" to bar.origin,
                            "Custody Status" to bar.custodyStatus.name,
                            "Storage Facility Node" to bar.currentVaultId,
                            "Ownership Registry Reference" to bar.ownerId.uppercase(),
                            "Audit Standard" to bar.inspectionStatus
                        )

                        LazyColumn(modifier = Modifier.height(240.dp)) {
                            items(labelValuePairs) { (label, value) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(label, fontSize = 11.sp, color = TextGray)
                                    Text(value, fontSize = 11.sp, color = OffWhiteText, fontWeight = FontWeight.Bold)
                                }
                                Divider(color = DarkSteel, thickness = 0.5.dp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "The physical asset remains permanently stored in custody under a certified bailment contract. Book-entry ownership is immutable.",
                            fontSize = 9.sp,
                            color = TextGray,
                            textAlign = TextAlign.Center,
                            lineHeight = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showPassportBar = null },
                        colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                    ) {
                        Text("DISMISS REGISTRY", color = BlackBg, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}

// ==========================================
// PORTFOLIO TAB
// ==========================================
@Composable
fun PortfolioTab(
    dict: Map<String, String>,
    totalWealthSgd: BigDecimal,
    goldAccount: MetalAccount,
    silverAccount: MetalAccount,
    cashAccounts: Map<String, CashAccount>,
    bars: List<MetalObject>,
    onBarSelect: (MetalObject) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Wealth Display Card (Private Banking aesthetic)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, BrushedGold.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = dict["wealth_summary"] ?: "TOTAL PORTFOLIO VALUE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BrushedGold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "SGD $totalWealthSgd",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmWhite
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SafeGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "VAULTED 100%",
                                color = BrushedGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Metal Accounts Weights Card
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Gold Account
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Graphite)
                        .padding(14.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Circle, "Gold", tint = BrushedGold, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("GOLD HOLDING", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("${goldAccount.totalWeightG} g", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Allocated: ${goldAccount.allocatedWeightG} g", fontSize = 10.sp, color = TextGray)
                    }
                }

                // Silver Account
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Graphite)
                        .padding(14.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Circle, "Silver", tint = SilverMetallic, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SILVER HOLDING", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("${silverAccount.totalWeightG} g", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Allocated: ${silverAccount.allocatedWeightG} g", fontSize = 10.sp, color = TextGray)
                    }
                }
            }
        }

        // Regional Custody Asset Map Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSteel)
                    .border(1.dp, MediumSteel, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text("REGIONAL GEOGRAPHIC HOLDINGS MAP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Simple text map nodes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SG", fontWeight = FontWeight.Bold, color = BrushedGold, fontSize = 12.sp)
                            Text("Singapore Hub", fontSize = 9.sp, color = TextGray)
                            Text("2,000 g", fontSize = 10.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("MY", fontWeight = FontWeight.Bold, color = WarmWhite, fontSize = 12.sp)
                            Text("Kuala Lumpur", fontSize = 9.sp, color = TextGray)
                            Text("100 g", fontSize = 10.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TH", fontWeight = FontWeight.Bold, color = WarmWhite, fontSize = 12.sp)
                            Text("Bangkok", fontSize = 9.sp, color = TextGray)
                            Text("50 g", fontSize = 10.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ID", fontWeight = FontWeight.Bold, color = WarmWhite, fontSize = 12.sp)
                            Text("Jakarta", fontSize = 9.sp, color = TextGray)
                            Text("1,000 g", fontSize = 10.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MediumSteel))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "✔ All assets verified via dual-factor audit keys. Physical bars backed 1:1 in real facilities.",
                        fontSize = 9.sp,
                        color = SafeGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Multi-currency cash accounts sub-table
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Graphite)
                    .padding(14.dp)
            ) {
                Text("LIQUID CASH WALLETS (SETTLEMENT BALANCES)", fontSize = 11.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                cashAccounts.values.forEach { cash ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MonetizationOn, "Cash", tint = OffWhiteText, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(cash.currency, fontSize = 12.sp, color = OffWhiteText, fontWeight = FontWeight.Bold)
                        }
                        Text("${MockData.getCurrencySymbol(cash.currency)}${cash.totalBalance}", fontSize = 12.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                    }
                    Divider(color = DarkSteel, thickness = 0.5.dp)
                }
            }
        }

        // Allocated Bars List header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ALLOCATED PHYSICAL ASSETS", fontSize = 13.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                Text("${bars.size} Bars Owned", fontSize = 11.sp, color = TextGray)
            }
        }

        // Allocated Bars List
        if (bars.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Graphite)
                ) {
                    Text(
                        "No physical bars currently registered in your custody portfolio. Open the trade portal to buy bullion.",
                        fontSize = 11.sp,
                        color = TextGray,
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(bars) { bar ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Graphite)
                        .clickable { onBarSelect(bar) }
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Square,
                                    contentDescription = "Bar",
                                    tint = if (bar.metal == Metal.GOLD) BrushedGold else SilverMetallic,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = bar.serialNumber,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WarmWhite
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${bar.refiner} • ${bar.purity} PPT • ${bar.grossWeightG}g",
                                fontSize = 11.sp,
                                color = TextGray
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DarkSteel)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = bar.currentVaultId,
                                    color = BrushedGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "PASSPORT ➜",
                                color = BrushedGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TRADE (BUY/SELL) TAB
// ==========================================
@Composable
fun TradeTab(
    dict: Map<String, String>,
    vaults: List<Vault>,
    cashAccounts: Map<String, CashAccount>,
    onExecuteSuccess: (String) -> Unit
) {
    var selectedMetal by remember { mutableStateOf(Metal.GOLD) }
    var selectedCountry by remember { mutableStateOf("Singapore") }
    var selectedProductWeight by remember { mutableStateOf(BigDecimal("100.00")) }
    var selectedCurrency by remember { mutableStateOf("SGD") }
    var selectedVault by remember { mutableStateOf("SG-01") }

    val countries = listOf("Singapore", "Malaysia", "Thailand", "Indonesia", "Vietnam", "Philippines")
    val goldProducts = listOf(
        BigDecimal("1.00"), BigDecimal("5.00"), BigDecimal("10.00"),
        BigDecimal("50.00"), BigDecimal("100.00"), BigDecimal("1000.00")
    )
    val silverProducts = listOf(
        BigDecimal("100.00"), BigDecimal("500.00"), BigDecimal("1000.00"),
        BigDecimal("5000.00"), BigDecimal("15000.00")
    )

    val pricing = SimulationEngine.calculateLocalPrice(selectedMetal, selectedCurrency, selectedCountry, selectedProductWeight)
    val spotGram = pricing["spotGram"] ?: BigDecimal.ZERO
    val regionalPremium = pricing["regionalPremium"] ?: BigDecimal.ZERO
    val barPremium = pricing["barPremium"] ?: BigDecimal.ZERO
    val vaultFee = pricing["vaultFee"] ?: BigDecimal.ZERO
    val finalPricePerGram = pricing["finalPricePerGram"] ?: BigDecimal.ZERO
    val totalValuation = pricing["totalValuation"] ?: BigDecimal.ZERO

    var errorMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "INSTITUTIONAL PHYSICAL BULION PORTAL",
                fontSize = 14.sp,
                color = BrushedGold,
                fontWeight = FontWeight.Bold
            )
        }

        // Metal Selection Row
        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        selectedMetal = Metal.GOLD
                        selectedProductWeight = BigDecimal("100.00")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp)
                        .testTag("trade_select_gold"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetal == Metal.GOLD) BrushedGold else DarkSteel
                    )
                ) {
                    Text("GOLD (XAU)", color = if (selectedMetal == Metal.GOLD) BlackBg else OffWhiteText, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        selectedMetal = Metal.SILVER
                        selectedProductWeight = BigDecimal("1000.00")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 6.dp)
                        .testTag("trade_select_silver"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetal == Metal.SILVER) SilverMetallic else DarkSteel
                    )
                ) {
                    Text("SILVER (XAG)", color = if (selectedMetal == Metal.SILVER) BlackBg else OffWhiteText, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Regional Hub Origin Node Selection
        item {
            Column {
                Text("CUSTODY HUB / REGIONAL JURISDICTION", fontSize = 11.sp, color = TextGray)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    countries.take(3).forEach { country ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedCountry == country) BrushedGold else Graphite)
                                .clickable {
                                    selectedCountry = country
                                    selectedCurrency = when (country) {
                                        "Singapore" -> "SGD"
                                        "Malaysia" -> "MYR"
                                        "Thailand" -> "THB"
                                        "Indonesia" -> "IDR"
                                        else -> "SGD"
                                    }
                                    selectedVault = when (country) {
                                        "Singapore" -> "SG-01"
                                        "Malaysia" -> "MY-01"
                                        "Thailand" -> "TH-01"
                                        "Indonesia" -> "ID-01"
                                        else -> "SG-01"
                                    }
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                country,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCountry == country) BlackBg else OffWhiteText
                            )
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    countries.drop(3).forEach { country ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedCountry == country) BrushedGold else Graphite)
                                .clickable {
                                    selectedCountry = country
                                    selectedCurrency = "SGD" // Fallback to base
                                    selectedVault = when (country) {
                                        "Vietnam" -> "VN-01"
                                        "Philippines" -> "PH-01"
                                        else -> "SG-01"
                                    }
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                country,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCountry == country) BlackBg else OffWhiteText
                            )
                        }
                    }
                }
            }
        }

        // Product Sizes Selection Row
        item {
            Column {
                Text("SPECIFY CERTIFIED PHYSICAL WEIGHT CLASS", fontSize = 11.sp, color = TextGray)
                Spacer(modifier = Modifier.height(6.dp))
                val products = if (selectedMetal == Metal.GOLD) goldProducts else silverProducts
                Row(modifier = Modifier.fillMaxWidth()) {
                    products.take(3).forEach { weight ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedProductWeight == weight) BrushedGold else Graphite)
                                .clickable { selectedProductWeight = weight }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${weight} g",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedProductWeight == weight) BlackBg else OffWhiteText
                            )
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    products.drop(3).forEach { weight ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedProductWeight == weight) BrushedGold else Graphite)
                                .clickable { selectedProductWeight = weight }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${weight} g",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedProductWeight == weight) BlackBg else OffWhiteText
                            )
                        }
                    }
                }
            }
        }

        // Settlement Currency Select
        item {
            Column {
                Text("SETTLEMENT CURRENCY", fontSize = 11.sp, color = TextGray)
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    listOf("SGD", "MYR", "THB", "USD").forEach { curr ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedCurrency == curr) BrushedGold else Graphite)
                                .clickable { selectedCurrency = curr }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                curr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCurrency == curr) BlackBg else OffWhiteText
                            )
                        }
                    }
                }
            }
        }

        // Storage Facility node dropdown (configured to selected country)
        item {
            Column {
                Text("VAULT ARCHITECTURE INSTANCE", fontSize = 11.sp, color = TextGray)
                Spacer(modifier = Modifier.height(6.dp))
                val appropriateVaults = vaults.filter { it.country.lowercase().contains(selectedCountry.lowercase().take(5)) || selectedCountry == "Singapore" && it.country == "Singapore" }
                appropriateVaults.forEach { v ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selectedVault == v.vaultId) BrushedGold else Graphite)
                            .clickable { selectedVault = v.vaultId }
                            .padding(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(v.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selectedVault == v.vaultId) BlackBg else OffWhiteText)
                            Text(v.vaultId, fontSize = 12.sp, color = if (selectedVault == v.vaultId) BlackBg else TextGray)
                        }
                    }
                }
            }
        }

        // TRANSPARENT FEE CALCULATIONS & VALUATION
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Graphite)
                    .border(1.dp, MediumSteel, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text("TRANSPARENT TRANSACTION INVOICE", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                val symbol = MockData.getCurrencySymbol(selectedCurrency)

                val details = listOf(
                    "Spot Price (Base/g)" to "$symbol$spotGram",
                    "Regional Premium (Logistics/g)" to "+ $symbol$regionalPremium",
                    "Fabrication & Assay Premium (Bar)" to "+ $symbol$barPremium",
                    "Security & Custody pre-ins (0.1%)" to "+ $symbol$vaultFee",
                    "Total Audited Price (per gram)" to "$symbol$finalPricePerGram",
                    "Purity Level Assigned" to if (selectedMetal == Metal.GOLD) "999.9 Fine Gold" else "999.0 Fine Silver"
                )

                details.forEach { (lbl, valStr) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(lbl, fontSize = 11.sp, color = TextGray)
                        Text(valStr, fontSize = 11.sp, color = OffWhiteText, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = MediumSteel)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TOTAL VALUATION AMOUNT", fontSize = 13.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                    Text("$symbol$totalValuation", fontSize = 18.sp, color = BrushedGold, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        // Error message if any
        errorMessage?.let { error ->
            item {
                Text(
                    text = error,
                    color = Color.Red,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Execution Actions
        item {
            Button(
                onClick = {
                    errorMessage = null
                    val (success, msg) = SimulationEngine.executeBuy(
                        metal = selectedMetal,
                        country = selectedCountry,
                        weightG = selectedProductWeight,
                        currency = selectedCurrency,
                        vaultId = selectedVault
                    )
                    if (success) {
                        onExecuteSuccess(msg)
                    } else {
                        errorMessage = msg
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("execute_buy_button"),
                colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
            ) {
                Text(
                    text = dict["buy_btn"] ?: "Execute Institutional Buy",
                    color = BlackBg,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ==========================================
// VAULTS TAB
// ==========================================
@Composable
fun VaultsTab(
    dict: Map<String, String>,
    vaults: List<Vault>,
    bars: List<MetalObject>,
    activeShipments: List<VaultMovement>,
    onActionSuccess: (String) -> Unit
) {
    var selectedTransferBarId by remember { mutableStateOf("") }
    var selectedTargetVaultId by remember { mutableStateOf("") }
    var deliveryBarId by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }

    var feedbackMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                dict["vault_network"] ?: "ASEAN Secure Vault Network",
                fontSize = 14.sp,
                color = BrushedGold,
                fontWeight = FontWeight.Bold
            )
        }

        // Digital Twins summary list
        item {
            Text("VAULT DIGITAL TWINS STATUS", fontSize = 11.sp, color = TextGray)
        }

        items(vaults.take(4)) { v ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Graphite)
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(v.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                            Text("${v.city}, ${v.country}", fontSize = 10.sp, color = TextGray)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SafeGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(v.securityState, color = BrushedGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("GOLD METALS", fontSize = 9.sp, color = TextGray)
                            Text("${v.goldTonnage} t", fontSize = 12.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("SILVER METALS", fontSize = 9.sp, color = TextGray)
                            Text("${v.silverTonnage} t", fontSize = 12.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("BAR COUNT", fontSize = 9.sp, color = TextGray)
                            Text(v.barCount.toString(), fontSize = 12.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CAPACITY", fontSize = 9.sp, color = TextGray)
                            val capPct = v.occupiedCapacityKg.divide(v.totalCapacityKg, 4, RoundingMode.HALF_UP).multiply(BigDecimal("100")).setScale(1, RoundingMode.HALF_UP)
                            Text("$capPct%", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (v.inboundShipments > 0 || v.outboundShipments > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(DarkSteel))
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (v.inboundShipments > 0) {
                                Text("⬇ Inbound Secure Transits: ${v.inboundShipments}", color = BrushedGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            if (v.outboundShipments > 0) {
                                Text("⬆ Outbound Secure Transits: ${v.outboundShipments}", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Action Section: Vault-to-Vault transfer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        dict["transfer_vault"] ?: "Vault-to-Vault Transfer",
                        fontSize = 13.sp,
                        color = BrushedGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Select physical bar to transfer", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    if (bars.isEmpty()) {
                        Text("No bars available for transfer.", color = TextGray, fontSize = 11.sp)
                    } else {
                        // Radio-like list
                        bars.forEach { b ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedTransferBarId = b.barId }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedTransferBarId == b.barId, onClick = { selectedTransferBarId = b.barId })
                                Text("${b.serialNumber} in ${b.currentVaultId} (${b.grossWeightG}g)", color = WarmWhite, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Select Destination Vault Node", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("SG-01", "MY-01", "TH-01", "ID-01").forEach { vId ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedTargetVaultId == vId) BrushedGold else DarkSteel)
                                    .clickable { selectedTargetVaultId = vId }
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(vId, color = if (selectedTargetVaultId == vId) BlackBg else OffWhiteText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            feedbackMsg = null
                            if (selectedTransferBarId.isEmpty() || selectedTargetVaultId.isEmpty()) {
                                feedbackMsg = "Please specify both bar and target vault."
                                return@Button
                            }
                            val (success, msg) = SimulationEngine.requestVaultTransfer(selectedTransferBarId, selectedTargetVaultId)
                            if (success) {
                                feedbackMsg = msg
                                onActionSuccess(msg)
                            } else {
                                feedbackMsg = msg
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                    ) {
                        Text("Initiate Secure Logistics Pipeline", color = BlackBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Action Section: Delivery request
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        dict["delivery_request"] ?: "Request Physical Delivery",
                        fontSize = 13.sp,
                        color = BrushedGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Select physical bar to withdraw", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))

                    if (bars.isEmpty()) {
                        Text("No bars available for physical release.", color = TextGray, fontSize = 11.sp)
                    } else {
                        bars.forEach { b ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { deliveryBarId = b.barId }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = deliveryBarId == b.barId, onClick = { deliveryBarId = b.barId })
                                Text("${b.serialNumber} (${b.grossWeightG}g)", color = WarmWhite, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Secure Courier Destination Address", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = deliveryAddress,
                        onValueChange = { deliveryAddress = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. Changi Financial Court 4, Singapore") },
                        textStyle = TextStyle(color = WarmWhite)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            feedbackMsg = null
                            if (deliveryBarId.isEmpty() || deliveryAddress.isEmpty()) {
                                feedbackMsg = "Please specify bar and delivery location."
                                return@Button
                            }
                            val (success, msg) = SimulationEngine.requestPhysicalDelivery(deliveryBarId, deliveryAddress, "Singapore")
                            if (success) {
                                feedbackMsg = msg
                                onActionSuccess(msg)
                            } else {
                                feedbackMsg = msg
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                    ) {
                        Text("Verify and Request Handover", color = BlackBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Feedback Text Status
        feedbackMsg?.let { msg ->
            item {
                Text(msg, color = BrushedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// SCRAP BUYBACK TAB
// ==========================================
@Composable
fun ScrapBuybackTab(
    dict: Map<String, String>,
    scrapCases: List<AssayReport>,
    onActionSuccess: (String) -> Unit
) {
    var jewelryDescription by remember { mutableStateOf("") }
    var grossWeightInput by remember { mutableStateOf("45") }
    var selectedKarat by remember { mutableStateOf(18) }

    var latestReport by remember { mutableStateOf<AssayReport?>(null) }
    var feedbackMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                dict["scrap_assay"] ?: "Scrap Gold Assay Engine",
                fontSize = 14.sp,
                color = BrushedGold,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Submit scrap gold, jewellery, and mixed-purity metals for strict high-grade scientific assay assessment.",
                fontSize = 11.sp,
                color = TextGray
            )
        }

        // Submit Item Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("ASSAY TESTING REGISTRATION", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Item Physical Description", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = jewelryDescription,
                        onValueChange = { jewelryDescription = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. Broken 18k chain and ring scrap") },
                        textStyle = TextStyle(color = WarmWhite)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Gross Weight (Grams)", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = grossWeightInput,
                        onValueChange = { grossWeightInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. 45.20") },
                        textStyle = TextStyle(color = WarmWhite)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Declared / Expected Karat Grade", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf(9, 14, 18, 22, 24).forEach { k ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedKarat == k) BrushedGold else DarkSteel)
                                    .clickable { selectedKarat = k }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${k}K", color = if (selectedKarat == k) BlackBg else OffWhiteText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            feedbackMsg = null
                            val weight = grossWeightInput.toBigDecimalOrNull()
                            if (jewelryDescription.isEmpty() || weight == null || weight <= BigDecimal.ZERO) {
                                feedbackMsg = "Please supply valid item specifications."
                                return@Button
                            }
                            val report = SimulationEngine.submitScrapAssay(jewelryDescription, weight, selectedKarat)
                            latestReport = report
                            feedbackMsg = "Scientific X-Ray Fluorescence (XRF) sweep & Fire Assay completed successfully."
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                    ) {
                        Text("Run scientific assay analysis", color = BlackBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Latest Report Result
        latestReport?.let { report ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Graphite)
                        .border(1.dp, BrushedGold, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, "Assay Verified", tint = SafeGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("VERIFIED ASSAY REPORT: ${report.assayId}", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    val rPairs = listOf(
                        "Description" to report.itemDescription,
                        "Gross Weight" to "${report.grossWeightG} g",
                        "Target Purity" to "${report.purityPct}% fine",
                        "XRF Scan Result" to "${report.xrfResultPct}% Gold",
                        "Fire Assay Sweep" to "${report.fireAssayResultPct}% Gold",
                        "Verified Fineness" to "${report.verifiedFineness} PPT",
                        "Absolute Fine Weight" to "${report.fineMetalWeightG} g",
                        "Scientific Confidence" to "${report.confidence.multiply(BigDecimal("100"))}%",
                        "Refining Deduction Fee" to "10.00%"
                    )

                    rPairs.forEach { (lbl, valStr) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(lbl, fontSize = 11.sp, color = TextGray)
                            Text(valStr, fontSize = 11.sp, color = OffWhiteText, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = DarkSteel)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("LIQUID CASH OFFER", fontSize = 12.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                        Text("SGD ${report.valuationAmount}", fontSize = 16.sp, color = BrushedGold, fontWeight = FontWeight.ExtraBold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val (success, msg) = SimulationEngine.acceptScrapOffer(report.assayId)
                            if (success) {
                                latestReport = null
                                onActionSuccess(msg)
                            } else {
                                feedbackMsg = msg
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SafeGreen)
                    ) {
                        Text("Accept scientific valuation & Settle Cash", color = WarmWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Case Ledger history list
        if (scrapCases.isNotEmpty()) {
            item {
                Text("HISTORICAL ASSAY CASES REGISTRY", fontSize = 11.sp, color = TextGray)
            }

            items(scrapCases) { case ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Graphite)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(case.itemDescription, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                        Text("Assay Ref: ${case.assayId} • Fine Weight: ${case.fineMetalWeightG}g", fontSize = 10.sp, color = TextGray)
                    }
                    Text("SGD ${case.valuationAmount}", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                }
            }
        }

        feedbackMsg?.let { msg ->
            item {
                Text(msg, color = BrushedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
