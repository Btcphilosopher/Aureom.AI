package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.math.BigDecimal
import java.math.RoundingMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DealerTerminalScreen() {
    val spotGoldUsd by SimulationEngine.spotXauUsd.collectAsState()
    val spotSilverUsd by SimulationEngine.spotXagUsd.collectAsState()
    val orders by SimulationEngine.orders.collectAsState()
    val rfqs by SimulationEngine.rfqs.collectAsState()
    val vaults by SimulationEngine.vaults.collectAsState()
    val activeShipments by SimulationEngine.activeShipments.collectAsState()
    val auditLogs by SimulationEngine.auditLogs.collectAsState()
    val reconciliationExceptions by SimulationEngine.reconciliationExceptions.collectAsState()
    val reconRunCount by SimulationEngine.reconciliationRunCount.collectAsState()

    var activeSubTab by remember { mutableStateOf("MARKET") } // "MARKET", "LEDGERS", "VAULTS", "RECONCILE", "API_SHELL"
    var commandLineInput by remember { mutableStateOf("") }
    var apiOutputText by remember { mutableStateOf("{\n  \"message\": \"ASEAN AURUM Developer Console. Type a command or run an API endpoint to view high-grade response JSON.\"\n}") }

    var actionFeedbackMsg by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, "Dealer Hub", tint = BrushedGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "INSTITUTIONAL DEALER CORE OPERATING SYSTEM",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrushedGold,
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Graphite)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(BlackBg)
        ) {
            // Live Price Bar Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Graphite)
                    .padding(vertical = 8.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("GOLD SPOT: ", fontSize = 10.sp, color = TextGray)
                    Text("USD $spotGoldUsd /oz", fontSize = 11.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SILVER SPOT: ", fontSize = 10.sp, color = TextGray)
                    Text("USD $spotSilverUsd /oz", fontSize = 11.sp, color = SilverMetallic, fontWeight = FontWeight.Bold)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(BrushedGold)
                        .clickable { SimulationEngine.tickPrices() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("TICK SPOT", color = BlackBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Tabs bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSteel)
            ) {
                val subTabs = listOf(
                    "MARKET" to "Market / RFQ",
                    "LEDGERS" to "Ledgers",
                    "VAULTS" to "Vault Twins",
                    "RECONCILE" to "Reconcile",
                    "API_SHELL" to "API & CLI Console"
                )
                subTabs.forEach { (key, lbl) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeSubTab = key }
                            .background(if (activeSubTab == key) Graphite else Color.Transparent)
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lbl,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeSubTab == key) BrushedGold else OffWhiteText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Main Console Action Areas
            Box(modifier = Modifier.weight(1f)) {
                when (activeSubTab) {
                    "MARKET" -> MarketTab(
                        rfqs = rfqs,
                        orders = orders,
                        onActionFeedback = { actionFeedbackMsg = it }
                    )
                    "LEDGERS" -> LedgersTab(
                        orders = orders,
                        auditLogs = auditLogs
                    )
                    "VAULTS" -> VaultsTab(
                        vaults = vaults,
                        activeShipments = activeShipments,
                        onActionFeedback = { actionFeedbackMsg = it }
                    )
                    "RECONCILE" -> ReconcileTab(
                        exceptions = reconciliationExceptions,
                        reconRunCount = reconRunCount,
                        onActionFeedback = { actionFeedbackMsg = it }
                    )
                    "API_SHELL" -> ApiShellTab(
                        commandInput = commandLineInput,
                        onCommandInputChange = { commandLineInput = it },
                        outputText = apiOutputText,
                        onOutputChange = { apiOutputText = it }
                    )
                }
            }

            // Global Action Status Footer
            actionFeedbackMsg?.let { msg ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Graphite)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(msg, color = BrushedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "DISMISS",
                            color = WarmWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.clickable { actionFeedbackMsg = null }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-TAB: MARKET & RFQ PIPELINE
// ==========================================
@Composable
fun MarketTab(
    rfqs: List<Rfq>,
    orders: List<Order>,
    onActionFeedback: (String) -> Unit
) {
    var customRfqClientName by remember { mutableStateOf("Bangkok Precious Metals Co") }
    var customRfqWeightKg by remember { mutableStateOf("15.00") }
    var rfqMetalSelection by remember { mutableStateOf(Metal.SILVER) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // RFQ Generator Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("BULK RFQ QUOTE INJECTOR (INSTITUTIONAL)", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Institutional Client Entity Name", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = customRfqClientName,
                        onValueChange = { customRfqClientName = it },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(color = WarmWhite)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Total Weight Class (Kg)", fontSize = 10.sp, color = TextGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = customRfqWeightKg,
                                onValueChange = { customRfqWeightKg = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = TextStyle(color = WarmWhite)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Metal Instrument", fontSize = 10.sp, color = TextGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (rfqMetalSelection == Metal.GOLD) BrushedGold else DarkSteel)
                                        .clickable { rfqMetalSelection = Metal.GOLD }
                                        .padding(10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("GOLD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (rfqMetalSelection == Metal.GOLD) BlackBg else OffWhiteText)
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (rfqMetalSelection == Metal.SILVER) SilverMetallic else DarkSteel)
                                        .clickable { rfqMetalSelection = Metal.SILVER }
                                        .padding(10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("SILVER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (rfqMetalSelection == Metal.SILVER) BlackBg else OffWhiteText)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val weight = customRfqWeightKg.toBigDecimalOrNull()
                            if (customRfqClientName.isEmpty() || weight == null || weight <= BigDecimal.ZERO) {
                                onActionFeedback("Please supply correct institutional specifications.")
                                return@Button
                            }
                            val createdRfq = SimulationEngine.requestInstitutionalRfq(
                                clientName = customRfqClientName,
                                metal = rfqMetalSelection,
                                weightKg = weight,
                                currency = "USD",
                                vaultId = "SG-01"
                            )
                            onActionFeedback("RFQ Generated. Spot quoted at USD ${createdRfq.spotPricePerKg}/Kg.")
                        },
                        modifier = Modifier.fillMaxWidth().testTag("dealer_rfq_generate"),
                        colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
                    ) {
                        Text("Inject RFQ request into pipeline", color = BlackBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active RFQ pipeline list
        item {
            Text("ACTIVE RFQ QUOTATION PIPELINE", fontSize = 11.sp, color = TextGray)
        }

        if (rfqs.isEmpty()) {
            item {
                Text(
                    "No active institutional RFQs inside the pricing queue. Generate one above.",
                    color = TextGray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                )
            }
        } else {
            items(rfqs) { rfq ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Graphite)
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(rfq.clientName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                                Text("RFQ ID: ${rfq.rfqId} • Weight: ${rfq.weightKg}Kg ${rfq.metal.name}", fontSize = 10.sp, color = TextGray)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (rfq.status == RfqStatus.EXECUTED) SafeGreen else DarkSteel)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(rfq.status.name, color = BrushedGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Spot: USD ${rfq.spotPricePerKg}/Kg", fontSize = 11.sp, color = OffWhiteText)
                            Text("Total Quote: USD ${rfq.totalQuoteAmount}", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.ExtraBold)
                        }

                        if (rfq.status == RfqStatus.QUOTED) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = {
                                        val (success, msg) = SimulationEngine.acceptRfqQuote(rfq.rfqId)
                                        onActionFeedback(msg)
                                    },
                                    modifier = Modifier.weight(1f).height(38.dp).testTag("dealer_accept_rfq"),
                                    colors = ButtonDefaults.buttonColors(containerColor = SafeGreen)
                                ) {
                                    Text("ACCEPT & EXECUTE QUOTE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-TAB: LEDGERS EXPLORER
// ==========================================
@Composable
fun LedgersTab(
    orders: List<Order>,
    auditLogs: List<AuditRecord>
) {
    var filterByRole by remember { mutableStateOf("ALL") } // "ALL", "TRADES", "AUDIT"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Filter Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            listOf("ALL" to "All Logs", "TRADES" to "Order Ledger", "AUDIT" to "Immutable Audits").forEach { (key, lbl) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { filterByRole = key }
                        .background(if (filterByRole == key) BrushedGold else Graphite)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(lbl, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (filterByRole == key) BlackBg else OffWhiteText)
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (filterByRole == "ALL" || filterByRole == "TRADES") {
                item {
                    Text("ORDER BOOK & LEDGERS RECORD", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
                }
                if (orders.isEmpty()) {
                    item {
                        Text("No trades recorded.", color = TextGray, fontSize = 11.sp, modifier = Modifier.padding(12.dp))
                    }
                } else {
                    items(orders) { o ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Graphite)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(o.type.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                                Text("ID: ${o.orderId} • ${o.quantityG}g ${o.metal} in ${o.vaultId}", fontSize = 10.sp, color = TextGray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${MockData.getCurrencySymbol(o.currency)}${o.totalValuation}", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                                Text(o.status.name, fontSize = 9.sp, color = SafeGreen)
                            }
                        }
                    }
                }
            }

            if (filterByRole == "ALL" || filterByRole == "AUDIT") {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("IMMUTABLE SYSTEM AUDIT TRAIL (WHO / WHAT / WHEN)", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
                }
                items(auditLogs) { a ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSteel)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(a.action, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                            Text(a.timestamp, fontSize = 9.sp, color = TextGray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(a.details, fontSize = 11.sp, color = OffWhiteText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Actor: ${a.actor}", fontSize = 9.sp, color = TextGray)
                            Text("Request Ref: ${a.apiRequestRef}", fontSize = 9.sp, color = TextGray)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-TAB: VAULT TWINS OPERATIONS
// ==========================================
@Composable
fun VaultsTab(
    vaults: List<Vault>,
    activeShipments: List<VaultMovement>,
    onActionFeedback: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("VAULT DIGITAL TWIN TELEMETRY", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
        }

        items(vaults) { v ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Graphite)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(v.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                    Text("Gold: ${v.goldTonnage}t • Silver: ${v.silverTonnage}t • Bars: ${v.barCount}", fontSize = 10.sp, color = TextGray)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkSteel)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    val capPct = v.occupiedCapacityKg.divide(v.totalCapacityKg, 4, RoundingMode.HALF_UP).multiply(BigDecimal("100")).setScale(1, RoundingMode.HALF_UP)
                    Text("$capPct% Vol", fontSize = 10.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("SECURE SHIPMENTS LOGISTICS PIPE", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
        }

        if (activeShipments.isEmpty()) {
            item {
                Text("No active inter-vault logistics flights detected.", color = TextGray, fontSize = 11.sp)
            }
        } else {
            items(activeShipments) { movement ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkSteel)
                        .padding(10.dp)
                ) {
                    Text("Secure Transit Ref: ${movement.movementId}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Item: Bar ${movement.barId} (${movement.metal})", fontSize = 11.sp, color = OffWhiteText)
                    Text("Route: ${movement.fromVaultId} ➜ ${movement.toVaultId}", fontSize = 11.sp, color = OffWhiteText)
                    Text("Carrier: ${movement.shippingProvider} • Customs Code: ${movement.customsDeclarationRef}", fontSize = 10.sp, color = TextGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            SimulationEngine.completeTransferShipment(movement.movementId)
                            onActionFeedback("Secure transfer ${movement.movementId} successfully received and audited at target facility.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SafeGreen),
                        modifier = Modifier.fillMaxWidth().height(36.dp)
                    ) {
                        Text("SIMULATE SIGN-OFF / RECEIVED AT DESTINATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-TAB: RECONCILIATION & ALARMS
// ==========================================
@Composable
fun ReconcileTab(
    exceptions: List<String>,
    reconRunCount: Int,
    onActionFeedback: (String) -> Unit
) {
    var simMissingBar by remember { mutableStateOf(SimulationEngine.simulateMissingBarError) }
    var simDuplicateSerial by remember { mutableStateOf(SimulationEngine.simulateDuplicateSerialError) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("MULTI-TIER INTEGRITY RECONCILIATION ENGINE", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Runs a full real-time cross-comparison: Physical Assets vs Book-Entry Ledger vs Customer Accounts.", fontSize = 11.sp, color = TextGray)
        }

        // Toggles for artificial error simulators
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Graphite)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("SIMULATE ARCHITECTURAL EXCEPTIONS (FOR DEMO)", fontSize = 10.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Simulate Missing Vault RFID Bar (SG-004821)", fontSize = 11.sp, color = OffWhiteText)
                        Switch(
                            checked = simMissingBar,
                            onCheckedChange = {
                                simMissingBar = it
                                SimulationEngine.simulateMissingBarError = it
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Simulate Duplicate Serial conflict (MY-112233)", fontSize = 11.sp, color = OffWhiteText)
                        Switch(
                            checked = simDuplicateSerial,
                            onCheckedChange = {
                                simDuplicateSerial = it
                                SimulationEngine.simulateDuplicateSerialError = it
                            }
                        )
                    }
                }
            }
        }

        // Reconciliation Trigger Button
        item {
            Button(
                onClick = {
                    val exList = SimulationEngine.runReconciliation()
                    if (exList.isEmpty()) {
                        onActionFeedback("Reconciliation #$reconRunCount: SUCCESS. 100% relational integrity verified.")
                    } else {
                        onActionFeedback("Reconciliation #$reconRunCount: ENCOUNTERED ${exList.size} DISCREPANCY EXCEPTIONS!")
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
            ) {
                Text("RUN DUAL-LEDGER AUDIT COMPILATION", color = BlackBg, fontWeight = FontWeight.Bold)
            }
        }

        // Alarm exceptions results
        item {
            Text("ALARM EXCEPTIONS REGISTERED (${exceptions.size})", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.Bold)
        }

        if (exceptions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(SafeGreen.copy(alpha = 0.2f))
                        .padding(14.dp)
                ) {
                    Text("✔ ALL AUDITED BALANCES MATCH UNDERLYING COUSTODY. ZERO INVENTORY MISMATCHES REPORTED.", color = BrushedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            items(exceptions) { ex ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(RestrainedRed.copy(alpha = 0.2f))
                        .border(1.dp, RestrainedRed, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, "Exception Alarm", tint = Color.Red, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(ex, color = OffWhiteText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-TAB: DEVELOPER API & CLI EMULATOR
// ==========================================
@Composable
fun ApiShellTab(
    commandInput: String,
    onCommandInputChange: (String) -> Unit,
    outputText: String,
    onOutputChange: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("ASEAN PRECIOUS-METALS INFRASTRUCTURE API", fontSize = 12.sp, color = BrushedGold, fontWeight = FontWeight.Bold)
        Text("Quick-test high-grade institutional endpoints or system commands:", fontSize = 11.sp, color = TextGray)

        // API Endpoint Quick Access Rows
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val ep1 = "GET /api/v1/prices"
            val ep2 = "GET /api/v1/vaults"
            Button(
                onClick = {
                    onOutputChange("{\n  \"status\": \"success\",\n  \"benchmark_market_feed\": {\n    \"XAU_USD\": \"${SimulationEngine.spotXauUsd.value}\",\n    \"XAG_USD\": \"${SimulationEngine.spotXagUsd.value}\"\n  },\n  \"local_pricing_sgd\": {\n    \"gold_100g\": \"${SimulationEngine.calculateLocalPrice(Metal.GOLD, "SGD", "Singapore", BigDecimal("100"))["finalPricePerGram"]}\",\n    \"silver_1kg\": \"${SimulationEngine.calculateLocalPrice(Metal.SILVER, "SGD", "Singapore", BigDecimal("1000"))["finalPricePerGram"]}\"\n  }\n}")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSteel)
            ) {
                Text(ep1, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = BrushedGold)
            }
            Button(
                onClick = {
                    val firstV = SimulationEngine.vaults.value.first()
                    onOutputChange("{\n  \"status\": \"success\",\n  \"vaults_node_count\": 11,\n  \"primary_central_hub\": {\n    \"id\": \"${firstV.vaultId}\",\n    \"name\": \"${firstV.name}\",\n    \"gold_tonnage\": ${firstV.goldTonnage},\n    \"silver_tonnage\": ${firstV.silverTonnage},\n    \"occupied_capacity_kg\": ${firstV.occupiedCapacityKg}\n  }\n}")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSteel)
            ) {
                Text(ep2, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = BrushedGold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val ep3 = "POST /api/v1/reconcile"
            val ep4 = "GET /api/v1/bars"
            Button(
                onClick = {
                    onOutputChange("{\n  \"status\": \"success\",\n  \"reconciliation_checksum\": \"0x8AE92B19F\",\n  \"exceptions_found_count\": ${SimulationEngine.reconciliationExceptions.value.size},\n  \"timestamp\": \"2026-10-06T01:06:00Z\"\n}")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSteel)
            ) {
                Text(ep3, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = BrushedGold)
            }
            Button(
                onClick = {
                    val firstBar = SimulationEngine.bars.value.first()
                    onOutputChange("{\n  \"status\": \"success\",\n  \"total_bars_registered\": ${SimulationEngine.bars.value.size},\n  \"sample_metal_passport\": {\n    \"id\": \"${firstBar.barId}\",\n    \"serial\": \"${firstBar.serialNumber}\",\n    \"metal\": \"${firstBar.metal}\",\n    \"purity\": ${firstBar.purity},\n    \"refiner\": \"${firstBar.refiner}\",\n    \"custody\": \"${firstBar.custodyStatus}\"\n  }\n}")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSteel)
            ) {
                Text(ep4, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = BrushedGold)
            }
        }

        // CLI Quick Access Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Button(
                onClick = {
                    onCommandInputChange("aurum reconcile")
                    onOutputChange("+------------------+-----------------------+--------+\n| VALIDATION NODE  | AUDITED SYSTEM CHECK  | STATUS |\n+------------------+-----------------------+--------+\n| METALS LEDGER    | Physical vs Custody   | OK     |\n| CASH WALLET      | Balance settlement    | OK     |\n| CORE COMPLIANCE  | Zero exceptions found | OK     |\n+------------------+-----------------------+--------+")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MediumSteel)
            ) {
                Text("aurum reconcile", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
            }
            Button(
                onClick = {
                    onCommandInputChange("aurum risk")
                    onOutputChange("=== REGIONAL PRECIOUS-METALS RISK ANALYSIS ===\nGlobal Price Exposure: SGD 14.8M\nCapital Collateralized: 98.4%\nTotal Vault Insurance: Active (LMG Underwriters)\nOperational Threat Level: MINIMAL")
                },
                modifier = Modifier.weight(1f).height(34.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MediumSteel)
            ) {
                Text("aurum risk", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
            }
        }

        // Text Input CLI shell
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = onCommandInputChange,
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(color = WarmWhite, fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                placeholder = { Text("Enter CLI Command e.g. aurum reconcile", fontSize = 11.sp) }
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    val raw = commandInput.trim().lowercase()
                    if (raw.contains("reconcile") || raw.contains("audit")) {
                        onOutputChange("Executing CLI 'aurum reconcile'...\nReconciling 11 hubs and ${SimulationEngine.bars.value.size} bars.\nFound ${SimulationEngine.reconciliationExceptions.value.size} integrity errors.")
                    } else if (raw.contains("risk") || raw.contains("scenario")) {
                        onOutputChange("Executing CLI 'aurum risk'...\nGenerating Stress Test:\nGold +25% Scenario: Portfolio appreciation of SGD 1,489,112.44.\nMYR Shock: Zero impact due to SGD central clearing hub.")
                    } else if (raw.contains("help") || raw.isEmpty()) {
                        onOutputChange("Available aurum CLI tools:\n  aurum prices      - Live metals indices\n  aurum reconcile   - Integrity check\n  aurum risk        - Stress metrics\n  aurum simulate    - Re-seed engine")
                    } else {
                        onOutputChange("aurum command unrecognized. Type 'help' to audit standard tools.")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrushedGold)
            ) {
                Text("RUN", color = BlackBg, fontWeight = FontWeight.Bold)
            }
        }

        // Output Code Block panel (Parchment background style or terminal look)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(Graphite)
                .border(1.dp, MediumSteel, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text(
                text = outputText,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = OffWhiteText,
                lineHeight = 15.sp,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
