package com.example.data

import java.math.BigDecimal
import java.math.RoundingMode

enum class Metal {
    GOLD, SILVER
}

enum class AllocationStatus {
    ALLOCATED,
    UNALLOCATED,
    PENDING_ALLOCATION
}

enum class CustodyStatus {
    VAULTED,
    IN_TRANSIT,
    RELEASED
}

enum class EncumbranceStatus {
    FREE,
    RESERVED,
    PLEDGED
}

data class MetalObject(
    val barId: String,
    val serialNumber: String,
    val metal: Metal,
    val refiner: String,
    val brand: String,
    val purity: BigDecimal, // e.g. 999.9 or 999.0
    val grossWeightG: BigDecimal, // weight in grams
    val fineWeightG: BigDecimal = grossWeightG.multiply(purity.divide(BigDecimal("1000.0"), 6, RoundingMode.HALF_UP)),
    val manufactureYear: Int,
    val assayReference: String,
    val origin: String,
    var currentVaultId: String,
    var ownerId: String, // "user" or "dealer" or "refiner"
    var allocationStatus: AllocationStatus,
    var custodyStatus: CustodyStatus,
    var encumbranceStatus: EncumbranceStatus = EncumbranceStatus.FREE,
    val inspectionStatus: String = "VERIFIED_AUDITED",
    val allocationDate: String = "2026-05-15"
)

data class MetalAccount(
    val metal: Metal,
    var totalWeightG: BigDecimal,
    var avgAcquisitionPrice: BigDecimal, // in base currency (e.g. SGD/g)
    var allocatedWeightG: BigDecimal,
    var unallocatedWeightG: BigDecimal
) {
    fun currentValuation(livePricePerGram: BigDecimal): BigDecimal {
        return totalWeightG.multiply(livePricePerGram).setScale(2, RoundingMode.HALF_UP)
    }
}

data class CashAccount(
    val currency: String,
    var totalBalance: BigDecimal,
    var availableBalance: BigDecimal,
    var reservedBalance: BigDecimal,
    var pendingSettlement: BigDecimal = BigDecimal.ZERO
)

data class Vault(
    val vaultId: String,
    val name: String,
    val city: String,
    val country: String,
    val totalCapacityKg: BigDecimal,
    var occupiedCapacityKg: BigDecimal,
    var goldTonnage: BigDecimal,
    var silverTonnage: BigDecimal,
    var barCount: Int,
    var containerCount: Int,
    val securityState: String, // "MAXIMUM_SECURITY_ACTIVE"
    val inspectionStatus: String, // "CERTIFIED_AUDITED_OCT_2026"
    var inboundShipments: Int = 0,
    var outboundShipments: Int = 0,
    var pendingAllocations: Int = 0,
    var pendingReleases: Int = 0,
    val isDemoFacility: Boolean = true
)

enum class OrderType {
    MARKET_BUY,
    MARKET_SELL,
    LIMIT_BUY,
    LIMIT_SELL,
    RFQ_EXECUTION,
    VAULT_TRANSFER,
    PHYSICAL_DELIVERY
}

enum class OrderStatus {
    NEW,
    VALIDATED,
    QUOTED,
    ACCEPTED,
    EXECUTED,
    ALLOCATED,
    SETTLED,
    DELIVERED,
    CANCELLED,
    FAILED
}

data class Order(
    val orderId: String,
    val type: OrderType,
    val metal: Metal,
    val quantityG: BigDecimal,
    val pricePerGram: BigDecimal,
    val premiumValue: BigDecimal,
    val totalValuation: BigDecimal,
    val currency: String,
    var status: OrderStatus,
    val vaultId: String,
    val serialNumber: String? = null,
    val timestamp: String,
    val correlationId: String,
    val clientName: String = "Kuala Lumpur Retail Client"
)

enum class RfqStatus {
    PENDING,
    QUOTED,
    ACCEPTED,
    EXPIRED,
    EXECUTED
}

data class Rfq(
    val rfqId: String,
    val clientName: String,
    val metal: Metal,
    val weightKg: BigDecimal,
    val currency: String,
    var spotPricePerKg: BigDecimal,
    var premiumPerKg: BigDecimal,
    var quotePricePerKg: BigDecimal,
    var totalQuoteAmount: BigDecimal,
    val validUntil: String,
    var status: RfqStatus,
    val targetVaultId: String,
    val responseTimeSeconds: Int = 3
)

data class LedgerEntry(
    val entryId: String,
    val accountId: String, // "user" or "dealer"
    val metal: Metal?, // null if purely cash ledger
    val quantity: BigDecimal, // positive or negative
    val unit: String, // "g" or "SGD" or "MYR" etc.
    val valuation: BigDecimal,
    val currency: String,
    val timestamp: String,
    val eventId: String,
    val reference: String,
    val actor: String
)

data class AuditRecord(
    val auditId: String,
    val timestamp: String,
    val actor: String,
    val action: String,
    val details: String,
    val accountId: String,
    val targetVaultId: String?,
    val targetBarId: String?,
    val apiRequestRef: String
)

data class ComplianceRule(
    val policyName: String,
    val jurisdiction: String,
    val ruleCode: String,
    val threshold: BigDecimal,
    val description: String,
    val isMandatory: Boolean = true
)

enum class AssayStatus {
    PENDING,
    TESTING,
    VERIFIED,
    FAILED,
    REQUIRES_REVIEW
}

data class AssayReport(
    val assayId: String,
    val itemDescription: String, // "Broken Jewelry" or "Scrap 18k Ring"
    val grossWeightG: BigDecimal,
    val purityPct: BigDecimal, // expected purity e.g. 75.0% for 18k
    val xrfResultPct: BigDecimal,
    val fireAssayResultPct: BigDecimal,
    val verifiedFineness: BigDecimal,
    val fineMetalWeightG: BigDecimal,
    val valuationAmount: BigDecimal,
    val currency: String,
    val confidence: BigDecimal, // 0.00 to 1.00
    var status: AssayStatus,
    val timestamp: String
)

data class VaultMovement(
    val movementId: String,
    val barId: String,
    val metal: Metal,
    val fromVaultId: String,
    val toVaultId: String,
    val status: String, // "IN_TRANSIT" or "COMPLETED"
    val estimatedArrival: String,
    val shippingProvider: String = "BRINKS_SECURE_LOGISTICS",
    val customsDeclarationRef: String
)
