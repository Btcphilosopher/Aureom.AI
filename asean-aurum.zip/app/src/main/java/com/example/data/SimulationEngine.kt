package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

object SimulationEngine {

    // 1. Live Global Benchmark Prices (Spot in USD/oz)
    private val _spotXauUsd = MutableStateFlow(BigDecimal("2645.50")) // Gold spot per oz
    val spotXauUsd: StateFlow<BigDecimal> = _spotXauUsd.asStateFlow()

    private val _spotXagUsd = MutableStateFlow(BigDecimal("31.25")) // Silver spot per oz
    val spotXagUsd: StateFlow<BigDecimal> = _spotXagUsd.asStateFlow()

    // 2. Live FX Rates (Base is 1 USD)
    val fxRates = mapOf(
        "USD" to BigDecimal("1.0000"),
        "SGD" to BigDecimal("1.3410"),
        "MYR" to BigDecimal("4.2250"),
        "THB" to BigDecimal("33.1500"),
        "IDR" to BigDecimal("15480.00"),
        "VND" to BigDecimal("24510.00"),
        "PHP" to BigDecimal("56.8200")
    )

    // Grams in 1 Troy Ounce
    private val OZ_TO_GRAMS = BigDecimal("31.1034768")

    // Regional Premium Configs (expressed in USD per gram)
    val regionalPremiums = mapOf(
        "Singapore" to BigDecimal("1.20"), // Premium logistics center
        "Malaysia" to BigDecimal("1.80"),
        "Thailand" to BigDecimal("2.10"),
        "Indonesia" to BigDecimal("2.50"),
        "Vietnam" to BigDecimal("3.40"), // High regulatory barrier
        "Philippines" to BigDecimal("2.80")
    )

    // Bar Weight Premiums (percent of base cost)
    fun getProductPremiumPercent(weightG: BigDecimal): BigDecimal {
        return when {
            weightG <= BigDecimal("1.00") -> BigDecimal("0.08")  // 8% premium for 1g bar
            weightG <= BigDecimal("10.00") -> BigDecimal("0.05") // 5% for 10g
            weightG <= BigDecimal("100.00") -> BigDecimal("0.025") // 2.5% for 100g
            weightG <= BigDecimal("1000.00") -> BigDecimal("0.015") // 1.5% for 1kg
            else -> BigDecimal("0.008") // 0.8% for bulk/institutional bars
        }
    }

    // --- Dynamic Mutable Database States ---
    private val _bars = MutableStateFlow(MockData.initialBars.toList())
    val bars: StateFlow<List<MetalObject>> = _bars.asStateFlow()

    private val _vaults = MutableStateFlow(MockData.initialVaults.toList())
    val vaults: StateFlow<List<Vault>> = _vaults.asStateFlow()

    // Metal & Cash Accounts for Client
    private val _clientGoldAccount = MutableStateFlow(
        MetalAccount(Metal.GOLD, BigDecimal("2150.00"), BigDecimal("98.15"), BigDecimal("2150.00"), BigDecimal.ZERO)
    )
    val clientGoldAccount: StateFlow<MetalAccount> = _clientGoldAccount.asStateFlow()

    private val _clientSilverAccount = MutableStateFlow(
        MetalAccount(Metal.SILVER, BigDecimal("1000.00"), BigDecimal("1.12"), BigDecimal("1000.00"), BigDecimal.ZERO)
    )
    val clientSilverAccount: StateFlow<MetalAccount> = _clientSilverAccount.asStateFlow()

    private val _clientCashAccounts = MutableStateFlow(
        mapOf(
            "SGD" to CashAccount("SGD", BigDecimal("24850.00"), BigDecimal("24850.00"), BigDecimal.ZERO),
            "MYR" to CashAccount("MYR", BigDecimal("15000.00"), BigDecimal("15000.00"), BigDecimal.ZERO),
            "THB" to CashAccount("THB", BigDecimal("120000.00"), BigDecimal("120000.00"), BigDecimal.ZERO),
            "USD" to CashAccount("USD", BigDecimal("5000.00"), BigDecimal("5000.00"), BigDecimal.ZERO)
        )
    )
    val clientCashAccounts: StateFlow<Map<String, CashAccount>> = _clientCashAccounts.asStateFlow()

    // Order Book
    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    // RFQ Queue
    private val _rfqs = MutableStateFlow<List<Rfq>>(emptyList())
    val rfqs: StateFlow<List<Rfq>> = _rfqs.asStateFlow()

    // Ledgers (Cash, Metal, Custody, Settlement)
    private val _ledgerEntries = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerEntries: StateFlow<List<LedgerEntry>> = _ledgerEntries.asStateFlow()

    // Compliance Cases Alert List
    private val _complianceAlerts = MutableStateFlow<List<String>>(emptyList())
    val complianceAlerts: StateFlow<List<String>> = _complianceAlerts.asStateFlow()

    // Immutable Audit Logs
    private val _auditLogs = MutableStateFlow<List<AuditRecord>>(listOf(
        AuditRecord("AUD-001", "2026-10-06 01:00:00", "SYSTEM_INIT", "LEDGER_BOOTSTRAP", "All multi-currency ledger engines booted. Zero errors.", "system", null, null, "REQ-0001")
    ))
    val auditLogs: StateFlow<List<AuditRecord>> = _auditLogs.asStateFlow()

    // Scrap Gold Buyback Cases
    private val _scrapCases = MutableStateFlow<List<AssayReport>>(emptyList())
    val scrapCases: StateFlow<List<AssayReport>> = _scrapCases.asStateFlow()

    // Vault-to-Vault Active Shipments
    private val _activeShipments = MutableStateFlow<List<VaultMovement>>(emptyList())
    val activeShipments: StateFlow<List<VaultMovement>> = _activeShipments.asStateFlow()

    // Reconciliation Exceptions State
    private val _reconciliationExceptions = MutableStateFlow<List<String>>(emptyList())
    val reconciliationExceptions: StateFlow<List<String>> = _reconciliationExceptions.asStateFlow()

    private var _reconciliationRunCount = MutableStateFlow(0)
    val reconciliationRunCount: StateFlow<Int> = _reconciliationRunCount.asStateFlow()

    // Artificial error flags for testing Reconciliation
    var simulateMissingBarError = false
    var simulateDuplicateSerialError = false

    // --- Market Tick Loop ---
    fun tickPrices() {
        val multiplierXau = BigDecimal("1.000") + BigDecimal((Math.random() * 0.002 - 0.001).toString())
        val multiplierXag = BigDecimal("1.000") + BigDecimal((Math.random() * 0.004 - 0.002).toString())

        _spotXauUsd.value = _spotXauUsd.value.multiply(multiplierXau).setScale(2, RoundingMode.HALF_UP)
        _spotXagUsd.value = _spotXagUsd.value.multiply(multiplierXag).setScale(2, RoundingMode.HALF_UP)
    }

    // --- Dynamic Transparent Pricing Engine ---
    fun calculateLocalPrice(
        metal: Metal,
        currency: String,
        country: String,
        weightG: BigDecimal
    ): Map<String, BigDecimal> {
        val spotUsdOz = if (metal == Metal.GOLD) _spotXauUsd.value else _spotXagUsd.value
        val spotUsdG = spotUsdOz.divide(OZ_TO_GRAMS, 6, RoundingMode.HALF_UP)
        
        val fxRate = fxRates[currency] ?: BigDecimal("1.0000")
        val localSpotG = spotUsdG.multiply(fxRate)

        val regionalPremiumUsd = regionalPremiums[country] ?: BigDecimal("2.00")
        val localRegionalPremiumG = regionalPremiumUsd.multiply(fxRate)

        val baseLocalG = localSpotG.add(localRegionalPremiumG)
        val productPremiumPct = getProductPremiumPercent(weightG)
        val localBarPremiumG = baseLocalG.multiply(productPremiumPct)

        val vaultFeeG = baseLocalG.multiply(BigDecimal("0.001")) // 0.1% custody fee pre-included
        val dealerSpreadG = baseLocalG.multiply(BigDecimal("0.005")) // 0.5% standard spread

        val totalPriceG = baseLocalG.add(localBarPremiumG).add(vaultFeeG).add(dealerSpreadG)
        val totalValuation = totalPriceG.multiply(weightG).setScale(2, RoundingMode.HALF_UP)

        return mapOf(
            "spotGram" to localSpotG.setScale(4, RoundingMode.HALF_UP),
            "regionalPremium" to localRegionalPremiumG.setScale(4, RoundingMode.HALF_UP),
            "barPremium" to localBarPremiumG.setScale(4, RoundingMode.HALF_UP),
            "vaultFee" to vaultFeeG.setScale(4, RoundingMode.HALF_UP),
            "dealerSpread" to dealerSpreadG.setScale(4, RoundingMode.HALF_UP),
            "finalPricePerGram" to totalPriceG.setScale(4, RoundingMode.HALF_UP),
            "totalValuation" to totalValuation
        )
    }

    // --- KYC / AML Compliance Screening Adapter ---
    fun screenTransaction(country: String, amount: BigDecimal, currency: String): String? {
        val convertedAmountSgd = if (currency == "SGD") amount else {
            val fxToSgd = (fxRates["SGD"] ?: BigDecimal.ONE).divide(fxRates[currency] ?: BigDecimal.ONE, 6, RoundingMode.HALF_UP)
            amount.multiply(fxToSgd)
        }
        
        // Find if any mandatory threshold is breached
        val breachedRule = MockData.complianceRules.find { rule ->
            rule.jurisdiction == country && convertedAmountSgd >= rule.threshold && rule.threshold > BigDecimal.ZERO
        }
        return breachedRule?.description
    }

    // --- Order Execution Mechanics ---
    fun executeBuy(
        metal: Metal,
        country: String,
        weightG: BigDecimal,
        currency: String,
        vaultId: String
    ): Pair<Boolean, String> {
        val priceMetrics = calculateLocalPrice(metal, currency, country, weightG)
        val totalValuation = priceMetrics["totalValuation"] ?: return Pair(false, "Pricing calculations failed.")

        // 1. Check Compliance
        val complianceBlock = screenTransaction(country, totalValuation, currency)
        if (complianceBlock != null) {
            val alertMsg = "COMPLIANCE SUSPENSION: $complianceBlock"
            val updatedAlerts = _complianceAlerts.value.toMutableList()
            updatedAlerts.add("[ALERT] ${country} Refusal - Valued at $currency $totalValuation")
            _complianceAlerts.value = updatedAlerts
            
            logAudit("COMPLIANCE_BLOCKED", "Trade blocked by AML filter.", "CLIENT_01", vaultId, null)
            return Pair(false, alertMsg)
        }

        // 2. Check Cash Funds
        val cashWallet = _clientCashAccounts.value[currency] ?: return Pair(false, "Wallet currency not available.")
        if (cashWallet.availableBalance < totalValuation) {
            return Pair(false, "Insufficient balance in multi-currency wallet. Required: $currency $totalValuation")
        }

        // 3. Complete Transfer of Cash & Allocation of Metal
        val originalCash = _clientCashAccounts.value.toMutableMap()
        val wallet = originalCash[currency]!!
        wallet.totalBalance = wallet.totalBalance.subtract(totalValuation)
        wallet.availableBalance = wallet.availableBalance.subtract(totalValuation)
        _clientCashAccounts.value = originalCash

        // Increase customer metal balance
        if (metal == Metal.GOLD) {
            val acc = _clientGoldAccount.value
            acc.totalWeightG = acc.totalWeightG.add(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.add(weightG)
            _clientGoldAccount.value = acc.copy()
        } else {
            val acc = _clientSilverAccount.value
            acc.totalWeightG = acc.totalWeightG.add(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.add(weightG)
            _clientSilverAccount.value = acc.copy()
        }

        // 4. Create Physical Bar Representation & Assign it (Allocated)
        val orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val correlationId = "COR-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val barId = "BAR-SG-" + UUID.randomUUID().toString().substring(0, 6).uppercase()
        val serialNum = "SG-" + (100000 + (Math.random() * 899999).toInt())

        val assignedBar = MetalObject(
            barId = barId,
            serialNumber = serialNum,
            metal = metal,
            refiner = "Metalor Singapore Ltd",
            brand = "ASEAN AURUM STANDARD",
            purity = if (metal == Metal.GOLD) BigDecimal("999.9") else BigDecimal("999.0"),
            grossWeightG = weightG,
            manufactureYear = 2026,
            assayReference = "ASSAY-" + UUID.randomUUID().toString().substring(0, 6).uppercase(),
            origin = "$country Hub Refinery",
            currentVaultId = vaultId,
            ownerId = "user",
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        )

        val updatedBars = _bars.value.toMutableList()
        updatedBars.add(assignedBar)
        _bars.value = updatedBars

        // 5. Update Vault Capacities
        val updatedVaults = _vaults.value.map { vault ->
            if (vault.vaultId == vaultId) {
                val addedKg = weightG.divide(BigDecimal("1000.0"), 6, RoundingMode.HALF_UP)
                vault.copy(
                    occupiedCapacityKg = vault.occupiedCapacityKg.add(addedKg),
                    goldTonnage = if (metal == Metal.GOLD) vault.goldTonnage.add(addedKg.divide(BigDecimal("1000.0"), 6, RoundingMode.HALF_UP)) else vault.goldTonnage,
                    silverTonnage = if (metal == Metal.SILVER) vault.silverTonnage.add(addedKg.divide(BigDecimal("1000.0"), 6, RoundingMode.HALF_UP)) else vault.silverTonnage,
                    barCount = vault.barCount + 1
                )
            } else vault
        }
        _vaults.value = updatedVaults

        // 6. Record Ledger Entry
        val entryId = "LED-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val ledgerLogs = _ledgerEntries.value.toMutableList()
        ledgerLogs.add(
            LedgerEntry(
                entryId = entryId,
                accountId = "user",
                metal = metal,
                quantity = weightG,
                unit = "g",
                valuation = totalValuation,
                currency = currency,
                timestamp = "2026-10-06 01:06:00",
                eventId = orderId,
                reference = assignedBar.serialNumber,
                actor = "CLIENT_TRADE_PORTAL"
            )
        )
        _ledgerEntries.value = ledgerLogs

        // 7. Save Order
        val order = Order(
            orderId = orderId,
            type = OrderType.MARKET_BUY,
            metal = metal,
            quantityG = weightG,
            pricePerGram = priceMetrics["finalPricePerGram"] ?: BigDecimal.ZERO,
            premiumValue = priceMetrics["barPremium"] ?: BigDecimal.ZERO,
            totalValuation = totalValuation,
            currency = currency,
            status = OrderStatus.SETTLED,
            vaultId = vaultId,
            serialNumber = assignedBar.serialNumber,
            timestamp = "2026-10-06 01:06:00",
            correlationId = correlationId
        )
        _orders.value = listOf(order) + _orders.value

        logAudit("TRADE_EXECUTED", "Metal allocated and assigned. Serial: ${assignedBar.serialNumber}", "user", vaultId, barId)
        return Pair(true, "Successfully purchased and allocated physical bar ${assignedBar.serialNumber} in vault $vaultId.")
    }

    // --- Sell Allocated Metal Mechanics ---
    fun executeSell(
        barId: String,
        settlementCurrency: String,
        settlementCountry: String
    ): Pair<Boolean, String> {
        val bar = _bars.value.find { it.barId == barId && it.ownerId == "user" }
            ?: return Pair(false, "Bar is not in user possession or not found.")

        val metal = bar.metal
        val weightG = bar.grossWeightG

        val priceMetrics = calculateLocalPrice(metal, settlementCurrency, settlementCountry, weightG)
        val rawValuation = priceMetrics["totalValuation"] ?: return Pair(false, "Valuation calculations failed.")

        // Apply Dealer Bid Spread Discount
        val discount = rawValuation.multiply(BigDecimal("0.01")) // 1% liquidity adjustment for sell-back
        val finalSettlementCash = rawValuation.subtract(discount).setScale(2, RoundingMode.HALF_UP)

        // 1. Remove/Deallocate Bar
        val updatedBars = _bars.value.map { b ->
            if (b.barId == barId) {
                b.copy(ownerId = "dealer", allocationStatus = AllocationStatus.UNALLOCATED)
            } else b
        }
        _bars.value = updatedBars

        // 2. Reduce Client Metal Balances
        if (metal == Metal.GOLD) {
            val acc = _clientGoldAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientGoldAccount.value = acc.copy()
        } else {
            val acc = _clientSilverAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientSilverAccount.value = acc.copy()
        }

        // 3. Deposit Settlement Cash
        val originalCash = _clientCashAccounts.value.toMutableMap()
        val wallet = originalCash[settlementCurrency] ?: CashAccount(settlementCurrency, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO)
        wallet.totalBalance = wallet.totalBalance.add(finalSettlementCash)
        wallet.availableBalance = wallet.availableBalance.add(finalSettlementCash)
        originalCash[settlementCurrency] = wallet
        _clientCashAccounts.value = originalCash

        // 4. Update Vault Metrics (transferred ownership inside vault)
        // Deduct from gold/silver total occupancy if required, or simply transfer custody. Here weight is still vaulted.

        // 5. Save Order & Ledgers
        val orderId = "ORD-S-" + UUID.randomUUID().toString().substring(0, 6).uppercase()
        val order = Order(
            orderId = orderId,
            type = OrderType.MARKET_SELL,
            metal = metal,
            quantityG = weightG,
            pricePerGram = priceMetrics["finalPricePerGram"] ?: BigDecimal.ZERO,
            premiumValue = discount,
            totalValuation = finalSettlementCash,
            currency = settlementCurrency,
            status = OrderStatus.SETTLED,
            vaultId = bar.currentVaultId,
            serialNumber = bar.serialNumber,
            timestamp = "2026-10-06 01:06:10",
            correlationId = "COR-" + UUID.randomUUID().toString().substring(0, 6).uppercase()
        )
        _orders.value = listOf(order) + _orders.value

        logAudit("TRADE_EXECUTED_SELL", "Metal bar deallocated and purchased by Dealer. Serial: ${bar.serialNumber}", "user", bar.currentVaultId, bar.barId)
        return Pair(true, "Successfully sold Bar ${bar.serialNumber} for $settlementCurrency $finalSettlementCash.")
    }

    // --- Vault-to-Vault Safe Transfer Simulation ---
    fun requestVaultTransfer(
        barId: String,
        targetVaultId: String
    ): Pair<Boolean, String> {
        val bar = _bars.value.find { it.barId == barId && it.ownerId == "user" }
            ?: return Pair(false, "Precious bar not found.")

        if (bar.currentVaultId == targetVaultId) {
            return Pair(false, "Metal bar is already stored in target vault.")
        }

        val originalVaultId = bar.currentVaultId

        // Move to IN_TRANSIT
        val updatedBars = _bars.value.map { b ->
            if (b.barId == barId) {
                b.copy(currentVaultId = "TRANSIT_SECURE", custodyStatus = CustodyStatus.IN_TRANSIT)
            } else b
        }
        _bars.value = updatedBars

        val movementId = "TRF-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val customDeclaration = "ASEAN-CUST-$movementId"
        val shipment = VaultMovement(
            movementId = movementId,
            barId = barId,
            metal = bar.metal,
            fromVaultId = originalVaultId,
            toVaultId = targetVaultId,
            status = "IN_TRANSIT",
            estimatedArrival = "24 Hours (Secured logistics flight)",
            customsDeclarationRef = customDeclaration
        )

        _activeShipments.value = _activeShipments.value + shipment

        // Immediately increase pending transit counters
        val updatedVaults = _vaults.value.map { vault ->
            if (vault.vaultId == targetVaultId) {
                vault.copy(inboundShipments = vault.inboundShipments + 1)
            } else if (vault.vaultId == originalVaultId) {
                vault.copy(outboundShipments = vault.outboundShipments + 1)
            } else vault
        }
        _vaults.value = updatedVaults

        logAudit("VAULT_TRANSFER_INCIPIENT", "Secure transfer initiated from $originalVaultId to $targetVaultId", "user", originalVaultId, barId)
        return Pair(true, "Transfer initiated. Customs declarations generated: $customDeclaration. Secure transit in progress.")
    }

    // --- Complete Secure Shipments ---
    fun completeTransferShipment(movementId: String) {
        val shipment = _activeShipments.value.find { it.movementId == movementId } ?: return
        
        // Remove from active shipments
        _activeShipments.value = _activeShipments.value.filter { it.movementId != movementId }

        // Update bar physical location
        val updatedBars = _bars.value.map { b ->
            if (b.barId == shipment.barId) {
                b.copy(currentVaultId = shipment.toVaultId, custodyStatus = CustodyStatus.VAULTED)
            } else b
        }
        _bars.value = updatedBars

        // Update vault statistics
        val updatedVaults = _vaults.value.map { vault ->
            if (vault.vaultId == shipment.toVaultId) {
                vault.copy(
                    inboundShipments = (vault.inboundShipments - 1).coerceAtLeast(0),
                    barCount = vault.barCount + 1
                )
            } else if (vault.vaultId == shipment.fromVaultId) {
                vault.copy(
                    outboundShipments = (vault.outboundShipments - 1).coerceAtLeast(0),
                    barCount = (vault.barCount - 1).coerceAtLeast(0)
                )
            } else vault
        }
        _vaults.value = updatedVaults

        logAudit("VAULT_TRANSFER_COMPLETED", "Secure transit finished. Bar received at target facility.", "system", shipment.toVaultId, shipment.barId)
    }

    // --- Physical Delivery Request ---
    fun requestPhysicalDelivery(
        barId: String,
        address: String,
        customsDeclarationsCountry: String
    ): Pair<Boolean, String> {
        val bar = _bars.value.find { it.barId == barId && it.ownerId == "user" }
            ?: return Pair(false, "Selected physical metal bar not located.")

        // 1. Remove from database / Set released
        val updatedBars = _bars.value.map { b ->
            if (b.barId == barId) {
                b.copy(custodyStatus = CustodyStatus.RELEASED, currentVaultId = "RELEASED_TO_CLIENT")
            } else b
        }
        _bars.value = updatedBars

        // 2. Reduce Client Metal Balances
        val weightG = bar.grossWeightG
        if (bar.metal == Metal.GOLD) {
            val acc = _clientGoldAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientGoldAccount.value = acc.copy()
        } else {
            val acc = _clientSilverAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientSilverAccount.value = acc.copy()
        }

        logAudit("PHYSICAL_DELIVERY_RELEASED", "Physical bar released from vault to carrier.", "user", bar.currentVaultId, bar.barId)
        return Pair(true, "Physical bar ${bar.serialNumber} has been released. Handed to Brinks secure delivery at $address. Customs bonded.")
    }

    // --- Book-Entry Ownership Transfer (A to B) ---
    fun executeBookEntryTransfer(
        barId: String,
        recipientId: String
    ): Pair<Boolean, String> {
        val bar = _bars.value.find { it.barId == barId && it.ownerId == "user" }
            ?: return Pair(false, "Precious bar not found or not owned by user.")

        // Swap owners
        val updatedBars = _bars.value.map { b ->
            if (b.barId == barId) {
                b.copy(ownerId = recipientId)
            } else b
        }
        _bars.value = updatedBars

        // Deduct from current client balance
        val weightG = bar.grossWeightG
        if (bar.metal == Metal.GOLD) {
            val acc = _clientGoldAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientGoldAccount.value = acc.copy()
        } else {
            val acc = _clientSilverAccount.value
            acc.totalWeightG = acc.totalWeightG.subtract(weightG)
            acc.allocatedWeightG = acc.allocatedWeightG.subtract(weightG)
            _clientSilverAccount.value = acc.copy()
        }

        logAudit("BOOK_ENTRY_OWNERSHIP_TRANSFER", "Book-entry ownership changed. Physical bar remains in vault ${bar.currentVaultId}.", "user", bar.currentVaultId, bar.barId)
        return Pair(true, "Ownership of Bar ${bar.serialNumber} successfully transferred to $recipientId without physical movement.")
    }

    // --- Scrap Gold Buyback Assay Engine ---
    fun submitScrapAssay(
        itemDesc: String,
        grossWeightG: BigDecimal,
        expectedPurityKarat: Int
    ): AssayReport {
        val expectedPurityPct = when (expectedPurityKarat) {
            24 -> BigDecimal("99.9")
            22 -> BigDecimal("91.6")
            18 -> BigDecimal("75.0")
            14 -> BigDecimal("58.5")
            9 -> BigDecimal("37.5")
            else -> BigDecimal("50.0")
        }

        // Simulating highly accurate XRF + Fire assay testing results with slight noise
        val randomNoise = BigDecimal((Math.random() * 0.4 - 0.2).toString())
        val xrfResult = expectedPurityPct.add(randomNoise).setScale(2, RoundingMode.HALF_UP)
        val fireAssayResult = expectedPurityPct.subtract(BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP)
        
        val verifiedFineness = fireAssayResult.divide(BigDecimal("100.0"), 4, RoundingMode.HALF_UP)
        val fineWeight = grossWeightG.multiply(verifiedFineness).setScale(4, RoundingMode.HALF_UP)

        // Value based on local Gold spot
        val localGoldSpot = calculateLocalPrice(Metal.GOLD, "SGD", "Singapore", BigDecimal.ONE)["spotGram"] ?: BigDecimal("98.15")
        // Scrap discount is 10% for refining & melting overhead
        val valuationAmount = fineWeight.multiply(localGoldSpot).multiply(BigDecimal("0.90")).setScale(2, RoundingMode.HALF_UP)

        val report = AssayReport(
            assayId = "ASY-" + UUID.randomUUID().toString().substring(0, 6).uppercase(),
            itemDescription = itemDesc,
            grossWeightG = grossWeightG,
            purityPct = expectedPurityPct,
            xrfResultPct = xrfResult,
            fireAssayResultPct = fireAssayResult,
            verifiedFineness = verifiedFineness.multiply(BigDecimal("1000")),
            fineMetalWeightG = fineWeight,
            valuationAmount = valuationAmount,
            currency = "SGD",
            confidence = BigDecimal("0.9850"),
            status = AssayStatus.VERIFIED,
            timestamp = "2026-10-06 01:06:00"
        )

        _scrapCases.value = _scrapCases.value + report
        logAudit("ASSAY_COMPLETED", "Scrap gold assayed. Expected: $expectedPurityPct%. Verified: ${report.verifiedFineness} fineness.", "system", null, null)
        return report
    }

    // Accept scrap offer
    fun acceptScrapOffer(assayId: String): Pair<Boolean, String> {
        val report = _scrapCases.value.find { it.assayId == assayId } ?: return Pair(false, "Assay case not found.")
        if (report.status != AssayStatus.VERIFIED) {
            return Pair(false, "Offer has already been settled or is in invalid status.")
        }

        // Change status to settled
        report.status = AssayStatus.VERIFIED // Keep verified, or change internally
        _scrapCases.value = _scrapCases.value.map { if (it.assayId == assayId) it.copy(status = AssayStatus.VERIFIED) else it }

        // Give SGD cash to client wallet
        val originalCash = _clientCashAccounts.value.toMutableMap()
        val sgdWallet = originalCash["SGD"] ?: CashAccount("SGD", BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO)
        sgdWallet.totalBalance = sgdWallet.totalBalance.add(report.valuationAmount)
        sgdWallet.availableBalance = sgdWallet.availableBalance.add(report.valuationAmount)
        originalCash["SGD"] = sgdWallet
        _clientCashAccounts.value = originalCash

        logAudit("ASSAY_SETTLED", "Scrap offer of SGD ${report.valuationAmount} accepted. Client wallet credited.", "user", null, null)
        return Pair(true, "Assay settled. SGD ${report.valuationAmount} credited to multi-currency wallet.")
    }

    // --- Institutional RFQ Processing Engine ---
    fun requestInstitutionalRfq(
        clientName: String,
        metal: Metal,
        weightKg: BigDecimal,
        currency: String,
        vaultId: String
    ): Rfq {
        val grams = weightKg.multiply(BigDecimal("1000.0"))
        val priceMetrics = calculateLocalPrice(metal, currency, "Singapore", grams)
        
        val totalVal = priceMetrics["totalValuation"] ?: BigDecimal.ZERO
        val baseGram = priceMetrics["finalPricePerGram"] ?: BigDecimal.ZERO
        
        val spotPerKg = baseGram.multiply(BigDecimal("1000.0")).multiply(BigDecimal("0.985"))
        val premiumPerKg = baseGram.multiply(BigDecimal("1000.0")).multiply(BigDecimal("0.015"))
        val quotePerKg = spotPerKg.add(premiumPerKg)

        val rfqId = "RFQ-" + UUID.randomUUID().toString().substring(0, 6).uppercase()
        val rfq = Rfq(
            rfqId = rfqId,
            clientName = clientName,
            metal = metal,
            weightKg = weightKg,
            currency = currency,
            spotPricePerKg = spotPerKg.setScale(2, RoundingMode.HALF_UP),
            premiumPerKg = premiumPerKg.setScale(2, RoundingMode.HALF_UP),
            quotePricePerKg = quotePerKg.setScale(2, RoundingMode.HALF_UP),
            totalQuoteAmount = totalVal.setScale(2, RoundingMode.HALF_UP),
            validUntil = "30 Seconds",
            status = RfqStatus.QUOTED,
            targetVaultId = vaultId
        )

        _rfqs.value = listOf(rfq) + _rfqs.value
        logAudit("RFQ_CREATED", "Bulk quote requested for ${weightKg}kg ${metal.name}.", clientName, vaultId, null)
        return rfq
    }

    // Execute RFQ Quote
    fun acceptRfqQuote(rfqId: String): Pair<Boolean, String> {
        val rfq = _rfqs.value.find { it.rfqId == rfqId } ?: return Pair(false, "RFQ ID not found.")
        if (rfq.status != RfqStatus.QUOTED) {
            return Pair(false, "RFQ has expired or is already executed.")
        }

        rfq.status = RfqStatus.EXECUTED
        _rfqs.value = _rfqs.value.map { if (it.rfqId == rfqId) rfq else it }

        // Complete institutional order
        val orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val grams = rfq.weightKg.multiply(BigDecimal("1000.0"))
        
        val order = Order(
            orderId = orderId,
            type = OrderType.RFQ_EXECUTION,
            metal = rfq.metal,
            quantityG = grams,
            pricePerGram = rfq.quotePricePerKg.divide(BigDecimal("1000.0"), 6, RoundingMode.HALF_UP),
            premiumValue = rfq.premiumPerKg.multiply(rfq.weightKg),
            totalValuation = rfq.totalQuoteAmount,
            currency = rfq.currency,
            status = OrderStatus.SETTLED,
            vaultId = rfq.targetVaultId,
            serialNumber = "INST-${10000 + (Math.random() * 89999).toInt()}",
            timestamp = "2026-10-06 01:06:20",
            correlationId = "INST-CORR-" + UUID.randomUUID().toString().substring(0, 4).uppercase(),
            clientName = rfq.clientName
        )
        _orders.value = listOf(order) + _orders.value

        logAudit("RFQ_EXECUTED", "Institutional order executed from RFQ quote.", rfq.clientName, rfq.targetVaultId, null)
        return Pair(true, "RFQ successfully executed. Recorded in institutional ledger order-book.")
    }

    // --- RECONCILIATION AUDIT ENGINE ---
    fun runReconciliation(): List<String> {
        val exceptions = mutableListOf<String>()
        _reconciliationRunCount.value += 1

        // 1. Calculate physical total in system vaults (owned by "user")
        val physicalGoldWeightG = _bars.value
            .filter { it.metal == Metal.GOLD && it.ownerId == "user" && it.custodyStatus == CustodyStatus.VAULTED }
            .fold(BigDecimal.ZERO) { acc, bar -> acc.add(bar.grossWeightG) }

        val physicalSilverWeightG = _bars.value
            .filter { it.metal == Metal.SILVER && it.ownerId == "user" && it.custodyStatus == CustodyStatus.VAULTED }
            .fold(BigDecimal.ZERO) { acc, bar -> acc.add(bar.grossWeightG) }

        // 2. Fetch Customer Metal Balance records
        val clientGoldAllocated = _clientGoldAccount.value.allocatedWeightG
        val clientSilverAllocated = _clientSilverAccount.value.allocatedWeightG

        // 3. Reconcile Book Ledger Balance vs. Physical Assets in Vault
        if (clientGoldAllocated.compareTo(physicalGoldWeightG) != 0) {
            exceptions.add("GOLD LEDGER MISMATCH: Account balance has ${clientGoldAllocated}g allocated, but physical bars in vault total ${physicalGoldWeightG}g.")
        }
        if (clientSilverAllocated.compareTo(physicalSilverWeightG) != 0) {
            exceptions.add("SILVER LEDGER MISMATCH: Account balance has ${clientSilverAllocated}g allocated, but physical bars in vault total ${physicalSilverWeightG}g.")
        }

        // 4. Check for Simulated Artificial Discrepancies (For demo purposes)
        if (simulateMissingBarError) {
            exceptions.add("[ALARM] PHYSICAL BAR EXCEPTION: Bar SG-004821 listed in ledger, but failed secure RFID RFID-Tag sweep in Singapore Central Vault.")
        }
        if (simulateDuplicateSerialError) {
            exceptions.add("[ALARM] DUPLICATE SERIAL EXCEPTION: Conflicting serial records for bar 'MY-112233' reported simultaneously in Kuala Lumpur Vault and Jakarta Vault.")
        }

        // 5. Ensure physical metrics correspond to cumulative sum of vaults
        val totalVaultGoldKg = _vaults.value.fold(BigDecimal.ZERO) { acc, v -> acc.add(v.goldTonnage) }
        val totalVaultSilverKg = _vaults.value.fold(BigDecimal.ZERO) { acc, v -> acc.add(v.silverTonnage) }
        // Verify no negative capacities
        _vaults.value.forEach { v ->
            if (v.occupiedCapacityKg < BigDecimal.ZERO || v.goldTonnage < BigDecimal.ZERO || v.silverTonnage < BigDecimal.ZERO) {
                exceptions.add("[ALARM] NEGATIVE CAPACITY ERROR: Vault ${v.name} has corrupt volumetric statistics.")
            }
        }

        _reconciliationExceptions.value = exceptions
        logAudit("RECONCILIATION_RUN", "All multi-vault and digital ledgers reconciled. Found ${exceptions.size} exceptions.", "system", null, null)
        return exceptions
    }

    // --- Private Helper Logging ---
    private fun logAudit(
        action: String,
        details: String,
        actor: String,
        vaultId: String?,
        barId: String?
    ) {
        val auditId = "AUD-" + (100 + (Math.random() * 899).toInt())
        val record = AuditRecord(
            auditId = auditId,
            timestamp = "2026-10-06 01:06:25",
            actor = actor,
            action = action,
            details = details,
            accountId = "user",
            targetVaultId = vaultId,
            targetBarId = barId,
            apiRequestRef = "REQ-" + UUID.randomUUID().toString().substring(0, 5).uppercase()
        )
        _auditLogs.value = listOf(record) + _auditLogs.value
    }
}
