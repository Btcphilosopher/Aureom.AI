package com.example.data

import java.math.BigDecimal

object MockData {

    // 1. Languages & Localization Dictionary (7 Southeast Asian Languages)
    val i18n = mapOf(
        "en" to mapOf(
            "app_subtitle" to "SOUTHEAST ASIAN GOLD & SILVER",
            "tagline" to "BULLION • CUSTODY • VAULTING • TRADE • DELIVERY",
            "tab_home" to "Home",
            "tab_buy_sell" to "Trade",
            "tab_vaults" to "Vaults",
            "tab_scrap" to "Scrap Buyback",
            "tab_terminal" to "Dealer Terminal",
            "tab_journey" to "Demo Journey",
            "wealth_summary" to "TOTAL PORTFOLIO VALUE",
            "allocated" to "Allocated Weight",
            "unallocated" to "Unallocated Weight",
            "passport" to "Metal Passport",
            "vault_network" to "ASEAN Secure Vault Network",
            "buy_btn" to "Execute Institutional Buy",
            "sell_btn" to "Execute Institutional Sell",
            "transfer_vault" to "Vault-to-Vault Transfer",
            "delivery_request" to "Request Physical Delivery",
            "reconcile_status" to "System Reconciliation Integrity",
            "scrap_assay" to "Scrap Gold Assay Engine"
        ),
        "zh" to mapOf(
            "app_subtitle" to "东南亚金银实物投资",
            "tagline" to "金条银条 • 托管 • 金库 • 交易 • 物理交割",
            "tab_home" to "主页",
            "tab_buy_sell" to "交易",
            "tab_vaults" to "金库",
            "tab_scrap" to "旧金回收",
            "tab_terminal" to "交易员终端",
            "tab_journey" to "演示流程",
            "wealth_summary" to "投资组合总价值",
            "allocated" to "已分配实物重量",
            "unallocated" to "未分配重量",
            "passport" to "贵金属护照",
            "vault_network" to "东盟安全金库网络",
            "buy_btn" to "执行机构买入",
            "sell_btn" to "执行机构卖出",
            "transfer_vault" to "库对库转移",
            "delivery_request" to "申请物理交割",
            "reconcile_status" to "系统对账完整性",
            "scrap_assay" to "废金检测评估引擎"
        ),
        "ms" to mapOf(
            "app_subtitle" to "EMAS & PERAK ASIA TENGGARA",
            "tagline" to "BULION • AMANAH • SIMPANAN • DAGANGAN • PENGHANTARAN",
            "tab_home" to "Utama",
            "tab_buy_sell" to "Dagang",
            "tab_vaults" to "Bilik Kebal",
            "tab_scrap" to "Kitar Semula",
            "tab_terminal" to "Terminal Pengedar",
            "tab_journey" to "Perjalanan Demo",
            "wealth_summary" to "JUMLAH NILAI PORTFOLIO",
            "allocated" to "Berat Diperuntukkan",
            "unallocated" to "Berat Tidak Diperuntukkan",
            "passport" to "Pasport Logam",
            "vault_network" to "Rangkaian Bilik Kebal ASEAN",
            "buy_btn" to "Beli Bulion",
            "sell_btn" to "Jual Bulion",
            "transfer_vault" to "Pindahan Bilik Kebal",
            "delivery_request" to "Mohon Penghantaran Fizikal",
            "reconcile_status" to "Integriti Penyelarasan Sistem",
            "scrap_assay" to "Enjin Assai Emas Scrap"
        ),
        "id" to mapOf(
            "app_subtitle" to "EMAS & PERAK ASIA TENGGARA",
            "tagline" to "BULLION • DEPOSIT • PENYIMPANAN • PERDAGANGAN • PENGIRIMAN",
            "tab_home" to "Beranda",
            "tab_buy_sell" to "Transaksi",
            "tab_vaults" to "Brankas",
            "tab_scrap" to "Gadai & Buyback",
            "tab_terminal" to "Terminal Dealer",
            "tab_journey" to "Panduan Demo",
            "wealth_summary" to "TOTAL NILAI PORTFOLIO",
            "allocated" to "Berat Teralokasi",
            "unallocated" to "Berat Non-Alokasi",
            "passport" to "Paspor Logam Mulia",
            "vault_network" to "Jaringan Brankas ASEAN",
            "buy_btn" to "Beli Logam Mulia",
            "sell_btn" to "Jual Logam Mulia",
            "transfer_vault" to "Transfer Antar Brankas",
            "delivery_request" to "Pengajuan Pengiriman Fisik",
            "reconcile_status" to "Integritas Rekonsiliasi Sistem",
            "scrap_assay" to "Mesin Uji Kadar Emas Bekas"
        ),
        "th" to mapOf(
            "app_subtitle" to "ทองคำและเงินแห่งเอเชียตะวันออกเฉียงใต้",
            "tagline" to "ทองคำแท่ง • บริการรับฝาก • ตู้เซฟนิรภัย • การค้า • การส่งมอบ",
            "tab_home" to "หน้าหลัก",
            "tab_buy_sell" to "ซื้อขาย",
            "tab_vaults" to "ตู้นิรภัย",
            "tab_scrap" to "รับซื้อคืนทองเก่า",
            "tab_terminal" to "เทอร์มินัลผู้ค้า",
            "tab_journey" to "การสาธิต",
            "wealth_summary" to "มูลค่าพอร์ตการลงทุนรวม",
            "allocated" to "น้ำหนักที่จัดสรรแล้ว",
            "unallocated" to "น้ำหนักที่ยังไม่จัดสรร",
            "passport" to "พาสปอร์ตทองคำ",
            "vault_network" to "เครือข่ายห้องนิรภัยอาเซียน",
            "buy_btn" to "สั่งซื้อทองคำแท่ง",
            "sell_btn" to "สั่งขายทองคำแท่ง",
            "transfer_vault" to "โอนย้ายระหว่างตู้นิรภัย",
            "delivery_request" to "ขอรับการส่งมอบจริง",
            "reconcile_status" to "ความถูกต้องของการกระทบยอดระบบ",
            "scrap_assay" to "เครื่องวิเคราะห์ทองเก่าและเศษทอง"
        ),
        "vi" to mapOf(
            "app_subtitle" to "VÀNG & BẠC ĐÔNG NAM Á",
            "tagline" to "KHO VÀNG • KÝ GỬI • LƯU TRỮ • GIAO DỊCH • VẬN CHUYỂN",
            "tab_home" to "Trang Chủ",
            "tab_buy_sell" to "Giao Dịch",
            "tab_vaults" to "Kho Lưu Trữ",
            "tab_scrap" to "Thu Mua Vàng Cũ",
            "tab_terminal" to "Hệ Thống Đại Lý",
            "tab_journey" to "Kịch Bản Demo",
            "wealth_summary" to "TỔNG GIÁ TRỊ TÀI SẢN",
            "allocated" to "Khối Lượng Đã Định Danh",
            "unallocated" to "Khối Lượng Chưa Định Danh",
            "passport" to "Hộ Chiếu Kim Loại",
            "vault_network" to "Mạng Lưới Kho Vàng ASEAN",
            "buy_btn" to "Mua Vàng Miếng",
            "sell_btn" to "Bán Vàng Miếng",
            "transfer_vault" to "Chuyển Kho Lưu Trữ",
            "delivery_request" to "Yêu Cầu Nhận Vật Chất",
            "reconcile_status" to "Kiểm Kê Đối Soát Hệ Thống",
            "scrap_assay" to "Hệ Thống Phân Tích Tuổi Vàng"
        ),
        "fil" to mapOf(
            "app_subtitle" to "GINTONG AT PILAK NG TIMOG-SILANGANG ASYA",
            "tagline" to "BULLION • PAGTITIWALA • KAHON-DE-YELO • KALAKALAN • PAGHAHATID",
            "tab_home" to "Tahanan",
            "tab_buy_sell" to "Kalakal",
            "tab_vaults" to "Kaban ng Yaman",
            "tab_scrap" to "Bilihan ng Lumang Ginto",
            "tab_terminal" to "Terminal ng Dealer",
            "tab_journey" to "Gabay sa Demo",
            "wealth_summary" to "KABUUANG HALAGA NG PORTFOLIO",
            "allocated" to "Nakalaang Timbang",
            "unallocated" to "Hindi Nakalaang Timbang",
            "passport" to "Pasaporte ng Metal",
            "vault_network" to "ASEAN Safe Vault Network",
            "buy_btn" to "Bumili ng Bullion",
            "sell_btn" to "Magbenta ng Bullion",
            "transfer_vault" to "Ilipat ng Kaban",
            "delivery_request" to "Hilingin ang Pisikal na Hatid",
            "reconcile_status" to "Integridad ng Rekonsilyasyon",
            "scrap_assay" to "Suri ng Lumang Ginto"
        )
    )

    // 2. Fictional / Synthetic Regional Vault Network Locations
    val initialVaults = listOf(
        // Singapore Hub
        Vault("SG-01", "Singapore Central Vault", "Singapore", "Singapore", BigDecimal("50000.0"), BigDecimal("36000.0"), BigDecimal("184.2"), BigDecimal("421.7"), 483291, 1420, "MAXIMUM_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026"),
        Vault("SG-02", "Changi Bullion Vault", "Singapore", "Singapore", BigDecimal("25000.0"), BigDecimal("12000.0"), BigDecimal("62.5"), BigDecimal("154.0"), 125000, 480, "MAXIMUM_SECURITY_ACTIVE", "CERTIFIED_AUDITED_SEP_2026"),
        Vault("SG-03", "Jurong Precious Metals Vault", "Singapore", "Singapore", BigDecimal("15000.0"), BigDecimal("9000.0"), BigDecimal("41.0"), BigDecimal("98.4"), 95000, 310, "MAXIMUM_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026"),
        
        // Malaysia Nodes
        Vault("MY-01", "Kuala Lumpur Vault", "Kuala Lumpur", "Malaysia", BigDecimal("12000.0"), BigDecimal("6400.0"), BigDecimal("32.4"), BigDecimal("88.2"), 72000, 290, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026"),
        Vault("MY-02", "Johor Bullion Vault", "Johor Bahru", "Malaysia", BigDecimal("8000.0"), BigDecimal("3100.0"), BigDecimal("12.1"), BigDecimal("45.0"), 34000, 110, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_AUG_2026"),
        
        // Thailand Node
        Vault("TH-01", "Bangkok Vault", "Bangkok", "Thailand", BigDecimal("18000.0"), BigDecimal("11200.0"), BigDecimal("54.1"), BigDecimal("121.5"), 114000, 440, "MAXIMUM_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026"),
        
        // Indonesia Nodes
        Vault("ID-01", "Jakarta Vault", "Jakarta", "Indonesia", BigDecimal("20000.0"), BigDecimal("13400.0"), BigDecimal("71.5"), BigDecimal("192.0"), 148000, 520, "MAXIMUM_SECURITY_ACTIVE", "CERTIFIED_AUDITED_SEP_2026"),
        Vault("ID-02", "Surabaya Vault", "Surabaya", "Indonesia", BigDecimal("10000.0"), BigDecimal("4200.0"), BigDecimal("18.2"), BigDecimal("59.0"), 45000, 150, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_JUL_2026"),
        
        // Vietnam Nodes
        Vault("VN-01", "Ho Chi Minh City Vault", "Ho Chi Minh", "Vietnam", BigDecimal("14000.0"), BigDecimal("8100.0"), BigDecimal("44.8"), BigDecimal("102.0"), 89000, 270, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_SEP_2026"),
        Vault("VN-02", "Hanoi Vault", "Hanoi", "Vietnam", BigDecimal("10000.0"), BigDecimal("5200.0"), BigDecimal("26.1"), BigDecimal("71.0"), 54000, 180, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026"),
        
        // Philippines Node
        Vault("PH-01", "Manila Vault", "Manila", "Philippines", BigDecimal("12000.0"), BigDecimal("5900.0"), BigDecimal("29.4"), BigDecimal("81.0"), 61000, 210, "HIGH_SECURITY_ACTIVE", "CERTIFIED_AUDITED_OCT_2026")
    )

    // 3. Fictional Regulated Compliance Policies
    val complianceRules = listOf(
        ComplianceRule("AML Regulated Bullion Trade", "Singapore", "SG-MND-01", BigDecimal("15000.00"), "Regulated Precious Metals Dealers Act. Mandatory KYC for cash trades exceeding SGD 15,000. Enhanced Due Diligence (EDD) & Source of Funds (SoF) validation required."),
        ComplianceRule("Shariah Gold Compliance", "Malaysia", "MY-SHA-02", BigDecimal("0.00"), "Islamic Finance guidelines. Gold allocation must be completed on book-entry on the same spot settlement date (Book-Entry Al-Sarf limit)."),
        ComplianceRule("Thailand Import-Customs Bond", "Thailand", "TH-CUS-05", BigDecimal("50000.00"), "Import clearance requires verified custom brokerage invoice and assay certification for physical items exceeding USD 50,000 equivalent."),
        ComplianceRule("Indonesia Antam Standard Audit", "Indonesia", "ID-BULL-09", BigDecimal("10000.00"), "Central bank coordination rule for physical gold savings and delivery. Mandatory audit tracking of physical bar certificates."),
        ComplianceRule("Vietnam Gold Import Quota", "Vietnam", "VN-SBV-03", BigDecimal("1000.00"), "State Bank of Vietnam (SBV) authorization required for importing gold bars above 1,000 grams.")
    )

    // 4. Initial Synthetic Metal Passports (Bars)
    val initialBars = mutableListOf(
        MetalObject(
            barId = "BAR-SG-004821",
            serialNumber = "SG-004821",
            metal = Metal.GOLD,
            refiner = "Metalor Singapore Ltd",
            brand = "ASEAN AURUM STANDARD",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("1000.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-SG-2026-994",
            origin = "Singapore Refinery",
            currentVaultId = "SG-01",
            ownerId = "user", // Pre-owned by the user
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-SG-004822",
            serialNumber = "SG-004822",
            metal = Metal.GOLD,
            refiner = "Metalor Singapore Ltd",
            brand = "ASEAN AURUM STANDARD",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("1000.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-SG-2026-995",
            origin = "Singapore Refinery",
            currentVaultId = "SG-01",
            ownerId = "user", // Pre-owned by the user
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-MY-112233",
            serialNumber = "MY-112233",
            metal = Metal.GOLD,
            refiner = "Nadir Refinery KL",
            brand = "AURUM MALAYSIA MINTED",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("100.00"),
            manufactureYear = 2025,
            assayReference = "ASSAY-KL-44910",
            origin = "Malaysia Gold Smelter",
            currentVaultId = "MY-01",
            ownerId = "user", // Pre-owned by user in KL
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-TH-882193",
            serialNumber = "TH-882193",
            metal = Metal.GOLD,
            refiner = "Bangkok Refining Corp",
            brand = "THAILAND INVESTMENT BAR",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("50.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-BKK-0922",
            origin = "Thailand BKK Mines",
            currentVaultId = "TH-01",
            ownerId = "user",
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-ID-449101",
            serialNumber = "ID-449101",
            metal = Metal.SILVER,
            refiner = "PT Aneka Tambang Tbk",
            brand = "INDONESIA SIL-CAST",
            purity = BigDecimal("999.0"),
            grossWeightG = BigDecimal("1000.00"), // 1kg
            manufactureYear = 2026,
            assayReference = "ASSAY-JKT-11492",
            origin = "Antam West Java",
            currentVaultId = "ID-01",
            ownerId = "user",
            allocationStatus = AllocationStatus.ALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        // Dealer Inventory / Liquid stock for execution
        MetalObject(
            barId = "BAR-SG-DL-001",
            serialNumber = "SG-DL-001",
            metal = Metal.GOLD,
            refiner = "Argor-Heraeus Switzerland",
            brand = "SWISS PRECISION BANKING",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("1000.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-CH-11004",
            origin = "Mendrisio Refinery",
            currentVaultId = "SG-01",
            ownerId = "dealer",
            allocationStatus = AllocationStatus.UNALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-SG-DL-002",
            serialNumber = "SG-DL-002",
            metal = Metal.GOLD,
            refiner = "Argor-Heraeus Switzerland",
            brand = "SWISS PRECISION BANKING",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("1000.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-CH-11005",
            origin = "Mendrisio Refinery",
            currentVaultId = "SG-01",
            ownerId = "dealer",
            allocationStatus = AllocationStatus.UNALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-MY-DL-001",
            serialNumber = "MY-DL-001",
            metal = Metal.GOLD,
            refiner = "Nadir Refinery KL",
            brand = "AURUM MALAYSIA MINTED",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("100.00"),
            manufactureYear = 2026,
            assayReference = "ASSAY-KL-99120",
            origin = "Malaysia Gold Smelter",
            currentVaultId = "MY-01",
            ownerId = "dealer",
            allocationStatus = AllocationStatus.UNALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        ),
        MetalObject(
            barId = "BAR-SG-DL-SV100",
            serialNumber = "SG-DL-SV100",
            metal = Metal.SILVER,
            refiner = "Metalor Singapore Ltd",
            brand = "ASEAN AURUM STANDARD",
            purity = BigDecimal("999.9"),
            grossWeightG = BigDecimal("3110.35"), // 100 oz approx
            manufactureYear = 2026,
            assayReference = "ASSAY-SG-SV001",
            origin = "Singapore Refinery",
            currentVaultId = "SG-01",
            ownerId = "dealer",
            allocationStatus = AllocationStatus.UNALLOCATED,
            custodyStatus = CustodyStatus.VAULTED
        )
    )

    // Helper: Find a regional currency symbol
    fun getCurrencySymbol(curr: String): String {
        return when (curr) {
            "SGD" -> "SGD "
            "MYR" -> "RM "
            "THB" -> "฿ "
            "IDR" -> "Rp "
            "VND" -> "₫ "
            "PHP" -> "₱ "
            "USD" -> "$ "
            else -> "$curr "
        }
    }
}
