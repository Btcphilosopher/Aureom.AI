package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CustomerAppScreen
import com.example.ui.screens.DealerTerminalScreen
import com.example.ui.screens.JourneyStepperScreen
import com.example.ui.theme.BlackBg
import com.example.ui.theme.BrushedGold
import com.example.ui.theme.Graphite
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OffWhiteText
import com.example.ui.theme.TextGray

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var currentMainTab by remember { mutableStateOf("CUSTOMER") } // "CUSTOMER", "DEALER", "DEMOS"

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Master Hub Tab Bar at the bottom for easy switching between distinct platforms
                        Surface(
                            color = Graphite,
                            tonalElevation = 8.dp,
                            modifier = Modifier.navigationBarsPadding()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(60.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Customer App Selection
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable { currentMainTab = "CUSTOMER" }
                                        .testTag("hub_btn_customer")
                                        .padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SupervisorAccount,
                                        contentDescription = "Customer Client Portal",
                                        tint = if (currentMainTab == "CUSTOMER") BrushedGold else TextGray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        "CUSTOMER PORTAL",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentMainTab == "CUSTOMER") BrushedGold else OffWhiteText
                                    )
                                }

                                // Institutional Dealer Terminal Selection
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable { currentMainTab = "DEALER" }
                                        .testTag("hub_btn_dealer")
                                        .padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = "Dealer Core Terminal",
                                        tint = if (currentMainTab == "DEALER") BrushedGold else TextGray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        "DEALER TERMINAL",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentMainTab == "DEALER") BrushedGold else OffWhiteText
                                    )
                                }

                                // Interactive Walkthrough Demo Selection
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable { currentMainTab = "DEMOS" }
                                        .testTag("hub_btn_demos")
                                        .padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Route,
                                        contentDescription = "Interactive Walkthrough Demos",
                                        tint = if (currentMainTab == "DEMOS") BrushedGold else TextGray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        "DEMO WORKFLOWS",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentMainTab == "DEMOS") BrushedGold else OffWhiteText
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .padding(innerPadding)
                            .fillMaxSize()
                            .background(BlackBg)
                    ) {
                        when (currentMainTab) {
                            "CUSTOMER" -> CustomerAppScreen()
                            "DEALER" -> DealerTerminalScreen()
                            "DEMOS" -> JourneyStepperScreen()
                        }
                    }
                }
            }
        }
    }
}
