import { ProjectInputs, OptimisationObjective, RoomType } from './simulation-types';

export interface OptimisationResult {
  objective: OptimisationObjective;
  title: string;
  description: string;
  recommendedInputs: ProjectInputs;
  recommendedDimensions: {
    widthFt: number;
    depthFt: number;
    floors: number;
    basement: boolean;
    garageCars: number;
    ceilingHeightFt: number;
  };
  recommendedRooms: Partial<Record<RoomType, number>>;
  keyBenefits: string[];
}

export class OptimizationEngine {
  public static optimize(
    currentInputs: ProjectInputs,
    currentWidth: number,
    currentDepth: number,
    objective: OptimisationObjective
  ): OptimisationResult {
    switch (objective) {
      case 'MINIMUM_COST':
        return {
          objective,
          title: 'Minimum Capital Cost Optimization',
          description: 'Streamlines structure, eliminates non-essential subterranean excavation, uses high-efficiency standard materials.',
          recommendedInputs: {
            ...currentInputs,
            style: 'American Colonial',
            exterior: 'brick',
            roof: 'asphalt',
            windows: 'standard',
            insulation: 'Basic',
            hvac: 'Gas',
            solar: 'Off',
            swimmingPool: false
          },
          recommendedDimensions: {
            widthFt: 54,
            depthFt: 36,
            floors: 2,
            basement: false,
            garageCars: 2,
            ceilingHeightFt: 9
          },
          recommendedRooms: { bedrooms: 4, bathrooms: 3, kitchens: 1, living: 1, dining: 1, offices: 1, cinemas: 0, wineCellars: 0, gyms: 0 },
          keyBenefits: [
            'Reduces capital expenditure by ~32%',
            'Accelerates construction timeline by 95 days',
            'Eliminates heavy subterranean geotechnical risks'
          ]
        };

      case 'MAXIMUM_FLOOR_AREA':
        return {
          objective,
          title: 'Maximum Gross Floor Area Optimization',
          description: 'Maximizes site footprint, adds a full structural basement, 3 living floors, and 4-car automotive gallery.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Traditional Mansion',
            exterior: 'stone_brick',
            roof: 'synthetic_slate',
            windows: 'premium',
            insulation: 'Premium',
            hvac: 'Heat Pump',
            solar: 'Standard',
            swimmingPool: true
          },
          recommendedDimensions: {
            widthFt: 88,
            depthFt: 52,
            floors: 3,
            basement: true,
            garageCars: 4,
            ceilingHeightFt: 11
          },
          recommendedRooms: { bedrooms: 6, bathrooms: 8, kitchens: 2, living: 2, dining: 1, offices: 2, libraries: 1, cinemas: 1, gyms: 1, wineCellars: 1, guestSuites: 1 },
          keyBenefits: [
            'Expands gross floor area to ~18,300 sq ft',
            'Provides 14 specialized lifestyle room suites',
            'Optimizes economy of scale unit rate ($/sq ft)'
          ]
        };

      case 'MAXIMUM_LUXURY':
        return {
          objective,
          title: 'Ultra-Luxury & Bespoke Craftsmanship',
          description: 'Full Indiana Cut Limestone facade, Welsh Slate roof, Minimalist Architectural Glazing, Geothermal, Pool, Dolby Cinema & Wine Cellar.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Modern Estate',
            exterior: 'limestone',
            roof: 'slate',
            windows: 'architectural',
            insulation: 'Passive',
            hvac: 'Geothermal',
            solar: 'Maximum',
            swimmingPool: true
          },
          recommendedDimensions: {
            widthFt: 82,
            depthFt: 48,
            floors: 2,
            basement: true,
            garageCars: 4,
            ceilingHeightFt: 12
          },
          recommendedRooms: { bedrooms: 5, bathrooms: 7, kitchens: 2, living: 2, dining: 1, offices: 2, libraries: 1, cinemas: 1, gyms: 1, wineCellars: 1, guestSuites: 1 },
          keyBenefits: [
            'Achieves 100/100 Luxury Architectural Rating',
            'Subterranean Dolby Cinema & Climate Wine Cellar',
            'Hand-carved limestone exterior with 100+ year durability'
          ]
        };

      case 'MINIMUM_ENERGY':
        return {
          objective,
          title: 'Net-Zero / Passivhaus Energy Optimization',
          description: 'Passivhaus Quad-Insulation, Triple Argon Glazing, Ground Exchange Geothermal, Maximum Roof Solar & Powerwall Array.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Contemporary',
            exterior: 'render',
            roof: 'metal',
            windows: 'premium',
            insulation: 'Passive',
            hvac: 'Geothermal',
            solar: 'Maximum',
            swimmingPool: false
          },
          recommendedDimensions: {
            widthFt: 64,
            depthFt: 40,
            floors: 2,
            basement: false,
            garageCars: 2,
            ceilingHeightFt: 10
          },
          recommendedRooms: { bedrooms: 4, bathrooms: 4, kitchens: 1, living: 1, dining: 1, offices: 1, plant: 1 },
          keyBenefits: [
            'Net-positive solar energy generation surplus',
            'Dramatically reduces EUI to ~11 kWh/sq ft/yr',
            'Saves over $18,000 annually in utility expenses'
          ]
        };

      case 'MINIMUM_CONSTRUCTION_TIME':
        return {
          objective,
          title: 'Rapid Construction Assembly',
          description: 'Timber engineered frame, pre-fabricated panelized walls, no basement excavation, rapid standing seam roof.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Mountain Estate',
            exterior: 'timber',
            roof: 'metal',
            windows: 'standard',
            insulation: 'Premium',
            hvac: 'Heat Pump',
            solar: 'Off',
            swimmingPool: false
          },
          recommendedDimensions: {
            widthFt: 60,
            depthFt: 38,
            floors: 2,
            basement: false,
            garageCars: 2,
            ceilingHeightFt: 10
          },
          recommendedRooms: { bedrooms: 4, bathrooms: 3, kitchens: 1, living: 1, dining: 1, offices: 1 },
          keyBenefits: [
            'Reduces construction duration to under 280 days',
            'Eliminates wet masonry and curing delays',
            'Reduces site overhead and machinery rental days'
          ]
        };

      case 'MAXIMUM_VALUE_PER_DOLLAR':
        return {
          objective,
          title: 'High ROI Balanced Estate',
          description: 'Sweet spot of high-grade facing stone/brick finish, heat pump HVAC, standard solar, 2 floors, high resale value density.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Georgian',
            exterior: 'stone_brick',
            roof: 'synthetic_slate',
            windows: 'premium',
            insulation: 'Premium',
            hvac: 'Heat Pump',
            solar: 'Standard',
            swimmingPool: false
          },
          recommendedDimensions: {
            widthFt: 68,
            depthFt: 42,
            floors: 2,
            basement: false,
            garageCars: 3,
            ceilingHeightFt: 10
          },
          recommendedRooms: { bedrooms: 5, bathrooms: 5, kitchens: 1, living: 1, dining: 1, offices: 1, libraries: 1, gyms: 1 },
          keyBenefits: [
            'Maximizes value per square foot ratio',
            'Optimal balance of hard cost vs architectural prestige',
            'Strongest 10-year equity retention curve'
          ]
        };

      case 'MINIMUM_LIFECYCLE_COST':
      default:
        return {
          objective,
          title: 'Minimum 50-Year Total Ownership Cost',
          description: 'High durability materials (granite/slate), heat pump, high R-value insulation, low maintenance building envelope.',
          recommendedInputs: {
            ...currentInputs,
            style: 'Georgian',
            exterior: 'granite',
            roof: 'slate',
            windows: 'premium',
            insulation: 'Passive',
            hvac: 'Heat Pump',
            solar: 'Maximum',
            swimmingPool: false
          },
          recommendedDimensions: {
            widthFt: 66,
            depthFt: 40,
            floors: 2,
            basement: false,
            garageCars: 3,
            ceilingHeightFt: 10
          },
          recommendedRooms: { bedrooms: 4, bathrooms: 4, kitchens: 1, living: 1, dining: 1, offices: 1, plant: 1 },
          keyBenefits: [
            'Saves over $420,000 in 50-year lifecycle operation',
            'Minimal envelope replacement requirement',
            'Self-funding through solar energy payback'
          ]
        };
    }
  }
}
