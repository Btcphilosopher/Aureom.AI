import * as THREE from 'three';
import { ProjectState } from './simulation-types';

export class ThreeBuildingGenerator {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private buildingGroup: THREE.Group;
  private siteGroup: THREE.Group;
  private machineryGroup: THREE.Group;
  private workersGroup: THREE.Group;
  private animFrameId: number | null = null;

  // Materials Cache
  private materialsCache: Record<string, THREE.Material> = {};

  constructor(container: HTMLElement, isMiniPreview = false) {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x090d12);
    this.scene.fog = new THREE.FogExp2(0x090d12, 0.008);

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 400;

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(60, isMiniPreview ? 45 : 60, 60);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    this.buildingGroup = new THREE.Group();
    this.siteGroup = new THREE.Group();
    this.machineryGroup = new THREE.Group();
    this.workersGroup = new THREE.Group();

    this.scene.add(this.siteGroup);
    this.scene.add(this.buildingGroup);
    this.scene.add(this.machineryGroup);
    this.scene.add(this.workersGroup);

    this.setupLighting();
    this.setupTechnicalGrid();

    // Start render loop
    this.startLoop();
  }

  private setupLighting(): void {
    const ambient = new THREE.AmbientLight(0xffffff, 0.65);
    this.scene.add(ambient);

    const dirLight = new THREE.DirectionalLight(0xfff5ea, 1.4);
    dirLight.position.set(80, 120, 60);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 300;
    const d = 100;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    this.scene.add(dirLight);

    // Cyan technical accent fill light
    const fillLight = new THREE.DirectionalLight(0x00e5ff, 0.45);
    fillLight.position.set(-80, 40, -60);
    this.scene.add(fillLight);
  }

  private setupTechnicalGrid(): void {
    const gridHelper = new THREE.GridHelper(300, 60, 0x00f0ff, 0x1e293b);
    gridHelper.position.y = -0.05;
    this.siteGroup.add(gridHelper);

    // Site Ground Mesh
    const groundGeo = new THREE.PlaneGeometry(320, 320);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.9,
      metalness: 0.1
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.1;
    ground.receiveShadow = true;
    this.siteGroup.add(ground);
  }

  /**
   * Main Procedural Building Generation based on Project State
   */
  public updateBuildingGeometry(state: ProjectState, animationProgressPct = 100, isCutaway = false): void {
    // Clear previous building meshes
    while (this.buildingGroup.children.length > 0) {
      const obj = this.buildingGroup.children[0];
      this.buildingGroup.remove(obj);
    }
    while (this.machineryGroup.children.length > 0) {
      this.machineryGroup.remove(this.machineryGroup.children[0]);
    }
    while (this.workersGroup.children.length > 0) {
      this.workersGroup.remove(this.workersGroup.children[0]);
    }

    const b = state.buildingCalc;
    const scale = 0.35; // 1 ft = 0.35 three units
    const width = b.width * scale;
    const depth = b.depth * scale;
    const floors = b.floors;
    const storyHeight = b.ceilingHeight * scale;
    const totalHeight = floors * storyHeight;

    // Get exterior material color/texture spec
    const facadeMat = this.getFacadeMaterial(state.inputs.exterior);
    const roofMat = this.getRoofMaterial(state.inputs.roof);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
      roughness: 0.1,
      metalness: 0.9,
      transmission: 0.6
    });
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.8 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.6 });

    // Stage visibility controls based on animationProgressPct (0 to 100)
    const showSubgrade = animationProgressPct >= 8;
    const showFoundations = animationProgressPct >= 18;
    const showFrame = animationProgressPct >= 32;
    const showRoof = animationProgressPct >= 48;
    const showEnvelope = animationProgressPct >= 62;
    const showWindows = animationProgressPct >= 75;

    // 1. BASEMENT / SUBGRADE EXCAVATION
    if (b.basement && showSubgrade) {
      const bHeight = 10 * scale;
      const bGeo = new THREE.BoxGeometry(width + 0.4, bHeight, depth + 0.4);
      const bMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        roughness: 0.9,
        wireframe: false
      });
      const basementMesh = new THREE.Mesh(bGeo, bMat);
      basementMesh.position.set(0, -bHeight / 2, 0);
      basementMesh.castShadow = true;
      basementMesh.receiveShadow = true;
      this.buildingGroup.add(basementMesh);
    }

    // 2. FOUNDATION SLAB
    if (showFoundations) {
      const slabGeo = new THREE.BoxGeometry(width + 0.8, 0.6, depth + 0.8);
      const slab = new THREE.Mesh(slabGeo, concreteMat);
      slab.position.set(0, 0.3, 0);
      slab.castShadow = true;
      slab.receiveShadow = true;
      this.buildingGroup.add(slab);
    }

    // 3. MAIN BUILDING FLOORS & STRUCTURE
    for (let f = 0; f < floors; f++) {
      const floorY = f * storyHeight + 0.6;

      // Floor Slab
      if (showFrame) {
        const fSlabGeo = new THREE.BoxGeometry(width + 0.2, 0.4, depth + 0.2);
        const fSlab = new THREE.Mesh(fSlabGeo, concreteMat);
        fSlab.position.set(0, floorY, 0);
        this.buildingGroup.add(fSlab);

        // Structural Columns at corners and grid
        const colGeo = new THREE.BoxGeometry(0.5, storyHeight, 0.5);
        const corners = [
          [-width / 2 + 0.3, floorY + storyHeight / 2, -depth / 2 + 0.3],
          [width / 2 - 0.3, floorY + storyHeight / 2, -depth / 2 + 0.3],
          [-width / 2 + 0.3, floorY + storyHeight / 2, depth / 2 - 0.3],
          [width / 2 - 0.3, floorY + storyHeight / 2, depth / 2 - 0.3],
          [0, floorY + storyHeight / 2, -depth / 2 + 0.3],
          [0, floorY + storyHeight / 2, depth / 2 - 0.3]
        ];

        corners.forEach(([cx, cy, cz]) => {
          const col = new THREE.Mesh(colGeo, woodMat);
          col.position.set(cx, cy, cz);
          col.castShadow = true;
          this.buildingGroup.add(col);
        });
      }

      // Exterior Walls (Envelope)
      if (showEnvelope) {
        const wallThickness = 0.4;
        const h = storyHeight - 0.4;

        // Front & Back Walls
        const wallFrontGeo = new THREE.BoxGeometry(width, h, wallThickness);
        const wallBackGeo = new THREE.BoxGeometry(width, h, wallThickness);

        const frontWall = new THREE.Mesh(wallFrontGeo, facadeMat);
        frontWall.position.set(0, floorY + h / 2 + 0.2, depth / 2);
        frontWall.castShadow = true;
        frontWall.receiveShadow = true;

        const backWall = new THREE.Mesh(wallBackGeo, facadeMat);
        backWall.position.set(0, floorY + h / 2 + 0.2, -depth / 2);
        backWall.castShadow = true;
        backWall.receiveShadow = true;

        // Side Walls
        const wallSideGeo = new THREE.BoxGeometry(wallThickness, h, depth);
        const leftWall = new THREE.Mesh(wallSideGeo, facadeMat);
        leftWall.position.set(-width / 2, floorY + h / 2 + 0.2, 0);
        leftWall.castShadow = true;

        const rightWall = new THREE.Mesh(wallSideGeo, facadeMat);
        rightWall.position.set(width / 2, floorY + h / 2 + 0.2, 0);
        rightWall.castShadow = true;

        // If cutaway mode active, don't show front wall so interior is visible!
        if (!isCutaway) {
          this.buildingGroup.add(frontWall);
        }
        this.buildingGroup.add(backWall);
        this.buildingGroup.add(leftWall);
        this.buildingGroup.add(rightWall);
      }

      // Windows
      if (showWindows) {
        const winW = width * 0.18;
        const winH = storyHeight * 0.5;
        const winGeo = new THREE.BoxGeometry(winW, winH, 0.1);

        const numWins = Math.max(2, Math.floor(width / 6));
        const spacing = width / (numWins + 1);

        for (let w = 1; w <= numWins; w++) {
          const wx = -width / 2 + spacing * w;
          const windowMesh = new THREE.Mesh(winGeo, glassMat);
          windowMesh.position.set(wx, floorY + storyHeight / 2, depth / 2 + 0.2);
          this.buildingGroup.add(windowMesh);

          const windowMeshBack = new THREE.Mesh(winGeo, glassMat);
          windowMeshBack.position.set(wx, floorY + storyHeight / 2, -depth / 2 - 0.2);
          this.buildingGroup.add(windowMeshBack);
        }
      }
    }

    // 4. GARAGE BAY WING
    if (b.garageCars > 0 && showFrame) {
      const gWidth = b.garageAreaSqFt > 0 ? (b.garageCars * 10) * scale : 4;
      const gDepth = 18 * scale;
      const gHeight = storyHeight;

      const gGeo = new THREE.BoxGeometry(gWidth, gHeight, gDepth);
      const garageMesh = new THREE.Mesh(gGeo, showEnvelope ? facadeMat : woodMat);
      garageMesh.position.set(width / 2 + gWidth / 2, gHeight / 2 + 0.3, depth / 4);
      garageMesh.castShadow = true;
      this.buildingGroup.add(garageMesh);
    }

    // 5. ROOF GEOMETRY
    if (showRoof) {
      const roofY = totalHeight + 0.6;
      const rOverhang = 0.8;

      if (state.inputs.roof === 'asphalt' || state.inputs.roof === 'slate' || state.inputs.roof === 'synthetic_slate' || state.inputs.roof === 'tile') {
        // Pitched Gable Roof
        const roofHeight = 4.5;
        const shape = new THREE.Shape();
        shape.moveTo(-width / 2 - rOverhang, 0);
        shape.lineTo(0, roofHeight);
        shape.lineTo(width / 2 + rOverhang, 0);
        shape.closePath();

        const extrudeSettings = { depth: depth + rOverhang * 2, bevelEnabled: false };
        const roofGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
        const roofMesh = new THREE.Mesh(roofGeo, roofMat);
        roofMesh.position.set(0, roofY, -depth / 2 - rOverhang);
        roofMesh.castShadow = true;
        this.buildingGroup.add(roofMesh);
      } else {
        // Flat Contemporary Metal Roof with Parapet
        const flatRoofGeo = new THREE.BoxGeometry(width + rOverhang, 0.5, depth + rOverhang);
        const flatRoof = new THREE.Mesh(flatRoofGeo, roofMat);
        flatRoof.position.set(0, roofY + 0.25, 0);
        flatRoof.castShadow = true;
        this.buildingGroup.add(flatRoof);
      }
    }

    // 6. SWIMMING POOL (If Selected)
    if (state.inputs.swimmingPool && showSubgrade) {
      const poolW = 12;
      const poolD = 24;
      const poolBorderGeo = new THREE.BoxGeometry(poolW + 1.2, 0.2, poolD + 1.2);
      const poolBorder = new THREE.Mesh(poolBorderGeo, concreteMat);
      poolBorder.position.set(-width / 2 - 14, 0.1, 0);
      this.buildingGroup.add(poolBorder);

      const poolWaterGeo = new THREE.BoxGeometry(poolW, 0.1, poolD);
      const poolWaterMat = new THREE.MeshPhysicalMaterial({
        color: 0x06b6d4,
        transparent: true,
        opacity: 0.85,
        roughness: 0.1
      });
      const water = new THREE.Mesh(poolWaterGeo, poolWaterMat);
      water.position.set(-width / 2 - 14, 0.05, 0);
      this.buildingGroup.add(water);
    }

    // 7. DATA-DRIVEN MACHINERY GENERATION
    this.generateDataDrivenMachinery(state, animationProgressPct, width, depth, totalHeight);

    // 8. DATA-DRIVEN WORKERS GENERATION
    this.generateDataDrivenWorkers(state, animationProgressPct, width, depth);

    // Position Camera dynamically to fit building
    const maxDim = Math.max(width, depth, totalHeight);
    const dist = maxDim * 2.8 + 20;
    this.camera.position.set(dist * 0.8, dist * 0.7, dist * 0.8);
    this.camera.lookAt(0, totalHeight / 2, 0);
  }

  /**
   * Facade Material Generator
   */
  private getFacadeMaterial(exterior: string): THREE.Material {
    if (this.materialsCache[`facade_${exterior}`]) {
      return this.materialsCache[`facade_${exterior}`];
    }

    let color = 0x94a3b8;
    let roughness = 0.7;

    switch (exterior) {
      case 'brick': color = 0x9a3412; roughness = 0.85; break;
      case 'render': color = 0xf8fafc; roughness = 0.4; break;
      case 'limestone': color = 0xe2e8f0; roughness = 0.65; break;
      case 'sandstone': color = 0xfde047; roughness = 0.8; break;
      case 'granite': color = 0x475569; roughness = 0.6; break;
      case 'stone_brick': color = 0x78350f; roughness = 0.8; break;
      case 'timber': color = 0x92400e; roughness = 0.5; break;
    }

    const mat = new THREE.MeshStandardMaterial({ color, roughness });
    this.materialsCache[`facade_${exterior}`] = mat;
    return mat;
  }

  /**
   * Roof Material Generator
   */
  private getRoofMaterial(roof: string): THREE.Material {
    let color = 0x1e293b;
    let roughness = 0.6;

    if (roof === 'slate') { color = 0x334155; roughness = 0.5; }
    if (roof === 'tile') { color = 0xca8a04; roughness = 0.7; }
    if (roof === 'metal') { color = 0x64748b; roughness = 0.3; }

    return new THREE.MeshStandardMaterial({ color, roughness });
  }

  /**
   * Data-Driven Machinery 3D Visualization
   */
  private generateDataDrivenMachinery(state: ProjectState, progress: number, w: number, d: number, h: number): void {
    const machineryList = state.machinery;

    // Excavator
    const excavatorReq = machineryList.find(m => m.equipmentType.includes('Excavation') || m.equipmentType.includes('Excavator'));
    if (excavatorReq && progress >= 5 && progress < 40) {
      for (let i = 0; i < excavatorReq.count; i++) {
        const excavator = this.createExcavatorMesh();
        excavator.position.set(-w / 2 - 12 - i * 8, 0, d / 2 + 6);
        this.machineryGroup.add(excavator);
      }
    }

    // Crane
    const craneReq = machineryList.find(m => m.equipmentType.includes('Crane'));
    if (craneReq && craneReq.count > 0 && progress >= 20 && progress < 80) {
      const crane = this.createCraneMesh(h + 15);
      crane.position.set(w / 2 + 10, 0, -d / 2 - 8);
      this.machineryGroup.add(crane);
    }

    // Telehandler
    const telehandlerReq = machineryList.find(m => m.equipmentType.includes('Telehandler'));
    if (telehandlerReq && progress >= 25 && progress < 85) {
      const tele = this.createTelehandlerMesh();
      tele.position.set(w / 2 + 8, 0, d / 2 + 10);
      this.machineryGroup.add(tele);
    }
  }

  /**
   * Data-Driven Workers 3D Visualization
   */
  private generateDataDrivenWorkers(state: ProjectState, progress: number, w: number, d: number): void {
    const totalWorkers = state.labour.reduce((a, b) => a + b.workersRequired, 0);
    const visibleWorkers = Math.min(30, Math.max(3, Math.round(totalWorkers * 0.4)));

    const workerGeo = new THREE.CapsuleGeometry(0.3, 1.2, 4, 8);

    for (let i = 0; i < visibleWorkers; i++) {
      const isMason = i % 3 === 0;
      const helmetColor = isMason ? 0xff6b00 : 0x00f0ff;
      const workerMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });

      const worker = new THREE.Mesh(workerGeo, workerMat);

      // Hard Hat
      const hatGeo = new THREE.SphereGeometry(0.35, 8, 8, 0, Math.PI * 2, 0, Math.PI / 2);
      const hatMat = new THREE.MeshStandardMaterial({ color: helmetColor });
      const hat = new THREE.Mesh(hatGeo, hatMat);
      hat.position.y = 0.7;
      worker.add(hat);

      // Position around building site
      const angle = (i / visibleWorkers) * Math.PI * 2;
      const rx = (w / 2 + 3 + (i % 3) * 2) * Math.cos(angle);
      const rz = (d / 2 + 3 + (i % 3) * 2) * Math.sin(angle);

      worker.position.set(rx, 0.9, rz);
      worker.castShadow = true;
      this.workersGroup.add(worker);
    }
  }

  // 3D Machinery Mesh Helpers
  private createExcavatorMesh(): THREE.Group {
    const group = new THREE.Group();
    const yellowMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });

    // Tracks
    const trackGeo = new THREE.BoxGeometry(4, 1.2, 6);
    const tracks = new THREE.Mesh(trackGeo, darkMat);
    tracks.position.y = 0.6;
    group.add(tracks);

    // Cab
    const cabGeo = new THREE.BoxGeometry(3, 2.5, 3.5);
    const cab = new THREE.Mesh(cabGeo, yellowMat);
    cab.position.set(0, 2.45, 0);
    group.add(cab);

    // Boom
    const boomGeo = new THREE.BoxGeometry(0.6, 5, 0.6);
    const boom = new THREE.Mesh(boomGeo, yellowMat);
    boom.rotation.z = -Math.PI / 4;
    boom.position.set(1.5, 4, 0);
    group.add(boom);

    return group;
  }

  private createCraneMesh(height: number): THREE.Group {
    const group = new THREE.Group();
    const craneMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.3 });

    // Vertical Tower Lattice
    const towerGeo = new THREE.BoxGeometry(1.5, height, 1.5);
    const tower = new THREE.Mesh(towerGeo, craneMat);
    tower.position.y = height / 2;
    group.add(tower);

    // Horizontal Jib Boom
    const jibGeo = new THREE.BoxGeometry(35, 1.2, 1.2);
    const jib = new THREE.Mesh(jibGeo, craneMat);
    jib.position.set(10, height, 0);
    group.add(jib);

    return group;
  }

  private createTelehandlerMesh(): THREE.Group {
    const group = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 });
    const bodyGeo = new THREE.BoxGeometry(3.5, 2, 5);
    const body = new THREE.Mesh(bodyGeo, mat);
    body.position.y = 1.5;
    group.add(body);
    return group;
  }

  public onResize(container: HTMLElement): void {
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 400;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private startLoop(): void {
    const animate = () => {
      this.animFrameId = requestAnimationFrame(animate);

      // Subtle ambient camera oscillation
      const time = Date.now() * 0.0003;
      this.buildingGroup.rotation.y = Math.sin(time) * 0.05;

      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }

  public destroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    this.renderer.dispose();
  }
}
