import {
  ProjectInputs,
  BuildingAreaCalc,
  RoomScheduleItem,
  RoomType,
  EconomicModel,
  HardCostBreakdown,
  SoftCostBreakdown,
  OtherCostBreakdown,
  CostCurvePoint,
  MaterialRequirement,
  TradeLabour,
  MachineryRequirement,
  ScheduleStage,
  WeatherConfig,
  ConstructionSchedule,
  EnergyModel,
  LifecycleModel,
  EngineeringWarning,
  SimulationEvent,
  ProjectState,
  LocationRegion,
  SimulationImpactDelta
} from './simulation-types';

export interface LocationMetric {
  labourMult: number;
  materialMult: number;
  climateZone: 'cold' | 'moderate' | 'warm' | 'hot';
  insulationReq: number;
  hvacCapMult: number;
  weatherDelayDays: number;
  rainfallMm: number;
  avgTempC: number;
  snowProbPct: number;
  regulatoryMult: number;
}

export class CalculationEngine {
  // Regional Multipliers for Costs, Labour Rate, Climate, Productivity & Weather Delays
  private static readonly LOCATION_DATA: Record<LocationRegion, {
    labourMult: number;
    materialMult: number;
    climateZone: 'cold' | 'moderate' | 'warm' | 'hot';
    insulationReq: number; // R-value multiplier
    hvacCapMult: number;
    weatherDelayDays: number;
    rainfallMm: number;
    avgTempC: number;
    snowProbPct: number;
    regulatoryMult: number;
  }> = {
    'UK': { labourMult: 0.92, materialMult: 1.05, climateZone: 'cold', insulationReq: 1.2, hvacCapMult: 1.1, weatherDelayDays: 24, rainfallMm: 950, avgTempC: 11, snowProbPct: 15, regulatoryMult: 1.15 },
    'US-Northeast': { labourMult: 1.18, materialMult: 1.10, climateZone: 'cold', insulationReq: 1.3, hvacCapMult: 1.3, weatherDelayDays: 28, rainfallMm: 1100, avgTempC: 10, snowProbPct: 35, regulatoryMult: 1.20 },
    'US-Mid-Atlantic': { labourMult: 1.08, materialMult: 1.02, climateZone: 'moderate', insulationReq: 1.0, hvacCapMult: 1.1, weatherDelayDays: 18, rainfallMm: 1000, avgTempC: 14, snowProbPct: 18, regulatoryMult: 1.12 },
    'US-Southeast': { labourMult: 0.88, materialMult: 0.95, climateZone: 'warm', insulationReq: 0.85, hvacCapMult: 1.4, weatherDelayDays: 16, rainfallMm: 1300, avgTempC: 21, snowProbPct: 2, regulatoryMult: 0.95 },
    'US-Midwest': { labourMult: 0.98, materialMult: 0.96, climateZone: 'cold', insulationReq: 1.25, hvacCapMult: 1.25, weatherDelayDays: 22, rainfallMm: 850, avgTempC: 9, snowProbPct: 40, regulatoryMult: 1.00 },
    'US-Southwest': { labourMult: 0.92, materialMult: 0.98, climateZone: 'hot', insulationReq: 0.9, hvacCapMult: 1.5, weatherDelayDays: 8, rainfallMm: 300, avgTempC: 23, snowProbPct: 1, regulatoryMult: 0.98 },
    'US-Mountain': { labourMult: 1.05, materialMult: 1.08, climateZone: 'cold', insulationReq: 1.35, hvacCapMult: 1.3, weatherDelayDays: 32, rainfallMm: 500, avgTempC: 7, snowProbPct: 55, regulatoryMult: 1.05 },
    'US-Pacific': { labourMult: 1.32, materialMult: 1.22, climateZone: 'moderate', insulationReq: 1.1, hvacCapMult: 1.0, weatherDelayDays: 14, rainfallMm: 750, avgTempC: 16, snowProbPct: 5, regulatoryMult: 1.35 },
    'Canada': { labourMult: 1.10, materialMult: 1.12, climateZone: 'cold', insulationReq: 1.4, hvacCapMult: 1.35, weatherDelayDays: 36, rainfallMm: 900, avgTempC: 6, snowProbPct: 60, regulatoryMult: 1.15 },
    'Europe': { labourMult: 1.05, materialMult: 1.15, climateZone: 'moderate', insulationReq: 1.25, hvacCapMult: 1.1, weatherDelayDays: 20, rainfallMm: 800, avgTempC: 12, snowProbPct: 20, regulatoryMult: 1.25 },
    'Australia': { labourMult: 1.15, materialMult: 1.18, climateZone: 'warm', insulationReq: 0.9, hvacCapMult: 1.4, weatherDelayDays: 12, rainfallMm: 600, avgTempC: 20, snowProbPct: 0, regulatoryMult: 1.10 },
    'Custom': { labourMult: 1.00, materialMult: 1.00, climateZone: 'moderate', insulationReq: 1.0, hvacCapMult: 1.0, weatherDelayDays: 15, rainfallMm: 800, avgTempC: 15, snowProbPct: 10, regulatoryMult: 1.00 },
  };

  /**
   * Main calculation pipeline execution
   */
  public static calculateProjectState(
    inputs: ProjectInputs,
    widthFt: number,
    depthFt: number,
    floors: number,
    basement: boolean,
    garageCars: number,
    ceilingHeightFt: number,
    roomsInput?: Partial<Record<RoomType, number>>
  ): ProjectState {
    const locInfo = this.LOCATION_DATA[inputs.location] || this.LOCATION_DATA['Custom'];

    // STEP 2 & 3: Building Area & Volume Calculation
    const footprintSqFt = widthFt * depthFt;
    const basementAreaSqFt = basement ? footprintSqFt : 0;
    const garageAreaSqFt = garageCars * 260; // ~260 sqft per car bay
    const floorAreaSqFt = footprintSqFt * floors;
    const grossFloorAreaSqFt = floorAreaSqFt + basementAreaSqFt + garageAreaSqFt;
    const conditionedFloorAreaSqFt = floorAreaSqFt + (basement ? basementAreaSqFt * 0.8 : 0);
    const perimeterFt = 2 * (widthFt + depthFt);
    const wallHeightFt = floors * ceilingHeightFt + (basement ? 10 : 0);
    const externalWallAreaSqFt = perimeterFt * wallHeightFt;
    
    // Window ratio based on window spec & style
    let windowRatio = 0.18;
    if (inputs.windows === 'premium') windowRatio = 0.22;
    if (inputs.windows === 'luxury') windowRatio = 0.28;
    if (inputs.windows === 'architectural') windowRatio = 0.35;
    if (inputs.style === 'Contemporary') windowRatio += 0.08;

    const windowAreaSqFt = externalWallAreaSqFt * windowRatio;
    const roofSlopeFactor = inputs.roof === 'slate' || inputs.roof === 'tile' ? 1.22 : 1.15;
    const roofAreaSqFt = footprintSqFt * roofSlopeFactor;
    const floorToWallRatio = externalWallAreaSqFt > 0 ? floorAreaSqFt / externalWallAreaSqFt : 1.0;
    const buildingVolumeCuFt = grossFloorAreaSqFt * ceilingHeightFt;

    const buildingCalc: BuildingAreaCalc = {
      width: widthFt,
      depth: depthFt,
      floors,
      basement,
      garageCars,
      ceilingHeight: ceilingHeightFt,
      footprintSqFt,
      floorAreaSqFt,
      grossFloorAreaSqFt,
      conditionedFloorAreaSqFt,
      basementAreaSqFt,
      garageAreaSqFt,
      roofAreaSqFt,
      externalWallAreaSqFt,
      windowAreaSqFt,
      floorToWallRatio: Math.round(floorToWallRatio * 100) / 100,
      buildingVolumeCuFt
    };

    // STEP 4: Room Schedule
    const rooms = this.generateRoomSchedule(buildingCalc, inputs, roomsInput);

    // STEP 5: Material Quantities & Embodied Carbon
    const materials = this.calculateMaterials(buildingCalc, inputs, locInfo.materialMult);

    // STEP 6: Labour Requirements
    const labour = this.calculateLabour(buildingCalc, inputs, materials, locInfo.labourMult);

    // STEP 7: Machinery Requirements
    const machinery = this.calculateMachinery(buildingCalc);

    // STEP 8: Construction Schedule & Weather Impact
    const { schedule } = this.calculateSchedule(buildingCalc, inputs, labour, machinery, locInfo);

    // STEP 9, 10, 11, 12: Economic Model (Hard, Soft, Other, Non-linear Marginal Cost)
    const economics = this.calculateEconomics(buildingCalc, inputs, materials, labour, machinery, schedule, locInfo);

    // STEP 13: Energy & Thermal Model
    const energy = this.calculateEnergyModel(buildingCalc, inputs, locInfo);

    // STEP 14: Lifecycle Cost Engine & Embodied Carbon
    const totalEmbodiedCarbonTonnes = materials.reduce((acc, m) => acc + m.embodiedCarbonTonnes, 0);
    const lifecycle = this.calculateLifecycleModel(economics.totalProjectCost, energy, buildingCalc);

    // Luxury Score Calculation
    const luxuryScore = this.calculateLuxuryScore(inputs, buildingCalc, rooms);

    // STEP 15: Engineering Validation & Warnings
    const warnings = this.generateEngineeringWarnings(buildingCalc, inputs, energy, schedule, rooms);

    // Generate Simulation Events
    const events = this.generateSimulationEvents(schedule);

    return {
      inputs,
      buildingCalc,
      rooms,
      economics,
      materials,
      labour,
      machinery,
      schedule,
      energy,
      lifecycle,
      warnings,
      events,
      totalEmbodiedCarbonTonnes: Math.round(totalEmbodiedCarbonTonnes * 10) / 10,
      luxuryScore
    };
  }

  /**
   * Room Schedule Generation
   */
  private static generateRoomSchedule(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    userRooms?: Partial<Record<RoomType, number>>
  ): RoomScheduleItem[] {
    // Default proportion heuristics based on area
    const totalArea = b.floorAreaSqFt;
    
    const bedroomCount = userRooms?.bedrooms ?? Math.max(3, Math.floor(totalArea / 1200));
    const bathroomCount = userRooms?.bathrooms ?? Math.max(2, Math.floor(bedroomCount * 1.2));
    const kitchenCount = userRooms?.kitchens ?? 1;
    const livingCount = userRooms?.living ?? Math.max(1, Math.floor(totalArea / 2500));
    const diningCount = userRooms?.dining ?? 1;
    const officeCount = userRooms?.offices ?? (totalArea > 4000 ? 1 : 0);
    const libraryCount = userRooms?.libraries ?? (totalArea > 6000 ? 1 : 0);
    const garageCount = userRooms?.garages ?? (b.garageCars > 0 ? 1 : 0);
    const utilityCount = userRooms?.utility ?? 1;
    const plantCount = userRooms?.plant ?? 1;
    const cinemaCount = userRooms?.cinemas ?? (totalArea > 5000 ? 1 : 0);
    const gymCount = userRooms?.gyms ?? (totalArea > 4500 ? 1 : 0);
    const wineCellarCount = userRooms?.wineCellars ?? (b.basement && totalArea > 5000 ? 1 : 0);
    const guestSuiteCount = userRooms?.guestSuites ?? (totalArea > 6500 ? 1 : 0);

    const items: { type: RoomType; label: string; count: number; avgSqFt: number; finish: string; mep: string }[] = [
      { type: 'bedrooms', label: 'Primary & Guest Bedrooms', count: bedroomCount, avgSqFt: 380, finish: 'Hardwood / Plush Carpet', mep: 'HVAC Zone, Smart Lighting' },
      { type: 'bathrooms', label: 'Bathrooms & En-Suites', count: bathroomCount, avgSqFt: 180, finish: 'Marble / Heated Tile', mep: 'Plumbing Stack, Radiant Heat, Exhaust' },
      { type: 'kitchens', label: 'Chef Kitchen & Pantry', count: kitchenCount, avgSqFt: 520, finish: 'Quartzite Countertops, Custom Joinery', mep: 'Gas/Induction 100A, Heavy Plumbing, Commercial Hood' },
      { type: 'living', label: 'Great Room & Family Living', count: livingCount, avgSqFt: 650, finish: 'Engineered Oak, Fireplace Surround', mep: 'Architectural Lighting, Multi-zone Audio' },
      { type: 'dining', label: 'Formal Dining Room', count: diningCount, avgSqFt: 320, finish: 'Hardwood / Coffered Ceiling', mep: 'Dimmable Lighting Array' },
      { type: 'offices', label: 'Executive Office', count: officeCount, avgSqFt: 280, finish: 'Walnut Paneling, Acoustic Drywall', mep: 'Dedicated Fiber / High Speed Data' },
      { type: 'libraries', label: 'Library & Reading Suite', count: libraryCount, avgSqFt: 250, finish: 'Floor-to-Ceiling Millwork', mep: 'Low-UV Lighting, Climate Humidity Control' },
      { type: 'garages', label: 'Automotive Gallery', count: garageCount, avgSqFt: b.garageAreaSqFt, finish: 'Epoxy Polyaspartic Floor', mep: 'EV Fast Chargers (80A), Ventilation' },
      { type: 'utility', label: 'Laundry & Utility Room', count: utilityCount, avgSqFt: 160, finish: 'Porcelain Tile', mep: 'Dual Washer Plumbing, Heavy Drainage' },
      { type: 'plant', label: 'Mechanical & MEP Plant Room', count: plantCount, avgSqFt: 220, finish: 'Industrial Sealed Concrete', mep: 'Main Electrical Panel, Geothermal/Boiler Stacks' },
      { type: 'cinemas', label: 'Private Dolby Atmos Cinema', count: cinemaCount, avgSqFt: 380, finish: 'Acoustic Wall Panels, Tiered Seating', mep: '4K Projection Power, Integrated Audio Routing' },
      { type: 'gyms', label: 'Wellness Gym & Sauna', count: gymCount, avgSqFt: 320, finish: 'Impact Rubber Flooring, Mirrors', mep: 'Heavy HVAC Cooling, Sauna Power (240V)' },
      { type: 'wineCellars', label: 'Temperature-Controlled Cellar', count: wineCellarCount, avgSqFt: 180, finish: 'Custom Mahogany Racks, Stone Wall', mep: 'Precision Humidity & Climate Unit' },
      { type: 'guestSuites', label: 'Detached/Attached Guest Suite', count: guestSuiteCount, avgSqFt: 450, finish: 'Full Residential Spec', mep: 'Sub-panel MEP Services' },
    ];

    return items.filter(item => item.count > 0).map(item => {
      const area = item.type === 'garages' ? item.avgSqFt : item.count * item.avgSqFt;
      const volume = area * b.ceilingHeight;
      const costPerSqFt = item.type === 'bathrooms' ? 320 : item.type === 'kitchens' ? 410 : item.type === 'cinemas' ? 380 : 210;
      return {
        type: item.type,
        label: item.label,
        count: item.count,
        areaSqFt: area,
        volumeCuFt: volume,
        cost: area * costPerSqFt,
        finishSpec: item.finish,
        laborHours: Math.round(area * 1.8),
        mepReq: item.mep
      };
    });
  }

  /**
   * Material Quantities Engine
   */
  private static calculateMaterials(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    matMult: number
  ): MaterialRequirement[] {
    const list: MaterialRequirement[] = [];

    // Concrete (Footings, Slabs, Foundation Walls, Basement)
    const slabThicknessFt = 0.5;
    const foundationWallVolumeYd3 = (b.footprintSqFt * (b.basement ? 10 : 4) * 0.15) / 27;
    const slabVolumeYd3 = (b.grossFloorAreaSqFt * slabThicknessFt) / 27;
    const totalConcreteYd3 = Math.round((foundationWallVolumeYd3 + slabVolumeYd3) * 1.1);
    const concreteUnitCost = 145 * matMult; // $ per yd3
    list.push({
      key: 'concrete',
      name: 'Ready-Mix Concrete (C35/40)',
      category: 'Structure',
      quantity: totalConcreteYd3,
      unit: 'yd³',
      unitCost: concreteUnitCost,
      totalCost: totalConcreteYd3 * concreteUnitCost,
      wastePct: 5,
      embodiedCarbonTonnes: totalConcreteYd3 * 0.28
    });

    // Rebar / Reinforcement
    const rebarTonnes = Math.round(totalConcreteYd3 * 0.045 * 10) / 10;
    const rebarCost = 1250 * matMult;
    list.push({
      key: 'rebar',
      name: 'High-Tensile Steel Rebar (Grade 60)',
      category: 'Structure',
      quantity: rebarTonnes,
      unit: 'tonnes',
      unitCost: rebarCost,
      totalCost: rebarTonnes * rebarCost,
      wastePct: 4,
      embodiedCarbonTonnes: rebarTonnes * 1.8
    });

    // Structural Steel / Timber Framing
    const timberTonnes = Math.round((b.grossFloorAreaSqFt * 0.012) * 10) / 10;
    const timberUnitCost = 1850 * matMult;
    list.push({
      key: 'timber',
      name: 'Engineered Structural Lumber (LVL & Glulam)',
      category: 'Structure',
      quantity: timberTonnes,
      unit: 'tonnes',
      unitCost: timberUnitCost,
      totalCost: timberTonnes * timberUnitCost,
      wastePct: 7,
      embodiedCarbonTonnes: timberTonnes * 0.4
    });

    // Facade / Exterior Cladding
    let exteriorUnitCost = 18;
    let exteriorName = 'Architectural Brick Veneer';
    let carbonPerSqFt = 0.008;

    switch (inputs.exterior) {
      case 'limestone':
        exteriorUnitCost = 42; exteriorName = 'Indiana Cut Limestone Slabs'; carbonPerSqFt = 0.015; break;
      case 'sandstone':
        exteriorUnitCost = 38; exteriorName = 'Ashlar Cut Sandstone Masonry'; carbonPerSqFt = 0.014; break;
      case 'granite':
        exteriorUnitCost = 55; exteriorName = 'Thermal Granite Wall Panels'; carbonPerSqFt = 0.022; break;
      case 'stone_brick':
        exteriorUnitCost = 32; exteriorName = 'Combined Natural Stone & Facing Brick'; carbonPerSqFt = 0.012; break;
      case 'render':
        exteriorUnitCost = 14; exteriorName = 'Insulated Silicone Render Finish'; carbonPerSqFt = 0.005; break;
      case 'timber':
        exteriorUnitCost = 22; exteriorName = 'Thermo-Treated Cedar Cladding'; carbonPerSqFt = 0.004; break;
      default:
        exteriorUnitCost = 18; exteriorName = 'Architectural Clay Brick Veneer'; carbonPerSqFt = 0.008; break;
    }

    const netWallAreaSqFt = Math.round(b.externalWallAreaSqFt - b.windowAreaSqFt);
    const exteriorTotalCost = netWallAreaSqFt * exteriorUnitCost * matMult;
    list.push({
      key: 'facade',
      name: exteriorName,
      category: 'Envelope',
      quantity: netWallAreaSqFt,
      unit: 'sq ft',
      unitCost: exteriorUnitCost * matMult,
      totalCost: exteriorTotalCost,
      wastePct: 8,
      embodiedCarbonTonnes: Math.round(netWallAreaSqFt * carbonPerSqFt * 10) / 10
    });

    // Roofing Material
    let roofUnitCost = 6;
    let roofName = 'Architectural Asphalt Shingles';
    if (inputs.roof === 'slate') { roofUnitCost = 24; roofName = 'Natural Welsh Slate Tiles'; }
    if (inputs.roof === 'synthetic_slate') { roofUnitCost = 15; roofName = 'Composite Synthetic Slate'; }
    if (inputs.roof === 'metal') { roofUnitCost = 18; roofName = 'Standing Seam Zinc-Aluminum Roof'; }
    if (inputs.roof === 'tile') { roofUnitCost = 16; roofName = 'Clay Terracotta Roof Tiles'; }

    const roofQty = Math.round(b.roofAreaSqFt);
    list.push({
      key: 'roofing',
      name: roofName,
      category: 'Envelope',
      quantity: roofQty,
      unit: 'sq ft',
      unitCost: roofUnitCost * matMult,
      totalCost: roofQty * roofUnitCost * matMult,
      wastePct: 6,
      embodiedCarbonTonnes: Math.round(roofQty * 0.009 * 10) / 10
    });

    // Glazing / Windows
    let windowUnitCost = 45;
    let windowName = 'Low-E Double Glazed Windows';
    if (inputs.windows === 'premium') { windowUnitCost = 85; windowName = 'Triple Glazed Argon Aluminum Clad'; }
    if (inputs.windows === 'luxury') { windowUnitCost = 140; windowName = 'Structural Thermal Glass Curtains'; }
    if (inputs.windows === 'architectural') { windowUnitCost = 210; windowName = 'Motorized Minimalist Slim-Profile Glazing'; }

    const glazingQty = Math.round(b.windowAreaSqFt);
    list.push({
      key: 'glazing',
      name: windowName,
      category: 'Envelope',
      quantity: glazingQty,
      unit: 'sq ft',
      unitCost: windowUnitCost * matMult,
      totalCost: glazingQty * windowUnitCost * matMult,
      wastePct: 3,
      embodiedCarbonTonnes: Math.round(glazingQty * 0.02 * 10) / 10
    });

    // Insulation
    let insUnitCost = 3.5;
    let insName = 'R-21 Mineral Wool Insulation';
    if (inputs.insulation === 'Premium') { insUnitCost = 6.2; insName = 'R-38 High-Density Rigid PIR Insulation'; }
    if (inputs.insulation === 'Passive') { insUnitCost = 9.8; insName = 'Passivhaus Air-Tight Quad Insulation System'; }

    const insQty = Math.round(b.externalWallAreaSqFt + b.roofAreaSqFt);
    list.push({
      key: 'insulation',
      name: insName,
      category: 'Envelope',
      quantity: insQty,
      unit: 'sq ft',
      unitCost: insUnitCost * matMult,
      totalCost: insQty * insUnitCost * matMult,
      wastePct: 5,
      embodiedCarbonTonnes: Math.round(insQty * 0.003 * 10) / 10
    });

    // Drywall & Interior Walls
    const drywallSqFt = Math.round(b.grossFloorAreaSqFt * 3.8);
    list.push({
      key: 'drywall',
      name: '5/8 Type-X Fire & Acoustic Gypsum Drywall',
      category: 'Finishes',
      quantity: drywallSqFt,
      unit: 'sq ft',
      unitCost: 2.8 * matMult,
      totalCost: drywallSqFt * 2.8 * matMult,
      wastePct: 8,
      embodiedCarbonTonnes: Math.round(drywallSqFt * 0.0018 * 10) / 10
    });

    // MEP Materials (Cables, Plumbing Pipe, HVAC Equipment)
    const cableLinearFt = Math.round(b.grossFloorAreaSqFt * 4.5);
    list.push({
      key: 'cables',
      name: 'THHN Copper Wiring & Armored Cable',
      category: 'MEP',
      quantity: cableLinearFt,
      unit: 'linear ft',
      unitCost: 3.2 * matMult,
      totalCost: cableLinearFt * 3.2 * matMult,
      wastePct: 5,
      embodiedCarbonTonnes: Math.round(cableLinearFt * 0.0008 * 10) / 10
    });

    const plumbingPipeFt = Math.round(b.grossFloorAreaSqFt * 2.2);
    list.push({
      key: 'plumbing',
      name: 'PEX-a & Cast Iron Acoustic Soil Pipes',
      category: 'MEP',
      quantity: plumbingPipeFt,
      unit: 'linear ft',
      unitCost: 6.5 * matMult,
      totalCost: plumbingPipeFt * 6.5 * matMult,
      wastePct: 4,
      embodiedCarbonTonnes: Math.round(plumbingPipeFt * 0.0012 * 10) / 10
    });

    // HVAC Plant Equipment
    const hvacTons = Math.round(b.conditionedFloorAreaSqFt / 450);
    let hvacEquipCost = 4200;
    let hvacName = `${hvacTons}-Ton High Efficiency Gas Central Plant`;
    if (inputs.hvac === 'Heat Pump') { hvacEquipCost = 6500; hvacName = `${hvacTons}-Ton Variable Refrigerant Heat Pump System`; }
    if (inputs.hvac === 'Geothermal') { hvacEquipCost = 12500; hvacName = `${hvacTons}-Ton Closed-Loop Geothermal Ground Exchange`; }

    list.push({
      key: 'hvac_plant',
      name: hvacName,
      category: 'MEP',
      quantity: hvacTons,
      unit: 'tons capacity',
      unitCost: hvacEquipCost * matMult,
      totalCost: hvacTons * hvacEquipCost * matMult,
      wastePct: 2,
      embodiedCarbonTonnes: Math.round(hvacTons * 1.2 * 10) / 10
    });

    return list;
  }

  /**
   * Labour Engine
   */
  private static calculateLabour(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    materials: MaterialRequirement[],
    labourMult: number
  ): TradeLabour[] {
    const trades: TradeLabour[] = [];

    // Base hourly rates
    const baseRates: Record<string, { rate: number; prodNote: string; factor: number }> = {
      'Excavation & Earthworks': { rate: 65, prodNote: '120 cu yd / worker-day', factor: b.basement ? 1.6 : 1.0 },
      'Concrete & Foundation': { rate: 72, prodNote: '18 cu yd / worker-day', factor: 1.0 },
      'Steel & Framing Carpenters': { rate: 78, prodNote: '180 sq ft framing / worker-day', factor: b.floors > 2 ? 1.25 : 1.0 },
      'Masons & Exterior Stone': { rate: 85, prodNote: inputs.exterior.includes('stone') ? '35 sq ft stone / worker-day' : '110 sq ft brick / worker-day', factor: inputs.exterior.includes('stone') || inputs.exterior.includes('limestone') ? 2.1 : 1.0 },
      'Roofing Specialists': { rate: 75, prodNote: '220 sq ft roofing / worker-day', factor: inputs.roof === 'slate' ? 1.8 : 1.0 },
      'Electricians': { rate: 88, prodNote: '140 sq ft MEP / worker-day', factor: 1.0 },
      'Plumbers & Pipefitters': { rate: 86, prodNote: '160 sq ft MEP / worker-day', factor: 1.0 },
      'HVAC Technicians': { rate: 90, prodNote: '250 sq ft HVAC / worker-day', factor: inputs.hvac === 'Geothermal' ? 1.6 : 1.0 },
      'Drywall & Plasterers': { rate: 62, prodNote: '450 sq ft drywall / worker-day', factor: 1.0 },
      'Finish Joiners & Painters': { rate: 68, prodNote: '200 sq ft finishes / worker-day', factor: 1.0 },
      'Flooring Installers': { rate: 64, prodNote: '280 sq ft flooring / worker-day', factor: 1.0 },
      'Landscapers & Hardscapers': { rate: 58, prodNote: '350 sq ft site / worker-day', factor: inputs.swimmingPool ? 1.5 : 1.0 }
    };

    const area = b.grossFloorAreaSqFt;

    for (const [trade, info] of Object.entries(baseRates)) {
      const baseHours = Math.round((area * 0.12) * info.factor);
      const hours = Math.max(120, baseHours);
      const workersRequired = Math.max(2, Math.min(12, Math.ceil(hours / 180)));
      const hourlyRate = Math.round(info.rate * labourMult);
      const totalLabourCost = hours * hourlyRate;

      trades.push({
        trade,
        workersRequired,
        hours,
        hourlyRate,
        totalLabourCost,
        productivityNote: info.prodNote
      });
    }

    return trades;
  }

  /**
   * Machinery Engine
   */
  private static calculateMachinery(
    b: BuildingAreaCalc
  ): MachineryRequirement[] {
    const area = b.grossFloorAreaSqFt;
    const isLarge = area > 5500;
    const isMansion = area > 8000;

    const items: { type: string; count: number; dailyRate: number; activeDays: number }[] = [
      { type: 'Heavy Hydraulic Excavator (30T)', count: b.basement || isLarge ? 2 : 1, dailyRate: 1100, activeDays: b.basement ? 18 : 8 },
      { type: 'Tower Crane / Mobile Heavy Crane', count: isMansion || b.floors >= 3 ? 1 : (isLarge ? 1 : 0), dailyRate: 2400, activeDays: isMansion ? 35 : 18 },
      { type: 'Rough-Terrain Telehandler', count: isLarge ? 2 : 1, dailyRate: 650, activeDays: 45 },
      { type: 'Concrete Pump Truck (42m Boom)', count: 1, dailyRate: 1800, activeDays: b.basement ? 12 : 6 },
      { type: 'Articulated Dump Trucks (20T)', count: b.basement ? 3 : 1, dailyRate: 750, activeDays: 10 },
      { type: 'Electric Scissor & Boom Lifts', count: isLarge ? 3 : 2, dailyRate: 320, activeDays: 50 },
      { type: 'Modular Facade Scaffolding System', count: 1, dailyRate: 480, activeDays: 65 },
      { type: 'Site Power Generators (150 kVA)', count: 1, dailyRate: 290, activeDays: 90 },
    ];

    return items.map(i => ({
      equipmentType: i.type,
      count: i.count,
      dailyRate: i.dailyRate,
      activeDays: i.activeDays,
      totalCost: i.count * i.dailyRate * i.activeDays
    }));
  }

  /**
   * Construction Schedule Engine & Weather Effects
   */
  private static calculateSchedule(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    labour: TradeLabour[],
    machinery: MachineryRequirement[],
    locInfo: LocationMetric
  ): { schedule: ConstructionSchedule; weatherConfig: WeatherConfig } {
    const area = b.grossFloorAreaSqFt;
    const scaleFactor = Math.pow(area / 3000, 0.42);

    // Weather impact
    const rainfallMm = locInfo.rainfallMm;
    const avgTempC = locInfo.avgTempC;
    const snowProbPct = locInfo.snowProbPct;
    let prodImpactPct = 0;

    if (rainfallMm > 1000) prodImpactPct += 12;
    if (avgTempC < 8) prodImpactPct += 15;
    if (snowProbPct > 25) prodImpactPct += 20;

    const weatherDelayDays = Math.round(locInfo.weatherDelayDays * (1 + prodImpactPct / 100));
    const curingDelayDays = avgTempC < 10 ? 6 : 3;

    // Stage Base Durations in Days
    const sitePrepDays = Math.round(10 * scaleFactor);
    const excavationDays = Math.round((b.basement ? 24 : 12) * scaleFactor);
    const foundationDays = Math.round((18 + curingDelayDays) * scaleFactor);
    const basementDays = b.basement ? Math.round(22 * scaleFactor) : 0;
    const structureDays = Math.round(32 * b.floors * scaleFactor);
    const roofDays = Math.round((inputs.roof === 'slate' ? 22 : 14) * scaleFactor);
    const envelopeDays = Math.round((inputs.exterior.includes('stone') ? 38 : 22) * scaleFactor);
    const windowDays = Math.round(14 * scaleFactor);
    const mepRoughDays = Math.round(28 * scaleFactor);
    const interiorDays = Math.round(45 * scaleFactor);
    const fixturesDays = Math.round(20 * scaleFactor);
    const landscapingDays = Math.round((inputs.swimmingPool ? 28 : 16) * scaleFactor);
    const commissioningDays = Math.round(12 * scaleFactor);

    let currentDay = 0;
    const stages: ScheduleStage[] = [];

    const addStage = (id: string, name: string, duration: number, deps: string[], critical: boolean, trades: string[], machines: string[]) => {
      if (duration <= 0) return;
      const startDay = currentDay;
      const endDay = startDay + duration;
      stages.push({
        id,
        name,
        durationDays: duration,
        startDay,
        endDay,
        dependencies: deps,
        isCriticalPath: critical,
        activeTrades: trades,
        activeMachinery: machines
      });
      currentDay = endDay;
    };

    addStage('site_prep', 'Site Preparation & Clearance', sitePrepDays, [], true, ['Excavation & Earthworks'], ['Heavy Hydraulic Excavator (30T)']);
    addStage('excavation', 'Bulk Excavation & Earthworks', excavationDays, ['site_prep'], true, ['Excavation & Earthworks'], ['Heavy Hydraulic Excavator (30T)', 'Articulated Dump Trucks (20T)']);
    addStage('foundations', 'Concrete Footings & Sub-Slab', foundationDays, ['excavation'], true, ['Concrete & Foundation'], ['Concrete Pump Truck (42m Boom)']);
    
    if (b.basement) {
      addStage('basement', 'Reinforced Basement Retaining Structure', basementDays, ['foundations'], true, ['Concrete & Foundation', 'Steel & Framing Carpenters'], ['Concrete Pump Truck (42m Boom)']);
    }

    addStage('structure', 'Structural Framing & Floor Slabs', structureDays, b.basement ? ['basement'] : ['foundations'], true, ['Steel & Framing Carpenters'], ['Tower Crane / Mobile Heavy Crane', 'Rough-Terrain Telehandler']);
    addStage('roof', 'Roof Truss & Weatherproof Decking', roofDays, ['structure'], true, ['Roofing Specialists'], ['Rough-Terrain Telehandler']);
    addStage('envelope', 'Exterior Facade & Masonry Enclosure', envelopeDays, ['roof'], true, ['Masons & Exterior Stone'], ['Modular Facade Scaffolding System']);
    addStage('windows', 'Window & Curtain Wall Glazing', windowDays, ['envelope'], true, ['Roofing Specialists'], ['Electric Scissor & Boom Lifts']);
    addStage('mep_rough', 'MEP Rough-In (Electric, Plumbing, HVAC)', mepRoughDays, ['windows'], true, ['Electricians', 'Plumbers & Pipefitters', 'HVAC Technicians'], ['Site Power Generators (150 kVA)']);
    addStage('interior', 'Drywall, Acoustic Plaster & Joinery', interiorDays, ['mep_rough'], true, ['Drywall & Plasterers', 'Finish Joiners & Painters'], []);
    addStage('fixtures', 'Flooring, Cabinetry & Luxury Fixtures', fixturesDays, ['interior'], false, ['Flooring Installers', 'Finish Joiners & Painters'], []);
    addStage('landscaping', 'Hardscaping, Pool & Exterior Grounds', landscapingDays, ['envelope'], false, ['Landscapers & Hardscapers'], ['Heavy Hydraulic Excavator (30T)']);
    addStage('commissioning', 'Building Automation & MEP Commissioning', commissioningDays, ['fixtures'], true, ['Electricians', 'HVAC Technicians'], []);

    const totalDurationDays = currentDay + weatherDelayDays;
    const startDate = new Date();
    const completionDate = new Date();
    completionDate.setDate(startDate.getDate() + totalDurationDays);

    const criticalPathSequence = stages.filter(s => s.isCriticalPath).map(s => s.name);

    return {
      schedule: {
        totalDurationDays,
        startDateStr: startDate.toISOString().split('T')[0],
        completionDateStr: completionDate.toISOString().split('T')[0],
        stages,
        criticalPathSequence,
        weatherDelayDays,
        weatherConfig: {
          rainfallMm,
          avgTempC,
          snowProbabilityPct: snowProbPct,
          productivityImpactPct: prodImpactPct,
          concreteCuringDelayDays: curingDelayDays,
          summary: `Regional weather factors incur +${weatherDelayDays} days delay (${prodImpactPct}% impact).`
        }
      },
      weatherConfig: {
        rainfallMm,
        avgTempC,
        snowProbabilityPct: snowProbPct,
        productivityImpactPct: prodImpactPct,
        concreteCuringDelayDays: curingDelayDays,
        summary: `Regional climate zone: ${locInfo.climateZone.toUpperCase()}.`
      }
    };
  }

  /**
   * Economic Engine (Hard, Soft, Other & Non-Linear Cost Curve)
   */
  private static calculateEconomics(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    materials: MaterialRequirement[],
    labour: TradeLabour[],
    machinery: MachineryRequirement[],
    schedule: ConstructionSchedule,
    locInfo: LocationMetric
  ): EconomicModel {
    // 1. HARD COST BREAKDOWN
    const materialsCost = materials.reduce((a, b) => a + b.totalCost, 0);
    const labourCost = labour.reduce((a, b) => a + b.totalLabourCost, 0);

    const sitePrep = Math.round(b.footprintSqFt * 14 * locInfo.materialMult);
    const excavation = Math.round((b.basement ? b.footprintSqFt * 32 : b.footprintSqFt * 8) * locInfo.materialMult);
    const foundations = Math.round(b.footprintSqFt * 28 * locInfo.materialMult);
    const structure = Math.round(materialsCost * 0.28 + labourCost * 0.25);
    const roof = Math.round((materials.find(m => m.key === 'roofing')?.totalCost || 0) * 1.8);
    const externalWalls = Math.round((materials.find(m => m.key === 'facade')?.totalCost || 0) * 1.7);
    const windows = Math.round((materials.find(m => m.key === 'glazing')?.totalCost || 0) * 1.4);
    const doors = Math.round(b.grossFloorAreaSqFt * 8);
    const mep = Math.round((materials.filter(m => m.category === 'MEP').reduce((a, b) => a + b.totalCost, 0)) * 2.2);
    const interiors = Math.round(b.grossFloorAreaSqFt * 65);
    const landscaping = Math.round((inputs.swimmingPool ? 185000 : 65000) * locInfo.materialMult);

    const totalHardCost = sitePrep + excavation + foundations + structure + roof + externalWalls + windows + doors + mep + interiors + landscaping;

    const hardCost: HardCostBreakdown = {
      sitePrep, excavation, foundations, structure, roof, externalWalls, windows, doors, mep, interiors, landscaping, totalHardCost
    };

    // 2. SOFT COST BREAKDOWN
    const architecture = Math.round(totalHardCost * 0.065 * locInfo.regulatoryMult);
    const engineering = Math.round(totalHardCost * 0.038);
    const surveying = Math.round(18500 * locInfo.regulatoryMult);
    const permits = Math.round(totalHardCost * 0.024 * locInfo.regulatoryMult);
    const projectManagement = Math.round(totalHardCost * 0.048);
    const inspections = Math.round(14200 * locInfo.regulatoryMult);

    const totalSoftCost = architecture + engineering + surveying + permits + projectManagement + inspections;

    const softCost: SoftCostBreakdown = {
      architecture, engineering, surveying, permits, projectManagement, inspections, totalSoftCost
    };

    // 3. OTHER COSTS
    const contingency = Math.round((totalHardCost + totalSoftCost) * 0.075);
    const temporaryWorks = Math.round(42000 * locInfo.materialMult);
    const logistics = Math.round(58000 * locInfo.materialMult);
    const financingAssumptions = Math.round((totalHardCost + totalSoftCost) * 0.035);

    const totalOtherCost = contingency + temporaryWorks + logistics + financingAssumptions;

    const otherCost: OtherCostBreakdown = {
      contingency, temporaryWorks, logistics, financingAssumptions, totalOtherCost
    };

    const totalProjectCost = totalHardCost + totalSoftCost + totalOtherCost;
    const areaSqFt = b.grossFloorAreaSqFt;
    const costPerSqFt = Math.round(totalProjectCost / areaSqFt);
    const costPerSqM = Math.round(costPerSqFt * 10.7639);

    // Non-linear marginal cost decomposition: TC = Fixed + Variable + Nonlinear
    const fixedCost = Math.round(totalSoftCost + temporaryWorks + logistics + surveying + permits);
    const baseUnitRate = 280; // $ per sqft variable linear component
    const variableCost = Math.round(areaSqFt * baseUnitRate * locInfo.materialMult);
    
    // Non-linear component based on special additions (basement, stone, luxury glazing, pool, geothermal, high floors)
    let nonlinearCost = 0;
    if (b.basement) nonlinearCost += b.basementAreaSqFt * 140;
    if (inputs.exterior.includes('stone') || inputs.exterior.includes('limestone') || inputs.exterior.includes('granite')) nonlinearCost += b.externalWallAreaSqFt * 45;
    if (inputs.hvac === 'Geothermal') nonlinearCost += 65000;
    if (inputs.windows === 'luxury' || inputs.windows === 'architectural') nonlinearCost += b.windowAreaSqFt * 90;
    if (inputs.swimmingPool) nonlinearCost += 120000;
    if (b.floors > 2) nonlinearCost += (b.floors - 2) * 85000;

    const currentMarginalCostPerSqFt = Math.round(baseUnitRate * locInfo.materialMult + (nonlinearCost / areaSqFt) * 0.6 + (totalHardCost / areaSqFt) * 0.25);
    const next500SqFtCost = Math.round(500 * currentMarginalCostPerSqFt);

    // Generate Cost Curve Points for Chart Rendering
    const costCurvePoints: CostCurvePoint[] = [];
    const minArea = Math.max(1500, Math.round(areaSqFt * 0.4));
    const maxArea = Math.round(areaSqFt * 1.8);
    const step = Math.round((maxArea - minArea) / 10);

    for (let q = minArea; q <= maxArea; q += step) {
      const qVar = q * baseUnitRate * locInfo.materialMult;
      const qNonLinear = nonlinearCost * Math.pow(q / areaSqFt, 1.28);
      const qTotal = fixedCost + qVar + qNonLinear;
      const qAvg = qTotal / q;
      const qMarginal = baseUnitRate * locInfo.materialMult + 1.28 * (qNonLinear / q);

      costCurvePoints.push({
        area: Math.round(q),
        totalCost: Math.round(qTotal),
        averageCost: Math.round(qAvg),
        marginalCost: Math.round(qMarginal)
      });
    }

    return {
      hardCost,
      softCost,
      otherCost,
      totalProjectCost,
      costPerSqFt,
      costPerSqM,
      fixedCost,
      variableCost,
      nonlinearCost,
      currentMarginalCostPerSqFt,
      next500SqFtCost,
      costCurvePoints,
      currentPositionArea: areaSqFt,
      nextOptimumArea: Math.round(areaSqFt * 1.08)
    };
  }

  /**
   * Energy & Thermal Model
   */
  private static calculateEnergyModel(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    locInfo: LocationMetric
  ): EnergyModel {
    const area = b.conditionedFloorAreaSqFt;
    const baseEUI = locInfo.climateZone === 'cold' ? 42 : locInfo.climateZone === 'hot' ? 38 : 30; // kWh/sqft/yr

    let insulationFactor = 1.0;
    if (inputs.insulation === 'Premium') insulationFactor = 0.75;
    if (inputs.insulation === 'Passive') insulationFactor = 0.45;

    let windowFactor = 1.0;
    if (inputs.windows === 'premium') windowFactor = 0.88;
    if (inputs.windows === 'luxury') windowFactor = 0.78;
    if (inputs.windows === 'architectural') windowFactor = 0.72;

    let hvacCOP = 3.2; // Gas/Electric standard
    let hvacFactor = 1.0;
    if (inputs.hvac === 'Heat Pump') { hvacCOP = 4.2; hvacFactor = 0.72; }
    if (inputs.hvac === 'Geothermal') { hvacCOP = 5.4; hvacFactor = 0.52; }

    const effectiveEUI = Math.round(baseEUI * insulationFactor * windowFactor * hvacFactor * 10) / 10;
    const annualEnergyDemandKWh = Math.round(area * effectiveEUI);

    const heatingDemandKWh = Math.round(annualEnergyDemandKWh * (locInfo.climateZone === 'cold' ? 0.55 : 0.30));
    const coolingDemandKWh = Math.round(annualEnergyDemandKWh * (locInfo.climateZone === 'hot' ? 0.50 : 0.22));
    const hotWaterDemandKWh = Math.round(annualEnergyDemandKWh * 0.15);
    const lightingKWh = Math.round(annualEnergyDemandKWh * 0.10);
    const ventilationKWh = Math.round(annualEnergyDemandKWh * 0.08);

    let solarGenerationKWh = 0;
    let batteryStorageKWh = 0;

    if (inputs.solar === 'Standard') {
      solarGenerationKWh = Math.round(b.roofAreaSqFt * 0.4 * 18); // ~18 kWh/sqft solar
      batteryStorageKWh = 27; // kWh tesla powerwall style
    } else if (inputs.solar === 'Maximum') {
      solarGenerationKWh = Math.round(b.roofAreaSqFt * 0.75 * 22);
      batteryStorageKWh = 64;
    }

    return {
      annualEnergyDemandKWh,
      heatingDemandKWh,
      coolingDemandKWh,
      hotWaterDemandKWh,
      lightingKWh,
      ventilationKWh,
      solarGenerationKWh,
      batteryStorageKWh,
      hvacEfficiencyCOP: hvacCOP,
      euiKWhPerSqFt: effectiveEUI
    };
  }

  /**
   * Lifecycle Cost Engine
   */
  private static calculateLifecycleModel(
    initialCost: number,
    energy: EnergyModel,
    b: BuildingAreaCalc
  ): LifecycleModel {
    const netKWh = Math.max(0, energy.annualEnergyDemandKWh - energy.solarGenerationKWh);
    const energyTariffPerKWh = 0.22; // average $0.22/kWh
    const annualEnergyCost = Math.round(netKWh * energyTariffPerKWh);

    const annualMaintenanceCost = Math.round(b.grossFloorAreaSqFt * 4.5);

    let year10Cost = initialCost;
    let year25Cost = initialCost;
    let year50Cost = initialCost;

    for (let y = 1; y <= 50; y++) {
      const compoundingEnergy = annualEnergyCost * Math.pow(1.03, y);
      const compoundingMaint = annualMaintenanceCost * Math.pow(1.025, y);
      const yearCost = compoundingEnergy + compoundingMaint;

      if (y <= 10) year10Cost += yearCost;
      if (y <= 25) year25Cost += yearCost;
      year50Cost += yearCost;
    }

    return {
      initialCost,
      annualEnergyCost,
      annualMaintenanceCost,
      year10Cost: Math.round(year10Cost),
      year25Cost: Math.round(year25Cost),
      year50Cost: Math.round(year50Cost),
      totalCostOfOwnership50Yr: Math.round(year50Cost)
    };
  }

  /**
   * Luxury Score Calculator (0 - 100)
   */
  private static calculateLuxuryScore(
    inputs: ProjectInputs,
    b: BuildingAreaCalc,
    rooms: RoomScheduleItem[]
  ): number {
    let score = 40; // baseline

    if (b.grossFloorAreaSqFt > 5000) score += 12;
    if (b.grossFloorAreaSqFt > 8000) score += 10;
    if (b.basement) score += 8;
    if (b.garageCars >= 3) score += 6;
    if (b.ceilingHeight >= 12) score += 6;

    if (inputs.exterior === 'limestone' || inputs.exterior === 'granite') score += 8;
    if (inputs.roof === 'slate' || inputs.roof === 'tile') score += 5;
    if (inputs.windows === 'luxury' || inputs.windows === 'architectural') score += 8;
    if (inputs.hvac === 'Geothermal') score += 6;
    if (inputs.swimmingPool) score += 8;

    const hasCinema = rooms.some(r => r.type === 'cinemas');
    const hasWine = rooms.some(r => r.type === 'wineCellars');
    const hasGym = rooms.some(r => r.type === 'gyms');
    if (hasCinema) score += 5;
    if (hasWine) score += 4;
    if (hasGym) score += 4;

    return Math.min(100, Math.round(score));
  }

  /**
   * Engineering Warnings & Rule Checks
   */
  private static generateEngineeringWarnings(
    b: BuildingAreaCalc,
    inputs: ProjectInputs,
    energy: EnergyModel,
    schedule: ConstructionSchedule,
    rooms: RoomScheduleItem[]
  ): EngineeringWarning[] {
    const list: EngineeringWarning[] = [];

    if (b.width / b.depth > 2.8 || b.depth / b.width > 2.8) {
      list.push({
        id: 'warn_span_ratio',
        severity: 'medium',
        category: 'Structural',
        title: 'High Building Aspect Ratio',
        message: 'Building footprint ratio exceeds 2.8:1. Additional lateral shear wall bracing and structural steel wind ties are required.'
      });
    }

    if (b.ceilingHeight > 14) {
      list.push({
        id: 'warn_ceiling_height',
        severity: 'high',
        category: 'Structural & HVAC',
        title: 'Excessive Story Height',
        message: 'Ceiling height exceeds 14ft. Structural column buckling criteria and thermal stratification demand high-volume displacement ventilation.'
      });
    }

    if (b.floorToWallRatio < 0.35) {
      list.push({
        id: 'warn_thermal_envelope',
        severity: 'medium',
        category: 'Thermal Envelope',
        title: 'High Exterior Surface Area',
        message: 'Low floor-to-wall area ratio increases conductive heat transfer losses. Passive or Premium insulation specified to offset EUI impact.'
      });
    }

    const plantRoom = rooms.find(r => r.type === 'plant');
    if (inputs.hvac === 'Geothermal' && (!plantRoom || plantRoom.areaSqFt < 200)) {
      list.push({
        id: 'warn_plant_space',
        severity: 'high',
        category: 'MEP Systems',
        title: 'Insufficient Mechanical Plant Footprint',
        message: 'Geothermal ground exchange heat pumps require at least 220 sq ft dedicated mechanical room area for manifold distribution.'
      });
    }

    if (b.basement && schedule.weatherConfig.snowProbabilityPct > 40) {
      list.push({
        id: 'warn_freeze_thaw',
        severity: 'medium',
        category: 'Geotechnical',
        title: 'Freeze-Thaw Hydrostatic Pressure',
        message: 'High cold climate probability for basement subterranean walls. Sub-slab perimeter drainage and dual membrane tanking mandated.'
      });
    }

    return list;
  }

  /**
   * Simulation Event Timeline Generator
   */
  private static generateSimulationEvents(schedule: ConstructionSchedule): SimulationEvent[] {
    const events: SimulationEvent[] = [];

    for (const stage of schedule.stages) {
      events.push({
        day: stage.startDay,
        type: `${stage.id.toUpperCase()}_STARTED`,
        description: `Stage [${stage.name}] initiated. Mobilizing ${stage.activeTrades.join(', ')}.`,
        stageId: stage.id,
        impactProgressPct: Math.round((stage.endDay / schedule.totalDurationDays) * 100)
      });
    }

    events.push({
      day: schedule.totalDurationDays,
      type: 'PROJECT_COMPLETE',
      description: 'Construction digital twin complete. Handover and occupancy commissioning verified.',
      stageId: 'complete',
      impactProgressPct: 100
    });

    return events;
  }

  /**
   * Helper to calculate Delta Impact when parameters change
   */
  public static calculateImpactDelta(
    oldState: ProjectState,
    newState: ProjectState
  ): SimulationImpactDelta {
    const areaDeltaSqFt = newState.buildingCalc.grossFloorAreaSqFt - oldState.buildingCalc.grossFloorAreaSqFt;
    const hardCostDelta = newState.economics.hardCost.totalHardCost - oldState.economics.hardCost.totalHardCost;
    const totalCostDelta = newState.economics.totalProjectCost - oldState.economics.totalProjectCost;
    
    const marginalCostPerSqFt = areaDeltaSqFt !== 0 
      ? Math.round(totalCostDelta / areaDeltaSqFt) 
      : newState.economics.currentMarginalCostPerSqFt;

    const oldConc = oldState.materials.find(m => m.key === 'concrete')?.quantity || 0;
    const newConc = newState.materials.find(m => m.key === 'concrete')?.quantity || 0;
    const concreteDeltaYd3 = newConc - oldConc;

    const oldTimber = oldState.materials.find(m => m.key === 'timber')?.quantity || 0;
    const newTimber = newState.materials.find(m => m.key === 'timber')?.quantity || 0;
    const timberDeltaTonnes = Math.round((newTimber - oldTimber) * 10) / 10;

    const oldStone = oldState.materials.find(m => m.key === 'facade')?.quantity || 0;
    const newStone = newState.materials.find(m => m.key === 'facade')?.quantity || 0;
    const stoneDeltaSqFt = newStone - oldStone;

    const oldWorkers = oldState.labour.reduce((a, b) => a + b.workersRequired, 0);
    const newWorkers = newState.labour.reduce((a, b) => a + b.workersRequired, 0);
    const workersDelta = newWorkers - oldWorkers;

    const durationDeltaDays = newState.schedule.totalDurationDays - oldState.schedule.totalDurationDays;

    const energyDemandDeltaPct = Math.round(
      ((newState.energy.annualEnergyDemandKWh - oldState.energy.annualEnergyDemandKWh) / Math.max(1, oldState.energy.annualEnergyDemandKWh)) * 100
    );

    const carbonDeltaTonnes = Math.round((newState.totalEmbodiedCarbonTonnes - oldState.totalEmbodiedCarbonTonnes) * 10) / 10;

    return {
      areaDeltaSqFt,
      hardCostDelta,
      totalCostDelta,
      marginalCostPerSqFt,
      concreteDeltaYd3,
      timberDeltaTonnes,
      stoneDeltaSqFt,
      workersDelta,
      durationDeltaDays,
      energyDemandDeltaPct,
      carbonDeltaTonnes
    };
  }
}
