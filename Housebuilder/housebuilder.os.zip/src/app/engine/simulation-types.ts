export type LocationRegion = 
  | 'UK'
  | 'US-Northeast'
  | 'US-Mid-Atlantic'
  | 'US-Southeast'
  | 'US-Midwest'
  | 'US-Southwest'
  | 'US-Mountain'
  | 'US-Pacific'
  | 'Canada'
  | 'Europe'
  | 'Australia'
  | 'Custom';

export type ArchitecturalStyle =
  | 'American Colonial'
  | 'Georgian'
  | 'Modern Estate'
  | 'Traditional Mansion'
  | 'Contemporary'
  | 'Mountain Estate';

export type ExteriorFinish =
  | 'brick'
  | 'render'
  | 'limestone'
  | 'sandstone'
  | 'granite'
  | 'stone_brick'
  | 'timber';

export type RoofType =
  | 'asphalt'
  | 'slate'
  | 'synthetic_slate'
  | 'metal'
  | 'tile';

export type WindowSpec =
  | 'standard'
  | 'premium'
  | 'luxury'
  | 'architectural';

export type InsulationSpec = 'Basic' | 'Premium' | 'Passive';
export type HvacSpec = 'Gas' | 'Heat Pump' | 'Geothermal';
export type SolarSpec = 'Off' | 'Standard' | 'Maximum';

export type RoomType =
  | 'bedrooms'
  | 'bathrooms'
  | 'kitchens'
  | 'living'
  | 'dining'
  | 'offices'
  | 'libraries'
  | 'garages'
  | 'utility'
  | 'plant'
  | 'cinemas'
  | 'gyms'
  | 'wineCellars'
  | 'guestSuites';

export interface RoomScheduleItem {
  type: RoomType;
  label: string;
  count: number;
  areaSqFt: number;
  volumeCuFt: number;
  cost: number;
  finishSpec: string;
  laborHours: number;
  mepReq: string;
}

export interface BuildingAreaCalc {
  width: number; // ft
  depth: number; // ft
  floors: number;
  basement: boolean;
  garageCars: number; // 0..4
  ceilingHeight: number; // ft
  footprintSqFt: number;
  floorAreaSqFt: number;
  grossFloorAreaSqFt: number;
  conditionedFloorAreaSqFt: number;
  basementAreaSqFt: number;
  garageAreaSqFt: number;
  roofAreaSqFt: number;
  externalWallAreaSqFt: number;
  windowAreaSqFt: number;
  floorToWallRatio: number;
  buildingVolumeCuFt: number;
}

export interface HardCostBreakdown {
  sitePrep: number;
  excavation: number;
  foundations: number;
  structure: number;
  roof: number;
  externalWalls: number;
  windows: number;
  doors: number;
  mep: number;
  interiors: number;
  landscaping: number;
  totalHardCost: number;
}

export interface SoftCostBreakdown {
  architecture: number;
  engineering: number;
  surveying: number;
  permits: number;
  projectManagement: number;
  inspections: number;
  totalSoftCost: number;
}

export interface OtherCostBreakdown {
  contingency: number;
  temporaryWorks: number;
  logistics: number;
  financingAssumptions: number;
  totalOtherCost: number;
}

export interface CostCurvePoint {
  area: number;
  totalCost: number;
  averageCost: number;
  marginalCost: number;
}

export interface EconomicModel {
  hardCost: HardCostBreakdown;
  softCost: SoftCostBreakdown;
  otherCost: OtherCostBreakdown;
  totalProjectCost: number;
  costPerSqFt: number;
  costPerSqM: number;
  fixedCost: number;
  variableCost: number;
  nonlinearCost: number;
  currentMarginalCostPerSqFt: number;
  next500SqFtCost: number;
  costCurvePoints: CostCurvePoint[];
  currentPositionArea: number;
  nextOptimumArea: number;
}

export interface MaterialRequirement {
  key: string;
  name: string;
  category: 'Structure' | 'Envelope' | 'MEP' | 'Finishes' | 'Site';
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
  wastePct: number;
  embodiedCarbonTonnes: number;
}

export interface TradeLabour {
  trade: string;
  workersRequired: number;
  hours: number;
  hourlyRate: number;
  totalLabourCost: number;
  productivityNote: string;
}

export interface MachineryRequirement {
  equipmentType: string;
  count: number;
  dailyRate: number;
  activeDays: number;
  totalCost: number;
}

export interface ScheduleStage {
  id: string;
  name: string;
  durationDays: number;
  startDay: number;
  endDay: number;
  dependencies: string[];
  isCriticalPath: boolean;
  activeTrades: string[];
  activeMachinery: string[];
}

export interface WeatherConfig {
  rainfallMm: number;
  avgTempC: number;
  snowProbabilityPct: number;
  productivityImpactPct: number;
  concreteCuringDelayDays: number;
  summary: string;
}

export interface ConstructionSchedule {
  totalDurationDays: number;
  startDateStr: string;
  completionDateStr: string;
  stages: ScheduleStage[];
  criticalPathSequence: string[];
  weatherDelayDays: number;
  weatherConfig: WeatherConfig;
}

export interface EnergyModel {
  annualEnergyDemandKWh: number;
  heatingDemandKWh: number;
  coolingDemandKWh: number;
  hotWaterDemandKWh: number;
  lightingKWh: number;
  ventilationKWh: number;
  solarGenerationKWh: number;
  batteryStorageKWh: number;
  hvacEfficiencyCOP: number;
  euiKWhPerSqFt: number;
}

export interface LifecycleModel {
  initialCost: number;
  annualEnergyCost: number;
  annualMaintenanceCost: number;
  year10Cost: number;
  year25Cost: number;
  year50Cost: number;
  totalCostOfOwnership50Yr: number;
}

export interface EngineeringWarning {
  id: string;
  severity: 'low' | 'medium' | 'high';
  category: string;
  title: string;
  message: string;
}

export interface SimulationEvent {
  day: number;
  type: string;
  description: string;
  stageId: string;
  impactProgressPct: number;
}

export interface ProjectInputs {
  projectName: string;
  location: LocationRegion;
  style: ArchitecturalStyle;
  exterior: ExteriorFinish;
  roof: RoofType;
  windows: WindowSpec;
  insulation: InsulationSpec;
  hvac: HvacSpec;
  solar: SolarSpec;
  swimmingPool: boolean;
}

export interface ProjectState {
  inputs: ProjectInputs;
  buildingCalc: BuildingAreaCalc;
  rooms: RoomScheduleItem[];
  economics: EconomicModel;
  materials: MaterialRequirement[];
  labour: TradeLabour[];
  machinery: MachineryRequirement[];
  schedule: ConstructionSchedule;
  energy: EnergyModel;
  lifecycle: LifecycleModel;
  warnings: EngineeringWarning[];
  events: SimulationEvent[];
  totalEmbodiedCarbonTonnes: number;
  luxuryScore: number; // 0 - 100
}

export interface SimulationImpactDelta {
  areaDeltaSqFt: number;
  hardCostDelta: number;
  totalCostDelta: number;
  marginalCostPerSqFt: number;
  concreteDeltaYd3: number;
  timberDeltaTonnes: number;
  stoneDeltaSqFt: number;
  workersDelta: number;
  durationDeltaDays: number;
  energyDemandDeltaPct: number;
  carbonDeltaTonnes: number;
}

export interface DesignSnapshot {
  id: string;
  name: string;
  timestamp: string;
  areaSqFt: number;
  floors: number;
  style: string;
  exterior: string;
  totalCost: number;
  costPerSqFt: number;
  marginalCost: number;
  durationDays: number;
  carbonTonnes: number;
  annualEnergyKWh: number;
  lifecycle50YrCost: number;
  luxuryScore: number;
  bedrooms: number;
  bathrooms: number;
  state: ProjectState;
}

export type OptimisationObjective =
  | 'MINIMUM_COST'
  | 'MAXIMUM_FLOOR_AREA'
  | 'MAXIMUM_LUXURY'
  | 'MINIMUM_ENERGY'
  | 'MINIMUM_CONSTRUCTION_TIME'
  | 'MAXIMUM_VALUE_PER_DOLLAR'
  | 'MINIMUM_LIFECYCLE_COST';
