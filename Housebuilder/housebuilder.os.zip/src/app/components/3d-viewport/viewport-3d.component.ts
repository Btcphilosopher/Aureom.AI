import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimulationService } from '../../services/simulation.service';
import { ThreeBuildingGenerator } from '../../engine/three-building-generator';

@Component({
  selector: 'app-viewport-3d',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #canvasContainer class="w-full h-full relative overflow-hidden bg-[#090d12]">
      <!-- Viewport Overlay Telemetry -->
      <div class="absolute top-3 left-3 z-10 pointer-events-none flex flex-col gap-1">
        <div class="flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-[#00f0ff] animate-pulse shadow-[0_0_8px_#00f0ff]"></span>
          <span class="font-mono text-[10px] text-[#00f0ff] tracking-widest font-bold uppercase">
            {{ isMiniPreview ? 'BIM PREVIEW // REALTIME 3D' : 'DIGITAL TWIN // SITE VIEWPORT' }}
          </span>
        </div>
        <span class="font-mono text-[9px] text-slate-500">
          PAR-GEOM v4.2 // ROTATION ACTIVE
        </span>
      </div>

      <!-- Controls Overlay -->
      <div class="absolute top-3 right-3 z-20 flex items-center gap-1 bg-[#0f1115]/80 backdrop-blur border border-slate-800 p-1 rounded-sm">
        <button 
          (click)="toggleCutaway()" 
          [class.bg-[#00f0ff]/20]="simService.isCutawayView()"
          [class.text-[#00f0ff]]="simService.isCutawayView()"
          [class.border-[#00f0ff]]="simService.isCutawayView()"
          class="px-2 py-0.5 font-mono text-[9px] border border-slate-700 text-slate-300 hover:border-[#00f0ff] transition-colors uppercase">
          Cutaway: {{ simService.isCutawayView() ? 'ON' : 'OFF' }}
        </button>
      </div>

      <!-- Live Stage Telemetry for Full Sim -->
      @if (!isMiniPreview) {
        <div class="absolute bottom-4 left-4 z-10 bg-[#0f1115]/90 border border-slate-800 p-3 font-mono text-xs max-w-sm">
          <div class="text-[9px] text-[#00f0ff] font-bold uppercase mb-1">Active Site Events</div>
          <div class="text-slate-200 font-bold mb-1">{{ activeStageName }}</div>
          <div class="text-[10px] text-slate-400">
            Workforce: <span class="text-[#ff6b00] font-bold">{{ activeWorkforceCount }} trades</span>
            | Equipment: <span class="text-[#00f0ff] font-bold">{{ activeMachineryCount }} units</span>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `]
})
export class Viewport3DComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;
  @Input() isMiniPreview = false;
  @Input() animationProgress = 100;

  public simService = inject(SimulationService);
  private generator?: ThreeBuildingGenerator;
  private resizeObserver?: ResizeObserver;

  constructor() {
    // Effect to update 3D mesh whenever state or options change
    effect(() => {
      const state = this.simService.currentState();
      const cutaway = this.simService.isCutawayView();
      const progress = this.animationProgress;

      if (this.generator) {
        this.generator.updateBuildingGeometry(state, progress, cutaway);
      }
    });
  }

  ngOnInit(): void {
    if (this.canvasContainer?.nativeElement) {
      this.generator = new ThreeBuildingGenerator(this.canvasContainer.nativeElement, this.isMiniPreview);
      
      this.resizeObserver = new ResizeObserver(() => {
        if (this.generator && this.canvasContainer?.nativeElement) {
          this.generator.onResize(this.canvasContainer.nativeElement);
        }
      });
      this.resizeObserver.observe(this.canvasContainer.nativeElement);

      // Initial build
      this.generator.updateBuildingGeometry(
        this.simService.currentState(),
        this.animationProgress,
        this.simService.isCutawayView()
      );
    }
  }

  toggleCutaway(): void {
    this.simService.isCutawayView.update(v => !v);
  }

  get activeStageName(): string {
    const stages = this.simService.currentState().schedule.stages;
    const currentDay = this.simService.activeStageDay();
    const current = stages.find(s => currentDay >= s.startDay && currentDay <= s.endDay);
    return current ? current.name : 'Mobilisation & Prep';
  }

  get activeWorkforceCount(): number {
    return this.simService.currentState().labour.reduce((a, b) => a + b.workersRequired, 0);
  }

  get activeMachineryCount(): number {
    return this.simService.currentState().machinery.reduce((a, b) => a + b.count, 0);
  }

  ngOnDestroy(): void {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.generator) {
      this.generator.destroy();
    }
  }
}
