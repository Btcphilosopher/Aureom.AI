import { Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimulationService } from '../../services/simulation.service';
import { CalculationEngine } from '../../engine/calculation-engine';

@Component({
  selector: 'app-economic-chart',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="w-full h-full flex flex-col justify-between">
      <!-- Live Stats Panel -->
      <div class="grid grid-cols-2 gap-2 mb-2">
        <div class="bg-[#111319] p-2.5 border border-slate-800">
          <div class="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Marginal Cost / Sq Ft</div>
          <div class="text-xl font-mono text-[#ff6b00] font-bold">
            \${{ currentMarginalCost().toLocaleString() }}
          </div>
          <div class="text-[8px] text-emerald-400 uppercase mt-0.5 font-mono">
            Optimal Range: 5,500 - 7,000 sq ft
          </div>
        </div>

        <div class="bg-[#111319] p-2.5 border border-slate-800">
          <div class="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Total Capital Cost</div>
          <div class="text-xl font-mono text-slate-100 font-bold">
            \${{ currentTotalCost().toLocaleString() }}
          </div>
          <div class="text-[8px] text-[#00f0ff] uppercase mt-0.5 font-mono">
            \${{ currentCostPerSqFt() }}/sq ft avg
          </div>
        </div>
      </div>

      <!-- SVG Curve Graph -->
      <div class="flex-grow bg-[#0c0e12] border border-slate-800 p-2 relative flex flex-col justify-end min-h-[140px]">
        <div class="absolute top-2 left-2 z-10 text-[8px] font-mono text-slate-500 uppercase flex items-center gap-2">
          <span class="inline-block w-2 h-0.5 bg-[#ff6b00]"></span> Marginal Cost Curve (MC = dTC/dQ)
        </div>

        <svg class="w-full h-32 overflow-visible" viewBox="0 0 300 100" preserveAspectRatio="none">
          <!-- Grid Lines -->
          <line x1="0" y1="20" x2="300" y2="20" stroke="#1f2430" stroke-dasharray="2 2" />
          <line x1="0" y1="50" x2="300" y2="50" stroke="#1f2430" stroke-dasharray="2 2" />
          <line x1="0" y1="80" x2="300" y2="80" stroke="#1f2430" stroke-dasharray="2 2" />

          <!-- Marginal Cost Curve Path -->
          <path [attr.d]="svgCurvePath()" fill="none" stroke="#ff6b00" stroke-width="2.5" />

          <!-- Current Point Indicator -->
          <g [attr.transform]="'translate(' + currentPointCoords().x + ',' + currentPointCoords().y + ')'">
            <circle r="5" fill="#ff6b00" class="animate-ping opacity-75" />
            <circle r="4" fill="#ff6b00" stroke="#ffffff" stroke-width="1.5" />
            <line y1="0" y2="100" stroke="#ff6b00" stroke-dasharray="2 2" stroke-width="1" />
          </g>
        </svg>

        <!-- Axis Labels -->
        <div class="flex justify-between items-center text-[8px] font-mono text-slate-500 mt-1 border-t border-slate-800 pt-1">
          <span>3,000 SQ FT</span>
          <span class="text-[#ff6b00] font-bold">CURRENT: {{ currentArea().toLocaleString() }} SQ FT</span>
          <span>12,000 SQ FT</span>
        </div>
      </div>
    </div>
  `
})
export class EconomicChartComponent {
  private simService = inject(SimulationService);

  readonly currentArea = computed(() => this.simService.currentState().buildingCalc.grossFloorAreaSqFt);
  readonly currentMarginalCost = computed(() => this.simService.currentState().economics.currentMarginalCostPerSqFt);
  readonly currentTotalCost = computed(() => this.simService.currentState().economics.totalProjectCost);
  readonly currentCostPerSqFt = computed(() => this.simService.currentState().economics.costPerSqFt);

  // Generate curve data points from 3,000 to 12,000 sq ft
  readonly curvePoints = computed(() => {
    const inputs = this.simService.currentState().inputs;
    const points: { sqft: number; marginalCost: number; x: number; y: number }[] = [];

    const minArea = 3000;
    const maxArea = 12000;
    const steps = 20;

    for (let i = 0; i <= steps; i++) {
      const sqft = minArea + (i / steps) * (maxArea - minArea);
      const w = Math.sqrt(sqft * 1.6);
      const d = sqft / w;

      const calc = CalculationEngine.calculateProjectState(
        inputs,
        Math.round(w),
        Math.round(d),
        this.simService.floors(),
        this.simService.basement(),
        this.simService.garageCars(),
        this.simService.ceilingHeightFt()
      );

      const mc = calc.economics.currentMarginalCostPerSqFt;
      
      // X coordinate 0 to 300
      const x = (i / steps) * 300;
      // Y coordinate 0 to 100 (MC mapped from $400 - $1200 to SVG Y: 90 down to 10)
      const clampedMc = Math.max(400, Math.min(1300, mc));
      const y = 90 - ((clampedMc - 400) / 900) * 80;

      points.push({ sqft, marginalCost: mc, x, y });
    }

    return points;
  });

  readonly svgCurvePath = computed(() => {
    const points = this.curvePoints();
    if (!points.length) return '';
    return points.reduce((acc, p, idx) => {
      return idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`;
    }, '');
  });

  readonly currentPointCoords = computed(() => {
    const area = this.currentArea();
    const minArea = 3000;
    const maxArea = 12000;
    const normX = Math.max(0, Math.min(1, (area - minArea) / (maxArea - minArea)));
    const x = normX * 300;

    const mc = this.currentMarginalCost();
    const clampedMc = Math.max(400, Math.min(1300, mc));
    const y = 90 - ((clampedMc - 400) / 900) * 80;

    return { x, y };
  });
}
