import { Injectable, signal, computed } from '@angular/core';
import {
  ProjectInputs,
  ProjectState,
  DesignSnapshot,
  SimulationImpactDelta,
  OptimisationObjective,
  LocationRegion,
  ArchitecturalStyle,
  ExteriorFinish,
  RoofType,
  WindowSpec,
  InsulationSpec,
  HvacSpec,
  SolarSpec,
  RoomType
} from '../engine/simulation-types';
import { CalculationEngine } from '../engine/calculation-engine';
import { OptimizationEngine } from '../engine/optimization-engine';

@Injectable({
  providedIn: 'root'
})
export class SimulationService {
  // Mode: 'START_DASHBOARD' | 'BUILD_TRANSITION' | 'FULL_SIMULATION'
  readonly activeMode = signal<'START_DASHBOARD' | 'BUILD_TRANSITION' | 'FULL_SIMULATION'>('START_DASHBOARD');

  // Engineering Mode Toggle (Exposes underlying math, equations, coefficients)
  readonly engineeringMode = signal<boolean>(false);

  // Transition Step Message
  readonly transitionStepMessage = signal<string>('');
  readonly transitionProgressPct = signal<number>(0);

  // Core Inputs State Signals
  readonly projectName = signal<string>('American Stone Estate');
  readonly location = signal<LocationRegion>('US-Northeast');
  readonly style = signal<ArchitecturalStyle>('Traditional Mansion');
  readonly exterior = signal<ExteriorFinish>('limestone');
  readonly roof = signal<RoofType>('slate');
  readonly windows = signal<WindowSpec>('luxury');
  readonly insulation = signal<InsulationSpec>('Premium');
  readonly hvac = signal<HvacSpec>('Geothermal');
  readonly solar = signal<SolarSpec>('Standard');
  readonly swimmingPool = signal<boolean>(true);

  // Building Dimensions
  readonly widthFt = signal<number>(72);
  readonly depthFt = signal<number>(44);
  readonly floors = signal<number>(2);
  readonly basement = signal<boolean>(true);
  readonly garageCars = signal<number>(3);
  readonly ceilingHeightFt = signal<number>(11);

  // Room Overrides (if any)
  readonly roomOverrides = signal<Partial<Record<RoomType, number>>>({});

  // Design Iterations / Snapshots
  readonly designSnapshots = signal<DesignSnapshot[]>([]);

  // Simulation View Controls
  readonly activeStageDay = signal<number>(0);
  readonly isCutawayView = signal<boolean>(false);
  readonly isMepOverlay = signal<boolean>(false);
  readonly isSimulationPlaying = signal<boolean>(false);

  // Previous State for Delta Calculation
  private previousState: ProjectState | null = null;

  // Primary Computed Project State
  readonly currentState = computed<ProjectState>(() => {
    const inputs: ProjectInputs = {
      projectName: this.projectName(),
      location: this.location(),
      style: this.style(),
      exterior: this.exterior(),
      roof: this.roof(),
      windows: this.windows(),
      insulation: this.insulation(),
      hvac: this.hvac(),
      solar: this.solar(),
      swimmingPool: this.swimmingPool()
    };

    return CalculationEngine.calculateProjectState(
      inputs,
      this.widthFt(),
      this.depthFt(),
      this.floors(),
      this.basement(),
      this.garageCars(),
      this.ceilingHeightFt(),
      this.roomOverrides()
    );
  });

  // Simulation Impact Delta Computed
  readonly simulationImpact = computed<SimulationImpactDelta | null>(() => {
    const curr = this.currentState();
    if (!this.previousState) return null;
    return CalculationEngine.calculateImpactDelta(this.previousState, curr);
  });

  constructor() {
    // Save initial design snapshot
    this.saveSnapshot('OPTION A - Default Estate');
  }

  /**
   * Called before user changes a major parameter to record previous state for Delta display
   */
  public recordStateForDelta(): void {
    this.previousState = JSON.parse(JSON.stringify(this.currentState()));
  }

  /**
   * Reset to Default American Stone Estate
   */
  public resetToDefault(): void {
    this.recordStateForDelta();
    this.projectName.set('American Stone Estate');
    this.location.set('US-Northeast');
    this.style.set('Traditional Mansion');
    this.exterior.set('limestone');
    this.roof.set('slate');
    this.windows.set('luxury');
    this.insulation.set('Premium');
    this.hvac.set('Geothermal');
    this.solar.set('Standard');
    this.swimmingPool.set(true);

    this.widthFt.set(72);
    this.depthFt.set(44);
    this.floors.set(2);
    this.basement.set(true);
    this.garageCars.set(3);
    this.ceilingHeightFt.set(11);
    this.roomOverrides.set({});
  }

  /**
   * Randomise Configuration
   */
  public randomiseBuilding(): void {
    this.recordStateForDelta();

    const names = ['Emerald Manor', 'Highland Crest Estate', 'Pacific Horizon Villa', 'Colonial Stone Mansion', 'Modern Glass Sanctuary', 'Georgian Reserve', 'Summit Alpine Lodge'];
    const locs: LocationRegion[] = ['UK', 'US-Northeast', 'US-Mid-Atlantic', 'US-Pacific', 'US-Mountain', 'Canada', 'Europe', 'Australia'];
    const styles: ArchitecturalStyle[] = ['American Colonial', 'Georgian', 'Modern Estate', 'Traditional Mansion', 'Contemporary', 'Mountain Estate'];
    const exteriors: ExteriorFinish[] = ['brick', 'render', 'limestone', 'sandstone', 'granite', 'stone_brick', 'timber'];
    const roofs: RoofType[] = ['asphalt', 'slate', 'synthetic_slate', 'metal', 'tile'];
    const windowsList: WindowSpec[] = ['standard', 'premium', 'luxury', 'architectural'];
    const insulations: InsulationSpec[] = ['Basic', 'Premium', 'Passive'];
    const hvacs: HvacSpec[] = ['Gas', 'Heat Pump', 'Geothermal'];
    const solars: SolarSpec[] = ['Off', 'Standard', 'Maximum'];

    const pick = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

    this.projectName.set(pick(names));
    this.location.set(pick(locs));
    this.style.set(pick(styles));
    this.exterior.set(pick(exteriors));
    this.roof.set(pick(roofs));
    this.windows.set(pick(windowsList));
    this.insulation.set(pick(insulations));
    this.hvac.set(pick(hvacs));
    this.solar.set(pick(solars));
    this.swimmingPool.set(Math.random() > 0.4);

    this.widthFt.set(Math.floor(Math.random() * 40) + 50); // 50 - 90 ft
    this.depthFt.set(Math.floor(Math.random() * 30) + 36); // 36 - 66 ft
    this.floors.set(Math.floor(Math.random() * 2) + 1); // 1 - 3
    this.basement.set(Math.random() > 0.3);
    this.garageCars.set(Math.floor(Math.random() * 3) + 1);
    this.ceilingHeightFt.set(Math.floor(Math.random() * 3) + 10);
  }

  /**
   * Apply Optimization Objectives
   */
  public applyOptimization(objective: OptimisationObjective): void {
    this.recordStateForDelta();
    const result = OptimizationEngine.optimize(
      this.currentState().inputs,
      this.widthFt(),
      this.depthFt(),
      objective
    );

    const rec = result.recommendedInputs;
    this.style.set(rec.style);
    this.exterior.set(rec.exterior);
    this.roof.set(rec.roof);
    this.windows.set(rec.windows);
    this.insulation.set(rec.insulation);
    this.hvac.set(rec.hvac);
    this.solar.set(rec.solar);
    this.swimmingPool.set(rec.swimmingPool);

    const dim = result.recommendedDimensions;
    this.widthFt.set(dim.widthFt);
    this.depthFt.set(dim.depthFt);
    this.floors.set(dim.floors);
    this.basement.set(dim.basement);
    this.garageCars.set(dim.garageCars);
    this.ceilingHeightFt.set(dim.ceilingHeightFt);

    if (result.recommendedRooms) {
      this.roomOverrides.set(result.recommendedRooms);
    }
  }

  /**
   * Save Snapshot Iteration
   */
  public saveSnapshot(customName?: string): void {
    const s = this.currentState();
    const count = this.designSnapshots().length + 1;
    const name = customName || `OPTION ${String.fromCharCode(64 + count)} (${s.buildingCalc.grossFloorAreaSqFt.toLocaleString()} sq ft)`;

    const bedrooms = s.rooms.find(r => r.type === 'bedrooms')?.count || 0;
    const bathrooms = s.rooms.find(r => r.type === 'bathrooms')?.count || 0;

    const snapshot: DesignSnapshot = {
      id: 'snap_' + Date.now(),
      name,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      areaSqFt: s.buildingCalc.grossFloorAreaSqFt,
      floors: s.buildingCalc.floors,
      style: s.inputs.style,
      exterior: s.inputs.exterior,
      totalCost: s.economics.totalProjectCost,
      costPerSqFt: s.economics.costPerSqFt,
      marginalCost: s.economics.currentMarginalCostPerSqFt,
      durationDays: s.schedule.totalDurationDays,
      carbonTonnes: s.totalEmbodiedCarbonTonnes,
      annualEnergyKWh: s.energy.annualEnergyDemandKWh,
      lifecycle50YrCost: s.lifecycle.totalCostOfOwnership50Yr,
      luxuryScore: s.luxuryScore,
      bedrooms,
      bathrooms,
      state: s
    };

    this.designSnapshots.update(list => [snapshot, ...list].slice(0, 5));
  }

  /**
   * Load a Snapshot
   */
  public loadSnapshot(snapshot: DesignSnapshot): void {
    this.recordStateForDelta();
    const state = snapshot.state;
    this.projectName.set(state.inputs.projectName);
    this.location.set(state.inputs.location);
    this.style.set(state.inputs.style);
    this.exterior.set(state.inputs.exterior);
    this.roof.set(state.inputs.roof);
    this.windows.set(state.inputs.windows);
    this.insulation.set(state.inputs.insulation);
    this.hvac.set(state.inputs.hvac);
    this.solar.set(state.inputs.solar);
    this.swimmingPool.set(state.inputs.swimmingPool);

    this.widthFt.set(state.buildingCalc.width);
    this.depthFt.set(state.buildingCalc.depth);
    this.floors.set(state.buildingCalc.floors);
    this.basement.set(state.buildingCalc.basement);
    this.garageCars.set(state.buildingCalc.garageCars);
    this.ceilingHeightFt.set(state.buildingCalc.ceilingHeight);
  }

  /**
   * Start "BUILD THIS HOUSE" Transition into 3D Construction Digital Twin
   */
  public startConstructionSimulation(): void {
    this.activeMode.set('BUILD_TRANSITION');
    this.transitionProgressPct.set(0);

    const steps = [
      { pct: 15, msg: 'CALCULATING PARAMETRIC DERIVATIVES...' },
      { pct: 30, msg: 'GENERATING HIGH-FIDELITY BIM GEOMETRY...' },
      { pct: 45, msg: 'CALCULATING MATERIAL QUANTITIES & LOGISTICS...' },
      { pct: 60, msg: 'ALLOCATING TRADE WORKFORCE & CREWS...' },
      { pct: 75, msg: 'ALLOCATING HEAVY MACHINERY & EQUIPMENT...' },
      { pct: 90, msg: 'GENERATING CRITICAL PATH PROGRAMME...' },
      { pct: 100, msg: 'INITIALISING DIGITAL TWIN SIMULATION...' }
    ];

    let idx = 0;
    const interval = setInterval(() => {
      if (idx < steps.length) {
        this.transitionProgressPct.set(steps[idx].pct);
        this.transitionStepMessage.set(steps[idx].msg);
        idx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          this.activeMode.set('FULL_SIMULATION');
          this.activeStageDay.set(0);
          this.isSimulationPlaying.set(true);
        }, 500);
      }
    }, 400);
  }

  /**
   * Exit Simulation back to Start Control Dashboard
   */
  public exitSimulationToDashboard(): void {
    this.activeMode.set('START_DASHBOARD');
    this.isSimulationPlaying.set(false);
  }
}
