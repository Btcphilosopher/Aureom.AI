import { ChangeDetectionStrategy, Component, inject, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimulationService } from './services/simulation.service';
import { Viewport3DComponent } from './components/3d-viewport/viewport-3d.component';
import { EconomicChartComponent } from './components/economic-chart/economic-chart.component';
import {
  LocationRegion,
  ArchitecturalStyle,
  ExteriorFinish,
  RoofType,
  WindowSpec,
  InsulationSpec,
  HvacSpec,
  SolarSpec,
  OptimisationObjective,
  ScheduleStage,
  SimulationEvent
} from './engine/simulation-types';
import { MatIconModule } from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, Viewport3DComponent, EconomicChartComponent, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnDestroy {
  public simService = inject(SimulationService);

  // Form selections and variables for loops in template
  readonly locations: { value: LocationRegion; label: string }[] = [
    { value: 'US-Northeast', label: 'US Northeast' },
    { value: 'US-Mid-Atlantic', label: 'US Mid-Atlantic' },
    { value: 'US-Southeast', label: 'US Southeast' },
    { value: 'US-Midwest', label: 'US Midwest' },
    { value: 'US-Southwest', label: 'US Southwest' },
    { value: 'US-Mountain', label: 'US Mountain' },
    { value: 'US-Pacific', label: 'US Pacific' },
    { value: 'UK', label: 'United Kingdom' },
    { value: 'Europe', label: 'Continental Europe' },
    { value: 'Canada', label: 'Canada' },
    { value: 'Australia', label: 'Australia' }
  ];

  readonly styles: ArchitecturalStyle[] = [
    'American Colonial',
    'Georgian',
    'Modern Estate',
    'Traditional Mansion',
    'Contemporary',
    'Mountain Estate'
  ];

  readonly exteriors: { value: ExteriorFinish; label: string }[] = [
    { value: 'brick', label: 'Classic Brick' },
    { value: 'render', label: 'Monocouche Render' },
    { value: 'limestone', label: 'Bespoke Limestone' },
    { value: 'sandstone', label: 'Ashlar Sandstone' },
    { value: 'granite', label: 'Polished Granite' },
    { value: 'stone_brick', label: 'Reconstituted Stone' },
    { value: 'timber', label: 'Sustainable Timber' }
  ];

  readonly roofs: { value: RoofType; label: string }[] = [
    { value: 'asphalt', label: 'Architectural Asphalt' },
    { value: 'slate', label: 'Natural Welsh Slate' },
    { value: 'synthetic_slate', label: 'Composite Slate' },
    { value: 'metal', label: 'Standing Seam Metal' },
    { value: 'tile', label: 'Clay Interlocking Tile' }
  ];

  readonly windows: { value: WindowSpec; label: string }[] = [
    { value: 'standard', label: 'Double Glazed PVC-U' },
    { value: 'premium', label: 'High Performance Alu-Clad' },
    { value: 'luxury', label: 'Minimalist Architectural Glazing' },
    { value: 'architectural', label: 'Bespoke Structural Glass' }
  ];

  readonly insulations: InsulationSpec[] = ['Basic', 'Premium', 'Passive'];
  readonly hvacs: HvacSpec[] = ['Gas', 'Heat Pump', 'Geothermal'];
  readonly solars: SolarSpec[] = ['Off', 'Standard', 'Maximum'];

  readonly optimizationObjectives: { value: OptimisationObjective; label: string; icon: string }[] = [
    { value: 'MINIMUM_COST', label: 'Minimum Cost', icon: 'payments' },
    { value: 'MAXIMUM_FLOOR_AREA', label: 'Max Floor Area', icon: 'zoom_out_map' },
    { value: 'MAXIMUM_LUXURY', label: 'Ultra Luxury', icon: 'diamond' },
    { value: 'MINIMUM_ENERGY', label: 'Energy Efficiency', icon: 'bolt' },
    { value: 'MINIMUM_CONSTRUCTION_TIME', label: 'Speed Build', icon: 'speed' },
    { value: 'MAXIMUM_VALUE_PER_DOLLAR', label: 'Value Focus', icon: 'trending_up' },
    { value: 'MINIMUM_LIFECYCLE_COST', label: 'Lifecycle Cost', icon: 'history' }
  ];

  // Manual snap name input
  public customSnapName = '';

  // Active view section tab
  public activeTab = signal<'specs' | 'hvac' | 'advanced'>('specs');

  onProjectNameChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.simService.recordStateForDelta();
    this.simService.projectName.set(value);
  }

  onLocationChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value as LocationRegion;
    this.simService.recordStateForDelta();
    this.simService.location.set(value);
  }

  onStyleChange(style: ArchitecturalStyle): void {
    this.simService.recordStateForDelta();
    this.simService.style.set(style);
  }

  onExteriorChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value as ExteriorFinish;
    this.simService.recordStateForDelta();
    this.simService.exterior.set(value);
  }

  onRoofChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value as RoofType;
    this.simService.recordStateForDelta();
    this.simService.roof.set(value);
  }

  onWindowsChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value as WindowSpec;
    this.simService.recordStateForDelta();
    this.simService.windows.set(value);
  }

  onInsulationChange(insulation: InsulationSpec): void {
    this.simService.recordStateForDelta();
    this.simService.insulation.set(insulation);
  }

  onHvacChange(hvac: HvacSpec): void {
    this.simService.recordStateForDelta();
    this.simService.hvac.set(hvac);
  }

  onSolarChange(solar: SolarSpec): void {
    this.simService.recordStateForDelta();
    this.simService.solar.set(solar);
  }

  toggleSwimmingPool(): void {
    this.simService.recordStateForDelta();
    this.simService.swimmingPool.update(v => !v);
  }

  onWidthChange(event: Event): void {
    const value = +(event.target as HTMLInputElement).value;
    this.simService.recordStateForDelta();
    this.simService.widthFt.set(value);
  }

  onDepthChange(event: Event): void {
    const value = +(event.target as HTMLInputElement).value;
    this.simService.recordStateForDelta();
    this.simService.depthFt.set(value);
  }

  onFloorsChange(floors: number): void {
    this.simService.recordStateForDelta();
    this.simService.floors.set(floors);
  }

  toggleBasement(): void {
    this.simService.recordStateForDelta();
    this.simService.basement.update(v => !v);
  }

  onGarageCarsChange(cars: number): void {
    this.simService.recordStateForDelta();
    this.simService.garageCars.set(cars);
  }

  onCeilingHeightChange(event: Event): void {
    const value = +(event.target as HTMLInputElement).value;
    this.simService.recordStateForDelta();
    this.simService.ceilingHeightFt.set(value);
  }

  onCustomSnapNameInput(event: Event): void {
    this.customSnapName = (event.target as HTMLInputElement).value;
  }

  saveSnapshot(): void {
    this.simService.saveSnapshot(this.customSnapName || undefined);
    this.customSnapName = '';
  }

  deleteSnapshot(id: string): void {
    this.simService.designSnapshots.update(list => list.filter(s => s.id !== id));
  }

  toggleEngineeringMode(): void {
    this.simService.engineeringMode.update(v => !v);
  }

  // Active Construction Time Control (Day slider)
  onActiveDayChange(event: Event): void {
    const value = +(event.target as HTMLInputElement).value;
    this.simService.activeStageDay.set(value);
  }

  toggleSimulationPlay(): void {
    this.simService.isSimulationPlaying.update(v => !v);
  }

  // Live simulation structural getters for full simulation templates
  get activeStageName(): string {
    const stages = this.simService.currentState().schedule.stages;
    const currentDay = this.simService.activeStageDay();
    const current = stages.find(s => currentDay >= s.startDay && currentDay <= s.endDay);
    return current ? current.name : 'Mobilisation & Prep';
  }

  get activePhaseLabel(): string {
    const currentDay = this.simService.activeStageDay();
    const totalDays = this.simService.currentState().schedule.totalDurationDays;
    const pct = currentDay / (totalDays || 1);
    if (pct < 0.15) return 'Excavation & Prep';
    if (pct < 0.4) return 'Substructure & Foundation';
    if (pct < 0.7) return 'Superstructure & Framing';
    if (pct < 0.9) return 'Mep, Glazing & Enclosure';
    return 'Interior finishes & Commissioning';
  }

  isStageCurrent(stg: ScheduleStage): boolean {
    const day = this.simService.activeStageDay();
    return day >= stg.startDay && day <= stg.endDay;
  }

  isStageCompleted(stg: ScheduleStage): boolean {
    const day = this.simService.activeStageDay();
    return day > stg.endDay;
  }

  get activeEvents(): SimulationEvent[] {
    const day = this.simService.activeStageDay();
    return this.simService.currentState().events.filter(e => e.day <= day).slice(-4);
  }

  get constructionPercentage(): number {
    const day = this.simService.activeStageDay();
    const total = this.simService.currentState().schedule.totalDurationDays;
    return Math.min(100, Math.round((day / (total || 1)) * 100));
  }

  // Simulated Time Loop for Full Construction Mode
  private simulationTimerId: ReturnType<typeof setInterval> | null = null;
  startSimulationPlayLoop(): void {
    if (this.simulationTimerId) return;
    this.simulationTimerId = setInterval(() => {
      if (this.simService.isSimulationPlaying() && this.simService.activeMode() === 'FULL_SIMULATION') {
        const totalDays = this.simService.currentState().schedule.totalDurationDays;
        const current = this.simService.activeStageDay();
        if (current < totalDays) {
          this.simService.activeStageDay.update(d => d + 2); // fast-forward 2 days per tick
        } else {
          this.simService.activeStageDay.set(0); // restart
        }
      }
    }, 150);
  }

  stopSimulationPlayLoop(): void {
    if (this.simulationTimerId) {
      clearInterval(this.simulationTimerId);
      this.simulationTimerId = null;
    }
  }

  constructor() {
    this.startSimulationPlayLoop();
  }

  ngOnDestroy(): void {
    this.stopSimulationPlayLoop();
  }
}
