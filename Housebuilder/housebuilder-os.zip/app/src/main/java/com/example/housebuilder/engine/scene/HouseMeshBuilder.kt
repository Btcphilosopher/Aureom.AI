package com.example.housebuilder.engine.scene

import androidx.compose.ui.graphics.Color
import com.example.housebuilder.engine.math.Polygon3D
import com.example.housebuilder.engine.math.Vector3
import com.example.housebuilder.model.*
import kotlin.math.cos
import kotlin.math.sin

/**
 * Procedural 3D Construction Mesh Generator for Housebuilder OS.
 * Generates accurate BIM geometry, animated machinery, workers, MEP conduits, and environmental scene.
 */
object HouseMeshBuilder {

    fun buildScenePolygons(
        currentDay: Int,
        config: ParametricHouseConfig,
        viewMode: ConstructionViewMode,
        explodedOffset: Float,
        selectedBimId: String?,
        selectedRoom: RoomType?,
        envState: SiteEnvironmentState,
        simulationTick: Float,
        activeMachinery: List<MachineryEntity>,
        activeWorkers: List<WorkerEntity>
    ): List<Polygon3D> {
        val polygons = mutableListOf<Polygon3D>()

        val currentStage = BuildingStage.forDay(currentDay)
        val w = config.widthMeters * 0.5f
        val l = config.lengthMeters * 0.5f
        val floorH = 2.8f
        val totalH = floorH * config.floorCount

        // Layer explosion vertical offsets
        val fndExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) -explodedOffset * 0.3f else 0f
        val slabExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 0.4f else 0f
        val gfWallsExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 1.0f else 0f
        val firstFlrExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 1.8f else 0f
        val ffWallsExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 2.5f else 0f
        val roofTrussExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 3.4f else 0f
        val roofTilesExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 4.2f else 0f
        val mepExplodeY = if (viewMode == ConstructionViewMode.EXPLODED_LAYERS) explodedOffset * 1.4f else 0f

        val isStructuralOnly = (viewMode == ConstructionViewMode.STRUCTURAL_FRAME)
        val isMepOnly = (viewMode == ConstructionViewMode.MEP_SERVICES)
        val isCutaway = (viewMode == ConstructionViewMode.CUTAWAY_XRAY)

        // -------------------------------------------------------------
        // 1. SITE TERRAIN & ENVIRONMENT
        // -------------------------------------------------------------
        if (!isMepOnly) {
            val grassColor = when (envState.season) {
                SeasonType.SPRING -> Color(0xFF4C8C2B)
                SeasonType.SUMMER -> Color(0xFF5B8A32)
                SeasonType.AUTUMN -> Color(0xFF7A7038)
                SeasonType.WINTER -> Color(0xFF8D99AE)
            }
            // Base ground plane (30m x 30m plot)
            polygons.add(
                createQuad(
                    v0 = Vector3(-16f, 0f, 16f),
                    v1 = Vector3(16f, 0f, 16f),
                    v2 = Vector3(16f, 0f, -16f),
                    v3 = Vector3(-16f, 0f, -16f),
                    color = grassColor,
                    tag = "Terrain"
                )
            )

            // Plot boundary security fence (Day 1+)
            if (currentDay >= 1) {
                buildPerimeterFence(polygons, 14f, 14f, currentDay)
            }

            // Site Access Road & Spoil Heap (Day 1..40)
            if (currentDay in 1..80) {
                // Hardcore construction access road
                polygons.add(
                    createQuad(
                        v0 = Vector3(-15f, 0.02f, 3f),
                        v1 = Vector3(-6f, 0.02f, 3f),
                        v2 = Vector3(-6f, 0.02f, -3f),
                        v3 = Vector3(-15f, 0.02f, -3f),
                        color = Color(0xFF78909C),
                        tag = "SiteAccessRoad"
                    )
                )
            }

            // Driveway & Landscaping (Day 234+)
            if (currentDay >= 234) {
                val paveProgress = ((currentDay - 234) / 6f).coerceIn(0f, 1f)
                val paveLen = 14f * paveProgress
                polygons.add(
                    createQuad(
                        v0 = Vector3(-w - 1f, 0.03f, 4f),
                        v1 = Vector3(-w - 1f + paveLen, 0.03f, 4f),
                        v2 = Vector3(-w - 1f + paveLen, 0.03f, -1f),
                        v3 = Vector3(-w - 1f, 0.03f, -1f),
                        color = Color(0xFF9E9E9E),
                        bimId = "LAND-DRIVE-01",
                        tag = "PermeableDriveway"
                    )
                )
                // Rear garden terrace patio
                polygons.add(
                    createQuad(
                        v0 = Vector3(-w, 0.03f, -l),
                        v1 = Vector3(w, 0.03f, -l),
                        v2 = Vector3(w, 0.03f, -l - 3.5f),
                        v3 = Vector3(-w, 0.03f, -l - 3.5f),
                        color = Color(0xFFB0BEC5),
                        bimId = "LAND-DRIVE-01",
                        tag = "PatioTerrace"
                    )
                )
            }
        }

        // -------------------------------------------------------------
        // 2. GROUNDWORKS, EXCAVATION & FOUNDATIONS (Y = -0.8m to 0m)
        // -------------------------------------------------------------
        if (currentDay >= 6 && (!isMepOnly || viewMode == ConstructionViewMode.EXPLODED_LAYERS)) {
            val excProgress = ((currentDay - 6) / 9f).coerceIn(0f, 1f)
            val trenchDepth = -0.8f * excProgress

            // Foundation Trench Excavation Cutaway
            buildTrenchPerimeter(polygons, w, l, trenchDepth + fndExplodeY, isExcavated = true)

            // Spoil Heap / Earth Mound during groundworks
            if (currentDay in 6..40) {
                buildSpoilHeap(polygons, Vector3(-w - 4f, 0f, 5f), 2.2f)
            }

            // Foundation Rebar Cages (Day 16-21)
            if (currentDay >= 16 && currentDay <= 28) {
                buildRebarMesh(polygons, w, l, trenchDepth * 0.7f + fndExplodeY)
            }

            // Concrete Footings Pour (Day 22+)
            if (currentDay >= 22) {
                val fndConcreteProgress = ((currentDay - 22) / 6f).coerceIn(0f, 1f)
                val concH = 0.45f * fndConcreteProgress
                buildTrenchPerimeter(
                    polygons,
                    w,
                    l,
                    -0.8f + concH + fndExplodeY,
                    isExcavated = false,
                    color = Color(0xFFB0BEC5),
                    bimId = "FND-CONC-01"
                )
            }

            // Underground Drainage Pipes (Day 31+)
            if (currentDay >= 31 || isMepOnly) {
                buildDrainageNetwork(polygons, w, l, -0.5f + fndExplodeY)
            }
        }

        // -------------------------------------------------------------
        // 3. GROUND FLOOR SLAB & INSULATION (Y = 0m to 0.25m)
        // -------------------------------------------------------------
        if (currentDay >= 41 && !isMepOnly) {
            val slabProgress = ((currentDay - 41) / 14f).coerceIn(0f, 1f)
            val slabY = 0f + slabExplodeY

            // 150mm PIR insulation layer (Yellow)
            if (currentDay >= 41) {
                polygons.addAll(
                    createBox(
                        center = Vector3(0f, slabY + 0.08f, 0f),
                        size = Vector3(w * 2f - 0.4f, 0.15f, l * 2f - 0.4f),
                        color = Color(0xFFFFD54F),
                        bimId = "SLAB-PIR-01",
                        tag = "GroundFloorInsulation"
                    )
                )
            }

            // Structural Concrete Slab (Day 48+)
            if (currentDay >= 48) {
                val concProgress = ((currentDay - 48) / 7f).coerceIn(0f, 1f)
                polygons.addAll(
                    createBox(
                        center = Vector3(0f, slabY + 0.15f + (0.1f * concProgress), 0f),
                        size = Vector3(w * 2f - 0.1f, 0.2f * concProgress, l * 2f - 0.1f),
                        color = Color(0xFFCFD8DC),
                        bimId = "SLAB-CONC-01",
                        tag = "ConcreteFloorSlab"
                    )
                )
            }
        }

        // -------------------------------------------------------------
        // 4. GROUND FLOOR STRUCTURAL WALLS (Y = 0.25m to 2.8m)
        // -------------------------------------------------------------
        if (currentDay >= 56 && !isMepOnly) {
            val wallProgress = ((currentDay - 56) / 24f).coerceIn(0f, 1f)
            val currentWallH = floorH * wallProgress
            val wallBaseY = 0.25f + gfWallsExplodeY

            val facadeColor = Color(config.facadeFinish.baseColorHex)
            val wallColor = if (isCutaway) facadeColor.copy(alpha = 0.35f) else facadeColor

            // Course-by-course brick wall geometry
            buildWallsWithOpenings(
                polygons = polygons,
                w = w,
                l = l,
                baseY = wallBaseY,
                height = currentWallH,
                color = wallColor,
                hasGarage = config.hasIntegralGarage,
                floorIndex = 0,
                bimId = "WALL-CAV-01",
                isCutaway = isCutaway
            )

            // Steel universal column & lintels (Day 72+)
            if (currentDay >= 72 || isStructuralOnly) {
                buildStructuralSteel(polygons, w, l, wallBaseY + floorH, "BEAM-STL-01")
            }

            // Multi-level Scaffolding growing with wall (Day 56..125)
            if (currentDay in 56..135) {
                buildScaffolding(polygons, w + 0.6f, l + 0.6f, wallBaseY, currentWallH + 0.8f)
            }
        }

        // -------------------------------------------------------------
        // 5. FIRST FLOOR JOISTS & DECKING (Y = 2.8m to 3.1m)
        // -------------------------------------------------------------
        if (currentDay >= 81 && config.floorCount >= 2 && !isMepOnly) {
            val ffProgress = ((currentDay - 81) / 14f).coerceIn(0f, 1f)
            val joistBaseY = floorH + firstFlrExplodeY

            // Engineered Timber I-Joists
            buildFloorJoists(polygons, w, l, joistBaseY, ffProgress, "FLR-JOIST-01")

            // Floor Decking Panels (Day 88+)
            if (currentDay >= 88) {
                val deckProgress = ((currentDay - 88) / 7f).coerceIn(0f, 1f)
                polygons.addAll(
                    createBox(
                        center = Vector3(0f, joistBaseY + 0.25f, 0f),
                        size = Vector3(w * 2f * deckProgress, 0.05f, l * 2f),
                        color = Color(0xFFD7CCC8),
                        bimId = "FLR-JOIST-01",
                        tag = "FloorDecking"
                    )
                )
            }
        }

        // -------------------------------------------------------------
        // 6. FIRST FLOOR WALLS (Y = 3.1m to 5.6m)
        // -------------------------------------------------------------
        if (currentDay >= 88 && config.floorCount >= 2 && !isMepOnly) {
            val ffWallProgress = ((currentDay - 88) / 12f).coerceIn(0f, 1f)
            val ffWallH = floorH * ffWallProgress
            val ffBaseY = floorH + 0.3f + ffWallsExplodeY
            val facadeColor = Color(config.facadeFinish.baseColorHex)
            val wallColor = if (isCutaway) facadeColor.copy(alpha = 0.35f) else facadeColor

            buildWallsWithOpenings(
                polygons = polygons,
                w = w,
                l = l,
                baseY = ffBaseY,
                height = ffWallH,
                color = wallColor,
                hasGarage = false,
                floorIndex = 1,
                bimId = "WALL-CAV-01",
                isCutaway = isCutaway
            )
        }

        // -------------------------------------------------------------
        // 7. ROOF STRUCTURE, MEMBRANE & TILES (Y = totalH to totalH + 3.2m)
        // -------------------------------------------------------------
        if (currentDay >= 96 && !isMepOnly) {
            val roofBaseY = totalH + 0.3f + roofTrussExplodeY
            val roofTilesY = totalH + 0.3f + roofTilesExplodeY
            val roofApexH = 3.2f

            // Timber Roof Trusses (Day 96-106)
            if (currentDay >= 96) {
                val trussProgress = ((currentDay - 96) / 10f).coerceIn(0f, 1f)
                buildRoofTrusses(
                    polygons = polygons,
                    w = w,
                    l = l,
                    baseY = roofBaseY,
                    apexH = roofApexH,
                    progress = trussProgress,
                    roofStyle = config.roofStyle,
                    bimId = "ROOF-TRUSS-01"
                )
            }

            // Breathable Membrane & Roof Tiles (Day 107+)
            if (currentDay >= 107 && !isStructuralOnly) {
                val tileProgress = ((currentDay - 107) / 12f).coerceIn(0f, 1f)
                val tileColor = Color(config.roofFinish.colorHex)
                buildRoofTiling(
                    polygons = polygons,
                    w = w + 0.3f,
                    l = l + 0.3f,
                    baseY = roofTilesY,
                    apexH = roofApexH,
                    progress = tileProgress,
                    roofStyle = config.roofStyle,
                    tileColor = tileColor,
                    hasSolarPv = config.hasSolarPvArray,
                    bimId = "ROOF-SLATE-01"
                )
            }
        }

        // -------------------------------------------------------------
        // 8. WINDOWS & EXTERIOR DOORS (Day 121+)
        // -------------------------------------------------------------
        if (currentDay >= 121 && !isStructuralOnly && !isMepOnly) {
            val winProgress = ((currentDay - 121) / 14f).coerceIn(0f, 1f)
            buildGlazingAndDoors(
                polygons = polygons,
                w = w,
                l = l,
                floorH = floorH,
                floorCount = config.floorCount,
                progress = winProgress,
                hasRearExt = config.hasRearGlassExtension,
                bimId = "WIN-TRIPLE-01",
                baseY = gfWallsExplodeY
            )
        }

        // -------------------------------------------------------------
        // 9. MEP SERVICES & ENERGY VISUALIZATION (Day 136+)
        // -------------------------------------------------------------
        if (currentDay >= 136 || isMepOnly || viewMode == ConstructionViewMode.ENERGY_SIMULATION) {
            buildMepServices(
                polygons = polygons,
                w = w,
                l = l,
                floorH = floorH,
                currentDay = currentDay,
                simTick = simulationTick,
                viewMode = viewMode,
                baseY = mepExplodeY
            )
        }

        // -------------------------------------------------------------
        // 10. INTERIOR FITOUT & FINISHES (Day 201+)
        // -------------------------------------------------------------
        if (currentDay >= 201 && !isStructuralOnly && !isMepOnly) {
            buildInteriorFitout(polygons, w, l, currentDay, gfWallsExplodeY)
        }

        // -------------------------------------------------------------
        // 11. MACHINERY & LIVE SITE ENTITIES
        // -------------------------------------------------------------
        if (viewMode == ConstructionViewMode.REALISTIC_3D || viewMode == ConstructionViewMode.STRUCTURAL_FRAME) {
            for (mach in activeMachinery) {
                if (mach.isActiveOnDay(currentDay)) {
                    buildMachinery(polygons, mach, simulationTick)
                }
            }

            for (worker in activeWorkers) {
                if (worker.isActiveOnDay(currentDay)) {
                    buildWorker(polygons, worker, simulationTick)
                }
            }
        }

        // -------------------------------------------------------------
        // 12. BIM HIGHLIGHTING OVERLAY
        // -------------------------------------------------------------
        if (selectedBimId != null) {
            highlightBimComponent(polygons, selectedBimId)
        }

        return polygons
    }

    // -----------------------------------------------------------------
    // Helper Primitive Geometry Builders
    // -----------------------------------------------------------------

    fun createQuad(
        v0: Vector3,
        v1: Vector3,
        v2: Vector3,
        v3: Vector3,
        color: Color,
        tag: String = "",
        bimId: String? = null,
        isWireframe: Boolean = false,
        normalOverride: Vector3? = null
    ): Polygon3D {
        return Polygon3D(
            vertices = listOf(v0, v1, v2, v3),
            baseColor = color,
            tag = tag,
            bimId = bimId,
            isWireframe = isWireframe,
            normalOverride = normalOverride
        )
    }

    fun createTriangle(
        v0: Vector3,
        v1: Vector3,
        v2: Vector3,
        color: Color,
        tag: String = "",
        bimId: String? = null
    ): Polygon3D {
        return Polygon3D(
            vertices = listOf(v0, v1, v2),
            baseColor = color,
            tag = tag,
            bimId = bimId
        )
    }

    fun createBox(
        center: Vector3,
        size: Vector3,
        color: Color,
        tag: String = "",
        bimId: String? = null,
        isWireframe: Boolean = false
    ): List<Polygon3D> {
        val hx = size.x * 0.5f
        val hy = size.y * 0.5f
        val hz = size.z * 0.5f

        val p0 = center + Vector3(-hx, -hy, hz)
        val p1 = center + Vector3(hx, -hy, hz)
        val p2 = center + Vector3(hx, hy, hz)
        val p3 = center + Vector3(-hx, hy, hz)

        val p4 = center + Vector3(-hx, -hy, -hz)
        val p5 = center + Vector3(hx, -hy, -hz)
        val p6 = center + Vector3(hx, hy, -hz)
        val p7 = center + Vector3(-hx, hy, -hz)

        return listOf(
            createQuad(p0, p1, p2, p3, color, tag, bimId, isWireframe, Vector3(0f, 0f, 1f)),  // Front
            createQuad(p5, p4, p7, p6, color, tag, bimId, isWireframe, Vector3(0f, 0f, -1f)), // Back
            createQuad(p3, p2, p6, p7, color, tag, bimId, isWireframe, Vector3(0f, 1f, 0f)),  // Top
            createQuad(p4, p5, p1, p0, color, tag, bimId, isWireframe, Vector3(0f, -1f, 0f)), // Bottom
            createQuad(p4, p0, p3, p7, color, tag, bimId, isWireframe, Vector3(-1f, 0f, 0f)), // Left
            createQuad(p1, p5, p6, p2, color, tag, bimId, isWireframe, Vector3(1f, 0f, 0f))   // Right
        )
    }

    // -----------------------------------------------------------------
    // Specific Architectural Subsystem Builders
    // -----------------------------------------------------------------

    private fun buildPerimeterFence(polygons: MutableList<Polygon3D>, halfW: Float, halfL: Float, day: Int) {
        val fenceColor = Color(0xFFB0BEC5)
        val posts = listOf(
            Vector3(-halfW, 0f, halfL), Vector3(halfW, 0f, halfL),
            Vector3(halfW, 0f, -halfL), Vector3(-halfW, 0f, -halfL)
        )
        // 4 boundary sides
        for (i in posts.indices) {
            val pA = posts[i]
            val pB = posts[(i + 1) % posts.size]
            // Skip entrance gate opening at front left
            if (i == 0) {
                polygons.add(createQuad(pA + Vector3(4f, 0f, 0f), pB, pB + Vector3(0f, 1.8f, 0f), pA + Vector3(4f, 1.8f, 0f), fenceColor.copy(alpha = 0.35f), tag = "SiteFence", bimId = "SITE-BOUND-01"))
            } else {
                polygons.add(createQuad(pA, pB, pB + Vector3(0f, 1.8f, 0f), pA + Vector3(0f, 1.8f, 0f), fenceColor.copy(alpha = 0.35f), tag = "SiteFence", bimId = "SITE-BOUND-01"))
            }
        }
    }

    private fun buildTrenchPerimeter(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        yLevel: Float,
        isExcavated: Boolean,
        color: Color = Color(0xFF5D4037),
        bimId: String = "EXC-TRENCH-01"
    ) {
        val thickness = 0.65f
        // 4 trench strips
        // Front & Back
        polygons.addAll(createBox(Vector3(0f, yLevel * 0.5f, l), Vector3(w * 2f, -yLevel, thickness), color, bimId = bimId, tag = "FoundationTrench"))
        polygons.addAll(createBox(Vector3(0f, yLevel * 0.5f, -l), Vector3(w * 2f, -yLevel, thickness), color, bimId = bimId, tag = "FoundationTrench"))
        // Left & Right
        polygons.addAll(createBox(Vector3(-w, yLevel * 0.5f, 0f), Vector3(thickness, -yLevel, l * 2f), color, bimId = bimId, tag = "FoundationTrench"))
        polygons.addAll(createBox(Vector3(w, yLevel * 0.5f, 0f), Vector3(thickness, -yLevel, l * 2f), color, bimId = bimId, tag = "FoundationTrench"))
        // Central spine foundation wall
        polygons.addAll(createBox(Vector3(0f, yLevel * 0.5f, 0f), Vector3(w * 1.8f, -yLevel, thickness), color, bimId = bimId, tag = "FoundationTrench"))
    }

    private fun buildSpoilHeap(polygons: MutableList<Polygon3D>, center: Vector3, radius: Float) {
        val soilColor = Color(0xFF6D4C41)
        val apex = center + Vector3(0f, 1.6f, 0f)
        val segments = 8
        for (i in 0 until segments) {
            val angle1 = (i.toFloat() / segments) * (2f * Math.PI.toFloat())
            val angle2 = ((i + 1).toFloat() / segments) * (2f * Math.PI.toFloat())
            val v1 = center + Vector3(cos(angle1) * radius, 0f, sin(angle1) * radius)
            val v2 = center + Vector3(cos(angle2) * radius, 0f, sin(angle2) * radius)
            polygons.add(createTriangle(apex, v1, v2, soilColor, tag = "SpoilHeap"))
        }
    }

    private fun buildRebarMesh(polygons: MutableList<Polygon3D>, w: Float, l: Float, y: Float) {
        val steelColor = Color(0xFF90A4AE)
        val offset = 0.2f
        polygons.addAll(createBox(Vector3(0f, y, l), Vector3(w * 2f - offset, 0.08f, 0.4f), steelColor, isWireframe = true, bimId = "FND-REBAR-01", tag = "RebarGrid"))
        polygons.addAll(createBox(Vector3(0f, y, -l), Vector3(w * 2f - offset, 0.08f, 0.4f), steelColor, isWireframe = true, bimId = "FND-REBAR-01", tag = "RebarGrid"))
        polygons.addAll(createBox(Vector3(-w, y, 0f), Vector3(0.4f, 0.08f, l * 2f - offset), steelColor, isWireframe = true, bimId = "FND-REBAR-01", tag = "RebarGrid"))
        polygons.addAll(createBox(Vector3(w, y, 0f), Vector3(0.4f, 0.08f, l * 2f - offset), steelColor, isWireframe = true, bimId = "FND-REBAR-01", tag = "RebarGrid"))
    }

    private fun buildDrainageNetwork(polygons: MutableList<Polygon3D>, w: Float, l: Float, y: Float) {
        val pipeColor = Color(0xFFE65100) // Orange PVCu
        // Main foul run from utility to boundary inspection chamber
        polygons.addAll(createBox(Vector3(w * 0.4f, y, 0f), Vector3(0.15f, 0.15f, l * 1.5f), pipeColor, bimId = "DRN-FOUL-01", tag = "DrainagePipe"))
        polygons.addAll(createBox(Vector3(w * 0.4f, y, l * 0.75f), Vector3(w * 0.8f, 0.15f, 0.15f), pipeColor, bimId = "DRN-FOUL-01", tag = "DrainagePipe"))
        // Inspection Chamber / Manhole
        polygons.addAll(createBox(Vector3(w * 0.4f, y + 0.25f, l * 0.75f), Vector3(0.6f, 0.6f, 0.6f), Color(0xFF455A64), bimId = "DRN-FOUL-01", tag = "InspectionChamber"))
    }

    private fun buildWallsWithOpenings(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        baseY: Float,
        height: Float,
        color: Color,
        hasGarage: Boolean,
        floorIndex: Int,
        bimId: String,
        isCutaway: Boolean
    ) {
        val wallThick = 0.35f
        val cy = baseY + (height * 0.5f)

        // Front Wall (Z = +l) with door and window openings
        if (!isCutaway || floorIndex > 0) {
            // Left segment
            polygons.addAll(createBox(Vector3(-w * 0.6f, cy, l), Vector3(w * 0.8f, height, wallThick), color, bimId = bimId, tag = "ExteriorWall"))
            // Right segment
            polygons.addAll(createBox(Vector3(w * 0.6f, cy, l), Vector3(w * 0.8f, height, wallThick), color, bimId = bimId, tag = "ExteriorWall"))
            // Lintel over front door
            if (height > 2.2f) {
                polygons.addAll(createBox(Vector3(0f, baseY + 2.4f, l), Vector3(w * 0.4f, height - 2.2f, wallThick), color, bimId = bimId, tag = "DoorLintel"))
            }
        }

        // Back Wall (Z = -l) with large garden aperture
        polygons.addAll(createBox(Vector3(-w * 0.55f, cy, -l), Vector3(w * 0.9f, height, wallThick), color, bimId = bimId, tag = "ExteriorWall"))
        polygons.addAll(createBox(Vector3(w * 0.55f, cy, -l), Vector3(w * 0.9f, height, wallThick), color, bimId = bimId, tag = "ExteriorWall"))
        if (height > 2.2f) {
            polygons.addAll(createBox(Vector3(0f, baseY + 2.4f, -l), Vector3(w * 0.9f, height - 2.2f, wallThick), color, bimId = bimId, tag = "RearApertureLintel"))
        }

        // Left Side Wall (X = -w)
        polygons.addAll(createBox(Vector3(-w, cy, 0f), Vector3(wallThick, height, l * 2f), color, bimId = bimId, tag = "ExteriorWall"))

        // Right Side Wall (X = +w)
        polygons.addAll(createBox(Vector3(w, cy, 0f), Vector3(wallThick, height, l * 2f), color, bimId = bimId, tag = "ExteriorWall"))

        // Internal Spine Dividing Wall
        polygons.addAll(createBox(Vector3(0f, cy, 0f), Vector3(wallThick * 0.6f, height, l * 1.6f), Color(0xFFECEFF1), bimId = bimId, tag = "InternalStudWall"))
    }

    private fun buildStructuralSteel(polygons: MutableList<Polygon3D>, w: Float, l: Float, y: Float, bimId: String) {
        val steelColor = Color(0xFFD84315) // Red-oxide primed steel
        // Main structural load-bearing spine beam (UB)
        polygons.addAll(createBox(Vector3(0f, y - 0.12f, 0f), Vector3(0.2f, 0.25f, l * 1.8f), steelColor, bimId = bimId, tag = "StructuralSteelBeam"))
        // Support column (UC)
        polygons.addAll(createBox(Vector3(0f, (y - 0.12f) * 0.5f, 0f), Vector3(0.2f, y, 0.2f), steelColor, bimId = bimId, tag = "SteelColumn"))
    }

    private fun buildScaffolding(polygons: MutableList<Polygon3D>, halfW: Float, halfL: Float, baseY: Float, currentH: Float) {
        val tubeColor = Color(0xFFB0BEC5)
        val boardColor = Color(0xFF8D6E63)
        val levels = (currentH / 1.8f).toInt().coerceAtLeast(1)

        for (lvl in 1..levels) {
            val yLvl = baseY + (lvl * 1.8f)
            // Wooden walkboards
            polygons.addAll(createBox(Vector3(0f, yLvl, halfL), Vector3(halfW * 2f, 0.05f, 0.6f), boardColor, tag = "ScaffoldBoard"))
            polygons.addAll(createBox(Vector3(0f, yLvl, -halfL), Vector3(halfW * 2f, 0.05f, 0.6f), boardColor, tag = "ScaffoldBoard"))
            polygons.addAll(createBox(Vector3(-halfW, yLvl, 0f), Vector3(0.6f, 0.05f, halfL * 2f), boardColor, tag = "ScaffoldBoard"))
            polygons.addAll(createBox(Vector3(halfW, yLvl, 0f), Vector3(0.6f, 0.05f, halfL * 2f), boardColor, tag = "ScaffoldBoard"))

            // Guardrails wireframe
            polygons.addAll(createBox(Vector3(0f, yLvl + 0.9f, halfL + 0.3f), Vector3(halfW * 2f, 0.05f, 0.05f), tubeColor, tag = "ScaffoldRail"))
            polygons.addAll(createBox(Vector3(0f, yLvl + 0.9f, -halfL - 0.3f), Vector3(halfW * 2f, 0.05f, 0.05f), tubeColor, tag = "ScaffoldRail"))
        }
    }

    private fun buildFloorJoists(polygons: MutableList<Polygon3D>, w: Float, l: Float, y: Float, progress: Float, bimId: String) {
        val joistColor = Color(0xFFBCAAA4)
        val joistCount = 12
        val visibleJoists = (joistCount * progress).toInt()

        for (i in 0 until visibleJoists) {
            val zPos = -l + (i.toFloat() / (joistCount - 1)) * (l * 2f)
            polygons.addAll(createBox(Vector3(0f, y + 0.12f, zPos), Vector3(w * 2f - 0.2f, 0.24f, 0.06f), joistColor, bimId = bimId, tag = "TimberIJoist"))
        }
    }

    private fun buildRoofTrusses(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        baseY: Float,
        apexH: Float,
        progress: Float,
        roofStyle: RoofStyle,
        bimId: String
    ) {
        val woodColor = Color(0xFFD7CCC8)
        val trussCount = 10
        val count = (trussCount * progress).toInt().coerceAtLeast(1)

        for (i in 0 until count) {
            val zPos = -l + (i.toFloat() / (trussCount - 1)) * (l * 2f)
            val pLeft = Vector3(-w, baseY, zPos)
            val pRight = Vector3(w, baseY, zPos)
            val pApex = Vector3(0f, baseY + apexH, zPos)

            // Bottom chord
            polygons.addAll(createBox(Vector3(0f, baseY + 0.05f, zPos), Vector3(w * 2f, 0.1f, 0.08f), woodColor, bimId = bimId, tag = "TrussBottomChord"))
            // Rafters
            polygons.addAll(createBox(Vector3(-w * 0.5f, baseY + apexH * 0.5f, zPos), Vector3(w, 0.1f, 0.08f), woodColor, bimId = bimId, tag = "TrussRafter"))
            polygons.addAll(createBox(Vector3(w * 0.5f, baseY + apexH * 0.5f, zPos), Vector3(w, 0.1f, 0.08f), woodColor, bimId = bimId, tag = "TrussRafter"))
            // King Post
            polygons.addAll(createBox(Vector3(0f, baseY + apexH * 0.5f, zPos), Vector3(0.08f, apexH, 0.08f), woodColor, bimId = bimId, tag = "TrussKingPost"))
        }
    }

    private fun buildRoofTiling(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        baseY: Float,
        apexH: Float,
        progress: Float,
        roofStyle: RoofStyle,
        tileColor: Color,
        hasSolarPv: Boolean,
        bimId: String
    ) {
        val feltColor = Color(0xFF37474F)
        val pApexFront = Vector3(0f, baseY + apexH, l)
        val pApexBack = Vector3(0f, baseY + apexH, -l)
        val pLeftFront = Vector3(-w, baseY, l)
        val pLeftBack = Vector3(-w, baseY, -l)
        val pRightFront = Vector3(w, baseY, l)
        val pRightBack = Vector3(w, baseY, -l)

        val activeColor = if (progress >= 0.7f) tileColor else feltColor

        // Left Pitch
        polygons.add(createQuad(pLeftFront, pApexFront, pApexBack, pLeftBack, activeColor, bimId = bimId, tag = "RoofPitchLeft"))
        // Right Pitch
        polygons.add(createQuad(pApexFront, pRightFront, pRightBack, pApexBack, activeColor, bimId = bimId, tag = "RoofPitchRight"))

        // Front Gable Triangle
        polygons.add(createTriangle(pApexFront, pLeftFront, pRightFront, activeColor, bimId = bimId, tag = "GableFront"))
        // Back Gable Triangle
        polygons.add(createTriangle(pApexBack, pRightBack, pLeftBack, activeColor, bimId = bimId, tag = "GableBack"))

        // In-Roof Solar PV Array (South Facing Pitch, Day 112+)
        if (hasSolarPv && progress >= 0.8f) {
            val solarGlass = Color(0xFF0D47A1)
            polygons.add(
                createQuad(
                    v0 = Vector3(w * 0.2f, baseY + apexH * 0.35f, l * 0.6f),
                    v1 = Vector3(w * 0.8f, baseY + apexH * 0.35f, l * 0.6f),
                    v2 = Vector3(w * 0.8f, baseY + apexH * 0.75f, -l * 0.3f),
                    v3 = Vector3(w * 0.2f, baseY + apexH * 0.75f, -l * 0.3f),
                    color = solarGlass,
                    bimId = "SOLAR-PV-01",
                    tag = "SolarPvArray"
                )
            )
        }
    }

    private fun buildGlazingAndDoors(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        floorH: Float,
        floorCount: Int,
        progress: Float,
        hasRearExt: Boolean,
        bimId: String,
        baseY: Float
    ) {
        val frameColor = Color(0xFF263238) // RAL 7016 Anthracite
        val glassColor = Color(0x9981D4FA) // Translucent light blue reflection
        val doorWoodColor = Color(0xFF5D4037)

        // Front Entrance Door
        polygons.addAll(createBox(Vector3(0f, baseY + 1.1f, l + 0.05f), Vector3(1.1f, 2.1f, 0.1f), doorWoodColor, bimId = bimId, tag = "EntranceDoor"))

        // Ground Floor Windows
        val gfWinPositions = listOf(
            Vector3(-w * 0.6f, baseY + 1.4f, l + 0.05f),
            Vector3(w * 0.6f, baseY + 1.4f, l + 0.05f)
        )
        for (pos in gfWinPositions) {
            polygons.addAll(createBox(pos, Vector3(1.4f, 1.3f, 0.08f), frameColor, bimId = bimId, tag = "WindowFrame"))
            polygons.add(createQuad(pos + Vector3(-0.6f, -0.55f, 0.05f), pos + Vector3(0.6f, -0.55f, 0.05f), pos + Vector3(0.6f, 0.55f, 0.05f), pos + Vector3(-0.6f, 0.55f, 0.05f), glassColor, bimId = bimId, tag = "WindowGlass"))
        }

        // Rear Bi-Fold Glass Doors
        polygons.addAll(createBox(Vector3(0f, baseY + 1.15f, -l - 0.05f), Vector3(w * 1.1f, 2.2f, 0.1f), frameColor, bimId = bimId, tag = "BiFoldFrame"))
        polygons.add(createQuad(Vector3(-w * 0.5f, baseY + 0.1f, -l - 0.08f), Vector3(w * 0.5f, baseY + 0.1f, -l - 0.08f), Vector3(w * 0.5f, baseY + 2.1f, -l - 0.08f), Vector3(-w * 0.5f, baseY + 2.1f, -l - 0.08f), glassColor, bimId = bimId, tag = "BiFoldGlass"))

        // Upper Floor Windows
        if (floorCount >= 2) {
            val ffWinPositions = listOf(
                Vector3(-w * 0.6f, baseY + floorH + 1.4f, l + 0.05f),
                Vector3(0f, baseY + floorH + 1.4f, l + 0.05f),
                Vector3(w * 0.6f, baseY + floorH + 1.4f, l + 0.05f)
            )
            for (pos in ffWinPositions) {
                polygons.addAll(createBox(pos, Vector3(1.2f, 1.2f, 0.08f), frameColor, bimId = bimId, tag = "WindowFrame"))
                polygons.add(createQuad(pos + Vector3(-0.5f, -0.5f, 0.05f), pos + Vector3(0.5f, -0.5f, 0.05f), pos + Vector3(0.5f, 0.5f, 0.05f), pos + Vector3(-0.5f, 0.5f, 0.05f), glassColor, bimId = bimId, tag = "WindowGlass"))
            }
        }
    }

    private fun buildMepServices(
        polygons: MutableList<Polygon3D>,
        w: Float,
        l: Float,
        floorH: Float,
        currentDay: Int,
        simTick: Float,
        viewMode: ConstructionViewMode,
        baseY: Float
    ) {
        val elecColor = Color(0xFFFFB300) // Amber electrical
        val hotWaterColor = Color(0xFFE53935) // Red hot water / heating
        val coldWaterColor = Color(0xFF1E88E5) // Blue cold water
        val hvacColor = Color(0xFF00ACC1) // Teal ventilation MVHR

        // Air-Source Heat Pump Outdoor Unit (Rear Wall)
        polygons.addAll(createBox(Vector3(w * 0.7f, baseY + 0.5f, -l - 0.7f), Vector3(1.2f, 0.9f, 0.5f), Color(0xFFECEFF1), bimId = "PLUMB-ASHP-01", tag = "HeatPumpUnit"))
        // Fan grill
        polygons.addAll(createBox(Vector3(w * 0.7f, baseY + 0.5f, -l - 0.96f), Vector3(0.6f, 0.6f, 0.05f), Color(0xFF37474F), bimId = "PLUMB-ASHP-01", tag = "HeatPumpFan"))

        // Hot Water Thermal Cylinder (Utility Room)
        polygons.addAll(createBox(Vector3(-w * 0.6f, baseY + 1.1f, -l * 0.4f), Vector3(0.7f, 1.8f, 0.7f), Color(0xFFB0BEC5), bimId = "PLUMB-ASHP-01", tag = "HotWaterCylinder"))

        // Consumer Unit & Battery Storage (Utility Room)
        polygons.addAll(createBox(Vector3(-w * 0.85f, baseY + 1.6f, l * 0.2f), Vector3(0.15f, 0.5f, 0.6f), Color(0xFFFAFAFA), bimId = "ELEC-CU-01", tag = "ConsumerUnit"))
        polygons.addAll(createBox(Vector3(-w * 0.85f, baseY + 0.6f, l * 0.2f), Vector3(0.25f, 0.9f, 0.6f), Color(0xFF263238), bimId = "SOLAR-PV-01", tag = "BatteryStorage"))

        // Animated Electrical Conduit Runs (Glowing circuit pulses)
        val pulseOffset = (sin(simTick * 3f) * 0.05f)
        polygons.addAll(createBox(Vector3(-w * 0.5f, baseY + 2.6f + pulseOffset, 0f), Vector3(w, 0.06f, 0.06f), elecColor, bimId = "ELEC-CU-01", tag = "ElectricalConduit", isEmissive = true))
        polygons.addAll(createBox(Vector3(0f, baseY + 2.6f + pulseOffset, l * 0.4f), Vector3(0.06f, 0.06f, l * 0.8f), elecColor, bimId = "ELEC-CU-01", tag = "ElectricalConduit", isEmissive = true))

        // Animated Underfloor Heating Coils (Ground Floor red loop)
        for (i in 0..5) {
            val zPos = -l * 0.7f + (i * 0.8f)
            polygons.addAll(createBox(Vector3(w * 0.3f, baseY + 0.22f, zPos), Vector3(w * 0.9f, 0.04f, 0.04f), hotWaterColor, bimId = "PLUMB-ASHP-01", tag = "UnderfloorHeatingPipe"))
        }

        // Fresh & Hot Water Rising Mains
        polygons.addAll(createBox(Vector3(-w * 0.55f, baseY + floorH * 0.5f, -l * 0.35f), Vector3(0.05f, floorH, 0.05f), hotWaterColor, bimId = "PLUMB-ASHP-01", tag = "HotWaterRiser"))
        polygons.addAll(createBox(Vector3(-w * 0.52f, baseY + floorH * 0.5f, -l * 0.35f), Vector3(0.05f, floorH, 0.05f), coldWaterColor, bimId = "PLUMB-ASHP-01", tag = "ColdWaterRiser"))
    }

    private fun buildInteriorFitout(polygons: MutableList<Polygon3D>, w: Float, l: Float, day: Int, baseY: Float) {
        val woodColor = Color(0xFF8D6E63)
        val quartzColor = Color(0xFFFAFAFA)
        val cabinetColor = Color(0xFF37474F)

        // Kitchen Island & Base Cabinets (Day 201+)
        if (day >= 201) {
            // Kitchen Island
            polygons.addAll(createBox(Vector3(w * 0.35f, baseY + 0.45f, -l * 0.45f), Vector3(1.6f, 0.9f, 0.9f), cabinetColor, bimId = "KIT-FITOUT-01", tag = "KitchenIsland"))
            // Quartz Worktop
            polygons.addAll(createBox(Vector3(w * 0.35f, baseY + 0.92f, -l * 0.45f), Vector3(1.7f, 0.05f, 1.0f), quartzColor, bimId = "KIT-FITOUT-01", tag = "QuartzWorktop"))
            // Perimeter L-Shape units
            polygons.addAll(createBox(Vector3(w * 0.75f, baseY + 0.45f, -l * 0.3f), Vector3(0.6f, 0.9f, 2.4f), cabinetColor, bimId = "KIT-FITOUT-01", tag = "KitchenUnits"))
        }

        // Oak Flooring (Day 216+)
        if (day >= 216) {
            polygons.add(
                createQuad(
                    v0 = Vector3(-w + 0.2f, baseY + 0.26f, l - 0.2f),
                    v1 = Vector3(w - 0.2f, baseY + 0.26f, l - 0.2f),
                    v2 = Vector3(w - 0.2f, baseY + 0.26f, -l + 0.2f),
                    v3 = Vector3(-w + 0.2f, baseY + 0.26f, -l + 0.2f),
                    color = Color(0xFFBCAAA4),
                    bimId = "FLR-OAK-01",
                    tag = "OakFlooring"
                )
            )
        }
    }

    // -----------------------------------------------------------------
    // Live Machinery & Mechanical Articulation
    // -----------------------------------------------------------------

    private fun buildMachinery(polygons: MutableList<Polygon3D>, mach: MachineryEntity, simTick: Float) {
        val yellowPlantColor = Color(0xFFFFB300)
        val blackTreadColor = Color(0xFF263238)
        val darkGrayColor = Color(0xFF455A64)

        val bx = mach.basePositionX
        val by = mach.basePositionY
        val bz = mach.basePositionZ

        when (mach.type) {
            MachineType.EXCAVATOR -> {
                // Tracked Chassis
                polygons.addAll(createBox(Vector3(bx, by + 0.35f, bz), Vector3(2.4f, 0.7f, 1.6f), blackTreadColor, tag = "ExcavatorTracks"))
                // Upper 360 Rotating Cab
                val cabSlew = sin(simTick * 1.5f) * 0.35f
                val cabCenter = Vector3(bx, by + 1.2f, bz)
                polygons.addAll(createBox(cabCenter, Vector3(1.8f, 1.1f, 1.4f), yellowPlantColor, tag = "ExcavatorCab"))
                // Boom Arm (Kinematic articulation)
                val boomAngle = (sin(simTick * 2f) * 0.25f + 0.5f)
                val boomEnd = cabCenter + Vector3(cos(boomAngle) * 2.2f, sin(boomAngle) * 2.0f, 0f)
                polygons.addAll(createBox(cabCenter + Vector3(1.0f, 0.9f, 0f), Vector3(2.0f, 0.35f, 0.35f), yellowPlantColor, tag = "ExcavatorBoom"))
                // Arm & Bucket
                val bucketPos = boomEnd + Vector3(1.2f, -1.0f, 0f)
                polygons.addAll(createBox(bucketPos, Vector3(0.7f, 0.6f, 0.6f), darkGrayColor, tag = "ExcavatorBucket"))
            }

            MachineType.TOWER_CRANE -> {
                val mastHeight = 11.5f
                val mastColor = yellowPlantColor
                // Vertical Lattice Mast
                polygons.addAll(createBox(Vector3(bx, by + mastHeight * 0.5f, bz), Vector3(0.6f, mastHeight, 0.6f), mastColor, tag = "CraneMast"))
                // Slewing Jib & Counterweight
                val jibLength = 12.0f
                val craneSlewAngle = (simTick * 0.6f)
                val jibCenter = Vector3(bx + cos(craneSlewAngle) * (jibLength * 0.3f), by + mastHeight, bz + sin(craneSlewAngle) * (jibLength * 0.3f))
                polygons.addAll(createBox(jibCenter, Vector3(jibLength, 0.45f, 0.45f), mastColor, tag = "CraneJib"))
                // Counterweight block
                val counterPos = Vector3(bx - cos(craneSlewAngle) * 3f, by + mastHeight + 0.2f, bz - sin(craneSlewAngle) * 3f)
                polygons.addAll(createBox(counterPos, Vector3(1.4f, 0.9f, 0.9f), Color(0xFF607D8B), tag = "CraneCounterweight"))
                // Trolley & Hoist Hook Cable
                val trolleyDist = 4.5f + sin(simTick * 1.2f) * 2.5f
                val trolleyPos = Vector3(bx + cos(craneSlewAngle) * trolleyDist, by + mastHeight - 0.2f, bz + sin(craneSlewAngle) * trolleyDist)
                polygons.addAll(createBox(trolleyPos, Vector3(0.5f, 0.3f, 0.5f), blackTreadColor, tag = "CraneTrolley"))
                // Hook with suspended truss/payload
                val hookPos = trolleyPos - Vector3(0f, 4.0f, 0f)
                polygons.addAll(createBox(hookPos, Vector3(0.3f, 0.4f, 0.3f), darkGrayColor, tag = "CraneHook"))
                polygons.addAll(createBox(hookPos - Vector3(0f, 0.3f, 0f), Vector3(3.4f, 0.15f, 0.15f), Color(0xFFD7CCC8), tag = "LiftedTrussPayload"))
            }

            MachineType.CONCRETE_MIXER -> {
                // Truck Chassis & Cab
                polygons.addAll(createBox(Vector3(bx + 1.2f, by + 0.9f, bz), Vector3(1.6f, 1.4f, 1.8f), yellowPlantColor, tag = "MixerCab"))
                polygons.addAll(createBox(Vector3(bx - 0.8f, by + 0.4f, bz), Vector3(3.2f, 0.6f, 1.8f), darkGrayColor, tag = "MixerChassis"))
                // Angled Rotating Drum
                polygons.addAll(createBox(Vector3(bx - 0.8f, by + 1.4f, bz), Vector3(2.6f, 1.5f, 1.5f), Color(0xFFECEFF1), tag = "MixerDrum"))
                // Discharge Chute
                polygons.addAll(createBox(Vector3(bx - 2.4f, by + 0.7f, bz), Vector3(1.2f, 0.3f, 0.4f), Color(0xFF90A4AE), tag = "MixerChute"))
            }

            MachineType.DUMP_TRUCK -> {
                // Cab
                polygons.addAll(createBox(Vector3(bx + 1.2f, by + 1.0f, bz), Vector3(1.8f, 1.6f, 2.0f), yellowPlantColor, tag = "DumpTruckCab"))
                // Tipper Bed
                polygons.addAll(createBox(Vector3(bx - 1.2f, by + 1.2f, bz), Vector3(2.8f, 1.2f, 2.0f), yellowPlantColor, tag = "DumpTruckBed"))
            }

            MachineType.TELEHANDLER -> {
                polygons.addAll(createBox(Vector3(bx, by + 0.9f, bz), Vector3(2.2f, 1.2f, 1.5f), yellowPlantColor, tag = "TelehandlerCab"))
                // Telescopic Boom
                polygons.addAll(createBox(Vector3(bx + 1.2f, by + 1.8f, bz), Vector3(3.0f, 0.4f, 0.4f), darkGrayColor, tag = "TelehandlerBoom"))
            }

            MachineType.DELIVERY_FLATBED -> {
                polygons.addAll(createBox(Vector3(bx + 2.0f, by + 1.1f, bz), Vector3(1.8f, 1.8f, 2.0f), Color(0xFF1976D2), tag = "LorryCab"))
                polygons.addAll(createBox(Vector3(bx - 1.5f, by + 0.6f, bz), Vector3(5.0f, 0.4f, 2.0f), darkGrayColor, tag = "FlatbedTrailer"))
                // Pallets on bed
                polygons.addAll(createBox(Vector3(bx - 1.0f, by + 1.2f, bz), Vector3(1.4f, 1.0f, 1.4f), Color(0xFFB34A38), tag = "BrickPallet"))
                polygons.addAll(createBox(Vector3(bx - 2.8f, by + 1.2f, bz), Vector3(1.4f, 1.0f, 1.4f), Color(0xFFBCAAA4), tag = "TimberPallet"))
            }
        }
    }

    private fun buildWorker(polygons: MutableList<Polygon3D>, worker: WorkerEntity, simTick: Float) {
        val hiVisColor = Color(0xFFFF6D00)
        val trousersColor = Color(0xFF1565C0)
        val helmetColor = Color(worker.trade.helmetColorHex)

        val bob = (sin(simTick * 4f + worker.x) * 0.05f).coerceAtLeast(0f)
        val wx = worker.x
        val wy = worker.y + bob
        val wz = worker.z

        // Torso / Hi-Vis Vest
        polygons.addAll(createBox(Vector3(wx, wy + 0.95f, wz), Vector3(0.45f, 0.6f, 0.28f), hiVisColor, tag = "WorkerTorso"))
        // Legs
        polygons.addAll(createBox(Vector3(wx, wy + 0.35f, wz), Vector3(0.38f, 0.65f, 0.24f), trousersColor, tag = "WorkerLegs"))
        // Hard Hat & Head
        polygons.addAll(createBox(Vector3(wx, wy + 1.42f, wz), Vector3(0.32f, 0.3f, 0.32f), helmetColor, tag = "WorkerHelmet"))
    }

    private fun highlightBimComponent(polygons: MutableList<Polygon3D>, selectedBimId: String) {
        val highlightColor = Color(0xFFFFEB3B)
        for (i in polygons.indices) {
            val poly = polygons[i]
            if (poly.bimId == selectedBimId) {
                polygons[i] = poly.copy(
                    baseColor = highlightColor,
                    isWireframe = true,
                    wireframeColor = Color(0xFFD50000),
                    strokeWidth = 3.0f
                )
            }
        }
    }
}
