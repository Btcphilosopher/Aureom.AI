package com.example.housebuilder.model

/**
 * The 18 canonical construction stages of Housebuilder OS.
 */
enum class BuildingStage(
    val stageNumber: Int,
    val title: String,
    val description: String,
    val startDay: Int,
    val endDay: Int,
    val iconName: String
) {
    SITE_PREPARATION(
        stageNumber = 1,
        title = "Site Preparation",
        description = "Plot boundary surveying, access road laying, vegetation clearance, and site welfare setup.",
        startDay = 1,
        endDay = 5,
        iconName = "Terrain"
    ),
    GROUNDWORKS(
        stageNumber = 2,
        title = "Groundworks & Excavation",
        description = "Excavators digging foundation trenches, soil carting, sub-base leveling, and drainage channels.",
        startDay = 6,
        endDay = 15,
        iconName = "Construction"
    ),
    FOUNDATIONS(
        stageNumber = 3,
        title = "Foundations & Concrete",
        description = "Steel reinforcement cages, shuttering formwork, C25/30 concrete pour, curing, and waterproofing.",
        startDay = 16,
        endDay = 30,
        iconName = "Foundation"
    ),
    DRAINAGE(
        stageNumber = 4,
        title = "Underground Drainage",
        description = "Foul water and rainwater pipework, inspection manholes, soakaway connections, and backfilling.",
        startDay = 31,
        endDay = 40,
        iconName = "Plumbing"
    ),
    GROUND_FLOOR(
        stageNumber = 5,
        title = "Ground Floor Slab",
        description = "Hardcore base, radon barrier, PIR rigid insulation (150mm), and power-floated structural concrete slab.",
        startDay = 41,
        endDay = 55,
        iconName = "Layers"
    ),
    STRUCTURAL_WALLS(
        stageNumber = 6,
        title = "Structural Walls & Lintels",
        description = "Course-by-course brick & block cavity construction, wall ties, DPC, structural steel lintels.",
        startDay = 56,
        endDay = 80,
        iconName = "Architecture"
    ),
    FIRST_FLOOR(
        stageNumber = 7,
        title = "Upper Floor Structure",
        description = "Engineered timber I-joists, steel universal beams, tongue-and-groove acoustic decking.",
        startDay = 81,
        endDay = 95,
        iconName = "Apartment"
    ),
    ROOF(
        stageNumber = 8,
        title = "Roof Structure & Tiling",
        description = "Tower crane lifting pre-fabricated timber trusses, breathable roofing membrane, treated counter-battens, natural slate tiles.",
        startDay = 96,
        endDay = 120,
        iconName = "Roofing"
    ),
    WINDOWS_DOORS(
        stageNumber = 9,
        title = "Windows & External Doors",
        description = "High-performance triple-glazed aluminium/timber composite window units, airtightness perimeter tapes, bi-fold doors.",
        startDay = 121,
        endDay = 135,
        iconName = "Window"
    ),
    ELECTRICAL(
        stageNumber = 10,
        title = "First-Fix Electrical",
        description = "Consumer unit distribution board, armoured incoming mains, lighting rings, smart bus cables, EV charger cabling.",
        startDay = 136,
        endDay = 150,
        iconName = "ElectricBolt"
    ),
    PLUMBING(
        stageNumber = 11,
        title = "First-Fix Plumbing & HVAC",
        description = "Multi-layer barrier pipework, unvented hot water cylinder, air-source heat pump (ASHP) loop, underfloor heating manifolds.",
        startDay = 151,
        endDay = 165,
        iconName = "WaterDrop"
    ),
    INSULATION(
        stageNumber = 12,
        title = "Thermal & Acoustic Insulation",
        description = "High-density mineral wool wall batts, continuous airtightness vapour control membrane, 400mm loft insulation.",
        startDay = 166,
        endDay = 175,
        iconName = "Shield"
    ),
    PLASTERBOARD(
        stageNumber = 13,
        title = "Drylining & Plasterboard",
        description = "Sound-block and moisture-resistant 15mm plasterboards screw-fixed to internal metal/timber studs.",
        startDay = 176,
        endDay = 188,
        iconName = "Dashboard"
    ),
    PLASTER(
        stageNumber = 14,
        title = "Plaster Skim & Curing",
        description = "Two-coat multi-finish gypsum plaster skim, corner beads, expansion joints, controlled humidity curing.",
        startDay = 189,
        endDay = 200,
        iconName = "FormatPaint"
    ),
    KITCHEN_BATHROOM(
        stageNumber = 15,
        title = "Kitchen & Bathrooms",
        description = "Custom cabinetry, quartz worktops, sanitaryware fixtures, frameless walk-in showers, tapware, appliances.",
        startDay = 201,
        endDay = 215,
        iconName = "Countertops"
    ),
    FLOORING(
        stageNumber = 16,
        title = "Flooring & Joinery",
        description = "Engineered prime oak plank flooring, large-format porcelain bathroom tiles, solid core internal doors, skirting.",
        startDay = 216,
        endDay = 225,
        iconName = "GridOn"
    ),
    DECORATION(
        stageNumber = 17,
        title = "Decoration & Final Fixtures",
        description = "Mist coat, two-coat breathable emulsion, designer architectural lighting, smart thermostats, switchplates.",
        startDay = 226,
        endDay = 233,
        iconName = "Brush"
    ),
    LANDSCAPING(
        stageNumber = 18,
        title = "Landscaping & Handover",
        description = "Permeable block-paved driveway, boundary cedar fencing, meadow turf, native specimen planting, final commissioning.",
        startDay = 234,
        endDay = 240,
        iconName = "Yard"
    ),
    COMPLETED_HOUSE(
        stageNumber = 19,
        title = "Completed Digital Twin",
        description = "Live digital twin: occupant lifecycle, solar microgeneration, heat pump telemetry, 30-year whole-life asset management.",
        startDay = 241,
        endDay = 365,
        iconName = "Verified"
    );

    val durationDays: Int get() = endDay - startDay + 1

    companion object {
        fun forDay(day: Int): BuildingStage {
            return entries.firstOrNull { day in it.startDay..it.endDay } ?: if (day > 240) COMPLETED_HOUSE else SITE_PREPARATION
        }
    }
}

enum class ComponentCategory(val label: String, val colorHex: Long) {
    SUBSTRUCTURE("Substructure & Groundworks", 0xFF8D6E63),
    SUPERSTRUCTURE("Superstructure & Frame", 0xFFD84315),
    ENVELOPE("Envelope & Glazing", 0xFF0288D1),
    MEP_SERVICES("MEP & Energy Services", 0xFFF57C00),
    INTERIOR_FINISH("Interior & Joinery", 0xFF7B1FA2),
    EXTERNAL_WORKS("External & Landscaping", 0xFF388E3C)
}

enum class ComponentState {
    NOT_STARTED,
    PLANNED,
    UNDER_CONSTRUCTION,
    INSTALLED,
    INSPECTED,
    COMPLETE
}

enum class RoomType(val displayName: String) {
    GROUND_ENTRANCE("Entrance Hall"),
    LIVING_ROOM("Living Room"),
    KITCHEN_DINING("Kitchen & Dining"),
    UTILITY_PLANT("Utility & Plant Room"),
    MASTER_BEDROOM("Master Bedroom"),
    BEDROOM_TWO("Bedroom 2"),
    BEDROOM_THREE("Bedroom 3"),
    FAMILY_BATHROOM("Family Bathroom"),
    EN_SUITE("En-Suite Shower"),
    ROOF_ATTIC("Roof & Attic Space"),
    GARAGE_DRIVEWAY("Garage & Driveway")
}
