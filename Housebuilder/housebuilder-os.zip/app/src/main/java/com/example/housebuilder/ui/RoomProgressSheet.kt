package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.RoomType
import com.example.housebuilder.simulation.SimulationEngine
import com.example.ui.theme.*

@Composable
fun RoomProgressSheet(
    engine: SimulationEngine,
    selectedRoom: RoomType?,
    onSelectRoom: (RoomType) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ROOM-BY-ROOM ZONE INSPECTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSecondary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Spatial Trade Progress",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Room Selector List
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RoomType.entries.forEach { room ->
                    val isSel = (room == selectedRoom)
                    val completion = engine.getRoomCompletionPercentage(room)

                    Surface(
                        onClick = { onSelectRoom(room) },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) SlateCard else SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) BrandSecondary else SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(room.displayName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Click to focus camera", fontSize = 11.sp, color = TextMuted)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "$completion%",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (completion == 100) AccentSuccess else BrandSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { completion / 100f },
                                    modifier = Modifier.width(80.dp).height(4.dp),
                                    color = if (completion == 100) AccentSuccess else BrandSecondary,
                                    trackColor = SlateDarkest
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandSecondary)
            ) {
                Text("Close Room Inspector", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
