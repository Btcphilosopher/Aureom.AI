package com.example.housebuilder.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.simulation.SimulationEngine
import com.example.ui.theme.*

@Composable
fun AnalyticsSheet(
    engine: SimulationEngine,
    onDismiss: () -> Unit
) {
    val totalBudget = engine.getTotalProjectBudget()
    val spentToDate = engine.getSpentToDate()
    val matSpend = engine.getMaterialCostToDate()
    val labSpend = engine.getLabourCostToDate()
    val plantSpend = engine.getPlantCostToDate()
    val currentDay = engine.currentDay

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FINANCIAL & SCHEDULE ANALYTICS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandTertiary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Cost Curves & Earned Value",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cost Summary Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateCard)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("TOTAL CONTRACT SUM", fontSize = 11.sp, color = TextSecondary)
                        Text("£${String.format("%,.2f", totalBudget)}", fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = TextPrimary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("CUMULATIVE SPENT", fontSize = 11.sp, color = TextSecondary)
                        Text("£${String.format("%,.2f", spentToDate)}", fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = BrandPrimary)
                    }
                }
                LinearProgressIndicator(
                    progress = { (spentToDate / totalBudget).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = BrandPrimary,
                    trackColor = SlateDarkest
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // S-Curve Canvas Graph
            Text("Cumulative Expenditure S-Curve (Earned Value)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateDarkest)
                    .padding(12.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Grid Lines
                    drawLine(Color(0xFF374151), Offset(0f, h), Offset(w, h), strokeWidth = 1f)
                    drawLine(Color(0xFF374151), Offset(0f, 0f), Offset(w, 0f), strokeWidth = 1f)
                    drawLine(Color(0xFF374151), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), strokeWidth = 0.5f)

                    // Planned S-Curve Path (Dashed Grey)
                    val plannedPath = Path()
                    plannedPath.moveTo(0f, h)
                    for (day in 1..240 step 10) {
                        val x = (day / 240f) * w
                        // Sigmoid S-curve equation
                        val norm = (day / 240f)
                        val s = (norm * norm * (3 - 2 * norm))
                        val y = h - (s * h)
                        plannedPath.lineTo(x, y)
                    }
                    drawPath(plannedPath, color = Color(0xFF64748B), style = Stroke(width = 2f))

                    // Actual Earned Value Path (BrandPrimary Solid)
                    val actualPath = Path()
                    actualPath.moveTo(0f, h)
                    val maxDay = currentDay.toInt().coerceAtMost(240)
                    for (day in 1..maxDay step 5) {
                        val x = (day / 240f) * w
                        val norm = (day / 240f)
                        val s = (norm * norm * (3 - 2 * norm))
                        val y = h - (s * h)
                        actualPath.lineTo(x, y)
                    }
                    drawPath(actualPath, color = BrandPrimary, style = Stroke(width = 3.5f))

                    // Current Day Marker dot
                    val curX = (currentDay / 240f) * w
                    val curNorm = (currentDay / 240f).coerceIn(0f, 1f)
                    val curY = h - (curNorm * curNorm * (3 - 2 * curNorm) * h)
                    drawCircle(color = BrandPrimary, radius = 5f, center = Offset(curX, curY))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cost Category Breakdown
            Text("Expenditure by Resource Type", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCard)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ResourceSpendRow("Direct Materials", matSpend, totalBudget * 0.55, BrandSecondary)
                ResourceSpendRow("Skilled Site Labour", labSpend, totalBudget * 0.35, BrandPrimary)
                ResourceSpendRow("Machinery & Plant Hire", plantSpend, totalBudget * 0.10, BrandTertiary)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandTertiary)
            ) {
                Text("Close Financial Analytics", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ResourceSpendRow(label: String, spent: Double, budget: Double, color: Color) {
    val pct = if (budget > 0) (spent / budget).toFloat().coerceIn(0f, 1f) else 0f
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = TextPrimary)
            Text("£${String.format("%,.0f", spent)} / £${String.format("%,.0f", budget)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { pct },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = color,
            trackColor = SlateDarkest
        )
    }
}
