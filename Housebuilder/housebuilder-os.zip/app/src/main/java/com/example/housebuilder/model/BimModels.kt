package com.example.housebuilder.model

/**
 * Rich Building Information Modeling (BIM) component entity.
 */
data class BimComponent(
    val id: String,
    val name: String,
    val category: ComponentCategory,
    val stage: BuildingStage,
    val startDay: Int,
    val endDay: Int,
    val dimensions: String,
    val material: String,
    val supplier: String,
    val costMaterial: Double,
    val costLabour: Double,
    val costPlant: Double,
    val warrantyYears: Int,
    val maintenanceIntervalMonths: Int,
    val energyRating: String,
    val embodiedCarbonKg: Double,
    val room: RoomType? = null,
    val layerIndex: Int = 0 // Used for vertical exploded view
) {
    val totalCost: Double get() = costMaterial + costLabour + costPlant

    fun getStateForDay(currentDay: Int): ComponentState {
        return when {
            currentDay < startDay -> ComponentState.NOT_STARTED
            currentDay == startDay -> ComponentState.PLANNED
            currentDay in startDay until endDay -> ComponentState.UNDER_CONSTRUCTION
            currentDay == endDay -> ComponentState.INSTALLED
            currentDay in (endDay + 1)..(endDay + 7) -> ComponentState.INSPECTED
            else -> ComponentState.COMPLETE
        }
    }

    fun getProgressFraction(currentDay: Int): Float {
        if (currentDay < startDay) return 0f
        if (currentDay >= endDay) return 1f
        val duration = (endDay - startDay).coerceAtLeast(1)
        return ((currentDay - startDay).toFloat() / duration).coerceIn(0f, 1f)
    }
}

/**
 * Active construction machinery entity with mechanical kinematics and articulated state.
 */
enum class MachineType(val displayName: String) {
    EXCAVATOR("360° Hydraulic Excavator (20T)"),
    DUMP_TRUCK("Articulated Dump Truck (30T)"),
    TOWER_CRANE("High-Luffing Tower Crane (40m)"),
    CONCRETE_MIXER("8m³ Volumetric Concrete Truck"),
    TELEHANDLER("17m Telescopic Fork Handler"),
    DELIVERY_FLATBED("Heavy Materials Transport Lorry")
}

data class MachineryEntity(
    val id: String,
    val type: MachineType,
    val activeStages: List<BuildingStage>,
    val basePositionX: Float,
    val basePositionY: Float,
    val basePositionZ: Float,
    var isOperating: Boolean = true,
    var currentTask: String = "Operating on plot",
    var articulatedAngle1: Float = 0f, // e.g. Crane slew or Excavator boom
    var articulatedAngle2: Float = 0f, // e.g. Crane trolley or Excavator arm
    var articulatedAngle3: Float = 0f  // e.g. Hook hoist or Bucket scoop
) {
    fun isActiveOnDay(day: Int): Boolean {
        val stage = BuildingStage.forDay(day)
        return activeStages.contains(stage)
    }
}

/**
 * Construction site skilled worker entity.
 */
enum class WorkerTrade(val title: String, val helmetColorHex: Long) {
    SITE_MANAGER("Site Manager & BIM Engineer", 0xFFFFFFFF),
    GROUNDWORKER("Civils & Groundworker", 0xFFFF9800),
    BRICKLAYER("Master Mason & Bricklayer", 0xFFFFC107),
    CARPENTER("Structural Framing Carpenter", 0xFF8D6E63),
    ELECTRICIAN("Certified High-Voltage Electrician", 0xFF2196F3),
    PLUMBER("Mechanical & Heating Engineer", 0xFF00BCD4),
    ROOFER("Specialist Roofing Contractor", 0xFF9E9E9E),
    PLASTERER("Interior Drylining & Plasterer", 0xFFE0E0E0),
    PAINTER("Architectural Decorator", 0xFF4CAF50),
    LANDSCAPER("Exterior Landscape Specialist", 0xFF8BC34A)
}

data class WorkerEntity(
    val id: String,
    val trade: WorkerTrade,
    val activeStages: List<BuildingStage>,
    val currentTask: String,
    val x: Float,
    val y: Float,
    val z: Float
) {
    fun isActiveOnDay(day: Int): Boolean {
        val stage = BuildingStage.forDay(day)
        return activeStages.contains(stage)
    }
}

/**
 * Dynamic material inventory item tracking delivery and installation volumes.
 */
data class MaterialInventoryItem(
    val id: String,
    val name: String,
    val totalRequired: Double,
    val unit: String,
    val startDeliveryDay: Int,
    val endConsumptionDay: Int,
    val costPerUnit: Double
) {
    fun getDeliveredQuantity(currentDay: Int): Double {
        if (currentDay < startDeliveryDay) return 0.0
        val deliveryDuration = (endConsumptionDay - startDeliveryDay) * 0.7
        val fraction = ((currentDay - startDeliveryDay) / deliveryDuration).coerceIn(0.0, 1.0)
        return totalRequired * fraction
    }

    fun getInstalledQuantity(currentDay: Int): Double {
        if (currentDay < startDeliveryDay + 3) return 0.0
        val installDuration = (endConsumptionDay - (startDeliveryDay + 3)).coerceAtLeast(1)
        val fraction = ((currentDay - (startDeliveryDay + 3)).toDouble() / installDuration).coerceIn(0.0, 1.0)
        return totalRequired * fraction
    }

    fun getRemainingOnSite(currentDay: Int): Double {
        return (getDeliveredQuantity(currentDay) - getInstalledQuantity(currentDay)).coerceAtLeast(0.0)
    }
}
