package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Architectural Blueprint & Construction Theme Palette
val BrandPrimary = Color(0xFFFF6D00) // Safety High-Vis Orange
val BrandSecondary = Color(0xFF00E5FF) // Blueprint Cyan
val BrandTertiary = Color(0xFFFFB300) // Equipment Amber Gold

val SlateDarkest = Color(0xFF0B0F19) // Deep Midnight Ground
val SlateDark = Color(0xFF111827) // Topbar & Container Surface
val SlateCard = Color(0xFF1F2937) // Card Elevated
val SlateBorder = Color(0xFF374151) // Subtle separator borders

val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val AccentSuccess = Color(0xFF10B981) // Passivhaus Green
val AccentWarning = Color(0xFFF59E0B) // Caution Yellow
val AccentError = Color(0xFFEF4444)   // Error Red
val CaliperGreen = Color(0xFF00E676)  // 3D Dimension Green
