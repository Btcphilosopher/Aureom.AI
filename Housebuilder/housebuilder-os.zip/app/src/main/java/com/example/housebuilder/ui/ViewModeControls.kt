package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.CameraPreset
import com.example.housebuilder.model.ConstructionViewMode
import com.example.ui.theme.*

@Composable
fun ViewModeSelectorBar(
    currentMode: ConstructionViewMode,
    onSelectMode: (ConstructionViewMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ConstructionViewMode.entries.forEach { mode ->
            val isSelected = (mode == currentMode)
            Surface(
                onClick = { onSelectMode(mode) },
                shape = RoundedCornerShape(20.dp),
                color = if (isSelected) BrandSecondary else SlateCard.copy(alpha = 0.85f),
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.height(34.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = getViewModeIcon(mode),
                        contentDescription = mode.title,
                        tint = if (isSelected) Color.Black else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = mode.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else TextPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun CameraPresetsBar(
    onSelectPreset: (CameraPreset) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CameraPreset.entries.forEach { preset ->
            FilledTonalButton(
                onClick = { onSelectPreset(preset) },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(28.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = SlateCard,
                    contentColor = TextSecondary
                )
            ) {
                Text(preset.label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

fun getViewModeIcon(mode: ConstructionViewMode): ImageVector {
    return when (mode) {
        ConstructionViewMode.REALISTIC_3D -> Icons.Default.Home
        ConstructionViewMode.EXPLODED_LAYERS -> Icons.Default.Layers
        ConstructionViewMode.CUTAWAY_XRAY -> Icons.Default.Visibility
        ConstructionViewMode.STRUCTURAL_FRAME -> Icons.Default.Architecture
        ConstructionViewMode.MEP_SERVICES -> Icons.Default.Plumbing
        ConstructionViewMode.ENERGY_SIMULATION -> Icons.Default.Bolt
        ConstructionViewMode.DIGITAL_TWIN_BIM -> Icons.Default.QrCode
        ConstructionViewMode.ROOM_BY_ROOM -> Icons.Default.MeetingRoom
        ConstructionViewMode.MEASURE_CALIPER -> Icons.Default.Straighten
        ConstructionViewMode.ESTATE_MASTERPLAN -> Icons.Default.LocationCity
        ConstructionViewMode.WHOLE_LIFE_MAINTENANCE -> Icons.Default.Build
    }
}
