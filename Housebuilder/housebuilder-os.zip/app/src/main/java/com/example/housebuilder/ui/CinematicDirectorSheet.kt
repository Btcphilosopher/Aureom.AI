package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CinematicDirectorSheet(
    isCinematic: Boolean,
    currentDurationSec: Int,
    onSetDuration: (Int) -> Unit,
    onStartCinematic: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CINEMATIC BUILD FILM DIRECTOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSecondary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Automated Time-Lapse Production",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Compresses 240 days of physical house construction into an ultra-smooth cinematic orbital camera flight with synchronized sunrise-to-sunset lighting transitions.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Duration Presets (30s, 60s, 2min, 5min)
            Text("Select Film Duration", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            val durations = listOf(
                30 to "30 Seconds (Fast Highlight)",
                60 to "60 Seconds (Standard Presentation)",
                120 to "2 Minutes (Detailed Showcase)",
                300 to "5 Minutes (Full Engineering Film)"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                durations.forEach { (sec, label) ->
                    val isSel = (currentDurationSec == sec)
                    Surface(
                        onClick = { onSetDuration(sec) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) SlateCard else SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) BrandSecondary else SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(label, fontSize = 13.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal, color = if (isSel) TextPrimary else TextSecondary)
                            if (isSel) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = BrandSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    onStartCinematic(currentDurationSec)
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandSecondary)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Cinematic Build Sequence", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
