package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.BimComponent
import com.example.ui.theme.*

@Composable
fun WholeLifeSheet(
    components: List<BimComponent>,
    currentYear: Int,
    onYearChange: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "30-YEAR WHOLE-LIFE ASSET TWIN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandTertiary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Degradation & Maintenance",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Year Timeline Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Simulated Operation Time", fontSize = 12.sp, color = TextSecondary)
                Text(
                    "YEAR $currentYear / 30",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = BrandTertiary
                )
            }
            Slider(
                value = currentYear.toFloat(),
                onValueChange = { onYearChange(it.toInt()) },
                valueRange = 1f..30f,
                steps = 28,
                colors = SliderDefaults.colors(
                    thumbColor = BrandTertiary,
                    activeTrackColor = BrandTertiary,
                    inactiveTrackColor = SlateCard
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Cumulative Maintenance Cost Projection Card
            val cumulativeMaintCost = currentYear * 1250.0 + (if (currentYear >= 15) 8500.0 else 0.0) + (if (currentYear >= 25) 12000.0 else 0.0)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateCard)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("CUMULATIVE MAINTENANCE & REPLACEMENTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                Text("£${String.format("%,.2f", cumulativeMaintCost)}", fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = BrandPrimary)
                Text(
                    "Predictive lifecycle replacement models based on CIBSE guide M and BRE durability standards.",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Component Degradation Health Index
            Text("Component Health & Warranty Status", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                components.take(8).forEach { comp ->
                    val isOutOfWarranty = (currentYear > comp.warrantyYears)
                    val expectedLife = (comp.warrantyYears * 1.5f).toInt()
                    val healthFraction = ((expectedLife - currentYear).toFloat() / expectedLife.toFloat()).coerceIn(0f, 1f)
                    val healthPct = (healthFraction * 100).toInt()

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(comp.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                if (isOutOfWarranty) {
                                    Surface(color = AccentWarning.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                                        Text("Expired Warranty", modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontSize = 10.sp, color = AccentWarning)
                                    }
                                } else {
                                    Surface(color = AccentSuccess.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                                        Text("In Warranty (${comp.warrantyYears - currentYear}y left)", modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontSize = 10.sp, color = AccentSuccess)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Asset Health: $healthPct%", fontSize = 11.sp, color = TextSecondary)
                                LinearProgressIndicator(
                                    progress = { healthFraction },
                                    modifier = Modifier.width(120.dp).height(5.dp),
                                    color = when {
                                        healthPct > 70 -> AccentSuccess
                                        healthPct > 35 -> AccentWarning
                                        else -> AccentError
                                    },
                                    trackColor = SlateCard
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandTertiary)
            ) {
                Text("Close Lifecycle Simulation", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
