package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HousebuilderColorScheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF37230F),
    onPrimaryContainer = Color(0xFFFFCC80),
    secondary = BrandSecondary,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003844),
    onSecondaryContainer = Color(0xFF80F2FF),
    tertiary = BrandTertiary,
    onTertiary = Color.Black,
    background = SlateDarkest,
    onBackground = TextPrimary,
    surface = SlateDark,
    onSurface = TextPrimary,
    surfaceVariant = SlateCard,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder
)

@Composable
fun HousebuilderTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HousebuilderColorScheme,
        typography = Typography,
        content = content
    )
}
