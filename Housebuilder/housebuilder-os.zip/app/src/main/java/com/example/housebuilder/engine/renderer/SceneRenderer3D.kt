package com.example.housebuilder.engine.renderer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.housebuilder.engine.math.Camera3D
import com.example.housebuilder.engine.math.Polygon3D
import com.example.housebuilder.engine.math.Vector3
import com.example.housebuilder.model.ConstructionViewMode
import com.example.housebuilder.model.ParametricHouseConfig
import com.example.housebuilder.model.SiteEnvironmentState
import com.example.housebuilder.model.WeatherType
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-performance 3D Scene Renderer for Compose Canvas.
 * Implements Painters algorithm depth sorting, dynamic directional solar lighting,
 * wireframe rendering, environmental weather particle systems, and 3D dimension overlays.
 */
object SceneRenderer3D {

    data class ProjectedPoly(
        val poly: Polygon3D,
        val projectedPoints: List<Offset>,
        val averageDepth: Float,
        val shadedColor: Color,
        val isVisible: Boolean
    )

    fun renderScene(
        drawScope: DrawScope,
        polygons: List<Polygon3D>,
        camera: Camera3D,
        envState: SiteEnvironmentState,
        viewMode: ConstructionViewMode,
        config: ParametricHouseConfig,
        simTick: Float,
        onProjectedPolysReady: (List<ProjectedPoly>) -> Unit = {}
    ) {
        val width = drawScope.size.width
        val height = drawScope.size.height
        val sunDir = camera.getSunDirection(envState.timeOfDayHours)

        // Sky & Ambient Background
        drawSkyBackground(drawScope, envState)

        // Transform, light, and depth-sort all 3D polygons
        val projectedList = ArrayList<ProjectedPoly>(polygons.size)

        for (poly in polygons) {
            var sumDepth = 0f
            var allVisible = true
            val offsets = ArrayList<Offset>(poly.vertices.size)

            for (v in poly.vertices) {
                val proj = camera.project(v, width, height)
                if (!proj.visible) {
                    allVisible = false
                }
                offsets.add(proj.screenOffset)
                sumDepth += proj.depth
            }

            if (allVisible && offsets.size >= 3) {
                val avgDepth = sumDepth / offsets.size

                // Lighting calculation
                val normal = poly.calculateNormal()
                val nDotL = normal.dot(sunDir).coerceIn(0f, 1f)

                val ambient = when {
                    envState.timeOfDayHours in 6f..18f -> 0.42f
                    else -> 0.20f // Night lighting
                }
                val diffuse = nDotL * 0.58f
                val lightFactor = if (poly.isEmissive) 1.2f else (ambient + diffuse).coerceIn(0.18f, 1.0f)

                val base = poly.baseColor
                val shadedColor = if (poly.isEmissive) {
                    base
                } else {
                    Color(
                        red = (base.red * lightFactor).coerceIn(0f, 1f),
                        green = (base.green * lightFactor).coerceIn(0f, 1f),
                        blue = (base.blue * lightFactor).coerceIn(0f, 1f),
                        alpha = base.alpha
                    )
                }

                projectedList.add(
                    ProjectedPoly(
                        poly = poly,
                        projectedPoints = offsets,
                        averageDepth = avgDepth,
                        shadedColor = shadedColor,
                        isVisible = true
                    )
                )
            }
        }

        // Sort by average depth descending (Painters algorithm: draw farthest objects first)
        projectedList.sortByDescending { it.averageDepth }
        onProjectedPolysReady(projectedList)

        // Draw Polygons
        val path = Path()
        for (item in projectedList) {
            path.reset()
            val points = item.projectedPoints
            if (points.isNotEmpty()) {
                path.moveTo(points[0].x, points[0].y)
                for (i in 1 until points.size) {
                    path.lineTo(points[i].x, points[i].y)
                }
                path.close()

                // Solid Fill
                if (!item.poly.isWireframe) {
                    drawScope.drawPath(path, color = item.shadedColor, style = Fill)
                }

                // Structural or Edge Wireframe
                if (item.poly.isWireframe || viewMode == ConstructionViewMode.STRUCTURAL_FRAME) {
                    drawScope.drawPath(
                        path,
                        color = if (item.poly.isWireframe) item.poly.wireframeColor else Color(0x66FFFFFF),
                        style = Stroke(width = item.poly.strokeWidth)
                    )
                }
            }
        }

        // 3D Dimensional Calipers & Measurement Overlays
        if (viewMode == ConstructionViewMode.MEASURE_CALIPER) {
            drawDimensionalCalipers(drawScope, camera, config, width, height)
        }

        // Weather particle simulation (Rain / Snow / Dust)
        drawWeatherParticles(drawScope, envState.weather, simTick, width, height)
    }

    private fun drawSkyBackground(drawScope: DrawScope, envState: SiteEnvironmentState) {
        val tod = envState.timeOfDayHours
        val skyColor = when {
            tod in 5.5f..7.0f -> Color(0xFFE65100)  // Sunrise amber
            tod in 7.0f..17.0f -> Color(0xFF1E293B) // Modern blueprint slate blue
            tod in 17.0f..19.5f -> Color(0xFFC2185B) // Sunset crimson
            else -> Color(0xFF0F172A)               // Midnight deep navy
        }
        // Subtle gradient background
        drawScope.drawRect(color = skyColor)
    }

    private fun drawDimensionalCalipers(
        drawScope: DrawScope,
        camera: Camera3D,
        config: ParametricHouseConfig,
        w: Float,
        h: Float
    ) {
        val hw = config.widthMeters * 0.5f
        val hl = config.lengthMeters * 0.5f
        val caliperColor = Color(0xFF00E676) // Bright neon green dimension lines

        // Width Caliper (Front ground line)
        val pW0 = camera.project(Vector3(-hw, 0.1f, hl + 1.2f), w, h).screenOffset
        val pW1 = camera.project(Vector3(hw, 0.1f, hl + 1.2f), w, h).screenOffset

        // Length Caliper (Side line)
        val pL0 = camera.project(Vector3(-hw - 1.2f, 0.1f, hl), w, h).screenOffset
        val pL1 = camera.project(Vector3(-hw - 1.2f, 0.1f, -hl), w, h).screenOffset

        // Height Caliper (Vertical apex line)
        val pH0 = camera.project(Vector3(hw + 1.2f, 0f, hl), w, h).screenOffset
        val pH1 = camera.project(Vector3(hw + 1.2f, config.floorCount * 2.8f + 3.2f, hl), w, h).screenOffset

        // Draw caliper guide lines
        drawScope.drawLine(caliperColor, pW0, pW1, strokeWidth = 2.5f)
        drawScope.drawLine(caliperColor, pL0, pL1, strokeWidth = 2.5f)
        drawScope.drawLine(caliperColor, pH0, pH1, strokeWidth = 2.5f)

        // End tick marks
        drawScope.drawCircle(caliperColor, radius = 4f, center = pW0)
        drawScope.drawCircle(caliperColor, radius = 4f, center = pW1)
        drawScope.drawCircle(caliperColor, radius = 4f, center = pL0)
        drawScope.drawCircle(caliperColor, radius = 4f, center = pL1)
        drawScope.drawCircle(caliperColor, radius = 4f, center = pH0)
        drawScope.drawCircle(caliperColor, radius = 4f, center = pH1)
    }

    private fun drawWeatherParticles(
        drawScope: DrawScope,
        weather: WeatherType,
        simTick: Float,
        screenWidth: Float,
        screenHeight: Float
    ) {
        if (weather == WeatherType.SUNNY_CLEAR || weather == WeatherType.OVERCAST) return

        val particleCount = 45
        for (i in 0 until particleCount) {
            val seed = (i * 137.5f)
            val px = (seed * 19f + simTick * 120f) % screenWidth
            val py = (seed * 31f + simTick * 320f) % screenHeight

            when (weather) {
                WeatherType.HEAVY_RAIN -> {
                    drawScope.drawLine(
                        color = Color(0x8081D4FA),
                        start = Offset(px, py),
                        end = Offset(px - 4f, py + 14f),
                        strokeWidth = 1.8f
                    )
                }
                WeatherType.WINTER_SNOW -> {
                    drawScope.drawCircle(
                        color = Color(0xCCFFFFFF),
                        radius = 2.5f,
                        center = Offset(px + sin(simTick + i) * 15f, py)
                    )
                }
                WeatherType.WINDY_GALE -> {
                    drawScope.drawLine(
                        color = Color(0x44ECEFF1),
                        start = Offset(px, py),
                        end = Offset(px + 28f, py + 3f),
                        strokeWidth = 1.2f
                    )
                }
                else -> Unit
            }
        }
    }

    /**
     * Hit test to find if user tapped on a BIM component polygon.
     */
    fun findBimComponentAtScreenPoint(
        tapOffset: Offset,
        projectedPolys: List<ProjectedPoly>
    ): String? {
        // Search from nearest (drawn last) to farthest (drawn first)
        for (item in projectedPolys.reversed()) {
            if (item.poly.bimId != null && isPointInPolygon(tapOffset, item.projectedPoints)) {
                return item.poly.bimId
            }
        }
        return null
    }

    private fun isPointInPolygon(p: Offset, vertices: List<Offset>): Boolean {
        var inside = false
        var j = vertices.size - 1
        for (i in vertices.indices) {
            val vi = vertices[i]
            val vj = vertices[j]
            if ((vi.y > p.y) != (vj.y > p.y) &&
                (p.x < (vj.x - vi.x) * (p.y - vi.y) / (vj.y - vi.y) + vi.x)
            ) {
                inside = !inside
            }
            j = i
        }
        return inside
    }
}
