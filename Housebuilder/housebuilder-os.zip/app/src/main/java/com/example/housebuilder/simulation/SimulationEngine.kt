package com.example.housebuilder.simulation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.housebuilder.engine.math.Camera3D
import com.example.housebuilder.engine.math.Vector3
import com.example.housebuilder.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.cos
import kotlin.math.sin

/**
 * Core Digital Housebuilding Simulation Engine for Housebuilder OS.
 * Manages construction time machine, real-time schedule synchronisation,
 * material inventory consumption, active machinery kinematics, and cinematic camera choreography.
 */
class SimulationEngine(
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {

    // --- State Properties ---
    var currentDay by mutableFloatStateOf(1.0f)
        private set

    var isPlaying by mutableStateOf(false)
        private set

    var playbackSpeed by mutableFloatStateOf(1.0f)
        private set

    var isReverseMode by mutableStateOf(false)
        private set

    var isCinematicMode by mutableStateOf(false)
        private set

    var cinematicDurationSec by mutableIntStateOf(60)

    var viewMode by mutableStateOf(ConstructionViewMode.REALISTIC_3D)
    var explodedOffset by mutableFloatStateOf(0.0f)

    var selectedBimComponent by mutableStateOf<BimComponent?>(null)
    var selectedRoom by mutableStateOf<RoomType?>(null)

    var camera = Camera3D()
    var targetAzimuth by mutableFloatStateOf(45f)
    var targetElevation by mutableFloatStateOf(30f)
    var targetZoom by mutableFloatStateOf(1.0f)
    var targetLookAt by mutableStateOf(Vector3(0f, 1.5f, 0f))

    var houseConfig by mutableStateOf(ParametricHouseConfig())
    var environmentState by mutableStateOf(SiteEnvironmentState())

    var developmentPlotCount by mutableIntStateOf(1)
    var maintenanceYear by mutableIntStateOf(1)

    // Data catalogs
    val allComponents = BimRepository.createStandardComponents()
    val allMachinery = BimRepository.createStandardMachinery()
    val allWorkers = BimRepository.createStandardWorkers()
    val allMaterials = BimRepository.createStandardMaterials()

    var simulationTick by mutableFloatStateOf(0f)
        private set

    private var simulationJob: Job? = null

    init {
        startSimulationLoop()
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = coroutineScope.launch {
            var lastTime = System.currentTimeMillis()
            while (isActive) {
                val now = System.currentTimeMillis()
                val dt = ((now - lastTime) / 1000f).coerceIn(0.001f, 0.1f)
                lastTime = now

                simulationTick += dt

                // Continuous Camera Smooth Interpolation
                updateCameraInterpolation(dt)

                // Cinematic Build Film Choreography
                if (isCinematicMode) {
                    updateCinematicChoreography(dt)
                }

                // Advance Timeline
                if (isPlaying) {
                    val dayDelta = (dt * playbackSpeed * if (isReverseMode) -1f else 1f)
                    val newDay = (currentDay + dayDelta).coerceIn(1.0f, 245.0f)
                    currentDay = newDay

                    if (newDay >= 240f && !isReverseMode) {
                        isPlaying = false
                    } else if (newDay <= 1.0f && isReverseMode) {
                        isPlaying = false
                    }
                }

                // Update machinery kinematics
                for (mach in allMachinery) {
                    mach.articulatedAngle1 = (sin(simulationTick * 1.8f) * 30f)
                    mach.articulatedAngle2 = (cos(simulationTick * 2.2f) * 20f)
                }

                delay(16) // ~60 FPS
            }
        }
    }

    private fun updateCameraInterpolation(dt: Float) {
        val lerpFactor = (dt * 7.5f).coerceIn(0.05f, 0.4f)
        camera.azimuthDeg += (targetAzimuth - camera.azimuthDeg) * lerpFactor
        camera.elevationDeg += (targetElevation - camera.elevationDeg) * lerpFactor
        camera.zoomScale += (targetZoom - camera.zoomScale) * lerpFactor

        val curTarget = camera.target
        camera.target = Vector3(
            curTarget.x + (targetLookAt.x - curTarget.x) * lerpFactor,
            curTarget.y + (targetLookAt.y - curTarget.y) * lerpFactor,
            curTarget.z + (targetLookAt.z - curTarget.z) * lerpFactor
        )
    }

    private fun updateCinematicChoreography(dt: Float) {
        val progress = (currentDay / 240f).coerceIn(0f, 1f)
        // Orbit camera around house as build progresses
        targetAzimuth = (progress * 360f + 45f) % 360f
        targetElevation = 18f + sin(progress * Math.PI.toFloat() * 2f) * 12f

        // Sun tracks with progress
        val timeOfDay = 6.0f + (progress * 14.0f) // Sunrise 6am -> Sunset 8pm
        environmentState = environmentState.copy(timeOfDayHours = timeOfDay)
    }

    // --- User Actions & Timeline Controls ---

    fun togglePlayPause() {
        isPlaying = !isPlaying
    }

    fun setSpeed(speed: Float) {
        playbackSpeed = speed
    }

    fun seekToDay(day: Float) {
        currentDay = day.coerceIn(1.0f, 245.0f)
    }

    fun stepForward(days: Float = 1.0f) {
        currentDay = (currentDay + days).coerceIn(1.0f, 245.0f)
    }

    fun stepBackward(days: Float = 1.0f) {
        currentDay = (currentDay - days).coerceIn(1.0f, 245.0f)
    }

    fun toggleReverseMode() {
        isReverseMode = !isReverseMode
    }

    fun setCinematicModeEnabled(enabled: Boolean) {
        isCinematicMode = enabled
        if (enabled) {
            isPlaying = true
            isReverseMode = false
            viewMode = ConstructionViewMode.REALISTIC_3D
            val speedFactor = 240f / cinematicDurationSec.toFloat()
            playbackSpeed = speedFactor
        }
    }

    fun applyCameraPreset(preset: CameraPreset) {
        targetAzimuth = preset.azimuth
        targetElevation = preset.elevation
        targetZoom = preset.zoom
        targetLookAt = Vector3(0f, 1.5f + preset.targetOffsetY, 0f)
    }

    fun orbitCamera(deltaAzimuth: Float, deltaElevation: Float) {
        isCinematicMode = false
        targetAzimuth = (targetAzimuth + deltaAzimuth) % 360f
        targetElevation = (targetElevation + deltaElevation).coerceIn(-30f, 85f)
    }

    fun zoomCamera(deltaZoom: Float) {
        targetZoom = (targetZoom * deltaZoom).coerceIn(0.4f, 3.5f)
    }

    fun selectBimById(id: String?) {
        selectedBimComponent = if (id != null) allComponents.firstOrNull { it.id == id } else null
    }

    fun selectRoom(room: RoomType?) {
        selectedRoom = room
        if (room != null) {
            when (room) {
                RoomType.KITCHEN_DINING -> applyCameraPreset(CameraPreset.INTERIOR_KITCHEN)
                RoomType.LIVING_ROOM -> applyCameraPreset(CameraPreset.INTERIOR_LIVING)
                RoomType.ROOF_ATTIC -> applyCameraPreset(CameraPreset.ROOF_AERIAL)
                RoomType.GROUND_ENTRANCE -> applyCameraPreset(CameraPreset.FRONT_ELEVATION)
                else -> applyCameraPreset(CameraPreset.ORBIT_ISOMETRIC)
            }
        }
    }

    // --- Metrics & KPI Calculations ---

    fun getOverallProgressFraction(): Float {
        return (currentDay / 240f).coerceIn(0f, 1f)
    }

    fun getStageProgress(stage: BuildingStage): Float {
        val day = currentDay.toInt()
        return when {
            day < stage.startDay -> 0f
            day >= stage.endDay -> 1f
            else -> ((day - stage.startDay).toFloat() / stage.durationDays.toFloat()).coerceIn(0f, 1f)
        }
    }

    fun getTotalProjectBudget(): Double {
        return allComponents.sumOf { it.totalCost }
    }

    fun getSpentToDate(): Double {
        val day = currentDay.toInt()
        var total = 0.0
        for (c in allComponents) {
            val prog = c.getProgressFraction(day)
            total += c.totalCost * prog
        }
        return total
    }

    fun getMaterialCostToDate(): Double {
        val day = currentDay.toInt()
        return allComponents.sumOf { it.costMaterial * it.getProgressFraction(day) }
    }

    fun getLabourCostToDate(): Double {
        val day = currentDay.toInt()
        return allComponents.sumOf { it.costLabour * it.getProgressFraction(day) }
    }

    fun getPlantCostToDate(): Double {
        val day = currentDay.toInt()
        return allComponents.sumOf { it.costPlant * it.getProgressFraction(day) }
    }

    fun getActiveWorkerCount(): Int {
        val day = currentDay.toInt()
        return allWorkers.count { it.isActiveOnDay(day) }
    }

    fun getActiveMachineryCount(): Int {
        val day = currentDay.toInt()
        return allMachinery.count { it.isActiveOnDay(day) }
    }

    fun getRoomCompletionPercentage(room: RoomType): Int {
        val day = currentDay.toInt()
        val roomComps = allComponents.filter { it.room == room }
        if (roomComps.isEmpty()) return (getOverallProgressFraction() * 100).toInt()
        val avg = roomComps.map { it.getProgressFraction(day) }.average()
        return (avg * 100).toInt()
    }
}
