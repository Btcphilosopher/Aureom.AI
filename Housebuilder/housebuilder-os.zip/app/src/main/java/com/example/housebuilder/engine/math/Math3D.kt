package com.example.housebuilder.engine.math

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vector3(
    val x: Float,
    val y: Float,
    val z: Float
) {
    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)
    operator fun div(scalar: Float) = Vector3(x / scalar, y / scalar, z / scalar)

    fun dot(other: Vector3): Float = x * other.x + y * other.y + z * other.z

    fun cross(other: Vector3): Vector3 = Vector3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun normalized(): Vector3 {
        val len = length()
        return if (len > 0.0001f) this / len else Vector3(0f, 1f, 0f)
    }

    companion object {
        val ZERO = Vector3(0f, 0f, 0f)
        val UP = Vector3(0f, 1f, 0f)
        val RIGHT = Vector3(1f, 0f, 0f)
        val FORWARD = Vector3(0f, 0f, 1f)
    }
}

data class ProjectedPoint(
    val screenOffset: Offset,
    val depth: Float,
    val visible: Boolean = true
)

data class Polygon3D(
    val vertices: List<Vector3>,
    val baseColor: Color,
    val tag: String = "",
    val bimId: String? = null,
    val isWireframe: Boolean = false,
    val wireframeColor: Color = Color.White.copy(alpha = 0.5f),
    val strokeWidth: Float = 1.5f,
    val normalOverride: Vector3? = null,
    val isEmissive: Boolean = false
) {
    fun calculateNormal(): Vector3 {
        if (normalOverride != null) return normalOverride
        if (vertices.size < 3) return Vector3.UP
        val v0 = vertices[0]
        val v1 = vertices[1]
        val v2 = vertices[2]
        val edge1 = v1 - v0
        val edge2 = v2 - v0
        return edge1.cross(edge2).normalized()
    }

    fun center(): Vector3 {
        if (vertices.isEmpty()) return Vector3.ZERO
        var sx = 0f
        var sy = 0f
        var sz = 0f
        for (v in vertices) {
            sx += v.x
            sy += v.y
            sz += v.z
        }
        val count = vertices.size.toFloat()
        return Vector3(sx / count, sy / count, sz / count)
    }
}

class Camera3D(
    var azimuthDeg: Float = 45f,     // Yaw around Y axis
    var elevationDeg: Float = 30f,   // Pitch above ground
    var zoomScale: Float = 1.0f,
    var target: Vector3 = Vector3(0f, 1.5f, 0f),
    var isPerspective: Boolean = true
) {
    fun project(point: Vector3, screenWidth: Float, screenHeight: Float): ProjectedPoint {
        val radAzimuth = Math.toRadians(azimuthDeg.toDouble()).toFloat()
        val radElevation = Math.toRadians(elevationDeg.toDouble()).toFloat()

        // 1. Translate relative to camera target
        val px = point.x - target.x
        val py = point.y - target.y
        val pz = point.z - target.z

        // 2. Rotate around Y (Azimuth)
        val cosAz = cos(radAzimuth)
        val sinAz = sin(radAzimuth)
        val x1 = px * cosAz - pz * sinAz
        val z1 = px * sinAz + pz * cosAz
        val y1 = py

        // 3. Rotate around X (Elevation)
        val cosEl = cos(radElevation)
        val sinEl = sin(radElevation)
        val y2 = y1 * cosEl - z1 * sinEl
        val z2 = y1 * sinEl + z1 * cosEl
        val x2 = x1

        val baseScale = (screenWidth.coerceAtMost(screenHeight) * 0.055f) * zoomScale

        val depthPerspective: Float
        val screenX: Float
        val screenY: Float

        if (isPerspective) {
            val cameraDist = 32.0f
            val denom = (cameraDist + z2).coerceAtLeast(1.0f)
            depthPerspective = cameraDist / denom
            screenX = (screenWidth / 2f) + (x2 * baseScale * depthPerspective)
            screenY = (screenHeight / 2f) - (y2 * baseScale * depthPerspective)
        } else {
            depthPerspective = 1.0f
            screenX = (screenWidth / 2f) + (x2 * baseScale)
            screenY = (screenHeight / 2f) - (y2 * baseScale)
        }

        return ProjectedPoint(
            screenOffset = Offset(screenX, screenY),
            depth = z2,
            visible = (z2 > -28f)
        )
    }

    fun getSunDirection(timeOfDayHours: Float): Vector3 {
        // Sun tracks from East (X > 0) to West (X < 0) as time moves 6am -> 6pm
        val hourNorm = (timeOfDayHours - 6f) / 12f // 0 at 6am, 0.5 at 12pm, 1.0 at 6pm
        val sunAngle = (hourNorm * Math.PI).toFloat()
        val sunX = cos(sunAngle) * 0.8f
        val sunY = (sin(sunAngle) * 0.9f + 0.2f).coerceAtLeast(0.1f)
        val sunZ = 0.5f
        return Vector3(sunX, sunY, sunZ).normalized()
    }
}
