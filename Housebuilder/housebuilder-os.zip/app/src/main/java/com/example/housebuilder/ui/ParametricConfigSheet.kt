package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.*
import com.example.ui.theme.*

@Composable
fun ParametricConfigSheet(
    config: ParametricHouseConfig,
    onConfigChange: (ParametricHouseConfig) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PARAMETRIC HOUSE CONFIGURATOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandPrimary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Procedural BIM Architecture",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Area & Cost Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateCard)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("GROSS INTERNAL AREA", fontSize = 11.sp, color = TextSecondary)
                    Text("${String.format("%.1f", config.totalFloorAreaM2)} m²", fontSize = 18.sp, fontWeight = FontWeight.Black, color = BrandSecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("ESTIMATED BUILD COST", fontSize = 11.sp, color = TextSecondary)
                    Text("£${String.format("%,.0f", config.estimatedTotalCost)}", fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = BrandTertiary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dimensions: Width & Length
            Text("Footprint Dimensions", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Width: ${String.format("%.1f", config.widthMeters)}m", fontSize = 12.sp, color = TextSecondary)
                    Slider(
                        value = config.widthMeters,
                        onValueChange = { onConfigChange(config.copy(widthMeters = it)) },
                        valueRange = 7.0f..14.0f
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Length: ${String.format("%.1f", config.lengthMeters)}m", fontSize = 12.sp, color = TextSecondary)
                    Slider(
                        value = config.lengthMeters,
                        onValueChange = { onConfigChange(config.copy(lengthMeters = it)) },
                        valueRange = 8.0f..18.0f
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Number of Storeys
            Text("Number of Storeys", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3).forEach { floors ->
                    val isSel = (config.floorCount == floors)
                    Surface(
                        onClick = { onConfigChange(config.copy(floorCount = floors)) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) BrandPrimary else SlateCard,
                        modifier = Modifier.weight(1f).height(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (floors == 1) "Bungalow (1F)" else "$floors Storeys",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.Black else TextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Facade Material Finish
            Text("External Facade Finish", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FacadeFinish.entries.forEach { finish ->
                    val isSel = (config.facadeFinish == finish)
                    Surface(
                        onClick = { onConfigChange(config.copy(facadeFinish = finish)) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) SlateCard else SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) BrandSecondary else SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(finish.baseColorHex))
                            )
                            Text(
                                text = finish.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Roof Geometry & Finish
            Text("Roof Covering Specification", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RoofFinish.entries.forEach { rf ->
                    val isSel = (config.roofFinish == rf)
                    Surface(
                        onClick = { onConfigChange(config.copy(roofFinish = rf)) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) SlateCard else SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) BrandTertiary else SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(rf.colorHex))
                            )
                            Text(
                                text = rf.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Smart Energy & Extensions Options
            Text("Renewables & Spatial Options", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            OptionSwitchRow("Integrated Solar PV Array (5.8 kWp)", config.hasSolarPvArray) {
                onConfigChange(config.copy(hasSolarPvArray = it))
            }
            OptionSwitchRow("Air Source Heat Pump (ASHP)", config.hasAirSourceHeatPump) {
                onConfigChange(config.copy(hasAirSourceHeatPump = it))
            }
            OptionSwitchRow("Rear Architectural Glass Extension", config.hasRearGlassExtension) {
                onConfigChange(config.copy(hasRearGlassExtension = it))
            }
            OptionSwitchRow("Integral Garage & Workshop", config.hasIntegralGarage) {
                onConfigChange(config.copy(hasIntegralGarage = it))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
            ) {
                Text("Apply & Update 3D Geometry", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun OptionSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = TextPrimary)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = BrandPrimary,
                checkedTrackColor = BrandPrimary.copy(alpha = 0.5f)
            )
        )
    }
}
