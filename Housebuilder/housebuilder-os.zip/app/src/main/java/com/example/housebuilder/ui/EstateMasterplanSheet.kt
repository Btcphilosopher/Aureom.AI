package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.BuildingStage
import com.example.ui.theme.*

@Composable
fun EstateMasterplanSheet(
    plotCount: Int,
    currentDay: Float,
    onSelectPlotCount: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MULTI-PLOT DEVELOPMENT MASTERPLAN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSecondary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Housebuilder Production Line",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Plot Scale Selector (1, 10, 50, 100 Houses)
            Text("Development Scale (Plots)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 10, 50, 100).forEach { count ->
                    val isSel = (plotCount == count)
                    Surface(
                        onClick = { onSelectPlotCount(count) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) BrandSecondary else SlateCard,
                        modifier = Modifier.weight(1f).height(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "$count Plots",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.Black else TextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Estate Analytics Grid
            val totalGdv = plotCount * 420000.0
            val startedUnits = ((currentDay / 12f).toInt() + 1).coerceAtMost(plotCount)
            val completedUnits = ((currentDay - 180f) / 10f).toInt().coerceIn(0, plotCount)
            val underConstruction = (startedUnits - completedUnits).coerceAtLeast(0)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateCard)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ESTATE VELOCITY & PRODUCTION METRICS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandTertiary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Gross Development Value", fontSize = 11.sp, color = TextSecondary)
                        Text("£${String.format("%,.0f", totalGdv)}", fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = TextPrimary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Active Production Units", fontSize = 11.sp, color = TextSecondary)
                        Text("$underConstruction Plots", fontSize = 16.sp, fontWeight = FontWeight.Black, color = BrandPrimary)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Completed Handovers", fontSize = 11.sp, color = TextSecondary)
                        Text("$completedUnits / $plotCount", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentSuccess)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Avg Build Cycle Time", fontSize = 11.sp, color = TextSecondary)
                        Text("185 Days / Unit", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Plot Pipeline Cards
            Text("Plot Construction Sequence (Live Throughput)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            val displayCount = plotCount.coerceAtMost(10)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (plot in 1..displayCount) {
                    // Staggered days for each plot in assembly line
                    val plotDay = (currentDay - (plot - 1) * 18f).coerceAtLeast(0f)
                    val stage = if (plotDay <= 0f) null else BuildingStage.forDay(plotDay.toInt())
                    val pct = if (plotDay <= 0f) 0 else ((plotDay / 240f) * 100).toInt().coerceIn(0, 100)

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("PLOT ${String.format("%02d", plot)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                                Text(
                                    text = stage?.title ?: "Scheduled / Site Survey",
                                    fontSize = 11.sp,
                                    color = if (stage != null) BrandSecondary else TextMuted
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("$pct%", fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = if (pct == 100) AccentSuccess else BrandPrimary)
                                LinearProgressIndicator(
                                    progress = { pct / 100f },
                                    modifier = Modifier.width(70.dp).height(4.dp),
                                    color = if (pct == 100) AccentSuccess else BrandPrimary,
                                    trackColor = SlateCard
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandSecondary)
            ) {
                Text("Close Masterplan View", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
