package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.housebuilder.ui.MainConstructionScreen
import com.example.ui.theme.HousebuilderTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      HousebuilderTheme {
        MainConstructionScreen()
      }
    }
  }
}
