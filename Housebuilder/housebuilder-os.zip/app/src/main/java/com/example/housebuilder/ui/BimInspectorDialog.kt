package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.housebuilder.model.BimComponent
import com.example.ui.theme.*

@Composable
fun BimInspectorDialog(
    component: BimComponent,
    currentDay: Int,
    onDismiss: () -> Unit
) {
    val state = component.getStateForDay(currentDay)
    val progress = (component.getProgressFraction(currentDay) * 100).toInt()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, BrandSecondary.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            color = SlateDark
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BIM DIGITAL TWIN ENTITY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandSecondary,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = component.id,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Component Name & Category Badge
                Text(
                    text = component.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = Color(component.category.colorHex).copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(component.category.colorHex))
                    ) {
                        Text(
                            text = component.category.label,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(component.category.colorHex)
                        )
                    }
                    Surface(
                        color = when (state) {
                            com.example.housebuilder.model.ComponentState.COMPLETE -> AccentSuccess.copy(alpha = 0.2f)
                            com.example.housebuilder.model.ComponentState.UNDER_CONSTRUCTION -> BrandPrimary.copy(alpha = 0.2f)
                            else -> SlateCard
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "State: ${state.name} ($progress%)",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (state) {
                                com.example.housebuilder.model.ComponentState.COMPLETE -> AccentSuccess
                                com.example.housebuilder.model.ComponentState.UNDER_CONSTRUCTION -> BrandPrimary
                                else -> TextSecondary
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = SlateBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Technical Specifications Grid
                BimSpecRow("Dimensions & Spec", component.dimensions)
                BimSpecRow("Material Description", component.material)
                BimSpecRow("Approved Supplier", component.supplier)
                BimSpecRow("Construction Schedule", "Day ${component.startDay} → Day ${component.endDay} (${component.stage.title})")
                BimSpecRow("Energy & Performance", component.energyRating)
                BimSpecRow("Embodied Carbon", "${component.embodiedCarbonKg} kg CO₂e")
                BimSpecRow("Warranty Period", "${component.warrantyYears} Years")
                BimSpecRow("Maintenance Interval", "Every ${component.maintenanceIntervalMonths} Months")

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = SlateBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Cost Breakdown Card
                Text(
                    text = "COST & EXPENDITURE BREAKDOWN",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandTertiary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SlateCard)
                        .padding(12.dp)
                ) {
                    CostItemRow("Materials Cost", "£${String.format("%,.2f", component.costMaterial)}")
                    CostItemRow("Direct Labour Cost", "£${String.format("%,.2f", component.costLabour)}")
                    CostItemRow("Machinery & Plant", "£${String.format("%,.2f", component.costPlant)}")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = SlateBorder)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TOTAL INSTALLED COST", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            "£${String.format("%,.2f", component.totalCost)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = BrandPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
                ) {
                    Text("Close BIM Inspector", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun BimSpecRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}

@Composable
private fun CostItemRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
        Text(text = value, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TextPrimary)
    }
}
