package com.example.housebuilder.model

/**
 * View modes for multi-layer construction inspection.
 */
enum class ConstructionViewMode(val title: String, val subtitle: String) {
    REALISTIC_3D("Construction 3D", "Full realistic building site view"),
    EXPLODED_LAYERS("Exploded Layers", "Vertical separation of structural strata"),
    CUTAWAY_XRAY("Cutaway X-Ray", "Section plane revealing MEP & wall studs"),
    STRUCTURAL_FRAME("Structural Frame", "Load-bearing columns, beams, joists & trusses"),
    MEP_SERVICES("MEP & Building Services", "Color-coded electrical, water, HVAC & drainage"),
    ENERGY_SIMULATION("Energy & Smart Twin", "Solar microgeneration, heat pump & battery flow"),
    DIGITAL_TWIN_BIM("Digital Twin Inspector", "Clickable BIM metadata, warranties & maintenance"),
    ROOM_BY_ROOM("Room Progress", "Zone-by-zone trade completion tracking"),
    MEASURE_CALIPER("3D Measure Tool", "Interactive dimensional calipers & area analysis"),
    ESTATE_MASTERPLAN("Estate Masterplan", "Multi-plot development throughput line"),
    WHOLE_LIFE_MAINTENANCE("Whole-Life Lifecycle", "30-year component degradation & maintenance")
}

/**
 * Camera View Angle presets
 */
enum class CameraPreset(val label: String, val azimuth: Float, val elevation: Float, val zoom: Float, val targetOffsetY: Float) {
    ORBIT_ISOMETRIC("Isometric 3D", 45f, 30f, 1.0f, 0f),
    FRONT_ELEVATION("Front View", 0f, 10f, 1.1f, 0f),
    SIDE_ELEVATION("Side View", 90f, 10f, 1.1f, 0f),
    TOP_DOWN("Top-Down Site", 0f, 85f, 0.85f, 0f),
    FOUNDATION_LOW("Underground", 35f, -15f, 1.25f, -2f),
    ROOF_AERIAL("Aerial Roof", 135f, 55f, 0.95f, 2f),
    INTERIOR_KITCHEN("Kitchen View", 60f, 15f, 1.8f, 1f),
    INTERIOR_LIVING("Living Room", 300f, 15f, 1.8f, 1f),
    CONSTRUCTION_ACTIVE("Tracking Action", 25f, 20f, 1.3f, 0f)
}

/**
 * Parametric House Architectural Configuration
 */
enum class RoofStyle(val displayName: String) {
    DUAL_PITCH_GABLE("Dual Pitch Gable (35°)"),
    HIP_ROOF("Four-Sided Hip Roof"),
    MONO_PITCH_MODERN("Mono-Pitch Studio"),
    MANSARD_ATTIC("Mansard Attic Roof")
}

enum class FacadeFinish(val displayName: String, val baseColorHex: Long, val accentColorHex: Long) {
    TRADITIONAL_RED_BRICK("Handmade Red Brick & Stone Lintels", 0xFFB34A38, 0xFFE0E0E0),
    BUFF_HERITAGE_BRICK("London Buff Stock Brick", 0xFFCCA473, 0xFFFAFAFA),
    COTSWOLD_NATURAL_STONE("Cotswold Dry Stone Course", 0xFFC9B896, 0xFF8D6E63),
    SCOTTISH_LARCH_TIMBER("Vertical Siberian Larch Cladding", 0xFF9E7B5A, 0xFF212121),
    CONTEMPORARY_WHITE_RENDER("Silicone White Monocouche Render", 0xFFECEFF1, 0xFF37474F),
    ANTHRACITE_ZINC_PANELS("Anthracite Standing Seam Zinc", 0xFF2C3437, 0xFFD84315)
}

enum class RoofFinish(val displayName: String, val colorHex: Long) {
    NATURAL_WELSH_SLATE("Natural Welsh Slate (Blue-Grey)", 0xFF37474F),
    TERRACOTTA_CLAY_TILES("Rosemary Terracotta Clay Tiles", 0xFFBF360C),
    DARK_CONCRETE_TILES("Charcoal Interlocking Concrete Tiles", 0xFF263238),
    ZINC_SEAM_SHEET("Standing Seam Quartz-Zinc Sheet", 0xFF546E7A),
    BIODIVERSE_GREEN_ROOF("Living Sedum Green Roof", 0xFF2E7D32)
}

data class ParametricHouseConfig(
    val plotNumber: Int = 1,
    val widthMeters: Float = 9.4f,
    val lengthMeters: Float = 11.2f,
    val floorCount: Int = 2,
    val roofStyle: RoofStyle = RoofStyle.DUAL_PITCH_GABLE,
    val facadeFinish: FacadeFinish = FacadeFinish.TRADITIONAL_RED_BRICK,
    val roofFinish: RoofFinish = RoofFinish.NATURAL_WELSH_SLATE,
    val bedroomCount: Int = 4,
    val bathroomCount: Int = 3,
    val hasIntegralGarage: Boolean = true,
    val hasRearGlassExtension: Boolean = true,
    val hasSolarPvArray: Boolean = true,
    val hasAirSourceHeatPump: Boolean = true,
    val hasEvChargingPoint: Boolean = true
) {
    val totalFloorAreaM2: Float get() = (widthMeters * lengthMeters * floorCount) + if (hasRearGlassExtension) 22f else 0f
    val estimatedTotalCost: Double get() = (totalFloorAreaM2 * 1850.0) + (if (hasSolarPvArray) 8500.0 else 0.0) + (if (hasAirSourceHeatPump) 11200.0 else 0.0)
}

/**
 * Environmental Simulation Parameters
 */
enum class WeatherType(val label: String, val icon: String, val delayFactor: Float) {
    SUNNY_CLEAR("Sunny & Dry", "WbSunny", 1.0f),
    OVERCAST("Overcast", "Cloud", 1.0f),
    HEAVY_RAIN("Heavy Rain (Wet Ground)", "WaterDrop", 1.35f),
    WINDY_GALE("High Winds (Crane Halted)", "Air", 1.4f),
    WINTER_SNOW("Snow & Freezing", "AcUnit", 1.5f)
}

enum class SeasonType(val label: String, val grassColorHex: Long, val foliageColorHex: Long) {
    SPRING("Spring Bloom", 0xFF558B2F, 0xFF7CB342),
    SUMMER("High Summer", 0xFF689F38, 0xFF33691E),
    AUTUMN("Golden Autumn", 0xFF8D6E63, 0xFFE65100),
    WINTER("Crisp Winter", 0xFF90A4AE, 0xFF546E7A)
}

data class SiteEnvironmentState(
    val timeOfDayHours: Float = 14.0f, // 0..24
    val weather: WeatherType = WeatherType.SUNNY_CLEAR,
    val season: SeasonType = SeasonType.SUMMER,
    val ambientTemperatureC: Float = 19.5f,
    val windSpeedKnots: Float = 8.0f
)
