package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.BuildingStage
import com.example.ui.theme.*

@Composable
fun TimelineScrubber(
    currentDay: Float,
    isPlaying: Boolean,
    playbackSpeed: Float,
    isReverseMode: Boolean,
    isCinematicMode: Boolean,
    onSeek: (Float) -> Unit,
    onTogglePlay: () -> Unit,
    onStepBack: () -> Unit,
    onStepForward: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onToggleReverse: () -> Unit,
    onToggleCinematic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeStage = BuildingStage.forDay(currentDay.toInt())

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark.copy(alpha = 0.95f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Stage Status & Day Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = BrandPrimary,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "STAGE ${activeStage.stageNumber}/18",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                    Text(
                        text = activeStage.title.uppercase(),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "DAY ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Text(
                        text = String.format("%03d", currentDay.toInt()),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = BrandPrimary
                    )
                    Text(
                        text = " / 240",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Interactive Day Slider
            Slider(
                value = currentDay,
                onValueChange = { onSeek(it) },
                valueRange = 1.0f..240.0f,
                colors = SliderDefaults.colors(
                    thumbColor = if (isReverseMode) AccentWarning else BrandPrimary,
                    activeTrackColor = if (isReverseMode) AccentWarning else BrandPrimary,
                    inactiveTrackColor = SlateCard
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Stage Milestone Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val milestones = listOf(
                    1 to "Site",
                    16 to "Foundations",
                    41 to "Slab",
                    56 to "Walls",
                    96 to "Roof",
                    121 to "Windows",
                    136 to "Electrical",
                    151 to "Plumbing",
                    201 to "Kitchen",
                    234 to "Landscaping",
                    240 to "Complete"
                )
                milestones.forEach { (day, label) ->
                    val isPastOrCurrent = (currentDay >= day)
                    Surface(
                        onClick = { onSeek(day.toFloat()) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isPastOrCurrent) SlateCard else SlateDarkest,
                        border = androidx.compose.foundation.BorderStroke(
                            0.5.dp,
                            if (isPastOrCurrent) BrandPrimary.copy(alpha = 0.5f) else SlateBorder
                        )
                    ) {
                        Text(
                            text = "D$day $label",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            fontSize = 10.sp,
                            fontWeight = if (isPastOrCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isPastOrCurrent) TextPrimary else TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Playback Control Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Speed Multiplier Selector
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val speeds = listOf(0.5f, 1f, 5f, 25f, 100f)
                    speeds.forEach { spd ->
                        val isSel = (playbackSpeed == spd)
                        Surface(
                            onClick = { onSetSpeed(spd) },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSel) BrandTertiary else SlateCard
                        ) {
                            Text(
                                text = if (spd < 1f) "0.5×" else "${spd.toInt()}×",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.Black else TextSecondary
                            )
                        }
                    }
                }

                // Center: Primary VCR Transport Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onStepBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "Step -1 Day", tint = TextPrimary)
                    }

                    FloatingActionButton(
                        onClick = onTogglePlay,
                        modifier = Modifier.size(44.dp),
                        containerColor = if (isReverseMode) AccentWarning else BrandPrimary,
                        shape = CircleShape
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.Black
                        )
                    }

                    IconButton(
                        onClick = onStepForward,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Step +1 Day", tint = TextPrimary)
                    }
                }

                // Right: Special Simulation Modes (Deconstruct & Cinematic Film)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = onToggleReverse,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isReverseMode) AccentWarning else SlateCard,
                            contentColor = if (isReverseMode) Color.Black else TextSecondary
                        )
                    ) {
                        Icon(Icons.Default.FastRewind, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Deconstruct", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = onToggleCinematic,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isCinematicMode) BrandSecondary else SlateCard,
                            contentColor = if (isCinematicMode) Color.Black else TextSecondary
                        )
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Build Film", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
