package com.example.housebuilder.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.engine.renderer.SceneRenderer3D
import com.example.housebuilder.engine.scene.HouseMeshBuilder
import com.example.housebuilder.model.BuildingStage
import com.example.housebuilder.model.CameraPreset
import com.example.housebuilder.model.ConstructionViewMode
import com.example.housebuilder.simulation.SimulationEngine
import com.example.ui.theme.*

enum class ActiveSheet {
    NONE,
    PARAMETRIC_CONFIG,
    ESTATE_MASTERPLAN,
    ANALYTICS,
    INVENTORY,
    CINEMATIC_DIRECTOR,
    WHOLE_LIFE,
    ROOM_PROGRESS
}

@Composable
fun MainConstructionScreen(
    engine: SimulationEngine = remember { SimulationEngine() }
) {
    var activeSheet by remember { mutableStateOf(ActiveSheet.NONE) }
    var lastProjectedPolys by remember { mutableStateOf<List<SceneRenderer3D.ProjectedPoly>>(emptyList()) }

    val currentDay = engine.currentDay
    val activeStage = BuildingStage.forDay(currentDay.toInt())

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SlateDarkest
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // -------------------------------------------------------------
            // 1. 3D INTERACTIVE VIEWPORT CANVAS
            // -------------------------------------------------------------
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    // Tap gesture for BIM Digital Twin hit testing
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val tappedBimId = SceneRenderer3D.findBimComponentAtScreenPoint(
                                offset,
                                lastProjectedPolys
                            )
                            if (tappedBimId != null) {
                                engine.selectBimById(tappedBimId)
                            }
                        }
                    }
                    // Transform gesture for 1-finger orbit & 2-finger zoom
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            engine.orbitCamera(
                                deltaAzimuth = pan.x * 0.45f,
                                deltaElevation = -pan.y * 0.45f
                            )
                            if (zoom != 1.0f) {
                                engine.zoomCamera(zoom)
                            }
                        }
                    }
            ) {
                // Generate 3D procedural polygons for current state
                val polygons = HouseMeshBuilder.buildScenePolygons(
                    currentDay = currentDay.toInt(),
                    config = engine.houseConfig,
                    viewMode = engine.viewMode,
                    explodedOffset = engine.explodedOffset,
                    selectedBimId = engine.selectedBimComponent?.id,
                    selectedRoom = engine.selectedRoom,
                    envState = engine.environmentState,
                    simulationTick = engine.simulationTick,
                    activeMachinery = engine.allMachinery,
                    activeWorkers = engine.allWorkers
                )

                // Render with directional sunlight and depth sorting
                SceneRenderer3D.renderScene(
                    drawScope = this,
                    polygons = polygons,
                    camera = engine.camera,
                    envState = engine.environmentState,
                    viewMode = engine.viewMode,
                    config = engine.houseConfig,
                    simTick = engine.simulationTick,
                    onProjectedPolysReady = { projected ->
                        lastProjectedPolys = projected
                    }
                )
            }

            // -------------------------------------------------------------
            // 2. TOP HUD HEADER & TOOLBAR
            // -------------------------------------------------------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
            ) {
                // Primary App Bar
                Surface(
                    color = SlateDark.copy(alpha = 0.90f),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, SlateBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Brand Title
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = BrandPrimary,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Architecture,
                                        contentDescription = "Housebuilder OS",
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "HOUSEBUILDER OS",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.1.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "4D Digital Construction Simulation",
                                    fontSize = 10.sp,
                                    color = BrandSecondary
                                )
                            }
                        }

                        // Top Action Icons
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = { activeSheet = ActiveSheet.PARAMETRIC_CONFIG },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = "House Generator", tint = BrandPrimary)
                            }
                            IconButton(
                                onClick = { activeSheet = ActiveSheet.ANALYTICS },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Analytics, contentDescription = "Cost Analytics", tint = BrandTertiary)
                            }
                            IconButton(
                                onClick = { activeSheet = ActiveSheet.INVENTORY },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Inventory, contentDescription = "Materials", tint = TextPrimary)
                            }
                            IconButton(
                                onClick = { activeSheet = ActiveSheet.ESTATE_MASTERPLAN },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.LocationCity, contentDescription = "Estate Masterplan", tint = BrandSecondary)
                            }
                        }
                    }
                }

                // View Modes Carousel Bar
                ViewModeSelectorBar(
                    currentMode = engine.viewMode,
                    onSelectMode = { mode ->
                        engine.viewMode = mode
                        when (mode) {
                            ConstructionViewMode.EXPLODED_LAYERS -> engine.explodedOffset = 2.0f
                            ConstructionViewMode.ROOM_BY_ROOM -> activeSheet = ActiveSheet.ROOM_PROGRESS
                            ConstructionViewMode.WHOLE_LIFE_MAINTENANCE -> activeSheet = ActiveSheet.WHOLE_LIFE
                            ConstructionViewMode.ESTATE_MASTERPLAN -> activeSheet = ActiveSheet.ESTATE_MASTERPLAN
                            else -> engine.explodedOffset = 0f
                        }
                    }
                )

                // Quick Camera Presets Ribbon
                CameraPresetsBar(onSelectPreset = { engine.applyCameraPreset(it) })
            }

            // -------------------------------------------------------------
            // 3. LIVE CONSTRUCTION HUD METRICS RIBBON (Left overlay)
            // -------------------------------------------------------------
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val overallPct = (engine.getOverallProgressFraction() * 100).toInt()
                val spent = engine.getSpentToDate()
                val workers = engine.getActiveWorkerCount()
                val machinery = engine.getActiveMachineryCount()

                HudMetricBadge("COMPLETION", "$overallPct%", AccentSuccess)
                HudMetricBadge("SPENT TO DATE", "£${String.format("%,.0f", spent)}", BrandPrimary)
                HudMetricBadge("ON-SITE LABOUR", "$workers Trades", BrandSecondary)
                HudMetricBadge("ACTIVE PLANT", "$machinery Units", BrandTertiary)
            }

            // -------------------------------------------------------------
            // 4. EXPLODED LAYER ELEVATION SLIDER (When Exploded Mode Active)
            // -------------------------------------------------------------
            if (engine.viewMode == ConstructionViewMode.EXPLODED_LAYERS) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 12.dp)
                        .width(180.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = SlateDark.copy(alpha = 0.90f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrandSecondary)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "EXPLOSION SPREAD",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandSecondary
                        )
                        Text(
                            "${String.format("%.1f", engine.explodedOffset)}m Strata",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Slider(
                            value = engine.explodedOffset,
                            onValueChange = { engine.explodedOffset = it },
                            valueRange = 0f..4.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = BrandSecondary,
                                activeTrackColor = BrandSecondary
                            )
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // 5. BOTTOM TIMELINE SCRUBBER
            // -------------------------------------------------------------
            TimelineScrubber(
                currentDay = engine.currentDay,
                isPlaying = engine.isPlaying,
                playbackSpeed = engine.playbackSpeed,
                isReverseMode = engine.isReverseMode,
                isCinematicMode = engine.isCinematicMode,
                onSeek = { engine.seekToDay(it) },
                onTogglePlay = { engine.togglePlayPause() },
                onStepBack = { engine.stepBackward(1f) },
                onStepForward = { engine.stepForward(1f) },
                onSetSpeed = { engine.setSpeed(it) },
                onToggleReverse = { engine.toggleReverseMode() },
                onToggleCinematic = {
                    if (engine.isCinematicMode) {
                        engine.setCinematicModeEnabled(false)
                    } else {
                        activeSheet = ActiveSheet.CINEMATIC_DIRECTOR
                    }
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )

            // -------------------------------------------------------------
            // 6. BIM DIGITAL TWIN INSPECTOR DIALOG
            // -------------------------------------------------------------
            engine.selectedBimComponent?.let { comp ->
                BimInspectorDialog(
                    component = comp,
                    currentDay = currentDay.toInt(),
                    onDismiss = { engine.selectBimById(null) }
                )
            }

            // -------------------------------------------------------------
            // 7. MODAL SHEETS
            // -------------------------------------------------------------
            when (activeSheet) {
                ActiveSheet.PARAMETRIC_CONFIG -> {
                    ParametricConfigSheet(
                        config = engine.houseConfig,
                        onConfigChange = { engine.houseConfig = it },
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.ESTATE_MASTERPLAN -> {
                    EstateMasterplanSheet(
                        plotCount = engine.developmentPlotCount,
                        currentDay = currentDay,
                        onSelectPlotCount = { engine.developmentPlotCount = it },
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.ANALYTICS -> {
                    AnalyticsSheet(
                        engine = engine,
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.INVENTORY -> {
                    MaterialInventorySheet(
                        materials = engine.allMaterials,
                        currentDay = currentDay.toInt(),
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.CINEMATIC_DIRECTOR -> {
                    CinematicDirectorSheet(
                        isCinematic = engine.isCinematicMode,
                        currentDurationSec = engine.cinematicDurationSec,
                        onSetDuration = { engine.cinematicDurationSec = it },
                        onStartCinematic = { duration ->
                            engine.cinematicDurationSec = duration
                            engine.setCinematicModeEnabled(true)
                        },
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.WHOLE_LIFE -> {
                    WholeLifeSheet(
                        components = engine.allComponents,
                        currentYear = engine.maintenanceYear,
                        onYearChange = { engine.maintenanceYear = it },
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.ROOM_PROGRESS -> {
                    RoomProgressSheet(
                        engine = engine,
                        selectedRoom = engine.selectedRoom,
                        onSelectRoom = { engine.selectRoom(it) },
                        onDismiss = { activeSheet = ActiveSheet.NONE }
                    )
                }
                ActiveSheet.NONE -> Unit
            }
        }
    }
}

@Composable
private fun HudMetricBadge(label: String, value: String, accentColor: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = SlateDark.copy(alpha = 0.85f),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            Text(
                value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = accentColor
            )
        }
    }
}
