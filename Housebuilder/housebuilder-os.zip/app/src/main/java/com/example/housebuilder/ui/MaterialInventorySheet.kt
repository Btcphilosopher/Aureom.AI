package com.example.housebuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.housebuilder.model.MaterialInventoryItem
import com.example.ui.theme.*

@Composable
fun MaterialInventorySheet(
    materials: List<MaterialInventoryItem>,
    currentDay: Int,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        color = SlateDark
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JUST-IN-TIME MATERIAL INVENTORY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandPrimary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Site Deliveries & Consumption",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Material List Cards
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                materials.forEach { mat ->
                    val delivered = mat.getDeliveredQuantity(currentDay)
                    val installed = mat.getInstalledQuantity(currentDay)
                    val remainingOnSite = mat.getRemainingOnSite(currentDay)
                    val total = mat.totalRequired

                    val deliverPct = (delivered / total).toFloat().coerceIn(0f, 1f)
                    val installPct = (installed / total).toFloat().coerceIn(0f, 1f)

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SlateCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(mat.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(
                                    "${String.format("%.1f", installed)} / ${String.format("%.1f", total)} ${mat.unit}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = BrandSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Dual progress bar: Delivered (Blue) & Installed (Orange)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SlateDarkest)
                            ) {
                                // Delivered bar
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(deliverPct)
                                        .background(Color(0xFF388E3C))
                                )
                                // Installed bar
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(installPct)
                                        .background(BrandPrimary)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "Staged On Site: ${String.format("%.1f", remainingOnSite)} ${mat.unit}",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    "Delivery: D${mat.startDeliveryDay} - D${mat.endConsumptionDay}",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
            ) {
                Text("Close Inventory Log", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
