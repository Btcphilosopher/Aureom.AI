package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.model.ConstructionStage
import com.example.engine.model.Trade
import com.example.engine.renderer.ViewRenderStyle
import com.example.ui.BuildMotionViewModel

import com.example.ui.theme.*

@Composable
fun ControlsAndFiltersBar(
    viewModel: BuildMotionViewModel,
    modifier: Modifier = Modifier
) {
    val sceneGraph = viewModel.sceneGraph
    val renderer = viewModel.renderer

    var explodeFactor by remember { mutableStateOf(0f) }
    var sectionEnabled by remember { mutableStateOf(false) }
    var sectionY by remember { mutableStateOf(3.0f) }
    var sunAngle by remember { mutableStateOf(45f) }
    var selectedStyle by remember { mutableStateOf(ViewRenderStyle.PBR_SHADED) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("controls_bar_card"),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Row 1: Render Style Chips & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Render Styles
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ViewRenderStyle.values().forEach { style ->
                        FilterChip(
                            selected = (selectedStyle == style),
                            onClick = {
                                selectedStyle = style
                                viewModel.setRenderStyle(style)
                            },
                            label = { Text(style.name.replace("_", " "), fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LavenderPrimary,
                                selectedLabelColor = LavenderDarkText,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimaryDark
                            ),
                            modifier = Modifier.testTag("style_${style.name}")
                        )
                    }
                }

                // Diagnostics & Docs Action Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.openBenchmarkModal() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SageGreen),
                        border = BorderStroke(1.dp, SurfaceBorder),
                        modifier = Modifier.testTag("btn_open_benchmark")
                    ) {
                        Icon(imageVector = Icons.Default.Speed, contentDescription = "Benchmark", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Diagnostics", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.openDocsModal() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LavenderPrimary),
                        border = BorderStroke(1.dp, SurfaceBorder),
                        modifier = Modifier.testTag("btn_open_docs")
                    ) {
                        Icon(imageVector = Icons.Default.MenuBook, contentDescription = "Docs", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Architecture & API", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Row 2: Sliders for Explode View, Section Clipping, and Sunlight
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Explode Assembly Slider
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Exploded Assembly", style = MaterialTheme.typography.labelSmall, color = TextPrimaryDark)
                        Text("${(explodeFactor * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = LavenderPrimary)
                    }
                    Slider(
                        value = explodeFactor,
                        onValueChange = {
                            explodeFactor = it
                            viewModel.setExplodeFactor(it)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = LavenderPrimary,
                            activeTrackColor = LavenderPrimary,
                            inactiveTrackColor = SurfaceBorder
                        ),
                        modifier = Modifier.testTag("slider_explode")
                    )
                }

                // Section Plane Clipping Switch & Y Height Slider
                Column(modifier = Modifier.weight(1.2f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Section View Plane", style = MaterialTheme.typography.labelSmall, color = TextPrimaryDark)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = sectionEnabled,
                                onCheckedChange = {
                                    sectionEnabled = it
                                    viewModel.setSectionPlaneEnabled(it)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = LavenderPrimary,
                                    checkedTrackColor = LavenderDarkText
                                ),
                                modifier = Modifier
                                    .scale(0.7f)
                                    .testTag("switch_section_plane")
                            )
                        }
                        if (sectionEnabled) {
                            Text("Y: ${String.format("%.1f", sectionY)}m", style = MaterialTheme.typography.labelSmall, color = SageGreen)
                        }
                    }
                    if (sectionEnabled) {
                        Slider(
                            value = sectionY,
                            onValueChange = {
                                sectionY = it
                                viewModel.setSectionPlaneY(it)
                            },
                            valueRange = 0.2f..6.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = SageGreen,
                                activeTrackColor = SageGreen,
                                inactiveTrackColor = SurfaceBorder
                            ),
                            modifier = Modifier.testTag("slider_section_y")
                        )
                    }
                }

                // Sun Daylight Slider
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sunlight Angle", style = MaterialTheme.typography.labelSmall, color = TextPrimaryDark)
                        Text("${sunAngle.toInt()}°", style = MaterialTheme.typography.labelSmall, color = SageGreen)
                    }
                    Slider(
                        value = sunAngle,
                        onValueChange = {
                            sunAngle = it
                            viewModel.setSunAngle(it)
                        },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(
                            thumbColor = SageGreen,
                            activeTrackColor = SageGreen,
                            inactiveTrackColor = SurfaceBorder
                        ),
                        modifier = Modifier.testTag("slider_sun_angle")
                    )
                }
            }

            // Row 3: Trade Filter Chips
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Trade Filter:", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                Spacer(modifier = Modifier.width(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    item {
                        FilterChip(
                            selected = (sceneGraph.activeTradeFilter == null),
                            onClick = { viewModel.setTradeFilter(null) },
                            label = { Text("All Trades", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LavenderPrimary,
                                selectedLabelColor = LavenderDarkText,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimaryDark
                            )
                        )
                    }
                    items(Trade.values()) { trade ->
                        FilterChip(
                            selected = (sceneGraph.activeTradeFilter == trade),
                            onClick = { viewModel.setTradeFilter(if (sceneGraph.activeTradeFilter == trade) null else trade) },
                            label = { Text(trade.displayName, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = trade.badgeColor,
                                selectedLabelColor = Color.White,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimaryDark
                            )
                        )
                    }
                }
            }
        }
    }
}

private fun Modifier.scale(scale: Float): Modifier = this
