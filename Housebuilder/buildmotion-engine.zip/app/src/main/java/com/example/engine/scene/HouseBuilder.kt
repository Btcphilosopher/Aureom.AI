package com.example.engine.scene

import com.example.engine.model.*
import java.util.UUID

object HouseBuilder {

    fun buildDigitalTwinHouse(sceneGraph: SceneGraph): Int {
        sceneGraph.clear()

        var currentStepIndex = 1

        // Root Plot Node
        val rootNode = SceneNode(
            id = "root_plot",
            name = "Site Plot #102 - Cedar Croft",
            transform = Transform3D(position = Vector3.ZERO),
            material = Material.SOIL,
            stage = ConstructionStage.SITE_CLEARANCE,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.GROUNDWORKS,
                stage = ConstructionStage.SITE_CLEARANCE,
                code = "SITE-PLOT-102",
                description = "Residential Development Plot 102 - 12m x 10m Ground Site",
                costGBP = 85000f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, -0.2f, 0f), Vector3(14f, 0.4f, 12f))
        )
        sceneGraph.addNode(rootNode)
        currentStepIndex += 2

        // PHASE 1: SITE CLEARANCE
        val grassPlot = SceneNode(
            id = "grass_turf_site",
            name = "Site Topsoil & Clearing",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(0f, 0.01f, 0f)),
            material = Material.GRASS,
            stage = ConstructionStage.SITE_CLEARANCE,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.LANDSCAPING,
                stage = ConstructionStage.SITE_CLEARANCE,
                code = "GRND-CLR-01",
                description = "Stripped topsoil & site leveling",
                costGBP = 1200f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 0.01f, 0f), Vector3(13f, 0.05f, 11f))
        )
        sceneGraph.addNode(grassPlot)
        currentStepIndex += 3

        // PHASE 2: EXCAVATION
        val trenchNorth = SceneNode(
            id = "trench_foundation_north",
            name = "Foundation Trench North",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(0f, -0.4f, -4f)),
            material = Material.SOIL,
            stage = ConstructionStage.EXCAVATION,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.GROUNDWORKS,
                stage = ConstructionStage.EXCAVATION,
                code = "EXC-TR-01",
                description = "600mm x 1000mm Strip Footing Excavation North",
                costGBP = 2400f
            ),
            meshShape = MeshShape.BEAM,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, -0.4f, -4f), Vector3(8.8f, 0.6f, 0.8f))
        )
        sceneGraph.addNode(trenchNorth)
        currentStepIndex += 2

        // PHASE 3: CONCRETE FOUNDATIONS
        val footingConcrete = SceneNode(
            id = "foundations_strip_concrete",
            name = "C35 Concrete Footing Slab",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(0f, 0.1f, 0f)),
            material = Material.CONCRETE,
            stage = ConstructionStage.FOUNDATIONS,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.GROUNDWORKS,
                stage = ConstructionStage.FOUNDATIONS,
                code = "FND-C35-01",
                description = "Mass poured C35 foundation footings",
                costGBP = 6500f,
                weightKg = 14500f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 0.1f, 0f), Vector3(8.4f, 0.4f, 6.4f))
        )
        sceneGraph.addNode(footingConcrete)
        currentStepIndex += 4

        // PHASE 4: UNDERGROUND DRAINAGE
        val drainPipeMain = SceneNode(
            id = "drainage_main_pipe",
            name = "110mm Underground Drainage Pipe",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(2f, 0.25f, 1f)),
            material = Material.COPPER_PIPE,
            stage = ConstructionStage.DRAINAGE,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.MEP,
                stage = ConstructionStage.DRAINAGE,
                code = "DRN-PVC-110",
                description = "Main sewer connection & inspection chamber",
                costGBP = 1800f
            ),
            meshShape = MeshShape.PIPE,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(2f, 0.25f, 1f), Vector3(0.15f, 0.15f, 5f))
        )
        sceneGraph.addNode(drainPipeMain)
        currentStepIndex += 3

        // PHASE 5: FLOOR SLAB & DPM
        val floorSlab = SceneNode(
            id = "ground_floor_slab",
            name = "Over-Site Concrete Slab & DPM",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(0f, 0.4f, 0f)),
            material = Material.CONCRETE,
            stage = ConstructionStage.FLOOR_SLAB,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.GROUNDWORKS,
                stage = ConstructionStage.FLOOR_SLAB,
                code = "SLAB-150-DPM",
                description = "150mm Reinforced Ground Floor Slab with Damp Proof Membrane",
                costGBP = 5200f,
                weightKg = 9800f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 0.4f, 0f), Vector3(8f, 0.3f, 6f))
        )
        sceneGraph.addNode(floorSlab)
        currentStepIndex += 4

        // PHASE 6: BRICKWORK & MASONRY (Ground Floor Outer Leaf - Course by Course)
        val brickWidth = 0.215f
        val brickHeight = 0.065f
        val brickDepth = 0.102f
        val wallLengthX = 8.0f
        val wallLengthZ = 6.0f
        val groundFloorHeight = 2.4f
        val coursesCount = 18

        var brickCountTotal = 0

        for (course in 0 until coursesCount) {
            val yPos = 0.55f + course * (brickHeight + 0.01f)
            val isHeaderCourse = (course % 2 == 1)
            val courseStep = currentStepIndex + course * 2

            // Front Wall (Z = 3.0)
            val bricksInRowX = (wallLengthX / (brickWidth + 0.01f)).toInt()
            for (i in 0 until bricksInRowX) {
                // Skip door opening in front wall
                val xPos = -wallLengthX / 2f + i * (brickWidth + 0.01f) + (if (isHeaderCourse) 0.1f else 0f)
                val isDoorZone = (xPos in -0.6f..0.6f) && (yPos < 2.2f)
                val isWindowZone = (xPos in 1.5f..3.2f) && (yPos in 1.2f..2.2f)

                if (!isDoorZone && !isWindowZone) {
                    val brickNode = SceneNode(
                        id = "brick_f_${course}_$i",
                        name = "Facing Brick C${course + 1}-$i",
                        parentId = "ground_floor_slab",
                        transform = Transform3D(position = Vector3(xPos, yPos, 3.0f)),
                        material = Material.BRICK_RED,
                        stage = ConstructionStage.BRICKWORK,
                        installationStep = courseStep,
                        metadata = NodeMetadata(
                            trade = Trade.MASONRY,
                            stage = ConstructionStage.BRICKWORK,
                            code = "BRK-FAC-01",
                            description = "Clay Facing Brick 215x102x65mm Class B",
                            costGBP = 1.2f,
                            weightKg = 2.3f
                        ),
                        meshShape = MeshShape.BRICK,
                        bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, yPos, 3.0f), Vector3(brickWidth, brickHeight, brickDepth)),
                        isInstanced = true
                    )
                    sceneGraph.addNode(brickNode)
                    brickCountTotal++
                }
            }

            // Back Wall (Z = -3.0)
            for (i in 0 until bricksInRowX) {
                val xPos = -wallLengthX / 2f + i * (brickWidth + 0.01f) + (if (isHeaderCourse) 0.1f else 0f)
                val isRearWindow = (xPos in -2.5f..-0.8f) && (yPos in 1.2f..2.2f)
                if (!isRearWindow) {
                    val brickNode = SceneNode(
                        id = "brick_b_${course}_$i",
                        name = "Facing Brick Rear C${course + 1}-$i",
                        parentId = "ground_floor_slab",
                        transform = Transform3D(position = Vector3(xPos, yPos, -3.0f)),
                        material = Material.BRICK_RED,
                        stage = ConstructionStage.BRICKWORK,
                        installationStep = courseStep,
                        metadata = NodeMetadata(
                            trade = Trade.MASONRY,
                            stage = ConstructionStage.BRICKWORK,
                            code = "BRK-FAC-01",
                            description = "Clay Facing Brick Rear Wall",
                            costGBP = 1.2f,
                            weightKg = 2.3f
                        ),
                        meshShape = MeshShape.BRICK,
                        bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, yPos, -3.0f), Vector3(brickWidth, brickHeight, brickDepth)),
                        isInstanced = true
                    )
                    sceneGraph.addNode(brickNode)
                    brickCountTotal++
                }
            }

            // Left Wall (X = -4.0)
            val bricksInRowZ = (wallLengthZ / (brickWidth + 0.01f)).toInt()
            for (j in 0 until bricksInRowZ) {
                val zPos = -wallLengthZ / 2f + j * (brickWidth + 0.01f)
                val brickNode = SceneNode(
                    id = "brick_l_${course}_$j",
                    name = "Facing Brick Left C${course + 1}-$j",
                    parentId = "ground_floor_slab",
                    transform = Transform3D(position = Vector3(-4.0f, yPos, zPos)),
                    material = Material.BRICK_RED,
                    stage = ConstructionStage.BRICKWORK,
                    installationStep = courseStep,
                    metadata = NodeMetadata(
                        trade = Trade.MASONRY,
                        stage = ConstructionStage.BRICKWORK,
                        code = "BRK-FAC-01",
                        description = "Gable Side Wall Brick",
                        costGBP = 1.2f,
                        weightKg = 2.3f
                    ),
                    meshShape = MeshShape.BRICK,
                    bounds = BoundingBox3D.createFromCenterAndSize(Vector3(-4.0f, yPos, zPos), Vector3(brickDepth, brickHeight, brickWidth)),
                    isInstanced = true
                )
                sceneGraph.addNode(brickNode)
                brickCountTotal++
            }

            // Right Wall (X = 4.0)
            for (j in 0 until bricksInRowZ) {
                val zPos = -wallLengthZ / 2f + j * (brickWidth + 0.01f)
                val brickNode = SceneNode(
                    id = "brick_r_${course}_$j",
                    name = "Facing Brick Right C${course + 1}-$j",
                    parentId = "ground_floor_slab",
                    transform = Transform3D(position = Vector3(4.0f, yPos, zPos)),
                    material = Material.BRICK_RED,
                    stage = ConstructionStage.BRICKWORK,
                    installationStep = courseStep,
                    metadata = NodeMetadata(
                        trade = Trade.MASONRY,
                        stage = ConstructionStage.BRICKWORK,
                        code = "BRK-FAC-01",
                        description = "Gable Side Wall Brick Right",
                        costGBP = 1.2f,
                        weightKg = 2.3f
                    ),
                    meshShape = MeshShape.BRICK,
                    bounds = BoundingBox3D.createFromCenterAndSize(Vector3(4.0f, yPos, zPos), Vector3(brickDepth, brickHeight, brickWidth)),
                    isInstanced = true
                )
                sceneGraph.addNode(brickNode)
                brickCountTotal++
            }
        }
        currentStepIndex += coursesCount * 2 + 5

        // PHASE 7: STRUCTURAL FRAME (Steel Beams & Lintels)
        val lintelFrontDoor = SceneNode(
            id = "lintel_front_door",
            name = "Steel Catnic Lintel Front Door",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 2.25f, 3.0f)),
            material = Material.STEEL,
            stage = ConstructionStage.STRUCTURAL_FRAME,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.STEELWORK,
                stage = ConstructionStage.STRUCTURAL_FRAME,
                code = "LNT-CAT-1500",
                description = "Galvanized Steel Heavy Duty Cavity Lintel 1500mm",
                costGBP = 185f,
                weightKg = 28f
            ),
            meshShape = MeshShape.BEAM,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 2.25f, 3.0f), Vector3(1.5f, 0.15f, 0.25f))
        )
        sceneGraph.addNode(lintelFrontDoor)

        val mainRsjBeam = SceneNode(
            id = "steel_rsj_main_beam",
            name = "203x133x25 Steel Universal Beam RSJ",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 2.45f, 0f)),
            material = Material.STEEL,
            stage = ConstructionStage.STRUCTURAL_FRAME,
            installationStep = currentStepIndex + 2,
            metadata = NodeMetadata(
                trade = Trade.STEELWORK,
                stage = ConstructionStage.STRUCTURAL_FRAME,
                code = "STL-UB-203",
                description = "Structural Steel Beam spanning ground floor lounge",
                costGBP = 640f,
                weightKg = 185f
            ),
            meshShape = MeshShape.BEAM,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 2.45f, 0f), Vector3(7.8f, 0.2f, 0.15f))
        )
        sceneGraph.addNode(mainRsjBeam)
        currentStepIndex += 5

        // PHASE 8: FLOORS (First Floor Timber Joists & Decking)
        val joistSpacing = 0.45f
        val joistsCount = (wallLengthX / joistSpacing).toInt()
        for (i in 0..joistsCount) {
            val xPos = -wallLengthX / 2f + i * joistSpacing
            val joistNode = SceneNode(
                id = "floor_joist_$i",
                name = "C24 Timber Joist #$i",
                parentId = "ground_floor_slab",
                transform = Transform3D(position = Vector3(xPos, 2.55f, 0f)),
                material = Material.TIMBER,
                stage = ConstructionStage.FLOORS,
                installationStep = currentStepIndex + i,
                metadata = NodeMetadata(
                    trade = Trade.CARPENTRY,
                    stage = ConstructionStage.FLOORS,
                    code = "JST-C24-225",
                    description = "225mm x 47mm C24 Structural Timber Floor Joist",
                    costGBP = 28f,
                    weightKg = 16f
                ),
                meshShape = MeshShape.BEAM,
                bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, 2.55f, 0f), Vector3(0.05f, 0.22f, 5.8f))
            )
            sceneGraph.addNode(joistNode)
        }

        val floorDecking = SceneNode(
            id = "first_floor_decking",
            name = "22mm P5 Structural Floor Decking",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 2.68f, 0f)),
            material = Material.TIMBER,
            stage = ConstructionStage.FLOORS,
            installationStep = currentStepIndex + joistsCount + 2,
            metadata = NodeMetadata(
                trade = Trade.CARPENTRY,
                stage = ConstructionStage.FLOORS,
                code = "DEC-P5-22",
                description = "Tongue & Groove Moisture Resistant Chipboard Flooring",
                costGBP = 420f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 2.68f, 0f), Vector3(7.8f, 0.022f, 5.8f))
        )
        sceneGraph.addNode(floorDecking)
        currentStepIndex += joistsCount + 6

        // FIRST FLOOR BRICKWORK (Upper Story Wall)
        val upperCourses = 14
        for (course in 0 until upperCourses) {
            val yPos = 2.75f + course * (brickHeight + 0.01f)
            val courseStep = currentStepIndex + course * 2

            // Front Upper Wall
            val bricksInRowX = (wallLengthX / (brickWidth + 0.01f)).toInt()
            for (i in 0 until bricksInRowX) {
                val xPos = -wallLengthX / 2f + i * (brickWidth + 0.01f)
                val isUpperWindow1 = (xPos in -2.8f..-1.2f) && (yPos in 3.2f..4.2f)
                val isUpperWindow2 = (xPos in 1.2f..2.8f) && (yPos in 3.2f..4.2f)

                if (!isUpperWindow1 && !isUpperWindow2) {
                    val brickNode = SceneNode(
                        id = "brick_f_upper_${course}_$i",
                        name = "Upper Facing Brick C${course + 1}-$i",
                        parentId = "first_floor_decking",
                        transform = Transform3D(position = Vector3(xPos, yPos, 3.0f)),
                        material = Material.BRICK_RED,
                        stage = ConstructionStage.BRICKWORK,
                        installationStep = courseStep,
                        metadata = NodeMetadata(
                            trade = Trade.MASONRY,
                            stage = ConstructionStage.BRICKWORK,
                            code = "BRK-FAC-02",
                            description = "First Floor Facing Brick",
                            costGBP = 1.2f,
                            weightKg = 2.3f
                        ),
                        meshShape = MeshShape.BRICK,
                        bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, yPos, 3.0f), Vector3(brickWidth, brickHeight, brickDepth)),
                        isInstanced = true
                    )
                    sceneGraph.addNode(brickNode)
                }
            }
        }
        currentStepIndex += upperCourses * 2 + 4

        // PHASE 9: ROOF (Timber Trusses & Tiling)
        val trussSpacing = 0.8f
        val trussCount = (wallLengthX / trussSpacing).toInt()
        val roofPeakY = 5.2f
        val eavesY = 3.8f

        for (t in 0..trussCount) {
            val xPos = -wallLengthX / 2f + t * trussSpacing
            val trussNode = SceneNode(
                id = "roof_truss_$t",
                name = "Fink Roof Truss #$t",
                parentId = "first_floor_decking",
                transform = Transform3D(position = Vector3(xPos, (eavesY + roofPeakY) / 2f, 0f)),
                material = Material.TIMBER,
                stage = ConstructionStage.ROOF,
                installationStep = currentStepIndex + t,
                metadata = NodeMetadata(
                    trade = Trade.CARPENTRY,
                    stage = ConstructionStage.ROOF,
                    code = "TRS-FINK-35",
                    description = "Prefabricated 35 degree Pitch Timber Roof Truss",
                    costGBP = 85f,
                    weightKg = 32f
                ),
                meshShape = MeshShape.TRUSS,
                bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, (eavesY + roofPeakY) / 2f, 0f), Vector3(0.05f, 1.4f, 6.4f))
            )
            sceneGraph.addNode(trussNode)
        }
        currentStepIndex += trussCount + 3

        // Roof Tiles (Instanced Grid across Pitch)
        val tileRows = 12
        val tileCols = (wallLengthX / 0.33f).toInt()
        for (r in 0 until tileRows) {
            val frac = r / tileRows.toFloat()
            val yPos = eavesY + frac * (roofPeakY - eavesY)
            val zFront = 3.2f - frac * 3.2f
            val zBack = -3.2f + frac * 3.2f

            for (c in 0 until tileCols) {
                val xPos = -wallLengthX / 2f + c * 0.33f

                // Front Slope Tile
                val tileFront = SceneNode(
                    id = "tile_f_${r}_$c",
                    name = "Marley Roof Slate F R$r C$c",
                    parentId = "first_floor_decking",
                    transform = Transform3D(position = Vector3(xPos, yPos + 0.05f, zFront)),
                    material = Material.ROOF_TILE,
                    stage = ConstructionStage.ROOF,
                    installationStep = currentStepIndex + r * 2,
                    metadata = NodeMetadata(
                        trade = Trade.ROOFING,
                        stage = ConstructionStage.ROOF,
                        code = "MRL-SLATE-01",
                        description = "Marley Interlocking Concrete Roof Tile",
                        costGBP = 2.4f,
                        weightKg = 4.2f
                    ),
                    meshShape = MeshShape.TILE,
                    bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, yPos + 0.05f, zFront), Vector3(0.32f, 0.04f, 0.42f)),
                    isInstanced = true
                )
                sceneGraph.addNode(tileFront)

                // Rear Slope Tile
                val tileBack = SceneNode(
                    id = "tile_b_${r}_$c",
                    name = "Marley Roof Slate B R$r C$c",
                    parentId = "first_floor_decking",
                    transform = Transform3D(position = Vector3(xPos, yPos + 0.05f, zBack)),
                    material = Material.ROOF_TILE,
                    stage = ConstructionStage.ROOF,
                    installationStep = currentStepIndex + r * 2 + 1,
                    metadata = NodeMetadata(
                        trade = Trade.ROOFING,
                        stage = ConstructionStage.ROOF,
                        code = "MRL-SLATE-01",
                        description = "Marley Interlocking Concrete Roof Tile Rear",
                        costGBP = 2.4f,
                        weightKg = 4.2f
                    ),
                    meshShape = MeshShape.TILE,
                    bounds = BoundingBox3D.createFromCenterAndSize(Vector3(xPos, yPos + 0.05f, zBack), Vector3(0.32f, 0.04f, 0.42f)),
                    isInstanced = true
                )
                sceneGraph.addNode(tileBack)
            }
        }
        currentStepIndex += tileRows * 2 + 5

        // PHASE 10: WINDOWS & EXTERNAL DOORS
        val frontDoor = SceneNode(
            id = "front_entrance_door",
            name = "Composite Front Entrance Door",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 1.3f, 3.0f)),
            material = Material.PVC_WHITE,
            stage = ConstructionStage.WINDOWS_DOORS,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.CARPENTRY,
                stage = ConstructionStage.WINDOWS_DOORS,
                code = "DOR-CMP-01",
                description = "High Security Composite Door with Anthracite Grey Finish",
                costGBP = 1150f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 1.3f, 3.0f), Vector3(1.1f, 2.0f, 0.12f))
        )
        sceneGraph.addNode(frontDoor)

        val windowGroundLounge = SceneNode(
            id = "window_ground_lounge",
            name = "uPVC Casement Window Lounge",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(2.35f, 1.7f, 3.0f)),
            material = Material.GLASS,
            stage = ConstructionStage.WINDOWS_DOORS,
            installationStep = currentStepIndex + 2,
            metadata = NodeMetadata(
                trade = Trade.CARPENTRY,
                stage = ConstructionStage.WINDOWS_DOORS,
                code = "WIN-UPVC-1700",
                description = "Double Glazed Argon-Filled Low-E Casement Window",
                costGBP = 480f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(2.35f, 1.7f, 3.0f), Vector3(1.6f, 1.1f, 0.12f))
        )
        sceneGraph.addNode(windowGroundLounge)

        val windowUpperBed1 = SceneNode(
            id = "window_upper_bed1",
            name = "Bedroom 1 Window Upper",
            parentId = "first_floor_decking",
            transform = Transform3D(position = Vector3(-2.0f, 3.7f, 3.0f)),
            material = Material.GLASS,
            stage = ConstructionStage.WINDOWS_DOORS,
            installationStep = currentStepIndex + 4,
            metadata = NodeMetadata(
                trade = Trade.CARPENTRY,
                stage = ConstructionStage.WINDOWS_DOORS,
                code = "WIN-UPVC-1500",
                description = "Master Bedroom Double Glazed Window",
                costGBP = 420f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(-2.0f, 3.7f, 3.0f), Vector3(1.5f, 1.1f, 0.12f))
        )
        sceneGraph.addNode(windowUpperBed1)
        currentStepIndex += 6

        // PHASE 11: FIRST FIX MEP
        val copperPipeLounge = SceneNode(
            id = "first_fix_copper_pipe",
            name = "Central Heating Water Mains Copper Pipe",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(-1.5f, 1.2f, 0f)),
            material = Material.COPPER_PIPE,
            stage = ConstructionStage.FIRST_FIX,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.MEP,
                stage = ConstructionStage.FIRST_FIX,
                code = "MEP-COP-22",
                description = "22mm Hard Drawn Copper Water Circuit",
                costGBP = 1400f
            ),
            meshShape = MeshShape.PIPE,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(-1.5f, 1.2f, 0f), Vector3(0.03f, 2.1f, 4.2f))
        )
        sceneGraph.addNode(copperPipeLounge)
        currentStepIndex += 4

        // PHASE 12: INSULATION
        val cavityInsulation = SceneNode(
            id = "cavity_wall_insulation",
            name = "Kingspan Kooltherm Cavity Insulation",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 1.8f, 2.88f)),
            material = Material.INSULATION_GOLD,
            stage = ConstructionStage.INSULATION,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.DRYWALL,
                stage = ConstructionStage.INSULATION,
                code = "INS-K108-100",
                description = "100mm Rigid Phenolic Insulation Board R-value 4.5",
                costGBP = 1850f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 1.8f, 2.88f), Vector3(7.6f, 2.2f, 0.08f))
        )
        sceneGraph.addNode(cavityInsulation)
        currentStepIndex += 4

        // PHASE 13: PLASTERBOARD
        val plasterboardLounge = SceneNode(
            id = "plasterboard_lounge_wall",
            name = "12.5mm Gyproc Wallboard Lounge",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 1.5f, 2.80f)),
            material = Material.PLASTER,
            stage = ConstructionStage.PLASTERBOARD,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.DRYWALL,
                stage = ConstructionStage.PLASTERBOARD,
                code = "DRY-GYP-125",
                description = "Tapered Edge Plasterboard & Skim Coat",
                costGBP = 920f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 1.5f, 2.80f), Vector3(7.4f, 2.1f, 0.02f))
        )
        sceneGraph.addNode(plasterboardLounge)
        currentStepIndex += 4

        // PHASE 14: SECOND FIX JOINERY
        val internalDoorHall = SceneNode(
            id = "internal_door_lounge",
            name = "Oak Veneer Internal Door Lounge",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(-1.8f, 1.2f, 1.2f)),
            material = Material.TIMBER,
            stage = ConstructionStage.SECOND_FIX,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.FINISHES,
                stage = ConstructionStage.SECOND_FIX,
                code = "DOR-INT-OAK",
                description = "Pre-hung 35mm Solid Core Internal Door",
                costGBP = 280f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(-1.8f, 1.2f, 1.2f), Vector3(0.85f, 1.98f, 0.04f))
        )
        sceneGraph.addNode(internalDoorHall)
        currentStepIndex += 3

        // PHASE 15: DECORATION
        val paintedWallLounge = SceneNode(
            id = "decor_paint_ocean_blue",
            name = "Feature Wall Ocean Blue Emulsion",
            parentId = "ground_floor_slab",
            transform = Transform3D(position = Vector3(0f, 1.5f, 2.78f)),
            material = Material.PAINT_BLUE,
            stage = ConstructionStage.DECORATION,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.FINISHES,
                stage = ConstructionStage.DECORATION,
                code = "PNT-MATT-BLU",
                description = "Dulux Trade Vinyl Matt Finish Ocean Breeze",
                costGBP = 340f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 1.5f, 2.78f), Vector3(7.38f, 2.08f, 0.005f))
        )
        sceneGraph.addNode(paintedWallLounge)
        currentStepIndex += 3

        // PHASE 16: LANDSCAPING
        val drivewayPaving = SceneNode(
            id = "driveway_block_paving",
            name = "Permeable Block Paving Driveway",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(0f, 0.02f, 4.8f)),
            material = Material.CONCRETE,
            stage = ConstructionStage.LANDSCAPING,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.LANDSCAPING,
                stage = ConstructionStage.LANDSCAPING,
                code = "LND-PAV-60",
                description = "Charcoal Interlocking Concrete Driveway Blocks",
                costGBP = 3600f
            ),
            meshShape = MeshShape.SLAB,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(0f, 0.02f, 4.8f), Vector3(6f, 0.06f, 3.2f))
        )
        sceneGraph.addNode(drivewayPaving)
        currentStepIndex += 3

        // COMPLETION
        val completionFlag = SceneNode(
            id = "completion_signboard",
            name = "BuildMotion Certificate of Completion",
            parentId = "root_plot",
            transform = Transform3D(position = Vector3(-3.5f, 0.8f, 5.2f)),
            material = Material.STEEL,
            stage = ConstructionStage.COMPLETION,
            installationStep = currentStepIndex,
            metadata = NodeMetadata(
                trade = Trade.FINISHES,
                stage = ConstructionStage.COMPLETION,
                code = "BIM-CERT-PASS",
                description = "Digital Construction Twin Verified & Passed",
                costGBP = 0f
            ),
            meshShape = MeshShape.PANEL,
            bounds = BoundingBox3D.createFromCenterAndSize(Vector3(-3.5f, 0.8f, 5.2f), Vector3(0.8f, 1.2f, 0.05f))
        )
        sceneGraph.addNode(completionFlag)

        return currentStepIndex
    }
}
