package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.animation.PlaybackState
import com.example.ui.BuildMotionViewModel

import com.example.ui.theme.*

@Composable
fun TimelineDock(
    viewModel: BuildMotionViewModel,
    modifier: Modifier = Modifier
) {
    val animEngine = viewModel.animationEngine
    val currentStep by animEngine.currentStep.collectAsState()
    val playbackState by animEngine.playbackState.collectAsState()
    val speed by animEngine.playbackSpeed.collectAsState()
    val maxSteps = animEngine.maxTimelineSteps

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("timeline_dock_card"),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Timeline Step & Phase Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(SageGreen, shape = RoundedCornerShape(50))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "STAGE CONSTRUCTION: STEP $currentStep / $maxSteps",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimaryDark,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = "${(animEngine.progressFraction * 100).toInt()}% COMPLETE",
                    style = MaterialTheme.typography.labelSmall,
                    color = LavenderPrimary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Timeline Slider
            Slider(
                value = currentStep.toFloat(),
                onValueChange = { viewModel.animationEngine.seekToStep(it.toInt()) },
                valueRange = 1f..maxSteps.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = LavenderPrimary,
                    activeTrackColor = LavenderPrimary,
                    inactiveTrackColor = SurfaceBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("timeline_slider")
            )

            // Playback Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play / Pause / Step Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { animEngine.reverse() },
                        modifier = Modifier.testTag("btn_reverse")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Reverse Playback",
                            tint = TextPrimaryDark
                        )
                    }
                    IconButton(
                        onClick = { animEngine.stepBackward() },
                        modifier = Modifier.testTag("btn_step_back")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Step Backward",
                            tint = TextPrimaryDark
                        )
                    }
                    FilledIconButton(
                        onClick = { animEngine.togglePlayPause() },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = LavenderContainer
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("btn_play_pause")
                    ) {
                        Icon(
                            imageVector = if (playbackState == PlaybackState.PLAYING) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play or Pause",
                            tint = LavenderDeep
                        )
                    }
                    IconButton(
                        onClick = { animEngine.stepForward() },
                        modifier = Modifier.testTag("btn_step_forward")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Step Forward",
                            tint = TextPrimaryDark
                        )
                    }
                }

                // Speed Multiplier Chips
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(0.5f, 1.0f, 2.0f, 4.0f).forEach { spd ->
                        FilterChip(
                            selected = (speed == spd),
                            onClick = { animEngine.setPlaybackSpeed(spd) },
                            label = { Text("${spd}x", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LavenderPrimary,
                                selectedLabelColor = LavenderDarkText,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimaryDark
                            )
                        )
                    }
                }
            }

            // Phase Bookmark Shortcuts
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(animEngine.bookmarks) { bm ->
                    AssistChip(
                        onClick = { animEngine.seekToStep(bm.step) },
                        label = { Text(bm.title, fontSize = 10.sp) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = SurfaceVariantDark,
                            labelColor = SageGreen
                        )
                    )
                }
            }
        }
    }
}
