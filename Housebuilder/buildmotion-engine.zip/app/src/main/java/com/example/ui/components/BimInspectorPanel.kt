package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.model.SceneNode
import com.example.ui.BuildMotionViewModel

import com.example.ui.theme.*

@Composable
fun BimInspectorPanel(
    viewModel: BuildMotionViewModel,
    modifier: Modifier = Modifier
) {
    val selectedNode by viewModel.selectedNode.collectAsState()
    val sceneGraph = viewModel.sceneGraph
    val measuredDistance by viewModel.measuredDistance.collectAsState()

    Card(
        modifier = modifier
            .width(320.dp)
            .fillMaxHeight()
            .padding(8.dp)
            .testTag("bim_inspector_card"),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Panel Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountTree,
                        contentDescription = "BIM Tree",
                        tint = LavenderPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BIM Node Inspector",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Distance Measurement Banner if active
            measuredDistance?.let { dist ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Straighten,
                            contentDescription = "Distance",
                            tint = SageGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Measurement Tool", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                            Text("Distance: ${String.format("%.3f", dist)} meters", style = MaterialTheme.typography.titleMedium, color = SageGreen)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Selected Node Details or Tree Explorer
            if (selectedNode != null) {
                val node = selectedNode!!
                NodeDetailView(node = node, onClear = { viewModel.selectNode(null) })
            } else {
                Text(
                    text = "Select any component in the 3D viewport or tree below:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Hierarchy Tree List
                val allNodes = remember(sceneGraph.totalNodeCount) { sceneGraph.getAllNodes().take(50) }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(allNodes) { n ->
                        Card(
                            onClick = { viewModel.selectNode(n) },
                            colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(n.name, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold)
                                    Text("${n.metadata.trade.displayName} • Step ${n.installationStep}", style = MaterialTheme.typography.bodySmall, color = TextSecondaryDark)
                                }
                                SuggestionChip(
                                    onClick = { viewModel.selectNode(n) },
                                    label = { Text(n.metadata.code, fontSize = 9.sp, color = LavenderPrimary) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = SurfaceBorder)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NodeDetailView(
    node: SceneNode,
    onClear: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(node.name, style = MaterialTheme.typography.titleSmall, color = LavenderPrimary)
                IconButton(onClick = onClear) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMutedDark)
                }
            }

            HorizontalDivider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 6.dp))

            DetailRow("UUID", node.id.take(13) + "...")
            DetailRow("Trade", node.metadata.trade.displayName)
            DetailRow("Phase", node.stage.phaseName)
            DetailRow("Spec Code", node.metadata.specCode)
            DetailRow("Material", node.material.name)
            DetailRow("Cost Est.", "£${String.format("%.2f", node.metadata.costGBP)}")
            DetailRow("Weight", "${node.metadata.weightKg} kg")
            DetailRow("Position X/Y/Z", "${String.format("%.2f", node.transform.position.x)}, ${String.format("%.2f", node.transform.position.y)}, ${String.format("%.2f", node.transform.position.z)}")
            DetailRow("Install Step", "Step #${node.installationStep}")
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondaryDark)
        Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark, fontWeight = FontWeight.Medium)
    }
}
