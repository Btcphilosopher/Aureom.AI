package com.example.engine.renderer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.engine.camera.CameraController
import com.example.engine.instancing.InstancedMeshManager
import com.example.engine.lod.LODManager
import com.example.engine.model.*
import com.example.engine.scene.SceneGraph
import kotlin.math.abs
import kotlin.math.max

data class RenderPolygon(
    val node: SceneNode,
    val screenPoints: List<Offset>,
    val averageDepth: Float,
    val faceColor: Color,
    val isSelected: Boolean,
    val isWireframe: Boolean
)

enum class ViewRenderStyle {
    PBR_SHADED,
    WIREFRAME,
    BLUEPRINT,
    XRAY_TRANSPARENT
}

class Software3DRenderer(
    val sceneGraph: SceneGraph,
    val cameraController: CameraController
) {
    var renderStyle: ViewRenderStyle = ViewRenderStyle.PBR_SHADED
    var sunLightAngleDeg: Float = 45f // Daylight angle
    var measurementPointA: Vector3? = null
    var measurementPointB: Vector3? = null

    var lastRenderedTriangles: Int = 0
        private set
    var lastFrameTimeMs: Long = 0
        private set

    private val instancingManager = InstancedMeshManager()

    fun render(drawScope: DrawScope, canvasWidth: Float, canvasHeight: Float, currentTimelineStep: Int) {
        val startTime = System.currentTimeMillis()
        val cameraPos = cameraController.getCameraPosition()
        val viewMatrix = cameraController.getViewMatrix()
        val projMatrix = cameraController.getProjectionMatrix(canvasWidth, canvasHeight)
        val viewProjMatrix = projMatrix * viewMatrix

        // Sun Direction Vector
        val sunRad = Math.toRadians(sunLightAngleDeg.toDouble()).toFloat()
        val sunDir = Vector3(kotlin.math.cos(sunRad), 0.8f, kotlin.math.sin(sunRad)).normalize()

        // 1. Draw Blueprint / Site Grid
        drawSiteGrid(drawScope, canvasWidth, canvasHeight, viewProjMatrix)

        // 2. Gather visible nodes & compute projection
        val visibleNodes = sceneGraph.getAllNodes().filter { sceneGraph.isNodeVisibleAtStep(it, currentTimelineStep) }
        val polygonsToDraw = mutableListOf<RenderPolygon>()

        instancingManager.clear()

        for (node in visibleNodes) {
            val worldPos = sceneGraph.getWorldPosition(node)
            val lod = LODManager.calculateLOD(node, cameraPos)
            node.lodLevel = lod

            if (lod == 3) continue // Frustum / Distance Culled

            if (node.isInstanced) {
                instancingManager.addInstance(node, worldPos)
            }

            val isSelected = (node.id == sceneGraph.selectedNodeId)
            val boundsSize = node.bounds.size
            val half = boundsSize * 0.5f

            // Project 3D bounding box corners
            val corners3D = listOf(
                worldPos + Vector3(-half.x, -half.y, -half.z),
                worldPos + Vector3(half.x, -half.y, -half.z),
                worldPos + Vector3(half.x, half.y, -half.z),
                worldPos + Vector3(-half.x, half.y, -half.z),
                worldPos + Vector3(-half.x, -half.y, half.z),
                worldPos + Vector3(half.x, -half.y, half.z),
                worldPos + Vector3(half.x, half.y, half.z),
                worldPos + Vector3(-half.x, half.y, half.z)
            )

            // Screen projection
            val projectedPoints = corners3D.map { p3d ->
                projectPoint(p3d, viewProjMatrix, canvasWidth, canvasHeight)
            }

            if (projectedPoints.any { it == null }) continue

            val validPoints = projectedPoints.filterNotNull()
            val avgDepth = corners3D.map { (it - cameraPos).length() }.average().toFloat()

            // Calculate Material Lighting Color
            val baseColor = when (renderStyle) {
                ViewRenderStyle.BLUEPRINT -> Color(0xFFD0BCFF)
                ViewRenderStyle.WIREFRAME -> Color(0xFFCCC2DC)
                ViewRenderStyle.XRAY_TRANSPARENT -> node.material.albedoColor.copy(alpha = 0.35f)
                ViewRenderStyle.PBR_SHADED -> {
                    val normal = Vector3.UP
                    val NdotL = max(0.25f, normal.dot(sunDir))
                    val r = (node.material.albedoColor.red * NdotL).coerceIn(0f, 1f)
                    val g = (node.material.albedoColor.green * NdotL).coerceIn(0f, 1f)
                    val b = (node.material.albedoColor.blue * NdotL).coerceIn(0f, 1f)
                    Color(r, g, b, node.material.transparency * node.animationOpacity)
                }
            }

            // Construct 3D faces (Front, Back, Left, Right, Top)
            val faceIndicesList = listOf(
                listOf(0, 1, 2, 3), // Front
                listOf(5, 4, 7, 6), // Back
                listOf(4, 0, 3, 7), // Left
                listOf(1, 5, 6, 2), // Right
                listOf(3, 2, 6, 7), // Top
                listOf(0, 4, 5, 1)  // Bottom
            )

            for (indices in faceIndicesList) {
                val pts = indices.map { validPoints[it] }
                polygonsToDraw.add(
                    RenderPolygon(
                        node = node,
                        screenPoints = pts,
                        averageDepth = avgDepth,
                        faceColor = baseColor,
                        isSelected = isSelected,
                        isWireframe = (renderStyle == ViewRenderStyle.WIREFRAME || renderStyle == ViewRenderStyle.BLUEPRINT)
                    )
                )
            }
        }

        instancingManager.finalizeBatches()

        // 3. Sort polygons back-to-front (Painter's depth algorithm)
        polygonsToDraw.sortByDescending { it.averageDepth }
        lastRenderedTriangles = polygonsToDraw.size * 2

        // 4. Render sorted faces onto Compose Canvas
        for (poly in polygonsToDraw) {
            val path = Path().apply {
                moveTo(poly.screenPoints[0].x, poly.screenPoints[0].y)
                for (i in 1 until poly.screenPoints.size) {
                    lineTo(poly.screenPoints[i].x, poly.screenPoints[i].y)
                }
                close()
            }

            if (poly.isWireframe) {
                drawScope.drawPath(
                    path = path,
                    color = if (poly.isSelected) Color(0xFFB1D18A) else poly.faceColor,
                    style = Stroke(width = if (poly.isSelected) 3f else 1.2f)
                )
            } else {
                drawScope.drawPath(
                    path = path,
                    color = poly.faceColor
                )
                // Outline border for clean CAD styling
                drawScope.drawPath(
                    path = path,
                    color = if (poly.isSelected) Color(0xFFB1D18A) else Color(0x33000000),
                    style = Stroke(width = if (poly.isSelected) 3.5f else 0.8f)
                )
            }
        }

        // 5. Draw Measurement Tool distance overlay if active
        val pA = measurementPointA
        val pB = measurementPointB
        if (pA != null && pB != null) {
            val projA = projectPoint(pA, viewProjMatrix, canvasWidth, canvasHeight)
            val projB = projectPoint(pB, viewProjMatrix, canvasWidth, canvasHeight)
            if (projA != null && projB != null) {
                drawScope.drawLine(
                    color = Color(0xFFFF6D00),
                    start = projA,
                    end = projB,
                    strokeWidth = 4f
                )
                drawScope.drawCircle(Color(0xFFFF6D00), radius = 8f, center = projA)
                drawScope.drawCircle(Color(0xFFFF6D00), radius = 8f, center = projB)
            }
        }

        lastFrameTimeMs = System.currentTimeMillis() - startTime
    }

    private fun drawSiteGrid(drawScope: DrawScope, width: Float, height: Float, viewProjMatrix: Matrix4) {
        val gridColor = if (renderStyle == ViewRenderStyle.BLUEPRINT) Color(0x33D0BCFF) else Color(0x2249454F)
        val gridSize = 10
        val step = 1.0f

        for (i in -gridSize..gridSize) {
            val p1 = Vector3(i * step, 0f, -gridSize * step)
            val p2 = Vector3(i * step, 0f, gridSize * step)
            val proj1 = projectPoint(p1, viewProjMatrix, width, height)
            val proj2 = projectPoint(p2, viewProjMatrix, width, height)
            if (proj1 != null && proj2 != null) {
                drawScope.drawLine(color = gridColor, start = proj1, end = proj2, strokeWidth = 1f)
            }

            val p3 = Vector3(-gridSize * step, 0f, i * step)
            val p4 = Vector3(gridSize * step, 0f, i * step)
            val proj3 = projectPoint(p3, viewProjMatrix, width, height)
            val proj4 = projectPoint(p4, viewProjMatrix, width, height)
            if (proj3 != null && proj4 != null) {
                drawScope.drawLine(color = gridColor, start = proj3, end = proj4, strokeWidth = 1f)
            }
        }
    }

    private fun projectPoint(point: Vector3, viewProjMatrix: Matrix4, width: Float, height: Float): Offset? {
        val clip = viewProjMatrix.transformPoint(point)
        // Transform NDC (-1..1) to Screen Space
        val xScreen = (clip.x + 1.0f) * 0.5f * width
        val yScreen = (1.0f - clip.y) * 0.5f * height

        return if (xScreen in -width..width * 2f && yScreen in -height..height * 2f) {
            Offset(xScreen, yScreen)
        } else null
    }
}
