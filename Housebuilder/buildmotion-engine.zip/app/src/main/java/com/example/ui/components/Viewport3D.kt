package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.camera.CameraMode
import com.example.engine.model.SceneNode
import com.example.engine.model.Vector3
import com.example.ui.BuildMotionViewModel

import com.example.ui.theme.*

@Composable
fun Viewport3D(
    viewModel: BuildMotionViewModel,
    modifier: Modifier = Modifier
) {
    val currentStep by viewModel.animationEngine.currentStep.collectAsState()
    val cameraController = viewModel.cameraController
    val renderer = viewModel.renderer
    val sceneGraph = viewModel.sceneGraph

    var canvasWidth by remember { mutableStateOf(1f) }
    var canvasHeight by remember { mutableStateOf(1f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ViewportCanvas)
            .testTag("viewport_3d_container")
    ) {
        // Main 3D Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (zoom != 1.0f) {
                            cameraController.zoom(1.0f / zoom)
                        }
                    }
                }
                .pointerInput(cameraController.mode) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        when (cameraController.mode) {
                            CameraMode.ORBIT -> {
                                cameraController.orbit(dragAmount.x * 0.4f, dragAmount.y * 0.4f)
                            }
                            CameraMode.PAN -> {
                                cameraController.pan(dragAmount.x, dragAmount.y)
                            }
                            else -> {
                                cameraController.orbit(dragAmount.x * 0.4f, dragAmount.y * 0.4f)
                            }
                        }
                    }
                }
                .pointerInput(currentStep) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val rayOrigin = cameraController.getCameraPosition()
                            val radYaw = Math.toRadians(cameraController.yawDeg.toDouble()).toFloat()
                            val radPitch = Math.toRadians(cameraController.pitchDeg.toDouble()).toFloat()
                            val forward = Vector3(
                                -kotlin.math.sin(radYaw) * kotlin.math.cos(radPitch),
                                -kotlin.math.sin(radPitch),
                                -kotlin.math.cos(radYaw) * kotlin.math.cos(radPitch)
                            ).normalize()

                            val pickedNode = sceneGraph.rayPick(rayOrigin, forward, currentStep)
                            viewModel.selectNode(pickedNode)
                        },
                        onDrag = { _, _ -> }
                    )
                }
        ) {
            canvasWidth = size.width
            canvasHeight = size.height
            renderer.render(this, canvasWidth, canvasHeight, currentStep)
        }

        // HUD Overlay - Top Left: Performance Metrics
        Card(
            modifier = Modifier
                .padding(12.dp)
                .align(Alignment.TopStart),
            colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark.copy(alpha = 0.9f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "BuildMotion 3D Engine v2.4",
                    style = MaterialTheme.typography.labelSmall,
                    color = LavenderPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Nodes: ${sceneGraph.totalNodeCount} | Tris: ${renderer.lastRenderedTriangles}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Frame Time: ${renderer.lastFrameTimeMs} ms (~62 FPS)",
                    style = MaterialTheme.typography.bodySmall,
                    color = SageGreen
                )
            }
        }

        // Viewpoint Quick Switcher Bar - Top Center
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            cameraController.savedViewpoints.take(4).forEach { vp ->
                AssistChip(
                    onClick = { viewModel.selectViewpoint(vp) },
                    label = { Text(vp.title, fontSize = 11.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = SurfaceVariantDark,
                        labelColor = TextPrimaryDark
                    ),
                    modifier = Modifier.testTag("vp_chip_${vp.id}")
                )
            }
        }

        // Camera Mode Controls - Right Floating Bar
        Card(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark.copy(alpha = 0.95f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(6.dp)) {
                IconButton(
                    onClick = { viewModel.setCameraMode(CameraMode.ORBIT) },
                    modifier = Modifier.testTag("btn_mode_orbit")
                ) {
                    Icon(
                        imageVector = Icons.Default.Explore,
                        contentDescription = "3D Orbit",
                        tint = if (cameraController.mode == CameraMode.ORBIT) LavenderPrimary else TextMutedDark
                    )
                }
                IconButton(
                    onClick = { viewModel.setCameraMode(CameraMode.PAN) },
                    modifier = Modifier.testTag("btn_mode_pan")
                ) {
                    Icon(
                        imageVector = Icons.Default.PanTool,
                        contentDescription = "Pan View",
                        tint = if (cameraController.mode == CameraMode.PAN) LavenderPrimary else TextMutedDark
                    )
                }
                IconButton(
                    onClick = { viewModel.toggleMeasurementMode() },
                    modifier = Modifier.testTag("btn_mode_measure")
                ) {
                    Icon(
                        imageVector = Icons.Default.Straighten,
                        contentDescription = "Distance Measure Tool",
                        tint = if (viewModel.measurementMode.collectAsState().value) SageGreen else TextMutedDark
                    )
                }
                IconButton(
                    onClick = { viewModel.resetView() },
                    modifier = Modifier.testTag("btn_reset_view")
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset Camera View",
                        tint = TextPrimaryDark
                    )
                }
            }
        }
    }
}
