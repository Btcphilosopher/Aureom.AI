package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.animation.AnimationEngine
import com.example.engine.camera.CameraController
import com.example.engine.camera.CameraMode
import com.example.engine.camera.CameraViewpoint
import com.example.engine.model.ConstructionStage
import com.example.engine.model.SceneNode
import com.example.engine.model.Trade
import com.example.engine.model.Vector3
import com.example.engine.renderer.Software3DRenderer
import com.example.engine.renderer.ViewRenderStyle
import com.example.engine.scene.HouseBuilder
import com.example.engine.scene.SceneGraph
import com.example.engine.testing.BenchmarkEngine
import com.example.engine.testing.BenchmarkResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BuildMotionViewModel : ViewModel() {

    val sceneGraph = SceneGraph()
    val animationEngine = AnimationEngine(sceneGraph)
    val cameraController = CameraController()
    val renderer = Software3DRenderer(sceneGraph, cameraController)
    val benchmarkEngine = BenchmarkEngine(sceneGraph, animationEngine)

    private val _selectedNode = MutableStateFlow<SceneNode?>(null)
    val selectedNode: StateFlow<SceneNode?> = _selectedNode.asStateFlow()

    private val _showDocsModal = MutableStateFlow(false)
    val showDocsModal: StateFlow<Boolean> = _showDocsModal.asStateFlow()

    private val _showBenchmarkModal = MutableStateFlow(false)
    val showBenchmarkModal: StateFlow<Boolean> = _showBenchmarkModal.asStateFlow()

    private val _benchmarkResult = MutableStateFlow<BenchmarkResult?>(null)
    val benchmarkResult: StateFlow<BenchmarkResult?> = _benchmarkResult.asStateFlow()

    private val _measurementMode = MutableStateFlow(false)
    val measurementMode: StateFlow<Boolean> = _measurementMode.asStateFlow()

    private val _measuredDistance = MutableStateFlow<Float?>(null)
    val measuredDistance: StateFlow<Float?> = _measuredDistance.asStateFlow()

    init {
        // Build the digital twin residential model
        val maxSteps = HouseBuilder.buildDigitalTwinHouse(sceneGraph)
        animationEngine.setMaxSteps(maxSteps)
        animationEngine.seekToStep(maxSteps) // Start with completed house view

        // Start 60 FPS animation ticker loop
        viewModelScope.launch {
            while (true) {
                delay(16) // ~60 FPS
                animationEngine.tick(0.016f)
            }
        }
    }

    fun selectNode(node: SceneNode?) {
        _selectedNode.value = node
        sceneGraph.selectedNodeId = node?.id

        if (_measurementMode.value && node != null) {
            val pos = sceneGraph.getWorldPosition(node)
            if (renderer.measurementPointA == null) {
                renderer.measurementPointA = pos
            } else if (renderer.measurementPointB == null) {
                renderer.measurementPointB = pos
                val dist = renderer.measurementPointA!!.distanceTo(pos)
                _measuredDistance.value = dist
            } else {
                renderer.measurementPointA = pos
                renderer.measurementPointB = null
                _measuredDistance.value = null
            }
        }
    }

    fun toggleMeasurementMode() {
        val newMode = !_measurementMode.value
        _measurementMode.value = newMode
        if (!newMode) {
            renderer.measurementPointA = null
            renderer.measurementPointB = null
            _measuredDistance.value = null
        }
    }

    fun setExplodeFactor(factor: Float) {
        sceneGraph.explodeFactor = factor.coerceIn(0f, 1f)
    }

    fun setSectionPlaneEnabled(enabled: Boolean) {
        sceneGraph.sectionPlaneEnabled = enabled
    }

    fun setSectionPlaneY(heightY: Float) {
        sceneGraph.sectionPlaneY = heightY
    }

    fun setRenderStyle(style: ViewRenderStyle) {
        renderer.renderStyle = style
    }

    fun setSunAngle(angleDeg: Float) {
        renderer.sunLightAngleDeg = angleDeg
    }

    fun setTradeFilter(trade: Trade?) {
        sceneGraph.activeTradeFilter = trade
    }

    fun setStageFilter(stage: ConstructionStage?) {
        sceneGraph.activeStageFilter = stage
        if (stage != null) {
            val targetStep = (stage.sequenceIndex.toFloat() / ConstructionStage.values().size * animationEngine.maxTimelineSteps).toInt()
            animationEngine.seekToStep(targetStep)
        }
    }

    fun selectViewpoint(vp: CameraViewpoint) {
        cameraController.applyViewpoint(vp)
    }

    fun setCameraMode(mode: CameraMode) {
        cameraController.mode = mode
    }

    fun openDocsModal() {
        _showDocsModal.value = true
    }

    fun closeDocsModal() {
        _showDocsModal.value = false
    }

    fun openBenchmarkModal() {
        _benchmarkResult.value = benchmarkEngine.runDiagnosticsAndBenchmark(
            lastFrameMs = renderer.lastFrameTimeMs,
            renderedTris = renderer.lastRenderedTriangles
        )
        _showBenchmarkModal.value = true
    }

    fun closeBenchmarkModal() {
        _showBenchmarkModal.value = false
    }

    fun resetView() {
        sceneGraph.explodeFactor = 0f
        sceneGraph.sectionPlaneEnabled = false
        sceneGraph.activeTradeFilter = null
        sceneGraph.activeStageFilter = null
        sceneGraph.selectedNodeId = null
        _selectedNode.value = null
        cameraController.applyViewpoint(cameraController.savedViewpoints[0])
    }
}
