package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkCanvas = Color(0xFF0F0F0F)
val ViewportCanvas = Color(0xFF050505)
val SurfaceDark = Color(0xFF1C1B1F)
val SurfaceVariantDark = Color(0xFF25232A)
val SurfaceBorder = Color(0xFF49454F)
val BorderSubtle = Color(0xFF333333)

val LavenderPrimary = Color(0xFFD0BCFF)
val LavenderContainer = Color(0xFFEADDFF)
val LavenderDarkText = Color(0xFF381E72)
val LavenderDeep = Color(0xFF21005D)

val SageGreen = Color(0xFFB1D18A)
val SageGreenDark = Color(0xFF1D3500)

val SafetyOrange = Color(0xFFFF6D00)
val MasonryRed = Color(0xFFE53935)
val ConcreteSteel = Color(0xFF90A4AE)

val TextPrimaryDark = Color(0xFFE6E1E5)
val TextSecondaryDark = Color(0xFFCCC2DC)
val TextMutedDark = Color(0xFF938F99)

