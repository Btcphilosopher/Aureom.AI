package com.example.engine.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

enum class Trade(val displayName: String, val badgeColor: Color) {
    GROUNDWORKS("Groundworks & Site", Color(0xFF795548)),
    MASONRY("Brickwork & Masonry", Color(0xFFD32F2F)),
    STEELWORK("Structural Steel", Color(0xFF1976D2)),
    CARPENTRY("Carpentry & Timber", Color(0xFFF57C00)),
    ROOFING("Roofing & Cladding", Color(0xFF388E3C)),
    MEP("Mechanical & Electrical", Color(0xFF00ACC1)),
    DRYWALL("Insulation & Drywall", Color(0xFF7B1FA2)),
    FINISHES("Finishes & Decoration", Color(0xFFE91E63)),
    LANDSCAPING("Landscaping", Color(0xFF4CAF50))
}

enum class ConstructionStage(val phaseName: String, val sequenceIndex: Int) {
    SITE_CLEARANCE("1. Site Clearance", 1),
    EXCAVATION("2. Excavation & Trenching", 2),
    FOUNDATIONS("3. Concrete Foundations", 3),
    DRAINAGE("4. Underground Drainage", 4),
    FLOOR_SLAB("5. Floor Slab & Damp Proofing", 5),
    BRICKWORK("6. Brickwork & Cavity Walls", 6),
    STRUCTURAL_FRAME("7. Steel Beams & Lintels", 7),
    FLOORS("8. First Floor Joists & Decking", 8),
    ROOF("9. Roof Trusses & Tiling", 9),
    WINDOWS_DOORS("10. Windows & External Doors", 10),
    FIRST_FIX("11. First Fix Plumbing & Electrical", 11),
    INSULATION("12. Cavity & Roof Insulation", 12),
    PLASTERBOARD("13. Plasterboard & Skimming", 13),
    SECOND_FIX("14. Second Fix Joinery & Outlets", 14),
    DECORATION("15. Paint & Floor Coverings", 15),
    LANDSCAPING("16. External Paving & Lawn", 16),
    COMPLETION("17. Handover & Completion", 17)
}

data class Material(
    val id: String,
    val name: String,
    val albedoColor: Color,
    val metallic: Float = 0.1f,
    val roughness: Float = 0.8f,
    val transparency: Float = 1.0f, // 1.0 = opaque, 0.0 = transparent
    val isGlass: Boolean = false
) {
    companion object {
        val SOIL = Material("soil", "Soil / Earth", Color(0xFF5D4037), roughness = 0.95f)
        val CONCRETE = Material("concrete", "C35 Concrete", Color(0xFF78909C), metallic = 0.05f, roughness = 0.85f)
        val BRICK_RED = Material("brick_red", "Standard Facing Brick", Color(0xFFB71C1C), roughness = 0.90f)
        val MORTAR = Material("mortar", "Lime Mortar", Color(0xFFCFD8DC), roughness = 0.95f)
        val STEEL = Material("steel", "Structural Steel S355", Color(0xFF455A64), metallic = 0.85f, roughness = 0.35f)
        val TIMBER = Material("timber", "C24 Construction Timber", Color(0xFFA1887F), roughness = 0.75f)
        val ROOF_TILE = Material("roof_tile", "Marley Slate Tile", Color(0xFF37474F), roughness = 0.60f)
        val GLASS = Material("glass", "Low-E Double Glazing", Color(0x99B2EBF2), metallic = 0.90f, roughness = 0.10f, transparency = 0.45f, isGlass = true)
        val PVC_WHITE = Material("pvc_white", "uPVC Frame White", Color(0xFFECEFF1), roughness = 0.30f)
        val COPPER_PIPE = Material("copper", "Copper Pipe", Color(0xFFB87333), metallic = 0.90f, roughness = 0.25f)
        val INSULATION_GOLD = Material("insulation", "Mineral Wool Insulation", Color(0xFFFBC02D), roughness = 0.99f)
        val PLASTER = Material("plaster", "Gypsum Board Finish", Color(0xFFFAFAFA), roughness = 0.90f)
        val PAINT_BLUE = Material("paint_blue", "Emulsion Paint Ocean", Color(0xFF0288D1), roughness = 0.50f)
        val GRASS = Material("grass", "Turf Grass", Color(0xFF2E7D32), roughness = 0.90f)
    }
}

data class BoundingBox3D(
    val min: Vector3,
    val max: Vector3
) {
    val center: Vector3 get() = (min + max) * 0.5f
    val size: Vector3 get() = max - min

    fun containsPoint(p: Vector3): Boolean {
        return p.x in min.x..max.x &&
               p.y in min.y..max.y &&
               p.z in min.z..max.z
    }

    companion object {
        fun createFromCenterAndSize(center: Vector3, size: Vector3): BoundingBox3D {
            val half = size * 0.5f
            return BoundingBox3D(center - half, center + half)
        }
    }
}

data class Transform3D(
    var position: Vector3 = Vector3.ZERO,
    var rotationEuler: Vector3 = Vector3.ZERO, // degrees
    var scale: Vector3 = Vector3.ONE,
    var pivot: Vector3 = Vector3.ZERO
) {
    fun toMatrix(): Matrix4 {
        val tMat = Matrix4.translation(position.x, position.y, position.z)
        val rMat = Matrix4.rotationY(rotationEuler.y) // Primary rotation for house components
        val sMat = Matrix4.scale(scale.x, scale.y, scale.z)
        return tMat * rMat * sMat
    }
}

enum class MeshShape {
    SLAB,
    BRICK,
    BEAM,
    TRUSS,
    TILE,
    PANEL,
    PIPE,
    CUSTOM
}

data class NodeMetadata(
    val trade: Trade,
    val stage: ConstructionStage,
    val code: String,
    val description: String,
    val floorLevel: Int = 0,
    val weightKg: Float = 0f,
    val costGBP: Float = 0f,
    val specCode: String = "BS-EN-771"
)

data class SceneNode(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val parentId: String? = null,
    val childrenIds: MutableList<String> = mutableListOf(),
    val transform: Transform3D = Transform3D(),
    val material: Material,
    var isVisible: Boolean = true,
    val stage: ConstructionStage,
    val installationStep: Int, // Global timeline step index
    val removalStep: Int? = null,
    val metadata: NodeMetadata,
    val meshShape: MeshShape = MeshShape.SLAB,
    val bounds: BoundingBox3D,
    var animationOffset: Vector3 = Vector3.ZERO, // Fly-in transition delta
    var animationOpacity: Float = 1.0f,
    var lodLevel: Int = 0,
    var isInstanced: Boolean = false
)
