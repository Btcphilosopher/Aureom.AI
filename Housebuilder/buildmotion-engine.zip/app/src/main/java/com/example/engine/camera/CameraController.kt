package com.example.engine.camera

import com.example.engine.model.Matrix4
import com.example.engine.model.Vector3
import kotlin.math.cos
import kotlin.math.sin

enum class CameraMode(val title: String) {
    ORBIT("3D Orbit"),
    PAN("Pan View"),
    FLY("Fly Mode"),
    WALKTHROUGH("Walkthrough"),
    FIRST_PERSON("First Person"),
    TOP_ORTHO("Orthographic Top"),
    SECTION_ELEVATION("Section Elevation")
}

data class CameraViewpoint(
    val id: String,
    val title: String,
    val yaw: Float,
    val pitch: Float,
    val distance: Float,
    val target: Vector3,
    val isOrtho: Boolean = false
)

class CameraController {
    var mode: CameraMode = CameraMode.ORBIT

    var yawDeg: Float = 35f
    var pitchDeg: Float = 25f
    var distance: Float = 16f
    var target: Vector3 = Vector3(0f, 2.2f, 0f)

    var fovDeg: Float = 55f
    var aspectRatio: Float = 1.6f
    var nearPlane: Float = 0.1f
    var farPlane: Float = 200f
    var isOrthographic: Boolean = false

    val savedViewpoints = listOf(
        CameraViewpoint("iso", "3D Isometric Overview", 45f, 30f, 16f, Vector3(0f, 2.2f, 0f)),
        CameraViewpoint("front", "Front Elevation", 0f, 5f, 14f, Vector3(0f, 2.0f, 0f)),
        CameraViewpoint("side", "Side Elevation", 90f, 5f, 14f, Vector3(0f, 2.0f, 0f)),
        CameraViewpoint("brickwork", "Brickwork Inspection", 25f, 15f, 7f, Vector3(1.5f, 1.8f, 2.0f)),
        CameraViewpoint("roof", "Roof Structural Framing", 60f, 55f, 11f, Vector3(0f, 4.2f, 0f)),
        CameraViewpoint("walkthrough", "Interior Living Room", 10f, 2f, 3f, Vector3(0f, 1.4f, 1.0f)),
        CameraViewpoint("top_ortho", "Orthographic Blueprint", 0f, 89f, 18f, Vector3(0f, 0f, 0f), isOrtho = true)
    )

    fun applyViewpoint(vp: CameraViewpoint) {
        yawDeg = vp.yaw
        pitchDeg = vp.pitch
        distance = vp.distance
        target = vp.target
        isOrthographic = vp.isOrtho
    }

    fun orbit(deltaYaw: Float, deltaPitch: Float) {
        yawDeg = (yawDeg + deltaYaw) % 360f
        pitchDeg = (pitchDeg + deltaPitch).coerceIn(-89f, 89f)
    }

    fun pan(deltaX: Float, deltaY: Float) {
        val radYaw = Math.toRadians(yawDeg.toDouble()).toFloat()
        val right = Vector3(cos(radYaw), 0f, -sin(radYaw))
        val up = Vector3.UP

        val panSpeed = distance * 0.002f
        target += (right * (-deltaX * panSpeed)) + (up * (deltaY * panSpeed))
    }

    fun zoom(zoomFactor: Float) {
        distance = (distance * zoomFactor).coerceIn(1.5f, 60f)
    }

    fun getCameraPosition(): Vector3 {
        val radYaw = Math.toRadians(yawDeg.toDouble()).toFloat()
        val radPitch = Math.toRadians(pitchDeg.toDouble()).toFloat()

        val x = distance * cos(radPitch) * sin(radYaw)
        val y = distance * sin(radPitch)
        val z = distance * cos(radPitch) * cos(radYaw)

        return target + Vector3(x, y, z)
    }

    fun getViewMatrix(): Matrix4 {
        val eye = getCameraPosition()
        return Matrix4.lookAt(eye, target, Vector3.UP)
    }

    fun getProjectionMatrix(widthPx: Float, heightPx: Float): Matrix4 {
        aspectRatio = if (heightPx > 0f) widthPx / heightPx else 1.0f

        return if (isOrthographic) {
            val orthoSize = distance * 0.5f
            Matrix4.orthographic(
                -orthoSize * aspectRatio, orthoSize * aspectRatio,
                -orthoSize, orthoSize,
                nearPlane, farPlane
            )
        } else {
            Matrix4.perspective(fovDeg, aspectRatio, nearPlane, farPlane)
        }
    }
}
