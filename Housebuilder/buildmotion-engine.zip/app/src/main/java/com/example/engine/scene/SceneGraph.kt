package com.example.engine.scene

import com.example.engine.model.*
import java.util.concurrent.ConcurrentHashMap

class SceneGraph {
    private val nodesMap = ConcurrentHashMap<String, SceneNode>()
    private var rootNodeId: String? = null

    var explodeFactor: Float = 0.0f // 0.0 = collapsed house, 1.0 = fully exploded assembly
    var sectionPlaneY: Float = 100f // Clipping plane height Y (objects above are clipped when enabled)
    var sectionPlaneEnabled: Boolean = false
    var activeTradeFilter: Trade? = null
    var activeStageFilter: ConstructionStage? = null
    var selectedNodeId: String? = null

    fun addNode(node: SceneNode) {
        nodesMap[node.id] = node
        if (node.parentId == null) {
            rootNodeId = node.id
        } else {
            nodesMap[node.parentId]?.childrenIds?.add(node.id)
        }
    }

    fun getNode(id: String): SceneNode? = nodesMap[id]

    fun getAllNodes(): List<SceneNode> = nodesMap.values.toList()

    fun clear() {
        nodesMap.clear()
        rootNodeId = null
        selectedNodeId = null
    }

    val totalNodeCount: Int get() = nodesMap.size

    /**
     * Calculates the world position of a node including parent transforms and exploded offsets.
     */
    fun getWorldPosition(node: SceneNode): Vector3 {
        var pos = node.transform.position + node.animationOffset

        // Apply Explode View offset
        if (explodeFactor > 0.001f) {
            val center = Vector3(0f, 2.5f, 0f) // Building centroid
            val dir = (node.bounds.center - center)
            val dist = dir.length()
            val explodeDir = if (dist > 0.1f) dir.normalize() else Vector3.UP
            // Elevate floors and push walls outward
            val heightBias = (node.metadata.floorLevel + 1) * 1.5f * explodeFactor
            pos += Vector3(explodeDir.x * 2.5f * explodeFactor, heightBias, explodeDir.z * 2.5f * explodeFactor)
        }

        return pos
    }

    /**
     * Checks if a node should be rendered based on active timeline step, stage filter, trade filter, and section clipping plane.
     */
    fun isNodeVisibleAtStep(node: SceneNode, currentStep: Int): Boolean {
        // Timeline visibility check
        if (currentStep < node.installationStep) return false
        if (node.removalStep != null && currentStep >= node.removalStep) return false

        // Filter checks
        if (activeTradeFilter != null && node.metadata.trade != activeTradeFilter) return false
        if (activeStageFilter != null && node.stage != activeStageFilter) return false

        // Section Plane Clipping check
        if (sectionPlaneEnabled) {
            val pos = getWorldPosition(node)
            if (pos.y > sectionPlaneY) return false
        }

        return node.isVisible
    }

    /**
     * Ray-casts from camera screen ray into bounding boxes to pick an object.
     */
    fun rayPick(rayOrigin: Vector3, rayDir: Vector3, currentStep: Int): SceneNode? {
        var closestNode: SceneNode? = null
        var closestDist = Float.MAX_VALUE

        for (node in nodesMap.values) {
            if (!isNodeVisibleAtStep(node, currentStep)) continue

            val worldPos = getWorldPosition(node)
            val half = node.bounds.size * 0.5f
            val nodeMin = worldPos - half
            val nodeMax = worldPos + half

            val dist = rayAABBIntersection(rayOrigin, rayDir, nodeMin, nodeMax)
            if (dist != null && dist < closestDist) {
                closestDist = dist
                closestNode = node
            }
        }

        return closestNode
    }

    private fun rayAABBIntersection(origin: Vector3, dir: Vector3, min: Vector3, max: Vector3): Float? {
        var tmin = (min.x - origin.x) / (if (dir.x != 0f) dir.x else 0.0001f)
        var tmax = (max.x - origin.x) / (if (dir.x != 0f) dir.x else 0.0001f)
        if (tmin > tmax) { val temp = tmin; tmin = tmax; tmax = temp }

        var tymin = (min.y - origin.y) / (if (dir.y != 0f) dir.y else 0.0001f)
        var tymax = (max.y - origin.y) / (if (dir.y != 0f) dir.y else 0.0001f)
        if (tymin > tymax) { val temp = tymin; tymin = tymax; tymax = temp }

        if (tmin > tymax || tymin > tmax) return null
        if (tymin > tmin) tmin = tymin
        if (tymax < tmax) tmax = tymax

        var tzmin = (min.z - origin.z) / (if (dir.z != 0f) dir.z else 0.0001f)
        var tzmax = (max.z - origin.z) / (if (dir.z != 0f) dir.z else 0.0001f)
        if (tzmin > tzmax) { val temp = tzmin; tzmin = tzmax; tzmax = temp }

        if (tmin > tzmax || tzmin > tmax) return null
        if (tzmin > tmin) tmin = tzmin

        return if (tmin >= 0f) tmin else null
    }
}
