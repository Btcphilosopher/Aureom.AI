package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*

import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildMotionApp(
    viewModel: BuildMotionViewModel = viewModel()
) {
    val showDocsModal by viewModel.showDocsModal.collectAsState()
    val showBenchmarkModal by viewModel.showBenchmarkModal.collectAsState()
    val benchmarkResult by viewModel.benchmarkResult.collectAsState()

    var showInspectorDrawer by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = LavenderPrimary
                        ) {
                            Icon(
                                imageVector = Icons.Default.Apartment,
                                contentDescription = "Logo",
                                tint = LavenderDarkText,
                                modifier = Modifier
                                    .padding(6.dp)
                                    .size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BuildMotion Engine",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Enterprise BIM Digital Twin • Plot #102 Cedar Croft",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryDark
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showInspectorDrawer = !showInspectorDrawer },
                        modifier = Modifier.testTag("btn_toggle_inspector")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountTree,
                            contentDescription = "Toggle BIM Inspector",
                            tint = if (showInspectorDrawer) LavenderPrimary else TextMutedDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkCanvas)
            )
        },
        containerColor = DarkCanvas
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Viewport Controls & Filters Bar
                ControlsAndFiltersBar(viewModel = viewModel)

                // Middle Area: 3D Viewport + Optional Inspector Panel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Viewport3D(
                        viewModel = viewModel,
                        modifier = Modifier.weight(1f)
                    )

                    if (showInspectorDrawer) {
                        BimInspectorPanel(viewModel = viewModel)
                    }
                }

                // Bottom Timeline & Playback Dock
                TimelineDock(viewModel = viewModel)
            }

            // Documentation Modal Dialog
            if (showDocsModal) {
                DocumentationModal(onDismiss = { viewModel.closeDocsModal() })
            }

            // Performance Diagnostic Audit Modal
            if (showBenchmarkModal) {
                BenchmarkModal(
                    result = benchmarkResult,
                    onDismiss = { viewModel.closeBenchmarkModal() }
                )
            }
        }
    }
}
