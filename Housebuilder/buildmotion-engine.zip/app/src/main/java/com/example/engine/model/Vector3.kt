package com.example.engine.model

import kotlin.math.*

/**
/ Immutable 3D Vector with full linear algebra support.
 */
data class Vector3(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f
) {
    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scale: Float) = Vector3(x * scale, y * scale, z * scale)
    operator fun div(scale: Float) = if (scale != 0f) Vector3(x / scale, y / scale, z / scale) else ZERO
    operator fun unaryMinus() = Vector3(-x, -y, -z)

    fun dot(other: Vector3): Float = x * other.x + y * other.y + z * other.z
    fun cross(other: Vector3): Vector3 = Vector3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )

    fun length(): Float = sqrt(x * x + y * y + z * z)
    fun lengthSquared(): Float = x * x + y * y + z * z
    fun normalize(): Vector3 {
        val len = length()
        return if (len > 0.00001f) this / len else ZERO
    }

    fun distanceTo(other: Vector3): Float = (this - other).length()

    fun rotateX(radians: Float): Vector3 {
        val cos = cos(radians)
        val sin = sin(radians)
        return Vector3(x, y * cos - z * sin, y * sin + z * cos)
    }

    fun rotateY(radians: Float): Vector3 {
        val cos = cos(radians)
        val sin = sin(radians)
        return Vector3(x * cos + z * sin, y, -x * sin + z * cos)
    }

    fun rotateZ(radians: Float): Vector3 {
        val cos = cos(radians)
        val sin = sin(radians)
        return Vector3(x * cos - y * sin, x * sin + y * cos, z)
    }

    fun rotateEuler(degX: Float, degY: Float, degZ: Float): Vector3 {
        val radX = Math.toRadians(degX.toDouble()).toFloat()
        val radY = Math.toRadians(degY.toDouble()).toFloat()
        val radZ = Math.toRadians(degZ.toDouble()).toFloat()
        return this.rotateX(radX).rotateY(radY).rotateZ(radZ)
    }

    companion object {
        val ZERO = Vector3(0f, 0f, 0f)
        val ONE = Vector3(1f, 1f, 1f)
        val UP = Vector3(0f, 1f, 0f)
        val RIGHT = Vector3(1f, 0f, 0f)
        val FORWARD = Vector3(0f, 0f, 1f)

        fun lerp(start: Vector3, end: Vector3, t: Float): Vector3 {
            val clamped = t.coerceIn(0f, 1f)
            return start + (end - start) * clamped
        }
    }
}

/**
 * 4x4 Matrix for 3D Transformations and Perspective/Orthographic Projection.
 */
class Matrix4(val data: FloatArray = FloatArray(16) { 0f }) {

    init {
        if (data.all { it == 0f }) {
            // Default to Identity
            data[0] = 1f; data[5] = 1f; data[10] = 1f; data[15] = 1f
        }
    }

    operator fun times(other: Matrix4): Matrix4 {
        val result = FloatArray(16)
        for (row in 0..3) {
            for (col in 0..3) {
                var sum = 0f
                for (i in 0..3) {
                    sum += data[row + i * 4] * other.data[i + col * 4]
                }
                result[row + col * 4] = sum
            }
        }
        return Matrix4(result)
    }

    fun transformPoint(v: Vector3): Vector3 {
        val x = v.x * data[0] + v.y * data[4] + v.z * data[8] + data[12]
        val y = v.x * data[1] + v.y * data[5] + v.z * data[9] + data[13]
        val z = v.x * data[2] + v.y * data[6] + v.z * data[10] + data[14]
        val w = v.x * data[3] + v.y * data[7] + v.z * data[11] + data[15]

        return if (w != 0f && w != 1f) {
            Vector3(x / w, y / w, z / w)
        } else {
            Vector3(x, y, z)
        }
    }

    companion object {
        fun identity(): Matrix4 = Matrix4()

        fun translation(tx: Float, ty: Float, tz: Float): Matrix4 {
            val m = identity()
            m.data[12] = tx
            m.data[13] = ty
            m.data[14] = tz
            return m
        }

        fun scale(sx: Float, sy: Float, sz: Float): Matrix4 {
            val m = identity()
            m.data[0] = sx
            m.data[5] = sy
            m.data[10] = sz
            return m
        }

        fun rotationY(deg: Float): Matrix4 {
            val m = identity()
            val rad = Math.toRadians(deg.toDouble()).toFloat()
            val c = cos(rad)
            val s = sin(rad)
            m.data[0] = c
            m.data[2] = -s
            m.data[8] = s
            m.data[10] = c
            return m
        }

        fun perspective(fovDeg: Float, aspect: Float, near: Float, far: Float): Matrix4 {
            val m = FloatArray(16)
            val f = 1.0f / tan(Math.toRadians(fovDeg.toDouble() / 2.0)).toFloat()
            val rangeInv = 1.0f / (near - far)

            m[0] = f / aspect
            m[5] = f
            m[10] = (far + near) * rangeInv
            m[11] = -1f
            m[14] = (2.0f * far * near) * rangeInv
            return Matrix4(m)
        }

        fun orthographic(left: Float, right: Float, bottom: Float, top: Float, near: Float, far: Float): Matrix4 {
            val m = FloatArray(16)
            m[0] = 2f / (right - left)
            m[5] = 2f / (top - bottom)
            m[10] = -2f / (far - near)
            m[12] = -(right + left) / (right - left)
            m[13] = -(top + bottom) / (top - bottom)
            m[14] = -(far + near) / (far - near)
            m[15] = 1f
            return Matrix4(m)
        }

        fun lookAt(eye: Vector3, target: Vector3, up: Vector3): Matrix4 {
            val zAxis = (eye - target).normalize()
            val xAxis = up.cross(zAxis).normalize()
            val yAxis = zAxis.cross(xAxis)

            val m = identity()
            m.data[0] = xAxis.x
            m.data[4] = xAxis.y
            m.data[8] = xAxis.z
            m.data[12] = -xAxis.dot(eye)

            m.data[1] = yAxis.x
            m.data[5] = yAxis.y
            m.data[9] = yAxis.z
            m.data[13] = -yAxis.dot(eye)

            m.data[2] = zAxis.x
            m.data[6] = zAxis.y
            m.data[10] = zAxis.z
            m.data[14] = -zAxis.dot(eye)

            return m
        }
    }
}
