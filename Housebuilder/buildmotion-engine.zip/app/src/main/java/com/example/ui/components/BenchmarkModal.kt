package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.testing.BenchmarkResult

import com.example.ui.theme.*

@Composable
fun BenchmarkModal(
    result: BenchmarkResult?,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(420.dp)
                .wrapContentHeight()
                .testTag("benchmark_modal_dialog"),
            color = SurfaceDark,
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Speed, contentDescription = "Benchmark", tint = SageGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Performance & Diagnostic Audit", style = MaterialTheme.typography.titleMedium, color = TextPrimaryDark)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_benchmark")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextPrimaryDark)
                    }
                }

                HorizontalDivider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 12.dp))

                if (result != null) {
                    // Summary Banner
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Passed", tint = SageGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(result.testSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Diagnostic Metrics Grid
                    MetricRow("Total Scene Nodes", "${result.totalNodes}")
                    MetricRow("Instanced GPU Batches", "${result.instancedBatches}")
                    MetricRow("Framerate Estimate", "${String.format("%.1f", result.fpsEstimate)} FPS")
                    MetricRow("Frame Compute Time", "${String.format("%.2f", result.frameTimeMs)} ms")
                    MetricRow("Memory Allocation", "${String.format("%.1f", result.memoryEstimateMB)} MB")
                    MetricRow("Scene Graph Hierarchy", if (result.sceneGraphValid) "VALID (0 Orphans)" else "INVALID")
                    MetricRow("Timeline Sequence Order", if (result.animationSequenceValid) "VALID (0 Mismatches)" else "INVALID")

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = LavenderPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_done_benchmark")
                    ) {
                        Text("Close Audit Report", color = LavenderDarkText, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondaryDark)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold)
    }
}
