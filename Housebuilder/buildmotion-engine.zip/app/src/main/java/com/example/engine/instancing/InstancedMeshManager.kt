package com.example.engine.instancing

import com.example.engine.model.MeshShape
import com.example.engine.model.SceneNode
import com.example.engine.model.Vector3

data class RenderInstance(
    val node: SceneNode,
    val position: Vector3,
    val boundsSize: Vector3
)

data class InstanceBatch(
    val meshShape: MeshShape,
    val materialId: String,
    val instances: MutableList<RenderInstance> = mutableListOf()
)

class InstancedMeshManager {
    private val batches = mutableMapOf<String, InstanceBatch>()

    var instancedDrawCalls: Int = 0
        private set
    var totalInstancedObjects: Int = 0
        private set

    fun clear() {
        batches.clear()
        instancedDrawCalls = 0
        totalInstancedObjects = 0
    }

    fun addInstance(node: SceneNode, worldPos: Vector3) {
        val key = "${node.meshShape}_${node.material.id}"
        val batch = batches.getOrPut(key) {
            InstanceBatch(node.meshShape, node.material.id)
        }
        batch.instances.add(RenderInstance(node, worldPos, node.bounds.size))
        totalInstancedObjects++
    }

    fun finalizeBatches() {
        instancedDrawCalls = batches.size
    }

    fun getBatches(): Collection<InstanceBatch> = batches.values
}
