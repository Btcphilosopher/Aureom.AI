package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BuildMotionDarkColorScheme = darkColorScheme(
    primary = LavenderPrimary,
    onPrimary = LavenderDarkText,
    primaryContainer = SurfaceVariantDark,
    onPrimaryContainer = LavenderPrimary,
    secondary = SageGreen,
    onSecondary = SageGreenDark,
    secondaryContainer = SurfaceVariantDark,
    onSecondaryContainer = SageGreen,
    tertiary = SafetyOrange,
    background = DarkCanvas,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = SurfaceBorder
)

@Composable
fun BuildMotionTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BuildMotionDarkColorScheme,
        typography = Typography,
        content = content
    )
}

