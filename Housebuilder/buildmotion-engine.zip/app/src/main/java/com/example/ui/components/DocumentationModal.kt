package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

import com.example.ui.theme.*

@Composable
fun DocumentationModal(
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("documentation_modal_dialog"),
            color = SurfaceDark,
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BuildMotion Engine Technical Documentation",
                            style = MaterialTheme.typography.titleLarge,
                            color = LavenderPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Enterprise Digital Twin Architecture & API Guide",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_docs")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextPrimaryDark)
                    }
                }

                HorizontalDivider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Scrollable Content Body
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        DocSectionTitle("1. Scene Graph Architecture")
                        DocParagraph(
                            "The scene graph represents every physical element of the building as a spatial node in a parent-child hierarchy. " +
                            "Nodes store transform matrices (position, rotation, scale, pivot), PBR material definitions, construction phase metadata, " +
                            "trade classification, installation steps, and 3D bounding boxes."
                        )
                        DocCodeSnippet(
                            """
                            data class SceneNode(
                                val id: String = UUID.randomUUID().toString(),
                                val name: String,
                                val parentId: String? = null,
                                val transform: Transform3D = Transform3D(),
                                val material: Material,
                                val stage: ConstructionStage,
                                val installationStep: Int,
                                val metadata: NodeMetadata,
                                val bounds: BoundingBox3D
                            )
                            """.trimIndent()
                        )
                    }

                    item {
                        DocSectionTitle("2. Deterministic Animation Engine")
                        DocParagraph(
                            "Animations are generated strictly from structured building metadata rather than hand-scripted sequences. " +
                            "The engine tracks timeline step counters, calculating smooth fly-in trajectory vectors and opacity fades on a 60 FPS tick loop. " +
                            "Supports frame-based scrubbing, step stepping, 0.25x-8x speed control, reverse playback, and phase bookmarks."
                        )
                    }

                    item {
                        DocSectionTitle("3. Brick Placement & Assembly Pipeline")
                        DocParagraph(
                            "Outer leaf brickwork is simulated course-by-course with mortar alignment snapping. " +
                            "Each brick evaluates its installation step, calculating fly-down offsets and alignment relative to lintels and cavity insulation."
                        )
                    }

                    item {
                        DocSectionTitle("4. Camera & Projection Engine")
                        DocParagraph(
                            "The Camera Controller supports 3D Orbit, Pan, Zoom, Fly Mode, Walkthrough, and Orthographic Section elevation viewports. " +
                            "Calculates 4x4 View and Projection Matrices for perspective and orthographic rendering."
                        )
                    }

                    item {
                        DocSectionTitle("5. GPU Instancing & Performance")
                        DocParagraph(
                            "Groups thousands of identical bricks, Marley roof tiles, and timber joists into instanced rendering batches. " +
                            "Implements frustum culling, LOD0-LOD3 distance mesh reduction, and depth painter sorting for high frame rate rendering."
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DocSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = SageGreen,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Composable
private fun DocParagraph(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = TextPrimaryDark,
        lineHeight = 20.sp
    )
}

@Composable
private fun DocCodeSnippet(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceVariantDark, shape = RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Text(
            text = code,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = LavenderPrimary
        )
    }
}
