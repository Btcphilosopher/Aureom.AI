package com.example.engine.lod

import com.example.engine.model.SceneNode
import com.example.engine.model.Vector3

object LODManager {

    fun calculateLOD(node: SceneNode, cameraPos: Vector3): Int {
        val dist = (node.bounds.center - cameraPos).length()

        return when {
            dist < 8.0f -> 0 // LOD0: High detail
            dist < 20.0f -> 1 // LOD1: Medium detail
            dist < 40.0f -> 2 // LOD2: Low detail proxy
            else -> 3        // LOD3: Aggressive culling / proxy
        }
    }
}
