package com.example.engine.animation

import com.example.engine.model.ConstructionStage
import com.example.engine.model.SceneNode
import com.example.engine.model.Vector3
import com.example.engine.scene.SceneGraph
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlaybackState {
    PAUSED,
    PLAYING,
    REVERSE
}

data class TimelineBookmark(
    val title: String,
    val step: Int,
    val stage: ConstructionStage
)

class AnimationEngine(
    private val sceneGraph: SceneGraph
) {
    var maxTimelineSteps: Int = 100
        private set

    private val _currentStep = MutableStateFlow(1)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState.PAUSED)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f) // 0.25x, 0.5x, 1x, 2x, 4x, 8x
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _assemblyStyle = MutableStateFlow("BRICK_BY_BRICK") // "BRICK_BY_BRICK", "PER_COURSE", "PER_WALL"
    val assemblyStyle: StateFlow<String> = _assemblyStyle.asStateFlow()

    val bookmarks = mutableListOf<TimelineBookmark>()

    fun setMaxSteps(maxSteps: Int) {
        maxTimelineSteps = maxSteps.coerceAtLeast(1)
        generateBookmarks()
    }

    private fun generateBookmarks() {
        bookmarks.clear()
        for (stage in ConstructionStage.values()) {
            val stepForStage = (stage.sequenceIndex.toFloat() / ConstructionStage.values().size * maxTimelineSteps).toInt()
            bookmarks.add(TimelineBookmark(stage.phaseName, stepForStage.coerceIn(1, maxTimelineSteps), stage))
        }
    }

    fun play() {
        _playbackState.value = PlaybackState.PLAYING
    }

    fun pause() {
        _playbackState.value = PlaybackState.PAUSED
    }

    fun togglePlayPause() {
        if (_playbackState.value == PlaybackState.PLAYING) {
            pause()
        } else {
            play()
        }
    }

    fun reverse() {
        _playbackState.value = PlaybackState.REVERSE
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
    }

    fun setAssemblyStyle(style: String) {
        _assemblyStyle.value = style
    }

    fun seekToStep(step: Int) {
        _currentStep.value = step.coerceIn(1, maxTimelineSteps)
        updateNodeAnimationStates()
    }

    fun seekToProgress(progressFraction: Float) {
        val targetStep = (progressFraction * maxTimelineSteps).toInt()
        seekToStep(targetStep)
    }

    fun stepForward() {
        if (_currentStep.value < maxTimelineSteps) {
            _currentStep.value += 1
            updateNodeAnimationStates()
        } else {
            pause()
        }
    }

    fun stepBackward() {
        if (_currentStep.value > 1) {
            _currentStep.value -= 1
            updateNodeAnimationStates()
        }
    }

    /**
     * Called on each frame tick (e.g. 60 FPS loop).
     */
    fun tick(deltaSeconds: Float) {
        val state = _playbackState.value
        if (state == PlaybackState.PAUSED) return

        val speed = _playbackSpeed.value
        val stepDelta = deltaSeconds * 12.0f * speed

        if (state == PlaybackState.PLAYING) {
            val nextStep = _currentStep.value + stepDelta
            if (nextStep >= maxTimelineSteps) {
                _currentStep.value = maxTimelineSteps
                pause()
            } else {
                _currentStep.value = nextStep.toInt()
            }
        } else if (state == PlaybackState.REVERSE) {
            val nextStep = _currentStep.value - stepDelta
            if (nextStep <= 1) {
                _currentStep.value = 1
                pause()
            } else {
                _currentStep.value = nextStep.toInt()
            }
        }

        updateNodeAnimationStates()
    }

    /**
     * Smoothly calculates smooth fly-in offsets and opacities for components as they are being installed.
     */
    private fun updateNodeAnimationStates() {
        val step = _currentStep.value
        val nodes = sceneGraph.getAllNodes()

        for (node in nodes) {
            val installStep = node.installationStep
            val stepDiff = step - installStep

            if (stepDiff in 0..4) {
                // Currently animating placement: smooth fly down & fade-in
                val frac = stepDiff / 4.0f
                val flyStartOffset = Vector3(0f, 1.2f * (1.0f - frac), 0f)
                node.animationOffset = flyStartOffset
                node.animationOpacity = frac.coerceIn(0.2f, 1.0f)
            } else {
                node.animationOffset = Vector3.ZERO
                node.animationOpacity = 1.0f
            }
        }
    }

    val progressFraction: Float get() = _currentStep.value.toFloat() / maxTimelineSteps.toFloat()
}
