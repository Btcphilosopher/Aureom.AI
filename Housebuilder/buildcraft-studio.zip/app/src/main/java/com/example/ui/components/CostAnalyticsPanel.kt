package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConstructionTech
import com.example.engine.RAnalyticsEngine
import com.example.ui.theme.BlueprintCyan
import com.example.ui.theme.ComplianceGreen
import com.example.ui.theme.ConstructionOrange
import com.example.ui.theme.OverrunRed
import com.example.ui.theme.RiskAmber
import com.example.viewmodel.BuildCraftUiState

@Composable
fun CostAnalyticsPanel(
    uiState: BuildCraftUiState,
    onSelectTech: (ConstructionTech) -> Unit,
    modifier: Modifier = Modifier
) {
    val cost = uiState.costBreakdown
    val currency = uiState.activeCurrencySymbol
    val scrollState = rememberScrollState()

    val monteCarlo = RAnalyticsEngine.runMonteCarloCostRisk(cost.totalProjectCost)
    val sCurve = RAnalyticsEngine.calculateSCurveCashflow(cost.totalProjectCost)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Cost Elements Breakdown
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.BarChart, contentDescription = null, tint = ConstructionOrange)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "PROJECT COST STRUCTURE BREAKDOWN",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ConstructionOrange
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                CostProgressBarRow("Raw Materials", cost.totalMaterialCost, cost.totalProjectCost, ConstructionOrange, currency)
                CostProgressBarRow("Labour & Operatives", cost.totalLabourCost, cost.totalProjectCost, BlueprintCyan, currency)
                CostProgressBarRow("Plant & Equipment Hire", cost.plantAndEquipmentHire, cost.totalProjectCost, ComplianceGreen, currency)
                CostProgressBarRow("Site Overheads & Welfare", cost.siteOverheads, cost.totalProjectCost, RiskAmber, currency)
                CostProgressBarRow("Professional Fees", cost.professionalFees, cost.totalProjectCost, Color(0xFFD946EF), currency)
                CostProgressBarRow("Contingency Buffer (5%)", cost.contingencyBuffer, cost.totalProjectCost, OverrunRed, currency)
            }
        }

        // 2. Monte Carlo & S-Curve Cashflow Graphs Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Monte Carlo Percentile Box
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Assessment, contentDescription = null, tint = BlueprintCyan)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "R MONTE CARLO RISK",
                            style = MaterialTheme.typography.titleMedium,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlueprintCyan
                        )
                    }
                    Text(text = "1,000 Iterations Material Price Variance", style = MaterialTheme.typography.bodyMedium, fontSize = 9.sp)

                    Spacer(modifier = Modifier.height(10.dp))

                    MonteCarloBandRow("P10 (Optimistic -8%)", monteCarlo.first, ComplianceGreen, currency)
                    MonteCarloBandRow("P50 (Expected +2%)", monteCarlo.second, ConstructionOrange, currency)
                    MonteCarloBandRow("P90 (Pessimistic +18%)", monteCarlo.third, OverrunRed, currency)
                }
            }

            // S-Curve Canvas Graph
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ShowChart, contentDescription = null, tint = ComplianceGreen)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "20-WEEK CASHFLOW S-CURVE",
                            style = MaterialTheme.typography.titleMedium,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ComplianceGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(Color(0xFF0F172A))
                            .border(0.5.dp, Color(0xFF1E293B))
                    ) {
                        val w = size.width
                        val h = size.height
                        val maxVal = cost.totalProjectCost

                        val path = Path()
                        sCurve.forEachIndexed { idx, pair ->
                            val x = (pair.first / 20f) * w
                            val y = h - ((pair.second / maxVal) * h).toFloat()
                            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }

                        drawPath(path = path, color = ComplianceGreen, style = Stroke(width = 3f))
                    }
                }
            }
        }

        // 3. Scenario Comparison Matrix (Option A vs B vs C)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Compare, contentDescription = null, tint = ConstructionOrange)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "STRUCTURAL SCENARIO COMPARISON MATRIX",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ConstructionOrange
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                uiState.scenarios.forEach { scenario ->
                    val isCurrent = uiState.houseSpec.constructionTech == scenario.tech
                    val cardBorder = if (isCurrent) ConstructionOrange else MaterialTheme.colorScheme.outlineVariant

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) ConstructionOrange.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(1.dp, cardBorder, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = scenario.tech.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$currency${String.format("%,.0f", scenario.totalCost)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = ConstructionOrange
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Duration: ${scenario.buildDurationWeeks} Weeks | Embodied CO₂: ${scenario.embodiedCarbonTonnes}t | U-Value: ${scenario.thermalPerformanceUValue} W/m²K",
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 11.sp,
                                color = BlueprintCyan
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = scenario.keyAdvantage,
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CostProgressBarRow(
    label: String,
    amount: Double,
    total: Double,
    color: Color,
    currency: String
) {
    val pct = if (total > 0) amount / total else 0.0
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, fontSize = 11.sp)
            Text(
                text = "$currency${String.format("%,.0f", amount)} (${String.format("%.1f", pct * 100)}%)",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(pct.toFloat())
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun MonteCarloBandRow(label: String, amount: Double, color: Color, currency: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, fontSize = 10.sp, color = color)
        Text(
            text = "$currency${String.format("%,.0f", amount)}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}
