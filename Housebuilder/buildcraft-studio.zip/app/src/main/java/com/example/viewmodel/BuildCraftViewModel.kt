package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuditLogEntity
import com.example.data.local.BuildCraftDatabase
import com.example.data.local.ProjectEntity
import com.example.data.model.AuditLogRecord
import com.example.data.model.BuildingComponent
import com.example.data.model.BuildingLayer
import com.example.data.model.ConstructionStage
import com.example.data.model.ConstructionTech
import com.example.data.model.CostBreakdown
import com.example.data.model.HouseModelSpec
import com.example.data.model.QuantitySummaryItem
import com.example.data.model.ScenarioComparison
import com.example.engine.RAnalyticsEngine
import com.example.engine.RustGeometryEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DockTab(val displayName: String) {
    BIM_3D("3D BIM Viewer"),
    CAD_2D("2D Floorplan"),
    SEQUENCER("20-Stage Sequencer"),
    QUANTITY_SURVEY("Quantity Survey (BoQ)"),
    COST_ANALYTICS("Cost & R Analytics"),
    GANTT_SCHEDULE("Gantt Scheduler"),
    EXECUTIVE_DASHBOARD("Executive Dashboard"),
    AUDIT_LOGS("Audit & Permissions")
}

data class Orbit3DState(
    val pitchAngle: Float = 28f,
    val yawAngle: Float = 45f,
    val zoomLevel: Float = 1.0f,
    val explodedOffset: Float = 0f, // 0 = assembled, 1 = exploded
    val crossSectionCut: Float = 1.0f, // 1 = full, 0 = sliced
    val isNightLighting: Boolean = false,
    val isMeasurementToolActive: Boolean = false,
    val visibleLayers: Map<BuildingLayer, Boolean> = BuildingLayer.values().associateWith { true }
)

data class Cad2DState(
    val selectedTool: String = "SELECT", // SELECT, WALL, ROOM, DOOR, WINDOW, STAIRS
    val activeRoomName: String = "Master Lounge",
    val wallThicknessM: Double = 0.3,
    val snappedDimensionText: String = "12.00m x 9.00m"
)

data class BuildCraftUiState(
    val houseSpec: HouseModelSpec = HouseModelSpec(),
    val currentStageIndex: Int = 10,
    val isPlayingSequencer: Boolean = false,
    val activeDockTab: DockTab = DockTab.BIM_3D,
    val orbit3D: Orbit3DState = Orbit3DState(),
    val cad2D: Cad2DState = Cad2DState(),
    val components: List<BuildingComponent> = emptyList(),
    val costBreakdown: CostBreakdown = CostBreakdown(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    val billOfQuantities: List<QuantitySummaryItem> = emptyList(),
    val scenarios: List<ScenarioComparison> = emptyList(),
    val auditLogs: List<AuditLogRecord> = emptyList(),
    val isDarkMode: Boolean = true,
    val activeCurrencySymbol: String = "£"
)

class BuildCraftViewModel(application: Application) : AndroidViewModel(application) {

    private val db = BuildCraftDatabase.getDatabase(application)
    private val dao = db.projectDao()

    private val _uiState = MutableStateFlow(BuildCraftUiState())
    val uiState: StateFlow<BuildCraftUiState> = _uiState.asStateFlow()

    init {
        recalculateModel()
        loadInitialProjectFromDb()
    }

    private fun loadInitialProjectFromDb() {
        viewModelScope.launch {
            try {
                val entity = dao.getProjectById("default_house_01")
                if (entity != null) {
                    val tech = try {
                        ConstructionTech.valueOf(entity.constructionTechName)
                    } catch (e: Exception) {
                        ConstructionTech.TRADITIONAL_MASONRY
                    }
                    val updatedSpec = HouseModelSpec(
                        id = entity.id,
                        title = entity.title,
                        houseType = entity.houseType,
                        widthMeters = entity.widthMeters,
                        depthMeters = entity.depthMeters,
                        storyCount = entity.storyCount,
                        roofPitchDegrees = entity.roofPitchDegrees,
                        constructionTech = tech,
                        currentStageIndex = entity.currentStageIndex
                    )
                    _uiState.update { it.copy(houseSpec = updatedSpec, currentStageIndex = entity.currentStageIndex) }
                    recalculateModel()
                } else {
                    saveCurrentProjectToDb()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun selectDockTab(tab: DockTab) {
        _uiState.update { it.copy(activeDockTab = tab) }
    }

    fun setStageIndex(stage: Int) {
        val clampedStage = stage.coerceIn(1, 20)
        _uiState.update { it.copy(currentStageIndex = clampedStage) }
        recalculateModel()
        addAuditLog("STAGE_CHANGE", "Scrubbed construction sequencer to Stage $clampedStage: ${RustGeometryEngine.STAGES_20.find { it.stageNumber == clampedStage }?.name}")
    }

    fun toggleSequencerPlay() {
        _uiState.update { it.copy(isPlayingSequencer = !it.isPlayingSequencer) }
    }

    fun stepSequencerNext() {
        val next = (_uiState.value.currentStageIndex % 20) + 1
        setStageIndex(next)
    }

    fun updateHouseDimensions(widthM: Double, depthM: Double, stories: Int) {
        val oldWidth = _uiState.value.houseSpec.widthMeters
        val oldDepth = _uiState.value.houseSpec.depthMeters
        val newSpec = _uiState.value.houseSpec.copy(
            widthMeters = widthM.coerceIn(6.0, 30.0),
            depthMeters = depthM.coerceIn(5.0, 25.0),
            storyCount = stories.coerceIn(1, 4)
        )
        _uiState.update { it.copy(houseSpec = newSpec) }
        recalculateModel()
        saveCurrentProjectToDb()
        addAuditLog("DIMENSION_UPDATE", "Resized house dimensions from ${oldWidth}m x ${oldDepth}m to ${newSpec.widthMeters}m x ${newSpec.depthMeters}m (${newSpec.storyCount} stories)")
    }

    fun updateConstructionTech(tech: ConstructionTech) {
        val oldTech = _uiState.value.houseSpec.constructionTech
        val newSpec = _uiState.value.houseSpec.copy(constructionTech = tech)
        _uiState.update { it.copy(houseSpec = newSpec) }
        recalculateModel()
        saveCurrentProjectToDb()
        addAuditLog("TECH_UPDATE", "Switched structural building tech from ${oldTech.displayName} to ${tech.displayName}")
    }

    fun updateOrbitAngle(pitchDelta: Float, yawDelta: Float) {
        val current = _uiState.value.orbit3D
        _uiState.update {
            it.copy(
                orbit3D = current.copy(
                    pitchAngle = (current.pitchAngle + pitchDelta).coerceIn(5f, 85f),
                    yawAngle = (current.yawAngle + yawDelta) % 360f
                )
            )
        }
    }

    fun updateZoom(zoomDelta: Float) {
        val current = _uiState.value.orbit3D
        _uiState.update {
            it.copy(
                orbit3D = current.copy(
                    zoomLevel = (current.zoomLevel + zoomDelta).coerceIn(0.5f, 3.0f)
                )
            )
        }
    }

    fun setExplodedOffset(offset: Float) {
        _uiState.update {
            it.copy(orbit3D = it.orbit3D.copy(explodedOffset = offset.coerceIn(0f, 1f)))
        }
    }

    fun setCrossSectionCut(cut: Float) {
        _uiState.update {
            it.copy(orbit3D = it.orbit3D.copy(crossSectionCut = cut.coerceIn(0f, 1f)))
        }
    }

    fun toggleLayerVisibility(layer: BuildingLayer) {
        val currentMap = _uiState.value.orbit3D.visibleLayers.toMutableMap()
        currentMap[layer] = !(currentMap[layer] ?: true)
        _uiState.update {
            it.copy(orbit3D = it.orbit3D.copy(visibleLayers = currentMap))
        }
    }

    fun toggleDayNight() {
        _uiState.update {
            it.copy(orbit3D = it.orbit3D.copy(isNightLighting = !it.orbit3D.isNightLighting))
        }
    }

    fun setCadTool(tool: String) {
        _uiState.update {
            it.copy(cad2D = it.cad2D.copy(selectedTool = tool))
        }
    }

    fun toggleThemeMode() {
        _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
    }

    private fun recalculateModel() {
        val spec = _uiState.value.houseSpec
        val stage = _uiState.value.currentStageIndex
        val generatedComponents = RustGeometryEngine.generateComponentsForHouse(spec, stage)
        val cost = RAnalyticsEngine.calculateCostBreakdown(generatedComponents, spec)
        val boq = RAnalyticsEngine.generateBillOfQuantities(generatedComponents)
        val comparisons = RAnalyticsEngine.generateScenarioComparisons(spec, generatedComponents)

        _uiState.update {
            it.copy(
                components = generatedComponents,
                costBreakdown = cost,
                billOfQuantities = boq,
                scenarios = comparisons
            )
        }
    }

    private fun saveCurrentProjectToDb() {
        viewModelScope.launch {
            try {
                val spec = _uiState.value.houseSpec
                val entity = ProjectEntity(
                    id = spec.id,
                    title = spec.title,
                    houseType = spec.houseType,
                    widthMeters = spec.widthMeters,
                    depthMeters = spec.depthMeters,
                    storyCount = spec.storyCount,
                    roofPitchDegrees = spec.roofPitchDegrees,
                    constructionTechName = spec.constructionTech.name,
                    currentStageIndex = _uiState.value.currentStageIndex,
                    jsonMetadata = "{}",
                    lastUpdated = System.currentTimeMillis()
                )
                dao.insertOrUpdateProject(entity)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun addAuditLog(actionType: String, description: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss dd-MMM-yyyy", Locale.getDefault()).format(Date())
        val record = AuditLogRecord(
            timestamp = timestamp,
            author = "Lead BIM Architect (You)",
            actionType = actionType,
            description = description
        )
        val currentLogs = _uiState.value.auditLogs.toMutableList()
        currentLogs.add(0, record)
        _uiState.update { it.copy(auditLogs = currentLogs) }

        viewModelScope.launch {
            try {
                dao.insertAuditLog(
                    AuditLogEntity(
                        id = record.id,
                        projectId = _uiState.value.houseSpec.id,
                        timestamp = record.timestamp,
                        author = record.author,
                        actionType = record.actionType,
                        description = record.description,
                        previousValue = record.previousValue,
                        newValue = record.newValue
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
