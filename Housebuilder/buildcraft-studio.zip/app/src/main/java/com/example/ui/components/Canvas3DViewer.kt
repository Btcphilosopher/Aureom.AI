package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildingComponent
import com.example.data.model.BuildingLayer
import com.example.ui.theme.BlueprintCyan
import com.example.ui.theme.ComplianceGreen
import com.example.ui.theme.ConstructionOrange
import com.example.viewmodel.BuildCraftUiState
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Canvas3DViewer(
    uiState: BuildCraftUiState,
    onUpdateOrbit: (pitchDelta: Float, yawDelta: Float) -> Unit,
    onUpdateZoom: (zoomDelta: Float) -> Unit,
    onSetExploded: (Float) -> Unit,
    onSetCrossSection: (Float) -> Unit,
    onToggleLayer: (BuildingLayer) -> Unit,
    onToggleDayNight: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orbit = uiState.orbit3D
    val isNight = orbit.isNightLighting
    val bgColor = if (isNight) Color(0xFF030712) else Color(0xFF0F172A)
    val gridColor = if (isNight) Color(0xFF1F2937) else Color(0xFF1E293B)

    var showLayerFilter by remember { mutableStateOf(false) }
    var selectedComponentInfo by remember { mutableStateOf<BuildingComponent?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    onUpdateOrbit(-pan.y * 0.3f, pan.x * 0.3f)
                    if (zoom != 1.0f) {
                        onUpdateZoom((zoom - 1.0f) * 0.5f)
                    }
                }
            }
    ) {
        // 3D Canvas Renderer
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2f
            val centerY = canvasHeight / 2f + 40f

            // Draw CAD Blueprint Grid
            draw3DGrid(
                centerX = centerX,
                centerY = centerY,
                yaw = orbit.yawAngle,
                pitch = orbit.pitchAngle,
                zoom = orbit.zoomLevel,
                gridColor = gridColor
            )

            // Render 3D Building Components
            val radYaw = Math.toRadians(orbit.yawAngle.toDouble())
            val radPitch = Math.toRadians(orbit.pitchAngle.toDouble())
            val scale = 22f * orbit.zoomLevel

            // Sort components by depth Z to render back-to-front
            val visibleComponents = uiState.components.filter { comp ->
                orbit.visibleLayers[comp.layer] != false && comp.stageIndex <= uiState.currentStageIndex
            }

            visibleComponents.forEach { comp ->
                // Apply Exploded offset vertical boost
                val explodeOffsetY = when (comp.layer) {
                    BuildingLayer.SITE_PREP, BuildingLayer.FOUNDATION -> -10f * orbit.explodedOffset
                    BuildingLayer.SLAB -> 0f
                    BuildingLayer.MASONRY -> 25f * orbit.explodedOffset
                    BuildingLayer.TIMBER -> 55f * orbit.explodedOffset
                    BuildingLayer.ROOF -> 90f * orbit.explodedOffset
                    else -> 40f * orbit.explodedOffset
                }

                // Cross-section cut filter
                if (orbit.crossSectionCut < 0.95f && comp.widthMeters > (uiState.houseSpec.widthMeters * orbit.crossSectionCut)) {
                    // Sliced element preview
                }

                drawBuilding3DElement(
                    comp = comp,
                    centerX = centerX,
                    centerY = centerY - explodeOffsetY,
                    radYaw = radYaw,
                    radPitch = radPitch,
                    scale = scale,
                    specWidth = uiState.houseSpec.widthMeters,
                    specDepth = uiState.houseSpec.depthMeters,
                    isNight = isNight
                )
            }
        }

        // Overlay Controls & HUD
        // Top Left Status Badge
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .padding(12.dp)
                .align(Alignment.TopStart)
                .border(0.5.dp, BlueprintCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "3D BIM MODEL VIEW",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BlueprintCyan,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Pitch: ${orbit.pitchAngle.toInt()}° | Yaw: ${orbit.yawAngle.toInt()}° | Scale: ${String.format("%.1f", orbit.zoomLevel)}x",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Top Right Action Buttons (Layers, Lighting, Zoom)
        Row(
            modifier = Modifier
                .padding(12.dp)
                .align(Alignment.TopEnd),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = { showLayerFilter = !showLayerFilter },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                    .testTag("layers_filter_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = "Layers",
                    tint = if (showLayerFilter) ConstructionOrange else BlueprintCyan
                )
            }
            IconButton(
                onClick = onToggleDayNight,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                    .testTag("day_night_toggle")
            ) {
                Icon(
                    imageVector = if (isNight) Icons.Default.WbSunny else Icons.Default.NightsStay,
                    contentDescription = "Lighting",
                    tint = if (isNight) ConstructionOrange else BlueprintCyan
                )
            }
            IconButton(
                onClick = { onUpdateZoom(0.2f) },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom In", tint = MaterialTheme.colorScheme.onSurface)
            }
            IconButton(
                onClick = { onUpdateZoom(-0.2f) },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom Out", tint = MaterialTheme.colorScheme.onSurface)
            }
        }

        // Bottom Left Sliders Panel (Exploded View & Cross Section Cut)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .padding(12.dp)
                .width(260.dp)
                .align(Alignment.BottomStart)
                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "EXPLODED VIEW DISASSEMBLY",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = ConstructionOrange
                )
                Slider(
                    value = orbit.explodedOffset,
                    onValueChange = onSetExploded,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = ConstructionOrange, activeTrackColor = ConstructionOrange),
                    modifier = Modifier
                        .height(24.dp)
                        .testTag("exploded_view_slider")
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "CROSS-SECTION CUT PLANE",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BlueprintCyan
                )
                Slider(
                    value = orbit.crossSectionCut,
                    onValueChange = onSetCrossSection,
                    valueRange = 0.2f..1f,
                    colors = SliderDefaults.colors(thumbColor = BlueprintCyan, activeTrackColor = BlueprintCyan),
                    modifier = Modifier
                        .height(24.dp)
                        .testTag("cross_section_slider")
                )
            }
        }

        // Layers Filter Drawer Overlay
        if (showLayerFilter) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .padding(top = 60.dp, end = 12.dp)
                    .width(220.dp)
                    .align(Alignment.TopEnd)
                    .border(1.dp, ConstructionOrange, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "BUILDING LAYERS",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ConstructionOrange
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    BuildingLayer.values().forEach { layer ->
                        val isChecked = orbit.visibleLayers[layer] ?: true
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { onToggleLayer(layer) },
                                colors = CheckboxDefaults.colors(checkedColor = ConstructionOrange)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = layer.displayName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.draw3DGrid(
    centerX: Float,
    centerY: Float,
    yaw: Float,
    pitch: Float,
    zoom: Float,
    gridColor: Color
) {
    val radYaw = Math.toRadians(yaw.toDouble())
    val radPitch = Math.toRadians(pitch.toDouble())
    val step = 20f * zoom
    val lines = 12

    for (i in -lines..lines) {
        val x1 = (i * step * cos(radYaw) - (-lines * step) * sin(radYaw)).toFloat()
        val y1 = ((i * step * sin(radYaw) + (-lines * step) * cos(radYaw)) * sin(radPitch)).toFloat()

        val x2 = (i * step * cos(radYaw) - (lines * step) * sin(radYaw)).toFloat()
        val y2 = ((i * step * sin(radYaw) + (lines * step) * cos(radYaw)) * sin(radPitch)).toFloat()

        drawLine(
            color = gridColor,
            start = Offset(centerX + x1, centerY + y1),
            end = Offset(centerX + x2, centerY + y2),
            strokeWidth = 1f
        )
    }
}

private fun DrawScope.drawBuilding3DElement(
    comp: BuildingComponent,
    centerX: Float,
    centerY: Float,
    radYaw: Double,
    radPitch: Double,
    scale: Float,
    specWidth: Double,
    specDepth: Double,
    isNight: Boolean
) {
    val w = comp.widthMeters.toFloat() * scale
    val d = comp.depthMeters.toFloat() * scale
    val h = comp.heightMeters.toFloat() * scale

    // Project 3D box coordinates
    val cosY = cos(radYaw)
    val sinY = sin(radYaw)
    val sinP = sin(radPitch)

    val color = when (comp.layer) {
        BuildingLayer.SITE_PREP -> Color(0xFF78350F)
        BuildingLayer.FOUNDATION -> Color(0xFF475569)
        BuildingLayer.SLAB -> Color(0xFF94A3B8)
        BuildingLayer.MASONRY -> Color(0xFFD97706)
        BuildingLayer.TIMBER -> Color(0xFFB45309)
        BuildingLayer.ROOF -> Color(0xFF0284C7)
        BuildingLayer.OPENINGS -> Color(0xFF38BDF8)
        BuildingLayer.SERVICES -> Color(0xFF059669)
        BuildingLayer.FINISHES -> Color(0xFFD946EF)
        BuildingLayer.LANDSCAPING -> Color(0xFF15803D)
    }

    // Convert 3D point (x, y, z) to isometric screen offset
    fun project(x: Float, y: Float, z: Float): Offset {
        val sx = (x * cosY - z * sinY).toFloat()
        val sy = ((x * sinY + z * cosY) * sinP - y).toFloat()
        return Offset(centerX + sx, centerY + sy)
    }

    val halfW = w / 2f
    val halfD = d / 2f
    val baseZ = when (comp.layer) {
        BuildingLayer.SITE_PREP -> -15f
        BuildingLayer.FOUNDATION -> -10f
        BuildingLayer.SLAB -> 0f
        BuildingLayer.MASONRY -> 5f
        BuildingLayer.TIMBER -> 45f
        BuildingLayer.ROOF -> 90f
        else -> 30f
    }

    // Top Face
    val p1 = project(-halfW, baseZ + h, -halfD)
    val p2 = project(halfW, baseZ + h, -halfD)
    val p3 = project(halfW, baseZ + h, halfD)
    val p4 = project(-halfW, baseZ + h, halfD)

    val topPath = Path().apply {
        moveTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p3.x, p3.y)
        lineTo(p4.x, p4.y)
        close()
    }

    drawPath(path = topPath, color = color.copy(alpha = 0.85f))
    drawPath(path = topPath, color = Color.White.copy(alpha = 0.3f), style = Stroke(width = 1.5f))

    // Front Face
    val p5 = project(-halfW, baseZ, halfD)
    val p6 = project(halfW, baseZ, halfD)

    val frontPath = Path().apply {
        moveTo(p4.x, p4.y)
        lineTo(p3.x, p3.y)
        lineTo(p6.x, p6.y)
        lineTo(p5.x, p5.y)
        close()
    }

    drawPath(path = frontPath, color = color.copy(alpha = 0.65f))
    drawPath(path = frontPath, color = Color.Black.copy(alpha = 0.3f), style = Stroke(width = 1.2f))
}
