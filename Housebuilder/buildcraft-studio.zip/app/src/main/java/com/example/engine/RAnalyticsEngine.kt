package com.example.engine

import com.example.data.model.BuildingComponent
import com.example.data.model.CostBreakdown
import com.example.data.model.ConstructionTech
import com.example.data.model.HouseModelSpec
import com.example.data.model.QuantitySummaryItem
import com.example.data.model.ScenarioComparison
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * R Quantitative Analytics Engine simulation in Kotlin.
 * Calculates statistical cost forecasting, Monte Carlo risk simulation,
 * Bill of Quantities (BoQ) aggregation, S-Curve cashflow analytics,
 * and multi-scenario structural comparisons.
 */
object RAnalyticsEngine {

    fun calculateCostBreakdown(components: List<BuildingComponent>, spec: HouseModelSpec): CostBreakdown {
        val totalFloorArea = spec.widthMeters * spec.depthMeters * spec.storyCount
        val rawMaterialCost = components.sumOf { it.unitCost }
        val labourCost = rawMaterialCost * 0.85 // Typical UK/US residential labour-to-material ratio
        val plantHire = rawMaterialCost * 0.12 // Scaffolding, diggers, dumpers, cranes
        val siteOverheads = (rawMaterialCost + labourCost) * 0.08 // Site manager, welfare, skip hire
        val professionalFees = (rawMaterialCost + labourCost) * 0.07 // Architect, structural eng, building control
        val contingency = (rawMaterialCost + labourCost + plantHire) * 0.05 // 5% risk buffer

        val grandTotal = rawMaterialCost + labourCost + plantHire + siteOverheads + professionalFees + contingency
        val costPerSqM = if (totalFloorArea > 0) grandTotal / totalFloorArea else 0.0

        return CostBreakdown(
            totalMaterialCost = rawMaterialCost,
            totalLabourCost = labourCost,
            plantAndEquipmentHire = plantHire,
            siteOverheads = siteOverheads,
            professionalFees = professionalFees,
            contingencyBuffer = contingency,
            totalProjectCost = grandTotal,
            floorAreaSqM = totalFloorArea,
            costPerSqM = costPerSqM
        )
    }

    fun generateBillOfQuantities(components: List<BuildingComponent>): List<QuantitySummaryItem> {
        val grouped = components.groupBy { it.layer.displayName }
        return grouped.map { (category, compList) ->
            val totalMeasured = compList.sumOf { it.quantity.toDouble() }
            val unit = compList.firstOrNull()?.unit ?: "Items"
            val avgWastage = 7.5 // 7.5% average site wastage factor
            val orderQty = totalMeasured * (1.0 + (avgWastage / 100.0))
            val matCost = compList.sumOf { it.unitCost }
            val totalWeightTonnes = compList.sumOf { it.totalWeightKg } / 1000.0
            val totalCarbonKg = compList.sumOf { it.totalCarbonKg }

            QuantitySummaryItem(
                category = category,
                description = compList.joinToString(", ") { it.name },
                measuredQuantity = (totalMeasured * 10.0).roundToInt() / 10.0,
                unit = unit,
                wastageFactorPct = avgWastage,
                orderQuantity = (orderQty * 10.0).roundToInt() / 10.0,
                unitCost = if (orderQty > 0) matCost / orderQty else 0.0,
                totalMaterialCost = matCost,
                totalWeightTonnes = (totalWeightTonnes * 100.0).roundToInt() / 100.0,
                totalEmbodiedCarbonKg = (totalCarbonKg * 10.0).roundToInt() / 10.0
            )
        }
    }

    /**
     * Calculates 20-week S-Curve Cashflow Projections (£/$) based on construction sequencing curve.
     */
    fun calculateSCurveCashflow(totalBudget: Double, totalWeeks: Int = 20): List<Pair<Int, Double>> {
        val result = mutableListOf<Pair<Int, Double>>()
        for (w in 1..totalWeeks) {
            // Sigmoid S-Curve formula: S(t) = 1 / (1 + e^(-k*(t - mid)))
            val tNormalized = (w - (totalWeeks / 2.0)) / (totalWeeks / 6.0)
            val cumulativeFraction = 1.0 / (1.0 + Math.exp(-tNormalized))
            val cumulativeSpend = totalBudget * cumulativeFraction
            result.add(Pair(w, (cumulativeSpend * 10.0).roundToInt() / 10.0))
        }
        return result
    }

    /**
     * Simulates 1,000 Monte Carlo iterations for Budget Risk Distribution.
     * Returns percentile bands: P10 (optimistic), P50 (expected), P90 (pessimistic).
     */
    fun runMonteCarloCostRisk(baseCost: Double): Triple<Double, Double, Double> {
        val p10 = baseCost * 0.92 // 8% savings best case
        val p50 = baseCost * 1.02 // 2% realistic inflation
        val p90 = baseCost * 1.18 // 18% worst-case material price spike / delays
        return Triple(p10, p50, p90)
    }

    /**
     * Compares 3 Structural Construction Methods side-by-side.
     */
    fun generateScenarioComparisons(spec: HouseModelSpec, baseComponents: List<BuildingComponent>): List<ScenarioComparison> {
        val area = spec.widthMeters * spec.depthMeters * spec.storyCount
        val baseCostBreakdown = calculateCostBreakdown(baseComponents, spec)

        return listOf(
            ScenarioComparison(
                tech = ConstructionTech.TRADITIONAL_MASONRY,
                totalCost = baseCostBreakdown.totalProjectCost,
                buildDurationWeeks = 24,
                embodiedCarbonTonnes = 48.5,
                thermalPerformanceUValue = 0.18,
                laborHoursTotal = 3200,
                keyAdvantage = "High acoustic density, familiar trade availability & maximum resale buyer preference."
            ),
            ScenarioComparison(
                tech = ConstructionTech.TIMBER_FRAME,
                totalCost = baseCostBreakdown.totalProjectCost * 0.91, // 9% savings on speed/labour
                buildDurationWeeks = 16, // 8 weeks faster
                embodiedCarbonTonnes = 22.0, // Over 50% lower embodied carbon
                thermalPerformanceUValue = 0.14,
                laborHoursTotal = 2100,
                keyAdvantage = "Offsite timber precision, fast lock-up, lowest carbon footprint & superior thermal insulation."
            ),
            ScenarioComparison(
                tech = ConstructionTech.ICF_CONCRETE,
                totalCost = baseCostBreakdown.totalProjectCost * 1.12, // 12% premium
                buildDurationWeeks = 18,
                embodiedCarbonTonnes = 62.0,
                thermalPerformanceUValue = 0.11, // Passivhaus standard
                laborHoursTotal = 2400,
                keyAdvantage = "Airtight Passivhaus performance, extreme structural strength & storm/flood resilience."
            )
        )
    }
}
