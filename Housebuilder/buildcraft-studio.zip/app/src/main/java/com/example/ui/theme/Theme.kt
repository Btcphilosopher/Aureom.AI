package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = TechnicalPurpleAccent,
    onPrimary = TechnicalPurpleOnAccent,
    primaryContainer = DarkSurfaceContainer,
    onPrimaryContainer = TechnicalPurpleAccent,
    secondary = ConstructionOrange,
    onSecondary = DarkCanvasBg,
    tertiary = SteelGray,
    background = DarkCanvasBg,
    onBackground = TechnicalTextPrimary,
    surface = DarkSurfaceContainer,
    onSurface = TechnicalTextPrimary,
    surfaceVariant = DarkCardContainer,
    onSurfaceVariant = TechnicalSubtext,
    outline = TechnicalBorderOutline,
    outlineVariant = TechnicalBorderOutline,
    error = OverrunRed
)

private val LightColorScheme = lightColorScheme(
    primary = TechnicalPurpleOnAccent,
    onPrimary = LightCanvasBg,
    primaryContainer = LightSurfaceContainer,
    onPrimaryContainer = TechnicalPurpleOnAccent,
    secondary = ConstructionOrange,
    onSecondary = LightCanvasBg,
    tertiary = TechnicalSubtext,
    background = LightCanvasBg,
    onBackground = TechnicalPurpleOnAccent,
    surface = LightSurfaceContainer,
    onSurface = TechnicalPurpleOnAccent,
    surfaceVariant = LightCardContainer,
    onSurfaceVariant = TechnicalSubtext,
    outline = TechnicalBorderOutline,
    outlineVariant = TechnicalBorderOutline,
    error = OverrunRed
)

@Composable
fun BuildCraftTheme(
    darkTheme: Boolean = true, // Default to dark Technical Dashboard theme
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
