package com.example.engine

import com.example.data.model.BuildingComponent
import com.example.data.model.BuildingLayer
import com.example.data.model.ConstructionStage
import com.example.data.model.ConstructionTech
import com.example.data.model.HouseModelSpec
import com.example.data.model.MaterialItem
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Rust Core Engine Geometry & Parametric Building Modeling simulation in Kotlin.
 * Computes exact 3D Mesh vertices, exploded view vector offsets, cross-section planes,
 * and 20-stage construction sequenced components.
 */
object RustGeometryEngine {

    val STAGES_20 = listOf(
        ConstructionStage(1, "Site Preparation", "Substructure", "Site clearance, topsoil strip, perimeter setting out & reduced level dig.", "Groundworks Crew", 4, 3, listOf("Site boundary secured", "Soil level survey completed", "Temporary water/power connected")),
        ConstructionStage(2, "Foundations", "Substructure", "Excavate trench foundations, pour C30 ready-mix concrete, lay sub-grade engineering bricks.", "Concrete & Groundworks", 5, 5, listOf("Trench depth verified (1.0m)", "Building control inspection approved", "Concrete pour completed")),
        ConstructionStage(3, "Drainage", "Substructure", "Lay foul & surface water pipework, manholes, pea shingle bedding & backfill.", "Plumbers & Groundworks", 3, 4, listOf("100mm PVC pipe gradient 1:40", "Air water pressure test passed", "Manhole chambers built")),
        ConstructionStage(4, "Floor Slab", "Substructure", "Hardcore bed, sand blinding, DPM membrane, PIR insulation, floor screed & power float.", "Groundworks & Concrete", 4, 3, listOf("120mm PIR insulation laid", "DPM lap sealed to DPC", "Structural slab poured")),
        ConstructionStage(5, "External Walls", "Substructure to DPC", "Raise cavity masonry/walls to DPC level with airbricks & radon barriers.", "Bricklayers", 6, 6, listOf("DPC laid at 150mm above GL", "Cavity ties spaced @ 900mm", "Air vents installed")),
        ConstructionStage(6, "Structural Frame", "Superstructure", "Erect main superstructure loadbearing walls (brickwork or offsite timber studs).", "Bricklayers / Carpenters", 8, 12, listOf("Wall plumbness verified", "Lintels installed over openings", "Hold-down straps fixed")),
        ConstructionStage(7, "Floors", "Superstructure", "Install C24 joists or floor cassettes, OSB subfloor decking & acoustic insulation.", "Carpenters", 4, 4, listOf("Joist hangers secured", "22mm moisture-resistant OSB glued", "Perimeter expansion gap left")),
        ConstructionStage(8, "Roof Structure", "Superstructure", "Erect roof trusses, valley rafters, wall plates, bargeboards & gable ladders.", "Carpenters / Structural", 6, 6, listOf("Truss bracing nailed to spec", "Gable straps fixed to masonry", "Fascia & soffit boards mounted")),
        ConstructionStage(9, "Windows & Doors", "Weatherproofing", "Fit double/triple glazed A-rated windows, composite front door & rear bi-folds.", "Window Fitters", 3, 3, listOf("Frame perimeter expanding foam sealed", "DPC cavity closers checked", "Glazing level & squareness verified")),
        ConstructionStage(10, "Roof Covering", "Weatherproofing", "Lay breathable membrane, counter battens, slate tiles & ridge caps. House now watertight!", "Roofers", 4, 5, listOf("Membrane lap 150mm minimum", "Tile battens nailed @ 300mm", "Lead flashing completed at chimneys")),
        ConstructionStage(11, "First Fix Services", "Services MEP", "Route first-fix electrical cables, copper water pipes, HVAC ducting & waste pipes.", "Electricians & Plumbers", 4, 8, listOf("Cable zones followed", "Pipe pressure test 6 bar", "Backing boxes installed")),
        ConstructionStage(12, "Insulation", "Enclosure", "Fit PIR wall cavity insulation, loft quilt roll & perimeter thermal break panels.", "Dryliners & Insulation", 3, 3, listOf("Vapour barrier stapled & taped", "No cold bridging gaps", "Loft insulation 300mm thickness")),
        ConstructionStage(13, "Plasterboard", "Enclosure", "Fix 12.5mm fire-rated plasterboard to walls/ceilings & apply multi-finish plaster skim.", "Plasterers", 4, 6, listOf("Scrim tape over joints", "Drywall screws 230mm centers", "2mm skim coat fully dried")),
        ConstructionStage(14, "Second Fix Plumbing", "Fitout", "Install sanitaryware, showers, radiators, boiler, kitchen sink & taps.", "Plumbers", 3, 4, listOf("Boiler commissioned & certified", "Sanitary leak testing passed", "TRV valves tested")),
        ConstructionStage(15, "Second Fix Electrical", "Fitout", "Fit light switches, socket faceplates, consumer unit, LED spotlights & smoke alarms.", "Electricians", 3, 3, listOf("NICEIC electrical certificate issued", "RCD trip testing verified", "Lighting zones tested")),
        ConstructionStage(16, "Kitchens", "Internal Finishes", "Erect kitchen cabinetry, granite/quartz worktops, integrated appliances & splashbacks.", "Kitchen Specialists", 3, 4, listOf("Base units leveled", "Worktop joint seamlessly glued", "Appliance safety checks completed")),
        ConstructionStage(17, "Bathrooms", "Internal Finishes", "Tile floor & shower walls, seal silicone joints, fit vanity units & heated towel rails.", "Tilers & Plumbers", 3, 5, listOf("Tanking membrane applied in wet areas", "Tile grout sealed", "Extract fan flow rate tested")),
        ConstructionStage(18, "Flooring & Joinery", "Decoration", "Fit engineered oak flooring, carpet underlay, skirting boards, architraves & internal doors.", "Carpenters & Flooring", 3, 4, listOf("Door gaps set to 3mm", "Skirting scribed & caulked", "Underfloor heating zone test")),
        ConstructionStage(19, "Decoration", "Decoration", "Apply mist coat primer, 2 coats washable emulsion, satinwood trim paint & final clean.", "Decorators", 3, 4, listOf("Surface preparation sanded smooth", "Paint color matching verified", "Snagging checklist resolved")),
        ConstructionStage(20, "External Works & Inspection", "Completion", "Pave block driveway, turf lawn, boundary fencing, final inspection & handover certificate.", "Landscape & Inspector", 4, 3, listOf("Building Control Completion Certificate", "EPC Rating A/B confirmed", "Client keys handover"))
    )

    fun getDefaultMaterials(): Map<String, MaterialItem> {
        return mapOf(
            "brick_facing" to MaterialItem("brick_facing", "Facing Bricks (Ibstock Red)", "Masonry", "1000 Bricks", 680.0, 2400.0, 480.0, 2, 5.0),
            "block_breeze" to MaterialItem("block_breeze", "Thermalite Dense Concrete Blocks", "Masonry", "100 Blocks", 190.0, 1400.0, 280.0, 1, 5.0),
            "timber_c24" to MaterialItem("timber_c24", "C24 Structural Timber 47x195mm", "Timber", "Linear Metre", 8.5, 5.2, 1.2, 1, 8.0),
            "concrete_c30" to MaterialItem("concrete_c30", "Ready-Mix C30/37 Concrete", "Concrete", "Cubic Metre", 125.0, 2400.0, 310.0, 1, 3.0),
            "insulation_pir" to MaterialItem("insulation_pir", "Kingspan 100mm PIR Insulation Board", "Insulation", "Sq Metre", 22.0, 3.8, 14.5, 2, 6.0),
            "roof_slate" to MaterialItem("roof_slate", "Natural Spanish Slate Tiles 500x250", "Roofing", "100 Tiles", 210.0, 320.0, 45.0, 3, 7.0),
            "window_unit" to MaterialItem("window_unit", "A+ Rated Smart PVC Window Unit", "Windows", "Unit", 450.0, 42.0, 85.0, 4, 0.0),
            "door_composite" to MaterialItem("door_composite", "High Security Composite External Door", "Doors", "Unit", 950.0, 55.0, 110.0, 3, 0.0),
            "plasterboard_12" to MaterialItem("plasterboard_12", "Gyproc 12.5mm FireLine Plasterboard", "Finishes", "Sq Metre", 7.8, 8.5, 2.1, 1, 10.0)
        )
    }

    /**
     * Rust parametric building geometry mesh generator.
     * Generates all building components based on house spec and active construction stage.
     */
    fun generateComponentsForHouse(spec: HouseModelSpec, targetStage: Int): List<BuildingComponent> {
        val components = mutableListOf<BuildingComponent>()
        val width = spec.widthMeters
        val depth = spec.depthMeters
        val stories = spec.storyCount
        val materials = getDefaultMaterials()

        // Stage 1: Site Prep
        if (targetStage >= 1) {
            components.add(
                BuildingComponent(
                    name = "Excavated Site Footprint",
                    layer = BuildingLayer.SITE_PREP,
                    stageIndex = 1,
                    widthMeters = width + 3.0,
                    heightMeters = 0.3,
                    depthMeters = depth + 3.0,
                    quantity = 1,
                    unit = "Site",
                    materialId = "site_dig",
                    materialName = "Excavated Earth",
                    unitCost = 1200.0,
                    totalWeightKg = 0.0,
                    totalCarbonKg = 45.0
                )
            )
        }

        // Stage 2: Foundations
        if (targetStage >= 2) {
            val perimeter = (width + depth) * 2
            val trenchVolume = perimeter * 0.6 * 1.0 // 0.6m wide, 1.0m deep
            val concreteCost = trenchVolume * (materials["concrete_c30"]?.unitPrice ?: 125.0)
            components.add(
                BuildingComponent(
                    name = "Trench Concrete Footings (C30)",
                    layer = BuildingLayer.FOUNDATION,
                    stageIndex = 2,
                    widthMeters = width,
                    heightMeters = 1.0,
                    depthMeters = depth,
                    quantity = trenchVolume.toInt(),
                    unit = "m³",
                    materialId = "concrete_c30",
                    materialName = materials["concrete_c30"]?.name ?: "Concrete C30",
                    unitCost = concreteCost,
                    totalWeightKg = trenchVolume * 2400.0,
                    totalCarbonKg = trenchVolume * 310.0
                )
            )
        }

        // Stage 3: Drainage
        if (targetStage >= 3) {
            components.add(
                BuildingComponent(
                    name = "Foul & Storm Underground Pipes (100mm PVC)",
                    layer = BuildingLayer.SERVICES,
                    stageIndex = 3,
                    widthMeters = width + 4.0,
                    heightMeters = 0.1,
                    depthMeters = depth + 4.0,
                    quantity = 45,
                    unit = "Metres",
                    materialId = "pvc_pipe",
                    materialName = "100mm Underground PVC Pipe",
                    unitCost = 850.0,
                    totalWeightKg = 180.0,
                    totalCarbonKg = 95.0
                )
            )
        }

        // Stage 4: Slab
        if (targetStage >= 4) {
            val area = width * depth
            val slabVolume = area * 0.15
            components.add(
                BuildingComponent(
                    name = "Insulated Ground Floor Slab (150mm)",
                    layer = BuildingLayer.SLAB,
                    stageIndex = 4,
                    widthMeters = width,
                    heightMeters = 0.15,
                    depthMeters = depth,
                    quantity = area.toInt(),
                    unit = "m²",
                    materialId = "concrete_c30",
                    materialName = "Insulated Concrete Slab",
                    unitCost = area * 45.0,
                    totalWeightKg = slabVolume * 2400.0,
                    totalCarbonKg = slabVolume * 310.0
                )
            )
        }

        // Stage 5: Substructure Masonry
        if (targetStage >= 5) {
            val perimeter = (width + depth) * 2
            val wallArea = perimeter * 0.6
            val blocksNeeded = (wallArea * 10).toInt()
            components.add(
                BuildingComponent(
                    name = "Substructure Masonry & Radon Membrane",
                    layer = BuildingLayer.MASONRY,
                    stageIndex = 5,
                    widthMeters = width,
                    heightMeters = 0.6,
                    depthMeters = depth,
                    quantity = blocksNeeded,
                    unit = "Blocks",
                    materialId = "block_breeze",
                    materialName = "Dense Substructure Blocks",
                    unitCost = (blocksNeeded / 100.0) * 190.0,
                    totalWeightKg = blocksNeeded * 14.0,
                    totalCarbonKg = blocksNeeded * 2.8
                )
            )
        }

        // Stage 6: Structural Frame / Superstructure Walls
        if (targetStage >= 6) {
            val perimeter = (width + depth) * 2
            val wallHeight = stories * 2.8
            val totalWallArea = perimeter * wallHeight
            val brickCount = (totalWallArea * 60).toInt() // 60 bricks per m2 for facing
            val brickCost = (brickCount / 1000.0) * (materials["brick_facing"]?.unitPrice ?: 680.0)

            val wallType = if (spec.constructionTech == ConstructionTech.TIMBER_FRAME) {
                "Offsite Timber Stud Frame Outer Brick Shell"
            } else if (spec.constructionTech == ConstructionTech.ICF_CONCRETE) {
                "Insulated Concrete Formwork Wall Core"
            } else {
                "Cavity Facing Brickwork & Thermalite Inner Leaf"
            }

            components.add(
                BuildingComponent(
                    name = wallType,
                    layer = BuildingLayer.MASONRY,
                    stageIndex = 6,
                    widthMeters = width,
                    heightMeters = wallHeight,
                    depthMeters = depth,
                    quantity = brickCount,
                    unit = "Bricks",
                    materialId = "brick_facing",
                    materialName = materials["brick_facing"]?.name ?: "Facing Bricks",
                    unitCost = brickCost,
                    totalWeightKg = brickCount * 2.4,
                    totalCarbonKg = brickCount * 0.48
                )
            )
        }

        // Stage 7: Floors / Joists
        if (targetStage >= 7 && stories > 1) {
            val floorArea = width * depth * (stories - 1)
            val linearMetersJoists = (floorArea / 0.4) * width // 400mm joist centers
            val joistCost = linearMetersJoists * (materials["timber_c24"]?.unitPrice ?: 8.5)
            components.add(
                BuildingComponent(
                    name = "First Floor Joist Cassettes & OSB3 Decking",
                    layer = BuildingLayer.TIMBER,
                    stageIndex = 7,
                    widthMeters = width,
                    heightMeters = 0.25,
                    depthMeters = depth,
                    quantity = floorArea.toInt(),
                    unit = "m²",
                    materialId = "timber_c24",
                    materialName = "C24 Structural Timber Joists",
                    unitCost = joistCost,
                    totalWeightKg = linearMetersJoists * 5.2,
                    totalCarbonKg = linearMetersJoists * 1.2
                )
            )
        }

        // Stage 8: Roof Trusses
        if (targetStage >= 8) {
            val roofArea = width * depth * 1.25 // pitch factor
            val trussCount = (width / 0.6).toInt() + 1
            components.add(
                BuildingComponent(
                    name = "Pre-engineered Gang-Nail Roof Trusses (${spec.roofPitchDegrees}° Pitch)",
                    layer = BuildingLayer.ROOF,
                    stageIndex = 8,
                    widthMeters = width,
                    heightMeters = 2.5,
                    depthMeters = depth,
                    quantity = trussCount,
                    unit = "Trusses",
                    materialId = "timber_c24",
                    materialName = "Engineered Timber Trusses",
                    unitCost = trussCount * 145.0,
                    totalWeightKg = trussCount * 48.0,
                    totalCarbonKg = trussCount * 12.0
                )
            )
        }

        // Stage 9: Windows & Doors
        if (targetStage >= 9) {
            val windowUnits = 12 * stories
            val windowCost = windowUnits * (materials["window_unit"]?.unitPrice ?: 450.0)
            components.add(
                BuildingComponent(
                    name = "A-Rated Double Glazed Windows & Doors Package",
                    layer = BuildingLayer.OPENINGS,
                    stageIndex = 9,
                    widthMeters = 1.2,
                    heightMeters = 1.5,
                    depthMeters = 0.1,
                    quantity = windowUnits,
                    unit = "Units",
                    materialId = "window_unit",
                    materialName = "Smart PVC Window Package",
                    unitCost = windowCost + 1800.0, // includes front/rear doors
                    totalWeightKg = windowUnits * 42.0 + 110.0,
                    totalCarbonKg = windowUnits * 85.0 + 220.0
                )
            )
        }

        // Stage 10: Roof Tiles
        if (targetStage >= 10) {
            val roofArea = width * depth * 1.25
            val tilesCount = (roofArea * 18).toInt() // 18 slates per m2
            val tileCost = (tilesCount / 100.0) * (materials["roof_slate"]?.unitPrice ?: 210.0)
            components.add(
                BuildingComponent(
                    name = "Natural Spanish Slate Roof Tiles & Breathable Felt",
                    layer = BuildingLayer.ROOF,
                    stageIndex = 10,
                    widthMeters = width,
                    heightMeters = 0.05,
                    depthMeters = depth,
                    quantity = tilesCount,
                    unit = "Tiles",
                    materialId = "roof_slate",
                    materialName = "Spanish Slate 500x250",
                    unitCost = tileCost,
                    totalWeightKg = tilesCount * 3.2,
                    totalCarbonKg = tilesCount * 0.45
                )
            )
        }

        // Stage 11: First Fix Services
        if (targetStage >= 11) {
            val totalFloorArea = width * depth * stories
            components.add(
                BuildingComponent(
                    name = "First Fix Electrical Cabling & Copper Plumbing Routes",
                    layer = BuildingLayer.SERVICES,
                    stageIndex = 11,
                    widthMeters = width,
                    heightMeters = 0.05,
                    depthMeters = depth,
                    quantity = totalFloorArea.toInt(),
                    unit = "m² floor",
                    materialId = "copper_mep",
                    materialName = "Copper Pipe & Ring Main Cable",
                    unitCost = totalFloorArea * 42.0,
                    totalWeightKg = totalFloorArea * 2.8,
                    totalCarbonKg = totalFloorArea * 14.0
                )
            )
        }

        // Stage 12: Insulation
        if (targetStage >= 12) {
            val wallArea = (width + depth) * 2 * stories * 2.8
            val insulationCost = wallArea * (materials["insulation_pir"]?.unitPrice ?: 22.0)
            components.add(
                BuildingComponent(
                    name = "Kingspan 100mm PIR Cavity Insulation & Vapour Layer",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 12,
                    widthMeters = width,
                    heightMeters = 0.1,
                    depthMeters = depth,
                    quantity = wallArea.toInt(),
                    unit = "m²",
                    materialId = "insulation_pir",
                    materialName = "Kingspan PIR Board",
                    unitCost = insulationCost,
                    totalWeightKg = wallArea * 3.8,
                    totalCarbonKg = wallArea * 14.5
                )
            )
        }

        // Stage 13: Plasterboard
        if (targetStage >= 13) {
            val internalSurfaceArea = width * depth * stories * 3.2
            val pbCost = internalSurfaceArea * (materials["plasterboard_12"]?.unitPrice ?: 7.8)
            components.add(
                BuildingComponent(
                    name = "12.5mm Plasterboard & Multi-Finish Plaster Skim",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 13,
                    widthMeters = width,
                    heightMeters = 0.015,
                    depthMeters = depth,
                    quantity = internalSurfaceArea.toInt(),
                    unit = "m²",
                    materialId = "plasterboard_12",
                    materialName = "Gyproc Plasterboard",
                    unitCost = pbCost,
                    totalWeightKg = internalSurfaceArea * 8.5,
                    totalCarbonKg = internalSurfaceArea * 2.1
                )
            )
        }

        // Stage 14: Second Fix Plumbing
        if (targetStage >= 14) {
            components.add(
                BuildingComponent(
                    name = "Sanitaryware, Gas Boiler & Designer Radiators",
                    layer = BuildingLayer.SERVICES,
                    stageIndex = 14,
                    widthMeters = 1.0,
                    heightMeters = 1.0,
                    depthMeters = 1.0,
                    quantity = 3,
                    unit = "Bathrooms",
                    materialId = "sanitary_pkg",
                    materialName = "Luxury Sanitary & Heating Package",
                    unitCost = 6500.0,
                    totalWeightKg = 380.0,
                    totalCarbonKg = 410.0
                )
            )
        }

        // Stage 15: Second Fix Electrical
        if (targetStage >= 15) {
            components.add(
                BuildingComponent(
                    name = "Brushed Steel Sockets, Downlights & Consumer Unit",
                    layer = BuildingLayer.SERVICES,
                    stageIndex = 15,
                    widthMeters = 1.0,
                    heightMeters = 1.0,
                    depthMeters = 1.0,
                    quantity = 1,
                    unit = "Full House",
                    materialId = "elec_second_fix",
                    materialName = "Smart Switches & LED Lighting Package",
                    unitCost = 3200.0,
                    totalWeightKg = 65.0,
                    totalCarbonKg = 120.0
                )
            )
        }

        // Stage 16: Kitchens
        if (targetStage >= 16) {
            components.add(
                BuildingComponent(
                    name = "Kitchen Cabinets, Quartz Island Worktops & Appliances",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 16,
                    widthMeters = 4.5,
                    heightMeters = 2.1,
                    depthMeters = 3.0,
                    quantity = 1,
                    unit = "Kitchen",
                    materialId = "kitchen_suite",
                    materialName = "German Handless Kitchen & Quartz",
                    unitCost = 14500.0,
                    totalWeightKg = 680.0,
                    totalCarbonKg = 520.0
                )
            )
        }

        // Stage 17: Bathrooms
        if (targetStage >= 17) {
            components.add(
                BuildingComponent(
                    name = "Porcelain Wall/Floor Tiling & Walk-In Glass Showers",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 17,
                    widthMeters = 3.0,
                    heightMeters = 2.4,
                    depthMeters = 2.5,
                    quantity = 3,
                    unit = "Bathrooms",
                    materialId = "bathroom_tiles",
                    materialName = "Italian Porcelain Tiles",
                    unitCost = 4200.0,
                    totalWeightKg = 450.0,
                    totalCarbonKg = 180.0
                )
            )
        }

        // Stage 18: Flooring & Joinery
        if (targetStage >= 18) {
            val area = width * depth * stories
            components.add(
                BuildingComponent(
                    name = "Engineered Oak Flooring & Ogee Skirting Boards",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 18,
                    widthMeters = width,
                    heightMeters = 0.02,
                    depthMeters = depth,
                    quantity = area.toInt(),
                    unit = "m²",
                    materialId = "oak_flooring",
                    materialName = "Engineered European Oak",
                    unitCost = area * 55.0,
                    totalWeightKg = area * 12.0,
                    totalCarbonKg = area * 4.2
                )
            )
        }

        // Stage 19: Decoration
        if (targetStage >= 19) {
            val area = width * depth * stories * 3.2
            components.add(
                BuildingComponent(
                    name = "Dulux Trade Matt Emulsion Paint & Satin Trim",
                    layer = BuildingLayer.FINISHES,
                    stageIndex = 19,
                    widthMeters = width,
                    heightMeters = 0.001,
                    depthMeters = depth,
                    quantity = area.toInt(),
                    unit = "m² paint",
                    materialId = "paint_trade",
                    materialName = "Dulux Washable Trade Paint",
                    unitCost = area * 4.5,
                    totalWeightKg = area * 0.4,
                    totalCarbonKg = area * 0.8
                )
            )
        }

        // Stage 20: External Works
        if (targetStage >= 20) {
            components.add(
                BuildingComponent(
                    name = "Permeable Block Paving Driveway & Turf Landscaping",
                    layer = BuildingLayer.LANDSCAPING,
                    stageIndex = 20,
                    widthMeters = width + 6.0,
                    heightMeters = 0.08,
                    depthMeters = 8.0,
                    quantity = 1,
                    unit = "Grounds",
                    materialId = "paving_blocks",
                    materialName = "Marshalls Driveway Paving & Lawn",
                    unitCost = 6800.0,
                    totalWeightKg = 3200.0,
                    totalCarbonKg = 480.0
                )
            )
        }

        return components
    }
}
