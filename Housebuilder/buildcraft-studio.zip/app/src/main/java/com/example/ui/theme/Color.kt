package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Technical Dashboard / Data Grid Theme Colors (from Design Theme Specification)
val DarkCanvasBg = Color(0xFF1C1B1F)
val DarkSurfaceContainer = Color(0xFF2B2930)
val DarkCardContainer = Color(0xFF211F26)
val TechnicalPurpleAccent = Color(0xFFD0BCFE)
val TechnicalPurpleOnAccent = Color(0xFF381E72)
val TechnicalBorderOutline = Color(0xFF49454F)
val TechnicalSubtext = Color(0xFF938F99)
val TechnicalTextPrimary = Color(0xFFE6E1E5)

// Functional Accent Status Colors
val ConstructionOrange = Color(0xFFFDBA74) // Warm technical orange highlight
val ConstructionOrangeDark = Color(0xFF381E72)
val BlueprintCyan = Color(0xFFD0BCFE) // Accent Purple/Cyan for tech indicators
val BlueprintCyanLight = Color(0xFFE8DEF8)
val SteelGray = Color(0xFF938F99)

// Light Mode Fallback Colors
val LightCanvasBg = Color(0xFFFEF7FF)
val LightSurfaceContainer = Color(0xFFF3EDF7)
val LightCardContainer = Color(0xFFE7E0EC)

// Status Indicators
val ComplianceGreen = Color(0xFF4ADE80)
val RiskAmber = Color(0xFFFDBA74)
val OverrunRed = Color(0xFFF2B8B5)
