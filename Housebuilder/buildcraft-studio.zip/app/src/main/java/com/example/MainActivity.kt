package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.components.AuditLogView
import com.example.ui.components.Canvas2DFloorplan
import com.example.ui.components.Canvas3DViewer
import com.example.ui.components.CostAnalyticsPanel
import com.example.ui.components.DockableNavigationRail
import com.example.ui.components.EngineeringHeader
import com.example.ui.components.ExecutiveDashboardView
import com.example.ui.components.GanttSchedulerView
import com.example.ui.components.QuantitySurveyingTable
import com.example.ui.components.SequencerBar
import com.example.ui.theme.BuildCraftTheme
import com.example.viewmodel.BuildCraftViewModel
import com.example.viewmodel.DockTab
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: BuildCraftViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val context = LocalContext.current
            val snackbarHostState = remember { SnackbarHostState() }
            val coroutineScope = rememberCoroutineScope()

            // Auto-play sequencer loop if enabled
            LaunchedEffect(uiState.isPlayingSequencer, uiState.currentStageIndex) {
                if (uiState.isPlayingSequencer) {
                    delay(2000)
                    viewModel.stepSequencerNext()
                }
            }

            BuildCraftTheme(darkTheme = uiState.isDarkMode) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        EngineeringHeader(
                            uiState = uiState,
                            onToggleTheme = { viewModel.toggleThemeMode() },
                            onExportReport = {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Exporting complete Bill of Quantities & Executive PDF Report...")
                                }
                            }
                        )
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Left Dock Rail Navigation
                        DockableNavigationRail(
                            activeTab = uiState.activeDockTab,
                            onTabSelected = { viewModel.selectDockTab(it) }
                        )

                        // Main Studio Active Tab View Area
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                when (uiState.activeDockTab) {
                                    DockTab.BIM_3D -> {
                                        Canvas3DViewer(
                                            uiState = uiState,
                                            onUpdateOrbit = { pitch, yaw -> viewModel.updateOrbitAngle(pitch, yaw) },
                                            onUpdateZoom = { zoom -> viewModel.updateZoom(zoom) },
                                            onSetExploded = { offset -> viewModel.setExplodedOffset(offset) },
                                            onSetCrossSection = { cut -> viewModel.setCrossSectionCut(cut) },
                                            onToggleLayer = { layer -> viewModel.toggleLayerVisibility(layer) },
                                            onToggleDayNight = { viewModel.toggleDayNight() }
                                        )
                                    }

                                    DockTab.CAD_2D -> {
                                        Canvas2DFloorplan(
                                            uiState = uiState,
                                            onSetTool = { viewModel.setCadTool(it) },
                                            onUpdateDimensions = { w, d, s -> viewModel.updateHouseDimensions(w, d, s) }
                                        )
                                    }

                                    DockTab.SEQUENCER -> {
                                        Canvas3DViewer(
                                            uiState = uiState,
                                            onUpdateOrbit = { pitch, yaw -> viewModel.updateOrbitAngle(pitch, yaw) },
                                            onUpdateZoom = { zoom -> viewModel.updateZoom(zoom) },
                                            onSetExploded = { offset -> viewModel.setExplodedOffset(offset) },
                                            onSetCrossSection = { cut -> viewModel.setCrossSectionCut(cut) },
                                            onToggleLayer = { layer -> viewModel.toggleLayerVisibility(layer) },
                                            onToggleDayNight = { viewModel.toggleDayNight() }
                                        )
                                    }

                                    DockTab.QUANTITY_SURVEY -> {
                                        QuantitySurveyingTable(uiState = uiState)
                                    }

                                    DockTab.COST_ANALYTICS -> {
                                        CostAnalyticsPanel(
                                            uiState = uiState,
                                            onSelectTech = { viewModel.updateConstructionTech(it) }
                                        )
                                    }

                                    DockTab.GANTT_SCHEDULE -> {
                                        GanttSchedulerView(uiState = uiState)
                                    }

                                    DockTab.EXECUTIVE_DASHBOARD -> {
                                        ExecutiveDashboardView(
                                            uiState = uiState,
                                            onExportPdf = {
                                                coroutineScope.launch {
                                                    snackbarHostState.showSnackbar("Generated PDF Executive Report. Saved to Downloads.")
                                                }
                                            },
                                            onExportCsv = {
                                                coroutineScope.launch {
                                                    snackbarHostState.showSnackbar("Exported Bill of Quantities CSV file.")
                                                }
                                            }
                                        )
                                    }

                                    DockTab.AUDIT_LOGS -> {
                                        AuditLogView(uiState = uiState)
                                    }
                                }
                            }

                            // Persistent 20-Stage Construction Sequencer Footer (for BIM 3D, CAD 2D, and Stage views)
                            if (uiState.activeDockTab in listOf(DockTab.BIM_3D, DockTab.CAD_2D, DockTab.SEQUENCER)) {
                                SequencerBar(
                                    currentStageIndex = uiState.currentStageIndex,
                                    isPlaying = uiState.isPlayingSequencer,
                                    onSetStage = { viewModel.setStageIndex(it) },
                                    onTogglePlay = { viewModel.toggleSequencerPlay() },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
