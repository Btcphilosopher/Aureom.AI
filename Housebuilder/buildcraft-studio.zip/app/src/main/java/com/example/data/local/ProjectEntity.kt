package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val houseType: String,
    val widthMeters: Double,
    val depthMeters: Double,
    val storyCount: Int,
    val roofPitchDegrees: Double,
    val constructionTechName: String,
    val currentStageIndex: Int,
    val jsonMetadata: String, // Store detailed JSON overrides
    val lastUpdated: Long
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val timestamp: String,
    val author: String,
    val actionType: String,
    val description: String,
    val previousValue: String,
    val newValue: String
)
