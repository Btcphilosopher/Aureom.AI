package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Stairs
import androidx.compose.material.icons.filled.Window
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueprintCyan
import com.example.ui.theme.ComplianceGreen
import com.example.ui.theme.ConstructionOrange
import com.example.viewmodel.BuildCraftUiState

@Composable
fun Canvas2DFloorplan(
    uiState: BuildCraftUiState,
    onSetTool: (String) -> Unit,
    onUpdateDimensions: (widthM: Double, depthM: Double, stories: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val spec = uiState.houseSpec
    val cadState = uiState.cad2D

    var widthInput by remember(spec.widthMeters) { mutableStateOf(spec.widthMeters.toFloat()) }
    var depthInput by remember(spec.depthMeters) { mutableStateOf(spec.depthMeters.toFloat()) }
    var storiesInput by remember(spec.storyCount) { mutableStateOf(spec.storyCount) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        // CAD 2D Grid Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height
            val centerX = canvasW / 2f
            val centerY = canvasH / 2f

            val scale = 24f // pixels per metre
            val housePixelW = spec.widthMeters.toFloat() * scale
            val housePixelH = spec.depthMeters.toFloat() * scale

            val rectLeft = centerX - housePixelW / 2f
            val rectTop = centerY - housePixelH / 2f

            // 1. Draw CAD Grid
            val gridStep = 1.0f * scale
            for (x in 0..(canvasW / gridStep).toInt()) {
                drawLine(
                    color = Color(0xFF1E293B),
                    start = Offset(x * gridStep, 0f),
                    end = Offset(x * gridStep, canvasH),
                    strokeWidth = 0.8f
                )
            }
            for (y in 0..(canvasH / gridStep).toInt()) {
                drawLine(
                    color = Color(0xFF1E293B),
                    start = Offset(0f, y * gridStep),
                    end = Offset(canvasW, y * gridStep),
                    strokeWidth = 0.8f
                )
            }

            // 2. Outer Cavity Walls
            drawRect(
                color = ConstructionOrange,
                topLeft = Offset(rectLeft, rectTop),
                size = Size(housePixelW, housePixelH),
                style = Stroke(width = 8f)
            )

            // Inner Wall Line (Cavity offset)
            drawRect(
                color = BlueprintCyan,
                topLeft = Offset(rectLeft + 6f, rectTop + 6f),
                size = Size(housePixelW - 12f, housePixelH - 12f),
                style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 5f)))
            )

            // 3. Interior Partition Rooms
            val roomW = housePixelW / 2f
            val roomH = housePixelH / 2f

            // Partitions
            drawLine(
                color = Color.White.copy(alpha = 0.8f),
                start = Offset(rectLeft + roomW, rectTop),
                end = Offset(rectLeft + roomW, rectTop + housePixelH),
                strokeWidth = 4f
            )
            drawLine(
                color = Color.White.copy(alpha = 0.8f),
                start = Offset(rectLeft, rectTop + roomH),
                end = Offset(rectLeft + housePixelW, rectTop + roomH),
                strokeWidth = 4f
            )

            // 4. Dimension Markers Callout Lines
            val dimOffset = 30f
            // Top width dimension
            drawLine(
                color = BlueprintCyan,
                start = Offset(rectLeft, rectTop - dimOffset),
                end = Offset(rectLeft + housePixelW, rectTop - dimOffset),
                strokeWidth = 1.5f
            )
            // Left depth dimension
            drawLine(
                color = BlueprintCyan,
                start = Offset(rectLeft - dimOffset, rectTop),
                end = Offset(rectLeft - dimOffset, rectTop + housePixelH),
                strokeWidth = 1.5f
            )
        }

        // Top CAD Toolbar
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(0.92f)
                .align(Alignment.TopCenter)
                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CadToolChip(
                    name = "Select",
                    icon = Icons.Default.PanTool,
                    isSelected = cadState.selectedTool == "SELECT",
                    onClick = { onSetTool("SELECT") }
                )
                CadToolChip(
                    name = "Wall / Boundary",
                    icon = Icons.Default.AspectRatio,
                    isSelected = cadState.selectedTool == "WALL",
                    onClick = { onSetTool("WALL") }
                )
                CadToolChip(
                    name = "Doorway",
                    icon = Icons.Default.MeetingRoom,
                    isSelected = cadState.selectedTool == "DOOR",
                    onClick = { onSetTool("DOOR") }
                )
                CadToolChip(
                    name = "Window",
                    icon = Icons.Default.Window,
                    isSelected = cadState.selectedTool == "WINDOW",
                    onClick = { onSetTool("WINDOW") }
                )
                CadToolChip(
                    name = "Staircase",
                    icon = Icons.Default.Stairs,
                    isSelected = cadState.selectedTool == "STAIRS",
                    onClick = { onSetTool("STAIRS") }
                )
            }
        }

        // Bottom Dimension Adjuster Drawer
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(0.88f)
                .align(Alignment.BottomCenter)
                .border(1.dp, BlueprintCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PARAMETRIC CAD DIMENSIONS",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueprintCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Footprint: ${String.format("%.1f", spec.widthMeters * spec.depthMeters)} m² | Enclosure: ${spec.storyCount} Storey",
                        style = MaterialTheme.typography.labelSmall,
                        color = ComplianceGreen
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Width: ${String.format("%.1f", widthInput)}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Slider(
                            value = widthInput,
                            onValueChange = {
                                widthInput = it
                                onUpdateDimensions(it.toDouble(), depthInput.toDouble(), storiesInput)
                            },
                            valueRange = 6f..24f,
                            colors = SliderDefaults.colors(thumbColor = ConstructionOrange, activeTrackColor = ConstructionOrange),
                            modifier = Modifier
                                .height(24.dp)
                                .testTag("cad_width_slider")
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Depth: ${String.format("%.1f", depthInput)}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Slider(
                            value = depthInput,
                            onValueChange = {
                                depthInput = it
                                onUpdateDimensions(widthInput.toDouble(), it.toDouble(), storiesInput)
                            },
                            valueRange = 5f..20f,
                            colors = SliderDefaults.colors(thumbColor = BlueprintCyan, activeTrackColor = BlueprintCyan),
                            modifier = Modifier
                                .height(24.dp)
                                .testTag("cad_depth_slider")
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Stories",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row {
                            Button(
                                onClick = {
                                    if (storiesInput > 1) {
                                        storiesInput--
                                        onUpdateDimensions(widthInput.toDouble(), depthInput.toDouble(), storiesInput)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("-")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$storiesInput",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = {
                                    if (storiesInput < 4) {
                                        storiesInput++
                                        onUpdateDimensions(widthInput.toDouble(), depthInput.toDouble(), storiesInput)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("+")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CadToolChip(
    name: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (isSelected) ConstructionOrange else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = name, tint = fg, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = name, style = MaterialTheme.typography.labelSmall, color = fg, fontSize = 10.sp)
    }
}
