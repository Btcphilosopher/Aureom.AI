package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.RustGeometryEngine
import com.example.ui.theme.BlueprintCyan
import com.example.ui.theme.ComplianceGreen
import com.example.ui.theme.ConstructionOrange
import com.example.ui.theme.OverrunRed
import com.example.viewmodel.BuildCraftUiState

@Composable
fun GanttSchedulerView(
    uiState: BuildCraftUiState,
    modifier: Modifier = Modifier
) {
    val stages = RustGeometryEngine.STAGES_20
    val totalWeeks = 20

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Banner Header
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.DateRange, contentDescription = null, tint = ConstructionOrange)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "CRITICAL PATH METHOD (CPM) SCHEDULER",
                            style = MaterialTheme.typography.titleMedium,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ConstructionOrange,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Master 20-Week Construction Timeline & Trade Dependencies",
                            style = MaterialTheme.typography.bodyMedium,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(OverrunRed)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Critical Path", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)

                    Spacer(modifier = Modifier.width(12.dp))

                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(BlueprintCyan)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Standard Task", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Week Scale Bar Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(vertical = 6.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "STAGE / TRADE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
            Row(modifier = Modifier.weight(3f), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (w in 1..totalWeeks step 2) {
                    Text(text = "W$w", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Gantt Rows
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(MaterialTheme.colorScheme.surface)
                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            items(stages) { stage ->
                val startWeek = stage.stageNumber
                val isCritical = stage.stageNumber in listOf(2, 4, 6, 8, 10, 13, 20)
                val isCompleted = stage.stageNumber <= uiState.currentStageIndex

                val barColor = when {
                    isCompleted -> ComplianceGreen
                    isCritical -> OverrunRed
                    else -> BlueprintCyan
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.2.dp, MaterialTheme.colorScheme.outlineVariant)
                        .padding(vertical = 6.dp, horizontal = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(2f)) {
                            Text(
                                text = "${stage.stageNumber}. ${stage.name}",
                                style = MaterialTheme.typography.titleMedium,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCritical) OverrunRed else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stage.requiredTrade,
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Gantt Bar Visualizer
                        Box(
                            modifier = Modifier
                                .weight(3f)
                                .height(16.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            val startFraction = (startWeek - 1) / 20f
                            val durationFraction = 1f / 20f

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(durationFraction)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(barColor)
                            )
                        }
                    }
                }
            }
        }
    }
}
