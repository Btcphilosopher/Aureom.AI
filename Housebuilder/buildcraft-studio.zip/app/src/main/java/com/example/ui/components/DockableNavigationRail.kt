package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ConstructionOrange
import com.example.viewmodel.DockTab

@Composable
fun DockableNavigationRail(
    activeTab: DockTab,
    onTabSelected: (DockTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(72.dp)
            .fillMaxHeight()
            .padding(start = 8.dp, top = 4.dp, end = 4.dp, bottom = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        DockNavItem(
            tab = DockTab.BIM_3D,
            icon = Icons.Default.ViewInAr,
            isSelected = activeTab == DockTab.BIM_3D,
            onClick = { onTabSelected(DockTab.BIM_3D) }
        )
        DockNavItem(
            tab = DockTab.CAD_2D,
            icon = Icons.Default.SquareFoot,
            isSelected = activeTab == DockTab.CAD_2D,
            onClick = { onTabSelected(DockTab.CAD_2D) }
        )
        DockNavItem(
            tab = DockTab.SEQUENCER,
            icon = Icons.Default.VideoLibrary,
            isSelected = activeTab == DockTab.SEQUENCER,
            onClick = { onTabSelected(DockTab.SEQUENCER) }
        )
        DockNavItem(
            tab = DockTab.QUANTITY_SURVEY,
            icon = Icons.Default.ListAlt,
            isSelected = activeTab == DockTab.QUANTITY_SURVEY,
            onClick = { onTabSelected(DockTab.QUANTITY_SURVEY) }
        )
        DockNavItem(
            tab = DockTab.COST_ANALYTICS,
            icon = Icons.Default.ShowChart,
            isSelected = activeTab == DockTab.COST_ANALYTICS,
            onClick = { onTabSelected(DockTab.COST_ANALYTICS) }
        )
        DockNavItem(
            tab = DockTab.GANTT_SCHEDULE,
            icon = Icons.Default.DateRange,
            isSelected = activeTab == DockTab.GANTT_SCHEDULE,
            onClick = { onTabSelected(DockTab.GANTT_SCHEDULE) }
        )
        DockNavItem(
            tab = DockTab.EXECUTIVE_DASHBOARD,
            icon = Icons.Default.Dashboard,
            isSelected = activeTab == DockTab.EXECUTIVE_DASHBOARD,
            onClick = { onTabSelected(DockTab.EXECUTIVE_DASHBOARD) }
        )
        Spacer(modifier = Modifier.weight(1f))
        DockNavItem(
            tab = DockTab.AUDIT_LOGS,
            icon = Icons.Default.Security,
            isSelected = activeTab == DockTab.AUDIT_LOGS,
            onClick = { onTabSelected(DockTab.AUDIT_LOGS) }
        )
    }
}

@Composable
private fun DockNavItem(
    tab: DockTab,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeBg = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
    val activeTint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = Modifier
            .padding(vertical = 3.dp)
            .size(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(activeBg)
            .clickable { onClick() }
            .testTag("dock_tab_${tab.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = tab.displayName,
                tint = activeTint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = when (tab) {
                    DockTab.BIM_3D -> "Model"
                    DockTab.CAD_2D -> "CAD"
                    DockTab.SEQUENCER -> "Sequence"
                    DockTab.QUANTITY_SURVEY -> "BoQ"
                    DockTab.COST_ANALYTICS -> "Stats"
                    DockTab.GANTT_SCHEDULE -> "Gantt"
                    DockTab.EXECUTIVE_DASHBOARD -> "Exec"
                    DockTab.AUDIT_LOGS -> "Audit"
                },
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = activeTint
            )
        }
    }
}
