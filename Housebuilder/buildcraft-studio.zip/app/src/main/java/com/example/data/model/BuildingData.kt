package com.example.data.model

import java.util.UUID

enum class ConstructionTech(val displayName: String, val description: String, val avgCostPerSqM: Double, val ecoRating: String) {
    TRADITIONAL_MASONRY("Traditional Cavity Brick & Block", "Dense block inner leaf, insulated cavity, brickwork outer leaf. High thermal mass.", 1850.0, "B+"),
    TIMBER_FRAME("Modern Offsite Timber Frame", "Precision engineered timber stud wall frame, OSB sheathing, brick/clad exterior. Rapid build.", 1680.0, "A+"),
    ICF_CONCRETE("Insulated Concrete Formwork (ICF)", "Interlocking EPS foam blocks poured with reinforced concrete. Exceptional air tightness.", 2100.0, "A")
}

enum class BuildingLayer(val id: String, val displayName: String, val colorHex: String) {
    SITE_PREP("site", "Site & Groundworks", "#78350F"),
    FOUNDATION("foundations", "Substructure & Foundations", "#475569"),
    SLAB("slab", "Concrete Slabs & Screed", "#64748B"),
    MASONRY("masonry", "Brickwork & Cavity Walls", "#B45309"),
    TIMBER("timber", "Structural Timber & Joists", "#D97706"),
    ROOF("roof", "Trusses, Felt & Tiles", "#1E293B"),
    OPENINGS("openings", "Windows & External Doors", "#0284C7"),
    SERVICES("mep", "Plumbing, Electrical & HVAC", "#059669"),
    FINISHES("finishes", "Plasterboard, Paint & Trim", "#D946EF"),
    LANDSCAPING("landscaping", "Paving & External Works", "#15803D")
}

data class MaterialItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val unit: String,
    val unitPrice: Double, // in £ or $
    val weightKgPerUnit: Double,
    val carbonKgCo2ePerUnit: Double, // Embodied Carbon
    val leadTimeWeeks: Int,
    val wastageAllowancePct: Double = 5.0,
    val supplier: String = "BuildCraft National Supply"
)

data class BuildingComponent(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val layer: BuildingLayer,
    val stageIndex: Int, // 1 to 20
    val widthMeters: Double,
    val heightMeters: Double,
    val depthMeters: Double,
    val quantity: Int,
    val unit: String,
    val materialId: String,
    val materialName: String,
    val unitCost: Double,
    val totalWeightKg: Double,
    val totalCarbonKg: Double,
    val isSelected: Boolean = false
)

data class ConstructionStage(
    val stageNumber: Int, // 1 to 20
    val name: String,
    val category: String,
    val description: String,
    val requiredTrade: String,
    val recommendedCrewSize: Int,
    val estimatedDays: Int,
    val keyChecklist: List<String>,
    val progressPct: Float = 0f,
    val isMilestone: Boolean = false
)

data class ScheduleTask(
    val id: String = UUID.randomUUID().toString(),
    val stageNumber: Int,
    val taskName: String,
    val startDay: Int,
    val durationDays: Int,
    val requiredTrade: String,
    val progressPct: Float = 0f,
    val dependencies: List<String> = emptyList(),
    val isCriticalPath: Boolean = false
)

data class QuantitySummaryItem(
    val category: String,
    val description: String,
    val measuredQuantity: Double,
    val unit: String,
    val wastageFactorPct: Double,
    val orderQuantity: Double,
    val unitCost: Double,
    val totalMaterialCost: Double,
    val totalWeightTonnes: Double,
    val totalEmbodiedCarbonKg: Double
)

data class CostBreakdown(
    val totalMaterialCost: Double,
    val totalLabourCost: Double,
    val plantAndEquipmentHire: Double,
    val siteOverheads: Double,
    val professionalFees: Double,
    val contingencyBuffer: Double,
    val totalProjectCost: Double,
    val floorAreaSqM: Double,
    val costPerSqM: Double
)

data class ScenarioComparison(
    val tech: ConstructionTech,
    val totalCost: Double,
    val buildDurationWeeks: Int,
    val embodiedCarbonTonnes: Double,
    val thermalPerformanceUValue: Double,
    val laborHoursTotal: Int,
    val keyAdvantage: String
)

data class AuditLogRecord(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val author: String,
    val actionType: String, // e.g. "DIMENSION_CHANGE", "MATERIAL_UPDATE", "STAGE_PROGRESS"
    val description: String,
    val previousValue: String = "",
    val newValue: String = ""
)

data class HouseModelSpec(
    val id: String = "default_house_01",
    val title: String = "The Oakwood Executive Villa",
    val houseType: String = "4-Bedroom Detached House",
    val widthMeters: Double = 12.0,
    val depthMeters: Double = 9.0,
    val storyCount: Int = 2,
    val roofPitchDegrees: Double = 35.0,
    val wallThicknessMeters: Double = 0.3,
    val constructionTech: ConstructionTech = ConstructionTech.TRADITIONAL_MASONRY,
    val isGarageIncluded: Boolean = true,
    val solarPanelsCount: Int = 12,
    val currentStageIndex: Int = 8 // Default view stage
)
