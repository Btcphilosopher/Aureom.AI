"""Parametric building generation.

:class:`StandardHouseBuilder` turns a handful of dimensional parameters into a
complete, dependency-linked component model: substructure, superstructure,
envelope, services and finishes. It exists for three reasons:

* it gives the engine a realistic model to exercise without hand-authoring
  hundreds of components;
* it encodes the conventional relationships between elements (which wall hosts
  which window, which slab supports which wall) in one auditable place;
* it produces the large models the performance benchmarks need, by repeating
  the same generator across many plots.

The generated model is deliberately conventional: a rectangular two-storey
masonry cavity-wall house with a duopitch trussed roof, which is the dominant
UK volume-housebuilding typology.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core.events import EventBus
from ..domain.building import Building
from ..domain.components import (
    BuildingComponent,
    Door,
    DrainageRun,
    ElectricalCircuit,
    Excavation,
    ExternalFinish,
    ExternalFinishType,
    Floor,
    FloorSlab,
    Foundation,
    FoundationType,
    InsulationLayer,
    InternalFinish,
    InternalFinishType,
    Joist,
    Opening,
    PlumbingRun,
    RoofCovering,
    RoofStructure,
    Wall,
    WallType,
    Window,
)
from ..domain.enums import ComponentKind, ConstructionStage, Orientation
from ..domain.geometry import Dimensions, Footprint, Placement, Vec3
from ..domain.materials import MaterialCatalogue
from ..domain.site import Plot, Site

__all__ = ["HouseSpecification", "StandardHouseBuilder", "build_estate"]


@dataclass
class HouseSpecification:
    """Dimensional and specification parameters for a generated house."""

    length: float = 9.0
    """External length in metres (front elevation)."""

    width: float = 7.5
    """External depth in metres."""

    storeys: int = 2
    storey_height: float = 2.6
    """Floor-to-floor height in metres."""

    wall_thickness: float = 0.3
    """Overall cavity wall thickness: 102.5 brick + 100 cavity + 100 block."""

    foundation_depth: float = 1.0
    foundation_width: float = 0.6
    slab_thickness: float = 0.15

    roof_pitch: float = 40.0
    truss_spacing: float = 0.6

    windows_per_storey: int = 5
    window_width: float = 1.2
    window_height: float = 1.2
    external_doors: int = 2
    internal_doors_per_storey: int = 4

    internal_wall_length_per_storey: float = 22.0
    """Total run of internal partitions per storey, in metres."""

    bathrooms: int = 2
    electrical_circuits: int = 8

    render_area: float = 0.0
    """Area of rendered elevation, m². Zero for full facing brick."""

    paving_area: float = 45.0
    garden_area: float = 90.0

    def validate(self) -> None:
        if self.length <= 0 or self.width <= 0:
            raise ValueError("House length and width must be positive")
        if self.storeys < 1:
            raise ValueError("A house needs at least one storey")
        if not 0 < self.roof_pitch < 85:
            raise ValueError("Roof pitch must be between 0 and 85 degrees")
        if self.wall_thickness <= 0 or self.wall_thickness >= min(self.length, self.width) / 2:
            raise ValueError("Implausible wall thickness for these plan dimensions")

    @property
    def footprint_area(self) -> float:
        return self.length * self.width

    @property
    def perimeter(self) -> float:
        return 2.0 * (self.length + self.width)

    @property
    def gross_internal_area(self) -> float:
        inner_length = self.length - 2 * self.wall_thickness
        inner_width = self.width - 2 * self.wall_thickness
        return round(inner_length * inner_width * self.storeys, 2)


@dataclass
class _BuildResult:
    """Internal accumulator threading ids between build phases."""

    substructure: list[str] = field(default_factory=list)
    slab: list[str] = field(default_factory=list)
    external_walls: list[str] = field(default_factory=list)
    upper_floor: list[str] = field(default_factory=list)
    internal_walls: list[str] = field(default_factory=list)
    roof_structure: list[str] = field(default_factory=list)
    roof_covering: list[str] = field(default_factory=list)
    openings: list[str] = field(default_factory=list)
    services: list[str] = field(default_factory=list)
    insulation: list[str] = field(default_factory=list)
    finishes: list[str] = field(default_factory=list)
    external_works: list[str] = field(default_factory=list)


class StandardHouseBuilder:
    """Generates a complete masonry house model on a plot.

    Example
    -------
    >>> builder = StandardHouseBuilder(HouseSpecification(length=8.0, width=7.0))
    >>> building = builder.build("PLOT-01", "Plot 1 — 3 bed semi")
    >>> len(building) > 40
    True
    """

    def __init__(
        self,
        specification: HouseSpecification | None = None,
        *,
        catalogue: MaterialCatalogue | None = None,
    ) -> None:
        self.specification = specification or HouseSpecification()
        self.specification.validate()
        self.catalogue = catalogue

    # -- entry point ------------------------------------------------------- #
    def build(
        self,
        building_id: str,
        name: str,
        *,
        plot: Plot | None = None,
        site: Site | None = None,
        event_bus: EventBus | None = None,
        origin: Vec3 | None = None,
    ) -> Building:
        """Generate and return a fully linked :class:`Building`."""
        building = Building(
            id=building_id,
            name=name,
            plot=plot,
            site=site,
            catalogue=self.catalogue,
            event_bus=event_bus,
        )
        base = origin or Vec3()
        result = _BuildResult()

        self._build_substructure(building, base, result)
        self._build_slab(building, base, result)
        self._build_external_walls(building, base, result)
        self._build_upper_floors(building, base, result)
        self._build_internal_walls(building, base, result)
        self._build_roof(building, base, result)
        self._build_openings(building, result)
        self._build_services(building, result)
        self._build_insulation(building, result)
        self._build_finishes(building, result)
        self._build_external_works(building, result)
        self._link(building, result)
        return building

    # -- phases ------------------------------------------------------------ #
    def _build_substructure(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification

        strip = Excavation(
            id=building.next_id(ComponentKind.EXCAVATION),
            name="Topsoil strip and site preparation",
            stage=ConstructionStage.SITE_PREPARATION,
            retained_fraction=0.0,
            dimensions=Dimensions(
                length=spec.length + 4.0, width=spec.width + 4.0, height=0.3
            ),
            placement=Placement(
                origin=Vec3(x=base.x - 2.0, y=base.y - 2.0, z=base.z - 0.3)
            ),
            cost_reference="NRM2-0.1",
        )
        building.add(strip)
        result.substructure.append(strip.id)

        excavation = Excavation(
            id=building.next_id(ComponentKind.EXCAVATION),
            name="Foundation trench excavation",
            dimensions=Dimensions(
                length=spec.length + 1.0,
                width=spec.width + 1.0,
                height=spec.foundation_depth,
            ),
            placement=Placement(origin=Vec3(x=base.x - 0.5, y=base.y - 0.5, z=base.z - spec.foundation_depth)),
            cost_reference="NRM2-1.1",
        )
        building.add(excavation)
        result.substructure.append(excavation.id)

        # One foundation run per elevation.
        elevations = self._elevations(spec)
        for label, length, placement in elevations:
            foundation = Foundation(
                id=building.next_id(ComponentKind.FOUNDATION),
                name=f"{label} elevation trench-fill foundation",
                foundation_type=FoundationType.TRENCH_FILL,
                dimensions=Dimensions(
                    length=length,
                    width=spec.foundation_width,
                    height=spec.foundation_depth,
                ),
                placement=Placement(
                    origin=Vec3(
                        x=base.x + placement[0],
                        y=base.y + placement[1],
                        z=base.z - spec.foundation_depth,
                    ),
                    rotation_z=placement[2],
                ),
                cost_reference="NRM2-1.2",
            )
            building.add(foundation)
            result.substructure.append(foundation.id)

        drainage = DrainageRun(
            id=building.next_id(ComponentKind.DRAINAGE_RUN),
            name="Foul and surface water drainage",
            dimensions=Dimensions(length=spec.perimeter * 0.6, width=0.6, height=0.3),
            placement=Placement(origin=Vec3(x=base.x, y=base.y - 1.5, z=base.z - 0.9)),
            cost_reference="NRM2-5.1",
        )
        building.add(drainage)
        result.substructure.append(drainage.id)

    def _build_slab(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification
        slab = FloorSlab(
            id=building.next_id(ComponentKind.FLOOR_SLAB),
            name="Ground floor slab",
            dimensions=Dimensions(
                length=spec.length, width=spec.width, height=spec.slab_thickness
            ),
            placement=Placement(origin=base),
            cost_reference="NRM2-1.3",
        )
        building.add(slab)
        result.slab.append(slab.id)

    def _elevations(
        self, spec: HouseSpecification
    ) -> list[tuple[str, float, tuple[float, float, float]]]:
        """``(label, length, (x, y, rotation))`` for the four external walls."""
        return [
            ("Front", spec.length, (0.0, 0.0, 0.0)),
            ("Rear", spec.length, (0.0, spec.width - spec.wall_thickness, 0.0)),
            ("Left", spec.width, (0.0, 0.0, 90.0)),
            ("Right", spec.width, (spec.length - spec.wall_thickness, 0.0, 90.0)),
        ]

    def _build_external_walls(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification
        orientations = {
            "Front": Orientation.SOUTH,
            "Rear": Orientation.NORTH,
            "Left": Orientation.WEST,
            "Right": Orientation.EAST,
        }
        for storey in range(spec.storeys):
            z = base.z + spec.slab_thickness + storey * spec.storey_height
            for label, length, placement in self._elevations(spec):
                wall = Wall(
                    id=building.next_id(ComponentKind.WALL),
                    name=f"{label} external wall, level {storey}",
                    wall_type=WallType.CAVITY_EXTERNAL,
                    orientation=orientations[label],
                    stage=ConstructionStage.EXTERNAL_WALLS,
                    level=storey,
                    dimensions=Dimensions(
                        length=length,
                        width=spec.wall_thickness,
                        height=spec.storey_height,
                    ),
                    placement=Placement(
                        origin=Vec3(x=base.x + placement[0], y=base.y + placement[1], z=z),
                        rotation_z=placement[2],
                    ),
                    cost_reference="NRM2-2.1",
                )
                building.add(wall)
                result.external_walls.append(wall.id)

    def _build_upper_floors(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification
        if spec.storeys < 2:
            return
        inner_length = spec.length - 2 * spec.wall_thickness
        inner_width = spec.width - 2 * spec.wall_thickness

        for storey in range(1, spec.storeys):
            z = base.z + spec.slab_thickness + storey * spec.storey_height
            joist_count = math.ceil(inner_length / 0.4) + 1
            joists = Joist(
                id=building.next_id(ComponentKind.JOIST),
                name=f"Level {storey} floor joists",
                level=storey,
                count=joist_count,
                dimensions=Dimensions(length=inner_width, width=inner_length, height=0.22),
                placement=Placement(
                    origin=Vec3(
                        x=base.x + spec.wall_thickness, y=base.y + spec.wall_thickness, z=z
                    )
                ),
                cost_reference="NRM2-3.1",
            )
            building.add(joists)
            result.upper_floor.append(joists.id)

            deck = Floor(
                id=building.next_id(ComponentKind.FLOOR),
                name=f"Level {storey} floor deck",
                level=storey,
                dimensions=Dimensions(length=inner_length, width=inner_width, height=0.018),
                placement=Placement(
                    origin=Vec3(
                        x=base.x + spec.wall_thickness,
                        y=base.y + spec.wall_thickness,
                        z=z + 0.22,
                    )
                ),
                cost_reference="NRM2-3.2",
            )
            building.add(deck)
            result.upper_floor.append(deck.id)

    def _build_internal_walls(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification
        #: Split the total partition run into three panels per storey so the
        #: model has realistic granularity without exploding in size.
        panels = 3
        panel_length = spec.internal_wall_length_per_storey / panels

        for storey in range(spec.storeys):
            z = base.z + spec.slab_thickness + storey * spec.storey_height
            for index in range(panels):
                wall = Wall(
                    id=building.next_id(ComponentKind.WALL),
                    name=f"Internal partition {index + 1}, level {storey}",
                    wall_type=WallType.STUD_PARTITION,
                    orientation=Orientation.INTERNAL,
                    stage=ConstructionStage.INTERNAL_WALLS,
                    level=storey,
                    load_bearing=False,
                    dimensions=Dimensions(
                        length=panel_length, width=0.115, height=spec.storey_height
                    ),
                    placement=Placement(
                        origin=Vec3(
                            x=base.x + spec.wall_thickness + index * 0.5,
                            y=base.y + spec.width / 2.0,
                            z=z,
                        )
                    ),
                    cost_reference="NRM2-2.7",
                )
                building.add(wall)
                result.internal_walls.append(wall.id)

    def _build_roof(self, building: Building, base: Vec3, result: _BuildResult) -> None:
        spec = self.specification
        eaves_z = base.z + spec.slab_thickness + spec.storeys * spec.storey_height
        span = spec.width
        ridge_height = (span / 2.0) * math.tan(math.radians(spec.roof_pitch))

        # Truss timber volume scales with span; 0.009 m³ per metre of span is a
        # good fit for standard fink trusses between 6 m and 11 m.
        timber_per_truss = round(0.009 * span, 5)

        structure = RoofStructure(
            id=building.next_id(ComponentKind.ROOF_STRUCTURE),
            name="Trussed roof carcass",
            level=spec.storeys,
            pitch_degrees=spec.roof_pitch,
            truss_spacing=spec.truss_spacing,
            timber_volume_per_truss=timber_per_truss,
            dimensions=Dimensions(length=spec.length, width=span, height=max(ridge_height, 0.1)),
            placement=Placement(origin=Vec3(x=base.x, y=base.y, z=eaves_z)),
            cost_reference="NRM2-4.1",
        )
        building.add(structure)
        result.roof_structure.append(structure.id)

        covering = RoofCovering(
            id=building.next_id(ComponentKind.ROOF_COVERING),
            name="Plain clay tile roof covering",
            level=spec.storeys,
            pitch_degrees=spec.roof_pitch,
            ridge_length=spec.length,
            dimensions=Dimensions(length=spec.length, width=span, height=0.05),
            placement=Placement(origin=Vec3(x=base.x, y=base.y, z=eaves_z)),
            cost_reference="NRM2-4.2",
        )
        building.add(covering)
        result.roof_covering.append(covering.id)

    def _build_openings(self, building: Building, result: _BuildResult) -> None:
        spec = self.specification
        external_walls = [building.get(i) for i in result.external_walls]

        window_index = 0
        for storey in range(spec.storeys):
            storey_walls = [w for w in external_walls if w.level == storey]
            if not storey_walls:
                continue
            for slot in range(spec.windows_per_storey):
                host = storey_walls[slot % len(storey_walls)]
                window = Window(
                    id=building.next_id(ComponentKind.WINDOW),
                    name=f"Window {window_index + 1} (level {storey})",
                    level=storey,
                    host_wall_id=host.id,
                    dimensions=Dimensions(
                        length=spec.window_width, width=0.15, height=spec.window_height
                    ),
                    placement=host.placement,
                    cost_reference="NRM2-3.5",
                )
                building.add(window)
                host.add_opening(
                    Opening(
                        component_id=window.id,
                        width=spec.window_width,
                        height=spec.window_height,
                        sill_height=0.9,
                    )
                )
                result.openings.append(window.id)
                window_index += 1

        ground_walls = [w for w in external_walls if w.level == 0]
        for index in range(spec.external_doors):
            host = ground_walls[index % len(ground_walls)] if ground_walls else None
            door = Door(
                id=building.next_id(ComponentKind.DOOR),
                name=f"External door {index + 1}",
                is_external=True,
                host_wall_id=host.id if host else None,
                dimensions=Dimensions(length=0.926, width=0.15, height=2.04),
                placement=host.placement if host else Placement(),
                cost_reference="NRM2-3.6",
            )
            building.add(door)
            if host is not None:
                host.add_opening(
                    Opening(
                        component_id=door.id, width=0.926, height=2.04, sill_height=0.0
                    )
                )
            result.openings.append(door.id)

        for storey in range(spec.storeys):
            for index in range(spec.internal_doors_per_storey):
                door = Door(
                    id=building.next_id(ComponentKind.DOOR),
                    name=f"Internal door {index + 1} (level {storey})",
                    is_external=False,
                    level=storey,
                    stage=ConstructionStage.SECOND_FIX,
                    dimensions=Dimensions(length=0.838, width=0.115, height=1.981),
                    cost_reference="NRM2-3.7",
                )
                building.add(door)
                result.openings.append(door.id)

    def _build_services(self, building: Building, result: _BuildResult) -> None:
        spec = self.specification
        gia = spec.gross_internal_area

        for index in range(spec.electrical_circuits):
            circuit = ElectricalCircuit(
                id=building.next_id(ComponentKind.ELECTRICAL_CIRCUIT),
                name=f"Electrical circuit {index + 1}",
                dimensions=Dimensions(length=1.0, width=0.1, height=0.1),
                cable_length_m=round(gia * 0.9, 2),
                accessory_count=max(3, int(gia / 12)),
                cost_reference="NRM2-5.8",
            )
            building.add(circuit)
            result.services.append(circuit.id)

        for index in range(max(1, spec.bathrooms)):
            run = PlumbingRun(
                id=building.next_id(ComponentKind.PLUMBING_RUN),
                name=f"Plumbing run {index + 1}",
                dimensions=Dimensions(length=1.0, width=0.1, height=0.1),
                pipe_length_m=round(gia * 0.45, 2),
                fixture_count=3,
                cost_reference="NRM2-5.4",
            )
            building.add(run)
            result.services.append(run.id)

    def _build_insulation(self, building: Building, result: _BuildResult) -> None:
        spec = self.specification
        loft = InsulationLayer(
            id=building.next_id(ComponentKind.INSULATION),
            name="Loft insulation",
            area_m2=round(spec.footprint_area, 2),
            thickness_mm=300.0,
            dimensions=Dimensions(length=spec.length, width=spec.width, height=0.3),
            cost_reference="NRM2-2.9",
        )
        building.add(loft)
        result.insulation.append(loft.id)

    def _build_finishes(self, building: Building, result: _BuildResult) -> None:
        spec = self.specification
        gia = spec.gross_internal_area
        # Wall and ceiling surface area to be finished internally.
        wall_surface = round(
            spec.storeys * spec.perimeter * spec.storey_height
            + spec.internal_wall_length_per_storey * spec.storey_height * spec.storeys * 2,
            2,
        )
        finish_area = round(wall_surface + gia, 2)

        for finish_type, area in (
            (InternalFinishType.PLASTERBOARD, finish_area),
            (InternalFinishType.SKIM, finish_area),
            (InternalFinishType.DECORATION, finish_area),
            (InternalFinishType.SCREED, gia),
            (InternalFinishType.FLOOR_FINISH, gia),
        ):
            finish = InternalFinish(
                id=building.next_id(ComponentKind.INTERNAL_FINISH),
                name=f"{finish_type.value.replace('_', ' ').title()} to house",
                finish_type=finish_type,
                area_m2=area,
                thickness_mm=65.0 if finish_type is InternalFinishType.SCREED else 0.0,
                dimensions=Dimensions(length=spec.length, width=spec.width, height=0.1),
                cost_reference="NRM2-2.8",
            )
            building.add(finish)
            result.finishes.append(finish.id)

    def _build_external_works(self, building: Building, result: _BuildResult) -> None:
        spec = self.specification
        works: list[BuildingComponent] = []
        if spec.render_area > 0:
            works.append(
                ExternalFinish(
                    id=building.next_id(ComponentKind.EXTERNAL_FINISH),
                    name="Silicone render to elevations",
                    finish_type=ExternalFinishType.RENDER,
                    area_m2=spec.render_area,
                    dimensions=Dimensions(length=spec.length, width=0.02, height=spec.storey_height),
                    cost_reference="NRM2-2.5",
                )
            )
        if spec.paving_area > 0:
            works.append(
                ExternalFinish(
                    id=building.next_id(ComponentKind.EXTERNAL_FINISH),
                    name="Block paved driveway and paths",
                    finish_type=ExternalFinishType.PAVING,
                    area_m2=spec.paving_area,
                    dimensions=Dimensions(length=10.0, width=4.5, height=0.08),
                    cost_reference="NRM2-8.2",
                )
            )
        if spec.garden_area > 0:
            works.append(
                ExternalFinish(
                    id=building.next_id(ComponentKind.EXTERNAL_FINISH),
                    name="Topsoil and turfing",
                    finish_type=ExternalFinishType.LANDSCAPING,
                    area_m2=spec.garden_area,
                    depth_mm=150.0,
                    dimensions=Dimensions(length=12.0, width=8.0, height=0.15),
                    cost_reference="NRM2-8.4",
                )
            )
        for component in works:
            building.add(component)
            result.external_works.append(component.id)

    # -- linking ----------------------------------------------------------- #
    def _link(self, building: Building, result: _BuildResult) -> None:
        """Wire the explicit dependency edges between generated components."""
        excavations = [
            i
            for i in result.substructure
            if building.get(i).kind is ComponentKind.EXCAVATION
        ]
        strip = next(
            i
            for i in excavations
            if building.get(i).stage is ConstructionStage.SITE_PREPARATION
        )
        excavation = next(
            i for i in excavations if building.get(i).stage is ConstructionStage.EXCAVATION
        )
        building.link(strip, excavation)

        foundations = [
            i for i in result.substructure if building.get(i).kind is ComponentKind.FOUNDATION
        ]
        drainage = [
            i for i in result.substructure if building.get(i).kind is ComponentKind.DRAINAGE_RUN
        ]

        for foundation_id in foundations:
            building.link(excavation, foundation_id)
        for drain_id in drainage:
            building.link(excavation, drain_id)

        for slab_id in result.slab:
            building.link_many(foundations, slab_id)
            building.link_many(drainage, slab_id)

        # Ground floor walls sit on the slab; upper walls sit on the floor below.
        walls_by_level: dict[int, list[str]] = {}
        for wall_id in result.external_walls:
            walls_by_level.setdefault(building.get(wall_id).level, []).append(wall_id)

        for level, wall_ids in sorted(walls_by_level.items()):
            for wall_id in wall_ids:
                if level == 0:
                    building.link_many(result.slab, wall_id)
                else:
                    supports = result.upper_floor or walls_by_level.get(level - 1, [])
                    building.link_many(supports, wall_id)

        for upper_id in result.upper_floor:
            building.link_many(walls_by_level.get(0, []), upper_id)

        top_level = max(walls_by_level) if walls_by_level else 0
        for roof_id in result.roof_structure:
            building.link_many(walls_by_level.get(top_level, []), roof_id)
        for covering_id in result.roof_covering:
            building.link_many(result.roof_structure, covering_id)

        # Openings depend on their host wall.
        for opening_id in result.openings:
            component = building.get(opening_id)
            host = getattr(component, "host_wall_id", None)
            if host and host in building:
                building.link(host, opening_id)

        # Internal partitions follow the floor they stand on.
        for wall_id in result.internal_walls:
            level = building.get(wall_id).level
            supports = result.slab if level == 0 else result.upper_floor
            building.link_many(supports, wall_id)

        # Services follow a watertight shell.
        watertight = result.roof_covering + [
            i for i in result.openings if building.get(i).kind is ComponentKind.WINDOW
        ]
        for service_id in result.services:
            building.link_many(watertight, service_id)

        for insulation_id in result.insulation:
            building.link_many(result.services, insulation_id)

        for finish_id in result.finishes:
            building.link_many(result.insulation, finish_id)

        for works_id in result.external_works:
            building.link_many(result.roof_covering, works_id)


def build_estate(
    plot_count: int,
    *,
    specification: HouseSpecification | None = None,
    site_name: str = "BuildCore Demonstration Estate",
    plot_length: float = 14.0,
    plot_width: float = 22.0,
    event_bus: EventBus | None = None,
) -> tuple[Site, list[Building]]:
    """Generate a site of ``plot_count`` identical houses laid out in a row.

    Used by the performance benchmarks to produce models with thousands of
    components, and by the logistics engine to exercise multi-plot planning.
    """
    if plot_count < 1:
        raise ValueError("plot_count must be at least 1")

    spec = specification or HouseSpecification()
    site = Site(
        id="SITE-001",
        name=site_name,
        boundary=Footprint.rectangle(plot_length * plot_count + 10.0, plot_width + 10.0),
    )

    builder = StandardHouseBuilder(spec)
    buildings: list[Building] = []

    for index in range(plot_count):
        x0 = 5.0 + index * plot_length
        plot = Plot(
            id=f"PLOT-{index + 1:03d}",
            name=f"Plot {index + 1}",
            boundary=Footprint.rectangle(plot_length, plot_width, origin=(x0, 5.0)),
            setback=1.0,
        )
        site.add_plot(plot)

        building = builder.build(
            building_id=f"BLD-{index + 1:03d}",
            name=f"Plot {index + 1} dwelling",
            plot=plot,
            site=site,
            event_bus=event_bus,
            origin=Vec3(x=x0 + 2.0, y=7.0, z=0.0),
        )
        plot.building_id = building.id
        buildings.append(building)

    return site, buildings
