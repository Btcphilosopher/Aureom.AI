"""Construction constants: coverage rates and labour productivity.

Every "magic number" used by the quantification and labour engines lives here,
each with its derivation stated. Estimators need to audit these figures, and
scenario analysis needs to vary them, so they must not be buried in method
bodies.

Sources are mainstream UK practice (SMM7/NRM2 measurement conventions, typical
BCIS and Spon's outputs). Values are *net* — waste allowances are applied
separately by :class:`~buildcore.core.config.WasteAllowances`.
"""

from __future__ import annotations

from .enums import Trade

__all__ = [
    "BATTEN_M3_PER_M2",
    "BLOCKS_PER_M2",
    "BRICKS_PER_M2",
    "CREW_SIZE",
    "HARDCORE_DENSITY_T_PER_M3",
    "LABOUR_HOURS",
    "MESH_OVERLAP_FACTOR",
    "MORTAR_M3_PER_M2_BLOCK",
    "MORTAR_M3_PER_M2_BRICK",
    "PAINT_LITRES_PER_M2",
    "PLAIN_TILES_PER_M2",
    "RIDGE_TILES_PER_M",
    "SKIM_COVERAGE_M2",
    "WALL_TIES_PER_M2",
]

# --------------------------------------------------------------------------- #
# Masonry
# --------------------------------------------------------------------------- #
#: A metric brick face is 215×65mm; with 10mm joints the coordinating face is
#: 225×75mm = 0.016875 m², giving 59.26 bricks per m² of half-brick skin.
#: Rounded up to the trade-standard figure.
BRICKS_PER_M2: float = 60.0

#: A 440×215mm block with 10mm joints coordinates at 450×225mm = 0.10125 m²,
#: giving 9.88 blocks per m². Rounded to the trade-standard figure.
BLOCKS_PER_M2: float = 10.0

#: Mortar for a half-brick skin: bed 10mm × 102.5mm deep plus perpends.
MORTAR_M3_PER_M2_BRICK: float = 0.022

#: Blockwork has far fewer joints per m² than brickwork.
MORTAR_M3_PER_M2_BLOCK: float = 0.010

#: Ties at 900mm horizontal / 450mm vertical centres = 2.47 per m², plus extra
#: ties at reveals and movement joints.
WALL_TIES_PER_M2: float = 2.7

# --------------------------------------------------------------------------- #
# Roofing
# --------------------------------------------------------------------------- #
#: Plain clay tiles 265×165mm laid at 100mm gauge: 1 / (0.165 × 0.100) = 60.6.
PLAIN_TILES_PER_M2: float = 60.0

#: Half-round ridge tiles bedded at 300mm effective length, plus laps.
RIDGE_TILES_PER_M: float = 3.3

#: 38×25mm battens at 100mm gauge = 10 linear metres per m² of roof slope,
#: giving 10 × 0.038 × 0.025 = 0.0095 m³ of timber per m².
BATTEN_M3_PER_M2: float = 0.0095

#: Roofing underlay laid with 150mm side and head laps.
MEMBRANE_LAP_FACTOR: float = 1.15

# --------------------------------------------------------------------------- #
# Finishes
# --------------------------------------------------------------------------- #
#: Two coats of vinyl matt at 12 m²/litre spreading rate.
PAINT_LITRES_PER_M2: float = 2.0 / 12.0

#: Skim plaster is measured net of the boarded area, 1:1.
SKIM_COVERAGE_M2: float = 1.0

# --------------------------------------------------------------------------- #
# Groundworks
# --------------------------------------------------------------------------- #
#: A393 mesh sheets lapped 400mm on a 2.4×4.8m sheet ≈ 1.20 factor on net area.
MESH_OVERLAP_FACTOR: float = 1.20

#: Compacted MOT Type 1 bulk density.
HARDCORE_DENSITY_T_PER_M3: float = 2.1

#: Bulking factor: excavated material occupies more volume once loosened.
EXCAVATION_BULKING_FACTOR: float = 1.25

# --------------------------------------------------------------------------- #
# Labour productivity
# --------------------------------------------------------------------------- #
#: Net productive hours per unit of measured work, keyed by an operation name.
#: Units are stated in the comment beside each entry. These are *gang-neutral*
#: man-hours; the labour engine divides by crew size to obtain elapsed time.
LABOUR_HOURS: dict[str, float] = {
    # Groundworks --------------------------------------------------------- #
    "site_strip": 0.02,             # hr per m² stripped
    "excavate_machine": 0.06,       # hr per m³ excavated
    "excavate_hand": 1.80,          # hr per m³ excavated
    "place_concrete": 0.55,         # hr per m³ placed and vibrated
    "lay_hardcore": 0.30,           # hr per m³ laid and compacted
    "lay_drainage": 0.65,           # hr per m of pipe run
    "lay_dpm": 0.06,                # hr per m²
    "fix_mesh": 0.09,               # hr per m²
    # Masonry ------------------------------------------------------------- #
    "lay_facing_brick": 1.05,       # hr per m² of half-brick skin
    "lay_blockwork": 0.70,          # hr per m² of blockwork
    "build_stud_partition": 0.55,   # hr per m² of partition
    # Structure ----------------------------------------------------------- #
    "erect_steel": 0.030,           # hr per kg of steelwork
    "install_joists": 0.28,         # hr per m² of floor
    "lay_deck": 0.18,               # hr per m² of decking
    "erect_trusses": 1.60,          # hr per truss
    "fix_battens": 0.12,            # hr per m² of roof slope
    # Envelope ------------------------------------------------------------ #
    "lay_roof_tiles": 0.38,         # hr per m² of roof slope
    "fix_membrane": 0.07,           # hr per m²
    "install_window": 2.20,         # hr per window unit
    "install_door_external": 3.00,  # hr per door set
    "install_door_internal": 1.10,  # hr per door set
    "fit_insulation": 0.14,         # hr per m²
    # Services ------------------------------------------------------------ #
    "first_fix_electrical": 0.09,   # hr per m of cable
    "second_fix_electrical": 0.55,  # hr per accessory
    "first_fix_plumbing": 0.32,     # hr per m of pipe
    "second_fix_plumbing": 2.40,    # hr per sanitaryware item
    # Internal finishes --------------------------------------------------- #
    "fix_plasterboard": 0.34,       # hr per m²
    "skim_plaster": 0.30,           # hr per m²
    "decorate": 0.17,               # hr per m²
    "lay_screed": 0.85,             # hr per m³
    "lay_floor_finish": 0.22,       # hr per m²
    # External works ------------------------------------------------------ #
    "lay_paving": 0.55,             # hr per m²
    "apply_render": 0.65,           # hr per m²
    "spread_topsoil": 0.35,         # hr per m³
}

#: Typical gang size for each trade. Used to convert man-hours into duration.
CREW_SIZE: dict[Trade, int] = {
    Trade.GROUNDWORKER: 3,
    Trade.CONCRETER: 4,
    Trade.BRICKLAYER: 2,      # a bricklayer plus a hod carrier
    Trade.SCAFFOLDER: 3,
    Trade.CARPENTER: 2,
    Trade.STEEL_ERECTOR: 3,
    Trade.ROOFER: 2,
    Trade.GLAZIER: 2,
    Trade.ELECTRICIAN: 1,
    Trade.PLUMBER: 1,
    Trade.INSULATION_FITTER: 2,
    Trade.PLASTERER: 2,
    Trade.DECORATOR: 2,
    Trade.FLOOR_LAYER: 2,
    Trade.LANDSCAPER: 3,
    Trade.LABOURER: 2,
    Trade.CRANE_OPERATOR: 1,
    Trade.SITE_MANAGER: 1,
}


def labour_hours(operation: str) -> float:
    """Look up a productivity constant, raising a clear error if unknown."""
    try:
        return LABOUR_HOURS[operation]
    except KeyError as exc:  # pragma: no cover - guards typos in engine code
        raise KeyError(
            f"Unknown labour operation {operation!r}; "
            f"known operations: {sorted(LABOUR_HOURS)}"
        ) from exc
