"""Module 1 — Building Object Engine.

Every physical part of the building is a :class:`BuildingComponent`. A component
knows its dimensions, material, construction stage, dependencies, location,
installation status and cost reference, and — critically — it knows *how to
measure itself*: :meth:`BuildingComponent.material_demands` returns the net
material take-off, and :meth:`BuildingComponent.labour_demands` returns the net
man-hours by trade.

Putting measurement on the object rather than in a central estimator is what
lets Module 4 (quantification), Module 5 (labour) and Module 6 (scheduling)
stay generic: they iterate over components and aggregate, and a new component
type becomes available to all three the moment it is defined.

Waste allowances are deliberately *not* applied here. Components report net
measured quantities; the quantification engine applies the commercial
allowances from :class:`~buildcore.core.config.WasteAllowances`.

Polymorphic serialisation is handled by :data:`AnyComponent`, a Pydantic
discriminated union keyed on ``kind``, so a whole project round-trips through
JSON without bespoke encoder code.
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.exceptions import ComponentError
from ..core.units import Quantity, Unit
from .constants import (
    BATTEN_M3_PER_M2,
    BLOCKS_PER_M2,
    BRICKS_PER_M2,
    EXCAVATION_BULKING_FACTOR,
    HARDCORE_DENSITY_T_PER_M3,
    MEMBRANE_LAP_FACTOR,
    MESH_OVERLAP_FACTOR,
    MORTAR_M3_PER_M2_BLOCK,
    MORTAR_M3_PER_M2_BRICK,
    PAINT_LITRES_PER_M2,
    PLAIN_TILES_PER_M2,
    RIDGE_TILES_PER_M,
    WALL_TIES_PER_M2,
    labour_hours,
)
from .enums import (
    STATUS_TRANSITIONS,
    ComponentKind,
    ConstructionStage,
    InstallationStatus,
    Orientation,
    Trade,
)
from .geometry import BoundingBox, Dimensions, Placement
from .materials import MaterialCatalogue

__all__ = [
    "COMPONENT_TYPES",
    "AnyComponent",
    "Beam",
    "BuildingComponent",
    "Column",
    "Door",
    "DrainageRun",
    "ElectricalCircuit",
    "Excavation",
    "ExternalFinish",
    "ExternalFinishType",
    "Floor",
    "FloorSlab",
    "Foundation",
    "FoundationType",
    "InsulationLayer",
    "InternalFinish",
    "InternalFinishType",
    "Joist",
    "LabourDemand",
    "MaterialDemand",
    "Opening",
    "PlumbingRun",
    "RoofCovering",
    "RoofStructure",
    "Wall",
    "WallType",
    "Window",
]


# --------------------------------------------------------------------------- #
# Demand records
# --------------------------------------------------------------------------- #
class MaterialDemand(BaseModel):
    """A net quantity of one material required by one component."""

    model_config = ConfigDict(frozen=True)

    material_id: str
    quantity: float = Field(ge=0.0)
    unit: Unit
    component_id: str = ""
    operation: str = Field(default="", description="What the material is used for.")

    @property
    def as_quantity(self) -> Quantity:
        return Quantity(value=self.quantity, unit=self.unit)

    def scaled(self, factor: float) -> MaterialDemand:
        return self.model_copy(update={"quantity": self.quantity * factor})


class LabourDemand(BaseModel):
    """Net man-hours of one trade required by one component."""

    model_config = ConfigDict(frozen=True)

    trade: Trade
    hours: float = Field(ge=0.0)
    component_id: str = ""
    operation: str = ""

    def scaled(self, factor: float) -> LabourDemand:
        return self.model_copy(update={"hours": self.hours * factor})


class Opening(BaseModel):
    """A void in a wall for a window or door.

    Openings are declared on the *wall* so that masonry is measured net of
    them, and are cross-referenced by the window/door component that fills
    them via ``component_id``.
    """

    model_config = ConfigDict(frozen=True)

    component_id: str
    width: float = Field(gt=0.0)
    height: float = Field(gt=0.0)
    sill_height: float = Field(default=0.9, ge=0.0)

    @property
    def area(self) -> float:
        return self.width * self.height

    @property
    def perimeter(self) -> float:
        return 2.0 * (self.width + self.height)


# --------------------------------------------------------------------------- #
# Base component
# --------------------------------------------------------------------------- #
class BuildingComponent(BaseModel):
    """Abstract base for every physical part of the building.

    Subclasses override :meth:`material_demands` and :meth:`labour_demands`.
    The base implementations return empty lists rather than raising, so a
    purely notional component (a milestone marker, a survey point) is valid.
    """

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    kind: ComponentKind
    stage: ConstructionStage
    status: InstallationStatus = InstallationStatus.NOT_STARTED
    dimensions: Dimensions
    placement: Placement = Field(default_factory=Placement)

    #: Storey index: 0 = ground, -1 = basement, 1 = first floor.
    level: int = 0
    #: Free-form spatial grouping (plot, block, core) used by logistics.
    zone: str = "default"
    #: Identifiers of components that must be complete before this one starts.
    depends_on: tuple[str, ...] = ()
    #: Key into an external cost plan (e.g. a NRM2 element code).
    cost_reference: str | None = None
    #: Primary material, where the component is monolithic.
    material_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    # -- geometry ---------------------------------------------------------- #
    @property
    def bounding_box(self) -> BoundingBox:
        """World-space axis-aligned bounding box."""
        return self.placement.bounding_box(self.dimensions)

    @property
    def gross_volume(self) -> float:
        """Bounding volume in m³, before deductions."""
        return self.dimensions.volume

    @property
    def net_volume(self) -> float:
        """Volume of material in m³, after deducting voids.

        Overridden by components with openings or hollow sections.
        """
        return self.gross_volume

    @property
    def measured_area(self) -> float:
        """The area on which this component is measured, in m².

        Defaults to the largest vertical face, which suits walls and cladding.
        Horizontal components override with their plan area.
        """
        return self.dimensions.face_area

    @property
    def centroid(self):
        """World-space centre of the bounding box — used for crane radius checks."""
        return self.bounding_box.centre

    # -- physical properties ----------------------------------------------- #
    def mass(self, catalogue: MaterialCatalogue) -> float:
        """Installed mass in kilograms.

        Computed from the material take-off, which is more accurate than
        ``volume × density`` for composite components such as cavity walls.
        Falls back to the primary material density when no demands are
        declared.
        """
        demands = self.material_demands()
        if demands:
            total = 0.0
            for demand in demands:
                material = catalogue.find(demand.material_id)
                if material is None:
                    continue
                if demand.unit is Unit.CUBIC_METRE and material.density_kg_m3 > 0:
                    total += demand.quantity * material.density_kg_m3
                else:
                    total += material.mass_for(demand.quantity)
            return round(total, 3)

        if self.material_id:
            material = catalogue.find(self.material_id)
            if material is not None and material.density_kg_m3 > 0:
                return round(self.net_volume * material.density_kg_m3, 3)
        return 0.0

    def weight_newtons(self, catalogue: MaterialCatalogue) -> float:
        """Installed weight in newtons (mass × standard gravity)."""
        return self.mass(catalogue) * 9.80665

    # -- measurement hooks ------------------------------------------------- #
    def material_demands(self) -> list[MaterialDemand]:
        """Net material take-off for this component."""
        return []

    def labour_demands(self) -> list[LabourDemand]:
        """Net man-hours by trade for this component."""
        return []

    def primary_trade(self) -> Trade | None:
        """The trade contributing the most hours — used for crew assignment."""
        demands = self.labour_demands()
        if not demands:
            return None
        totals: dict[Trade, float] = {}
        for demand in demands:
            totals[demand.trade] = totals.get(demand.trade, 0.0) + demand.hours
        return max(totals, key=lambda trade: totals[trade])

    def total_labour_hours(self) -> float:
        return round(sum(demand.hours for demand in self.labour_demands()), 4)

    def material_cost(self, catalogue: MaterialCatalogue) -> float:
        """Net material cost, excluding waste, labour and markup."""
        total = 0.0
        for demand in self.material_demands():
            material = catalogue.find(demand.material_id)
            if material is not None:
                total += material.cost_for(demand.quantity)
        return round(total, 2)

    # -- lifecycle --------------------------------------------------------- #
    @property
    def progress_fraction(self) -> float:
        return self.status.progress_fraction

    @property
    def is_complete(self) -> bool:
        return self.status is InstallationStatus.COMPLETE

    def can_transition_to(self, target: InstallationStatus) -> bool:
        return target in STATUS_TRANSITIONS.get(self.status, frozenset())

    def transition_to(self, target: InstallationStatus, *, force: bool = False) -> InstallationStatus:
        """Advance the installation status, returning the previous value.

        Raises
        ------
        ComponentError
            If the transition is not permitted and ``force`` is ``False``.
        """
        previous = self.status
        if target is previous:
            return previous
        if not force and not self.can_transition_to(target):
            raise ComponentError(
                "Illegal status transition",
                component_id=self.id,
                current=previous.value,
                requested=target.value,
                allowed=sorted(s.value for s in STATUS_TRANSITIONS.get(previous, frozenset())),
            )
        self.status = target
        return previous

    # -- dependencies ------------------------------------------------------ #
    def add_dependency(self, component_id: str) -> None:
        if component_id == self.id:
            raise ComponentError("A component cannot depend on itself", component_id=self.id)
        if component_id not in self.depends_on:
            self.depends_on = (*self.depends_on, component_id)

    def remove_dependency(self, component_id: str) -> bool:
        if component_id not in self.depends_on:
            return False
        self.depends_on = tuple(d for d in self.depends_on if d != component_id)
        return True

    # -- presentation ------------------------------------------------------ #
    def summary(self) -> dict[str, Any]:
        """Compact dictionary for API responses and progress reports."""
        return {
            "id": self.id,
            "name": self.name,
            "kind": self.kind.value,
            "stage": self.stage.name,
            "status": self.status.value,
            "level": self.level,
            "zone": self.zone,
            "volume_m3": round(self.net_volume, 4),
            "area_m2": round(self.measured_area, 4),
            "labour_hours": self.total_labour_hours(),
            "dependencies": list(self.depends_on),
        }

    def __repr__(self) -> str:  # pragma: no cover
        return f"{type(self).__name__}({self.id}, {self.stage.name}, {self.status.value})"


# --------------------------------------------------------------------------- #
# Substructure
# --------------------------------------------------------------------------- #
class Excavation(BuildingComponent):
    """A volume of ground to be removed."""

    kind: Literal[ComponentKind.EXCAVATION] = ComponentKind.EXCAVATION
    stage: ConstructionStage = ConstructionStage.EXCAVATION
    #: True when a machine can reach; hand digging is ~30× slower.
    machine_accessible: bool = True
    #: Fraction of arisings retained on site for backfill rather than carted away.
    retained_fraction: float = Field(default=0.3, ge=0.0, le=1.0)

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    @property
    def bulked_volume(self) -> float:
        """Loose volume of arisings, which is what lorries actually carry."""
        return self.gross_volume * EXCAVATION_BULKING_FACTOR

    @property
    def disposal_volume(self) -> float:
        return self.bulked_volume * (1.0 - self.retained_fraction)

    def labour_demands(self) -> list[LabourDemand]:
        operation = "excavate_machine" if self.machine_accessible else "excavate_hand"
        return [
            LabourDemand(
                trade=Trade.GROUNDWORKER,
                hours=self.gross_volume * labour_hours(operation),
                component_id=self.id,
                operation=operation,
            )
        ]


class FoundationType(str, Enum):
    STRIP = "strip"
    TRENCH_FILL = "trench_fill"
    RAFT = "raft"
    PILE_CAP = "pile_cap"


class Foundation(BuildingComponent):
    """A concrete foundation element."""

    kind: Literal[ComponentKind.FOUNDATION] = ComponentKind.FOUNDATION
    stage: ConstructionStage = ConstructionStage.FOUNDATIONS
    foundation_type: FoundationType = FoundationType.TRENCH_FILL
    material_id: str | None = "CONCRETE_C35"
    #: Reinforcement mesh is measured on plan area; strip footings often omit it.
    reinforced: bool = False

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    def material_demands(self) -> list[MaterialDemand]:
        demands = [
            MaterialDemand(
                material_id=self.material_id or "CONCRETE_C35",
                quantity=round(self.net_volume, 4),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="foundation concrete",
            )
        ]
        if self.reinforced:
            demands.append(
                MaterialDemand(
                    material_id="REBAR_A393",
                    quantity=round(self.measured_area * MESH_OVERLAP_FACTOR, 4),
                    unit=Unit.SQUARE_METRE,
                    component_id=self.id,
                    operation="foundation reinforcement",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        demands = [
            LabourDemand(
                trade=Trade.CONCRETER,
                hours=self.net_volume * labour_hours("place_concrete"),
                component_id=self.id,
                operation="place_concrete",
            )
        ]
        if self.reinforced:
            demands.append(
                LabourDemand(
                    trade=Trade.GROUNDWORKER,
                    hours=self.measured_area * labour_hours("fix_mesh"),
                    component_id=self.id,
                    operation="fix_mesh",
                )
            )
        return demands


class DrainageRun(BuildingComponent):
    """A below-ground drainage pipe run."""

    kind: Literal[ComponentKind.DRAINAGE_RUN] = ComponentKind.DRAINAGE_RUN
    stage: ConstructionStage = ConstructionStage.DRAINAGE
    material_id: str | None = "PIPE_SOIL_110"
    invert_depth: float = Field(default=0.9, gt=0.0, description="Depth to pipe invert, m.")
    #: Granular bed and surround thickness around the pipe, in metres.
    bedding_thickness: float = Field(default=0.15, ge=0.0)

    @property
    def length(self) -> float:
        return self.dimensions.length

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    def material_demands(self) -> list[MaterialDemand]:
        bedding_volume = (
            self.length * self.dimensions.width * self.bedding_thickness
            if self.bedding_thickness > 0
            else 0.0
        )
        demands = [
            MaterialDemand(
                material_id=self.material_id or "PIPE_SOIL_110",
                quantity=round(self.length, 4),
                unit=Unit.METRE,
                component_id=self.id,
                operation="drainage pipe",
            )
        ]
        if bedding_volume > 0:
            demands.append(
                MaterialDemand(
                    material_id="HARDCORE_MOT1",
                    quantity=round(bedding_volume * HARDCORE_DENSITY_T_PER_M3, 4),
                    unit=Unit.TONNE,
                    component_id=self.id,
                    operation="pipe bedding and surround",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.GROUNDWORKER,
                hours=self.length * labour_hours("lay_drainage"),
                component_id=self.id,
                operation="lay_drainage",
            )
        ]


class FloorSlab(BuildingComponent):
    """A ground-bearing concrete floor slab and its build-up."""

    kind: Literal[ComponentKind.FLOOR_SLAB] = ComponentKind.FLOOR_SLAB
    stage: ConstructionStage = ConstructionStage.FLOOR_SLAB
    material_id: str | None = "CONCRETE_C25"
    hardcore_thickness: float = Field(default=0.15, ge=0.0)
    sand_blinding_thickness: float = Field(default=0.025, ge=0.0)
    insulation_thickness: float = Field(default=0.10, ge=0.0)
    reinforced: bool = True

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    @property
    def slab_thickness(self) -> float:
        return self.dimensions.height

    def material_demands(self) -> list[MaterialDemand]:
        area = self.measured_area
        demands = [
            MaterialDemand(
                material_id=self.material_id or "CONCRETE_C25",
                quantity=round(area * self.slab_thickness, 4),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="slab concrete",
            ),
            MaterialDemand(
                material_id="DPM_1200G",
                quantity=round(area * 1.10, 4),  # 10% for laps and upstands
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="damp-proof membrane",
            ),
        ]
        if self.hardcore_thickness > 0:
            demands.append(
                MaterialDemand(
                    material_id="HARDCORE_MOT1",
                    quantity=round(
                        area * self.hardcore_thickness * HARDCORE_DENSITY_T_PER_M3, 4
                    ),
                    unit=Unit.TONNE,
                    component_id=self.id,
                    operation="sub-base",
                )
            )
        if self.sand_blinding_thickness > 0:
            demands.append(
                MaterialDemand(
                    material_id="SAND_BLINDING",
                    quantity=round(area * self.sand_blinding_thickness * 1.6, 4),
                    unit=Unit.TONNE,
                    component_id=self.id,
                    operation="blinding",
                )
            )
        if self.insulation_thickness > 0:
            demands.append(
                MaterialDemand(
                    material_id="INSUL_PIR_100",
                    quantity=round(area, 4),
                    unit=Unit.SQUARE_METRE,
                    component_id=self.id,
                    operation="floor insulation",
                )
            )
        if self.reinforced:
            demands.append(
                MaterialDemand(
                    material_id="REBAR_A393",
                    quantity=round(area * MESH_OVERLAP_FACTOR, 4),
                    unit=Unit.SQUARE_METRE,
                    component_id=self.id,
                    operation="slab reinforcement",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        area = self.measured_area
        demands = [
            LabourDemand(
                trade=Trade.CONCRETER,
                hours=area * self.slab_thickness * labour_hours("place_concrete"),
                component_id=self.id,
                operation="place_concrete",
            ),
            LabourDemand(
                trade=Trade.GROUNDWORKER,
                hours=area * self.hardcore_thickness * labour_hours("lay_hardcore")
                + area * labour_hours("lay_dpm"),
                component_id=self.id,
                operation="slab preparation",
            ),
        ]
        if self.reinforced:
            demands.append(
                LabourDemand(
                    trade=Trade.GROUNDWORKER,
                    hours=area * labour_hours("fix_mesh"),
                    component_id=self.id,
                    operation="fix_mesh",
                )
            )
        return demands


# --------------------------------------------------------------------------- #
# Superstructure
# --------------------------------------------------------------------------- #
class WallType(str, Enum):
    CAVITY_EXTERNAL = "cavity_external"
    SOLID_BLOCK = "solid_block"
    STUD_PARTITION = "stud_partition"
    PARTY_WALL = "party_wall"


class Wall(BuildingComponent):
    """A wall panel between two structural supports.

    Measured net of declared :class:`Opening` voids, per NRM2 convention.
    Stud partitions include their plasterboard linings (both faces); skim and
    decoration are measured separately as :class:`InternalFinish`.
    """

    kind: Literal[ComponentKind.WALL] = ComponentKind.WALL
    stage: ConstructionStage = ConstructionStage.EXTERNAL_WALLS
    wall_type: WallType = WallType.CAVITY_EXTERNAL
    orientation: Orientation = Orientation.INTERNAL
    openings: tuple[Opening, ...] = ()
    #: Cavity width in metres; determines insulation thickness for cavity walls.
    cavity_width: float = Field(default=0.10, ge=0.0)
    #: Stud centres in metres, for stud partitions.
    stud_centres: float = Field(default=0.6, gt=0.0)
    load_bearing: bool = True

    @model_validator(mode="after")
    def _check_stage_matches_type(self) -> Wall:
        if self.wall_type in {WallType.STUD_PARTITION, WallType.SOLID_BLOCK} and (
            self.stage is ConstructionStage.EXTERNAL_WALLS and self.orientation is Orientation.INTERNAL
        ):
            # Internal walls default to the internal-walls stage unless the
            # caller has explicitly placed them elsewhere in the sequence.
            object.__setattr__(self, "stage", ConstructionStage.INTERNAL_WALLS)
        return self

    @property
    def gross_area(self) -> float:
        """Elevational area including openings, in m²."""
        return self.dimensions.face_area

    @property
    def opening_area(self) -> float:
        return sum(opening.area for opening in self.openings)

    @property
    def measured_area(self) -> float:
        """Elevational area net of openings, in m² (never negative)."""
        return max(0.0, self.gross_area - self.opening_area)

    @property
    def net_volume(self) -> float:
        return self.measured_area * self.dimensions.width

    def add_opening(self, opening: Opening) -> None:
        """Register an opening, rejecting it if the wall cannot accommodate it."""
        if opening.area > self.gross_area:
            raise ComponentError(
                "Opening is larger than the wall",
                component_id=self.id,
                opening=opening.component_id,
                opening_area=round(opening.area, 3),
                wall_area=round(self.gross_area, 3),
            )
        if self.opening_area + opening.area > self.gross_area:
            raise ComponentError(
                "Openings would exceed the wall area",
                component_id=self.id,
                opening=opening.component_id,
            )
        self.openings = (*self.openings, opening)

    def material_demands(self) -> list[MaterialDemand]:
        area = self.measured_area
        if area <= 0:
            return []

        if self.wall_type is WallType.CAVITY_EXTERNAL:
            return [
                MaterialDemand(
                    material_id="BRICK_FACING",
                    quantity=round(area * BRICKS_PER_M2, 2),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="outer leaf brickwork",
                ),
                MaterialDemand(
                    material_id="BLOCK_AAC_100",
                    quantity=round(area * BLOCKS_PER_M2, 2),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="inner leaf blockwork",
                ),
                MaterialDemand(
                    material_id="MORTAR_M4",
                    quantity=round(
                        area * (MORTAR_M3_PER_M2_BRICK + MORTAR_M3_PER_M2_BLOCK), 4
                    ),
                    unit=Unit.CUBIC_METRE,
                    component_id=self.id,
                    operation="bedding mortar",
                ),
                MaterialDemand(
                    material_id="WALL_TIE_SS",
                    quantity=round(area * WALL_TIES_PER_M2, 2),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="cavity ties",
                ),
                MaterialDemand(
                    material_id="INSUL_PIR_100",
                    quantity=round(area, 4),
                    unit=Unit.SQUARE_METRE,
                    component_id=self.id,
                    operation="cavity insulation",
                ),
            ]

        if self.wall_type in {WallType.SOLID_BLOCK, WallType.PARTY_WALL}:
            leaves = 2.0 if self.wall_type is WallType.PARTY_WALL else 1.0
            demands = [
                MaterialDemand(
                    material_id="BLOCK_AAC_100",
                    quantity=round(area * BLOCKS_PER_M2 * leaves, 2),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="blockwork",
                ),
                MaterialDemand(
                    material_id="MORTAR_M4",
                    quantity=round(area * MORTAR_M3_PER_M2_BLOCK * leaves, 4),
                    unit=Unit.CUBIC_METRE,
                    component_id=self.id,
                    operation="bedding mortar",
                ),
            ]
            if self.wall_type is WallType.PARTY_WALL:
                demands.append(
                    MaterialDemand(
                        material_id="INSUL_MINERAL_WOOL",
                        quantity=round(area, 4),
                        unit=Unit.SQUARE_METRE,
                        component_id=self.id,
                        operation="party wall acoustic infill",
                    )
                )
            return demands

        # Stud partition: sole/head plates plus studs at centres, boarded both sides.
        stud_count = math.ceil(self.dimensions.length / self.stud_centres) + 1
        stud_section = 0.089 * 0.038  # 89×38mm CLS
        stud_volume = stud_count * self.dimensions.height * stud_section
        plate_volume = 2.0 * self.dimensions.length * stud_section
        return [
            MaterialDemand(
                material_id="TIMBER_C24",
                quantity=round(stud_volume + plate_volume, 4),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="partition studwork",
            ),
            MaterialDemand(
                material_id="PLASTERBOARD_12_5",
                quantity=round(area * 2.0, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="partition linings, both faces",
            ),
            MaterialDemand(
                material_id="INSUL_MINERAL_WOOL",
                quantity=round(area, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="partition acoustic infill",
            ),
            MaterialDemand(
                material_id="NAILS_FIXINGS",
                quantity=round(area * 0.25, 4),
                unit=Unit.KILOGRAM,
                component_id=self.id,
                operation="partition fixings",
            ),
        ]

    def labour_demands(self) -> list[LabourDemand]:
        area = self.measured_area
        if area <= 0:
            return []

        if self.wall_type is WallType.CAVITY_EXTERNAL:
            return [
                LabourDemand(
                    trade=Trade.BRICKLAYER,
                    hours=area
                    * (labour_hours("lay_facing_brick") + labour_hours("lay_blockwork")),
                    component_id=self.id,
                    operation="cavity walling",
                )
            ]
        if self.wall_type in {WallType.SOLID_BLOCK, WallType.PARTY_WALL}:
            leaves = 2.0 if self.wall_type is WallType.PARTY_WALL else 1.0
            return [
                LabourDemand(
                    trade=Trade.BRICKLAYER,
                    hours=area * labour_hours("lay_blockwork") * leaves,
                    component_id=self.id,
                    operation="blockwork walling",
                )
            ]
        return [
            LabourDemand(
                trade=Trade.CARPENTER,
                hours=area * labour_hours("build_stud_partition"),
                component_id=self.id,
                operation="build_stud_partition",
            ),
            LabourDemand(
                trade=Trade.PLASTERER,
                hours=area * 2.0 * labour_hours("fix_plasterboard"),
                component_id=self.id,
                operation="board partition",
            ),
        ]


class Beam(BuildingComponent):
    """A structural steel or timber beam."""

    kind: Literal[ComponentKind.BEAM] = ComponentKind.BEAM
    stage: ConstructionStage = ConstructionStage.STRUCTURAL_BEAMS
    material_id: str | None = "STEEL_UB_S275"
    #: Section self-weight. For a 203×133×25 UB this is 25 kg/m.
    mass_per_metre: float = Field(default=25.0, gt=0.0)

    @property
    def span(self) -> float:
        return self.dimensions.length

    @property
    def steel_mass(self) -> float:
        return self.span * self.mass_per_metre

    def material_demands(self) -> list[MaterialDemand]:
        material_id = self.material_id or "STEEL_UB_S275"
        if material_id.startswith("TIMBER"):
            return [
                MaterialDemand(
                    material_id=material_id,
                    quantity=round(self.net_volume, 4),
                    unit=Unit.CUBIC_METRE,
                    component_id=self.id,
                    operation="timber beam",
                )
            ]
        return [
            MaterialDemand(
                material_id=material_id,
                quantity=round(self.steel_mass, 3),
                unit=Unit.KILOGRAM,
                component_id=self.id,
                operation="structural steel beam",
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        material_id = self.material_id or "STEEL_UB_S275"
        if material_id.startswith("TIMBER"):
            return [
                LabourDemand(
                    trade=Trade.CARPENTER,
                    hours=self.span * 0.45,
                    component_id=self.id,
                    operation="install timber beam",
                )
            ]
        return [
            LabourDemand(
                trade=Trade.STEEL_ERECTOR,
                hours=self.steel_mass * labour_hours("erect_steel"),
                component_id=self.id,
                operation="erect_steel",
            )
        ]


class Column(Beam):
    """A vertical structural member. Shares beam measurement rules."""

    kind: Literal[ComponentKind.COLUMN] = ComponentKind.COLUMN  # type: ignore[assignment]

    @property
    def span(self) -> float:
        return self.dimensions.height


class Joist(BuildingComponent):
    """A floor or ceiling joist, or a grouped run of identical joists.

    Modelling every joist individually is supported (``count = 1``) and is the
    default; ``count > 1`` groups an identical run into a single object, which
    keeps large developments tractable without losing quantity accuracy.
    """

    kind: Literal[ComponentKind.JOIST] = ComponentKind.JOIST
    stage: ConstructionStage = ConstructionStage.UPPER_FLOORS
    material_id: str | None = "TIMBER_C24"
    count: int = Field(default=1, ge=1)
    section_width: float = Field(default=0.047, gt=0.0, description="Metres.")
    section_depth: float = Field(default=0.220, gt=0.0, description="Metres.")
    hangers_per_joist: int = Field(default=2, ge=0)

    @property
    def span(self) -> float:
        return self.dimensions.length

    @property
    def net_volume(self) -> float:
        return self.count * self.span * self.section_width * self.section_depth

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    def material_demands(self) -> list[MaterialDemand]:
        demands = [
            MaterialDemand(
                material_id=self.material_id or "TIMBER_C24",
                quantity=round(self.net_volume, 5),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="floor joists",
            )
        ]
        if self.hangers_per_joist:
            demands.append(
                MaterialDemand(
                    material_id="JOIST_HANGER",
                    quantity=float(self.count * self.hangers_per_joist),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="joist hangers",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        # Joist installation is measured per m² of floor area served.
        served_area = self.count * self.span * 0.4  # nominal 400mm centres
        return [
            LabourDemand(
                trade=Trade.CARPENTER,
                hours=served_area * labour_hours("install_joists"),
                component_id=self.id,
                operation="install_joists",
            )
        ]


class Floor(BuildingComponent):
    """A structural floor deck spanning over joists."""

    kind: Literal[ComponentKind.FLOOR] = ComponentKind.FLOOR
    stage: ConstructionStage = ConstructionStage.UPPER_FLOORS
    material_id: str | None = "OSB3_18MM"

    @property
    def measured_area(self) -> float:
        return self.dimensions.footprint_area

    def material_demands(self) -> list[MaterialDemand]:
        return [
            MaterialDemand(
                material_id=self.material_id or "OSB3_18MM",
                quantity=round(self.measured_area, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="floor decking",
            ),
            MaterialDemand(
                material_id="NAILS_FIXINGS",
                quantity=round(self.measured_area * 0.12, 4),
                unit=Unit.KILOGRAM,
                component_id=self.id,
                operation="deck fixings",
            ),
        ]

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.CARPENTER,
                hours=self.measured_area * labour_hours("lay_deck"),
                component_id=self.id,
                operation="lay_deck",
            )
        ]


class RoofStructure(BuildingComponent):
    """A trussed or cut roof carcass.

    ``dimensions`` describe the plan extent and the ridge height. The sloping
    area is derived from the pitch, which is the area that roofing, battens and
    underlay are measured on.
    """

    kind: Literal[ComponentKind.ROOF_STRUCTURE] = ComponentKind.ROOF_STRUCTURE
    stage: ConstructionStage = ConstructionStage.ROOF_STRUCTURE
    material_id: str | None = "TIMBER_C24"
    pitch_degrees: float = Field(default=40.0, gt=0.0, lt=85.0)
    truss_spacing: float = Field(default=0.6, gt=0.0)
    #: Timber volume in a single truss; scales with span in the builder.
    timber_volume_per_truss: float = Field(default=0.075, gt=0.0)

    @property
    def truss_count(self) -> int:
        return math.ceil(self.dimensions.length / self.truss_spacing) + 1

    @property
    def plan_area(self) -> float:
        return self.dimensions.footprint_area

    @property
    def slope_area(self) -> float:
        """Area measured on the slope, in m².

        For a duopitch roof the two slopes together cover the plan area
        divided by the cosine of the pitch.
        """
        return self.plan_area / math.cos(math.radians(self.pitch_degrees))

    @property
    def ridge_length(self) -> float:
        return self.dimensions.length

    @property
    def measured_area(self) -> float:
        return self.slope_area

    @property
    def net_volume(self) -> float:
        return self.truss_count * self.timber_volume_per_truss

    def material_demands(self) -> list[MaterialDemand]:
        return [
            MaterialDemand(
                material_id=self.material_id or "TIMBER_C24",
                quantity=round(self.net_volume, 4),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="roof trusses",
            ),
            MaterialDemand(
                material_id="TIMBER_TREATED",
                quantity=round(self.slope_area * BATTEN_M3_PER_M2, 5),
                unit=Unit.CUBIC_METRE,
                component_id=self.id,
                operation="roof battens",
            ),
            MaterialDemand(
                material_id="NAILS_FIXINGS",
                quantity=round(self.truss_count * 0.9, 3),
                unit=Unit.KILOGRAM,
                component_id=self.id,
                operation="truss fixings and straps",
            ),
        ]

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.CARPENTER,
                hours=self.truss_count * labour_hours("erect_trusses")
                + self.slope_area * labour_hours("fix_battens"),
                component_id=self.id,
                operation="erect_trusses",
            )
        ]


class RoofCovering(BuildingComponent):
    """Tiles, underlay and ridge to a roof slope."""

    kind: Literal[ComponentKind.ROOF_COVERING] = ComponentKind.ROOF_COVERING
    stage: ConstructionStage = ConstructionStage.ROOF_COVERING
    material_id: str | None = "TILE_PLAIN_CLAY"
    pitch_degrees: float = Field(default=40.0, gt=0.0, lt=85.0)
    ridge_length: float = Field(default=0.0, ge=0.0)

    @property
    def slope_area(self) -> float:
        return self.dimensions.footprint_area / math.cos(math.radians(self.pitch_degrees))

    @property
    def measured_area(self) -> float:
        return self.slope_area

    def material_demands(self) -> list[MaterialDemand]:
        area = self.slope_area
        demands = [
            MaterialDemand(
                material_id=self.material_id or "TILE_PLAIN_CLAY",
                quantity=round(area * PLAIN_TILES_PER_M2, 1),
                unit=Unit.EACH,
                component_id=self.id,
                operation="roof tiling",
            ),
            MaterialDemand(
                material_id="ROOF_MEMBRANE",
                quantity=round(area * MEMBRANE_LAP_FACTOR, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="roofing underlay",
            ),
        ]
        if self.ridge_length > 0:
            demands.append(
                MaterialDemand(
                    material_id="RIDGE_TILE",
                    quantity=round(self.ridge_length * RIDGE_TILES_PER_M, 1),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="ridge tiling",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        area = self.slope_area
        return [
            LabourDemand(
                trade=Trade.ROOFER,
                hours=area * (labour_hours("lay_roof_tiles") + labour_hours("fix_membrane")),
                component_id=self.id,
                operation="lay_roof_tiles",
            )
        ]


# --------------------------------------------------------------------------- #
# Envelope openings
# --------------------------------------------------------------------------- #
class Window(BuildingComponent):
    """A glazed opening unit."""

    kind: Literal[ComponentKind.WINDOW] = ComponentKind.WINDOW
    stage: ConstructionStage = ConstructionStage.WINDOWS
    material_id: str | None = "WINDOW_UPVC_DG"
    host_wall_id: str | None = None

    @property
    def measured_area(self) -> float:
        return self.dimensions.face_area

    def material_demands(self) -> list[MaterialDemand]:
        return [
            MaterialDemand(
                material_id=self.material_id or "WINDOW_UPVC_DG",
                quantity=round(self.measured_area, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="glazed unit",
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.GLAZIER,
                hours=labour_hours("install_window"),
                component_id=self.id,
                operation="install_window",
            )
        ]


class Door(BuildingComponent):
    """A door set, internal or external."""

    kind: Literal[ComponentKind.DOOR] = ComponentKind.DOOR
    stage: ConstructionStage = ConstructionStage.DOORS
    is_external: bool = True
    host_wall_id: str | None = None

    @model_validator(mode="after")
    def _default_material(self) -> Door:
        if self.material_id is None:
            object.__setattr__(
                self, "material_id", "DOOR_EXTERNAL" if self.is_external else "DOOR_INTERNAL"
            )
        return self

    @property
    def measured_area(self) -> float:
        return self.dimensions.face_area

    def material_demands(self) -> list[MaterialDemand]:
        return [
            MaterialDemand(
                material_id=self.material_id
                or ("DOOR_EXTERNAL" if self.is_external else "DOOR_INTERNAL"),
                quantity=1.0,
                unit=Unit.EACH,
                component_id=self.id,
                operation="door set",
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        operation = "install_door_external" if self.is_external else "install_door_internal"
        return [
            LabourDemand(
                trade=Trade.CARPENTER,
                hours=labour_hours(operation),
                component_id=self.id,
                operation=operation,
            )
        ]


class InsulationLayer(BuildingComponent):
    """A discrete insulation layer measured on area."""

    kind: Literal[ComponentKind.INSULATION] = ComponentKind.INSULATION
    stage: ConstructionStage = ConstructionStage.INSULATION
    material_id: str | None = "INSUL_MINERAL_WOOL"
    area_m2: float = Field(gt=0.0)
    thickness_mm: float = Field(default=150.0, gt=0.0)

    @property
    def measured_area(self) -> float:
        return self.area_m2

    @property
    def net_volume(self) -> float:
        return self.area_m2 * self.thickness_mm / 1000.0

    def material_demands(self) -> list[MaterialDemand]:
        return [
            MaterialDemand(
                material_id=self.material_id or "INSUL_MINERAL_WOOL",
                quantity=round(self.area_m2, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation="insulation layer",
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.INSULATION_FITTER,
                hours=self.area_m2 * labour_hours("fit_insulation"),
                component_id=self.id,
                operation="fit_insulation",
            )
        ]


# --------------------------------------------------------------------------- #
# Services
# --------------------------------------------------------------------------- #
class ElectricalCircuit(BuildingComponent):
    """A single electrical circuit: cable run plus its accessories."""

    kind: Literal[ComponentKind.ELECTRICAL_CIRCUIT] = ComponentKind.ELECTRICAL_CIRCUIT
    stage: ConstructionStage = ConstructionStage.FIRST_FIX
    material_id: str | None = "CABLE_TWIN_EARTH"
    cable_length_m: float = Field(gt=0.0)
    accessory_count: int = Field(default=0, ge=0)

    @property
    def measured_area(self) -> float:
        return 0.0

    def material_demands(self) -> list[MaterialDemand]:
        demands = [
            MaterialDemand(
                material_id=self.material_id or "CABLE_TWIN_EARTH",
                quantity=round(self.cable_length_m, 3),
                unit=Unit.METRE,
                component_id=self.id,
                operation="circuit cabling",
            )
        ]
        if self.accessory_count:
            demands.append(
                MaterialDemand(
                    material_id="ELECTRICAL_ACCESSORY",
                    quantity=float(self.accessory_count),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="electrical accessories",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.ELECTRICIAN,
                hours=self.cable_length_m * labour_hours("first_fix_electrical")
                + self.accessory_count * labour_hours("second_fix_electrical"),
                component_id=self.id,
                operation="electrical installation",
            )
        ]


class PlumbingRun(BuildingComponent):
    """A plumbing pipe run and the fixtures it serves."""

    kind: Literal[ComponentKind.PLUMBING_RUN] = ComponentKind.PLUMBING_RUN
    stage: ConstructionStage = ConstructionStage.FIRST_FIX
    material_id: str | None = "PIPE_COPPER_15"
    pipe_length_m: float = Field(gt=0.0)
    fixture_count: int = Field(default=0, ge=0)

    @property
    def measured_area(self) -> float:
        return 0.0

    def material_demands(self) -> list[MaterialDemand]:
        demands = [
            MaterialDemand(
                material_id=self.material_id or "PIPE_COPPER_15",
                quantity=round(self.pipe_length_m, 3),
                unit=Unit.METRE,
                component_id=self.id,
                operation="pipework",
            )
        ]
        if self.fixture_count:
            demands.append(
                MaterialDemand(
                    material_id="SANITARYWARE",
                    quantity=float(self.fixture_count),
                    unit=Unit.EACH,
                    component_id=self.id,
                    operation="sanitaryware",
                )
            )
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        return [
            LabourDemand(
                trade=Trade.PLUMBER,
                hours=self.pipe_length_m * labour_hours("first_fix_plumbing")
                + self.fixture_count * labour_hours("second_fix_plumbing"),
                component_id=self.id,
                operation="plumbing installation",
            )
        ]


# --------------------------------------------------------------------------- #
# Finishes
# --------------------------------------------------------------------------- #
class InternalFinishType(str, Enum):
    PLASTERBOARD = "plasterboard"
    SKIM = "skim"
    DECORATION = "decoration"
    SCREED = "screed"
    FLOOR_FINISH = "floor_finish"


class InternalFinish(BuildingComponent):
    """An internal finish measured on area."""

    kind: Literal[ComponentKind.INTERNAL_FINISH] = ComponentKind.INTERNAL_FINISH
    stage: ConstructionStage = ConstructionStage.DECORATION
    finish_type: InternalFinishType = InternalFinishType.SKIM
    area_m2: float = Field(gt=0.0)
    thickness_mm: float = Field(default=0.0, ge=0.0, description="Used by screed only.")

    @model_validator(mode="after")
    def _align_stage_and_material(self) -> InternalFinish:
        defaults: dict[InternalFinishType, tuple[ConstructionStage, str]] = {
            InternalFinishType.PLASTERBOARD: (
                ConstructionStage.PLASTERBOARD,
                "PLASTERBOARD_12_5",
            ),
            InternalFinishType.SKIM: (ConstructionStage.PLASTERBOARD, "PLASTER_SKIM"),
            InternalFinishType.DECORATION: (ConstructionStage.DECORATION, "PAINT_EMULSION"),
            InternalFinishType.SCREED: (ConstructionStage.FLOOR_FINISHES, "SCREED_50MM"),
            InternalFinishType.FLOOR_FINISH: (
                ConstructionStage.FLOOR_FINISHES,
                "FLOOR_FINISH_LVT",
            ),
        }
        stage, material = defaults[self.finish_type]
        if self.material_id is None:
            object.__setattr__(self, "material_id", material)
        if "stage" not in self.model_fields_set:
            object.__setattr__(self, "stage", stage)
        return self

    @property
    def measured_area(self) -> float:
        return self.area_m2

    @property
    def net_volume(self) -> float:
        if self.finish_type is InternalFinishType.SCREED:
            return self.area_m2 * self.thickness_mm / 1000.0
        return 0.0

    def material_demands(self) -> list[MaterialDemand]:
        material_id = self.material_id or "PLASTER_SKIM"
        if self.finish_type is InternalFinishType.DECORATION:
            return [
                MaterialDemand(
                    material_id=material_id,
                    quantity=round(self.area_m2 * PAINT_LITRES_PER_M2, 3),
                    unit=Unit.LITRE,
                    component_id=self.id,
                    operation="two coats emulsion",
                )
            ]
        if self.finish_type is InternalFinishType.SCREED:
            return [
                MaterialDemand(
                    material_id=material_id,
                    quantity=round(self.net_volume, 4),
                    unit=Unit.CUBIC_METRE,
                    component_id=self.id,
                    operation="floor screed",
                )
            ]
        return [
            MaterialDemand(
                material_id=material_id,
                quantity=round(self.area_m2, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation=self.finish_type.value,
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        mapping: dict[InternalFinishType, tuple[Trade, str, float]] = {
            InternalFinishType.PLASTERBOARD: (Trade.PLASTERER, "fix_plasterboard", self.area_m2),
            InternalFinishType.SKIM: (Trade.PLASTERER, "skim_plaster", self.area_m2),
            InternalFinishType.DECORATION: (Trade.DECORATOR, "decorate", self.area_m2),
            InternalFinishType.SCREED: (Trade.CONCRETER, "lay_screed", self.net_volume),
            InternalFinishType.FLOOR_FINISH: (
                Trade.FLOOR_LAYER,
                "lay_floor_finish",
                self.area_m2,
            ),
        }
        trade, operation, driver = mapping[self.finish_type]
        return [
            LabourDemand(
                trade=trade,
                hours=driver * labour_hours(operation),
                component_id=self.id,
                operation=operation,
            )
        ]


class ExternalFinishType(str, Enum):
    RENDER = "render"
    PAVING = "paving"
    LANDSCAPING = "landscaping"


class ExternalFinish(BuildingComponent):
    """External works and finishes measured on area."""

    kind: Literal[ComponentKind.EXTERNAL_FINISH] = ComponentKind.EXTERNAL_FINISH
    stage: ConstructionStage = ConstructionStage.EXTERNAL_WORKS
    finish_type: ExternalFinishType = ExternalFinishType.PAVING
    area_m2: float = Field(gt=0.0)
    depth_mm: float = Field(default=150.0, ge=0.0, description="Used by landscaping only.")

    @model_validator(mode="after")
    def _default_material(self) -> ExternalFinish:
        if self.material_id is None:
            defaults = {
                ExternalFinishType.RENDER: "RENDER_SILICONE",
                ExternalFinishType.PAVING: "PAVING_BLOCK",
                ExternalFinishType.LANDSCAPING: "TOPSOIL",
            }
            object.__setattr__(self, "material_id", defaults[self.finish_type])
        return self

    @property
    def measured_area(self) -> float:
        return self.area_m2

    @property
    def net_volume(self) -> float:
        if self.finish_type is ExternalFinishType.LANDSCAPING:
            return self.area_m2 * self.depth_mm / 1000.0
        return 0.0

    def material_demands(self) -> list[MaterialDemand]:
        material_id = self.material_id or "PAVING_BLOCK"
        if self.finish_type is ExternalFinishType.LANDSCAPING:
            return [
                MaterialDemand(
                    material_id=material_id,
                    quantity=round(self.net_volume, 4),
                    unit=Unit.CUBIC_METRE,
                    component_id=self.id,
                    operation="topsoil",
                )
            ]
        return [
            MaterialDemand(
                material_id=material_id,
                quantity=round(self.area_m2, 4),
                unit=Unit.SQUARE_METRE,
                component_id=self.id,
                operation=self.finish_type.value,
            )
        ]

    def labour_demands(self) -> list[LabourDemand]:
        mapping: dict[ExternalFinishType, tuple[Trade, str, float]] = {
            ExternalFinishType.RENDER: (Trade.PLASTERER, "apply_render", self.area_m2),
            ExternalFinishType.PAVING: (Trade.LANDSCAPER, "lay_paving", self.area_m2),
            ExternalFinishType.LANDSCAPING: (
                Trade.LANDSCAPER,
                "spread_topsoil",
                self.net_volume,
            ),
        }
        trade, operation, driver = mapping[self.finish_type]
        return [
            LabourDemand(
                trade=trade,
                hours=driver * labour_hours(operation),
                component_id=self.id,
                operation=operation,
            )
        ]


# --------------------------------------------------------------------------- #
# Polymorphic union for serialisation
# --------------------------------------------------------------------------- #
#: Every concrete component type, in declaration order.
COMPONENT_TYPES: tuple[type[BuildingComponent], ...] = (
    Excavation,
    Foundation,
    DrainageRun,
    FloorSlab,
    Wall,
    Beam,
    Column,
    Joist,
    Floor,
    RoofStructure,
    RoofCovering,
    Window,
    Door,
    InsulationLayer,
    ElectricalCircuit,
    PlumbingRun,
    InternalFinish,
    ExternalFinish,
)

#: Discriminated union enabling ``TypeAdapter(AnyComponent)`` round-tripping.
AnyComponent = Annotated[
    Excavation | Foundation | DrainageRun | FloorSlab | Wall | Beam | Column | Joist | Floor | RoofStructure | RoofCovering | Window | Door | InsulationLayer | ElectricalCircuit | PlumbingRun | InternalFinish | ExternalFinish,
    Field(discriminator="kind"),
]
