"""Indexed component registry.

The registry is the in-memory "database" of a project model. It maintains
secondary indexes by kind, stage, status, level and zone so that the twelve
engines can slice a 10,000-component model without repeated linear scans —
the single most important performance decision in the whole package.

Indexes are maintained incrementally on add/remove and on status change, so
lookups are O(1) amortised and iteration is O(k) in the size of the result.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable, Iterator
from typing import Any, TypeVar

from ..core.exceptions import ComponentNotFoundError, DuplicateComponentError
from .components import BuildingComponent, LabourDemand, MaterialDemand
from .enums import ComponentKind, ConstructionStage, InstallationStatus

__all__ = ["ComponentRegistry"]

ComponentT = TypeVar("ComponentT", bound=BuildingComponent)


class ComponentRegistry:
    """A collection of components with maintained secondary indexes."""

    __slots__ = ("_by_kind", "_by_level", "_by_stage", "_by_status", "_by_zone", "_components")

    def __init__(self, components: Iterable[BuildingComponent] = ()) -> None:
        self._components: dict[str, BuildingComponent] = {}
        self._by_kind: dict[ComponentKind, set[str]] = defaultdict(set)
        self._by_stage: dict[ConstructionStage, set[str]] = defaultdict(set)
        self._by_status: dict[InstallationStatus, set[str]] = defaultdict(set)
        self._by_level: dict[int, set[str]] = defaultdict(set)
        self._by_zone: dict[str, set[str]] = defaultdict(set)
        for component in components:
            self.add(component)

    # -- mutation ---------------------------------------------------------- #
    def add(self, component: BuildingComponent) -> BuildingComponent:
        """Register ``component``.

        Raises
        ------
        DuplicateComponentError
            If the identifier is already present.
        """
        if component.id in self._components:
            raise DuplicateComponentError(
                "Component identifier already registered",
                component_id=component.id,
                existing_kind=self._components[component.id].kind.value,
            )
        self._components[component.id] = component
        self._index(component)
        return component

    def add_all(self, components: Iterable[BuildingComponent]) -> list[BuildingComponent]:
        return [self.add(component) for component in components]

    def remove(self, component_id: str) -> BuildingComponent:
        """Unregister and return a component."""
        component = self.get(component_id)
        self._deindex(component)
        del self._components[component_id]
        return component

    def replace(self, component: BuildingComponent) -> BuildingComponent:
        """Swap an existing component for a new definition with the same id."""
        if component.id not in self._components:
            raise ComponentNotFoundError("Cannot replace unknown component", component_id=component.id)
        self._deindex(self._components[component.id])
        self._components[component.id] = component
        self._index(component)
        return component

    def clear(self) -> None:
        self._components.clear()
        for index in (self._by_kind, self._by_stage, self._by_status, self._by_level, self._by_zone):
            index.clear()

    def _index(self, component: BuildingComponent) -> None:
        self._by_kind[component.kind].add(component.id)
        self._by_stage[component.stage].add(component.id)
        self._by_status[component.status].add(component.id)
        self._by_level[component.level].add(component.id)
        self._by_zone[component.zone].add(component.id)

    def _deindex(self, component: BuildingComponent) -> None:
        self._by_kind[component.kind].discard(component.id)
        self._by_stage[component.stage].discard(component.id)
        self._by_status[component.status].discard(component.id)
        self._by_level[component.level].discard(component.id)
        self._by_zone[component.zone].discard(component.id)

    def reindex(self) -> None:
        """Rebuild every index from scratch.

        Needed after external code mutates a component's status or zone without
        going through :meth:`set_status`.
        """
        for index in (self._by_kind, self._by_stage, self._by_status, self._by_level, self._by_zone):
            index.clear()
        for component in self._components.values():
            self._index(component)

    def set_status(
        self, component_id: str, status: InstallationStatus, *, force: bool = False
    ) -> InstallationStatus:
        """Transition a component's status, keeping the status index correct."""
        component = self.get(component_id)
        previous = component.status
        self._by_status[previous].discard(component_id)
        try:
            component.transition_to(status, force=force)
        finally:
            self._by_status[component.status].add(component_id)
        return previous

    # -- lookup ------------------------------------------------------------ #
    def get(self, component_id: str) -> BuildingComponent:
        try:
            return self._components[component_id]
        except KeyError as exc:
            raise ComponentNotFoundError(
                "Unknown component id", component_id=component_id, registry_size=len(self._components)
            ) from exc

    def find(self, component_id: str) -> BuildingComponent | None:
        return self._components.get(component_id)

    def __contains__(self, component_id: object) -> bool:
        return component_id in self._components

    def __len__(self) -> int:
        return len(self._components)

    def __iter__(self) -> Iterator[BuildingComponent]:
        return iter(self._components.values())

    @property
    def ids(self) -> list[str]:
        return list(self._components)

    def all(self) -> list[BuildingComponent]:
        return list(self._components.values())

    # -- indexed queries --------------------------------------------------- #
    def _resolve(self, ids: Iterable[str]) -> list[BuildingComponent]:
        return [self._components[i] for i in ids if i in self._components]

    def by_kind(self, kind: ComponentKind) -> list[BuildingComponent]:
        return self._resolve(self._by_kind.get(kind, ()))

    def by_stage(self, stage: ConstructionStage) -> list[BuildingComponent]:
        return self._resolve(self._by_stage.get(stage, ()))

    def by_status(self, status: InstallationStatus) -> list[BuildingComponent]:
        return self._resolve(self._by_status.get(status, ()))

    def by_level(self, level: int) -> list[BuildingComponent]:
        return self._resolve(self._by_level.get(level, ()))

    def by_zone(self, zone: str) -> list[BuildingComponent]:
        return self._resolve(self._by_zone.get(zone, ()))

    def by_type(self, component_type: type[ComponentT]) -> list[ComponentT]:
        """Filter by Python class, including subclasses."""
        return [c for c in self._components.values() if isinstance(c, component_type)]

    def where(self, predicate: Callable[[BuildingComponent], bool]) -> list[BuildingComponent]:
        return [c for c in self._components.values() if predicate(c)]

    def stages_present(self) -> list[ConstructionStage]:
        """Stages that contain at least one component, in build order."""
        return sorted(stage for stage, ids in self._by_stage.items() if ids)

    def zones(self) -> list[str]:
        return sorted(zone for zone, ids in self._by_zone.items() if ids)

    def levels(self) -> list[int]:
        return sorted(level for level, ids in self._by_level.items() if ids)

    # -- aggregation ------------------------------------------------------- #
    def material_demands(self) -> list[MaterialDemand]:
        """Concatenated net material take-off across every component."""
        demands: list[MaterialDemand] = []
        for component in self._components.values():
            demands.extend(component.material_demands())
        return demands

    def labour_demands(self) -> list[LabourDemand]:
        demands: list[LabourDemand] = []
        for component in self._components.values():
            demands.extend(component.labour_demands())
        return demands

    def total_labour_hours(self) -> float:
        return round(sum(d.hours for d in self.labour_demands()), 3)

    def completion_fraction(self) -> float:
        """Unweighted mean progress across all components, 0.0 – 1.0."""
        if not self._components:
            return 0.0
        total = sum(c.progress_fraction for c in self._components.values())
        return round(total / len(self._components), 6)

    def weighted_completion_fraction(self) -> float:
        """Progress weighted by labour content — a better earned-value proxy."""
        numerator = 0.0
        denominator = 0.0
        for component in self._components.values():
            weight = component.total_labour_hours() or 1e-6
            numerator += weight * component.progress_fraction
            denominator += weight
        return round(numerator / denominator, 6) if denominator else 0.0

    def status_counts(self) -> dict[str, int]:
        return {
            status.value: len(ids)
            for status, ids in sorted(self._by_status.items(), key=lambda kv: kv[0].value)
            if ids
        }

    def stage_counts(self) -> dict[str, int]:
        return {stage.name: len(ids) for stage, ids in sorted(self._by_stage.items()) if ids}

    def statistics(self) -> dict[str, Any]:
        """Summary block used by the progress and validation reports."""
        return {
            "component_count": len(self._components),
            "stages": self.stage_counts(),
            "statuses": self.status_counts(),
            "zones": len(self.zones()),
            "levels": self.levels(),
            "total_labour_hours": self.total_labour_hours(),
            "completion": self.completion_fraction(),
            "weighted_completion": self.weighted_completion_fraction(),
        }

    def __repr__(self) -> str:  # pragma: no cover
        return f"ComponentRegistry({len(self._components)} components)"
