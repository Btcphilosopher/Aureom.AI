"""Computational geometry primitives.

Deliberately lightweight: the heavy geometry kernel lives in the Rust service.
What Python needs is enough geometry to (a) compute quantities, (b) place
components in space for the logistics engine, and (c) detect gross modelling
errors such as a building outside its plot.

Shapely is used for 2D footprint operations (plot containment, crane radius,
access routes); everything else is closed-form arithmetic on ``Vec3``.

All lengths are metres.
"""

from __future__ import annotations

import math
from collections.abc import Iterable, Sequence

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from shapely.geometry import Point, Polygon

from ..core.exceptions import GeometryError

__all__ = [
    "BoundingBox",
    "Dimensions",
    "Footprint",
    "Placement",
    "Vec3",
    "polygon_area",
    "polygon_perimeter",
]

_EPS = 1e-9


class Vec3(BaseModel):
    """An immutable 3D point/vector in metres (X east, Y north, Z up)."""

    model_config = ConfigDict(frozen=True)

    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def __add__(self, other: Vec3) -> Vec3:
        return Vec3(x=self.x + other.x, y=self.y + other.y, z=self.z + other.z)

    def __sub__(self, other: Vec3) -> Vec3:
        return Vec3(x=self.x - other.x, y=self.y - other.y, z=self.z - other.z)

    def __mul__(self, scalar: float) -> Vec3:
        return Vec3(x=self.x * scalar, y=self.y * scalar, z=self.z * scalar)

    __rmul__ = __mul__

    def __neg__(self) -> Vec3:
        return Vec3(x=-self.x, y=-self.y, z=-self.z)

    @property
    def length(self) -> float:
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)

    @property
    def length_2d(self) -> float:
        """Horizontal distance from the origin, ignoring Z."""
        return math.hypot(self.x, self.y)

    def distance_to(self, other: Vec3) -> float:
        return (self - other).length

    def distance_2d(self, other: Vec3) -> float:
        return math.hypot(self.x - other.x, self.y - other.y)

    def dot(self, other: Vec3) -> float:
        return self.x * other.x + self.y * other.y + self.z * other.z

    def cross(self, other: Vec3) -> Vec3:
        return Vec3(
            x=self.y * other.z - self.z * other.y,
            y=self.z * other.x - self.x * other.z,
            z=self.x * other.y - self.y * other.x,
        )

    def normalised(self) -> Vec3:
        magnitude = self.length
        if magnitude < _EPS:
            raise GeometryError("Cannot normalise a zero-length vector")
        return self * (1.0 / magnitude)

    def rotated_z(self, degrees: float) -> Vec3:
        """Rotate about the vertical axis through the origin."""
        radians = math.radians(degrees)
        cos_a, sin_a = math.cos(radians), math.sin(radians)
        return Vec3(
            x=self.x * cos_a - self.y * sin_a,
            y=self.x * sin_a + self.y * cos_a,
            z=self.z,
        )

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)

    def __repr__(self) -> str:
        return f"Vec3({self.x:.3f}, {self.y:.3f}, {self.z:.3f})"

    @classmethod
    def origin(cls) -> Vec3:
        return cls()


class Dimensions(BaseModel):
    """Axis-aligned extents of a component before placement rotation.

    ``length`` runs along local X, ``width`` along local Y, ``height`` along Z.
    """

    model_config = ConfigDict(frozen=True)

    length: float = Field(gt=0.0, description="Metres along local X.")
    width: float = Field(gt=0.0, description="Metres along local Y.")
    height: float = Field(gt=0.0, description="Metres along local Z.")

    @field_validator("length", "width", "height")
    @classmethod
    def _finite(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("Dimension must be finite")
        return float(value)

    @property
    def volume(self) -> float:
        """Gross bounding volume in m³."""
        return self.length * self.width * self.height

    @property
    def footprint_area(self) -> float:
        """Plan area in m²."""
        return self.length * self.width

    @property
    def face_area(self) -> float:
        """Area of the largest vertical face (length × height) in m².

        This is the measured area for walls, cladding and plasterboard.
        """
        return self.length * self.height

    @property
    def perimeter(self) -> float:
        """Plan perimeter in m."""
        return 2.0 * (self.length + self.width)

    def scaled(self, factor: float) -> Dimensions:
        if factor <= 0:
            raise GeometryError("Scale factor must be positive", factor=factor)
        return Dimensions(
            length=self.length * factor,
            width=self.width * factor,
            height=self.height * factor,
        )

    def __repr__(self) -> str:
        return f"Dimensions({self.length:.3f}×{self.width:.3f}×{self.height:.3f} m)"


class BoundingBox(BaseModel):
    """Axis-aligned bounding box in world coordinates."""

    model_config = ConfigDict(frozen=True)

    minimum: Vec3
    maximum: Vec3

    @model_validator(mode="after")
    def _check_ordering(self) -> BoundingBox:
        if (
            self.maximum.x < self.minimum.x
            or self.maximum.y < self.minimum.y
            or self.maximum.z < self.minimum.z
        ):
            raise ValueError("BoundingBox maximum must be >= minimum on every axis")
        return self

    @property
    def size(self) -> Vec3:
        return self.maximum - self.minimum

    @property
    def centre(self) -> Vec3:
        return Vec3(
            x=(self.minimum.x + self.maximum.x) / 2.0,
            y=(self.minimum.y + self.maximum.y) / 2.0,
            z=(self.minimum.z + self.maximum.z) / 2.0,
        )

    @property
    def volume(self) -> float:
        size = self.size
        return size.x * size.y * size.z

    @property
    def footprint_area(self) -> float:
        size = self.size
        return size.x * size.y

    def contains(self, point: Vec3, tolerance: float = _EPS) -> bool:
        return (
            self.minimum.x - tolerance <= point.x <= self.maximum.x + tolerance
            and self.minimum.y - tolerance <= point.y <= self.maximum.y + tolerance
            and self.minimum.z - tolerance <= point.z <= self.maximum.z + tolerance
        )

    def intersects(self, other: BoundingBox, tolerance: float = _EPS) -> bool:
        """True if the two boxes overlap with more than ``tolerance`` slack."""
        return not (
            self.maximum.x <= other.minimum.x + tolerance
            or other.maximum.x <= self.minimum.x + tolerance
            or self.maximum.y <= other.minimum.y + tolerance
            or other.maximum.y <= self.minimum.y + tolerance
            or self.maximum.z <= other.minimum.z + tolerance
            or other.maximum.z <= self.minimum.z + tolerance
        )

    def overlap_volume(self, other: BoundingBox) -> float:
        """Volume shared with ``other`` — used by the clash detector."""
        dx = min(self.maximum.x, other.maximum.x) - max(self.minimum.x, other.minimum.x)
        dy = min(self.maximum.y, other.maximum.y) - max(self.minimum.y, other.minimum.y)
        dz = min(self.maximum.z, other.maximum.z) - max(self.minimum.z, other.minimum.z)
        if dx <= 0 or dy <= 0 or dz <= 0:
            return 0.0
        return dx * dy * dz

    def merged(self, other: BoundingBox) -> BoundingBox:
        return BoundingBox(
            minimum=Vec3(
                x=min(self.minimum.x, other.minimum.x),
                y=min(self.minimum.y, other.minimum.y),
                z=min(self.minimum.z, other.minimum.z),
            ),
            maximum=Vec3(
                x=max(self.maximum.x, other.maximum.x),
                y=max(self.maximum.y, other.maximum.y),
                z=max(self.maximum.z, other.maximum.z),
            ),
        )

    def expanded(self, margin: float) -> BoundingBox:
        delta = Vec3(x=margin, y=margin, z=margin)
        return BoundingBox(minimum=self.minimum - delta, maximum=self.maximum + delta)

    @classmethod
    def enclosing(cls, boxes: Iterable[BoundingBox]) -> BoundingBox | None:
        """Smallest box enclosing all inputs, or ``None`` for an empty input."""
        iterator = iter(boxes)
        try:
            result = next(iterator)
        except StopIteration:
            return None
        for box in iterator:
            result = result.merged(box)
        return result


class Placement(BaseModel):
    """Position and Z-rotation of a component in world space.

    Rotation is limited to the vertical axis, which covers every realistic
    residential component (walls, joists, windows). Roof planes carry their
    pitch as an explicit attribute rather than a full rotation matrix.
    """

    model_config = ConfigDict(frozen=True)

    origin: Vec3 = Field(default_factory=Vec3, description="Local origin in world space.")
    rotation_z: float = Field(default=0.0, description="Degrees anticlockwise about +Z.")

    @field_validator("rotation_z")
    @classmethod
    def _normalise_rotation(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("rotation_z must be finite")
        return float(value) % 360.0

    def to_world(self, local: Vec3) -> Vec3:
        """Transform a local-space point into world space."""
        return self.origin + local.rotated_z(self.rotation_z)

    def bounding_box(self, dimensions: Dimensions) -> BoundingBox:
        """World-space AABB of a box with ``dimensions`` under this placement.

        The AABB of a rotated box is computed from all four rotated plan
        corners, so a wall at 45° yields a correctly enlarged box rather than
        the naive unrotated extents.
        """
        corners_local = [
            Vec3(x=0.0, y=0.0, z=0.0),
            Vec3(x=dimensions.length, y=0.0, z=0.0),
            Vec3(x=dimensions.length, y=dimensions.width, z=0.0),
            Vec3(x=0.0, y=dimensions.width, z=0.0),
        ]
        world = [self.to_world(corner) for corner in corners_local]
        xs = [point.x for point in world]
        ys = [point.y for point in world]
        base_z = self.origin.z
        return BoundingBox(
            minimum=Vec3(x=min(xs), y=min(ys), z=base_z),
            maximum=Vec3(x=max(xs), y=max(ys), z=base_z + dimensions.height),
        )

    def translated(self, delta: Vec3) -> Placement:
        return Placement(origin=self.origin + delta, rotation_z=self.rotation_z)


class Footprint(BaseModel):
    """A closed 2D plan polygon, backed by Shapely for spatial predicates."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    vertices: tuple[tuple[float, float], ...] = Field(min_length=3)

    @field_validator("vertices")
    @classmethod
    def _validate_ring(
        cls, value: tuple[tuple[float, float], ...]
    ) -> tuple[tuple[float, float], ...]:
        cleaned = tuple((float(x), float(y)) for x, y in value)
        if len(cleaned) >= 2 and cleaned[0] == cleaned[-1]:
            cleaned = cleaned[:-1]
        if len(cleaned) < 3:
            raise ValueError("A footprint needs at least 3 distinct vertices")
        if not Polygon(cleaned).is_valid:
            raise ValueError("Footprint polygon is self-intersecting or degenerate")
        return cleaned

    @property
    def polygon(self) -> Polygon:
        return Polygon(self.vertices)

    @property
    def area(self) -> float:
        return float(self.polygon.area)

    @property
    def perimeter(self) -> float:
        return float(self.polygon.length)

    @property
    def centroid(self) -> Vec3:
        point = self.polygon.centroid
        return Vec3(x=float(point.x), y=float(point.y), z=0.0)

    @property
    def bounds(self) -> tuple[float, float, float, float]:
        """``(min_x, min_y, max_x, max_y)``."""
        return tuple(float(v) for v in self.polygon.bounds)  # type: ignore[return-value]

    def contains_point(self, point: Vec3, tolerance: float = 1e-6) -> bool:
        return bool(self.polygon.buffer(tolerance).contains(Point(point.x, point.y)))

    def contains_footprint(self, other: Footprint, tolerance: float = 1e-6) -> bool:
        return bool(self.polygon.buffer(tolerance).contains(other.polygon))

    def overlaps(self, other: Footprint) -> bool:
        return bool(self.polygon.intersects(other.polygon) and not self.polygon.touches(other.polygon))

    def intersection_area(self, other: Footprint) -> float:
        return float(self.polygon.intersection(other.polygon).area)

    def offset(self, distance: float) -> Footprint | None:
        """Inward (negative) or outward (positive) buffer.

        Returns ``None`` if an inward offset collapses the polygon — used when
        computing usable site working area inside a boundary setback.
        """
        buffered = self.polygon.buffer(distance, join_style=2)
        if buffered.is_empty or buffered.geom_type != "Polygon":
            return None
        coords = tuple((float(x), float(y)) for x, y in buffered.exterior.coords)
        return Footprint(vertices=coords)

    @classmethod
    def rectangle(
        cls, length: float, width: float, origin: tuple[float, float] = (0.0, 0.0)
    ) -> Footprint:
        """Convenience constructor for the common rectangular case."""
        if length <= 0 or width <= 0:
            raise GeometryError("Rectangle dimensions must be positive", length=length, width=width)
        x0, y0 = origin
        return cls(
            vertices=(
                (x0, y0),
                (x0 + length, y0),
                (x0 + length, y0 + width),
                (x0, y0 + width),
            )
        )

    def __repr__(self) -> str:
        return f"Footprint({len(self.vertices)} vertices, {self.area:.2f} m²)"


def polygon_area(vertices: Sequence[tuple[float, float]]) -> float:
    """Shoelace area of a closed ring, always non-negative."""
    if len(vertices) < 3:
        return 0.0
    total = 0.0
    count = len(vertices)
    for index in range(count):
        x1, y1 = vertices[index]
        x2, y2 = vertices[(index + 1) % count]
        total += x1 * y2 - x2 * y1
    return abs(total) / 2.0


def polygon_perimeter(vertices: Sequence[tuple[float, float]]) -> float:
    """Perimeter length of a closed ring."""
    if len(vertices) < 2:
        return 0.0
    count = len(vertices)
    return sum(
        math.dist(vertices[index], vertices[(index + 1) % count]) for index in range(count)
    )
