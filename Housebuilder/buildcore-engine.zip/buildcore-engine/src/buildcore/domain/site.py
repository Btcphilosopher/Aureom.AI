"""Site and plot models.

The site is the outermost spatial container: it owns the boundary polygon, the
vehicle access points, the working setback and the plots within it. The
logistics engine (Module 8) plans within the site; the validation engine
(Module 11) checks that buildings sit inside their plots.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.exceptions import SiteError
from .geometry import Footprint, Vec3

__all__ = ["AccessPoint", "GroundConditions", "Plot", "Site"]


class GroundConditions(BaseModel):
    """Geotechnical assumptions that drive foundation design and excavation."""

    model_config = ConfigDict(frozen=True)

    #: Allowable bearing pressure in kN/m².
    bearing_capacity_kpa: float = Field(default=100.0, gt=0.0)
    #: Depth to a competent stratum, in metres. Drives foundation depth.
    competent_stratum_depth: float = Field(default=0.9, gt=0.0)
    water_table_depth: float = Field(default=3.0, gt=0.0)
    #: Higher values require deeper foundations near trees (NHBC Chapter 4.2).
    shrinkable_clay: bool = False
    contaminated: bool = False
    #: Multiplier applied to excavation labour for difficult ground.
    excavation_difficulty: float = Field(default=1.0, ge=0.5, le=4.0)

    @property
    def recommended_foundation_depth(self) -> float:
        """Minimum foundation depth in metres for these conditions."""
        depth = max(0.9, self.competent_stratum_depth)
        if self.shrinkable_clay:
            depth = max(depth, 1.5)
        return round(depth, 2)


class AccessPoint(BaseModel):
    """A gate or crossing where vehicles enter the site."""

    model_config = ConfigDict(frozen=True)

    id: str
    name: str = "Site access"
    position: Vec3
    #: Widest vehicle that can use this access, in metres.
    max_vehicle_width: float = Field(default=2.9, gt=0.0)
    max_vehicle_length: float = Field(default=16.5, gt=0.0)
    max_gross_weight_tonnes: float = Field(default=44.0, gt=0.0)

    def admits(self, width: float, length: float, weight_tonnes: float) -> bool:
        """True if a vehicle of the given envelope can use this access."""
        return (
            width <= self.max_vehicle_width
            and length <= self.max_vehicle_length
            and weight_tonnes <= self.max_gross_weight_tonnes
        )


class Plot(BaseModel):
    """A single dwelling plot within a site."""

    model_config = ConfigDict(validate_assignment=True)

    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    boundary: Footprint
    #: Identifier of the building occupying this plot, if any.
    building_id: str | None = None
    #: Minimum distance from the boundary to any structure, in metres.
    setback: float = Field(default=1.0, ge=0.0)
    ground_conditions: GroundConditions = Field(default_factory=GroundConditions)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def area(self) -> float:
        return self.boundary.area

    @property
    def buildable_area(self) -> Footprint | None:
        """The boundary inset by the setback, or ``None`` if it collapses."""
        if self.setback <= 0:
            return self.boundary
        return self.boundary.offset(-self.setback)

    def can_accommodate(self, footprint: Footprint) -> bool:
        """True if ``footprint`` sits inside the buildable envelope."""
        envelope = self.buildable_area
        if envelope is None:
            return False
        return envelope.contains_footprint(footprint)

    def assert_accommodates(self, footprint: Footprint) -> None:
        """Raise :class:`SiteError` if the footprint breaches the envelope."""
        if not self.can_accommodate(footprint):
            raise SiteError(
                "Building footprint breaches the plot setback envelope",
                plot_id=self.id,
                plot_area=round(self.area, 2),
                footprint_area=round(footprint.area, 2),
                setback=self.setback,
            )


class Site(BaseModel):
    """The development site containing one or more plots."""

    model_config = ConfigDict(validate_assignment=True)

    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    boundary: Footprint
    plots: tuple[Plot, ...] = ()
    access_points: tuple[AccessPoint, ...] = ()
    #: Ordnance datum level of the site origin, in metres.
    datum_level: float = 0.0
    ground_conditions: GroundConditions = Field(default_factory=GroundConditions)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_plot_ids_unique(self) -> Site:
        ids = [plot.id for plot in self.plots]
        if len(ids) != len(set(ids)):
            duplicates = sorted({i for i in ids if ids.count(i) > 1})
            raise ValueError(f"Duplicate plot identifiers: {duplicates}")
        return self

    @property
    def area(self) -> float:
        return self.boundary.area

    @property
    def developed_area(self) -> float:
        return sum(plot.area for plot in self.plots)

    @property
    def working_area(self) -> float:
        """Site area outside the plots — where compounds and storage go."""
        return max(0.0, self.area - self.developed_area)

    def plot(self, plot_id: str) -> Plot:
        for plot in self.plots:
            if plot.id == plot_id:
                return plot
        raise SiteError("Unknown plot id", plot_id=plot_id, site_id=self.id)

    def add_plot(self, plot: Plot, *, check_containment: bool = True) -> Site:
        """Add a plot, optionally verifying that it lies within the site."""
        if any(existing.id == plot.id for existing in self.plots):
            raise SiteError("Duplicate plot id", plot_id=plot.id)
        if check_containment and not self.boundary.contains_footprint(plot.boundary):
            raise SiteError(
                "Plot boundary is not contained within the site boundary",
                plot_id=plot.id,
                site_id=self.id,
            )
        self.plots = (*self.plots, plot)
        return self

    def add_access_point(self, access: AccessPoint) -> Site:
        if any(existing.id == access.id for existing in self.access_points):
            raise SiteError("Duplicate access point id", access_id=access.id)
        self.access_points = (*self.access_points, access)
        return self

    def overlapping_plots(self) -> list[tuple[str, str]]:
        """Pairs of plot identifiers whose boundaries overlap."""
        clashes: list[tuple[str, str]] = []
        plots = list(self.plots)
        for index, first in enumerate(plots):
            for second in plots[index + 1 :]:
                if first.boundary.overlaps(second.boundary):
                    clashes.append((first.id, second.id))
        return clashes

    def statistics(self) -> dict[str, Any]:
        return {
            "site_id": self.id,
            "site_area_m2": round(self.area, 2),
            "plot_count": len(self.plots),
            "developed_area_m2": round(self.developed_area, 2),
            "working_area_m2": round(self.working_area, 2),
            "density_plots_per_hectare": (
                round(len(self.plots) / (self.area / 10_000.0), 2) if self.area > 0 else 0.0
            ),
            "access_points": len(self.access_points),
        }

    @classmethod
    def rectangular(
        cls,
        id: str,
        name: str,
        length: float,
        width: float,
        **kwargs: Any,
    ) -> Site:
        """Convenience constructor for a rectangular site at the origin."""
        return cls(id=id, name=name, boundary=Footprint.rectangle(length, width), **kwargs)
