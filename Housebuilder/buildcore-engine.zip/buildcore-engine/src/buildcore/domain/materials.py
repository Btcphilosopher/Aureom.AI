"""Materials and the material catalogue.

A :class:`Material` is a *specification*, not a quantity: it carries density,
unit rate, procurement lead time, storage class and coverage constants. The
quantification engine multiplies measured quantities by these constants; the
procurement engine reads lead times; the logistics engine reads storage class
and delivery unit.

The bundled :func:`standard_catalogue` reflects mainstream UK residential
construction (metric brick, blockwork inner leaf, C-grade structural timber,
plain clay tiles). Rates are indicative benchmark values in GBP and are
expected to be overridden by a live cost feed in production — every rate is
therefore isolated in one place rather than embedded in calculations.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.exceptions import MaterialError
from ..core.units import Unit
from .enums import MaterialClass, ProcurementStrategy, StorageClass

__all__ = ["Material", "MaterialCatalogue", "standard_catalogue"]


class Material(BaseModel):
    """Specification of a single purchasable material."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str = Field(description="Stable catalogue key, e.g. 'BRICK_FACING'.")
    name: str
    material_class: MaterialClass
    unit: Unit = Field(description="Unit in which the material is measured and priced.")
    unit_cost: float = Field(ge=0.0, description="Cost per `unit` in project currency.")
    density_kg_m3: float = Field(default=0.0, ge=0.0, description="0 if not volumetric.")

    #: Mass of one purchase unit — used for delivery and crane-lift planning.
    unit_mass_kg: float = Field(default=0.0, ge=0.0)
    lead_time_days: int = Field(default=7, ge=0, le=365)
    storage_class: StorageClass = StorageClass.OPEN_STACK
    procurement_strategy: ProcurementStrategy = ProcurementStrategy.STAGED
    #: Minimum order quantity, in `unit`. 0 means no minimum.
    minimum_order: float = Field(default=0.0, ge=0.0)
    #: Order granularity (pack size). 0 means continuously divisible.
    order_increment: float = Field(default=0.0, ge=0.0)
    supplier: str | None = None
    #: Optional class-specific override of the global waste allowance.
    waste_factor: float | None = Field(default=None, ge=0.0, le=0.5)
    carbon_kg_co2e_per_unit: float = Field(default=0.0, ge=0.0)

    @model_validator(mode="after")
    def _derive_unit_mass(self) -> Material:
        """Fill in ``unit_mass_kg`` from density where it is derivable."""
        if self.unit_mass_kg == 0.0 and self.density_kg_m3 > 0.0:
            if self.unit is Unit.CUBIC_METRE:
                object.__setattr__(self, "unit_mass_kg", self.density_kg_m3)
            elif self.unit is Unit.LITRE:
                object.__setattr__(self, "unit_mass_kg", self.density_kg_m3 / 1000.0)
        return self

    def cost_for(self, quantity: float) -> float:
        """Net material cost for ``quantity`` of this material."""
        return round(quantity * self.unit_cost, 2)

    def mass_for(self, quantity: float) -> float:
        """Mass in kilograms for ``quantity`` of this material."""
        return quantity * self.unit_mass_kg

    def orderable_quantity(self, quantity: float) -> float:
        """Round ``quantity`` up to a purchasable amount.

        Applies the minimum order first, then rounds up to the next whole
        ``order_increment`` (pack, pallet, load).
        """
        import math

        adjusted = max(quantity, self.minimum_order)
        if self.order_increment > 0:
            packs = math.ceil(adjusted / self.order_increment - 1e-9)
            adjusted = packs * self.order_increment
        elif self.unit is Unit.EACH:
            adjusted = float(math.ceil(adjusted - 1e-9))
        return round(adjusted, 4)

    def __repr__(self) -> str:  # pragma: no cover
        return f"Material({self.id}, {self.unit_cost:.2f}/{self.unit.value})"


class MaterialCatalogue:
    """An indexed, immutable-by-convention collection of materials."""

    def __init__(self, materials: Iterable[Material] = ()) -> None:
        self._by_id: dict[str, Material] = {}
        for material in materials:
            self.add(material)

    # -- mutation ---------------------------------------------------------- #
    def add(self, material: Material, *, replace: bool = False) -> MaterialCatalogue:
        if material.id in self._by_id and not replace:
            raise MaterialError("Duplicate material id", material_id=material.id)
        self._by_id[material.id] = material
        return self

    def extend(self, materials: Iterable[Material], *, replace: bool = False) -> MaterialCatalogue:
        for material in materials:
            self.add(material, replace=replace)
        return self

    def remove(self, material_id: str) -> None:
        if material_id not in self._by_id:
            raise MaterialError("Unknown material id", material_id=material_id)
        del self._by_id[material_id]

    # -- lookup ------------------------------------------------------------ #
    def get(self, material_id: str) -> Material:
        try:
            return self._by_id[material_id]
        except KeyError as exc:
            raise MaterialError(
                "Unknown material id",
                material_id=material_id,
                available=len(self._by_id),
            ) from exc

    def find(self, material_id: str) -> Material | None:
        return self._by_id.get(material_id)

    def by_class(self, material_class: MaterialClass) -> list[Material]:
        return [m for m in self._by_id.values() if m.material_class is material_class]

    def ids(self) -> list[str]:
        return sorted(self._by_id)

    def __contains__(self, material_id: object) -> bool:
        return material_id in self._by_id

    def __len__(self) -> int:
        return len(self._by_id)

    def __iter__(self) -> Iterator[Material]:
        return iter(self._by_id.values())

    def copy(self) -> MaterialCatalogue:
        return MaterialCatalogue(self._by_id.values())

    def with_price_adjustment(self, factor: float) -> MaterialCatalogue:
        """Return a catalogue with every rate scaled — for inflation scenarios."""
        if factor <= 0:
            raise MaterialError("Price adjustment factor must be positive", factor=factor)
        return MaterialCatalogue(
            m.model_copy(update={"unit_cost": round(m.unit_cost * factor, 4)}) for m in self
        )

    def __repr__(self) -> str:  # pragma: no cover
        return f"MaterialCatalogue({len(self._by_id)} materials)"


# --------------------------------------------------------------------------- #
# Standard UK residential catalogue
# --------------------------------------------------------------------------- #
_STANDARD: tuple[Material, ...] = (
    # --- masonry --------------------------------------------------------- #
    Material(
        id="BRICK_FACING",
        name="Facing brick, 215×102.5×65mm",
        material_class=MaterialClass.MASONRY,
        unit=Unit.EACH,
        unit_cost=0.62,
        density_kg_m3=1900.0,
        unit_mass_kg=2.6,
        lead_time_days=21,
        storage_class=StorageClass.OPEN_STACK,
        order_increment=500.0,  # standard pack
        carbon_kg_co2e_per_unit=0.55,
    ),
    Material(
        id="BLOCK_AAC_100",
        name="Aerated concrete block, 440×215×100mm",
        material_class=MaterialClass.MASONRY,
        unit=Unit.EACH,
        unit_cost=1.85,
        density_kg_m3=600.0,
        unit_mass_kg=5.7,
        lead_time_days=14,
        order_increment=48.0,
        carbon_kg_co2e_per_unit=1.9,
    ),
    Material(
        id="MORTAR_M4",
        name="Designation (iii) mortar, 1:1:6",
        material_class=MaterialClass.MORTAR,
        unit=Unit.CUBIC_METRE,
        unit_cost=185.0,
        density_kg_m3=2000.0,
        lead_time_days=3,
        storage_class=StorageClass.COVERED,
        procurement_strategy=ProcurementStrategy.JUST_IN_TIME,
        carbon_kg_co2e_per_unit=290.0,
    ),
    Material(
        id="WALL_TIE_SS",
        name="Stainless steel cavity wall tie, 225mm",
        material_class=MaterialClass.FIXING,
        unit=Unit.EACH,
        unit_cost=0.42,
        unit_mass_kg=0.05,
        lead_time_days=7,
        order_increment=250.0,
    ),
    # --- concrete -------------------------------------------------------- #
    Material(
        id="CONCRETE_C25",
        name="Ready-mix concrete C25/30",
        material_class=MaterialClass.CONCRETE,
        unit=Unit.CUBIC_METRE,
        unit_cost=142.0,
        density_kg_m3=2400.0,
        lead_time_days=2,
        procurement_strategy=ProcurementStrategy.JUST_IN_TIME,
        minimum_order=6.0,
        carbon_kg_co2e_per_unit=280.0,
    ),
    Material(
        id="CONCRETE_C35",
        name="Ready-mix concrete C35/45, foundation grade",
        material_class=MaterialClass.CONCRETE,
        unit=Unit.CUBIC_METRE,
        unit_cost=158.0,
        density_kg_m3=2450.0,
        lead_time_days=2,
        procurement_strategy=ProcurementStrategy.JUST_IN_TIME,
        minimum_order=6.0,
        carbon_kg_co2e_per_unit=330.0,
    ),
    Material(
        id="HARDCORE_MOT1",
        name="MOT Type 1 sub-base",
        material_class=MaterialClass.AGGREGATE,
        unit=Unit.TONNE,
        unit_cost=38.0,
        density_kg_m3=2100.0,
        unit_mass_kg=1000.0,
        lead_time_days=3,
        carbon_kg_co2e_per_unit=8.0,
    ),
    Material(
        id="SAND_BLINDING",
        name="Sharp sand blinding",
        material_class=MaterialClass.AGGREGATE,
        unit=Unit.TONNE,
        unit_cost=44.0,
        density_kg_m3=1600.0,
        unit_mass_kg=1000.0,
        lead_time_days=3,
    ),
    Material(
        id="REBAR_A393",
        name="A393 steel reinforcement mesh",
        material_class=MaterialClass.STEEL,
        unit=Unit.SQUARE_METRE,
        unit_cost=11.40,
        unit_mass_kg=6.16,
        lead_time_days=14,
        carbon_kg_co2e_per_unit=12.5,
    ),
    Material(
        id="DPM_1200G",
        name="1200 gauge polythene damp-proof membrane",
        material_class=MaterialClass.MEMBRANE,
        unit=Unit.SQUARE_METRE,
        unit_cost=1.35,
        unit_mass_kg=0.29,
        lead_time_days=5,
        storage_class=StorageClass.COVERED,
    ),
    # --- timber and steel ------------------------------------------------ #
    Material(
        id="TIMBER_C24",
        name="C24 graded structural softwood",
        material_class=MaterialClass.TIMBER,
        unit=Unit.CUBIC_METRE,
        unit_cost=680.0,
        density_kg_m3=420.0,
        lead_time_days=10,
        storage_class=StorageClass.COVERED,
        carbon_kg_co2e_per_unit=110.0,
    ),
    Material(
        id="TIMBER_TREATED",
        name="Treated softwood, roof battens and sole plates",
        material_class=MaterialClass.TIMBER,
        unit=Unit.CUBIC_METRE,
        unit_cost=740.0,
        density_kg_m3=450.0,
        lead_time_days=10,
        storage_class=StorageClass.COVERED,
    ),
    Material(
        id="OSB3_18MM",
        name="18mm OSB3 structural board",
        material_class=MaterialClass.TIMBER,
        unit=Unit.SQUARE_METRE,
        unit_cost=13.80,
        unit_mass_kg=11.5,
        lead_time_days=7,
        storage_class=StorageClass.COVERED,
    ),
    Material(
        id="STEEL_UB_S275",
        name="S275 universal beam",
        material_class=MaterialClass.STEEL,
        unit=Unit.KILOGRAM,
        unit_cost=1.95,
        density_kg_m3=7850.0,
        unit_mass_kg=1.0,
        lead_time_days=35,
        storage_class=StorageClass.OPEN_STACK,
        procurement_strategy=ProcurementStrategy.BULK_UPFRONT,
        carbon_kg_co2e_per_unit=1.55,
    ),
    Material(
        id="JOIST_HANGER",
        name="Galvanised joist hanger",
        material_class=MaterialClass.FIXING,
        unit=Unit.EACH,
        unit_cost=1.75,
        unit_mass_kg=0.24,
        lead_time_days=7,
    ),
    Material(
        id="NAILS_FIXINGS",
        name="Structural nails and fixings, mixed",
        material_class=MaterialClass.FIXING,
        unit=Unit.KILOGRAM,
        unit_cost=4.10,
        unit_mass_kg=1.0,
        lead_time_days=5,
        storage_class=StorageClass.SECURE,
    ),
    # --- roof ------------------------------------------------------------ #
    Material(
        id="TILE_PLAIN_CLAY",
        name="Plain clay roof tile, 265×165mm",
        material_class=MaterialClass.ROOF_COVERING,
        unit=Unit.EACH,
        unit_cost=0.78,
        unit_mass_kg=1.4,
        lead_time_days=28,
        order_increment=100.0,
        carbon_kg_co2e_per_unit=0.65,
    ),
    Material(
        id="ROOF_MEMBRANE",
        name="Breathable roofing underlay",
        material_class=MaterialClass.MEMBRANE,
        unit=Unit.SQUARE_METRE,
        unit_cost=2.20,
        unit_mass_kg=0.14,
        lead_time_days=7,
        storage_class=StorageClass.COVERED,
    ),
    Material(
        id="RIDGE_TILE",
        name="Half-round ridge tile",
        material_class=MaterialClass.ROOF_COVERING,
        unit=Unit.EACH,
        unit_cost=8.90,
        unit_mass_kg=5.2,
        lead_time_days=28,
    ),
    # --- envelope -------------------------------------------------------- #
    Material(
        id="INSUL_PIR_100",
        name="100mm PIR rigid insulation board",
        material_class=MaterialClass.INSULATION,
        unit=Unit.SQUARE_METRE,
        unit_cost=22.50,
        unit_mass_kg=3.2,
        lead_time_days=14,
        storage_class=StorageClass.COVERED,
        carbon_kg_co2e_per_unit=9.8,
    ),
    Material(
        id="INSUL_MINERAL_WOOL",
        name="Mineral wool quilt, 150mm",
        material_class=MaterialClass.INSULATION,
        unit=Unit.SQUARE_METRE,
        unit_cost=8.40,
        unit_mass_kg=2.4,
        lead_time_days=10,
        storage_class=StorageClass.COVERED,
        carbon_kg_co2e_per_unit=2.1,
    ),
    Material(
        id="WINDOW_UPVC_DG",
        name="uPVC double-glazed window unit",
        material_class=MaterialClass.GLAZING,
        unit=Unit.SQUARE_METRE,
        unit_cost=315.0,
        unit_mass_kg=26.0,
        lead_time_days=42,
        storage_class=StorageClass.SECURE,
        procurement_strategy=ProcurementStrategy.CALL_OFF,
        carbon_kg_co2e_per_unit=88.0,
    ),
    Material(
        id="DOOR_EXTERNAL",
        name="Composite external door set",
        material_class=MaterialClass.JOINERY,
        unit=Unit.EACH,
        unit_cost=680.0,
        unit_mass_kg=45.0,
        lead_time_days=42,
        storage_class=StorageClass.SECURE,
        procurement_strategy=ProcurementStrategy.CALL_OFF,
    ),
    Material(
        id="DOOR_INTERNAL",
        name="Internal door and lining set",
        material_class=MaterialClass.JOINERY,
        unit=Unit.EACH,
        unit_cost=145.0,
        unit_mass_kg=22.0,
        lead_time_days=21,
        storage_class=StorageClass.SECURE,
    ),
    # --- internal finishes ----------------------------------------------- #
    Material(
        id="PLASTERBOARD_12_5",
        name="12.5mm tapered-edge plasterboard",
        material_class=MaterialClass.PLASTERBOARD,
        unit=Unit.SQUARE_METRE,
        unit_cost=5.60,
        unit_mass_kg=9.5,
        lead_time_days=7,
        storage_class=StorageClass.COVERED,
        carbon_kg_co2e_per_unit=2.9,
    ),
    Material(
        id="PLASTER_SKIM",
        name="Multi-finish skim plaster",
        material_class=MaterialClass.FINISH,
        unit=Unit.SQUARE_METRE,
        unit_cost=2.35,
        unit_mass_kg=3.4,
        lead_time_days=5,
        storage_class=StorageClass.COVERED,
    ),
    Material(
        id="PAINT_EMULSION",
        name="Vinyl matt emulsion paint",
        material_class=MaterialClass.PAINT,
        unit=Unit.LITRE,
        unit_cost=4.80,
        density_kg_m3=1300.0,
        lead_time_days=5,
        storage_class=StorageClass.LIQUID_BUNDED,
        order_increment=10.0,
    ),
    Material(
        id="SCREED_50MM",
        name="Sand:cement floor screed",
        material_class=MaterialClass.CONCRETE,
        unit=Unit.CUBIC_METRE,
        unit_cost=168.0,
        density_kg_m3=2100.0,
        lead_time_days=3,
        procurement_strategy=ProcurementStrategy.JUST_IN_TIME,
    ),
    Material(
        id="FLOOR_FINISH_LVT",
        name="Luxury vinyl tile floor finish",
        material_class=MaterialClass.FINISH,
        unit=Unit.SQUARE_METRE,
        unit_cost=28.00,
        unit_mass_kg=5.1,
        lead_time_days=21,
        storage_class=StorageClass.SECURE,
    ),
    # --- services -------------------------------------------------------- #
    Material(
        id="CABLE_TWIN_EARTH",
        name="6242Y twin and earth cable, 2.5mm²",
        material_class=MaterialClass.CABLE,
        unit=Unit.METRE,
        unit_cost=1.65,
        unit_mass_kg=0.12,
        lead_time_days=7,
        storage_class=StorageClass.SECURE,
        order_increment=50.0,
    ),
    Material(
        id="ELECTRICAL_ACCESSORY",
        name="Socket / switch / luminaire accessory",
        material_class=MaterialClass.CABLE,
        unit=Unit.EACH,
        unit_cost=14.50,
        unit_mass_kg=0.3,
        lead_time_days=10,
        storage_class=StorageClass.SECURE,
    ),
    Material(
        id="PIPE_COPPER_15",
        name="15mm copper pipe",
        material_class=MaterialClass.PLASTIC,
        unit=Unit.METRE,
        unit_cost=6.30,
        unit_mass_kg=0.39,
        lead_time_days=10,
        storage_class=StorageClass.SECURE,
    ),
    Material(
        id="PIPE_SOIL_110",
        name="110mm uPVC soil and drainage pipe",
        material_class=MaterialClass.PLASTIC,
        unit=Unit.METRE,
        unit_cost=9.20,
        unit_mass_kg=1.8,
        lead_time_days=10,
    ),
    Material(
        id="SANITARYWARE",
        name="Sanitaryware item (WC / basin / bath)",
        material_class=MaterialClass.FINISH,
        unit=Unit.EACH,
        unit_cost=240.0,
        unit_mass_kg=32.0,
        lead_time_days=28,
        storage_class=StorageClass.SECURE,
    ),
    # --- external -------------------------------------------------------- #
    Material(
        id="PAVING_BLOCK",
        name="Concrete block paving",
        material_class=MaterialClass.MASONRY,
        unit=Unit.SQUARE_METRE,
        unit_cost=32.0,
        unit_mass_kg=115.0,
        lead_time_days=14,
    ),
    Material(
        id="TOPSOIL",
        name="Screened topsoil",
        material_class=MaterialClass.AGGREGATE,
        unit=Unit.CUBIC_METRE,
        unit_cost=42.0,
        density_kg_m3=1400.0,
        unit_mass_kg=1400.0,
        lead_time_days=5,
    ),
    Material(
        id="RENDER_SILICONE",
        name="Silicone through-coloured render",
        material_class=MaterialClass.FINISH,
        unit=Unit.SQUARE_METRE,
        unit_cost=34.0,
        unit_mass_kg=18.0,
        lead_time_days=14,
        storage_class=StorageClass.COVERED,
    ),
)


def standard_catalogue() -> MaterialCatalogue:
    """Return a fresh copy of the bundled UK residential material catalogue."""
    return MaterialCatalogue(_STANDARD)
