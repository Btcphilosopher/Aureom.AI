"""The :class:`Building` aggregate root.

A ``Building`` owns its components, its identifier generator and its
relationship to a plot. It is the transactional boundary: every mutation goes
through it, and every mutation emits a domain event so that downstream engines
can invalidate caches without polling.

Serialisation lives here too. :meth:`Building.to_dict` and
:meth:`Building.from_dict` round-trip the whole model through plain JSON via
the discriminated union in :mod:`buildcore.domain.components`, which is what
the Rust storage layer and the REST API both consume.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from typing import Any

from pydantic import TypeAdapter

from ..core.events import (
    BuildingCreated,
    ComponentAdded,
    ComponentRemoved,
    ComponentStatusChanged,
    DependencyAdded,
    DependencyRemoved,
    EventBus,
    GraphInvalidated,
    NullEventBus,
)
from ..core.exceptions import ComponentError, MissingDependencyError
from ..core.identifiers import IdGenerator
from .components import AnyComponent, BuildingComponent, LabourDemand, MaterialDemand
from .enums import ComponentKind, ConstructionStage, InstallationStatus
from .geometry import BoundingBox, Footprint
from .materials import MaterialCatalogue, standard_catalogue
from .registry import ComponentRegistry
from .site import Plot, Site

__all__ = ["Building"]

_COMPONENT_ADAPTER: TypeAdapter[BuildingComponent] = TypeAdapter(AnyComponent)  # type: ignore[arg-type]
_COMPONENT_LIST_ADAPTER: TypeAdapter[list[BuildingComponent]] = TypeAdapter(
    list[AnyComponent]  # type: ignore[valid-type]
)

SCHEMA_VERSION = "1.0"


class Building:
    """Aggregate root for one dwelling (or one structure) under construction."""

    def __init__(
        self,
        id: str,
        name: str,
        *,
        plot: Plot | None = None,
        site: Site | None = None,
        catalogue: MaterialCatalogue | None = None,
        event_bus: EventBus | None = None,
        registry: ComponentRegistry | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if not id or not name:
            raise ValueError("Building requires a non-empty id and name")
        self.id = id
        self.name = name
        self.plot = plot
        self.site = site
        self.catalogue = catalogue or standard_catalogue()
        self.metadata: dict[str, Any] = dict(metadata or {})
        self.created_at = datetime.now(UTC)

        self._registry = registry or ComponentRegistry()
        self._events = event_bus or NullEventBus()
        self._ids = IdGenerator(namespace=id)

        self._events.publish(BuildingCreated(building_id=self.id, building_name=self.name))

    # -- collaborators ----------------------------------------------------- #
    @property
    def registry(self) -> ComponentRegistry:
        return self._registry

    @property
    def events(self) -> EventBus:
        return self._events

    @property
    def ids(self) -> IdGenerator:
        return self._ids

    # -- component lifecycle ----------------------------------------------- #
    def next_id(self, kind: ComponentKind | str) -> str:
        """Issue a deterministic identifier for a component of ``kind``."""
        prefix = kind.prefix if isinstance(kind, ComponentKind) else str(kind).upper()
        return self._ids.next(prefix)

    def add(self, component: BuildingComponent) -> BuildingComponent:
        """Add a component and emit :class:`ComponentAdded`."""
        self._registry.add(component)
        self._events.publish(
            ComponentAdded(
                building_id=self.id,
                component_id=component.id,
                kind=component.kind.value,
                stage=component.stage.name,
            )
        )
        return component

    def add_all(self, components: Iterable[BuildingComponent]) -> list[BuildingComponent]:
        return [self.add(component) for component in components]

    def remove(self, component_id: str) -> BuildingComponent:
        """Remove a component and detach any dependencies pointing at it."""
        component = self._registry.remove(component_id)
        for other in self._registry:
            other.remove_dependency(component_id)
        self._events.publish(ComponentRemoved(building_id=self.id, component_id=component_id))
        self._events.publish(
            GraphInvalidated(reason=f"component {component_id} removed")
        )
        return component

    def get(self, component_id: str) -> BuildingComponent:
        return self._registry.get(component_id)

    def find(self, component_id: str) -> BuildingComponent | None:
        return self._registry.find(component_id)

    def __contains__(self, component_id: object) -> bool:
        return component_id in self._registry

    def __len__(self) -> int:
        return len(self._registry)

    def __iter__(self) -> Iterator[BuildingComponent]:
        return iter(self._registry)

    @property
    def components(self) -> list[BuildingComponent]:
        return self._registry.all()

    # -- dependencies ------------------------------------------------------ #
    def link(self, predecessor_id: str, successor_id: str) -> None:
        """Declare that ``successor_id`` depends on ``predecessor_id``.

        Both components must exist; a missing endpoint is an error rather than
        a silently dangling edge, because dangling edges surface much later as
        confusing scheduling failures.
        """
        if predecessor_id not in self._registry:
            raise MissingDependencyError(
                "Predecessor does not exist", predecessor_id=predecessor_id
            )
        successor = self._registry.get(successor_id)
        successor.add_dependency(predecessor_id)
        self._events.publish(
            DependencyAdded(predecessor_id=predecessor_id, successor_id=successor_id)
        )
        self._events.publish(GraphInvalidated(reason="dependency added"))

    def link_many(self, predecessor_ids: Iterable[str], successor_id: str) -> None:
        for predecessor_id in predecessor_ids:
            self.link(predecessor_id, successor_id)

    def unlink(self, predecessor_id: str, successor_id: str) -> bool:
        successor = self._registry.get(successor_id)
        removed = successor.remove_dependency(predecessor_id)
        if removed:
            self._events.publish(
                DependencyRemoved(predecessor_id=predecessor_id, successor_id=successor_id)
            )
            self._events.publish(GraphInvalidated(reason="dependency removed"))
        return removed

    def dangling_dependencies(self) -> list[tuple[str, str]]:
        """``(component_id, missing_predecessor_id)`` pairs."""
        dangling: list[tuple[str, str]] = []
        for component in self._registry:
            for dependency in component.depends_on:
                if dependency not in self._registry:
                    dangling.append((component.id, dependency))
        return dangling

    # -- status ------------------------------------------------------------ #
    def set_status(
        self, component_id: str, status: InstallationStatus, *, force: bool = False
    ) -> InstallationStatus:
        """Transition a component and emit :class:`ComponentStatusChanged`."""
        previous = self._registry.set_status(component_id, status, force=force)
        if previous is not status:
            self._events.publish(
                ComponentStatusChanged(
                    component_id=component_id, previous=previous.value, current=status.value
                )
            )
        return previous

    def advance(self, component_id: str) -> InstallationStatus:
        """Move a component one step along the canonical status path."""
        component = self._registry.get(component_id)
        path = [
            InstallationStatus.SCHEDULED,
            InstallationStatus.MATERIALS_ORDERED,
            InstallationStatus.MATERIALS_ON_SITE,
            InstallationStatus.IN_PROGRESS,
            InstallationStatus.INSTALLED,
            InstallationStatus.INSPECTED,
            InstallationStatus.COMPLETE,
        ]
        for candidate in path:
            if component.can_transition_to(candidate):
                self.set_status(component_id, candidate)
                return candidate
        raise ComponentError(
            "Component cannot be advanced further",
            component_id=component_id,
            status=component.status.value,
        )

    def complete_all(self) -> int:
        """Force every component to COMPLETE. Used to test terminal states."""
        count = 0
        for component in self._registry:
            if not component.is_complete:
                self.set_status(component.id, InstallationStatus.COMPLETE, force=True)
                count += 1
        return count

    # -- geometry ---------------------------------------------------------- #
    @property
    def bounding_box(self) -> BoundingBox | None:
        """Enclosing box of every component, or ``None`` for an empty model."""
        return BoundingBox.enclosing(c.bounding_box for c in self._registry)

    def footprint(self) -> Footprint | None:
        """Rectangular plan envelope derived from the bounding box."""
        box = self.bounding_box
        if box is None:
            return None
        size = box.size
        if size.x <= 0 or size.y <= 0:
            return None
        return Footprint.rectangle(size.x, size.y, origin=(box.minimum.x, box.minimum.y))

    @property
    def gross_internal_area(self) -> float:
        """Sum of slab and upper-floor plan areas, in m²."""
        total = 0.0
        for component in self._registry.by_kind(ComponentKind.FLOOR_SLAB):
            total += component.measured_area
        for component in self._registry.by_kind(ComponentKind.FLOOR):
            total += component.measured_area
        return round(total, 3)

    # -- aggregation ------------------------------------------------------- #
    def material_demands(self) -> list[MaterialDemand]:
        return self._registry.material_demands()

    def labour_demands(self) -> list[LabourDemand]:
        return self._registry.labour_demands()

    def total_mass(self) -> float:
        """Installed mass of the whole building, in kilograms."""
        return round(sum(c.mass(self.catalogue) for c in self._registry), 2)

    def net_material_cost(self) -> float:
        """Net material cost before waste, labour, preliminaries and markup."""
        return round(sum(c.material_cost(self.catalogue) for c in self._registry), 2)

    def stages(self) -> list[ConstructionStage]:
        return self._registry.stages_present()

    def statistics(self) -> dict[str, Any]:
        stats = self._registry.statistics()
        box = self.bounding_box
        stats.update(
            {
                "building_id": self.id,
                "name": self.name,
                "plot_id": self.plot.id if self.plot else None,
                "gross_internal_area_m2": self.gross_internal_area,
                "total_mass_kg": self.total_mass(),
                "net_material_cost": self.net_material_cost(),
                "bounding_box_m": (
                    {
                        "min": box.minimum.as_tuple(),
                        "max": box.maximum.as_tuple(),
                    }
                    if box
                    else None
                ),
                "dangling_dependencies": len(self.dangling_dependencies()),
            }
        )
        return stats

    # -- serialisation ----------------------------------------------------- #
    def to_dict(self) -> dict[str, Any]:
        """Full JSON-safe representation of the building."""
        return {
            "schema_version": SCHEMA_VERSION,
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
            "plot": self.plot.model_dump(mode="json") if self.plot else None,
            "site": self.site.model_dump(mode="json") if self.site else None,
            "components": [c.model_dump(mode="json") for c in self._registry],
        }

    def to_json(self, *, indent: int | None = None) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=False)

    @classmethod
    def from_dict(
        cls,
        payload: dict[str, Any],
        *,
        catalogue: MaterialCatalogue | None = None,
        event_bus: EventBus | None = None,
    ) -> Building:
        """Rebuild a :class:`Building` from :meth:`to_dict` output."""
        version = payload.get("schema_version")
        if version is not None and version != SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported schema version {version!r}; expected {SCHEMA_VERSION!r}"
            )

        plot = Plot.model_validate(payload["plot"]) if payload.get("plot") else None
        site = Site.model_validate(payload["site"]) if payload.get("site") else None

        building = cls(
            id=payload["id"],
            name=payload["name"],
            plot=plot,
            site=site,
            catalogue=catalogue,
            event_bus=event_bus,
            metadata=payload.get("metadata"),
        )
        components = _COMPONENT_LIST_ADAPTER.validate_python(payload.get("components", []))
        for component in components:
            building._registry.add(component)

        created = payload.get("created_at")
        if created:
            building.created_at = datetime.fromisoformat(created)
        return building

    @classmethod
    def from_json(cls, text: str, **kwargs: Any) -> Building:
        return cls.from_dict(json.loads(text), **kwargs)

    def clone(self, *, new_id: str | None = None, event_bus: EventBus | None = None) -> Building:
        """Deep copy, used by the scenario engine to fork a baseline model."""
        payload = self.to_dict()
        if new_id:
            payload["id"] = new_id
        return Building.from_dict(payload, catalogue=self.catalogue, event_bus=event_bus)

    def __repr__(self) -> str:  # pragma: no cover
        return f"Building({self.id!r}, {len(self._registry)} components)"
