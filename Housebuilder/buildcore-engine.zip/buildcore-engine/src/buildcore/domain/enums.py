"""Domain enumerations.

The most important type here is :class:`ConstructionStage`. It is an
:class:`~enum.IntEnum` whose *values encode the canonical build order*, so the
dependency graph can detect an impossible sequence (roof before foundations)
by integer comparison alone — no lookup table, no ordering configuration.

Values are spaced by 10 so that bespoke intermediate stages can be inserted by
downstream users without renumbering.
"""

from __future__ import annotations

from enum import Enum, IntEnum

__all__ = [
    "ComponentKind",
    "ConstructionStage",
    "InstallationStatus",
    "MaterialClass",
    "Orientation",
    "ProcurementStrategy",
    "StorageClass",
    "Trade",
]


class ConstructionStage(IntEnum):
    """Canonical residential construction stages, ordered by build sequence."""

    SITE_PREPARATION = 10
    EXCAVATION = 20
    FOUNDATIONS = 30
    DRAINAGE = 40
    FLOOR_SLAB = 50
    EXTERNAL_WALLS = 60
    STRUCTURAL_BEAMS = 70
    UPPER_FLOORS = 80
    INTERNAL_WALLS = 90
    ROOF_STRUCTURE = 100
    ROOF_COVERING = 110
    WINDOWS = 120
    DOORS = 130
    FIRST_FIX = 140
    INSULATION = 150
    PLASTERBOARD = 160
    SECOND_FIX = 170
    DECORATION = 180
    FLOOR_FINISHES = 190
    EXTERNAL_WORKS = 200
    COMPLETION = 210

    @property
    def label(self) -> str:
        """Human-readable stage name."""
        return self.name.replace("_", " ").title()

    @property
    def is_weather_sensitive(self) -> bool:
        """True for stages performed before the building is watertight.

        Used by the weather-delay model in the simulation engine: groundworks
        and superstructure are exposed, internal fit-out is not.
        """
        return self <= ConstructionStage.ROOF_COVERING

    @property
    def is_structural(self) -> bool:
        return ConstructionStage.FOUNDATIONS <= self <= ConstructionStage.ROOF_STRUCTURE

    @classmethod
    def ordered(cls) -> list[ConstructionStage]:
        """All stages in build order."""
        return sorted(cls)

    def successor(self) -> ConstructionStage | None:
        """The next stage in the canonical sequence, or ``None`` if last."""
        stages = ConstructionStage.ordered()
        index = stages.index(self)
        return stages[index + 1] if index + 1 < len(stages) else None

    def predecessor(self) -> ConstructionStage | None:
        stages = ConstructionStage.ordered()
        index = stages.index(self)
        return stages[index - 1] if index > 0 else None


class Trade(str, Enum):
    """Labour trades modelled by the Labour Engine."""

    GROUNDWORKER = "groundworker"
    CONCRETER = "concreter"
    BRICKLAYER = "bricklayer"
    SCAFFOLDER = "scaffolder"
    CARPENTER = "carpenter"
    STEEL_ERECTOR = "steel_erector"
    ROOFER = "roofer"
    GLAZIER = "glazier"
    ELECTRICIAN = "electrician"
    PLUMBER = "plumber"
    INSULATION_FITTER = "insulation_fitter"
    PLASTERER = "plasterer"
    DECORATOR = "decorator"
    FLOOR_LAYER = "floor_layer"
    LANDSCAPER = "landscaper"
    LABOURER = "labourer"
    CRANE_OPERATOR = "crane_operator"
    SITE_MANAGER = "site_manager"

    @property
    def label(self) -> str:
        return self.value.replace("_", " ").title()


class InstallationStatus(str, Enum):
    """Lifecycle of a physical component on site."""

    NOT_STARTED = "not_started"
    SCHEDULED = "scheduled"
    MATERIALS_ORDERED = "materials_ordered"
    MATERIALS_ON_SITE = "materials_on_site"
    IN_PROGRESS = "in_progress"
    INSTALLED = "installed"
    INSPECTED = "inspected"
    COMPLETE = "complete"
    REWORK_REQUIRED = "rework_required"

    @property
    def is_terminal(self) -> bool:
        return self is InstallationStatus.COMPLETE

    @property
    def is_physically_present(self) -> bool:
        """True once the component physically exists on site."""
        return self in {
            InstallationStatus.INSTALLED,
            InstallationStatus.INSPECTED,
            InstallationStatus.COMPLETE,
            InstallationStatus.REWORK_REQUIRED,
        }

    @property
    def progress_fraction(self) -> float:
        """Earned-value weighting for progress reporting."""
        return _PROGRESS_WEIGHT[self]


_PROGRESS_WEIGHT: dict[InstallationStatus, float] = {
    InstallationStatus.NOT_STARTED: 0.0,
    InstallationStatus.SCHEDULED: 0.0,
    InstallationStatus.MATERIALS_ORDERED: 0.05,
    InstallationStatus.MATERIALS_ON_SITE: 0.15,
    InstallationStatus.IN_PROGRESS: 0.50,
    InstallationStatus.INSTALLED: 0.90,
    InstallationStatus.INSPECTED: 0.97,
    InstallationStatus.COMPLETE: 1.00,
    InstallationStatus.REWORK_REQUIRED: 0.40,
}

#: Permitted status transitions. Enforced by ``BuildingComponent.transition_to``.
STATUS_TRANSITIONS: dict[InstallationStatus, frozenset[InstallationStatus]] = {
    InstallationStatus.NOT_STARTED: frozenset(
        {InstallationStatus.SCHEDULED, InstallationStatus.MATERIALS_ORDERED}
    ),
    InstallationStatus.SCHEDULED: frozenset(
        {InstallationStatus.MATERIALS_ORDERED, InstallationStatus.NOT_STARTED}
    ),
    InstallationStatus.MATERIALS_ORDERED: frozenset({InstallationStatus.MATERIALS_ON_SITE}),
    InstallationStatus.MATERIALS_ON_SITE: frozenset({InstallationStatus.IN_PROGRESS}),
    InstallationStatus.IN_PROGRESS: frozenset(
        {InstallationStatus.INSTALLED, InstallationStatus.REWORK_REQUIRED}
    ),
    InstallationStatus.INSTALLED: frozenset(
        {InstallationStatus.INSPECTED, InstallationStatus.REWORK_REQUIRED}
    ),
    InstallationStatus.INSPECTED: frozenset(
        {InstallationStatus.COMPLETE, InstallationStatus.REWORK_REQUIRED}
    ),
    InstallationStatus.REWORK_REQUIRED: frozenset({InstallationStatus.IN_PROGRESS}),
    InstallationStatus.COMPLETE: frozenset(),
}


class MaterialClass(str, Enum):
    """Broad material family, driving waste allowance and storage rules."""

    MASONRY = "masonry"
    CONCRETE = "concrete"
    MORTAR = "mortar"
    AGGREGATE = "aggregate"
    TIMBER = "timber"
    STEEL = "steel"
    INSULATION = "insulation"
    PLASTERBOARD = "plasterboard"
    ROOF_COVERING = "roof_covering"
    GLAZING = "glazing"
    JOINERY = "joinery"
    MEMBRANE = "membrane"
    PLASTIC = "plastic"
    CABLE = "cable"
    PAINT = "paint"
    FIXING = "fixing"
    FINISH = "finish"

    @property
    def label(self) -> str:
        return self.value.replace("_", " ").title()


class ComponentKind(str, Enum):
    """Discriminator for the polymorphic component union.

    The value doubles as the identifier prefix (uppercased) and as the
    Pydantic discriminated-union tag for JSON round-tripping.
    """

    SITE = "site"
    PLOT = "plot"
    EXCAVATION = "excavation"
    FOUNDATION = "foundation"
    DRAINAGE_RUN = "drainage_run"
    FLOOR_SLAB = "floor_slab"
    WALL = "wall"
    BEAM = "beam"
    COLUMN = "column"
    JOIST = "joist"
    FLOOR = "floor"
    ROOF_STRUCTURE = "roof_structure"
    ROOF_COVERING = "roof_covering"
    WINDOW = "window"
    DOOR = "door"
    INSULATION = "insulation"
    ELECTRICAL_CIRCUIT = "electrical_circuit"
    PLUMBING_RUN = "plumbing_run"
    INTERNAL_FINISH = "internal_finish"
    EXTERNAL_FINISH = "external_finish"

    @property
    def prefix(self) -> str:
        return self.value.upper()


class Orientation(str, Enum):
    """Cardinal orientation of a wall or roof plane."""

    NORTH = "north"
    EAST = "east"
    SOUTH = "south"
    WEST = "west"
    INTERNAL = "internal"

    @property
    def bearing_degrees(self) -> float | None:
        return {"north": 0.0, "east": 90.0, "south": 180.0, "west": 270.0}.get(self.value)


class StorageClass(str, Enum):
    """How a material must be stored on site — drives the logistics engine."""

    OPEN_STACK = "open_stack"
    COVERED = "covered"
    SECURE = "secure"
    LIQUID_BUNDED = "liquid_bunded"
    JUST_IN_TIME = "just_in_time"


class ProcurementStrategy(str, Enum):
    """How the procurement engine orders a material."""

    BULK_UPFRONT = "bulk_upfront"
    STAGED = "staged"
    JUST_IN_TIME = "just_in_time"
    CALL_OFF = "call_off"
