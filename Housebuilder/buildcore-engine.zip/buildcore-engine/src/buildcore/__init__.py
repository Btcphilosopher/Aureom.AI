"""BuildCore Engine — computational intelligence layer for a digital housebuilding platform."""

from .core.config import EngineSettings, default_settings
from .core.events import EventBus
from .core.logging import configure_logging, get_logger
from .domain.building import Building
from .domain.enums import ConstructionStage, InstallationStatus, Trade
from .domain.materials import standard_catalogue
from .domain.site import Plot, Site
from .fabrication.house_builder import HouseSpecification, StandardHouseBuilder, build_estate
from .graph.dependency_graph import ConstructionDependencyGraph

__version__ = "0.1.0"

__all__ = [
    "Building",
    "ConstructionDependencyGraph",
    "ConstructionStage",
    "EngineSettings",
    "EventBus",
    "HouseSpecification",
    "InstallationStatus",
    "Plot",
    "Site",
    "StandardHouseBuilder",
    "Trade",
    "__version__",
    "build_estate",
    "configure_logging",
    "default_settings",
    "get_logger",
    "standard_catalogue",
]
