"""Module 2 — construction dependency graph and ordering rules."""

from .dependency_graph import STAGE_GATE_PREFIX, ConstructionDependencyGraph
from .rules import (
    MANDATORY_STAGE_PRECEDENCE,
    RuleFinding,
    RuleSet,
    Severity,
    check_edge,
    missing_stage_links,
)

__all__ = [
    "MANDATORY_STAGE_PRECEDENCE",
    "STAGE_GATE_PREFIX",
    "ConstructionDependencyGraph",
    "RuleFinding",
    "RuleSet",
    "Severity",
    "check_edge",
    "missing_stage_links",
]
