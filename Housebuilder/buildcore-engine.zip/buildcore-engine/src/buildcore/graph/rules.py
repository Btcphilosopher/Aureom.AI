"""Canonical construction ordering rules.

Module 2 must "automatically detect dependency violations". Two independent
mechanisms do that:

1. **Stage ordering** — an edge whose predecessor sits at a *later* stage than
   its successor is physically impossible (you cannot make the roof a
   prerequisite of the foundations). Because
   :class:`~buildcore.domain.enums.ConstructionStage` encodes order in its
   integer values, this reduces to a comparison.

2. **Mandatory precedence** — some stages must be preceded by others even when
   the modeller forgot to draw the edge. ``MANDATORY_STAGE_PRECEDENCE`` lists
   these, and :func:`missing_stage_links` reports where they are absent.

Both are advisory by default: :class:`RuleSet` returns findings, and the caller
decides whether to warn or to raise. Real projects legitimately break textbook
sequence (piecemeal handover, phased occupation), so the engine reports rather
than dictates.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ..domain.enums import ConstructionStage

__all__ = [
    "MANDATORY_STAGE_PRECEDENCE",
    "SAME_STAGE_PARALLEL",
    "RuleFinding",
    "RuleSet",
    "Severity",
    "check_edge",
    "missing_stage_links",
]


class Severity(str, Enum):
    """How seriously to treat a rule finding."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass(frozen=True)
class RuleFinding:
    """One rule violation or observation."""

    rule: str
    severity: Severity
    message: str
    predecessor_id: str | None = None
    successor_id: str | None = None
    predecessor_stage: str | None = None
    successor_stage: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "rule": self.rule,
            "severity": self.severity.value,
            "message": self.message,
            "predecessor_id": self.predecessor_id,
            "successor_id": self.successor_id,
            "predecessor_stage": self.predecessor_stage,
            "successor_stage": self.successor_stage,
        }


#: Stages that cannot begin until the listed stages exist in the model.
#: Read as "``key`` requires all of ``value``".
MANDATORY_STAGE_PRECEDENCE: dict[ConstructionStage, frozenset[ConstructionStage]] = {
    ConstructionStage.EXCAVATION: frozenset({ConstructionStage.SITE_PREPARATION}),
    ConstructionStage.FOUNDATIONS: frozenset({ConstructionStage.EXCAVATION}),
    ConstructionStage.DRAINAGE: frozenset({ConstructionStage.EXCAVATION}),
    ConstructionStage.FLOOR_SLAB: frozenset(
        {ConstructionStage.FOUNDATIONS, ConstructionStage.DRAINAGE}
    ),
    ConstructionStage.EXTERNAL_WALLS: frozenset({ConstructionStage.FLOOR_SLAB}),
    ConstructionStage.STRUCTURAL_BEAMS: frozenset({ConstructionStage.EXTERNAL_WALLS}),
    ConstructionStage.UPPER_FLOORS: frozenset({ConstructionStage.EXTERNAL_WALLS}),
    ConstructionStage.INTERNAL_WALLS: frozenset({ConstructionStage.FLOOR_SLAB}),
    ConstructionStage.ROOF_STRUCTURE: frozenset({ConstructionStage.EXTERNAL_WALLS}),
    ConstructionStage.ROOF_COVERING: frozenset({ConstructionStage.ROOF_STRUCTURE}),
    ConstructionStage.WINDOWS: frozenset({ConstructionStage.EXTERNAL_WALLS}),
    ConstructionStage.DOORS: frozenset({ConstructionStage.EXTERNAL_WALLS}),
    ConstructionStage.FIRST_FIX: frozenset(
        {ConstructionStage.INTERNAL_WALLS, ConstructionStage.ROOF_COVERING}
    ),
    ConstructionStage.INSULATION: frozenset({ConstructionStage.FIRST_FIX}),
    ConstructionStage.PLASTERBOARD: frozenset({ConstructionStage.INSULATION}),
    ConstructionStage.SECOND_FIX: frozenset({ConstructionStage.PLASTERBOARD}),
    ConstructionStage.DECORATION: frozenset({ConstructionStage.PLASTERBOARD}),
    ConstructionStage.FLOOR_FINISHES: frozenset({ConstructionStage.DECORATION}),
    ConstructionStage.COMPLETION: frozenset({ConstructionStage.FLOOR_FINISHES}),
}

#: Stage pairs that routinely run concurrently. Used to suppress spurious
#: "out of sequence" warnings when scheduling overlaps them.
SAME_STAGE_PARALLEL: frozenset[frozenset[ConstructionStage]] = frozenset(
    {
        frozenset({ConstructionStage.DRAINAGE, ConstructionStage.FOUNDATIONS}),
        frozenset({ConstructionStage.WINDOWS, ConstructionStage.DOORS}),
        frozenset({ConstructionStage.INTERNAL_WALLS, ConstructionStage.UPPER_FLOORS}),
        # In multi-storey masonry construction these two genuinely interleave:
        # the ground-floor walls carry the first-floor joists, which in turn
        # carry the first-floor walls. Neither strictly precedes the other.
        frozenset({ConstructionStage.EXTERNAL_WALLS, ConstructionStage.UPPER_FLOORS}),
        frozenset({ConstructionStage.EXTERNAL_WALLS, ConstructionStage.STRUCTURAL_BEAMS}),
        frozenset({ConstructionStage.SECOND_FIX, ConstructionStage.DECORATION}),
    }
)


def check_edge(
    predecessor_id: str,
    predecessor_stage: ConstructionStage,
    successor_id: str,
    successor_stage: ConstructionStage,
    *,
    predecessor_level: int | None = None,
    successor_level: int | None = None,
) -> RuleFinding | None:
    """Validate a single dependency edge against the stage ordering.

    Returns ``None`` when the edge is sound, otherwise a finding.

    * A predecessor at a strictly later stage is an ``ERROR`` — physically
      impossible.
    * A predecessor at the same stage is fine (walls supporting walls).
    * **Storey exception.** A building is erected storey by storey, so a stage
      inversion across an increasing level is expected rather than wrong: the
      first-floor external walls genuinely depend on the upper floor structure,
      even though ``EXTERNAL_WALLS`` precedes ``UPPER_FLOORS`` in the canonical
      single-storey sequence. Without this exception every two-storey model
      reports spurious errors.
    """
    if predecessor_id == successor_id:
        return RuleFinding(
            rule="self_dependency",
            severity=Severity.ERROR,
            message="A component cannot depend on itself",
            predecessor_id=predecessor_id,
            successor_id=successor_id,
            predecessor_stage=predecessor_stage.name,
            successor_stage=successor_stage.name,
        )

    if predecessor_stage > successor_stage:
        if (
            predecessor_level is not None
            and successor_level is not None
            and successor_level > predecessor_level
        ):
            return RuleFinding(
                rule="storey_sequence",
                severity=Severity.INFO,
                message=(
                    f"{predecessor_stage.label} precedes {successor_stage.label} across "
                    f"level {predecessor_level} to level {successor_level}; "
                    "expected for storey-by-storey construction"
                ),
                predecessor_id=predecessor_id,
                successor_id=successor_id,
                predecessor_stage=predecessor_stage.name,
                successor_stage=successor_stage.name,
            )
        if frozenset({predecessor_stage, successor_stage}) in SAME_STAGE_PARALLEL:
            return RuleFinding(
                rule="parallel_stage_inversion",
                severity=Severity.INFO,
                message=(
                    f"{predecessor_stage.label} precedes {successor_stage.label}; "
                    "these stages commonly overlap, so this is accepted"
                ),
                predecessor_id=predecessor_id,
                successor_id=successor_id,
                predecessor_stage=predecessor_stage.name,
                successor_stage=successor_stage.name,
            )
        return RuleFinding(
            rule="stage_inversion",
            severity=Severity.ERROR,
            message=(
                f"{predecessor_stage.label} cannot precede {successor_stage.label}: "
                "the predecessor is built later in the canonical sequence"
            ),
            predecessor_id=predecessor_id,
            successor_id=successor_id,
            predecessor_stage=predecessor_stage.name,
            successor_stage=successor_stage.name,
        )
    return None


def missing_stage_links(present: set[ConstructionStage]) -> list[RuleFinding]:
    """Report stages present in the model whose prerequisites are absent.

    This catches the "incomplete construction stages" case from Module 11: a
    model with roof tiles but no roof structure.
    """
    findings: list[RuleFinding] = []
    for stage in sorted(present):
        required = MANDATORY_STAGE_PRECEDENCE.get(stage, frozenset())
        for prerequisite in sorted(required):
            if prerequisite not in present:
                findings.append(
                    RuleFinding(
                        rule="missing_prerequisite_stage",
                        severity=Severity.WARNING,
                        message=(
                            f"{stage.label} is present but its prerequisite "
                            f"{prerequisite.label} has no components"
                        ),
                        successor_stage=stage.name,
                        predecessor_stage=prerequisite.name,
                    )
                )
    return findings


class RuleSet:
    """Configurable bundle of ordering rules.

    Parameters
    ----------
    enforce_stage_order:
        When ``False``, stage inversions are downgraded to warnings. Useful for
        refurbishment models where the textbook sequence does not apply.
    require_prerequisite_stages:
        When ``False``, :meth:`check_model` skips the missing-stage sweep.
    """

    def __init__(
        self,
        *,
        enforce_stage_order: bool = True,
        require_prerequisite_stages: bool = True,
    ) -> None:
        self.enforce_stage_order = enforce_stage_order
        self.require_prerequisite_stages = require_prerequisite_stages

    def check_edge(
        self,
        predecessor_id: str,
        predecessor_stage: ConstructionStage,
        successor_id: str,
        successor_stage: ConstructionStage,
        *,
        predecessor_level: int | None = None,
        successor_level: int | None = None,
    ) -> RuleFinding | None:
        finding = check_edge(
            predecessor_id,
            predecessor_stage,
            successor_id,
            successor_stage,
            predecessor_level=predecessor_level,
            successor_level=successor_level,
        )
        if (
            finding is not None
            and not self.enforce_stage_order
            and finding.rule == "stage_inversion"
        ):
            return RuleFinding(
                rule=finding.rule,
                severity=Severity.WARNING,
                message=finding.message,
                predecessor_id=finding.predecessor_id,
                successor_id=finding.successor_id,
                predecessor_stage=finding.predecessor_stage,
                successor_stage=finding.successor_stage,
            )
        return finding

    def check_model(self, present: set[ConstructionStage]) -> list[RuleFinding]:
        if not self.require_prerequisite_stages:
            return []
        return missing_stage_links(present)

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"RuleSet(enforce_stage_order={self.enforce_stage_order}, "
            f"require_prerequisite_stages={self.require_prerequisite_stages})"
        )
