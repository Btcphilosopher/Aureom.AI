"""Module 2 — Construction Dependency Graph.

The whole building is represented as a directed acyclic graph whose nodes are
components and whose edges are "must be complete before" relationships. Edges
come from two sources:

* **Explicit** — ``component.depends_on``, declared by the modeller or by a
  builder such as :mod:`buildcore.fabrication`.
* **Implicit stage edges** — optionally inferred so that every component in
  stage *N* depends on the whole of the stages it mandatorily requires. This
  gives a usable schedule from a model that only declares stages, without
  forcing the modeller to draw thousands of edges by hand.

Implicit edges are generated at the *stage* level rather than the component
level to avoid the combinatorial blow-up of connecting every wall to every
foundation: a synthetic stage-gate node is inserted per stage, giving
``O(n)`` edges instead of ``O(n²)``.

The graph is a thin, well-tested wrapper around :mod:`networkx`, exposing the
operations the rest of the engine actually needs (topological order, waves,
ancestors, cycle detection, validation) rather than the whole NetworkX API.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import networkx as nx

from ..core.exceptions import CyclicDependencyError, GraphError, MissingDependencyError
from ..core.logging import get_logger
from ..domain.building import Building
from ..domain.components import BuildingComponent
from ..domain.enums import ConstructionStage
from ..domain.registry import ComponentRegistry
from .rules import RuleFinding, RuleSet, Severity

__all__ = ["STAGE_GATE_PREFIX", "ConstructionDependencyGraph"]

_log = get_logger("graph")

#: Node identifiers for synthetic stage gates carry this prefix so they can be
#: filtered out of component-level results.
STAGE_GATE_PREFIX = "__STAGE__"


def stage_gate_id(stage: ConstructionStage) -> str:
    """Identifier of the synthetic gate node for ``stage``."""
    return f"{STAGE_GATE_PREFIX}{stage.name}"


class ConstructionDependencyGraph:
    """Directed dependency graph over a building's components.

    Parameters
    ----------
    registry:
        Source of components. Passing a :class:`Building` is also supported via
        :meth:`from_building`.
    rules:
        Ordering rules used by :meth:`validate`.
    infer_stage_edges:
        When ``True``, insert synthetic stage-gate nodes and wire stage
        prerequisites, so a model with no explicit edges still sequences
        correctly.
    """

    def __init__(
        self,
        registry: ComponentRegistry,
        *,
        rules: RuleSet | None = None,
        infer_stage_edges: bool = True,
    ) -> None:
        self._registry = registry
        self._rules = rules or RuleSet()
        self._infer_stage_edges = infer_stage_edges
        self._graph = nx.DiGraph()
        self._topological_cache: list[str] | None = None
        self.rebuild()

    # -- construction ------------------------------------------------------ #
    @classmethod
    def from_building(cls, building: Building, **kwargs: Any) -> ConstructionDependencyGraph:
        return cls(building.registry, **kwargs)

    def rebuild(self) -> ConstructionDependencyGraph:
        """Rebuild the graph from the current registry contents."""
        graph = nx.DiGraph()
        self._topological_cache = None

        for component in self._registry:
            graph.add_node(
                component.id,
                kind=component.kind.value,
                stage=int(component.stage),
                stage_name=component.stage.name,
                status=component.status.value,
                labour_hours=component.total_labour_hours(),
                level=component.level,
                zone=component.zone,
                is_gate=False,
            )

        # Explicit edges.
        for component in self._registry:
            for dependency in component.depends_on:
                if dependency not in self._registry:
                    raise MissingDependencyError(
                        "Component depends on an unknown predecessor",
                        component_id=component.id,
                        missing=dependency,
                    )
                graph.add_edge(dependency, component.id, kind="explicit")

        if self._infer_stage_edges:
            self._add_stage_gates(graph)

        self._graph = graph
        _log.debug(
            "dependency graph rebuilt",
            extra={"nodes": graph.number_of_nodes(), "edges": graph.number_of_edges()},
        )
        return self

    def _add_stage_gates(self, graph: nx.DiGraph) -> None:
        """Insert one gate node per present stage and wire the stage sequence.

        Design
        ------
        A synthetic gate node per stage keeps the edge count linear: without
        gates, "every wall depends on every foundation" is ``O(n²)`` edges.

        **Explicit edges take precedence over inferred ones.** A component that
        already declares predecessors does not receive a gate-entry edge, and
        one that already has successors does not receive a gate-exit edge. This
        is not merely tidiness — it is what keeps the graph acyclic. Consider a
        two-storey house: level-0 and level-1 external walls share the
        ``EXTERNAL_WALLS`` stage, yet the level-1 walls explicitly depend on the
        upper floor, which is a *later* stage. Attaching every wall to both the
        entry and exit of its own stage would close the loop
        ``wall(L1) → gate(UPPER_FLOORS) → joists → wall(L1)``.

        A final sweep removes any inferred edge that still participates in a
        cycle, so stage inference can never make a valid explicit model
        unschedulable.
        """
        from .rules import MANDATORY_STAGE_PRECEDENCE

        present = self._registry.stages_present()
        if not present:
            return

        for stage in present:
            graph.add_node(
                stage_gate_id(stage),
                kind="stage_gate",
                stage=int(stage),
                stage_name=stage.name,
                status="n/a",
                labour_hours=0.0,
                level=0,
                zone="__system__",
                is_gate=True,
            )

        present_set = set(present)
        ordered = sorted(present)

        # Chain the gates in canonical order, honouring declared prerequisites.
        for index, stage in enumerate(ordered):
            gate = stage_gate_id(stage)
            prerequisites = MANDATORY_STAGE_PRECEDENCE.get(stage, frozenset()) & present_set
            if prerequisites:
                for prerequisite in prerequisites:
                    graph.add_edge(stage_gate_id(prerequisite), gate, kind="stage_prerequisite")
            elif index > 0:
                graph.add_edge(stage_gate_id(ordered[index - 1]), gate, kind="stage_sequence")

        # Attach only those components the modeller left unconstrained.
        explicit_in = {node: graph.in_degree(node) for node in self._registry.ids}
        explicit_out = {node: graph.out_degree(node) for node in self._registry.ids}

        for stage in ordered:
            gate = stage_gate_id(stage)
            successor_gates = [
                stage_gate_id(later)
                for later in ordered
                if later > stage and graph.has_edge(gate, stage_gate_id(later))
            ]
            for component in self._registry.by_stage(stage):
                if explicit_in.get(component.id, 0) == 0:
                    graph.add_edge(gate, component.id, kind="stage_entry")
                if explicit_out.get(component.id, 0) == 0:
                    for successor_gate in successor_gates:
                        graph.add_edge(component.id, successor_gate, kind="stage_exit")

        self._break_inferred_cycles(graph)

    @staticmethod
    def _break_inferred_cycles(graph: nx.DiGraph, max_passes: int = 1000) -> int:
        """Remove inferred edges until the graph is acyclic.

        Only edges the engine inferred are eligible for removal; a cycle made
        entirely of explicit edges is a genuine modelling error and is left in
        place for :meth:`validate` to report.

        Returns the number of edges removed.
        """
        inferred = {"stage_entry", "stage_exit", "stage_sequence", "stage_prerequisite"}
        removed = 0
        for _ in range(max_passes):
            try:
                cycle = nx.find_cycle(graph, orientation="original")
            except nx.NetworkXNoCycle:
                break
            victim = next(
                (
                    (u, v)
                    for u, v, *_ in cycle
                    if graph.edges[u, v].get("kind") in inferred
                ),
                None,
            )
            if victim is None:
                # Cycle is entirely explicit — leave it for validate() to report.
                break
            graph.remove_edge(*victim)
            removed += 1
        if removed:
            _log.warning(
                "removed inferred stage edges to preserve acyclicity",
                extra={"edges_removed": removed},
            )
        return removed

    # -- basic accessors --------------------------------------------------- #
    @property
    def graph(self) -> nx.DiGraph:
        """The underlying NetworkX graph. Treat as read-only."""
        return self._graph

    @property
    def registry(self) -> ComponentRegistry:
        return self._registry

    def __len__(self) -> int:
        return self._graph.number_of_nodes()

    @property
    def node_count(self) -> int:
        return self._graph.number_of_nodes()

    @property
    def edge_count(self) -> int:
        return self._graph.number_of_edges()

    @property
    def component_nodes(self) -> list[str]:
        """Node identifiers excluding synthetic stage gates."""
        return [n for n, data in self._graph.nodes(data=True) if not data.get("is_gate")]

    @staticmethod
    def is_gate(node_id: str) -> bool:
        return node_id.startswith(STAGE_GATE_PREFIX)

    def component(self, node_id: str) -> BuildingComponent:
        return self._registry.get(node_id)

    def __iter__(self) -> Iterator[str]:
        return iter(self._graph.nodes)

    # -- edge manipulation ------------------------------------------------- #
    def add_edge(self, predecessor_id: str, successor_id: str, *, kind: str = "explicit") -> None:
        """Add a dependency edge, rejecting one that would create a cycle."""
        for node_id in (predecessor_id, successor_id):
            if node_id not in self._graph:
                raise MissingDependencyError("Unknown node", node_id=node_id)
        if predecessor_id == successor_id:
            raise GraphError("Self-dependency is not permitted", node_id=predecessor_id)
        if nx.has_path(self._graph, successor_id, predecessor_id):
            raise CyclicDependencyError(
                "Edge would create a cycle",
                cycle=nx.shortest_path(self._graph, successor_id, predecessor_id),
            )
        self._graph.add_edge(predecessor_id, successor_id, kind=kind)
        self._topological_cache = None

    def remove_edge(self, predecessor_id: str, successor_id: str) -> bool:
        if not self._graph.has_edge(predecessor_id, successor_id):
            return False
        self._graph.remove_edge(predecessor_id, successor_id)
        self._topological_cache = None
        return True

    def has_edge(self, predecessor_id: str, successor_id: str) -> bool:
        return self._graph.has_edge(predecessor_id, successor_id)

    # -- traversal --------------------------------------------------------- #
    def predecessors(self, node_id: str, *, include_gates: bool = False) -> list[str]:
        nodes = list(self._graph.predecessors(node_id))
        return nodes if include_gates else [n for n in nodes if not self.is_gate(n)]

    def successors(self, node_id: str, *, include_gates: bool = False) -> list[str]:
        nodes = list(self._graph.successors(node_id))
        return nodes if include_gates else [n for n in nodes if not self.is_gate(n)]

    def ancestors(self, node_id: str, *, include_gates: bool = False) -> set[str]:
        """Every node that must complete before ``node_id`` can start."""
        nodes = nx.ancestors(self._graph, node_id)
        return nodes if include_gates else {n for n in nodes if not self.is_gate(n)}

    def descendants(self, node_id: str, *, include_gates: bool = False) -> set[str]:
        nodes = nx.descendants(self._graph, node_id)
        return nodes if include_gates else {n for n in nodes if not self.is_gate(n)}

    def roots(self) -> list[str]:
        """Component nodes with no component predecessors — valid start points."""
        return [n for n in self.component_nodes if not self.predecessors(n)]

    def leaves(self) -> list[str]:
        return [n for n in self.component_nodes if not self.successors(n)]

    # -- ordering ---------------------------------------------------------- #
    def topological_order(self, *, include_gates: bool = False) -> list[str]:
        """A valid construction order.

        Raises
        ------
        CyclicDependencyError
            If the graph contains a cycle.
        """
        if self._topological_cache is None:
            try:
                self._topological_cache = list(nx.topological_sort(self._graph))
            except nx.NetworkXUnfeasible as exc:
                cycle = self.find_cycle()
                raise CyclicDependencyError(
                    "Dependency graph contains a cycle and cannot be sequenced",
                    cycle=cycle,
                ) from exc
        order = self._topological_cache
        return list(order) if include_gates else [n for n in order if not self.is_gate(n)]

    def waves(self, *, include_gates: bool = False) -> list[list[str]]:
        """Group nodes into sets that can be built concurrently.

        Wave *k* contains every node whose longest path from a root is exactly
        *k*, so all members of a wave are mutually independent.
        """
        try:
            generations = list(nx.topological_generations(self._graph))
        except nx.NetworkXUnfeasible as exc:
            raise CyclicDependencyError(
                "Dependency graph contains a cycle", cycle=self.find_cycle()
            ) from exc
        if include_gates:
            return [sorted(wave) for wave in generations]
        filtered = [sorted(n for n in wave if not self.is_gate(n)) for wave in generations]
        return [wave for wave in filtered if wave]

    def depth(self, node_id: str) -> int:
        """Longest path length from any root to ``node_id``."""
        if node_id not in self._graph:
            raise MissingDependencyError("Unknown node", node_id=node_id)
        longest = 0
        for order_index, wave in enumerate(self.waves(include_gates=True)):
            if node_id in wave:
                longest = order_index
                break
        return longest

    def longest_chain(self, *, weight: str | None = "labour_hours") -> list[str]:
        """The heaviest dependency chain through the graph.

        This is the structural precursor of the critical path: Module 6 refines
        it with durations, crews and calendars.

        ``weight`` names a *node* attribute (labour hours by default); pass
        ``None`` to find the chain with the most links instead. NetworkX's
        ``dag_longest_path`` weights *edges*, so this is computed directly with
        a dynamic program over the topological order — O(V + E).
        """
        if self._graph.number_of_nodes() == 0:
            return []

        order = self.topological_order(include_gates=True)
        best: dict[str, float] = {}
        parent: dict[str, str | None] = {}

        for node in order:
            if weight is None:
                own = 0.0 if self.is_gate(node) else 1.0
            else:
                own = float(self._graph.nodes[node].get(weight, 0.0) or 0.0)
            best_predecessor: str | None = None
            best_score = 0.0
            for predecessor in self._graph.predecessors(node):
                score = best.get(predecessor, 0.0)
                if score > best_score or best_predecessor is None:
                    best_score = score
                    best_predecessor = predecessor
            best[node] = own + (best_score if best_predecessor is not None else 0.0)
            parent[node] = best_predecessor

        if not best:
            return []
        terminal = max(best, key=lambda node: (best[node], node))
        chain: list[str] = []
        cursor: str | None = terminal
        while cursor is not None:
            chain.append(cursor)
            cursor = parent.get(cursor)
        chain.reverse()
        return [n for n in chain if not self.is_gate(n)]

    def chain_weight(self, chain: list[str], weight: str = "labour_hours") -> float:
        """Total of a node attribute along ``chain``."""
        return round(
            sum(float(self._graph.nodes[n].get(weight, 0.0) or 0.0) for n in chain), 3
        )

    # -- integrity --------------------------------------------------------- #
    def has_cycle(self) -> bool:
        return not nx.is_directed_acyclic_graph(self._graph)

    def find_cycle(self) -> list[str]:
        """Return one cycle's node identifiers, or an empty list if acyclic."""
        try:
            edges = nx.find_cycle(self._graph, orientation="original")
        except nx.NetworkXNoCycle:
            return []
        return [edge[0] for edge in edges]

    def isolated_components(self) -> list[str]:
        """Components with no dependency relationships at all.

        With stage inference enabled every component is attached to its gate,
        so an isolated node indicates a component whose stage is not present in
        the model — a genuine modelling fault.
        """
        return [
            node
            for node in self.component_nodes
            if self._graph.in_degree(node) == 0 and self._graph.out_degree(node) == 0
        ]

    def disconnected_subgraphs(self) -> list[set[str]]:
        """Weakly connected components, largest first.

        More than one indicates a building modelled in unconnected fragments.
        """
        groups = [
            {n for n in group if not self.is_gate(n)}
            for group in nx.weakly_connected_components(self._graph)
        ]
        return sorted((g for g in groups if g), key=len, reverse=True)

    def validate(self) -> list[RuleFinding]:
        """Run every ordering rule and return the findings.

        Checks performed:

        * cycles (fatal — reported as a single ``ERROR``)
        * stage inversion on every explicit edge
        * missing prerequisite stages
        * isolated components
        * fragmented models
        """
        findings: list[RuleFinding] = []

        if self.has_cycle():
            cycle = self.find_cycle()
            findings.append(
                RuleFinding(
                    rule="cycle",
                    severity=Severity.ERROR,
                    message=f"Circular dependency: {' -> '.join(cycle[:8])}",
                )
            )
            return findings  # Nothing else is meaningful until the cycle is cut.

        for predecessor, successor, data in self._graph.edges(data=True):
            if data.get("kind") != "explicit":
                continue
            if self.is_gate(predecessor) or self.is_gate(successor):
                continue
            before = self._registry.get(predecessor)
            after = self._registry.get(successor)
            finding = self._rules.check_edge(
                predecessor,
                before.stage,
                successor,
                after.stage,
                predecessor_level=before.level,
                successor_level=after.level,
            )
            if finding is not None:
                findings.append(finding)

        findings.extend(self._rules.check_model(set(self._registry.stages_present())))

        for node in self.isolated_components():
            findings.append(
                RuleFinding(
                    rule="isolated_component",
                    severity=Severity.WARNING,
                    message="Component has no dependency relationships",
                    successor_id=node,
                    successor_stage=self._registry.get(node).stage.name,
                )
            )

        fragments = self.disconnected_subgraphs()
        if len(fragments) > 1:
            findings.append(
                RuleFinding(
                    rule="fragmented_model",
                    severity=Severity.WARNING,
                    message=(
                        f"Model splits into {len(fragments)} disconnected groups "
                        f"(sizes: {[len(f) for f in fragments[:5]]})"
                    ),
                )
            )
        return findings

    def assert_valid(self) -> None:
        """Raise :class:`GraphError` if validation produces any ``ERROR``."""
        errors = [f for f in self.validate() if f.severity is Severity.ERROR]
        if errors:
            raise GraphError(
                "Dependency graph validation failed",
                error_count=len(errors),
                first=errors[0].message,
            )

    # -- scheduling support ------------------------------------------------ #
    def _satisfied_nodes(self) -> dict[str, bool]:
        """Map every node to whether its whole upstream is complete.

        A stage gate is satisfied when all of *its* predecessors are; a
        component is satisfied when its predecessors are satisfied *and* it is
        itself complete. Computing this as a single DP over the topological
        order is O(V + E), versus O(V·(V+E)) for per-node ancestor queries —
        which matters because the sequencing engine calls it on every tick.
        """
        satisfied: dict[str, bool] = {}
        for node in self.topological_order(include_gates=True):
            upstream_ok = all(
                satisfied.get(p, False) for p in self._graph.predecessors(node)
            )
            if self.is_gate(node):
                satisfied[node] = upstream_ok
            else:
                satisfied[node] = upstream_ok and self._registry.get(node).is_complete
        return satisfied

    def ready_components(self) -> list[str]:
        """Components that can start now: upstream complete, self not started.

        This is the frontier that the sequencing engine (Module 3) consumes on
        each simulation tick. Stage gates are honoured, so a second-fix item
        with no explicitly declared predecessors is still correctly held back
        until the stages it depends on have finished.
        """
        satisfied = self._satisfied_nodes()
        ready: list[str] = []
        for node in self.component_nodes:
            component = self._registry.get(node)
            if component.is_complete or component.status.is_physically_present:
                continue
            if all(satisfied.get(p, False) for p in self._graph.predecessors(node)):
                ready.append(node)
        return sorted(ready, key=lambda n: (int(self._registry.get(n).stage), n))

    def blocking_components(self, node_id: str) -> list[str]:
        """Incomplete components preventing ``node_id`` from starting.

        Resolves through stage gates, so the answer is always a list of real
        components a site manager can act on rather than synthetic nodes.
        """
        blocking: set[str] = set()
        for predecessor in self._graph.predecessors(node_id):
            if self.is_gate(predecessor):
                for ancestor in nx.ancestors(self._graph, predecessor):
                    if self.is_gate(ancestor):
                        continue
                    if not self._registry.get(ancestor).is_complete:
                        blocking.add(ancestor)
            elif not self._registry.get(predecessor).is_complete:
                blocking.add(predecessor)
        return sorted(blocking)

    def critical_nodes(self, top_n: int = 10) -> list[tuple[str, float]]:
        """Components ranked by how many others depend on them.

        Uses descendant count rather than betweenness because it directly
        answers the site manager's question: what unblocks the most work?
        """
        scores = [
            (node, float(len(self.descendants(node)))) for node in self.component_nodes
        ]
        scores.sort(key=lambda item: (-item[1], item[0]))
        return scores[:top_n]

    # -- reporting --------------------------------------------------------- #
    def statistics(self) -> dict[str, Any]:
        component_nodes = self.component_nodes
        acyclic = not self.has_cycle()
        return {
            "nodes": self._graph.number_of_nodes(),
            "component_nodes": len(component_nodes),
            "stage_gates": self._graph.number_of_nodes() - len(component_nodes),
            "edges": self._graph.number_of_edges(),
            "is_acyclic": acyclic,
            "roots": len(self.roots()),
            "leaves": len(self.leaves()),
            "waves": len(self.waves()) if acyclic else 0,
            "longest_chain": len(self.longest_chain()) if acyclic else 0,
            "isolated": len(self.isolated_components()),
            "fragments": len(self.disconnected_subgraphs()),
            "density": round(nx.density(self._graph), 6),
        }

    def to_dict(self) -> dict[str, Any]:
        """Node-link JSON, suitable for the Kotlin UI to render."""
        return {
            "nodes": [
                {"id": node, **data}
                for node, data in self._graph.nodes(data=True)
            ],
            "edges": [
                {"from": u, "to": v, "kind": data.get("kind", "explicit")}
                for u, v, data in self._graph.edges(data=True)
            ],
        }

    def subgraph_for_stage(self, stage: ConstructionStage) -> nx.DiGraph:
        """Induced subgraph containing only the components of one stage."""
        nodes = [c.id for c in self._registry.by_stage(stage)]
        return self._graph.subgraph(nodes).copy()

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"ConstructionDependencyGraph(nodes={self._graph.number_of_nodes()}, "
            f"edges={self._graph.number_of_edges()})"
        )
