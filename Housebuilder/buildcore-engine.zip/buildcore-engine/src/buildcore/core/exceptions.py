"""Exception hierarchy for the BuildCore Engine.

Every exception raised deliberately by the engine derives from
:class:`BuildCoreError`, so that host applications (the Rust API layer, the
FastAPI service, or a test harness) can trap engine faults with a single
``except`` clause while still being able to discriminate on subtype.

The hierarchy is intentionally shallow and grouped by bounded context:

.. code-block:: text

    BuildCoreError
    ├── ConfigurationError
    ├── DomainError
    │   ├── GeometryError
    │   ├── MaterialError
    │   ├── ComponentError
    │   │   ├── ComponentNotFoundError
    │   │   └── DuplicateComponentError
    │   └── SiteError
    ├── GraphError
    │   ├── CyclicDependencyError
    │   ├── MissingDependencyError
    │   └── DependencyViolationError
    ├── ValidationError
    ├── ContainerError
    │   └── DependencyResolutionError
    └── EventBusError
"""

from __future__ import annotations

from typing import Any


class BuildCoreError(Exception):
    """Root of the BuildCore exception tree.

    Carries an optional ``context`` mapping so that structured logging can
    emit machine-readable diagnostics alongside the human-readable message.
    """

    def __init__(self, message: str, **context: Any) -> None:
        super().__init__(message)
        self.message = message
        self.context: dict[str, Any] = dict(context)

    def __str__(self) -> str:  # pragma: no cover - trivial formatting
        if not self.context:
            return self.message
        rendered = ", ".join(f"{k}={v!r}" for k, v in sorted(self.context.items()))
        return f"{self.message} ({rendered})"

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable representation of the failure."""
        return {
            "error": type(self).__name__,
            "message": self.message,
            "context": self.context,
        }


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
class ConfigurationError(BuildCoreError):
    """Engine settings are missing, malformed or mutually inconsistent."""


# --------------------------------------------------------------------------- #
# Domain
# --------------------------------------------------------------------------- #
class DomainError(BuildCoreError):
    """Base class for violations of domain invariants."""


class GeometryError(DomainError):
    """Invalid geometry: negative extents, degenerate polygons, bad rotations."""


class MaterialError(DomainError):
    """Unknown material reference, or a material used outside its valid range."""


class ComponentError(DomainError):
    """Base class for faults relating to a single building component."""


class ComponentNotFoundError(ComponentError):
    """A component was referenced by identifier but is not in the registry."""


class DuplicateComponentError(ComponentError):
    """A component identifier was registered twice."""


class SiteError(DomainError):
    """Plot/site level invariant violation (e.g. building outside its plot)."""


# --------------------------------------------------------------------------- #
# Dependency graph
# --------------------------------------------------------------------------- #
class GraphError(BuildCoreError):
    """Base class for construction dependency graph faults."""


class CyclicDependencyError(GraphError):
    """The dependency graph contains a cycle and cannot be sequenced.

    ``cycle`` holds the offending node identifiers in traversal order.
    """

    def __init__(self, message: str, cycle: list[str] | None = None, **context: Any) -> None:
        super().__init__(message, cycle=cycle or [], **context)
        self.cycle: list[str] = list(cycle or [])


class MissingDependencyError(GraphError):
    """A component declares a predecessor that does not exist in the model."""


class DependencyViolationError(GraphError):
    """An edge contradicts the canonical construction stage ordering.

    For example, a wall declared as a predecessor of its own foundation.
    """


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
class ValidationError(BuildCoreError):
    """Raised when a validation run is escalated from *report* to *raise*."""

    def __init__(self, message: str, issues: list[Any] | None = None, **context: Any) -> None:
        super().__init__(message, issue_count=len(issues or []), **context)
        self.issues: list[Any] = list(issues or [])


# --------------------------------------------------------------------------- #
# Infrastructure
# --------------------------------------------------------------------------- #
class ContainerError(BuildCoreError):
    """Dependency injection container misuse."""


class DependencyResolutionError(ContainerError):
    """A requested service could not be constructed."""


class EventBusError(BuildCoreError):
    """Event publication or subscription failure."""


__all__ = [
    "BuildCoreError",
    "ComponentError",
    "ComponentNotFoundError",
    "ConfigurationError",
    "ContainerError",
    "CyclicDependencyError",
    "DependencyResolutionError",
    "DependencyViolationError",
    "DomainError",
    "DuplicateComponentError",
    "EventBusError",
    "GeometryError",
    "GraphError",
    "MaterialError",
    "MissingDependencyError",
    "SiteError",
    "ValidationError",
]
