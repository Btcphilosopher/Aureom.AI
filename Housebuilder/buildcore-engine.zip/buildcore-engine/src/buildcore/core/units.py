"""Units of measure and dimension-checked quantity arithmetic.

Construction estimating mixes counts, lengths, areas, volumes and masses in the
same bill. Silent unit errors are the classic source of six-figure estimating
mistakes, so quantities carry their unit and refuse to be added across
incompatible dimensions.

All internal storage is SI (metre, square metre, cubic metre, kilogram); the
unit attached to a :class:`Quantity` is a *presentation* unit and conversion is
exact via the factor table below.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = ["Dimension", "Quantity", "Unit", "convert"]


class Dimension(str, Enum):
    """Physical dimension of a measurement."""

    COUNT = "count"
    LENGTH = "length"
    AREA = "area"
    VOLUME = "volume"
    MASS = "mass"
    TIME = "time"
    CURRENCY = "currency"


class Unit(str, Enum):
    """Supported units of measure."""

    # count
    EACH = "nr"
    # length
    MILLIMETRE = "mm"
    METRE = "m"
    KILOMETRE = "km"
    # area
    SQUARE_METRE = "m2"
    # volume
    CUBIC_METRE = "m3"
    LITRE = "l"
    # mass
    KILOGRAM = "kg"
    TONNE = "t"
    # time
    HOUR = "hr"
    DAY = "day"
    # money
    CURRENCY = "cur"

    @property
    def dimension(self) -> Dimension:
        return _DIMENSION_OF[self]

    @property
    def si_factor(self) -> float:
        """Multiplier converting one of this unit into the SI base unit."""
        return _SI_FACTOR[self]


_DIMENSION_OF: dict[Unit, Dimension] = {
    Unit.EACH: Dimension.COUNT,
    Unit.MILLIMETRE: Dimension.LENGTH,
    Unit.METRE: Dimension.LENGTH,
    Unit.KILOMETRE: Dimension.LENGTH,
    Unit.SQUARE_METRE: Dimension.AREA,
    Unit.CUBIC_METRE: Dimension.VOLUME,
    Unit.LITRE: Dimension.VOLUME,
    Unit.KILOGRAM: Dimension.MASS,
    Unit.TONNE: Dimension.MASS,
    Unit.HOUR: Dimension.TIME,
    Unit.DAY: Dimension.TIME,
    Unit.CURRENCY: Dimension.CURRENCY,
}

_SI_FACTOR: dict[Unit, float] = {
    Unit.EACH: 1.0,
    Unit.MILLIMETRE: 0.001,
    Unit.METRE: 1.0,
    Unit.KILOMETRE: 1000.0,
    Unit.SQUARE_METRE: 1.0,
    Unit.CUBIC_METRE: 1.0,
    Unit.LITRE: 0.001,
    Unit.KILOGRAM: 1.0,
    Unit.TONNE: 1000.0,
    Unit.HOUR: 1.0,
    Unit.DAY: 24.0,
    Unit.CURRENCY: 1.0,
}


def convert(value: float, source: Unit, target: Unit) -> float:
    """Convert ``value`` from ``source`` to ``target``.

    Raises
    ------
    ValueError
        If the units have different dimensions.
    """
    if source.dimension is not target.dimension:
        raise ValueError(
            f"Cannot convert {source.value} ({source.dimension.value}) to "
            f"{target.value} ({target.dimension.value})"
        )
    return value * source.si_factor / target.si_factor


class Quantity(BaseModel):
    """An immutable measured amount with a unit.

    Supports ``+``, ``-`` (same dimension only, result in the left unit) and
    scalar ``*`` / ``/``. Comparison operators normalise to SI first.

    >>> Quantity(value=2.0, unit=Unit.METRE) + Quantity(value=500.0, unit=Unit.MILLIMETRE)
    Quantity(2.5 m)
    """

    model_config = ConfigDict(frozen=True)

    value: float = Field(description="Magnitude in the attached unit.")
    unit: Unit = Field(default=Unit.EACH)

    @field_validator("value")
    @classmethod
    def _finite(cls, v: float) -> float:
        if v != v or v in (float("inf"), float("-inf")):
            raise ValueError("Quantity value must be finite")
        return float(v)

    # -- conversion -------------------------------------------------------- #
    @property
    def dimension(self) -> Dimension:
        return self.unit.dimension

    @property
    def si_value(self) -> float:
        return self.value * self.unit.si_factor

    def to(self, unit: Unit) -> Quantity:
        return Quantity(value=convert(self.value, self.unit, unit), unit=unit)

    # -- arithmetic -------------------------------------------------------- #
    def _require_same_dimension(self, other: Quantity) -> None:
        if self.dimension is not other.dimension:
            raise ValueError(
                f"Dimension mismatch: {self.dimension.value} vs {other.dimension.value}"
            )

    def __add__(self, other: Quantity) -> Quantity:
        self._require_same_dimension(other)
        return Quantity(value=self.value + other.to(self.unit).value, unit=self.unit)

    def __sub__(self, other: Quantity) -> Quantity:
        self._require_same_dimension(other)
        return Quantity(value=self.value - other.to(self.unit).value, unit=self.unit)

    def __mul__(self, factor: float) -> Quantity:
        return Quantity(value=self.value * float(factor), unit=self.unit)

    __rmul__ = __mul__

    def __truediv__(self, divisor: float) -> Quantity:
        if divisor == 0:
            raise ZeroDivisionError("Cannot divide a Quantity by zero")
        return Quantity(value=self.value / float(divisor), unit=self.unit)

    def __neg__(self) -> Quantity:
        return Quantity(value=-self.value, unit=self.unit)

    # -- comparison -------------------------------------------------------- #
    def __lt__(self, other: Quantity) -> bool:
        self._require_same_dimension(other)
        return self.si_value < other.si_value

    def __le__(self, other: Quantity) -> bool:
        self._require_same_dimension(other)
        return self.si_value <= other.si_value

    def __gt__(self, other: Quantity) -> bool:
        self._require_same_dimension(other)
        return self.si_value > other.si_value

    def __ge__(self, other: Quantity) -> bool:
        self._require_same_dimension(other)
        return self.si_value >= other.si_value

    # -- presentation ------------------------------------------------------ #
    def rounded(self, places: int = 3) -> Quantity:
        return Quantity(value=round(self.value, places), unit=self.unit)

    def ceil_to_whole(self) -> Quantity:
        """Round up to a whole number — used for orderable countable items."""
        import math

        return Quantity(value=float(math.ceil(self.value - 1e-9)), unit=self.unit)

    def __repr__(self) -> str:
        return f"Quantity({self.value:g} {self.unit.value})"

    def __str__(self) -> str:
        return f"{self.value:,.3f} {self.unit.value}".replace(".000 ", " ")

    @classmethod
    def zero(cls, unit: Unit = Unit.EACH) -> Quantity:
        return cls(value=0.0, unit=unit)

    @classmethod
    def sum(cls, quantities: Any, unit: Unit | None = None) -> Quantity:
        """Sum an iterable of quantities, returning zero for an empty input."""
        items = list(quantities)
        if not items:
            return cls.zero(unit or Unit.EACH)
        target = unit or items[0].unit
        total = cls.zero(target)
        for item in items:
            total = total + item
        return total
