"""Event-driven backbone.

The engine is event driven: mutating the domain model emits :class:`DomainEvent`
instances, and cross-cutting concerns (progress tracking, validation caches,
audit logging, telemetry) subscribe rather than being called explicitly. This
keeps the domain layer free of references to the services that observe it.

Design notes
------------
* Events are immutable frozen Pydantic models — safe to fan out to many handlers.
* The bus supports **both** synchronous and coroutine handlers. ``publish`` runs
  only the synchronous handlers; ``publish_async`` runs both, awaiting the
  coroutines concurrently via :func:`asyncio.gather`.
* Handler failures are isolated. One misbehaving subscriber must not abort a
  simulation, so exceptions are captured into an :class:`EventDispatchReport`.
  Set ``strict=True`` on the bus to re-raise instead.
* Subscription is by event *class*, and is inheritance-aware: subscribing to
  :class:`DomainEvent` receives everything.
"""

from __future__ import annotations

import asyncio
import inspect
from collections import defaultdict
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any, TypeVar

from pydantic import BaseModel, ConfigDict, Field

from .identifiers import correlation_id

__all__ = [
    "BuildingCreated",
    "ComponentAdded",
    "ComponentRemoved",
    "ComponentStatusChanged",
    "DependencyAdded",
    "DependencyRemoved",
    "DomainEvent",
    "EventBus",
    "EventDispatchReport",
    "EventHandlerFailure",
    "GraphInvalidated",
]

EventT = TypeVar("EventT", bound="DomainEvent")
Handler = Callable[[Any], None] | Callable[[Any], Awaitable[None]]


def _utcnow() -> datetime:
    return datetime.now(UTC)


# --------------------------------------------------------------------------- #
# Event types
# --------------------------------------------------------------------------- #
class DomainEvent(BaseModel):
    """Immutable record of something that happened in the domain model."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_id: str = Field(default_factory=correlation_id)
    occurred_at: datetime = Field(default_factory=_utcnow)
    source: str = Field(default="buildcore", description="Emitting subsystem.")

    @property
    def name(self) -> str:
        """Event type name, used as the logging discriminator."""
        return type(self).__name__


class BuildingCreated(DomainEvent):
    building_id: str
    building_name: str


class ComponentAdded(DomainEvent):
    building_id: str
    component_id: str
    kind: str
    stage: str


class ComponentRemoved(DomainEvent):
    building_id: str
    component_id: str


class ComponentStatusChanged(DomainEvent):
    component_id: str
    previous: str
    current: str


class DependencyAdded(DomainEvent):
    predecessor_id: str
    successor_id: str


class DependencyRemoved(DomainEvent):
    predecessor_id: str
    successor_id: str


class GraphInvalidated(DomainEvent):
    """Emitted when cached graph analyses (topological order, CPM) go stale."""

    reason: str


# --------------------------------------------------------------------------- #
# Dispatch reporting
# --------------------------------------------------------------------------- #
class EventHandlerFailure(BaseModel):
    """A single subscriber that raised while handling an event."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    event_name: str
    handler: str
    error: str
    error_type: str


class EventDispatchReport(BaseModel):
    """Outcome of publishing one event."""

    model_config = ConfigDict(frozen=True)

    event_name: str
    handlers_invoked: int = 0
    failures: tuple[EventHandlerFailure, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.failures


# --------------------------------------------------------------------------- #
# The bus
# --------------------------------------------------------------------------- #
class EventBus:
    """In-process publish/subscribe bus with inheritance-aware routing.

    Parameters
    ----------
    strict:
        When ``True``, a handler exception propagates to the publisher instead
        of being collected into the dispatch report.
    record_history:
        When ``True``, retains every published event in :attr:`history`. Useful
        for tests and for replaying a simulation run; disable for long runs.
    """

    def __init__(self, *, strict: bool = False, record_history: bool = False) -> None:
        self._subscribers: dict[type[DomainEvent], list[Handler]] = defaultdict(list)
        self._strict = strict
        self._record_history = record_history
        self._history: list[DomainEvent] = []

    # -- subscription ------------------------------------------------------ #
    def subscribe(self, event_type: type[EventT], handler: Handler) -> Callable[[], None]:
        """Register ``handler`` for ``event_type`` and subclasses.

        Returns an *unsubscribe* callable, which makes scoped subscriptions in
        context managers and tests straightforward.
        """
        if not (isinstance(event_type, type) and issubclass(event_type, DomainEvent)):
            raise TypeError("event_type must be a DomainEvent subclass")
        if not callable(handler):
            raise TypeError("handler must be callable")
        self._subscribers[event_type].append(handler)

        def _unsubscribe() -> None:
            self.unsubscribe(event_type, handler)

        return _unsubscribe

    def unsubscribe(self, event_type: type[EventT], handler: Handler) -> bool:
        """Remove a subscription. Returns ``True`` if one was removed."""
        handlers = self._subscribers.get(event_type)
        if not handlers or handler not in handlers:
            return False
        handlers.remove(handler)
        if not handlers:
            del self._subscribers[event_type]
        return True

    def clear(self) -> None:
        """Drop all subscriptions and history."""
        self._subscribers.clear()
        self._history.clear()

    def subscriber_count(self, event_type: type[EventT] | None = None) -> int:
        if event_type is None:
            return sum(len(v) for v in self._subscribers.values())
        return len(self._subscribers.get(event_type, ()))

    # -- routing ----------------------------------------------------------- #
    def _matching_handlers(self, event: DomainEvent) -> list[Handler]:
        matches: list[Handler] = []
        for registered_type, handlers in self._subscribers.items():
            if isinstance(event, registered_type):
                matches.extend(handlers)
        return matches

    @staticmethod
    def _handler_name(handler: Handler) -> str:
        return getattr(handler, "__qualname__", None) or repr(handler)

    # -- publication ------------------------------------------------------- #
    def publish(self, event: DomainEvent) -> EventDispatchReport:
        """Dispatch ``event`` to all synchronous subscribers.

        Coroutine handlers are skipped — use :meth:`publish_async` for those.
        This keeps the domain model callable from ordinary synchronous code
        (which the simulation inner loop relies on for speed).
        """
        if self._record_history:
            self._history.append(event)

        invoked = 0
        failures: list[EventHandlerFailure] = []
        for handler in self._matching_handlers(event):
            if inspect.iscoroutinefunction(handler):
                continue
            try:
                handler(event)
                invoked += 1
            except Exception as exc:
                if self._strict:
                    raise
                failures.append(
                    EventHandlerFailure(
                        event_name=event.name,
                        handler=self._handler_name(handler),
                        error=str(exc),
                        error_type=type(exc).__name__,
                    )
                )
        return EventDispatchReport(
            event_name=event.name,
            handlers_invoked=invoked,
            failures=tuple(failures),
        )

    async def publish_async(self, event: DomainEvent) -> EventDispatchReport:
        """Dispatch ``event`` to synchronous *and* coroutine subscribers."""
        if self._record_history:
            self._history.append(event)

        invoked = 0
        failures: list[EventHandlerFailure] = []
        pending: list[tuple[Handler, Awaitable[None]]] = []

        for handler in self._matching_handlers(event):
            if inspect.iscoroutinefunction(handler):
                pending.append((handler, handler(event)))
                continue
            try:
                handler(event)
                invoked += 1
            except Exception as exc:
                if self._strict:
                    raise
                failures.append(
                    EventHandlerFailure(
                        event_name=event.name,
                        handler=self._handler_name(handler),
                        error=str(exc),
                        error_type=type(exc).__name__,
                    )
                )

        if pending:
            results = await asyncio.gather(
                *(awaitable for _, awaitable in pending), return_exceptions=True
            )
            for (handler, _), result in zip(pending, results, strict=True):
                if isinstance(result, Exception):
                    if self._strict:
                        raise result
                    failures.append(
                        EventHandlerFailure(
                            event_name=event.name,
                            handler=self._handler_name(handler),
                            error=str(result),
                            error_type=type(result).__name__,
                        )
                    )
                else:
                    invoked += 1

        return EventDispatchReport(
            event_name=event.name,
            handlers_invoked=invoked,
            failures=tuple(failures),
        )

    # -- history ----------------------------------------------------------- #
    @property
    def history(self) -> tuple[DomainEvent, ...]:
        return tuple(self._history)

    def history_of(self, event_type: type[EventT]) -> tuple[EventT, ...]:
        return tuple(e for e in self._history if isinstance(e, event_type))  # type: ignore[misc]

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"EventBus(subscriptions={self.subscriber_count()}, "
            f"strict={self._strict}, history={len(self._history)})"
        )


class NullEventBus(EventBus):
    """A bus that accepts publications and does nothing.

    Used as the default collaborator so that domain objects never need a
    ``if bus is not None`` guard, per the Null Object pattern.
    """

    def publish(self, event: DomainEvent) -> EventDispatchReport:
        return EventDispatchReport(event_name=event.name)

    async def publish_async(self, event: DomainEvent) -> EventDispatchReport:
        return EventDispatchReport(event_name=event.name)
