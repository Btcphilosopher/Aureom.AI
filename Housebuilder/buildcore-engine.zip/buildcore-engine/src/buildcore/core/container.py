"""A small, explicit dependency injection container.

Rationale
---------
The engine has a dozen collaborating services (quantification, scheduling,
procurement, logistics, optimisation...). Wiring them by hand at every call
site produces brittle code; pulling in a heavyweight DI framework produces
opaque code. This container sits in between: ~200 lines, no magic beyond
constructor type-hint inspection, and it fails loudly.

Supported registrations
-----------------------
``register_instance``
    Bind an already-constructed object.
``register_singleton``
    Bind a factory or class; constructed once, then memoised.
``register_factory``
    Bind a factory or class; constructed on every resolve (transient).

Autowiring
----------
When a class is registered without an explicit factory, the container inspects
``__init__`` type hints and resolves each annotated parameter recursively.
Parameters with defaults that cannot be resolved fall back to their default
rather than raising, which keeps optional collaborators optional.
"""

from __future__ import annotations

import inspect
import threading
from collections.abc import Callable
from enum import Enum
from typing import Any, TypeVar, get_type_hints

from .exceptions import ContainerError, DependencyResolutionError

__all__ = ["Container", "Lifetime", "Registration"]

T = TypeVar("T")


class Lifetime(str, Enum):
    """How long a resolved instance lives."""

    SINGLETON = "singleton"
    TRANSIENT = "transient"
    INSTANCE = "instance"


class Registration:
    """Internal record describing how to build one service."""

    __slots__ = ("factory", "instance", "key", "lifetime")

    def __init__(
        self,
        key: type,
        factory: Callable[..., Any] | None,
        lifetime: Lifetime,
        instance: Any = None,
    ) -> None:
        self.key = key
        self.factory = factory
        self.lifetime = lifetime
        self.instance = instance

    def __repr__(self) -> str:  # pragma: no cover
        return f"Registration({self.key.__name__}, {self.lifetime.value})"


class Container:
    """Thread-safe service container.

    Example
    -------
    >>> from buildcore.core.events import EventBus
    >>> c = Container()
    >>> _ = c.register_singleton(EventBus)
    >>> c.resolve(EventBus) is c.resolve(EventBus)
    True
    """

    def __init__(self, *, parent: Container | None = None) -> None:
        self._registrations: dict[type, Registration] = {}
        self._lock = threading.RLock()
        self._resolving: set[type] = set()
        self._parent = parent

    # -- registration ------------------------------------------------------ #
    def register_instance(self, key: type[T], instance: T) -> Container:
        """Bind ``key`` to an existing object."""
        if not isinstance(key, type):
            raise ContainerError("Registration key must be a type", key=repr(key))
        with self._lock:
            self._registrations[key] = Registration(key, None, Lifetime.INSTANCE, instance)
        return self

    def register_singleton(
        self, key: type[T], factory: Callable[..., T] | None = None
    ) -> Container:
        """Bind ``key`` to a lazily constructed, memoised instance."""
        return self._register(key, factory, Lifetime.SINGLETON)

    def register_factory(
        self, key: type[T], factory: Callable[..., T] | None = None
    ) -> Container:
        """Bind ``key`` to a factory invoked on every resolution."""
        return self._register(key, factory, Lifetime.TRANSIENT)

    def _register(
        self, key: type[T], factory: Callable[..., T] | None, lifetime: Lifetime
    ) -> Container:
        if not isinstance(key, type):
            raise ContainerError("Registration key must be a type", key=repr(key))
        resolved_factory = factory if factory is not None else key
        if not callable(resolved_factory):
            raise ContainerError(
                "Factory must be callable", key=key.__name__, factory=repr(factory)
            )
        with self._lock:
            self._registrations[key] = Registration(key, resolved_factory, lifetime)
        return self

    # -- introspection ----------------------------------------------------- #
    def is_registered(self, key: type) -> bool:
        if key in self._registrations:
            return True
        return self._parent.is_registered(key) if self._parent else False

    @property
    def registrations(self) -> dict[type, Registration]:
        return dict(self._registrations)

    def create_scope(self) -> Container:
        """Return a child container that inherits, but cannot mutate, this one."""
        return Container(parent=self)

    # -- resolution -------------------------------------------------------- #
    def resolve(self, key: type[T]) -> T:
        """Construct (or fetch) an instance of ``key``.

        Raises
        ------
        DependencyResolutionError
            If ``key`` is unregistered and cannot be autowired, or if a
            circular dependency is detected.
        """
        with self._lock:
            registration = self._registrations.get(key)
            if registration is None:
                if self._parent is not None and self._parent.is_registered(key):
                    return self._parent.resolve(key)
                # Implicit autowiring for concrete, unregistered classes.
                if inspect.isclass(key):
                    return self._construct(key)
                raise DependencyResolutionError(
                    "No registration and not autowirable", service=repr(key)
                )

            if registration.lifetime is Lifetime.INSTANCE:
                return registration.instance

            if registration.lifetime is Lifetime.SINGLETON and registration.instance is not None:
                return registration.instance

            assert registration.factory is not None
            instance = self._invoke(registration.factory, key)

            if registration.lifetime is Lifetime.SINGLETON:
                registration.instance = instance
            return instance

    def _construct(self, cls: type[T]) -> T:
        return self._invoke(cls, cls)

    def _invoke(self, factory: Callable[..., Any], key: type) -> Any:
        """Call ``factory``, resolving its annotated parameters recursively."""
        if key in self._resolving:
            chain = " -> ".join(sorted(t.__name__ for t in self._resolving))
            raise DependencyResolutionError(
                "Circular dependency detected", service=key.__name__, chain=chain
            )

        self._resolving.add(key)
        try:
            kwargs = self._build_kwargs(factory)
            return factory(**kwargs)
        except DependencyResolutionError:
            raise
        except Exception as exc:
            raise DependencyResolutionError(
                f"Failed to construct service: {exc}",
                service=key.__name__,
                error_type=type(exc).__name__,
            ) from exc
        finally:
            self._resolving.discard(key)

    def _build_kwargs(self, factory: Callable[..., Any]) -> dict[str, Any]:
        target = factory.__init__ if inspect.isclass(factory) else factory  # type: ignore[misc]
        try:
            signature = inspect.signature(target)
        except (TypeError, ValueError):  # pragma: no cover - builtins
            return {}

        try:
            hints = get_type_hints(target)
        except Exception:
            hints = {}

        kwargs: dict[str, Any] = {}
        for name, parameter in signature.parameters.items():
            if name in {"self", "cls"}:
                continue
            if parameter.kind in {
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            }:
                continue

            annotation = hints.get(name, parameter.annotation)
            has_default = parameter.default is not inspect.Parameter.empty

            # ``inspect.Parameter.empty`` is itself a class, so a bare
            # ``isinstance(annotation, type)`` check would treat an *unannotated*
            # parameter as resolvable and silently inject a junk sentinel
            # instance. Normalise the sentinel to "no annotation" first.
            if annotation is inspect.Parameter.empty:
                annotation = None

            if not isinstance(annotation, type):
                if has_default:
                    continue
                raise DependencyResolutionError(
                    "Unannotated required parameter cannot be autowired",
                    parameter=name,
                    factory=getattr(factory, "__name__", repr(factory)),
                )

            if not self.is_registered(annotation) and has_default:
                continue

            try:
                kwargs[name] = self.resolve(annotation)
            except DependencyResolutionError:
                if has_default:
                    continue
                raise
        return kwargs

    def __repr__(self) -> str:  # pragma: no cover
        return f"Container(registrations={len(self._registrations)})"
