"""Identifier generation.

Simulation work must be **reproducible**: running the same scenario twice has
to produce byte-identical project data so that scenario comparison (Module 10)
measures the effect of the changed variable rather than the effect of random
identifiers. We therefore avoid bare :func:`uuid.uuid4` in domain code and use
a seedable generator instead.

Two strategies are provided:

``IdGenerator``
    Monotonic, seeded, human-legible: ``WALL-0007``. Deterministic across runs.

``uuid_id``
    Random UUID4 hex, for cases where global uniqueness across processes
    matters more than reproducibility (e.g. API request correlation IDs).
"""

from __future__ import annotations

import itertools
import threading
import uuid
from collections.abc import Iterator

__all__ = ["IdGenerator", "correlation_id", "slugify", "uuid_id"]


def uuid_id(prefix: str = "") -> str:
    """Return a globally unique identifier, optionally prefixed."""
    token = uuid.uuid4().hex[:12].upper()
    return f"{prefix}-{token}" if prefix else token


def correlation_id() -> str:
    """Return a request/run correlation identifier for structured logging."""
    return uuid.uuid4().hex


def slugify(text: str) -> str:
    """Normalise free text into an uppercase, hyphen-free identifier fragment."""
    cleaned = [c if c.isalnum() else "_" for c in text.strip().upper()]
    slug = "".join(cleaned)
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_") or "ITEM"


class IdGenerator:
    """Thread-safe, deterministic, per-prefix sequential identifier source.

    Example
    -------
    >>> gen = IdGenerator(width=4)
    >>> gen.next("WALL")
    'WALL-0001'
    >>> gen.next("WALL")
    'WALL-0002'
    >>> gen.next("ROOF")
    'ROOF-0001'

    The generator is deliberately *not* global. Each :class:`~buildcore.domain.building.Building`
    owns one, which keeps identifiers stable and scoped to a single project.
    """

    __slots__ = ("_counters", "_lock", "_namespace", "_width")

    def __init__(self, width: int = 4, namespace: str = "") -> None:
        if width < 1:
            raise ValueError("width must be >= 1")
        self._width = width
        self._namespace = slugify(namespace) if namespace else ""
        self._counters: dict[str, Iterator[int]] = {}
        self._lock = threading.Lock()

    @property
    def namespace(self) -> str:
        return self._namespace

    def next(self, prefix: str) -> str:
        """Return the next identifier for ``prefix``."""
        key = slugify(prefix)
        with self._lock:
            counter = self._counters.get(key)
            if counter is None:
                counter = itertools.count(1)
                self._counters[key] = counter
            index = next(counter)
        body = f"{key}-{index:0{self._width}d}"
        return f"{self._namespace}-{body}" if self._namespace else body

    def issued(self, prefix: str) -> int:
        """Return how many identifiers have been issued for ``prefix``."""
        key = slugify(prefix)
        with self._lock:
            counter = self._counters.get(key)
            if counter is None:
                return 0
            # itertools.count has no introspection; peek and rewind via a probe.
            current = next(counter)
            self._counters[key] = itertools.count(current)
            return current - 1

    def reset(self) -> None:
        """Clear all counters. Primarily a test affordance."""
        with self._lock:
            self._counters.clear()

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"IdGenerator(width={self._width}, namespace={self._namespace!r})"
