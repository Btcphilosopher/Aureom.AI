"""Engine configuration.

All tunable assumptions live here rather than being scattered as literals
through the domain code. This matters for a construction engine because the
"constants" — waste allowances, working hours, weather factors, VAT — are
commercial assumptions that estimators need to override per project.

Settings are layered:

1. Field defaults (sensible UK housebuilding assumptions).
2. Environment variables prefixed ``BUILDCORE_`` (e.g. ``BUILDCORE_LOG_LEVEL``).
3. Explicit keyword overrides at construction time.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .exceptions import ConfigurationError

__all__ = [
    "EngineSettings",
    "PerformanceSettings",
    "UnitSystem",
    "WasteAllowances",
    "WorkingCalendar",
    "default_settings",
]


class UnitSystem(str, Enum):
    METRIC = "metric"
    IMPERIAL = "imperial"


class WasteAllowances(BaseSettings):
    """Proportional over-order allowances applied during quantification.

    Values are fractions, not percentages: ``0.05`` means order 105% of the
    net measured quantity. Defaults follow typical UK NHBC/BCIS practice.
    """

    model_config = SettingsConfigDict(env_prefix="BUILDCORE_WASTE_", extra="forbid")

    masonry: float = Field(default=0.05, ge=0.0, le=0.5)
    mortar: float = Field(default=0.10, ge=0.0, le=0.5)
    concrete: float = Field(default=0.05, ge=0.0, le=0.5)
    timber: float = Field(default=0.10, ge=0.0, le=0.5)
    steel: float = Field(default=0.03, ge=0.0, le=0.5)
    insulation: float = Field(default=0.08, ge=0.0, le=0.5)
    plasterboard: float = Field(default=0.12, ge=0.0, le=0.5)
    roof_covering: float = Field(default=0.07, ge=0.0, le=0.5)
    paint: float = Field(default=0.05, ge=0.0, le=0.5)
    default: float = Field(default=0.05, ge=0.0, le=0.5)

    def for_class(self, material_class: str) -> float:
        """Look up the allowance for a :class:`MaterialClass` value."""
        return float(getattr(self, material_class.lower(), self.default))


class WorkingCalendar(BaseSettings):
    """Site working pattern used to convert man-hours into elapsed dates."""

    model_config = SettingsConfigDict(env_prefix="BUILDCORE_CALENDAR_", extra="forbid")

    hours_per_day: float = Field(default=8.0, gt=0.0, le=24.0)
    days_per_week: int = Field(default=5, ge=1, le=7)
    #: Fraction of nominal hours actually productive (breaks, setup, snagging).
    productivity_factor: float = Field(default=0.85, gt=0.0, le=1.0)
    #: Probability that a given winter working day is lost to weather.
    weather_loss_factor: float = Field(default=0.08, ge=0.0, le=0.9)
    public_holidays_per_year: int = Field(default=8, ge=0, le=40)

    @property
    def effective_hours_per_day(self) -> float:
        return self.hours_per_day * self.productivity_factor

    @property
    def hours_per_week(self) -> float:
        return self.effective_hours_per_day * self.days_per_week


class PerformanceSettings(BaseSettings):
    """Knobs governing parallelism and caching."""

    model_config = SettingsConfigDict(env_prefix="BUILDCORE_PERF_", extra="forbid")

    max_workers: int = Field(default=4, ge=1, le=256)
    enable_graph_cache: bool = True
    enable_quantity_cache: bool = True
    #: Above this component count, analyses switch to array-based fast paths.
    large_model_threshold: int = Field(default=5_000, ge=100)
    solver_time_limit_seconds: float = Field(default=30.0, gt=0.0, le=3600.0)


class EngineSettings(BaseSettings):
    """Root configuration object for a BuildCore Engine instance."""

    model_config = SettingsConfigDict(
        env_prefix="BUILDCORE_",
        env_nested_delimiter="__",
        extra="forbid",
    )

    environment: str = Field(default="development")
    log_level: str = Field(default="INFO")
    log_json: bool = Field(default=True)
    unit_system: UnitSystem = Field(default=UnitSystem.METRIC)
    currency: str = Field(default="GBP", min_length=3, max_length=3)
    #: Overhead and profit applied on top of measured cost.
    overhead_and_profit: float = Field(default=0.18, ge=0.0, le=1.0)
    preliminaries: float = Field(default=0.12, ge=0.0, le=1.0)
    contingency: float = Field(default=0.05, ge=0.0, le=1.0)
    vat_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    strict_events: bool = Field(default=False)
    record_event_history: bool = Field(default=False)

    waste: WasteAllowances = Field(default_factory=WasteAllowances)
    calendar: WorkingCalendar = Field(default_factory=WorkingCalendar)
    performance: PerformanceSettings = Field(default_factory=PerformanceSettings)

    @field_validator("log_level")
    @classmethod
    def _validate_level(cls, value: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = value.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {sorted(allowed)}")
        return upper

    @field_validator("currency")
    @classmethod
    def _validate_currency(cls, value: str) -> str:
        if not value.isalpha():
            raise ValueError("currency must be a 3-letter ISO 4217 code")
        return value.upper()

    @model_validator(mode="after")
    def _check_markups(self) -> EngineSettings:
        total = self.overhead_and_profit + self.preliminaries + self.contingency
        if total >= 1.0:
            raise ValueError(
                "combined overhead_and_profit + preliminaries + contingency must be < 100%"
            )
        return self

    @property
    def markup_multiplier(self) -> float:
        """Multiplier converting net measured cost into tendered cost."""
        return 1.0 + self.overhead_and_profit + self.preliminaries + self.contingency

    def with_overrides(self, **overrides: Any) -> EngineSettings:
        """Return a copy with ``overrides`` applied and re-validated."""
        try:
            return EngineSettings(**{**self.model_dump(), **overrides})
        except Exception as exc:
            raise ConfigurationError(f"Invalid settings override: {exc}") from exc


def default_settings() -> EngineSettings:
    """Return settings built from defaults plus environment variables."""
    try:
        return EngineSettings()
    except Exception as exc:
        raise ConfigurationError(f"Could not load engine settings: {exc}") from exc
