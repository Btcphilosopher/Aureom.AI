"""Structured logging and performance instrumentation.

Log records are emitted as single-line JSON so that they can be shipped
straight into Loki/Elastic/CloudWatch without a regex parsing stage. Every
record carries the engine version, the logger name, and any bound context.

Two instruments are provided for the *performance metrics* and *simulation
timings* requirements:

``timed``
    A context manager / decorator that logs wall-clock duration.
``MetricsCollector``
    An in-memory aggregate (count / total / min / max / mean / p95) suitable
    for exposure via the ``/health`` and ``/metrics`` API endpoints.
"""

from __future__ import annotations

import json
import logging
import math
import sys
import threading
import time
from collections.abc import Callable, Iterator, MutableMapping
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from functools import wraps
from typing import Any, TypeVar

__all__ = [
    "BoundLogger",
    "JsonFormatter",
    "MetricSummary",
    "MetricsCollector",
    "configure_logging",
    "get_logger",
    "metrics",
    "timed",
]

F = TypeVar("F", bound=Callable[..., Any])

_RESERVED = {
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "taskName", "message", "asctime",
}


class JsonFormatter(logging.Formatter):
    """Render :class:`logging.LogRecord` as a single JSON object."""

    def __init__(self, *, engine_version: str = "0.0.0", service: str = "buildcore") -> None:
        super().__init__()
        self.engine_version = engine_version
        self.service = service

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "service": self.service,
            "version": self.engine_version,
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        for key, value in record.__dict__.items():
            if key in _RESERVED or key.startswith("_"):
                continue
            payload[key] = _jsonable(value)

        return json.dumps(payload, default=str, separators=(",", ":"))


def _jsonable(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)


def configure_logging(
    level: int | str = logging.INFO,
    *,
    json_format: bool = True,
    stream: Any = None,
    engine_version: str = "0.0.0",
) -> logging.Logger:
    """Install the BuildCore root handler and return the root engine logger.

    Idempotent: repeated calls replace the handler rather than stacking them,
    which matters because tests and the FastAPI startup hook may both call it.
    """
    root = logging.getLogger("buildcore")
    for handler in list(root.handlers):
        root.removeHandler(handler)

    handler = logging.StreamHandler(stream or sys.stderr)
    if json_format:
        handler.setFormatter(JsonFormatter(engine_version=engine_version))
    else:
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)-8s %(name)s :: %(message)s")
        )
    root.addHandler(handler)
    root.setLevel(level)
    root.propagate = False
    return root


class BoundLogger(logging.LoggerAdapter):
    """A logger carrying persistent structured context.

    >>> log = get_logger("scheduler").bind(project_id="P-001")
    >>> log.info("schedule generated", extra={"tasks": 412})
    """

    def process(self, msg: Any, kwargs: MutableMapping[str, Any]) -> tuple[Any, MutableMapping[str, Any]]:
        extra = dict(self.extra or {})
        extra.update(kwargs.get("extra") or {})
        kwargs["extra"] = extra
        return msg, kwargs

    def bind(self, **context: Any) -> BoundLogger:
        merged = dict(self.extra or {})
        merged.update(context)
        return BoundLogger(self.logger, merged)


def get_logger(name: str = "") -> BoundLogger:
    """Return a bound logger under the ``buildcore`` namespace."""
    full = f"buildcore.{name}" if name else "buildcore"
    return BoundLogger(logging.getLogger(full), {})


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class MetricSummary:
    """Aggregated statistics for one named metric."""

    name: str
    count: int
    total: float
    minimum: float
    maximum: float
    mean: float
    p95: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "count": self.count,
            "total_ms": round(self.total * 1000, 3),
            "min_ms": round(self.minimum * 1000, 3),
            "max_ms": round(self.maximum * 1000, 3),
            "mean_ms": round(self.mean * 1000, 3),
            "p95_ms": round(self.p95 * 1000, 3),
        }


@dataclass
class MetricsCollector:
    """Thread-safe in-memory metric accumulator."""

    _samples: dict[str, list[float]] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def record(self, name: str, value: float) -> None:
        with self._lock:
            self._samples.setdefault(name, []).append(float(value))

    def increment(self, name: str, amount: float = 1.0) -> None:
        self.record(name, amount)

    def summary(self, name: str) -> MetricSummary | None:
        with self._lock:
            values = list(self._samples.get(name, ()))
        if not values:
            return None
        ordered = sorted(values)
        index = min(len(ordered) - 1, max(0, math.ceil(0.95 * len(ordered)) - 1))
        return MetricSummary(
            name=name,
            count=len(ordered),
            total=sum(ordered),
            minimum=ordered[0],
            maximum=ordered[-1],
            mean=sum(ordered) / len(ordered),
            p95=ordered[index],
        )

    def all_summaries(self) -> list[MetricSummary]:
        with self._lock:
            names = list(self._samples)
        return [s for s in (self.summary(n) for n in sorted(names)) if s is not None]

    def snapshot(self) -> dict[str, Any]:
        return {s.name: s.to_dict() for s in self.all_summaries()}

    def reset(self) -> None:
        with self._lock:
            self._samples.clear()


#: Process-wide default collector. Services may inject their own instead.
metrics = MetricsCollector()


@contextmanager
def timed(
    name: str,
    *,
    logger: BoundLogger | None = None,
    collector: MetricsCollector | None = None,
    **context: Any,
) -> Iterator[dict[str, Any]]:
    """Time a block, log the duration, and record it as a metric.

    Yields a mutable dict; anything placed into it is merged into the log
    record, which lets the caller annotate the timing with result sizes.

    >>> with timed("quantification", components=1200) as span:
    ...     span["line_items"] = 87
    """
    log = logger or get_logger("metrics")
    sink = collector if collector is not None else metrics
    span: dict[str, Any] = {}
    started = time.perf_counter()
    try:
        yield span
    finally:
        elapsed = time.perf_counter() - started
        sink.record(name, elapsed)
        log.info(
            "operation completed",
            extra={
                "operation": name,
                "duration_ms": round(elapsed * 1000, 3),
                **context,
                **span,
            },
        )


def timeit(name: str | None = None) -> Callable[[F], F]:
    """Decorator form of :func:`timed`."""

    def decorator(func: F) -> F:
        metric_name = name or f"{func.__module__}.{func.__qualname__}"

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with timed(metric_name):
                return func(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
