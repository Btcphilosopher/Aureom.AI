"""Shared fixtures for the BuildCore test suite."""

from __future__ import annotations

import pytest

from buildcore.core.config import EngineSettings
from buildcore.core.events import EventBus
from buildcore.domain.building import Building
from buildcore.domain.components import (
    Excavation,
    FloorSlab,
    Foundation,
    Wall,
    WallType,
)
from buildcore.domain.enums import ComponentKind, ConstructionStage, Orientation
from buildcore.domain.geometry import Dimensions, Footprint, Placement, Vec3
from buildcore.domain.materials import standard_catalogue
from buildcore.domain.registry import ComponentRegistry
from buildcore.domain.site import Plot, Site
from buildcore.fabrication.house_builder import HouseSpecification, StandardHouseBuilder
from buildcore.graph.dependency_graph import ConstructionDependencyGraph


@pytest.fixture
def catalogue():
    return standard_catalogue()


@pytest.fixture
def settings():
    return EngineSettings()


@pytest.fixture
def bus():
    return EventBus(record_history=True)


@pytest.fixture
def dims():
    return Dimensions(length=4.0, width=0.3, height=2.5)


@pytest.fixture
def wall(dims):
    return Wall(
        id="WALL-0001",
        name="Test cavity wall",
        dimensions=dims,
        wall_type=WallType.CAVITY_EXTERNAL,
        orientation=Orientation.SOUTH,
    )


@pytest.fixture
def plot():
    return Plot(
        id="PLOT-001",
        name="Plot 1",
        boundary=Footprint.rectangle(20.0, 30.0, origin=(0.0, 0.0)),
        setback=1.0,
    )


@pytest.fixture
def site(plot):
    site = Site(id="SITE-001", name="Test site", boundary=Footprint.rectangle(60.0, 60.0))
    site.add_plot(plot)
    return site


@pytest.fixture
def empty_building(plot, bus):
    return Building(id="BLD-TEST", name="Test building", plot=plot, event_bus=bus)


@pytest.fixture
def tiny_building(bus):
    """A four-component model exercising the canonical early stages."""
    building = Building(id="BLD-TINY", name="Tiny building", event_bus=bus)

    excavation = Excavation(
        id="EXC-1",
        name="Dig",
        stage=ConstructionStage.SITE_PREPARATION,
        dimensions=Dimensions(length=10.0, width=8.0, height=0.3),
    )
    trench = Excavation(
        id="EXC-2",
        name="Trench",
        dimensions=Dimensions(length=10.0, width=0.6, height=1.0),
    )
    foundation = Foundation(
        id="FDN-1",
        name="Trench fill",
        dimensions=Dimensions(length=10.0, width=0.6, height=1.0),
    )
    slab = FloorSlab(
        id="SLB-1",
        name="Ground slab",
        dimensions=Dimensions(length=10.0, width=8.0, height=0.15),
    )
    building.add_all([excavation, trench, foundation, slab])
    building.link("EXC-1", "EXC-2")
    building.link("EXC-2", "FDN-1")
    building.link("FDN-1", "SLB-1")
    return building


@pytest.fixture
def house():
    """A full generated house — the workhorse fixture for integration tests."""
    return StandardHouseBuilder(HouseSpecification()).build("BLD-001", "Reference house")


@pytest.fixture
def house_graph(house):
    return ConstructionDependencyGraph.from_building(house)


@pytest.fixture
def registry():
    return ComponentRegistry()


@pytest.fixture
def placement():
    return Placement(origin=Vec3(x=1.0, y=2.0, z=0.0), rotation_z=0.0)


@pytest.fixture
def component_kinds():
    return list(ComponentKind)
