"""Edge-case tests targeting defensive paths that normal models never reach."""

from __future__ import annotations

import asyncio
import io
import json
import logging

import pytest

from buildcore.core.container import Container
from buildcore.core.events import DomainEvent, EventBus
from buildcore.core.exceptions import DependencyResolutionError
from buildcore.core.identifiers import IdGenerator
from buildcore.core.logging import JsonFormatter, configure_logging, get_logger, timeit
from buildcore.domain.building import Building
from buildcore.domain.components import FloorSlab, Foundation, Wall
from buildcore.domain.enums import ConstructionStage
from buildcore.domain.geometry import Dimensions
from buildcore.graph.dependency_graph import ConstructionDependencyGraph
from buildcore.graph.rules import Severity


class TestInferredCycleBreaking:
    """The stage-gate inference must never render a model unschedulable."""

    @staticmethod
    def _inverted_model() -> Building:
        """A model whose explicit edge runs backwards through the stages.

        ``slab -> foundation`` is a stage inversion. Because the foundation now
        has an explicit predecessor it loses its gate-entry edge but keeps its
        gate-exit edge, and the slab keeps its gate-entry edge. That closes the
        loop ``foundation -> gate(FLOOR_SLAB) -> slab -> foundation``, which is
        exactly the situation the safety net exists for.
        """
        building = Building(id="B", name="Inverted")
        building.add(
            Foundation(
                id="FDN", name="Foundation", dimensions=Dimensions(length=8, width=0.6, height=1)
            )
        )
        building.add(
            FloorSlab(
                id="SLB", name="Slab", dimensions=Dimensions(length=8, width=6, height=0.15)
            )
        )
        building.link("SLB", "FDN")  # deliberately backwards
        return building

    def test_graph_remains_acyclic(self):
        graph = ConstructionDependencyGraph.from_building(self._inverted_model())
        assert not graph.has_cycle()

    def test_still_produces_a_topological_order(self):
        graph = ConstructionDependencyGraph.from_building(self._inverted_model())
        order = graph.topological_order()
        assert set(order) == {"FDN", "SLB"}
        assert order.index("SLB") < order.index("FDN")

    def test_explicit_edge_survives_the_repair(self):
        graph = ConstructionDependencyGraph.from_building(self._inverted_model())
        assert graph.has_edge("SLB", "FDN")

    def test_underlying_fault_is_still_reported(self):
        graph = ConstructionDependencyGraph.from_building(self._inverted_model())
        findings = graph.validate()
        assert any(
            f.rule == "stage_inversion" and f.severity is Severity.ERROR for f in findings
        )

    def test_repair_removes_only_inferred_edges(self):
        graph = ConstructionDependencyGraph.from_building(self._inverted_model())
        kinds = {data.get("kind") for _, _, data in graph.graph.edges(data=True)}
        assert "explicit" in kinds

    def test_break_cycles_reports_zero_on_clean_graph(self, house_graph):
        removed = ConstructionDependencyGraph._break_inferred_cycles(house_graph.graph)
        assert removed == 0

    def test_break_cycles_gives_up_on_purely_explicit_cycles(self):
        building = Building(id="B", name="B")
        for index in range(2):
            building.add(
                Wall(
                    id=f"W-{index}",
                    name=f"W{index}",
                    dimensions=Dimensions(length=2, width=0.3, height=2.4),
                )
            )
        building.get("W-0").add_dependency("W-1")
        building.get("W-1").add_dependency("W-0")
        graph = ConstructionDependencyGraph(building.registry)
        # The safety net must not loop forever, and must leave the fault visible.
        assert graph.has_cycle()
        assert graph.validate()[0].rule == "cycle"


class TestContainerEdgeCases:
    def test_unannotated_required_parameter_is_rejected(self):
        class Bad:
            def __init__(self, thing):  # no annotation
                self.thing = thing

        with pytest.raises(DependencyResolutionError, match="Unannotated"):
            Container().resolve(Bad)

    def test_varargs_are_ignored(self):
        class Varargs:
            def __init__(self, *args, **kwargs):
                self.ok = True

        assert Container().resolve(Varargs).ok

    def test_non_type_resolution_key_rejected(self):
        with pytest.raises(DependencyResolutionError):
            Container().resolve(42)  # type: ignore[arg-type]

    def test_scope_does_not_leak_upward(self):
        class Leaf:
            pass

        parent = Container()
        child = parent.create_scope()
        child.register_singleton(Leaf)
        assert child.is_registered(Leaf)
        assert not parent.is_registered(Leaf)

    def test_unresolvable_annotation_with_default_is_skipped(self):
        class Weird:
            def __init__(self, value: DoesNotExist = None):  # noqa: F821
                self.value = value

        assert Container().resolve(Weird).value is None


class _Ping(DomainEvent):
    pass


class TestEventEdgeCases:
    def test_strict_mode_propagates_async_failure(self):
        bus = EventBus(strict=True)

        async def broken(event):
            raise ValueError("async boom")

        bus.subscribe(_Ping, broken)
        with pytest.raises(ValueError, match="async boom"):
            asyncio.run(bus.publish_async(_Ping()))

    def test_strict_mode_propagates_sync_failure_during_async_publish(self):
        bus = EventBus(strict=True)

        def broken(event):
            raise ValueError("sync boom")

        bus.subscribe(_Ping, broken)
        with pytest.raises(ValueError, match="sync boom"):
            asyncio.run(bus.publish_async(_Ping()))

    def test_async_publish_records_history(self):
        bus = EventBus(record_history=True)
        asyncio.run(bus.publish_async(_Ping()))
        assert len(bus.history) == 1

    def test_repr_is_informative(self):
        bus = EventBus()
        bus.subscribe(_Ping, lambda e: None)
        assert "subscriptions=1" in repr(bus)


class TestLoggingEdgeCases:
    def test_formatter_renders_nested_structures(self):
        record = logging.LogRecord("buildcore.t", logging.INFO, __file__, 1, "m", None, None)
        record.nested = {"a": [1, 2, {"b": Dimensions(length=1, width=1, height=1)}]}
        payload = json.loads(JsonFormatter().format(record))
        assert isinstance(payload["nested"]["a"], list)

    def test_formatter_includes_exception_text(self):
        try:
            raise RuntimeError("kaboom")
        except RuntimeError:
            import sys

            record = logging.LogRecord(
                "buildcore.t", logging.ERROR, __file__, 1, "m", None, sys.exc_info()
            )
        payload = json.loads(JsonFormatter().format(record))
        assert "kaboom" in payload["exception"]

    def test_timeit_decorator_logs_duration(self):
        stream = io.StringIO()
        configure_logging(stream=stream)

        @timeit("decorated_op")
        def work(x: int) -> int:
            return x * 2

        assert work(3) == 6
        payload = json.loads(stream.getvalue().strip().splitlines()[-1])
        assert payload["operation"] == "decorated_op"

    def test_get_logger_without_name(self):
        assert get_logger().logger.name == "buildcore"


class TestIdentifierEdgeCases:
    def test_thread_safety_under_contention(self):
        import threading

        generator = IdGenerator()
        results: list[str] = []
        lock = threading.Lock()

        def worker() -> None:
            local = [generator.next("W") for _ in range(50)]
            with lock:
                results.extend(local)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        assert len(results) == 400
        assert len(set(results)) == 400, "identifier collision under concurrency"


class TestGeometryEdgeCases:
    def test_dimensions_reject_non_finite(self):
        with pytest.raises(Exception):
            Dimensions(length=float("nan"), width=1, height=1)

    def test_placement_rejects_non_finite_rotation(self):
        from buildcore.domain.geometry import Placement

        with pytest.raises(Exception):
            Placement(rotation_z=float("inf"))

    def test_stage_gate_prefix_is_not_a_valid_component_id(self, house_graph):
        assert all(
            not component_id.startswith("__STAGE__")
            for component_id in house_graph.registry.ids
        )


class TestStageCoverage:
    def test_every_stage_has_a_label(self):
        for stage in ConstructionStage:
            assert stage.label
            assert stage.label != stage.name

    def test_stage_values_are_uniquely_ordered(self):
        values = [int(s) for s in ConstructionStage]
        assert values == sorted(values)
        assert len(values) == len(set(values))
