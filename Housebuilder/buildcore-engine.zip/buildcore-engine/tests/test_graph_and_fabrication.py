"""Tests for Module 2 (dependency graph), the fabrication layer, and end-to-end flows."""

from __future__ import annotations

import pytest

from buildcore.core.exceptions import CyclicDependencyError, GraphError, MissingDependencyError
from buildcore.domain.building import Building
from buildcore.domain.components import Foundation, WallType
from buildcore.domain.enums import ComponentKind, ConstructionStage, InstallationStatus, Trade
from buildcore.domain.geometry import Dimensions
from buildcore.fabrication.house_builder import (
    HouseSpecification,
    StandardHouseBuilder,
    build_estate,
)
from buildcore.graph.dependency_graph import (
    STAGE_GATE_PREFIX,
    ConstructionDependencyGraph,
    stage_gate_id,
)
from buildcore.graph.rules import (
    MANDATORY_STAGE_PRECEDENCE,
    RuleSet,
    Severity,
    check_edge,
    missing_stage_links,
)


# --------------------------------------------------------------------------- #
# Ordering rules
# --------------------------------------------------------------------------- #
class TestRules:
    def test_forward_edge_is_sound(self):
        assert (
            check_edge("a", ConstructionStage.FOUNDATIONS, "b", ConstructionStage.FLOOR_SLAB)
            is None
        )

    def test_same_stage_is_sound(self):
        assert (
            check_edge("a", ConstructionStage.EXTERNAL_WALLS, "b", ConstructionStage.EXTERNAL_WALLS)
            is None
        )

    def test_inversion_is_an_error(self):
        finding = check_edge(
            "roof", ConstructionStage.ROOF_COVERING, "fdn", ConstructionStage.FOUNDATIONS
        )
        assert finding is not None
        assert finding.rule == "stage_inversion"
        assert finding.severity is Severity.ERROR

    def test_self_dependency(self):
        finding = check_edge(
            "a", ConstructionStage.FOUNDATIONS, "a", ConstructionStage.FOUNDATIONS
        )
        assert finding.rule == "self_dependency"

    def test_storey_exception_downgrades_inversion(self):
        finding = check_edge(
            "joist",
            ConstructionStage.UPPER_FLOORS,
            "wall",
            ConstructionStage.EXTERNAL_WALLS,
            predecessor_level=0,
            successor_level=1,
        )
        assert finding.rule == "storey_sequence"
        assert finding.severity is Severity.INFO

    def test_parallel_stage_pair_downgraded(self):
        finding = check_edge(
            "joist", ConstructionStage.UPPER_FLOORS, "wall", ConstructionStage.EXTERNAL_WALLS
        )
        assert finding.rule == "parallel_stage_inversion"
        assert finding.severity is Severity.INFO

    def test_finding_to_dict(self):
        finding = check_edge(
            "roof", ConstructionStage.ROOF_COVERING, "fdn", ConstructionStage.FOUNDATIONS
        )
        payload = finding.to_dict()
        assert payload["severity"] == "error"
        assert payload["predecessor_stage"] == "ROOF_COVERING"

    def test_missing_prerequisite_stage(self):
        findings = missing_stage_links({ConstructionStage.ROOF_COVERING})
        rules = {f.rule for f in findings}
        assert "missing_prerequisite_stage" in rules

    def test_complete_stage_set_has_no_findings(self):
        assert missing_stage_links(set(ConstructionStage.ordered())) == []

    def test_ruleset_can_relax_ordering(self):
        relaxed = RuleSet(enforce_stage_order=False)
        finding = relaxed.check_edge(
            "roof", ConstructionStage.ROOF_COVERING, "fdn", ConstructionStage.FOUNDATIONS
        )
        assert finding.severity is Severity.WARNING

    def test_ruleset_can_skip_prerequisites(self):
        relaxed = RuleSet(require_prerequisite_stages=False)
        assert relaxed.check_model({ConstructionStage.ROOF_COVERING}) == []

    def test_precedence_table_is_ordered(self):
        for stage, prerequisites in MANDATORY_STAGE_PRECEDENCE.items():
            for prerequisite in prerequisites:
                assert prerequisite < stage, f"{prerequisite} must precede {stage}"


# --------------------------------------------------------------------------- #
# Dependency graph
# --------------------------------------------------------------------------- #
class TestDependencyGraph:
    def test_builds_from_building(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert len(graph.component_nodes) == 4
        assert graph.edge_count > 0

    def test_gate_nodes_are_flagged(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        gates = [n for n in graph if graph.is_gate(n)]
        assert gates
        assert all(n.startswith(STAGE_GATE_PREFIX) for n in gates)

    def test_stage_inference_can_be_disabled(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(
            tiny_building, infer_stage_edges=False
        )
        assert graph.node_count == len(graph.component_nodes) == 4

    def test_topological_order_respects_dependencies(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        order = graph.topological_order()
        assert order.index("EXC-1") < order.index("FDN-1") < order.index("SLB-1")

    def test_topological_order_is_cached(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.topological_order() == graph.topological_order()

    def test_waves_are_independent_sets(self, house_graph):
        waves = house_graph.waves()
        assert len(waves) > 3
        seen: set[str] = set()
        for wave in waves:
            for node in wave:
                assert not (house_graph.ancestors(node) & set(wave))
                seen.add(node)
        assert seen == set(house_graph.component_nodes)

    def test_predecessors_and_successors(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.predecessors("FDN-1") == ["EXC-2"]
        assert graph.successors("FDN-1") == ["SLB-1"]

    def test_gates_included_on_request(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        with_gates = graph.predecessors("EXC-1", include_gates=True)
        assert any(graph.is_gate(n) for n in with_gates)

    def test_ancestors_and_descendants(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.ancestors("SLB-1") == {"EXC-1", "EXC-2", "FDN-1"}
        assert graph.descendants("EXC-1") == {"EXC-2", "FDN-1", "SLB-1"}

    def test_roots_and_leaves(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.roots() == ["EXC-1"]
        assert graph.leaves() == ["SLB-1"]

    def test_add_edge(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        graph.add_edge("EXC-1", "SLB-1")
        assert graph.has_edge("EXC-1", "SLB-1")

    def test_add_edge_rejects_cycle(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        with pytest.raises(CyclicDependencyError):
            graph.add_edge("SLB-1", "EXC-1")

    def test_add_edge_rejects_self_loop(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        with pytest.raises(GraphError):
            graph.add_edge("EXC-1", "EXC-1")

    def test_add_edge_rejects_unknown_node(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        with pytest.raises(MissingDependencyError):
            graph.add_edge("GHOST", "SLB-1")

    def test_remove_edge(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.remove_edge("FDN-1", "SLB-1")
        assert not graph.remove_edge("FDN-1", "SLB-1")

    def test_missing_dependency_raises_on_build(self, tiny_building):
        tiny_building.get("SLB-1").add_dependency("GHOST")
        with pytest.raises(MissingDependencyError):
            ConstructionDependencyGraph.from_building(tiny_building)

    def test_explicit_cycle_is_detected(self):
        building = Building(id="B", name="B")
        for index in range(3):
            building.add(
                Foundation(
                    id=f"F-{index}",
                    name=f"F{index}",
                    dimensions=Dimensions(length=1, width=1, height=1),
                )
            )
        building.get("F-1").add_dependency("F-0")
        building.get("F-2").add_dependency("F-1")
        building.get("F-0").add_dependency("F-2")

        graph = ConstructionDependencyGraph(building.registry)
        assert graph.has_cycle()
        assert len(graph.find_cycle()) == 3
        with pytest.raises(CyclicDependencyError):
            graph.topological_order()
        findings = graph.validate()
        assert findings[0].rule == "cycle"
        with pytest.raises(GraphError):
            graph.assert_valid()

    def test_find_cycle_empty_when_acyclic(self, house_graph):
        assert house_graph.find_cycle() == []

    def test_waves_raise_on_cycle(self):
        building = Building(id="B", name="B")
        for index in range(2):
            building.add(
                Foundation(
                    id=f"F-{index}",
                    name=f"F{index}",
                    dimensions=Dimensions(length=1, width=1, height=1),
                )
            )
        building.get("F-0").add_dependency("F-1")
        building.get("F-1").add_dependency("F-0")
        graph = ConstructionDependencyGraph(building.registry)
        with pytest.raises(CyclicDependencyError):
            graph.waves()

    def test_stage_inference_never_creates_a_cycle(self, house_graph):
        assert not house_graph.has_cycle()

    def test_two_storey_model_validates_cleanly(self, house_graph):
        errors = [f for f in house_graph.validate() if f.severity is Severity.ERROR]
        assert errors == []
        house_graph.assert_valid()

    def test_isolated_component_reported(self):
        building = Building(id="B", name="B")
        building.add(
            Foundation(id="F", name="F", dimensions=Dimensions(length=1, width=1, height=1))
        )
        graph = ConstructionDependencyGraph(building.registry, infer_stage_edges=False)
        assert graph.isolated_components() == ["F"]
        assert any(f.rule == "isolated_component" for f in graph.validate())

    def test_fragmented_model_reported(self):
        building = Building(id="B", name="B")
        for index in range(4):
            building.add(
                Foundation(
                    id=f"F-{index}",
                    name=f"F{index}",
                    dimensions=Dimensions(length=1, width=1, height=1),
                )
            )
        building.link("F-0", "F-1")
        building.link("F-2", "F-3")
        graph = ConstructionDependencyGraph(building.registry, infer_stage_edges=False)
        assert len(graph.disconnected_subgraphs()) == 2
        assert any(f.rule == "fragmented_model" for f in graph.validate())

    def test_longest_chain_by_labour(self, house_graph):
        chain = house_graph.longest_chain()
        assert len(chain) > 3
        assert house_graph.chain_weight(chain) > 0

    def test_longest_chain_by_links(self, house_graph):
        by_links = house_graph.longest_chain(weight=None)
        assert len(by_links) > 3

    def test_longest_chain_of_empty_graph(self):
        graph = ConstructionDependencyGraph(Building(id="B", name="B").registry)
        assert graph.longest_chain() == []

    def test_depth_increases_downstream(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.depth("SLB-1") > graph.depth("EXC-1")

    def test_depth_unknown_node(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        with pytest.raises(MissingDependencyError):
            graph.depth("GHOST")

    def test_ready_components_start_at_the_root(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.ready_components() == ["EXC-1"]

    def test_ready_frontier_advances(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        tiny_building.set_status("EXC-1", InstallationStatus.COMPLETE, force=True)
        graph.rebuild()
        assert graph.ready_components() == ["EXC-2"]

    def test_ready_respects_stage_gates(self, house, house_graph):
        """Second-fix items with no explicit predecessors must not be buildable."""
        ready = house_graph.ready_components()
        assert len(ready) == 1
        assert house.get(ready[0]).stage is ConstructionStage.SITE_PREPARATION

    def test_completed_components_leave_the_frontier(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        tiny_building.complete_all()
        graph.rebuild()
        assert graph.ready_components() == []

    def test_blocking_components_resolve_through_gates(self, house, house_graph):
        target = next(
            c.id for c in house.registry.by_stage(ConstructionStage.SECOND_FIX)
        )
        blockers = house_graph.blocking_components(target)
        assert blockers
        assert all(not house_graph.is_gate(b) for b in blockers)

    def test_blocking_empty_when_predecessors_done(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        tiny_building.set_status("EXC-1", InstallationStatus.COMPLETE, force=True)
        graph.rebuild()
        assert graph.blocking_components("EXC-2") == []

    def test_critical_nodes_rank_by_downstream_impact(self, house_graph):
        ranked = house_graph.critical_nodes(5)
        assert len(ranked) == 5
        assert ranked[0][1] >= ranked[-1][1]

    def test_statistics(self, house_graph):
        stats = house_graph.statistics()
        assert stats["is_acyclic"]
        assert stats["component_nodes"] > 50
        assert stats["stage_gates"] > 0
        assert 0 <= stats["density"] <= 1

    def test_to_dict_is_node_link(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        payload = graph.to_dict()
        assert {"nodes", "edges"} == set(payload)
        assert all("id" in node for node in payload["nodes"])
        assert all({"from", "to", "kind"} <= set(edge) for edge in payload["edges"])

    def test_subgraph_for_stage(self, house, house_graph):
        subgraph = house_graph.subgraph_for_stage(ConstructionStage.EXTERNAL_WALLS)
        expected = len(house.registry.by_stage(ConstructionStage.EXTERNAL_WALLS))
        assert subgraph.number_of_nodes() == expected

    def test_component_lookup(self, tiny_building):
        graph = ConstructionDependencyGraph.from_building(tiny_building)
        assert graph.component("EXC-1").id == "EXC-1"

    def test_stage_gate_id_helper(self):
        assert stage_gate_id(ConstructionStage.FOUNDATIONS).endswith("FOUNDATIONS")

    def test_empty_registry_graph(self):
        graph = ConstructionDependencyGraph(Building(id="B", name="B").registry)
        assert graph.node_count == 0
        assert graph.waves() == []
        assert graph.topological_order() == []


# --------------------------------------------------------------------------- #
# Fabrication
# --------------------------------------------------------------------------- #
class TestHouseSpecification:
    def test_derived_measures(self):
        spec = HouseSpecification(length=10.0, width=8.0, wall_thickness=0.3, storeys=2)
        assert spec.footprint_area == pytest.approx(80.0)
        assert spec.perimeter == pytest.approx(36.0)
        assert spec.gross_internal_area == pytest.approx(2 * 9.4 * 7.4, rel=1e-6)

    @pytest.mark.parametrize(
        "kwargs",
        [
            {"length": 0.0},
            {"storeys": 0},
            {"roof_pitch": 95.0},
            {"wall_thickness": 10.0},
        ],
    )
    def test_validation_rejects_nonsense(self, kwargs):
        with pytest.raises(ValueError):
            HouseSpecification(**kwargs).validate()

    def test_builder_validates_on_construction(self):
        with pytest.raises(ValueError):
            StandardHouseBuilder(HouseSpecification(storeys=0))


class TestStandardHouseBuilder:
    def test_produces_a_substantial_model(self, house):
        assert len(house) > 50

    def test_covers_the_full_stage_sequence(self, house):
        stages = set(house.stages())
        for required in (
            ConstructionStage.SITE_PREPARATION,
            ConstructionStage.EXCAVATION,
            ConstructionStage.FOUNDATIONS,
            ConstructionStage.DRAINAGE,
            ConstructionStage.FLOOR_SLAB,
            ConstructionStage.EXTERNAL_WALLS,
            ConstructionStage.INTERNAL_WALLS,
            ConstructionStage.UPPER_FLOORS,
            ConstructionStage.ROOF_STRUCTURE,
            ConstructionStage.ROOF_COVERING,
            ConstructionStage.WINDOWS,
            ConstructionStage.DOORS,
            ConstructionStage.FIRST_FIX,
            ConstructionStage.INSULATION,
            ConstructionStage.PLASTERBOARD,
            ConstructionStage.SECOND_FIX,
            ConstructionStage.DECORATION,
            ConstructionStage.FLOOR_FINISHES,
            ConstructionStage.EXTERNAL_WORKS,
        ):
            assert required in stages, f"missing stage {required.name}"

    def test_no_dangling_dependencies(self, house):
        assert house.dangling_dependencies() == []

    def test_windows_are_hosted_and_deducted(self, house):
        windows = house.registry.by_kind(ComponentKind.WINDOW)
        assert windows
        for window in windows:
            assert window.host_wall_id in house
            host = house.get(window.host_wall_id)
            assert any(o.component_id == window.id for o in host.openings)

    def test_wall_openings_reduce_brick_count(self, house):
        walls = [
            w
            for w in house.registry.by_kind(ComponentKind.WALL)
            if w.wall_type is WallType.CAVITY_EXTERNAL and w.openings
        ]
        assert walls
        for wall in walls:
            assert wall.measured_area < wall.gross_area

    def test_gross_internal_area_is_plausible(self, house):
        assert 90.0 < house.gross_internal_area < 200.0

    def test_mass_is_plausible_for_a_masonry_house(self, house):
        tonnes = house.total_mass() / 1000.0
        assert 80.0 < tonnes < 500.0

    def test_material_cost_is_plausible(self, house):
        assert 20_000.0 < house.net_material_cost() < 200_000.0

    def test_all_trades_are_represented(self, house):
        trades = {d.trade for d in house.labour_demands()}
        for expected in (
            Trade.GROUNDWORKER,
            Trade.BRICKLAYER,
            Trade.CARPENTER,
            Trade.ROOFER,
            Trade.ELECTRICIAN,
            Trade.PLUMBER,
            Trade.PLASTERER,
            Trade.DECORATOR,
            Trade.GLAZIER,
        ):
            assert expected in trades, f"missing trade {expected}"

    def test_labour_hours_are_plausible(self, house):
        hours = house.registry.total_labour_hours()
        assert 800.0 < hours < 6000.0

    def test_single_storey_variant(self):
        building = StandardHouseBuilder(HouseSpecification(storeys=1)).build("B", "Bungalow")
        assert building.registry.levels() == [0, 1]
        graph = ConstructionDependencyGraph.from_building(building)
        graph.assert_valid()

    def test_three_storey_variant(self):
        building = StandardHouseBuilder(HouseSpecification(storeys=3)).build("B", "Townhouse")
        graph = ConstructionDependencyGraph.from_building(building)
        graph.assert_valid()
        assert len(building) > 60

    def test_render_option_adds_component(self):
        building = StandardHouseBuilder(
            HouseSpecification(render_area=40.0)
        ).build("B", "Rendered")
        finishes = building.registry.by_kind(ComponentKind.EXTERNAL_FINISH)
        assert any(f.material_id == "RENDER_SILICONE" for f in finishes)

    def test_external_works_can_be_omitted(self):
        building = StandardHouseBuilder(
            HouseSpecification(paving_area=0.0, garden_area=0.0, render_area=0.0)
        ).build("B", "No works")
        assert building.registry.by_kind(ComponentKind.EXTERNAL_FINISH) == []

    def test_larger_house_costs_more(self):
        small = StandardHouseBuilder(HouseSpecification(length=7.0, width=6.0)).build("A", "S")
        large = StandardHouseBuilder(HouseSpecification(length=12.0, width=10.0)).build("B", "L")
        assert large.net_material_cost() > small.net_material_cost()
        assert large.gross_internal_area > small.gross_internal_area

    def test_identifiers_are_namespaced_and_deterministic(self):
        first = StandardHouseBuilder(HouseSpecification()).build("BLD-9", "H")
        second = StandardHouseBuilder(HouseSpecification()).build("BLD-9", "H")
        assert first.registry.ids == second.registry.ids
        assert all(i.startswith("BLD_9-") for i in first.registry.ids)


class TestBuildEstate:
    def test_generates_plots_and_buildings(self):
        site, buildings = build_estate(4)
        assert len(site.plots) == 4
        assert len(buildings) == 4
        assert all(len(b) > 50 for b in buildings)

    def test_plots_do_not_overlap(self):
        site, _ = build_estate(6)
        assert site.overlapping_plots() == []

    def test_plots_are_linked_to_buildings(self):
        site, buildings = build_estate(3)
        assert [p.building_id for p in site.plots] == [b.id for b in buildings]

    def test_rejects_zero_plots(self):
        with pytest.raises(ValueError):
            build_estate(0)

    def test_scales_to_a_large_model(self):
        _, buildings = build_estate(20)
        total = sum(len(b) for b in buildings)
        assert total > 1000


# --------------------------------------------------------------------------- #
# End-to-end
# --------------------------------------------------------------------------- #
class TestIntegration:
    def test_full_build_simulation_completes_every_component(self, house):
        """Repeatedly build the ready frontier until nothing remains."""
        graph = ConstructionDependencyGraph.from_building(house)
        ticks = 0
        while True:
            ready = graph.ready_components()
            if not ready:
                break
            for component_id in ready:
                house.set_status(component_id, InstallationStatus.COMPLETE, force=True)
            graph.rebuild()
            ticks += 1
            assert ticks < 100, "sequencing failed to converge"

        assert ticks > 3
        assert house.registry.completion_fraction() == 1.0

    def test_sequence_never_builds_before_its_predecessors(self, house):
        graph = ConstructionDependencyGraph.from_building(house)
        built: set[str] = set()
        while True:
            ready = graph.ready_components()
            if not ready:
                break
            for component_id in ready:
                for predecessor in graph.predecessors(component_id):
                    assert predecessor in built, (
                        f"{component_id} started before {predecessor}"
                    )
                house.set_status(component_id, InstallationStatus.COMPLETE, force=True)
                built.add(component_id)
            graph.rebuild()
        assert built == set(graph.component_nodes)

    def test_topological_order_is_a_valid_build_order(self, house, house_graph):
        position = {node: i for i, node in enumerate(house_graph.topological_order())}
        for component in house:
            for dependency in component.depends_on:
                assert position[dependency] < position[component.id]

    def test_round_trip_preserves_graph_structure(self, house):
        original = ConstructionDependencyGraph.from_building(house)
        restored = ConstructionDependencyGraph.from_building(
            Building.from_json(house.to_json())
        )
        assert original.statistics() == restored.statistics()

    def test_quantities_are_conserved_across_round_trip(self, house):
        restored = Building.from_json(house.to_json())
        original_totals: dict[str, float] = {}
        for demand in house.material_demands():
            original_totals[demand.material_id] = (
                original_totals.get(demand.material_id, 0.0) + demand.quantity
            )
        restored_totals: dict[str, float] = {}
        for demand in restored.material_demands():
            restored_totals[demand.material_id] = (
                restored_totals.get(demand.material_id, 0.0) + demand.quantity
            )
        assert original_totals == pytest.approx(restored_totals)

    def test_every_demanded_material_exists_in_the_catalogue(self, house, catalogue):
        missing = {
            d.material_id
            for d in house.material_demands()
            if catalogue.find(d.material_id) is None
        }
        assert missing == set()

    def test_every_component_type_is_exercised_by_the_builder(self, house):
        produced = {c.kind for c in house}
        expected = {
            ComponentKind.EXCAVATION,
            ComponentKind.FOUNDATION,
            ComponentKind.DRAINAGE_RUN,
            ComponentKind.FLOOR_SLAB,
            ComponentKind.WALL,
            ComponentKind.JOIST,
            ComponentKind.FLOOR,
            ComponentKind.ROOF_STRUCTURE,
            ComponentKind.ROOF_COVERING,
            ComponentKind.WINDOW,
            ComponentKind.DOOR,
            ComponentKind.INSULATION,
            ComponentKind.ELECTRICAL_CIRCUIT,
            ComponentKind.PLUMBING_RUN,
            ComponentKind.INTERNAL_FINISH,
            ComponentKind.EXTERNAL_FINISH,
        }
        assert expected <= produced

    def test_events_fire_throughout_a_build(self, bus):
        from buildcore.core.events import ComponentAdded, DependencyAdded

        building = StandardHouseBuilder(HouseSpecification()).build(
            "BLD-EV", "Event house", event_bus=bus
        )
        assert len(bus.history_of(ComponentAdded)) == len(building)
        assert len(bus.history_of(DependencyAdded)) > 50

    def test_estate_graph_validates(self):
        _, buildings = build_estate(3)
        for building in buildings:
            ConstructionDependencyGraph.from_building(building).assert_valid()
