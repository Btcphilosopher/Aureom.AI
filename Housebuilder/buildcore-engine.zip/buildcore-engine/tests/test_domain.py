"""Unit tests for the domain layer."""

from __future__ import annotations

import math

import pytest

from buildcore.core.exceptions import (
    ComponentError,
    ComponentNotFoundError,
    DuplicateComponentError,
    GeometryError,
    MaterialError,
    MissingDependencyError,
    SiteError,
)
from buildcore.core.units import Unit
from buildcore.domain.building import Building
from buildcore.domain.components import (
    Beam,
    Column,
    Door,
    DrainageRun,
    ElectricalCircuit,
    Excavation,
    ExternalFinish,
    ExternalFinishType,
    Floor,
    FloorSlab,
    Foundation,
    FoundationType,
    InsulationLayer,
    InternalFinish,
    InternalFinishType,
    Joist,
    Opening,
    PlumbingRun,
    RoofCovering,
    RoofStructure,
    Wall,
    WallType,
    Window,
)
from buildcore.domain.constants import BLOCKS_PER_M2, BRICKS_PER_M2, labour_hours
from buildcore.domain.enums import (
    ComponentKind,
    ConstructionStage,
    InstallationStatus,
    Orientation,
    Trade,
)
from buildcore.domain.geometry import (
    BoundingBox,
    Dimensions,
    Footprint,
    Placement,
    Vec3,
    polygon_area,
    polygon_perimeter,
)
from buildcore.domain.materials import Material, MaterialCatalogue
from buildcore.domain.site import AccessPoint, GroundConditions, Plot, Site


# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #
class TestEnums:
    def test_stages_ordered_by_build_sequence(self):
        assert ConstructionStage.FOUNDATIONS < ConstructionStage.ROOF_STRUCTURE
        assert ConstructionStage.ordered()[0] is ConstructionStage.SITE_PREPARATION
        assert ConstructionStage.ordered()[-1] is ConstructionStage.COMPLETION

    def test_stage_labels(self):
        assert ConstructionStage.FLOOR_SLAB.label == "Floor Slab"

    def test_weather_sensitivity(self):
        assert ConstructionStage.FOUNDATIONS.is_weather_sensitive
        assert not ConstructionStage.DECORATION.is_weather_sensitive

    def test_structural_flag(self):
        assert ConstructionStage.EXTERNAL_WALLS.is_structural
        assert not ConstructionStage.DECORATION.is_structural

    def test_successor_and_predecessor(self):
        assert ConstructionStage.SITE_PREPARATION.predecessor() is None
        assert ConstructionStage.COMPLETION.successor() is None
        assert ConstructionStage.EXCAVATION.predecessor() is ConstructionStage.SITE_PREPARATION

    def test_status_progress_is_monotonic(self):
        assert InstallationStatus.NOT_STARTED.progress_fraction == 0.0
        assert InstallationStatus.COMPLETE.progress_fraction == 1.0
        assert (
            InstallationStatus.IN_PROGRESS.progress_fraction
            < InstallationStatus.INSTALLED.progress_fraction
        )

    def test_physical_presence(self):
        assert InstallationStatus.INSTALLED.is_physically_present
        assert not InstallationStatus.SCHEDULED.is_physically_present

    def test_terminal_status(self):
        assert InstallationStatus.COMPLETE.is_terminal
        assert not InstallationStatus.INSTALLED.is_terminal

    def test_component_kind_prefix(self):
        assert ComponentKind.WALL.prefix == "WALL"

    def test_trade_label(self):
        assert Trade.STEEL_ERECTOR.label == "Steel Erector"

    def test_orientation_bearing(self):
        assert Orientation.SOUTH.bearing_degrees == 180.0
        assert Orientation.INTERNAL.bearing_degrees is None


# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #
class TestVec3:
    def test_arithmetic(self):
        a, b = Vec3(x=1, y=2, z=3), Vec3(x=4, y=5, z=6)
        assert (a + b).as_tuple() == (5, 7, 9)
        assert (b - a).as_tuple() == (3, 3, 3)
        assert (a * 2).as_tuple() == (2, 4, 6)
        assert (2 * a).as_tuple() == (2, 4, 6)
        assert (-a).as_tuple() == (-1, -2, -3)

    def test_length(self):
        assert Vec3(x=3, y=4, z=0).length == pytest.approx(5.0)
        assert Vec3(x=3, y=4, z=12).length_2d == pytest.approx(5.0)

    def test_distance(self):
        assert Vec3().distance_to(Vec3(x=3, y=4)) == pytest.approx(5.0)
        assert Vec3(z=99).distance_2d(Vec3(x=3, y=4)) == pytest.approx(5.0)

    def test_dot_and_cross(self):
        x, y = Vec3(x=1), Vec3(y=1)
        assert x.dot(y) == 0
        assert x.cross(y).as_tuple() == (0, 0, 1)

    def test_normalised(self):
        assert Vec3(x=5).normalised().length == pytest.approx(1.0)

    def test_normalise_zero_raises(self):
        with pytest.raises(GeometryError):
            Vec3().normalised()

    def test_rotation(self):
        rotated = Vec3(x=1).rotated_z(90)
        assert rotated.x == pytest.approx(0.0, abs=1e-9)
        assert rotated.y == pytest.approx(1.0)

    def test_frozen(self):
        with pytest.raises(Exception):
            Vec3().x = 1


class TestDimensions:
    def test_derived_measures(self, dims):
        assert dims.volume == pytest.approx(4.0 * 0.3 * 2.5)
        assert dims.footprint_area == pytest.approx(1.2)
        assert dims.face_area == pytest.approx(10.0)
        assert dims.perimeter == pytest.approx(8.6)

    def test_rejects_non_positive(self):
        with pytest.raises(Exception):
            Dimensions(length=0, width=1, height=1)

    def test_scaled(self, dims):
        assert dims.scaled(2).length == pytest.approx(8.0)

    def test_scale_must_be_positive(self, dims):
        with pytest.raises(GeometryError):
            dims.scaled(0)


class TestBoundingBox:
    def make(self, size=1.0):
        return BoundingBox(minimum=Vec3(), maximum=Vec3(x=size, y=size, z=size))

    def test_measures(self):
        box = self.make(2.0)
        assert box.volume == pytest.approx(8.0)
        assert box.footprint_area == pytest.approx(4.0)
        assert box.centre.as_tuple() == (1.0, 1.0, 1.0)

    def test_rejects_inverted(self):
        with pytest.raises(Exception):
            BoundingBox(minimum=Vec3(x=5), maximum=Vec3(x=0))

    def test_contains(self):
        box = self.make(2.0)
        assert box.contains(Vec3(x=1, y=1, z=1))
        assert not box.contains(Vec3(x=5))

    def test_intersects_and_overlap(self):
        a = self.make(2.0)
        b = BoundingBox(minimum=Vec3(x=1, y=1, z=1), maximum=Vec3(x=3, y=3, z=3))
        assert a.intersects(b)
        assert a.overlap_volume(b) == pytest.approx(1.0)

    def test_no_overlap(self):
        a = self.make(1.0)
        b = BoundingBox(minimum=Vec3(x=5), maximum=Vec3(x=6, y=1, z=1))
        assert not a.intersects(b)
        assert a.overlap_volume(b) == 0.0

    def test_merged_and_expanded(self):
        a = self.make(1.0)
        b = BoundingBox(minimum=Vec3(x=2), maximum=Vec3(x=3, y=1, z=1))
        assert a.merged(b).maximum.x == 3.0
        assert a.expanded(1.0).minimum.x == -1.0

    def test_enclosing(self):
        boxes = [self.make(1.0), BoundingBox(minimum=Vec3(x=4), maximum=Vec3(x=5, y=1, z=1))]
        assert BoundingBox.enclosing(boxes).maximum.x == 5.0

    def test_enclosing_empty(self):
        assert BoundingBox.enclosing([]) is None


class TestPlacement:
    def test_to_world(self):
        placement = Placement(origin=Vec3(x=10), rotation_z=90)
        assert placement.to_world(Vec3(x=1)).y == pytest.approx(1.0)

    def test_rotation_normalised(self):
        assert Placement(rotation_z=450).rotation_z == pytest.approx(90.0)

    def test_bounding_box_accounts_for_rotation(self):
        dimensions = Dimensions(length=4.0, width=1.0, height=2.0)
        unrotated = Placement().bounding_box(dimensions)
        rotated = Placement(rotation_z=90).bounding_box(dimensions)
        assert unrotated.size.x == pytest.approx(4.0)
        assert rotated.size.y == pytest.approx(4.0)
        assert rotated.size.x == pytest.approx(1.0)

    def test_bounding_box_height(self, dims):
        assert Placement().bounding_box(dims).size.z == pytest.approx(dims.height)

    def test_translated(self):
        assert Placement().translated(Vec3(x=5)).origin.x == 5.0


class TestFootprint:
    def test_rectangle_measures(self):
        footprint = Footprint.rectangle(10.0, 5.0)
        assert footprint.area == pytest.approx(50.0)
        assert footprint.perimeter == pytest.approx(30.0)
        assert footprint.centroid.x == pytest.approx(5.0)

    def test_bounds(self):
        assert Footprint.rectangle(2.0, 3.0).bounds == (0.0, 0.0, 2.0, 3.0)

    def test_closing_vertex_removed(self):
        footprint = Footprint(vertices=((0, 0), (1, 0), (1, 1), (0, 0)))
        assert len(footprint.vertices) == 3

    def test_rejects_degenerate(self):
        with pytest.raises(Exception):
            Footprint(vertices=((0, 0), (1, 1)))

    def test_rejects_self_intersecting(self):
        with pytest.raises(Exception):
            Footprint(vertices=((0, 0), (2, 2), (2, 0), (0, 2)))

    def test_rectangle_rejects_bad_dimensions(self):
        with pytest.raises(GeometryError):
            Footprint.rectangle(0, 5)

    def test_containment(self):
        outer = Footprint.rectangle(10.0, 10.0)
        inner = Footprint.rectangle(2.0, 2.0, origin=(1.0, 1.0))
        assert outer.contains_footprint(inner)
        assert not inner.contains_footprint(outer)
        assert outer.contains_point(Vec3(x=5, y=5))
        assert not outer.contains_point(Vec3(x=50, y=5))

    def test_overlap(self):
        a = Footprint.rectangle(4.0, 4.0)
        b = Footprint.rectangle(4.0, 4.0, origin=(2.0, 2.0))
        far = Footprint.rectangle(1.0, 1.0, origin=(50.0, 50.0))
        assert a.overlaps(b)
        assert a.intersection_area(b) == pytest.approx(4.0)
        assert not a.overlaps(far)

    def test_offset_inward(self):
        inset = Footprint.rectangle(10.0, 10.0).offset(-1.0)
        assert inset is not None
        assert inset.area == pytest.approx(64.0)

    def test_offset_collapses_to_none(self):
        assert Footprint.rectangle(1.0, 1.0).offset(-5.0) is None

    def test_shoelace_helpers(self):
        square = [(0, 0), (2, 0), (2, 2), (0, 2)]
        assert polygon_area(square) == pytest.approx(4.0)
        assert polygon_perimeter(square) == pytest.approx(8.0)
        assert polygon_area([(0, 0)]) == 0.0
        assert polygon_perimeter([(0, 0)]) == 0.0


# --------------------------------------------------------------------------- #
# Materials
# --------------------------------------------------------------------------- #
class TestMaterials:
    def test_standard_catalogue_populated(self, catalogue):
        assert len(catalogue) > 30
        assert "BRICK_FACING" in catalogue

    def test_get_unknown_raises(self, catalogue):
        with pytest.raises(MaterialError):
            catalogue.get("NOT_A_MATERIAL")

    def test_find_returns_none(self, catalogue):
        assert catalogue.find("NOPE") is None

    def test_duplicate_rejected(self, catalogue):
        brick = catalogue.get("BRICK_FACING")
        with pytest.raises(MaterialError):
            catalogue.add(brick)

    def test_replace_allowed(self, catalogue):
        brick = catalogue.get("BRICK_FACING")
        catalogue.add(brick.model_copy(update={"unit_cost": 1.0}), replace=True)
        assert catalogue.get("BRICK_FACING").unit_cost == 1.0

    def test_remove(self, catalogue):
        catalogue.remove("BRICK_FACING")
        assert "BRICK_FACING" not in catalogue
        with pytest.raises(MaterialError):
            catalogue.remove("BRICK_FACING")

    def test_by_class(self, catalogue):
        from buildcore.domain.enums import MaterialClass

        assert catalogue.by_class(MaterialClass.MASONRY)

    def test_cost_and_mass(self, catalogue):
        brick = catalogue.get("BRICK_FACING")
        assert brick.cost_for(100) == pytest.approx(62.0)
        assert brick.mass_for(100) == pytest.approx(260.0)

    def test_unit_mass_derived_from_density(self):
        material = Material(
            id="X",
            name="X",
            material_class="concrete",
            unit=Unit.CUBIC_METRE,
            unit_cost=1.0,
            density_kg_m3=2400.0,
        )
        assert material.unit_mass_kg == pytest.approx(2400.0)

    def test_orderable_rounds_to_pack(self, catalogue):
        brick = catalogue.get("BRICK_FACING")
        assert brick.orderable_quantity(501) == 1000.0

    def test_orderable_respects_minimum(self, catalogue):
        concrete = catalogue.get("CONCRETE_C25")
        assert concrete.orderable_quantity(1.0) == 6.0

    def test_orderable_ceils_countables(self):
        material = Material(
            id="Y", name="Y", material_class="fixing", unit=Unit.EACH, unit_cost=1.0
        )
        assert material.orderable_quantity(3.2) == 4.0

    def test_price_adjustment(self, catalogue):
        adjusted = catalogue.with_price_adjustment(2.0)
        assert adjusted.get("BRICK_FACING").unit_cost == pytest.approx(1.24)

    def test_price_adjustment_rejects_non_positive(self, catalogue):
        with pytest.raises(MaterialError):
            catalogue.with_price_adjustment(0)

    def test_iteration_and_copy(self, catalogue):
        assert len(list(catalogue)) == len(catalogue)
        assert len(catalogue.copy()) == len(catalogue)
        assert catalogue.ids() == sorted(catalogue.ids())

    def test_empty_catalogue(self):
        assert len(MaterialCatalogue()) == 0


# --------------------------------------------------------------------------- #
# Components
# --------------------------------------------------------------------------- #
class TestWall:
    def test_cavity_wall_brick_count(self, wall):
        demands = {d.material_id: d.quantity for d in wall.material_demands()}
        assert demands["BRICK_FACING"] == pytest.approx(10.0 * BRICKS_PER_M2)
        assert demands["BLOCK_AAC_100"] == pytest.approx(10.0 * BLOCKS_PER_M2)
        assert demands["MORTAR_M4"] > 0
        assert demands["INSUL_PIR_100"] == pytest.approx(10.0)

    def test_openings_deducted(self, wall):
        wall.add_opening(Opening(component_id="WIN-1", width=1.0, height=1.0))
        assert wall.gross_area == pytest.approx(10.0)
        assert wall.opening_area == pytest.approx(1.0)
        assert wall.measured_area == pytest.approx(9.0)
        demands = {d.material_id: d.quantity for d in wall.material_demands()}
        assert demands["BRICK_FACING"] == pytest.approx(9.0 * BRICKS_PER_M2)

    def test_oversized_opening_rejected(self, wall):
        with pytest.raises(ComponentError, match="larger than the wall"):
            wall.add_opening(Opening(component_id="W", width=50.0, height=50.0))

    def test_cumulative_openings_rejected(self, wall):
        wall.add_opening(Opening(component_id="A", width=3.0, height=2.5))
        with pytest.raises(ComponentError, match="exceed the wall"):
            wall.add_opening(Opening(component_id="B", width=3.0, height=2.5))

    def test_fully_glazed_wall_has_no_demands(self):
        wall = Wall(
            id="W", name="W", dimensions=Dimensions(length=2.0, width=0.3, height=2.0)
        )
        wall.add_opening(Opening(component_id="G", width=2.0, height=2.0))
        assert wall.measured_area == 0.0
        assert wall.material_demands() == []
        assert wall.labour_demands() == []

    def test_net_volume_uses_net_area(self, wall):
        assert wall.net_volume == pytest.approx(10.0 * 0.3)

    def test_solid_block_wall(self):
        wall = Wall(
            id="W",
            name="W",
            wall_type=WallType.SOLID_BLOCK,
            dimensions=Dimensions(length=4.0, width=0.1, height=2.5),
        )
        ids = {d.material_id for d in wall.material_demands()}
        assert ids == {"BLOCK_AAC_100", "MORTAR_M4"}

    def test_party_wall_doubles_leaves(self):
        single = Wall(
            id="A",
            name="A",
            wall_type=WallType.SOLID_BLOCK,
            dimensions=Dimensions(length=4.0, width=0.1, height=2.5),
        )
        party = Wall(
            id="B",
            name="B",
            wall_type=WallType.PARTY_WALL,
            dimensions=Dimensions(length=4.0, width=0.25, height=2.5),
        )
        single_blocks = next(
            d.quantity for d in single.material_demands() if d.material_id == "BLOCK_AAC_100"
        )
        party_blocks = next(
            d.quantity for d in party.material_demands() if d.material_id == "BLOCK_AAC_100"
        )
        assert party_blocks == pytest.approx(single_blocks * 2)

    def test_stud_partition_materials_and_trades(self):
        wall = Wall(
            id="P",
            name="Partition",
            wall_type=WallType.STUD_PARTITION,
            dimensions=Dimensions(length=4.0, width=0.115, height=2.5),
        )
        ids = {d.material_id for d in wall.material_demands()}
        assert "TIMBER_C24" in ids and "PLASTERBOARD_12_5" in ids
        trades = {d.trade for d in wall.labour_demands()}
        assert trades == {Trade.CARPENTER, Trade.PLASTERER}

    def test_partition_boards_both_faces(self):
        wall = Wall(
            id="P",
            name="P",
            wall_type=WallType.STUD_PARTITION,
            dimensions=Dimensions(length=4.0, width=0.115, height=2.5),
        )
        board = next(
            d.quantity for d in wall.material_demands() if d.material_id == "PLASTERBOARD_12_5"
        )
        assert board == pytest.approx(20.0)

    def test_internal_wall_type_moves_stage(self):
        wall = Wall(
            id="P",
            name="P",
            wall_type=WallType.STUD_PARTITION,
            dimensions=Dimensions(length=2.0, width=0.1, height=2.4),
        )
        assert wall.stage is ConstructionStage.INTERNAL_WALLS

    def test_bricklayer_is_primary_trade(self, wall):
        assert wall.primary_trade() is Trade.BRICKLAYER

    def test_labour_scales_with_area(self, wall):
        expected = 10.0 * (labour_hours("lay_facing_brick") + labour_hours("lay_blockwork"))
        assert wall.total_labour_hours() == pytest.approx(expected, rel=1e-6)


class TestOtherComponents:
    def test_excavation_bulking(self):
        excavation = Excavation(
            id="E", name="E", dimensions=Dimensions(length=10, width=2, height=1)
        )
        assert excavation.gross_volume == pytest.approx(20.0)
        assert excavation.bulked_volume == pytest.approx(25.0)
        assert excavation.disposal_volume == pytest.approx(17.5)

    def test_hand_dig_is_slower(self):
        machine = Excavation(
            id="A", name="A", dimensions=Dimensions(length=10, width=2, height=1)
        )
        hand = Excavation(
            id="B",
            name="B",
            machine_accessible=False,
            dimensions=Dimensions(length=10, width=2, height=1),
        )
        assert hand.total_labour_hours() > machine.total_labour_hours() * 10

    def test_foundation_concrete_volume(self):
        foundation = Foundation(
            id="F", name="F", dimensions=Dimensions(length=10, width=0.6, height=1.0)
        )
        demand = foundation.material_demands()[0]
        assert demand.material_id == "CONCRETE_C35"
        assert demand.quantity == pytest.approx(6.0)

    def test_reinforced_foundation_adds_mesh(self):
        foundation = Foundation(
            id="F",
            name="F",
            reinforced=True,
            dimensions=Dimensions(length=10, width=2.0, height=0.4),
        )
        ids = {d.material_id for d in foundation.material_demands()}
        assert "REBAR_A393" in ids

    def test_foundation_types(self):
        foundation = Foundation(
            id="F",
            name="F",
            foundation_type=FoundationType.RAFT,
            dimensions=Dimensions(length=8, width=8, height=0.3),
        )
        assert foundation.foundation_type is FoundationType.RAFT

    def test_drainage_run(self):
        run = DrainageRun(
            id="D", name="D", dimensions=Dimensions(length=20.0, width=0.6, height=0.3)
        )
        demands = {d.material_id: d.quantity for d in run.material_demands()}
        assert demands["PIPE_SOIL_110"] == pytest.approx(20.0)
        assert demands["HARDCORE_MOT1"] > 0
        assert run.labour_demands()[0].trade is Trade.GROUNDWORKER

    def test_drainage_without_bedding(self):
        run = DrainageRun(
            id="D",
            name="D",
            bedding_thickness=0.0,
            dimensions=Dimensions(length=20.0, width=0.6, height=0.3),
        )
        assert len(run.material_demands()) == 1

    def test_floor_slab_full_buildup(self):
        slab = FloorSlab(
            id="S", name="S", dimensions=Dimensions(length=10, width=8, height=0.15)
        )
        demands = {d.material_id: d.quantity for d in slab.material_demands()}
        assert demands["CONCRETE_C25"] == pytest.approx(12.0)
        assert demands["DPM_1200G"] == pytest.approx(88.0)
        assert "HARDCORE_MOT1" in demands
        assert "SAND_BLINDING" in demands
        assert "INSUL_PIR_100" in demands
        assert "REBAR_A393" in demands

    def test_slab_without_optional_layers(self):
        slab = FloorSlab(
            id="S",
            name="S",
            hardcore_thickness=0.0,
            sand_blinding_thickness=0.0,
            insulation_thickness=0.0,
            reinforced=False,
            dimensions=Dimensions(length=10, width=8, height=0.15),
        )
        ids = {d.material_id for d in slab.material_demands()}
        assert ids == {"CONCRETE_C25", "DPM_1200G"}

    def test_steel_beam_mass(self):
        beam = Beam(
            id="B",
            name="B",
            mass_per_metre=25.0,
            dimensions=Dimensions(length=4.0, width=0.2, height=0.2),
        )
        assert beam.steel_mass == pytest.approx(100.0)
        assert beam.material_demands()[0].unit is Unit.KILOGRAM
        assert beam.labour_demands()[0].trade is Trade.STEEL_ERECTOR

    def test_timber_beam_switches_measurement(self):
        beam = Beam(
            id="B",
            name="B",
            material_id="TIMBER_C24",
            dimensions=Dimensions(length=4.0, width=0.1, height=0.3),
        )
        assert beam.material_demands()[0].unit is Unit.CUBIC_METRE
        assert beam.labour_demands()[0].trade is Trade.CARPENTER

    def test_column_spans_vertically(self):
        column = Column(
            id="C", name="C", dimensions=Dimensions(length=0.2, width=0.2, height=3.0)
        )
        assert column.span == pytest.approx(3.0)
        assert column.kind is ComponentKind.COLUMN

    def test_joist_group_volume(self):
        joist = Joist(
            id="J",
            name="J",
            count=20,
            section_width=0.047,
            section_depth=0.22,
            dimensions=Dimensions(length=4.0, width=6.0, height=0.22),
        )
        assert joist.net_volume == pytest.approx(20 * 4.0 * 0.047 * 0.22)
        hangers = next(
            d.quantity for d in joist.material_demands() if d.material_id == "JOIST_HANGER"
        )
        assert hangers == 40.0

    def test_joist_without_hangers(self):
        joist = Joist(
            id="J",
            name="J",
            hangers_per_joist=0,
            dimensions=Dimensions(length=4.0, width=1.0, height=0.22),
        )
        assert len(joist.material_demands()) == 1

    def test_floor_deck(self):
        floor = Floor(id="F", name="F", dimensions=Dimensions(length=8, width=6, height=0.018))
        demands = {d.material_id: d.quantity for d in floor.material_demands()}
        assert demands["OSB3_18MM"] == pytest.approx(48.0)
        assert floor.labour_demands()[0].trade is Trade.CARPENTER

    def test_roof_structure_geometry(self):
        roof = RoofStructure(
            id="R",
            name="R",
            pitch_degrees=45.0,
            truss_spacing=0.6,
            dimensions=Dimensions(length=9.0, width=7.0, height=3.5),
        )
        assert roof.truss_count == 16
        assert roof.plan_area == pytest.approx(63.0)
        assert roof.slope_area == pytest.approx(63.0 / math.cos(math.radians(45.0)))
        assert roof.ridge_length == pytest.approx(9.0)

    def test_roof_structure_materials(self):
        roof = RoofStructure(
            id="R", name="R", dimensions=Dimensions(length=9.0, width=7.0, height=3.0)
        )
        ids = {d.material_id for d in roof.material_demands()}
        assert ids == {"TIMBER_C24", "TIMBER_TREATED", "NAILS_FIXINGS"}

    def test_roof_covering_tiles(self):
        covering = RoofCovering(
            id="C",
            name="C",
            pitch_degrees=0.0001,
            ridge_length=9.0,
            dimensions=Dimensions(length=9.0, width=7.0, height=0.05),
        )
        demands = {d.material_id: d.quantity for d in covering.material_demands()}
        assert demands["TILE_PLAIN_CLAY"] == pytest.approx(63.0 * 60.0, rel=1e-3)
        assert demands["RIDGE_TILE"] == pytest.approx(9.0 * 3.3, rel=1e-3)
        assert covering.labour_demands()[0].trade is Trade.ROOFER

    def test_roof_covering_without_ridge(self):
        covering = RoofCovering(
            id="C", name="C", dimensions=Dimensions(length=9.0, width=7.0, height=0.05)
        )
        assert "RIDGE_TILE" not in {d.material_id for d in covering.material_demands()}

    def test_pitch_increases_slope_area(self):
        shallow = RoofCovering(
            id="A", name="A", pitch_degrees=15.0, dimensions=Dimensions(length=9, width=7, height=0.05)
        )
        steep = RoofCovering(
            id="B", name="B", pitch_degrees=60.0, dimensions=Dimensions(length=9, width=7, height=0.05)
        )
        assert steep.slope_area > shallow.slope_area

    def test_window(self):
        window = Window(
            id="W", name="W", dimensions=Dimensions(length=1.2, width=0.15, height=1.2)
        )
        assert window.measured_area == pytest.approx(1.44)
        assert window.material_demands()[0].unit is Unit.SQUARE_METRE
        assert window.labour_demands()[0].trade is Trade.GLAZIER

    def test_external_door_defaults(self):
        door = Door(id="D", name="D", dimensions=Dimensions(length=0.9, width=0.15, height=2.0))
        assert door.material_id == "DOOR_EXTERNAL"
        assert door.labour_demands()[0].operation == "install_door_external"

    def test_internal_door_defaults(self):
        door = Door(
            id="D",
            name="D",
            is_external=False,
            dimensions=Dimensions(length=0.8, width=0.1, height=2.0),
        )
        assert door.material_id == "DOOR_INTERNAL"
        assert door.labour_demands()[0].operation == "install_door_internal"

    def test_insulation_layer(self):
        layer = InsulationLayer(
            id="I",
            name="I",
            area_m2=70.0,
            thickness_mm=300.0,
            dimensions=Dimensions(length=10, width=7, height=0.3),
        )
        assert layer.measured_area == pytest.approx(70.0)
        assert layer.net_volume == pytest.approx(21.0)
        assert layer.labour_demands()[0].trade is Trade.INSULATION_FITTER

    def test_electrical_circuit(self):
        circuit = ElectricalCircuit(
            id="E",
            name="E",
            cable_length_m=100.0,
            accessory_count=12,
            dimensions=Dimensions(length=1, width=0.1, height=0.1),
        )
        demands = {d.material_id: d.quantity for d in circuit.material_demands()}
        assert demands["CABLE_TWIN_EARTH"] == pytest.approx(100.0)
        assert demands["ELECTRICAL_ACCESSORY"] == 12.0
        assert circuit.labour_demands()[0].trade is Trade.ELECTRICIAN
        assert circuit.measured_area == 0.0

    def test_circuit_without_accessories(self):
        circuit = ElectricalCircuit(
            id="E",
            name="E",
            cable_length_m=50.0,
            dimensions=Dimensions(length=1, width=0.1, height=0.1),
        )
        assert len(circuit.material_demands()) == 1

    def test_plumbing_run(self):
        run = PlumbingRun(
            id="P",
            name="P",
            pipe_length_m=60.0,
            fixture_count=3,
            dimensions=Dimensions(length=1, width=0.1, height=0.1),
        )
        demands = {d.material_id: d.quantity for d in run.material_demands()}
        assert demands["SANITARYWARE"] == 3.0
        assert run.labour_demands()[0].trade is Trade.PLUMBER

    @pytest.mark.parametrize(
        "finish_type,unit,trade",
        [
            (InternalFinishType.PLASTERBOARD, Unit.SQUARE_METRE, Trade.PLASTERER),
            (InternalFinishType.SKIM, Unit.SQUARE_METRE, Trade.PLASTERER),
            (InternalFinishType.DECORATION, Unit.LITRE, Trade.DECORATOR),
            (InternalFinishType.SCREED, Unit.CUBIC_METRE, Trade.CONCRETER),
            (InternalFinishType.FLOOR_FINISH, Unit.SQUARE_METRE, Trade.FLOOR_LAYER),
        ],
    )
    def test_internal_finishes(self, finish_type, unit, trade):
        finish = InternalFinish(
            id="F",
            name="F",
            finish_type=finish_type,
            area_m2=100.0,
            thickness_mm=65.0,
            dimensions=Dimensions(length=10, width=10, height=0.1),
        )
        assert finish.material_demands()[0].unit is unit
        assert finish.labour_demands()[0].trade is trade

    def test_paint_coverage(self):
        finish = InternalFinish(
            id="F",
            name="F",
            finish_type=InternalFinishType.DECORATION,
            area_m2=120.0,
            dimensions=Dimensions(length=10, width=10, height=0.1),
        )
        assert finish.material_demands()[0].quantity == pytest.approx(20.0, rel=1e-3)

    def test_screed_volume(self):
        finish = InternalFinish(
            id="F",
            name="F",
            finish_type=InternalFinishType.SCREED,
            area_m2=100.0,
            thickness_mm=65.0,
            dimensions=Dimensions(length=10, width=10, height=0.1),
        )
        assert finish.net_volume == pytest.approx(6.5)

    def test_finish_stage_defaults(self):
        decoration = InternalFinish(
            id="F",
            name="F",
            finish_type=InternalFinishType.DECORATION,
            area_m2=10.0,
            dimensions=Dimensions(length=1, width=1, height=0.1),
        )
        assert decoration.stage is ConstructionStage.DECORATION

    def test_explicit_stage_is_respected(self):
        finish = InternalFinish(
            id="F",
            name="F",
            finish_type=InternalFinishType.DECORATION,
            stage=ConstructionStage.COMPLETION,
            area_m2=10.0,
            dimensions=Dimensions(length=1, width=1, height=0.1),
        )
        assert finish.stage is ConstructionStage.COMPLETION

    @pytest.mark.parametrize(
        "finish_type,material",
        [
            (ExternalFinishType.RENDER, "RENDER_SILICONE"),
            (ExternalFinishType.PAVING, "PAVING_BLOCK"),
            (ExternalFinishType.LANDSCAPING, "TOPSOIL"),
        ],
    )
    def test_external_finishes(self, finish_type, material):
        finish = ExternalFinish(
            id="E",
            name="E",
            finish_type=finish_type,
            area_m2=50.0,
            dimensions=Dimensions(length=10, width=5, height=0.15),
        )
        assert finish.material_id == material
        assert finish.labour_demands()[0].hours > 0

    def test_landscaping_volume(self):
        finish = ExternalFinish(
            id="E",
            name="E",
            finish_type=ExternalFinishType.LANDSCAPING,
            area_m2=100.0,
            depth_mm=150.0,
            dimensions=Dimensions(length=10, width=10, height=0.15),
        )
        assert finish.net_volume == pytest.approx(15.0)


class TestComponentBase:
    def test_status_transitions_follow_the_permitted_path(self, wall):
        assert wall.can_transition_to(InstallationStatus.SCHEDULED)
        wall.transition_to(InstallationStatus.SCHEDULED)
        assert wall.status is InstallationStatus.SCHEDULED

    def test_illegal_transition_rejected(self, wall):
        with pytest.raises(ComponentError, match="Illegal status transition"):
            wall.transition_to(InstallationStatus.COMPLETE)

    def test_force_bypasses_the_state_machine(self, wall):
        wall.transition_to(InstallationStatus.COMPLETE, force=True)
        assert wall.is_complete

    def test_self_transition_is_a_noop(self, wall):
        assert wall.transition_to(InstallationStatus.NOT_STARTED) is InstallationStatus.NOT_STARTED

    def test_terminal_status_blocks_further_moves(self, wall):
        wall.transition_to(InstallationStatus.COMPLETE, force=True)
        assert not wall.can_transition_to(InstallationStatus.IN_PROGRESS)

    def test_dependencies(self, wall):
        wall.add_dependency("FDN-1")
        wall.add_dependency("FDN-1")
        assert wall.depends_on == ("FDN-1",)
        assert wall.remove_dependency("FDN-1")
        assert not wall.remove_dependency("FDN-1")

    def test_self_dependency_rejected(self, wall):
        with pytest.raises(ComponentError):
            wall.add_dependency(wall.id)

    def test_mass_from_demands(self, wall, catalogue):
        assert wall.mass(catalogue) > 1000.0

    def test_weight_newtons(self, wall, catalogue):
        assert wall.weight_newtons(catalogue) == pytest.approx(wall.mass(catalogue) * 9.80665)

    def test_mass_falls_back_to_density(self, catalogue):
        beam = Beam(
            id="B",
            name="B",
            material_id="TIMBER_C24",
            dimensions=Dimensions(length=4.0, width=0.1, height=0.3),
        )
        assert beam.mass(catalogue) > 0

    def test_mass_ignores_unknown_materials(self, catalogue):
        foundation = Foundation(
            id="F",
            name="F",
            material_id="NOT_REAL",
            dimensions=Dimensions(length=1, width=1, height=1),
        )
        assert foundation.mass(catalogue) == 0.0

    def test_material_cost(self, wall, catalogue):
        assert wall.material_cost(catalogue) > 0

    def test_progress_fraction_tracks_status(self, wall):
        assert wall.progress_fraction == 0.0
        wall.transition_to(InstallationStatus.COMPLETE, force=True)
        assert wall.progress_fraction == 1.0

    def test_summary_shape(self, wall):
        summary = wall.summary()
        assert summary["id"] == wall.id
        assert summary["kind"] == "wall"
        assert "labour_hours" in summary

    def test_bounding_box_uses_placement(self):
        wall = Wall(
            id="W",
            name="W",
            dimensions=Dimensions(length=4.0, width=0.3, height=2.5),
            placement=Placement(origin=Vec3(x=10.0, y=5.0, z=0.0)),
        )
        assert wall.bounding_box.minimum.x == pytest.approx(10.0)
        assert wall.centroid.z == pytest.approx(1.25)

    def test_primary_trade_none_when_no_labour(self):
        wall = Wall(
            id="W", name="W", dimensions=Dimensions(length=2.0, width=0.3, height=2.0)
        )
        wall.add_opening(Opening(component_id="X", width=2.0, height=2.0))
        assert wall.primary_trade() is None

    def test_extra_fields_rejected(self):
        with pytest.raises(Exception):
            Wall(
                id="W",
                name="W",
                dimensions=Dimensions(length=1, width=1, height=1),
                nonsense=True,
            )


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
class TestRegistry:
    def make(self, count=3):
        return [
            Wall(
                id=f"W-{i}",
                name=f"Wall {i}",
                level=i % 2,
                zone="A" if i % 2 == 0 else "B",
                dimensions=Dimensions(length=4.0, width=0.3, height=2.5),
            )
            for i in range(count)
        ]

    def test_add_and_get(self, registry):
        walls = self.make(1)
        registry.add(walls[0])
        assert registry.get("W-0") is walls[0]
        assert "W-0" in registry
        assert len(registry) == 1

    def test_duplicate_rejected(self, registry):
        walls = self.make(1)
        registry.add(walls[0])
        with pytest.raises(DuplicateComponentError):
            registry.add(walls[0])

    def test_missing_raises(self, registry):
        with pytest.raises(ComponentNotFoundError):
            registry.get("nope")
        assert registry.find("nope") is None

    def test_remove(self, registry):
        registry.add_all(self.make(2))
        registry.remove("W-0")
        assert "W-0" not in registry
        assert registry.by_kind(ComponentKind.WALL) and len(registry) == 1

    def test_replace(self, registry):
        registry.add_all(self.make(1))
        replacement = Wall(
            id="W-0", name="New", dimensions=Dimensions(length=1, width=1, height=1)
        )
        registry.replace(replacement)
        assert registry.get("W-0").name == "New"

    def test_replace_unknown_raises(self, registry):
        with pytest.raises(ComponentNotFoundError):
            registry.replace(self.make(1)[0])

    def test_indexed_queries(self, registry):
        registry.add_all(self.make(4))
        assert len(registry.by_kind(ComponentKind.WALL)) == 4
        assert len(registry.by_stage(ConstructionStage.EXTERNAL_WALLS)) == 4
        assert len(registry.by_status(InstallationStatus.NOT_STARTED)) == 4
        assert len(registry.by_level(0)) == 2
        assert len(registry.by_zone("A")) == 2
        assert len(registry.by_type(Wall)) == 4

    def test_where_predicate(self, registry):
        registry.add_all(self.make(4))
        assert len(registry.where(lambda c: c.level == 1)) == 2

    def test_set_status_keeps_index_correct(self, registry):
        registry.add_all(self.make(2))
        registry.set_status("W-0", InstallationStatus.SCHEDULED)
        assert len(registry.by_status(InstallationStatus.SCHEDULED)) == 1
        assert len(registry.by_status(InstallationStatus.NOT_STARTED)) == 1

    def test_set_status_index_survives_rejection(self, registry):
        registry.add_all(self.make(1))
        with pytest.raises(ComponentError):
            registry.set_status("W-0", InstallationStatus.COMPLETE)
        assert len(registry.by_status(InstallationStatus.NOT_STARTED)) == 1

    def test_reindex_recovers_from_direct_mutation(self, registry):
        registry.add_all(self.make(1))
        registry.get("W-0").zone = "MOVED"
        assert registry.by_zone("MOVED") == []
        registry.reindex()
        assert len(registry.by_zone("MOVED")) == 1

    def test_stage_and_zone_listings(self, registry):
        registry.add_all(self.make(3))
        assert ConstructionStage.EXTERNAL_WALLS in registry.stages_present()
        assert set(registry.zones()) == {"A", "B"}
        assert registry.levels() == [0, 1]

    def test_aggregation(self, registry):
        registry.add_all(self.make(3))
        assert len(registry.material_demands()) == 15
        assert registry.total_labour_hours() > 0

    def test_completion_fractions(self, registry):
        registry.add_all(self.make(2))
        assert registry.completion_fraction() == 0.0
        registry.set_status("W-0", InstallationStatus.COMPLETE, force=True)
        assert registry.completion_fraction() == pytest.approx(0.5)
        assert 0.0 < registry.weighted_completion_fraction() <= 1.0

    def test_empty_completion(self, registry):
        assert registry.completion_fraction() == 0.0
        assert registry.weighted_completion_fraction() == 0.0

    def test_statistics(self, registry):
        registry.add_all(self.make(3))
        stats = registry.statistics()
        assert stats["component_count"] == 3
        assert "EXTERNAL_WALLS" in stats["stages"]

    def test_clear(self, registry):
        registry.add_all(self.make(3))
        registry.clear()
        assert len(registry) == 0
        assert registry.by_kind(ComponentKind.WALL) == []

    def test_iteration_and_ids(self, registry):
        registry.add_all(self.make(3))
        assert len(list(registry)) == 3
        assert sorted(registry.ids) == ["W-0", "W-1", "W-2"]


# --------------------------------------------------------------------------- #
# Site
# --------------------------------------------------------------------------- #
class TestSite:
    def test_plot_measures(self, plot):
        assert plot.area == pytest.approx(600.0)
        assert plot.buildable_area is not None
        assert plot.buildable_area.area < plot.area

    def test_no_setback_returns_boundary(self):
        plot = Plot(id="P", name="P", boundary=Footprint.rectangle(10, 10), setback=0.0)
        assert plot.buildable_area.area == pytest.approx(100.0)

    def test_can_accommodate(self, plot):
        assert plot.can_accommodate(Footprint.rectangle(9.0, 7.0, origin=(2.0, 2.0)))
        assert not plot.can_accommodate(Footprint.rectangle(19.9, 29.9))

    def test_assert_accommodates_raises(self, plot):
        with pytest.raises(SiteError, match="setback envelope"):
            plot.assert_accommodates(Footprint.rectangle(19.9, 29.9))

    def test_collapsed_envelope_cannot_accommodate(self):
        plot = Plot(id="P", name="P", boundary=Footprint.rectangle(2, 2), setback=5.0)
        assert plot.buildable_area is None
        assert not plot.can_accommodate(Footprint.rectangle(0.5, 0.5))

    def test_site_statistics(self, site):
        stats = site.statistics()
        assert stats["plot_count"] == 1
        assert stats["site_area_m2"] == pytest.approx(3600.0)
        assert stats["working_area_m2"] == pytest.approx(3000.0)

    def test_duplicate_plot_rejected(self, site, plot):
        with pytest.raises(SiteError, match="Duplicate plot"):
            site.add_plot(plot)

    def test_plot_outside_site_rejected(self, site):
        outside = Plot(
            id="P-X", name="Outside", boundary=Footprint.rectangle(5, 5, origin=(500, 500))
        )
        with pytest.raises(SiteError, match="not contained"):
            site.add_plot(outside)

    def test_containment_check_can_be_skipped(self, site):
        outside = Plot(
            id="P-X", name="Outside", boundary=Footprint.rectangle(5, 5, origin=(500, 500))
        )
        site.add_plot(outside, check_containment=False)
        assert len(site.plots) == 2

    def test_lookup_unknown_plot(self, site):
        with pytest.raises(SiteError):
            site.plot("NOPE")

    def test_overlapping_plots_detected(self):
        site = Site(id="S", name="S", boundary=Footprint.rectangle(100, 100))
        site.add_plot(Plot(id="A", name="A", boundary=Footprint.rectangle(20, 20)))
        site.add_plot(
            Plot(id="B", name="B", boundary=Footprint.rectangle(20, 20, origin=(10, 10)))
        )
        assert site.overlapping_plots() == [("A", "B")]

    def test_duplicate_plot_ids_rejected_at_construction(self):
        with pytest.raises(Exception, match="Duplicate plot"):
            Site(
                id="S",
                name="S",
                boundary=Footprint.rectangle(100, 100),
                plots=(
                    Plot(id="A", name="A", boundary=Footprint.rectangle(5, 5)),
                    Plot(id="A", name="A2", boundary=Footprint.rectangle(5, 5)),
                ),
            )

    def test_access_points(self, site):
        access = AccessPoint(id="GATE-1", position=Vec3(x=0, y=0, z=0))
        site.add_access_point(access)
        assert access.admits(2.5, 12.0, 32.0)
        assert not access.admits(4.0, 12.0, 32.0)
        assert not access.admits(2.5, 12.0, 60.0)
        with pytest.raises(SiteError):
            site.add_access_point(access)

    def test_rectangular_constructor(self):
        site = Site.rectangular("S", "Site", 50.0, 40.0)
        assert site.area == pytest.approx(2000.0)

    def test_ground_conditions_depth(self):
        normal = GroundConditions()
        clay = GroundConditions(shrinkable_clay=True)
        assert normal.recommended_foundation_depth == pytest.approx(0.9)
        assert clay.recommended_foundation_depth == pytest.approx(1.5)

    def test_deep_stratum_governs(self):
        conditions = GroundConditions(competent_stratum_depth=2.2)
        assert conditions.recommended_foundation_depth == pytest.approx(2.2)


# --------------------------------------------------------------------------- #
# Building aggregate
# --------------------------------------------------------------------------- #
class TestBuilding:
    def test_requires_id_and_name(self):
        with pytest.raises(ValueError):
            Building(id="", name="X")

    def test_emits_created_event(self, empty_building, bus):
        from buildcore.core.events import BuildingCreated

        assert len(bus.history_of(BuildingCreated)) == 1

    def test_add_emits_event(self, empty_building, bus, wall):
        from buildcore.core.events import ComponentAdded

        empty_building.add(wall)
        assert len(bus.history_of(ComponentAdded)) == 1
        assert len(empty_building) == 1

    def test_next_id_is_deterministic(self, empty_building):
        assert empty_building.next_id(ComponentKind.WALL) == "BLD_TEST-WALL-0001"
        assert empty_building.next_id("wall") == "BLD_TEST-WALL-0002"

    def test_remove_detaches_dependencies(self, tiny_building):
        tiny_building.remove("EXC-2")
        assert "EXC-2" not in tiny_building
        assert "EXC-2" not in tiny_building.get("FDN-1").depends_on

    def test_link_and_unlink(self, tiny_building):
        assert "FDN-1" in tiny_building.get("SLB-1").depends_on
        assert tiny_building.unlink("FDN-1", "SLB-1")
        assert not tiny_building.unlink("FDN-1", "SLB-1")

    def test_link_missing_predecessor(self, tiny_building):
        with pytest.raises(MissingDependencyError):
            tiny_building.link("GHOST", "SLB-1")

    def test_dangling_dependencies_detected(self, tiny_building):
        tiny_building.get("SLB-1").add_dependency("GHOST")
        assert ("SLB-1", "GHOST") in tiny_building.dangling_dependencies()

    def test_status_change_emits_event(self, tiny_building, bus):
        from buildcore.core.events import ComponentStatusChanged

        tiny_building.set_status("EXC-1", InstallationStatus.SCHEDULED)
        assert len(bus.history_of(ComponentStatusChanged)) == 1

    def test_advance_walks_the_path(self, tiny_building):
        statuses = [tiny_building.advance("EXC-1") for _ in range(7)]
        assert statuses[-1] is InstallationStatus.COMPLETE
        with pytest.raises(ComponentError):
            tiny_building.advance("EXC-1")

    def test_complete_all(self, tiny_building):
        assert tiny_building.complete_all() == 4
        assert tiny_building.complete_all() == 0
        assert tiny_building.registry.completion_fraction() == 1.0

    def test_bounding_box_and_footprint(self, tiny_building):
        assert tiny_building.bounding_box is not None
        assert tiny_building.footprint().area > 0

    def test_empty_building_has_no_box(self, empty_building):
        assert empty_building.bounding_box is None
        assert empty_building.footprint() is None

    def test_gross_internal_area(self, tiny_building):
        assert tiny_building.gross_internal_area == pytest.approx(80.0)

    def test_aggregations(self, tiny_building):
        assert tiny_building.material_demands()
        assert tiny_building.labour_demands()
        assert tiny_building.total_mass() > 0
        assert tiny_building.net_material_cost() > 0

    def test_statistics(self, tiny_building):
        stats = tiny_building.statistics()
        assert stats["building_id"] == "BLD-TINY"
        assert stats["component_count"] == 4
        assert stats["dangling_dependencies"] == 0

    def test_json_round_trip(self, tiny_building):
        restored = Building.from_json(tiny_building.to_json())
        assert len(restored) == len(tiny_building)
        assert restored.net_material_cost() == tiny_building.net_material_cost()
        assert restored.get("SLB-1").depends_on == ("FDN-1",)

    def test_round_trip_preserves_subclasses(self, tiny_building):
        restored = Building.from_dict(tiny_building.to_dict())
        assert isinstance(restored.get("FDN-1"), Foundation)
        assert isinstance(restored.get("SLB-1"), FloorSlab)

    def test_round_trip_with_plot(self, empty_building, wall):
        empty_building.add(wall)
        restored = Building.from_dict(empty_building.to_dict())
        assert restored.plot is not None
        assert restored.plot.id == "PLOT-001"

    def test_rejects_unknown_schema_version(self, tiny_building):
        payload = tiny_building.to_dict()
        payload["schema_version"] = "99.0"
        with pytest.raises(ValueError, match="Unsupported schema"):
            Building.from_dict(payload)

    def test_clone_is_independent(self, tiny_building):
        clone = tiny_building.clone(new_id="BLD-CLONE")
        clone.set_status("EXC-1", InstallationStatus.COMPLETE, force=True)
        assert clone.id == "BLD-CLONE"
        assert tiny_building.get("EXC-1").status is InstallationStatus.NOT_STARTED

    def test_container_protocol(self, tiny_building):
        assert "EXC-1" in tiny_building
        assert len(list(tiny_building)) == 4
        assert len(tiny_building.components) == 4
        assert tiny_building.find("nope") is None
