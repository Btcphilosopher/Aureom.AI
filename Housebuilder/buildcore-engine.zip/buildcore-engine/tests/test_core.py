"""Unit tests for the core infrastructure layer."""

from __future__ import annotations

import asyncio
import io
import json
import logging

import pytest

from buildcore.core.config import EngineSettings, WasteAllowances, WorkingCalendar
from buildcore.core.container import Container, Lifetime
from buildcore.core.events import (
    ComponentAdded,
    DomainEvent,
    EventBus,
    NullEventBus,
)
from buildcore.core.exceptions import (
    BuildCoreError,
    ConfigurationError,
    CyclicDependencyError,
    DependencyResolutionError,
    ValidationError,
)
from buildcore.core.identifiers import IdGenerator, slugify, uuid_id
from buildcore.core.logging import (
    JsonFormatter,
    MetricsCollector,
    configure_logging,
    get_logger,
    timed,
)
from buildcore.core.units import Dimension, Quantity, Unit, convert


# --------------------------------------------------------------------------- #
# Exceptions
# --------------------------------------------------------------------------- #
class TestExceptions:
    def test_carries_context(self):
        error = BuildCoreError("boom", component_id="W-1", stage="WALLS")
        assert error.context["component_id"] == "W-1"
        assert "W-1" in str(error)

    def test_to_dict_is_json_safe(self):
        payload = BuildCoreError("boom", n=3).to_dict()
        assert json.loads(json.dumps(payload))["error"] == "BuildCoreError"

    def test_message_only_has_no_parenthetical(self):
        assert str(BuildCoreError("plain")) == "plain"

    def test_cyclic_error_keeps_cycle(self):
        error = CyclicDependencyError("cycle", cycle=["a", "b", "a"])
        assert error.cycle == ["a", "b", "a"]
        assert error.context["cycle"] == ["a", "b", "a"]

    def test_validation_error_counts_issues(self):
        error = ValidationError("bad", issues=[1, 2, 3])
        assert error.context["issue_count"] == 3


# --------------------------------------------------------------------------- #
# Units
# --------------------------------------------------------------------------- #
class TestUnits:
    def test_dimension_lookup(self):
        assert Unit.CUBIC_METRE.dimension is Dimension.VOLUME
        assert Unit.EACH.dimension is Dimension.COUNT

    @pytest.mark.parametrize(
        "value,source,target,expected",
        [
            (1.0, Unit.METRE, Unit.MILLIMETRE, 1000.0),
            (2500.0, Unit.MILLIMETRE, Unit.METRE, 2.5),
            (1.0, Unit.TONNE, Unit.KILOGRAM, 1000.0),
            (1.0, Unit.CUBIC_METRE, Unit.LITRE, 1000.0),
            (1.0, Unit.DAY, Unit.HOUR, 24.0),
        ],
    )
    def test_convert(self, value, source, target, expected):
        assert convert(value, source, target) == pytest.approx(expected)

    def test_convert_rejects_dimension_mismatch(self):
        with pytest.raises(ValueError, match="Cannot convert"):
            convert(1.0, Unit.METRE, Unit.KILOGRAM)

    def test_addition_normalises_units(self):
        total = Quantity(value=2.0, unit=Unit.METRE) + Quantity(value=500.0, unit=Unit.MILLIMETRE)
        assert total.value == pytest.approx(2.5)
        assert total.unit is Unit.METRE

    def test_subtraction(self):
        result = Quantity(value=5.0, unit=Unit.METRE) - Quantity(value=1.5, unit=Unit.METRE)
        assert result.value == pytest.approx(3.5)

    def test_addition_rejects_dimension_mismatch(self):
        with pytest.raises(ValueError, match="Dimension mismatch"):
            Quantity(value=1.0, unit=Unit.METRE) + Quantity(value=1.0, unit=Unit.KILOGRAM)

    def test_scalar_multiplication_both_sides(self):
        base = Quantity(value=3.0, unit=Unit.SQUARE_METRE)
        assert (base * 2).value == pytest.approx(6.0)
        assert (2 * base).value == pytest.approx(6.0)

    def test_division(self):
        assert (Quantity(value=10.0, unit=Unit.EACH) / 4).value == pytest.approx(2.5)

    def test_division_by_zero(self):
        with pytest.raises(ZeroDivisionError):
            Quantity(value=1.0, unit=Unit.EACH) / 0

    def test_negation(self):
        assert (-Quantity(value=2.0, unit=Unit.METRE)).value == -2.0

    def test_comparisons_normalise(self):
        metre = Quantity(value=1.0, unit=Unit.METRE)
        millimetres = Quantity(value=999.0, unit=Unit.MILLIMETRE)
        assert millimetres < metre
        assert metre > millimetres
        assert metre >= millimetres
        assert millimetres <= metre

    def test_ceil_to_whole(self):
        assert Quantity(value=12.1, unit=Unit.EACH).ceil_to_whole().value == 13.0
        assert Quantity(value=12.0, unit=Unit.EACH).ceil_to_whole().value == 12.0

    def test_rounded(self):
        assert Quantity(value=1.23456, unit=Unit.METRE).rounded(2).value == 1.23

    def test_zero_and_sum(self):
        assert Quantity.zero(Unit.CUBIC_METRE).value == 0.0
        total = Quantity.sum(
            [Quantity(value=1.0, unit=Unit.METRE), Quantity(value=2.0, unit=Unit.METRE)]
        )
        assert total.value == pytest.approx(3.0)

    def test_sum_of_empty_is_zero(self):
        assert Quantity.sum([], Unit.METRE).value == 0.0

    def test_rejects_non_finite(self):
        with pytest.raises(Exception):
            Quantity(value=float("inf"), unit=Unit.METRE)

    def test_is_frozen(self):
        quantity = Quantity(value=1.0, unit=Unit.METRE)
        with pytest.raises(Exception):
            quantity.value = 2.0

    def test_repr_and_str(self):
        quantity = Quantity(value=2.0, unit=Unit.METRE)
        assert "2" in repr(quantity)
        assert "m" in str(quantity)


# --------------------------------------------------------------------------- #
# Identifiers
# --------------------------------------------------------------------------- #
class TestIdentifiers:
    def test_sequential_per_prefix(self):
        generator = IdGenerator()
        assert generator.next("WALL") == "WALL-0001"
        assert generator.next("WALL") == "WALL-0002"
        assert generator.next("ROOF") == "ROOF-0001"

    def test_deterministic_across_instances(self):
        assert IdGenerator().next("WALL") == IdGenerator().next("WALL")

    def test_namespace_prefix(self):
        assert IdGenerator(namespace="BLD-1").next("WALL") == "BLD_1-WALL-0001"

    def test_width(self):
        assert IdGenerator(width=6).next("W") == "W-000001"

    def test_rejects_bad_width(self):
        with pytest.raises(ValueError):
            IdGenerator(width=0)

    def test_issued_count(self):
        generator = IdGenerator()
        generator.next("W")
        generator.next("W")
        assert generator.issued("W") == 2
        assert generator.issued("NOPE") == 0

    def test_issued_does_not_disturb_sequence(self):
        generator = IdGenerator()
        generator.next("W")
        generator.issued("W")
        assert generator.next("W") == "W-0002"

    def test_reset(self):
        generator = IdGenerator()
        generator.next("W")
        generator.reset()
        assert generator.next("W") == "W-0001"

    @pytest.mark.parametrize(
        "text,expected",
        [("wall", "WALL"), ("roof tile", "ROOF_TILE"), ("a--b", "A_B"), ("!!", "ITEM")],
    )
    def test_slugify(self, text, expected):
        assert slugify(text) == expected

    def test_uuid_id_unique_and_prefixed(self):
        first = uuid_id("REQ")
        assert first.startswith("REQ-")
        assert first != uuid_id("REQ")


# --------------------------------------------------------------------------- #
# Events
# --------------------------------------------------------------------------- #
class _Sample(DomainEvent):
    payload: str = "x"


class TestEventBus:
    def test_publish_reaches_subscriber(self):
        bus = EventBus()
        seen = []
        bus.subscribe(_Sample, seen.append)
        report = bus.publish(_Sample(payload="hello"))
        assert len(seen) == 1
        assert report.handlers_invoked == 1
        assert report.ok

    def test_subscription_is_inheritance_aware(self):
        bus = EventBus()
        seen = []
        bus.subscribe(DomainEvent, seen.append)
        bus.publish(_Sample())
        assert len(seen) == 1

    def test_unsubscribe_via_returned_callable(self):
        bus = EventBus()
        seen = []
        cancel = bus.subscribe(_Sample, seen.append)
        cancel()
        bus.publish(_Sample())
        assert seen == []

    def test_unsubscribe_returns_false_when_absent(self):
        bus = EventBus()
        assert bus.unsubscribe(_Sample, lambda e: None) is False

    def test_handler_failure_is_isolated(self):
        bus = EventBus()
        seen = []

        def broken(event):
            raise RuntimeError("nope")

        bus.subscribe(_Sample, broken)
        bus.subscribe(_Sample, seen.append)
        report = bus.publish(_Sample())
        assert not report.ok
        assert report.failures[0].error_type == "RuntimeError"
        assert len(seen) == 1

    def test_strict_mode_propagates(self):
        bus = EventBus(strict=True)

        def broken(event):
            raise RuntimeError("nope")

        bus.subscribe(_Sample, broken)
        with pytest.raises(RuntimeError):
            bus.publish(_Sample())

    def test_sync_publish_skips_coroutine_handlers(self):
        bus = EventBus()
        calls = []

        async def handler(event):
            calls.append(event)

        bus.subscribe(_Sample, handler)
        report = bus.publish(_Sample())
        assert report.handlers_invoked == 0
        assert calls == []

    def test_async_publish_runs_both(self):
        bus = EventBus()
        calls = []

        async def async_handler(event):
            calls.append("async")

        bus.subscribe(_Sample, async_handler)
        bus.subscribe(_Sample, lambda e: calls.append("sync"))
        report = asyncio.run(bus.publish_async(_Sample()))
        assert report.handlers_invoked == 2
        assert set(calls) == {"async", "sync"}

    def test_async_failure_captured(self):
        bus = EventBus()

        async def broken(event):
            raise ValueError("bad")

        bus.subscribe(_Sample, broken)
        report = asyncio.run(bus.publish_async(_Sample()))
        assert not report.ok
        assert report.failures[0].error_type == "ValueError"

    def test_history_recording(self):
        bus = EventBus(record_history=True)
        bus.publish(_Sample())
        bus.publish(ComponentAdded(building_id="b", component_id="c", kind="wall", stage="X"))
        assert len(bus.history) == 2
        assert len(bus.history_of(_Sample)) == 1

    def test_history_off_by_default(self):
        bus = EventBus()
        bus.publish(_Sample())
        assert bus.history == ()

    def test_clear_removes_subscriptions(self):
        bus = EventBus(record_history=True)
        bus.subscribe(_Sample, lambda e: None)
        bus.publish(_Sample())
        bus.clear()
        assert bus.subscriber_count() == 0
        assert bus.history == ()

    def test_subscriber_count_by_type(self):
        bus = EventBus()
        bus.subscribe(_Sample, lambda e: None)
        assert bus.subscriber_count(_Sample) == 1
        assert bus.subscriber_count(ComponentAdded) == 0

    def test_rejects_non_event_type(self):
        bus = EventBus()
        with pytest.raises(TypeError):
            bus.subscribe(str, lambda e: None)  # type: ignore[arg-type]

    def test_rejects_non_callable(self):
        bus = EventBus()
        with pytest.raises(TypeError):
            bus.subscribe(_Sample, "not callable")  # type: ignore[arg-type]

    def test_events_are_frozen(self):
        event = _Sample()
        with pytest.raises(Exception):
            event.payload = "y"

    def test_event_name(self):
        assert _Sample().name == "_Sample"

    def test_null_bus_is_inert(self):
        bus = NullEventBus()
        seen = []
        bus.subscribe(_Sample, seen.append)
        assert bus.publish(_Sample()).ok
        assert seen == []
        assert asyncio.run(bus.publish_async(_Sample())).ok


# --------------------------------------------------------------------------- #
# Container
# --------------------------------------------------------------------------- #
class _Leaf:
    def __init__(self) -> None:
        self.value = 1


class _Branch:
    def __init__(self, leaf: _Leaf) -> None:
        self.leaf = leaf


class _Optional:
    def __init__(self, leaf: _Leaf | None = None, count: int = 5) -> None:
        self.leaf = leaf
        self.count = count


class _CycleA:
    def __init__(self, other: _CycleB) -> None:
        self.other = other


class _CycleB:
    def __init__(self, other: _CycleA) -> None:
        self.other = other


class TestContainer:
    def test_register_instance(self):
        leaf = _Leaf()
        container = Container().register_instance(_Leaf, leaf)
        assert container.resolve(_Leaf) is leaf

    def test_singleton_memoised(self):
        container = Container().register_singleton(_Leaf)
        assert container.resolve(_Leaf) is container.resolve(_Leaf)

    def test_transient_is_fresh(self):
        container = Container().register_factory(_Leaf)
        assert container.resolve(_Leaf) is not container.resolve(_Leaf)

    def test_autowires_constructor(self):
        container = Container().register_singleton(_Leaf).register_singleton(_Branch)
        assert isinstance(container.resolve(_Branch).leaf, _Leaf)

    def test_autowires_unregistered_concrete_class(self):
        assert isinstance(Container().resolve(_Leaf), _Leaf)

    def test_optional_dependency_falls_back_to_default(self):
        resolved = Container().resolve(_Optional)
        assert resolved.count == 5

    def test_custom_factory(self):
        container = Container().register_singleton(_Leaf, lambda: _Leaf())
        assert isinstance(container.resolve(_Leaf), _Leaf)

    def test_circular_dependency_detected(self):
        container = Container().register_singleton(_CycleA).register_singleton(_CycleB)
        with pytest.raises(DependencyResolutionError, match="Circular"):
            container.resolve(_CycleA)

    def test_is_registered(self):
        container = Container().register_singleton(_Leaf)
        assert container.is_registered(_Leaf)
        assert not container.is_registered(_Branch)

    def test_scope_inherits_from_parent(self):
        parent = Container().register_singleton(_Leaf)
        child = parent.create_scope()
        assert child.resolve(_Leaf) is parent.resolve(_Leaf)

    def test_rejects_non_type_key(self):
        with pytest.raises(Exception):
            Container().register_instance("nope", 1)  # type: ignore[arg-type]

    def test_rejects_non_callable_factory(self):
        with pytest.raises(Exception):
            Container().register_singleton(_Leaf, "nope")  # type: ignore[arg-type]

    def test_factory_error_is_wrapped(self):
        def boom() -> _Leaf:
            raise RuntimeError("kaboom")

        container = Container().register_singleton(_Leaf, boom)
        with pytest.raises(DependencyResolutionError, match="Failed to construct"):
            container.resolve(_Leaf)

    def test_registrations_snapshot(self):
        container = Container().register_singleton(_Leaf)
        registrations = container.registrations
        assert registrations[_Leaf].lifetime is Lifetime.SINGLETON


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
class TestConfig:
    def test_defaults(self, settings):
        assert settings.currency == "GBP"
        assert settings.calendar.hours_per_day == 8.0

    def test_markup_multiplier(self):
        settings = EngineSettings(overhead_and_profit=0.1, preliminaries=0.1, contingency=0.05)
        assert settings.markup_multiplier == pytest.approx(1.25)

    def test_rejects_excessive_combined_markup(self):
        with pytest.raises(Exception):
            EngineSettings(overhead_and_profit=0.5, preliminaries=0.4, contingency=0.2)

    def test_log_level_normalised(self):
        assert EngineSettings(log_level="debug").log_level == "DEBUG"

    def test_rejects_bad_log_level(self):
        with pytest.raises(Exception):
            EngineSettings(log_level="LOUD")

    def test_currency_uppercased(self):
        assert EngineSettings(currency="gbp").currency == "GBP"

    def test_rejects_numeric_currency(self):
        with pytest.raises(Exception):
            EngineSettings(currency="123")

    def test_with_overrides(self, settings):
        assert settings.with_overrides(currency="EUR").currency == "EUR"

    def test_with_overrides_rejects_invalid(self, settings):
        with pytest.raises(ConfigurationError):
            settings.with_overrides(log_level="NOPE")

    def test_waste_for_class(self):
        waste = WasteAllowances()
        assert waste.for_class("MASONRY") == waste.masonry
        assert waste.for_class("UNKNOWN_THING") == waste.default

    def test_effective_hours(self):
        calendar = WorkingCalendar(hours_per_day=10.0, productivity_factor=0.5)
        assert calendar.effective_hours_per_day == pytest.approx(5.0)
        assert calendar.hours_per_week == pytest.approx(25.0)

    def test_waste_bounds_enforced(self):
        with pytest.raises(Exception):
            WasteAllowances(masonry=0.9)


# --------------------------------------------------------------------------- #
# Logging and metrics
# --------------------------------------------------------------------------- #
class TestLogging:
    def test_json_formatter_emits_object(self):
        record = logging.LogRecord(
            "buildcore.test", logging.INFO, __file__, 1, "hello", None, None
        )
        record.component_id = "W-1"
        payload = json.loads(JsonFormatter(engine_version="9.9").format(record))
        assert payload["message"] == "hello"
        assert payload["component_id"] == "W-1"
        assert payload["version"] == "9.9"

    def test_configure_logging_is_idempotent(self):
        stream = io.StringIO()
        configure_logging(stream=stream)
        root = configure_logging(stream=stream)
        assert len(root.handlers) == 1

    def test_plain_format_option(self):
        stream = io.StringIO()
        configure_logging(stream=stream, json_format=False)
        get_logger("t").info("plain message")
        assert "plain message" in stream.getvalue()

    def test_bound_logger_merges_context(self):
        stream = io.StringIO()
        configure_logging(stream=stream)
        get_logger("t").bind(project="P1").info("hi", extra={"n": 2})
        payload = json.loads(stream.getvalue().strip().splitlines()[-1])
        assert payload["project"] == "P1"
        assert payload["n"] == 2

    def test_bind_is_chainable(self):
        logger = get_logger("t").bind(a=1).bind(b=2)
        assert logger.extra == {"a": 1, "b": 2}

    def test_metrics_summary(self):
        collector = MetricsCollector()
        for value in (0.1, 0.2, 0.3):
            collector.record("op", value)
        summary = collector.summary("op")
        assert summary is not None
        assert summary.count == 3
        assert summary.mean == pytest.approx(0.2)
        assert summary.minimum == pytest.approx(0.1)

    def test_metrics_missing_returns_none(self):
        assert MetricsCollector().summary("absent") is None

    def test_metrics_snapshot_and_reset(self):
        collector = MetricsCollector()
        collector.increment("count")
        assert "count" in collector.snapshot()
        collector.reset()
        assert collector.snapshot() == {}

    def test_summary_to_dict_is_milliseconds(self):
        collector = MetricsCollector()
        collector.record("op", 1.0)
        assert collector.summary("op").to_dict()["mean_ms"] == pytest.approx(1000.0)

    def test_timed_records_and_annotates(self):
        stream = io.StringIO()
        configure_logging(stream=stream)
        collector = MetricsCollector()
        with timed("quantify", collector=collector, components=5) as span:
            span["line_items"] = 42
        payload = json.loads(stream.getvalue().strip().splitlines()[-1])
        assert payload["operation"] == "quantify"
        assert payload["line_items"] == 42
        assert payload["components"] == 5
        assert collector.summary("quantify").count == 1

    def test_timed_records_even_on_exception(self):
        collector = MetricsCollector()
        with pytest.raises(RuntimeError), timed("boom", collector=collector):
            raise RuntimeError("x")
        assert collector.summary("boom").count == 1
