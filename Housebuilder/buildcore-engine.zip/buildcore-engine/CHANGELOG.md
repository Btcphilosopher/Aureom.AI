# Changelog

## 0.1.0 — Phase 1

Initial delivery: core infrastructure, Module 1 (Building Object Engine) and
Module 2 (Construction Dependency Graph), plus parametric model generation.

### Added
- **Core** — layered configuration, DI container with constructor autowiring,
  sync/async event bus with handler isolation, JSON structured logging with
  timers and a metrics collector, dimension-checked quantity arithmetic,
  deterministic thread-safe identifiers, full exception hierarchy.
- **Module 1** — 18 self-measuring component types covering substructure,
  superstructure, envelope, services and finishes. Each reports net material
  and labour demands from its own geometry. Indexed component registry,
  building aggregate root with JSON round-tripping, site/plot model with
  setback envelopes and ground conditions, UK residential material catalogue
  (38 materials with lead times, storage classes and pack sizes).
- **Module 2** — NetworkX-backed dependency graph with O(n) stage-gate
  inference, cycle detection and repair, topological ordering, parallel work
  waves, ready-frontier computation, critical-node ranking and an eight-rule
  violation detector.
- **Fabrication** — parametric house generator and multi-plot estate builder.
- 399 tests at 98% statement coverage; benchmark suite; runnable demo.

### Notable design decisions
- Components measure themselves, so Modules 4–6 become aggregation.
- Construction stage order is encoded in `IntEnum` values, making sequence
  violations an integer comparison.
- Stage inference yields to explicit edges and self-repairs cycles, so it can
  never render a valid model unschedulable.
- Waste allowances are applied by the quantification engine, not by
  components, so one model can be re-costed under different assumptions.
