# BuildCore Engine

The computational intelligence layer of an enterprise digital housebuilding
platform. BuildCore models a residential build as a **structured process**
rather than a 3D scene: every component knows its dimensions, material,
construction stage, dependencies, quantities and labour content, and the engine
reasons about order, resources and time on top of that.

```
Kotlin  →  user interface
Rust    →  geometry kernel, storage, high-performance core
Python  →  ← this package: construction intelligence, optimisation, simulation
R       →  cost analytics and executive dashboards
```

---

## Status

This is **Phase 1 of a phased delivery**. What is here is complete, tested and
production-shaped — there are no stubs or placeholder implementations in the
delivered modules.

| Module | Scope | Status |
|---|---|---|
| Core infrastructure | Config, DI, events, structured logging, units, IDs | **Delivered** |
| **1 — Building Object Engine** | 18 component types with real self-measurement | **Delivered** |
| **2 — Construction Dependency Graph** | DAG, stage rules, violation detection | **Delivered** |
| Fabrication | Parametric house and estate generation | **Delivered** |
| 3 — Sequencing Engine | SimPy time simulation | Phase 2 |
| 4 — Material Quantification | Bills of Quantities, waste, procurement units | Phase 2 |
| 5 — Labour Engine | Crews, productivity, allocation over time | Phase 2 |
| 6 — Scheduler | OR-Tools CP-SAT, critical path, Gantt | Phase 3 |
| 7 — Procurement | Lead times, deliveries, inventory | Phase 3 |
| 8 — Site Logistics | Storage, access, crane positioning | Phase 4 |
| 9 — Progress Engine | Live status, snapshots | Phase 4 |
| 10 — Simulation Engine | Scenario comparison, weather | Phase 5 |
| 11 — Validation Engine | Full consistency reporting | Phase 5 |
| 12 — Optimisation Engine | Multi-objective optimisation | Phase 6 |
| REST + gRPC API | FastAPI and protobuf surfaces | Phase 6 |

Phase 1 already contains the substrate every later module depends on: the
component measurement protocol (`material_demands` / `labour_demands`) means
the quantification, labour and scheduling engines are largely aggregation over
what components already report.

**399 tests, 98% statement coverage.**

---

## Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

Requires Python 3.12+. Phase 1 needs only `pydantic`, `pydantic-settings`,
`networkx`, `numpy` and `shapely`; the heavier solver and API dependencies are
optional extras so the core stays light.

---

## Quickstart

```python
from buildcore import (
    StandardHouseBuilder, HouseSpecification, ConstructionDependencyGraph
)

# Generate a complete, dependency-linked 3-bed house
spec = HouseSpecification(length=9.0, width=7.5, storeys=2, roof_pitch=40.0)
house = StandardHouseBuilder(spec).build("BLD-001", "Plot 1 — 3 bed semi")

print(len(house))                     # 64 components
print(house.gross_internal_area)      # 125.46 m²
print(house.total_mass() / 1000)      # 205.4 tonnes
print(house.net_material_cost())      # 55677.99

# Build and interrogate the dependency graph
graph = ConstructionDependencyGraph.from_building(house)
graph.assert_valid()                  # raises if the model is unbuildable

graph.topological_order()[:3]         # a valid construction order
graph.waves()                         # sets of mutually independent work
graph.ready_components()              # what can start right now
graph.critical_nodes(5)               # what unblocks the most downstream work
```

### Simulating the build

```python
from buildcore.domain.enums import InstallationStatus

while (ready := graph.ready_components()):
    for component_id in ready:
        house.set_status(component_id, InstallationStatus.COMPLETE, force=True)
    graph.rebuild()

assert house.registry.completion_fraction() == 1.0
```

### Measuring the model

```python
# Every component measures itself; the registry aggregates
for demand in house.material_demands()[:3]:
    print(demand.material_id, demand.quantity, demand.unit.value)
# BRICK_FACING 456.0 nr
# BLOCK_AAC_100 76.0 nr
# MORTAR_M4 0.2432 m3

hours_by_trade = {}
for demand in house.labour_demands():
    hours_by_trade[demand.trade] = hours_by_trade.get(demand.trade, 0) + demand.hours
```

### Whole developments

```python
from buildcore import build_estate

site, buildings = build_estate(25)          # 1,600 components in ~100 ms
print(site.statistics()["density_plots_per_hectare"])
```

---

## Run the tests and benchmarks

```bash
pytest                              # 399 tests
pytest --cov=buildcore              # coverage report
python benchmarks/benchmark.py      # scaling benchmarks
python examples/demo.py             # end-to-end walkthrough
```

---

## Design notes

**Components measure themselves.** `material_demands()` and `labour_demands()`
live on the component, not in a central estimator. Adding a new component type
makes it immediately available to quantification, labour planning and
scheduling without touching those modules.

**Stage order is encoded in the type system.** `ConstructionStage` is an
`IntEnum` whose values *are* the build sequence, so "roof before foundations"
is detected by integer comparison rather than a lookup table.

**Explicit dependencies beat inferred ones.** The graph inserts synthetic
stage-gate nodes so that a model declaring only stages still sequences
correctly, in `O(n)` edges rather than `O(n²)`. But gates only attach to
components the modeller left unconstrained, and a final sweep removes any
inferred edge that would create a cycle — stage inference can never make a
valid model unschedulable.

**Reproducibility is a requirement, not a nicety.** Identifiers are
deterministic and project-scoped, so running the same scenario twice yields
byte-identical output. Scenario comparison then measures the variable you
changed rather than random identifier churn.

**Commercial assumptions are isolated.** Waste allowances, productivity rates
and coverage constants live in `core/config.py` and `domain/constants.py`, each
with its derivation documented, because estimators need to audit and override
them per project.

See `docs/ARCHITECTURE.md` for the full design, layering rules and module
contracts.

---

## Layout

```
src/buildcore/
├── core/              infrastructure — no domain knowledge
│   ├── config.py      layered settings; all commercial assumptions
│   ├── container.py   dependency injection with constructor autowiring
│   ├── events.py      sync + async event bus with handler isolation
│   ├── exceptions.py  exception tree rooted at BuildCoreError
│   ├── identifiers.py deterministic, thread-safe ID generation
│   ├── logging.py     JSON logging, timers, metrics collector
│   └── units.py       dimension-checked quantity arithmetic
├── domain/            the model — depends only on core
│   ├── building.py    aggregate root, events, JSON round-tripping
│   ├── components.py  Module 1: 18 self-measuring component types
│   ├── constants.py   coverage rates and labour productivity, sourced
│   ├── enums.py       stages, trades, statuses, status state machine
│   ├── geometry.py    vectors, boxes, placements, Shapely footprints
│   ├── materials.py   material specs + UK residential catalogue
│   ├── registry.py    indexed component store with query API
│   └── site.py        sites, plots, access, ground conditions
├── graph/             Module 2 — depends on domain
│   ├── dependency_graph.py
│   └── rules.py       ordering rules and violation detection
└── fabrication/       parametric model generation
    └── house_builder.py
```

Dependencies point strictly inward: `fabrication → graph → domain → core`.
