# BuildCore Engine — Architecture

## 1. Position in the platform

BuildCore is the Python tier of a four-language platform. It owns *construction
reasoning*: what must be built, in what order, from what materials, by whom, and
how long that takes. It deliberately owns neither geometry kernels nor
rendering nor persistence.

```
┌──────────────────────────────────────────────────────────┐
│  Kotlin — user interface                                 │
└──────────────────────┬───────────────────────────────────┘
                       │ REST / gRPC
┌──────────────────────▼───────────────────────────────────┐
│  Rust — geometry kernel, project storage, API gateway    │
└──────────┬───────────────────────────────┬───────────────┘
           │ REST / gRPC                   │
┌──────────▼─────────────────────┐  ┌──────▼───────────────┐
│  Python — BuildCore Engine     │  │  R — cost analytics  │
│  construction intelligence     │  │  and dashboards      │
└────────────────────────────────┘  └──────────────────────┘
```

The contract with Rust is plain JSON: `Building.to_dict()` /
`Building.from_dict()` round-trip the entire model, including polymorphic
component types, with no bespoke encoder.

---

## 2. Layering

Dependencies point strictly inward. A module may import from layers to its
left, never to its right.

```
core  ←  domain  ←  graph  ←  fabrication  ←  (Phase 2+ engines)
```

| Layer | Knows about | Must not know about |
|---|---|---|
| `core` | Nothing domain-specific | Walls, stages, materials |
| `domain` | Components, materials, sites | Graphs, schedules, solvers |
| `graph` | The domain model | Solvers, simulation, APIs |
| `fabrication` | Domain + graph | Solvers, APIs |

This is enforced by convention and reviewed at import time; `core` contains no
construction vocabulary whatsoever, which is what makes it reusable and makes
the domain testable without infrastructure.

---

## 3. Class model (Phase 1)

```
                          ┌────────────────┐
                          │     Site       │
                          │  boundary      │
                          │  access points │
                          └───────┬────────┘
                                  │ 1..*
                          ┌───────▼────────┐
                          │      Plot      │
                          │  boundary      │
                          │  setback       │
                          │  ground cond.  │
                          └───────┬────────┘
                                  │ 0..1
                          ┌───────▼────────────────────┐
                          │        Building            │  aggregate root
                          │  id, name, catalogue       │
                          │  IdGenerator, EventBus     │
                          └───────┬────────────────────┘
                                  │ owns
                          ┌───────▼────────────────────┐
                          │    ComponentRegistry       │
                          │  indexes: kind, stage,     │
                          │  status, level, zone       │
                          └───────┬────────────────────┘
                                  │ 0..*
                          ┌───────▼────────────────────┐
                          │     BuildingComponent      │  abstract
                          │  dimensions, placement     │
                          │  stage, status, depends_on │
                          │  material_demands()        │
                          │  labour_demands()          │
                          └───────┬────────────────────┘
                                  │
   ┌──────────┬──────────┬────────┼────────┬──────────┬──────────┐
   ▼          ▼          ▼        ▼        ▼          ▼          ▼
Excavation Foundation FloorSlab  Wall    Joist   RoofStructure  Window
DrainageRun  Beam     Column    Floor  RoofCovering  Door   InsulationLayer
ElectricalCircuit  PlumbingRun  InternalFinish  ExternalFinish
```

`Wall` additionally owns `Opening` records so masonry is measured net of
windows and doors, and `Window`/`Door` cross-reference their host wall.

---

## 4. The measurement protocol

This is the single most important design decision in the package.

```python
class BuildingComponent(BaseModel):
    def material_demands(self) -> list[MaterialDemand]: ...
    def labour_demands(self) -> list[LabourDemand]: ...
```

Each component computes its own **net** take-off from its own geometry and
specification. A cavity wall knows it needs 60 bricks and 10 blocks per net m²,
plus mortar, ties and cavity insulation. A trussed roof knows its truss count
follows from span and spacing, and that tiles are measured on the slope, not on
plan.

Consequences:

* **Modules 4 and 5 become aggregation.** The Bill of Quantities is a grouped
  sum over `registry.material_demands()` with waste applied; the labour plan is
  a grouped sum over `registry.labour_demands()` divided by crew size.
* **Module 6 gets its durations for free.** Task duration is
  `labour_hours / (crew_size × effective_hours_per_day)`.
* **New component types are self-integrating.** Define the class, implement the
  two methods, and quantification, labour, costing and scheduling all pick it
  up without modification.

Waste is deliberately *not* applied here. Components report measured net
quantities — a physical fact. Waste allowances are a commercial assumption held
in `WasteAllowances` and applied by the quantification engine, so the same
model can be re-costed under different allowances without remeasuring.

---

## 5. The dependency graph

### Two sources of edges

**Explicit** edges come from `component.depends_on`. These are authoritative.

**Inferred** edges come from stage-gate synthesis. Without them, a model that
declares only stages could not be sequenced; with them done naively — every
wall depending on every foundation — the edge count is `O(n²)`. BuildCore
inserts one synthetic gate node per present stage:

```
      gate(FOUNDATIONS) ──────► gate(FLOOR_SLAB) ──────► gate(EXTERNAL_WALLS)
        │        │                    │                        │
        ▼        ▼                    ▼                        ▼
      FDN-1    FDN-2                SLB-1                  WALL-1 … WALL-8
```

Edge count is linear in components.

### Why inference must yield to explicit edges

Consider a two-storey house. Level-0 and level-1 external walls share the
`EXTERNAL_WALLS` stage, but level-1 walls explicitly depend on the upper floor
joists, which belong to the *later* `UPPER_FLOORS` stage. Attaching every
component to both the entry and the exit of its own stage would close the loop:

```
wall(L1) ──► gate(UPPER_FLOORS) ──► joists ──► wall(L1)     ✗ cycle
```

Two mechanisms prevent this:

1. **Gates attach only to unconstrained components.** A component that already
   declares predecessors gets no gate-entry edge; one that already has
   successors gets no gate-exit edge.
2. **A repair sweep removes any inferred edge still participating in a cycle.**
   Explicit edges are never removed, so a genuinely circular model is still
   reported as a fault by `validate()` rather than silently patched.

The net guarantee: *stage inference can never make a valid explicit model
unschedulable, and can never hide a modelling error.*

### Violation detection

| Rule | Severity | Meaning |
|---|---|---|
| `cycle` | ERROR | Graph cannot be sequenced |
| `self_dependency` | ERROR | Component depends on itself |
| `stage_inversion` | ERROR | Predecessor is built later in the sequence |
| `storey_sequence` | INFO | Inversion explained by an increasing level |
| `parallel_stage_inversion` | INFO | Stages that legitimately interleave |
| `missing_prerequisite_stage` | WARNING | e.g. roof tiles with no roof structure |
| `isolated_component` | WARNING | No dependency relationships at all |
| `fragmented_model` | WARNING | Model splits into disconnected groups |

The storey exception matters: without it, every two-storey model reports
spurious errors. The engine reports rather than dictates, because real projects
legitimately break textbook sequence (phased handover, refurbishment).

---

## 6. Sequencing

`ready_components()` is the frontier the simulation engine consumes each tick.
It is computed with a single dynamic program over the topological order:

```
satisfied[gate]      = all predecessors satisfied
satisfied[component] = all predecessors satisfied AND component is complete
ready                = components not yet started whose predecessors are all satisfied
```

This is `O(V + E)` per tick. The naive alternative — asking for each component's
ancestor set — is `O(V·(V+E))`, which at 6,400 components is the difference
between a simulation that runs and one that does not.

Resolving through gates matters for correctness, not just speed: a second-fix
door with no explicitly declared predecessors must still be held back until the
stages it depends on have finished.

---

## 7. Event flow

```
Building.add(component)
        │
        ├──► ComponentRegistry.add()   maintains 5 secondary indexes
        │
        └──► EventBus.publish(ComponentAdded)
                    │
                    ├──► progress tracker      (Phase 4)
                    ├──► graph cache invalidator
                    ├──► audit log
                    └──► telemetry
```

The bus supports synchronous and coroutine handlers, routes by event class with
inheritance awareness, and **isolates handler failures** into an
`EventDispatchReport` — one misbehaving subscriber must not abort a simulation.
`NullEventBus` is the default collaborator so domain objects never need a
`if bus is not None` guard.

---

## 8. Sequence: generating and sequencing a house

```
Caller          StandardHouseBuilder      Building       Registry      Graph
  │                     │                    │              │            │
  ├──build()───────────►│                    │              │            │
  │                     ├──Building()───────►│              │            │
  │                     │                    ├─publish(BuildingCreated)  │
  │                     ├──_build_substructure()            │            │
  │                     │      └──add(Excavation)──────────►│            │
  │                     ├──_build_slab() … _build_roof()    │            │
  │                     ├──_build_finishes()                │            │
  │                     ├──_link()                          │            │
  │                     │      └──link(pred, succ)──────────►│           │
  │◄────Building────────┤                    │              │            │
  │                                                                      │
  ├──ConstructionDependencyGraph.from_building()───────────────────────►│
  │                                                          rebuild()   │
  │                                              ┌───────────────────────┤
  │                                              │ 1. explicit edges     │
  │                                              │ 2. stage gates        │
  │                                              │ 3. cycle repair sweep │
  │                                              └───────────────────────┤
  ├──validate()────────────────────────────────────────────────────────►│
  ├──ready_components()────────────────────────────────────────────────►│
  │◄──['BLD_001-EXCAVATION-0001']───────────────────────────────────────┤
```

---

## 9. Performance

Measured on the bundled benchmark, generating identical houses across an estate:

| Operation | 6,400 components | Per component |
|---|---|---|
| Model generation | 401 ms | 62.7 µs |
| Graph construction | 165 ms | 25.7 µs |
| Topological sequencing | 178 ms | 27.8 µs |
| Material + labour take-off | 41 ms | 6.4 µs |
| Validation | 34 ms | 5.3 µs |

Per-component cost varies by only **1.19×** between a 64-component model and a
6,400-component model, confirming linear scaling.

Design choices behind this:

* **Maintained secondary indexes** on the registry (kind, stage, status, level,
  zone) turn repeated filtering from `O(n)` scans into `O(1)` lookups.
* **Stage gates** keep edge count linear rather than quadratic.
* **Single-pass DP** for the ready frontier and the longest chain.
* **Grouped components** — a `Joist` can represent an identical run via
  `count`, keeping large developments tractable without losing accuracy.

---

## 10. Reproducibility

Scenario comparison (Module 10) is only meaningful if two runs of the same
model produce identical output. `IdGenerator` is therefore deterministic,
thread-safe and scoped to a building, producing identifiers like
`BLD_001-WALL-0007`. `uuid4` appears only in correlation IDs, never in domain
data.

---

## 11. Extension points

| To add | Do this |
|---|---|
| A component type | Subclass `BuildingComponent`, implement the two demand methods, add to `COMPONENT_TYPES` and `AnyComponent` |
| A material | Append to the catalogue, or supply your own `MaterialCatalogue` |
| A cost feed | Build a `MaterialCatalogue` from live rates; `with_price_adjustment` handles inflation scenarios |
| An ordering rule | Extend `RuleSet`; findings flow into `validate()` automatically |
| A building typology | Write a builder alongside `StandardHouseBuilder` |
| A cross-cutting concern | Subscribe to the event bus rather than editing the domain |

---

## 12. Deployment

Phase 1 is a library with no runtime services. It requires Python 3.12+ and
five light dependencies. Solver, simulation, analytics and API dependencies are
declared as optional extras so that a consumer embedding only the object model
and graph does not pull in OR-Tools.

```bash
pip install buildcore-engine                 # core only
pip install "buildcore-engine[solver,api]"   # Phase 3+ engines
```

For the eventual API tier (Phase 6), the intended shape is a FastAPI process
behind the Rust gateway, with the engine held stateless and project state
loaded per request from the Rust storage layer via the JSON contract in §1.
