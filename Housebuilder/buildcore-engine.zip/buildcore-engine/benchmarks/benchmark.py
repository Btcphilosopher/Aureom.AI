"""Performance benchmarks.

Run with ``python benchmarks/benchmark.py`` or ``pytest benchmarks -m benchmark``.

The benchmarks answer the questions the performance requirement actually cares
about: how does model generation, graph construction, sequencing and
quantification scale with component count, and where does the time go?
"""

from __future__ import annotations

import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from buildcore.domain.enums import InstallationStatus
from buildcore.fabrication.house_builder import (
    HouseSpecification,
    StandardHouseBuilder,
    build_estate,
)
from buildcore.graph.dependency_graph import ConstructionDependencyGraph


@dataclass
class Result:
    name: str
    components: int
    seconds: float

    @property
    def per_component_us(self) -> float:
        return (self.seconds / self.components) * 1e6 if self.components else 0.0

    def render(self) -> str:
        return (
            f"{self.name:<34} {self.components:>7,}  "
            f"{self.seconds * 1000:>9.1f} ms  {self.per_component_us:>8.1f} µs/comp"
        )


def _time(function, repeats: int = 3) -> float:
    """Best-of-N wall clock, which is the stable estimator for short runs."""
    timings = []
    for _ in range(repeats):
        started = time.perf_counter()
        function()
        timings.append(time.perf_counter() - started)
    return min(timings)


def bench_model_generation(plot_counts: list[int]) -> list[Result]:
    results = []
    for count in plot_counts:
        holder: dict[str, int] = {}

        def run(count: int = count, holder: dict = holder) -> None:
            _, buildings = build_estate(count)
            holder["n"] = sum(len(b) for b in buildings)

        seconds = _time(run)
        results.append(Result(f"generate estate ({count} plots)", holder["n"], seconds))
    return results


def bench_graph_construction(plot_counts: list[int]) -> list[Result]:
    results = []
    for count in plot_counts:
        _, buildings = build_estate(count)
        total = sum(len(b) for b in buildings)

        def run(buildings: list = buildings) -> None:
            for building in buildings:
                ConstructionDependencyGraph.from_building(building)

        results.append(Result(f"build graphs ({count} plots)", total, _time(run)))
    return results


def bench_topological_sort(plot_counts: list[int]) -> list[Result]:
    results = []
    for count in plot_counts:
        _, buildings = build_estate(count)
        graphs = [ConstructionDependencyGraph.from_building(b) for b in buildings]
        total = sum(len(b) for b in buildings)

        def run(graphs: list = graphs) -> None:
            for graph in graphs:
                graph.rebuild()
                graph.topological_order()

        results.append(Result(f"topological sort ({count} plots)", total, _time(run)))
    return results


def bench_quantification(plot_counts: list[int]) -> list[Result]:
    results = []
    for count in plot_counts:
        _, buildings = build_estate(count)
        total = sum(len(b) for b in buildings)

        def run(buildings: list = buildings) -> None:
            for building in buildings:
                building.material_demands()
                building.labour_demands()

        results.append(Result(f"quantify ({count} plots)", total, _time(run)))
    return results


def bench_validation(plot_counts: list[int]) -> list[Result]:
    results = []
    for count in plot_counts:
        _, buildings = build_estate(count)
        graphs = [ConstructionDependencyGraph.from_building(b) for b in buildings]
        total = sum(len(b) for b in buildings)

        def run(graphs: list = graphs) -> None:
            for graph in graphs:
                graph.validate()

        results.append(Result(f"validate ({count} plots)", total, _time(run)))
    return results


def bench_full_sequence_simulation() -> list[Result]:
    """Drive one house from empty plot to completion via the ready frontier."""
    building = StandardHouseBuilder(HouseSpecification()).build("BENCH", "Benchmark house")
    graph = ConstructionDependencyGraph.from_building(building)

    started = time.perf_counter()
    ticks = 0
    while True:
        ready = graph.ready_components()
        if not ready:
            break
        for component_id in ready:
            building.set_status(component_id, InstallationStatus.COMPLETE, force=True)
        graph.rebuild()
        ticks += 1
    seconds = time.perf_counter() - started

    print(f"  full build simulation converged in {ticks} waves")
    return [Result("sequence one house to completion", len(building), seconds)]


def bench_serialisation() -> list[Result]:
    from buildcore.domain.building import Building

    _, buildings = build_estate(10)
    total = sum(len(b) for b in buildings)
    payloads = [b.to_json() for b in buildings]

    write = _time(lambda: [b.to_json() for b in buildings])
    read = _time(lambda: [Building.from_json(p) for p in payloads])

    size_kb = sum(len(p) for p in payloads) / 1024
    print(f"  serialised payload: {size_kb:,.0f} KB for {total:,} components")
    return [
        Result("serialise to JSON (10 plots)", total, write),
        Result("deserialise from JSON (10 plots)", total, read),
    ]


def main() -> int:
    plot_counts = [1, 5, 25, 100]

    print("=" * 78)
    print("BuildCore Engine — performance benchmarks")
    print("=" * 78)

    sections: list[tuple[str, list[Result]]] = [
        ("Model generation", bench_model_generation(plot_counts)),
        ("Dependency graph construction", bench_graph_construction(plot_counts)),
        ("Topological sequencing", bench_topological_sort(plot_counts)),
        ("Material and labour take-off", bench_quantification(plot_counts)),
        ("Model validation", bench_validation(plot_counts)),
        ("Serialisation", bench_serialisation()),
        ("Sequencing simulation", bench_full_sequence_simulation()),
    ]

    for title, results in sections:
        print(f"\n{title}")
        print("-" * 78)
        for result in results:
            print("  " + result.render())

    # Scaling check: per-component cost should stay roughly flat.
    graph_results = sections[1][1]
    per_component = [r.per_component_us for r in graph_results]
    spread = max(per_component) / min(per_component) if min(per_component) > 0 else 0.0
    print("\nScaling")
    print("-" * 78)
    print(f"  graph construction per-component spread across 1→100 plots: {spread:.2f}×")
    print(f"  median per-component cost: {statistics.median(per_component):.1f} µs")
    print(
        "  (a spread near 1.0 indicates linear scaling; "
        "large values indicate super-linear behaviour)"
    )
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
