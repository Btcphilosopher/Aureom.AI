"""End-to-end demonstration of the BuildCore Engine.

Run with ``python examples/demo.py``.

Walks an empty plot through model generation, validation, quantification,
labour planning and a full construction sequence simulation.
"""

from __future__ import annotations

import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from buildcore.core.config import EngineSettings
from buildcore.core.events import ComponentAdded, DependencyAdded, EventBus
from buildcore.domain.constants import CREW_SIZE
from buildcore.domain.enums import ConstructionStage, InstallationStatus
from buildcore.domain.geometry import Footprint
from buildcore.domain.materials import standard_catalogue
from buildcore.domain.site import GroundConditions, Plot, Site
from buildcore.fabrication.house_builder import (
    HouseSpecification,
    StandardHouseBuilder,
)
from buildcore.graph.dependency_graph import ConstructionDependencyGraph
from buildcore.graph.rules import Severity


def rule(title: str) -> None:
    print(f"\n{'─' * 74}\n  {title}\n{'─' * 74}")


def main() -> int:
    settings = EngineSettings()
    catalogue = standard_catalogue()
    bus = EventBus(record_history=True)

    # ---------------------------------------------------------------- site --
    rule("1. Site and plot")

    site = Site(
        id="SITE-001",
        name="Meadowbrook Phase 2",
        boundary=Footprint.rectangle(60.0, 45.0),
        ground_conditions=GroundConditions(shrinkable_clay=True, bearing_capacity_kpa=120.0),
    )
    plot = Plot(
        id="PLOT-014",
        name="Plot 14",
        boundary=Footprint.rectangle(16.0, 26.0, origin=(8.0, 8.0)),
        setback=1.5,
        ground_conditions=site.ground_conditions,
    )
    site.add_plot(plot)

    for key, value in site.statistics().items():
        print(f"  {key:<32} {value}")
    print(f"  {'recommended foundation depth':<32} "
          f"{plot.ground_conditions.recommended_foundation_depth} m (shrinkable clay)")

    # ----------------------------------------------------------- generation --
    rule("2. Generate the building model")

    spec = HouseSpecification(
        length=9.0,
        width=7.5,
        storeys=2,
        roof_pitch=40.0,
        foundation_depth=plot.ground_conditions.recommended_foundation_depth,
        bathrooms=2,
        electrical_circuits=8,
    )
    house = StandardHouseBuilder(spec, catalogue=catalogue).build(
        "BLD-014", "Plot 14 — 4 bed detached", plot=plot, site=site, event_bus=bus
    )
    plot.building_id = house.id

    footprint = house.footprint()
    if footprint is not None:
        fits = plot.can_accommodate(footprint)
        print(f"  building footprint            {footprint.area:.1f} m²  "
              f"(fits within setback: {fits})")

    print(f"  components generated          {len(house)}")
    print(f"  gross internal area           {house.gross_internal_area:.1f} m²")
    print(f"  installed mass                {house.total_mass() / 1000:.1f} tonnes")
    print(f"  events emitted                {len(bus.history_of(ComponentAdded))} added, "
          f"{len(bus.history_of(DependencyAdded))} links")

    # ------------------------------------------------------------- validate --
    rule("3. Dependency graph and validation")

    graph = ConstructionDependencyGraph.from_building(house)
    stats = graph.statistics()
    print(f"  nodes                         {stats['nodes']} "
          f"({stats['component_nodes']} components + {stats['stage_gates']} stage gates)")
    print(f"  edges                         {stats['edges']}")
    print(f"  acyclic                       {stats['is_acyclic']}")
    print(f"  parallel work waves           {stats['waves']}")

    findings = graph.validate()
    by_severity: dict[str, int] = defaultdict(int)
    for finding in findings:
        by_severity[finding.severity.value] += 1
    print(f"  validation findings           {dict(by_severity) or 'none'}")

    errors = [f for f in findings if f.severity is Severity.ERROR]
    print(f"  blocking errors               {len(errors)}")
    graph.assert_valid()

    print("\n  Most critical components (unblock the most downstream work):")
    for component_id, downstream in graph.critical_nodes(5):
        print(f"    {int(downstream):>3} downstream   {house.get(component_id).name}")

    # -------------------------------------------------------- quantification --
    rule("4. Material take-off (net, before waste)")

    totals: dict[str, tuple[float, str]] = {}
    for demand in house.material_demands():
        quantity, _ = totals.get(demand.material_id, (0.0, demand.unit.value))
        totals[demand.material_id] = (quantity + demand.quantity, demand.unit.value)

    ranked = sorted(
        totals.items(),
        key=lambda item: catalogue.get(item[0]).cost_for(item[1][0]),
        reverse=True,
    )
    print(f"  {'Material':<34}{'Net qty':>12}  {'Unit':<5}{'Cost':>12}")
    net_total = 0.0
    for material_id, (quantity, unit) in ranked[:12]:
        material = catalogue.get(material_id)
        cost = material.cost_for(quantity)
        net_total += cost
        print(f"  {material.name[:33]:<34}{quantity:>12,.1f}  {unit:<5}"
              f"{cost:>12,.0f}")

    full_net = house.net_material_cost()
    print(f"\n  {'net material cost (all lines)':<34}{'':>12}  {'':<5}{full_net:>12,.0f}")
    print(f"  {'× markup (O&P, prelims, cont.)':<34}{settings.markup_multiplier:>12.2f}")
    print(f"  {'indicative material total':<34}{'':>12}  {'':<5}"
          f"{full_net * settings.markup_multiplier:>12,.0f} {settings.currency}")

    # --------------------------------------------------------------- labour --
    rule("5. Labour plan")

    hours_by_trade: dict[str, float] = defaultdict(float)
    for demand in house.labour_demands():
        hours_by_trade[demand.trade] += demand.hours

    total_hours = sum(hours_by_trade.values())
    print(f"  {'Trade':<22}{'Man-hours':>12}{'Crew':>7}{'Crew-days':>12}{'Share':>9}")
    for trade, hours in sorted(hours_by_trade.items(), key=lambda kv: -kv[1]):
        crew = CREW_SIZE[trade]
        crew_days = hours / (crew * settings.calendar.effective_hours_per_day)
        print(f"  {trade.label:<22}{hours:>12,.0f}{crew:>7}{crew_days:>12,.1f}"
              f"{hours / total_hours:>8.1%}")
    print(f"  {'TOTAL':<22}{total_hours:>12,.0f}")

    # ------------------------------------------------------------ sequencing --
    rule("6. Construction sequence simulation")

    print(f"  {'Wave':<6}{'Items':>7}  Stages in this wave")
    wave_number = 0
    cumulative_hours = 0.0
    while True:
        ready = graph.ready_components()
        if not ready:
            break
        wave_number += 1

        stages = sorted({house.get(i).stage for i in ready})
        stage_text = ", ".join(s.label for s in stages)
        if len(stage_text) > 52:
            stage_text = stage_text[:49] + "..."

        for component_id in ready:
            cumulative_hours += house.get(component_id).total_labour_hours()
            house.set_status(component_id, InstallationStatus.COMPLETE, force=True)

        print(f"  {wave_number:<6}{len(ready):>7}  {stage_text}")
        graph.rebuild()

    print(f"\n  waves to completion           {wave_number}")
    print(f"  labour consumed               {cumulative_hours:,.0f} man-hours")
    print(f"  completion                    "
          f"{house.registry.completion_fraction():.0%}")

    # ------------------------------------------------------------ stage view --
    rule("7. Work content by construction stage")

    stage_hours: dict[ConstructionStage, float] = defaultdict(float)
    for component in house:
        stage_hours[component.stage] += component.total_labour_hours()

    peak = max(stage_hours.values())
    for stage in sorted(stage_hours):
        hours = stage_hours[stage]
        bar = "█" * round(28 * hours / peak)
        print(f"  {stage.label:<20}{hours:>9,.0f} hr  {bar}")

    # --------------------------------------------------------- serialisation --
    rule("8. Serialisation round-trip")

    from buildcore.domain.building import Building

    payload = house.to_json()
    restored = Building.from_json(payload)
    print(f"  JSON payload size             {len(payload) / 1024:.1f} KB")
    print(f"  components restored           {len(restored)}")
    print(f"  quantities preserved          "
          f"{restored.net_material_cost() == house.net_material_cost()}")
    print(f"  types preserved               "
          f"{type(restored.get(house.registry.ids[0])).__name__}")

    print(f"\n{'─' * 74}\n  Demonstration complete.\n{'─' * 74}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
