/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Room-by-Room Build Status Matrix
 */

import React from 'react';
import {
  Bed,
  Building,
  CheckCircle2,
  ChevronRight,
  Eye,
  Hammer,
  Home,
  LayoutGrid,
  Sparkles,
  Utensils,
  Wrench,
  X
} from 'lucide-react';
import { CameraPreset, RoomBuildStatus } from '../types/simulation';

interface RoomProgressGridProps {
  rooms: RoomBuildStatus[];
  currentDay: number;
  onFocusRoom: (roomId: string, cameraPreset?: CameraPreset) => void;
  onClose: () => void;
}

export const RoomProgressGrid: React.FC<RoomProgressGridProps> = ({
  rooms,
  currentDay,
  onFocusRoom,
  onClose
}) => {
  const getRoomIcon = (id: string) => {
    switch (id) {
      case 'ROOM-KITCHEN':
        return <Utensils className="w-4 h-4 text-amber-400" />;
      case 'ROOM-LIVING':
        return <Home className="w-4 h-4 text-indigo-400" />;
      case 'ROOM-MASTER_BED':
      case 'ROOM-BEDROOM_2':
        return <Bed className="w-4 h-4 text-purple-400" />;
      default:
        return <Building className="w-4 h-4 text-slate-400" />;
    }
  };

  const getCameraForRoom = (id: string): CameraPreset => {
    if (id === 'ROOM-KITCHEN') return CameraPreset.INTERIOR_KITCHEN;
    if (id === 'ROOM-LIVING') return CameraPreset.INTERIOR_LIVING;
    return CameraPreset.ORBIT;
  };

  return (
    <div className="absolute top-16 left-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Room-by-Room Build Matrix
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-3 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        <p className="text-slate-400 text-[10px]">
          Trade-by-trade status per living zone. Click camera to focus inside.
        </p>

        {rooms.map((room) => (
          <div
            key={room.id}
            className="bg-black/40 border border-white/10 hover:border-[#ff7b00]/40 rounded-xl p-3 space-y-2.5 transition-all group"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                  {getRoomIcon(room.id)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-xs">{room.name}</h4>
                  <div className="text-[9px] text-slate-400">
                    Floor: {room.floor === 0 ? 'Ground' : 'First'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-xs text-[#ff7b00] drop-shadow-[0_0_8px_rgba(255,123,0,0.4)]">
                  {room.overall}%
                </span>
                <button
                  onClick={() => onFocusRoom(room.id, getCameraForRoom(room.id))}
                  className="p-1.5 rounded bg-white/5 hover:bg-[#ff7b00] hover:text-black text-slate-300 transition-all border border-white/5"
                  title="Fly Camera into Room"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Overall Progress Bar */}
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#ff7b00] to-emerald-400 rounded-full transition-all duration-300"
                style={{ width: `${room.overall}%` }}
              />
            </div>

            {/* Trade breakdown badges */}
            <div className="grid grid-cols-3 gap-1.5 text-[9px] font-mono pt-1">
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Structure</span>
                <span className="text-slate-200 font-bold">{room.structure}%</span>
              </div>
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Electrical</span>
                <span className="text-[#00f2ff] font-bold">{room.electrical}%</span>
              </div>
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Plumbing</span>
                <span className="text-blue-300 font-bold">{room.plumbing}%</span>
              </div>
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Plaster</span>
                <span className="text-slate-200 font-bold">{room.plaster}%</span>
              </div>
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Flooring</span>
                <span className="text-[#ff7b00] font-bold">{room.flooring}%</span>
              </div>
              <div className="bg-white/5 px-2 py-1 rounded border border-white/5 flex justify-between">
                <span className="text-slate-400">Paint</span>
                <span className="text-emerald-300 font-bold">{room.decoration}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
