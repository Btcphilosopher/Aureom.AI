/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - BIM Digital Twin Inspector
 */

import React from 'react';
import {
  Activity,
  AlertCircle,
  Award,
  Box,
  Calendar,
  CheckCircle2,
  Clock,
  Coins,
  Cpu,
  Flame,
  HardHat,
  Info,
  Layers,
  Leaf,
  Maximize2,
  Ruler,
  ShieldCheck,
  Tag,
  Truck,
  Wrench,
  X
} from 'lucide-react';
import { BimComponent, ComponentState } from '../types/simulation';

interface BimInspectorModalProps {
  component: BimComponent | null;
  currentDay: number;
  onClose: () => void;
}

export const BimInspectorModal: React.FC<BimInspectorModalProps> = ({
  component,
  currentDay,
  onClose
}) => {
  if (!component) return null;

  const isComplete = currentDay >= component.endDay;
  const isStarted = currentDay >= component.startDay;
  const progressPercent = Math.min(
    100,
    Math.max(
      0,
      Math.round(
        ((currentDay - component.startDay) /
          Math.max(1, component.endDay - component.startDay)) *
          100
      )
    )
  );

  return (
    <div className="absolute top-16 right-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      {/* Header with ID and Close */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-0.5 rounded font-mono font-bold bg-[#ff7b00]/15 text-[#ff7b00] border border-[#ff7b00]/40 shadow-[0_0_8px_rgba(255,123,0,0.3)]">
            {component.id}
          </span>
          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
            {component.category}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Close Inspector"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto scrollbar-thin">
        {/* Component Title & Material */}
        <div>
          <h3 className="font-bold text-sm text-white tracking-wide leading-tight">
            {component.name}
          </h3>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            {component.material}
          </p>
        </div>

        {/* Live Construction Status */}
        <div className="bg-black/40 border border-white/10 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
              <Activity className="w-3.5 h-3.5 text-[#ff7b00]" />
              Status
            </span>
            <span
              className={`font-mono font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider ${
                isComplete
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : isStarted
                  ? 'bg-[#ff7b00]/20 text-[#ff7b00] border border-[#ff7b00]/40'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {isComplete ? 'SIGNED OFF' : isStarted ? `IN PROGRESS (${progressPercent}%)` : 'NOT STARTED'}
            </span>
          </div>

          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                isComplete ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]' : 'bg-[#ff7b00] shadow-[0_0_8px_rgba(255,123,0,0.5)]'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1">
            <span>Schedule: D{component.startDay} → D{component.endDay}</span>
            <span className="text-[#00f2ff]">Trade: {component.tradeRequired}</span>
          </div>
        </div>

        {/* Dimensions & Engineering Specs */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <Ruler className="w-3.5 h-3.5 text-[#00f2ff]" />
            BIM Physical Properties
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-white/5 p-2 rounded-lg border border-white/5">
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Dimensions (L×W×H)</div>
              <div className="font-mono font-bold text-slate-200 mt-0.5 text-[11px]">
                {component.dimensions.lengthM.toFixed(1)}m × {component.dimensions.widthM.toFixed(1)}m × {component.dimensions.heightM.toFixed(1)}m
              </div>
            </div>
            {component.dimensions.areaM2 && (
              <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                <div className="text-[9px] text-slate-400 uppercase tracking-wider">Surface Area</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5 text-[11px]">
                  {component.dimensions.areaM2.toFixed(1)} m²
                </div>
              </div>
            )}
            {component.dimensions.volumeM3 && (
              <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                <div className="text-[9px] text-slate-400 uppercase tracking-wider">Net Volume</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5 text-[11px]">
                  {component.dimensions.volumeM3.toFixed(1)} m³
                </div>
              </div>
            )}
            {component.uValue && (
              <div className="bg-white/5 p-2 rounded-lg border border-white/5 border-l-2 border-l-[#ff7b00]">
                <div className="text-[9px] text-slate-400 uppercase tracking-wider">Thermal U-Value</div>
                <div className="font-mono font-bold text-[#ff7b00] mt-0.5 text-[11px]">
                  {component.uValue} W/m²K
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Cost & Financial Breakdown */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-[#00f2ff]" />
            Cost Analysis
          </span>
          <div className="bg-black/40 border border-white/10 rounded-xl p-3 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-[11px]">Materials:</span>
              <span className="font-mono font-bold text-slate-200">£{component.costs.materials.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-[11px]">Labour:</span>
              <span className="font-mono font-bold text-slate-200">£{component.costs.labour.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-slate-300">
              <span className="text-[11px]">Plant & Machinery:</span>
              <span className="font-mono font-bold text-slate-200">£{component.costs.plant.toLocaleString()}</span>
            </div>
            <div className="pt-1.5 border-t border-white/10 flex justify-between items-center font-bold text-[#00f2ff]">
              <span className="text-[11px] uppercase tracking-wider">Total Component Cost:</span>
              <span className="font-mono text-sm drop-shadow-[0_0_8px_rgba(0,242,255,0.4)]">£{component.costs.total.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Sustainability & Lifecycle */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <Leaf className="w-3.5 h-3.5 text-emerald-400" />
            Digital Twin Lifecycle Data
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-white/5 p-2 rounded-lg border border-white/5">
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Embodied Carbon</div>
              <div className="font-mono font-bold text-emerald-300 mt-0.5 text-[11px]">
                {component.embodiedCarbonKg.toLocaleString()} kg CO₂e
              </div>
            </div>
            <div className="bg-white/5 p-2 rounded-lg border border-white/5">
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Warranty</div>
              <div className="font-mono font-bold text-slate-200 mt-0.5 text-[11px]">
                {component.warrantyYears} Years
              </div>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 pt-1 font-mono">
            Supplier: <span className="text-slate-200 font-semibold">{component.supplier}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
