/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Multi-House Masterplan & Production Line Engine
 */

import React from 'react';
import {
  Activity,
  ArrowRight,
  BarChart3,
  Building,
  Building2,
  CheckCircle2,
  Clock,
  Coins,
  HardHat,
  Layers,
  MapPin,
  TrendingUp,
  Truck,
  Users,
  X
} from 'lucide-react';
import { MasterplanPlot } from '../types/simulation';

interface MasterplanDashboardProps {
  plots: MasterplanPlot[];
  onSelectPlot: (plotId: number) => void;
  onClose: () => void;
}

export const MasterplanDashboard: React.FC<MasterplanDashboardProps> = ({
  plots,
  onSelectPlot,
  onClose
}) => {
  const completedCount = plots.filter(p => p.progressPercent >= 100).length;
  const inProgressCount = plots.filter(p => p.progressPercent > 0 && p.progressPercent < 100).length;
  const queuedCount = plots.filter(p => p.progressPercent === 0).length;

  return (
    <div className="absolute top-16 left-4 w-[480px] max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Development Masterplan & Production Line
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Production Line Key Analytics */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 border-l-2 border-l-[#ff7b00] text-center">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider">In Construction</div>
            <div className="font-mono font-bold text-base text-[#ff7b00] mt-0.5 drop-shadow-[0_0_8px_rgba(255,123,0,0.3)]">
              {inProgressCount} Plots
            </div>
            <div className="text-[8px] text-slate-400">Active sites</div>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 border-l-2 border-l-emerald-400 text-center">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider">Labour Efficiency</div>
            <div className="font-mono font-bold text-base text-emerald-400 mt-0.5 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
              94.8%
            </div>
            <div className="text-[8px] text-slate-400">Zero trade idle</div>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 border-l-2 border-l-[#00f2ff] text-center">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider">Mean Takt Time</div>
            <div className="font-mono font-bold text-base text-[#00f2ff] mt-0.5 drop-shadow-[0_0_8px_rgba(0,242,255,0.3)]">
              14.2 Days
            </div>
            <div className="text-[8px] text-slate-400">Per stage handoff</div>
          </div>
        </div>

        {/* Staggered Estate Production Line */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between text-[10px]">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#ff7b00]" />
              Continuous Flow Production Line
            </span>
            <span className="text-[9px] text-slate-400 font-mono">8 Staggered Units</span>
          </span>

          <div className="space-y-1.5">
            {plots.map((plot) => (
              <div
                key={plot.id}
                onClick={() => onSelectPlot(plot.id)}
                className="bg-black/30 hover:bg-white/5 border border-white/5 hover:border-[#ff7b00]/50 rounded-xl p-2.5 flex items-center justify-between gap-3 cursor-pointer transition-all group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center font-mono font-bold text-xs text-[#00f2ff] group-hover:border-[#00f2ff]/40">
                    {plot.id}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-xs text-white truncate flex items-center gap-2">
                      <span>{plot.plotNumber}</span>
                      <span className="text-slate-400 text-[10px] font-normal">• {plot.houseType}</span>
                    </div>
                    <div className="text-[9px] text-slate-400 flex items-center gap-2 font-mono">
                      <span>Stage: {plot.stage}</span>
                      <span>•</span>
                      <span>Day {plot.currentDay}/240</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <div className="text-right font-mono">
                    <div className="text-xs font-bold text-[#ff7b00]">{plot.progressPercent}%</div>
                    <div className="text-[9px] text-slate-400">£{plot.budgetSpent.toLocaleString()}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-[#ff7b00] group-hover:translate-x-0.5 transition-all" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
