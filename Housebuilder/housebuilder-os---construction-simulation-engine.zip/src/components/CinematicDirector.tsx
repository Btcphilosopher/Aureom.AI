/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Cinematic Construction Camera & Film Director
 */

import React from 'react';
import {
  Camera,
  Clapperboard,
  Compass,
  Film,
  Maximize2,
  Monitor,
  Moon,
  Move3d,
  Play,
  RotateCcw,
  Sparkles,
  Sun,
  Video,
  X
} from 'lucide-react';
import { CameraPreset, SimulationState, TimeOfDay, WeatherType } from '../types/simulation';

interface CinematicDirectorProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  onSetCameraPreset: (preset: CameraPreset) => void;
  onStartCinematicFilm: (durationSec: number) => void;
  onClose: () => void;
}

export const CinematicDirector: React.FC<CinematicDirectorProps> = ({
  simState,
  onUpdateSimState,
  onSetCameraPreset,
  onStartCinematicFilm,
  onClose
}) => {
  const cameraAngles = [
    { key: CameraPreset.ORBIT, label: '360° Orbit View', desc: 'Free orbit around the building plot' },
    { key: CameraPreset.AERIAL_CRANE, label: 'Tower Crane Jib', desc: 'High overhead construction angle' },
    { key: CameraPreset.SITE_OVERVIEW, label: 'Master Site Panorama', desc: 'Wide plot boundary and road layout' },
    { key: CameraPreset.GROUND_LEVEL, label: 'Groundworker Eye-Level', desc: 'Pedestrian perspective at 1.6m elevation' },
    { key: CameraPreset.INTERIOR_KITCHEN, label: 'Kitchen & Island', desc: 'Interior ground floor living space' },
    { key: CameraPreset.INTERIOR_LIVING, label: 'Living Room Hearth', desc: 'Open-plan ground floor view' },
    { key: CameraPreset.ROOF_LEVEL, label: 'Roof Trusses & Solar', desc: 'Pitch apex and roof structure' },
    { key: CameraPreset.SECTION_CUT, label: 'Orthographic Section', desc: 'Direct elevation architectural cut' }
  ];

  return (
    <div className="absolute top-16 right-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Clapperboard className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Cinematic Camera & Film Director
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Automated Time-Lapse Film Builder */}
        <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
              <Film className="w-4 h-4 text-[#ff7b00]" />
              Build Film Time-Lapse Sequence
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#ff7b00]/20 text-[#ff7b00] border border-[#ff7b00]/40 uppercase tracking-wider">
              CINEMATIC
            </span>
          </div>
          <p className="text-slate-400 text-[10px] font-sans">
            Automated drone camera sequence transitioning from Sunrise Day 0 to Sunset Handover.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => onStartCinematicFilm(30)}
              className="py-2 px-3 rounded-xl bg-[#ff7b00] hover:bg-[#ff8f24] text-black font-bold flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(255,123,0,0.4)] transition-all uppercase tracking-wider text-[11px]"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>30s Reel</span>
            </button>
            <button
              onClick={() => onStartCinematicFilm(60)}
              className="py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold flex items-center justify-center gap-1.5 border border-white/10 transition-all uppercase tracking-wider text-[11px]"
            >
              <Play className="w-3.5 h-3.5 fill-current text-[#00f2ff]" />
              <span>60s Reel</span>
            </button>
          </div>
        </div>

        {/* Dynamic Camera Angle Presets */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest text-[10px] flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-[#00f2ff]" />
            Camera View Angles
          </span>

          <div className="grid grid-cols-1 gap-1.5 font-sans">
            {cameraAngles.map((cam) => {
              const isSelected = simState.cameraPreset === cam.key;
              return (
                <button
                  key={cam.key}
                  onClick={() => {
                    onUpdateSimState({ cameraPreset: cam.key });
                    onSetCameraPreset(cam.key);
                  }}
                  className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-[#ff7b00]/15 border-[#ff7b00]/60 text-white ring-1 ring-[#ff7b00]/40 shadow-[0_0_12px_rgba(255,123,0,0.2)]'
                      : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs">{cam.label}</div>
                    <div className="text-[10px] text-slate-400">{cam.desc}</div>
                  </div>
                  <Move3d className="w-4 h-4 text-slate-500" />
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
