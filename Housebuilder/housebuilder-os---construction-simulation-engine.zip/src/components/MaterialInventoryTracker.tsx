/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Material Inventory & Supply Chain Tracker
 */

import React from 'react';
import {
  Boxes,
  CheckCircle2,
  Clock,
  Coins,
  Layers,
  PackageCheck,
  TrendingDown,
  TrendingUp,
  Truck,
  X
} from 'lucide-react';
import { MaterialStock } from '../types/simulation';

interface MaterialInventoryTrackerProps {
  materials: MaterialStock[];
  currentDay: number;
  onClose: () => void;
}

export const MaterialInventoryTracker: React.FC<MaterialInventoryTrackerProps> = ({
  materials,
  currentDay,
  onClose
}) => {
  return (
    <div className="absolute top-16 right-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Boxes className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Logistics & Inventory Flow
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-3 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        <p className="text-slate-400 text-[10px]">
          Site delivered stock vs fixed in place. Day {currentDay} tracking.
        </p>

        <div className="space-y-2">
          {materials.map((mat) => {
            const deliveredPercent = Math.min(100, Math.round((mat.deliveredToDate / mat.totalRequired) * 100));
            const installedPercent = Math.min(100, Math.round((mat.installedToDate / mat.totalRequired) * 100));

            return (
              <div
                key={mat.id}
                className="bg-black/40 border border-white/10 rounded-xl p-2.5 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-xs">{mat.name}</h4>
                    <span className="text-[9px] text-slate-400 font-mono">
                      Category: {mat.category}
                    </span>
                  </div>

                  <div className="text-right font-mono">
                    <span className="font-bold text-[#ff7b00] text-xs">
                      {mat.installedToDate.toLocaleString()} / {mat.totalRequired.toLocaleString()} {mat.unit}
                    </span>
                    <div className="text-[9px] text-slate-400">
                      £{(mat.installedToDate * mat.unitCostGbp).toLocaleString()} committed
                    </div>
                  </div>
                </div>

                {/* Progress bars: delivered (cyan border/glow) vs installed (orange) */}
                <div className="space-y-1">
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
                    {/* Delivered background */}
                    <div
                      className="h-full bg-slate-600 rounded-full absolute left-0 top-0"
                      style={{ width: `${deliveredPercent}%` }}
                    />
                    {/* Installed foreground */}
                    <div
                      className="h-full bg-gradient-to-r from-[#ff7b00] to-emerald-400 rounded-full absolute left-0 top-0"
                      style={{ width: `${installedPercent}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                    <span>Delivered: {deliveredPercent}%</span>
                    <span className="text-[#00f2ff]">Installed: {installedPercent}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
