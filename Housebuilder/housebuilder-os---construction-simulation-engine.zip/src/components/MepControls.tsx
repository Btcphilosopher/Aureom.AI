/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - MEP Building Services & Energy Engine
 */

import React, { useState } from 'react';
import {
  Activity,
  BatteryCharging,
  Car,
  CheckCircle,
  Droplets,
  Fan,
  Flame,
  Gauge,
  Lightbulb,
  Play,
  Power,
  RotateCcw,
  Sun,
  ThermometerSnowflake,
  Wind,
  X,
  Zap
} from 'lucide-react';
import { SimulationState } from '../types/simulation';

interface MepControlsProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  onClose: () => void;
}

export const MepControls: React.FC<MepControlsProps> = ({
  simState,
  onUpdateSimState,
  onClose
}) => {
  const [solarKw, setSolarKw] = useState(5.4);
  const [batteryCharge, setBatteryCharge] = useState(84);
  const [ashpCop, setAshpCop] = useState(3.85);
  const [ufhTemp, setUfhTemp] = useState(32);
  const [lightsOn, setLightsOn] = useState(true);
  const [evCharging, setEvCharging] = useState(true);

  const homeConsumptionKw = 2.1;
  const gridExportKw = Math.max(0, +(solarKw - homeConsumptionKw - (evCharging ? 2.4 : 0)).toFixed(1));

  return (
    <div className="absolute top-16 left-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#00f2ff]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            MEP Services & Smart Energy Flow
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Live Renewable Energy Dashboard */}
        <div className="bg-black/40 border border-white/10 rounded-xl p-3 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
              <Sun className="w-4 h-4 text-[#ff7b00]" />
              Live Solar & Microgrid Flow
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase tracking-wider">
              NET EXPORTING
            </span>
          </div>

          {/* Microgrid Stats Grid */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-white/5 p-2 rounded-lg border border-white/5 border-l-2 border-l-[#ff7b00]">
              <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-wider">
                <span>Solar PV Array</span>
                <Sun className="w-3 h-3 text-[#ff7b00]" />
              </div>
              <div className="font-mono font-bold text-sm text-[#ff7b00] mt-1 drop-shadow-[0_0_8px_rgba(255,123,0,0.3)]">
                {solarKw} kW
              </div>
              <div className="text-[9px] text-slate-400">17 In-Roof Panels (6.8kWp)</div>
            </div>

            <div className="bg-white/5 p-2 rounded-lg border border-white/5 border-l-2 border-l-emerald-400">
              <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-wider">
                <span>Home Battery</span>
                <BatteryCharging className="w-3 h-3 text-emerald-400" />
              </div>
              <div className="font-mono font-bold text-sm text-emerald-300 mt-1">
                {batteryCharge}% Charged
              </div>
              <div className="text-[9px] text-slate-400">LiFePO4 GivEnergy 10.4kWh</div>
            </div>

            <div className="bg-white/5 p-2 rounded-lg border border-white/5 border-l-2 border-l-[#00f2ff]">
              <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-wider">
                <span>ASHP Heat Pump</span>
                <ThermometerSnowflake className="w-3 h-3 text-[#00f2ff]" />
              </div>
              <div className="font-mono font-bold text-sm text-[#00f2ff] mt-1">
                COP {ashpCop}
              </div>
              <div className="text-[9px] text-slate-400">Vaillant aroTHERM Plus</div>
            </div>

            <div className="bg-white/5 p-2 rounded-lg border border-white/5 border-l-2 border-l-emerald-400">
              <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-wider">
                <span>Grid Feed-In</span>
                <Zap className="w-3 h-3 text-emerald-400" />
              </div>
              <div className="font-mono font-bold text-sm text-emerald-400 mt-1 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                +{gridExportKw} kW
              </div>
              <div className="text-[9px] text-slate-400">Octopus Agile Export</div>
            </div>
          </div>
        </div>

        {/* Electrical Circuits & Lighting */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest text-[10px] flex items-center gap-1.5">
            <Power className="w-3.5 h-3.5 text-[#00f2ff]" />
            Active Electrical Distribution
          </span>

          <div className="space-y-1.5 bg-black/40 p-2.5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-300 flex items-center gap-2">
                <Lightbulb className="w-3.5 h-3.5 text-[#ff7b00]" />
                LED Downlights & Pendants
              </span>
              <button
                onClick={() => setLightsOn(!lightsOn)}
                className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold transition-all ${
                  lightsOn ? 'bg-[#ff7b00] text-black shadow-[0_0_10px_rgba(255,123,0,0.4)]' : 'bg-white/10 text-slate-400'
                }`}
              >
                {lightsOn ? 'ON (140W)' : 'OFF'}
              </button>
            </div>

            <div className="flex items-center justify-between py-1 border-t border-white/10">
              <span className="text-slate-300 flex items-center gap-2">
                <Car className="w-3.5 h-3.5 text-[#00f2ff]" />
                22kW EV Smart Charger
              </span>
              <button
                onClick={() => setEvCharging(!evCharging)}
                className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold transition-all ${
                  evCharging ? 'bg-[#00f2ff] text-black shadow-[0_0_10px_rgba(0,242,255,0.4)]' : 'bg-white/10 text-slate-400'
                }`}
              >
                {evCharging ? 'CHARGING (2.4kW)' : 'STANDBY'}
              </button>
            </div>
          </div>
        </div>

        {/* Heating, Plumbing & UFH */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest text-[10px] flex items-center gap-1.5">
            <Droplets className="w-3.5 h-3.5 text-blue-400" />
            Hydronic Plumbing & Underfloor Heating
          </span>

          <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">UFH Flow Water Temp</span>
              <span className="font-mono text-[#ff7b00] font-bold">{ufhTemp}°C</span>
            </div>
            <input
              type="range"
              min={24}
              max={42}
              value={ufhTemp}
              onChange={(e) => setUfhTemp(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00]"
            />
            <div className="flex justify-between text-[9px] text-slate-400 font-mono">
              <span>Eco 24°C</span>
              <span>Comfort 32°C</span>
              <span>Max 42°C</span>
            </div>
          </div>
        </div>

        {/* HVAC & Mechanical Ventilation */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest text-[10px] flex items-center gap-1.5">
            <Wind className="w-3.5 h-3.5 text-[#00f2ff]" />
            MVHR Heat Recovery Ventilation
          </span>

          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 flex items-center justify-between">
            <div>
              <div className="text-slate-200 font-semibold text-xs">Whole-House Air Exchange</div>
              <div className="text-[9px] text-slate-400">92% Thermal Recovery • 280 m³/h</div>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 font-mono text-[10px]">
              <Fan className="w-3.5 h-3.5 animate-spin" />
              <span>ACTIVE</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
