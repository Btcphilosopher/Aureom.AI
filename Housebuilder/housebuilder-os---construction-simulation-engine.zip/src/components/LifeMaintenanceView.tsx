/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - 30-Year Whole-Life Building Simulator & Asset Maintenance
 */

import React from 'react';
import {
  AlertTriangle,
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  Coins,
  FileCheck,
  History,
  ShieldCheck,
  TrendingUp,
  Wrench,
  X
} from 'lucide-react';
import { WHOLE_LIFE_MAINTENANCE_SCHEDULE } from '../engine/simulationModel';

interface LifeMaintenanceViewProps {
  currentYear: number;
  onUpdateYear: (year: number) => void;
  onClose: () => void;
}

export const LifeMaintenanceView: React.FC<LifeMaintenanceViewProps> = ({
  currentYear,
  onUpdateYear,
  onClose
}) => {
  const years = [1, 2, 5, 7, 10, 15, 18, 20, 25, 30];

  const filteredTasks = WHOLE_LIFE_MAINTENANCE_SCHEDULE.filter(
    (item) => item.year <= currentYear
  );

  const totalSpentForecast = filteredTasks.reduce(
    (acc, cur) => acc + cur.estimatedCost,
    0
  );

  return (
    <div className="absolute top-16 right-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            30-Year Asset Lifecycle & Maintenance
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Timeline Slider (Year 1 to 30) */}
        <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-300 font-bold uppercase tracking-wider flex items-center gap-1.5 text-[10px]">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              Occupancy Timeline
            </span>
            <span className="font-mono text-emerald-400 font-bold text-sm drop-shadow-[0_0_8px_rgba(52,211,153,0.4)]">
              YEAR {currentYear}
            </span>
          </div>

          <input
            type="range"
            min={1}
            max={30}
            value={currentYear}
            onChange={(e) => onUpdateYear(Number(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />

          <div className="flex justify-between text-[9px] text-slate-400 font-mono">
            <span>Yr 1 Handover</span>
            <span>Yr 10 Service</span>
            <span>Yr 20 Refresh</span>
            <span>Yr 30 Retrofit</span>
          </div>
        </div>

        {/* Asset Financials at Year X */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 border-l-2 border-l-emerald-400">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider">Cumulative Maint.</div>
            <div className="font-mono font-bold text-emerald-400 mt-0.5 text-sm drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
              £{totalSpentForecast.toLocaleString()}
            </div>
            <div className="text-[8px] text-slate-400">Scheduled interventions</div>
          </div>

          <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 border-l-2 border-l-[#ff7b00]">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider">Estimated Value</div>
            <div className="font-mono font-bold text-[#ff7b00] mt-0.5 text-sm drop-shadow-[0_0_8px_rgba(255,123,0,0.3)]">
              £{Math.round(485000 * Math.pow(1.025, currentYear)).toLocaleString()}
            </div>
            <div className="text-[8px] text-slate-400">2.5% p.a. indexation</div>
          </div>
        </div>

        {/* Interventions Log */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Wrench className="w-3.5 h-3.5 text-[#ff7b00]" />
            Interventions Log up to Year {currentYear}
          </span>

          <div className="space-y-1.5">
            {WHOLE_LIFE_MAINTENANCE_SCHEDULE.map((item, idx) => {
              const isPastOrCurrent = item.year <= currentYear;
              return (
                <div
                  key={idx}
                  className={`p-2.5 rounded-xl border transition-all ${
                    isPastOrCurrent
                      ? 'bg-black/40 border-white/10 text-slate-200'
                      : 'bg-black/20 border-white/5 text-slate-600 opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-[10px] px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-[#ff7b00]">
                        YR {item.year}
                      </span>
                      <span className="font-bold text-xs">{item.componentName}</span>
                    </div>
                    <span className="font-mono font-bold text-emerald-400 text-xs">
                      £{item.estimatedCost}
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-400 mt-1 font-sans">
                    {item.actionRequired}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
