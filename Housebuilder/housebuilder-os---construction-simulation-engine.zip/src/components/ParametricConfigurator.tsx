/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Parametric House & Material Variant Engine
 */

import React from 'react';
import {
  Check,
  Cpu,
  Layers,
  Palette,
  RotateCcw,
  Ruler,
  Sliders,
  Sparkles,
  Sun,
  X,
  Zap
} from 'lucide-react';
import { HouseParameters } from '../types/simulation';

interface ParametricConfiguratorProps {
  parameters: HouseParameters;
  onUpdateParameters: (newParams: HouseParameters) => void;
  onClose: () => void;
}

export const ParametricConfigurator: React.FC<ParametricConfiguratorProps> = ({
  parameters,
  onUpdateParameters,
  onClose
}) => {
  const materialsList = [
    { key: 'BRICK_RED', name: 'Ibstock Red Multi Brick', color: 'bg-red-800', desc: 'Traditional Class B Wirecut Facing Brick' },
    { key: 'STONE_COTSWOLD', name: 'Cotswold Dressed Stone', color: 'bg-amber-200 text-slate-900', desc: 'Natural quarried Oolitic limestone' },
    { key: 'TIMBER_LARCH', name: 'Siberian Larch Cladding', color: 'bg-amber-600', desc: 'Sustainable rain-screen timber battens' },
    { key: 'WHITE_RENDER', name: 'Crisp Silicone White Render', color: 'bg-slate-100 text-slate-900', desc: 'K-Rend through-coloured thin coat' },
    { key: 'DARK_ZINC', name: 'Anthra-Zinc Standing Seam', color: 'bg-slate-800', desc: 'VMZINC architectural metal cladding' }
  ];

  return (
    <div className="absolute top-16 left-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Parametric House Generator
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Footprint Dimensions Sliders */}
        <div className="space-y-3 bg-black/40 p-3 rounded-xl border border-white/10">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Ruler className="w-3.5 h-3.5 text-[#00f2ff]" />
            Footprint Dimensions
          </span>

          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Width (Frontage):</span>
              <span className="font-mono text-[#ff7b00] font-bold">{parameters.widthM.toFixed(1)} m</span>
            </div>
            <input
              type="range"
              min={7.2}
              max={14.0}
              step={0.4}
              value={parameters.widthM}
              onChange={(e) => onUpdateParameters({ ...parameters, widthM: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00]"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Length (Depth):</span>
              <span className="font-mono text-[#ff7b00] font-bold">{parameters.lengthM.toFixed(1)} m</span>
            </div>
            <input
              type="range"
              min={6.4}
              max={12.0}
              step={0.4}
              value={parameters.lengthM}
              onChange={(e) => onUpdateParameters({ ...parameters, lengthM: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00]"
            />
          </div>

          <div className="flex justify-between text-[10px] text-slate-400 font-mono pt-1 border-t border-white/10">
            <span>Gross Floor Area:</span>
            <span className="text-[#00f2ff] font-bold">
              {Math.round(parameters.widthM * parameters.lengthM * parameters.floors)} m² ({(Math.round(parameters.widthM * parameters.lengthM * parameters.floors * 10.764))} sq ft)
            </span>
          </div>
        </div>

        {/* Facade Material Variant Morpher */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Palette className="w-3.5 h-3.5 text-[#ff7b00]" />
            Facade Material Palette
          </span>

          <div className="space-y-1.5 font-sans">
            {materialsList.map((mat) => {
              const isSelected = parameters.claddingMaterial === mat.key;
              return (
                <button
                  key={mat.key}
                  onClick={() => onUpdateParameters({ ...parameters, claddingMaterial: mat.key as any })}
                  className={`w-full flex items-center justify-between p-2 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-[#ff7b00]/15 border-[#ff7b00]/60 ring-1 ring-[#ff7b00]/40 text-white shadow-[0_0_12px_rgba(255,123,0,0.2)]'
                      : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className={`w-4 h-4 rounded-full border border-white/20 shadow-sm ${mat.color}`} />
                    <div>
                      <div className="font-semibold text-xs text-white">{mat.name}</div>
                      <div className="text-[10px] text-slate-400">{mat.desc}</div>
                    </div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-[#ff7b00] flex-shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Clean Tech & Options */}
        <div className="space-y-2 pt-2 border-t border-white/10">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            Zero-Carbon Specifications
          </span>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onUpdateParameters({ ...parameters, hasSolarPanels: !parameters.hasSolarPanels })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasSolarPanels
                  ? 'bg-[#ff7b00]/20 border-[#ff7b00]/50 text-[#ff7b00] shadow-[0_0_10px_rgba(255,123,0,0.2)]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div className="font-bold text-xs">Solar PV (6.8kW)</div>
              <div className="text-[9px] text-slate-400">In-Roof Array</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hasHeatPump: !parameters.hasHeatPump })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasHeatPump
                  ? 'bg-[#00f2ff]/20 border-[#00f2ff]/50 text-[#00f2ff] shadow-[0_0_10px_rgba(0,242,255,0.2)]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div className="font-bold text-xs">ASHP Heat Pump</div>
              <div className="text-[9px] text-slate-400">R290 Refrigerant</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hasEVCharger: !parameters.hasEVCharger })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasEVCharger
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-[0_0_10px_rgba(52,211,153,0.2)]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div className="font-bold text-xs">22kW EV Charger</div>
              <div className="text-[9px] text-slate-400">Smart Fast Charge</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hasGarage: !parameters.hasGarage })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasGarage
                  ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300 shadow-[0_0_10px_rgba(99,102,241,0.2)]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div className="font-bold text-xs">Integrated Garage</div>
              <div className="text-[9px] text-slate-400">Power & Workshop</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
