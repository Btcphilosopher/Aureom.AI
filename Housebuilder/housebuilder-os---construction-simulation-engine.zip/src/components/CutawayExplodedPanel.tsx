/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Cutaway & Exploded View Controls
 */

import React from 'react';
import {
  ChevronsDown,
  ChevronsUp,
  Eye,
  EyeOff,
  Flame,
  Layers,
  Maximize2,
  Minimize2,
  Sliders,
  TrendingUp,
  X
} from 'lucide-react';
import { SimulationState, ViewMode } from '../types/simulation';

interface CutawayExplodedPanelProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  onClose: () => void;
}

export const CutawayExplodedPanel: React.FC<CutawayExplodedPanelProps> = ({
  simState,
  onUpdateSimState,
  onClose
}) => {
  const { viewMode, cutawayHeight, explodedSeparation, showStructuralOnly } = simState;

  return (
    <div className="absolute top-16 left-4 w-80 bg-[#0f1218]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Layer & Cutaway Controls
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-5 text-xs">
        {/* Exploded View Separation Slider */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
              <TrendingUp className="w-3.5 h-3.5 text-[#ff7b00]" />
              Exploded Layer Separation
            </span>
            <span className="font-mono text-[#ff7b00] font-bold">
              {Math.round(explodedSeparation * 100)}%
            </span>
          </div>

          <input
            type="range"
            min={0}
            max={1}
            step={0.02}
            value={explodedSeparation}
            onChange={(e) => {
              onUpdateSimState({
                viewMode: ViewMode.EXPLODED,
                explodedSeparation: Number(e.target.value)
              });
            }}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00]"
          />

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => onUpdateSimState({ viewMode: ViewMode.EXPLODED, explodedSeparation: 1.0 })}
              className="flex-1 py-1.5 px-2 rounded-lg bg-[#ff7b00]/15 border border-[#ff7b00]/40 text-[#ff7b00] font-bold hover:bg-[#ff7b00]/25 transition-all text-center uppercase tracking-wider text-[10px]"
            >
              Explode All
            </button>
            <button
              onClick={() => onUpdateSimState({ explodedSeparation: 0.0 })}
              className="flex-1 py-1.5 px-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 font-bold hover:bg-white/10 transition-all text-center uppercase tracking-wider text-[10px]"
            >
              Assemble House
            </button>
          </div>
        </div>

        {/* Cutaway Section Height Slider */}
        <div className="space-y-2 pt-3 border-t border-white/10">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
              <Sliders className="w-3.5 h-3.5 text-[#00f2ff]" />
              Cutaway Section Height
            </span>
            <span className="font-mono text-[#00f2ff] font-bold">
              {Math.round(cutawayHeight * 6.0)}m
            </span>
          </div>

          <input
            type="range"
            min={0.1}
            max={1.0}
            step={0.02}
            value={cutawayHeight}
            onChange={(e) => {
              onUpdateSimState({
                viewMode: ViewMode.CUTAWAY,
                cutawayHeight: Number(e.target.value)
              });
            }}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#00f2ff]"
          />

          <div className="grid grid-cols-3 gap-1.5 text-[10px] pt-1">
            <button
              onClick={() => onUpdateSimState({ viewMode: ViewMode.CUTAWAY, cutawayHeight: 0.25 })}
              className="py-1 px-1.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-center border border-white/5"
            >
              Ground Fl.
            </button>
            <button
              onClick={() => onUpdateSimState({ viewMode: ViewMode.CUTAWAY, cutawayHeight: 0.65 })}
              className="py-1 px-1.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-center border border-white/5"
            >
              First Fl.
            </button>
            <button
              onClick={() => onUpdateSimState({ viewMode: ViewMode.CUTAWAY, cutawayHeight: 1.0 })}
              className="py-1 px-1.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-center border border-white/5"
            >
              Roof Level
            </button>
          </div>
        </div>

        {/* Structural Only View Toggle */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between">
          <div>
            <div className="font-semibold text-slate-200 text-xs">Structural View Only</div>
            <div className="text-[9px] text-slate-400">Reveal timber frame & steel</div>
          </div>
          <button
            onClick={() => onUpdateSimState({ showStructuralOnly: !showStructuralOnly })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              showStructuralOnly ? 'bg-[#ff7b00]' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                showStructuralOnly ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
