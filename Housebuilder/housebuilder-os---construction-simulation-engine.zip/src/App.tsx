/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Kotlin Construction Animation Engine
 * Main Application Orchestrator
 */

import React, { useCallback, useMemo, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  BimInspectorModal
} from './components/BimInspectorModal';
import {
  CinematicDirector
} from './components/CinematicDirector';
import {
  CutawayExplodedPanel
} from './components/CutawayExplodedPanel';
import {
  LifeMaintenanceView
} from './components/LifeMaintenanceView';
import {
  MasterplanDashboard
} from './components/MasterplanDashboard';
import {
  MaterialInventoryTracker
} from './components/MaterialInventoryTracker';
import {
  MepControls
} from './components/MepControls';
import {
  ParametricConfigurator
} from './components/ParametricConfigurator';
import {
  RoomProgressGrid
} from './components/RoomProgressGrid';
import {
  TimelineBar
} from './components/TimelineBar';
import {
  TopHeader
} from './components/TopHeader';
import {
  Viewport3D
} from './components/Viewport3D';
import {
  calculateBudgetSpent,
  calculateMaterialStock,
  calculateOverallProgress,
  calculateRoomsProgress,
  DEFAULT_PARAMETERS,
  GENERATE_BIM_COMPONENTS,
  GENERATE_MASTERPLAN_PLOTS,
  getStageFromDay,
  SCHEDULE_MILESTONES
} from './engine/simulationModel';
import {
  BimComponent,
  CameraPreset,
  ConstructionStage,
  HouseParameters,
  SimulationState,
  TimeOfDay,
  ViewMode,
  WeatherType
} from './types/simulation';

export default function App() {
  // Core Simulation State
  const [simState, setSimState] = useState<SimulationState>({
    currentDay: 0,
    maxDays: 240,
    isPlaying: false,
    playbackSpeed: 1,
    isReverse: false,
    viewMode: ViewMode.CONSTRUCTION,
    cameraPreset: CameraPreset.ORBIT,
    weather: WeatherType.CLEAR_SUNNY,
    timeOfDay: TimeOfDay.MIDDAY,
    weatherDrivenDelay: false,

    // Cutaway & Exploded
    cutawayHeight: 1.0,
    cutawayWallAlpha: 1.0,
    explodedSeparation: 0.0,
    showStructuralOnly: false,

    // MEP
    mepElectricalVisible: true,
    mepPlumbingVisible: true,
    mepHvacVisible: true,
    mepDrainageVisible: true,
    mepFlowAnimated: true,

    // Selections
    selectedComponentId: null,
    selectedRoomId: null,

    // Dimension
    dimensionModeActive: false,
    measuredDistanceM: null,

    // Parametric model
    parameters: DEFAULT_PARAMETERS,

    // Masterplan
    masterplanActive: false,
    totalMasterplanPlots: 8,

    // Whole-Life
    maintenanceYear: 1
  });

  // Active floating dock panel ('cutaway' | 'mep' | 'rooms' | 'parametric' | 'materials' | 'masterplan' | 'maintenance' | 'camera' | null)
  const [activePanel, setActivePanel] = useState<string | null>(null);

  // Update simulation state partially
  const handleUpdateSimState = useCallback((updates: Partial<SimulationState>) => {
    setSimState((prev) => ({ ...prev, ...updates }));
  }, []);

  // Recalculate dynamic BIM components list when parameters change
  const bimComponents = useMemo(() => {
    return GENERATE_BIM_COMPONENTS(simState.parameters);
  }, [simState.parameters]);

  // Masterplan plots
  const masterplanPlots = useMemo(() => {
    return GENERATE_MASTERPLAN_PLOTS(simState.totalMasterplanPlots);
  }, [simState.totalMasterplanPlots]);

  // Calculations derived from current day
  const currentStage = useMemo(() => getStageFromDay(simState.currentDay), [simState.currentDay]);
  const overallProgress = useMemo(() => calculateOverallProgress(simState.currentDay), [simState.currentDay]);
  const budgetInfo = useMemo(() => calculateBudgetSpent(simState.currentDay, bimComponents), [simState.currentDay, bimComponents]);
  const roomsProgress = useMemo(() => calculateRoomsProgress(simState.currentDay), [simState.currentDay]);
  const materialsStock = useMemo(() => calculateMaterialStock(simState.currentDay), [simState.currentDay]);

  // Selected BIM Component for Inspector
  const selectedComponent = useMemo(() => {
    if (!simState.selectedComponentId) return null;
    return bimComponents.find((c) => c.id === simState.selectedComponentId) || null;
  }, [simState.selectedComponentId, bimComponents]);

  // Current milestone description
  const currentMilestone = useMemo(() => {
    const passed = SCHEDULE_MILESTONES.filter((m) => m.day <= simState.currentDay);
    return passed.length > 0 ? passed[passed.length - 1] : SCHEDULE_MILESTONES[0];
  }, [simState.currentDay]);

  // Toggle floating panels
  const handleTogglePanel = useCallback((panel: string) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  }, []);

  // Completion Ceremony
  const handleCompletionCeremony = useCallback(() => {
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  }, []);

  // Cinematic Film Player Sequence
  const handleStartCinematicFilm = useCallback((durationSec: number) => {
    handleUpdateSimState({
      currentDay: 0,
      isPlaying: true,
      playbackSpeed: durationSec === 30 ? 8 : 4,
      cameraPreset: CameraPreset.CINEMATIC_DRONE,
      timeOfDay: TimeOfDay.SUNRISE
    });
    setActivePanel(null);
  }, [handleUpdateSimState]);

  // Room focus handler
  const handleFocusRoom = useCallback((roomId: string, cameraPreset?: CameraPreset) => {
    handleUpdateSimState({
      selectedRoomId: roomId,
      cameraPreset: cameraPreset || CameraPreset.INTERIOR_LIVING
    });
  }, [handleUpdateSimState]);

  return (
    <div className="relative w-screen h-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* Top Header & Project HUD */}
      <TopHeader
        simState={simState}
        onUpdateSimState={handleUpdateSimState}
        onSetCameraPreset={(preset) => handleUpdateSimState({ cameraPreset: preset })}
        spentBudget={budgetInfo.spent}
        totalBudget={budgetInfo.total}
        overallProgress={overallProgress}
        currentStage={currentStage}
      />

      {/* Main 3D Viewport & Canvas */}
      <main className="relative flex-1 w-full h-full flex overflow-hidden">
        <Viewport3D
          simState={simState}
          onUpdateSimState={handleUpdateSimState}
          bimComponents={bimComponents}
          onSelectComponent={(id) => handleUpdateSimState({ selectedComponentId: id })}
          activePanel={activePanel}
          onTogglePanel={handleTogglePanel}
        />

        {/* Floating Modals / Control Drawers */}
        {selectedComponent && (
          <BimInspectorModal
            component={selectedComponent}
            currentDay={simState.currentDay}
            onClose={() => handleUpdateSimState({ selectedComponentId: null })}
          />
        )}

        {activePanel === 'cutaway' && (
          <CutawayExplodedPanel
            simState={simState}
            onUpdateSimState={handleUpdateSimState}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'mep' && (
          <MepControls
            simState={simState}
            onUpdateSimState={handleUpdateSimState}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'rooms' && (
          <RoomProgressGrid
            rooms={roomsProgress}
            currentDay={simState.currentDay}
            onFocusRoom={handleFocusRoom}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'parametric' && (
          <ParametricConfigurator
            parameters={simState.parameters}
            onUpdateParameters={(params: HouseParameters) => handleUpdateSimState({ parameters: params })}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'materials' && (
          <MaterialInventoryTracker
            materials={materialsStock}
            currentDay={simState.currentDay}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'masterplan' && (
          <MasterplanDashboard
            plots={masterplanPlots}
            onSelectPlot={(plotId) => {
              const plot = masterplanPlots.find((p) => p.id === plotId);
              if (plot) {
                handleUpdateSimState({ currentDay: plot.currentDay });
              }
            }}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'maintenance' && (
          <LifeMaintenanceView
            currentYear={simState.maintenanceYear}
            onUpdateYear={(yr) => handleUpdateSimState({ maintenanceYear: yr })}
            onClose={() => setActivePanel(null)}
          />
        )}

        {activePanel === 'camera' && (
          <CinematicDirector
            simState={simState}
            onUpdateSimState={handleUpdateSimState}
            onSetCameraPreset={(preset) => handleUpdateSimState({ cameraPreset: preset })}
            onStartCinematicFilm={handleStartCinematicFilm}
            onClose={() => setActivePanel(null)}
          />
        )}
      </main>

      {/* Bottom Construction Time Machine Scrubber Bar */}
      <TimelineBar
        simState={simState}
        onUpdateSimState={handleUpdateSimState}
        currentMilestoneTitle={currentMilestone.title}
        activeMachinery={currentMilestone.activeMachinery}
        activeTrades={currentMilestone.activeTrades}
        onCompletionCeremony={handleCompletionCeremony}
      />
    </div>
  );
}
