/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Simulation Engine Types
 * Kotlin Compose / BIM / Simulation Architecture
 */

export enum ConstructionStage {
  SITE = 'SITE',
  GROUNDWORK = 'GROUNDWORK',
  FOUNDATION = 'FOUNDATION',
  GROUND_FLOOR = 'GROUND_FLOOR',
  STRUCTURE = 'STRUCTURE',
  ROOF = 'ROOF',
  ENVELOPE = 'ENVELOPE',
  SERVICES = 'SERVICES',
  INTERNAL_FINISH = 'INTERNAL_FINISH',
  EXTERNAL_FINISH = 'EXTERNAL_FINISH',
  LANDSCAPE = 'LANDSCAPE',
  COMPLETE = 'COMPLETE',
  BUILDING_LIFE = 'BUILDING_LIFE'
}

export enum ComponentState {
  NOT_STARTED = 'NOT_STARTED',
  PLANNED = 'PLANNED',
  UNDER_CONSTRUCTION = 'UNDER_CONSTRUCTION',
  INSTALLED = 'INSTALLED',
  INSPECTED = 'INSPECTED',
  COMPLETE = 'COMPLETE'
}

export enum ViewMode {
  CONSTRUCTION = 'CONSTRUCTION',
  CUTAWAY = 'CUTAWAY',
  EXPLODED = 'EXPLODED',
  STRUCTURAL = 'STRUCTURAL',
  SERVICES_MEP = 'SERVICES_MEP',
  ENERGY = 'ENERGY',
  DIGITAL_TWIN = 'DIGITAL_TWIN',
  DIMENSION = 'DIMENSION',
  MASTERPLAN = 'MASTERPLAN',
  MAINTENANCE = 'MAINTENANCE'
}

export enum CameraPreset {
  ORBIT = 'ORBIT',
  SITE_OVERVIEW = 'SITE_OVERVIEW',
  GROUND_LEVEL = 'GROUND_LEVEL',
  AERIAL_CRANE = 'AERIAL_CRANE',
  INTERIOR_KITCHEN = 'INTERIOR_KITCHEN',
  INTERIOR_LIVING = 'INTERIOR_LIVING',
  ROOF_LEVEL = 'ROOF_LEVEL',
  SECTION_CUT = 'SECTION_CUT',
  CINEMATIC_DRONE = 'CINEMATIC_DRONE'
}

export enum WeatherType {
  CLEAR_SUNNY = 'CLEAR_SUNNY',
  PARTLY_CLOUDY = 'PARTLY_CLOUDY',
  OVERCAST = 'OVERCAST',
  RAIN = 'RAIN',
  SNOW = 'SNOW'
}

export enum TimeOfDay {
  SUNRISE = 'SUNRISE',
  MORNING = 'MORNING',
  MIDDAY = 'MIDDAY',
  AFTERNOON = 'AFTERNOON',
  GOLDEN_HOUR = 'GOLDEN_HOUR',
  NIGHT = 'NIGHT'
}

export enum TradeType {
  GROUNDWORKER = 'GROUNDWORKER',
  BRICKLAYER = 'BRICKLAYER',
  CARPENTER = 'CARPENTER',
  ELECTRICIAN = 'ELECTRICIAN',
  PLUMBER = 'PLUMBER',
  ROOFER = 'ROOFER',
  PLASTERER = 'PLASTERER',
  PAINTER = 'PAINTER',
  LANDSCAPER = 'LANDSCAPER',
  SITE_SUPERVISOR = 'SITE_SUPERVISOR'
}

export enum MachineType {
  EXCAVATOR = 'EXCAVATOR',
  DUMP_TRUCK = 'DUMP_TRUCK',
  TOWER_CRANE = 'TOWER_CRANE',
  CONCRETE_MIXER = 'CONCRETE_MIXER',
  TELEHANDLER = 'TELEHANDLER',
  DELIVERY_TRUCK = 'DELIVERY_TRUCK',
  SCAFFOLDING = 'SCAFFOLDING'
}

export interface BimComponent {
  id: string;
  name: string;
  category: 'Foundation' | 'Structure' | 'Roof' | 'Envelope' | 'MEP_Electrical' | 'MEP_Plumbing' | 'MEP_HVAC' | 'Interior' | 'Landscape' | 'Renewable';
  startDay: number;
  endDay: number;
  stage: ConstructionStage;
  material: string;
  dimensions: {
    lengthM: number;
    widthM: number;
    heightM: number;
    areaM2?: number;
    volumeM3?: number;
  };
  costs: {
    materials: number;
    labour: number;
    plant: number;
    total: number;
  };
  embodiedCarbonKg: number;
  uValue?: number; // W/m²K
  supplier: string;
  warrantyYears: number;
  expectedLifeYears: number;
  maintenanceIntervalMonths: number;
  tradeRequired: TradeType;
  machineRequired?: MachineType;
  position: [number, number, number];
  rotation?: [number, number, number];
  state: ComponentState;
  progress: number; // 0.0 to 1.0
  meshName?: string;
  layerGroup: 'foundations' | 'structure' | 'floors' | 'roof' | 'envelope' | 'mep' | 'interior' | 'landscape';
}

export interface ScheduleMilestone {
  day: number;
  title: string;
  stage: ConstructionStage;
  description: string;
  costSpentToDate: number;
  materialsDelivered: string[];
  activeMachinery: MachineType[];
  activeTrades: TradeType[];
}

export interface MaterialStock {
  id: string;
  name: string;
  unit: string;
  totalRequired: number;
  deliveredToDate: number;
  installedToDate: number;
  unitCostGbp: number;
  category: string;
}

export interface WorkerEntity {
  id: string;
  trade: TradeType;
  name: string;
  position: [number, number, number];
  rotation: number;
  state: 'WORKING' | 'WALKING' | 'IDLE' | 'INSPECTING';
  currentTaskId?: string;
}

export interface MachineryEntity {
  id: string;
  type: MachineType;
  name: string;
  position: [number, number, number];
  rotation: number;
  working: boolean;
  boomAngle?: number;
  armAngle?: number;
  trolleyPos?: number;
  hookHeight?: number;
  drumRotation?: number;
  activePayload?: string;
}

export interface RoomBuildStatus {
  id: string;
  name: string;
  floor: 0 | 1 | 2;
  structure: number; // 0 - 100
  electrical: number;
  plumbing: number;
  plaster: number;
  flooring: number;
  decoration: number;
  overall: number;
}

export interface EnergyFlowStats {
  solarGenerationKw: number;
  heatPumpConsumptionKw: number;
  batteryStorageKwh: number;
  batteryChargePercent: number;
  gridImportKw: number;
  gridExportKw: number;
  homeLoadKw: number;
  evChargingKw: number;
  copEfficiency: number;
}

export interface MasterplanPlot {
  id: number;
  plotNumber: string;
  houseType: string;
  currentDay: number;
  stage: ConstructionStage;
  progressPercent: number;
  positionOffset: [number, number, number];
  targetCompletionDays: number;
  budgetSpent: number;
}

export interface HouseParameters {
  widthM: number;
  lengthM: number;
  floors: 1 | 2 | 3;
  roofType: 'GABLE' | 'HIP' | 'FLAT_MODERN';
  claddingMaterial: 'BRICK_RED' | 'STONE_COTSWOLD' | 'TIMBER_LARCH' | 'WHITE_RENDER' | 'DARK_ZINC';
  hasSolarPanels: boolean;
  hasHeatPump: boolean;
  hasEVCharger: boolean;
  hasGarage: boolean;
  bedroomCount: number;
  bathroomCount: number;
}

export interface MaintenanceItem {
  year: number;
  componentId: string;
  componentName: string;
  actionRequired: string;
  estimatedCost: number;
  urgency: 'ROUTINE' | 'RECOMMENDED' | 'CRITICAL';
  status: 'PENDING' | 'SCHEDULED' | 'SERVICED';
}

export interface SimulationState {
  currentDay: number;
  maxDays: number;
  isPlaying: boolean;
  playbackSpeed: number; // 0.25, 1, 2, 5, 10, 50, 100
  isReverse: boolean;
  viewMode: ViewMode;
  cameraPreset: CameraPreset;
  weather: WeatherType;
  timeOfDay: TimeOfDay;
  weatherDrivenDelay: boolean;
  
  // Cutaway & Exploded
  cutawayHeight: number; // 0 to 1
  cutawayWallAlpha: number; // 0 to 1
  explodedSeparation: number; // 0 to 1
  showStructuralOnly: boolean;
  
  // MEP & Services
  mepElectricalVisible: boolean;
  mepPlumbingVisible: boolean;
  mepHvacVisible: boolean;
  mepDrainageVisible: boolean;
  mepFlowAnimated: boolean;
  
  // Selection
  selectedComponentId: string | null;
  selectedRoomId: string | null;
  
  // Dimension tool
  dimensionModeActive: boolean;
  measuredDistanceM: number | null;
  
  // Parameters
  parameters: HouseParameters;
  
  // Masterplan
  masterplanActive: boolean;
  totalMasterplanPlots: number;
  
  // Whole-life maintenance
  maintenanceYear: number; // 1 to 30
}
