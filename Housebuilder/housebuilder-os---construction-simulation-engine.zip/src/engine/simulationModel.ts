/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Simulation Model & Data Engine
 */

import {
  BimComponent,
  ComponentState,
  ConstructionStage,
  HouseParameters,
  MachineType,
  MaintenanceItem,
  MasterplanPlot,
  MaterialStock,
  RoomBuildStatus,
  ScheduleMilestone,
  TradeType
} from '../types/simulation';

// Default initial house parametric specification
export const DEFAULT_PARAMETERS: HouseParameters = {
  widthM: 9.6,
  lengthM: 8.4,
  floors: 2,
  roofType: 'GABLE',
  claddingMaterial: 'BRICK_RED',
  hasSolarPanels: true,
  hasHeatPump: true,
  hasEVCharger: true,
  hasGarage: true,
  bedroomCount: 4,
  bathroomCount: 3
};

// Schedule Milestones from Day 0 to Day 240
export const SCHEDULE_MILESTONES: ScheduleMilestone[] = [
  {
    day: 0,
    title: 'Site Possession & Clearance',
    stage: ConstructionStage.SITE,
    description: 'Empty plot surveyed, boundary fencing erected, tree protection zones marked, site welfare cabins delivered.',
    costSpentToDate: 8500,
    materialsDelivered: ['Perimeter Heras Fencing', 'Site Welfare Units', 'Protective Ground Mats'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.SITE_SUPERVISOR, TradeType.GROUNDWORKER]
  },
  {
    day: 10,
    title: 'Excavation & Trenching',
    stage: ConstructionStage.GROUNDWORK,
    description: 'Topsoil stripped, foundation strip footings excavated by 20t tracked excavator, spoil shifted to stockpile.',
    costSpentToDate: 24200,
    materialsDelivered: ['Type 1 MOT Sub-base', 'Geotextile Membrane', '110mm Underground Drainage Pipes'],
    activeMachinery: [MachineType.EXCAVATOR, MachineType.DUMP_TRUCK],
    activeTrades: [TradeType.GROUNDWORKER]
  },
  {
    day: 25,
    title: 'Foundations & Rebar Pour',
    stage: ConstructionStage.FOUNDATION,
    description: 'Steel reinforcement rebar cages installed, C35 concrete pumped into strip footings, concrete curing monitored.',
    costSpentToDate: 49800,
    materialsDelivered: ['B500B Steel Rebar Cages', 'Ready-mix C35 Concrete', 'Formwork Timber'],
    activeMachinery: [MachineType.CONCRETE_MIXER],
    activeTrades: [TradeType.GROUNDWORKER]
  },
  {
    day: 45,
    title: 'Ground Floor Slab & DPC',
    stage: ConstructionStage.GROUND_FLOOR,
    description: 'Sub-floor gravel compacted, 150mm PIR insulation laid, DPM damp-proof membrane sealed, power-floated structural floor slab poured.',
    costSpentToDate: 78500,
    materialsDelivered: ['150mm PIR Floor Insulation', '1200 Gauge DPM', 'Reinforced Mesh A252'],
    activeMachinery: [MachineType.CONCRETE_MIXER, MachineType.TELEHANDLER],
    activeTrades: [TradeType.GROUNDWORKER, TradeType.BRICKLAYER]
  },
  {
    day: 75,
    title: 'Superstructure Walls & Scaffolding',
    stage: ConstructionStage.STRUCTURE,
    description: 'External brick outer leaf and aircrete thermal block inner leaf built course-by-course. Structural steel RSJs and floor joists installed.',
    costSpentToDate: 128400,
    materialsDelivered: ['Facing Bricks (Class B)', 'Thermalite Aircrete Blocks', 'Wall Ties & Cavity Insulation', 'Structural Steel Beams'],
    activeMachinery: [MachineType.TELEHANDLER, MachineType.SCAFFOLDING],
    activeTrades: [TradeType.BRICKLAYER, TradeType.CARPENTER]
  },
  {
    day: 105,
    title: 'Roof Trusses & Tiling',
    stage: ConstructionStage.ROOF,
    description: 'Tower crane hoists engineered timber roof trusses. Breathable membrane, treated battens, slate/concrete tiles laid, zinc gutters fixed.',
    costSpentToDate: 172000,
    materialsDelivered: ['FSC Timber Roof Trusses', 'Breathable Sarking Membrane', 'Marley Modern Roof Tiles', 'Zinc Gutters'],
    activeMachinery: [MachineType.TOWER_CRANE, MachineType.SCAFFOLDING],
    activeTrades: [TradeType.ROOFER, TradeType.CARPENTER]
  },
  {
    day: 130,
    title: 'Windows, Doors & Weathertight Envelope',
    stage: ConstructionStage.ENVELOPE,
    description: 'Triple-glazed aluminium windows and bifold doors installed with expanding airtight tapes. Building fully watertight envelope.',
    costSpentToDate: 204500,
    materialsDelivered: ['Triple Glazed Aluminium Windows', 'Composite Entrance Door', 'External Render Basecoat'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.CARPENTER, TradeType.BRICKLAYER]
  },
  {
    day: 160,
    title: '1st Fix MEP Services (Electrical & Plumbing)',
    stage: ConstructionStage.SERVICES,
    description: 'First fix electrical cable runs, consumer unit, PEX plumbing feeds, underfloor heating manifolds, MVHR ventilation ductwork.',
    costSpentToDate: 236800,
    materialsDelivered: ['Twin & Earth Cable Spools', 'Underfloor Heating Pipe 16mm', 'MVHR Ducting Kits', 'ASHP Outdoor Unit'],
    activeMachinery: [],
    activeTrades: [TradeType.ELECTRICIAN, TradeType.PLUMBER]
  },
  {
    day: 185,
    title: 'Insulation & Drylining / Plastering',
    stage: ConstructionStage.INTERNAL_FINISH,
    description: 'Acoustic partition insulation fitted, moisture resistant plasterboards hung, taped and two-coat skim plaster applied.',
    costSpentToDate: 262100,
    materialsDelivered: ['Acoustic Rockwool Insulation', '12.5mm Tapered Plasterboard', 'Thistle Multi-Finish Plaster'],
    activeMachinery: [],
    activeTrades: [TradeType.PLASTERER, TradeType.CARPENTER]
  },
  {
    day: 215,
    title: '2nd Fix Kitchen, Bathrooms & Flooring',
    stage: ConstructionStage.INTERNAL_FINISH,
    description: 'Luxury kitchen cabinetry, quartz countertops, sanitaryware suites, porcelain tiles, engineered herringbone flooring, paint decoration.',
    costSpentToDate: 295000,
    materialsDelivered: ['Kitchen Island & Units', 'Sanitaryware & Brassware', 'Oak Herringbone Flooring', 'Designer Radiators'],
    activeMachinery: [],
    activeTrades: [TradeType.CARPENTER, TradeType.PLUMBER, TradeType.ELECTRICIAN, TradeType.PAINTER]
  },
  {
    day: 235,
    title: 'Landscaping, Driveway & EV Setup',
    stage: ConstructionStage.LANDSCAPE,
    description: 'Permeable block paved driveway, timber acoustic boundary fence, turf lawn, solar PV commissioning, 22kW EV charger online.',
    costSpentToDate: 314600,
    materialsDelivered: ['Marshalls Permeable Block Paving', 'Turf Rolls & Topsoil', 'Solar PV 8kW Panels', 'EV Fast Charger'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.LANDSCAPER, TradeType.ELECTRICIAN]
  },
  {
    day: 240,
    title: 'Handover & Digital Twin Commissioning',
    stage: ConstructionStage.COMPLETE,
    description: 'Building Control completion certificate issued. EPC rating A certified. Full digital twin asset model handed to homeowner.',
    costSpentToDate: 319500,
    materialsDelivered: ['Smart Home Hub & Sensors'],
    activeMachinery: [],
    activeTrades: [TradeType.SITE_SUPERVISOR]
  }
];

// Initial BIM Components Catalog
export const GENERATE_BIM_COMPONENTS = (params: HouseParameters = DEFAULT_PARAMETERS): BimComponent[] => {
  const { widthM, lengthM, floors, roofType, claddingMaterial, hasSolarPanels, hasHeatPump, hasEVCharger, hasGarage } = params;

  return [
    // --- FOUNDATIONS & GROUND ---
    {
      id: 'FND-001',
      name: 'Reinforced Concrete Strip Footings (C35)',
      category: 'Foundation',
      startDay: 15,
      endDay: 28,
      stage: ConstructionStage.FOUNDATION,
      material: 'C35/45 Ready-Mix Concrete with B500B Rebar',
      dimensions: { lengthM: widthM + 1.2, widthM: lengthM + 1.2, heightM: 0.9, volumeM3: 42.5 },
      costs: { materials: 14200, labour: 8400, plant: 4200, total: 26800 },
      embodiedCarbonKg: 8200,
      supplier: 'Cemex UK Infrastructure',
      warrantyYears: 60,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.GROUNDWORKER,
      machineRequired: MachineType.CONCRETE_MIXER,
      position: [0, -0.45, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'foundations'
    },
    {
      id: 'FND-002',
      name: 'Sub-base MOT Type 1 & 150mm PIR Insulation',
      category: 'Foundation',
      startDay: 28,
      endDay: 38,
      stage: ConstructionStage.FOUNDATION,
      material: 'Compacted MOT Type 1 Crushed Aggregate & Kingspan TF70 PIR',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 0.3, areaM2: widthM * lengthM },
      costs: { materials: 6800, labour: 3400, plant: 1200, total: 11400 },
      embodiedCarbonKg: 1450,
      uValue: 0.12,
      supplier: 'Kingspan Insulation UK',
      warrantyYears: 30,
      expectedLifeYears: 60,
      maintenanceIntervalMonths: 240,
      tradeRequired: TradeType.GROUNDWORKER,
      position: [0, 0.05, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'foundations'
    },
    {
      id: 'FND-003',
      name: 'Power-Floated Reinforced Ground Slab & DPM',
      category: 'Foundation',
      startDay: 35,
      endDay: 45,
      stage: ConstructionStage.GROUND_FLOOR,
      material: 'Power-Floated Reinforced Concrete C30 with Visqueen 1200g DPM',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 0.15, areaM2: widthM * lengthM, volumeM3: widthM * lengthM * 0.15 },
      costs: { materials: 9400, labour: 5600, plant: 2200, total: 17200 },
      embodiedCarbonKg: 3800,
      supplier: 'Tarmac PowerSlab Ltd',
      warrantyYears: 50,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.GROUNDWORKER,
      machineRequired: MachineType.CONCRETE_MIXER,
      position: [0, 0.2, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'floors'
    },

    // --- SUPERSTRUCTURE WALLS ---
    {
      id: 'STR-001',
      name: 'Ground Floor External Facade & Cavity Wall',
      category: 'Structure',
      startDay: 46,
      endDay: 75,
      stage: ConstructionStage.STRUCTURE,
      material: claddingMaterial === 'BRICK_RED' ? 'Ibstock Red Multi Brick + 100mm Cavity Batts + Aircrete Inner Leaf' :
                claddingMaterial === 'STONE_COTSWOLD' ? 'Cotswold Dressed Natural Stone + Cavity Insulation' :
                claddingMaterial === 'TIMBER_LARCH' ? 'Siberian Larch Rain-screen Cladding + Timber Stud Frame' :
                claddingMaterial === 'DARK_ZINC' ? 'VMZINC Standing Seam Anthra-Zinc' : 'K-Rend Silicone Thin-Coat Render',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 2.8, areaM2: 2 * (widthM + lengthM) * 2.8 },
      costs: { materials: 22400, labour: 18600, plant: 3400, total: 44400 },
      embodiedCarbonKg: 5200,
      uValue: 0.15,
      supplier: 'Ibstock Brick / Forterra UK',
      warrantyYears: 30,
      expectedLifeYears: 80,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.BRICKLAYER,
      machineRequired: MachineType.TELEHANDLER,
      position: [0, 1.6, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'structure'
    },
    {
      id: 'STR-002',
      name: 'Intermediate Floor Structure (Posi-Joists & 22mm Weyroc)',
      category: 'Structure',
      startDay: 72,
      endDay: 84,
      stage: ConstructionStage.STRUCTURE,
      material: 'Engineered Timber Metal-Web Posi-Joists & Moisture-Resistant Tongue & Groove Deck',
      dimensions: { lengthM: widthM - 0.4, widthM: lengthM - 0.4, heightM: 0.25, areaM2: (widthM - 0.4) * (lengthM - 0.4) },
      costs: { materials: 8600, labour: 5200, plant: 1100, total: 14900 },
      embodiedCarbonKg: 1100,
      supplier: 'MiTek Engineered Timber Systems',
      warrantyYears: 30,
      expectedLifeYears: 75,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.CARPENTER,
      position: [0, 3.0, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'floors'
    },
    {
      id: 'STR-003',
      name: 'First Floor External Superstructure Walls',
      category: 'Structure',
      startDay: 80,
      endDay: 104,
      stage: ConstructionStage.STRUCTURE,
      material: 'Masonry & Timber Stud Inner Leaf with External Cladding',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 2.7, areaM2: 2 * (widthM + lengthM) * 2.7 },
      costs: { materials: 19800, labour: 16200, plant: 2900, total: 38900 },
      embodiedCarbonKg: 4600,
      uValue: 0.15,
      supplier: 'Ibstock / Celcon Blocks',
      warrantyYears: 30,
      expectedLifeYears: 80,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.BRICKLAYER,
      machineRequired: MachineType.SCAFFOLDING,
      position: [0, 4.45, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'structure'
    },

    // --- ROOF ---
    {
      id: 'ROOF-001',
      name: 'Engineered FSC Timber Roof Trusses & Structural Bracing',
      category: 'Roof',
      startDay: 102,
      endDay: 116,
      stage: ConstructionStage.ROOF,
      material: 'C24 Graded FSC Timber Prefabricated Trusses & Galvanised Gang-Nail Plates',
      dimensions: { lengthM: widthM + 0.6, widthM: lengthM + 0.6, heightM: 2.5, areaM2: (widthM + 0.6) * (lengthM + 0.6) * 1.3 },
      costs: { materials: 14500, labour: 7800, plant: 4500, total: 26800 },
      embodiedCarbonKg: 950,
      supplier: 'Donaldson Timber Engineering',
      warrantyYears: 30,
      expectedLifeYears: 60,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.ROOFER,
      machineRequired: MachineType.TOWER_CRANE,
      position: [0, 6.7, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'roof'
    },
    {
      id: 'ROOF-002',
      name: 'Roof Tiles, Breathable Membrane, Battens & Gutters',
      category: 'Roof',
      startDay: 112,
      endDay: 128,
      stage: ConstructionStage.ROOF,
      material: 'Marley Modern Anthracite Interlocking Tiles, Tyvek Membrane, Treated Battens',
      dimensions: { lengthM: widthM + 0.8, widthM: lengthM + 0.8, heightM: 2.6, areaM2: (widthM + 0.8) * (lengthM + 0.8) * 1.35 },
      costs: { materials: 11200, labour: 8900, plant: 1800, total: 21900 },
      embodiedCarbonKg: 2100,
      uValue: 0.11,
      supplier: 'Marley Roofing UK',
      warrantyYears: 25,
      expectedLifeYears: 50,
      maintenanceIntervalMonths: 36,
      tradeRequired: TradeType.ROOFER,
      machineRequired: MachineType.SCAFFOLDING,
      position: [0, 6.8, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'roof'
    },

    // --- ENVELOPE (WINDOWS & DOORS) ---
    {
      id: 'ENV-001',
      name: 'High Performance Triple-Glazed Aluminium Windows (14 Units)',
      category: 'Envelope',
      startDay: 125,
      endDay: 138,
      stage: ConstructionStage.ENVELOPE,
      material: 'Thermally Broken Powder-Coated Aluminium RAL 7016 with Argon Gas Filled Triple Glazing',
      dimensions: { lengthM: 1.4, widthM: 0.2, heightM: 1.6, areaM2: 24.5 },
      costs: { materials: 18400, labour: 4600, plant: 800, total: 23800 },
      embodiedCarbonKg: 1800,
      uValue: 0.8,
      supplier: 'Velfac / Rationel Windows',
      warrantyYears: 12,
      expectedLifeYears: 35,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.CARPENTER,
      position: [0, 3.2, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'envelope'
    },
    {
      id: 'ENV-002',
      name: 'Architectural Aluminium Bifold Doors & Insulated Front Door',
      category: 'Envelope',
      startDay: 132,
      endDay: 142,
      stage: ConstructionStage.ENVELOPE,
      material: 'Origin 4-Pane Aluminium Bifold Doors & Solid Core Composite Front Door',
      dimensions: { lengthM: 3.6, widthM: 0.2, heightM: 2.2, areaM2: 7.9 },
      costs: { materials: 7600, labour: 2400, plant: 400, total: 10400 },
      embodiedCarbonKg: 950,
      uValue: 1.1,
      supplier: 'Origin Global Doors UK',
      warrantyYears: 20,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.CARPENTER,
      position: [0, 1.3, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'envelope'
    },

    // --- MEP SERVICES ---
    {
      id: 'MEP-001',
      name: '1st & 2nd Fix Electrical Distribution, LED Lighting & Smart Hub',
      category: 'MEP_Electrical',
      startDay: 145,
      endDay: 205,
      stage: ConstructionStage.SERVICES,
      material: 'Hager Dual RCD Consumer Unit, Low-Smoke Zero-Halogen Cabling, BG Brushed Steel Accessories',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 5.5 },
      costs: { materials: 8900, labour: 12400, plant: 600, total: 21900 },
      embodiedCarbonKg: 850,
      supplier: 'Hager Electrical UK & Rexel',
      warrantyYears: 10,
      expectedLifeYears: 25,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.ELECTRICIAN,
      position: [0, 2.5, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },
    {
      id: 'MEP-002',
      name: 'Underfloor Heating, Unvented Cylinder & Plumbing Feeds',
      category: 'MEP_Plumbing',
      startDay: 150,
      endDay: 210,
      stage: ConstructionStage.SERVICES,
      material: 'Uponor PEX-a Pipe Loops, Brass Manifolds, Telford 250L Tempest Stainless Hot Water Cylinder',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 4.5 },
      costs: { materials: 11400, labour: 9800, plant: 500, total: 21700 },
      embodiedCarbonKg: 780,
      supplier: 'Uponor Building Solutions / Telford Cylinders',
      warrantyYears: 25,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.PLUMBER,
      position: [0, 2.0, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },
    {
      id: 'MEP-003',
      name: 'Air Source Heat Pump (ASHP 8.5kW) & MVHR Heat Recovery Ventilation',
      category: 'MEP_HVAC',
      startDay: 165,
      endDay: 215,
      stage: ConstructionStage.SERVICES,
      material: 'Vaillant aroTHERM plus Air-to-Water Heat Pump with R290 refrigerant & Brink MVHR Unit',
      dimensions: { lengthM: 1.2, widthM: 0.6, heightM: 1.0 },
      costs: { materials: 9800, labour: 4200, plant: 600, total: 14600 },
      embodiedCarbonKg: 620,
      supplier: 'Vaillant Group UK',
      warrantyYears: 7,
      expectedLifeYears: 18,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.PLUMBER,
      position: [widthM / 2 + 0.8, 0.6, -lengthM / 4],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },

    // --- RENEWABLES & SMART ENERGY ---
    {
      id: 'REN-001',
      name: 'In-Roof Solar PV Array (6.8kWp) & 10.4kWh Home Battery Storage',
      category: 'Renewable',
      startDay: 175,
      endDay: 220,
      stage: ConstructionStage.SERVICES,
      material: 'Viridian Solar Clearline Fusion In-Roof Panels & GivEnergy Hybrid Inverter + LiFePO4 Battery',
      dimensions: { lengthM: 4.8, widthM: 0.1, heightM: 3.2, areaM2: 15.3 },
      costs: { materials: 11200, labour: 3600, plant: 800, total: 15600 },
      embodiedCarbonKg: 1200,
      supplier: 'Viridian Solar / GivEnergy',
      warrantyYears: 25,
      expectedLifeYears: 25,
      maintenanceIntervalMonths: 24,
      tradeRequired: TradeType.ELECTRICIAN,
      position: [0, 7.2, lengthM / 4],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'roof'
    },

    // --- INTERIOR FINISHES ---
    {
      id: 'INT-001',
      name: 'Drylining, Sound Insulation, Plasterboard & Skim Coat',
      category: 'Interior',
      startDay: 180,
      endDay: 205,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'British Gypsum Gyproc SoundBloc & Multi-finish Thistle Plaster',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 5.5, areaM2: 380 },
      costs: { materials: 7400, labour: 14200, plant: 400, total: 22000 },
      embodiedCarbonKg: 1600,
      supplier: 'British Gypsum Saint-Gobain',
      warrantyYears: 10,
      expectedLifeYears: 40,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.PLASTERER,
      position: [0, 2.8, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-002',
      name: 'Bespoke Island Kitchen with Quartz Tops & Integrated Bosch Appliances',
      category: 'Interior',
      startDay: 206,
      endDay: 224,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'Handleless Anthracite Matte Cabinetry, 30mm Calacatta Quartz Worktops, Bosch 800 Series',
      dimensions: { lengthM: 3.8, widthM: 2.6, heightM: 2.2 },
      costs: { materials: 18900, labour: 4500, plant: 200, total: 23600 },
      embodiedCarbonKg: 1100,
      supplier: 'Wren Kitchens / Silestone Quartz',
      warrantyYears: 15,
      expectedLifeYears: 20,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.CARPENTER,
      position: [-2.2, 0.8, -1.8],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-003',
      name: 'Luxury Bathrooms (3 Suites) & Porcelain Wall/Floor Tiling',
      category: 'Interior',
      startDay: 208,
      endDay: 226,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'Crosswater Concealed Valves, Freestanding Mineral Cast Bath, 1200x600 Porcelain Tiles',
      dimensions: { lengthM: 3.2, widthM: 2.4, heightM: 2.4 },
      costs: { materials: 12400, labour: 6800, plant: 300, total: 19500 },
      embodiedCarbonKg: 950,
      supplier: 'Crosswater London / Porcelanosa',
      warrantyYears: 15,
      expectedLifeYears: 20,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.PLUMBER,
      position: [2.2, 3.8, 1.6],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-004',
      name: 'Engineered Oak Herringbone Flooring & Internal Solid Core Doors',
      category: 'Interior',
      startDay: 218,
      endDay: 232,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: '15mm Brushed Natural Oak Engineered Herringbone Parquet & Deanta Oak Doors',
      dimensions: { lengthM: widthM, widthM: lengthM, heightM: 0.02, areaM2: widthM * lengthM * 1.8 },
      costs: { materials: 10800, labour: 5400, plant: 300, total: 16500 },
      embodiedCarbonKg: 550,
      supplier: 'Havwoods Wood Flooring UK',
      warrantyYears: 25,
      expectedLifeYears: 40,
      maintenanceIntervalMonths: 24,
      tradeRequired: TradeType.CARPENTER,
      position: [0, 0.25, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },

    // --- LANDSCAPING & EXTERNAL ---
    {
      id: 'LND-001',
      name: 'Permeable Block Paved Driveway & 22kW Untethered EV Charger',
      category: 'Landscape',
      startDay: 222,
      endDay: 236,
      stage: ConstructionStage.LANDSCAPE,
      material: 'Marshalls Priora Permeable Concrete Setts & Pod Point 22kW Fast Charger',
      dimensions: { lengthM: 5.5, widthM: 4.8, heightM: 0.15, areaM2: 26.4 },
      costs: { materials: 6400, labour: 4200, plant: 1200, total: 11800 },
      embodiedCarbonKg: 1300,
      supplier: 'Marshalls Commercial Paving / PodPoint UK',
      warrantyYears: 10,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 24,
      tradeRequired: TradeType.LANDSCAPER,
      position: [3.5, 0.05, 4.5],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'landscape'
    },
    {
      id: 'LND-002',
      name: 'Rear Porcelain Patio, Turf Lawn & Boundary Acoustic Fencing',
      category: 'Landscape',
      startDay: 225,
      endDay: 238,
      stage: ConstructionStage.LANDSCAPE,
      material: '20mm Exterior Grip Porcelain Slabs, Rolawn Medallion Turf, Jacksons Hit & Miss Fencing',
      dimensions: { lengthM: widthM + 4, widthM: lengthM + 6, heightM: 1.8, areaM2: (widthM + 4) * (lengthM + 6) },
      costs: { materials: 8200, labour: 5800, plant: 900, total: 14900 },
      embodiedCarbonKg: 850,
      supplier: 'Jacksons Fencing / Rolawn UK',
      warrantyYears: 25,
      expectedLifeYears: 25,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.LANDSCAPER,
      position: [0, 0.02, -5.5],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'landscape'
    }
  ];
};

// Material Stock DB
export const INITIAL_MATERIAL_STOCK: MaterialStock[] = [
  { id: 'MAT-BRICK', name: 'Facing Bricks (Class B)', unit: 'bricks', totalRequired: 18500, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 0.95, category: 'Structure' },
  { id: 'MAT-BLOCK', name: 'Thermalite Aircrete Blocks', unit: 'blocks', totalRequired: 3400, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 2.20, category: 'Structure' },
  { id: 'MAT-CONCRETE', name: 'Ready-Mix Concrete C35', unit: 'm³', totalRequired: 68, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 135, category: 'Foundation' },
  { id: 'MAT-STEEL', name: 'Reinforcement Steel & RSJs', unit: 'tonnes', totalRequired: 6.2, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 1450, category: 'Structure' },
  { id: 'MAT-TIMBER', name: 'C24 Structural Timber & Trusses', unit: 'tonnes', totalRequired: 8.5, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 1280, category: 'Roof' },
  { id: 'MAT-TILES', name: 'Marley Anthracite Roof Tiles', unit: 'tiles', totalRequired: 2200, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 2.40, category: 'Roof' },
  { id: 'MAT-WINDOWS', name: 'Aluminium Triple Glazed Units', unit: 'units', totalRequired: 16, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 1150, category: 'Envelope' },
  { id: 'MAT-INSULATION', name: 'PIR & Mineral Wool Insulation', unit: 'm²', totalRequired: 420, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 28, category: 'Envelope' },
  { id: 'MAT-SOLAR', name: 'In-Roof Solar PV Modules (400W)', unit: 'panels', totalRequired: 17, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 260, category: 'Renewable' },
  { id: 'MAT-UFH', name: '16mm PEX Underfloor Heating Pipe', unit: 'metres', totalRequired: 680, deliveredToDate: 0, installedToDate: 0, unitCostGbp: 1.80, category: 'MEP' }
];

// Room-by-Room list with initial status
export const ROOMS_CONFIG: RoomBuildStatus[] = [
  { id: 'ROOM-KITCHEN', name: 'Kitchen & Dining Island', floor: 0, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-LIVING', name: 'Open Plan Living Room', floor: 0, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-MASTER_BED', name: 'Master Bedroom & Dressing', floor: 1, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-BATHROOM', name: 'Family Bathroom & En-Suite', floor: 1, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-BEDROOM_2', name: 'Guest Bedroom 2', floor: 1, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-UTILITY', name: 'Plant / Utility Room', floor: 0, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-GARAGE', name: 'EV Garage & Workshop', floor: 0, structure: 0, electrical: 0, plumbing: 0, plaster: 0, flooring: 0, decoration: 0, overall: 0 }
];

// Masterplan Estate Plots (1 to 24 plots)
export const GENERATE_MASTERPLAN_PLOTS = (count: number = 8): MasterplanPlot[] => {
  const plotTypes = ['The Oakwood (4-Bed Detached)', 'The Somerville (3-Bed Semi)', 'The Aspen (5-Bed Executive)', 'The Birch (3-Bed Townhouse)'];
  const stagesList = [
    { stage: ConstructionStage.LANDSCAPE, day: 232, progress: 96 },
    { stage: ConstructionStage.INTERNAL_FINISH, day: 210, progress: 87 },
    { stage: ConstructionStage.SERVICES, day: 168, progress: 70 },
    { stage: ConstructionStage.ENVELOPE, day: 135, progress: 56 },
    { stage: ConstructionStage.ROOF, day: 110, progress: 45 },
    { stage: ConstructionStage.STRUCTURE, day: 78, progress: 32 },
    { stage: ConstructionStage.GROUND_FLOOR, day: 42, progress: 18 },
    { stage: ConstructionStage.FOUNDATION, day: 24, progress: 10 },
    { stage: ConstructionStage.GROUNDWORK, day: 8, progress: 4 },
    { stage: ConstructionStage.SITE, day: 0, progress: 0 }
  ];

  const plots: MasterplanPlot[] = [];
  const cols = 4;
  for (let i = 0; i < count; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const stageInfo = stagesList[i % stagesList.length];
    plots.push({
      id: i + 1,
      plotNumber: `PLOT ${String(i + 1).padStart(2, '0')}`,
      houseType: plotTypes[i % plotTypes.length],
      currentDay: stageInfo.day,
      stage: stageInfo.stage,
      progressPercent: stageInfo.progress,
      positionOffset: [(col - 1.5) * 16, 0, (row - 1) * 22],
      targetCompletionDays: 240,
      budgetSpent: Math.round(stageInfo.progress * 3195)
    });
  }
  return plots;
};

// Whole-Life Maintenance Schedule (1 to 30 years)
export const WHOLE_LIFE_MAINTENANCE_SCHEDULE: MaintenanceItem[] = [
  { year: 1, componentId: 'MEP-003', componentName: 'Air Source Heat Pump', actionRequired: 'Initial 12-month manufacturer refrigerant & COP performance audit', estimatedCost: 180, urgency: 'ROUTINE', status: 'SCHEDULED' },
  { year: 2, componentId: 'MEP-002', componentName: 'Unvented Cylinder', actionRequired: 'Pressure relief valve test & expansion vessel recharge', estimatedCost: 140, urgency: 'ROUTINE', status: 'SCHEDULED' },
  { year: 5, componentId: 'ENV-001', componentName: 'Aluminium Windows & Bi-folds', actionRequired: 'Perimeter silicone joint inspection and gasket lubrication', estimatedCost: 350, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 7, componentId: 'MEP-003', componentName: 'Heat Pump Outdoor Unit', actionRequired: 'Compressor inverter check & fan motor bearing service', estimatedCost: 650, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 10, componentId: 'MEP-001', componentName: 'Consumer Unit / EICR', actionRequired: '10-Year Electrical Installation Condition Report & RCD testing', estimatedCost: 450, urgency: 'CRITICAL', status: 'PENDING' },
  { year: 10, componentId: 'REN-001', componentName: 'Home Battery Storage', actionRequired: 'LiFePO4 battery pack capacity test & BMS firmware optimization', estimatedCost: 400, urgency: 'ROUTINE', status: 'PENDING' },
  { year: 15, componentId: 'INT-002', componentName: 'Kitchen Appliances', actionRequired: 'Scheduled replacement of induction hob & steam oven', estimatedCost: 2200, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 18, componentId: 'MEP-003', componentName: 'Heat Pump Replacement', actionRequired: 'Full generation heat pump unit upgrade to latest seasonal COP standard', estimatedCost: 5500, urgency: 'CRITICAL', status: 'PENDING' },
  { year: 20, componentId: 'ROOF-002', componentName: 'Roof Flashing & Ridges', actionRequired: 'Lead flashing reseal and dry ridge system inspection', estimatedCost: 1200, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 25, componentId: 'REN-001', componentName: 'Solar PV Inverter', actionRequired: 'Hybrid solar inverter renewal & PV cell cleaning', estimatedCost: 2400, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 30, componentId: 'LND-001', componentName: 'Permeable Driveway', actionRequired: 'Aggregate joint vacuuming and sub-base re-sanding', estimatedCost: 1800, urgency: 'ROUTINE', status: 'PENDING' }
];

/**
 * Calculates current construction stage based on currentDay
 */
export function getStageFromDay(day: number): ConstructionStage {
  if (day <= 5) return ConstructionStage.SITE;
  if (day <= 18) return ConstructionStage.GROUNDWORK;
  if (day <= 38) return ConstructionStage.FOUNDATION;
  if (day <= 50) return ConstructionStage.GROUND_FLOOR;
  if (day <= 90) return ConstructionStage.STRUCTURE;
  if (day <= 120) return ConstructionStage.ROOF;
  if (day <= 145) return ConstructionStage.ENVELOPE;
  if (day <= 180) return ConstructionStage.SERVICES;
  if (day <= 215) return ConstructionStage.INTERNAL_FINISH;
  if (day <= 230) return ConstructionStage.EXTERNAL_FINISH;
  if (day <= 239) return ConstructionStage.LANDSCAPE;
  return ConstructionStage.COMPLETE;
}

/**
 * Calculates overall progress percentage (0 - 100)
 */
export function calculateOverallProgress(day: number): number {
  return Math.min(100, Math.max(0, Math.round((day / 240) * 100)));
}

/**
 * Calculate component state given current day
 */
export function getComponentStateAtDay(component: BimComponent, currentDay: number): { state: ComponentState; progress: number } {
  if (currentDay < component.startDay) {
    return { state: ComponentState.NOT_STARTED, progress: 0 };
  }
  if (currentDay >= component.endDay) {
    return { state: ComponentState.COMPLETE, progress: 1.0 };
  }
  const span = component.endDay - component.startDay;
  const elapsed = currentDay - component.startDay;
  const progress = Math.min(1.0, Math.max(0.0, elapsed / span));
  return {
    state: progress >= 0.9 ? ComponentState.INSTALLED : ComponentState.UNDER_CONSTRUCTION,
    progress
  };
}

/**
 * Calculate total spent budget up to current day
 */
export function calculateBudgetSpent(day: number, components: BimComponent[]): { spent: number; total: number; remaining: number } {
  let spent = 0;
  let total = 0;
  for (const comp of components) {
    total += comp.costs.total;
    const { progress } = getComponentStateAtDay(comp, day);
    spent += comp.costs.total * progress;
  }
  return {
    spent: Math.round(spent),
    total: Math.round(total),
    remaining: Math.max(0, Math.round(total - spent))
  };
}

/**
 * Calculate Room progress matrix at current day
 */
export function calculateRoomsProgress(day: number): RoomBuildStatus[] {
  return ROOMS_CONFIG.map(room => {
    // Structure: complete by Day 95
    const structure = Math.min(100, Math.max(0, Math.round((day / 95) * 100)));
    // Electrical 1st + 2nd fix: Day 140 to 215
    const electrical = day < 140 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 140) / 75) * 100)));
    // Plumbing: Day 150 to 220
    const plumbing = day < 150 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 150) / 70) * 100)));
    // Plaster: Day 175 to 205
    const plaster = day < 175 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 175) / 30) * 100)));
    // Flooring: Day 215 to 230
    const flooring = day < 215 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 215) / 15) * 100)));
    // Decoration: Day 220 to 238
    const decoration = day < 220 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 220) / 18) * 100)));

    const overall = Math.round((structure * 0.25) + (electrical * 0.15) + (plumbing * 0.15) + (plaster * 0.15) + (flooring * 0.15) + (decoration * 0.15));

    return {
      ...room,
      structure,
      electrical,
      plumbing,
      plaster,
      flooring,
      decoration,
      overall
    };
  });
}

/**
 * Calculate dynamic material stock delivered vs installed
 */
export function calculateMaterialStock(day: number): MaterialStock[] {
  return INITIAL_MATERIAL_STOCK.map(mat => {
    // Logistics delivery happens ~10-15 days ahead of installation
    let deliveryFactor = 0;
    let installFactor = 0;

    if (mat.id === 'MAT-CONCRETE') {
      deliveryFactor = day > 10 ? Math.min(1, day / 45) : 0;
      installFactor = day > 15 ? Math.min(1, (day - 15) / 35) : 0;
    } else if (mat.id === 'MAT-BRICK' || mat.id === 'MAT-BLOCK' || mat.id === 'MAT-STEEL') {
      deliveryFactor = day > 35 ? Math.min(1, (day - 35) / 50) : 0;
      installFactor = day > 45 ? Math.min(1, (day - 45) / 50) : 0;
    } else if (mat.id === 'MAT-TIMBER' || mat.id === 'MAT-TILES') {
      deliveryFactor = day > 85 ? Math.min(1, (day - 85) / 35) : 0;
      installFactor = day > 100 ? Math.min(1, (day - 100) / 25) : 0;
    } else if (mat.id === 'MAT-WINDOWS' || mat.id === 'MAT-INSULATION') {
      deliveryFactor = day > 115 ? Math.min(1, (day - 115) / 25) : 0;
      installFactor = day > 125 ? Math.min(1, (day - 125) / 20) : 0;
    } else {
      deliveryFactor = day > 140 ? Math.min(1, (day - 140) / 70) : 0;
      installFactor = day > 155 ? Math.min(1, (day - 155) / 65) : 0;
    }

    return {
      ...mat,
      deliveredToDate: Math.round(mat.totalRequired * deliveryFactor),
      installedToDate: Math.round(mat.totalRequired * installFactor)
    };
  });
}
