/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Core 3D WebGL Construction Simulation Engine
 */

import * as THREE from 'three';
import {
  BimComponent,
  CameraPreset,
  ComponentState,
  ConstructionStage,
  HouseParameters,
  SimulationState,
  TimeOfDay,
  ViewMode,
  WeatherType
} from '../types/simulation';
import { MachineryEngine } from './machinery';
import { WorkerSimulationEngine } from './workers';

export class ConstructionSceneEngine {
  public container: HTMLElement;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;

  // Camera & Orbit state
  private isMouseDown = false;
  private mousePrev = { x: 0, y: 0 };
  public cameraTarget = new THREE.Vector3(0, 2.5, 0);
  public cameraRadius = 18;
  public cameraTheta = Math.PI / 4; // Horizontal angle
  public cameraPhi = Math.PI / 4;   // Vertical elevation
  private targetCameraPos = new THREE.Vector3();
  private isCinematicDrone = false;

  // Sub-systems
  public machinery: MachineryEngine;
  public workers: WorkerSimulationEngine;

  // Lighting
  private sunLight: THREE.DirectionalLight;
  private ambientLight: THREE.AmbientLight;
  private siteFloodLights: THREE.Group;
  private houseInteriorLights: THREE.Group;

  // Weather & Particles
  private rainParticles?: THREE.Points;
  private snowParticles?: THREE.Points;
  private mepFlowParticles?: THREE.Points;
  private energyFlowParticles?: THREE.Points;

  // Geometry groups for stages & exploded view
  public groundGroup: THREE.Group;
  public foundationGroup: THREE.Group;
  public groundFloorGroup: THREE.Group;
  public wallsGroup: THREE.Group;
  public firstFloorGroup: THREE.Group;
  public roofGroup: THREE.Group;
  public envelopeGroup: THREE.Group;
  public mepGroup: THREE.Group;
  public interiorGroup: THREE.Group;
  public landscapeGroup: THREE.Group;
  public masterplanGroup: THREE.Group;

  // Dynamic meshes
  private brickMeshes: THREE.Mesh[] = [];
  private roofTileMeshes: THREE.Mesh[] = [];
  private ufhPipeGroup: THREE.Group;
  private ashpFanMesh?: THREE.Mesh;
  private concretePourMesh?: THREE.Mesh;

  // Raycasting & Selection
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  public hoveredComponentId: string | null = null;
  public onSelectComponent?: (id: string | null) => void;
  private componentMeshMap = new Map<string, THREE.Object3D[]>();

  // Dimensioning
  public dimensionPoints: THREE.Vector3[] = [];
  private dimensionLineGroup: THREE.Group;
  public onDistanceMeasured?: (distanceM: number) => void;

  // Animation frame tracking
  private clock = new THREE.Clock();
  private animFrameId: number | null = null;
  public isDisposed = false;

  constructor(container: HTMLElement) {
    this.container = container;

    // 1. Scene & Renderer
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0f172a); // Slate-900 canvas
    this.scene.fog = new THREE.FogExp2(0x0f172a, 0.018);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;
    container.appendChild(this.renderer.domElement);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 500);
    this.updateCameraTransform();

    // 3. Lighting
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xfffbeb, 1.8);
    this.sunLight.position.set(20, 35, 20);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 100;
    const d = 22;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.scene.add(this.sunLight);

    this.siteFloodLights = new THREE.Group();
    this.scene.add(this.siteFloodLights);

    this.houseInteriorLights = new THREE.Group();
    this.scene.add(this.houseInteriorLights);

    // 4. Geometry Root Groups
    this.groundGroup = new THREE.Group();
    this.foundationGroup = new THREE.Group();
    this.groundFloorGroup = new THREE.Group();
    this.wallsGroup = new THREE.Group();
    this.firstFloorGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.envelopeGroup = new THREE.Group();
    this.mepGroup = new THREE.Group();
    this.interiorGroup = new THREE.Group();
    this.landscapeGroup = new THREE.Group();
    this.masterplanGroup = new THREE.Group();
    this.ufhPipeGroup = new THREE.Group();
    this.dimensionLineGroup = new THREE.Group();

    this.scene.add(
      this.groundGroup,
      this.foundationGroup,
      this.groundFloorGroup,
      this.wallsGroup,
      this.firstFloorGroup,
      this.roofGroup,
      this.envelopeGroup,
      this.mepGroup,
      this.interiorGroup,
      this.landscapeGroup,
      this.masterplanGroup,
      this.ufhPipeGroup,
      this.dimensionLineGroup
    );

    // 5. Machinery & Workers
    this.machinery = new MachineryEngine();
    this.workers = new WorkerSimulationEngine();
    this.scene.add(
      this.machinery.excavatorGroup,
      this.machinery.craneGroup,
      this.machinery.mixerGroup,
      this.machinery.telehandlerGroup,
      this.machinery.scaffoldingGroup,
      this.machinery.dumpTruckGroup,
      this.workers.rootGroup
    );

    // 6. Build Initial House Meshes
    this.buildGroundAndSite();
    this.buildHouseGeometry(undefined, 'BRICK_RED');
    this.initWeatherParticles();
    this.initMepFlowParticles();

    // 7. Event listeners
    this.setupEventListeners();

    // 8. Start Render Loop
    this.animate();
  }

  // --- 3D HOUSE PROCEDURAL BUILDER ---
  public buildHouseGeometry(params: HouseParameters = {
    widthM: 9.6,
    lengthM: 8.4,
    floors: 2,
    roofType: 'GABLE',
    claddingMaterial: 'BRICK_RED',
    hasSolarPanels: true,
    hasHeatPump: true,
    hasEVCharger: true,
    hasGarage: true,
    bedroomCount: 4,
    bathroomCount: 3
  }, materialKey: string = 'BRICK_RED') {
    // Clear existing groups
    [
      this.foundationGroup,
      this.groundFloorGroup,
      this.wallsGroup,
      this.firstFloorGroup,
      this.roofGroup,
      this.envelopeGroup,
      this.mepGroup,
      this.interiorGroup,
      this.landscapeGroup,
      this.ufhPipeGroup
    ].forEach(g => {
      while (g.children.length > 0) {
        g.remove(g.children[0]);
      }
    });

    this.componentMeshMap.clear();
    this.brickMeshes = [];
    this.roofTileMeshes = [];

    const { widthM: w, lengthM: l } = params;

    // Materials Palette
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.8 });
    const insulationMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.9 });
    const rebarMat = new THREE.MeshStandardMaterial({ color: 0x71717a, metalness: 0.8, roughness: 0.3 });
    const timberJoistMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.7 });
    const timberFloorMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.6 });

    // Cladding color based on selection
    let wallColor = 0x991b1b; // Default Red Brick
    if (materialKey === 'STONE_COTSWOLD') wallColor = 0xd6cbb8;
    else if (materialKey === 'TIMBER_LARCH') wallColor = 0xc28d57;
    else if (materialKey === 'WHITE_RENDER') wallColor = 0xf1f5f9;
    else if (materialKey === 'DARK_ZINC') wallColor = 0x334155;

    const facadeMat = new THREE.MeshStandardMaterial({ color: wallColor, roughness: 0.7 });
    const blockInnerMat = new THREE.MeshStandardMaterial({ color: 0xcfd8dc, roughness: 0.9 });
    const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xbae6fd, transparent: true, opacity: 0.5, roughness: 0.1, metalness: 0.1 });
    const windowFrameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.6 });
    const roofSlateMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 });
    const solarPvMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.2, metalness: 0.8 });

    // 1. FOUNDATIONS (Rebar & Concrete Strip Footings)
    const footingGeo = new THREE.BoxGeometry(w + 0.8, 0.7, l + 0.8);
    const footingMesh = new THREE.Mesh(footingGeo, concreteMat);
    footingMesh.position.set(0, -0.35, 0);
    footingMesh.castShadow = true;
    footingMesh.receiveShadow = true;
    this.foundationGroup.add(footingMesh);
    this.registerMeshForBim('FND-001', footingMesh);

    // Rebar Cage
    const rebarCage = new THREE.Mesh(new THREE.BoxGeometry(w + 0.6, 0.4, l + 0.6), rebarMat);
    rebarCage.position.set(0, -0.3, 0);
    this.foundationGroup.add(rebarCage);

    // Sub-base & PIR Insulation
    const pirMesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.15, l), insulationMat);
    pirMesh.position.set(0, 0.08, 0);
    this.foundationGroup.add(pirMesh);
    this.registerMeshForBim('FND-002', pirMesh);

    // 2. GROUND FLOOR SLAB
    const slabMesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.18, l), concreteMat);
    slabMesh.position.set(0, 0.22, 0);
    slabMesh.receiveShadow = true;
    this.groundFloorGroup.add(slabMesh);
    this.registerMeshForBim('FND-003', slabMesh);

    // Underfloor Heating Grid on Ground Floor
    const ufhLoopMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    for (let x = -w / 2 + 0.5; x <= w / 2 - 0.5; x += 0.4) {
      const ufhPipe = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, l - 1.0), ufhLoopMat);
      ufhPipe.rotation.x = Math.PI / 2;
      ufhPipe.position.set(x, 0.32, 0);
      this.ufhPipeGroup.add(ufhPipe);
    }
    this.groundFloorGroup.add(this.ufhPipeGroup);

    // 3. GROUND FLOOR WALLS (Course-by-course brickwork elevation)
    const wallThick = 0.32;
    const gfHeight = 2.7;

    // Outer & Inner Leaf Walls
    const wallLeft = new THREE.Mesh(new THREE.BoxGeometry(wallThick, gfHeight, l), facadeMat);
    wallLeft.position.set(-w / 2 + wallThick / 2, 0.31 + gfHeight / 2, 0);
    wallLeft.castShadow = true;

    const wallRight = new THREE.Mesh(new THREE.BoxGeometry(wallThick, gfHeight, l), facadeMat);
    wallRight.position.set(w / 2 - wallThick / 2, 0.31 + gfHeight / 2, 0);
    wallRight.castShadow = true;

    const wallBack = new THREE.Mesh(new THREE.BoxGeometry(w - wallThick * 2, gfHeight, wallThick), facadeMat);
    wallBack.position.set(0, 0.31 + gfHeight / 2, -l / 2 + wallThick / 2);
    wallBack.castShadow = true;

    // Front wall with opening for front door and windows
    const wallFrontL = new THREE.Mesh(new THREE.BoxGeometry((w - 2.4) / 2, gfHeight, wallThick), facadeMat);
    wallFrontL.position.set(-w / 4 - 0.6, 0.31 + gfHeight / 2, l / 2 - wallThick / 2);
    const wallFrontR = new THREE.Mesh(new THREE.BoxGeometry((w - 2.4) / 2, gfHeight, wallThick), facadeMat);
    wallFrontR.position.set(w / 4 + 0.6, 0.31 + gfHeight / 2, l / 2 - wallThick / 2);
    const wallFrontHeader = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.6, wallThick), facadeMat);
    wallFrontHeader.position.set(0, 0.31 + gfHeight - 0.3, l / 2 - wallThick / 2);

    this.wallsGroup.add(wallLeft, wallRight, wallBack, wallFrontL, wallFrontR, wallFrontHeader);
    this.brickMeshes.push(wallLeft, wallRight, wallBack, wallFrontL, wallFrontR, wallFrontHeader);
    this.registerMeshForBim('STR-001', wallLeft);

    // 4. INTERMEDIATE FIRST FLOOR JOISTS & DECK
    const joistGeo = new THREE.BoxGeometry(w - 0.4, 0.22, 0.05);
    for (let z = -l / 2 + 0.4; z <= l / 2 - 0.4; z += 0.45) {
      const joist = new THREE.Mesh(joistGeo, timberJoistMat);
      joist.position.set(0, 3.1, z);
      this.firstFloorGroup.add(joist);
    }
    const deck = new THREE.Mesh(new THREE.BoxGeometry(w - 0.4, 0.03, l - 0.4), timberFloorMat);
    deck.position.set(0, 3.22, 0);
    deck.receiveShadow = true;
    this.firstFloorGroup.add(deck);
    this.registerMeshForBim('STR-002', deck);

    // 5. FIRST FLOOR WALLS
    const ffHeight = 2.6;
    const ffWallLeft = new THREE.Mesh(new THREE.BoxGeometry(wallThick, ffHeight, l), facadeMat);
    ffWallLeft.position.set(-w / 2 + wallThick / 2, 3.25 + ffHeight / 2, 0);
    const ffWallRight = new THREE.Mesh(new THREE.BoxGeometry(wallThick, ffHeight, l), facadeMat);
    ffWallRight.position.set(w / 2 - wallThick / 2, 3.25 + ffHeight / 2, 0);
    const ffWallBack = new THREE.Mesh(new THREE.BoxGeometry(w - wallThick * 2, ffHeight, wallThick), facadeMat);
    ffWallBack.position.set(0, 3.25 + ffHeight / 2, -l / 2 + wallThick / 2);
    const ffWallFront = new THREE.Mesh(new THREE.BoxGeometry(w - wallThick * 2, ffHeight, wallThick), facadeMat);
    ffWallFront.position.set(0, 3.25 + ffHeight / 2, l / 2 - wallThick / 2);

    this.wallsGroup.add(ffWallLeft, ffWallRight, ffWallBack, ffWallFront);
    this.brickMeshes.push(ffWallLeft, ffWallRight, ffWallBack, ffWallFront);
    this.registerMeshForBim('STR-003', ffWallFront);

    // 6. ROOF TRUSSES & TILES
    const roofApex = 5.85 + 2.4;
    const trussCount = 9;
    const trussSpacing = (l + 0.6) / (trussCount - 1);

    for (let i = 0; i < trussCount; i++) {
      const zPos = -l / 2 - 0.3 + i * trussSpacing;
      // Left rafter
      const rafterL = new THREE.Mesh(new THREE.BoxGeometry((w + 1.0) / 1.4, 0.12, 0.05), timberJoistMat);
      rafterL.position.set(-w / 4, 5.85 + 1.2, zPos);
      rafterL.rotation.z = -Math.PI / 6.5;

      const rafterR = new THREE.Mesh(new THREE.BoxGeometry((w + 1.0) / 1.4, 0.12, 0.05), timberJoistMat);
      rafterR.position.set(w / 4, 5.85 + 1.2, zPos);
      rafterR.rotation.z = Math.PI / 6.5;

      const tieBeam = new THREE.Mesh(new THREE.BoxGeometry(w + 0.6, 0.12, 0.05), timberJoistMat);
      tieBeam.position.set(0, 5.9, zPos);

      this.roofGroup.add(rafterL, rafterR, tieBeam);
    }
    this.registerMeshForBim('ROOF-001', this.roofGroup.children[0]);

    // Roof Pitch Slopes & Tiles
    const pitchSlopeGeo = new THREE.BoxGeometry(w / 1.6 + 0.6, 0.1, l + 1.0);
    const roofSlopeL = new THREE.Mesh(pitchSlopeGeo, roofSlateMat);
    roofSlopeL.position.set(-w / 4 - 0.1, 5.85 + 1.3, 0);
    roofSlopeL.rotation.z = -Math.PI / 6.5;
    roofSlopeL.castShadow = true;

    const roofSlopeR = new THREE.Mesh(pitchSlopeGeo, roofSlateMat);
    roofSlopeR.position.set(w / 4 + 0.1, 5.85 + 1.3, 0);
    roofSlopeR.rotation.z = Math.PI / 6.5;
    roofSlopeR.castShadow = true;

    this.roofGroup.add(roofSlopeL, roofSlopeR);
    this.roofTileMeshes.push(roofSlopeL, roofSlopeR);
    this.registerMeshForBim('ROOF-002', roofSlopeL);

    // In-Roof Solar PV Array (South slope)
    if (params.hasSolarPanels) {
      const solarMesh = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.04, 3.2), solarPvMat);
      solarMesh.position.set(-w / 4 - 0.12, 5.85 + 1.38, 0);
      solarMesh.rotation.z = -Math.PI / 6.5;
      this.roofGroup.add(solarMesh);
      this.registerMeshForBim('REN-001', solarMesh);
    }

    // 7. ENVELOPE (Windows & Doors)
    const windowGeo = new THREE.BoxGeometry(1.4, 1.4, 0.1);
    const win1 = new THREE.Mesh(windowGeo, glassMat);
    win1.position.set(-2.5, 1.6, l / 2);
    const win2 = new THREE.Mesh(windowGeo, glassMat);
    win2.position.set(2.5, 1.6, l / 2);
    const win3 = new THREE.Mesh(windowGeo, glassMat);
    win3.position.set(-2.5, 4.4, l / 2);
    const win4 = new THREE.Mesh(windowGeo, glassMat);
    win4.position.set(2.5, 4.4, l / 2);
    this.envelopeGroup.add(win1, win2, win3, win4);
    this.registerMeshForBim('ENV-001', win1);

    // Front Composite Door
    const doorMesh = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.1, 0.08), new THREE.MeshStandardMaterial({ color: 0x047857 })); // Racing Green
    doorMesh.position.set(0, 1.35, l / 2);
    this.envelopeGroup.add(doorMesh);

    // Rear Bifold Doors
    const bifoldMesh = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.2, 0.08), glassMat);
    bifoldMesh.position.set(0, 1.4, -l / 2);
    this.envelopeGroup.add(bifoldMesh);
    this.registerMeshForBim('ENV-002', bifoldMesh);

    // 8. MEP & SERVICES (Cables, Pipes, MVHR, ASHP)
    const elecMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 }); // Glowing Cyan electrical
    const waterHotMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const waterColdMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6 });
    const ductMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.6 });

    // Electrical Consumer Unit & Conduit Spine
    const consumerUnit = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.2), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    consumerUnit.position.set(-w / 2 + 0.6, 1.5, l / 2 - 0.6);
    const elecRiser = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 5.0), elecMat);
    elecRiser.position.set(-w / 2 + 0.6, 2.8, l / 2 - 0.6);
    this.mepGroup.add(consumerUnit, elecRiser);
    this.registerMeshForBim('MEP-001', consumerUnit);

    // Plumbing Hot Water Cylinder
    const cylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 1.6, 16), new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.8 }));
    cylinder.position.set(2.4, 4.2, -1.8);
    const hotPipe = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 4.2), waterHotMat);
    hotPipe.position.set(2.2, 2.4, -1.8);
    const coldPipe = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 4.2), waterColdMat);
    coldPipe.position.set(2.3, 2.4, -1.8);
    this.mepGroup.add(cylinder, hotPipe, coldPipe);
    this.registerMeshForBim('MEP-002', cylinder);

    // ASHP Outdoor Unit
    if (params.hasHeatPump) {
      const ashpBody = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.9, 0.45), new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 }));
      ashpBody.position.set(w / 2 + 0.7, 0.65, -l / 4);
      this.ashpFanMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.04, 8), new THREE.MeshStandardMaterial({ color: 0x334155 }));
      this.ashpFanMesh.rotation.x = Math.PI / 2;
      this.ashpFanMesh.position.set(w / 2 + 0.7, 0.65, -l / 4 + 0.24);
      this.mepGroup.add(ashpBody, this.ashpFanMesh);
      this.registerMeshForBim('MEP-003', ashpBody);
    }

    // 9. INTERIOR FINISHES (Kitchen Island, Bathroom Suite, Flooring)
    const kitchenIsland = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.9, 1.1), new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 }));
    kitchenIsland.position.set(-2.2, 0.75, -1.8);
    const quartzTop = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.06, 1.15), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1 }));
    quartzTop.position.set(-2.2, 1.23, -1.8);
    this.interiorGroup.add(kitchenIsland, quartzTop);
    this.registerMeshForBim('INT-002', kitchenIsland);

    // Bathroom Tub
    const bathTub = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.6, 0.8), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1 }));
    bathTub.position.set(2.4, 3.6, 1.6);
    this.interiorGroup.add(bathTub);
    this.registerMeshForBim('INT-003', bathTub);

    // 10. LANDSCAPING (Driveway, Turf, Patio, EV Charger)
    const driveway = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.04, 6.5), new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.8 }));
    driveway.position.set(w / 2 - 1.2, 0.02, l / 2 + 3.4);
    driveway.receiveShadow = true;

    const patio = new THREE.Mesh(new THREE.BoxGeometry(w + 1.5, 0.04, 4.0), new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.7 }));
    patio.position.set(0, 0.02, -l / 2 - 2.2);
    patio.receiveShadow = true;

    const lawn = new THREE.Mesh(new THREE.BoxGeometry(w + 8.0, 0.02, 6.0), new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.9 }));
    lawn.position.set(0, 0.01, -l / 2 - 7.2);
    lawn.receiveShadow = true;

    this.landscapeGroup.add(driveway, patio, lawn);
    this.registerMeshForBim('LND-001', driveway);
    this.registerMeshForBim('LND-002', lawn);

    if (params.hasEVCharger) {
      const evPost = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.2, 0.15), new THREE.MeshStandardMaterial({ color: 0x1e293b }));
      evPost.position.set(w / 2 + 0.4, 0.6, l / 2 + 1.2);
      const evLight = new THREE.Mesh(new THREE.SphereGeometry(0.06), new THREE.MeshBasicMaterial({ color: 0x22c55e }));
      evLight.position.set(w / 2 + 0.4, 1.1, l / 2 + 1.28);
      this.landscapeGroup.add(evPost, evLight);
    }
  }

  // Register mesh mapping for BIM hover & inspection
  private registerMeshForBim(componentId: string, mesh: THREE.Object3D) {
    mesh.userData = { bimId: componentId };
    const list = this.componentMeshMap.get(componentId) || [];
    list.push(mesh);
    this.componentMeshMap.set(componentId, list);
  }

  // --- SITE GROUND & SOIL EXCAVATION TRENCH ---
  private buildGroundAndSite() {
    const siteGroundGeo = new THREE.PlaneGeometry(70, 70);
    const siteGroundMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.95 });
    const siteGround = new THREE.Mesh(siteGroundGeo, siteGroundMat);
    siteGround.rotation.x = -Math.PI / 2;
    siteGround.receiveShadow = true;
    siteGround.position.y = -0.01;
    this.groundGroup.add(siteGround);

    // Site Boundary Hoarding / Fencing
    const fenceMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.5, metalness: 0.3 });
    const fW = 28;
    const fL = 26;
    const fenceFront = new THREE.Mesh(new THREE.BoxGeometry(fW, 2.0, 0.08), fenceMat);
    fenceFront.position.set(0, 1.0, fL / 2);
    const fenceBack = new THREE.Mesh(new THREE.BoxGeometry(fW, 2.0, 0.08), fenceMat);
    fenceBack.position.set(0, 1.0, -fL / 2);
    const fenceLeft = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.0, fL), fenceMat);
    fenceLeft.position.set(-fW / 2, 1.0, 0);
    const fenceRight = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.0, fL), fenceMat);
    fenceRight.position.set(fW / 2, 1.0, 0);
    this.groundGroup.add(fenceFront, fenceBack, fenceLeft, fenceRight);
  }

  // --- WEATHER PARTICLE SYSTEMS ---
  private initWeatherParticles() {
    // Rain Particles
    const rainCount = 1800;
    const rainGeo = new THREE.BufferGeometry();
    const rainPositions = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      rainPositions[i * 3] = (Math.random() - 0.5) * 40;
      rainPositions[i * 3 + 1] = Math.random() * 25;
      rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({ color: 0x93c5fd, size: 0.15, transparent: true, opacity: 0.6 });
    this.rainParticles = new THREE.Points(rainGeo, rainMat);
    this.rainParticles.visible = false;
    this.scene.add(this.rainParticles);

    // Snow Particles
    const snowCount = 1200;
    const snowGeo = new THREE.BufferGeometry();
    const snowPositions = new Float32Array(snowCount * 3);
    for (let i = 0; i < snowCount; i++) {
      snowPositions[i * 3] = (Math.random() - 0.5) * 40;
      snowPositions[i * 3 + 1] = Math.random() * 25;
      snowPositions[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPositions, 3));
    const snowMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.25, transparent: true, opacity: 0.8 });
    this.snowParticles = new THREE.Points(snowGeo, snowMat);
    this.snowParticles.visible = false;
    this.scene.add(this.snowParticles);
  }

  // --- MEP / ENERGY FLOW PARTICLES ---
  private initMepFlowParticles() {
    const count = 120;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 8;
      pos[i * 3 + 1] = 0.5 + Math.random() * 4.5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 8;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({ color: 0x38bdf8, size: 0.18, transparent: true, opacity: 0.9 });
    this.mepFlowParticles = new THREE.Points(geo, mat);
    this.mepFlowParticles.visible = false;
    this.scene.add(this.mepFlowParticles);
  }

  // --- UPDATE ANIMATION & STATE ---
  public update(simState: SimulationState, bimComponents: BimComponent[]) {
    const dt = this.clock.getDelta();
    const timeSec = this.clock.getElapsedTime();

    const { currentDay, viewMode, cameraPreset, weather, timeOfDay, cutawayHeight, explodedSeparation, showStructuralOnly } = simState;

    // 1. Lighting & Day/Night transitions
    this.updateAtmosphericLighting(timeOfDay, weather);

    // 2. Weather particles
    if (this.rainParticles) {
      this.rainParticles.visible = weather === WeatherType.RAIN;
      if (this.rainParticles.visible) {
        const pos = this.rainParticles.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < pos.length; i += 3) {
          pos[i] -= 0.8;
          if (pos[i] < 0) pos[i] = 25;
        }
        this.rainParticles.geometry.attributes.position.needsUpdate = true;
      }
    }

    if (this.snowParticles) {
      this.snowParticles.visible = weather === WeatherType.SNOW;
      if (this.snowParticles.visible) {
        const pos = this.snowParticles.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < pos.length; i += 3) {
          pos[i] -= 0.15;
          if (pos[i] < 0) pos[i] = 25;
        }
        this.snowParticles.geometry.attributes.position.needsUpdate = true;
      }
    }

    // 3. Stage-driven component visibility & growth
    this.updateStageVisibility(currentDay, viewMode, showStructuralOnly);

    // 4. Cutaway & Exploded View Transforms
    this.updateExplodedAndCutaway(viewMode, cutawayHeight, explodedSeparation);

    // 5. Machinery & Worker Kinematics
    this.machinery.update(currentDay, timeSec);
    this.workers.update(simState.parameters ? (currentDay > 239 ? ConstructionStage.COMPLETE : ConstructionStage.SITE) : ConstructionStage.SITE, timeSec);

    // 6. Fan & Flow rotations
    if (this.ashpFanMesh && currentDay >= 165) {
      this.ashpFanMesh.rotation.z += 0.15;
    }

    if (this.mepFlowParticles && (viewMode === ViewMode.SERVICES_MEP || viewMode === ViewMode.ENERGY)) {
      this.mepFlowParticles.visible = true;
      const pos = this.mepFlowParticles.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < pos.length; i += 3) {
        pos[i] += 0.05;
        if (pos[i] > 5.5) pos[i] = 0.5;
      }
      this.mepFlowParticles.geometry.attributes.position.needsUpdate = true;
    } else if (this.mepFlowParticles) {
      this.mepFlowParticles.visible = false;
    }

    // 7. Camera smooth lerping
    if (cameraPreset === CameraPreset.CINEMATIC_DRONE) {
      this.cameraTheta += 0.003;
      this.cameraPhi = Math.PI / 4 + Math.sin(timeSec * 0.2) * 0.1;
      this.updateCameraTransform();
    }
  }

  private updateStageVisibility(day: number, viewMode: ViewMode, structuralOnly: boolean) {
    // Stage logic:
    // Foundations: Day 15 - 38
    this.foundationGroup.visible = day >= 12;
    // Ground floor slab: Day 35+
    this.groundFloorGroup.visible = day >= 32;
    // Superstructure walls: Day 46+ (progressive vertical scale)
    this.wallsGroup.visible = day >= 46;
    if (this.wallsGroup.visible && day < 104) {
      const wallProgress = Math.min(1.0, (day - 46) / 58);
      this.wallsGroup.scale.y = Math.max(0.1, wallProgress);
    } else if (this.wallsGroup.visible) {
      this.wallsGroup.scale.y = 1.0;
    }

    // First floor structure: Day 72+
    this.firstFloorGroup.visible = day >= 70;

    // Roof: Day 102+
    this.roofGroup.visible = day >= 100 && !structuralOnly && viewMode !== ViewMode.CUTAWAY;
    if (this.roofGroup.visible && day < 128) {
      const roofProgress = Math.min(1.0, (day - 100) / 28);
      this.roofGroup.scale.y = Math.max(0.1, roofProgress);
    } else if (this.roofGroup.visible) {
      this.roofGroup.scale.y = 1.0;
    }

    // Windows & Doors Envelope: Day 125+
    this.envelopeGroup.visible = day >= 122 && !structuralOnly;

    // MEP Services: Day 145+ (or always if in SERVICES_MEP view)
    this.mepGroup.visible = (day >= 140 || viewMode === ViewMode.SERVICES_MEP || viewMode === ViewMode.ENERGY) && !structuralOnly;

    // Interior finishes: Day 180+
    this.interiorGroup.visible = day >= 178 && !structuralOnly;

    // Landscaping: Day 222+
    this.landscapeGroup.visible = day >= 220 && !structuralOnly;

    // Underfloor heating
    this.ufhPipeGroup.visible = viewMode === ViewMode.SERVICES_MEP || (day >= 40 && day <= 55);
  }

  private updateExplodedAndCutaway(viewMode: ViewMode, cutawayH: number, explodedSep: number) {
    if (viewMode === ViewMode.EXPLODED) {
      const s = explodedSep * 6.0;
      this.foundationGroup.position.y = -s * 0.4;
      this.groundFloorGroup.position.y = 0;
      this.wallsGroup.position.y = s * 0.5;
      this.firstFloorGroup.position.y = s * 1.0;
      this.mepGroup.position.y = s * 1.4;
      this.roofGroup.position.y = s * 2.2;
      this.interiorGroup.position.y = s * 0.7;
    } else {
      this.foundationGroup.position.y = 0;
      this.groundFloorGroup.position.y = 0;
      this.wallsGroup.position.y = 0;
      this.firstFloorGroup.position.y = 0;
      this.mepGroup.position.y = 0;
      this.roofGroup.position.y = 0;
      this.interiorGroup.position.y = 0;
    }

    if (viewMode === ViewMode.CUTAWAY) {
      // Hide roof and make upper walls invisible
      this.roofGroup.visible = false;
      const targetY = cutawayH * 6.0;
      this.wallsGroup.position.y = Math.min(0, targetY - 6.0);
    }
  }

  private updateAtmosphericLighting(time: TimeOfDay, weather: WeatherType) {
    switch (time) {
      case TimeOfDay.SUNRISE:
        this.sunLight.color.setHex(0xfb923c); // Warm amber
        this.sunLight.intensity = 1.4;
        this.sunLight.position.set(25, 8, 25);
        this.ambientLight.color.setHex(0x38bdf8);
        this.ambientLight.intensity = 0.5;
        this.scene.background = new THREE.Color(0x1e1b4b);
        break;
      case TimeOfDay.MIDDAY:
        this.sunLight.color.setHex(0xffffff);
        this.sunLight.intensity = 2.0;
        this.sunLight.position.set(5, 35, 10);
        this.ambientLight.color.setHex(0xffffff);
        this.ambientLight.intensity = 0.8;
        this.scene.background = new THREE.Color(0x0f172a);
        break;
      case TimeOfDay.GOLDEN_HOUR:
        this.sunLight.color.setHex(0xf59e0b);
        this.sunLight.intensity = 1.6;
        this.sunLight.position.set(-25, 10, -20);
        this.ambientLight.color.setHex(0xfdba74);
        this.ambientLight.intensity = 0.6;
        this.scene.background = new THREE.Color(0x2e1065);
        break;
      case TimeOfDay.NIGHT:
        this.sunLight.intensity = 0.1;
        this.ambientLight.color.setHex(0x1e293b);
        this.ambientLight.intensity = 0.3;
        this.scene.background = new THREE.Color(0x030712);
        break;
      default:
        this.sunLight.color.setHex(0xfffbeb);
        this.sunLight.intensity = 1.8;
        this.sunLight.position.set(20, 30, 20);
        this.ambientLight.intensity = 0.7;
        this.scene.background = new THREE.Color(0x0f172a);
        break;
    }

    if (weather === WeatherType.OVERCAST || weather === WeatherType.RAIN) {
      this.sunLight.intensity *= 0.4;
      this.ambientLight.intensity = 0.5;
      this.scene.background = new THREE.Color(0x1e293b);
    }
  }

  // --- CAMERA NAVIGATION PRESETS ---
  public setCameraPreset(preset: CameraPreset) {
    switch (preset) {
      case CameraPreset.ORBIT:
        this.cameraRadius = 18;
        this.cameraTheta = Math.PI / 4;
        this.cameraPhi = Math.PI / 4;
        this.cameraTarget.set(0, 2.5, 0);
        break;
      case CameraPreset.SITE_OVERVIEW:
        this.cameraRadius = 32;
        this.cameraTheta = Math.PI / 3;
        this.cameraPhi = Math.PI / 3;
        this.cameraTarget.set(0, 2.0, 0);
        break;
      case CameraPreset.GROUND_LEVEL:
        this.cameraRadius = 14;
        this.cameraTheta = Math.PI / 6;
        this.cameraPhi = 0.2;
        this.cameraTarget.set(0, 1.6, 0);
        break;
      case CameraPreset.AERIAL_CRANE:
        this.cameraRadius = 24;
        this.cameraTheta = -Math.PI / 3;
        this.cameraPhi = Math.PI / 2.3;
        this.cameraTarget.set(0, 4.0, 0);
        break;
      case CameraPreset.INTERIOR_KITCHEN:
        this.cameraRadius = 5;
        this.cameraTheta = Math.PI / 1.5;
        this.cameraPhi = 0.3;
        this.cameraTarget.set(-1.8, 1.2, -1.2);
        break;
      case CameraPreset.INTERIOR_LIVING:
        this.cameraRadius = 5.5;
        this.cameraTheta = -Math.PI / 4;
        this.cameraPhi = 0.3;
        this.cameraTarget.set(1.5, 1.2, 1.0);
        break;
      case CameraPreset.ROOF_LEVEL:
        this.cameraRadius = 12;
        this.cameraTheta = Math.PI / 4;
        this.cameraPhi = 0.8;
        this.cameraTarget.set(0, 6.5, 0);
        break;
      case CameraPreset.SECTION_CUT:
        this.cameraRadius = 16;
        this.cameraTheta = 0;
        this.cameraPhi = 0.1;
        this.cameraTarget.set(0, 2.5, 0);
        break;
    }
    this.updateCameraTransform();
  }

  private updateCameraTransform() {
    this.cameraPhi = Math.max(0.05, Math.min(Math.PI / 2 - 0.05, this.cameraPhi));
    const x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    const y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  // --- INTERACTION & EVENT LISTENERS ---
  private setupEventListeners() {
    const el = this.renderer.domElement;

    el.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.mousePrev = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    el.addEventListener('mousemove', (e) => {
      if (this.isMouseDown) {
        const dx = e.clientX - this.mousePrev.x;
        const dy = e.clientY - this.mousePrev.y;
        this.cameraTheta -= dx * 0.006;
        this.cameraPhi += dy * 0.006;
        this.updateCameraTransform();
        this.mousePrev = { x: e.clientX, y: e.clientY };
      }

      // Raycasting for BIM Hover
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.checkRaycastHover();
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraRadius = Math.max(3, Math.min(60, this.cameraRadius + e.deltaY * 0.02));
      this.updateCameraTransform();
    }, { passive: false });

    // Click for BIM Selection / Dimensioning
    el.addEventListener('click', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.scene.children, true);

      if (intersects.length > 0) {
        const hit = intersects[0];
        let obj: THREE.Object3D | null = hit.object;
        while (obj && !obj.userData?.bimId && obj.parent) {
          obj = obj.parent;
        }
        if (obj?.userData?.bimId) {
          this.onSelectComponent?.(obj.userData.bimId);
        } else {
          this.onSelectComponent?.(null);
        }
      } else {
        this.onSelectComponent?.(null);
      }
    });

    // Touch support for tablet experience
    let touchStartDist = 0;
    el.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isMouseDown = true;
        this.mousePrev = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        touchStartDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    });

    el.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1 && this.isMouseDown) {
        const dx = e.touches[0].clientX - this.mousePrev.x;
        const dy = e.touches[0].clientY - this.mousePrev.y;
        this.cameraTheta -= dx * 0.008;
        this.cameraPhi += dy * 0.008;
        this.updateCameraTransform();
        this.mousePrev = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        const dist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const diff = touchStartDist - dist;
        this.cameraRadius = Math.max(3, Math.min(60, this.cameraRadius + diff * 0.04));
        touchStartDist = dist;
        this.updateCameraTransform();
      }
    });

    el.addEventListener('touchend', () => {
      this.isMouseDown = false;
    });

    // Resize handler
    window.addEventListener('resize', () => {
      if (!this.container || this.isDisposed) return;
      this.camera.aspect = this.container.clientWidth / this.container.clientHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    });
  }

  private checkRaycastHover() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);
    if (intersects.length > 0) {
      let obj: THREE.Object3D | null = intersects[0].object;
      while (obj && !obj.userData?.bimId && obj.parent) {
        obj = obj.parent;
      }
      this.hoveredComponentId = obj?.userData?.bimId || null;
    } else {
      this.hoveredComponentId = null;
    }
  }

  private animate = () => {
    if (this.isDisposed) return;
    this.animFrameId = requestAnimationFrame(this.animate);
    this.renderer.render(this.scene, this.camera);
  };

  public dispose() {
    this.isDisposed = true;
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    this.renderer.dispose();
    if (this.container && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
