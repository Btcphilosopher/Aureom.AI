/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Worker Entities & Trade Simulation
 */

import * as THREE from 'three';
import { ConstructionStage, TradeType } from '../types/simulation';

interface WorkerData {
  trade: TradeType;
  basePos: [number, number, number];
  activeStages: ConstructionStage[];
  vestColor: number;
  hatColor: number;
}

export class WorkerSimulationEngine {
  public rootGroup: THREE.Group;
  private workers: {
    group: THREE.Group;
    data: WorkerData;
    leftArm: THREE.Group;
    rightArm: THREE.Group;
    body: THREE.Mesh;
    tool?: THREE.Mesh;
  }[] = [];

  constructor() {
    this.rootGroup = new THREE.Group();
    this.rootGroup.name = 'CONSTRUCTION_WORKERS';
    this.initWorkers();
  }

  private initWorkers() {
    const workerConfigs: WorkerData[] = [
      {
        trade: TradeType.SITE_SUPERVISOR,
        basePos: [-3.5, 0, 5.5],
        activeStages: [
          ConstructionStage.SITE,
          ConstructionStage.GROUNDWORK,
          ConstructionStage.FOUNDATION,
          ConstructionStage.GROUND_FLOOR,
          ConstructionStage.STRUCTURE,
          ConstructionStage.ROOF,
          ConstructionStage.ENVELOPE,
          ConstructionStage.SERVICES,
          ConstructionStage.INTERNAL_FINISH,
          ConstructionStage.LANDSCAPE,
          ConstructionStage.COMPLETE
        ],
        vestColor: 0xffffff, // White supervisor vest
        hatColor: 0xffffff
      },
      {
        trade: TradeType.GROUNDWORKER,
        basePos: [-4.2, 0, 1.8],
        activeStages: [ConstructionStage.SITE, ConstructionStage.GROUNDWORK, ConstructionStage.FOUNDATION, ConstructionStage.GROUND_FLOOR],
        vestColor: 0xf97316, // Orange
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.BRICKLAYER,
        basePos: [3.8, 1.8, 2.5],
        activeStages: [ConstructionStage.GROUND_FLOOR, ConstructionStage.STRUCTURE, ConstructionStage.ENVELOPE],
        vestColor: 0xeab308, // Hi-vis yellow
        hatColor: 0xfacc15
      },
      {
        trade: TradeType.CARPENTER,
        basePos: [-2.0, 3.2, -1.0],
        activeStages: [ConstructionStage.STRUCTURE, ConstructionStage.ROOF, ConstructionStage.INTERNAL_FINISH],
        vestColor: 0xeab308,
        hatColor: 0xef4444
      },
      {
        trade: TradeType.ROOFER,
        basePos: [1.2, 6.5, 0.5],
        activeStages: [ConstructionStage.ROOF, ConstructionStage.ENVELOPE],
        vestColor: 0xf97316,
        hatColor: 0xef4444
      },
      {
        trade: TradeType.ELECTRICIAN,
        basePos: [-1.5, 1.2, 0.5],
        activeStages: [ConstructionStage.SERVICES, ConstructionStage.INTERNAL_FINISH],
        vestColor: 0x06b6d4, // Cyan
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.PLUMBER,
        basePos: [2.5, 1.2, -1.5],
        activeStages: [ConstructionStage.SERVICES, ConstructionStage.INTERNAL_FINISH],
        vestColor: 0x3b82f6, // Blue
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.LANDSCAPER,
        basePos: [3.2, 0, 3.8],
        activeStages: [ConstructionStage.LANDSCAPE],
        vestColor: 0x22c55e, // Green
        hatColor: 0xfacc15
      }
    ];

    workerConfigs.forEach(cfg => {
      const workerMesh = this.createWorkerMesh(cfg);
      this.workers.push(workerMesh);
      this.rootGroup.add(workerMesh.group);
    });
  }

  private createWorkerMesh(data: WorkerData) {
    const group = new THREE.Group();
    group.position.set(...data.basePos);

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xfcd34d, roughness: 0.8 });
    const jeansMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.9 });
    const bootsMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
    const vestMat = new THREE.MeshStandardMaterial({ color: data.vestColor, roughness: 0.5 });
    const hatMat = new THREE.MeshStandardMaterial({ color: data.hatColor, roughness: 0.3, metalness: 0.2 });

    // Boots & Legs
    const legGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.7);
    const leftLeg = new THREE.Mesh(legGeo, jeansMat);
    leftLeg.position.set(-0.12, 0.35, 0);
    const rightLeg = new THREE.Mesh(legGeo, jeansMat);
    rightLeg.position.set(0.12, 0.35, 0);

    const bootGeo = new THREE.BoxGeometry(0.12, 0.12, 0.22);
    const leftBoot = new THREE.Mesh(bootGeo, bootsMat);
    leftBoot.position.set(-0.12, 0.06, 0.04);
    const rightBoot = new THREE.Mesh(bootGeo, bootsMat);
    rightBoot.position.set(0.12, 0.06, 0.04);

    group.add(leftLeg, rightLeg, leftBoot, rightBoot);

    // Torso with Hi-Vis Vest
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.5, 0.22), vestMat);
    body.position.set(0, 0.95, 0);
    group.add(body);

    // Head & Hard Hat
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), skinMat);
    head.position.set(0, 1.32, 0);

    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.14, 12), hatMat);
    hat.position.set(0, 1.42, 0);
    group.add(head, hat);

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.45);

    const leftArm = new THREE.Group();
    leftArm.position.set(-0.24, 1.15, 0);
    const leftArmMesh = new THREE.Mesh(armGeo, vestMat);
    leftArmMesh.position.set(0, -0.2, 0);
    leftArm.add(leftArmMesh);

    const rightArm = new THREE.Group();
    rightArm.position.set(0.24, 1.15, 0);
    const rightArmMesh = new THREE.Mesh(armGeo, vestMat);
    rightArmMesh.position.set(0, -0.2, 0);
    rightArm.add(rightArmMesh);

    // Tool (Trowel / Tablet / Hammer)
    let tool: THREE.Mesh | undefined;
    if (data.trade === TradeType.SITE_SUPERVISOR) {
      tool = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.2, 0.02), new THREE.MeshStandardMaterial({ color: 0x0f172a }));
      tool.position.set(0, -0.35, 0.12);
      rightArm.add(tool);
    } else {
      tool = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.15, 0.04), new THREE.MeshStandardMaterial({ color: 0x94a3b8 }));
      tool.position.set(0, -0.35, 0.1);
      rightArm.add(tool);
    }

    group.add(leftArm, rightArm);

    return { group, data, leftArm, rightArm, body, tool };
  }

  public update(currentStage: ConstructionStage, timeSec: number) {
    this.workers.forEach((w, idx) => {
      const isActive = w.data.activeStages.includes(currentStage);
      w.group.visible = isActive;

      if (isActive) {
        // Natural work animations
        const animSpeed = 3.0 + (idx % 3);
        const cycle = timeSec * animSpeed + idx;
        w.rightArm.rotation.x = Math.sin(cycle) * 0.6;
        w.leftArm.rotation.x = -Math.cos(cycle * 0.8) * 0.4;
        w.group.rotation.y = Math.sin(timeSec * 0.5 + idx) * 0.3;
      }
    });
  }
}
