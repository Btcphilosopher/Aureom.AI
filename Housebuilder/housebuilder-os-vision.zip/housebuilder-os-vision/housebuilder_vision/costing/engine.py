"""Construction cost engine: bill of quantities x rate book -> layered, bounded estimate.

``estimate_construction_cost(boq, rate_book, params, *, settings, ...)`` prices a
:class:`~housebuilder_vision.core.models.BillOfQuantities` in nine explicit layers
(:class:`~housebuilder_vision.core.models.CostLayer`).  Every cost line keeps its
quantity, unit, net rate, rate id, formula, provenance basis and the rate's
uncertainty fractions; lines priced from a quantity line keep its
``quantity_line_id``.

Layers
------
1. **Materials** - ``mat:`` lines are priced **per order**: for each material (cost key and
   purchase unit) the lines' unrounded needs ``purchase_required = required_qty x
   purchase_per_installed`` are summed, rounded once to whole packs (``packs = ceil(sum /
   pack_size)``) and priced; the order cost is allocated back to the lines pro rata to their
   need, so every cost line keeps its ``quantity_line_id`` and its formula shows its share.
   The orders are recorded in ``CostEstimate.material_orders`` (repeat-build economics re-round
   them for n houses).  ``allow:`` lines (labelled allowances) are priced on their quantity by
   the ``allow:`` rate, which covers the material / supply component (labour on the line is
   priced in layer 2).
2. **Labour** - per quantity line, ``labour_hours x lab:<trade>`` (per hour; a day / week rate is
   converted as working time, see :mod:`.rates`).
3. **Plant** - quantity lines with a ``plant:`` key (``plant:excavation`` per m3 bank:
   excavator incl. fuel; when no per-m3 rate resolves but ``plant:excavator`` per hour
   does, hours = m3 x :attr:`CostRules.excavator_hours_per_m3`), plus derived hires
   (:class:`CostRules`): dumper weeks = ceil(groundworks labour hours /
   ``dumper_gang_hours_per_week``); scaffold m2-weeks = external wall gross area x
   ``scaffold_area_factor`` x ``scaffold_programme_share`` x programme weeks;
   telehandler weeks = ceil(``telehandler_programme_share`` x programme weeks).
4. **Logistics & waste** - ``log:`` quantity lines (spoil disposal per m3 loose);
   delivery loads x ``log:delivery_load`` (site receipt per load) where loads =
   ``logistics.total_loads`` when a logistics plan is given, else one order per
   material (``max(1, ceil(max(mass / payload_kg, volume / payload_m3)))``) plus one per
   allowance item; delivery treatment of **every rate used** (``mat:``, ``allow:``, ``plant:``
   and rule keys): ``delivery_charged_separately`` / ``ex_works`` / ``collection`` rates add their
   ``delivery_charge`` once per order (cost key); without a charge the carriage is listed in
   ``unresolved_items`` (never priced as zero); waste skips =
   ``ceil(waste volume x bulking / skip volume)`` x ``log:skip``, waste volume from the
   lines' cutting + waste quantities via the material's volume (or mass / density) per
   purchase unit.  ``log:delivery_load`` / ``log:skip`` rates fall back to ``CostParameters``
   values only when the rate book has none (:data:`COST_PARAMETER_FALLBACKS`, labelled).
5. **Preliminaries** - setup + weekly x programme weeks (``prelim:setup`` /
   ``prelim:weekly`` rates if present, else the ``CostParameters`` fallbacks).
6. **Fees** - ``FeeItem.fraction x base`` (``direct`` = layers 1-4, ``construction`` = 1-5).
7. **Contingency** - ``contingency_fraction x (L1..L6)``.
8. **Overhead & margin** - overhead = ``o x (L1..L7)``; margin = ``m x (L1..L7 + overhead)``.
9. **Land, finance, taxes, sales** - only items the user entered: land; finance =
   ``rate x months / 12 x (land + drawdown x contract sum)`` (land is assumed drawn at the
   start; the build cost is assumed drawn evenly, so on average
   :attr:`CostRules.finance_drawdown_fraction` = 0.5 of the contract sum is outstanding);
   entered taxes; VAT only when ``settings.include_vat`` (``vat_rate x contract sum``, "as
   entered - check applicable treatment"); sales costs = ``fraction x sales_value``.

Boundaries (cumulative): ``materials`` (L1), ``direct_works`` (L1-4),
``construction_before_contingency`` (L1-6), ``construction_incl_contingency`` (L1-7),
``contract_sum`` (L1-8), ``total_development_cost`` (L1-9, only when a layer-9 item was
entered).  ``sales_value`` is reported separately and is never inside a boundary.

Unresolved quantity lines and missing rates are listed in ``unresolved_items`` with the
affected line ids - never priced as zero.  When a higher-priority rate was excluded only because
it is dated after the pricing date, the first warning starts with
:data:`~housebuilder_vision.costing.rates.PRICING_DATE_WARNING`.

Boundaries of the method: concept-stage estimate from a conceptual reconstruction and
labelled assumptions.  Not a tender price, valuation or cost plan for contract; the
bundled demo rates are fictional.  VAT and tax treatment is never determined here.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Optional

from ..core.models import (
    COST_LAYER_NAMES,
    AssemblyLibrary,
    BillOfQuantities,
    CostBoundary,
    CostEstimate,
    CostLayer,
    CostLine,
    CostParameters,
    DeliveryTreatment,
    LogisticsResult,
    MaterialOrder,
    MaterialSpec,
    QuantityLine,
    QuantityStatus,
    RateBook,
)
from ..core.provenance import Basis, weakest_basis
from ..core.settings import ProjectSettings
from ..quantities.procurement import PACK_TOLERANCE
from .rates import (
    PRICING_DATE_WARNING,
    RateIndex,
    ResolvedRate,
    cost_key_layer,
    rate_index,
    resolve_rate_detailed,
)

__all__ = [
    "CostRules",
    "DEFAULT_COST_RULES",
    "BOUNDARY_KEYS",
    "COST_CONVENTIONS",
    "RULE_COST_KEYS",
    "COST_PARAMETER_FALLBACKS",
    "INCOMPLETE_WARNING",
    "estimate_construction_cost",
    "cost_lines_table",
    "boundary_table",
]

_LAYERS = list(CostLayer)
L1, L2, L3, L4, L5, L6, L7, L8, L9 = _LAYERS

#: Start of the first estimate warning when items of layers 1-5 are unpriced (the boundary amounts are then
#: lower bounds - e.g. after a currency switch without an FX rate, or a pricing date before every rate).
INCOMPLETE_WARNING = "INCOMPLETE ESTIMATE"

#: Cost keys priced by derived rules (not emitted by the take-off) and their units.
RULE_COST_KEYS: dict[str, str] = {
    "plant:excavator": "hr",
    "plant:dumper": "week",
    "plant:scaffold": "m2_week",
    "plant:telehandler": "week",
    "log:delivery_load": "load",
    "log:skip": "nr",
    "prelim:setup": "sum",
    "prelim:weekly": "week",
}

#: CostParameters fields used only when the rate book has no usable rate for the key:
#: field -> (cost_key, unit).  The UI shows the rate in force next to each fallback input.
COST_PARAMETER_FALLBACKS: dict[str, tuple[str, str]] = {
    "prelims_weekly_cost": ("prelim:weekly", "week"),
    "prelims_fixed_setup": ("prelim:setup", "sum"),
    "cost_per_delivery_load": ("log:delivery_load", "load"),
    "cost_per_skip": ("log:skip", "nr"),
}

BOUNDARY_KEYS = ("materials", "direct_works", "construction_before_contingency", "construction_incl_contingency",
                 "contract_sum", "total_development_cost")


@dataclass(frozen=True)
class CostRules:
    """Labelled rule assumptions used by the engine (all editable; none is a measured fact)."""

    #: Fallback only: excavator hours per m3 bank when pricing ``plant:excavator`` per hour.
    excavator_hours_per_m3: float = 0.10
    #: Groundworks labour hours served by one dumper-week (2 operatives x 37.5 h).
    dumper_gang_hours_per_week: float = 75.0
    #: Scaffold face area per m2 of external wall gross area (corners, lift above plate).
    scaffold_area_factor: float = 1.15
    #: Share of the programme the scaffold stays on hire.
    scaffold_programme_share: float = 0.40
    #: Share of the programme a telehandler is on hire (superstructure / roof loading-out).
    telehandler_programme_share: float = 0.35
    #: Rigid delivery vehicle payload used to estimate loads per material order.
    lorry_payload_kg: float = 10_000.0
    lorry_payload_m3: float = 20.0
    #: Average share of the contract sum outstanding over the finance period (even drawdown).
    finance_drawdown_fraction: float = 0.5


DEFAULT_COST_RULES = CostRules()

COST_CONVENTIONS: dict[str, str] = {
    "net_of_vat": "All rates are converted to net of VAT; VAT is only added in layer 9 when settings.include_vat.",
    "materials_quantity": "Layer 1 prices each material once per order: the lines' unrounded purchase needs are "
                          "summed and rounded to whole packs, and the order cost is allocated to the lines pro "
                          "rata (CostEstimate.material_orders).",
    "working_time": "Labour, plant and preliminaries rates quoted per day / week are working time "
                    "(ProjectSettings.hours_per_working_day, working_days_per_week; assumption), not calendar time.",
    "allowances": "allow: rates price the supply / material component; installation labour is layer 2.",
    "labour": "Labour = labour_hours on each BoQ line x lab:<trade> hourly rate.",
    "plant": "plant:excavation per m3 bank (excavator incl. fuel); derived hires: dumper weeks = ceil(groundworks "
             "hours / 75), scaffold m2-weeks = external wall gross x 1.15 x 0.40 x programme weeks, telehandler weeks "
             "= ceil(0.35 x programme weeks) (CostRules defaults).",
    "logistics": "Loads from the logistics plan if given, else one order per material (payload 10 t / 20 m3) plus one "
                 "per allowance item; delivery charges of every rate used (materials, allowances, plant) once per "
                 "order - ex-works / collection / separately charged rates without a charge are unresolved; skips = "
                 "ceil(waste volume x bulking / skip volume); all cutting and waste losses assumed to leave site in "
                 "skips. CostParameters load / skip costs are fallbacks used only without log: rates.",
    "prelims": "Preliminaries = setup + weekly x programme weeks (prelim: rates; CostParameters values only as "
               "fallbacks when the rate book has none).",
    "fees": "Fees = fraction x layers 1-4 ('direct') or layers 1-5 ('construction').",
    "contingency": "Contingency = fraction x layers 1-6.",
    "overhead_margin": "Overhead = o x layers 1-7; margin = m x (layers 1-7 + overhead).",
    "finance": "Finance = annual rate x months / 12 x (land + 0.5 x contract sum): land drawn at start, build cost "
               "drawn evenly (assumption).",
    "vat": "VAT line only when include_vat: rate x contract sum, as entered - check applicable treatment.",
    "sales_value": "Sales value (GDV) is reported separately and never included in a cost boundary.",
    "unresolved": "Unresolved quantities and missing rates are listed, never priced as zero.",
    "information_level": "Concept-stage estimate; not a tender price or valuation. Demo rates are FICTIONAL.",
}

_BOUNDARY_DEFS: list[tuple[str, str, list[CostLayer], str, str]] = [
    ("materials", "Materials", [L1],
     "Layer 1: purchased materials (order-level pack-rounded purchase quantities per material, allocated to the "
     "lines) and allowance supply components, net of VAT.",
     "Labour, plant, logistics, preliminaries, fees, contingency, overhead & margin, land, finance, taxes, sales "
     "costs and VAT."),
    ("direct_works", "Direct works", [L1, L2, L3, L4],
     "Layers 1-4: materials, direct installation labour, plant and logistics & waste.",
     "Preliminaries, fees, contingency, overhead & margin, land, finance, taxes, sales costs and VAT."),
    ("construction_before_contingency", "Construction cost before contingency", [L1, L2, L3, L4, L5, L6],
     "Layers 1-6: direct works plus site preliminaries and professional fees / allowances.",
     "Contingency, overhead & margin, land, finance, taxes, sales costs and VAT."),
    ("construction_incl_contingency", "Construction cost incl. contingency", [L1, L2, L3, L4, L5, L6, L7],
     "Layers 1-7: construction cost before contingency plus the risk contingency.",
     "Contractor overhead & margin, land, finance, taxes, sales costs and VAT."),
    ("contract_sum", "Indicative contract sum", [L1, L2, L3, L4, L5, L6, L7, L8],
     "Layers 1-8: construction cost incl. contingency plus contractor overhead and margin (ex VAT). Indicative, "
     "not a tender price.",
     "Land, finance, taxes, sales costs and VAT."),
    ("total_development_cost", "Total development cost", _LAYERS,
     "Layers 1-9: contract sum plus the land, finance, taxes, VAT (if included) and sales costs that were entered.",
     "Sales value (GDV) - reported separately, never a cost. Items not entered are not included."),
]


@lru_cache(maxsize=1)
def _default_library() -> AssemblyLibrary:
    from ..quantities.library import default_library

    return default_library()


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower()[:40] or "item"


# =============================================================================
# Internal state
# =============================================================================
class _Resolver:
    """Per-estimate cache of rate resolutions (one lookup per (cost_key, unit))."""

    def __init__(self, idx: RateIndex, settings: ProjectSettings) -> None:
        self.idx = idx
        self.settings = settings
        self.cache: dict[tuple[str, str], ResolvedRate] = {}

    def get(self, cost_key: str, unit: str) -> ResolvedRate:
        k = (cost_key, unit)
        rr = self.cache.get(k)
        if rr is None:
            rr = self.cache[k] = resolve_rate_detailed(self.idx, cost_key, unit, settings=self.settings)
        return rr


@dataclass
class _State:
    currency: str
    lines: list[CostLine] = field(default_factory=list)
    totals: dict[CostLayer, float] = field(default_factory=lambda: {layer: 0.0 for layer in CostLayer})
    unresolved: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    #: (cost_key, unit) -> quantity line ids that could not be priced for lack of a rate
    missing: dict[tuple[str, str], list[str]] = field(default_factory=dict)
    used: dict[tuple[str, str], ResolvedRate] = field(default_factory=dict)
    #: order-level material purchases (one per priced (mat: cost key, purchase unit))
    orders: list[MaterialOrder] = field(default_factory=list)
    #: cost layer of each entry of ``unresolved`` (boundaries count the items in their layers)
    unresolved_layers: list[CostLayer] = field(default_factory=list)
    #: currency of the CostParameters money amounts and its factor to ``currency`` (None: no FX rate -> unpriced)
    param_currency: str = ""
    param_fx: Optional[float] = 1.0

    def unresolve(self, text: str, layer: CostLayer) -> None:
        """List an item that could not be priced (never priced as zero) under its cost layer."""
        self.unresolved.append(text)
        self.unresolved_layers.append(layer)

    def param_money(self, amount: float) -> Optional[float]:
        """A CostParameters money amount in the estimate currency (None when it cannot be converted)."""
        return None if self.param_fx is None else float(amount) * self.param_fx

    def param_src(self) -> str:
        if self.param_fx is None or self.param_currency == self.currency:
            return ""
        return f" converted {self.param_currency}->{self.currency} at FX ×{self.param_fx:g}"

    def add(self, *, line_id: str, layer: CostLayer, description: str, amount: float, cost_key: Optional[str] = None,
            quantity: Optional[float] = None, unit: str = "", rr: Optional[ResolvedRate] = None,
            rate_value: Optional[float] = None, quantity_line_id: Optional[str] = None,
            basis: Basis = Basis.ASSUMED, formula: str = "", notes: str = "") -> None:
        rate = rr.rate if rr is not None else None
        if rr is not None and rate is not None:
            self.used[(rr.cost_key, rr.unit)] = rr
        self.lines.append(CostLine.model_construct(
            line_id=line_id, layer=layer, description=description, cost_key=cost_key, quantity=quantity, unit=unit,
            rate_value=rate_value if rate_value is not None else (rr.value if rate is not None else None),
            rate_id=rate.rate_id if rate is not None else None, currency=self.currency, amount=float(amount),
            quantity_line_id=quantity_line_id, basis=basis, formula=formula,
            uncertainty_low=rate.uncertainty_low if rate is not None else 0.0,
            uncertainty_high=rate.uncertainty_high if rate is not None else 0.0, notes=notes))
        self.totals[layer] += float(amount)

    def miss(self, cost_key: str, unit: str, ref: str) -> None:
        self.missing.setdefault((cost_key, unit), []).append(ref)


def _rate_formula(qty: float, unit: str, rr: ResolvedRate, cur: str, amount: float) -> str:
    assert rr.rate is not None
    adj = f"; {', '.join(rr.adjustments)}" if rr.adjustments else ""
    return (f"{qty:.3f} {unit} × {cur} {rr.value:.4f}/{unit} = {cur} {amount:.2f} "
            f"[rate {rr.rate.rate_id}: {rr.rate.value:g} {rr.rate.currency}/{rr.rate.unit}{adj}]")


def _delivery_note(rr: Optional[ResolvedRate]) -> str:
    """How the delivery of a priced line's rate is handled (empty when delivery is included / not applicable)."""
    if rr is None or rr.rate is None:
        return ""
    r = rr.rate
    t = r.delivery_treatment
    label = t.value.replace("_", " ")
    if t in (DeliveryTreatment.DELIVERY_CHARGED_SEPARATELY, DeliveryTreatment.EX_WORKS):
        if r.delivery_charge is None:
            return f"Delivery: {label} - carriage NOT priced (no delivery_charge; listed as unresolved)."
        return f"Delivery: {label} - delivery charge priced once per order in layer 4."
    if t == DeliveryTreatment.COLLECTION:
        if r.delivery_charge is None:
            return "Delivery: collection - own transport to site NOT priced (listed as unresolved)."
        return "Delivery: collection - collection cost (delivery_charge) priced once per order in layer 4."
    if t == DeliveryTreatment.UNKNOWN:
        return "Delivery: treatment unknown - assumed included in the rate."
    return ""


def _join_notes(*parts: str) -> str:
    return " ".join(p for p in parts if p)


def _priced(st: _State, *, line_id: str, layer: CostLayer, description: str, cost_key: str, qty: float, unit: str,
            rr: ResolvedRate, basis: Basis, quantity_line_id: Optional[str] = None, notes: str = "") -> float:
    amount = qty * rr.value
    st.add(line_id=line_id, layer=layer, description=description, amount=amount, cost_key=cost_key, quantity=qty,
           unit=unit, rr=rr, quantity_line_id=quantity_line_id, basis=weakest_basis(basis, rr.basis),
           formula=_rate_formula(qty, unit, rr, st.currency, amount), notes=_join_notes(notes, _delivery_note(rr)))
    return amount


def _line_quantity(ln: QuantityLine) -> Optional[float]:
    for q in (ln.purchased_qty, ln.required_qty, ln.installed_qty):
        if q is not None:
            return float(q)
    return None


def _purchase_need(ln: QuantityLine) -> Optional[float]:
    """Unrounded purchase need of a line in purchase units (required x purchase_per_installed)."""
    if ln.required_qty is not None:
        return float(ln.required_qty) * float(ln.purchase_per_installed)
    if ln.purchased_qty is not None:
        return float(ln.purchased_qty)  # no unrounded figure available: the purchase as given
    if ln.installed_qty is not None:
        return float(ln.installed_qty) * float(ln.purchase_per_installed)
    return None


def _is_material_line(ln: QuantityLine) -> bool:
    return bool(ln.cost_key) and ln.cost_key.startswith("mat:") and ln.status != QuantityStatus.UNRESOLVED


@dataclass
class _Order:
    """Order-level purchase of one material (internal; exported as :class:`MaterialOrder`)."""

    cost_key: str
    unit: str
    rr: ResolvedRate
    lines: list[tuple[QuantityLine, float]]  # (line, unrounded need)
    pack: float = 1.0
    need: float = 0.0
    packs: int = 0
    purchased: float = 0.0
    amount: float = 0.0


def _plan_orders(st: _State, boq: BillOfQuantities, res: _Resolver,
                 mats: dict[str, MaterialSpec]) -> dict[tuple[str, str], _Order]:
    """Group the priceable ``mat:`` lines into one order per (cost key, purchase unit) and round it to packs."""
    orders: dict[tuple[str, str], _Order] = {}
    for ln in boq.lines:
        if not _is_material_line(ln):
            continue
        need = _purchase_need(ln)
        if need is None or need <= 0:
            continue
        unit = ln.purchase_unit or ln.unit
        rr = res.get(ln.cost_key, unit)
        if not rr.found:
            continue
        key = (ln.cost_key, unit)
        o = orders.get(key)
        if o is None:
            o = orders[key] = _Order(cost_key=ln.cost_key, unit=unit, rr=rr, lines=[])
        o.lines.append((ln, need))
    for (ck, unit), o in orders.items():
        packs_seen = {float(ln.pack_size) for ln, _ in o.lines}
        mid = next((ln.material_id for ln, _ in o.lines if ln.material_id), None)
        pack = packs_seen.pop() if len(packs_seen) == 1 else None
        if pack is None:
            mat = mats.get(mid or "")
            pack = float(mat.pack_size) if mat is not None else max(float(ln.pack_size) for ln, _ in o.lines)
            st.warnings.append(f"{ck}: the lines carry different pack sizes; the order is rounded to packs of "
                               f"{pack:g} {unit}")
        o.pack = pack if pack > 0 else 0.0
        o.need = sum(need for _, need in o.lines)
        if o.pack > 0:
            o.packs = 0 if o.need <= 0 else int(math.ceil(o.need / o.pack - PACK_TOLERANCE))
            o.purchased = o.packs * o.pack
        else:  # no packaging information: buy the need as is
            o.packs, o.purchased = 0, o.need
        o.amount = o.purchased * o.rr.value
        r = o.rr.rate
        st.orders.append(MaterialOrder(
            cost_key=ck, material_id=mid, purchase_unit=unit, pack_size=o.pack, purchase_required=o.need,
            packs=o.packs, purchased=o.purchased, rate_id=r.rate_id if r is not None else None,
            rate_value=o.rr.value, amount=o.amount, line_ids=[ln.line_id for ln, _ in o.lines],
            line_level_purchased=sum(float(ln.purchased_qty or 0.0) for ln, _ in o.lines)))
    return orders


def _price_material_line(st: _State, ln: QuantityLine, need: float, o: _Order, note: str) -> None:
    """Allocate the order of ``o`` to line ``ln`` pro rata to its unrounded need."""
    rr = o.rr
    cur, unit = st.currency, o.unit
    share = need / o.need if o.need > 0 else 0.0
    qty = o.purchased * share
    amount = qty * rr.value
    if len(o.lines) == 1:
        order_txt = f"{need:.3f} {unit} required"
    else:
        order_txt = (f"share {need:.3f} / {o.need:.3f} {unit} ({share:.2%}) of the {o.cost_key} order over "
                     f"{len(o.lines)} lines")
    rounding = (f"ceil({o.need:.3f} / {o.pack:g} per pack) = {o.packs} packs = {o.purchased:.3f} {unit}"
                if o.pack > 0 else f"{o.purchased:.3f} {unit} (no pack size)")
    formula = f"{order_txt}; order {rounding}; allocated " + _rate_formula(qty, unit, rr, cur, amount)
    st.add(line_id=f"1:{ln.line_id}", layer=L1, description=ln.description, amount=amount, cost_key=o.cost_key,
           quantity=qty, unit=unit, rr=rr, quantity_line_id=ln.line_id, basis=weakest_basis(ln.basis, rr.basis),
           formula=formula, notes=_join_notes(note, "Priced at order level (pack rounding on the material's total, "
                                                    "allocated pro rata).", _delivery_note(rr)))


# =============================================================================
# Layers 1-3 from quantity lines
# =============================================================================
def _price_quantity_lines(st: _State, boq: BillOfQuantities, res: _Resolver, rules: CostRules,
                          mats: dict[str, MaterialSpec]) -> dict[str, float]:
    """Layers 1-4 lines that come straight from BoQ lines; returns aggregates for the rules."""
    agg = {"groundworks_hours": 0.0, "excavation_m3": 0.0}
    orders = _plan_orders(st, boq, res, mats)
    for ln in boq.lines:
        if ln.status == QuantityStatus.UNRESOLVED:
            reason = (ln.notes or ln.formula or "no reason given").removeprefix("UNRESOLVED: ")
            st.unresolve(f"{ln.line_id} ({ln.description}): quantity unresolved - {reason}; not priced", L1)
            continue
        ck = ln.cost_key
        if ck:
            qty = _line_quantity(ln)
            unit = ln.purchase_unit or ln.unit
            note = "Labelled allowance (not measured)." if ln.status == QuantityStatus.ALLOWANCE else ""
            order = orders.get((ck, unit)) if ck.startswith("mat:") else None
            if qty is None:
                st.unresolve(f"{ln.line_id} ({ln.description}): no quantity on a {ln.status.value} line; "
                             "not priced", cost_key_layer(ck) or L1)
            elif order is not None:
                need = _purchase_need(ln) or 0.0
                if need > 0:
                    _price_material_line(st, ln, need, order, note)
            elif qty > 0:
                layer = cost_key_layer(ck)
                rr = res.get(ck, unit)
                if rr.found:
                    layer = layer or rr.rate.layer
                    _priced(st, line_id=f"{layer.value[0]}:{ln.line_id}", layer=layer, description=ln.description,
                            cost_key=ck, qty=qty, unit=unit, rr=rr, basis=ln.basis, quantity_line_id=ln.line_id,
                            notes=note)
                    if ck == "plant:excavation":
                        agg["excavation_m3"] += qty
                elif ck == "plant:excavation" and res.get("plant:excavator", "hr").found:
                    rx = res.get("plant:excavator", "hr")
                    hours = qty * rules.excavator_hours_per_m3
                    amount = hours * rx.value
                    st.add(line_id=f"3:{ln.line_id}", layer=L3, description=f"{ln.description} (excavator hours)",
                           amount=amount, cost_key="plant:excavator", quantity=hours, unit="hr", rr=rx,
                           quantity_line_id=ln.line_id, basis=weakest_basis(ln.basis, rx.basis, Basis.ASSUMED),
                           formula=f"{qty:.3f} m3 bank × {rules.excavator_hours_per_m3:g} hr/m3 = {hours:.3f} hr; "
                                   + _rate_formula(hours, "hr", rx, st.currency, amount),
                           notes=_join_notes("No per-m3 excavation rate: priced as excavator hours (CostRules "
                                             "assumption).", _delivery_note(rx)))
                    agg["excavation_m3"] += qty
                else:
                    st.miss(ck, unit, ln.line_id)
        hours = ln.labour_hours
        if hours is not None and hours > 0:
            lk = f"lab:{ln.trade}"
            rr = res.get(lk, "hr")
            if rr.found:
                _priced(st, line_id=f"2:{ln.line_id}", layer=L2, description=f"Labour ({ln.trade}) - {ln.description}",
                        cost_key=lk, qty=float(hours), unit="hr", rr=rr, basis=ln.basis, quantity_line_id=ln.line_id)
            else:
                st.miss(lk, "hr", ln.line_id)
            if ln.trade == "groundworks":
                agg["groundworks_hours"] += float(hours)
    return agg


# =============================================================================
# Layer 3 derived plant
# =============================================================================
def _derived_plant(st: _State, boq: BillOfQuantities, res: _Resolver, rules: CostRules, weeks: float,
                   weeks_basis: Basis, agg: dict[str, float]) -> None:
    gw = agg["groundworks_hours"]
    items: list[tuple[str, str, str, float, str]] = []
    if gw > 0:
        dw = math.ceil(gw / rules.dumper_gang_hours_per_week - 1e-9)
        items.append(("dumper", "plant:dumper", "week", float(dw),
                      f"ceil({gw:.2f} groundworks hr / {rules.dumper_gang_hours_per_week:g} hr per dumper-week) "
                      f"= {dw} week"))
    ext = boq.geometry.external_wall_gross_m2
    if ext > 0 and weeks > 0:
        sw = rules.scaffold_programme_share * weeks
        m2wk = ext * rules.scaffold_area_factor * sw
        items.append(("scaffold", "plant:scaffold", "m2_week", m2wk,
                      f"{ext:.3f} m2 external wall gross × {rules.scaffold_area_factor:g} face factor × "
                      f"({rules.scaffold_programme_share:g} × {weeks:g} wk) = {m2wk:.3f} m2-week"))
    if weeks > 0:
        tw = math.ceil(rules.telehandler_programme_share * weeks - 1e-9)
        items.append(("telehandler", "plant:telehandler", "week", float(tw),
                      f"ceil({rules.telehandler_programme_share:g} × {weeks:g} programme weeks) = {tw} week"))
    for name, ck, unit, qty, rule_txt in items:
        if qty <= 0:
            continue
        rr = res.get(ck, unit)
        if not rr.found:
            st.miss(ck, unit, f"plant rule '{name}' ({qty:.2f} {unit})")
            continue
        amount = qty * rr.value
        st.add(line_id=f"3:plant.{name}", layer=L3, description=f"{name.capitalize()} hire (derived plant rule)",
               amount=amount, cost_key=ck, quantity=qty, unit=unit, rr=rr,
               basis=weakest_basis(Basis.ASSUMED, weeks_basis if name != "dumper" else Basis.ASSUMED, rr.basis),
               formula=rule_txt + "; " + _rate_formula(qty, unit, rr, st.currency, amount),
               notes=_join_notes("Derived from BoQ / programme by a labelled CostRules assumption.",
                                 _delivery_note(rr)))


# =============================================================================
# Layer 4 logistics & waste
# =============================================================================
def _material_waste_volume(ln: QuantityLine, mat: MaterialSpec) -> Optional[float]:
    w = (ln.cutting_loss_qty or 0.0) + (ln.waste_qty or 0.0)
    if w <= 0:
        return 0.0
    if mat.installed_unit == "m3":
        return w
    pu = w * (ln.purchase_per_installed or mat.purchase_per_installed)
    if mat.volume_per_purchase_unit_m3:
        return pu * mat.volume_per_purchase_unit_m3
    if mat.mass_per_purchase_unit_kg and mat.density_kg_m3:
        return pu * mat.mass_per_purchase_unit_kg / mat.density_kg_m3
    return None


def _log_rate(st: _State, res: _Resolver, ck: str, unit: str, fallback: float, fallback_name: str
              ) -> tuple[Optional[ResolvedRate], Optional[float], str]:
    """Rate for a logistics / preliminaries key, else the CostParameters fallback in the estimate currency.

    The fallback is entered in ``CostParameters.currency``: it is converted with the project FX rate, and
    without one it is NOT used (value ``None``; the caller lists the item as unresolved) - a GBP 1,800 /
    week fallback is never re-labelled as EUR 1,800 / week.
    """
    rr = res.get(ck, unit)
    if rr.found:
        return rr, rr.value, f"rate {rr.rate.rate_id}"
    val = st.param_money(fallback)
    if val is None:
        return None, None, (f"no usable '{ck}' rate, and the fallback CostParameters.{fallback_name} = "
                            f"{st.param_currency} {fallback:,.2f} has no FX rate {st.param_currency}->{st.currency}")
    return None, val, (f"CostParameters.{fallback_name} (fallback: no usable '{ck}' rate; assumption"
                       f"{st.param_src()})")


def _delivery_line_id(cost_key: str) -> str:
    """``4:log.delivery_charge.<item>`` for ``mat:`` keys (stable ids), ``...<prefix>.<item>`` for other keys."""
    prefix, _, item = cost_key.partition(":")
    return f"4:log.delivery_charge.{item}" if prefix == "mat" else f"4:log.delivery_charge.{prefix}.{item}"


def _delivery_charges(st: _State) -> None:
    """Delivery treatment of every rate actually used (materials, allowances, plant, rule keys): one order each.

    ``delivery_charged_separately`` / ``ex_works`` / ``collection`` with a ``delivery_charge`` -> one layer-4
    line per cost key; without a charge -> listed in ``unresolved_items`` (never priced as zero);
    ``unknown`` -> warned and assumed included.
    """
    cur = st.currency
    seen: set[tuple[str, str]] = set()
    for rr in list(st.used.values()):
        r = rr.rate
        ck = rr.cost_key
        if r is None or (ck, r.rate_id) in seen:
            continue
        seen.add((ck, r.rate_id))
        t = r.delivery_treatment
        label = t.value.replace("_", " ")
        if t in (DeliveryTreatment.DELIVERY_CHARGED_SEPARATELY, DeliveryTreatment.EX_WORKS,
                 DeliveryTreatment.COLLECTION):
            if r.delivery_charge is None:
                what = ("own transport to site (collection)" if t == DeliveryTreatment.COLLECTION
                        else "carriage to site")
                st.unresolve(f"{ck}: rate '{r.rate_id}' is {label} but has no delivery_charge; {what} not "
                             "priced - enter a delivery charge per order or use a delivered rate", L4)
                continue
            amount = float(r.delivery_charge) * rr.money_factor
            item = ck.split(":", 1)[1]
            kind = "Collection / own transport cost" if t == DeliveryTreatment.COLLECTION else \
                "Supplier delivery charge"
            st.add(line_id=_delivery_line_id(ck), layer=L4, description=f"{kind} - {item} (1 order)", amount=amount,
                   cost_key=ck, quantity=1.0, unit="order", rr=rr, rate_value=amount,
                   basis=weakest_basis(Basis.ASSUMED, rr.basis),
                   formula=f"1 order × {r.delivery_charge:g} {r.currency} delivery charge ({label})"
                           + (f" × {rr.money_factor:.4f}" if abs(rr.money_factor - 1) > 1e-12 else "")
                           + f" = {cur} {amount:.2f} [rate {r.rate_id}]",
                   notes=f"One delivery order per cost key assumed ({ck}).")
        elif t == DeliveryTreatment.UNKNOWN:
            st.warnings.append(f"{ck}: delivery treatment of rate '{r.rate_id}' is unknown; assumed included.")


def _logistics(st: _State, boq: BillOfQuantities, res: _Resolver, params: CostParameters, rules: CostRules,
               logistics: Optional[LogisticsResult], mats: dict[str, MaterialSpec]) -> None:
    cur = st.currency
    priced_mat_lines = [ln for ln in boq.lines
                        if _is_material_line(ln) and (_line_quantity(ln) or 0.0) > 0]
    # ---- delivery loads
    if logistics is not None:
        loads = int(logistics.total_loads)
        loads_txt = f"{loads} loads from the logistics plan"
        loads_basis = Basis.ASSUMED
    else:
        # purchase quantity per material: the order where one was priced, else the lines' own purchases
        qty_by_mat: dict[str, float] = {}
        ordered = {lid for o in st.orders for lid in o.line_ids}
        for o in st.orders:
            mid = o.material_id or o.cost_key.split(":", 1)[1]
            qty_by_mat[mid] = qty_by_mat.get(mid, 0.0) + o.purchased
        for ln in priced_mat_lines:
            if ln.line_id in ordered:
                continue
            mid = ln.material_id or ln.cost_key.split(":", 1)[1]
            qty_by_mat[mid] = qty_by_mat.get(mid, 0.0) + (_line_quantity(ln) or 0.0)
        mat_loads = 0
        for mid, q in qty_by_mat.items():
            mat = mats.get(mid)
            mass = q * (mat.mass_per_purchase_unit_kg or 0.0) if mat is not None else 0.0
            vol = q * (mat.volume_per_purchase_unit_m3 or 0.0) if mat is not None else 0.0
            mat_loads += max(1, math.ceil(max(mass / rules.lorry_payload_kg, vol / rules.lorry_payload_m3) - 1e-9))
        allow_orders = len({ln.cost_key for ln in boq.lines if ln.status != QuantityStatus.UNRESOLVED
                            and ln.cost_key and ln.cost_key.startswith("allow:") and (_line_quantity(ln) or 0) > 0})
        loads = mat_loads + allow_orders
        loads_txt = (f"{mat_loads} loads for {len(qty_by_mat)} material orders (payload "
                     f"{rules.lorry_payload_kg / 1000:g} t / {rules.lorry_payload_m3:g} m3) + {allow_orders} "
                     f"allowance deliveries = {loads} loads (estimate; no logistics plan supplied)")
        loads_basis = Basis.ASSUMED
    if loads > 0:
        ck, unit = COST_PARAMETER_FALLBACKS["cost_per_delivery_load"]
        rr, val, src = _log_rate(st, res, ck, unit, params.cost_per_delivery_load, "cost_per_delivery_load")
        if val is None:
            st.unresolve(f"delivery loads ({loads} load(s)): {src}; not priced", L4)
        else:
            amount = loads * val
            st.add(line_id="4:log.delivery_loads", layer=L4, description="Delivery loads - site receipt and handling",
                   amount=amount, cost_key=ck, quantity=float(loads), unit="load", rr=rr,
                   rate_value=val, basis=weakest_basis(loads_basis, rr.basis if rr else Basis.ASSUMED),
                   formula=f"{loads_txt}; × {cur} {val:.2f}/load ({src}) = {cur} {amount:.2f}",
                   notes="Supplier carriage is in the rates unless charged separately (delivery charges below).")
    # ---- waste skips
    vol = 0.0
    no_data: list[str] = []
    for ln in priced_mat_lines:
        mat = mats.get(ln.material_id or "")
        v = _material_waste_volume(ln, mat) if mat is not None else None
        if v is None:
            if (ln.cutting_loss_qty or 0) + (ln.waste_qty or 0) > 0:
                no_data.append(ln.material_id or ln.line_id)
            continue
        vol += v
    if no_data:
        st.warnings.append("Waste volume not estimated for material(s) without volume/mass data: "
                           + ", ".join(sorted(set(no_data))))
    if vol > 0:
        bulk, skip_v = params.waste_bulking_factor, params.skip_volume_m3
        skips = math.ceil(vol * bulk / skip_v - 1e-9)
        ck, unit = COST_PARAMETER_FALLBACKS["cost_per_skip"]
        rr, val, src = _log_rate(st, res, ck, unit, params.cost_per_skip, "cost_per_skip")
        if val is None:
            st.unresolve(f"waste skips ({skips} skip(s)): {src}; not priced", L4)
            return
        amount = skips * val
        st.add(line_id="4:log.skips", layer=L4, description="Waste skips (cutting and waste losses)", amount=amount,
               cost_key=ck, quantity=float(skips), unit="nr", rr=rr, rate_value=val,
               basis=weakest_basis(Basis.ASSUMED, rr.basis if rr else Basis.ASSUMED),
               formula=f"ceil({vol:.3f} m3 waste × bulking {bulk:g} / {skip_v:g} m3 skip) = {skips} skips × "
                       f"{cur} {val:.2f} ({src}) = {cur} {amount:.2f}",
               notes="Waste volume from BoQ cutting + waste quantities via material volume per purchase unit.")
        if logistics is not None and logistics.skips and logistics.skips != skips:
            st.notes.append(f"Logistics plan reports {logistics.skips} skips; the cost engine priced {skips} skips "
                            "from the BoQ losses and CostParameters (bulking, skip volume).")


# =============================================================================
# Layers 5-9
# =============================================================================
def _prelims(st: _State, res: _Resolver, params: CostParameters, weeks: float, weeks_basis: Basis,
             weeks_src: str) -> None:
    cur = st.currency
    ck, unit = COST_PARAMETER_FALLBACKS["prelims_fixed_setup"]
    rr, val, src = _log_rate(st, res, ck, unit, params.prelims_fixed_setup, "prelims_fixed_setup")
    if val is None:
        st.unresolve(f"site set-up (fixed preliminaries): {src}; not priced", L5)
    else:
        st.add(line_id="5:prelim.setup", layer=L5, description="Site set-up (fixed preliminaries)", amount=val,
               cost_key="prelim:setup", quantity=1.0, unit="sum", rr=rr, rate_value=val,
               basis=rr.basis if rr else Basis.ASSUMED, formula=f"1 sum × {cur} {val:.2f} ({src})")
    ck, unit = COST_PARAMETER_FALLBACKS["prelims_weekly_cost"]
    rr, val, src = _log_rate(st, res, ck, unit, params.prelims_weekly_cost, "prelims_weekly_cost")
    if val is None:
        st.unresolve(f"time-related preliminaries ({weeks:g} weeks): {src}; not priced", L5)
        return
    amount = weeks * val
    st.add(line_id="5:prelim.weekly", layer=L5, description="Time-related preliminaries", amount=amount,
           cost_key="prelim:weekly", quantity=weeks, unit="week", rr=rr, rate_value=val,
           basis=weakest_basis(weeks_basis, rr.basis if rr else Basis.ASSUMED),
           formula=f"{weeks:g} weeks ({weeks_src}) × {cur} {val:.2f}/week ({src}) = {cur} {amount:.2f}")


def _sum(st: _State, layers: list[CostLayer]) -> float:
    return sum(st.totals[layer] for layer in layers)


def _fees_to_margin(st: _State, params: CostParameters) -> None:
    cur = st.currency
    direct = _sum(st, [L1, L2, L3, L4])
    construction = direct + st.totals[L5]
    for i, fee in enumerate(params.fees):
        base, label = (direct, "layers 1-4") if fee.applies_to == "direct" else (construction, "layers 1-5")
        amount = fee.fraction * base
        st.add(line_id=f"6:fee.{i}.{_slug(fee.name)}", layer=L6, description=fee.name, amount=amount,
               quantity=base, unit=cur, rate_value=fee.fraction, basis=fee.basis,
               formula=f"{fee.fraction:.2%} × {cur} {base:.2f} ({label}) = {cur} {amount:.2f}", notes=fee.note)
    b7 = _sum(st, _LAYERS[:6])
    amount = params.contingency_fraction * b7
    st.add(line_id="7:contingency", layer=L7, description="Risk contingency", amount=amount, quantity=b7, unit=cur,
           rate_value=params.contingency_fraction, basis=Basis.ASSUMED,
           formula=f"{params.contingency_fraction:.2%} × {cur} {b7:.2f} (layers 1-6) = {cur} {amount:.2f}",
           notes=params.contingency_basis)
    b8 = _sum(st, _LAYERS[:7])
    oh = params.overhead_fraction * b8
    st.add(line_id="8:overhead", layer=L8, description="Contractor overhead", amount=oh, quantity=b8, unit=cur,
           rate_value=params.overhead_fraction, basis=Basis.ASSUMED,
           formula=f"{params.overhead_fraction:.2%} × {cur} {b8:.2f} (layers 1-7) = {cur} {oh:.2f}")
    mb = b8 + oh
    margin = params.margin_fraction * mb
    st.add(line_id="8:margin", layer=L8, description="Contractor margin", amount=margin, quantity=mb, unit=cur,
           rate_value=params.margin_fraction, basis=Basis.ASSUMED,
           formula=f"{params.margin_fraction:.2%} × {cur} {mb:.2f} (layers 1-7 + overhead) = {cur} {margin:.2f}")


def _layer9(st: _State, params: CostParameters, settings: ProjectSettings, rules: CostRules) -> bool:
    cur = st.currency
    contract = _sum(st, _LAYERS[:8])
    entered = False
    no_fx = f"is in {st.param_currency} and no FX rate {st.param_currency}->{cur} is set; not included"
    land = params.land_cost
    if land is not None:
        land_v = st.param_money(land)
        if land_v is None:
            st.unresolve(f"land: {no_fx}", L9)
            land = None
        else:
            st.add(line_id="9:land", layer=L9, description="Land (as entered)", amount=land_v, quantity=1.0,
                   unit="sum", rate_value=land_v, basis=Basis.USER_CONFIRMED,
                   formula=f"{cur} {land_v:.2f} as entered" + (f" ({st.param_currency} {land:.2f}{st.param_src()})"
                                                                if st.param_currency != cur else ""))
            land = land_v
            entered = True
    fr, fm = params.finance_rate_annual, params.finance_months
    if fr is not None and fm is not None:
        dd = rules.finance_drawdown_fraction
        base = (land or 0.0) + dd * contract
        amount = fr * fm / 12.0 * base
        st.add(line_id="9:finance", layer=L9, description="Development finance (indicative)", amount=amount,
               quantity=base, unit=cur, rate_value=fr, basis=Basis.ASSUMED,
               formula=f"{fr:.2%}/yr × {fm:g}/12 yr × ({cur} {land or 0.0:.2f} land + {dd:g} × {cur} {contract:.2f} "
                       f"contract sum) = {cur} {amount:.2f}",
               notes="Land drawn at start; build cost drawn evenly (average 50% outstanding) - assumption.")
        entered = True
    elif fr is not None or fm is not None:
        st.unresolve("finance: both finance_rate_annual and finance_months are needed; finance not priced", L9)
    for name, amt in sorted(params.taxes.items()):
        if not math.isfinite(float(amt)):
            st.unresolve(f"tax '{name}': amount is not a finite number; not included", L9)
            continue
        amt_v = st.param_money(float(amt))
        if amt_v is None:
            st.unresolve(f"tax '{name}': {no_fx}", L9)
            continue
        st.add(line_id=f"9:tax.{_slug(name)}", layer=L9, description=f"{name} (as entered)", amount=amt_v,
               quantity=1.0, unit="sum", rate_value=amt_v, basis=Basis.USER_CONFIRMED,
               formula=f"{cur} {amt_v:.2f} as entered" + (f" ({st.param_currency} {float(amt):.2f}{st.param_src()})"
                                                         if st.param_currency != cur else ""),
               notes="Entered by the user; not computed or verified.")
        entered = True
    if settings.include_vat:
        vr = settings.vat_rate
        amount = vr * contract
        st.add(line_id="9:vat", layer=L9, description="VAT on contract sum (as entered - check applicable treatment)",
               amount=amount, quantity=contract, unit=cur, rate_value=vr, basis=Basis.ASSUMED,
               formula=f"{vr:.2%} × {cur} {contract:.2f} contract sum = {cur} {amount:.2f}",
               notes="VAT rate as entered in settings; the applicable treatment (standard / reduced / zero-rated) "
                     "is not determined here.")
        entered = True
    sf = params.sales_cost_fraction
    if sf is not None:
        sv = None if params.sales_value is None else st.param_money(params.sales_value)
        if params.sales_value is None:
            st.unresolve("sales costs: sales_cost_fraction entered without a sales_value; not priced", L9)
        elif sv is None:
            st.unresolve(f"sales costs: the sales value {no_fx}", L9)
        else:
            amount = sf * sv
            st.add(line_id="9:sales_costs", layer=L9, description="Sales and marketing costs", amount=amount,
                   quantity=sv, unit=cur, rate_value=sf, basis=Basis.ASSUMED,
                   formula=f"{sf:.2%} × {cur} {sv:.2f} sales value = {cur} {amount:.2f}")
            entered = True
    return entered


# =============================================================================
# Public entry point
# =============================================================================
def estimate_construction_cost(boq: BillOfQuantities, rate_book: RateBook, params: CostParameters, *,
                               settings: ProjectSettings, programme_weeks: Optional[float] = None,
                               logistics: Optional[LogisticsResult] = None,
                               library: Optional[AssemblyLibrary] = None,
                               rules: CostRules = DEFAULT_COST_RULES) -> CostEstimate:
    """Price ``boq`` with ``rate_book`` into a nine-layer :class:`CostEstimate` (see module docstring).

    ``programme_weeks`` (e.g. from the programme module) drives time-related prelims and plant;
    without it ``params.default_programme_weeks`` is used and flagged.  ``logistics`` supplies
    delivery loads.  ``library`` supplies material masses / volumes for loads and waste (default:
    the bundled generic library).  Never raises for missing data: it is listed in
    ``unresolved_items``.
    """
    cur = settings.currency
    st = _State(currency=cur)
    pcur = (params.currency or cur).strip().upper()
    st.param_currency = pcur
    if pcur != cur:
        fx = settings.fx_rates.get(pcur)
        st.param_fx = float(fx) if fx is not None and fx > 0 else None
        st.warnings.append(
            f"Commercial parameters (fallbacks, land, taxes, sales value) are in {pcur}, the estimate in {cur}: "
            + (f"converted at FX 1 {pcur} = {st.param_fx:g} {cur}." if st.param_fx is not None else
               f"no FX rate {pcur}->{cur} is set, so the fallbacks and layer-9 amounts are NOT priced (listed as "
               "unresolved). Set the FX rate in the sidebar settings or re-enter them in "
               f"{cur} (Costs -> Commercial parameters)."))
    idx = rate_index(rate_book)
    res = _Resolver(idx, settings)
    lib = library if library is not None else _default_library()
    mats = {m.material_id: m for m in lib.materials}
    if programme_weeks is not None and (not math.isfinite(programme_weeks) or programme_weeks < 0):
        st.warnings.append(f"programme_weeks {programme_weeks!r} is invalid; default used")
        programme_weeks = None
    if programme_weeks is None:
        weeks, weeks_basis = float(params.default_programme_weeks), Basis.ASSUMED
        weeks_src = "CostParameters.default_programme_weeks (assumed)"
        st.warnings.append(f"Programme length assumed at {weeks:g} weeks (no programme supplied); time-related "
                           "preliminaries and plant depend on it.")
    else:
        weeks, weeks_basis, weeks_src = float(programme_weeks), Basis.INFERRED, "indicative programme"

    agg = _price_quantity_lines(st, boq, res, rules, mats)
    _derived_plant(st, boq, res, rules, weeks, weeks_basis, agg)
    _logistics(st, boq, res, params, rules, logistics, mats)
    _prelims(st, res, params, weeks, weeks_basis, weeks_src)
    # delivery treatment of every rate used so far (materials, allowances, plant, logistics, prelims)
    _delivery_charges(st)
    # Missing rates are summarised before percentage layers so the user sees them grouped.
    for (ck, unit), refs in st.missing.items():
        rr = res.get(ck, unit)
        why = "; ".join(rr.warnings) or "no rate"
        shown = ", ".join(refs[:6]) + (f" (+{len(refs) - 6} more)" if len(refs) > 6 else "")
        st.unresolve(f"missing rate {ck} per {unit}: {len(refs)} item(s) not priced [{shown}] - {why}",
                     cost_key_layer(ck) or L1)
    _fees_to_margin(st, params)
    l9 = _layer9(st, params, settings, rules)

    # ---- warnings / notes from rate resolution (deduplicated)
    esc = sorted({rr.rate.rate_id for rr in st.used.values() if rr.escalation_factor != 1.0})
    reg = sorted({rr.rate.rate_id for rr in st.used.values() if rr.regional_factor != 1.0})
    for rr in st.used.values():
        st.warnings.extend(rr.warnings)
    firm = sorted({rr.rate.rate_id for rr in st.used.values()
                   if any(a.startswith("not escalated") for a in rr.adjustments)})
    if esc or firm:
        st.notes.append(f"Escalation at {settings.annual_escalation_rate:+.1%}/yr applied to {len(esc)} rate(s) dated "
                        f"before the pricing date {settings.pricing_date.isoformat()} (assumption)"
                        + (f"; {len(firm)} rate(s) valid on the pricing date (firm quotes / price lists) were not "
                           "escalated." if firm else "."))
    if settings.regional_cost_factor != 1.0:
        local = len({rr.rate.rate_id for rr in st.used.values()}) - len(reg)
        st.notes.append(f"Regional cost factor ×{settings.regional_cost_factor:g} applied to {len(reg)} rate(s) not "
                        f"located in the project area; {local} rate(s) were not adjusted (located in the project area, "
                        "or supplier quotes without a location - treated as quoted for the site).")
    used_rates = {rr.rate.rate_id: rr.rate for rr in st.used.values()}
    fictional = sum(1 for r in used_rates.values() if _is_fictional(r))
    if fictional:
        st.warnings.append(f"{fictional} of {len(used_rates)} rates used are labelled FICTIONAL (demo data) - not "
                           "market prices.")
    st.warnings.extend(f"rate book: {w}" for w in rate_book.warnings[:20])
    _pricing_date_summary(st, settings)
    _incomplete_summary(st, res, settings)
    _order_level_note(st)
    if params.sales_value is not None:
        sv = st.param_money(params.sales_value)
        if sv is None:
            st.warnings.append(f"Sales value {st.param_currency} {params.sales_value:.2f} is not reported: no FX rate "
                               f"{st.param_currency}->{cur} is set.")
        else:
            st.notes.append(f"Sales value {cur} {sv:.2f} is reported separately; it is not a cost and is not netted "
                            "off any boundary.")

    # ---- boundaries
    boundaries: list[CostBoundary] = []
    for key, name, layers, definition, excludes in _BOUNDARY_DEFS:
        if key == "total_development_cost" and not l9:
            continue
        in_b = set(layers)
        bases = [ln.basis for ln in st.lines if ln.layer in in_b]
        boundaries.append(CostBoundary(key=key, name=name, layers=list(layers), amount=_sum(st, layers),
                                       definition=definition, excludes=excludes,
                                       basis=weakest_basis(bases) if bases else Basis.UNKNOWN,
                                       unresolved_count=sum(1 for lay in st.unresolved_layers if lay in in_b)))
    layer_totals = {layer.value: st.totals[layer] for layer in CostLayer}
    conventions = dict(COST_CONVENTIONS)
    conventions["programme_weeks"] = f"{weeks:g} weeks ({weeks_src})"
    conventions["layers"] = "; ".join(f"{layer.value}: {COST_LAYER_NAMES[layer]}" for layer in CostLayer)
    if library is None:
        conventions["material_data"] = "Material masses / volumes from the bundled generic library (none passed)."
    return CostEstimate(
        currency=cur, pricing_date=settings.pricing_date, location=settings.site_location,
        rate_book_name=rate_book.name, lines=st.lines, layer_totals=layer_totals, boundaries=boundaries,
        gia_m2=float(boq.geometry.gia_m2), unresolved_items=st.unresolved, warnings=_dedupe(st.warnings),
        sales_value=None if params.sales_value is None else st.param_money(params.sales_value),
        programme_weeks=weeks, conventions=conventions, notes=_dedupe(st.notes),
        material_orders=st.orders,
    )


def _pricing_date_summary(st: _State, settings: ProjectSettings) -> None:
    """Prominent first warning when newer, higher-priority rates were excluded only by the pricing date."""
    pairs: list[str] = []
    for rr in st.used.values():
        for rid in rr.excluded_newer:
            used = rr.rate.rate_id + (" (FICTIONAL)" if _is_fictional(rr.rate) else "")
            txt = f"{rid} for {rr.cost_key} -> {used} used"
            if txt not in pairs:
                pairs.append(txt)
    if pairs:
        st.warnings.insert(0, f"{PRICING_DATE_WARNING}: {len(pairs)} newer, higher-priority rate(s) are dated after the "
                              f"pricing date {settings.pricing_date.isoformat()} and were excluded, so lower-priority "
                              f"rates priced the estimate ({'; '.join(pairs[:8])}"
                              + (f"; +{len(pairs) - 8} more" if len(pairs) > 8 else "")
                              + "). Move the pricing date forward if the newer rates should apply.")


def _incomplete_summary(st: _State, res: _Resolver, settings: ProjectSettings) -> None:
    """Prominent first warning when items of layers 1-5 are unpriced: the boundaries are then lower bounds.

    Names the cause found in the rate resolutions (rates in another currency without an FX rate, rates dated
    after the pricing date, no rate at all) so a currency switch or an early pricing date is not mistaken
    for a cheap house.
    """
    direct = [lay for lay in st.unresolved_layers if lay in _LAYERS[:5]]
    if not direct:
        return
    fx_keys, future_keys, other_keys = set(), set(), set()
    for (ck, unit) in st.missing:
        ws = res.get(ck, unit).warnings
        if any("no fx rate" in w for w in ws):
            fx_keys.add(ck)
        elif any("after the pricing date" in w for w in ws):
            future_keys.add(ck)
        else:
            other_keys.add(ck)
    causes = []
    if fx_keys:
        curs = sorted({r.currency for ck in fx_keys for r in res.idx.candidates(ck) if r.currency != st.currency})
        causes.append(f"{len(fx_keys)} cost key(s) only have rates in {', '.join(curs) or 'another currency'} and no FX "
                      f"rate to {st.currency} is set (sidebar settings)")
    if future_keys:
        causes.append(f"{len(future_keys)} cost key(s) only have rates dated after the pricing date "
                      f"{settings.pricing_date.isoformat()}")
    if other_keys:
        causes.append(f"{len(other_keys)} cost key(s) have no usable rate in the rate book")
    if st.param_fx is None:
        causes.append(f"the CostParameters fallbacks are in {st.param_currency} without an FX rate to {st.currency}")
    priced = sum(1 for ln in st.lines if ln.layer in _LAYERS[:5])
    st.warnings.insert(0, f"{INCOMPLETE_WARNING}: {len(direct)} item(s) in layers 1-5 are not priced "
                          f"({priced} cost line(s) in those layers are)"
                          + (f" - {'; '.join(causes)}" if causes else "")
                          + ". Every cost boundary excludes them, so the amounts are lower bounds, not the cost.")


def _order_level_note(st: _State) -> None:
    """Note what per-line pack rounding would have added compared with the order-level pricing used."""
    extra = sum(max(0.0, o.line_level_purchased - o.purchased) * o.rate_value for o in st.orders)
    multi = sum(1 for o in st.orders if len(o.line_ids) > 1)
    if st.orders:
        st.notes.append(f"Materials are priced per order: {len(st.orders)} material order(s) ({multi} spanning several "
                        f"BoQ lines) are rounded to whole packs once and allocated to the lines pro rata"
                        + (f"; rounding each line separately would have added about {st.currency} {extra:.0f}."
                           if extra > 0.5 else "."))


def _is_fictional(rate) -> bool:
    return (rate.source_type.value == "fictional_demo" or "fictional" in rate.source.lower()
            or "fictional" in rate.supplier.lower())


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for s in items:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


# =============================================================================
# Presentation helpers
# =============================================================================
def cost_lines_table(estimate: CostEstimate) -> list[dict]:
    """Flat rows for tables / CSV export (one per cost line)."""
    return [{
        "line_id": ln.line_id, "layer": ln.layer.value, "layer_name": COST_LAYER_NAMES[ln.layer],
        "description": ln.description, "cost_key": ln.cost_key, "quantity": ln.quantity, "unit": ln.unit,
        "rate": ln.rate_value, "rate_id": ln.rate_id, "amount": ln.amount, "currency": ln.currency,
        "basis": ln.basis.value, "uncertainty_low": ln.uncertainty_low, "uncertainty_high": ln.uncertainty_high,
        "quantity_line_id": ln.quantity_line_id, "formula": ln.formula, "notes": ln.notes,
    } for ln in estimate.lines]


def boundary_table(estimate: CostEstimate) -> list[dict]:
    """One row per cost boundary with amount, per-m2 GIA, definition and exclusions."""
    gia = estimate.gia_m2
    return [{
        "key": b.key, "name": b.name, "amount": b.amount,
        "per_m2_gia": b.amount / gia if gia > 0 else None, "layers": [layer.value for layer in b.layers],
        "definition": b.definition, "excludes": b.excludes, "basis": b.basis.value,
        "unresolved_count": b.unresolved_count,
    } for b in estimate.boundaries]
