import math

import pytest

from housebuilder_engine.core.errors import GeometryError
from housebuilder_engine.geometry_engine.bamboo_geometry import (
    BambooGrade,
    BambooPoleGeometry,
    approximate_mass,
    cross_sectional_area,
    radius_of_gyration,
    second_moment_of_area,
    section_modulus,
    slenderness_ratio,
)


def _geom(outer=100.0, thickness=10.0, length=3000.0) -> BambooPoleGeometry:
    return BambooPoleGeometry(
        outer_diameter_mm=outer,
        wall_thickness_mm=thickness,
        length_mm=length,
        grade=BambooGrade.RAW,
    )


def test_cross_sectional_area_matches_hand_calculation():
    # D_out=100mm, t=10mm -> D_in=80mm
    # A = pi/4 * (100^2 - 80^2) = pi/4 * (10000-6400) = pi/4*3600 = 2827.433...
    geom = _geom()
    result = cross_sectional_area(geom)
    expected = math.pi / 4.0 * (100.0**2 - 80.0**2)
    assert result.value.magnitude == pytest.approx(expected, rel=1e-9)
    assert expected == pytest.approx(2827.4334, rel=1e-6)


def test_second_moment_of_area_matches_hand_calculation():
    # I = pi/64 * (100^4 - 80^4) = pi/64 * (100000000 - 40960000) = pi/64 * 59040000
    geom = _geom()
    result = second_moment_of_area(geom)
    expected = math.pi / 64.0 * (100.0**4 - 80.0**4)
    assert result.value.magnitude == pytest.approx(expected, rel=1e-9)
    assert expected == pytest.approx(2_898_119.22, rel=1e-5)


def test_section_modulus_matches_hand_calculation():
    geom = _geom()
    i_val = math.pi / 64.0 * (100.0**4 - 80.0**4)
    expected_z = i_val / (100.0 / 2.0)
    result = section_modulus(geom)
    assert result.value.magnitude == pytest.approx(expected_z, rel=1e-9)


def test_radius_of_gyration_matches_sqrt_i_over_a():
    geom = _geom()
    a = math.pi / 4.0 * (100.0**2 - 80.0**2)
    i_val = math.pi / 64.0 * (100.0**4 - 80.0**4)
    expected_r = math.sqrt(i_val / a)
    result = radius_of_gyration(geom)
    assert result.value.magnitude == pytest.approx(expected_r, rel=1e-9)


def test_slenderness_ratio_flags_high_values():
    # Long, thin pole -> high slenderness -> warning present
    geom = BambooPoleGeometry(outer_diameter_mm=40.0, wall_thickness_mm=5.0, length_mm=6000.0, grade=BambooGrade.RAW)
    result = slenderness_ratio(geom, effective_length_mm=6000.0)
    assert result.value > 100
    assert result.warnings
    assert result.review_required is True


def test_slenderness_ratio_no_warning_for_stocky_member():
    geom = BambooPoleGeometry(outer_diameter_mm=150.0, wall_thickness_mm=20.0, length_mm=500.0, grade=BambooGrade.RAW)
    result = slenderness_ratio(geom, effective_length_mm=500.0)
    assert result.value < 100
    assert result.warnings == ()


def test_approximate_mass_positive_and_scales_with_density():
    geom = _geom(length=3000.0)
    low = approximate_mass(geom, 400.0).value.magnitude
    high = approximate_mass(geom, 800.0).value.magnitude
    assert low > 0
    assert high == pytest.approx(low * 2, rel=1e-9)


def test_rejects_non_positive_diameters_and_thickness():
    with pytest.raises(GeometryError):
        BambooPoleGeometry(outer_diameter_mm=0, wall_thickness_mm=5, length_mm=1000, grade=BambooGrade.RAW)
    with pytest.raises(GeometryError):
        BambooPoleGeometry(outer_diameter_mm=100, wall_thickness_mm=0, length_mm=1000, grade=BambooGrade.RAW)


def test_rejects_wall_thickness_implying_non_positive_inner_diameter():
    with pytest.raises(GeometryError):
        # thickness so large that inner diameter <= 0
        BambooPoleGeometry(outer_diameter_mm=50.0, wall_thickness_mm=30.0, length_mm=1000, grade=BambooGrade.RAW)


def test_every_result_carries_model_version_and_provenance():
    geom = _geom()
    result = cross_sectional_area(geom)
    assert result.provenance.model_version
    assert result.provenance.review_required is False
    assert result.provenance.validation_status.value == "REQUIRES_ENGINEERING_VALIDATION"
