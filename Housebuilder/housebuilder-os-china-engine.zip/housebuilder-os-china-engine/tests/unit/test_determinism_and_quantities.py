from decimal import Decimal

import pytest

from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.architecture_engine.jiangnan_fixture import build


def test_typed_id_deterministic_for_same_seed():
    a = TypedId.new("wall", seed="abc")
    b = TypedId.new("wall", seed="abc")
    assert a == b
    assert a.value == b.value


def test_typed_id_differs_across_kinds_for_same_seed():
    a = TypedId.new("wall", seed="abc")
    b = TypedId.new("material", seed="abc")
    assert a.value != b.value


def test_typed_id_random_without_seed_is_unique():
    a = TypedId.new("wall")
    b = TypedId.new("wall")
    assert a.value != b.value


def test_jiangnan_fixture_is_reproducible():
    slice_a = build()
    slice_b = build()
    assert slice_a.project.id == slice_b.project.id
    assert slice_a.gross_footprint_m2() == pytest.approx(slice_b.gross_footprint_m2())
    assert slice_a.bill_of_quantities.total_estimate().amount == (
        slice_b.bill_of_quantities.total_estimate().amount
    )
    for wa, wb in zip(slice_a.walls, slice_b.walls):
        assert wa.id == wb.id
        assert wa.net_area_m2().magnitude == pytest.approx(wb.net_area_m2().magnitude)


def test_jiangnan_boq_total_reproducible_from_line_items():
    slice_ = build()
    boq = slice_.bill_of_quantities
    manual_direct = sum((line.line_total.amount for line in boq.lines), Decimal("0"))
    assert boq.direct_cost().amount == manual_direct
    expected_total = (manual_direct + manual_direct * Decimal(str(boq.contingency_fraction))).quantize(
        Decimal("0.01")
    )
    assert boq.total_estimate().amount == expected_total


def test_jiangnan_courtyard_within_site():
    slice_ = build()
    assert slice_.site.contains(slice_.courtyard)


def test_jiangnan_wall_openings_do_not_exceed_gross_area():
    slice_ = build()
    for wall in slice_.walls:
        assert wall.opening_area_m2().magnitude <= wall.gross_area_m2().magnitude
