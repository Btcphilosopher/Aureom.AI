import pytest

from housebuilder_engine.core.errors import GeometryError
from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.geometry_engine.primitives import (
    Opening,
    Point2D,
    Polygon2D,
    WallSegment,
)


def _square(side: float, seed: str = "sq") -> Polygon2D:
    return Polygon2D(
        id=TypedId.new("polygon", seed=seed),
        points=(
            Point2D(0, 0),
            Point2D(side, 0),
            Point2D(side, side),
            Point2D(0, side),
        ),
    )


def test_polygon_area_and_perimeter():
    sq = _square(4.0)
    assert sq.area_m2().to("m**2").magnitude == pytest.approx(16.0)
    assert sq.perimeter_m().to("m").magnitude == pytest.approx(16.0)


def test_polygon_centroid():
    sq = _square(4.0)
    c = sq.centroid()
    assert c.x == pytest.approx(2.0)
    assert c.y == pytest.approx(2.0)


def test_polygon_rejects_fewer_than_three_points():
    with pytest.raises(GeometryError):
        Polygon2D(
            id=TypedId.new("polygon", seed="degenerate"),
            points=(Point2D(0, 0), Point2D(1, 1)),
        )


def test_polygon_rejects_zero_area():
    with pytest.raises(GeometryError):
        Polygon2D(
            id=TypedId.new("polygon", seed="collinear"),
            points=(Point2D(0, 0), Point2D(1, 0), Point2D(2, 0)),
        )


def test_courtyard_contains_check():
    site = _square(10.0, seed="site")
    courtyard_inside = Polygon2D(
        id=TypedId.new("polygon", seed="courtyard_inside"),
        points=(Point2D(2, 2), Point2D(8, 2), Point2D(8, 8), Point2D(2, 8)),
    )
    courtyard_outside = Polygon2D(
        id=TypedId.new("polygon", seed="courtyard_outside"),
        points=(Point2D(9, 9), Point2D(15, 9), Point2D(15, 15), Point2D(9, 15)),
    )
    assert site.contains(courtyard_inside)
    assert not site.contains(courtyard_outside)


def test_wall_net_area_deducts_openings():
    wall = WallSegment(
        id=TypedId.new("wall", seed="w1"),
        length_m=10.0,
        height_m=3.0,
        thickness_m=0.2,
        openings=(
            Opening(id=TypedId.new("opening", seed="o1"), kind="window", width_m=1.2, height_m=1.5),
            Opening(id=TypedId.new("opening", seed="o2"), kind="door", width_m=1.0, height_m=2.1),
        ),
    )
    gross = wall.gross_area_m2().magnitude
    net = wall.net_area_m2().magnitude
    assert gross == pytest.approx(30.0)
    assert net == pytest.approx(30.0 - (1.2 * 1.5) - (1.0 * 2.1))


def test_wall_rejects_openings_exceeding_gross_area():
    with pytest.raises(GeometryError):
        WallSegment(
            id=TypedId.new("wall", seed="w_bad"),
            length_m=2.0,
            height_m=2.0,
            thickness_m=0.2,
            openings=(
                Opening(id=TypedId.new("opening", seed="o_big"), kind="door", width_m=3.0, height_m=3.0),
            ),
        )


def test_wall_rejects_negative_dimensions():
    with pytest.raises(GeometryError):
        WallSegment(id=TypedId.new("wall", seed="w_neg"), length_m=-1.0, height_m=3.0, thickness_m=0.2)


def test_wall_material_volume():
    wall = WallSegment(id=TypedId.new("wall", seed="w2"), length_m=5.0, height_m=3.0, thickness_m=0.25)
    volume = wall.material_volume_m3().magnitude
    assert volume == pytest.approx(5.0 * 3.0 * 0.25)
