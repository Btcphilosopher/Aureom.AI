from datetime import date
from decimal import Decimal

import pytest

from housebuilder_engine.core.money import CurrencyError, Money, PriceStatus, sum_money


def _m(amount: str, currency: str = "CNY", status=PriceStatus.SYNTHETIC) -> Money:
    return Money.of(
        Decimal(amount),
        currency,
        price_date=date(2026, 1, 1),
        market="test_market",
        status=status,
    )


def test_rejects_unsupported_currency():
    with pytest.raises(CurrencyError):
        _m("10.00", currency="XYZ")


def test_rejects_float_construction():
    with pytest.raises(CurrencyError):
        Money.of(10.5, "CNY", price_date=date(2026, 1, 1), market="test_market")  # type: ignore[arg-type]


def test_addition_is_exact_decimal():
    a = _m("10.10")
    b = _m("0.20")
    total = a + b
    assert total.amount == Decimal("10.30")


def test_cannot_add_different_currencies():
    a = _m("10.00", currency="CNY")
    b = _m("10.00", currency="USD")
    with pytest.raises(CurrencyError):
        _ = a + b


def test_multiplication_rounds_half_up_to_cents():
    a = _m("10.005")
    result = a * Decimal("1")
    assert result.amount == Decimal("10.01") or result.amount == Decimal("10.00")
    # exact rounding behaviour: 10.005 rounds half-up to 10.01
    assert (a * Decimal("1")).amount == Decimal("10.01")


def test_mixing_synthetic_and_verified_degrades_status():
    synthetic = _m("5.00", status=PriceStatus.SYNTHETIC)
    verified = _m("5.00", status=PriceStatus.VERIFIED)
    total = synthetic + verified
    assert total.status == PriceStatus.SYNTHETIC


def test_sum_money_requires_nonempty_list():
    with pytest.raises(CurrencyError):
        sum_money([])


def test_sum_money_totals_correctly():
    items = [_m("1.11"), _m("2.22"), _m("3.33")]
    total = sum_money(items)
    assert total.amount == Decimal("6.66")
