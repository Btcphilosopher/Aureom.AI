# HOUSEBUILDER.OS CHINA ENGINE

Computational core for Chinese residential architecture, materials,
construction and digital-twin simulation. This is **not** a certified
structural, code-compliance, or permitting tool — see `NOT_FOR_CONSTRUCTION`
notes throughout.

## What's in this delivery

This is the **first vertical slice** of a much larger specified system
(25 planned subsystems — geometry, materials, structure, building physics,
water, construction simulation, cost, carbon, maintenance, digital twin,
Monte Carlo, optimisation, API, CLI). This delivery implements, for real,
with passing tests and no stubs:

| Area | Module(s) | Status |
|---|---|---|
| Typed IDs (deterministic UUID5) | `core/ids.py` | IMPLEMENTED |
| Units (pint-backed, dimensional validation) | `core/units.py` | IMPLEMENTED |
| Money (Decimal, provenance, no floats) | `core/money.py` | IMPLEMENTED |
| Provenance / model versioning | `core/provenance.py`, `core/versioning.py` | IMPLEMENTED |
| CalculationResult framework | `core/result.py`, `core/uncertainty.py` | IMPLEMENTED |
| Error hierarchy | `core/errors.py` | IMPLEMENTED |
| Geometry primitives (polygons, walls, openings) | `geometry_engine/primitives.py` | IMPLEMENTED |
| Bamboo hollow-section calculations | `geometry_engine/bamboo_geometry.py` | IMPLEMENTED (geometry) / REQUIRES_ENGINEERING_VALIDATION (structural use) |
| Material model + synthetic catalogue | `materials_engine/material_properties.py`, `catalogue.py` | IMPLEMENTED (model) / SYNTHETIC_MODEL (values) |
| Quantity takeoff | `materials_engine/material_quantities.py` | IMPLEMENTED |
| Bill of quantities / cost estimate | `cost_engine/estimates.py` | IMPLEMENTED (assembly) / SYNTHETIC_MODEL (rates) |
| Project domain model | `domain/project.py` | PARTIALLY_IMPLEMENTED |
| Jiangnan Bamboo House 001 vertical slice | `architecture_engine/jiangnan_fixture.py` | PARTIALLY_IMPLEMENTED |
| CLI (`housebuilder demo`, `python -m housebuilder_engine demo`) | `cli/main.py` | PARTIALLY_IMPLEMENTED |

**Not yet implemented** (present in the target architecture but out of
scope for this delivery): full architecture_engine typologies beyond the
one fixture, structural_engine load-case/beam models, building_physics
(thermal/solar/moisture), water_engine, construction_engine (SimPy
scheduling), carbon_engine, maintenance_engine, digital_twin event
sourcing, simulation_engine Monte Carlo, optimisation_engine, persistence
layer, FastAPI routes, and most CLI subcommands (`init`, `validate`,
`calculate`, `simulate`, `optimise`, `twin`, `report`).

## Running it

```bash
pip install -e ".[dev]"
python -m pytest tests/ -v          # 34 tests, all passing
python -m housebuilder_engine demo  # runs Jiangnan Bamboo House 001 end-to-end
```

`demo` prints computed geometry, bamboo section properties, a roof tile
quantity, and a full bill of quantities with a CNY total — all derived
from the actual input dimensions, not hard-coded — and writes the same
data as JSON to `output/jiangnan_bamboo_house_001_demo.json`.

## Engineering boundaries

This engine performs **simplified, transparent calculations** with
explicit assumptions and provenance on every result. It does not invent
Chinese regulatory standards, does not perform certified structural
design, and labels all currently-bundled material/cost data as
`SYNTHETIC_MODEL` — general literature ranges, not verified regional or
market data. Every `CalculationResult` carries `assumptions`,
`warnings`, and a `Provenance` block with `validation_status` and
`review_required`, so downstream consumers (Kotlin/web/desktop clients)
can render the right caveats rather than presenting a number as ground
truth.

## Continuing the build

The remaining ~20 subsystems follow the same pattern established here:
Pydantic/dataclass domain models → pure calculation functions returning
`CalculationResult` → tests checked against hand calculations → CLI/API
wiring. The project tree for the full system is documented in the
original engineering spec; this delivery deliberately did not create
empty placeholder files for unimplemented subsystems, per that spec's
own instruction not to fake completeness.
