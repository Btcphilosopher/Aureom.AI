"""
Assembles a bill-of-quantities cost estimate from QuantityLine records and
per-unit rates. Every total is reproducible from its stored line items
(see BillOfQuantities.recompute_total).

Status: IMPLEMENTED (assembly logic) / SYNTHETIC_MODEL (unit rates used
in the demo — see cli demo command)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from housebuilder_engine.core.errors import CalculationError
from housebuilder_engine.core.money import Money, PriceStatus, sum_money
from housebuilder_engine.materials_engine.material_quantities import QuantityLine


@dataclass(frozen=True, slots=True)
class RatedLine:
    """A QuantityLine priced at a per-kg or per-unit rate."""

    quantity: QuantityLine
    unit_rate: Money  # rate per kg
    line_total: Money

    @classmethod
    def from_quantity(cls, quantity: QuantityLine, unit_rate: Money) -> "RatedLine":
        line_total = unit_rate * Decimal(str(quantity.mass_kg))
        return cls(quantity=quantity, unit_rate=unit_rate, line_total=line_total)


@dataclass(frozen=True, slots=True)
class BillOfQuantities:
    project_ref: str
    lines: tuple[RatedLine, ...]
    contingency_fraction: float

    def __post_init__(self) -> None:
        if not self.lines:
            raise CalculationError("BillOfQuantities requires at least one line")
        if self.contingency_fraction < 0:
            raise CalculationError("contingency_fraction must be >= 0")

    def direct_cost(self) -> Money:
        return sum_money([line.line_total for line in self.lines])

    def contingency(self) -> Money:
        return self.direct_cost() * Decimal(str(self.contingency_fraction))

    def total_estimate(self) -> Money:
        """Reproducible total: sum of line items + contingency, nothing else."""
        return self.direct_cost() + self.contingency()

    def as_report(self) -> dict:
        return {
            "project_ref": self.project_ref,
            "lines": [
                {
                    "material": line.quantity.material.name_en,
                    "material_zh": line.quantity.material.name_zh,
                    "mass_kg": round(line.quantity.mass_kg, 2),
                    "unit_rate": str(line.unit_rate),
                    "line_total": str(line.line_total),
                }
                for line in self.lines
            ],
            "direct_cost": str(self.direct_cost()),
            "contingency_fraction": self.contingency_fraction,
            "contingency": str(self.contingency()),
            "total_estimate": str(self.total_estimate()),
        }
