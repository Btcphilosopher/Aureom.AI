"""
Geometry primitives used across the platform: 2D polygons via shapely,
area/perimeter/centroid calculations, and simple wall-opening deductions.

All areas are returned as pint Quantities in square metres unless
otherwise noted; callers needing a CalculationResult wrapper should use
geometry_engine.quantity_geometry.

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass, field

from shapely.geometry import Polygon
from shapely.validation import explain_validity

from housebuilder_engine.core.errors import GeometryError
from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.core.units import Q, ureg


@dataclass(frozen=True, slots=True)
class Point2D:
    x: float
    y: float


@dataclass(slots=True)
class Polygon2D:
    """A simple, validated 2D polygon footprint (metres, local coordinates).

    Wraps shapely.Polygon but enforces the engine's own validation rules
    (non-degenerate, non-self-intersecting) at construction time so that
    every Polygon2D in the system is guaranteed usable.
    """

    id: TypedId
    points: tuple[Point2D, ...]
    level: str = "ground"

    def __post_init__(self) -> None:
        if len(self.points) < 3:
            raise GeometryError(
                f"Polygon2D {self.id} needs at least 3 points, got {len(self.points)}"
            )
        poly = self._shapely()
        if not poly.is_valid:
            raise GeometryError(
                f"Polygon2D {self.id} is invalid: {explain_validity(poly)}"
            )
        if poly.area <= 0:
            raise GeometryError(f"Polygon2D {self.id} has zero or negative area")

    def _shapely(self) -> Polygon:
        return Polygon([(p.x, p.y) for p in self.points])

    def area_m2(self) -> "ureg.Quantity":
        return Q(self._shapely().area, "m**2")

    def perimeter_m(self) -> "ureg.Quantity":
        return Q(self._shapely().length, "m")

    def centroid(self) -> Point2D:
        c = self._shapely().centroid
        return Point2D(x=c.x, y=c.y)

    def bounding_box(self) -> tuple[Point2D, Point2D]:
        minx, miny, maxx, maxy = self._shapely().bounds
        return Point2D(minx, miny), Point2D(maxx, maxy)

    def contains(self, other: "Polygon2D") -> bool:
        return self._shapely().contains(other._shapely())

    def intersection_area_m2(self, other: "Polygon2D") -> "ureg.Quantity":
        inter = self._shapely().intersection(other._shapely())
        return Q(inter.area, "m**2")

    def union_area_m2(self, other: "Polygon2D") -> "ureg.Quantity":
        union = self._shapely().union(other._shapely())
        return Q(union.area, "m**2")


@dataclass(slots=True)
class Opening:
    """A door or window opening cut into a wall, for net-area deduction."""

    id: TypedId
    kind: str  # "door" | "window"
    width_m: float
    height_m: float

    def __post_init__(self) -> None:
        if self.width_m <= 0 or self.height_m <= 0:
            raise GeometryError(
                f"Opening {self.id} ({self.kind}) must have positive width and height, "
                f"got {self.width_m} x {self.height_m}"
            )

    def area_m2(self) -> "ureg.Quantity":
        return Q(self.width_m * self.height_m, "m**2")


@dataclass(slots=True)
class WallSegment:
    """A straight wall segment defined by length, height and thickness."""

    id: TypedId
    length_m: float
    height_m: float
    thickness_m: float
    material_id: TypedId | None = None
    openings: tuple[Opening, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if self.length_m <= 0:
            raise GeometryError(f"WallSegment {self.id} length_m must be > 0, got {self.length_m}")
        if self.height_m <= 0:
            raise GeometryError(f"WallSegment {self.id} height_m must be > 0, got {self.height_m}")
        if self.thickness_m <= 0:
            raise GeometryError(
                f"WallSegment {self.id} thickness_m must be > 0, got {self.thickness_m}"
            )
        gross = self.length_m * self.height_m
        opening_total = sum(o.width_m * o.height_m for o in self.openings)
        if opening_total > gross:
            raise GeometryError(
                f"WallSegment {self.id} openings ({opening_total:.2f} m2) exceed "
                f"gross wall area ({gross:.2f} m2)"
            )

    def gross_area_m2(self) -> "ureg.Quantity":
        return Q(self.length_m * self.height_m, "m**2")

    def opening_area_m2(self) -> "ureg.Quantity":
        total = sum(o.width_m * o.height_m for o in self.openings)
        return Q(total, "m**2")

    def net_area_m2(self) -> "ureg.Quantity":
        return self.gross_area_m2() - self.opening_area_m2()

    def material_volume_m3(self) -> "ureg.Quantity":
        """net wall area * thickness = wall material volume."""
        net_area = self.net_area_m2()
        return Q(net_area.magnitude * self.thickness_m, "m**3")
