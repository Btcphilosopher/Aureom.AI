"""
Bamboo pole geometry and simplified section-property calculations.

Bamboo culms are modelled as hollow circular sections. This module
computes purely geometric section properties (area, second moment of
area, section modulus, mass) plus a few simplified structural
*indicators* (slenderness ratio). It explicitly does NOT perform code
-compliant structural design — see structural_engine for load-case
combination, and note the ENGINEERING_REVIEW_REQUIRED status on every
result here.

Formulas (thin/thick hollow circular section, D_outer > D_inner > 0):
    A = pi/4 * (D_outer^2 - D_inner^2)
    I = pi/64 * (D_outer^4 - D_inner^4)
    Z = I / (D_outer / 2)                      (elastic section modulus)
    slenderness = effective_length / radius_of_gyration
    radius_of_gyration r = sqrt(I / A)

Status: IMPLEMENTED (geometry) / REQUIRES_ENGINEERING_VALIDATION (any
structural interpretation of the outputs)
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum

from housebuilder_engine.core.errors import GeometryError
from housebuilder_engine.core.provenance import (
    ConfidenceLevel,
    Provenance,
    ValidationStatus,
)
from housebuilder_engine.core.result import CalculationResult
from housebuilder_engine.core.uncertainty import Uncertainty
from housebuilder_engine.core.units import Q, ureg
from housebuilder_engine.core.versioning import version_for


class BambooGrade(str, Enum):
    """Distinguishes processing grade — raw bamboo and engineered/laminated
    bamboo have materially different, non-interchangeable properties."""

    RAW = "raw"
    TREATED = "treated"
    LAMINATED = "laminated"
    ENGINEERED = "engineered"
    DECORATIVE = "decorative"


@dataclass(frozen=True, slots=True)
class BambooPoleGeometry:
    """A single bamboo culm/pole segment, treated as a uniform hollow
    circular section (a simplification — real culms taper along their
    length; see `warnings` on derived results)."""

    outer_diameter_mm: float
    wall_thickness_mm: float
    length_mm: float
    grade: BambooGrade
    defect_factor: float = 1.0
    """Multiplier in (0, 1] applied downstream to strength assumptions to
    account for natural defects/grading; 1.0 = no reduction. This module
    only carries the factor through — it does not itself assume a strength
    value."""

    def __post_init__(self) -> None:
        if self.outer_diameter_mm <= 0:
            raise GeometryError("outer_diameter_mm must be > 0")
        if self.wall_thickness_mm <= 0:
            raise GeometryError("wall_thickness_mm must be > 0")
        if self.length_mm <= 0:
            raise GeometryError("length_mm must be > 0")
        inner = self.inner_diameter_mm
        if inner <= 0:
            raise GeometryError(
                f"wall_thickness_mm ({self.wall_thickness_mm}) implies a "
                f"non-positive inner diameter for outer_diameter_mm "
                f"({self.outer_diameter_mm}); wall_thickness must be < D_outer/2"
            )
        if not (0 < self.defect_factor <= 1.0):
            raise GeometryError("defect_factor must be in (0, 1]")

    @property
    def inner_diameter_mm(self) -> float:
        return self.outer_diameter_mm - 2 * self.wall_thickness_mm


def _prov(model_name: str, *, review: bool, confidence: ConfidenceLevel) -> Provenance:
    return Provenance(
        model_name=model_name,
        model_version=version_for("bamboo.hollow_section"),
        data_sources=("closed_form_geometry",),
        confidence=confidence,
        validation_status=ValidationStatus.REQUIRES_ENGINEERING_VALIDATION,
        review_required=review,
    )


def cross_sectional_area(geom: BambooPoleGeometry) -> CalculationResult:
    """A = pi/4 * (D_outer^2 - D_inner^2), returned in mm^2."""
    d_out = geom.outer_diameter_mm
    d_in = geom.inner_diameter_mm
    area_mm2 = math.pi / 4.0 * (d_out**2 - d_in**2)
    return CalculationResult(
        value=Q(area_mm2, "mm**2"),
        unit="mm**2",
        method="hollow_circular_section.cross_sectional_area",
        provenance=_prov(
            "bamboo.hollow_section.area", review=False, confidence=ConfidenceLevel.HIGH
        ),
        assumptions=(
            "Uniform hollow circular cross-section (no taper along length)",
            "Wall thickness assumed constant around circumference",
        ),
        input_references=(f"outer_diameter_mm={d_out}", f"wall_thickness_mm={geom.wall_thickness_mm}"),
    )


def second_moment_of_area(geom: BambooPoleGeometry) -> CalculationResult:
    """I = pi/64 * (D_outer^4 - D_inner^4), returned in mm^4."""
    d_out = geom.outer_diameter_mm
    d_in = geom.inner_diameter_mm
    i_mm4 = math.pi / 64.0 * (d_out**4 - d_in**4)
    return CalculationResult(
        value=Q(i_mm4, "mm**4"),
        unit="mm**4",
        method="hollow_circular_section.second_moment_of_area",
        provenance=_prov(
            "bamboo.hollow_section.inertia", review=False, confidence=ConfidenceLevel.HIGH
        ),
        assumptions=("Uniform hollow circular cross-section (no taper along length)",),
    )


def section_modulus(geom: BambooPoleGeometry) -> CalculationResult:
    """Z = I / (D_outer / 2), elastic section modulus, returned in mm^3."""
    i_result = second_moment_of_area(geom)
    i_mm4 = i_result.value.magnitude
    z_mm3 = i_mm4 / (geom.outer_diameter_mm / 2.0)
    return CalculationResult(
        value=Q(z_mm3, "mm**3"),
        unit="mm**3",
        method="hollow_circular_section.section_modulus",
        provenance=_prov(
            "bamboo.hollow_section.section_modulus",
            review=False,
            confidence=ConfidenceLevel.HIGH,
        ),
        assumptions=("Elastic section modulus about a diametral axis (extreme fibre at D_outer/2)",),
    )


def radius_of_gyration(geom: BambooPoleGeometry) -> CalculationResult:
    """r = sqrt(I / A), returned in mm."""
    i_mm4 = second_moment_of_area(geom).value.magnitude
    a_mm2 = cross_sectional_area(geom).value.magnitude
    r_mm = math.sqrt(i_mm4 / a_mm2)
    return CalculationResult(
        value=Q(r_mm, "mm"),
        unit="mm",
        method="hollow_circular_section.radius_of_gyration",
        provenance=_prov(
            "bamboo.hollow_section.radius_of_gyration",
            review=False,
            confidence=ConfidenceLevel.HIGH,
        ),
    )


def slenderness_ratio(geom: BambooPoleGeometry, effective_length_mm: float) -> CalculationResult:
    """slenderness = effective_length / radius_of_gyration (dimensionless).

    This is a preliminary buckling *indicator* only — a high slenderness
    ratio flags a member for closer engineering review, it is not itself
    a buckling capacity check.
    """
    if effective_length_mm <= 0:
        raise GeometryError("effective_length_mm must be > 0")
    r_mm = radius_of_gyration(geom).value.magnitude
    ratio = effective_length_mm / r_mm
    warnings = []
    if ratio > 100:
        warnings.append(
            "Slenderness ratio exceeds 100 — this member is a strong candidate "
            "for buckling governance and MUST receive engineering review before "
            "any load is assigned."
        )
    return CalculationResult(
        value=ratio,
        unit=None,
        method="hollow_circular_section.slenderness_ratio",
        provenance=_prov(
            "bamboo.hollow_section.slenderness",
            review=True,
            confidence=ConfidenceLevel.MEDIUM,
        ),
        assumptions=(
            "Effective length supplied by caller (accounts for end-fixity, not "
            "computed here)",
            "PRELIMINARY_ESTIMATE — not a substitute for a licensed structural "
            "engineer's buckling check",
        ),
        warnings=tuple(warnings),
    )


def approximate_mass(geom: BambooPoleGeometry, density_kg_per_m3: float) -> CalculationResult:
    """mass = cross-sectional area * length * density.

    `density_kg_per_m3` must be supplied by the caller from a Material
    record (see materials_engine.bamboo) — this module carries no
    hard-coded bamboo density, since raw/treated/laminated/engineered
    bamboo densities differ materially.
    """
    if density_kg_per_m3 <= 0:
        raise GeometryError("density_kg_per_m3 must be > 0")
    area_m2 = cross_sectional_area(geom).value.to("m**2").magnitude
    length_m = geom.length_mm / 1000.0
    volume_m3 = area_m2 * length_m
    mass_kg = volume_m3 * density_kg_per_m3
    return CalculationResult(
        value=Q(mass_kg, "kg"),
        unit="kg",
        method="hollow_circular_section.approximate_mass",
        provenance=_prov(
            "bamboo.hollow_section.mass",
            review=False,
            confidence=ConfidenceLevel.MEDIUM,
        ),
        assumptions=(
            f"Uniform density {density_kg_per_m3} kg/m^3 applied along full length "
            "(ignores node thickening and natural taper)",
        ),
        uncertainty=Uncertainty.relative(
            mass_kg, 0.10, "±10% for natural bamboo density variation by culm/node"
        ),
    )
