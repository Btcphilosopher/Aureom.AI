"""
Synthetic reference project: "Jiangnan Bamboo House 001".

This is the first end-to-end vertical slice described in the engineering
spec (section 21): a single, fully computed project exercising geometry,
bamboo section properties, material quantity takeoff, and a cost
estimate, all wired through CalculationResult/provenance rather than
returning bare numbers.

Location, floor area, storeys and material choices are as specified:
    Location: Synthetic humid eastern-China climate zone
    Floor area: 180 m^2 (target; actual computed footprint may differ
                slightly, and the two are reported separately rather than
                silently reconciled)
    Storeys: 2
    Structural concept: Bamboo-timber hybrid
    Roof: Grey tiled pitched roof
    Walls: Bamboo-timber composite walls
    Courtyard: Central courtyard

Status: PARTIALLY_IMPLEMENTED — covers geometry -> quantities -> bamboo
section properties -> cost estimate. Structural, thermal, water,
construction-schedule, carbon, maintenance and digital-twin stages
described in the spec are NOT yet wired into this fixture (see the
engine's remaining module list).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.core.money import Money, PriceStatus
from housebuilder_engine.core.result import CalculationResult
from housebuilder_engine.cost_engine.estimates import BillOfQuantities, RatedLine
from housebuilder_engine.domain.project import Project
from housebuilder_engine.geometry_engine.bamboo_geometry import (
    BambooGrade,
    BambooPoleGeometry,
    approximate_mass,
    cross_sectional_area,
    second_moment_of_area,
    slenderness_ratio,
)
from housebuilder_engine.geometry_engine.primitives import (
    Opening,
    Point2D,
    Polygon2D,
    WallSegment,
)
from housebuilder_engine.materials_engine.catalogue import (
    GREY_ROOF_TILE,
    LAMINATED_BAMBOO,
    LOCAL_STONE,
    MOSO_BAMBOO_RAW,
    SHAN_MU_TIMBER,
)
from housebuilder_engine.materials_engine.material_quantities import (
    QuantityLine,
    roof_tile_quantity,
    wall_material_quantity,
)

PROJECT_SEED = "jiangnan_bamboo_house_001"


@dataclass(frozen=True, slots=True)
class JiangnanVerticalSlice:
    """Bundles every computed artefact produced by build()."""

    project: Project
    site: Polygon2D
    courtyard: Polygon2D
    walls: tuple[WallSegment, ...]
    roof_area_m2: float
    wall_quantity_results: tuple[CalculationResult, ...]
    roof_tile_result: CalculationResult
    bamboo_geometry: BambooPoleGeometry
    bamboo_area_result: CalculationResult
    bamboo_inertia_result: CalculationResult
    bamboo_mass_result: CalculationResult
    bamboo_slenderness_result: CalculationResult
    bill_of_quantities: BillOfQuantities

    def gross_footprint_m2(self) -> float:
        return self.site.area_m2().magnitude

    def net_courtyard_m2(self) -> float:
        return self.courtyard.area_m2().magnitude


def _synthetic_rate(amount: str, market: str = "eastern_china_synthetic_zone") -> Money:
    return Money.of(
        Decimal(amount),
        "CNY",
        price_date=date(2026, 1, 1),
        market=market,
        status=PriceStatus.SYNTHETIC,
        source="synthetic_placeholder:not_a_real_market_quote",
    )


def build() -> JiangnanVerticalSlice:
    project = Project(
        id=TypedId.new("project", seed=PROJECT_SEED),
        name="Jiangnan Bamboo House 001",
        location="Synthetic humid eastern-China climate zone",
        building_type="Modern Jiangnan courtyard residence",
        floor_area_target_m2=180.0,
        storeys=2,
    )

    # --- Site & courtyard polygons (rectangular footprint, 12m x 16.5m ~= 198 m^2 gross,
    # with a 6m x 5m central courtyard subtracted conceptually — courtyard sits
    # fully inside the site, validated via Polygon2D.contains). ---
    site = Polygon2D(
        id=TypedId.new("polygon.site", seed=PROJECT_SEED + ":site"),
        points=(
            Point2D(0.0, 0.0),
            Point2D(12.0, 0.0),
            Point2D(12.0, 16.5),
            Point2D(0.0, 16.5),
        ),
    )
    courtyard = Polygon2D(
        id=TypedId.new("polygon.courtyard", seed=PROJECT_SEED + ":courtyard"),
        points=(
            Point2D(3.0, 6.0),
            Point2D(9.0, 6.0),
            Point2D(9.0, 11.0),
            Point2D(3.0, 11.0),
        ),
    )
    assert site.contains(courtyard), "courtyard must sit within the site boundary"

    # --- Perimeter walls: bamboo-timber composite, two storeys @ 3.0 m each. ---
    storey_height_m = 3.0
    wall_height_m = storey_height_m * project.storeys
    wall_thickness_m = 0.24  # bamboo-timber composite panel thickness, synthetic

    def make_wall(seed_suffix: str, length_m: float, n_windows: int, n_doors: int) -> WallSegment:
        openings: list[Opening] = []
        for i in range(n_windows):
            openings.append(
                Opening(
                    id=TypedId.new("opening.window", seed=f"{PROJECT_SEED}:{seed_suffix}:win:{i}"),
                    kind="window",
                    width_m=1.2,
                    height_m=1.5,
                )
            )
        for i in range(n_doors):
            openings.append(
                Opening(
                    id=TypedId.new("opening.door", seed=f"{PROJECT_SEED}:{seed_suffix}:door:{i}"),
                    kind="door",
                    width_m=1.0,
                    height_m=2.1,
                )
            )
        return WallSegment(
            id=TypedId.new("wall", seed=f"{PROJECT_SEED}:{seed_suffix}"),
            length_m=length_m,
            height_m=wall_height_m,
            thickness_m=wall_thickness_m,
            openings=tuple(openings),
        )

    walls = (
        make_wall("wall_north", 12.0, n_windows=3, n_doors=1),
        make_wall("wall_south", 12.0, n_windows=3, n_doors=0),
        make_wall("wall_east", 16.5, n_windows=4, n_doors=0),
        make_wall("wall_west", 16.5, n_windows=4, n_doors=1),
    )

    # --- Roof: pitched, grey tile, projected area * pitch factor for 28 degrees. ---
    import math

    roof_pitch_degrees = 28.0
    projected_roof_area_m2 = site.area_m2().magnitude  # footprint projection
    pitch_factor = 1.0 / math.cos(math.radians(roof_pitch_degrees))
    roof_area_m2 = projected_roof_area_m2 * pitch_factor

    # --- Material quantity takeoff, wall by wall ---
    wall_quantity_results = tuple(
        wall_material_quantity(wall, LAMINATED_BAMBOO, waste_fraction=0.06) for wall in walls
    )

    roof_tile_result = roof_tile_quantity(
        roof_area_m2, GREY_ROOF_TILE, coverage_factor_tiles_per_m2=55.0, waste_fraction=0.08
    )

    # --- A representative primary bamboo column member ---
    bamboo_geom = BambooPoleGeometry(
        outer_diameter_mm=120.0,
        wall_thickness_mm=12.0,
        length_mm=wall_height_m * 1000.0,
        grade=BambooGrade.TREATED,
        defect_factor=0.9,
    )
    bamboo_area_result = cross_sectional_area(bamboo_geom)
    bamboo_inertia_result = second_moment_of_area(bamboo_geom)
    bamboo_mass_result = approximate_mass(bamboo_geom, MOSO_BAMBOO_RAW.density_kg_per_m3)
    bamboo_slenderness_result = slenderness_ratio(bamboo_geom, effective_length_mm=bamboo_geom.length_mm)

    # --- Cost estimate: rate each wall's bamboo mass and the timber frame allowance ---
    bamboo_rate = _synthetic_rate("18.50")  # CNY per kg, synthetic
    rated_lines = [
        RatedLine.from_quantity(result.value, bamboo_rate) for result in wall_quantity_results
    ]
    # Add a synthetic timber-frame allowance line, using the roof area as a proxy
    # for frame extent (a real build would take this off a generated timber
    # frame geometry model, not yet implemented).
    timber_frame_line = QuantityLine(
        material=SHAN_MU_TIMBER,
        source_id=TypedId.new("frame_allowance", seed=PROJECT_SEED),
        net_volume_m3=roof_area_m2 * 0.015,
        waste_fraction=0.10,
        gross_volume_m3=roof_area_m2 * 0.015 * 1.10,
        mass_kg=roof_area_m2 * 0.015 * 1.10 * SHAN_MU_TIMBER.density_kg_per_m3,
    )
    timber_rate = _synthetic_rate("6.80")
    rated_lines.append(RatedLine.from_quantity(timber_frame_line, timber_rate))

    stone_paving_line = QuantityLine(
        material=LOCAL_STONE,
        source_id=courtyard.id,
        net_volume_m3=courtyard.area_m2().magnitude * 0.05,
        waste_fraction=0.05,
        gross_volume_m3=courtyard.area_m2().magnitude * 0.05 * 1.05,
        mass_kg=courtyard.area_m2().magnitude * 0.05 * 1.05 * LOCAL_STONE.density_kg_per_m3,
    )
    stone_rate = _synthetic_rate("1.20")
    rated_lines.append(RatedLine.from_quantity(stone_paving_line, stone_rate))

    boq = BillOfQuantities(
        project_ref=project.name,
        lines=tuple(rated_lines),
        contingency_fraction=0.10,
    )

    return JiangnanVerticalSlice(
        project=project,
        site=site,
        courtyard=courtyard,
        walls=walls,
        roof_area_m2=roof_area_m2,
        wall_quantity_results=wall_quantity_results,
        roof_tile_result=roof_tile_result,
        bamboo_geometry=bamboo_geom,
        bamboo_area_result=bamboo_area_result,
        bamboo_inertia_result=bamboo_inertia_result,
        bamboo_mass_result=bamboo_mass_result,
        bamboo_slenderness_result=bamboo_slenderness_result,
        bill_of_quantities=boq,
    )
