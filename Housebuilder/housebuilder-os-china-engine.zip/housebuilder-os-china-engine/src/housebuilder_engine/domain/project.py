"""
Minimal Project domain model: enough to validate and identify a project
for the vertical slice. Expand with site/building sub-models as later
modules are implemented.

Status: PARTIALLY_IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass

from housebuilder_engine.core.errors import DomainValidationError
from housebuilder_engine.core.ids import TypedId


@dataclass(frozen=True, slots=True)
class Project:
    id: TypedId
    name: str
    location: str
    building_type: str
    floor_area_target_m2: float
    storeys: int

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise DomainValidationError("Project.name must be non-empty")
        if self.floor_area_target_m2 <= 0:
            raise DomainValidationError("floor_area_target_m2 must be > 0")
        if self.storeys < 1:
            raise DomainValidationError("storeys must be >= 1")
