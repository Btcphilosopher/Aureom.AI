"""
A minimal, explicitly SYNTHETIC material catalogue covering the materials
needed by the Jiangnan Bamboo House 001 vertical slice: bamboo, timber,
grey roof tile, local stone, and a lime-based finish.

All property values here are placeholders drawn from general published
ranges, NOT verified Chinese regional test data, and every Material's
`confidence` is set accordingly. Replace with sourced data before any
value from this catalogue is used for real design decisions.

Status: SYNTHETIC_MODEL — REQUIRES_ENGINEERING_VALIDATION before use
beyond demonstration purposes.
"""
from __future__ import annotations

from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.core.provenance import ConfidenceLevel
from housebuilder_engine.materials_engine.material_properties import (
    DurabilityProperties,
    Material,
    MaterialCategory,
    ThermalProperties,
)

_SOURCE = "synthetic_placeholder:general_literature_range_not_regionally_verified"


def _material(
    seed: str,
    name_en: str,
    name_zh: str,
    category: MaterialCategory,
    region: str,
    density: float,
    conductivity: float,
    service_life_years: float,
    moisture_sensitive: bool,
) -> Material:
    return Material(
        id=TypedId.new("material", seed=seed),
        name_en=name_en,
        name_zh=name_zh,
        category=category,
        region=region,
        density_kg_per_m3=density,
        thermal=ThermalProperties(thermal_conductivity_w_per_mk=conductivity),
        durability=DurabilityProperties(
            service_life_years=service_life_years,
            moisture_sensitive=moisture_sensitive,
        ),
        confidence=ConfidenceLevel.LOW,
        source=_SOURCE,
    )


MOSO_BAMBOO_RAW = _material(
    "material.moso_bamboo_raw",
    "Moso bamboo (raw culm)",
    "毛竹",
    MaterialCategory.BAMBOO,
    region="eastern_china_synthetic_zone",
    density=650.0,
    conductivity=0.13,
    service_life_years=15.0,
    moisture_sensitive=True,
)

LAMINATED_BAMBOO = _material(
    "material.laminated_bamboo",
    "Laminated bamboo",
    "重组竹",
    MaterialCategory.BAMBOO,
    region="eastern_china_synthetic_zone",
    density=800.0,
    conductivity=0.17,
    service_life_years=35.0,
    moisture_sensitive=True,
)

SHAN_MU_TIMBER = _material(
    "material.shan_mu_timber",
    "China fir timber",
    "杉木",
    MaterialCategory.TIMBER,
    region="eastern_china_synthetic_zone",
    density=420.0,
    conductivity=0.12,
    service_life_years=40.0,
    moisture_sensitive=True,
)

GREY_ROOF_TILE = _material(
    "material.grey_roof_tile",
    "Grey clay roof tile",
    "小青瓦",
    MaterialCategory.ROOF_TILE,
    region="eastern_china_synthetic_zone",
    density=1800.0,
    conductivity=0.84,
    service_life_years=50.0,
    moisture_sensitive=False,
)

LOCAL_STONE = _material(
    "material.local_stone",
    "Local paving stone",
    "青石",
    MaterialCategory.STONE,
    region="eastern_china_synthetic_zone",
    density=2600.0,
    conductivity=2.20,
    service_life_years=100.0,
    moisture_sensitive=False,
)

LIME_FINISH = _material(
    "material.lime_finish",
    "Lime-based render",
    "石灰抹面",
    MaterialCategory.BINDER,
    region="eastern_china_synthetic_zone",
    density=1600.0,
    conductivity=0.70,
    service_life_years=20.0,
    moisture_sensitive=True,
)

CATALOGUE: dict[str, Material] = {
    m.name_en: m
    for m in (
        MOSO_BAMBOO_RAW,
        LAMINATED_BAMBOO,
        SHAN_MU_TIMBER,
        GREY_ROOF_TILE,
        LOCAL_STONE,
        LIME_FINISH,
    )
}


def get_material(name_en: str) -> Material:
    try:
        return CATALOGUE[name_en]
    except KeyError as exc:
        raise KeyError(
            f"No material named {name_en!r} in catalogue; available: {sorted(CATALOGUE)}"
        ) from exc
