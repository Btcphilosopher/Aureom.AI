"""
Core Material record used across the engine. Every material must carry
provenance for its properties — density, thermal behaviour, cost and
carbon figures are frequently synthetic placeholders in this early build
and must be labelled as such rather than presented as verified data.

Status: IMPLEMENTED (model) / SYNTHETIC_MODEL (bundled property values —
see materials_engine.catalogue)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from housebuilder_engine.core.errors import MaterialError
from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.core.provenance import ConfidenceLevel


class MaterialCategory(str, Enum):
    BAMBOO = "bamboo"
    TIMBER = "timber"
    EARTH = "earth"
    BRICK = "brick"
    STONE = "stone"
    ROOF_TILE = "roof_tile"
    BINDER = "binder"
    COMPOSITE = "composite"


@dataclass(frozen=True, slots=True)
class ThermalProperties:
    thermal_conductivity_w_per_mk: float  # lambda (W/m.K)
    specific_heat_j_per_kgk: float | None = None

    def __post_init__(self) -> None:
        if self.thermal_conductivity_w_per_mk <= 0:
            raise MaterialError("thermal_conductivity_w_per_mk must be > 0")


@dataclass(frozen=True, slots=True)
class DurabilityProperties:
    service_life_years: float
    moisture_sensitive: bool
    notes: str = ""

    def __post_init__(self) -> None:
        if self.service_life_years <= 0:
            raise MaterialError("service_life_years must be > 0")


@dataclass(frozen=True, slots=True)
class Material:
    id: TypedId
    name_en: str
    name_zh: str
    category: MaterialCategory
    region: str
    density_kg_per_m3: float
    thermal: ThermalProperties
    durability: DurabilityProperties
    confidence: ConfidenceLevel
    source: str
    model_version: str = "1.0.0"

    def __post_init__(self) -> None:
        if self.density_kg_per_m3 <= 0:
            raise MaterialError(f"Material {self.name_en}: density_kg_per_m3 must be > 0")
        if not self.source.strip():
            raise MaterialError(f"Material {self.name_en}: source must be non-empty")
