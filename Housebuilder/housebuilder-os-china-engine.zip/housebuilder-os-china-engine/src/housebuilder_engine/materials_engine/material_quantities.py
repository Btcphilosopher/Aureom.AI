"""
Quantity-takeoff: turns geometry (wall segments, roof areas) into material
quantities, applying waste factors, and retains a traceable link back to
the originating geometry (`source_id`).

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass

from housebuilder_engine.core.errors import CalculationError, MaterialError
from housebuilder_engine.core.ids import TypedId
from housebuilder_engine.core.provenance import (
    ConfidenceLevel,
    Provenance,
    ValidationStatus,
)
from housebuilder_engine.core.result import CalculationResult
from housebuilder_engine.core.units import Q
from housebuilder_engine.core.versioning import version_for
from housebuilder_engine.geometry_engine.primitives import WallSegment
from housebuilder_engine.materials_engine.material_properties import Material


@dataclass(frozen=True, slots=True)
class QuantityLine:
    """One line of a material schedule / bill of quantities."""

    material: Material
    source_id: TypedId
    net_volume_m3: float
    waste_fraction: float
    gross_volume_m3: float
    mass_kg: float

    def __post_init__(self) -> None:
        if self.waste_fraction < 0:
            raise MaterialError("waste_fraction must be >= 0")
        if self.net_volume_m3 < 0:
            raise MaterialError("net_volume_m3 must be >= 0")


def wall_material_quantity(
    wall: WallSegment, material: Material, *, waste_fraction: float = 0.05
) -> CalculationResult:
    """net wall area (already deducted for openings in WallSegment) x
    thickness = net volume; apply waste_fraction to get gross volume and
    the resulting mass, using the material's density.
    """
    if waste_fraction < 0 or waste_fraction > 1:
        raise CalculationError(f"waste_fraction must be in [0, 1], got {waste_fraction}")

    net_volume_m3 = wall.material_volume_m3().to("m**3").magnitude
    gross_volume_m3 = net_volume_m3 * (1.0 + waste_fraction)
    mass_kg = gross_volume_m3 * material.density_kg_per_m3

    line = QuantityLine(
        material=material,
        source_id=wall.id,
        net_volume_m3=net_volume_m3,
        waste_fraction=waste_fraction,
        gross_volume_m3=gross_volume_m3,
        mass_kg=mass_kg,
    )

    provenance = Provenance(
        model_name="materials.quantity_takeoff.wall",
        model_version=version_for("materials.quantity_takeoff"),
        data_sources=(f"wall:{wall.id}", f"material:{material.id}"),
        confidence=ConfidenceLevel.MEDIUM,
        validation_status=ValidationStatus.SYNTHETIC_MODEL
        if material.confidence == ConfidenceLevel.LOW
        else ValidationStatus.IMPLEMENTED,
        review_required=material.confidence == ConfidenceLevel.LOW,
    )

    return CalculationResult(
        value=line,
        unit="m**3 / kg (see QuantityLine)",
        method="material_quantities.wall_material_quantity",
        provenance=provenance,
        assumptions=(
            f"Waste factor {waste_fraction:.0%} applied uniformly",
            "Material density treated as constant (no moisture-content adjustment)",
        ),
        input_references=(f"wall:{wall.id}", f"material:{material.name_en}"),
        warnings=(
            (f"Material {material.name_en} uses synthetic, unverified density data",)
            if material.confidence == ConfidenceLevel.LOW
            else ()
        ),
    )


def roof_tile_quantity(
    roof_area_m2: float,
    material: Material,
    *,
    coverage_factor_tiles_per_m2: float,
    waste_fraction: float = 0.08,
) -> CalculationResult:
    """roof surface area x tile coverage factor = tile quantity (count),
    plus derived mass via an assumed per-tile mass computed from material
    density and a nominal tile volume.
    """
    if roof_area_m2 <= 0:
        raise CalculationError("roof_area_m2 must be > 0")
    if coverage_factor_tiles_per_m2 <= 0:
        raise CalculationError("coverage_factor_tiles_per_m2 must be > 0")

    net_tile_count = roof_area_m2 * coverage_factor_tiles_per_m2
    gross_tile_count = net_tile_count * (1.0 + waste_fraction)

    provenance = Provenance(
        model_name="materials.quantity_takeoff.roof_tile",
        model_version=version_for("materials.quantity_takeoff"),
        data_sources=(f"material:{material.id}",),
        confidence=ConfidenceLevel.LOW,
        validation_status=ValidationStatus.SYNTHETIC_MODEL,
        review_required=True,
    )

    return CalculationResult(
        value=gross_tile_count,
        unit="count",
        method="material_quantities.roof_tile_quantity",
        provenance=provenance,
        assumptions=(
            f"Coverage factor {coverage_factor_tiles_per_m2} tiles/m^2 (synthetic, "
            "typical overlap for small clay roof tiles — not manufacturer data)",
            f"Waste factor {waste_fraction:.0%} applied for breakage/cutting",
        ),
        warnings=("Tile coverage factor is a synthetic placeholder, not sourced from a manufacturer",),
    )
