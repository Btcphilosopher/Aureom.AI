"""
CLI entry point. `housebuilder demo` runs the Jiangnan Bamboo House 001
vertical slice end-to-end and prints real computed numbers.

Status: PARTIALLY_IMPLEMENTED — only `demo` is wired up in this first
delivery; `init`, `validate`, `calculate`, `simulate`, `optimise`, `twin`,
`report` are not yet implemented.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from housebuilder_engine.architecture_engine.jiangnan_fixture import build

app = typer.Typer(add_completion=False, help="HOUSEBUILDER.OS CHINA ENGINE command line interface")
console = Console()


@app.command()
def version() -> None:
    """Print the engine version."""
    console.print("housebuilder-engine 0.1.0")


@app.command()
def demo(output_dir: Path = typer.Option(Path("output"), help="Directory to write JSON results to")) -> None:
    """Run the Jiangnan Bamboo House 001 vertical slice and print real numbers."""
    start = time.perf_counter()
    console.rule("[bold cyan]HOUSEBUILDER.OS CHINA ENGINE — demo[/bold cyan]")
    console.print("[bold]Project:[/bold] Jiangnan Bamboo House 001 (synthetic humid eastern-China climate zone)")

    slice_ = build()

    geo_table = Table(title="Geometry")
    geo_table.add_column("Quantity")
    geo_table.add_column("Value", justify="right")
    geo_table.add_row("Site gross footprint", f"{slice_.gross_footprint_m2():.2f} m2")
    geo_table.add_row("Courtyard net area", f"{slice_.net_courtyard_m2():.2f} m2")
    geo_table.add_row("Roof surface area (28deg pitch)", f"{slice_.roof_area_m2:.2f} m2")
    for wall, qres in zip(slice_.walls, slice_.wall_quantity_results):
        net = wall.net_area_m2().magnitude
        geo_table.add_row(f"Wall {wall.id.value.hex[:8]} net area", f"{net:.2f} m2")
    console.print(geo_table)

    bamboo_table = Table(title="Bamboo primary column — hollow section properties")
    bamboo_table.add_column("Property")
    bamboo_table.add_column("Value", justify="right")
    bamboo_table.add_row("Outer diameter", f"{slice_.bamboo_geometry.outer_diameter_mm:.1f} mm")
    bamboo_table.add_row("Inner diameter", f"{slice_.bamboo_geometry.inner_diameter_mm:.1f} mm")
    bamboo_table.add_row("Cross-sectional area", f"{slice_.bamboo_area_result.value.magnitude:.1f} mm^2")
    bamboo_table.add_row("Second moment of area", f"{slice_.bamboo_inertia_result.value.magnitude:.0f} mm^4")
    bamboo_table.add_row("Approx. mass", f"{slice_.bamboo_mass_result.value.magnitude:.2f} kg")
    bamboo_table.add_row("Slenderness ratio", f"{slice_.bamboo_slenderness_result.value:.1f}")
    for w in slice_.bamboo_slenderness_result.warnings:
        bamboo_table.add_row("[yellow]warning[/yellow]", w)
    console.print(bamboo_table)

    console.print(
        f"[bold]Roof tile quantity[/bold]: {slice_.roof_tile_result.value:.0f} tiles "
        f"(gross, incl. {8}% waste) — [yellow]{slice_.roof_tile_result.warnings[0]}[/yellow]"
    )

    boq = slice_.bill_of_quantities
    cost_table = Table(title="Bill of Quantities — cost estimate")
    cost_table.add_column("Material")
    cost_table.add_column("Mass (kg)", justify="right")
    cost_table.add_column("Rate", justify="right")
    cost_table.add_column("Line total", justify="right")
    for line in boq.lines:
        cost_table.add_row(
            line.quantity.material.name_en,
            f"{line.quantity.mass_kg:.1f}",
            str(line.unit_rate),
            str(line.line_total),
        )
    console.print(cost_table)
    console.print(f"[bold]Direct cost:[/bold] {boq.direct_cost()}")
    console.print(f"[bold]Contingency ({boq.contingency_fraction:.0%}):[/bold] {boq.contingency()}")
    console.print(f"[bold green]Total estimate: {boq.total_estimate()}[/bold green]")
    console.print(
        "[yellow]All unit rates and several material properties in this run are "
        "SYNTHETIC placeholder data — not verified market or laboratory figures.[/yellow]"
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "project": {
            "name": slice_.project.name,
            "location": slice_.project.location,
            "storeys": slice_.project.storeys,
            "floor_area_target_m2": slice_.project.floor_area_target_m2,
        },
        "geometry": {
            "site_gross_footprint_m2": slice_.gross_footprint_m2(),
            "courtyard_net_area_m2": slice_.net_courtyard_m2(),
            "roof_area_m2": slice_.roof_area_m2,
        },
        "bamboo_column": {
            "area_result": slice_.bamboo_area_result.as_dict(),
            "inertia_result": slice_.bamboo_inertia_result.as_dict(),
            "mass_result": slice_.bamboo_mass_result.as_dict(),
            "slenderness_result": slice_.bamboo_slenderness_result.as_dict(),
        },
        "roof_tile_quantity": slice_.roof_tile_result.as_dict(),
        "bill_of_quantities": boq.as_report(),
    }
    out_path = output_dir / "jiangnan_bamboo_house_001_demo.json"
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    elapsed = time.perf_counter() - start
    console.print(f"\nWrote results to [bold]{out_path}[/bold] ({elapsed:.3f}s)")


if __name__ == "__main__":
    app()
