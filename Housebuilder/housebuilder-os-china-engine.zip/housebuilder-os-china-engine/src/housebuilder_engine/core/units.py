"""
Explicit unit handling for all physical quantities in the engine.

Wraps `pint` with a single shared UnitRegistry (pint requires this — two
registries produce mutually-incompatible Quantity objects) and a strict
`Q` constructor that rejects bare, unitless numbers wherever a physical
quantity is expected.

Status: IMPLEMENTED
"""
from __future__ import annotations

from typing import Any

import pint

# Single shared registry for the whole process. Import this module's
# `ureg` / `Q` rather than instantiating pint directly anywhere else.
ureg = pint.UnitRegistry(autoconvert_offset_to_baseunit=True)
ureg.formatter.default_format = "~P"

Quantity = ureg.Quantity


class UnitError(ValueError):
    """Raised when a dimensionally invalid or ambiguous quantity is used."""


# Canonical unit families the engine is allowed to work in. Anything
# outside these dimensionalities is very likely a modelling mistake, so
# `Q()` will still construct it (pint supports far more), but call sites
# that pass `expect_dimensionality=` get an explicit, early check.
LENGTH = "[length]"
AREA = "[length] ** 2"
VOLUME = "[length] ** 3"
MASS = "[mass]"
FORCE = "[length] * [mass] / [time] ** 2"
PRESSURE = "[mass] / [length] / [time] ** 2"
POWER = "[length] ** 2 * [mass] / [time] ** 3"
ENERGY = "[length] ** 2 * [mass] / [time] ** 2"
TEMPERATURE = "[temperature]"
VOLUME_FLOW = "[length] ** 3 / [time]"


def Q(value: float, unit: str, *, expect_dimensionality: str | None = None) -> "pint.Quantity":
    """Construct a pint Quantity with optional dimensionality validation.

    Raises UnitError (not pint's own exception types) so callers only
    need to catch one error type for all unit problems in this engine.
    """
    try:
        quantity = ureg.Quantity(value, unit)
    except (pint.UndefinedUnitError, pint.DimensionalityError) as exc:
        raise UnitError(f"Invalid unit {unit!r}: {exc}") from exc

    if expect_dimensionality is not None:
        try:
            if not quantity.check(expect_dimensionality):
                raise UnitError(
                    f"Quantity {quantity} does not have dimensionality "
                    f"{expect_dimensionality!r} (has {quantity.dimensionality})"
                )
        except pint.DimensionalityError as exc:  # pragma: no cover - defensive
            raise UnitError(str(exc)) from exc
    return quantity


def require_dimensionality(quantity: Any, dimensionality: str, *, context: str = "") -> None:
    """Validate that `quantity` is a pint Quantity with the given dimensionality."""
    if not isinstance(quantity, ureg.Quantity):
        raise UnitError(
            f"{context or 'value'} must be a pint Quantity with units, got {type(quantity)!r}. "
            "Bare numbers are not accepted for physical quantities."
        )
    if not quantity.check(dimensionality):
        raise UnitError(
            f"{context or 'value'} has dimensionality {quantity.dimensionality}, "
            f"expected {dimensionality}"
        )


def to(quantity: "pint.Quantity", unit: str) -> "pint.Quantity":
    """Convert a quantity to `unit`, raising UnitError on incompatible units."""
    try:
        return quantity.to(unit)
    except pint.DimensionalityError as exc:
        raise UnitError(str(exc)) from exc


def magnitude_in(quantity: "pint.Quantity", unit: str) -> float:
    """Return the bare float magnitude of `quantity` expressed in `unit`."""
    return float(to(quantity, unit).magnitude)
