"""
Explicit uncertainty bounds for calculation results.

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Uncertainty:
    """A simple bound description; not a full probability distribution.

    `low`/`high` are in the same unit as the parent CalculationResult.
    `basis` explains where the bound came from (e.g. "±15% material
    property scatter, generic literature range" — never invented
    precision).
    """

    low: float
    high: float
    basis: str

    def __post_init__(self) -> None:
        if self.low > self.high:
            raise ValueError(f"Uncertainty low ({self.low}) exceeds high ({self.high})")
        if not self.basis.strip():
            raise ValueError("Uncertainty.basis must describe where the bound comes from")

    def as_dict(self) -> dict:
        return {"low": self.low, "high": self.high, "basis": self.basis}

    @classmethod
    def relative(cls, value: float, fraction: float, basis: str) -> "Uncertainty":
        """Build a symmetric uncertainty band as ±fraction of `value`."""
        if fraction < 0:
            raise ValueError("fraction must be >= 0")
        delta = abs(value) * fraction
        return cls(low=value - delta, high=value + delta, basis=basis)
