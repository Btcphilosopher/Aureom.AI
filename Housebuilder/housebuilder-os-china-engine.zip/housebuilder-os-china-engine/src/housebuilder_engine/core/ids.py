"""
Deterministic, typed identifiers used throughout the engine.

All domain objects are identified by a `TypedId`: a UUID5 derived from a
namespace + a caller-supplied seed string, OR a random UUID4 when no seed
is given. Using UUID5 with an explicit seed is what makes fixtures and
demo projects reproducible: the same seed string always yields the same ID.

Status: IMPLEMENTED
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import ClassVar

# Fixed namespace UUID for the whole engine. Do not change this value —
# changing it would silently change every deterministic ID ever generated.
_ENGINE_NAMESPACE = uuid.UUID("c1a1d0f0-7e6a-4b2a-9b0a-5d1a2f3c4e5f")


@dataclass(frozen=True, slots=True)
class TypedId:
    """A namespaced, typed identifier.

    `kind` is a short domain tag (e.g. "project", "wall", "material") so
    that IDs are self-describing when logged or serialised, and so that
    two objects of different kinds sharing a seed never collide.
    """

    kind: str
    value: uuid.UUID

    KIND_NAMESPACES: ClassVar[dict[str, uuid.UUID]] = {}

    @classmethod
    def new(cls, kind: str, seed: str | None = None) -> "TypedId":
        if not kind or not kind.strip():
            raise ValueError("TypedId kind must be a non-empty string")
        ns = cls._namespace_for_kind(kind)
        if seed is None:
            value = uuid.uuid4()
        else:
            value = uuid.uuid5(ns, seed)
        return cls(kind=kind, value=value)

    @classmethod
    def _namespace_for_kind(cls, kind: str) -> uuid.UUID:
        if kind not in cls.KIND_NAMESPACES:
            cls.KIND_NAMESPACES[kind] = uuid.uuid5(_ENGINE_NAMESPACE, kind)
        return cls.KIND_NAMESPACES[kind]

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"{self.kind}:{self.value}"

    def to_str(self) -> str:
        return str(self)

    @classmethod
    def parse(cls, text: str) -> "TypedId":
        kind, _, raw = text.partition(":")
        if not raw:
            raise ValueError(f"Malformed TypedId string: {text!r}")
        return cls(kind=kind, value=uuid.UUID(raw))
