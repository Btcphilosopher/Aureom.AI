"""
Structured calculation results. Engineering/physics functions in this
codebase should return a `CalculationResult`, not a bare float — bare
floats carry no units, no provenance and no uncertainty, and are exactly
how "synthetic data" silently becomes "verified data" downstream.

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

from housebuilder_engine.core.provenance import Provenance
from housebuilder_engine.core.uncertainty import Uncertainty

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class CalculationResult(Generic[T]):
    value: T
    unit: str | None
    method: str
    provenance: Provenance
    assumptions: tuple[str, ...] = field(default_factory=tuple)
    uncertainty: Uncertainty | None = None
    input_references: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    @property
    def review_required(self) -> bool:
        return self.provenance.review_required

    def as_dict(self) -> dict[str, Any]:
        value = self.value
        # Unwrap pint Quantities / Money into plain-serialisable form.
        if hasattr(value, "magnitude"):
            value = float(value.magnitude)
        elif hasattr(value, "amount"):
            value = str(value.amount)
        return {
            "value": value,
            "unit": self.unit,
            "method": self.method,
            "assumptions": list(self.assumptions),
            "uncertainty": self.uncertainty.as_dict() if self.uncertainty else None,
            "input_references": list(self.input_references),
            "warnings": list(self.warnings),
            "provenance": self.provenance.as_dict(),
        }
