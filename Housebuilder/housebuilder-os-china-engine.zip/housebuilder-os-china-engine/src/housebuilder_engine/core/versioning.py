"""
Central registry of model versions used to populate Provenance.model_version.

Bumping a version here is a deliberate act that should accompany a change
to the corresponding calculation's formula or assumptions, so that
historical results computed under the old formula remain distinguishable.

Status: IMPLEMENTED
"""
from __future__ import annotations

MODEL_VERSIONS: dict[str, str] = {
    "geometry.polygon": "1.0.0",
    "geometry.wall_area": "1.0.0",
    "geometry.roof_area": "1.0.0",
    "bamboo.hollow_section": "1.0.0",
    "materials.quantity_takeoff": "1.0.0",
    "structural.simplified_beam": "1.0.0",
    "cost.bill_of_quantities": "1.0.0",
}


def version_for(model_name: str) -> str:
    try:
        return MODEL_VERSIONS[model_name]
    except KeyError as exc:
        raise KeyError(
            f"No registered model version for {model_name!r}; "
            "register it in core.versioning.MODEL_VERSIONS"
        ) from exc
