"""
Decimal-based money type. No monetary calculation in this engine may use
floating-point arithmetic — floats are only acceptable for physical
engineering quantities (via pint), never for currency.

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from enum import Enum
from typing import Union

SUPPORTED_CURRENCIES = {"CNY", "USD", "EUR"}

DecimalLike = Union[Decimal, int, str]


class PriceStatus(str, Enum):
    SYNTHETIC = "synthetic"
    VERIFIED = "verified"
    SUPPLIER_QUOTE = "supplier_quote"


class CurrencyError(ValueError):
    pass


def _as_decimal(value: DecimalLike) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        raise CurrencyError(
            "Money amounts must not be constructed from float — pass Decimal, "
            "int, or a str representation to avoid binary floating-point error."
        )
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class Money:
    """A currency amount with mandatory provenance metadata.

    Every Money value must be traceable: on what date the price applied,
    in what geographic market, whether it is tax-inclusive, and whether it
    is synthetic placeholder data or a verified/sourced figure.
    """

    amount: Decimal
    currency: str
    price_date: date
    market: str
    tax_inclusive: bool
    status: PriceStatus
    source: str = ""

    def __post_init__(self) -> None:
        if self.currency not in SUPPORTED_CURRENCIES:
            raise CurrencyError(
                f"Unsupported currency {self.currency!r}; "
                f"supported: {sorted(SUPPORTED_CURRENCIES)}"
            )
        if not self.market or not self.market.strip():
            raise CurrencyError("Money requires a non-empty `market` field")
        if self.status == PriceStatus.SYNTHETIC and not self.source:
            object.__setattr__(self, "source", "synthetic_placeholder")

    @classmethod
    def of(
        cls,
        amount: DecimalLike,
        currency: str,
        *,
        price_date: date,
        market: str,
        tax_inclusive: bool = False,
        status: PriceStatus = PriceStatus.SYNTHETIC,
        source: str = "",
    ) -> "Money":
        return cls(
            amount=_as_decimal(amount),
            currency=currency,
            price_date=price_date,
            market=market,
            tax_inclusive=tax_inclusive,
            status=status,
            source=source,
        )

    def _check_compatible(self, other: "Money") -> None:
        if not isinstance(other, Money):
            raise CurrencyError(f"Cannot combine Money with {type(other)!r}")
        if other.currency != self.currency:
            raise CurrencyError(
                f"Cannot combine {self.currency} with {other.currency} without "
                "an explicit, dated FX conversion"
            )

    def __add__(self, other: "Money") -> "Money":
        self._check_compatible(other)
        status = self.status
        if self.status != other.status:
            # Mixing synthetic and verified figures degrades the whole sum
            # to synthetic — never silently present a partly-synthetic
            # total as verified.
            status = PriceStatus.SYNTHETIC
        return Money(
            amount=self.amount + other.amount,
            currency=self.currency,
            price_date=max(self.price_date, other.price_date),
            market=self.market if self.market == other.market else "mixed",
            tax_inclusive=self.tax_inclusive and other.tax_inclusive,
            status=status,
            source="aggregate",
        )

    def __mul__(self, factor: DecimalLike) -> "Money":
        return Money(
            amount=(self.amount * _as_decimal(factor)).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            ),
            currency=self.currency,
            price_date=self.price_date,
            market=self.market,
            tax_inclusive=self.tax_inclusive,
            status=self.status,
            source=self.source,
        )

    __rmul__ = __mul__

    def rounded(self, places: str = "0.01") -> "Money":
        return Money(
            amount=self.amount.quantize(Decimal(places), rounding=ROUND_HALF_UP),
            currency=self.currency,
            price_date=self.price_date,
            market=self.market,
            tax_inclusive=self.tax_inclusive,
            status=self.status,
            source=self.source,
        )

    def __str__(self) -> str:  # pragma: no cover - trivial
        tag = "" if self.status == PriceStatus.VERIFIED else f" [{self.status.value}]"
        return f"{self.amount} {self.currency}{tag}"


def sum_money(items: list[Money]) -> Money:
    if not items:
        raise CurrencyError("sum_money() requires at least one Money value")
    total = items[0]
    for m in items[1:]:
        total = total + m
    return total
