"""
Provenance metadata attached to every non-trivial calculation result.

Status: IMPLEMENTED
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class ValidationStatus(str, Enum):
    IMPLEMENTED = "IMPLEMENTED"
    PARTIALLY_IMPLEMENTED = "PARTIALLY_IMPLEMENTED"
    SYNTHETIC_MODEL = "SYNTHETIC_MODEL"
    REQUIRES_ENGINEERING_VALIDATION = "REQUIRES_ENGINEERING_VALIDATION"
    ARCHITECTURAL_ONLY = "ARCHITECTURAL_ONLY"


class ConfidenceLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    UNVALIDATED = "unvalidated"


@dataclass(frozen=True, slots=True)
class Provenance:
    """Describes where a number came from and how much to trust it.

    Attached to CalculationResult (see core.result) rather than duplicated
    ad hoc on every domain object.
    """

    model_name: str
    model_version: str
    data_sources: tuple[str, ...]
    confidence: ConfidenceLevel
    validation_status: ValidationStatus
    review_required: bool
    generated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def as_dict(self) -> dict:
        return {
            "model_name": self.model_name,
            "model_version": self.model_version,
            "data_sources": list(self.data_sources),
            "confidence": self.confidence.value,
            "validation_status": self.validation_status.value,
            "review_required": self.review_required,
            "generated_at": self.generated_at.isoformat(),
        }
