"""
Shared exception hierarchy for the engine.

Status: IMPLEMENTED
"""
from __future__ import annotations


class EngineError(Exception):
    """Base class for all engine-raised errors."""


class DomainValidationError(EngineError):
    """A domain model or input failed validation (e.g. negative dimension)."""


class GeometryError(EngineError):
    """Invalid or degenerate geometry."""


class MaterialError(EngineError):
    """A material reference or property is missing or invalid."""


class CalculationError(EngineError):
    """A calculation could not be completed with the given inputs."""
