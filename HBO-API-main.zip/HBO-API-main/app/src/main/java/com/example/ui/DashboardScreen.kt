package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*

// ==========================================
// CUSTOM GLASSMORPHIC UI HELPERS
// ==========================================

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val baseModifier = modifier
        .clip(RoundedCornerShape(24.dp))
        .background(
            Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.08f),
                    Color.White.copy(alpha = 0.02f)
                )
            )
        )
        .border(
            BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
            RoundedCornerShape(24.dp)
        )
    
    if (onClick != null) {
        Column(
            modifier = baseModifier.clickable(onClick = onClick).padding(20.dp),
            content = content
        )
    } else {
        Column(
            modifier = baseModifier.padding(20.dp),
            content = content
        )
    }
}

@Composable
fun SovereignSystemHeader(
    balance: Double,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepNavy)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        // System status row: Mainnet-Alpha and status ping indicators
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Glow/Neon status bullet
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(NeonGreen, RoundedCornerShape(50))
                )
                Text(
                    text = "Mainnet-Alpha // Node_0x4F",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GrayText.copy(alpha = 0.9f),
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.2.sp,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Vault: LOCKED",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldBrass,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Text(
                    text = "92ms",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GrayText.copy(alpha = 0.7f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(10.dp))
        
        // Brand logo header styling & portable wallet balance
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "HBO",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = GoldBrass,
                        fontSize = 32.sp,
                        letterSpacing = (-0.5).sp,
                        lineHeight = 32.sp
                    )
                    Text(
                        text = " API",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Light,
                        color = Color.White,
                        fontSize = 18.sp,
                        letterSpacing = 3.sp,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "SOVEREIGN MEDIA PROTOCOL",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GrayText.copy(alpha = 0.6f),
                        letterSpacing = 2.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                )
            }
            
            // Vault wallet balance display (Dynamic)
            Surface(
                color = GoldBrass,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.clickable {
                    clipboard.setText(AnnotatedString(viewModel.userAddress))
                    Toast.makeText(context, "Wallet address copied: ${viewModel.userAddress.take(8)}...", Toast.LENGTH_SHORT).show()
                }
            ) {
                Text(
                    text = "${String.format("%.2f", balance)} \$AURE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = DeepNavy,
                        letterSpacing = 0.5.sp
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) }

    val allContent by viewModel.allContent.collectAsStateWithLifecycle()
    val allChannels by viewModel.allChannels.collectAsStateWithLifecycle()
    val allP2PNodes by viewModel.allP2PNodes.collectAsStateWithLifecycle()
    val userSubscriptions by viewModel.userSubscriptions.collectAsStateWithLifecycle()
    val balance by viewModel.userWalletBalance.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            SovereignSystemHeader(balance = balance, viewModel = viewModel)
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.Black.copy(alpha = 0.40f),
                tonalElevation = 0.dp,
                modifier = Modifier
                    .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.04f)), RoundedCornerShape(0.dp))
                    .navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Stream Deck") },
                    label = { Text("Stream Deck") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepNavy,
                        selectedTextColor = GoldBrass,
                        indicatorColor = GoldBrass,
                        unselectedIconColor = GrayText,
                        unselectedTextColor = GrayText
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = "Creator Studio") },
                    label = { Text("Studio API") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepNavy,
                        selectedTextColor = GoldBrass,
                        indicatorColor = GoldBrass,
                        unselectedIconColor = GrayText,
                        unselectedTextColor = GrayText
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Default.Lock, contentDescription = "HBO Vault") },
                    label = { Text("Vault") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepNavy,
                        selectedTextColor = GoldBrass,
                        indicatorColor = GoldBrass,
                        unselectedIconColor = GrayText,
                        unselectedTextColor = GrayText
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Config & Analytics") },
                    label = { Text("Rights & Analytics") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepNavy,
                        selectedTextColor = GoldBrass,
                        indicatorColor = GoldBrass,
                        unselectedIconColor = GrayText,
                        unselectedTextColor = GrayText
                    )
                )
            }
        },
        containerColor = DeepNavy
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal border accent to delineate content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(GridBorder.copy(alpha = 0.4f))
            )

            // Dynamic Tab Views
            when (activeTab) {
                0 -> StreamDeckView(viewModel, allContent, allChannels, userSubscriptions)
                1 -> CreatorStudioView(viewModel)
                2 -> SovereignVaultView(viewModel, allChannels, userSubscriptions, balance)
                3 -> RightsAndAnalyticsView(viewModel, allP2PNodes)
            }
        }
    }
}

// ==========================================
// TAB 1: STREAM DECK VIEW
// ==========================================

@Composable
fun StreamDeckView(
    viewModel: MainViewModel,
    allContent: List<ContentNodeEntity>,
    allChannels: List<ChannelEntity>,
    userSubscriptions: List<SubscriptionEntity>
) {
    val context = LocalContext.current
    val currentPlaying by viewModel.currentPlayingNode.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val progress by viewModel.playbackProgress.collectAsStateWithLifecycle()
    val isP2P by viewModel.isDistributedStreaming.collectAsStateWithLifecycle()
    val bitrate by viewModel.bitrateMode.collectAsStateWithLifecycle()

    val p2pDownSpeed by viewModel.peerDownloadSpeed.collectAsStateWithLifecycle()
    val p2pUpSpeed by viewModel.peerUploadSpeed.collectAsStateWithLifecycle()
    val ratio by viewModel.p2pContributionRatio.collectAsStateWithLifecycle()
    val peersCount by viewModel.activePeersCount.collectAsStateWithLifecycle()

    var showBitrateMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Broadcaster screening terminal (Luxury Glass Card format)
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Now Streaming Top row (styled exactly like Elegant Dark HTML)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isPlaying) "NOW STREAMING" else "BROADCAST SUSPENDED",
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            fontWeight = FontWeight.Bold,
                            color = GoldBrass,
                            fontSize = 11.sp,
                            letterSpacing = 1.5.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                        Text(
                            text = if (isPlaying) (currentPlaying?.title ?: "The Gilded Age S3") else "Console Deck Suspended",
                            fontFamily = FontFamily.Serif,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            lineHeight = 28.sp
                        )
                        if (isPlaying) {
                            Text(
                                text = "Decentralized Node IPFS Broadcast",
                                style = MaterialTheme.typography.bodySmall.copy(color = GrayText, fontSize = 11.sp)
                            )
                        }
                    }

                    // Luxury circular gold/brass broadcast play/pause action button
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .border(BorderStroke(1.dp, GoldBrass.copy(alpha = 0.4f)), RoundedCornerShape(50))
                            .clickable { viewModel.togglePlayback() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isPlaying) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(modifier = Modifier.size(width = 3.dp, height = 12.dp).background(GoldBrass))
                                Box(modifier = Modifier.size(width = 3.dp, height = 12.dp).background(GoldBrass))
                            }
                        } else {
                            // Perfect canvas draw for clean gold play triangle
                            Canvas(modifier = Modifier.size(12.dp)) {
                                val path = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(3f, 0f)
                                    lineTo(12f, 6f)
                                    lineTo(3f, 12f)
                                    close()
                                }
                                drawPath(path, color = GoldBrass)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Simulated Video Visualizer Terminal with dark grid lines
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Drawing futuristic grid overlay lines
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 1f
                        val gridSpacing = size.width / 10
                        for (i in 1..9) {
                            drawLine(
                                color = GridBorder.copy(alpha = 0.25f),
                                start = Offset(i * gridSpacing, 0f),
                                end = Offset(i * gridSpacing, size.height),
                                strokeWidth = strokeWidth
                            )
                            drawLine(
                                color = GridBorder.copy(alpha = 0.25f),
                                start = Offset(0f, i * (size.height / 10)),
                                end = Offset(size.width, i * (size.height / 10)),
                                strokeWidth = strokeWidth
                            )
                        }
                    }

                    // Content details on screens
                    if (isPlaying) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Active signal",
                                tint = GoldBrass.copy(alpha = 0.5f),
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentPlaying?.title ?: "Media Node Active",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "CID: " + (currentPlaying?.contentHash?.take(16) ?: "QmXoyp..."),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = GrayText,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Screen offline",
                                tint = GrayText.copy(alpha = 0.5f),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "STREAM CONSOLE STANDBY",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GrayText.copy(alpha = 0.7f),
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                    }

                    // Overlay standard network status
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Text(
                            text = "AURELIA DECENTRALIZED HYBRID SWARM",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NeonGreen.copy(alpha = 0.6f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Seek & Swarm Buffer progress indicators
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Swarm Replication Buffer",
                            style = MaterialTheme.typography.labelSmall.copy(color = GrayText, fontSize = 10.sp)
                        )
                        Text(
                            text = "${(progress * 100).toInt()}% Buffer Synced",
                            style = MaterialTheme.typography.labelSmall.copy(color = GoldBrass, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = GoldBrass,
                        trackColor = CardNavy
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Triple column telemetry grid matching "Elegant Dark" design specs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.2f))
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "PEERS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GrayText,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isP2P) "${peersCount} Nodes" else "1.2K",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                        )
                    }

                    Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.White.copy(alpha = 0.05f)))

                    Column(
                        modifier = Modifier.weight(1.2f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "BANDWIDTH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GrayText,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isPlaying) (if (isP2P) "${String.format("%.1f", p2pDownSpeed + 3.2)} Gbps" else "1.8 Gbps") else "0.0 Gbps",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                        )
                    }

                    Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.White.copy(alpha = 0.05f)))

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "RIGHTS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GrayText,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "L1 EXEC",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GoldBrass,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tactical action trigger buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.togglePlayback() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPlaying) SolidNavy else GoldBrass,
                            contentColor = if (isPlaying) GoldBrass else DeepNavy
                        ),
                        border = if (isPlaying) BorderStroke(1.dp, GoldBrass) else null,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text(
                            text = if (isPlaying) "PAUSE DECK" else "PLAY DECK",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.toggleP2P() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isP2P) CardNavy else DeepNavy,
                            contentColor = if (isP2P) NeonBlue else GrayText
                        ),
                        border = BorderStroke(1.dp, if (isP2P) NeonBlue else GridBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.4f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isP2P) Icons.Default.Share else Icons.Default.Settings,
                                contentDescription = "P2P Net",
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (isP2P) "SWARM ACTIVE" else "STANDARD CDN",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }

        // SWARM TELEMETRY METRICS
        if (isP2P) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SolidNavy),
                    border = BorderStroke(1.dp, GridBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "P2P Indicators", tint = NeonBlue)
                            Text(
                                text = "Distributed Streaming Swarm",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Grid of telemetry cards
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Metric 1: Download
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = CardNavy),
                                border = BorderStroke(1.dp, GridBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Peer Down speed", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                    Text(
                                        text = "${String.format("%.1f", p2pDownSpeed)} MB/s",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NeonGreen,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                            }
                            // Metric 2: Upload
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = CardNavy),
                                border = BorderStroke(1.dp, GridBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Peer Relay Upload", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                    Text(
                                        text = "${String.format("%.1f", p2pUpSpeed)} MB/s",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NeonBlue,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Metric 3: Ratio
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = CardNavy),
                                border = BorderStroke(1.dp, GridBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Swarm Saved Bandwidth", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                    Text(
                                        text = "${String.format("%.1f", ratio)}%",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = GoldBrass,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                            }
                            // Metric 4: Peers Active
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = CardNavy),
                                border = BorderStroke(1.dp, GridBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Connected Swarm Peers", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                    Text(
                                        text = "$peersCount Browser Nodes",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // MEDIA LIBRARY SELECTIONS
        item {
            Text(
                text = "Premium Media Catalog",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GoldBrass
                )
            )
        }

        if (allContent.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = GoldBrass)
                }
            }
        } else {
            items(allContent) { contentNode ->
                val channel = allChannels.find { it.channelId == contentNode.creatorId }
                val isUnlocked = remember(contentNode, userSubscriptions) {
                    val address = viewModel.userAddress
                    contentNode.pricingModel == "FREE" || 
                    userSubscriptions.any { it.channelId == contentNode.creatorId } ||
                    userSubscriptions.any { it.channelId == contentNode.contentId }
                }

                Card(
                    onClick = {
                        if (isUnlocked) {
                            viewModel.selectContentToPlay(contentNode)
                        } else {
                            Toast.makeText(
                                context,
                                "Access Restricted. Deploy Vault Subscription for ${channel?.name ?: "Channel"} to play.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentPlaying?.contentId == contentNode.contentId) SolidNavy else Color.Black.copy(alpha = 0.3f)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (currentPlaying?.contentId == contentNode.contentId) GoldBrass else Color.White.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contentNode.contentType + " • " + (channel?.name ?: "Decentralized Creator"),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = GoldBrass,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = contentNode.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                )
                            }

                            // Pricing Access Pill
                            Surface(
                                color = if (isUnlocked) NeonGreen.copy(alpha = 0.2f) else SoftGold.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, if (isUnlocked) NeonGreen else SoftGold),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = if (isUnlocked) "UNLOCKED" else if (contentNode.pricingModel == "PPV") "PPV: $${contentNode.pricingAmount}" else "SUBSCRIBE_REQUIRED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (isUnlocked) NeonGreen else LightGold
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = contentNode.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = GrayText),
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Render hash and tags
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = "Cryptographic Root", tint = GrayText, modifier = Modifier.size(12.dp))
                                Text(
                                    text = "IPFS_HASH: ${contentNode.contentHash.take(15)}...",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = GrayText,
                                        fontSize = 10.sp
                                    )
                                )
                            }

                            if (!isUnlocked) {
                                Button(
                                    onClick = {
                                        if (contentNode.pricingModel == "PPV") {
                                            viewModel.buyPPVTicket(contentNode) { msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            viewModel.subscribeWithVault(contentNode.creatorId, contentNode.pricingAmount) { msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldBrass),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("UNLOCK NOW", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DeepNavy)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: CREATOR STUDIO & API PLAYLOAD VIEW
// ==========================================

@Composable
fun CreatorStudioView(viewModel: MainViewModel) {
    val context = LocalContext.current
    val title by viewModel.studioTitle.collectAsStateWithLifecycle()
    val description by viewModel.studioDescription.collectAsStateWithLifecycle()
    val isGeneratingAI by viewModel.isGeneratingAI.collectAsStateWithLifecycle()
    val selectedContentType by viewModel.studioContentType.collectAsStateWithLifecycle()
    val selectedPricingMode by viewModel.studioPricingMode.collectAsStateWithLifecycle()
    val pricingAmount by viewModel.studioPricingAmount.collectAsStateWithLifecycle()
    val seriesId by viewModel.studioSeriesId.collectAsStateWithLifecycle()
    val apiPayload by viewModel.apiConsolePayload.collectAsStateWithLifecycle()

    var showTypeDropdown by remember { mutableStateOf(false) }
    var showPricingDropdown by remember { mutableStateOf(false) }

    val clipboard = LocalClipboardManager.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Sovereign Creator Studio",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = GoldBrass,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Publish cryptographic media nodes directly to the decentralized network registry without intermediate gatekeepers.",
                    style = MaterialTheme.typography.bodySmall.copy(color = GrayText)
                )
            }
        }

        // Creator Uplink Board (Polished luxury layout specs)
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "1. METADATA REGISTRATION",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldBrass,
                            letterSpacing = 1.2.sp
                        )
                    )

                    // Title fields
                    OutlinedTextField(
                        value = title,
                        onValueChange = {
                            viewModel.studioTitle.value = it
                            viewModel.updateApiConsoleLog()
                        },
                        label = { Text("Content/Episode Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldBrass,
                            unfocusedBorderColor = GridBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                            unfocusedContainerColor = Color.Black.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Series ID field
                    OutlinedTextField(
                        value = seriesId,
                        onValueChange = {
                            viewModel.studioSeriesId.value = it
                            viewModel.updateApiConsoleLog()
                        },
                        label = { Text("Series / Collection ID") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldBrass,
                            unfocusedBorderColor = GridBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                            unfocusedContainerColor = Color.Black.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Description & Gemini Assistance
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Cinematic Description",
                                style = MaterialTheme.typography.labelSmall.copy(color = GrayText)
                            )

                            Button(
                                onClick = { viewModel.generateDescriptionWithGemini() },
                                colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                                border = BorderStroke(1.dp, GoldBrass),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp),
                                enabled = !isGeneratingAI
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Gemini AI",
                                        tint = GoldBrass,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = if (isGeneratingAI) "DRAFTING..." else "DRAFT METADATA VIA GEMINI",
                                        fontSize = 8.sp,
                                        color = GoldBrass,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = {
                                viewModel.studioDescription.value = it
                                viewModel.updateApiConsoleLog()
                            },
                            placeholder = { Text("Enter movie overview or let Gemini generate it dynamically...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldBrass,
                                unfocusedBorderColor = GridBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.1f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "2. POLICY & DISTRIBUTION MODEL",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldBrass,
                            letterSpacing = 1.2.sp
                        )
                    )

                    // Content Type & Pricing Model selector rows
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, GridBorder),
                            color = CardNavy,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showTypeDropdown = true }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Media Type", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedContentType, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = GoldBrass)
                                }
                                DropdownMenu(
                                    expanded = showTypeDropdown,
                                    onDismissRequest = { showTypeDropdown = false },
                                    modifier = Modifier.background(SolidNavy)
                                ) {
                                    listOf("EPISODE", "MOVIE", "TRAILER", "PPV_EVENT").forEach { typeStr ->
                                        DropdownMenuItem(
                                            text = { Text(typeStr, color = Color.White) },
                                            onClick = {
                                                viewModel.studioContentType.value = typeStr
                                                viewModel.updateApiConsoleLog()
                                                showTypeDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, GridBorder),
                            color = CardNavy,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showPricingDropdown = true }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Access Tier", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedPricingMode, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = GoldBrass)
                                }
                                DropdownMenu(
                                    expanded = showPricingDropdown,
                                    onDismissRequest = { showPricingDropdown = false },
                                    modifier = Modifier.background(SolidNavy)
                                ) {
                                    listOf("SUBSCRIPTION", "FREE", "PPV").forEach { modeStr ->
                                        DropdownMenuItem(
                                            text = { Text(modeStr, color = Color.White) },
                                            onClick = {
                                                viewModel.studioPricingMode.value = modeStr
                                                viewModel.updateApiConsoleLog()
                                                showPricingDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (selectedPricingMode != "FREE") {
                        OutlinedTextField(
                            value = pricingAmount,
                            onValueChange = {
                                viewModel.studioPricingAmount.value = it
                                viewModel.updateApiConsoleLog()
                            },
                            label = { Text("Access Fee (\$AURE tokens)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldBrass,
                                unfocusedBorderColor = GridBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Signature & Publish
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Text("PROVENANCE CRYPTO SIGNATURE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = GrayText))
                            Text(
                                "ECDSA_VAL:${viewModel.userAddress.take(16)}..._SHA256",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = NeonGreen,
                                    fontSize = 9.sp
                                )
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.publishCustomContent { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldBrass),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Publish content", tint = DeepNavy)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("PUBLISH REGISTER", color = DeepNavy, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // SOVEREIGN API PLAYLOAD CONSOLE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(modifier = Modifier.size(6.dp).background(GoldBrass, RoundedCornerShape(50)))
                            Text(
                                text = "Aurelia Browser SDK Executable Payload",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }

                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(apiPayload))
                                Toast.makeText(context, "API script copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Copy SDK Script", tint = GoldBrass)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = SolidNavy,
                        border = BorderStroke(1.dp, GridBorder),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = apiPayload,
                            modifier = Modifier
                                .padding(12.dp)
                                .horizontalScroll(rememberScrollState()),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SoftGold,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: SOVEREIGN VAULT SECURE CREDENTIALS
// ==========================================

@Composable
fun SovereignVaultView(
    viewModel: MainViewModel,
    allChannels: List<ChannelEntity>,
    userSubscriptions: List<SubscriptionEntity>,
    balance: Double
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AURELIA Cryptographic Vault",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = GoldBrass,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Your sovereign decentralized authorization card. Holds verification keys to validate streams, purchase subscriptions, and retain platform portable credentials.",
                    style = MaterialTheme.typography.bodySmall.copy(color = GrayText)
                )
            }
        }

        // Vault Keys Info Code Card (Custom high-end GlassCard format)
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "IDENTIFICATION SCHEME",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = GoldBrass,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )

                        Surface(
                            color = NeonGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, NeonGreen)
                        ) {
                            Text(
                                "SECP256K1 APPROVED",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                    // Address
                    Column {
                        Text("Sovereign Wallet Address", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                viewModel.userAddress,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 15.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                clipboard.setText(AnnotatedString(viewModel.userAddress))
                                Toast.makeText(context, "Wallet address copied!", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Send, contentDescription = "Copy Wallet", tint = GoldBrass, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    // Keys Base64 Display
                    Column {
                        Text("ECC Public Key Signature", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                        Surface(
                            color = Color.Black.copy(alpha = 0.3f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                viewModel.userPublicKeyBase64,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = SoftGold,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Column {
                        Text("ECC Encrypted Private Seed Key", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                        Surface(
                            color = Color.Black.copy(alpha = 0.3f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                viewModel.userPrivateKeyBase64,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.Red.copy(alpha = 0.5f),
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                "Sovereign Premium Subscriptions",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GoldBrass
                )
            )
        }

        // Channel subscription items
        if (allChannels.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = GoldBrass)
                }
            }
        } else {
            items(allChannels) { channel ->
                val isSubscribed = userSubscriptions.any { it.channelId == channel.channelId }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                    border = BorderStroke(1.dp, if (isSubscribed) NeonGreen else Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = channel.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Text(
                                    text = "Creator Signature: ${channel.creatorAddress.take(24)}...",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = GrayText
                                    )
                                )
                            }

                            if (isSubscribed) {
                                Surface(
                                    color = NeonGreen.copy(alpha = 0.2f),
                                    border = BorderStroke(1.dp, NeonGreen),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = NeonGreen, modifier = Modifier.size(12.dp))
                                        Text("VAULT SECURED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        viewModel.subscribeWithVault(channel.channelId, 15.0) { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldBrass),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("SUBSCRIBE • 15.00 \$AURE", fontSize = 10.sp, color = DeepNavy, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = channel.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = GrayText)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text("Total Subscribers: ${channel.subscriberCount}", style = MaterialTheme.typography.labelSmall.copy(color = GrayText))
                            Text("Vault Deposited: $${channel.revenueBalance}", style = MaterialTheme.typography.labelSmall.copy(color = GoldBrass))
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 4: ACCESS CONTROL POLICY & ANALYTICS
// ==========================================

@Composable
fun RightsAndAnalyticsView(viewModel: MainViewModel, allP2PNodes: List<P2PNodeEntity>) {
    var geoWhitelistUs by remember { mutableStateOf(true) }
    var geoWhitelistEu by remember { mutableStateOf(true) }
    var geoWhitelistAp by remember { mutableStateOf(false) }
    var deviceRestricted by remember { mutableStateOf(true) }
    var ageGated by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Consensus Access Rules (Rights Policy)",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = GoldBrass,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Configure programmable constraints on ContentNodes. Network validators verify rules before rendering stream decryption nodes.",
                    style = MaterialTheme.typography.bodySmall.copy(color = GrayText)
                )
            }
        }

        // Access Control Switch Panel (Custom luxury GlassCard format)
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "RULE SETS DEFINITIONS",
                        style = MaterialTheme.typography.labelMedium.copy(color = GoldBrass, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    )

                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                    // Metric Swaps
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Validation Whitelist: United States", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold))
                            Text("Allow stream handshakes from US nodes", style = MaterialTheme.typography.bodySmall.copy(color = GrayText, fontSize = 11.sp))
                        }
                        Switch(
                            checked = geoWhitelistUs,
                            onCheckedChange = { geoWhitelistUs = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = GoldBrass, checkedTrackColor = CardNavy)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Validation Whitelist: European Union", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold))
                            Text("Allow stream handshakes from EU nodes", style = MaterialTheme.typography.bodySmall.copy(color = GrayText, fontSize = 11.sp))
                        }
                        Switch(
                            checked = geoWhitelistEu,
                            onCheckedChange = { geoWhitelistEu = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = GoldBrass, checkedTrackColor = CardNavy)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Validation Whitelist: Asia-Pacific", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold))
                            Text("Allow stream handshakes from AP nodes", style = MaterialTheme.typography.bodySmall.copy(color = GrayText, fontSize = 11.sp))
                        }
                        Switch(
                            checked = geoWhitelistAp,
                            onCheckedChange = { geoWhitelistAp = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = GoldBrass, checkedTrackColor = CardNavy)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enforce Hardware Cryptographic Vault", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold))
                            Text("Limits streams to approved security modules", style = MaterialTheme.typography.bodySmall.copy(color = GrayText, fontSize = 11.sp))
                        }
                        Switch(
                            checked = deviceRestricted,
                            onCheckedChange = { deviceRestricted = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = GoldBrass, checkedTrackColor = CardNavy)
                        )
                    }
                }
            }
        }

        // Sovereign cache distribution nodes
        item {
            Text(
                "Sovereign Cache Distribution Nodes & Telemetry",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GoldBrass
                )
            )
        }

        if (allP2PNodes.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = GoldBrass)
                }
            }
        } else {
            items(allP2PNodes) { node ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Online/Offline radar pulse
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(if (node.online) NeonGreen else Color.Gray, RoundedCornerShape(50))
                            )

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(node.hostName, fontWeight = FontWeight.Bold, color = Color.White)
                                    Surface(color = CardNavy, shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            node.role,
                                            fontSize = 8.sp,
                                            color = GoldBrass,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text("P2P IP Address: ${node.ipAddress}", style = MaterialTheme.typography.labelSmall.copy(color = GrayText, fontFamily = FontFamily.Monospace))
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${String.format("%.1f", node.bandwidthUsedMb)} MB Relay",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = NeonBlue,
                                    fontFamily = FontFamily.Monospace
                                )
                            )

                            Text(
                                text = "+${String.format("%.1f", node.rewardEarnedTokens)} \$AURE Earned",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NeonGreen,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
