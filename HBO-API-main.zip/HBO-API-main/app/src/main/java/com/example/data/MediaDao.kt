package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaDao {
    // Content Node Queries
    @Query("SELECT * FROM content_nodes ORDER BY timestamp DESC")
    fun getAllContentFlow(): Flow<List<ContentNodeEntity>>

    @Query("SELECT * FROM content_nodes WHERE contentId = :contentId LIMIT 1")
    suspend fun getContentById(contentId: String): ContentNodeEntity?

    @Query("SELECT * FROM content_nodes WHERE seriesId = :seriesId")
    fun getContentBySeries(seriesId: String): Flow<List<ContentNodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContent(content: ContentNodeEntity)

    @Delete
    suspend fun deleteContent(content: ContentNodeEntity)

    @Query("DELETE FROM content_nodes")
    suspend fun clearAllContent()

    // Channel Queries
    @Query("SELECT * FROM channels")
    fun getAllChannelsFlow(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE channelId = :channelId LIMIT 1")
    suspend fun getChannelById(channelId: String): ChannelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: ChannelEntity)

    @Query("UPDATE channels SET revenueBalance = revenueBalance + :amount WHERE channelId = :channelId")
    suspend fun addChannelRevenue(channelId: String, amount: Double)

    @Query("UPDATE channels SET subscriberCount = subscriberCount + 1 WHERE channelId = :channelId")
    suspend fun incrementSubscribers(channelId: String)

    // Subscription Queries
    @Query("SELECT * FROM subscriptions WHERE subscriberAddress = :address")
    fun getSubscriptionsForUserFlow(address: String): Flow<List<SubscriptionEntity>>

    @Query("SELECT COUNT(*) FROM subscriptions WHERE subscriberAddress = :address AND channelId = :channelId")
    suspend fun checkSubscriptionStatus(address: String, channelId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: SubscriptionEntity)

    // P2P Node Queries
    @Query("SELECT * FROM p2p_nodes")
    fun getAllP2PNodesFlow(): Flow<List<P2PNodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertP2PNode(node: P2PNodeEntity)

    @Query("UPDATE p2p_nodes SET bandwidthUsedMb = bandwidthUsedMb + :mb, rewardEarnedTokens = rewardEarnedTokens + :rewards WHERE nodeId = :nodeId")
    suspend fun updateNodeBandwidth(nodeId: String, mb: Double, rewards: Double)
}
