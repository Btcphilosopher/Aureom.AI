package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GoldBrass,
    secondary = SoftGold,
    tertiary = NeonGreen,
    background = DeepNavy,
    surface = SolidNavy,
    surfaceVariant = CardNavy,
    onPrimary = DeepNavy,
    onSecondary = DeepNavy,
    onBackground = Color.White,
    onSurface = Color(0xFFE1E4F2),
    outline = GridBorder
  )

private val LightColorScheme = DarkColorScheme // Always premium dark theme in this broadcast console!

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force premium dark by default
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve our tailored broadcast branding
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
