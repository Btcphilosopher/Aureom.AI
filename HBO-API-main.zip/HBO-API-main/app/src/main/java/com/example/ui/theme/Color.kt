package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldBrass = Color(0xFFC5A059) // High-end brass gold matching HTML
val LightGold = Color(0xFFF1E4C3) // Polished cream gold highlight
val DeepNavy = Color(0xFF020617) // Slate dark background base
val SolidNavy = Color(0xFF0B0F19) // Elegant deep dark container/card
val CardNavy = Color(0xFF131A2E) // Semi-translucent glass overlay fill
val GrayText = Color(0xFF94A3B8) // Elegant slate gray body text
val SoftGold = Color(0xFFA1803C) // Secondary darker golden accent
val NeonBlue = Color(0xFF6366F1) // Indigo/neon blue accent
val NeonGreen = Color(0xFF10B981) // Emerald status pulse indicator
val TranslucentGlass = Color(0x33FFFFFF) // Delicate white glass border
val GridBorder = Color(0xFF1E293B) // Dark grid line/border color
