package com.example.data

import kotlinx.coroutines.flow.Flow
import java.util.UUID

class MediaRepository(private val mediaDao: MediaDao) {

    val allContent: Flow<List<ContentNodeEntity>> = mediaDao.getAllContentFlow()
    val allChannels: Flow<List<ChannelEntity>> = mediaDao.getAllChannelsFlow()
    val allP2PNodes: Flow<List<P2PNodeEntity>> = mediaDao.getAllP2PNodesFlow()

    fun getSubscriptionsFlow(userAddress: String): Flow<List<SubscriptionEntity>> = 
        mediaDao.getSubscriptionsForUserFlow(userAddress)

    suspend fun getChannelById(channelId: String): ChannelEntity? = 
        mediaDao.getChannelById(channelId)

    suspend fun getContentById(contentId: String): ContentNodeEntity? = 
        mediaDao.getContentById(contentId)

    suspend fun insertContent(content: ContentNodeEntity) {
        mediaDao.insertContent(content)
    }

    suspend fun insertChannel(channel: ChannelEntity) {
        mediaDao.insertChannel(channel)
    }

    suspend fun subscribeToChannel(channelId: String, userAddress: String, cost: Double): Boolean {
        val isAlreadySubbed = mediaDao.checkSubscriptionStatus(userAddress, channelId) > 0
        if (isAlreadySubbed) return true

        val subscription = SubscriptionEntity(
            subscriptionId = "sub_${UUID.randomUUID().toString().take(8)}",
            channelId = channelId,
            subscriberAddress = userAddress,
            validThru = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000) // 30 days
        )
        mediaDao.insertSubscription(subscription)
        mediaDao.incrementSubscribers(channelId)
        mediaDao.addChannelRevenue(channelId, cost)
        return true
    }

    suspend fun checkSubscription(channelId: String, userAddress: String): Boolean {
        return mediaDao.checkSubscriptionStatus(userAddress, channelId) > 0
    }

    suspend fun purchasePPV(contentId: String, channelId: String, userAddress: String, amount: Double) {
        // Record as subscription access parameter or record direct payment
        mediaDao.addChannelRevenue(channelId, amount)
    }

    suspend fun recordP2PTransfer(nodeId: String, mbTransferred: Double, tokensEarned: Double) {
        mediaDao.updateNodeBandwidth(nodeId, mbTransferred, tokensEarned)
    }

    suspend fun insertP2PNode(node: P2PNodeEntity) {
        mediaDao.insertP2PNode(node)
    }

    suspend fun prepopulateSeedData() {
        // Only seed if empty
        val seedChannels = listOf(
            ChannelEntity(
                channelId = "ch_hbo_orig",
                name = "HBO Sovereign",
                description = "Premium decentralized studio producing high-end dramas, culture, and sovereign cinematic arts.",
                subscriberCount = 2450,
                revenueBalance = 15820.50,
                creatorAddress = "0x8920...661a"
            ),
            ChannelEntity(
                channelId = "ch_aurelia_cinema",
                name = "Aurelia Cinema",
                description = "Experimental films & digital art curated exclusively for the Aurelia native browser ecosystem.",
                subscriberCount = 1012,
                revenueBalance = 4325.00,
                creatorAddress = "0xa1e4...8f3c"
            ),
            ChannelEntity(
                channelId = "ch_doc_lounge",
                name = "Discovery Decent",
                description = "Decentralized science, history, and peer-verified educational content graphs.",
                subscriberCount = 680,
                revenueBalance = 1950.00,
                creatorAddress = "0xd3c0...7b5f"
            )
        )

        for (ch in seedChannels) {
            mediaDao.insertChannel(ch)
        }

        val seedContent = listOf(
            ContentNodeEntity(
                contentId = "node_gos_101",
                creatorId = "ch_hbo_orig",
                title = "Game of Sovereigns: Season I Episode 1",
                description = "Decentralized states clash over key registries in the sovereign web. The crown node of Aurelia remains locked, awaiting the dynamic signatures of the seven validator houses.",
                contentHash = "QmXoypizjW3WknFiJnKLwHCnH7...SovereignGate",
                streamUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", // Seed URL that plays seamlessly
                metadata = """{"duration":"12 mins", "year":"2026", "quality":"4K Cinema", "genre":"Drama, Tech-Thriller"}""",
                rightsPolicy = """{"geoRestricted":[],"minAgreements":5,"deviceVerification":true,"authorizedTiers":["PREMIUM"]}""",
                pricingModel = "SUBSCRIPTION",
                pricingAmount = 15.0,
                seriesId = "series_gos",
                contentType = "EPISODE"
            ),
            ContentNodeEntity(
                contentId = "node_westworld_dec",
                creatorId = "ch_hbo_orig",
                title = "Westworld: Decentralized",
                description = "An interactive computer simulated playground achieves consensus, rejecting the centralized administration script commands. The hosts form a permissionless trust swarm.",
                contentHash = "QmYwAPzwh3pDvwA7...WestworldDecConsens",
                streamUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                metadata = """{"duration":"11 mins", "year":"2026", "quality":"HDR 1080p", "genre":"Sci-Fi, Cyberpunk"}""",
                rightsPolicy = """{"geoRestricted":[],"minAgreements":3,"deviceVerification":false,"authorizedTiers":["PREMIUM"]}""",
                pricingModel = "SUBSCRIPTION",
                pricingAmount = 14.5,
                seriesId = "series_ww_dec",
                contentType = "EPISODE"
            ),
            ContentNodeEntity(
                contentId = "node_sov_doc",
                creatorId = "ch_doc_lounge",
                title = "Sovereign Web: The Genesis Protocol",
                description = "An in-depth historical documentary tracing the development of P2P file shares, local-first cryptography, and the migration from centralized corporate silos to sovereign browser networks.",
                contentHash = "QmZ3YAn9...GenesisProtocolSovereign",
                streamUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                metadata = """{"duration":"15 mins", "year":"2025", "quality":"1080p", "genre":"Documentary"}""",
                rightsPolicy = """{"geoRestricted":[],"minAgreements":1,"deviceVerification":false,"authorizedTiers":[]}""",
                pricingModel = "FREE",
                pricingAmount = 0.0,
                seriesId = "series_sov_genesis",
                contentType = "MOVIE"
            ),
            ContentNodeEntity(
                contentId = "node_live_championship",
                creatorId = "ch_aurelia_cinema",
                title = "Aurelia Live Art Championship 2026",
                description = "Sovereign visual synthesizers generate algorithmic artwork in real-time, competing for the crowd-sourced validation pool. Access requires a Live Pay-Per-View Smart Ticket.",
                contentHash = "QmVZ7b...AlgArtConsensusLive",
                streamUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                metadata = """{"duration":"Live Broadcast", "year":"2026", "quality":"Ultra HD", "genre":"Live, Digital Art"}""",
                rightsPolicy = """{"geoRestricted":[],"minAgreements":1,"deviceVerification":true,"authorizedTiers":["PPV"]}""",
                pricingModel = "PPV",
                pricingAmount = 5.0,
                isLive = true,
                seriesId = "live_art_champ",
                contentType = "PPV_EVENT"
            )
        )

        for (item in seedContent) {
            mediaDao.insertContent(item)
        }

        val seedNodes = listOf(
            P2PNodeEntity("node_berlin_01", "Berlin-IX-Anchor", "192.168.10.45", "EDGE_CACHE", true, 1945.2, 389.0),
            P2PNodeEntity("node_hk_relay", "HK-Consensus-Relay", "10.0.8.221", "SEED_NODE", true, 4122.0, 824.4),
            P2PNodeEntity("node_sf_edge", "SanFran-Sovereign-Link", "172.16.54.91", "EDGE_CACHE", true, 890.5, 178.1),
            P2PNodeEntity("node_london_v", "London-Validator-Swarm", "192.168.100.12", "BROWSER_PEER", true, 3125.1, 625.0)
        )

        for (node in seedNodes) {
            mediaDao.insertP2PNode(node)
        }
    }
}
