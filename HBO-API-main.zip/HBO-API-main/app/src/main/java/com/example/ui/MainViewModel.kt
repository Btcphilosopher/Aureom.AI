package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.security.KeyPairGenerator
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MediaRepository

    // User Sovereign Identity (HBO Vault Integration)
    val userAddress = "0x7F90" + UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
    var userPublicKeyBase64 = ""
    var userPrivateKeyBase64 = ""
    private val _userWalletBalance = MutableStateFlow(250.0) // Starting Aurelia tokens
    val userWalletBalance = _userWalletBalance.asStateFlow()

    // Database Streams
    val allContent: StateFlow<List<ContentNodeEntity>>
    val allChannels: StateFlow<List<ChannelEntity>>
    val allP2PNodes: StateFlow<List<P2PNodeEntity>>
    val userSubscriptions: StateFlow<List<SubscriptionEntity>>

    // Media Player State
    private val _currentPlayingNode = MutableStateFlow<ContentNodeEntity?>(null)
    val currentPlayingNode = _currentPlayingNode.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f) // 0.0 to 1.0
    val playbackProgress = _playbackProgress.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _bitrateMode = MutableStateFlow("1080p (HQ)")
    val bitrateMode = _bitrateMode.asStateFlow()

    private val _isDistributedStreaming = MutableStateFlow(true)
    val isDistributedStreaming = _isDistributedStreaming.asStateFlow()

    // Swarm metrics simulation
    private val _peerUploadSpeed = MutableStateFlow(0.0) // MB/s
    val peerUploadSpeed = _peerUploadSpeed.asStateFlow()

    private val _peerDownloadSpeed = MutableStateFlow(0.0) // MB/s
    val peerDownloadSpeed = _peerDownloadSpeed.asStateFlow()

    private val _p2pContributionRatio = MutableStateFlow(65.0) // %
    val p2pContributionRatio = _p2pContributionRatio.asStateFlow()

    private val _activePeersCount = MutableStateFlow(4)
    val activePeersCount = _activePeersCount.asStateFlow()

    // Creator Studio Draft Inputs
    val studioTitle = MutableStateFlow("Game of Sovereigns: Season I Episode 2")
    val studioDescription = MutableStateFlow("")
    val studioContentType = MutableStateFlow("EPISODE") // EPISODE, MOVIE, TRAILER, PPV_EVENT
    val studioPricingMode = MutableStateFlow("SUBSCRIPTION") // FREE, SUBSCRIPTION, PPV
    val studioPricingAmount = MutableStateFlow("15.00")
    val studioSeriesId = MutableStateFlow("series_gos")

    private val _isGeneratingAI = MutableStateFlow(false)
    val isGeneratingAI = _isGeneratingAI.asStateFlow()

    // Endpoints Log API Payload Console
    private val _apiConsolePayload = MutableStateFlow("")
    val apiConsolePayload = _apiConsolePayload.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        val dao = database.mediaDao()
        repository = MediaRepository(dao)

        allContent = repository.allContent
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allChannels = repository.allChannels
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allP2PNodes = repository.allP2PNodes
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        userSubscriptions = repository.getSubscriptionsFlow(userAddress)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        generateSovereignKeyPair()
        prepopulateAndSetup()
        startMetricsSimulator()
        updateApiConsoleLog()
    }

    private fun generateSovereignKeyPair() {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val kpg = KeyPairGenerator.getInstance("RSA")
                kpg.initialize(512) // Minimal size for fast UI representation
                val keyPair = kpg.generateKeyPair()
                userPublicKeyBase64 = android.util.Base64.encodeToString(keyPair.public.encoded, android.util.Base64.NO_WRAP).take(45) + "..."
                userPrivateKeyBase64 = android.util.Base64.encodeToString(keyPair.private.encoded, android.util.Base64.NO_WRAP).take(45) + "..."
            } catch (e: Exception) {
                userPublicKeyBase64 = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDeqX5Yt..."
                userPrivateKeyBase64 = "MIICWwIBAAKBgQDeqX5Ytd82vF28hC7Y7MhY34m..."
            }
        }
    }

    private fun prepopulateAndSetup() {
        viewModelScope.launch(Dispatchers.IO) {
            // Prepopulate seed data
            repository.prepopulateSeedData()
            // Set initial selected content node for the player if available
            delay(1000)
            val list = allContent.value
            if (list.isNotEmpty()) {
                _currentPlayingNode.value = list.first()
            }
        }
    }

    private fun startMetricsSimulator() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(2000)
                if (_isPlaying.value) {
                    // Update progress increment
                    val newProgress = _playbackProgress.value + 0.02f
                    if (newProgress >= 1.0f) {
                        _playbackProgress.value = 0f
                    } else {
                        _playbackProgress.value = newProgress
                    }

                    // Simulate download/upload swarm metrics
                    if (_isDistributedStreaming.value) {
                        _peerDownloadSpeed.value = (8.5 + (Math.random() * 4.2))
                        _peerUploadSpeed.value = (3.1 + (Math.random() * 1.8))
                        _p2pContributionRatio.value = (58.0 + (Math.random() * 19.0))
                        _activePeersCount.value = (3 + (Math.random() * 6).toInt())

                        // Log data usage to db for an online node randomly
                        val nodes = allP2PNodes.value
                        if (nodes.isNotEmpty()) {
                            val pickNode = nodes.random()
                            repository.recordP2PTransfer(pickNode.nodeId, 4.5, 0.9)
                        }
                    } else {
                        // Standard CDN Mode
                        _peerDownloadSpeed.value = (14.2 + (Math.random() * 2.0))
                        _peerUploadSpeed.value = 0.0
                        _p2pContributionRatio.value = 0.0
                        _activePeersCount.value = 0
                    }
                } else {
                    // Idle mode
                    _peerDownloadSpeed.value = 0.0
                    _peerUploadSpeed.value = 0.0
                }
            }
        }
    }

    fun selectContentToPlay(node: ContentNodeEntity) {
        _currentPlayingNode.value = node
        _playbackProgress.value = 0f
        _isPlaying.value = true
        updateApiConsoleLog()
    }

    fun togglePlayback() {
        _isPlaying.value = !_isPlaying.value
    }

    fun toggleP2P() {
        _isDistributedStreaming.value = !_isDistributedStreaming.value
    }

    fun changeBitrate(mode: String) {
        _bitrateMode.value = mode
    }

    // Subscription & Payments Handlers
    fun subscribeWithVault(channelId: String, cost: Double, onFinished: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            if (_userWalletBalance.value >= cost) {
                val success = repository.subscribeToChannel(channelId, userAddress, cost)
                if (success) {
                    _userWalletBalance.value -= cost
                    onFinished("Vault signature validated. Premium Channel unlocked!")
                } else {
                    onFinished("Subscription registration failed.")
                }
            } else {
                onFinished("Insufficient \$AURE tokens balance in HBO Vault.")
            }
        }
    }

    fun buyPPVTicket(content: ContentNodeEntity, onFinished: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val cost = content.pricingAmount
            if (_userWalletBalance.value >= cost) {
                _userWalletBalance.value -= cost
                // Unlock PPV (by registering local subscription)
                repository.subscribeToChannel(content.contentId, userAddress, cost)
                onFinished("PPV Access Granted! Cryptographic ticket signature recorded on-network.")
            } else {
                onFinished("Insufficient tokens inside Aurelia Vault.")
            }
        }
    }

    // AI Creator Studio draft trigger
    fun generateDescriptionWithGemini() {
        viewModelScope.launch {
            _isGeneratingAI.value = true
            val title = studioTitle.value
            val type = studioContentType.value
            val desc = GeminiClient.generateMediaDescription(title, type)
            studioDescription.value = desc
            _isGeneratingAI.value = false
            updateApiConsoleLog()
        }
    }

    // Publish Content Creator Form
    fun publishCustomContent(onFinished: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val title = studioTitle.value
            val desc = studioDescription.value
            if (title.isEmpty() || desc.isEmpty()) {
                onFinished("Please include a Title and a Description to upload.")
                return@launch
            }

            // Mock uploading
            val contentId = "node_" + title.take(5).lowercase().replace(" ", "_") + "_" + (100 + (Math.random() * 900).toInt())
            val contentHash = "QmZ" + UUID.randomUUID().toString().replace("-", "").take(32).uppercase()
            val price = studioPricingAmount.value.toDoubleOrNull() ?: 0.0

            val customNode = ContentNodeEntity(
                contentId = contentId,
                creatorId = "ch_hbo_orig", // Seed Creator Channel
                title = title,
                description = desc,
                contentHash = contentHash,
                streamUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", // default playable
                metadata = """{"duration":"10 mins", "year":"2026", "quality":"Super HD", "genre":"Sovereign Broadcast Art"}""",
                rightsPolicy = """{"geoRestricted":[],"minAgreements":3,"deviceVerification":true,"authorizedTiers":["PREMIUM"]}""",
                pricingModel = studioPricingMode.value,
                pricingAmount = price,
                seriesId = studioSeriesId.value,
                contentType = studioContentType.value
            )

            repository.insertContent(customNode)
            onFinished("Content published successfully! Signed content hash is: ${contentHash.take(15)}...")

            // Reset Form fields
            studioTitle.value = "New Premium Media " + (100 + (Math.random() * 899).toInt())
            studioDescription.value = ""
            updateApiConsoleLog()
        }
    }

    fun updateApiConsoleLog() {
        val activeNode = _currentPlayingNode.value
        val model = studioPricingMode.value
        val amount = studioPricingAmount.value

        _apiConsolePayload.value = """
// ==========================================
// HBO SOVEREIGN API INTERFACE DOCUMENTATION
// REST / Graph Engine Payload Emulator
// ==========================================

// 1. GET /content/${activeNode?.contentId ?: "node_gos_101"}
Request Headers:
  Authorization: Bearer Vault_Signature_${userAddress}
  X-Aurelia-Device-Cert: SHA256_F929ACD34
Response Body:
{
  "content_id": "${activeNode?.contentId ?: "node_gos_101"}",
  "title": "${activeNode?.title ?: "Game of Sovereigns"}",
  "content_hash": "${activeNode?.contentHash?.take(18) ?: "QmXoypizjW3..."}...",
  "pricing_model": "${activeNode?.pricingModel ?: "SUBSCRIPTION"}",
  "pricing_amount": ${activeNode?.pricingAmount ?: 15.0},
  "rights_policy": {
    "device_restricted": true,
    "min_node_consensus": 3,
    "authorized_tiers": ["PREMIUM"]
  },
  "distributed_cache_routing": {
    "active_swarm_nodes": ${activePeersCount.value},
    "swarm_efficiency": "${String.format("%.1f", p2pContributionRatio.value)}%",
    "edge_fallback_cdn": "Cloudflare-Enterprise-Sovereign-Edge"
  }
}

// 2. POST /content/upload
Request Body:
{
  "title": "${studioTitle.value}",
  "pricing_model": "$model",
  "pricing_amount": $amount,
  "creator_id": "ch_hbo_orig",
  "provenance_sig": "ECDSA_${userAddress}_SHA256"
}
        """.trimIndent()
    }
}
