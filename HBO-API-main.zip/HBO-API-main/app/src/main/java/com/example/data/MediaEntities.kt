package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "content_nodes")
data class ContentNodeEntity(
    @PrimaryKey val contentId: String,
    val creatorId: String,
    val title: String,
    val description: String,
    val contentHash: String,
    val streamUrl: String,
    val metadata: String, // Stringified JSON
    val rightsPolicy: String, // Stringified JSON
    val pricingModel: String, // FREE, SUBSCRIPTION, PPV
    val pricingAmount: Double,
    val isLive: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val seriesId: String = "",
    val contentType: String = "MOVIE" // MOVIE, EPISODE, TRAILER, PPV_EVENT
)

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val channelId: String,
    val name: String,
    val description: String,
    val subscriberCount: Int,
    val revenueBalance: Double,
    val creatorAddress: String
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val subscriptionId: String,
    val channelId: String,
    val subscriberAddress: String,
    val validThru: Long,
    val tier: String = "PREMIUM"
)

@Entity(tableName = "p2p_nodes")
data class P2PNodeEntity(
    @PrimaryKey val nodeId: String,
    val hostName: String,
    val ipAddress: String,
    val role: String, // EDGE_CACHE, SEED_NODE, BROWSER_PEER
    val online: Boolean,
    val bandwidthUsedMb: Double,
    val rewardEarnedTokens: Double
)
