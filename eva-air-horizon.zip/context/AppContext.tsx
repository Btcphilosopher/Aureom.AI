'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language, SearchQueryParams, Flight } from '@/types';
import { getTranslation, TranslationDictionary } from '@/i18n/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: TranslationDictionary;
  reducedMotion: boolean;
  setReducedMotion: (val: boolean) => void;
  atmosphere: 'morning' | 'day' | 'sunset' | 'night';
  setAtmosphere: (val: 'morning' | 'day' | 'sunset' | 'night') => void;
  searchQuery: SearchQueryParams;
  setSearchQuery: React.Dispatch<React.SetStateAction<SearchQueryParams>>;
  isSearching: boolean;
  setIsSearching: (val: boolean) => void;
  searchDone: boolean;
  setSearchDone: (val: boolean) => void;
  activeModal: string | null;
  setActiveModal: (modal: string | null) => void;
  selectedFlight: Flight | null;
  setSelectedFlight: (flight: Flight | null) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  triggerWowInteraction: boolean;
  setTriggerWowInteraction: (val: boolean) => void;
}

const defaultSearchQuery: SearchQueryParams = {
  tripType: 'roundTrip',
  from: 'TPE',
  to: 'NRT',
  departureDate: '2026-06-15',
  returnDate: '2026-06-22',
  passengers: {
    adults: 1,
    children: 0,
    infants: 0,
  },
  cabinClass: 'Economy',
  redeemMiles: false,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const savedLang = localStorage.getItem('eva_air_lang') as Language;
      if (savedLang && (savedLang === 'zhTW' || savedLang === 'en')) {
        return savedLang;
      }
    }
    return 'zhTW';
  });
  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });
  const [atmosphere, setAtmosphere] = useState<'morning' | 'day' | 'sunset' | 'night'>(() => {
    if (typeof window !== 'undefined') {
      const hour = new Date().getHours();
      if (hour >= 5 && hour < 10) return 'morning';
      if (hour >= 10 && hour < 17) return 'day';
      if (hour >= 17 && hour < 20) return 'sunset';
      return 'night';
    }
    return 'day';
  });
  const [searchQuery, setSearchQuery] = useState<SearchQueryParams>(defaultSearchQuery);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchDone, setSearchDone] = useState<boolean>(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [triggerWowInteraction, setTriggerWowInteraction] = useState<boolean>(false);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('eva_air_lang', lang);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  const t = getTranslation(language);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        reducedMotion,
        setReducedMotion,
        atmosphere,
        setAtmosphere,
        searchQuery,
        setSearchQuery,
        isSearching,
        setIsSearching,
        searchDone,
        setSearchDone,
        activeModal,
        setActiveModal,
        selectedFlight,
        setSelectedFlight,
        toastMessage,
        showToast,
        triggerWowInteraction,
        setTriggerWowInteraction,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
