import type { Metadata } from 'next';
import './globals.css';
import { AppProvider } from '@/context/AppContext';

export const metadata: Metadata = {
  title: 'EVA Air 長榮航空 | Hypermodern Bilingual Airline Website',
  description: 'Experience world-class Taiwanese hospitality and award-winning aviation excellence with EVA Air.',
  openGraph: {
    title: 'EVA Air 長榮航空 | Hypermodern Bilingual Airline Website',
    description: 'Experience world-class Taiwanese hospitality and award-winning aviation excellence with EVA Air.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'EVA Air 長榮航空 | Hypermodern Bilingual Airline Website',
    description: 'Experience world-class Taiwanese hospitality and award-winning aviation excellence with EVA Air.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-TW" className="scroll-smooth">
      <body suppressHydrationWarning className="bg-white text-gray-900 font-sans">
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
