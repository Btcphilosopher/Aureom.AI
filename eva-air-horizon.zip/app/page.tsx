'use client';

import React from 'react';
import { UtilityBar } from '@/components/navigation/UtilityBar';
import { FloatingNav } from '@/components/navigation/FloatingNav';
import { AircraftScene } from '@/components/aircraft/AircraftScene';
import { QuickActionSidebar } from '@/components/booking/QuickActionSidebar';
import { BookingWidget } from '@/components/booking/BookingWidget';
import { LoadingOverlay } from '@/components/flight/LoadingOverlay';
import { FlightResults } from '@/components/flight/FlightResults';
import { WorldRouteMap } from '@/components/aircraft/WorldRouteMap';
import { DestinationExplorer } from '@/components/destinations/DestinationExplorer';
import { OffersSection } from '@/components/offers/OffersSection';
import { ExperienceSection } from '@/components/experience/ExperienceSection';
import { LoyaltySection } from '@/components/loyalty/LoyaltySection';
import { FlightStatusWidget } from '@/components/status/FlightStatusWidget';
import { OnlineCheckInWidget } from '@/components/status/OnlineCheckInWidget';
import { BaggageWidget } from '@/components/status/BaggageWidget';
import { Footer } from '@/components/Footer';

import { Toast } from '@/components/ui/Toast';
import { LoginModal } from '@/components/ui/LoginModal';
import { CartModal } from '@/components/ui/CartModal';
import { SeatMapModal } from '@/components/ui/SeatMapModal';
import { BoardingPassModal } from '@/components/ui/BoardingPassModal';

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 font-sans antialiased selection:bg-[#006039] selection:text-white">
      {/* Top Utility Bar & Sticky Main Nav (Includes Mobile Drawer) */}
      <UtilityBar />
      <FloatingNav />

      {/* Hero Canvas Aircraft Animation & Quick Action Sidebar */}
      <div className="relative">
        <AircraftScene />
        <QuickActionSidebar />
      </div>

      {/* Primary Floating Booking Engine */}
      <BookingWidget />

      {/* Flight Search Loading State & Results */}
      <LoadingOverlay />
      <FlightResults />

      {/* Interactive Global Route Map */}
      <WorldRouteMap />

      {/* Editorial Destination Cards Explorer */}
      <DestinationExplorer />

      {/* Specials & Fares Offers Section */}
      <OffersSection />

      {/* EVA Experience & Cabin Engineering */}
      <ExperienceSection />

      {/* Infinity Mileagelands Loyalty Program */}
      <LoyaltySection />

      {/* Real-time Flight Tracker Status */}
      <FlightStatusWidget />

      {/* Digital Express Check-In Widget */}
      <OnlineCheckInWidget />

      {/* Baggage Guide & Allowance */}
      <BaggageWidget />

      {/* Comprehensive Footer */}
      <Footer />

      {/* Global Toast & Interactive Modals */}
      <Toast />
      <LoginModal />
      <CartModal />
      <SeatMapModal />
      <BoardingPassModal />
    </main>
  );
}
