'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { X, Plane, QrCode, Compass, CheckCircle2 } from 'lucide-react';

export function BoardingPassModal() {
  const { activeModal, setActiveModal, t } = useApp();

  if (activeModal !== 'boardingPass') return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="bg-white max-w-lg w-full rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
        <div className="p-5 bg-[#003B23] text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Compass className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-bold text-lg">{t.boardingPassPreview}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Boarding Pass Card */}
        <div className="p-6 space-y-6">
          <div className="border border-gray-200 rounded-3xl overflow-hidden shadow-lg bg-gradient-to-b from-gray-50 to-white">
            <div className="bg-[#003B23] text-white p-4 flex justify-between items-center text-xs font-bold">
              <span>EVA AIR BOARDING PASS</span>
              <span className="text-[#D4AF37]">FLIGHT BR198</span>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center text-center pb-4 border-b border-gray-200">
                <div>
                  <div className="text-3xl font-black text-gray-900">TPE</div>
                  <div className="text-xs text-gray-500 font-bold">TAIPEI</div>
                </div>

                <Plane className="w-6 h-6 text-[#006039] rotate-45" />

                <div>
                  <div className="text-3xl font-black text-gray-900">NRT</div>
                  <div className="text-xs text-gray-500 font-bold">TOKYO</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <div className="text-gray-400 font-bold">PASSENGER</div>
                  <div className="font-black text-gray-900">CHEN/WEITING</div>
                </div>
                <div>
                  <div className="text-gray-400 font-bold">GATE</div>
                  <div className="font-black text-[#006039] text-base">C7</div>
                </div>
                <div>
                  <div className="text-gray-400 font-bold">SEAT</div>
                  <div className="font-black text-[#006039] text-base">08K</div>
                </div>
              </div>

              {/* Barcode / QR Section */}
              <div className="pt-4 border-t border-dashed border-gray-300 flex flex-col items-center justify-center space-y-2">
                <div className="w-48 h-16 bg-slate-900 rounded-xl flex items-center justify-center text-white font-mono tracking-[8px] text-xs">
                  ||||||||||||||||||||||||||||||||
                </div>
                <span className="text-[10px] text-gray-400 font-mono">
                  BOARDING PASS # BR198-20260615-08K
                </span>
              </div>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={() => setActiveModal(null)}
              className="px-8 py-3 rounded-2xl bg-[#006039] text-white font-bold text-xs shadow-md"
            >
              Save to Apple Wallet / Google Pay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
