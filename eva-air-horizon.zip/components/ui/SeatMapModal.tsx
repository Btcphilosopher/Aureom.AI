'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Plane, Check, Grid } from 'lucide-react';

export function SeatMapModal() {
  const { activeModal, setActiveModal, selectedFlight, showToast } = useApp();
  const [selectedSeat, setSelectedSeat] = useState<string>('08K');

  if (activeModal !== 'seatMap') return null;

  const rows = ['01', '02', '03', '05', '06', '07', '08', '09', '10', '11'];
  const columns = ['A', 'D', 'G', 'K'];

  const handleConfirmSeat = () => {
    showToast(`Seat ${selectedSeat} reserved for ${selectedFlight?.flightNumber || 'BR198'}.`);
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="bg-white max-w-xl w-full rounded-3xl shadow-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-[#003B23] text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Grid className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-bold text-lg">
              Royal Laurel Suite Seat Map ({selectedFlight?.aircraftModel || 'Boeing 787-10'})
            </h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Seat Map Area */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div className="text-center text-xs font-bold text-gray-500 uppercase tracking-widest pb-2 border-b border-gray-200">
            AIRCRAFT COCKPIT FRONT ▲
          </div>

          {/* Seat Grid */}
          <div className="space-y-3 max-w-md mx-auto">
            {rows.map((row) => (
              <div key={row} className="flex items-center justify-between text-xs font-bold text-gray-700">
                <span className="w-6 font-mono text-gray-400">{row}</span>

                <div className="flex items-center space-x-3">
                  {columns.map((col) => {
                    const seatId = `${row}${col}`;
                    const isSelected = selectedSeat === seatId;
                    const isOccupied = seatId === '02A' || seatId === '05D' || seatId === '07G';

                    return (
                      <button
                        key={col}
                        disabled={isOccupied}
                        onClick={() => setSelectedSeat(seatId)}
                        className={`w-10 h-10 rounded-xl font-mono font-bold text-xs flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-[#006039] text-white ring-4 ring-[#006039]/30 scale-110 shadow-lg'
                            : isOccupied
                            ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                            : 'bg-gray-100 text-gray-800 hover:bg-[#006039]/20'
                        }`}
                      >
                        {seatId}
                      </button>
                    );
                  })}
                </div>

                <span className="w-6 font-mono text-gray-400">{row}</span>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-gray-200 flex items-center justify-between">
            <div className="text-xs text-gray-600 font-semibold">
              Selected Seat: <span className="font-black text-[#006039] text-sm">{selectedSeat}</span>
            </div>

            <button
              onClick={handleConfirmSeat}
              className="px-6 py-2.5 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-xs shadow-md"
            >
              Confirm Seat {selectedSeat}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
