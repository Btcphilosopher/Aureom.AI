'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { X, Plane, Clock, ShoppingBag, ArrowRight } from 'lucide-react';

export function CartModal() {
  const { activeModal, setActiveModal, selectedFlight, t, showToast } = useApp();

  if (activeModal !== 'cart') return null;

  const handleCheckout = () => {
    showToast('Proceeding to passenger details & payment...');
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="bg-white max-w-lg w-full rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
        <div className="p-5 bg-[#003B23] text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-bold text-lg">{t.cartToolTip}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {selectedFlight ? (
            <div className="p-5 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-black text-lg text-gray-900">
                  {selectedFlight.flightNumber}
                </span>
                <span className="text-xs px-2.5 py-1 rounded-full bg-[#006039] text-white font-bold">
                  {selectedFlight.aircraft}
                </span>
              </div>

              <div className="flex items-center justify-between text-sm font-bold text-gray-800 pt-2 border-t border-gray-200">
                <div>
                  <div className="text-xl font-black">{selectedFlight.departureTime}</div>
                  <div className="text-xs text-gray-500">{selectedFlight.origin.code}</div>
                </div>

                <div className="text-xs text-gray-400 font-mono">
                  {selectedFlight.duration} (Direct)
                </div>

                <div>
                  <div className="text-xl font-black">{selectedFlight.arrivalTime}</div>
                  <div className="text-xs text-gray-500">{selectedFlight.destination.code}</div>
                </div>
              </div>

              <div className="pt-3 border-t border-gray-200 flex items-center justify-between text-xs">
                <span className="text-gray-500 font-medium">Total Fare:</span>
                <span className="text-xl font-black text-[#006039]">
                  TWD {selectedFlight.fares.Economy.priceTwd.toLocaleString()}
                </span>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-gray-400">
              No flight selected yet. Use the search bar above to pick a flight.
            </div>
          )}

          {selectedFlight && (
            <button
              onClick={handleCheckout}
              className="w-full py-4 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-black text-sm shadow-xl flex items-center justify-center space-x-2 transition-all"
            >
              <span>Continue to Passenger & Seat Selection</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
