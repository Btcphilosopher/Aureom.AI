'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Lock, User, Compass, ArrowRight } from 'lucide-react';

export function LoginModal() {
  const { activeModal, setActiveModal, t, showToast } = useApp();
  const [memberId, setMemberId] = useState('');
  const [password, setPassword] = useState('');

  if (activeModal !== 'login') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('Login successful! Welcome to Infinity Mileagelands.');
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="bg-white max-w-md w-full rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
        <div className="p-6 bg-[#003B23] text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Compass className="w-6 h-6 text-[#D4AF37]" />
            <h3 className="font-bold text-lg">Infinity Mileagelands</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">
              Member ID / Email
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={memberId}
                onChange={(e) => setMemberId(e.target.value)}
                placeholder="e.g. 88291092"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:ring-2 focus:ring-[#006039] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:ring-2 focus:ring-[#006039] focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-sm shadow-md flex items-center justify-center space-x-2 transition-all"
          >
            <span>Sign In to Account</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="text-center text-xs text-gray-400 pt-2">
            Not a member? <span className="text-[#006039] font-bold cursor-pointer hover:underline">Register Now</span>
          </div>
        </form>
      </div>
    </div>
  );
}
