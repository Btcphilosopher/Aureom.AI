'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, Sparkles } from 'lucide-react';

export function Toast() {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 bg-[#003B23] text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-white/20 flex items-center space-x-3 text-xs font-bold animate-bounce">
      <CheckCircle2 className="w-5 h-5 text-[#D4AF37]" />
      <span>{toastMessage}</span>
    </div>
  );
}
