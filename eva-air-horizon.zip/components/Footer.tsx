'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Compass, Sparkles, Globe, Shield, Heart } from 'lucide-react';

export function Footer() {
  const { t } = useApp();

  const scrollTo = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="support-footer" className="bg-[#002416] text-white pt-16 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Top Brand Banner */}
        <div className="flex flex-wrap items-center justify-between gap-6 pb-12 border-b border-white/15">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#006039] flex items-center justify-center text-white shadow-lg">
              <Compass className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <div>
              <span className="text-2xl font-black tracking-tight text-white font-sans">
                EVA AIR
              </span>
              <span className="text-xs font-bold text-[#D4AF37] block -mt-1">
                長榮航空 • 探索世界 從心出發
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-black/40 px-4 py-2 rounded-2xl border border-white/15 text-xs text-gray-300 font-semibold tracking-wider uppercase">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
            <span>{t.starAllianceText}</span>
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 py-12 text-xs">
          {/* Section 1 */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-[#D4AF37] uppercase tracking-wider">
              {t.footerBook}
            </h4>
            <ul className="space-y-2 text-gray-300 font-medium">
              <li>
                <button onClick={() => scrollTo('booking-section')} className="hover:text-white">
                  {t.tabBookFlight}
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('check-in-section')} className="hover:text-white">
                  {t.quickCheckIn}
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('flight-status-section')} className="hover:text-white">
                  {t.quickFlightStatus}
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('baggage-section')} className="hover:text-white">
                  {t.quickBaggage}
                </button>
              </li>
            </ul>
          </div>

          {/* Section 2 */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-[#D4AF37] uppercase tracking-wider">
              {t.footerDestinations}
            </h4>
            <ul className="space-y-2 text-gray-300 font-medium">
              <li>
                <button onClick={() => scrollTo('destinations-section')} className="hover:text-white">
                  Taipei (TPE Hub)
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('destinations-section')} className="hover:text-white">
                  Asia Pacific
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('destinations-section')} className="hover:text-white">
                  Europe
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('destinations-section')} className="hover:text-white">
                  North America
                </button>
              </li>
            </ul>
          </div>

          {/* Section 3 */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-[#D4AF37] uppercase tracking-wider">
              {t.footerExperience}
            </h4>
            <ul className="space-y-2 text-gray-300 font-medium">
              <li>
                <button onClick={() => scrollTo('experience-section')} className="hover:text-white">
                  Royal Laurel Class
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('experience-section')} className="hover:text-white">
                  Premium Economy
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('experience-section')} className="hover:text-white">
                  Din Tai Fung Inflight Menu
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('experience-section')} className="hover:text-white">
                  EVA VIP Lounges
                </button>
              </li>
            </ul>
          </div>

          {/* Section 4 */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-[#D4AF37] uppercase tracking-wider">
              {t.footerLoyalty}
            </h4>
            <ul className="space-y-2 text-gray-300 font-medium">
              <li>
                <button onClick={() => scrollTo('infinity-mileagelands')} className="hover:text-white">
                  Infinity Mileagelands
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('infinity-mileagelands')} className="hover:text-white">
                  Tier Benefits
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('infinity-mileagelands')} className="hover:text-white">
                  Redeem Award Tickets
                </button>
              </li>
            </ul>
          </div>

          {/* Section 5 */}
          <div className="space-y-3 col-span-2 md:col-span-1">
            <h4 className="font-bold text-sm text-[#D4AF37] uppercase tracking-wider">
              {t.footerSupport}
            </h4>
            <ul className="space-y-2 text-gray-300 font-medium">
              <li>Customer Service Hotline: +886-2-25011999</li>
              <li>Special Assistance & Accessibility</li>
              <li>FAQ & Travel Notices</li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal & Copyright */}
        <div className="pt-8 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs text-gray-400">
          <div>{t.copyright}</div>
          <div className="flex flex-wrap items-center space-x-4">
            <a href="#" className="hover:text-white">{t.privacy}</a>
            <span>•</span>
            <a href="#" className="hover:text-white">{t.terms}</a>
            <span>•</span>
            <a href="#" className="hover:text-white">{t.cookie}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
