'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Sparkles, Award, Shield, ArrowRight, Gift, CheckCircle2 } from 'lucide-react';

export function LoyaltySection() {
  const { t, language, setActiveModal } = useApp();
  const [tier, setTier] = useState<'Green' | 'Silver' | 'Gold' | 'Diamond'>('Gold');

  const tierColors = {
    Green: 'from-emerald-600 to-green-800 text-emerald-200',
    Silver: 'from-slate-400 to-slate-600 text-slate-100',
    Gold: 'from-amber-400 to-amber-600 text-amber-100',
    Diamond: 'from-cyan-300 via-indigo-400 to-purple-600 text-white',
  };

  return (
    <div
      id="infinity-mileagelands"
      className="bg-gradient-to-b from-[#003B23] via-[#002B19] to-slate-950 text-white py-16 sm:py-24 my-12 border-y border-white/10 relative overflow-hidden"
    >
      {/* Background Gold Ambient Glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#D4AF37]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        {/* Header */}
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-bold mb-4">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>LOYALTY & REWARDS PROGRAM</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-black tracking-tight font-sans">
              INFINITY MILEAGELANDS
            </h2>
            <p className="text-xl sm:text-2xl font-light text-[#D4AF37] font-serif mt-1">
              {t.loyaltyTitle}
            </p>
            <p className="text-sm text-gray-300 mt-2 font-light max-w-xl">
              {t.loyaltySub}
            </p>
          </div>

          <button
            onClick={() => setActiveModal('login')}
            className="px-6 py-3.5 rounded-2xl bg-[#D4AF37] hover:bg-amber-400 text-slate-950 font-black text-sm shadow-xl flex items-center space-x-2 transition-all hover:scale-105"
          >
            <span>{t.joinLoyalty}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Loyalty Dashboard Card */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-6 lg:p-10 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Card & Status */}
          <div className="lg:col-span-5 space-y-6">
            <div
              className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-br ${tierColors[tier]} shadow-2xl border border-white/30 flex flex-col justify-between h-56 relative overflow-hidden`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-[10px] tracking-widest uppercase opacity-80">
                    EVA AIR
                  </div>
                  <div className="text-xl font-black tracking-wider">
                    INFINITY MILEAGELANDS
                  </div>
                </div>
                <Award className="w-8 h-8 text-white/90" />
              </div>

              <div>
                <div className="text-xs opacity-90 font-mono">
                  MEMBER ID: 8829-1092-4102
                </div>
                <div className="text-lg font-black tracking-wider mt-0.5">
                  CHEN / WEI-TING
                </div>
                <div className="inline-block mt-2 px-3 py-1 rounded-full bg-black/40 text-xs font-bold tracking-widest uppercase border border-white/30">
                  {tier} MEMBER
                </div>
              </div>
            </div>

            {/* Tier Switcher Pills */}
            <div className="flex items-center space-x-2 bg-black/30 p-1.5 rounded-2xl border border-white/10 text-xs font-bold">
              {(['Green', 'Silver', 'Gold', 'Diamond'] as const).map((tName) => (
                <button
                  key={tName}
                  onClick={() => setTier(tName)}
                  className={`flex-1 py-1.5 rounded-xl transition-all ${
                    tier === tName
                      ? 'bg-[#D4AF37] text-black font-black shadow-md'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  {tName}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Miles Counters & Progress Rings */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Miles Balance Box */}
            <div className="p-6 rounded-2xl bg-black/30 border border-white/10 space-y-2">
              <div className="text-xs text-gray-400 font-bold uppercase">
                {t.currentBalance}
              </div>
              <div className="text-3xl sm:text-4xl font-black text-[#D4AF37]">
                128,450 <span className="text-sm text-white font-normal">MILES</span>
              </div>
              <div className="text-xs text-emerald-400 font-medium flex items-center">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                12,000 miles earned from recent BR198 flight
              </div>
            </div>

            {/* Tier Upgrade Progress */}
            <div className="p-6 rounded-2xl bg-black/30 border border-white/10 space-y-2">
              <div className="text-xs text-gray-400 font-bold uppercase">
                {t.tierMilesProgress}
              </div>
              <div className="text-3xl sm:text-4xl font-black text-white">
                11,550 <span className="text-sm text-gray-400 font-normal">MILES NEEDED</span>
              </div>
              {/* Progress Bar */}
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mt-3">
                <div className="bg-gradient-to-r from-[#006039] to-[#D4AF37] h-full w-[78%]" />
              </div>
            </div>

            {/* Upcoming Redemption Rewards */}
            <div className="sm:col-span-2 p-6 rounded-2xl bg-black/30 border border-white/10 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-sm font-bold text-white">
                  Taipei (TPE) ↔ Tokyo (NRT) Round Trip Flight Award
                </div>
                <div className="text-xs text-gray-400 mt-0.5">
                  Requires 35,000 Miles (You have enough balance!)
                </div>
              </div>

              <button
                onClick={() => {
                  const bookingElem = document.getElementById('booking-section');
                  bookingElem?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-5 py-2.5 rounded-xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md"
              >
                <Gift className="w-4 h-4 text-[#D4AF37]" />
                <span>{t.redeemAward}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
