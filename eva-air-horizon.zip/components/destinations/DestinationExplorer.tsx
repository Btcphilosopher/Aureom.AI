'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { destinations } from '@/data/destinations';
import { Destination } from '@/types';
import { Compass, Clock, ChevronRight, Plane, Sparkles } from 'lucide-react';

export function DestinationExplorer() {
  const { t, language, setSearchQuery, setIsSearching, setSearchDone } = useApp();
  const [activeFilter, setActiveFilter] = useState<'all' | 'asia' | 'europe' | 'northAmerica' | 'oceania'>('all');

  const filtered = destinations.filter((d) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'asia') return ['NRT', 'ICN', 'SIN', 'BKK'].includes(d.code);
    if (activeFilter === 'europe') return ['LHR', 'CDG'].includes(d.code);
    if (activeFilter === 'northAmerica') return ['JFK', 'SFO', 'LAX'].includes(d.code);
    return true;
  });

  const handleBookDestination = (dest: Destination) => {
    setSearchQuery((prev) => ({
      ...prev,
      from: 'TPE',
      to: dest.code,
    }));
    setIsSearching(true);
    setSearchDone(false);

    const elem = document.getElementById('search-results-section');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }

    setTimeout(() => {
      setIsSearching(false);
      setSearchDone(true);
    }, 2000);
  };

  return (
    <div id="destinations-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-16 my-8">
      {/* Section Title */}
      <div className="flex flex-wrap items-end justify-between gap-6 mb-10">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#006039] uppercase tracking-wider mb-2">
            <Compass className="w-4 h-4 text-[#006039]" />
            <span>GLOBAL GATEWAYS & CITIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 tracking-tight font-sans">
            {t.destinationsTitle}
          </h2>
          <p className="text-sm sm:text-base text-gray-500 mt-1 font-serif">
            {t.destinationsSub}
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 bg-gray-100 p-1.5 rounded-2xl border border-gray-200">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeFilter === 'all'
                ? 'bg-[#006039] text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {t.filterAll}
          </button>
          <button
            onClick={() => setActiveFilter('asia')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeFilter === 'asia'
                ? 'bg-[#006039] text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {t.filterAsia}
          </button>
          <button
            onClick={() => setActiveFilter('europe')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeFilter === 'europe'
                ? 'bg-[#006039] text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {t.filterEurope}
          </button>
          <button
            onClick={() => setActiveFilter('northAmerica')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeFilter === 'northAmerica'
                ? 'bg-[#006039] text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {t.filterNorthAmerica}
          </button>
        </div>
      </div>

      {/* Destination Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filtered.map((dest) => (
          <div
            key={dest.id}
            onClick={() => handleBookDestination(dest)}
            className="group relative h-[420px] rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer border border-gray-100 flex flex-col justify-between p-6 transform hover:-translate-y-2"
          >
            {/* Full Bleed Background Photography */}
            <div
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
              style={{ backgroundImage: `url(${dest.image})` }}
            />

            {/* Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

            {/* Top Tag & Code Badge */}
            <div className="relative z-10 flex items-center justify-between">
              <span className="px-3 py-1 rounded-full bg-[#006039] text-white text-[10px] font-bold tracking-wider uppercase shadow-md">
                {language === 'zhTW' ? dest.tagZh : dest.tagEn}
              </span>
              <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-[#D4AF37] font-mono text-xs font-black border border-white/20">
                {dest.code}
              </span>
            </div>

            {/* Bottom Content Area */}
            <div className="relative z-10 text-white space-y-2">
              <div className="flex items-baseline justify-between">
                <div>
                  <h3 className="text-2xl font-black tracking-tight leading-tight">
                    {language === 'zhTW' ? dest.nameZh : dest.nameEn}
                  </h3>
                  <div className="text-xs text-gray-300 font-serif">
                    {language === 'zhTW' ? dest.nameEn : dest.nameZh}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-gray-300">{t.startingFrom}</div>
                  <div className="text-xl font-black text-[#D4AF37]">
                    TWD {dest.priceTwd.toLocaleString()}
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-200 line-clamp-2 pt-1 border-t border-white/20 font-light">
                {language === 'zhTW' ? dest.descriptionZh : dest.descriptionEn}
              </p>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] font-semibold text-gray-300 flex items-center">
                  <Clock className="w-3.5 h-3.5 mr-1 text-[#00A859]" />
                  {dest.flightTime}
                </span>

                <button className="px-4 py-2 rounded-xl bg-white text-gray-900 font-bold text-xs flex items-center space-x-1.5 shadow-md group-hover:bg-[#006039] group-hover:text-white transition-colors">
                  <span>{t.discoverBtn}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
