'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { getFlightStatus } from '@/data/flightStatus';
import { FlightStatus } from '@/types';
import { Plane, Search, Clock, MapPin, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

export function FlightStatusWidget() {
  const { t, language } = useApp();
  const [flightInput, setFlightInput] = useState('BR198');
  const [statusResult, setStatusResult] = useState<FlightStatus>(getFlightStatus('BR198'));

  const handleCheckStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!flightInput.trim()) return;
    setStatusResult(getFlightStatus(flightInput));
  };

  const statusBadges = {
    ON_TIME: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    DELAYED: 'bg-amber-100 text-amber-800 border-amber-300',
    BOARDING: 'bg-blue-100 text-blue-800 border-blue-300',
    DEPARTED: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    ARRIVED: 'bg-gray-100 text-gray-800 border-gray-300',
    CANCELLED: 'bg-red-100 text-red-800 border-red-300',
  };

  return (
    <div id="flight-status-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-16 my-8">
      <div className="bg-white rounded-3xl border border-gray-200 shadow-xl p-6 sm:p-10">
        {/* Title */}
        <div className="max-w-2xl mb-8">
          <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#006039] uppercase tracking-wider mb-2">
            <Plane className="w-4 h-4 text-[#006039]" />
            <span>REAL-TIME FLIGHT TRACKER</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 tracking-tight">
            {t.statusTitle}
          </h2>
          <p className="text-sm text-gray-500 mt-1 font-serif">
            {t.statusSub}
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={handleCheckStatus} className="flex flex-wrap items-center gap-3 mb-8">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-5 h-5 text-gray-400 absolute left-4 top-3.5" />
            <input
              type="text"
              value={flightInput}
              onChange={(e) => setFlightInput(e.target.value)}
              placeholder={t.flightNumberInput}
              className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 text-sm font-bold uppercase focus:outline-none focus:ring-2 focus:ring-[#006039]"
            />
          </div>

          <button
            type="submit"
            className="px-8 py-3.5 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-sm shadow-md transition-all flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>{t.checkStatusCTA}</span>
          </button>
        </form>

        {/* Status Result Display */}
        {statusResult && (
          <div className="p-6 rounded-2xl bg-gray-50 border border-gray-200 space-y-6">
            {/* Top Bar: Flight Number & Status Badge */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <span className="text-2xl font-black text-gray-900">
                  {statusResult.flightNumber}
                </span>
                <span className="text-xs text-gray-500 font-medium">
                  {statusResult.date} | {statusResult.aircraft}
                </span>
              </div>

              <span
                className={`px-4 py-1.5 rounded-full text-xs font-black border uppercase shadow-sm ${
                  statusBadges[statusResult.status]
                }`}
              >
                {t[statusResult.status.toLowerCase() as keyof typeof t] || statusResult.status}
              </span>
            </div>

            {/* Route & Times Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center text-center">
              <div>
                <div className="text-3xl font-black text-gray-900">
                  {statusResult.origin.code}
                </div>
                <div className="text-sm font-bold text-gray-700 mt-1">
                  {language === 'zhTW' ? statusResult.origin.cityZh : statusResult.origin.cityEn}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {t.scheduledDep}: {statusResult.scheduledDep}
                </div>
              </div>

              {/* Live Flight Progress Tracker */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-[#006039]">
                  <span>{t.terminalLabel} {statusResult.terminal}</span>
                  <span>{t.gateLabel} {statusResult.gate}</span>
                </div>
                <div className="relative w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#006039] h-full transition-all duration-1000"
                    style={{ width: `${statusResult.progressPercent}%` }}
                  />
                </div>
                <div className="text-[11px] font-mono text-gray-400">
                  Flight in progress ({statusResult.progressPercent}%)
                </div>
              </div>

              <div>
                <div className="text-3xl font-black text-gray-900">
                  {statusResult.destination.code}
                </div>
                <div className="text-sm font-bold text-gray-700 mt-1">
                  {language === 'zhTW' ? statusResult.destination.cityZh : statusResult.destination.cityEn}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {t.scheduledArr}: {statusResult.scheduledArr}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
