'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, QrCode, FileText, ArrowRight } from 'lucide-react';

export function OnlineCheckInWidget() {
  const { t, showToast, setActiveModal } = useApp();
  const [bookingRef, setBookingRef] = useState('EVA888');
  const [surname, setSurname] = useState('CHEN');

  const handleStartCheckIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingRef || bookingRef.length < 4) {
      showToast(t.errorInvalidRef);
      return;
    }
    setActiveModal('boardingPass');
  };

  return (
    <div id="check-in-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-12 my-8">
      <div className="bg-[#003B23] text-white rounded-3xl p-8 sm:p-12 shadow-2xl border border-white/10 relative overflow-hidden">
        <div className="max-w-2xl relative z-10">
          <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#D4AF37] uppercase tracking-wider mb-2">
            <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
            <span>EXPRESS DIGITAL CHECK-IN</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black tracking-tight">
            {t.checkInTitle}
          </h2>
          <p className="text-sm text-gray-300 mt-1 font-serif">
            {t.checkInSub}
          </p>

          {/* Form */}
          <form onSubmit={handleStartCheckIn} className="mt-8 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase mb-1">
                  {t.bookingReference}
                </label>
                <input
                  type="text"
                  value={bookingRef}
                  onChange={(e) => setBookingRef(e.target.value.toUpperCase())}
                  placeholder="e.g. EVA123"
                  className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white font-mono text-sm uppercase placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase mb-1">
                  {t.passengerSurname}
                </label>
                <input
                  type="text"
                  value={surname}
                  onChange={(e) => setSurname(e.target.value.toUpperCase())}
                  placeholder="e.g. CHEN"
                  className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white font-mono text-sm uppercase placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-[#D4AF37] hover:bg-amber-400 text-black font-black text-sm shadow-xl flex items-center justify-center space-x-2 transition-all hover:scale-105"
            >
              <QrCode className="w-4 h-4" />
              <span>{t.startCheckInCTA}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
