'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Luggage, CheckCircle2, Info, ChevronRight, Scale } from 'lucide-react';

export function BaggageWidget() {
  const { t, language } = useApp();
  const [selectedCabin, setSelectedCabin] = useState<'Economy' | 'PremiumEconomy' | 'RoyalLaurel'>('Economy');

  const baggageInfo = {
    Economy: {
      cabin: '7 kg (15 lbs) x 1 piece',
      checked: '23 kg (50 lbs) x 1 piece',
      dims: '56 x 36 x 23 cm (22 x 14 x 9 in)',
    },
    PremiumEconomy: {
      cabin: '7 kg (15 lbs) x 1 piece + 1 personal item',
      checked: '23 kg (50 lbs) x 2 pieces',
      dims: '56 x 36 x 23 cm (22 x 14 x 9 in)',
    },
    RoyalLaurel: {
      cabin: '7 kg (15 lbs) x 2 pieces + 1 personal item',
      checked: '32 kg (70 lbs) x 2 pieces',
      dims: '56 x 36 x 23 cm (22 x 14 x 9 in)',
    },
  };

  return (
    <div id="baggage-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-16 my-8">
      <div className="bg-white rounded-3xl border border-gray-200 shadow-xl p-6 sm:p-10">
        {/* Title */}
        <div className="max-w-2xl mb-8">
          <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#006039] uppercase tracking-wider mb-2">
            <Luggage className="w-4 h-4 text-[#006039]" />
            <span>BAGGAGE ALLOWANCE & GUIDE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 tracking-tight">
            {t.baggageTitle}
          </h2>
          <p className="text-sm text-gray-500 mt-1 font-serif">
            {t.baggageSub}
          </p>
        </div>

        {/* Cabin Class Selector Tabs */}
        <div className="flex items-center space-x-2 bg-gray-100 p-1.5 rounded-2xl mb-8 max-w-md">
          <button
            onClick={() => setSelectedCabin('Economy')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCabin === 'Economy'
                ? 'bg-[#006039] text-white shadow-md'
                : 'text-gray-700 hover:text-gray-900'
            }`}
          >
            {t.cabinEconomy}
          </button>
          <button
            onClick={() => setSelectedCabin('PremiumEconomy')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCabin === 'PremiumEconomy'
                ? 'bg-[#006039] text-white shadow-md'
                : 'text-gray-700 hover:text-gray-900'
            }`}
          >
            {t.cabinPremiumEconomy}
          </button>
          <button
            onClick={() => setSelectedCabin('RoyalLaurel')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCabin === 'RoyalLaurel'
                ? 'bg-[#006039] text-white shadow-md'
                : 'text-gray-700 hover:text-gray-900'
            }`}
          >
            {t.cabinRoyalLaurel}
          </button>
        </div>

        {/* Baggage Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
            <div className="flex items-center space-x-3 text-[#006039]">
              <Luggage className="w-6 h-6" />
              <h3 className="font-bold text-base text-gray-900">{t.cabinBaggage}</h3>
            </div>
            <div className="text-xl font-black text-gray-900">
              {baggageInfo[selectedCabin].cabin}
            </div>
            <div className="text-xs text-gray-500">
              Max Dimension: {baggageInfo[selectedCabin].dims}
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
            <div className="flex items-center space-x-3 text-[#006039]">
              <Scale className="w-6 h-6" />
              <h3 className="font-bold text-base text-gray-900">{t.checkedBaggage}</h3>
            </div>
            <div className="text-xl font-black text-gray-900">
              {baggageInfo[selectedCabin].checked}
            </div>
            <div className="text-xs text-gray-500">
              Infinity Mileagelands Silver/Gold/Diamond members receive extra allowance.
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
            <div className="flex items-center space-x-3 text-[#006039]">
              <Info className="w-6 h-6" />
              <h3 className="font-bold text-base text-gray-900">{t.sportsEquipment}</h3>
            </div>
            <div className="text-sm font-bold text-gray-900">
              Golf, Scuba, Surfboard & Musical Instruments Accepted
            </div>
            <div className="text-xs text-gray-500">
              Pre-registration recommended at least 24 hours prior to departure.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
