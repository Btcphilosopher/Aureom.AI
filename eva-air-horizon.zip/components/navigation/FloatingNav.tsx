'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { useScrollPosition } from '@/hooks/useScrollPosition';
import { Search, ShoppingBag, Menu, X, Compass, ChevronRight } from 'lucide-react';
import { MobileDrawer } from './MobileDrawer';

export function FloatingNav() {
  const { t, setActiveModal, selectedFlight } = useApp();
  const { isScrolled } = useScrollPosition();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchBarOpen, setSearchBarOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <nav
        className={`sticky top-0 left-0 right-0 z-40 transition-all duration-500 px-4 sm:px-8 ${
          isScrolled
            ? 'py-2 bg-white/95 backdrop-blur-md shadow-lg shadow-black/5 rounded-b-2xl border-b border-gray-100'
            : 'py-4 bg-white/90 backdrop-blur-sm shadow-md rounded-b-3xl border-b border-gray-200/50'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* EVA AIR Logo with Iconic Compass Mark & Star Alliance */}
          <div
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="flex items-center space-x-2">
              <div className="w-9 h-9 rounded-lg bg-[#006039] flex items-center justify-center text-white shadow-sm group-hover:bg-[#00482B] transition-colors">
                <Compass className="w-6 h-6 text-[#D4AF37] group-hover:rotate-45 transition-transform duration-500" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-[#006039] font-sans">
                  EVA AIR
                </span>
                <span className="text-[10px] font-bold tracking-widest text-[#00482B] -mt-1">
                  長榮航空
                </span>
              </div>
            </div>

            {/* Star Alliance Tag */}
            <div className="hidden lg:flex items-center border-l border-gray-200 pl-3 ml-2 text-[10px] text-gray-500 font-medium tracking-wider uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] mr-1.5 animate-pulse" />
              Star Alliance
            </div>
          </div>

          {/* Center Navigation Items */}
          <div className="hidden xl:flex items-center space-x-1 lg:space-x-2">
            <button
              onClick={() => scrollToSection('booking-section')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-gray-800 hover:text-[#006039] hover:bg-gray-100/80 transition-all flex items-center space-x-1 group"
            >
              <span>{t.navBook}</span>
            </button>

            <button
              onClick={() => scrollToSection('offers-section')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-gray-800 hover:text-[#006039] hover:bg-gray-100/80 transition-all"
            >
              <span>{t.navOffers}</span>
            </button>

            <button
              onClick={() => scrollToSection('check-in-section')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-gray-800 hover:text-[#006039] hover:bg-gray-100/80 transition-all"
            >
              <span>{t.navManage}</span>
            </button>

            <button
              onClick={() => scrollToSection('experience-section')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-gray-800 hover:text-[#006039] hover:bg-gray-100/80 transition-all"
            >
              <span>{t.navExperience}</span>
            </button>

            <button
              onClick={() => scrollToSection('infinity-mileagelands')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-[#006039] font-bold hover:bg-[#006039]/10 transition-all"
            >
              <span>{t.navLoyalty}</span>
            </button>

            <button
              onClick={() => scrollToSection('support-footer')}
              className="px-3.5 py-2 rounded-xl text-sm font-semibold text-gray-800 hover:text-[#006039] hover:bg-gray-100/80 transition-all"
            >
              <span>{t.navSupport}</span>
            </button>
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Search Toggle Button */}
            <button
              onClick={() => setSearchBarOpen(!searchBarOpen)}
              className="p-2.5 rounded-xl hover:bg-gray-100 text-gray-700 hover:text-[#006039] transition-colors relative"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Cart / Selected Flight Drawer Trigger */}
            <button
              onClick={() => setActiveModal('cart')}
              className="p-2.5 rounded-xl hover:bg-gray-100 text-gray-700 hover:text-[#006039] transition-colors relative"
              aria-label="Selected flights"
              title={t.cartToolTip}
            >
              <ShoppingBag className="w-5 h-5" />
              {selectedFlight && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#006039] ring-2 ring-white" />
              )}
            </button>

            {/* Book Now Quick CTA */}
            <button
              onClick={() => scrollToSection('booking-section')}
              className="hidden sm:flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-[#006039] hover:bg-[#00482B] text-white text-xs font-bold tracking-wide shadow-md shadow-[#006039]/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>{t.searchFlightsCTA}</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="xl:hidden p-2.5 rounded-xl hover:bg-gray-100 text-gray-800 transition-colors"
              aria-label="Open Mobile Menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Expandable Quick Search Bar */}
        {searchBarOpen && (
          <div className="max-w-4xl mx-auto mt-3 pt-3 border-t border-gray-100 flex items-center bg-gray-50 rounded-xl p-2 px-4 shadow-inner">
            <Search className="w-5 h-5 text-gray-400 mr-3" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              className="w-full bg-transparent text-sm focus:outline-none text-gray-800 placeholder-gray-400"
              autoFocus
            />
            <button
              onClick={() => setSearchBarOpen(false)}
              className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </nav>

      {/* Mobile Drawer Menu */}
      <MobileDrawer isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
    </>
  );
}
