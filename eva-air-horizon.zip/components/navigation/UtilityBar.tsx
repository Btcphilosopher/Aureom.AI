'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Globe, User, Sun, Moon, Sparkles, Activity } from 'lucide-react';

export function UtilityBar() {
  const {
    language,
    setLanguage,
    t,
    atmosphere,
    setAtmosphere,
    reducedMotion,
    setReducedMotion,
    setActiveModal,
  } = useApp();

  return (
    <div className="bg-[#003B23] text-white/90 text-xs font-medium py-1.5 px-4 sm:px-8 border-b border-white/10 z-50 relative">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        {/* Left Utility: Language & Location Selector */}
        <div className="flex items-center space-x-3 sm:space-x-5">
          <div className="flex items-center space-x-1.5 text-white/80 hover:text-white transition-colors cursor-pointer">
            <Globe className="w-3.5 h-3.5 text-[#00A859]" />
            <span>{t.location}</span>
          </div>

          <span className="text-white/20">|</span>

          {/* Language Buttons with smooth active indicator */}
          <div className="flex items-center bg-black/20 rounded-full p-0.5 border border-white/10">
            <button
              onClick={() => setLanguage('zhTW')}
              className={`px-2.5 py-0.5 rounded-full transition-all duration-300 ${
                language === 'zhTW'
                  ? 'bg-[#006039] text-white font-semibold shadow-sm'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              繁體中文
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-0.5 rounded-full transition-all duration-300 ${
                language === 'en'
                  ? 'bg-[#006039] text-white font-semibold shadow-sm'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Right Utility: Atmosphere, Motion Toggle & Member Portal */}
        <div className="flex items-center space-x-3 sm:space-x-5 text-xs">
          {/* Atmosphere Switcher */}
          <div className="hidden md:flex items-center space-x-1 bg-black/20 rounded-full px-2 py-0.5 border border-white/10">
            <span className="text-white/60 text-[10px] mr-1">{t.atmosphereTime}:</span>
            <button
              onClick={() => setAtmosphere('morning')}
              className={`px-1.5 py-0.5 rounded text-[10px] ${
                atmosphere === 'morning' ? 'bg-[#D4AF37] text-black font-bold' : 'text-white/70 hover:text-white'
              }`}
              title={t.timeMorning}
            >
              <Sun className="w-3 h-3 inline mr-0.5" />
              {t.timeMorning}
            </button>
            <button
              onClick={() => setAtmosphere('day')}
              className={`px-1.5 py-0.5 rounded text-[10px] ${
                atmosphere === 'day' ? 'bg-[#00A859] text-white font-bold' : 'text-white/70 hover:text-white'
              }`}
              title={t.timeDay}
            >
              {t.timeDay}
            </button>
            <button
              onClick={() => setAtmosphere('sunset')}
              className={`px-1.5 py-0.5 rounded text-[10px] ${
                atmosphere === 'sunset' ? 'bg-amber-600 text-white font-bold' : 'text-white/70 hover:text-white'
              }`}
              title={t.timeSunset}
            >
              {t.timeSunset}
            </button>
            <button
              onClick={() => setAtmosphere('night')}
              className={`px-1.5 py-0.5 rounded text-[10px] ${
                atmosphere === 'night' ? 'bg-indigo-900 text-white font-bold' : 'text-white/70 hover:text-white'
              }`}
              title={t.timeNight}
            >
              <Moon className="w-3 h-3 inline mr-0.5" />
              {t.timeNight}
            </button>
          </div>

          {/* Reduced Motion Toggle */}
          <button
            onClick={() => setReducedMotion(!reducedMotion)}
            className="hidden lg:flex items-center space-x-1 px-2 py-0.5 rounded bg-black/20 text-[10px] text-white/80 hover:text-white border border-white/10"
            title="Toggle high performance / reduced motion"
          >
            <Activity className="w-3 h-3 text-[#00A859]" />
            <span>{reducedMotion ? t.reducedMotionOn : t.reducedMotionOff}</span>
          </button>

          <span className="text-white/20 hidden sm:inline">|</span>

          {/* Member Login / Register */}
          <button
            onClick={() => setActiveModal('login')}
            className="flex items-center space-x-1.5 text-white/90 hover:text-[#D4AF37] transition-colors"
          >
            <User className="w-3.5 h-3.5" />
            <span>{t.memberLogin}</span>
          </button>

          <span className="text-white/20">|</span>

          {/* Infinity Mileagelands Badge */}
          <div
            onClick={() => {
              const elem = document.getElementById('infinity-mileagelands');
              elem?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex items-center space-x-1.5 text-[#D4AF37] hover:text-amber-300 transition-colors font-semibold cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{t.infinityMember}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
