'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { X, Globe, User, Compass, ChevronRight, PhoneCall, Sparkles } from 'lucide-react';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileDrawer({ isOpen, onClose }: MobileDrawerProps) {
  const { language, setLanguage, t, setActiveModal } = useApp();

  if (!isOpen) return null;

  const handleNavClick = (sectionId: string) => {
    onClose();
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 xl:hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Panel */}
      <div className="fixed inset-y-0 right-0 w-full max-w-sm bg-white shadow-2xl flex flex-col justify-between overflow-y-auto transform transition-transform duration-300">
        <div>
          {/* Header */}
          <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-[#003B23] text-white">
            <div className="flex items-center space-x-2">
              <Compass className="w-6 h-6 text-[#D4AF37]" />
              <span className="font-bold text-lg tracking-wider">EVA AIR 長榮航空</span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Language Switcher Row */}
          <div className="p-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 flex items-center">
              <Globe className="w-4 h-4 text-[#006039] mr-1.5" />
              Language / 語言
            </span>
            <div className="flex items-center bg-gray-200/80 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setLanguage('zhTW')}
                className={`px-3 py-1 rounded-md font-semibold transition-all ${
                  language === 'zhTW' ? 'bg-[#006039] text-white shadow-sm' : 'text-gray-700'
                }`}
              >
                繁體中文
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-md font-semibold transition-all ${
                  language === 'en' ? 'bg-[#006039] text-white shadow-sm' : 'text-gray-700'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Menu Items */}
          <div className="p-4 space-y-1">
            <button
              onClick={() => handleNavClick('booking-section')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.navBook}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button
              onClick={() => handleNavClick('offers-section')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.navOffers}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button
              onClick={() => handleNavClick('check-in-section')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.navManage}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button
              onClick={() => handleNavClick('experience-section')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.navExperience}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button
              onClick={() => handleNavClick('infinity-mileagelands')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl bg-[#006039]/10 text-[#006039] font-bold"
            >
              <span className="flex items-center">
                <Sparkles className="w-4 h-4 text-[#D4AF37] mr-2" />
                {t.navLoyalty}
              </span>
              <ChevronRight className="w-4 h-4 text-[#006039]" />
            </button>

            <button
              onClick={() => handleNavClick('flight-status-section')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.quickFlightStatus}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button
              onClick={() => handleNavClick('support-footer')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl hover:bg-gray-100 text-left font-semibold text-gray-800"
            >
              <span>{t.navSupport}</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-gray-100 bg-gray-50 space-y-3">
          <button
            onClick={() => {
              onClose();
              setActiveModal('login');
            }}
            className="w-full py-3 rounded-xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-sm flex items-center justify-center space-x-2 shadow-md"
          >
            <User className="w-4 h-4" />
            <span>{t.memberLogin}</span>
          </button>

          <div className="text-center text-[11px] text-gray-500 pt-2 flex items-center justify-center space-x-1">
            <PhoneCall className="w-3 h-3 text-[#006039]" />
            <span>EVA Air Customer Service 24/7 Hotline</span>
          </div>
        </div>
      </div>
    </div>
  );
}
