'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { offers } from '@/data/offers';
import { Sparkles, ArrowRight, Tag, Gift } from 'lucide-react';

export function OffersSection() {
  const { t, language, setSearchQuery, setIsSearching, setSearchDone } = useApp();

  const handleSelectOffer = (offer: typeof offers[0]) => {
    setSearchQuery((prev) => ({
      ...prev,
      from: 'TPE',
      to: offer.id === 'offer-1' ? 'NRT' : offer.id === 'offer-2' ? 'LAX' : 'NRT',
    }));
    setIsSearching(true);
    setSearchDone(false);

    const elem = document.getElementById('search-results-section');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }

    setTimeout(() => {
      setIsSearching(false);
      setSearchDone(true);
    }, 2000);
  };

  return (
    <div id="offers-section" className="bg-slate-50 py-16 sm:py-20 my-12 border-y border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#006039] uppercase tracking-wider mb-2">
              <Gift className="w-4 h-4 text-[#006039]" />
              <span>EDITORIAL SPECIALS & FARES</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-gray-900 tracking-tight font-sans">
              {t.offersTitle}
            </h2>
            <p className="text-sm sm:text-base text-gray-500 mt-1 font-serif">
              {t.offersSub}
            </p>
          </div>

          <button
            onClick={() => {
              const elem = document.getElementById('destinations-section');
              elem?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-5 py-2.5 rounded-2xl bg-white hover:bg-gray-100 border border-gray-200 text-gray-800 font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all shadow-sm"
          >
            <span>{t.viewAllOffers}</span>
            <ArrowRight className="w-4 h-4 text-[#006039]" />
          </button>
        </div>

        {/* Magazine Editorial Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {offers.map((offer) => (
            <div
              key={offer.id}
              onClick={() => handleSelectOffer(offer)}
              className="group bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 border border-gray-200 flex flex-col justify-between cursor-pointer transform hover:-translate-y-1.5"
            >
              {/* Card Image Banner */}
              <div className="relative h-52 overflow-hidden">
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                  style={{ backgroundImage: `url(${offer.image})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#006039] text-white text-[10px] font-bold tracking-wider uppercase shadow-md">
                  {language === 'zhTW' ? offer.tagZh : offer.tagEn}
                </span>

                {offer.priceTwd > 0 && (
                  <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-2xl shadow-lg border border-gray-100 text-right">
                    <div className="text-[10px] text-gray-500 font-bold uppercase">{t.fromTwd}</div>
                    <div className="text-base font-black text-[#006039]">
                      TWD {offer.priceTwd.toLocaleString()}
                    </div>
                  </div>
                )}
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="text-xs font-bold text-[#006039] mb-1">
                    {language === 'zhTW' ? offer.routeZh : offer.routeEn}
                  </div>
                  <h3 className="text-lg font-black text-gray-900 group-hover:text-[#006039] transition-colors leading-snug">
                    {language === 'zhTW' ? offer.titleZh : offer.titleEn}
                  </h3>
                  <p className="text-xs text-gray-500 mt-2 font-serif leading-relaxed line-clamp-2">
                    {language === 'zhTW' ? offer.subtitleZh : offer.subtitleEn}
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-[#006039]">
                  <span className="flex items-center text-gray-400 font-mono text-[10px]">
                    EXP: {offer.expiryDate}
                  </span>
                  <span className="flex items-center space-x-1 group-hover:translate-x-1 transition-transform">
                    <span>{t.bookOfferCTA}</span>
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
