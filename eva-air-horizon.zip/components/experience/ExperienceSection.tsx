'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { cabinExperiences } from '@/data/cabins';
import { CabinExperience } from '@/types';
import { Compass, CheckCircle2, ChevronRight, Sparkles, X, Utensils, Shield, Award } from 'lucide-react';

export function ExperienceSection() {
  const { t, language } = useApp();
  const [selectedCabin, setSelectedCabin] = useState<CabinExperience | null>(null);

  return (
    <div id="experience-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-16 my-8">
      {/* Title */}
      <div className="max-w-3xl mb-12">
        <div className="inline-flex items-center space-x-2 text-xs font-bold text-[#006039] uppercase tracking-wider mb-2">
          <Award className="w-4 h-4 text-[#D4AF37]" />
          <span>TAIWANESE HOSPITALITY & CABIN ENGINEERING</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 tracking-tight font-sans">
          {t.experienceTitle}
        </h2>
        <p className="text-sm sm:text-base text-gray-500 mt-2 font-serif">
          {t.experienceSub}
        </p>
      </div>

      {/* Horizontal Scrolling Cards */}
      <div className="flex space-x-6 overflow-x-auto pb-8 pt-2 no-scrollbar scroll-smooth">
        {cabinExperiences.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedCabin(item)}
            className="group flex-none w-80 sm:w-96 bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 border border-gray-200 cursor-pointer flex flex-col justify-between transform hover:-translate-y-2"
          >
            {/* Image Banner */}
            <div className="relative h-60 overflow-hidden">
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url(${item.image})` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

              <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#006039] text-white text-[10px] font-bold tracking-wider uppercase shadow-md">
                {language === 'zhTW' ? item.badgeZh : item.badgeEn}
              </span>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="text-xl font-black text-gray-900 group-hover:text-[#006039] transition-colors">
                  {language === 'zhTW' ? item.titleZh : item.titleEn}
                </h3>
                <div className="text-xs font-bold text-[#006039] mt-0.5">
                  {language === 'zhTW' ? item.subtitleZh : item.subtitleEn}
                </div>
                <p className="text-xs text-gray-500 mt-2 font-serif leading-relaxed line-clamp-3">
                  {language === 'zhTW' ? item.descriptionZh : item.descriptionEn}
                </p>
              </div>

              {/* Bullet Features Preview */}
              <div className="space-y-1.5 pt-3 border-t border-gray-100">
                {(language === 'zhTW' ? item.featuresZh : item.featuresEn).slice(0, 3).map((feat, idx) => (
                  <div key={idx} className="flex items-center text-xs font-medium text-gray-700">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-2 text-[#006039] flex-shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              <button className="w-full py-3 rounded-2xl bg-gray-100 group-hover:bg-[#006039] text-gray-800 group-hover:text-white font-bold text-xs flex items-center justify-center space-x-2 transition-colors shadow-sm">
                <span>{t.viewCabinDetails}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Cabin Details Modal */}
      {selectedCabin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="bg-white max-w-2xl w-full rounded-3xl shadow-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[90vh]">
            <div className="relative h-64 bg-cover bg-center" style={{ backgroundImage: `url(${selectedCabin.image})` }}>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <button
                onClick={() => setSelectedCabin(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-black transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-6 left-6 text-white">
                <span className="px-3 py-1 rounded-full bg-[#006039] text-white text-[10px] font-bold uppercase">
                  {language === 'zhTW' ? selectedCabin.badgeZh : selectedCabin.badgeEn}
                </span>
                <h3 className="text-3xl font-black mt-2">
                  {language === 'zhTW' ? selectedCabin.titleZh : selectedCabin.titleEn}
                </h3>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-6">
              <div>
                <h4 className="text-sm font-bold text-[#006039] uppercase">Overview</h4>
                <p className="text-sm text-gray-600 mt-1 leading-relaxed">
                  {language === 'zhTW' ? selectedCabin.descriptionZh : selectedCabin.descriptionEn}
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-[#006039] uppercase mb-3">Key Highlights & Inflight Amenities</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(language === 'zhTW' ? selectedCabin.featuresZh : selectedCabin.featuresEn).map((feat, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-gray-50 border border-gray-200 flex items-center space-x-2 text-xs font-semibold text-gray-800">
                      <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 text-center">
                <button
                  onClick={() => setSelectedCabin(null)}
                  className="px-8 py-3 rounded-2xl bg-[#006039] text-white font-bold text-sm shadow-md"
                >
                  Close Explorer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
