'use client';

import React, { useState } from 'react';
import { airports } from '@/data/airports';
import { Airport } from '@/types';
import { Search, MapPin, X, Plane } from 'lucide-react';
import { useApp } from '@/context/AppContext';

interface AirportPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (airport: Airport) => void;
  title: string;
}

export function AirportPickerModal({ isOpen, onClose, onSelect, title }: AirportPickerModalProps) {
  const { language } = useApp();
  const [filterQuery, setFilterQuery] = useState('');

  if (!isOpen) return null;

  const filtered = airports.filter(
    (a) =>
      a.code.toLowerCase().includes(filterQuery.toLowerCase()) ||
      a.nameZh.includes(filterQuery) ||
      a.nameEn.toLowerCase().includes(filterQuery.toLowerCase()) ||
      a.cityZh.includes(filterQuery) ||
      a.cityEn.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-[#003B23] text-white">
          <div className="flex items-center space-x-2">
            <Plane className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-bold text-lg">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Input */}
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Search city, airport or code (e.g. TPE, Tokyo, 台北)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#006039]"
              autoFocus
            />
          </div>
        </div>

        {/* List */}
        <div className="p-3 overflow-y-auto space-y-1 divide-y divide-gray-50">
          {filtered.map((a) => (
            <button
              key={a.code}
              onClick={() => {
                onSelect(a);
                onClose();
              }}
              className="w-full p-3 rounded-xl hover:bg-gray-100 flex items-center justify-between transition-colors text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-[#006039]/10 text-[#006039] flex items-center justify-center font-bold text-sm group-hover:bg-[#006039] group-hover:text-white transition-colors">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-gray-900 text-sm">
                    {language === 'zhTW' ? `${a.cityZh} (${a.nameZh})` : `${a.cityEn} (${a.nameEn})`}
                  </div>
                  <div className="text-xs text-gray-500">
                    {language === 'zhTW' ? a.countryZh : a.countryEn}
                  </div>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-gray-100 text-gray-700 group-hover:bg-[#006039] group-hover:text-white transition-colors">
                {a.code}
              </span>
            </button>
          ))}

          {filtered.length === 0 && (
            <div className="p-8 text-center text-sm text-gray-400">
              No matching airport found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
