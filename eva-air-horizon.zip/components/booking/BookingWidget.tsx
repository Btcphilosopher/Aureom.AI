'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { getAirportByCode } from '@/data/airports';
import { Airport, CabinClass } from '@/types';
import {
  Plane,
  Gift,
  FileText,
  Clock,
  ArrowRightLeft,
  MapPin,
  Calendar,
  Users,
  Search,
  ChevronRight,
  Sparkles,
  Tag,
} from 'lucide-react';
import { AirportPickerModal } from './AirportPickerModal';

export function BookingWidget() {
  const {
    t,
    searchQuery,
    setSearchQuery,
    setIsSearching,
    setSearchDone,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'book' | 'redeem' | 'manage' | 'schedule'>('book');
  const [pickingType, setPickingType] = useState<'from' | 'to' | null>(null);
  const [showPassengerPicker, setShowPassengerPicker] = useState(false);

  const fromAirport = getAirportByCode(searchQuery.from);
  const toAirport = getAirportByCode(searchQuery.to);

  // Swap origin and destination
  const handleSwapAirports = () => {
    setSearchQuery((prev) => ({
      ...prev,
      from: prev.to,
      to: prev.from,
    }));
  };

  // Perform search
  const handleSearch = () => {
    if (searchQuery.from === searchQuery.to) {
      showToast(t.errorSameAirport);
      return;
    }

    setIsSearching(true);
    setSearchDone(false);

    // Scroll down to results section or loading position
    const elem = document.getElementById('search-results-section');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }

    // Simulate search query delay
    setTimeout(() => {
      setIsSearching(false);
      setSearchDone(true);
    }, 2200);
  };

  const cabinClassNames: Record<CabinClass, string> = {
    Economy: t.cabinEconomy,
    PremiumEconomy: t.cabinPremiumEconomy,
    Business: t.cabinBusiness,
    RoyalLaurel: t.cabinRoyalLaurel,
  };

  return (
    <div
      id="booking-section"
      className="max-w-7xl mx-auto px-4 sm:px-8 relative z-30 -mt-16 sm:-mt-24 lg:-mt-28 mb-16"
    >
      <div className="bg-white rounded-3xl shadow-2xl shadow-black/10 border border-gray-100 p-4 sm:p-6 lg:p-8 backdrop-blur-xl">
        {/* Top Tabs Bar */}
        <div className="flex items-center space-x-1 border-b border-gray-100 pb-4 mb-6 overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              setActiveTab('book');
              setSearchQuery((prev) => ({ ...prev, redeemMiles: false }));
            }}
            className={`px-4 py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all whitespace-nowrap ${
              activeTab === 'book'
                ? 'bg-[#006039] text-white shadow-md shadow-[#006039]/20'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Plane className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.tabBookFlight}</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('redeem');
              setSearchQuery((prev) => ({ ...prev, redeemMiles: true }));
            }}
            className={`px-4 py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all whitespace-nowrap ${
              activeTab === 'redeem'
                ? 'bg-[#006039] text-white shadow-md shadow-[#006039]/20'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Gift className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.tabRedeemMiles}</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('manage');
              const checkIn = document.getElementById('check-in-section');
              checkIn?.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-4 py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all whitespace-nowrap ${
              activeTab === 'manage'
                ? 'bg-[#006039] text-white shadow-md shadow-[#006039]/20'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{t.tabManageBooking}</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('schedule');
              const status = document.getElementById('flight-status-section');
              status?.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-4 py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all whitespace-nowrap ${
              activeTab === 'schedule'
                ? 'bg-[#006039] text-white shadow-md shadow-[#006039]/20'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{t.tabFlightSchedule}</span>
          </button>
        </div>

        {/* Trip Type Selector Pills */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center space-x-2 bg-gray-100 p-1 rounded-2xl">
            <button
              onClick={() => setSearchQuery((prev) => ({ ...prev, tripType: 'roundTrip' }))}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                searchQuery.tripType === 'roundTrip'
                  ? 'bg-white text-[#006039] shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {t.tripRoundTrip}
            </button>
            <button
              onClick={() => setSearchQuery((prev) => ({ ...prev, tripType: 'oneWay' }))}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                searchQuery.tripType === 'oneWay'
                  ? 'bg-white text-[#006039] shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {t.tripOneWay}
            </button>
            <button
              onClick={() => setSearchQuery((prev) => ({ ...prev, tripType: 'multiCity' }))}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                searchQuery.tripType === 'multiCity'
                  ? 'bg-white text-[#006039] shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {t.tripMultiCity}
            </button>
          </div>

          {searchQuery.redeemMiles && (
            <div className="flex items-center space-x-1.5 text-xs text-[#006039] font-bold bg-[#006039]/10 px-3 py-1.5 rounded-xl">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>Infinity Mileagelands Redemption Mode Active</span>
            </div>
          )}
        </div>

        {/* Form Fields Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3 items-center">
          {/* FROM Field */}
          <div className="lg:col-span-3 relative">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
              {t.fieldFrom}
            </label>
            <button
              onClick={() => setPickingType('from')}
              className="w-full p-3.5 rounded-2xl bg-gray-50 hover:bg-gray-100/80 border border-gray-200 flex items-center justify-between text-left transition-all group"
            >
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-[#006039]" />
                <div>
                  <div className="text-base font-black text-gray-900 leading-tight">
                    {fromAirport.code} {fromAirport.cityZh}
                  </div>
                  <div className="text-xs text-gray-500 font-medium">
                    {fromAirport.nameZh}
                  </div>
                </div>
              </div>
            </button>
          </div>

          {/* Swap Origin / Destination Button */}
          <div className="lg:col-span-1 flex items-center justify-center -my-2 lg:my-0">
            <button
              onClick={handleSwapAirports}
              className="p-3 rounded-full bg-white hover:bg-gray-100 border border-gray-200 shadow-md text-[#006039] transition-transform hover:scale-110 active:scale-95"
              title={t.swapAirports}
              aria-label="Swap Airports"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
          </div>

          {/* TO Field */}
          <div className="lg:col-span-3 relative">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
              {t.fieldTo}
            </label>
            <button
              onClick={() => setPickingType('to')}
              className="w-full p-3.5 rounded-2xl bg-gray-50 hover:bg-gray-100/80 border border-gray-200 flex items-center justify-between text-left transition-all group"
            >
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-[#006039]" />
                <div>
                  <div className="text-base font-black text-gray-900 leading-tight">
                    {toAirport.code} {toAirport.cityZh}
                  </div>
                  <div className="text-xs text-gray-500 font-medium">
                    {toAirport.nameZh}
                  </div>
                </div>
              </div>
            </button>
          </div>

          {/* DEPARTURE & RETURN Dates */}
          <div className="lg:col-span-2 relative">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
              {t.fieldDeparture}
            </label>
            <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-[#006039]" />
              <input
                type="date"
                value={searchQuery.departureDate}
                onChange={(e) =>
                  setSearchQuery((prev) => ({ ...prev, departureDate: e.target.value }))
                }
                className="w-full bg-transparent text-sm font-bold text-gray-900 focus:outline-none"
              />
            </div>
          </div>

          {/* PASSENGERS & CLASS Field */}
          <div className="lg:col-span-3 relative">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
              {t.fieldPassengersClass}
            </label>
            <button
              onClick={() => setShowPassengerPicker(!showPassengerPicker)}
              className="w-full p-3.5 rounded-2xl bg-gray-50 hover:bg-gray-100/80 border border-gray-200 flex items-center justify-between text-left transition-all"
            >
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4 text-[#006039]" />
                <div>
                  <div className="text-sm font-bold text-gray-900 leading-tight">
                    {searchQuery.passengers.adults + searchQuery.passengers.children} {t.passengerCount}
                  </div>
                  <div className="text-xs text-gray-500 font-medium">
                    {searchQuery.cabinClass}
                  </div>
                </div>
              </div>
            </button>

            {/* Passenger Selector Dropdown */}
            {showPassengerPicker && (
              <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 z-50 space-y-4">
                <div className="font-bold text-sm text-gray-900 border-b border-gray-100 pb-2">
                  {t.fieldPassengersClass}
                </div>

                {/* Adults */}
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span>{t.adults}</span>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() =>
                        setSearchQuery((prev) => ({
                          ...prev,
                          passengers: {
                            ...prev.passengers,
                            adults: Math.max(1, prev.passengers.adults - 1),
                          },
                        }))
                      }
                      className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 font-bold"
                    >
                      -
                    </button>
                    <span>{searchQuery.passengers.adults}</span>
                    <button
                      onClick={() =>
                        setSearchQuery((prev) => ({
                          ...prev,
                          passengers: {
                            ...prev.passengers,
                            adults: prev.passengers.adults + 1,
                          },
                        }))
                      }
                      className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Cabin Class Options */}
                <div className="space-y-1.5 pt-2 border-t border-gray-100">
                  <div className="text-[11px] font-bold text-gray-400 uppercase">Cabin Class</div>
                  {(['Economy', 'PremiumEconomy', 'Business', 'RoyalLaurel'] as CabinClass[]).map(
                    (cls) => (
                      <button
                        key={cls}
                        onClick={() => {
                          setSearchQuery((prev) => ({ ...prev, cabinClass: cls }));
                          setShowPassengerPicker(false);
                        }}
                        className={`w-full text-left p-2 rounded-xl text-xs font-semibold transition-colors ${
                          searchQuery.cabinClass === cls
                            ? 'bg-[#006039] text-white font-bold'
                            : 'hover:bg-gray-100 text-gray-800'
                        }`}
                      >
                        {cls}
                      </button>
                    )
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Submit Search Button */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-2 text-xs text-gray-500 font-medium">
            <Tag className="w-4 h-4 text-[#006039]" />
            <input
              type="text"
              placeholder={t.fieldPromoCode}
              value={searchQuery.promoCode || ''}
              onChange={(e) =>
                setSearchQuery((prev) => ({ ...prev, promoCode: e.target.value }))
              }
              className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#006039]"
            />
          </div>

          <button
            onClick={handleSearch}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-black text-base shadow-xl shadow-[#006039]/30 flex items-center justify-center space-x-3 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>{t.searchFlightsCTA}</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Airport Picker Modal */}
      <AirportPickerModal
        isOpen={pickingType !== null}
        onClose={() => setPickingType(null)}
        title={pickingType === 'from' ? t.fieldFrom : t.fieldTo}
        onSelect={(airport) => {
          if (pickingType === 'from') {
            setSearchQuery((prev) => ({ ...prev, from: airport.code }));
          } else {
            setSearchQuery((prev) => ({ ...prev, to: airport.code }));
          }
        }}
      />
    </div>
  );
}
