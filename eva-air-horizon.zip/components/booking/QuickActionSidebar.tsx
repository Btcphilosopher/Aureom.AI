'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, Plane, Luggage } from 'lucide-react';

export function QuickActionSidebar() {
  const { t } = useApp();

  const scrollTo = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="hidden lg:flex flex-col space-y-2 absolute right-6 top-24 z-30">
      {/* Online Check-in */}
      <button
        onClick={() => scrollTo('check-in-section')}
        className="group w-48 p-3.5 rounded-2xl bg-[#003B23]/90 hover:bg-[#006039] text-white backdrop-blur-md border border-white/20 shadow-xl transition-all duration-300 hover:translate-x-[-6px] flex items-center space-x-3 text-left"
      >
        <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
          <CheckCircle2 className="w-5 h-5 text-white group-hover:text-black" />
        </div>
        <div>
          <div className="text-xs font-bold leading-tight">{t.quickCheckIn}</div>
          <div className="text-[10px] text-white/70 font-mono tracking-wider">
            {t.quickCheckInSub}
          </div>
        </div>
      </button>

      {/* Flight Status */}
      <button
        onClick={() => scrollTo('flight-status-section')}
        className="group w-48 p-3.5 rounded-2xl bg-[#003B23]/90 hover:bg-[#006039] text-white backdrop-blur-md border border-white/20 shadow-xl transition-all duration-300 hover:translate-x-[-6px] flex items-center space-x-3 text-left"
      >
        <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
          <Plane className="w-5 h-5 text-white group-hover:text-black" />
        </div>
        <div>
          <div className="text-xs font-bold leading-tight">{t.quickFlightStatus}</div>
          <div className="text-[10px] text-white/70 font-mono tracking-wider">
            {t.quickFlightStatusSub}
          </div>
        </div>
      </button>

      {/* Baggage Info */}
      <button
        onClick={() => scrollTo('baggage-section')}
        className="group w-48 p-3.5 rounded-2xl bg-[#003B23]/90 hover:bg-[#006039] text-white backdrop-blur-md border border-white/20 shadow-xl transition-all duration-300 hover:translate-x-[-6px] flex items-center space-x-3 text-left"
      >
        <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center group-hover:bg-[#D4AF37] group-hover:text-black transition-colors">
          <Luggage className="w-5 h-5 text-white group-hover:text-black" />
        </div>
        <div>
          <div className="text-xs font-bold leading-tight">{t.quickBaggage}</div>
          <div className="text-[10px] text-white/70 font-mono tracking-wider">
            {t.quickBaggageSub}
          </div>
        </div>
      </button>
    </div>
  );
}
