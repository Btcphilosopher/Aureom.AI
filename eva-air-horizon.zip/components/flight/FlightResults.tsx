'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { searchFlightsMock } from '@/data/flights';
import { Flight, CabinClass } from '@/types';
import {
  Plane,
  Clock,
  ChevronDown,
  ChevronUp,
  Check,
  Luggage,
  Sparkles,
  Info,
  Grid,
} from 'lucide-react';

export function FlightResults() {
  const {
    t,
    searchQuery,
    isSearching,
    searchDone,
    setSelectedFlight,
    setActiveModal,
    showToast,
  } = useApp();

  const [expandedFlightId, setExpandedFlightId] = useState<string | null>(null);
  const [selectedCabinMap, setSelectedCabinMap] = useState<Record<string, CabinClass>>({});

  if (isSearching) return null;
  if (!searchDone) return null;

  const flights = searchFlightsMock(searchQuery.from, searchQuery.to);

  const handleSelectCabin = (flight: Flight, cabin: CabinClass) => {
    setSelectedCabinMap((prev) => ({ ...prev, [flight.id]: cabin }));
  };

  const handleConfirmFlight = (flight: Flight) => {
    const cabin = selectedCabinMap[flight.id] || searchQuery.cabinClass;
    setSelectedFlight(flight);
    showToast(`Flight ${flight.flightNumber} (${cabin}) added to your itinerary.`);
    setActiveModal('cart');
  };

  return (
    <div id="search-results-section" className="max-w-7xl mx-auto px-4 sm:px-8 mb-20">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-gray-200">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight flex items-center space-x-3">
            <span>{t.resultsFound}</span>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#006039] text-white">
              {flights.length} FLIGHTS
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            {searchQuery.from} → {searchQuery.to} | {searchQuery.departureDate}
          </p>
        </div>
      </div>

      {/* Flight Cards List */}
      <div className="space-y-4">
        {flights.map((flight) => {
          const isExpanded = expandedFlightId === flight.id;
          const activeCabin = selectedCabinMap[flight.id] || searchQuery.cabinClass;
          const fare = flight.fares[activeCabin];

          return (
            <div
              key={flight.id}
              className="bg-white rounded-3xl border border-gray-200 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              {/* Main Card Summary Row */}
              <div className="p-5 sm:p-7 flex flex-wrap items-center justify-between gap-6">
                {/* Flight Carrier & Aircraft */}
                <div className="flex items-center space-x-4 min-w-[200px]">
                  <div className="w-12 h-12 rounded-2xl bg-[#006039]/10 text-[#006039] flex items-center justify-center font-black text-lg">
                    <Plane className="w-6 h-6 rotate-45" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-lg text-gray-900">
                        {flight.flightNumber}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded-md bg-[#006039]/10 text-[#006039] font-bold">
                        EVA AIR
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 font-medium mt-0.5">
                      {flight.aircraft}
                    </div>
                  </div>
                </div>

                {/* Departure & Arrival Times */}
                <div className="flex items-center space-x-6 sm:space-x-10 text-center">
                  <div>
                    <div className="text-xl sm:text-2xl font-black text-gray-900">
                      {flight.departureTime}
                    </div>
                    <div className="text-xs font-bold text-gray-500">
                      {flight.origin.code} {flight.origin.cityZh}
                    </div>
                  </div>

                  {/* Flight Duration Visual Line */}
                  <div className="flex flex-col items-center w-28 sm:w-36">
                    <span className="text-[11px] font-bold text-gray-400 mb-1 flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {flight.duration}
                    </span>
                    <div className="w-full relative flex items-center">
                      <div className="w-2 h-2 rounded-full bg-[#006039]" />
                      <div className="flex-1 h-0.5 bg-[#006039]" />
                      <Plane className="w-4 h-4 text-[#006039] mx-1" />
                      <div className="flex-1 h-0.5 bg-[#006039]" />
                      <div className="w-2 h-2 rounded-full bg-[#006039]" />
                    </div>
                    <span className="text-[10px] font-bold text-[#006039] mt-1">
                      {t.nonStop}
                    </span>
                  </div>

                  <div>
                    <div className="text-xl sm:text-2xl font-black text-gray-900">
                      {flight.arrivalTime}
                    </div>
                    <div className="text-xs font-bold text-gray-500">
                      {flight.destination.code} {flight.destination.cityZh}
                    </div>
                  </div>
                </div>

                {/* Price & CTA */}
                <div className="flex items-center space-x-4 ml-auto">
                  <div className="text-right">
                    <div className="text-2xl sm:text-3xl font-black text-[#006039]">
                      TWD {fare.priceTwd.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-400 font-medium">
                      {activeCabin} / per passenger
                    </div>
                  </div>

                  <div className="flex flex-col space-y-2">
                    <button
                      onClick={() => handleConfirmFlight(flight)}
                      className="px-6 py-3 rounded-2xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-xs sm:text-sm shadow-md transition-all hover:scale-105 active:scale-95"
                    >
                      {t.selectFlight}
                    </button>

                    <button
                      onClick={() =>
                        setExpandedFlightId(isExpanded ? null : flight.id)
                      }
                      className="text-xs font-bold text-[#006039] hover:underline flex items-center justify-center space-x-1"
                    >
                      <span>{t.compareFares}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Expandable Fare Comparison & Seat Map Bar */}
              {isExpanded && (
                <div className="border-t border-gray-100 bg-gray-50 p-6 space-y-6">
                  {/* Cabin Fare Options Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {(
                      [
                        'Economy',
                        'PremiumEconomy',
                        'Business',
                        'RoyalLaurel',
                      ] as CabinClass[]
                    ).map((cabinKey) => {
                      const cabFare = flight.fares[cabinKey];
                      const isSelected = activeCabin === cabinKey;

                      return (
                        <div
                          key={cabinKey}
                          onClick={() => handleSelectCabin(flight, cabinKey)}
                          className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-white border-[#006039] shadow-lg ring-2 ring-[#006039]/20'
                              : 'bg-white/60 border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-black text-sm text-gray-900">
                              {cabinKey}
                            </span>
                            {isSelected && (
                              <span className="w-5 h-5 rounded-full bg-[#006039] text-white flex items-center justify-center text-xs">
                                <Check className="w-3 h-3" />
                              </span>
                            )}
                          </div>

                          <div className="text-xl font-black text-[#006039] mb-3">
                            TWD {cabFare.priceTwd.toLocaleString()}
                          </div>

                          <div className="space-y-1.5 text-xs text-gray-600 mb-4">
                            <div className="flex items-center text-gray-700 font-medium">
                              <Luggage className="w-3.5 h-3.5 mr-1.5 text-[#006039]" />
                              {cabFare.baggageAllowance}
                            </div>
                            {cabFare.featuresZh.slice(0, 2).map((feat, idx) => (
                              <div key={idx} className="flex items-center">
                                <Check className="w-3 h-3 mr-1 text-[#006039]" />
                                {feat}
                              </div>
                            ))}
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSelectCabin(flight, cabinKey);
                            }}
                            className={`w-full py-2 rounded-xl font-bold text-xs transition-colors ${
                              isSelected
                                ? 'bg-[#006039] text-white'
                                : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                            }`}
                          >
                            {isSelected ? 'Selected' : 'Choose'}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Seat Map Preview CTA Button */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200 text-xs">
                    <span className="text-gray-500 font-medium flex items-center">
                      <Info className="w-4 h-4 text-[#006039] mr-1.5" />
                      Aircraft Boeing 787-10 Dreamliner featuring 180° lie-flat Royal Laurel Suites.
                    </span>

                    <button
                      onClick={() => {
                        setSelectedFlight(flight);
                        setActiveModal('seatMap');
                      }}
                      className="px-4 py-2 rounded-xl bg-white border border-gray-300 hover:bg-gray-100 font-bold text-gray-800 flex items-center space-x-1.5 shadow-sm"
                    >
                      <Grid className="w-4 h-4 text-[#006039]" />
                      <span>{t.seatMap}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
