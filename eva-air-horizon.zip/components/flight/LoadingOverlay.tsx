'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Plane, Compass } from 'lucide-react';

export function LoadingOverlay() {
  const { t, searchQuery } = useApp();

  return (
    <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-8 sm:p-12 border border-gray-100 shadow-2xl text-center max-w-2xl mx-auto my-12">
      <div className="flex justify-center mb-6">
        <div className="w-16 h-16 rounded-3xl bg-[#006039] text-white flex items-center justify-center shadow-xl shadow-[#006039]/30 animate-pulse">
          <Compass className="w-8 h-8 text-[#D4AF37] animate-spin" style={{ animationDuration: '6s' }} />
        </div>
      </div>

      <h3 className="text-xl sm:text-2xl font-black text-gray-900 mb-2">
        {t.searchingTitle}
      </h3>
      <p className="text-sm text-gray-500 mb-8 max-w-md mx-auto">
        {t.searchingSub}
      </p>

      {/* Route Flight Path Animation */}
      <div className="relative max-w-md mx-auto my-8">
        <div className="flex items-center justify-between text-base font-black text-[#006039] mb-3">
          <span>{searchQuery.from}</span>
          <span className="text-xs text-gray-400 font-mono">BR198 BOEING 787-10</span>
          <span>{searchQuery.to}</span>
        </div>

        {/* Animated Dashed Line with Flying Aircraft */}
        <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
          <div className="absolute inset-y-0 left-0 bg-[#006039] w-full origin-left animate-pulse" />
        </div>

        {/* Traveling Plane Icon */}
        <div className="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 animate-bounce">
          <Plane className="w-6 h-6 text-[#006039] rotate-90" />
        </div>
      </div>

      <div className="text-xs font-mono font-bold text-[#006039] tracking-wider uppercase">
        EVA AIRWAY NETWORK CONNECTING...
      </div>
    </div>
  );
}
