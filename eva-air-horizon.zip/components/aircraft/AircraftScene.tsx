'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '@/context/AppContext';
import { useParallax } from '@/hooks/useParallax';
import { Compass, Sparkles, Plane, MapPin, Globe } from 'lucide-react';

export function AircraftScene() {
  const {
    t,
    atmosphere,
    reducedMotion,
    triggerWowInteraction,
    setTriggerWowInteraction,
  } = useApp();
  const parallax = useParallax();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [sequenceStep, setSequenceStep] = useState(0);

  // Staggered cinematic sequence on load
  useEffect(() => {
    const t0 = setTimeout(() => setSequenceStep(1), 100);  // Bg
    const t1 = setTimeout(() => setSequenceStep(2), 400);  // Mountains
    const t2 = setTimeout(() => setSequenceStep(3), 800);  // Clouds
    const t3 = setTimeout(() => setSequenceStep(4), 1200); // Aircraft
    const t4 = setTimeout(() => setSequenceStep(5), 3000); // Headline
    const t5 = setTimeout(() => setSequenceStep(6), 3500); // Booking widget

    return () => {
      clearTimeout(t0);
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, []);

  // Atmospheric background gradients based on weather state
  const atmosphereGradients = {
    morning: 'from-amber-200/90 via-sky-300/80 to-[#00482B]/60',
    day: 'from-sky-300 via-sky-100 to-[#006039]/40',
    sunset: 'from-amber-600 via-rose-400 to-[#003420]',
    night: 'from-slate-950 via-indigo-950 to-[#002416]',
  };

  // Canvas Aircraft Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const resize = () => {
      if (!canvas.parentElement) return;
      canvas.width = canvas.parentElement.clientWidth;
      canvas.height = canvas.parentElement.clientHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    // Continuous flight loop
    const render = () => {
      time += reducedMotion ? 0.002 : 0.006;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const w = canvas.width;
      const h = canvas.height;

      // Aircraft position along curved flight path
      // Normal path or accelerated WOW transform path
      const progress = (time % 1);
      let posX = w * (0.05 + progress * 0.9);
      let posY = h * (0.55 - Math.sin(progress * Math.PI) * 0.25);
      let scale = 0.6 + Math.sin(progress * Math.PI) * 0.3;
      let angle = -0.15 + Math.cos(progress * Math.PI * 2) * 0.05;

      if (triggerWowInteraction) {
        // Accelerate aircraft to upper right
        posX = w * (0.3 + (time * 2) % 1);
        posY = h * (0.4 - Math.sin((time * 2) % 1) * 0.3);
        scale = 1.2;
        angle = -0.3;
      }

      // Parallax mouse offsets
      const mouseX = parallax.x * 15;
      const mouseY = parallax.y * 10;

      // Draw Aircraft Shadow on distant clouds
      ctx.save();
      ctx.translate(posX + mouseX * 0.5, posY + 40 + mouseY * 0.5);
      ctx.scale(scale * 0.9, scale * 0.2);
      ctx.beginPath();
      ctx.ellipse(0, 0, 70, 15, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 30, 15, 0.12)';
      ctx.filter = 'blur(8px)';
      ctx.fill();
      ctx.restore();

      // Draw Boeing 787 Aircraft Silhouetted / EVA Livery
      ctx.save();
      ctx.translate(posX + mouseX, posY + mouseY);
      ctx.rotate(angle);
      ctx.scale(scale, scale);

      // Aircraft Fuselage Body
      ctx.beginPath();
      ctx.ellipse(0, 0, 85, 14, -0.05, 0, Math.PI * 2);
      const fuselageGrad = ctx.createLinearGradient(0, -15, 0, 15);
      fuselageGrad.addColorStop(0, '#FFFFFF');
      fuselageGrad.addColorStop(0.5, '#F8FAFC');
      fuselageGrad.addColorStop(1, '#006039'); // EVA Green Belly
      ctx.fillStyle = fuselageGrad;
      ctx.fill();
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(0,0,0,0.1)';
      ctx.stroke();

      // Nose Cone
      ctx.beginPath();
      ctx.moveTo(80, -2);
      ctx.quadraticCurveTo(95, 2, 80, 7);
      ctx.fillStyle = '#1E293B';
      ctx.fill();

      // Cockpit Window
      ctx.beginPath();
      ctx.ellipse(72, -4, 8, 3, -0.2, 0, Math.PI * 2);
      ctx.fillStyle = '#0F172A';
      ctx.fill();

      // EVA Air Emerald Green Belly Line & Gold Accent
      ctx.beginPath();
      ctx.moveTo(-60, 2);
      ctx.lineTo(70, 2);
      ctx.strokeStyle = '#D4AF37'; // Gold Line
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Main Swept Wing (Port & Starboard)
      ctx.beginPath();
      ctx.moveTo(-10, 0);
      ctx.lineTo(-40, 65);
      ctx.lineTo(-10, 60);
      ctx.lineTo(25, 0);
      ctx.closePath();
      const wingGrad = ctx.createLinearGradient(-10, 0, -40, 65);
      wingGrad.addColorStop(0, '#FFFFFF');
      wingGrad.addColorStop(1, '#E2E8F0');
      ctx.fillStyle = wingGrad;
      ctx.fill();

      // Engine Nacelle (GE90/GEnx)
      ctx.beginPath();
      ctx.ellipse(10, 22, 18, 7, -0.05, 0, Math.PI * 2);
      ctx.fillStyle = '#00482B';
      ctx.fill();
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Vertical Tail Fin with EVA Air Compass Logo
      ctx.beginPath();
      ctx.moveTo(-65, -8);
      ctx.lineTo(-88, -48);
      ctx.lineTo(-65, -45);
      ctx.lineTo(-45, -8);
      ctx.closePath();
      const tailGrad = ctx.createLinearGradient(-88, -48, -45, -8);
      tailGrad.addColorStop(0, '#006039');
      tailGrad.addColorStop(1, '#003B23');
      ctx.fillStyle = tailGrad;
      ctx.fill();

      // Compass Gold Star Emblem on Tail
      ctx.beginPath();
      ctx.arc(-72, -30, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#D4AF37';
      ctx.fill();

      // Navigation Strobe Lights (Flashing)
      const flash = Math.sin(time * 15) > 0.7;
      if (flash || atmosphere === 'night') {
        // Red Port Winglight
        ctx.beginPath();
        ctx.arc(-40, 65, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#EF4444';
        ctx.shadowColor = '#EF4444';
        ctx.shadowBlur = 8;
        ctx.fill();

        // White Tail Strobe
        ctx.beginPath();
        ctx.arc(-88, -48, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = '#FFFFFF';
        ctx.shadowBlur = 10;
        ctx.fill();
      }

      ctx.restore();

      // Condensation Contrails behind engines
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(posX - 20, posY + 15);
      ctx.lineTo(posX - 180, posY + 25);
      const trailGrad = ctx.createLinearGradient(posX - 20, posY, posX - 180, posY);
      trailGrad.addColorStop(0, 'rgba(255,255,255,0.4)');
      trailGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = trailGrad;
      ctx.lineWidth = 4;
      ctx.filter = 'blur(3px)';
      ctx.stroke();
      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [reducedMotion, atmosphere, triggerWowInteraction, parallax]);

  return (
    <div className="relative w-full min-h-[580px] sm:min-h-[640px] lg:min-h-[720px] overflow-hidden bg-slate-900 select-none">
      {/* Layer 1: Atmospheric Background Sky */}
      <div
        className={`absolute inset-0 bg-gradient-to-b ${
          atmosphereGradients[atmosphere]
        } transition-all duration-1000 ${
          sequenceStep >= 1 ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Layer 2: Taiwan Central Mountain Range Silhouette (Distant Parallax) */}
      <div
        className={`absolute inset-x-0 bottom-0 h-2/3 pointer-events-none transition-all duration-1000 ${
          sequenceStep >= 2 ? 'opacity-90 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
        style={{
          transform: `translate3d(${parallax.x * -10}px, ${parallax.y * -5}px, 0)`,
        }}
      >
        <svg
          viewBox="0 0 1440 320"
          className="w-full h-full object-cover align-bottom"
          preserveAspectRatio="none"
        >
          {/* Back Mountain Ridge */}
          <path
            fill="rgba(0, 50, 30, 0.4)"
            d="M0,192L60,181.3C120,171,240,149,360,165.3C480,181,600,235,720,234.7C840,235,960,181,1080,160C1200,139,1320,150,1380,154.7L1440,160L1440,320L0,320Z"
          />
          {/* Middle Yushan Peak Ridge */}
          <path
            fill="rgba(0, 72, 43, 0.65)"
            d="M0,224L80,208C160,192,320,160,480,176C640,192,800,256,960,245.3C1120,235,1280,149,1360,106.7L1440,64L1440,320L0,320Z"
          />
          {/* Foreground Foothill Ridge */}
          <path
            fill="#003B23"
            d="M0,288L120,272C240,256,480,224,720,240C960,256,1200,320,1320,330.7L1440,341L1440,380L0,380Z"
          />
        </svg>
      </div>

      {/* Layer 3: Cloud Layers Drifting */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-1000 ${
          sequenceStep >= 3 ? 'opacity-80' : 'opacity-0'
        }`}
      >
        <div
          className="absolute top-1/4 left-10 w-96 h-32 rounded-full bg-white/20 blur-3xl animate-pulse"
          style={{ animationDuration: '8s' }}
        />
        <div
          className="absolute top-1/3 right-20 w-[500px] h-40 rounded-full bg-white/15 blur-3xl animate-pulse"
          style={{ animationDuration: '12s' }}
        />
      </div>

      {/* Layer 4: Interactive Canvas Aircraft Flight */}
      <div
        className={`absolute inset-0 z-10 transition-opacity duration-1000 ${
          sequenceStep >= 4 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <canvas ref={canvasRef} className="w-full h-full block" />
      </div>

      {/* Layer 5: Hero Copy Typography (Staggered Reveal) */}
      <div className="absolute top-12 sm:top-16 left-6 sm:left-12 lg:left-20 z-20 max-w-2xl text-white">
        {/* Main Traditional Chinese Headline */}
        <div
          className={`transition-all duration-1000 ${
            sequenceStep >= 5
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-4 text-xs font-semibold text-[#D4AF37]">
            <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>2026 DIGITAL FLAGSHIP FLAGSHIP</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight drop-shadow-md font-sans leading-tight">
            探索世界 從心出發
          </h1>
          <p className="text-lg sm:text-2xl lg:text-3xl font-light text-white/90 mt-1 sm:mt-2 tracking-wide font-serif">
            Explore the World, Fly with Heart
          </p>
        </div>

        {/* Supporting Copy */}
        <div
          className={`mt-4 sm:mt-6 pt-4 border-t border-white/20 flex flex-wrap items-center justify-between gap-4 transition-all duration-1000 delay-300 ${
            sequenceStep >= 5
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4'
          }`}
        >
          <div>
            <p className="text-sm sm:text-base font-semibold text-white/95">
              {t.heroTagline}
            </p>
            <p className="text-xs text-white/70">
              Taipei Taoyuan International Airport (TPE) Global Hub
            </p>
          </div>

          {/* WOW Signature Interaction CTA: EXPLORE THE WORLD Route Map */}
          <button
            onClick={() => {
              setTriggerWowInteraction(true);
              const mapElem = document.getElementById('route-map-section');
              if (mapElem) {
                setTimeout(() => {
                  mapElem.scrollIntoView({ behavior: 'smooth' });
                  setTriggerWowInteraction(false);
                }, 1200);
              }
            }}
            className="group px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/30 text-white text-xs font-bold flex items-center space-x-2 transition-all hover:scale-105 active:scale-95 shadow-xl"
          >
            <Globe className="w-4 h-4 text-[#D4AF37] group-hover:rotate-180 transition-transform duration-700" />
            <span>{t.exploreWorldCTA}</span>
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] animate-bounce" />
          </button>
        </div>
      </div>
    </div>
  );
}
