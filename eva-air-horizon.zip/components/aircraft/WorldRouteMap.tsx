'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { destinations } from '@/data/destinations';
import { Destination } from '@/types';
import { Plane, Compass, MapPin, Sparkles, Clock, ChevronRight } from 'lucide-react';

export function WorldRouteMap() {
  const { t, language, setSearchQuery, setIsSearching, setSearchDone } = useApp();
  const [activeDestination, setActiveDestination] = useState<Destination>(destinations[0]);

  const handleSelectRoute = (dest: Destination) => {
    setActiveDestination(dest);
    setSearchQuery((prev) => ({
      ...prev,
      from: 'TPE',
      to: dest.code,
    }));
  };

  const handleSearchThisRoute = (dest: Destination) => {
    setSearchQuery((prev) => ({
      ...prev,
      from: 'TPE',
      to: dest.code,
    }));
    setIsSearching(true);
    setSearchDone(false);

    const elem = document.getElementById('search-results-section');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }

    setTimeout(() => {
      setIsSearching(false);
      setSearchDone(true);
    }, 2000);
  };

  return (
    <div
      id="route-map-section"
      className="bg-slate-950 py-16 sm:py-24 text-white relative overflow-hidden my-12"
    >
      {/* Background Emerald Radar Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full bg-[#006039]/20 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#006039]/30 border border-[#006039]/50 text-[#D4AF37] text-xs font-bold mb-4">
            <Compass className="w-4 h-4 text-[#D4AF37] animate-spin" style={{ animationDuration: '10s' }} />
            <span>GLOBAL AIRWAY RADAR NETWORK</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white font-sans">
            {t.interactiveRouteMap}
          </h2>
          <p className="text-sm sm:text-base text-gray-400 mt-2 font-serif">
            {t.routeMapSub}
          </p>
        </div>

        {/* Route Canvas Map Stage */}
        <div className="relative bg-slate-900/90 rounded-3xl border border-white/10 p-6 lg:p-10 shadow-2xl overflow-hidden min-h-[480px] sm:min-h-[560px] flex flex-col justify-between">
          {/* Decorative Grid Lines */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

          {/* Map Nodes & Animated Flight Arcs */}
          <div className="relative w-full h-[360px] sm:h-[420px]">
            {/* TPE Hub Central Node (Taipei) */}
            <div
              className="absolute z-20 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center cursor-pointer group"
              style={{ left: '62%', top: '48%' }}
            >
              <div className="relative flex items-center justify-center">
                <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-[#006039] opacity-75" />
                <div className="w-6 h-6 rounded-full bg-[#006039] ring-4 ring-[#D4AF37] flex items-center justify-center text-white shadow-lg">
                  <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
                </div>
              </div>
              <span className="mt-1 font-black text-xs text-[#D4AF37] bg-black/80 px-2 py-0.5 rounded-full border border-[#D4AF37]/50 shadow-md">
                TPE 台北 (HUB)
              </span>
            </div>

            {/* Destination Nodes */}
            {destinations.map((dest) => {
              const isSelected = activeDestination.code === dest.code;

              return (
                <div
                  key={dest.code}
                  onClick={() => handleSelectRoute(dest)}
                  className="absolute z-20 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center cursor-pointer group transition-transform hover:scale-125"
                  style={{ left: `${dest.coordinates.x}%`, top: `${dest.coordinates.y}%` }}
                >
                  {/* Glowing Route Arc SVG from TPE */}
                  <svg className="absolute inset-0 w-[1000px] h-[1000px] pointer-events-none -left-[500px] -top-[500px]">
                    <line
                      x1="500"
                      y1="500"
                      x2={500 + (dest.coordinates.x - 62) * 5}
                      y2={500 + (dest.coordinates.y - 48) * 5}
                      stroke={isSelected ? '#D4AF37' : '#006039'}
                      strokeWidth={isSelected ? '2.5' : '1.5'}
                      strokeDasharray="6 4"
                      className="animate-pulse"
                    />
                  </svg>

                  <div className="relative flex items-center justify-center">
                    <div
                      className={`w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-[#D4AF37] ring-4 ring-[#D4AF37]/40 text-black scale-125'
                          : 'bg-[#006039] text-white hover:bg-[#00A859]'
                      }`}
                    >
                      <MapPin className="w-2.5 h-2.5" />
                    </div>
                  </div>

                  <span
                    className={`mt-1 font-bold text-[11px] px-2 py-0.5 rounded-full border transition-all ${
                      isSelected
                        ? 'bg-[#D4AF37] text-black border-[#D4AF37] shadow-lg font-black'
                        : 'bg-black/70 text-white/80 border-white/20 group-hover:bg-black group-hover:text-white'
                    }`}
                  >
                    {dest.code} {language === 'zhTW' ? dest.cityZh : dest.cityEn}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Selected Route Info Card Overlay */}
          <div className="bg-slate-900/90 rounded-2xl border border-white/15 p-5 flex flex-wrap items-center justify-between gap-4 backdrop-blur-md">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-[#006039] text-[#D4AF37] flex items-center justify-center font-black text-lg">
                <Plane className="w-6 h-6 rotate-45" />
              </div>
              <div>
                <div className="text-lg font-black text-white">
                  TPE 台北 ↔ {activeDestination.code}{' '}
                  {language === 'zhTW' ? activeDestination.nameZh : activeDestination.nameEn}
                </div>
                <div className="text-xs text-gray-400 font-medium flex items-center space-x-3 mt-0.5">
                  <span className="flex items-center">
                    <Clock className="w-3.5 h-3.5 mr-1 text-[#006039]" />
                    {activeDestination.flightTime}
                  </span>
                  <span>•</span>
                  <span className="text-[#D4AF37] font-bold">
                    TWD {activeDestination.priceTwd.toLocaleString()} {t.fromTwd}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleSearchThisRoute(activeDestination)}
              className="px-6 py-3 rounded-xl bg-[#006039] hover:bg-[#00482B] text-white font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all hover:scale-105 shadow-lg"
            >
              <span>{t.searchFlightsCTA}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
