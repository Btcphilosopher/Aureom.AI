import { Language } from '@/types';

export type TranslationDictionary = typeof zhTW;

const zhTW = {
  // Utility Top Bar
  location: '台灣 / TAIWAN',
  langZh: '繁體中文',
  langEn: 'English',
  memberLogin: '會員登入 / 立即註冊',
  infinityMember: '無限萬哩遊',
  
  // Main Nav
  navBook: '預訂行程',
  navOffers: '優惠專區',
  navManage: '行程管理',
  navExperience: '體驗長榮',
  navLoyalty: '無限萬哩遊',
  navSupport: '支援服務',
  searchPlaceholder: '搜尋航班、目的地或服務...',
  cartToolTip: '已選航班',
  
  // Hero Section
  heroTitle: '探索世界 從心出發',
  heroSubtitle: 'Explore the World, Fly with Heart',
  heroTagline: '來自台灣的全球航空服務',
  exploreWorldCTA: '探索世界路線圖',
  exploreWorldDesc: '開啟互動式環球航線視野',
  
  // Quick Panel Side Buttons
  quickCheckIn: '線上報到',
  quickCheckInSub: 'ONLINE CHECK-IN',
  quickFlightStatus: '航班動態',
  quickFlightStatusSub: 'FLIGHT STATUS',
  quickBaggage: '行李資訊',
  quickBaggageSub: 'BAGGAGE INFO',
  
  // Booking Engine Tabs
  tabBookFlight: '預訂航班',
  tabRedeemMiles: '哩程兌換',
  tabManageBooking: '機票管理',
  tabFlightSchedule: '航班時刻表',
  
  // Booking Form
  tripRoundTrip: '來回',
  tripOneWay: '單程',
  tripMultiCity: '多航段',
  
  fieldFrom: '出發地',
  fieldTo: '目的地',
  fieldDeparture: '出發日',
  fieldReturn: '回程日',
  fieldPassengersClass: '旅客 / 艙等',
  fieldPromoCode: '優惠代碼',
  
  searchFlightsCTA: '搜尋航班',
  selectAirport: '選擇機場',
  swapAirports: '對調出發地與目的地',
  
  // Passenger & Class Picker
  adults: '成人 (12歲以上)',
  children: '兒童 (2-11歲)',
  infants: '嬰兒 (2歲以下)',
  passengerCount: '位旅客',
  
  cabinEconomy: '經濟艙 Economy',
  cabinPremiumEconomy: '豪華經濟艙 Premium Economy',
  cabinBusiness: '商務艙 Business',
  cabinRoyalLaurel: '皇璽桂冠艙 Royal Laurel',
  
  // Search Results & Loading
  searchingTitle: '正在搜尋最佳航班…',
  searchingSub: '長榮航空 787 夢幻客機正在為您檢索星宇聯網即時票價',
  resultsFound: '找到的直飛與轉機航班',
  fromTwd: 'TWD 起',
  nonStop: '直飛',
  stopsCount: '次轉機',
  duration: '飛行時間',
  aircraftModel: '機型',
  selectFlight: '選擇此航班',
  flightDetails: '航班細節',
  seatMap: '預覽座位圖',
  compareFares: '比較票價',
  
  // Route Map
  interactiveRouteMap: '長榮全球航線互動地圖',
  routeMapSub: '從台北桃園(TPE) hub 樞紐連接五大洲重點城市',
  viewRouteDetails: '檢視該航線航班時間表',
  
  // Destinations Explorer
  destinationsTitle: '探索熱門目的地',
  destinationsSub: '精選長榮優質航點 感受精緻飛行旅行體驗',
  filterAll: '全部航點',
  filterAsia: '亞洲航線',
  filterEurope: '歐洲航線',
  filterNorthAmerica: '北美航線',
  filterOceania: '大洋洲航線',
  discoverBtn: '探索航班',
  flightTimeLabel: '平均飛行時間',
  startingFrom: '優惠起價',
  
  // Offers Section
  offersTitle: '最新限時特惠',
  offersSub: '尊榮舒適的飛行體驗 與您展開夢幻假期',
  viewAllOffers: '查看全部分類特惠',
  bookOfferCTA: '立即搶購優惠票',
  
  // EVA Experience
  experienceTitle: '長榮頂級飛行體驗',
  experienceSub: '結合台灣精緻款待與國際頂級客艙設計',
  viewCabinDetails: '深入瞭解客艙配備',
  
  // Infinity Mileagelands
  loyaltyTitle: '無限萬哩遊',
  loyaltySub: '累積哩程，換取無限精彩可能',
  memberTier: '會員尊榮卡級',
  currentBalance: '可用哩程餘額',
  tierMilesProgress: '晉升下一卡級所需哩程',
  expiringNotice: '最近即將到期哩程',
  redeemAward: '立即兌換免費機票',
  joinLoyalty: '免費加入無限萬哩遊',
  
  // Flight Status
  statusTitle: '即時航班動態查詢',
  statusSub: '輸入航班號碼或出發/目的地，掌握最新航班時刻',
  flightNumberInput: '航班號碼 (例: BR198)',
  checkStatusCTA: '查詢航班狀態',
  onTime: '準點 ON TIME',
  delayed: '延誤 DELAYED',
  boarding: '登機中 BOARDING',
  departed: '已起飛 DEPARTED',
  arrived: '已到達 ARRIVED',
  cancelled: '已取消 CANCELLED',
  scheduledDep: '預定起飛',
  estimatedDep: '預估起飛',
  scheduledArr: '預定到達',
  estimatedArr: '預估到達',
  gateLabel: '登機門 Gate',
  terminalLabel: '航廈 Terminal',
  
  // Online Check In
  checkInTitle: '預辦登機與預選座位',
  checkInSub: '班機起飛前48小時至70分鐘即可辦理線上報到',
  bookingReference: '訂位代號 / 機票號碼 (6碼英文數字)',
  passengerSurname: '旅客姓氏 (英文)',
  startCheckInCTA: '辦理報到',
  boardingPassPreview: '數位登機證預覽',
  
  // Baggage Info
  baggageTitle: '托運與手提行李須知',
  baggageSub: '依照您的艙等獲得最充裕的行李配額與貼心說明',
  cabinBaggage: '手提行李',
  checkedBaggage: '托行李額度',
  specialBaggage: '特殊器材',
  sportsEquipment: '運動器材與樂器',
  baggageCalcCTA: '計算行李配額',
  
  // Atmosphere & Controls
  atmosphereTime: '場景氣氛',
  timeMorning: '晨曦 Morning',
  timeDay: '晴空 Day',
  timeSunset: '晚霞 Sunset',
  timeNight: '星夜 Night',
  reducedMotionOn: '減緩動態開',
  reducedMotionOff: '流暢3D/動畫',
  
  // Errors & Validations
  errorSameAirport: '出發地與目的地不能相同',
  errorInvalidRef: '請輸入有效的6位數訂位代號 (例: EVA123)',
  errorNoFlight: '查無符合條件之航班，請重新選擇日期',
  errorNetwork: '網路連線逾時，請再試一次',
  
  // Footer
  footerBook: '預訂與管理',
  footerDestinations: '航線與目的地',
  footerExperience: '機上與服務',
  footerLoyalty: '無限萬哩遊',
  footerSupport: '客戶支援',
  starAllianceText: '星空聯盟成員 (A STAR ALLIANCE MEMBER)',
  copyright: '© 2026 長榮航空 EVA AIRWAY CORP. 保留所有權利。',
  privacy: '隱私權保護聲明',
  terms: '顧客服務承諾與運送條款',
  cookie: 'Cookie 設定',
};

const en: TranslationDictionary = {
  // Utility Top Bar
  location: 'TAIWAN / 台灣',
  langZh: '繁體中文',
  langEn: 'English',
  memberLogin: 'Member Login / Register',
  infinityMember: 'INFINITY MILEAGELANDS',
  
  // Main Nav
  navBook: 'BOOK',
  navOffers: 'OFFERS',
  navManage: 'MANAGE TRIP',
  navExperience: 'EXPERIENCE EVA',
  navLoyalty: 'INFINITY MILEAGELANDS',
  navSupport: 'SUPPORT',
  searchPlaceholder: 'Search flights, destinations, or services...',
  cartToolTip: 'Selected Flights',
  
  // Hero Section
  heroTitle: 'Explore the World, Fly with Heart',
  heroSubtitle: '探索世界 從心出发',
  heroTagline: "Taiwan's Leading Global Airline",
  exploreWorldCTA: 'Explore Global Route Map',
  exploreWorldDesc: 'Interactive high-altitude route transformation',
  
  // Quick Panel Side Buttons
  quickCheckIn: 'ONLINE CHECK-IN',
  quickCheckInSub: '線報到',
  quickFlightStatus: 'FLIGHT STATUS',
  quickFlightStatusSub: '航班動態',
  quickBaggage: 'BAGGAGE INFO',
  quickBaggageSub: '行李資訊',
  
  // Booking Engine Tabs
  tabBookFlight: 'BOOK A FLIGHT',
  tabRedeemMiles: 'REDEEM MILES',
  tabManageBooking: 'MANAGE BOOKING',
  tabFlightSchedule: 'FLIGHT SCHEDULE',
  
  // Booking Form
  tripRoundTrip: 'Round Trip',
  tripOneWay: 'One Way',
  tripMultiCity: 'Multi-city',
  
  fieldFrom: 'FROM',
  fieldTo: 'TO',
  fieldDeparture: 'DEPARTURE',
  fieldReturn: 'RETURN',
  fieldPassengersClass: 'PASSENGERS / CLASS',
  fieldPromoCode: 'PROMO CODE',
  
  searchFlightsCTA: 'SEARCH FLIGHTS',
  selectAirport: 'Select Airport',
  swapAirports: 'Swap origin and destination',
  
  // Passenger & Class Picker
  adults: 'Adults (12+ yrs)',
  children: 'Children (2-11 yrs)',
  infants: 'Infants (Under 2 yrs)',
  passengerCount: 'Passenger(s)',
  
  cabinEconomy: 'Economy',
  cabinPremiumEconomy: 'Premium Economy',
  cabinBusiness: 'Business',
  cabinRoyalLaurel: 'Royal Laurel Class',
  
  // Search Results & Loading
  searchingTitle: 'Searching best flights…',
  searchingSub: 'EVA Air Boeing 787 Dreamliner network fetching live fares',
  resultsFound: 'Direct & Connecting Flights Found',
  fromTwd: 'TWD',
  nonStop: 'Non-stop',
  stopsCount: 'Stop(s)',
  duration: 'Flight Duration',
  aircraftModel: 'Aircraft',
  selectFlight: 'Select Flight',
  flightDetails: 'Flight Details',
  seatMap: 'View Seat Map',
  compareFares: 'Compare Fares',
  
  // Route Map
  interactiveRouteMap: 'EVA Air Interactive Global Route Map',
  routeMapSub: 'Connecting 5 continents from Taipei Taoyuan (TPE) international hub',
  viewRouteDetails: 'View schedule for this route',
  
  // Destinations Explorer
  destinationsTitle: 'Explore Featured Destinations',
  destinationsSub: 'Experience world-class Asian hospitality across premier global gateways',
  filterAll: 'All Regions',
  filterAsia: 'Asia',
  filterEurope: 'Europe',
  filterNorthAmerica: 'North America',
  filterOceania: 'Oceania',
  discoverBtn: 'Discover Flights',
  flightTimeLabel: 'Avg Flight Time',
  startingFrom: 'Fares From',
  
  // Offers Section
  offersTitle: 'Featured Seasonal Offers',
  offersSub: 'Premium comfort in the sky for your dream international journey',
  viewAllOffers: 'View All Fares & Offers',
  bookOfferCTA: 'Book Offer Now',
  
  // EVA Experience
  experienceTitle: 'The EVA Air Inflight Experience',
  experienceSub: 'Modern Taiwanese elegance meets world-class cabin engineering',
  viewCabinDetails: 'Explore Cabin Amenities',
  
  // Infinity Mileagelands
  loyaltyTitle: 'INFINITY MILEAGELANDS',
  loyaltySub: 'Earn Miles, Unlock Endless Travel Possibilities',
  memberTier: 'Membership Tier',
  currentBalance: 'Available Miles Balance',
  tierMilesProgress: 'Miles Needed for Next Tier',
  expiringNotice: 'Expiring Miles',
  redeemAward: 'Redeem Flight Award',
  joinLoyalty: 'Join Infinity Mileagelands Free',
  
  // Flight Status
  statusTitle: 'Live Flight Status Search',
  statusSub: 'Track real-time flight arrival, departure, gate, and aircraft updates',
  flightNumberInput: 'Flight Number (e.g. BR198)',
  checkStatusCTA: 'CHECK FLIGHT STATUS',
  onTime: 'ON TIME',
  delayed: 'DELAYED',
  boarding: 'BOARDING',
  departed: 'DEPARTED',
  arrived: 'ARRIVED',
  cancelled: 'CANCELLED',
  scheduledDep: 'Scheduled Dep',
  estimatedDep: 'Estimated Dep',
  scheduledArr: 'Scheduled Arr',
  estimatedArr: 'Estimated Arr',
  gateLabel: 'Gate',
  terminalLabel: 'Terminal',
  
  // Online Check In
  checkInTitle: 'Online Check-In & Seat Selection',
  checkInSub: 'Available 48 hours to 70 minutes prior to scheduled flight departure',
  bookingReference: 'Booking Reference / Ticket Number (6 chars)',
  passengerSurname: 'Passenger Surname (As on passport)',
  startCheckInCTA: 'CHECK IN NOW',
  boardingPassPreview: 'Digital Boarding Pass',
  
  // Baggage Info
  baggageTitle: 'Baggage Allowance & Guidelines',
  baggageSub: 'Generous baggage limits and guidelines tailored to your cabin class',
  cabinBaggage: 'Cabin Baggage',
  checkedBaggage: 'Checked Allowance',
  specialBaggage: 'Special Baggage',
  sportsEquipment: 'Sports Equipment & Instruments',
  baggageCalcCTA: 'Calculate Baggage Allowance',
  
  // Atmosphere & Controls
  atmosphereTime: 'Atmosphere',
  timeMorning: 'Morning',
  timeDay: 'Day',
  timeSunset: 'Sunset',
  timeNight: 'Night',
  reducedMotionOn: 'Reduced Motion ON',
  reducedMotionOff: 'Full 3D / Motion',
  
  // Errors & Validations
  errorSameAirport: 'Origin and destination airports cannot be identical',
  errorInvalidRef: 'Please enter a valid 6-character booking reference (e.g. EVA123)',
  errorNoFlight: 'No flights found for selected criteria. Please adjust travel dates.',
  errorNetwork: 'Network request timed out. Please try again.',
  
  // Footer
  footerBook: 'BOOK & MANAGE',
  footerDestinations: 'ROUTES & DESTINATIONS',
  footerExperience: 'INFLIGHT EXPERIENCE',
  footerLoyalty: 'INFINITY MILEAGELANDS',
  footerSupport: 'CUSTOMER SUPPORT',
  starAllianceText: 'A STAR ALLIANCE MEMBER',
  copyright: '© 2026 EVA AIRWAYS CORP. All rights reserved.',
  privacy: 'Privacy Policy Statement',
  terms: 'Customer Service Commitment & Conditions of Carriage',
  cookie: 'Cookie Preferences',
};

export const translations: Record<Language, TranslationDictionary> = {
  zhTW,
  en,
};

export function getTranslation(lang: Language): TranslationDictionary {
  return translations[lang] || translations.zhTW;
}
