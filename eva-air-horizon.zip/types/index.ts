export type Language = 'zhTW' | 'en';

export interface Airport {
  code: string;
  nameZh: string;
  nameEn: string;
  cityZh: string;
  cityEn: string;
  countryZh: string;
  countryEn: string;
  region: 'asia' | 'europe' | 'northAmerica' | 'oceania';
}

export type CabinClass = 'Economy' | 'PremiumEconomy' | 'Business' | 'RoyalLaurel';

export interface FareOption {
  cabinClass: CabinClass;
  priceTwd: number;
  priceUsd: number;
  availableSeats: number;
  featuresZh: string[];
  featuresEn: string[];
  baggageAllowance: string;
  refundable: boolean;
  changeable: boolean;
}

export interface Flight {
  id: string;
  flightNumber: string;
  origin: Airport;
  destination: Airport;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  aircraft: string;
  aircraftModel: string;
  stops: number;
  fares: Record<CabinClass, FareOption>;
}

export interface Destination {
  id: string;
  code: string;
  nameZh: string;
  nameEn: string;
  cityZh: string;
  cityEn: string;
  countryZh: string;
  countryEn: string;
  image: string;
  priceTwd: number;
  flightTime: string;
  descriptionZh: string;
  descriptionEn: string;
  tagZh: string;
  tagEn: string;
  popular?: boolean;
  coordinates: { x: number; y: number }; // Percentage for interactive route map
}

export interface Offer {
  id: string;
  titleZh: string;
  titleEn: string;
  subtitleZh: string;
  subtitleEn: string;
  priceTwd: number;
  routeZh: string;
  routeEn: string;
  tagZh: string;
  tagEn: string;
  image: string;
  expiryDate: string;
}

export interface CabinExperience {
  id: string;
  key: CabinClass | 'dining' | 'lounge' | 'amenity';
  titleZh: string;
  titleEn: string;
  subtitleZh: string;
  subtitleEn: string;
  descriptionZh: string;
  descriptionEn: string;
  featuresZh: string[];
  featuresEn: string[];
  image: string;
  badgeZh: string;
  badgeEn: string;
}

export type FlightStatusCode = 'ON_TIME' | 'DELAYED' | 'BOARDING' | 'DEPARTED' | 'ARRIVED' | 'CANCELLED';

export interface FlightStatus {
  flightNumber: string;
  date: string;
  origin: Airport;
  destination: Airport;
  scheduledDep: string;
  estimatedDep: string;
  actualDep?: string;
  scheduledArr: string;
  estimatedArr: string;
  actualArr?: string;
  status: FlightStatusCode;
  delayMinutes?: number;
  gate: string;
  terminal: string;
  aircraft: string;
  progressPercent: number; // 0 to 100 for live track
}

export interface LoyaltyUser {
  name: string;
  tier: 'Green' | 'Silver' | 'Gold' | 'Diamond';
  memberId: string;
  milesBalance: number;
  tierMiles: number;
  milesToNextTier: number;
  expiringMiles: number;
  expiringDate: string;
}

export interface SearchQueryParams {
  tripType: 'roundTrip' | 'oneWay' | 'multiCity';
  from: string;
  to: string;
  departureDate: string;
  returnDate?: string;
  passengers: {
    adults: number;
    children: number;
    infants: number;
  };
  cabinClass: CabinClass;
  redeemMiles: boolean;
  promoCode?: string;
}
