import { FlightStatus } from '@/types';
import { getAirportByCode } from './airports';

export const mockFlightStatuses: Record<string, FlightStatus> = {
  BR198: {
    flightNumber: 'BR198',
    date: '2026-06-15',
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('NRT'),
    scheduledDep: '08:50',
    estimatedDep: '08:50',
    actualDep: '08:54',
    scheduledArr: '13:15',
    estimatedArr: '13:10',
    status: 'DEPARTED',
    gate: 'C7',
    terminal: 'T2',
    aircraft: 'Boeing 787-10 (B-17801)',
    progressPercent: 65,
  },
  BR192: {
    flightNumber: 'BR192',
    date: '2026-06-15',
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('NRT'),
    scheduledDep: '13:20',
    estimatedDep: '13:20',
    scheduledArr: '17:45',
    estimatedArr: '17:45',
    status: 'ON_TIME',
    gate: 'C5',
    terminal: 'T2',
    aircraft: 'Boeing 787-10 (B-17803)',
    progressPercent: 0,
  },
  BR184: {
    flightNumber: 'BR184',
    date: '2026-06-15',
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('NRT'),
    scheduledDep: '15:10',
    estimatedDep: '15:25',
    delayMinutes: 15,
    scheduledArr: '19:30',
    estimatedArr: '19:45',
    status: 'DELAYED',
    gate: 'B8',
    terminal: 'T2',
    aircraft: 'Boeing 777-300ER (B-16722)',
    progressPercent: 0,
  },
  BR12: {
    flightNumber: 'BR12',
    date: '2026-06-15',
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('LAX'),
    scheduledDep: '19:20',
    estimatedDep: '19:20',
    scheduledArr: '16:00',
    estimatedArr: '15:48',
    actualDep: '19:20',
    actualArr: '15:48',
    status: 'ARRIVED',
    gate: '132',
    terminal: 'TBIT',
    aircraft: 'Boeing 777-300ER (B-16701)',
    progressPercent: 100,
  },
  BR67: {
    flightNumber: 'BR67',
    date: '2026-06-15',
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('LHR'),
    scheduledDep: '23:40',
    estimatedDep: '23:40',
    scheduledArr: '06:55 (+1)',
    estimatedArr: '06:55 (+1)',
    status: 'BOARDING',
    gate: 'C2',
    terminal: 'T2',
    aircraft: 'Boeing 777-300ER (B-16738)',
    progressPercent: 10,
  },
};

export function getFlightStatus(flightNo: string): FlightStatus {
  const code = flightNo.toUpperCase().trim();
  if (mockFlightStatuses[code]) {
    return mockFlightStatuses[code];
  }

  // Generate dynamic fallback for any typed flight code
  return {
    flightNumber: code.startsWith('BR') ? code : `BR${code}`,
    date: new Date().toISOString().split('T')[0],
    origin: getAirportByCode('TPE'),
    destination: getAirportByCode('NRT'),
    scheduledDep: '10:00',
    estimatedDep: '10:00',
    actualDep: '10:02',
    scheduledArr: '14:20',
    estimatedArr: '14:15',
    status: 'ON_TIME',
    gate: 'C8',
    terminal: 'T2',
    aircraft: 'Boeing 787-10 Dreamliner',
    progressPercent: 40,
  };
}
