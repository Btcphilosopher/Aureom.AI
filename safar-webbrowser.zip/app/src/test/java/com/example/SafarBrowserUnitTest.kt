package com.example

import com.example.model.SearchEngine
import com.example.util.ArabicTextHelper
import com.example.util.UrlUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SafarBrowserUnitTest {

    @Test
    fun testUrlParsing_exactUrl() {
        val input = "https://example.com"
        val parsed = UrlUtils.parseInputOrSearch(input, SearchEngine.DUCKDUCKGO)
        assertEquals("https://example.com", parsed)
    }

    @Test
    fun testUrlParsing_domainWithoutScheme() {
        val input = "ar.wikipedia.org"
        val parsed = UrlUtils.parseInputOrSearch(input, SearchEngine.DUCKDUCKGO)
        assertEquals("https://ar.wikipedia.org", parsed)
    }

    @Test
    fun testUrlParsing_arabicSearchQuery() {
        val query = "تاريخ الأندلس"
        val parsed = UrlUtils.parseInputOrSearch(query, SearchEngine.DUCKDUCKGO)
        assertTrue(parsed.startsWith("https://duckduckgo.com/?q="))
    }

    @Test
    fun testUrlParsing_mixedSearchQuery() {
        val query = "Jetpack Compose في الأندرويد"
        val parsed = UrlUtils.parseInputOrSearch(query, SearchEngine.GOOGLE)
        assertTrue(parsed.startsWith("https://www.google.com/search?q="))
    }

    @Test
    fun testExtractDomain() {
        val url = "https://news.ycombinator.com/item?id=12345"
        val domain = UrlUtils.extractDomain(url)
        assertEquals("news.ycombinator.com", domain)
    }

    @Test
    fun testIsHttps() {
        assertTrue(UrlUtils.isHttps("https://safebrowsing.org"))
        assertFalse(UrlUtils.isHttps("http://insecure.org"))
    }

    @Test
    fun testArabicDetection() {
        assertTrue(ArabicTextHelper.isArabic("سَفَر متصفح عربي أصيل"))
        assertFalse(ArabicTextHelper.isArabic("Hello World"))
    }

    @Test
    fun testBidiUrlIsolation() {
        val url = "https://example.com"
        val isolated = ArabicTextHelper.isolateBidiUrl(url)
        assertTrue(isolated.startsWith("\u2066"))
        assertTrue(isolated.endsWith("\u2069"))
    }
}
