package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [BookmarkEntity::class, HistoryEntity::class, ShortcutEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SafarDatabase : RoomDatabase() {
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun shortcutDao(): ShortcutDao

    companion object {
        @Volatile
        private var INSTANCE: SafarDatabase? = null

        fun getDatabase(context: Context): SafarDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SafarDatabase::class.java,
                    "safar_browser.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed directly via raw SQL without background DB re-entrance to avoid deadlock
                        try {
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('ويكيبيديا العربية', 'https://ar.wikipedia.org', '📚', 0)")
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('الجزيرة نت', 'https://www.aljazeera.net', '📰', 1)")
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('حاسوب إكاديمية', 'https://academy.hsoub.com', '💻', 2)")
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('موضوع', 'https://mawdoo3.com', '📖', 3)")
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('بي بي سي عربي', 'https://www.bbc.com/arabic', '🌍', 4)")
                            db.execSQL("INSERT OR REPLACE INTO quick_shortcuts (title, url, iconEmoji, orderIndex) VALUES ('DuckDuckGo', 'https://duckduckgo.com', '🦆', 5)")
                        } catch (_: Exception) {}
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
