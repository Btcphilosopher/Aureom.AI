package com.example.data.repository

import com.example.data.local.BookmarkDao
import com.example.data.local.BookmarkEntity
import com.example.data.local.HistoryDao
import com.example.data.local.HistoryEntity
import com.example.data.local.ShortcutDao
import com.example.data.local.ShortcutEntity
import kotlinx.coroutines.flow.Flow

class BrowserRepository(
    private val bookmarkDao: BookmarkDao,
    private val historyDao: HistoryDao,
    private val shortcutDao: ShortcutDao
) {
    val bookmarks: Flow<List<BookmarkEntity>> = bookmarkDao.getAllBookmarks()
    val history: Flow<List<HistoryEntity>> = historyDao.getRecentHistory()
    val shortcuts: Flow<List<ShortcutEntity>> = shortcutDao.getAllShortcuts()

    suspend fun addBookmark(title: String, url: String, category: String = "عام"): Long {
        return bookmarkDao.insertBookmark(BookmarkEntity(title = title, url = url, category = category))
    }

    suspend fun removeBookmark(bookmark: BookmarkEntity) {
        bookmarkDao.deleteBookmark(bookmark)
    }

    suspend fun removeBookmarkById(id: Long) {
        bookmarkDao.deleteBookmarkById(id)
    }

    suspend fun clearAllBookmarks() {
        bookmarkDao.clearAllBookmarks()
    }

    suspend fun isBookmarked(url: String): Boolean {
        return bookmarkDao.isBookmarked(url)
    }

    suspend fun recordHistory(title: String, url: String) {
        if (url.isNotBlank() && url != "about:blank") {
            historyDao.insertHistory(HistoryEntity(title = title.ifBlank { url }, url = url))
        }
    }

    suspend fun removeHistory(historyEntity: HistoryEntity) {
        historyDao.deleteHistory(historyEntity)
    }

    suspend fun clearHistory() {
        historyDao.clearAllHistory()
    }

    suspend fun addShortcut(title: String, url: String, emoji: String = "🌐") {
        shortcutDao.insertShortcut(ShortcutEntity(title = title, url = url, iconEmoji = emoji))
    }

    suspend fun removeShortcut(id: Long) {
        shortcutDao.deleteShortcutById(id)
    }
}
