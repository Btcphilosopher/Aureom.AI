package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.model.SafarStrings
import com.example.ui.theme.SafarBronzeAccent
import com.example.ui.theme.SafarDanger
import com.example.ui.theme.SafarSuccess
import com.example.ui.theme.SafarTealAccent
import com.example.util.ArabicTextHelper
import com.example.util.UrlUtils

@Composable
fun AddShortcutDialog(
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onAdd: (title: String, url: String, emoji: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("🌐") }

    val emojis = listOf("🌐", "📰", "📚", "💻", "🛒", "🔍", "⚡", "✨", "🕌")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(SafarStrings.addShortcut(isArabic)) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(SafarStrings.title(isArabic)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("shortcut_title_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text(SafarStrings.url(isArabic)) },
                    placeholder = { Text("https://example.com") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("shortcut_url_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    emojis.forEach { e ->
                        TextButton(
                            onClick = { emoji = e },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Text(text = e, fontSize = 18.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && url.isNotBlank()) {
                        val formattedUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            "https://$url"
                        } else url
                        onAdd(title, formattedUrl, emoji)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SafarTealAccent),
                modifier = Modifier.testTag("shortcut_confirm_button")
            ) {
                Text(SafarStrings.save(isArabic))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(SafarStrings.cancel(isArabic))
            }
        }
    )
}

@Composable
fun PrivacyInfoDialog(
    tab: BrowserTab,
    isArabic: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (tab.isSecure) Icons.Default.Lock else Icons.Default.Security,
                    contentDescription = null,
                    tint = if (tab.isSecure) SafarSuccess else SafarDanger,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (tab.isSecure)
                        SafarStrings.secureConnection(isArabic)
                    else
                        SafarStrings.insecureConnection(isArabic),
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isArabic) "النطاق الحالي:" else "Current Domain:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SafarTealAccent
                        )
                        Text(
                            text = ArabicTextHelper.isolateBidiUrl(UrlUtils.extractDomain(tab.url)),
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Shield,
                                contentDescription = null,
                                tint = SafarTealAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = SafarStrings.privacyShield(isArabic),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic)
                                "درع سَفَر يعمل بنشاط على حجب محاولات تعقب الأطراف الثالثة وملفات التتبع الإعلانية."
                            else
                                "SAFAR Shield is actively blocking 3rd party trackers and profiling scripts.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (tab.isPrivate) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = SafarStrings.privateModeExplainer(isArabic),
                        fontSize = 12.sp,
                        color = SafarBronzeAccent
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = SafarTealAccent)
            ) {
                Text(SafarStrings.close(isArabic))
            }
        }
    )
}
