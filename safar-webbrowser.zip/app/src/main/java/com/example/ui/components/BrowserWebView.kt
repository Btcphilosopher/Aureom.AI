package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.BrowserTab
import com.example.viewmodel.WebViewAction
import java.io.ByteArrayInputStream

// Known tracker and ad domains to block for Privacy Shield
private val TRACKER_DOMAINS = listOf(
    "google-analytics.com",
    "doubleclick.net",
    "googlesyndication.com",
    "adnxs.com",
    "scorecardresearch.com",
    "facebook.net/tr",
    "criteo.com",
    "outbrain.com",
    "taboola.com"
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserWebView(
    tab: BrowserTab,
    adBlockEnabled: Boolean,
    javaScriptEnabled: Boolean,
    pendingAction: WebViewAction?,
    onActionConsumed: () -> Unit,
    onProgressChange: (progress: Int, isLoading: Boolean) -> Unit,
    onPageInfoChange: (title: String, url: String, canBack: Boolean, canForward: Boolean, isSecure: Boolean) -> Unit,
    onReadingContentReady: (title: String, content: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webView = remember(tab.id) {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            settings.apply {
                this.javaScriptEnabled = javaScriptEnabled
                domStorageEnabled = !tab.isPrivate
                databaseEnabled = !tab.isPrivate
                cacheMode = if (tab.isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    val loading = newProgress < 100
                    onProgressChange(newProgress, loading)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    val currentUrl = view?.url ?: tab.url
                    val isSecure = currentUrl.startsWith("https://", ignoreCase = true)
                    onPageInfoChange(
                        title ?: currentUrl,
                        currentUrl,
                        view?.canGoBack() ?: false,
                        view?.canGoForward() ?: false,
                        isSecure
                    )
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    // Keep navigation within the browser for standard web protocols
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        return false
                    }
                    return true
                }

                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    if (adBlockEnabled) {
                        val requestUrl = request?.url?.toString() ?: ""
                        for (tracker in TRACKER_DOMAINS) {
                            if (requestUrl.contains(tracker, ignoreCase = true)) {
                                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".toByteArray()))
                            }
                        }
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    val currentUrl = url ?: tab.url
                    val isSecure = currentUrl.startsWith("https://", ignoreCase = true)
                    onPageInfoChange(
                        view?.title ?: currentUrl,
                        currentUrl,
                        view?.canGoBack() ?: false,
                        view?.canGoForward() ?: false,
                        isSecure
                    )
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val currentUrl = url ?: tab.url
                    val isSecure = currentUrl.startsWith("https://", ignoreCase = true)
                    onPageInfoChange(
                        view?.title ?: currentUrl,
                        currentUrl,
                        view?.canGoBack() ?: false,
                        view?.canGoForward() ?: false,
                        isSecure
                    )
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    // Critical security: Never automatically ignore SSL certificate errors
                    handler?.cancel()
                }
            }
        }
    }

    // Configure desktop mode user agent
    LaunchedEffect(tab.desktopMode) {
        val defaultUa = WebSettings.getDefaultUserAgent(context)
        if (tab.desktopMode) {
            webView.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        } else {
            webView.settings.userAgentString = defaultUa
        }
    }

    // Handle incoming UI actions (Back, Forward, Reload, etc.)
    LaunchedEffect(pendingAction) {
        if (pendingAction != null) {
            when (pendingAction) {
                is WebViewAction.LoadUrl -> {
                    if (pendingAction.url.isNotBlank() && pendingAction.url != "about:blank") {
                        webView.loadUrl(pendingAction.url)
                    }
                }
                is WebViewAction.GoBack -> {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    }
                }
                is WebViewAction.GoForward -> {
                    if (webView.canGoForward()) {
                        webView.goForward()
                    }
                }
                is WebViewAction.Reload -> {
                    webView.reload()
                }
                is WebViewAction.StopLoading -> {
                    webView.stopLoading()
                }
                is WebViewAction.SetDesktopMode -> {
                    val ua = if (pendingAction.enabled) {
                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                    } else {
                        WebSettings.getDefaultUserAgent(context)
                    }
                    webView.settings.userAgentString = ua
                    webView.reload()
                }
                is WebViewAction.ExtractReadingContent -> {
                    // Extract page title and article paragraphs using JavaScript
                    val js = """
                        (function() {
                            var title = document.title || '';
                            var article = document.querySelector('article') || document.querySelector('main') || document.body;
                            var paragraphs = article ? article.querySelectorAll('p, h1, h2, h3, blockquote') : [];
                            var textArr = [];
                            for (var i = 0; i < paragraphs.length; i++) {
                                var txt = paragraphs[i].innerText.trim();
                                if (txt.length > 20) {
                                    textArr.push(txt);
                                }
                            }
                            return JSON.stringify({ title: title, content: textArr.join('\n\n') });
                        })();
                    """.trimIndent()
                    webView.evaluateJavascript(js) { result ->
                        try {
                            if (result != null && result != "null") {
                                // Basic unescape of JSON string response
                                val cleaned = result.removeSurrounding("\"")
                                    .replace("\\n", "\n")
                                    .replace("\\\"", "\"")
                                    .replace("\\\\", "\\")
                                onReadingContentReady(webView.title ?: "المقال", cleaned)
                            } else {
                                onReadingContentReady(webView.title ?: "المقال", "")
                            }
                        } catch (_: Exception) {
                            onReadingContentReady(webView.title ?: "المقال", "")
                        }
                    }
                }
            }
            onActionConsumed()
        }
    }

    DisposableEffect(tab.id) {
        onDispose {
            if (tab.isPrivate) {
                webView.clearCache(true)
                webView.clearFormData()
                webView.clearHistory()
            }
        }
    }

    AndroidView(
        factory = { webView },
        modifier = modifier.fillMaxSize()
    )
}
