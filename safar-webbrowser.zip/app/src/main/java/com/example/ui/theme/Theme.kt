package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SafarTealLight,
    onPrimary = SafarInkDark,
    primaryContainer = SafarTealAccent,
    onPrimaryContainer = SafarTextPrimaryDark,
    secondary = SafarBronzeAccent,
    onSecondary = SafarInkDark,
    background = SafarInkDark,
    onBackground = SafarTextPrimaryDark,
    surface = SafarSurfaceDark,
    onSurface = SafarTextPrimaryDark,
    surfaceVariant = SafarSurfaceElevatedDark,
    onSurfaceVariant = SafarTextSecondaryDark,
    outline = SafarBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = SafarTealAccent,
    onPrimary = SafarSurfaceLight,
    primaryContainer = SafarTealLight,
    onPrimaryContainer = SafarInkDark,
    secondary = SafarBronzeAccent,
    onSecondary = SafarSurfaceLight,
    background = SafarPaperLight,
    onBackground = SafarTextPrimaryLight,
    surface = SafarSurfaceLight,
    onSurface = SafarTextPrimaryLight,
    surfaceVariant = SafarSurfaceElevatedLight,
    onSurfaceVariant = SafarTextSecondaryLight,
    outline = SafarBorderLight
)

@Composable
fun SafarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set false to prioritize SAFAR's bespoke Arabic identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
