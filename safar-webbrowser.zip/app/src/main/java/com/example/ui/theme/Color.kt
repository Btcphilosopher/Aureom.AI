package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SAFAR Arabic-First Signature Palette
// Dark mode: Deep ink, graphite, and midnight navy with restrained teal and warm bronze
val SafarInkDark = Color(0xFF0A1118)
val SafarSurfaceDark = Color(0xFF131D27)
val SafarSurfaceElevatedDark = Color(0xFF1A2634)
val SafarBorderDark = Color(0xFF263545)
val SafarTealAccent = Color(0xFF1E8278)
val SafarTealLight = Color(0xFF38B2A3)
val SafarBronzeAccent = Color(0xFFC9985E)
val SafarTextPrimaryDark = Color(0xFFF1F5F9)
val SafarTextSecondaryDark = Color(0xFF94A3B8)

// Light mode: Warm ivory and paper white with deep ink accents
val SafarPaperLight = Color(0xFFFAF8F5)
val SafarSurfaceLight = Color(0xFFFFFFFF)
val SafarSurfaceElevatedLight = Color(0xFFF1EDE6)
val SafarBorderLight = Color(0xFFE2DCD5)
val SafarTextPrimaryLight = Color(0xFF15222E)
val SafarTextSecondaryLight = Color(0xFF5D6B78)

val SafarSuccess = Color(0xFF2E7D32)
val SafarWarning = Color(0xFFED6C02)
val SafarDanger = Color(0xFFD32F2F)
