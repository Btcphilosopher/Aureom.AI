package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.model.SafarStrings
import com.example.ui.theme.SafarBronzeAccent
import com.example.ui.theme.SafarDanger
import com.example.ui.theme.SafarSuccess
import com.example.ui.theme.SafarTealAccent
import com.example.util.ArabicTextHelper
import com.example.util.UrlUtils

@Composable
fun BrowserTopBar(
    tab: BrowserTab,
    isArabic: Boolean,
    tabCount: Int,
    isBookmarked: Boolean,
    onNavigate: (String) -> Unit,
    onReload: () -> Unit,
    onStop: () -> Unit,
    onGoBack: () -> Unit,
    onGoForward: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenTabsManager: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivacyInfo: () -> Unit,
    onTranslate: () -> Unit,
    onReadingMode: () -> Unit,
    onToggleDesktopMode: () -> Unit,
    onGoHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditing by remember { mutableStateOf(false) }
    var urlInput by remember(tab.url) {
        mutableStateOf(if (tab.url == "about:blank") "" else tab.url)
    }
    var showMenu by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Navigation controls
                IconButton(
                    onClick = onGoBack,
                    enabled = tab.canGoBack,
                    modifier = Modifier.size(40.dp).testTag("button_back")
                ) {
                    Icon(
                        imageVector = if (isArabic) Icons.AutoMirrored.Filled.ArrowForward else Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = if (tab.canGoBack) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(
                    onClick = onGoForward,
                    enabled = tab.canGoForward,
                    modifier = Modifier.size(40.dp).testTag("button_forward")
                ) {
                    Icon(
                        imageVector = if (isArabic) Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Forward",
                        tint = if (tab.canGoForward) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                    )
                }

                // Smart Address & Omnibox Bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                ) {
                    if (isEditing) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            placeholder = {
                                Text(
                                    text = SafarStrings.searchOrUrl(isArabic),
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    if (urlInput.isNotBlank()) {
                                        onNavigate(urlInput)
                                        isEditing = false
                                        focusManager.clearFocus()
                                    }
                                }
                            ),
                            trailingIcon = {
                                if (urlInput.isNotEmpty()) {
                                    IconButton(onClick = { urlInput = "" }) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Clear",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SafarTealAccent,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .focusRequester(focusRequester)
                                .onFocusChanged { state ->
                                    if (!state.isFocused && !state.hasFocus) {
                                        isEditing = false
                                    }
                                }
                                .testTag("address_bar_input")
                        )
                    } else {
                        // Display Mode Bar
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .clickable {
                                    isEditing = true
                                    urlInput = if (tab.url == "about:blank") "" else tab.url
                                }
                                .testTag("address_bar_display")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp)
                            ) {
                                // Security / Status Icon
                                if (tab.isPrivate) {
                                    Icon(
                                        Icons.Default.Shield,
                                        contentDescription = "Private",
                                        tint = SafarBronzeAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else if (UrlUtils.isHttps(tab.url)) {
                                    Icon(
                                        Icons.Default.Lock,
                                        contentDescription = "Secure",
                                        tint = SafarSuccess,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { onOpenPrivacyInfo() }
                                    )
                                } else if (tab.url.startsWith("http://")) {
                                    Icon(
                                        Icons.Default.Security,
                                        contentDescription = "Not Secure",
                                        tint = SafarDanger,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = "Search",
                                        tint = SafarTealAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Domain / Title Display with Bidi Isolation
                                val displayDomain = if (tab.url == "about:blank") {
                                    SafarStrings.searchOrUrl(isArabic)
                                } else {
                                    ArabicTextHelper.isolateBidiUrl(UrlUtils.extractDomain(tab.url))
                                }

                                Text(
                                    text = displayDomain,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (tab.url == "about:blank") MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )

                                // Reload / Stop button
                                if (tab.isLoading) {
                                    IconButton(
                                        onClick = onStop,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Stop",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else {
                                    IconButton(
                                        onClick = onReload,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Refresh,
                                            contentDescription = "Reload",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bookmark action
                IconButton(
                    onClick = onToggleBookmark,
                    modifier = Modifier.size(40.dp).testTag("button_bookmark")
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (isBookmarked) SafarBronzeAccent else MaterialTheme.colorScheme.onSurface
                    )
                }

                // Tabs counter badge
                BadgedBox(
                    badge = {
                        Badge(
                            containerColor = SafarTealAccent,
                            contentColor = Color.White
                        ) {
                            Text(text = tabCount.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.padding(horizontal = 2.dp)
                ) {
                    IconButton(
                        onClick = onOpenTabsManager,
                        modifier = Modifier.size(40.dp).testTag("button_tabs_manager")
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.onSurface),
                            color = Color.Transparent,
                            modifier = Modifier.size(20.dp)
                        ) {}
                    }
                }

                // Menu
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(40.dp).testTag("button_menu")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                    ) {
                        DropdownMenuItem(
                            text = { Text(SafarStrings.home(isArabic)) },
                            onClick = {
                                showMenu = false
                                onGoHome()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.newTab(isArabic)) },
                            onClick = {
                                showMenu = false
                                onOpenTabsManager()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.bookmarks(isArabic)) },
                            onClick = {
                                showMenu = false
                                onOpenBookmarks()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.history(isArabic)) },
                            onClick = {
                                showMenu = false
                                onOpenHistory()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.readingMode(isArabic)) },
                            onClick = {
                                showMenu = false
                                onReadingMode()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.translatePage(isArabic)) },
                            onClick = {
                                showMenu = false
                                onTranslate()
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (tab.desktopMode)
                                        (if (isArabic) "إصدار الهاتف" else "Mobile Site")
                                    else
                                        SafarStrings.desktopSite(isArabic)
                                )
                            },
                            onClick = {
                                showMenu = false
                                onToggleDesktopMode()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.privacyShield(isArabic)) },
                            onClick = {
                                showMenu = false
                                onOpenPrivacyInfo()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(SafarStrings.settings(isArabic)) },
                            onClick = {
                                showMenu = false
                                onOpenSettings()
                            }
                        )
                    }
                }
            }

            // Progress bar
            AnimatedVisibility(visible = tab.isLoading && tab.progress > 0 && tab.progress < 100) {
                LinearProgressIndicator(
                    progress = { tab.progress / 100f },
                    color = SafarTealAccent,
                    trackColor = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp)
                )
            }
        }
    }
}
