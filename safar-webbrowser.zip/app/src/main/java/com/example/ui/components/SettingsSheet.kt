package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.BrowserSettings
import com.example.model.SafarStrings
import com.example.model.SearchEngine
import com.example.ui.theme.SafarTealAccent

@Composable
fun SettingsSheet(
    settings: BrowserSettings,
    isArabic: Boolean,
    onUpdateSettings: (BrowserSettings) -> Unit,
    onToggleLanguage: () -> Unit,
    onCloseSheet: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = SafarStrings.settings(isArabic),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = onCloseSheet,
                    modifier = Modifier.size(36.dp).testTag("close_settings_sheet")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp)
            ) {
                // Language Selection
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isArabic) "لغة الواجهة (Interface Language)" else "Interface Language",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SafarTealAccent
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column {
                            AppLanguage.entries.forEach { lang ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (settings.language != lang) onToggleLanguage()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    RadioButton(
                                        selected = settings.language == lang,
                                        onClick = {
                                            if (settings.language != lang) onToggleLanguage()
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = SafarTealAccent)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${lang.titleAr} (${lang.titleEn})",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // Default Search Engine
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = if (isArabic) "محرك البحث الافتراضي" else "Default Search Engine",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SafarTealAccent
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column {
                            SearchEngine.entries.forEach { engine ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onUpdateSettings(settings.copy(searchEngine = engine))
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    RadioButton(
                                        selected = settings.searchEngine == engine,
                                        onClick = {
                                            onUpdateSettings(settings.copy(searchEngine = engine))
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = SafarTealAccent)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isArabic) engine.displayNameAr else engine.displayNameEn,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // Privacy and Security Controls
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = if (isArabic) "الخصوصية والأمان" else "Privacy & Security",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SafarTealAccent
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            // Ad-Block & Tracker Protection
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = SafarStrings.trackersBlocked(isArabic),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = if (isArabic) "منع مواقع التتبع وملفات تعريف الارتباط الخارجية" else "Block tracking domains and third-party cookies",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = settings.adBlockEnabled,
                                    onCheckedChange = { onUpdateSettings(settings.copy(adBlockEnabled = it)) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = SafarTealAccent)
                                )
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                            // Do Not Track Header
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isArabic) "إرسال طلب عدم التتبع (Do Not Track)" else "Send Do Not Track request",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Switch(
                                    checked = settings.doNotTrack,
                                    onCheckedChange = { onUpdateSettings(settings.copy(doNotTrack = it)) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = SafarTealAccent)
                                )
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                            // HTTPS-Only Warning
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isArabic) "تفضيل الاتصال الآمن (HTTPS-Only)" else "HTTPS-Only mode",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Switch(
                                    checked = settings.httpsOnlyMode,
                                    onCheckedChange = { onUpdateSettings(settings.copy(httpsOnlyMode = it)) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = SafarTealAccent)
                                )
                            }
                        }
                    }
                }

                // About SAFAR
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "سَفَر (SAFAR) v1.0",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SafarTealAccent
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = SafarStrings.aboutDesc(isArabic),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
