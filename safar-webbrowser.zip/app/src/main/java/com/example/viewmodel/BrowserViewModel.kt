package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookmarkEntity
import com.example.data.local.HistoryEntity
import com.example.data.local.SafarDatabase
import com.example.data.local.ShortcutEntity
import com.example.data.repository.BrowserRepository
import com.example.model.AppLanguage
import com.example.model.BrowserSettings
import com.example.model.BrowserSheetType
import com.example.model.BrowserTab
import com.example.model.SearchEngine
import com.example.util.UrlUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class BrowserViewModel(
    application: Application,
    private val repository: BrowserRepository
) : AndroidViewModel(application) {

    // User settings - defined first so other properties can read safely
    private val _settings = MutableStateFlow(BrowserSettings())
    val settings: StateFlow<BrowserSettings> = _settings.asStateFlow()

    // Flow of persistent data
    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryEntity>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shortcuts: StateFlow<List<ShortcutEntity>> = repository.shortcuts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tabs state
    private val _tabs = MutableStateFlow<List<BrowserTab>>(listOf(
        BrowserTab(
            id = UUID.randomUUID().toString(),
            title = "صفحة جديدة",
            url = "about:blank",
            isPrivate = false
        )
    ))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(_tabs.value.first().id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    // Active sheet/dialog
    private val _activeSheet = MutableStateFlow<BrowserSheetType>(BrowserSheetType.None)
    val activeSheet: StateFlow<BrowserSheetType> = _activeSheet.asStateFlow()

    // Notification message (Snackbar)
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Action triggers for active WebView
    private val _webViewAction = MutableStateFlow<WebViewAction?>(null)
    val webViewAction: StateFlow<WebViewAction?> = _webViewAction.asStateFlow()

    fun clearWebViewAction() {
        _webViewAction.value = null
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun getActiveTab(): BrowserTab? {
        return _tabs.value.find { it.id == _activeTabId.value }
    }

    fun openNewTab(url: String = "about:blank", isPrivate: Boolean = false) {
        val newTab = BrowserTab(
            id = UUID.randomUUID().toString(),
            title = if (url == "about:blank") {
                if (_settings.value.language == AppLanguage.ARABIC) "صفحة جديدة" else "New Tab"
            } else {
                url
            },
            url = url,
            isPrivate = isPrivate
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
        _activeSheet.value = BrowserSheetType.None
    }

    fun selectTab(tabId: String) {
        _activeTabId.value = tabId
        _activeSheet.value = BrowserSheetType.None
    }

    fun closeTab(tabId: String) {
        val currentList = _tabs.value
        if (currentList.size <= 1) {
            // Keep at least one tab open
            val freshTab = BrowserTab(
                id = UUID.randomUUID().toString(),
                title = if (_settings.value.language == AppLanguage.ARABIC) "صفحة جديدة" else "New Tab",
                url = "about:blank",
                isPrivate = false
            )
            _tabs.value = listOf(freshTab)
            _activeTabId.value = freshTab.id
            return
        }

        val indexToRemove = currentList.indexOfFirst { it.id == tabId }
        val updated = currentList.filterNot { it.id == tabId }
        _tabs.value = updated

        if (_activeTabId.value == tabId) {
            val newIndex = (indexToRemove.coerceAtMost(updated.size - 1)).coerceAtLeast(0)
            _activeTabId.value = updated[newIndex].id
        }
    }

    fun updateActiveTabProgress(progress: Int, isLoading: Boolean) {
        val currentId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == currentId) it.copy(progress = progress, isLoading = isLoading) else it
        }
    }

    fun updateActiveTabInfo(title: String, url: String, canGoBack: Boolean, canGoForward: Boolean, isSecure: Boolean) {
        val currentId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == currentId) {
                it.copy(
                    title = if (title.isBlank() && url != "about:blank") UrlUtils.extractDomain(url) else title,
                    url = url,
                    canGoBack = canGoBack,
                    canGoForward = canGoForward,
                    isSecure = isSecure
                )
            } else it
        }

        val active = getActiveTab()
        // Save to history only if not private and not about:blank
        if (active != null && !active.isPrivate && url.isNotBlank() && url != "about:blank") {
            viewModelScope.launch {
                repository.recordHistory(title = title, url = url)
            }
        }
    }

    fun navigateTo(input: String) {
        val parsedUrl = UrlUtils.parseInputOrSearch(input, _settings.value.searchEngine)
        val currentId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == currentId) it.copy(url = parsedUrl, isLoading = true, progress = 10) else it
        }
        _webViewAction.value = WebViewAction.LoadUrl(parsedUrl)
    }

    fun goBack() {
        _webViewAction.value = WebViewAction.GoBack
    }

    fun goForward() {
        _webViewAction.value = WebViewAction.GoForward
    }

    fun reload() {
        _webViewAction.value = WebViewAction.Reload
    }

    fun stopLoading() {
        _webViewAction.value = WebViewAction.StopLoading
    }

    fun goHome() {
        val currentId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == currentId) it.copy(
                url = "about:blank",
                title = if (_settings.value.language == AppLanguage.ARABIC) "صفحة جديدة" else "New Tab"
            ) else it
        }
        _webViewAction.value = WebViewAction.LoadUrl("about:blank")
    }

    fun toggleDesktopMode() {
        val currentId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == currentId) {
                val newMode = !it.desktopMode
                _webViewAction.value = WebViewAction.SetDesktopMode(newMode)
                it.copy(desktopMode = newMode)
            } else it
        }
    }

    fun toggleBookmarkCurrentPage() {
        val active = getActiveTab() ?: return
        if (active.url.isBlank() || active.url == "about:blank") return

        viewModelScope.launch {
            val isBookmarked = repository.isBookmarked(active.url)
            if (isBookmarked) {
                // Remove
                val currentBookmarks = bookmarks.value
                val existing = currentBookmarks.find { it.url == active.url }
                if (existing != null) {
                    repository.removeBookmark(existing)
                    _statusMessage.value = if (_settings.value.language == AppLanguage.ARABIC) "تم حذف الإشارة المرجعية" else "Bookmark removed"
                }
            } else {
                repository.addBookmark(
                    title = active.title.ifBlank { UrlUtils.extractDomain(active.url) },
                    url = active.url
                )
                _statusMessage.value = if (_settings.value.language == AppLanguage.ARABIC) "تمت إضافة الإشارة المرجعية" else "Bookmark saved"
            }
        }
    }

    fun deleteBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch {
            repository.removeBookmark(bookmark)
        }
    }

    fun clearAllBookmarks() {
        viewModelScope.launch {
            repository.clearAllBookmarks()
        }
    }

    fun deleteHistory(historyEntity: HistoryEntity) {
        viewModelScope.launch {
            repository.removeHistory(historyEntity)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _statusMessage.value = if (_settings.value.language == AppLanguage.ARABIC) "تم مسح سجل التصفح" else "History cleared"
        }
    }

    fun addShortcut(title: String, url: String, emoji: String) {
        viewModelScope.launch {
            repository.addShortcut(title, url, emoji)
            _activeSheet.value = BrowserSheetType.None
        }
    }

    fun removeShortcut(id: Long) {
        viewModelScope.launch {
            repository.removeShortcut(id)
        }
    }

    fun showSheet(sheetType: BrowserSheetType) {
        _activeSheet.value = sheetType
    }

    fun closeSheet() {
        _activeSheet.value = BrowserSheetType.None
    }

    fun updateSettings(newSettings: BrowserSettings) {
        _settings.value = newSettings
    }

    fun updateSearchEngine(engine: SearchEngine) {
        _settings.value = _settings.value.copy(searchEngine = engine)
    }

    fun toggleLanguage() {
        val newLang = if (_settings.value.language == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        _settings.value = _settings.value.copy(language = newLang)
    }

    fun triggerTranslationToArabic() {
        val active = getActiveTab() ?: return
        if (active.url.isNotBlank() && active.url != "about:blank") {
            val translateUrl = "https://translate.google.com/translate?sl=auto&tl=ar&u=${java.net.URLEncoder.encode(active.url, "UTF-8")}"
            _webViewAction.value = WebViewAction.LoadUrl(translateUrl)
            _statusMessage.value = if (_settings.value.language == AppLanguage.ARABIC) "جاري ترجمة الصفحة إلى العربية..." else "Translating page to Arabic..."
        }
    }

    fun requestReadingMode() {
        _webViewAction.value = WebViewAction.ExtractReadingContent
    }

    fun onReadingContentExtracted(title: String, content: String) {
        if (content.isNotBlank()) {
            _activeSheet.value = BrowserSheetType.ReadingMode(title = title, textContent = content)
        } else {
            _statusMessage.value = if (_settings.value.language == AppLanguage.ARABIC) "تعذّر استخراج محتوى المقال" else "Unable to extract article text"
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = SafarDatabase.getDatabase(application)
                    val repo = BrowserRepository(
                        bookmarkDao = db.bookmarkDao(),
                        historyDao = db.historyDao(),
                        shortcutDao = db.shortcutDao()
                    )
                    return BrowserViewModel(application, repo) as T
                }
            }
    }
}

sealed interface WebViewAction {
    data class LoadUrl(val url: String) : WebViewAction
    data object GoBack : WebViewAction
    data object GoForward : WebViewAction
    data object Reload : WebViewAction
    data object StopLoading : WebViewAction
    data class SetDesktopMode(val enabled: Boolean) : WebViewAction
    data object ExtractReadingContent : WebViewAction
}
