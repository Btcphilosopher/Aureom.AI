package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppLanguage
import com.example.model.BrowserSheetType
import com.example.ui.components.AddShortcutDialog
import com.example.ui.components.BookmarksSheet
import com.example.ui.components.BrowserHomeScreen
import com.example.ui.components.BrowserTopBar
import com.example.ui.components.BrowserWebView
import com.example.ui.components.HistorySheet
import com.example.ui.components.PrivacyInfoDialog
import com.example.ui.components.ReadingModeSheet
import com.example.ui.components.SettingsSheet
import com.example.ui.components.TabsManagerSheet
import com.example.ui.theme.SafarTheme
import com.example.viewmodel.BrowserViewModel

class MainActivity : ComponentActivity() {

    private val browserViewModel: BrowserViewModel by viewModels {
        BrowserViewModel.provideFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle URL from external Intent (e.g., VIEW intent)
        intent?.data?.toString()?.let { incomingUrl ->
            if (incomingUrl.isNotBlank()) {
                browserViewModel.navigateTo(incomingUrl)
            }
        }

        setContent {
            val settings by browserViewModel.settings.collectAsStateWithLifecycle()
            val isArabic = settings.language == AppLanguage.ARABIC
            val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

            // Native RTL LayoutDirection applied globally to all SAFAR interface components
            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                SafarTheme {
                    SafarBrowserApp(viewModel = browserViewModel, isArabic = isArabic)
                }
            }
        }
    }
}

@Composable
fun SafarBrowserApp(
    viewModel: BrowserViewModel,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val activeTab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
    val activeSheet by viewModel.activeSheet.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val shortcuts by viewModel.shortcuts.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val webViewAction by viewModel.webViewAction.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Predictive back handler
    BackHandler(enabled = activeSheet !is BrowserSheetType.None || (activeTab != null && (activeTab.canGoBack || activeTab.url != "about:blank"))) {
        when {
            activeSheet !is BrowserSheetType.None -> {
                viewModel.closeSheet()
            }
            activeTab != null && activeTab.canGoBack -> {
                viewModel.goBack()
            }
            activeTab != null && activeTab.url != "about:blank" -> {
                viewModel.goHome()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (activeTab != null) {
                val isBookmarked = bookmarks.any { it.url == activeTab.url }
                BrowserTopBar(
                    tab = activeTab,
                    isArabic = isArabic,
                    tabCount = tabs.size,
                    isBookmarked = isBookmarked,
                    onNavigate = { input -> viewModel.navigateTo(input) },
                    onReload = { viewModel.reload() },
                    onStop = { viewModel.stopLoading() },
                    onGoBack = { viewModel.goBack() },
                    onGoForward = { viewModel.goForward() },
                    onToggleBookmark = { viewModel.toggleBookmarkCurrentPage() },
                    onOpenTabsManager = { viewModel.showSheet(BrowserSheetType.TabsManager) },
                    onOpenBookmarks = { viewModel.showSheet(BrowserSheetType.Bookmarks) },
                    onOpenHistory = { viewModel.showSheet(BrowserSheetType.History) },
                    onOpenSettings = { viewModel.showSheet(BrowserSheetType.Settings) },
                    onOpenPrivacyInfo = { viewModel.showSheet(BrowserSheetType.PrivacyInfo) },
                    onTranslate = { viewModel.triggerTranslationToArabic() },
                    onReadingMode = { viewModel.requestReadingMode() },
                    onToggleDesktopMode = { viewModel.toggleDesktopMode() },
                    onGoHome = { viewModel.goHome() }
                )
            }
        },
        modifier = modifier.fillMaxSize().imePadding()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Browser Web or Home View
            if (activeTab != null) {
                if (activeTab.url == "about:blank") {
                    BrowserHomeScreen(
                        isArabic = isArabic,
                        shortcuts = shortcuts,
                        settings = settings,
                        isPrivate = activeTab.isPrivate,
                        onNavigate = { input -> viewModel.navigateTo(input) },
                        onAddShortcutClick = { viewModel.showSheet(BrowserSheetType.QuickAccessAdd) },
                        onOpenPrivacyInfo = { viewModel.showSheet(BrowserSheetType.PrivacyInfo) }
                    )
                } else {
                    BrowserWebView(
                        tab = activeTab,
                        adBlockEnabled = settings.adBlockEnabled,
                        javaScriptEnabled = settings.javaScriptEnabled,
                        pendingAction = webViewAction,
                        onActionConsumed = { viewModel.clearWebViewAction() },
                        onProgressChange = { progress, isLoading ->
                            viewModel.updateActiveTabProgress(progress, isLoading)
                        },
                        onPageInfoChange = { title, url, canBack, canForward, isSecure ->
                            viewModel.updateActiveTabInfo(title, url, canBack, canForward, isSecure)
                        },
                        onReadingContentReady = { title, content ->
                            viewModel.onReadingContentExtracted(title, content)
                        }
                    )
                }
            }

            // Sheets & Dialogs Layer
            when (val sheet = activeSheet) {
                is BrowserSheetType.TabsManager -> {
                    TabsManagerSheet(
                        tabs = tabs,
                        activeTabId = activeTabId,
                        isArabic = isArabic,
                        onSelectTab = { tabId -> viewModel.selectTab(tabId) },
                        onCloseTab = { tabId -> viewModel.closeTab(tabId) },
                        onNewTab = { isPrivate -> viewModel.openNewTab(isPrivate = isPrivate) },
                        onCloseSheet = { viewModel.closeSheet() }
                    )
                }
                is BrowserSheetType.Bookmarks -> {
                    BookmarksSheet(
                        bookmarks = bookmarks,
                        isArabic = isArabic,
                        onNavigate = { url ->
                            viewModel.navigateTo(url)
                            viewModel.closeSheet()
                        },
                        onDeleteBookmark = { bookmark -> viewModel.deleteBookmark(bookmark) },
                        onClearAll = { viewModel.clearAllBookmarks() },
                        onCloseSheet = { viewModel.closeSheet() }
                    )
                }
                is BrowserSheetType.History -> {
                    HistorySheet(
                        historyList = history,
                        isArabic = isArabic,
                        onNavigate = { url ->
                            viewModel.navigateTo(url)
                            viewModel.closeSheet()
                        },
                        onDeleteHistory = { historyEntity -> viewModel.deleteHistory(historyEntity) },
                        onClearAll = { viewModel.clearHistory() },
                        onCloseSheet = { viewModel.closeSheet() }
                    )
                }
                is BrowserSheetType.Settings -> {
                    SettingsSheet(
                        settings = settings,
                        isArabic = isArabic,
                        onUpdateSettings = { newSettings -> viewModel.updateSettings(newSettings) },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onCloseSheet = { viewModel.closeSheet() }
                    )
                }
                is BrowserSheetType.QuickAccessAdd -> {
                    AddShortcutDialog(
                        isArabic = isArabic,
                        onDismiss = { viewModel.closeSheet() },
                        onAdd = { title, url, emoji -> viewModel.addShortcut(title, url, emoji) }
                    )
                }
                is BrowserSheetType.PrivacyInfo -> {
                    if (activeTab != null) {
                        PrivacyInfoDialog(
                            tab = activeTab,
                            isArabic = isArabic,
                            onDismiss = { viewModel.closeSheet() }
                        )
                    }
                }
                is BrowserSheetType.ReadingMode -> {
                    ReadingModeSheet(
                        title = sheet.title,
                        textContent = sheet.textContent,
                        isArabic = isArabic,
                        onCloseSheet = { viewModel.closeSheet() }
                    )
                }
                BrowserSheetType.None -> {
                    // No modal displayed
                }
            }
        }
    }
}
