package com.example.util

import com.example.model.AppLanguage

object ArabicTextHelper {
    /**
     * Determines whether text contains significant Arabic script
     */
    fun isArabic(text: String): Boolean {
        for (char in text) {
            val block = Character.UnicodeBlock.of(char)
            if (block == Character.UnicodeBlock.ARABIC ||
                block == Character.UnicodeBlock.ARABIC_SUPPLEMENT ||
                block == Character.UnicodeBlock.ARABIC_EXTENDED_A ||
                block == Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_A ||
                block == Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_B
            ) {
                return true
            }
        }
        return false
    }

    /**
     * Formats URLs and tech strings safely for display without corrupting bidirectional text
     */
    fun isolateBidiUrl(url: String): String {
        // Enclose with Left-To-Right Isolate (U+2066) and Pop Directional Isolate (U+2069)
        return "\u2066$url\u2069"
    }
}
