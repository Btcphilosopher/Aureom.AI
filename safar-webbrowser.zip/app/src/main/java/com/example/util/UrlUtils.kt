package com.example.util

import com.example.model.SearchEngine
import java.net.URI

object UrlUtils {
    /**
     * Parses an address bar input string. If it's a valid URL or domain, formats it as URL.
     * Otherwise formats it as a query using the given search engine.
     */
    fun parseInputOrSearch(input: String, searchEngine: SearchEngine): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "about:blank"

        // Handle internal URLs
        if (trimmed.equals("about:blank", ignoreCase = true) ||
            trimmed.startsWith("javascript:", ignoreCase = true)
        ) {
            return trimmed
        }

        // Already has scheme
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            return trimmed
        }

        // Check if it looks like a web domain (e.g. "example.com", "ar.wikipedia.org", "bbc.co.uk/news")
        val hasSpaces = trimmed.contains(" ")
        val looksLikeDomain = !hasSpaces && (
            trimmed.contains(".") &&
            !trimmed.startsWith(".") &&
            !trimmed.endsWith(".") &&
            trimmed.split(".").all { it.isNotEmpty() }
        )

        return if (looksLikeDomain) {
            "https://$trimmed"
        } else {
            searchEngine.buildSearchUrl(trimmed)
        }
    }

    /**
     * Extracts clean domain for display in address bar without Android-framework dependencies.
     */
    fun extractDomain(url: String): String {
        if (url.isBlank() || url == "about:blank") return ""
        return try {
            val uri = URI(if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url)
            uri.host ?: run {
                // Fallback extraction
                val withoutProtocol = url.substringAfter("://").substringBefore("/")
                withoutProtocol.substringBefore(":")
            }
        } catch (_: Exception) {
            val withoutProtocol = url.substringAfter("://").substringBefore("/")
            withoutProtocol.substringBefore(":")
        }
    }

    /**
     * Checks if the connection is HTTPS.
     */
    fun isHttps(url: String): Boolean {
        return url.startsWith("https://", ignoreCase = true)
    }
}
