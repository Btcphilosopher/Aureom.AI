package com.example.model

enum class SearchEngine(
    val id: String,
    val displayNameAr: String,
    val displayNameEn: String,
    val searchUrlTemplate: String,
    val suggestUrlTemplate: String? = null
) {
    GOOGLE(
        id = "google",
        displayNameAr = "جوجل (Google)",
        displayNameEn = "Google",
        searchUrlTemplate = "https://www.google.com/search?q={query}"
    ),
    DUCKDUCKGO(
        id = "duckduckgo",
        displayNameAr = "داك داك جو (DuckDuckGo - خصوصية)",
        displayNameEn = "DuckDuckGo (Privacy)",
        searchUrlTemplate = "https://duckduckgo.com/?q={query}"
    ),
    BING(
        id = "bing",
        displayNameAr = "بينج (Bing)",
        displayNameEn = "Bing",
        searchUrlTemplate = "https://www.bing.com/search?q={query}"
    ),
    WIKIPEDIA_AR(
        id = "wikipedia_ar",
        displayNameAr = "ويكيبيديا العربية",
        displayNameEn = "Arabic Wikipedia",
        searchUrlTemplate = "https://ar.wikipedia.org/wiki/Special:Search?search={query}"
    );

    fun buildSearchUrl(query: String): String {
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        return searchUrlTemplate.replace("{query}", encodedQuery)
    }

    companion object {
        fun fromId(id: String): SearchEngine {
            return entries.find { it.id == id } ?: DUCKDUCKGO
        }
    }
}
