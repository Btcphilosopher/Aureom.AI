package com.example.model

sealed interface BrowserSheetType {
    data object None : BrowserSheetType
    data object TabsManager : BrowserSheetType
    data object Bookmarks : BrowserSheetType
    data object History : BrowserSheetType
    data object Settings : BrowserSheetType
    data object QuickAccessAdd : BrowserSheetType
    data object PrivacyInfo : BrowserSheetType
    data class ReadingMode(val title: String, val textContent: String) : BrowserSheetType
}
