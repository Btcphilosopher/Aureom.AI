package com.example.model

enum class AppLanguage(val code: String, val titleAr: String, val titleEn: String) {
    ARABIC("ar", "العربية", "Arabic"),
    ENGLISH("en", "الإنجليزية", "English")
}

data class BrowserSettings(
    val searchEngine: SearchEngine = SearchEngine.DUCKDUCKGO,
    val language: AppLanguage = AppLanguage.ARABIC,
    val adBlockEnabled: Boolean = true,
    val javaScriptEnabled: Boolean = true,
    val doNotTrack: Boolean = true,
    val desktopModeDefault: Boolean = false,
    val showQuickAccess: Boolean = true,
    val readingFontSize: Int = 18,
    val clearDataOnExit: Boolean = false,
    val httpsOnlyMode: Boolean = true
)
