package com.example.model

object SafarStrings {
    // Top Bar & Controls
    fun searchOrUrl(isArabic: Boolean) = if (isArabic) "ابحث أو أدخل رابط موقع..." else "Search or enter web address..."
    fun newTab(isArabic: Boolean) = if (isArabic) "علامة تبويب جديدة" else "New Tab"
    fun tabs(isArabic: Boolean) = if (isArabic) "علامات التبويب" else "Tabs"
    fun bookmarks(isArabic: Boolean) = if (isArabic) "الإشارات المرجعية" else "Bookmarks"
    fun history(isArabic: Boolean) = if (isArabic) "سجل التصفح" else "History"
    fun settings(isArabic: Boolean) = if (isArabic) "الإعدادات" else "Settings"
    fun privateBrowsing(isArabic: Boolean) = if (isArabic) "التصفح الخاص" else "Private Browsing"
    fun exitPrivateBrowsing(isArabic: Boolean) = if (isArabic) "الخروج من التصفح الخاص" else "Exit Private Browsing"
    fun readingMode(isArabic: Boolean) = if (isArabic) "وضع القراءة" else "Reading Mode"
    fun translatePage(isArabic: Boolean) = if (isArabic) "ترجمة الصفحة إلى العربية" else "Translate to Arabic"
    fun reload(isArabic: Boolean) = if (isArabic) "إعادة التحميل" else "Reload"
    fun desktopSite(isArabic: Boolean) = if (isArabic) "إصدار سطح المكتب" else "Desktop Site"
    fun secureConnection(isArabic: Boolean) = if (isArabic) "الاتصال آمن ومشفّر (HTTPS)" else "Connection is secure (HTTPS)"
    fun insecureConnection(isArabic: Boolean) = if (isArabic) "الموقع غير آمن (HTTP)" else "Site is not secure (HTTP)"
    fun clearData(isArabic: Boolean) = if (isArabic) "حذف بيانات التصفح" else "Clear Browsing Data"
    fun home(isArabic: Boolean) = if (isArabic) "الصفحة الرئيسية" else "Home"
    fun share(isArabic: Boolean) = if (isArabic) "مشاركة الرابط" else "Share Link"
    fun copyUrl(isArabic: Boolean) = if (isArabic) "نسخ الرابط" else "Copy Link"
    fun bookmarkAdded(isArabic: Boolean) = if (isArabic) "تمت إضافة الإشارة المرجعية بنجاح" else "Bookmark added successfully"
    fun bookmarkRemoved(isArabic: Boolean) = if (isArabic) "تمت إزالة الإشارة المرجعية" else "Bookmark removed"
    fun clearAll(isArabic: Boolean) = if (isArabic) "مسح الكل" else "Clear All"
    fun quickAccess(isArabic: Boolean) = if (isArabic) "الوصول السريع" else "Quick Access"
    fun addShortcut(isArabic: Boolean) = if (isArabic) "إضافة اختصار" else "Add Shortcut"
    fun close(isArabic: Boolean) = if (isArabic) "إغلاق" else "Close"
    fun save(isArabic: Boolean) = if (isArabic) "حفظ" else "Save"
    fun cancel(isArabic: Boolean) = if (isArabic) "إلغاء" else "Cancel"
    fun delete(isArabic: Boolean) = if (isArabic) "حذف" else "Delete"
    fun title(isArabic: Boolean) = if (isArabic) "العنوان" else "Title"
    fun url(isArabic: Boolean) = if (isArabic) "الرابط" else "URL"
    fun privacyShield(isArabic: Boolean) = if (isArabic) "درع سَفَر للخصوصية" else "SAFAR Privacy Shield"
    fun trackersBlocked(isArabic: Boolean) = if (isArabic) "حظر التتبع والإعلانات المتطفلة" else "Block trackers & intrusive ads"
    fun privateModeExplainer(isArabic: Boolean) = if (isArabic)
        "أنت في وضع التصفح الخاص. لا يتم حفظ سجل التصفح أو ملفات تعريف الارتباط أو الإشارات المؤقتة."
    else
        "You are in Private Browsing. History, cookies, and temporary site data will not be saved."
    fun noHistory(isArabic: Boolean) = if (isArabic) "سجل التصفح فارغ" else "Browsing history is empty"
    fun noBookmarks(isArabic: Boolean) = if (isArabic) "لا توجد إشارات مرجعية محفوظة" else "No saved bookmarks yet"
    fun aboutSafar(isArabic: Boolean) = if (isArabic) "عن متصفح سَفَر" else "About SAFAR Browser"
    fun aboutDesc(isArabic: Boolean) = if (isArabic)
        "سَفَر هو متصفح ويب عربي أصيل مصمم لتقديم تجربة تصفح سريعة، آمنة، ومصممة خصيصاً للغة العربية واتجاه اليمين إلى اليسار (RTL)."
    else
        "SAFAR is a premier Arabic-first web browser engineered for fast, secure, and native RTL digital exploration."
}
