package com.example.model

data class BrowserTab(
    val id: String,
    val title: String = "صفحة جديدة",
    val url: String = "about:blank",
    val progress: Int = 0,
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isSecure: Boolean = false,
    val isPrivate: Boolean = false,
    val isPinned: Boolean = false,
    val desktopMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
