import concurrent.futures
import tempfile
import unittest
from pathlib import Path
import app

class CheckoutTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DB = Path(self.temp.name)/'test.db'
        app.init_db()
        self.body = {'customer':{'name':'Demo User','email':'demo@example.com','address':'1 Example Street'},'items':[{'id':1,'quantity':2}]}
    def tearDown(self):
        self.temp.cleanup()
    def test_server_price_and_retry(self):
        self.body['total']=1
        first = app.create_order(self.body,'checkout_key_0001')
        self.assertEqual(first['total'],4800)
        self.assertEqual(first,app.create_order(self.body,'checkout_key_0001'))
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0],28)
            self.assertEqual(db.execute('SELECT count(*) FROM orders').fetchone()[0],1)
        self.body['items'][0]['quantity']=3
        with self.assertRaises(app.InvalidOrder):app.create_order(self.body,'checkout_key_0001')
    def test_rollback(self):
        self.body['items'].append({'id':4,'quantity':99})
        with self.assertRaises(app.InvalidOrder):app.create_order(self.body,'checkout_key_0002')
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0],30)
            self.assertEqual(db.execute('SELECT count(*) FROM orders').fetchone()[0],0)
    def test_competing_orders(self):
        with app.connect() as db:db.execute('UPDATE products SET stock=2 WHERE id=1')
        def order(i):
            try:return app.create_order(self.body,f'concurrent_key_{i:04}')['id']
            except app.InvalidOrder:return None
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(order,[1,2]))
        self.assertEqual(sum(x is not None for x in results),1)
        with app.connect() as db:self.assertEqual(db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0],0)
    def test_validation(self):
        for bad in [0,-1,True,1.5,'2',100]:
            self.body['items'][0]['quantity']=bad
            with self.assertRaises(app.InvalidOrder):app.create_order(self.body,'checkout_key_0003')

if __name__ == '__main__':unittest.main()
