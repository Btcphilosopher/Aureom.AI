"""Local demo shop. Python 3.10+, standard library only."""
import hashlib
import json
import os
import re
import sqlite3
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get('SHOP_DB', str(ROOT / 'shop.db')))

def connect():
    db = sqlite3.connect(DB, timeout=10)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
          description TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>=0),
          stock INTEGER NOT NULL CHECK(stock>=0), icon TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS orders (
          id TEXT PRIMARY KEY, request_key TEXT UNIQUE NOT NULL,
          fingerprint TEXT NOT NULL, email TEXT NOT NULL, name TEXT NOT NULL,
          address TEXT NOT NULL, total INTEGER NOT NULL,
          items TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        ''')
        db.executemany('INSERT OR IGNORE INTO products VALUES (?,?,?,?,?,?,?)', [
            (1,'Everyday tote','Accessories','Heavy cotton. Made for the everyday.',2400,30,'◒'),
            (2,'Studio mug','Home','A generous ceramic mug in warm ivory.',1800,40,'◡'),
            (3,'Field notebook','Stationery','Lay-flat pages for your next good idea.',1200,50,'▤'),
            (4,'Desk lamp','Home','A compact light for considered spaces.',6500,12,'◠'),
            (5,'Travel bottle','Accessories','Insulated steel, ready to go.',2800,25,'▥'),
            (6,'Weekly planner','Stationery','A little structure for a busy week.',1600,35,'▦'),
        ])

class InvalidOrder(ValueError):
    pass

def create_order(body, key):
    if not isinstance(body, dict):
        raise InvalidOrder('Expected a JSON object.')
    if not re.fullmatch(r'[A-Za-z0-9_-]{16,100}', key):
        raise InvalidOrder('A valid Idempotency-Key is required.')
    customer = body.get('customer')
    items = body.get('items')
    if not isinstance(customer, dict) or not isinstance(items, list) or not 1 <= len(items) <= 50:
        raise InvalidOrder('Customer details and 1–50 items are required.')
    limits = {'name':100, 'email':254, 'address':500}
    details = {}
    for field, limit in limits.items():
        value = customer.get(field)
        if not isinstance(value, str) or not 1 <= len(value.strip()) <= limit:
            raise InvalidOrder('Check your ' + field + '.')
        details[field] = value.strip()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', details['email']):
        raise InvalidOrder('Enter a valid email address.')
    quantities = {}
    for item in items:
        if not isinstance(item, dict):
            raise InvalidOrder('Invalid item.')
        pid, qty = item.get('id'), item.get('quantity')
        if type(pid) is not int or type(qty) is not int or not 1 <= qty <= 99:
            raise InvalidOrder('Quantities must be whole numbers from 1 to 99.')
        quantities[pid] = quantities.get(pid, 0) + qty
        if quantities[pid] > 99:
            raise InvalidOrder('Maximum 99 of each item.')
    canonical = {'customer':details, 'items':sorted(quantities.items())}
    fingerprint = hashlib.sha256(json.dumps(canonical, sort_keys=True).encode()).hexdigest()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        previous = db.execute('SELECT * FROM orders WHERE request_key=?', (key,)).fetchone()
        if previous:
            if previous['fingerprint'] != fingerprint:
                raise InvalidOrder('This checkout key belongs to a different order.')
            return {'id':previous['id'], 'total':previous['total'], 'currency':'GBP', 'status':'demo_order_saved'}
        lines, total = [], 0
        for pid, qty in sorted(quantities.items()):
            product = db.execute('SELECT * FROM products WHERE id=?', (pid,)).fetchone()
            if product is None:
                raise InvalidOrder('A product no longer exists.')
            if product['stock'] < qty:
                raise InvalidOrder(product['name'] + ': insufficient stock. Refresh the catalogue.')
            total += product['price'] * qty
            lines.append({'id':pid, 'name':product['name'], 'quantity':qty, 'price':product['price']})
            db.execute('UPDATE products SET stock=stock-? WHERE id=?', (qty,pid))
        oid = str(uuid.uuid4())
        db.execute('INSERT INTO orders (id,request_key,fingerprint,email,name,address,total,items) VALUES (?,?,?,?,?,?,?,?)',
                   (oid,key,fingerprint,details['email'],details['name'],details['address'],total,json.dumps(lines)))
    return {'id':oid, 'total':total, 'currency':'GBP', 'status':'demo_order_saved'}

class Handler(BaseHTTPRequestHandler):
    def send(self, status, payload, content_type='application/json'):
        data = json.dumps(payload).encode() if content_type == 'application/json' else payload
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split('?',1)[0]
        if path == '/api/products':
            with connect() as db:
                products = [dict(row) for row in db.execute('SELECT * FROM products ORDER BY id')]
            return self.send(200, {'products':products,'currency':'GBP'})
        assets = {'/':('index.html','text/html; charset=utf-8'),
                  '/app.js':('app.js','text/javascript; charset=utf-8'),
                  '/style.css':('style.css','text/css; charset=utf-8')}
        if path not in assets:
            return self.send(404, {'error':'Not found'})
        name, kind = assets[path]
        self.send(200, (ROOT/'static'/name).read_bytes(), kind)

    def do_POST(self):
        if self.path != '/api/orders':
            return self.send(404, {'error':'Not found'})
        # Local demo: reject cross-origin submissions and unsupported content types.
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            return self.send(403, {'error':'Cross-site requests are not allowed.'})
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + self.headers.get('Host',''):
            return self.send(403, {'error':'Invalid origin.'})
        if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            return self.send(415, {'error':'Use application/json.'})
        try:
            length = int(self.headers.get('Content-Length','0'))
            if not 0 < length <= 16384:
                raise InvalidOrder('Request must be between 1 and 16384 bytes.')
            body = json.loads(self.rfile.read(length))
            result = create_order(body, self.headers.get('Idempotency-Key',''))
            self.send(201, result)
        except (ValueError, UnicodeError) as error:
            self.send(400, {'error':str(error) if isinstance(error,InvalidOrder) else 'Invalid request.'})
        except sqlite3.Error:
            self.send(503, {'error':'Database unavailable. Retry with the same checkout key.'})

if __name__ == '__main__':
    init_db()
    print('Open http://127.0.0.1:8000 — demo checkout; no payments collected.', flush=True)
    ThreadingHTTPServer(('127.0.0.1',8000), Handler).serve_forever()
