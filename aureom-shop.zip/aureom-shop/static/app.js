'use strict';
const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(n/100);
let products = [], category = 'All', cart = {}, pending = null;
try { cart = JSON.parse(localStorage.getItem('aureom-cart')) || {}; if(Array.isArray(cart)||typeof cart!=='object') cart={}; } catch { cart={}; }
function el(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;}
function save(){try{localStorage.setItem('aureom-cart',JSON.stringify(cart));}catch{}$('count').textContent=Object.values(cart).reduce((a,b)=>a+b,0);}
function change(id,delta){if(pending){$('checkout-message').textContent='Resolve the pending checkout before changing your bag.';return;}const p=products.find(p=>p.id===id);const qty=(cart[id]||0)+delta;if(qty>Math.min(p.stock,99))return;if(qty<=0)delete cart[id];else cart[id]=qty;save();renderCart();}
function render(){const term=$('search').value.toLowerCase();$('products').replaceChildren();const visible=products.filter(p=>(category==='All'||p.category===category)&&(p.name+' '+p.description).toLowerCase().includes(term));for(const p of visible){const card=el('article',undefined,'product');const art=el('div',p.icon,'product-art');art.setAttribute('aria-hidden','true');card.append(art,el('h3',p.name),el('p',p.description));const bottom=el('div',undefined,'product-bottom'),button=el('button',p.stock?'Add to bag +':'Sold out');button.disabled=!p.stock;button.onclick=()=>change(p.id,1);bottom.append(el('strong',money(p.price)),button);card.append(bottom);$('products').append(card);}$('status').textContent=visible.length?'':'No products match your search.';}
function renderCart(){const lines=$('cart-lines');lines.replaceChildren();let total=0;for(const [id,qty] of Object.entries(cart)){const p=products.find(p=>p.id===Number(id));if(!p)continue;total+=p.price*qty;const row=el('div',undefined,'cart-row'),name=el('div',p.name);name.append(el('small',money(p.price)+' each'));const controls=el('div',undefined,'cart-controls');for(const [text,delta,label] of [['−',-1,'Remove one '],['+',1,'Add one ']]){const b=el('button',text);b.setAttribute('aria-label',label+p.name);b.onclick=()=>change(p.id,delta);controls.append(b);if(delta===-1)controls.append(el('span',String(qty)));}row.append(name,controls);lines.append(row);}if(!Object.keys(cart).length)lines.append(el('p','Your bag is waiting for something good.'));$('total').textContent=money(total);$('place-order').disabled=!Object.keys(cart).length;}
async function load(){const response=await fetch('/api/products');if(!response.ok)throw Error('Could not load products. Please reload.');products=(await response.json()).products;for(const [id,qty] of Object.entries(cart)){if(!products.some(p=>p.id===Number(id))||!Number.isInteger(qty)||qty<1||qty>99)delete cart[id];}save();$('filters').replaceChildren();for(const c of ['All',...new Set(products.map(p=>p.category))]){const button=el('button',c);button.setAttribute('aria-pressed',String(category===c));button.onclick=()=>{category=c;for(const b of $('filters').children)b.setAttribute('aria-pressed',String(b===button));render();};$('filters').append(button);}render();renderCart();}
$('search').oninput=render;
$('open-cart').onclick=()=>{$('bag').showModal();renderCart();};
$('close-cart').onclick=()=>$('bag').close();
// Keep an uncertain checkout identity across reloads so retries cannot create another order.
try {
  pending = JSON.parse(sessionStorage.getItem('aureom-pending'));
  if (pending && (!pending.key || !pending.body?.customer || !Array.isArray(pending.body.items))) pending = null;
} catch { pending = null; }
function rememberPending() {
  if (pending) sessionStorage.setItem('aureom-pending', JSON.stringify(pending));
  else sessionStorage.removeItem('aureom-pending');
}
function lockCustomer(locked) {
  for (const field of $('checkout').querySelectorAll('input, textarea')) field.readOnly = locked;
}
if (pending) {
  for (const [name, value] of Object.entries(pending.body.customer)) {
    const field = $('checkout').elements.namedItem(name);
    if (field) field.value = value;
  }
  cart = Object.fromEntries(pending.body.items.map(item => [item.id, item.quantity]));
  lockCustomer(true);
  $('checkout-message').textContent = 'A previous checkout needs confirmation. Retry to check the same order.';
}
$('checkout').onsubmit = async event => {
  event.preventDefault();
  if (!Object.keys(cart).length) return;
  const button = $('place-order');
  button.disabled = true;
  try {
    if (!pending) {
      pending = {
        key: crypto.randomUUID(),
        body: {
          customer: Object.fromEntries(new FormData(event.target)),
          items: Object.entries(cart).map(([id, quantity]) => ({id: Number(id), quantity}))
        }
      };
      // Persist before sending; do not send if durable session storage is unavailable.
      try { rememberPending(); } catch {
        pending = null;
        throw Error('Session storage is required for safe checkout. Enable it and retry.');
      }
    }
    lockCustomer(true);
    $('checkout-message').textContent = 'Saving your demo order…';
    const response = await fetch('/api/orders', {
      method: 'POST',
      headers: {'Content-Type':'application/json', 'Idempotency-Key':pending.key},
      body: JSON.stringify(pending.body)
    });
    const data = await response.json();
    if (!response.ok) {
      if (response.status < 500) { pending = null; rememberPending(); lockCustomer(false); }
      throw Error(data.error || 'Checkout failed.');
    }
    cart = {};
    pending = null;
    rememberPending();
    save();
    lockCustomer(false);
    event.target.reset();
    $('checkout-message').textContent = 'Demo order ' + data.id.slice(0,8) + ' saved · ' + money(data.total) + '. No payment was taken.';
    renderCart();
    // Order success remains visible even if the catalogue refresh fails.
    load().catch(error => { $('status').textContent = error.message; });
  } catch (error) {
    $('checkout-message').textContent = error.message + (pending ? ' Retry to safely check the same order.' : '');
  } finally {
    button.disabled = !Object.keys(cart).length;
  }
};
load().catch(error => { $('status').textContent = error.message; });
