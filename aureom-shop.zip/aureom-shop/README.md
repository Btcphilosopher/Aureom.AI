# Aureom Goods — simple full-stack shop

A dependency-free starter you can run or give to Gemini 3.8 to extend.

## Run

Requires Python 3.10 or newer. From this folder:

```sh
python3 app.py
```

Open http://127.0.0.1:8000. The SQLite database is created automatically.

## Included

- Responsive HTML/CSS/JavaScript storefront, category filters and search.
- Local-storage cart, editable quantities and accessible modal checkout.
- Python JSON API, SQLite catalogue and persistent demo orders.
- Server-side prices, integer-pence totals, atomic stock deduction and checkout idempotency.
- No external dependencies, analytics, image downloads or paid APIs.

`GET /api/products` returns the catalogue. `POST /api/orders` accepts a customer object and items containing `id` and `quantity`, with an `Idempotency-Key` header. Prices supplied by a client are never used. Orders have status `demo_order_saved`, not paid.

Shipping is free in this demo; catalogue prices are final demo prices. No tax engine or payment processing is implemented.

## Test

```sh
python3 -m unittest -v
```

Tests cover price authority, duplicate-request safety, conflicting keys, transaction rollback, competing orders and invalid quantities.

## Files

- `app.py`: backend and database setup.
- `static/index.html`: storefront structure.
- `static/style.css`: responsive styling.
- `static/app.js`: catalogue, cart and checkout.
- `test_app.py`: backend tests.

## Scope

Local development/demo only. Checkout saves orders but takes no payments and sends no email. Use fictional details. The server intentionally binds to localhost. There are no customer accounts, admin authentication, returns, order lookup, fulfilment, tax calculation or shipping integrations.

Before real deployment, use a production web stack with HTTPS, authentication, rate limits, operational monitoring and backups. Integrate hosted payment checkout and authenticated webhooks; validate prices and stock again on the server and reconcile payment/order states. Do not collect card numbers in this form.

The cart survives reloads. Pending checkout identities are saved in session storage before submission so retries in the same browser tab, including after reload, reuse the same key. Keep that tab available when resolving a network error. Production payment checkout should additionally use a durable server-side checkout session.

Delete `shop.db` while the server is stopped to reset the demonstration stock and orders. Do not do this with data you need to keep.

## Suggested Gemini 3.8 follow-up

“Extend this existing project. Preserve server-authoritative prices, atomic inventory updates and idempotent order creation. Add authenticated administration and hosted payment checkout using a provider adapter. Keep payment confirmation separate from order creation, verify webhook signatures, add meaningful tests, and explain the setup. Do not claim payment support until it is implemented and verified.”

## Verification performed

All four backend tests passed, and `node --check static/app.js` passed. Automated browser testing could not run because this execution environment blocked Chromium from creating its process socket; the layout and end-to-end browser flow therefore remain unverified here.
