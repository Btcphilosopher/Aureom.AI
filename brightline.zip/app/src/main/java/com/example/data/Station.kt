package com.example.data

data class Station(
    val id: String,
    val name: String,
    val code: String,
    val address: String,
    val openingHours: String,
    val parking: String,
    val rideshare: String,
    val amenities: List<String>,
    val description: String
)

object StationData {
    val stations = listOf(
        Station(
            id = "miami",
            name = "MiamiCentral",
            code = "MIA",
            address = "600 NW 1st Ave, Miami, FL 33136",
            openingHours = "5:00 AM - 11:00 PM Daily",
            parking = "MiamiCentral Garage ($15/day). Electric vehicle charging stations available.",
            rideshare = "Dedicated Uber pickup zone at NW 1st Court entrance. Connect to Metrorail & Metromover.",
            amenities = listOf("Mary Mary Bar", "Citizens Culinary Center", "Premium Lounge", "Free Wi-Fi", "Charging Stations", "Baggage Service"),
            description = "Brightline's flagship terminal located in the heart of downtown Miami. A vibrant hub of retail, dining, and residences."
        ),
        Station(
            id = "aventura",
            name = "Aventura",
            code = "AVT",
            address = "19796 West Dixie Hwy, Aventura, FL 33180",
            openingHours = "6:00 AM - 10:30 PM Daily",
            parking = "Aventura Station Surface Lot ($10/day). Convenient pedestrian bridge directly to Aventura Mall.",
            rideshare = "Rideshare drop-off on West Dixie Hwy. Complimentary shuttle services to the shopping center.",
            amenities = listOf("Mary Mary Grab & Go", "Premium Lounge", "Wi-Fi", "Retail Shops", "Self-Serve Ticketing"),
            description = "Connected directly to the world-renowned Aventura Mall via a beautifully designed elevated pedestrian bridge."
        ),
        Station(
            id = "fort_lauderdale",
            name = "Fort Lauderdale",
            code = "FLL",
            address = "101 NW 2nd Ave, Fort Lauderdale, FL 33311",
            openingHours = "5:30 AM - 11:00 PM Daily",
            parking = "On-site multi-story parking garage ($12/day). Bicycle storage locker available.",
            rideshare = "Uber zone located on Browand Blvd. 5-minute walk to Riverwalk and downtown dining.",
            amenities = listOf("Mary Mary Bar", "Premium Lounge", "Luggage Lockers", "High-speed Wi-Fi", "Business Center"),
            description = "Just steps from Las Olas Boulevard, Riverwalk, and Broward Center for the Performing Arts."
        ),
        Station(
            id = "boca_raton",
            name = "Boca Raton",
            code = "BOC",
            address = "101 NW 4th St, Boca Raton, FL 33432",
            openingHours = "6:00 AM - 10:30 PM Daily",
            parking = "Surface parking lot and garage ($10/day). Walking distance to Mizner Park.",
            rideshare = "Pick up at main entrance. Shuttle service directly to Boca Raton beaches.",
            amenities = listOf("Grab & Go Market", "Premium Lounge", "Smart Lockers", "Bicycle Racks", "Free Wi-Fi"),
            description = "Centrally located next to Mizner Park, offering high-speed connections to Miami and Orlando for business and leisure."
        ),
        Station(
            id = "west_palm_beach",
            name = "West Palm Beach",
            code = "WPB",
            address = "501 S Rosemary Ave, West Palm Beach, FL 33401",
            openingHours = "5:30 AM - 11:00 PM Daily",
            parking = "Rosemary Square Garages ($15/day). Validation available for transit riders.",
            rideshare = "Rosemary Avenue main drop-off. Convenient trolley connect to downtown Clematis Street.",
            amenities = listOf("Mary Mary Bar", "Premium Lounge", "Meeting Rooms", "Free Wi-Fi", "Passenger Lounge"),
            description = "Located in the heart of West Palm Beach's bustling Rosemary Square, connecting you to fine dining and shopping."
        ),
        Station(
            id = "orlando",
            name = "Orlando",
            code = "ORL",
            address = "10705 Jeff Fuqua Blvd, Orlando, FL 32827 (Airport Terminal C)",
            openingHours = "4:30 AM - Midnight Daily",
            parking = "Orlando Airport Terminal C Parking Garage ($19/day). Valet parking available.",
            rideshare = "Ground transportation level 1 of Terminal C. Direct connection to Terminal Link shuttle for A & B.",
            amenities = listOf("Mary Mary Bar", "Premium Lounge", "Kids Play Area", "Baggage Check-In", "Conference Hub", "Orlando Theme Park Services"),
            description = "Located directly inside Orlando International Airport's new Terminal C. Your premium gateway to Central Florida's magic."
        )
    )
}
