package com.example.data

data class TransitPass(
    val title: String,
    val description: String,
    val ridesCount: String,
    val price: Int,
    val type: String // "SMART" or "PREMIUM"
)

object PassData {
    val passes = listOf(
        TransitPass("5-Ride Commuter Pass", "Perfect for weekly commuters. Valid for 30 days.", "5 Rides", 199, "SMART"),
        TransitPass("10-Ride Commuter Pass", "Best value for frequent riders. Save over 25%.", "10 Rides", 349, "SMART"),
        TransitPass("Monthly Unlimited Pass", "Unlimited travel between designated stations.", "Unlimited", 599, "SMART"),
        TransitPass("Premium 10-Ride Pass", "Settle into spacious seats & lounge access.", "10 Rides", 899, "PREMIUM"),
        TransitPass("Monthly Premium Pass", "Unlimited first-class travel with complimentary drinks.", "Unlimited", 1499, "PREMIUM")
    )
}
