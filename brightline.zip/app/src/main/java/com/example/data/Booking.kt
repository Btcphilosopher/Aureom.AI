package com.example.data

data class PassengerInfo(
    val firstName: String = "",
    val lastName: String = "",
    val email: String = "",
    val phone: String = "",
    val saveDetails: Boolean = false
)

data class BookedTrip(
    val bookingReference: String,
    val trainNumber: String,
    val originCode: String,
    val originName: String,
    val destinationCode: String,
    val destinationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val date: String,
    val seat: String,
    val coach: String,
    val passengerName: String,
    val fareType: String, // "SMART" or "PREMIUM"
    val price: Int,
    val extras: List<String> = emptyList(),
    val status: String = "CONFIRMED"
)
