package com.example.data

data class Train(
    val number: String,
    val originCode: String,
    val originName: String,
    val destinationCode: String,
    val destinationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val smartPrice: Int,
    val premiumPrice: Int,
    val status: String = "ON TIME"
)

object TrainData {
    val trains = listOf(
        Train("BL201", "MIA", "Miami", "ORL", "Orlando", "08:00", "11:30", "3h 30m", 59, 149),
        Train("BL204", "MIA", "Miami", "ORL", "Orlando", "10:00", "13:30", "3h 30m", 69, 159),
        Train("BL215", "MIA", "Miami", "ORL", "Orlando", "13:00", "16:30", "3h 30m", 59, 149),
        Train("BL220", "MIA", "Miami", "ORL", "Orlando", "17:00", "20:30", "3h 30m", 79, 169),

        Train("BL202", "ORL", "Orlando", "MIA", "Miami", "07:30", "11:00", "3h 30m", 59, 149),
        Train("BL206", "ORL", "Orlando", "MIA", "Miami", "11:15", "14:45", "3h 30m", 69, 159),
        Train("BL210", "ORL", "Orlando", "MIA", "Miami", "14:30", "18:00", "3h 30m", 59, 149),
        Train("BL224", "ORL", "Orlando", "MIA", "Miami", "18:45", "22:15", "3h 30m", 79, 169),

        Train("BL101", "MIA", "Miami", "WPB", "West Palm Beach", "06:15", "07:30", "1h 15m", 19, 39),
        Train("BL105", "MIA", "Miami", "WPB", "West Palm Beach", "09:00", "10:15", "1h 15m", 25, 49),
        Train("BL102", "WPB", "West Palm Beach", "MIA", "Miami", "08:00", "09:15", "1h 15m", 19, 39),
        Train("BL106", "WPB", "West Palm Beach", "MIA", "Miami", "11:30", "12:45", "1h 15m", 25, 49)
    )

    fun getDeparturesForRoute(origin: String, destination: String): List<Train> {
        val filtered = trains.filter {
            it.originName.equals(origin, ignoreCase = true) &&
            it.destinationName.equals(destination, ignoreCase = true)
        }
        if (filtered.isNotEmpty()) return filtered

        val origCode = origin.take(3).uppercase()
        val destCode = destination.take(3).uppercase()
        return listOf(
            Train("BL401", origCode, origin, destCode, destination, "08:15", "11:45", "3h 30m", 59, 149),
            Train("BL405", origCode, origin, destCode, destination, "12:30", "16:00", "3h 30m", 69, 159),
            Train("BL412", origCode, origin, destCode, destination, "17:15", "20:45", "3h 30m", 79, 169)
        )
    }
}
