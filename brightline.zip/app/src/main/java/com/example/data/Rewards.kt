package com.example.data

data class RewardItem(
    val title: String,
    val pointsRequired: Int,
    val description: String,
    val isAvailable: Boolean
)

data class PointsActivity(
    val description: String,
    val date: String,
    val points: Int,
    val isEarned: Boolean
)

object RewardsData {
    val items = listOf(
        RewardItem("Complimentary Mary Mary Beverage", 500, "Get any premium coffee, wine, beer, or cocktail at our station bars.", true),
        RewardItem("Premium Class Upgrade", 1500, "Upgrade your next SMART journey to PREMIUM to enjoy lounge access and wider seats.", true),
        RewardItem("One-Way SMART Ticket", 3000, "Enjoy a free single-journey ride anywhere on the network (SMART service).", true),
        RewardItem("Station Parking Pass", 800, "Free daily parking at any Brightline parking garage.", true),
        RewardItem("One-Way PREMIUM Ticket", 6000, "Experience the highest level of hospitality with a complimentary PREMIUM ticket.", false)
    )

    val activities = listOf(
        PointsActivity("Miami to Orlando (PREMIUM)", "Sep 24, 2026", 450, true),
        PointsActivity("Orlando to West Palm (SMART)", "Sep 12, 2026", 250, true),
        PointsActivity("Reward Redeemed: Free Parking", "Aug 30, 2026", -800, false),
        PointsActivity("West Palm to Miami (PREMIUM)", "Aug 15, 2026", 300, true),
        PointsActivity("Aventura to Miami (SMART)", "Jul 22, 2026", 120, true)
    )
}
