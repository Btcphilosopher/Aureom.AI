package com.example.state

import androidx.lifecycle.ViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BrightlineViewModel : ViewModel() {
    // State-driven navigation stack
    private val _navigationStack = MutableStateFlow<List<Screen>>(listOf(Screen.HOME))
    val navigationStack: StateFlow<List<Screen>> = _navigationStack.asStateFlow()

    val currentScreen: Screen get() = _navigationStack.value.lastOrNull() ?: Screen.HOME

    fun navigateTo(screen: Screen) {
        val current = _navigationStack.value.toMutableList()
        current.add(screen)
        _navigationStack.value = current
    }

    fun popScreen(): Boolean {
        val current = _navigationStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _navigationStack.value = current
            return true
        }
        return false
    }

    fun resetToHome() {
        _navigationStack.value = listOf(Screen.HOME)
    }

    // Booking flow states
    private val _origin = MutableStateFlow(StationData.stations.first { it.id == "miami" })
    val origin = _origin.asStateFlow()

    private val _destination = MutableStateFlow(StationData.stations.first { it.id == "orlando" })
    val destination = _destination.asStateFlow()

    private val _date = MutableStateFlow("Sat, Oct 17")
    val date = _date.asStateFlow()

    private val _passengerCount = MutableStateFlow("1 Adult")
    val passengerCount = _passengerCount.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Train>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    private val _selectedTrain = MutableStateFlow<Train?>(null)
    val selectedTrain = _selectedTrain.asStateFlow()

    private val _selectedFareType = MutableStateFlow("SMART") // SMART or PREMIUM
    val selectedFareType = _selectedFareType.asStateFlow()

    private val _passengerInfo = MutableStateFlow(PassengerInfo("Tom", "Example", "tom@ahyx.org", "+1 (305) 555-0199", true))
    val passengerInfo = _passengerInfo.asStateFlow()

    private val _selectedSeat = MutableStateFlow("12A")
    val selectedSeat = _selectedSeat.asStateFlow()

    private val _selectedCoach = MutableStateFlow("2")
    val selectedCoach = _selectedCoach.asStateFlow()

    private val _selectedExtras = MutableStateFlow<List<String>>(emptyList())
    val selectedExtras = _selectedExtras.asStateFlow()

    // Confirmed booking state
    private val _latestBooking = MutableStateFlow<BookedTrip?>(null)
    val latestBooking = _latestBooking.asStateFlow()

    // Booked Trips list (Database simulation)
    private val _bookedTrips = MutableStateFlow<List<BookedTrip>>(
        listOf(
            BookedTrip(
                bookingReference = "BL7K4P",
                trainNumber = "BL201",
                originCode = "MIA",
                originName = "Miami",
                destinationCode = "ORL",
                destinationName = "Orlando",
                departureTime = "08:00",
                arrivalTime = "11:30",
                date = "Sat, Oct 17",
                seat = "12A",
                coach = "2",
                passengerName = "Tom Example",
                fareType = "SMART",
                price = 59,
                extras = listOf("Premium Wi-Fi")
            )
        )
    )
    val bookedTrips = _bookedTrips.asStateFlow()

    // Selected ticket detail
    private val _selectedTicketForView = MutableStateFlow<BookedTrip?>(null)
    val selectedTicketForView = _selectedTicketForView.asStateFlow()

    // Train Status States
    private val _searchTrainQuery = MutableStateFlow("BL201")
    val searchTrainQuery = _searchTrainQuery.asStateFlow()

    private val _searchedTrainStatus = MutableStateFlow<Train?>(TrainData.trains.first())
    val searchedTrainStatus = _searchedTrainStatus.asStateFlow()

    // Selected Station Explorer State
    private val _selectedStation = MutableStateFlow(StationData.stations.first { it.id == "miami" })
    val selectedStation = _selectedStation.asStateFlow()

    // Pass purchases states
    private val _purchasedPasses = MutableStateFlow<List<TransitPass>>(emptyList())
    val purchasedPasses = _purchasedPasses.asStateFlow()

    // Rewards point state
    private val _rewardsPoints = MutableStateFlow(12450)
    val rewardsPoints = _rewardsPoints.asStateFlow()

    // Functions
    fun setOrigin(station: Station) {
        _origin.value = station
    }

    fun setDestination(station: Station) {
        _destination.value = station
    }

    fun swapRoute() {
        val temp = _origin.value
        _origin.value = _destination.value
        _destination.value = temp
    }

    fun setDate(newDate: String) {
        _date.value = newDate
    }

    fun setPassengerCount(count: String) {
        _passengerCount.value = count
    }

    fun searchTrains() {
        _searchResults.value = TrainData.getDeparturesForRoute(_origin.value.name, _destination.value.name)
        navigateTo(Screen.SEARCH_RESULTS)
    }

    fun selectTrain(train: Train) {
        _selectedTrain.value = train
        navigateTo(Screen.FARE_SELECTION)
    }

    fun selectFareType(type: String) {
        _selectedFareType.value = type
        navigateTo(Screen.PASSENGER_FORM)
    }

    fun savePassengerInfo(info: PassengerInfo) {
        _passengerInfo.value = info
        navigateTo(Screen.SEAT_SELECTION)
    }

    fun selectSeat(seat: String, coach: String) {
        _selectedSeat.value = seat
        _selectedCoach.value = coach
        navigateTo(Screen.TRIP_SUMMARY)
    }

    fun toggleExtra(extra: String) {
        val current = _selectedExtras.value.toMutableList()
        if (current.contains(extra)) {
            current.remove(extra)
        } else {
            current.add(extra)
        }
        _selectedExtras.value = current
    }

    fun proceedToPayment() {
        navigateTo(Screen.PAYMENT)
    }

    fun executeBooking() {
        val train = _selectedTrain.value ?: return
        val passenger = _passengerInfo.value
        val reference = "BL" + (100000..999999).random().toString().take(6)
        val price = if (_selectedFareType.value == "PREMIUM") train.premiumPrice else train.smartPrice
        val totalWithExtras = price + (_selectedExtras.value.size * 10)

        val newBooking = BookedTrip(
            bookingReference = reference,
            trainNumber = train.number,
            originCode = train.originCode,
            originName = train.originName,
            destinationCode = train.destinationCode,
            destinationName = train.destinationName,
            departureTime = train.departureTime,
            arrivalTime = train.arrivalTime,
            date = _date.value,
            seat = _selectedSeat.value,
            coach = _selectedCoach.value,
            passengerName = "${passenger.firstName} ${passenger.lastName}",
            fareType = _selectedFareType.value,
            price = totalWithExtras,
            extras = _selectedExtras.value
        )

        _latestBooking.value = newBooking

        val currentTrips = _bookedTrips.value.toMutableList()
        currentTrips.add(0, newBooking)
        _bookedTrips.value = currentTrips

        _rewardsPoints.value += totalWithExtras * 5

        navigateTo(Screen.CONFIRMATION)
    }

    fun viewTicket(trip: BookedTrip) {
        _selectedTicketForView.value = trip
        navigateTo(Screen.DIGITAL_TICKET)
    }

    fun searchTrainStatus(query: String) {
        _searchTrainQuery.value = query
        val found = TrainData.trains.firstOrNull {
            it.number.equals(query, ignoreCase = true) ||
            it.destinationName.equals(query, ignoreCase = true) ||
            it.originName.equals(query, ignoreCase = true)
        }
        _searchedTrainStatus.value = found ?: TrainData.trains.first()
    }

    fun selectStation(station: Station) {
        _selectedStation.value = station
        navigateTo(Screen.STATIONS)
    }

    fun purchasePass(pass: TransitPass) {
        val current = _purchasedPasses.value.toMutableList()
        current.add(pass)
        _purchasedPasses.value = current
        _rewardsPoints.value += pass.price * 5
    }
}

enum class Screen {
    HOME,
    SEARCH_RESULTS,
    FARE_SELECTION,
    PASSENGER_FORM,
    SEAT_SELECTION,
    TRIP_SUMMARY,
    PAYMENT,
    CONFIRMATION,
    MY_TRIPS,
    DIGITAL_TICKET,
    TRAIN_STATUS,
    STATIONS,
    BRIGHTLINE_PLUS,
    REWARDS,
    PASSES,
    ACCOUNT
}
