package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrightlineYellow,
    secondary = Color(0xFFE2E4EB),
    tertiary = RestrainedCoral,
    background = CharcoalDark,
    surface = Color(0xFF1E1E1E),
    onPrimary = CharcoalDark,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF2C2C2C),
    onSurfaceVariant = Color(0xFFE2E4EB)
)

private val LightColorScheme = lightColorScheme(
    primary = CharcoalDark,
    secondary = BrightlineYellow,
    tertiary = RestrainedCoral,
    background = WarmWhite,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = CharcoalDark,
    onBackground = CharcoalDark,
    onSurface = CharcoalDark,
    surfaceVariant = LightGray,
    onSurfaceVariant = Color(0xFF4A4B4F)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
