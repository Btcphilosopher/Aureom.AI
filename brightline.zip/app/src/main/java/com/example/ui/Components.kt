package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.util.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrightlineHeader(
    title: String,
    onBackClick: (() -> Unit)? = null,
    onHomeClick: (() -> Unit)? = null
) {
    CenterAlignedTopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title.uppercase(),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = CharcoalDark
                )
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(RestrainedCoral, CircleShape)
                )
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = CharcoalDark
                    )
                }
            }
        },
        actions = {
            if (onHomeClick != null) {
                IconButton(
                    onClick = onHomeClick,
                    modifier = Modifier.testTag("home_shortcut")
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Home",
                        tint = CharcoalDark
                    )
                }
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = BrightlineYellow
        ),
        modifier = Modifier.shadow(4.dp)
    )
}

@Composable
fun RouteSwapSelector(
    origin: Station,
    destination: Station,
    onOriginClick: () -> Unit,
    onDestinationClick: () -> Unit,
    onSwap: () -> Unit
) {
    var isRotated by remember { mutableStateOf(false) }
    val rotationAngle by animateFloatAsState(
        targetValue = if (isRotated) 180f else 0f,
        animationSpec = tween(300)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGray, RoundedCornerShape(16.dp))
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            // From Station
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOriginClick() }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.TripOrigin,
                    contentDescription = "Origin",
                    tint = BrightlineDarkYellow,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "DEPARTING FROM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${origin.name} (${origin.code})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = LightGray, thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // To Station
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDestinationClick() }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = "Destination",
                    tint = RestrainedCoral,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "ARRIVING AT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${destination.name} (${destination.code})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalDark
                    )
                }
            }
        }

        // Swap Button Overlaid
        IconButton(
            onClick = {
                isRotated = !isRotated
                onSwap()
            },
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = (-16).dp)
                .background(CharcoalDark, CircleShape)
                .size(40.dp)
                .rotate(rotationAngle)
                .testTag("route_swap_button")
        ) {
            Icon(
                imageVector = Icons.Default.SwapVert,
                contentDescription = "Swap Locations",
                tint = BrightlineYellow,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun DemoQRCode(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color.White, shape = RoundedCornerShape(12.dp))
            .border(1.dp, BorderGray, shape = RoundedCornerShape(12.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(150.dp)) {
            val size = this.size.width
            val cellSize = size / 10f

            // Draw positioning blocks
            // Top Left
            drawRect(CharcoalDark, size = Size(cellSize * 3, cellSize * 3))
            drawRect(Color.White, topLeft = Offset(cellSize, cellSize), size = Size(cellSize, cellSize))

            // Top Right
            drawRect(CharcoalDark, topLeft = Offset(cellSize * 7, 0f), size = Size(cellSize * 3, cellSize * 3))
            drawRect(Color.White, topLeft = Offset(cellSize * 8, cellSize), size = Size(cellSize, cellSize))

            // Bottom Left
            drawRect(CharcoalDark, topLeft = Offset(0f, cellSize * 7), size = Size(cellSize * 3, cellSize * 3))
            drawRect(Color.White, topLeft = Offset(cellSize, cellSize * 8), size = Size(cellSize, cellSize))

            // Draw random QR noise
            val seed = 12345L
            val random = Random(seed)
            for (row in 0 until 10) {
                for (col in 0 until 10) {
                    if ((row < 3 && col < 3) || (row < 3 && col > 6) || (row > 6 && col < 3)) {
                        continue // Skip markers
                    }
                    if (random.nextBoolean()) {
                        drawRect(
                            CharcoalDark,
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = Size(cellSize, cellSize)
                        )
                    }
                }
            }
        }

        // Demo stamp
        Box(
            modifier = Modifier
                .rotate(-15f)
                .background(RestrainedCoral.copy(alpha = 0.95f), shape = RoundedCornerShape(4.dp))
                .border(1.dp, Color.White, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = "DEMO TICKET",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun StatusTimelineView(
    trainNumber: String,
    originCode: String,
    destinationCode: String,
    departureTime: String,
    arrivalTime: String,
    modifier: Modifier = Modifier
) {
    // We animate a sliding train icon along the timeline
    var animationTriggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animationTriggered = true
    }
    val trainOffsetPct by animateFloatAsState(
        targetValue = if (animationTriggered) 0.45f else 0f,
        animationSpec = tween(2000)
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(1.dp, BorderGray, RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = trainNumber,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark
                )
                Text(
                    text = "Florida Express Route",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = TropicalGreen.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "ON TIME",
                    color = TropicalGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Vertical timeline representing intermediate stations
        val stops = listOf(
            Triple("MiamiCentral (MIA)", "Departed at $departureTime", true),
            Triple("Fort Lauderdale (FLL)", "Passed at 08:35", true),
            Triple("West Palm Beach (WPB)", "Passed at 09:15", true),
            Triple("Orlando (ORL)", "Scheduled for $arrivalTime", false)
        )

        Box(modifier = Modifier.fillMaxWidth()) {
            // Background line
            Canvas(
                modifier = Modifier
                    .width(4.dp)
                    .height(220.dp)
                    .offset(x = 10.dp)
                    .align(Alignment.TopStart)
            ) {
                drawLine(
                    color = LightGray,
                    start = Offset(0f, 0f),
                    end = Offset(0f, size.height),
                    strokeWidth = 4.dp.toPx()
                )
                drawLine(
                    color = BrightlineYellow,
                    start = Offset(0f, 0f),
                    end = Offset(0f, size.height * trainOffsetPct),
                    strokeWidth = 4.dp.toPx()
                )
            }

            // Train icon sliding along line
            Box(
                modifier = Modifier
                    .offset(y = (220 * trainOffsetPct).dp, x = 0.dp)
                    .size(24.dp)
                    .background(BrightlineYellow, CircleShape)
                    .border(2.dp, CharcoalDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Train,
                    contentDescription = "Train Position",
                    tint = CharcoalDark,
                    modifier = Modifier.size(14.dp)
                )
            }

            // Stop descriptions
            Column(
                modifier = Modifier
                    .padding(start = 36.dp)
                    .height(220.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                stops.forEach { (station, statusText, isPassed) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .offset(x = (-32).dp)
                                .background(
                                    if (isPassed) BrightlineYellow else Color.White,
                                    CircleShape
                                )
                                .border(
                                    2.dp,
                                    if (isPassed) CharcoalDark else Color.Gray,
                                    CircleShape
                                )
                        )
                        Column(modifier = Modifier.offset(x = (-16).dp)) {
                            Text(
                                text = station,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPassed) CharcoalDark else Color.Gray
                            )
                            Text(
                                text = statusText,
                                fontSize = 12.sp,
                                color = if (isPassed) CharcoalDark.copy(alpha = 0.7f) else Color.Gray.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CarriageSeatMap(
    selectedSeat: String,
    onSeatSelected: (String, String) -> Unit
) {
    // Simulated coach layout. 2 columns on each side of the aisle.
    // Window: A, D. Aisle: B, C.
    val rows = listOf("01", "02", "03", "04", "05", "06", "07", "08")
    val cols = listOf("A", "B", "C", "D")

    // Hardcode some synthetic occupied seats for realism
    val occupiedSeats = setOf("01B", "02C", "02D", "03A", "05B", "06C", "08A", "08D")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(1.dp, BorderGray, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "COACH 2 — SMART CLASS",
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            color = CharcoalDark,
            letterSpacing = 1.sp
        )
        Text(
            text = "Direction of travel: Forward ➔",
            fontSize = 11.sp,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(Color.White, RoundedCornerShape(4.dp))
                        .border(1.dp, Color.Gray, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Available", fontSize = 11.sp, color = Color.Gray)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(BrightlineYellow, RoundedCornerShape(4.dp))
                        .border(1.dp, CharcoalDark, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Selected", fontSize = 11.sp, color = Color.Gray)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(LightGray, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Occupied", fontSize = 11.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Train outline wrapper
        Column(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .border(2.dp, CharcoalDark, RoundedCornerShape(12.dp))
                .background(LightGray.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(vertical = 16.dp, horizontal = 12.dp)
        ) {
            rows.forEach { rowNum ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Side: A (Window) & B (Aisle)
                    cols.take(2).forEach { colName ->
                        val seatCode = "$rowNum$colName"
                        val isOccupied = occupiedSeats.contains(seatCode)
                        val isSelected = selectedSeat == seatCode

                        val backgroundColor = when {
                            isOccupied -> Color(0xFFDDDDDD)
                            isSelected -> BrightlineYellow
                            else -> Color.White
                        }
                        val borderColor = when {
                            isOccupied -> Color.Transparent
                            isSelected -> CharcoalDark
                            else -> Color.Gray
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(backgroundColor)
                                .border(1.dp, borderColor, RoundedCornerShape(6.dp))
                                .clickable(enabled = !isOccupied) {
                                    onSeatSelected(seatCode, "2")
                                }
                                .testTag("seat_$seatCode"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = colName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isOccupied) Color.Gray else CharcoalDark
                            )
                        }
                    }

                    // Aisle Number
                    Text(
                        text = rowNum,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(24.dp)
                    )

                    // Right Side: C (Aisle) & D (Window)
                    cols.takeLast(2).forEach { colName ->
                        val seatCode = "$rowNum$colName"
                        val isOccupied = occupiedSeats.contains(seatCode)
                        val isSelected = selectedSeat == seatCode

                        val backgroundColor = when {
                            isOccupied -> Color(0xFFDDDDDD)
                            isSelected -> BrightlineYellow
                            else -> Color.White
                        }
                        val borderColor = when {
                            isOccupied -> Color.Transparent
                            isSelected -> CharcoalDark
                            else -> Color.Gray
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(backgroundColor)
                                .border(1.dp, borderColor, RoundedCornerShape(6.dp))
                                .clickable(enabled = !isOccupied) {
                                    onSeatSelected(seatCode, "2")
                                }
                                .testTag("seat_$seatCode"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = colName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isOccupied) Color.Gray else CharcoalDark
                            )
                        }
                    }
                }
            }
        }
    }
}
