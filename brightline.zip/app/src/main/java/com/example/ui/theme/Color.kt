package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brightline Signature Colors
val BrightlineYellow = Color(0xFFFFDB00) // Bold Florida Sunshine Yellow
val BrightlineDarkYellow = Color(0xFFDAB400)
val CharcoalDark = Color(0xFF121212)    // Premium Charcoal
val WarmWhite = Color(0xFFF9F9FB)       // Crisp Tropical Off-White
val RestrainedCoral = Color(0xFFFF5A36)  // Sunset Orange / Coral
val TropicalGreen = Color(0xFF00A86B)    // Palm Tree Green

// Material Theme standard colors mapped
val PrimaryYellow = BrightlineYellow
val SecondaryCharcoal = Color(0xFF232323)
val DarkAccent = Color(0xFF0F0F10)
val LightGray = Color(0xFFF0F1F5)
val BorderGray = Color(0xFFE2E4EB)

val Purple80 = BrightlineYellow
val PurpleGrey80 = Color(0xFF2C2C2C)
val Pink80 = RestrainedCoral

val Purple40 = BrightlineDarkYellow
val PurpleGrey40 = Color(0xFF121212)
val Pink40 = RestrainedCoral
