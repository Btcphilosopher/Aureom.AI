package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.state.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun AppContent(viewModel: BrightlineViewModel) {
    val navStack by viewModel.navigationStack.collectAsState()
    val currentScreen = viewModel.currentScreen

    Scaffold(
        bottomBar = {
            if (currentScreen == Screen.HOME ||
                currentScreen == Screen.MY_TRIPS ||
                currentScreen == Screen.TRAIN_STATUS ||
                currentScreen == Screen.STATIONS ||
                currentScreen == Screen.ACCOUNT ||
                currentScreen == Screen.REWARDS ||
                currentScreen == Screen.PASSES ||
                currentScreen == Screen.BRIGHTLINE_PLUS
            ) {
                BrightlineBottomNavigation(
                    currentScreen = currentScreen,
                    onNavigate = { screen ->
                        viewModel.resetToHome()
                        if (screen != Screen.HOME) {
                            viewModel.navigateTo(screen)
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(viewModel)
                Screen.SEARCH_RESULTS -> SearchResultsScreen(viewModel)
                Screen.FARE_SELECTION -> FareSelectionScreen(viewModel)
                Screen.PASSENGER_FORM -> PassengerFormScreen(viewModel)
                Screen.SEAT_SELECTION -> SeatSelectionScreen(viewModel)
                Screen.TRIP_SUMMARY -> TripSummaryScreen(viewModel)
                Screen.PAYMENT -> PaymentScreen(viewModel)
                Screen.CONFIRMATION -> ConfirmationScreen(viewModel)
                Screen.MY_TRIPS -> MyTripsScreen(viewModel)
                Screen.DIGITAL_TICKET -> DigitalTicketScreen(viewModel)
                Screen.TRAIN_STATUS -> TrainStatusScreen(viewModel)
                Screen.STATIONS -> StationsScreen(viewModel)
                Screen.BRIGHTLINE_PLUS -> BrightlinePlusScreen(viewModel)
                Screen.REWARDS -> RewardsScreen(viewModel)
                Screen.PASSES -> PassesScreen(viewModel)
                Screen.ACCOUNT -> AccountScreen(viewModel)
            }
        }
    }
}

@Composable
fun BrightlineBottomNavigation(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    val items = listOf(
        Triple(Screen.HOME, "Book", Icons.Default.Train),
        Triple(Screen.MY_TRIPS, "Trips", Icons.Default.ConfirmationNumber),
        Triple(Screen.TRAIN_STATUS, "Status", Icons.Default.Timeline),
        Triple(Screen.STATIONS, "Stations", Icons.Default.LocationOn),
        Triple(Screen.ACCOUNT, "Account", Icons.Default.Person)
    )

    NavigationBar(
        containerColor = CharcoalDark,
        tonalElevation = 8.dp
    ) {
        items.forEach { (screen, label, icon) ->
            val isSelected = when (screen) {
                Screen.HOME -> currentScreen == Screen.HOME
                Screen.MY_TRIPS -> currentScreen == Screen.MY_TRIPS || currentScreen == Screen.DIGITAL_TICKET
                Screen.TRAIN_STATUS -> currentScreen == Screen.TRAIN_STATUS
                Screen.STATIONS -> currentScreen == Screen.STATIONS
                Screen.ACCOUNT -> currentScreen == Screen.ACCOUNT || currentScreen == Screen.REWARDS || currentScreen == Screen.PASSES || currentScreen == Screen.BRIGHTLINE_PLUS
                else -> false
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) CharcoalDark else Color.LightGray
                    )
                },
                label = {
                    Text(
                        text = label,
                        color = if (isSelected) BrightlineYellow else Color.LightGray,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = BrightlineYellow
                ),
                modifier = Modifier.testTag("nav_item_${label.lowercase()}")
            )
        }
    }
}

@Composable
fun HomeScreen(viewModel: BrightlineViewModel) {
    val origin by viewModel.origin.collectAsState()
    val destination by viewModel.destination.collectAsState()
    val date by viewModel.date.collectAsState()
    val passengerCount by viewModel.passengerCount.collectAsState()

    var showOriginDialog by remember { mutableStateOf(false) }
    var showDestinationDialog by remember { mutableStateOf(false) }

    if (showOriginDialog) {
        StationSelectionDialog(
            title = "Choose Departure",
            onDismiss = { showOriginDialog = false },
            onSelect = {
                viewModel.setOrigin(it)
                showOriginDialog = false
            }
        )
    }

    if (showDestinationDialog) {
        StationSelectionDialog(
            title = "Choose Destination",
            onDismiss = { showDestinationDialog = false },
            onSelect = {
                viewModel.setDestination(it)
                showDestinationDialog = false
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        // Hero Header Section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_brightline_hero),
                    contentDescription = "Sleek Brightline Train Speeding in Florida Sun",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Dark Gradient overlay to make text pop
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, CharcoalDark.copy(alpha = 0.85f)),
                                startY = 100f
                            )
                        )
                )

                // Editorial Hero Text
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(24.dp)
                ) {
                    Text(
                        text = "BRIGHTLINE",
                        color = BrightlineYellow,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = "GO SOMEWHERE\nBRIGHT.",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp,
                        lineHeight = 36.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Search Form Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .offset(y = (-20).dp)
                    .shadow(12.dp, RoundedCornerShape(20.dp))
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                // Origin / Destination Swap Block
                RouteSwapSelector(
                    origin = origin,
                    destination = destination,
                    onOriginClick = { showOriginDialog = true },
                    onDestinationClick = { showDestinationDialog = true },
                    onSwap = { viewModel.swapRoute() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Date and Passengers row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Date Selector
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setDate("Sat, Oct 17") }
                            .testTag("date_selector"),
                        colors = CardDefaults.cardColors(containerColor = LightGray),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("DATE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(date, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }

                    // Passengers Selector
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setPassengerCount("1 Adult") }
                            .testTag("passengers_selector"),
                        colors = CardDefaults.cardColors(containerColor = LightGray),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("PASSENGERS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(passengerCount, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Primary Booking Button
                Button(
                    onClick = { viewModel.searchTrains() },
                    colors = ButtonDefaults.buttonColors(containerColor = BrightlineYellow),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("search_trains_button"),
                    shape = RoundedCornerShape(14.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Text(
                        text = "SEARCH TRAINS",
                        color = CharcoalDark,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        fontSize = 16.sp
                    )
                }
            }
        }

        // WHERE ARE YOU GOING? Quick Destination explorer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "WHERE ARE YOU GOING?",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Customized Florida destination grids
                val destinations = listOf(
                    Triple("MIAMI", "Sunset Palms & MiamiCentral vibe", Brush.linearGradient(colors = listOf(Color(0xFFFF5A36), Color(0xFFFF9A8B)))),
                    Triple("FORT LAUDERDALE", "Yacht Capital & Riverwalk canals", Brush.linearGradient(colors = listOf(Color(0xFF00A86B), Color(0xFF00C9FF)))),
                    Triple("BOCA RATON", "Mizner Park upscale cultural hub", Brush.linearGradient(colors = listOf(Color(0xFF7B2CBF), Color(0xFF9D4EDD)))),
                    Triple("WEST PALM BEACH", "Clematis dining & pristine beaches", Brush.linearGradient(colors = listOf(Color(0xFFFF9E00), Color(0xFFFFD000)))),
                    Triple("ORLANDO", "Central Florida Theme Parks hub", Brush.linearGradient(colors = listOf(Color(0xFF0072FF), Color(0xFF00C6FF))))
                )

                destinations.forEach { (name, tag, brush) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .height(90.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(brush)
                            .clickable {
                                // Select origin / destination as Miami/Orlando on click as a prototype helper
                                val targetStat = StationData.stations.firstOrNull { it.name.uppercase().contains(name) || name.contains(it.name.uppercase()) }
                                if (targetStat != null) {
                                    viewModel.setDestination(targetStat)
                                }
                            }
                            .padding(16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Column {
                            Text(
                                text = name,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.5.sp
                            )
                            Text(
                                text = tag.uppercase(),
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                letterSpacing = 0.5.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Explore",
                            tint = Color.White,
                            modifier = Modifier.align(Alignment.CenterEnd)
                        )
                    }
                }
            }
        }

        // Secondary Links: Brightline+, Rewards, Passes, Account
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "TRAVEL EXPERIENCES",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.navigateTo(Screen.REWARDS) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = borderStroke()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.CardMembership, "Rewards", tint = BrightlineDarkYellow)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("REWARDS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("12,450 pts", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.navigateTo(Screen.PASSES) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = borderStroke()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.ConfirmationNumber, "Passes", tint = RestrainedCoral)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("PASSES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("Save on rides", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.navigateTo(Screen.BRIGHTLINE_PLUS) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = borderStroke()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.LocalTaxi, "Plus", tint = TropicalGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("BRIGHTLINE+", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("First/Last mile", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(30.dp)) }
    }
}

@Composable
fun SearchResultsScreen(viewModel: BrightlineViewModel) {
    val origin by viewModel.origin.collectAsState()
    val destination by viewModel.destination.collectAsState()
    val date by viewModel.date.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Departures",
            onBackClick = { viewModel.popScreen() }
        )

        // Route Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalDark),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${origin.code} ➔ ${destination.code}",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${origin.name} to ${destination.name}",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = date,
                    color = BrightlineYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Departures List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(searchResults) { train ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .border(1.dp, BorderGray, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = train.number,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).background(TropicalGreen, CircleShape))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(train.status, color = TropicalGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Departure Block
                            Column {
                                Text(train.departureTime, fontSize = 24.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                Text(train.originCode, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }

                            // Travel Indicator
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Text(train.duration, fontSize = 11.sp, color = Color.Gray)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.6f)
                                        .height(2.dp)
                                        .background(LightGray)
                                )
                                Icon(Icons.Default.Train, "Train", modifier = Modifier.size(16.dp), tint = BrightlineDarkYellow)
                            }

                            // Arrival Block
                            Column(horizontalAlignment = Alignment.End) {
                                Text(train.arrivalTime, fontSize = 24.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                Text(train.destinationCode, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider(color = LightGray)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Price and Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("SMART FROM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text("$${train.smartPrice}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                            }
                            Column {
                                Text("PREMIUM FROM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text("$${train.premiumPrice}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = RestrainedCoral)
                            }

                            Button(
                                onClick = { viewModel.selectTrain(train) },
                                colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("select_train_${train.number}")
                            ) {
                                Text("SELECT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FareSelectionScreen(viewModel: BrightlineViewModel) {
    val selectedTrain by viewModel.selectedTrain.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Experience",
            onBackClick = { viewModel.popScreen() }
        )

        if (selectedTrain == null) return

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CHOOSE YOUR EXPERIENCE",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
            Text(
                text = "Elevate your journey across Florida",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // SMART FARE SELECTOR CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectFareType("SMART") }
                    .padding(vertical = 8.dp)
                    .border(2.dp, BrightlineYellow, RoundedCornerShape(16.dp))
                    .testTag("fare_smart_card"),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SMART", fontSize = 20.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                        Text(
                            text = "From $${selectedTrain?.smartPrice}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalDark
                        )
                    }

                    Text("Plausible luxury made simple.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))

                    Divider(color = LightGray, modifier = Modifier.padding(vertical = 12.dp))

                    listOf(
                        "Comfortable leather seats & wide hand rests",
                        "High-speed complimentary Wi-Fi onboard",
                        "In-seat power outlets & USB ports",
                        "Scrumptious foods and beverage available for purchase"
                    ).forEach { benefit ->
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, "Check", tint = TropicalGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(benefit, fontSize = 12.sp, color = CharcoalDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.selectFareType("SMART") },
                        colors = ButtonDefaults.buttonColors(containerColor = BrightlineYellow),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("SELECT SMART", color = CharcoalDark, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // PREMIUM FARE SELECTOR CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectFareType("PREMIUM") }
                    .padding(vertical = 8.dp)
                    .border(2.dp, RestrainedCoral, RoundedCornerShape(16.dp))
                    .testTag("fare_premium_card"),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("PREMIUM", fontSize = 20.sp, fontWeight = FontWeight.Black, color = RestrainedCoral)
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.background(RestrainedCoral, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text("BEST VALUE", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "From $${selectedTrain?.premiumPrice}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = RestrainedCoral
                        )
                    }

                    Text("The ultimate first-class hospitality experience.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))

                    Divider(color = LightGray, modifier = Modifier.padding(vertical = 12.dp))

                    listOf(
                        "Spacious premium seating arrangement",
                        "Access to private PREMIUM station lounges",
                        "Priority boarding & premium security fast track",
                        "Complimentary gourmet snacks, craft beer, and wines"
                    ).forEach { benefit ->
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, "Check", tint = RestrainedCoral, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(benefit, fontSize = 12.sp, color = CharcoalDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.selectFareType("PREMIUM") },
                        colors = ButtonDefaults.buttonColors(containerColor = RestrainedCoral),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("SELECT PREMIUM", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PassengerFormScreen(viewModel: BrightlineViewModel) {
    val currentInfo by viewModel.passengerInfo.collectAsState()

    var firstName by remember { mutableStateOf(currentInfo.firstName) }
    var lastName by remember { mutableStateOf(currentInfo.lastName) }
    var email by remember { mutableStateOf(currentInfo.email) }
    var phone by remember { mutableStateOf(currentInfo.phone) }
    var saveDetails by remember { mutableStateOf(currentInfo.saveDetails) }

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Passenger",
            onBackClick = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "PASSENGER DETAILS",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
            Text(
                text = "Provide traveler credentials for boarding clearance.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            OutlinedTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = { Text("First Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("first_name_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = { Text("Last Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("last_name_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("email_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("phone_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { saveDetails = !saveDetails },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = saveDetails,
                    onCheckedChange = { saveDetails = it },
                    modifier = Modifier.testTag("save_passenger_checkbox")
                )
                Text(
                    text = "Save passenger to my travel profile",
                    fontSize = 14.sp,
                    color = CharcoalDark
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    viewModel.savePassengerInfo(
                        PassengerInfo(firstName, lastName, email, phone, saveDetails)
                    )
                },
                enabled = firstName.isNotBlank() && lastName.isNotBlank() && email.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("passenger_continue_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("CONTINUE TO SEAT MAP", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            }
        }
    }
}

@Composable
fun SeatSelectionScreen(viewModel: BrightlineViewModel) {
    val selectedSeat by viewModel.selectedSeat.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Seats",
            onBackClick = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "SELECT YOUR SEAT",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
            Text(
                text = "Seat: $selectedSeat (Window)",
                fontSize = 13.sp,
                color = RestrainedCoral,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            CarriageSeatMap(
                selectedSeat = selectedSeat,
                onSeatSelected = { seat, coach ->
                    viewModel.selectSeat(seat, coach)
                }
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { viewModel.navigateTo(Screen.TRIP_SUMMARY) },
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("seat_continue_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("CONFIRM SEAT $selectedSeat", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TripSummaryScreen(viewModel: BrightlineViewModel) {
    val origin by viewModel.origin.collectAsState()
    val destination by viewModel.destination.collectAsState()
    val selectedTrain by viewModel.selectedTrain.collectAsState()
    val selectedFareType by viewModel.selectedFareType.collectAsState()
    val passengerInfo by viewModel.passengerInfo.collectAsState()
    val selectedSeat by viewModel.selectedSeat.collectAsState()
    val selectedCoach by viewModel.selectedCoach.collectAsState()
    val selectedExtras by viewModel.selectedExtras.collectAsState()

    val basePrice = if (selectedFareType == "PREMIUM") selectedTrain?.premiumPrice ?: 149 else selectedTrain?.smartPrice ?: 59
    val extrasPrice = selectedExtras.size * 10
    val totalPrice = basePrice + extrasPrice

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Summary",
            onBackClick = { viewModel.popScreen() }
        )

        if (selectedTrain == null) return

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(20.dp)
        ) {
            item {
                Text(
                    text = "YOUR TRIP SUMMARY",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Route block card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(origin.code, fontSize = 28.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                Text(origin.name, fontSize = 12.sp, color = Color.Gray)
                                Text(selectedTrain!!.departureTime, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = BrightlineDarkYellow)
                            }

                            Icon(Icons.Default.TrendingFlat, "to", modifier = Modifier.size(32.dp), tint = Color.Gray)

                            Column(horizontalAlignment = Alignment.End) {
                                Text(destination.code, fontSize = 28.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                Text(destination.name, fontSize = 12.sp, color = Color.Gray)
                                Text(selectedTrain!!.arrivalTime, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = RestrainedCoral)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider(color = LightGray)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TRAIN: ${selectedTrain!!.number}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("EXPERIENCE: $selectedFareType", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RestrainedCoral)
                        }
                    }
                }
            }

            // Passenger/Seat Info Card
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("PASSENGER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("SEAT / COACH", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${passengerInfo.firstName} ${passengerInfo.lastName}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("Seat $selectedSeat, Coach $selectedCoach", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }
            }

            // Trip Extras section
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text("ADD TRIP EXTRAS", fontSize = 13.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                Spacer(modifier = Modifier.height(8.dp))

                listOf(
                    "Premium Wi-Fi Connection" to "Uncompressed streaming speed on board",
                    "Gourmet Meal Box" to "Chef-curated lunch option",
                    "Guaranteed Parking" to "Premium garage space validation"
                ).forEach { (extraName, desc) ->
                    val isChecked = selectedExtras.contains(extraName)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { viewModel.toggleExtra(extraName) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isChecked) BrightlineYellow.copy(alpha = 0.15f) else Color.White
                        ),
                        border = borderStroke()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { viewModel.toggleExtra(extraName) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(extraName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                                Text(desc, fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("+$10", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }
            }

            // Pricing totals breakdown
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Base Fare ($selectedFareType)", color = Color.Gray, fontSize = 13.sp)
                        Text("$$basePrice", fontWeight = FontWeight.Bold, color = CharcoalDark)
                    }
                    if (selectedExtras.isNotEmpty()) {
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Trip Extras (${selectedExtras.size})", color = Color.Gray, fontSize = 13.sp)
                            Text("$$extrasPrice", fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                    Divider(color = LightGray, modifier = Modifier.padding(vertical = 12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Price", fontSize = 16.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                        Text("$$totalPrice", fontSize = 20.sp, fontWeight = FontWeight.Black, color = RestrainedCoral)
                    }
                }
            }
        }

        // Checkout Button
        Box(modifier = Modifier.padding(20.dp)) {
            Button(
                onClick = { viewModel.proceedToPayment() },
                colors = ButtonDefaults.buttonColors(containerColor = BrightlineYellow),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("pay_and_book_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("PAY & BOOK — $$totalPrice", color = CharcoalDark, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun PaymentScreen(viewModel: BrightlineViewModel) {
    val selectedTrain by viewModel.selectedTrain.collectAsState()
    val selectedFareType by viewModel.selectedFareType.collectAsState()
    val selectedExtras by viewModel.selectedExtras.collectAsState()

    val basePrice = if (selectedFareType == "PREMIUM") selectedTrain?.premiumPrice ?: 149 else selectedTrain?.smartPrice ?: 59
    val totalPrice = basePrice + (selectedExtras.size * 10)

    var cardNum by remember { mutableStateOf("4000 1234 5678 4821") }
    var expiration by remember { mutableStateOf("12/29") }
    var cvv by remember { mutableStateOf("381") }
    var isProcessing by remember { mutableStateOf(false) }

    LaunchedEffect(isProcessing) {
        if (isProcessing) {
            delay(1800) // Simulated pay network lag
            viewModel.executeBooking()
        }
    }

    BackHandler {
        if (!isProcessing) {
            viewModel.popScreen()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Payment",
            onBackClick = { if (!isProcessing) viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "SIMULATED CHECKOUT",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
            Text(
                text = "Provide synthetic credentials for sandbox payment.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Credit Card shape mockup
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(CharcoalDark, Color(0xFF333333))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Brightline Card", color = BrightlineYellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Icon(Icons.Default.CreditCard, "Card Icon", tint = Color.White)
                    }

                    Text(
                        text = cardNum,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("EXPIRY", fontSize = 8.sp, color = Color.Gray)
                            Text(expiration, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("CVV", fontSize = 8.sp, color = Color.Gray)
                            Text(cvv, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = cardNum,
                onValueChange = { cardNum = it },
                label = { Text("Card Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("card_number_input")
            )

            Row(modifier = Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = expiration,
                    onValueChange = { expiration = it },
                    label = { Text("Expiration") },
                    modifier = Modifier.weight(1f).testTag("expiry_input")
                )
                OutlinedTextField(
                    value = cvv,
                    onValueChange = { cvv = it },
                    label = { Text("CVV") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("cvv_input")
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            if (isProcessing) {
                CircularProgressIndicator(color = BrightlineYellow)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Securing Sandbox Booking...", fontSize = 14.sp, color = CharcoalDark, fontWeight = FontWeight.Bold)
            } else {
                Button(
                    onClick = { isProcessing = true },
                    colors = ButtonDefaults.buttonColors(containerColor = RestrainedCoral),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("submit_payment_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("PAY $$totalPrice", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
fun ConfirmationScreen(viewModel: BrightlineViewModel) {
    val booking by viewModel.latestBooking.collectAsState()

    BackHandler {
        viewModel.resetToHome()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrightlineYellow),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(30.dp))
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Success",
            tint = CharcoalDark,
            modifier = Modifier.size(80.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "YOU'RE GOING\nSOMEWHERE BRIGHT.",
            fontWeight = FontWeight.Black,
            fontSize = 28.sp,
            textAlign = TextAlign.Center,
            lineHeight = 34.sp,
            color = CharcoalDark
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 30.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalDark)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${booking?.originCode} ➔ ${booking?.destinationCode}",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )
                Text(
                    text = "${booking?.date} | ${booking?.departureTime}",
                    color = BrightlineYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Divider(color = Color.Gray, modifier = Modifier.padding(vertical = 12.dp))
                Text(
                    text = "BOOKING REFERENCE",
                    color = Color.LightGray,
                    fontSize = 10.sp
                )
                Text(
                    text = booking?.bookingReference ?: "BL7K4P",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = 2.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = {
                val bTrip = booking
                if (bTrip != null) {
                    viewModel.viewTicket(bTrip)
                } else {
                    viewModel.navigateTo(Screen.MY_TRIPS)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 30.dp)
                .height(56.dp)
                .testTag("view_ticket_button")
        ) {
            Text("VIEW DIGITAL TICKET", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = { viewModel.resetToHome() },
            border = borderStroke(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalDark),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 30.dp)
                .height(56.dp)
        ) {
            Text("RETURN TO HOME", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MyTripsScreen(viewModel: BrightlineViewModel) {
    val trips by viewModel.bookedTrips.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(title = "My Trips")

        if (trips.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Train, "Train", tint = Color.Gray, modifier = Modifier.size(60.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("No booked trips yet.", fontWeight = FontWeight.Bold, color = CharcoalDark)
                Text("Go somewhere bright by selecting Miami ➔ Orlando!", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(16.dp)
            ) {
                item {
                    Text(
                        text = "UPCOMING JOURNEYS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = CharcoalDark,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                items(trips) { trip ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .border(1.dp, BorderGray, RoundedCornerShape(16.dp))
                            .clickable { viewModel.viewTicket(trip) }
                            .testTag("booked_trip_card_${trip.bookingReference}"),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BOOKING: ${trip.bookingReference}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                                Box(modifier = Modifier.background(TropicalGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text(trip.status, color = TropicalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(trip.originCode, fontSize = 24.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                    Text(trip.departureTime, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrightlineDarkYellow)
                                }
                                Icon(Icons.Default.TrendingFlat, "to", tint = Color.Gray)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(trip.destinationCode, fontSize = 24.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                                    Text(trip.arrivalTime, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RestrainedCoral)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = LightGray)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Passenger: ${trip.passengerName}", fontSize = 12.sp, color = Color.Gray)
                                Text("Seat: ${trip.seat} (Coach ${trip.coach})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalTicketScreen(viewModel: BrightlineViewModel) {
    val trip by viewModel.selectedTicketForView.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Boarding Pass",
            onBackClick = { viewModel.popScreen() }
        )

        if (trip == null) return

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(20.dp)
        ) {
            item {
                Text(
                    text = "DIGITAL BOARDING CREDENTIAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = CharcoalDark
                )
                Text(
                    text = "Scan QR code at station access gates.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Ticket Boarding Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(24.dp))
                        .background(Color.White, RoundedCornerShape(24.dp))
                        .border(1.dp, BorderGray, RoundedCornerShape(24.dp))
                ) {
                    // Upper half: Brand and stations
                    Column(
                        modifier = Modifier
                            .background(CharcoalDark, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                            .padding(20.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("BRIGHTLINE", color = BrightlineYellow, fontWeight = FontWeight.Black, fontSize = 16.sp)
                            Text(trip!!.fareType, color = RestrainedCoral, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(trip!!.originCode, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
                                Text(trip!!.originName, color = Color.LightGray, fontSize = 12.sp)
                            }
                            Icon(Icons.Default.ArrowForward, "to", tint = Color.LightGray, modifier = Modifier.size(24.dp).align(Alignment.CenterVertically))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(trip!!.destinationCode, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
                                Text(trip!!.destinationName, color = Color.LightGray, fontSize = 12.sp)
                            }
                        }
                    }

                    // Ticket Dotted line separator
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .background(Color.White)
                    ) {
                        val pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        drawLine(
                            color = Color.Gray,
                            start = Offset(0f, this.size.height / 2),
                            end = Offset(this.size.width, this.size.height / 2),
                            pathEffect = pathEffect,
                            strokeWidth = 2.dp.toPx()
                        )
                    }

                    // Lower half: Details and QR code
                    Column(
                        modifier = Modifier
                            .background(Color.White, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("DEPARTURE TIME", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(trip!!.departureTime, fontSize = 16.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                            }
                            Column {
                                Text("DATE", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(trip!!.date, fontSize = 16.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("COACH / SEAT", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text("Ch ${trip!!.coach} | St ${trip!!.seat}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("PASSENGER", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(trip!!.passengerName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("BOOKING REF", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(trip!!.bookingReference, fontSize = 14.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // QR Code implementation
                        DemoQRCode()

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "OFFLINE COMPATIBLE CREDENTIAL",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Wallet options
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { /* Simulated */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Default.Wallet, "Wallet")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ADD TO GOOGLE WALLET", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TrainStatusScreen(viewModel: BrightlineViewModel) {
    val searchQuery by viewModel.searchTrainQuery.collectAsState()
    val searchedTrain by viewModel.searchedTrainStatus.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(title = "Train Status")

        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TRAIN STATUS TRACKER",
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
            Text(
                text = "Monitor live location and schedules.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Search query field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchTrainStatus(it) },
                label = { Text("Search Train (e.g. BL201, Miami)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_search_input"),
                trailingIcon = { Icon(Icons.Default.Search, "Search") },
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (searchedTrain != null) {
                StatusTimelineView(
                    trainNumber = searchedTrain!!.number,
                    originCode = searchedTrain!!.originCode,
                    destinationCode = searchedTrain!!.destinationCode,
                    departureTime = searchedTrain!!.departureTime,
                    arrivalTime = searchedTrain!!.arrivalTime
                )
            } else {
                Text("Search or enter a valid Florida train code.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun StationsScreen(viewModel: BrightlineViewModel) {
    val stations = StationData.stations
    val selectedStation by viewModel.selectedStation.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(title = "Stations")

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .height(110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(stations) { station ->
                val isSelected = selectedStation.id == station.id
                Card(
                    modifier = Modifier
                        .clickable { viewModel.selectStation(station) }
                        .border(
                            1.dp,
                            if (isSelected) BrightlineYellow else Color.Transparent,
                            RoundedCornerShape(10.dp)
                        )
                        .testTag("station_tab_${station.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CharcoalDark else Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Box(modifier = Modifier.padding(12.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = station.name.uppercase(),
                            color = if (isSelected) BrightlineYellow else CharcoalDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Station Explorer details
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text(
                    text = selectedStation.name.uppercase(),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark
                )
                Text(
                    text = selectedStation.address,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                Text(selectedStation.description, fontSize = 14.sp, color = CharcoalDark, modifier = Modifier.padding(bottom = 16.dp))
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccessTime, "Hours", tint = BrightlineDarkYellow)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("HOURS: ${selectedStation.openingHours}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalParking, "Parking", tint = RestrainedCoral)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("PARKING: ${selectedStation.parking}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalTaxi, "Rideshare", tint = TropicalGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("RIDESHARE: ${selectedStation.rideshare}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }
                }
            }

            // Amenities list
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text("STATION AMENITIES", fontSize = 13.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        selectedStation.amenities.take(3).forEach { amenity ->
                            Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Check, "Checked", tint = TropicalGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(amenity, fontSize = 12.sp, color = CharcoalDark)
                            }
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        selectedStation.amenities.drop(3).forEach { amenity ->
                            Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Check, "Checked", tint = TropicalGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(amenity, fontSize = 12.sp, color = CharcoalDark)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BrightlinePlusScreen(viewModel: BrightlineViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Brightline+",
            onBackClick = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "GET THERE FROM HERE.",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark
            )
            Text(
                text = "Seamless private rides, shuttles & parking integrations.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Flow graphics
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = borderStroke()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Train, "Train", tint = BrightlineDarkYellow, modifier = Modifier.size(36.dp))
                            Text("Train Ride", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                        Icon(Icons.Default.ArrowForward, "to", tint = Color.Gray)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.LocalTaxi, "Rideshare", tint = RestrainedCoral, modifier = Modifier.size(36.dp))
                            Text("Uber Ride", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                        Icon(Icons.Default.ArrowForward, "to", tint = Color.Gray)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Home, "Destination", tint = TropicalGreen, modifier = Modifier.size(36.dp))
                            Text("Destination", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Brightline+ works directly with Uber, local electric shuttles, and airport transport to offer discounted door-to-station mobility in Miami, Aventura, Fort Lauderdale, Boca Raton, West Palm Beach, and Orlando.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun RewardsScreen(viewModel: BrightlineViewModel) {
    val points by viewModel.rewardsPoints.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Rewards",
            onBackClick = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(20.dp)
        ) {
            item {
                Text(
                    text = "BRIGHTLINE REWARDS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Points card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("TOTAL POINTS BALANCE", color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "%,d".format(points),
                            color = BrightlineYellow,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = 0.8f,
                            color = BrightlineYellow,
                            trackColor = Color.Gray,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "2,550 points to your next reward ticket!",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Available Rewards List
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("AVAILABLE REDEMPTIONS", fontSize = 13.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(RewardsData.items) { reward ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = borderStroke()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(reward.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text(reward.description, fontSize = 11.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = { /* Redeemed action */ },
                            colors = ButtonDefaults.buttonColors(containerColor = BrightlineYellow),
                            shape = RoundedCornerShape(8.dp),
                            enabled = reward.isAvailable && points >= reward.pointsRequired
                        ) {
                            Text(
                                text = "${reward.pointsRequired} pts",
                                color = CharcoalDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Points Activity
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("RECENT POINTS ACTIVITY", fontSize = 13.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(RewardsData.activities) { act ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(act.description, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                        Text(act.date, fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(
                        text = if (act.isEarned) "+${act.points}" else "${act.points}",
                        color = if (act.isEarned) TropicalGreen else RestrainedCoral,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Divider(color = LightGray)
            }
        }
    }
}

@Composable
fun PassesScreen(viewModel: BrightlineViewModel) {
    val purchasedPasses by viewModel.purchasedPasses.collectAsState()

    BackHandler {
        viewModel.popScreen()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(
            title = "Transit Passes",
            onBackClick = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(20.dp)
        ) {
            item {
                Text(
                    text = "COMMUTER TRANSIT WALLET",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = CharcoalDark,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Save up to 40% on Florida high-speed connections.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            if (purchasedPasses.isNotEmpty()) {
                item {
                    Text("MY ACTIVE PASSES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                    Spacer(modifier = Modifier.height(6.dp))
                }
                items(purchasedPasses) { pass ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalDark)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(pass.title.uppercase(), color = BrightlineYellow, fontSize = 14.sp, fontWeight = FontWeight.Black)
                            Text("Active Transit Credential", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(20.dp)) }
            }

            item {
                Text("PURCHASE NEW PASSES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(PassData.passes) { pass ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = borderStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(pass.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("$$${pass.price}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = RestrainedCoral)
                        }
                        Text(pass.description, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.purchasePass(pass) },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("BUY PASS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccountScreen(viewModel: BrightlineViewModel) {
    val points by viewModel.rewardsPoints.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        BrightlineHeader(title = "Account")

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Profile Summary card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(BrightlineYellow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("TE", color = CharcoalDark, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text("Tom Example", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("tom@ahyx.org", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Rewards Shortcut Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clickable { viewModel.navigateTo(Screen.REWARDS) },
                    colors = CardDefaults.cardColors(containerColor = BrightlineYellow)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("LOYALTY REWARDS BALANCE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text("%,d POINTS".format(points), fontSize = 20.sp, fontWeight = FontWeight.Black, color = CharcoalDark)
                        }
                        Icon(Icons.Default.CardMembership, "Rewards", tint = CharcoalDark)
                    }
                }
            }

            // Saved Passengers Option
            item {
                AccountOptionRow("Personal Information", Icons.Default.Person) {}
                AccountOptionRow("Saved Passengers", Icons.Default.People) {}
                AccountOptionRow("Payment Cards", Icons.Default.CreditCard) {}
                AccountOptionRow("Travel Preferences", Icons.Default.Settings) {}
                AccountOptionRow("Transit Passes Wallet", Icons.Default.ConfirmationNumber) {
                    viewModel.navigateTo(Screen.PASSES)
                }
                AccountOptionRow("Brightline+ Rides", Icons.Default.LocalTaxi) {
                    viewModel.navigateTo(Screen.BRIGHTLINE_PLUS)
                }
                AccountOptionRow("Help & Sandboxed Support", Icons.Default.Help) {}
                AccountOptionRow("Terms & Sandbox Privacy", Icons.Default.PrivacyTip) {}
            }
        }
    }
}

@Composable
fun AccountOptionRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = title, tint = CharcoalDark, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
        }
        Icon(Icons.Default.ChevronRight, "Navigate", tint = Color.Gray)
    }
    Divider(color = LightGray)
}

// Custom Station Dialog for choosing Departure/Arrival
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSelectionDialog(
    title: String,
    onDismiss: () -> Unit,
    onSelect: (Station) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = {
            Text(
                title.uppercase(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = CharcoalDark,
                letterSpacing = 1.sp
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth()
            ) {
                items(StationData.stations) { station ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(station) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(BrightlineYellow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                station.code,
                                color = CharcoalDark,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(station.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalDark)
                            Text(station.address, fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Divider(color = LightGray)
                }
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp)
    )
}

// Premium helper for Border Stroke setup
private fun borderStroke() = androidx.compose.foundation.BorderStroke(1.dp, BorderGray)
