"""Démarrage d'un environnement : migrations Alembic, jeu de démonstration si la base est vide,
publication de la clé publique sur le registre (avec reprises si le registre n'est pas encore prêt).
Usage : python -m app.bootstrap
"""
from __future__ import annotations

import time

from alembic import command
from alembic.config import Config
from sqlalchemy import func, select, text

from app import models  # noqa: F401
from app.config import get_settings
from app.db import SessionLocal, get_engine
from app.modules.admin.models import Organisation


def main() -> None:
    for _ in range(30):
        try:
            with get_engine().connect() as c:
                c.execute(text("SELECT 1"))
            break
        except Exception:
            print("En attente de PostgreSQL…", flush=True)
            time.sleep(2)
    command.upgrade(Config("alembic.ini"), "head")
    with SessionLocal() as db:
        empty = not db.scalar(select(func.count()).select_from(Organisation))
    if empty and get_settings().environment != "production":
        from app.seed import seed

        print("Base vide : chargement du jeu de démonstration Maison & Marché", flush=True)
        seed()
    print("Initialisation terminée (la clé publique est publiée par le worker dès que le registre répond).",
          flush=True)


if __name__ == "__main__":
    main()
