"""Commandes omnicanales : magasin, en ligne (livraison / retrait), professionnelles."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Cost, Qty, created_at, pk, ts
from app.db import Base

ORDER_STATUSES = {
    "RECUE": "Reçue", "VALIDEE": "Validée", "RESERVEE": "Stock réservé", "EN_PREPARATION": "En préparation",
    "PRETE": "Prête au retrait", "EXPEDIEE": "Expédiée", "REMISE": "Remise au client", "LIVREE": "Livrée",
    "ANNULEE": "Annulée",
}
TRANSITIONS = {
    "RECUE": {"VALIDEE", "ANNULEE"},
    "VALIDEE": {"RESERVEE", "ANNULEE"},
    "RESERVEE": {"EN_PREPARATION", "ANNULEE"},
    "EN_PREPARATION": {"PRETE", "EXPEDIEE", "ANNULEE"},
    "PRETE": {"REMISE", "ANNULEE"},
    "EXPEDIEE": {"LIVREE"},
    "REMISE": set(),
    "LIVREE": set(),
    "ANNULEE": set(),
}


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    channel: Mapped[str] = mapped_column(String(10))  # MAGASIN, WEB, PRO
    fulfilment: Mapped[str] = mapped_column(String(15))  # LIVRAISON, RETRAIT
    source_site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))  # une seule source de stock
    pickup_site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    price_list_code: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20), default="RECUE")
    # Paiement suivi séparément : payé ne signifie pas prêt.
    payment_status: Mapped[str] = mapped_column(String(25), default="NON_PAYEE")
    total_ttc_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    total_tax_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_address: Mapped[dict | None] = mapped_column(JSONB)  # données personnelles : base uniquement
    customer_po_ref: Mapped[str | None] = mapped_column(String(60))
    pickup_code_hash: Mapped[str | None] = mapped_column(String(64))
    idempotency_key: Mapped[str | None] = mapped_column(String(120), unique=True)
    split_group: Mapped[str | None] = mapped_column(String(30))  # commandes issues d'un fractionnement
    created_at: Mapped[datetime] = created_at()
    promised_at: Mapped[datetime | None] = ts()
    ready_at: Mapped[datetime | None] = ts()
    completed_at: Mapped[datetime | None] = ts()
    lines: Mapped[list["OrderLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan",
                                                    order_by="OrderLine.id")


class OrderLine(Base):
    __tablename__ = "order_lines"
    id: Mapped[int] = pk()
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    sku: Mapped[str] = mapped_column(String(40))
    label: Mapped[str] = mapped_column(String(200))
    unit: Mapped[str] = mapped_column(String(10))
    packaging_level: Mapped[str] = mapped_column(String(10), default="PIECE")
    qty_in_base: Mapped[Decimal] = mapped_column(Qty)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit_price_cents: Mapped[int] = mapped_column(BigInteger)
    tax_inclusive: Mapped[bool] = mapped_column(default=True)
    tax_rate_bp: Mapped[int] = mapped_column(Integer)
    tax_regime_code: Mapped[str] = mapped_column(String(40))
    total_ttc_cents: Mapped[int] = mapped_column(BigInteger)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger)
    total_tax_cents: Mapped[int] = mapped_column(BigInteger)
    unit_cost: Mapped[Decimal | None] = mapped_column(Cost)
    picked_base_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    delivered_base_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    returned_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))


class OrderEvent(Base):
    __tablename__ = "order_events"
    id: Mapped[int] = pk()
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    from_status: Mapped[str | None] = mapped_column(String(20))
    to_status: Mapped[str] = mapped_column(String(20))
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    note: Mapped[str | None] = mapped_column(Text)
    at: Mapped[datetime] = created_at()


class PickTask(Base):
    __tablename__ = "pick_tasks"
    id: Mapped[int] = pk()
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    order_line_id: Mapped[int] = mapped_column(ForeignKey("order_lines.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    picked_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    status: Mapped[str] = mapped_column(String(15), default="A_FAIRE")  # A_FAIRE, PRELEVE, ECART
    scanned_code: Mapped[str | None] = mapped_column(String(48))
    picked_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    picked_at: Mapped[datetime | None] = ts()


class Shipment(Base):
    __tablename__ = "shipments"
    id: Mapped[int] = pk()
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"))
    carrier: Mapped[str] = mapped_column(String(60))
    tracking_ref: Mapped[str] = mapped_column(String(60))
    parcels: Mapped[int] = mapped_column(Integer, default=1)
    shipped_at: Mapped[datetime] = created_at()
    delivered_at: Mapped[datetime | None] = ts()
