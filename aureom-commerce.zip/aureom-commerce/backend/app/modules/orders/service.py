"""Reçue → validée → stock réservé → préparation → prête ou expédiée → remise ou livrée.

Règles :
- une commande = une source de stock et un mode de livraison (v1) ; le fractionnement est proposé
  par une règle explicite (propose_split) et ne s'exécute qu'après validation humaine ;
- le paiement est suivi à part : une commande payée n'est pas « prête » ; la remise d'une commande
  en retrait exige en revanche un paiement capturé (sauf compte professionnel à échéance).
"""
from __future__ import annotations

import hashlib
import secrets
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.common import audit, next_code
from app.core.errors import DomainError, NotFound
from app.core.money import line_amount, split_ttc, ttc_from_ht
from app.core.security import CurrentUser
from app.core.types import ZERO, utcnow
from app.core.units import check_quantity
from app.db import notify
from app.modules.admin.models import Organisation, Site
from app.modules.catalog import service as cat
from app.modules.customers.models import Customer
from app.modules.inventory import service as inv
from app.modules.inventory.models import Lot, Reservation, StockPosition
from app.modules.orders.models import ORDER_STATUSES, TRANSITIONS, Order, OrderEvent, OrderLine, PickTask, Shipment
from app.modules.payments import service as pay
from app.modules.traceability import service as trace

PRICE_LISTS = {"MAGASIN": "MAGASIN", "WEB": "WEB", "PRO": "PRO"}


def _transition(db: Session, o: Order, to: str, actor_id: int | None, note: str | None = None) -> None:
    if to not in TRANSITIONS[o.status]:
        raise DomainError("TRANSITION_INTERDITE",
                          f"Passage impossible de « {ORDER_STATUSES[o.status]} » à « {ORDER_STATUSES[to]} »")
    db.add(OrderEvent(order_id=o.id, from_status=o.status, to_status=to, actor_user_id=actor_id, note=note))
    o.status = to
    notify(db, "commande.statut", {"code": o.code, "statut": to, "libelle": ORDER_STATUSES[to]})


def get_order(db: Session, oid: int, lock: bool = False) -> Order:
    q = select(Order).where(Order.id == oid)
    o = db.scalar(q.with_for_update() if lock else q)
    if not o:
        raise NotFound("Commande", oid)
    return o


def create_order(db: Session, data: dict, actor_id: int | None) -> Order:
    key = data.get("idempotency_key")
    if key:
        existing = db.scalar(select(Order).where(Order.idempotency_key == key))
        if existing:
            return existing
    channel, fulfilment = data["channel"], data["fulfilment"]
    if channel not in PRICE_LISTS or fulfilment not in ("LIVRAISON", "RETRAIT"):
        raise DomainError("COMMANDE_INVALIDE", "Canal ou mode de livraison inconnu")
    source = db.get(Site, data["source_site_id"])
    if source is None:
        raise NotFound("Site", data["source_site_id"])
    pickup_id = data.get("pickup_site_id")
    if fulfilment == "RETRAIT":
        pickup_id = pickup_id or source.id
        if pickup_id != source.id:
            raise DomainError("SOURCE_UNIQUE", "En v1, le retrait se fait sur le site source du stock "
                                               "(sinon : transfert préalable ou commande fractionnée)")
        if not source.allows_click_collect:
            raise DomainError("RETRAIT_INDISPONIBLE", f"{source.name} ne propose pas le retrait")
    elif not source.ships_online:
        raise DomainError("EXPEDITION_INDISPONIBLE", f"{source.name} n'expédie pas de commandes")
    if channel == "PRO" and not data.get("customer_id"):
        raise DomainError("CLIENT_REQUIS", "Une commande professionnelle exige un compte client")
    o = Order(code=next_code(db, "CMD"), channel=channel, fulfilment=fulfilment, source_site_id=source.id,
              pickup_site_id=pickup_id, customer_id=data.get("customer_id"), price_list_code=PRICE_LISTS[channel],
              shipping_cents=int(data.get("shipping_cents", 0)), shipping_address=data.get("shipping_address"),
              customer_po_ref=data.get("customer_po_ref"), idempotency_key=key, split_group=data.get("split_group"),
              promised_at=utcnow() + timedelta(days=2))
    db.add(o)
    db.flush()
    for ln in data["lines"]:
        variant_id = ln.get("variant_id") or cat.lookup_code(db, ln["code"])[0].id
        level = ln.get("packaging_level", "PIECE")
        try:
            snap = cat.snapshot(db, o.price_list_code, variant_id, packaging_level=level)
        except DomainError:
            if level == "PIECE":
                raise
            snap = cat.snapshot(db, o.price_list_code, variant_id)
            pk_ = cat.packaging(db, variant_id, level)
            snap.unit_price_cents, snap.qty_in_base, snap.packaging_level = \
                int(snap.unit_price_cents * pk_.qty_in_base), pk_.qty_in_base, level
        qty = check_quantity(Decimal(str(ln["quantity"])), "PCE" if level != "PIECE" else snap.unit)
        if qty <= 0:
            raise DomainError("QUANTITE_INVALIDE", "Quantité strictement positive requise")
        amount = line_amount(snap.unit_price_cents, qty)
        if snap.tax_inclusive:
            ttc = amount
            ht, tax = split_ttc(ttc, snap.tax_rate_bp)
        else:
            ht = amount
            ttc, tax = ttc_from_ht(ht, snap.tax_rate_bp)
        pos = db.get(StockPosition, (variant_id, source.id))
        o.lines.append(OrderLine(variant_id=variant_id, sku=snap.sku, label=snap.label, unit=snap.unit,
                                 packaging_level=level, qty_in_base=snap.qty_in_base, quantity=qty,
                                 unit_price_cents=snap.unit_price_cents, tax_inclusive=snap.tax_inclusive,
                                 tax_rate_bp=snap.tax_rate_bp, tax_regime_code=snap.tax_regime_code,
                                 total_ttc_cents=ttc, total_ht_cents=ht, total_tax_cents=tax,
                                 unit_cost=pos.avg_unit_cost if pos else None))
    db.flush()
    o.total_ht_cents = sum(l.total_ht_cents for l in o.lines)
    o.total_tax_cents = sum(l.total_tax_cents for l in o.lines)
    o.total_ttc_cents = sum(l.total_ttc_cents for l in o.lines) + o.shipping_cents
    db.add(OrderEvent(order_id=o.id, from_status=None, to_status="RECUE", actor_user_id=actor_id))
    audit(db, actor_id, "commande.creation", "order", o.id, f"Commande {o.code} ({channel}, {fulfilment})")
    notify(db, "commande.statut", {"code": o.code, "statut": "RECUE"})
    return o


def validate(db: Session, o: Order, actor_id: int | None) -> None:
    if not o.lines:
        raise DomainError("COMMANDE_VIDE", "Commande sans ligne")
    _transition(db, o, "VALIDEE", actor_id)


def reserve(db: Session, o: Order, actor_id: int | None, hold_hours: int = 72) -> list[Reservation]:
    """Réserve toutes les lignes ou aucune (transaction)."""
    if o.status != "VALIDEE":
        raise DomainError("ETAT_INVALIDE", "Seule une commande validée peut être réservée")
    res = []
    for l in o.lines:
        res.append(inv.reserve(db, l.id, l.variant_id, o.source_site_id, l.quantity * l.qty_in_base,
                               expires_at=utcnow() + timedelta(hours=hold_hours)))
    _transition(db, o, "RESERVEE", actor_id)
    return res


def start_preparation(db: Session, o: Order, actor_id: int | None) -> list[PickTask]:
    if o.status != "RESERVEE":
        raise DomainError("ETAT_INVALIDE", "La commande doit être réservée avant préparation")
    tasks = []
    for l in o.lines:
        lines, missing = inv.allocate_fefo(db, l.variant_id, o.source_site_id, l.quantity * l.qty_in_base,
                                           exclude_kinds=("PREPARATION",))
        for ml in lines:
            t = PickTask(order_id=o.id, order_line_id=l.id, site_id=o.source_site_id, location_id=ml.location_id,
                         lot_id=ml.lot_id, quantity=-ml.quantity)
            db.add(t)
            tasks.append(t)
        if missing > 0:
            raise DomainError("PREPARATION_IMPOSSIBLE", f"Stock physique insuffisant pour préparer {l.label} "
                                                        f"(manque {missing})")
    db.flush()
    _transition(db, o, "EN_PREPARATION", actor_id)
    return tasks


def confirm_pick(db: Session, task_id: int, picked_qty, scanned_code: str, actor_id: int) -> PickTask:
    t = db.get(PickTask, task_id)
    if not t:
        raise NotFound("Tâche de préparation", task_id)
    if t.status != "A_FAIRE":
        raise DomainError("DEJA_PRELEVE", "Tâche déjà traitée")
    line = db.get(OrderLine, t.order_line_id)
    variant, _ = cat.lookup_code(db, scanned_code)
    if variant.id != line.variant_id:
        raise DomainError("MAUVAIS_ARTICLE", f"Article scanné ({variant.label}) différent de l'article attendu "
                                             f"({line.label})")
    picked = check_quantity(Decimal(str(picked_qty)), line.unit)
    if picked > t.quantity:
        raise DomainError("SUR_PRELEVEMENT", "Quantité prélevée supérieure à la quantité demandée")
    prep = inv.site_location(db, t.site_id, "PREPARATION")
    if picked > 0:
        inv.post_movements(db, "PRELEVEMENT", [
            inv.MoveLine(line.variant_id, t.location_id, -picked, "DISPONIBLE", t.lot_id),
            inv.MoveLine(line.variant_id, prep.id, picked, "DISPONIBLE", t.lot_id)],
            actor_id=actor_id, document_type="COMMANDE", document_id=t.order_id,
            document_ref=db.get(Order, t.order_id).code)
    t.picked_qty, t.scanned_code, t.picked_by, t.picked_at = picked, scanned_code, actor_id, utcnow()
    t.status = "PRELEVE" if picked == t.quantity else "ECART"
    line.picked_base_qty += picked
    if t.status == "ECART":
        inv.record_exception(db, "ECART_PREPARATION", line.variant_id, t.site_id, t.quantity - picked,
                             db.get(Order, t.order_id).code,
                             f"Prélèvement incomplet : {t.quantity - picked} manquant(s) à l'emplacement {t.location_id}")
    notify(db, "commande.preparation", {"tache": t.id, "statut": t.status})
    return t


def _all_picked(db: Session, o: Order) -> bool:
    return all(l.picked_base_qty >= l.quantity * l.qty_in_base for l in o.lines)


def mark_ready(db: Session, o: Order, actor_id: int) -> str:
    if o.fulfilment != "RETRAIT":
        raise DomainError("MODE_INVALIDE", "« Prête » concerne les commandes en retrait")
    if not _all_picked(db, o):
        raise DomainError("PREPARATION_INCOMPLETE", "Toutes les lignes ne sont pas prélevées")
    code = f"{secrets.randbelow(10**6):06d}"
    o.pickup_code_hash = hashlib.sha256(f"{o.code}:{code}".encode()).hexdigest()
    o.ready_at = utcnow()
    _transition(db, o, "PRETE", actor_id, "Code de retrait communiqué au client (simulé)")
    return code


def _consume_reserved(db: Session, o: Order, actor_id: int, movement_type: str = "EXPEDITION") -> None:
    prep = inv.site_location(db, o.source_site_id, "PREPARATION")
    for l in o.lines:
        r = db.scalar(select(Reservation).where(Reservation.order_line_id == l.id, Reservation.status == "ACTIVE"))
        tasks = list(db.scalars(select(PickTask).where(PickTask.order_line_id == l.id, PickTask.picked_qty > 0)))
        mls = [inv.MoveLine(l.variant_id, prep.id, -t.picked_qty, "DISPONIBLE", t.lot_id) for t in tasks]
        if mls:
            inv.post_movements(db, movement_type, mls, actor_id=actor_id, document_type="COMMANDE", document_id=o.id,
                               document_ref=o.code, lot_attribution="SCANNE")
        l.delivered_base_qty = sum((t.picked_qty for t in tasks), ZERO)
        if r:
            inv.release_reservation(db, r, "CONSOMMEE")


def refresh_payment_status(db: Session, o: Order) -> None:
    paid = pay.paid_cents(db, "COMMANDE", o.id)
    if paid <= 0:
        refunded_any = any(p.status == "CAPTURE" for p in pay.payments_for(db, "COMMANDE", o.id))
        o.payment_status = "REMBOURSEE" if refunded_any else "NON_PAYEE"
    elif paid < o.total_ttc_cents:
        o.payment_status = "PARTIELLEMENT_PAYEE"
    else:
        o.payment_status = "PAYEE"


def _payment_ok_for_handover(db: Session, o: Order) -> bool:
    if o.payment_status == "PAYEE":
        return True
    if o.channel == "PRO" and o.customer_id:
        c = db.get(Customer, o.customer_id)
        return bool(c and c.payment_terms_days)
    return False


def handover(db: Session, o: Order, pickup_code: str, actor_id: int) -> None:
    if o.status != "PRETE":
        raise DomainError("ETAT_INVALIDE", "La commande n'est pas prête")
    expected = hashlib.sha256(f"{o.code}:{pickup_code}".encode()).hexdigest()
    if not secrets.compare_digest(expected, o.pickup_code_hash or ""):
        raise DomainError("CODE_RETRAIT_INVALIDE", "Code de retrait invalide", 403)
    refresh_payment_status(db, o)
    if not _payment_ok_for_handover(db, o):
        raise DomainError("PAIEMENT_REQUIS", "Paiement non capturé : encaissez avant de remettre la commande")
    _consume_reserved(db, o, actor_id)
    o.completed_at = utcnow()
    _transition(db, o, "REMISE", actor_id)
    _customer_shipment_events(db, o, actor_id)


def ship(db: Session, o: Order, carrier: str, actor_id: int, parcels: int = 1) -> Shipment:
    if o.fulfilment != "LIVRAISON":
        raise DomainError("MODE_INVALIDE", "Commande en retrait : utilisez la remise")
    if o.status != "EN_PREPARATION" or not _all_picked(db, o):
        raise DomainError("PREPARATION_INCOMPLETE", "Préparation incomplète")
    refresh_payment_status(db, o)
    if not _payment_ok_for_handover(db, o):
        raise DomainError("PAIEMENT_REQUIS", "Paiement non capturé : expédition bloquée")
    _consume_reserved(db, o, actor_id)
    s = Shipment(order_id=o.id, carrier=carrier, tracking_ref="SIM" + secrets.token_hex(5).upper(), parcels=parcels)
    db.add(s)
    _transition(db, o, "EXPEDIEE", actor_id, f"Transporteur {carrier} (simulé)")
    _customer_shipment_events(db, o, actor_id)
    return s


def deliver(db: Session, o: Order, actor_id: int | None) -> None:
    o.completed_at = utcnow()
    _transition(db, o, "LIVREE", actor_id, "Confirmation transporteur (simulée)")


def _customer_shipment_events(db: Session, o: Order, actor_id: int | None) -> None:
    """Événement partagé sans donnée personnelle : référence du lot, site, empreinte salée des détails."""
    site = db.get(Site, o.source_site_id)
    counterparty = None
    if o.customer_id:
        c = db.get(Customer, o.customer_id)
        if c and c.org_id:
            org = db.get(Organisation, c.org_id)
            counterparty = org.msp_id if org and org.ledger_member else None
    seen = set()
    for t in db.scalars(select(PickTask).where(PickTask.order_id == o.id, PickTask.lot_id.is_not(None))):
        if t.lot_id in seen:
            continue
        seen.add(t.lot_id)
        trace.declare_event(db, event_type="CUSTOMER_SHIPMENT", occurred_at=utcnow(), actor_id=actor_id,
                            lot=db.get(Lot, t.lot_id), counterparty_org=counterparty,
                            location_ref=site.gln or site.code,
                            details={"commande": o.code, "canal": o.channel, "mode": o.fulfilment},
                            source_type="COMMANDE", source_id=o.id)


def cancel(db: Session, o: Order, reason: str, actor_id: int) -> None:
    if o.status in ("EXPEDIEE", "REMISE", "LIVREE", "ANNULEE"):
        raise DomainError("ANNULATION_IMPOSSIBLE", "Commande déjà remise ou expédiée : utilisez un retour")
    prep = inv.site_location(db, o.source_site_id, "PREPARATION") if o.status in ("EN_PREPARATION", "PRETE") else None
    for l in o.lines:
        r = db.scalar(select(Reservation).where(Reservation.order_line_id == l.id, Reservation.status == "ACTIVE"))
        if r:
            inv.release_reservation(db, r)
        if prep:
            for t in db.scalars(select(PickTask).where(PickTask.order_line_id == l.id, PickTask.picked_qty > 0)):
                inv.post_movements(db, "DEPLACEMENT", [
                    inv.MoveLine(l.variant_id, prep.id, -t.picked_qty, "DISPONIBLE", t.lot_id),
                    inv.MoveLine(l.variant_id, t.location_id, t.picked_qty, "DISPONIBLE", t.lot_id)],
                    actor_id=actor_id, document_type="COMMANDE", document_id=o.id, document_ref=o.code,
                    reason="Annulation de commande : remise en emplacement")
    _transition(db, o, "ANNULEE", actor_id, reason)


def pay_order(db: Session, o: Order, method: str, amount_cents: int, idempotency_key: str, user: CurrentUser,
              card_token: str | None = None):
    o = get_order(db, o.id, lock=True)
    if o.status == "ANNULEE":
        raise DomainError("COMMANDE_ANNULEE", "Commande annulée")
    p = pay.create_payment(db, target_type="COMMANDE", target_id=o.id, method=method, amount_cents=amount_cents,
                           idempotency_key=idempotency_key, due_cents=o.total_ttc_cents, actor_id=user.id,
                           card_token=card_token)
    refresh_payment_status(db, o)
    return p


def propose_split(db: Session, lines: list[dict], site_ids: list[int]) -> dict:
    """Règle explicite de fractionnement :
    1. si un site couvre toute la commande, on le choisit (entrepôt prioritaire, puis plus fort disponible) ;
    2. sinon, affectation gloutonne : chaque ligne va au site ayant le plus de disponible, en privilégiant
       les sites déjà retenus (minimiser le nombre d'envois) ;
    3. une ligne non couvrable reste en « non servie ». Rien n'est créé sans validation."""
    sites = [db.get(Site, s) for s in site_ids]
    sites.sort(key=lambda s: (s.kind != "ENTREPOT", s.id))
    need = {int(l["variant_id"]): Decimal(str(l["quantity"])) for l in lines}

    def avail(v, s):
        return inv.position(db, v, s.id)["disponible"]

    for s in sites:
        if all(avail(v, s) >= q for v, q in need.items()):
            return {"fractionnement": False, "regle": "Un site couvre toute la commande",
                    "plan": [{"site_id": s.id, "site": s.name, "lignes": [{"variant_id": v, "quantite": str(q)}
                                                                          for v, q in need.items()]}],
                    "non_servi": []}
    chosen: dict[int, list] = {}
    unserved = []
    for v, q in need.items():
        cands = sorted(sites, key=lambda s: (s.id not in chosen, -avail(v, s)))
        rest = q
        for s in cands:
            a = avail(v, s)
            if a <= 0 or rest <= 0:
                continue
            take = min(a, rest)
            chosen.setdefault(s.id, []).append({"variant_id": v, "quantite": str(take)})
            rest -= take
        if rest > 0:
            unserved.append({"variant_id": v, "quantite": str(rest)})
    return {"fractionnement": True, "regle": "Affectation gloutonne, minimisation du nombre de sites",
            "plan": [{"site_id": sid, "site": db.get(Site, sid).name, "lignes": ls} for sid, ls in chosen.items()],
            "non_servi": unserved}


def expire_reservations(db: Session) -> int:
    n = 0
    for r in db.scalars(select(Reservation).where(Reservation.status == "ACTIVE", Reservation.expires_at < utcnow())):
        line = db.get(OrderLine, r.order_line_id)
        o = db.get(Order, line.order_id)
        if o.status == "RESERVEE":  # une commande en préparation garde sa réservation
            inv.release_reservation(db, r, "EXPIREE")
            n += 1
    return n
