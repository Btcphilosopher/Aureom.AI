"""Règles du catalogue et de la tarification."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.core.common import audit
from app.core.errors import DomainError, NotFound
from app.core.types import utcnow
from app.core.units import PACKAGING_LABELS, PACKAGING_LEVELS, UNITS, check_quantity
from app.modules.catalog.models import (Barcode, Packaging, Price, PriceList, Product, ProductFamily, TaxRate,
                                        TaxRegime, Variant)
from app.config import get_settings
from zoneinfo import ZoneInfo


def gtin_check_digit_ok(code: str) -> bool:
    """Clé de contrôle GS1 (EAN-8/13, GTIN-14)."""
    if not code.isdigit() or len(code) not in (8, 12, 13, 14):
        return False
    digits = [int(c) for c in code]
    body, check = digits[:-1], digits[-1]
    total = sum(d * (3 if i % 2 == 0 else 1) for i, d in enumerate(reversed(body)))
    return (10 - total % 10) % 10 == check


def gtin_with_check(body: str) -> str:
    digits = [int(c) for c in body]
    total = sum(d * (3 if i % 2 == 0 else 1) for i, d in enumerate(reversed(digits)))
    return body + str((10 - total % 10) % 10)


def create_product(db: Session, data: dict, user_id: int | None) -> Product:
    """data : code, name, description, family_code, tax_regime_code, base_unit, lot_tracked, expiry_kind,
    variants: [{sku, label, gtin, attributes, packagings: [{level, label, qty_in_base, gtin}]}]"""
    fam = db.scalar(select(ProductFamily).where(ProductFamily.code == data["family_code"]))
    if not fam:
        raise NotFound("Famille", data["family_code"])
    regime = db.scalar(select(TaxRegime).where(TaxRegime.code == data["tax_regime_code"]))
    if not regime:
        raise NotFound("Régime de taxe", data["tax_regime_code"])
    base_unit = data.get("base_unit", "PCE")
    if base_unit not in UNITS:
        raise DomainError("UNITE_INCONNUE", f"Unité inconnue : {base_unit}")
    if db.scalar(select(Product).where(Product.code == data["code"])):
        raise DomainError("CODE_EXISTANT", f"Le code article {data['code']} existe déjà", 409)
    if data.get("expiry_kind") not in (None, "DLC", "DDM"):
        raise DomainError("PEREMPTION_INVALIDE", "Type de date : DLC, DDM ou aucune")
    p = Product(code=data["code"], name=data["name"], description=data.get("description", ""),
                brand=data.get("brand"), family_id=fam.id, tax_regime_id=regime.id, base_unit=base_unit,
                lot_tracked=bool(data.get("lot_tracked") or data.get("expiry_kind")),
                serial_tracked=bool(data.get("serial_tracked")), expiry_kind=data.get("expiry_kind"),
                storage_temp_min_c=data.get("storage_temp_min_c"), storage_temp_max_c=data.get("storage_temp_max_c"))
    db.add(p)
    db.flush()
    for vdata in data.get("variants", []):
        add_variant(db, p, vdata)
    audit(db, user_id, "catalogue.creation", "product", p.id, f"Création de l'article {p.code} — {p.name}")
    return p


def add_variant(db: Session, p: Product, vdata: dict) -> Variant:
    gtin = vdata.get("gtin")
    if gtin and not gtin_check_digit_ok(gtin):
        raise DomainError("GTIN_INVALIDE", f"Clé de contrôle GTIN incorrecte : {gtin}")
    v = Variant(product_id=p.id, sku=vdata["sku"], label=vdata.get("label", p.name),
                attributes=vdata.get("attributes", {}), gtin=gtin)
    db.add(v)
    db.flush()
    packs = vdata.get("packagings") or [{"level": "PIECE", "label": "Pièce", "qty_in_base": 1}]
    validate_packaging_chain(packs, p.base_unit)
    prev = None
    for pk_ in sorted(packs, key=lambda x: Decimal(str(x["qty_in_base"]))):
        qty = Decimal(str(pk_["qty_in_base"]))
        if pk_.get("gtin") and not gtin_check_digit_ok(pk_["gtin"]):
            raise DomainError("GTIN_INVALIDE", f"Clé de contrôle GTIN incorrecte : {pk_['gtin']}")
        pack = Packaging(variant_id=v.id, level=pk_["level"], label=pk_.get("label", PACKAGING_LABELS[pk_["level"]]),
                         qty_in_base=qty, gtin=pk_.get("gtin"), gross_weight_kg=pk_.get("gross_weight_kg"),
                         contains_level=prev.level if prev else None,
                         contains_qty=(qty / prev.qty_in_base) if prev else None)
        db.add(pack)
        db.flush()
        code = pk_.get("gtin") or (gtin if pk_["level"] == "PIECE" else None)
        if code:
            db.add(Barcode(code=code, symbology="EAN13" if len(code) == 13 else "GTIN14", variant_id=v.id,
                           packaging_id=pack.id))
        prev = pack
    return v


def validate_packaging_chain(packs: list[dict], base_unit: str) -> None:
    """Pièce < paquet < carton < palette ; chaque niveau contient un nombre entier du niveau inférieur."""
    seen = set()
    ordered = sorted(packs, key=lambda x: PACKAGING_LEVELS.index(x["level"]) if x["level"] in PACKAGING_LEVELS else 99)
    prev_qty = None
    for pk_ in ordered:
        if pk_["level"] not in PACKAGING_LEVELS:
            raise DomainError("CONDITIONNEMENT_INVALIDE", f"Niveau inconnu : {pk_['level']}")
        if pk_["level"] in seen:
            raise DomainError("CONDITIONNEMENT_INVALIDE", f"Niveau en double : {pk_['level']}")
        seen.add(pk_["level"])
        qty = check_quantity(Decimal(str(pk_["qty_in_base"])), base_unit)
        if qty <= 0:
            raise DomainError("CONDITIONNEMENT_INVALIDE", "Quantité de conditionnement nulle")
        if prev_qty is not None:
            if qty <= prev_qty:
                raise DomainError("CONDITIONNEMENT_INVALIDE",
                                  f"Le niveau {PACKAGING_LABELS[pk_['level']]} doit contenir plus que le niveau inférieur")
            ratio = qty / prev_qty
            if ratio != ratio.to_integral_value():
                raise DomainError("CONDITIONNEMENT_INVALIDE",
                                  f"Le niveau {PACKAGING_LABELS[pk_['level']]} doit contenir un nombre entier "
                                  f"du niveau inférieur (rapport {str(ratio.normalize()).replace('.', ',')})")
        prev_qty = qty


def packaging(db: Session, variant_id: int, level: str) -> Packaging:
    p = db.scalar(select(Packaging).where(Packaging.variant_id == variant_id, Packaging.level == level))
    if not p:
        raise DomainError("CONDITIONNEMENT_ABSENT", f"Conditionnement « {PACKAGING_LABELS.get(level, level)} » "
                                                    f"non défini pour cet article")
    return p


def tax_rate_at(db: Session, regime_id: int, on: date) -> TaxRate:
    r = db.scalar(select(TaxRate).where(TaxRate.regime_id == regime_id, TaxRate.valid_from <= on,
                                        or_(TaxRate.valid_to.is_(None), TaxRate.valid_to > on)))
    if not r:
        raise DomainError("TAUX_ABSENT", "Aucun taux de taxe configuré à cette date pour ce régime")
    return r


def set_price(db: Session, price_list_code: str, variant_id: int, amount_cents: int, valid_from: datetime | None,
              user_id: int | None, packaging_level: str = "PIECE", is_promotion: bool = False,
              valid_to: datetime | None = None) -> Price:
    """Publie un prix daté. Le prix ouvert en cours est borné à la date d'effet du nouveau.
    Les ventes passées gardent leurs prix figés : aucun document historique n'est modifié."""
    if amount_cents < 0:
        raise DomainError("PRIX_NEGATIF", "Un prix ne peut pas être négatif")
    pl = db.scalar(select(PriceList).where(PriceList.code == price_list_code))
    if not pl:
        raise NotFound("Liste de prix", price_list_code)
    valid_from = valid_from or utcnow()
    current = db.scalar(select(Price).where(
        Price.price_list_id == pl.id, Price.variant_id == variant_id, Price.packaging_level == packaging_level,
        Price.valid_from <= valid_from, or_(Price.valid_to.is_(None), Price.valid_to > valid_from)).with_for_update())
    if current is not None:
        if current.valid_from == valid_from:
            raise DomainError("PRIX_CONFLIT", "Un prix existe déjà avec cette date d'effet", 409)
        if is_promotion and valid_to is not None and (current.valid_to is None or current.valid_to > valid_to):
            # Promotion temporaire : le prix courant est scindé (avant / après la promotion).
            after_end = current.valid_to
            current.valid_to = valid_from
            db.flush()
            promo = Price(price_list_id=pl.id, variant_id=variant_id, packaging_level=packaging_level,
                          amount_cents=amount_cents, valid_from=valid_from, valid_to=valid_to, is_promotion=True,
                          created_by=user_id)
            db.add(promo)
            db.add(Price(price_list_id=pl.id, variant_id=variant_id, packaging_level=packaging_level,
                         amount_cents=current.amount_cents, valid_from=valid_to, valid_to=after_end,
                         created_by=user_id))
            db.flush()
            audit(db, user_id, "prix.promotion", "price", promo.id, f"Promotion {pl.code} variante {variant_id}")
            return promo
        current.valid_to = valid_from
    later = db.scalar(select(Price.valid_from).where(
        Price.price_list_id == pl.id, Price.variant_id == variant_id, Price.packaging_level == packaging_level,
        Price.valid_from > valid_from).order_by(Price.valid_from).limit(1))
    p = Price(price_list_id=pl.id, variant_id=variant_id, packaging_level=packaging_level, amount_cents=amount_cents,
              valid_from=valid_from, valid_to=valid_to or later, is_promotion=is_promotion, created_by=user_id)
    db.add(p)
    db.flush()
    audit(db, user_id, "prix.publication", "price", p.id,
          f"Prix {pl.code} variante {variant_id} ({packaging_level}) : {amount_cents} c à partir de {valid_from:%d/%m/%Y %H:%M}")
    return p


def price_at(db: Session, price_list_code: str, variant_id: int, at: datetime | None = None,
             packaging_level: str = "PIECE") -> tuple[Price, PriceList]:
    at = at or utcnow()
    row = db.execute(select(Price, PriceList).join(PriceList, PriceList.id == Price.price_list_id).where(
        PriceList.code == price_list_code, Price.variant_id == variant_id, Price.packaging_level == packaging_level,
        Price.valid_from <= at, or_(Price.valid_to.is_(None), Price.valid_to > at))).first()
    if not row:
        raise DomainError("PRIX_ABSENT", f"Aucun prix en vigueur ({price_list_code}) pour cet article")
    return row[0], row[1]


def reference_price(db: Session, price_list_code: str, variant_id: int, at: datetime | None = None) -> int | None:
    """Prix de référence d'une réduction : prix le plus bas pratiqué sur les 30 jours précédant
    l'application de la réduction (art. L112-1-1 du code de la consommation — à vérifier)."""
    at = at or utcnow()
    start = at - timedelta(days=30)
    return db.scalar(select(func.min(Price.amount_cents)).join(PriceList, PriceList.id == Price.price_list_id).where(
        PriceList.code == price_list_code, Price.variant_id == variant_id, Price.packaging_level == "PIECE",
        Price.valid_from < at, or_(Price.valid_to.is_(None), Price.valid_to > start)))


@dataclass
class LineSnapshot:
    variant_id: int
    sku: str
    label: str
    description: str
    unit: str
    packaging_level: str
    qty_in_base: Decimal
    unit_price_cents: int
    price_id: int
    tax_inclusive: bool
    tax_rate_bp: int
    tax_regime_code: str


def snapshot(db: Session, price_list_code: str, variant_id: int, at: datetime | None = None,
             packaging_level: str = "PIECE") -> LineSnapshot:
    """Fige libellé, description, prix et taux au moment de la vente."""
    at = at or utcnow()
    v = db.get(Variant, variant_id)
    if not v or v.status != "ACTIF":
        raise DomainError("ARTICLE_INACTIF", "Article inconnu ou inactif")
    price, pl = price_at(db, price_list_code, variant_id, at, packaging_level)
    local_day = at.astimezone(ZoneInfo(get_settings().timezone)).date()
    rate = tax_rate_at(db, v.product.tax_regime_id, local_day)
    regime = db.get(TaxRegime, v.product.tax_regime_id)
    pack = packaging(db, variant_id, packaging_level)
    return LineSnapshot(variant_id=v.id, sku=v.sku, label=v.label, description=v.product.description[:500],
                        unit=v.product.base_unit, packaging_level=packaging_level, qty_in_base=pack.qty_in_base,
                        unit_price_cents=price.amount_cents, price_id=price.id, tax_inclusive=pl.tax_inclusive,
                        tax_rate_bp=rate.rate_bp, tax_regime_code=regime.code)


def lookup_code(db: Session, code: str) -> tuple[Variant, Packaging | None]:
    """Résolution d'un scan : code-barres (pièce ou carton) ou SKU."""
    code = code.strip()
    bc = db.scalar(select(Barcode).where(Barcode.code == code))
    if bc:
        return db.get(Variant, bc.variant_id), db.get(Packaging, bc.packaging_id) if bc.packaging_id else None
    v = db.scalar(select(Variant).where(Variant.sku == code))
    if v:
        return v, None
    raise NotFound("Code", code)


def search(db: Session, text_: str, limit: int = 20) -> list[Variant]:
    like = f"%{text_.strip()}%"
    return list(db.scalars(select(Variant).join(Product).where(or_(
        Variant.label.ilike(like), Variant.sku.ilike(like), Product.name.ilike(like), Variant.gtin == text_.strip(),
        and_(Product.brand.is_not(None), Product.brand.ilike(like)))).limit(limit)))
