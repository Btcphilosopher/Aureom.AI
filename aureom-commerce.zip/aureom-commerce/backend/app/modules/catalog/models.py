"""Catalogue : familles, articles, variantes (SKU), codes-barres, conditionnements, fournisseurs,
documents, listes de prix par canal avec dates d'effet, régimes de taxe configurés."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, Numeric, String,
                        Text, UniqueConstraint, text)
from sqlalchemy.dialects.postgresql import ExcludeConstraint, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Qty, created_at, pk
from app.db import Base


class TaxRegime(Base):
    __tablename__ = "tax_regimes"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    label: Mapped[str] = mapped_column(String(120))
    country: Mapped[str] = mapped_column(String(2), default="FR")
    rates: Mapped[list["TaxRate"]] = relationship(lazy="selectin", order_by="TaxRate.valid_from")


class TaxRate(Base):
    """Taux applicable à un régime sur une période (configuration, pas une constante du code)."""

    __tablename__ = "tax_rates"
    __table_args__ = (
        CheckConstraint("rate_bp >= 0 AND rate_bp <= 10000", name="taux"),
        ExcludeConstraint(("regime_id", "="), (text("daterange(valid_from, valid_to, '[)')"), "&&"),
                          name="tax_rates_sans_chevauchement", using="gist"),
    )
    id: Mapped[int] = pk()
    regime_id: Mapped[int] = mapped_column(ForeignKey("tax_regimes.id"))
    rate_bp: Mapped[int] = mapped_column(Integer)
    valid_from: Mapped[date] = mapped_column(Date)
    valid_to: Mapped[date | None] = mapped_column(Date)
    source_note: Mapped[str | None] = mapped_column(String(300))


class ProductFamily(Base):
    __tablename__ = "product_families"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("product_families.id"))


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    brand: Mapped[str | None] = mapped_column(String(100))
    family_id: Mapped[int] = mapped_column(ForeignKey("product_families.id"))
    tax_regime_id: Mapped[int] = mapped_column(ForeignKey("tax_regimes.id"))
    base_unit: Mapped[str] = mapped_column(String(10), default="PCE")
    lot_tracked: Mapped[bool] = mapped_column(Boolean, default=False)
    serial_tracked: Mapped[bool] = mapped_column(Boolean, default=False)
    expiry_kind: Mapped[str | None] = mapped_column(String(3))  # DLC, DDM ou NULL
    storage_temp_min_c: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    storage_temp_max_c: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    status: Mapped[str] = mapped_column(String(20), default="ACTIF")
    created_at: Mapped[datetime] = created_at()
    variants: Mapped[list["Variant"]] = relationship(back_populates="product", lazy="selectin")


class Variant(Base):
    __tablename__ = "variants"
    id: Mapped[int] = pk()
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    sku: Mapped[str] = mapped_column(String(40), unique=True)
    label: Mapped[str] = mapped_column(String(200))
    attributes: Mapped[dict] = mapped_column(JSONB, default=dict)
    gtin: Mapped[str | None] = mapped_column(String(14), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="ACTIF")
    product: Mapped[Product] = relationship(back_populates="variants", lazy="joined")
    packagings: Mapped[list["Packaging"]] = relationship(lazy="selectin", order_by="Packaging.qty_in_base")


class Packaging(Base):
    """Niveau de conditionnement. qty_in_base = nombre d'unités de base contenues (ex. carton = 24 pièces)."""

    __tablename__ = "packagings"
    __table_args__ = (UniqueConstraint("variant_id", "level"), CheckConstraint("qty_in_base > 0", name="positif"))
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    level: Mapped[str] = mapped_column(String(10))  # PIECE, PAQUET, CARTON, PALETTE
    label: Mapped[str] = mapped_column(String(120))
    qty_in_base: Mapped[Decimal] = mapped_column(Qty)
    contains_level: Mapped[str | None] = mapped_column(String(10))
    contains_qty: Mapped[Decimal | None] = mapped_column(Qty)
    gtin: Mapped[str | None] = mapped_column(String(14), unique=True)
    gross_weight_kg: Mapped[Decimal | None] = mapped_column(Numeric(10, 3))


class Barcode(Base):
    __tablename__ = "barcodes"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(48), unique=True)
    symbology: Mapped[str] = mapped_column(String(20))  # EAN13, GTIN14, CODE128
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    packaging_id: Mapped[int | None] = mapped_column(ForeignKey("packagings.id"))


class ProductSupplier(Base):
    __tablename__ = "product_suppliers"
    __table_args__ = (UniqueConstraint("variant_id", "supplier_id"),)
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    supplier_ref: Mapped[str] = mapped_column(String(60))
    purchase_packaging_id: Mapped[int] = mapped_column(ForeignKey("packagings.id"))
    cost_cents_per_pack: Mapped[int] = mapped_column(BigInteger)  # HT
    min_order_packs: Mapped[int] = mapped_column(Integer, default=1)
    lead_time_days: Mapped[int] = mapped_column(Integer, default=5)
    preferred: Mapped[bool] = mapped_column(Boolean, default=True)


class ProductDocument(Base):
    __tablename__ = "product_documents"
    id: Mapped[int] = pk()
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    kind: Mapped[str] = mapped_column(String(30))  # FICHE_TECHNIQUE, NOTICE, FDS, DECLARATION_CE
    title: Mapped[str] = mapped_column(String(200))
    object_id: Mapped[int] = mapped_column(ForeignKey("stored_objects.id"))
    created_at: Mapped[datetime] = created_at()


class PriceList(Base):
    __tablename__ = "price_lists"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    label: Mapped[str] = mapped_column(String(120))
    channel: Mapped[str] = mapped_column(String(20))  # MAGASIN, WEB, PRO
    tax_inclusive: Mapped[bool] = mapped_column(Boolean, default=True)  # TTC pour les particuliers
    currency: Mapped[str] = mapped_column(String(3), default="EUR")


class Price(Base):
    """Prix daté. Jamais modifié en place : un changement crée une nouvelle ligne (historique conservé).
    Une contrainte d'exclusion interdit deux prix actifs simultanés pour un même article/conditionnement."""

    __tablename__ = "prices"
    __table_args__ = (
        CheckConstraint("amount_cents >= 0", name="positif"),
        ExcludeConstraint(("price_list_id", "="), ("variant_id", "="), ("packaging_level", "="),
                          (text("tstzrange(valid_from, valid_to, '[)')"), "&&"),
                          name="prices_sans_chevauchement", using="gist"),
    )
    id: Mapped[int] = pk()
    price_list_id: Mapped[int] = mapped_column(ForeignKey("price_lists.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    packaging_level: Mapped[str] = mapped_column(String(10), default="PIECE")
    amount_cents: Mapped[int] = mapped_column(BigInteger)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    valid_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_promotion: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
