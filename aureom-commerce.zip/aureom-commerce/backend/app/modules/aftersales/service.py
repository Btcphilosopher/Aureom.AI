"""Retours et rappels.

Retour : réception en zone RETOURS à l'état « à inspecter » (non vendable) → inspection → disposition
explicite. Le remboursement est une opération distincte qui ne remet RIEN en stock vendable.

Rappel : identification des lots, blocage des stocks, recherche des destinations connues (avec niveau
de certitude : lot scanné ou présumé FEFO), tâches de suivi, journal des décisions et communications,
événement RECALL publié sur le registre.
"""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.common import audit, next_code
from app.core.errors import DomainError, NotFound
from app.core.money import round_cents
from app.core.types import ZERO, utcnow
from app.core.units import check_quantity, format_qty
from app.db import notify
from app.modules.admin.models import Organisation, Site
from app.modules.aftersales.models import (CONDITIONS, DISPOSITIONS, Recall, RecallLog, RecallLot, RecallTask,
                                           ReturnLine, ReturnRequest)
from app.modules.automation.alerts import raise_alert
from app.modules.customers import service as cust
from app.modules.inventory import service as inv
from app.modules.inventory.models import Lot, Reservation, StockBalance, StockMovement, StockPosition, TransferLine, Transfer
from app.modules.orders.models import Order, OrderLine
from app.modules.payments import service as pay
from app.modules.pos.models import Sale, SaleLine
from app.modules.traceability import service as trace


def create_return(db: Session, *, origin: str, source_id: int, lines: list[dict], site_id: int,
                  actor_id: int) -> ReturnRequest:
    if origin == "VENTE":
        sale = db.get(Sale, source_id)
        if not sale or sale.status != "TERMINEE":
            raise DomainError("VENTE_INVALIDE", "Retour possible uniquement sur une vente terminée")
        customer_id = sale.customer_id
    elif origin == "COMMANDE":
        o = db.get(Order, source_id)
        if not o or o.status not in ("REMISE", "LIVREE"):
            raise DomainError("COMMANDE_INVALIDE", "Retour possible uniquement sur une commande remise ou livrée")
        customer_id = o.customer_id
    else:
        raise DomainError("ORIGINE_INCONNUE", "Origine : VENTE ou COMMANDE")
    r = ReturnRequest(code=next_code(db, "RET"), origin=origin, sale_id=source_id if origin == "VENTE" else None,
                      order_id=source_id if origin == "COMMANDE" else None, customer_id=customer_id, site_id=site_id,
                      created_by=actor_id)
    db.add(r)
    db.flush()
    loc = inv.site_location(db, site_id, "RETOURS")
    moves = []
    for ln in lines:
        if origin == "VENTE":
            sl = db.get(SaleLine, ln["line_id"])
            if not sl or sl.sale_id != source_id or sl.status != "ACTIVE":
                raise DomainError("LIGNE_INVALIDE", "Ligne de vente invalide")
            sold_base = sl.quantity * sl.qty_in_base
            already = sl.returned_qty
            line_total = sl.total_ttc_cents
            variant_id = sl.variant_id
            lot_id = ln.get("lot_id") or sl.lot_id or _presumed_lot(db, "VENTE", source_id, variant_id)
        else:
            ol = db.get(OrderLine, ln["line_id"])
            if not ol or ol.order_id != source_id:
                raise DomainError("LIGNE_INVALIDE", "Ligne de commande invalide")
            sold_base, already, line_total, variant_id = ol.delivered_base_qty, ol.returned_qty, ol.total_ttc_cents, ol.variant_id
            sl = None
            lot_id = ln.get("lot_id") or _presumed_lot(db, "COMMANDE", source_id, variant_id)
        qty = check_quantity(Decimal(str(ln["quantity"])), inv._variant_unit(db, variant_id))
        if qty <= 0 or already + qty > sold_base:
            raise DomainError("QUANTITE_RETOUR", f"Quantité retournée supérieure à la quantité vendue restante "
                                                 f"({sold_base - already})")
        refundable = round_cents(Decimal(line_total) * qty / sold_base)
        if sl:
            sl.returned_qty = already + qty
        else:
            ol.returned_qty = already + qty
        r.lines.append(ReturnLine(sale_line_id=sl.id if sl else None, order_line_id=None if sl else ol.id,
                                  variant_id=variant_id, lot_id=lot_id, quantity=qty, reason=ln.get("reason", ""),
                                  refundable_cents=refundable))
        moves.append(inv.MoveLine(variant_id, loc.id, qty, "A_INSPECTER", lot_id))
    inv.post_movements(db, "RETOUR_CLIENT", moves, actor_id=actor_id, document_type="RETOUR", document_id=r.id,
                       document_ref=r.code, reason="Retour client — en attente d'inspection")
    audit(db, actor_id, "retour.creation", "return", r.id, f"Retour {r.code}")
    return r


def _presumed_lot(db: Session, doc_type: str, doc_id: int, variant_id: int) -> int | None:
    m = db.scalar(select(StockMovement).where(StockMovement.document_type == doc_type,
                                              StockMovement.document_id == doc_id,
                                              StockMovement.variant_id == variant_id,
                                              StockMovement.quantity < 0).order_by(StockMovement.id))
    return m.lot_id if m else None


def inspect_line(db: Session, line_id: int, condition: str, disposition: str, notes: str, actor_id: int) -> ReturnLine:
    ln = db.get(ReturnLine, line_id)
    if not ln:
        raise NotFound("Ligne de retour", line_id)
    if ln.disposition:
        raise DomainError("DEJA_INSPECTE", "Ligne déjà inspectée")
    if condition not in CONDITIONS or disposition not in DISPOSITIONS:
        raise DomainError("VALEUR_INCONNUE", "État ou disposition inconnu")
    r = db.get(ReturnRequest, ln.return_id)
    lot = db.get(Lot, ln.lot_id) if ln.lot_id else None
    if disposition == "REMISE_EN_VENTE":
        if condition not in ("NEUF_INTACT", "OUVERT_COMPLET"):
            raise DomainError("REMISE_EN_VENTE_INTERDITE", f"Un article « {CONDITIONS[condition].lower()} » ne peut "
                                                           f"pas être remis en vente")
        if lot and lot.status != "ACTIF":
            raise DomainError("LOT_BLOQUE", "Lot bloqué ou rappelé : remise en vente interdite")
        if lot and lot.expiry_kind == "DLC":
            raise DomainError("DLC_RETOUR", "Produit à DLC retourné : remise en vente interdite par prudence")
    src = inv.site_location(db, r.site_id, "RETOURS")
    if disposition == "REMISE_EN_VENTE":
        inv.change_quality(db, variant_id=ln.variant_id, from_location_id=src.id, lot_id=ln.lot_id,
                           from_state="A_INSPECTER", to_state="DISPONIBLE", qty=ln.quantity, actor_id=actor_id,
                           movement_type="CHANGEMENT_ETAT", to_location_id=inv.site_location(db, r.site_id, "STOCKAGE").id,
                           reason=f"Retour {r.code} inspecté : {CONDITIONS[condition]}", document_type="RETOUR",
                           document_id=r.id, document_ref=r.code)
    elif disposition in ("RETOUR_FOURNISSEUR", "QUARANTAINE"):
        inv.change_quality(db, variant_id=ln.variant_id, from_location_id=src.id, lot_id=ln.lot_id,
                           from_state="A_INSPECTER", to_state="ENDOMMAGE" if disposition == "RETOUR_FOURNISSEUR"
                           else "QUARANTAINE", qty=ln.quantity, actor_id=actor_id, movement_type="MISE_EN_QUARANTAINE",
                           to_location_id=inv.site_location(db, r.site_id, "QUARANTAINE").id,
                           reason=f"Retour {r.code} : {DISPOSITIONS[disposition]}", document_type="RETOUR",
                           document_id=r.id, document_ref=r.code)
    else:
        inv.post_movements(db, "PERTE", [inv.MoveLine(ln.variant_id, src.id, -ln.quantity, "A_INSPECTER", ln.lot_id)],
                           actor_id=actor_id, document_type="RETOUR", document_id=r.id, document_ref=r.code,
                           reason=f"Destruction après inspection : {CONDITIONS[condition]}")
    ln.condition, ln.disposition, ln.inspection_notes = condition, disposition, notes
    ln.inspected_by, ln.inspected_at = actor_id, utcnow()
    if all(l.disposition for l in r.lines):
        r.status = "INSPECTE"
    audit(db, actor_id, "retour.inspection", "return_line", ln.id, f"{CONDITIONS[condition]} → {DISPOSITIONS[disposition]}")
    return ln


def refund_return(db: Session, return_id: int, idempotency_key: str, actor_id: int,
                  session_id: int | None = None) -> dict:
    """Rembourse sur les moyens de paiement d'origine (carte d'abord, puis espèces). Ne touche pas au stock."""
    r = db.scalar(select(ReturnRequest).where(ReturnRequest.id == return_id).with_for_update())
    if not r:
        raise NotFound("Retour", return_id)
    if r.refund_status == "REMBOURSE":
        return {"retour": r.code, "rembourse": r.refund_cents, "rejeu": True}
    total = sum(l.refundable_cents for l in r.lines)
    target = ("VENTE", r.sale_id) if r.origin == "VENTE" else ("COMMANDE", r.order_id)
    pays = [p for p in pay.payments_for(db, *target) if p.status == "CAPTURE"]
    pays.sort(key=lambda p: {"CARTE_SIMULEE": 0, "VIREMENT_SIMULE": 1, "ESPECES": 2, "AVOIR": 3}[p.method])
    remaining, refunds = total, []
    for i, p in enumerate(pays):
        if remaining <= 0:
            break
        from sqlalchemy import func
        from app.modules.payments.models import Refund

        done = db.scalar(select(func.coalesce(func.sum(Refund.amount_cents), 0)).where(
            Refund.payment_id == p.id, Refund.status.in_(("EN_ATTENTE", "REMBOURSE")))) or 0
        cap = p.captured_cents - int(done)
        amt = min(cap, remaining)
        if amt > 0:
            refunds.append(pay.refund(db, p, amt, f"Retour {r.code}", f"{idempotency_key}:{i}", actor_id, r.id,
                                      session_id=session_id))
            remaining -= amt
    if remaining > 0:
        raise DomainError("REMBOURSEMENT_INCOMPLET", f"Impossible de rembourser {remaining} c sur les paiements d'origine")
    r.refund_cents, r.refund_status = total, "REMBOURSE"
    pts = cust.adjust_for_refund(db, r.customer_id, total, r.code)
    audit(db, actor_id, "retour.remboursement", "return", r.id, f"Remboursement {total} c, {pts} point(s) retiré(s)")
    return {"retour": r.code, "rembourse": total, "remboursements": [x.id for x in refunds], "points_retires": pts,
            "note": "Le remboursement ne remet aucun article en stock vendable : seule l'inspection en décide."}


# --- Rappels -------------------------------------------------------------------------------------------
def open_recall(db: Session, lot_ids: list[int], reason: str, severity: str, actor_id: int,
                initiated_by_org: str | None = None) -> Recall:
    if severity not in ("RETRAIT", "RAPPEL_CONSOMMATEURS"):
        raise DomainError("GRAVITE_INCONNUE", "Gravité : RETRAIT ou RAPPEL_CONSOMMATEURS")
    rc = Recall(code=next_code(db, "RAP"), reason=reason, severity=severity, opened_by=actor_id,
                initiated_by_org=initiated_by_org)
    db.add(rc)
    db.flush()
    db.add(RecallLog(recall_id=rc.id, kind="DECISION", content=f"Ouverture du rappel : {reason} (gravité {severity})",
                     by_user=actor_id))
    impact = {"lots": [], "stock_bloque": {}, "ventes": 0, "clients_identifies": 0, "ventes_anonymes": 0,
              "commandes": 0, "sites": []}
    for lid in lot_ids:
        lot = db.get(Lot, lid)
        if not lot:
            raise NotFound("Lot", lid)
        blocked = _block_lot(db, rc, lot, actor_id)
        ev = trace.declare_event(db, event_type="RECALL", occurred_at=utcnow(), actor_id=actor_id, lot=lot,
                                 details={"rappel": rc.code, "motif": reason, "gravite": severity},
                                 source_type="RAPPEL", source_id=rc.id)
        db.add(RecallLot(recall_id=rc.id, lot_id=lot.id, blocked_qty=blocked, trace_event_id=ev.id))
        impact["lots"].append(lot.lot_code)
        impact["stock_bloque"][lot.lot_code] = format_qty(blocked, inv._variant_unit(db, lot.variant_id))
        _destinations(db, rc, lot, impact)
    sup_ids = {db.get(Lot, l).supplier_id for l in lot_ids}
    for sid in sup_ids:
        if sid:
            org = db.get(Organisation, sid)
            db.add(RecallTask(recall_id=rc.id, kind="INFORMER_FOURNISSEUR", description=f"Informer {org.name} et "
                              f"obtenir l'analyse de cause", reference=org.code))
    if severity == "RAPPEL_CONSOMMATEURS":
        db.add(RecallTask(recall_id=rc.id, kind="DECLARER_RAPPELCONSO",
                          description="Vérifier/déclarer la fiche sur RappelConso (démarche manuelle hors prototype)"))
        db.add(RecallTask(recall_id=rc.id, kind="AFFICHAGE_MAGASIN",
                          description="Afficher l'avis de rappel dans les magasins concernés"))
    rc.impact = impact
    rc.status = "EN_COURS"
    raise_alert(db, "RAPPEL", "CRITIQUE", f"Rappel {rc.code} en cours",
                f"Lots {', '.join(impact['lots'])} bloqués ; {impact['clients_identifies']} client(s) identifié(s), "
                f"{impact['ventes_anonymes']} vente(s) sans client identifié.", f"rappel:{rc.code}",
                entity_type="recall", entity_id=rc.id)
    audit(db, actor_id, "rappel.ouverture", "recall", rc.id, f"Rappel {rc.code}")
    notify(db, "rappel", {"code": rc.code, "lots": impact["lots"]})
    return rc


def _block_lot(db: Session, rc: Recall, lot: Lot, actor_id: int) -> Decimal:
    lot.status = "RAPPELE"
    total = ZERO
    by_site: dict[int, Decimal] = defaultdict(lambda: ZERO)
    bals = list(db.scalars(select(StockBalance).where(StockBalance.lot_id == lot.id, StockBalance.quantity > 0,
                                                      StockBalance.quality_state.in_(("DISPONIBLE", "A_INSPECTER",
                                                                                      "QUARANTAINE")))))
    for b in bals:
        q = b.quantity
        inv.change_quality(db, variant_id=b.variant_id, from_location_id=b.location_id, lot_id=lot.id,
                           from_state=b.quality_state, to_state="BLOQUE", qty=q, actor_id=actor_id,
                           movement_type="MISE_EN_QUARANTAINE", reason=f"Rappel {rc.code}", document_type="RAPPEL",
                           document_id=rc.id, document_ref=rc.code)
        total += q
        by_site[b.site_id] += q
    for site_id, q in by_site.items():
        site = db.get(Site, site_id)
        db.add(RecallTask(recall_id=rc.id, kind="RETIRER_RAYON", site_id=site_id,
                          description=f"{site.name} : retirer physiquement {format_qty(q, inv._variant_unit(db, lot.variant_id))} du lot {lot.lot_code} et les "
                                      f"isoler (stock système déjà bloqué)", reference=lot.lot_code, confidence="CERTAINE"))
        pos = db.get(StockPosition, (lot.variant_id, site_id))
        if pos and pos.sellable - pos.reserved < 0:
            inv.record_exception(db, "RESERVATION_A_REAFFECTER", lot.variant_id, site_id, pos.reserved - pos.sellable,
                                 rc.code, f"Rappel {rc.code} : des réservations dépassent le stock vendable restant")
            for r in db.scalars(select(Reservation).where(Reservation.variant_id == lot.variant_id,
                                                          Reservation.site_id == site_id, Reservation.status == "ACTIVE")):
                ol = db.get(OrderLine, r.order_line_id)
                db.add(RecallTask(recall_id=rc.id, kind="REAFFECTER_COMMANDE", site_id=site_id,
                                  description=f"Commande {db.get(Order, ol.order_id).code} : vérifier que le lot préparé "
                                              f"n'est pas {lot.lot_code}, sinon réaffecter", reference=db.get(Order, ol.order_id).code))
    return total


def _destinations(db: Session, rc: Recall, lot: Lot, impact: dict) -> None:
    outs = db.scalars(select(StockMovement).where(StockMovement.lot_id == lot.id,
                                                  StockMovement.movement_type.in_(("VENTE", "EXPEDITION")),
                                                  StockMovement.quantity < 0))
    seen = set()
    for m in outs:
        key = (m.document_type, m.document_id)
        if key in seen:
            continue
        seen.add(key)
        conf = "CERTAINE" if m.lot_attribution == "SCANNE" else "PRESUMEE"
        if m.document_type == "VENTE":
            sale = db.get(Sale, m.document_id)
            impact["ventes"] += 1
            if sale.customer_id:
                impact["clients_identifies"] += 1
                db.add(RecallTask(recall_id=rc.id, kind="CONTACTER_CLIENT", customer_id=sale.customer_id,
                                  site_id=sale.site_id, reference=sale.code, confidence=conf,
                                  description=f"Contacter le client du ticket {sale.code} (lot {'scanné' if conf == 'CERTAINE' else 'présumé par FEFO'})"))
            else:
                impact["ventes_anonymes"] += 1
        elif m.document_type == "COMMANDE":
            o = db.get(Order, m.document_id)
            impact["commandes"] += 1
            if o.customer_id:
                impact["clients_identifies"] += 1
            db.add(RecallTask(recall_id=rc.id, kind="CONTACTER_CLIENT", customer_id=o.customer_id, reference=o.code,
                              site_id=o.source_site_id, confidence=conf,
                              description=f"Contacter le client de la commande {o.code}"))
    if impact["ventes_anonymes"]:
        db.add(RecallTask(recall_id=rc.id, kind="INFORMATION_PUBLIQUE", confidence="PRESUMEE",
                          description=f"{impact['ventes_anonymes']} vente(s) sans client identifié : seule "
                                      f"l'information publique (affichage, RappelConso) peut les atteindre"))
    for tl in db.scalars(select(TransferLine).where(TransferLine.lot_id == lot.id)):
        t = db.get(Transfer, tl.transfer_id)
        name = db.get(Site, t.to_site_id).name
        if name not in impact["sites"]:
            impact["sites"].append(name)


def log_recall(db: Session, recall_id: int, kind: str, content: str, actor_id: int, channel: str | None = None,
               audience: str | None = None, count: int = 0) -> RecallLog:
    if kind not in ("DECISION", "COMMUNICATION"):
        raise DomainError("TYPE_INCONNU", "DECISION ou COMMUNICATION")
    lg = RecallLog(recall_id=recall_id, kind=kind, content=content, by_user=actor_id, channel=channel,
                   audience=audience, count=count)
    db.add(lg)
    return lg


def complete_task(db: Session, task_id: int, notes: str, actor_id: int, status: str = "FAITE") -> RecallTask:
    t = db.get(RecallTask, task_id)
    if not t:
        raise NotFound("Tâche", task_id)
    t.status, t.notes, t.done_by, t.done_at = status, notes, actor_id, utcnow()
    return t


def close_recall(db: Session, recall_id: int, actor_id: int, note: str) -> Recall:
    rc = db.get(Recall, recall_id)
    open_tasks = db.scalars(select(RecallTask).where(RecallTask.recall_id == recall_id,
                                                     RecallTask.status == "A_FAIRE")).all()
    if open_tasks:
        raise DomainError("TACHES_OUVERTES", f"{len(open_tasks)} tâche(s) de suivi non traitée(s)")
    rc.status, rc.closed_at = "CLOS", utcnow()
    db.add(RecallLog(recall_id=rc.id, kind="DECISION", content=f"Clôture : {note}", by_user=actor_id))
    return rc
