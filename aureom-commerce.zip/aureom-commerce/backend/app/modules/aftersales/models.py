"""Retours clients (inspection + disposition explicite) et rappels de lots."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Qty, created_at, pk, ts
from app.db import Base

CONDITIONS = {"NEUF_INTACT": "Neuf, emballage intact", "OUVERT_COMPLET": "Ouvert, complet, sans défaut",
              "ENDOMMAGE": "Endommagé", "DEFECTUEUX": "Défectueux", "PERIME": "Périmé / DLC dépassée"}
DISPOSITIONS = {"REMISE_EN_VENTE": "Remise en stock vendable", "RETOUR_FOURNISSEUR": "Retour au fournisseur",
                "DESTRUCTION": "Destruction (perte)", "QUARANTAINE": "Maintien en quarantaine"}


class ReturnRequest(Base):
    __tablename__ = "returns"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    origin: Mapped[str] = mapped_column(String(10))  # VENTE, COMMANDE
    sale_id: Mapped[int | None] = mapped_column(ForeignKey("sales.id"))
    order_id: Mapped[int | None] = mapped_column(ForeignKey("orders.id"))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    status: Mapped[str] = mapped_column(String(15), default="RECU")  # RECU, INSPECTE, CLOS
    refund_status: Mapped[str] = mapped_column(String(15), default="NON_REMBOURSE")
    refund_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    lines: Mapped[list["ReturnLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan")


class ReturnLine(Base):
    __tablename__ = "return_lines"
    id: Mapped[int] = pk()
    return_id: Mapped[int] = mapped_column(ForeignKey("returns.id"))
    sale_line_id: Mapped[int | None] = mapped_column(ForeignKey("sale_lines.id"))
    order_line_id: Mapped[int | None] = mapped_column(ForeignKey("order_lines.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # unité de base
    reason: Mapped[str] = mapped_column(Text)
    refundable_cents: Mapped[int] = mapped_column(BigInteger)
    condition: Mapped[str | None] = mapped_column(String(20))
    disposition: Mapped[str | None] = mapped_column(String(20))
    inspection_notes: Mapped[str | None] = mapped_column(Text)
    inspected_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    inspected_at: Mapped[datetime | None] = ts()


class Recall(Base):
    __tablename__ = "recalls"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    reason: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(25))  # RETRAIT (distribution), RAPPEL_CONSOMMATEURS
    status: Mapped[str] = mapped_column(String(15), default="OUVERT")  # OUVERT, EN_COURS, CLOS
    initiated_by_org: Mapped[str | None] = mapped_column(String(60))
    rappelconso_ref: Mapped[str | None] = mapped_column(String(60))
    impact: Mapped[dict] = mapped_column(JSONB, default=dict)
    opened_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    opened_at: Mapped[datetime] = created_at()
    closed_at: Mapped[datetime | None] = ts()


class RecallLot(Base):
    __tablename__ = "recall_lots"
    recall_id: Mapped[int] = mapped_column(ForeignKey("recalls.id"), primary_key=True)
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"), primary_key=True)
    blocked_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    trace_event_id: Mapped[str | None] = mapped_column(String(36))


class RecallTask(Base):
    __tablename__ = "recall_tasks"
    id: Mapped[int] = pk()
    recall_id: Mapped[int] = mapped_column(ForeignKey("recalls.id"), index=True)
    kind: Mapped[str] = mapped_column(String(30))
    description: Mapped[str] = mapped_column(Text)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    reference: Mapped[str | None] = mapped_column(String(60))
    confidence: Mapped[str | None] = mapped_column(String(20))  # CERTAINE (lot scanné), PRESUMEE (FEFO)
    status: Mapped[str] = mapped_column(String(15), default="A_FAIRE")  # A_FAIRE, FAITE, SANS_OBJET
    done_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    done_at: Mapped[datetime | None] = ts()
    notes: Mapped[str | None] = mapped_column(Text)


class RecallLog(Base):
    """Décisions et communications, conservées sans réécriture."""

    __tablename__ = "recall_logs"
    id: Mapped[int] = pk()
    recall_id: Mapped[int] = mapped_column(ForeignKey("recalls.id"), index=True)
    kind: Mapped[str] = mapped_column(String(15))  # DECISION, COMMUNICATION
    channel: Mapped[str | None] = mapped_column(String(30))
    audience: Mapped[str | None] = mapped_column(String(120))
    content: Mapped[str] = mapped_column(Text)
    by_user: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    at: Mapped[datetime] = created_at()
    count: Mapped[int] = mapped_column(Integer, default=0)
