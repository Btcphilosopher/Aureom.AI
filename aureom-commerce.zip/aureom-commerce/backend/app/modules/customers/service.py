"""Clients, consentements et fidélité.

Règles de fidélité (version 2026-01, lisibles par le client) :
- 1 point par euro TTC effectivement payé (centimes ignorés), hors paiement par avoir ;
- un remboursement retire les points correspondant au montant remboursé (même règle), sans
  descendre sous zéro ; l'ajustement est journalisé ;
- l'adhésion est facultative et indépendante du consentement marketing.
"""
from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.common import audit, next_code
from app.core.errors import DomainError, NotFound
from app.core.types import utcnow
from app.modules.customers.models import Customer, LoyaltyAccount, LoyaltyEntry, MarketingConsent

LOYALTY_RULES_TEXT = ("1 point par euro TTC payé (hors avoir). Un remboursement retire les points du montant "
                      "remboursé. 100 points = bon de 5 € (non mis en œuvre dans le prototype).")
CONSENT_WORDING = "2026-01"


def create_customer(db: Session, data: dict, actor_id: int | None) -> Customer:
    c = Customer(code=next_code(db, "CLI", width=6), kind=data.get("kind", "PARTICULIER"),
                 first_name=data.get("first_name"), last_name=data.get("last_name"),
                 company_name=data.get("company_name"), siret=data.get("siret"), email=data.get("email"),
                 phone=data.get("phone"), org_id=data.get("org_id"), payment_terms_days=data.get("payment_terms_days"))
    db.add(c)
    db.flush()
    for ch in ("EMAIL", "SMS"):
        if ch.lower() + "_marketing" in data:
            set_consent(db, c.id, ch, bool(data[ch.lower() + "_marketing"]), data.get("source", "CAISSE"), actor_id)
    if data.get("loyalty"):
        enroll(db, c.id)
    audit(db, actor_id, "client.creation", "customer", c.id, f"Client {c.code} créé")
    return c


def set_consent(db: Session, customer_id: int, channel: str, granted: bool, source: str, actor_id: int | None):
    if channel not in ("EMAIL", "SMS"):
        raise DomainError("CANAL_INCONNU", "Canal : EMAIL ou SMS")
    db.add(MarketingConsent(customer_id=customer_id, channel=channel, granted=granted, source=source,
                            wording_version=CONSENT_WORDING, recorded_by=actor_id))


def current_consents(db: Session, customer_id: int) -> dict:
    out = {}
    for ch in ("EMAIL", "SMS"):
        last = db.scalar(select(MarketingConsent).where(MarketingConsent.customer_id == customer_id,
                                                        MarketingConsent.channel == ch)
                         .order_by(MarketingConsent.recorded_at.desc(), MarketingConsent.id.desc()).limit(1))
        out[ch] = {"accorde": bool(last and last.granted), "depuis": last.recorded_at if last else None,
                   "source": last.source if last else None}
    return out


def enroll(db: Session, customer_id: int) -> LoyaltyAccount:
    acc = db.scalar(select(LoyaltyAccount).where(LoyaltyAccount.customer_id == customer_id))
    if acc:
        return acc
    acc = LoyaltyAccount(customer_id=customer_id)
    db.add(acc)
    db.flush()
    return acc


def balance(db: Session, account_id: int) -> int:
    return int(db.scalar(select(func.coalesce(func.sum(LoyaltyEntry.points), 0))
                         .where(LoyaltyEntry.account_id == account_id)))


def earn(db: Session, customer_id: int | None, paid_cents_excluding_credit: int, reference: str) -> int:
    if not customer_id:
        return 0
    acc = db.scalar(select(LoyaltyAccount).where(LoyaltyAccount.customer_id == customer_id,
                                                 LoyaltyAccount.status == "ACTIF"))
    if not acc:
        return 0
    pts = max(paid_cents_excluding_credit, 0) // 100
    if pts:
        db.add(LoyaltyEntry(account_id=acc.id, kind="GAIN", points=pts, basis_cents=paid_cents_excluding_credit,
                            reference=reference, explanation=f"{pts} point(s) : 1 point par euro payé ({reference})"))
    return pts


def adjust_for_refund(db: Session, customer_id: int | None, refunded_cents: int, reference: str) -> int:
    if not customer_id:
        return 0
    acc = db.scalar(select(LoyaltyAccount).where(LoyaltyAccount.customer_id == customer_id))
    if not acc:
        return 0
    wanted = refunded_cents // 100
    current = balance(db, acc.id)
    pts = min(wanted, current)
    if pts:
        db.add(LoyaltyEntry(account_id=acc.id, kind="AJUSTEMENT_REMBOURSEMENT", points=-pts, basis_cents=refunded_cents,
                            reference=reference,
                            explanation=f"Retrait de {pts} point(s) suite au remboursement {reference}"
                                        + (f" (plafonné au solde de {current})" if wanted > current else "")))
    return pts


def anonymize(db: Session, customer_id: int, actor_id: int) -> None:
    c = db.get(Customer, customer_id)
    if not c:
        raise NotFound("Client", customer_id)
    c.first_name = c.last_name = c.email = c.phone = None
    c.anonymized_at = utcnow()
    audit(db, actor_id, "client.anonymisation", "customer", c.id, f"Client {c.code} anonymisé")


def public_view(c: Customer, with_pii: bool) -> dict:
    d = {"id": c.id, "code": c.code, "type": c.kind, "societe": c.company_name, "anonymise": c.anonymized_at is not None}
    if with_pii:
        d.update({"prenom": c.first_name, "nom": c.last_name, "email": c.email, "telephone": c.phone, "siret": c.siret})
    else:
        d["nom_affiche"] = (c.company_name or (f"{(c.first_name or '')[:1]}. {(c.last_name or '')[:1]}." if c.last_name else c.code))
    return d
