"""Clients, consentements marketing (séparés de la gestion des achats), fidélité facultative."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.types import created_at, pk, ts
from app.db import Base


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)  # pseudonyme utilisé dans les rapports
    kind: Mapped[str] = mapped_column(String(15), default="PARTICULIER")  # PARTICULIER, PROFESSIONNEL
    first_name: Mapped[str | None] = mapped_column(String(80))
    last_name: Mapped[str | None] = mapped_column(String(80))
    company_name: Mapped[str | None] = mapped_column(String(160))
    siret: Mapped[str | None] = mapped_column(String(14))
    email: Mapped[str | None] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(30))
    org_id: Mapped[int | None] = mapped_column(ForeignKey("organisations.id"))  # client pro membre du réseau
    payment_terms_days: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = created_at()
    anonymized_at: Mapped[datetime | None] = ts()


class MarketingConsent(Base):
    """Historique append-only : le consentement courant est la dernière ligne par canal.
    Aucun lien avec la possibilité d'acheter ou d'adhérer à la fidélité."""

    __tablename__ = "marketing_consents"
    id: Mapped[int] = pk()
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"))
    channel: Mapped[str] = mapped_column(String(10))  # EMAIL, SMS
    granted: Mapped[bool] = mapped_column(Boolean)
    source: Mapped[str] = mapped_column(String(40))  # CAISSE, SITE_WEB, FORMULAIRE
    wording_version: Mapped[str] = mapped_column(String(20))
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = created_at()


class LoyaltyAccount(Base):
    __tablename__ = "loyalty_accounts"
    id: Mapped[int] = pk()
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), unique=True)
    status: Mapped[str] = mapped_column(String(15), default="ACTIF")
    enrolled_at: Mapped[datetime] = created_at()
    rules_version: Mapped[str] = mapped_column(String(20), default="2026-01")


class LoyaltyEntry(Base):
    __tablename__ = "loyalty_entries"
    id: Mapped[int] = pk()
    account_id: Mapped[int] = mapped_column(ForeignKey("loyalty_accounts.id"))
    kind: Mapped[str] = mapped_column(String(30))  # GAIN, AJUSTEMENT_REMBOURSEMENT, UTILISATION
    points: Mapped[int] = mapped_column(Integer)
    basis_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    reference: Mapped[str | None] = mapped_column(String(60))
    explanation: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = created_at()
