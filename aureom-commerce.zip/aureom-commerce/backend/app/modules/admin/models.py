"""Organisations, sites, emplacements, utilisateurs, rôles, jetons, journal d'audit."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Boolean, CheckConstraint, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import created_at, pk, ts
from app.db import Base


class Organisation(Base):
    __tablename__ = "organisations"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(20))  # ENSEIGNE, FOURNISSEUR, TRANSPORTEUR, CLIENT_PRO
    msp_id: Mapped[str | None] = mapped_column(String(60), unique=True)
    is_self: Mapped[bool] = mapped_column(Boolean, default=False)
    ledger_member: Mapped[bool] = mapped_column(Boolean, default=False)
    # Gouvernance du registre : CANDIDATE → ADMISE → SUSPENDUE / RETIREE
    ledger_status: Mapped[str] = mapped_column(String(20), default="NON_MEMBRE")
    gln: Mapped[str | None] = mapped_column(String(13))
    siret: Mapped[str | None] = mapped_column(String(14))
    city: Mapped[str | None] = mapped_column(String(100))
    default_lead_time_days: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = created_at()


class Site(Base):
    __tablename__ = "sites"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(20))  # MAGASIN, ENTREPOT
    org_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    gln: Mapped[str | None] = mapped_column(String(13))
    city: Mapped[str | None] = mapped_column(String(100))
    allows_click_collect: Mapped[bool] = mapped_column(Boolean, default=False)
    ships_online: Mapped[bool] = mapped_column(Boolean, default=False)
    locations: Mapped[list["Location"]] = relationship(back_populates="site")


class Location(Base):
    __tablename__ = "locations"
    __table_args__ = (UniqueConstraint("site_id", "code"),)
    id: Mapped[int] = pk()
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    code: Mapped[str] = mapped_column(String(40))
    label: Mapped[str] = mapped_column(String(120))
    # STOCKAGE, RAYON, RECEPTION, PREPARATION, EXPEDITION, QUARANTAINE, RETOURS, TRANSIT
    kind: Mapped[str] = mapped_column(String(20))
    sellable: Mapped[bool] = mapped_column(Boolean, default=True)
    temp_min_c: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    temp_max_c: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    site: Mapped[Site] = relationship(back_populates="locations")


class Role(Base):
    __tablename__ = "roles"
    code: Mapped[str] = mapped_column(String(40), primary_key=True)
    label: Mapped[str] = mapped_column(String(120))
    max_discount_bp: Mapped[int] = mapped_column(Integer, default=0)
    purchase_approval_limit_cents: Mapped[int] = mapped_column(BigInteger, default=0)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = pk()
    username: Mapped[str] = mapped_column(String(60), unique=True)
    full_name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(300))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_service: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = created_at()
    roles: Mapped[list["UserRole"]] = relationship(cascade="all, delete-orphan", lazy="selectin")
    sites: Mapped[list["UserSite"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class UserRole(Base):
    __tablename__ = "user_roles"
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    role_code: Mapped[str] = mapped_column(ForeignKey("roles.code"), primary_key=True)


class UserSite(Base):
    """Restriction de périmètre : si aucune ligne, accès à tous les sites."""

    __tablename__ = "user_sites"
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), primary_key=True)


class ApiToken(Base):
    __tablename__ = "api_tokens"
    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    created_at: Mapped[datetime] = created_at()
    expires_at: Mapped[datetime] = ts(False)
    revoked_at: Mapped[datetime | None] = ts()


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = pk()
    at: Mapped[datetime] = created_at()
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(80))
    entity_type: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str | None] = mapped_column(String(80))
    summary: Mapped[str] = mapped_column(Text)
    data: Mapped[dict | None] = mapped_column(JSONB)


class IdempotencyRecord(Base):
    __tablename__ = "idempotency_records"
    __table_args__ = (UniqueConstraint("scope", "key"),)
    id: Mapped[int] = pk()
    scope: Mapped[str] = mapped_column(String(80))
    key: Mapped[str] = mapped_column(String(120))
    request_hash: Mapped[str] = mapped_column(String(64))
    response: Mapped[dict | None] = mapped_column(JSONB)
    status_code: Mapped[int] = mapped_column(Integer, default=200)
    created_at: Mapped[datetime] = created_at()


class StoredObject(Base):
    """Pièce stockée dans le stockage objet protégé. Le fichier n'est jamais servi publiquement."""

    __tablename__ = "stored_objects"
    __table_args__ = (CheckConstraint("size_bytes >= 0", name="taille"),)
    id: Mapped[int] = pk()
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    media_type: Mapped[str] = mapped_column(String(100))
    original_name: Mapped[str] = mapped_column(String(255))
    storage_key: Mapped[str] = mapped_column(String(255))
    classification: Mapped[str] = mapped_column(String(20), default="INTERNE")  # INTERNE, CONFIDENTIEL, PERSONNEL
    uploaded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    uploaded_at: Mapped[datetime] = created_at()


class Sequence(Base):
    """Numérotation lisible des documents (CF-2026-00001…), incrémentée sous verrou de ligne."""

    __tablename__ = "doc_sequences"
    name: Mapped[str] = mapped_column(String(40), primary_key=True)
    value: Mapped[int] = mapped_column(BigInteger, default=0)


class DemoFlag(Base):
    """Paramètres de démonstration (ex. injection de panne du registre)."""

    __tablename__ = "runtime_flags"
    name: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[str] = mapped_column(String(200))
    updated_at: Mapped[datetime] = created_at()
