"""Adaptateurs du registre partagé.

- FabricGatewayAdapter : appelle la passerelle REST (Node.js, @hyperledger/fabric-gateway) d'une
  organisation membre du canal Hyperledger Fabric « tracabilite ». C'est le seul mode qui constitue un
  registre distribué : endorsement par plusieurs organisations (politique MAJORITY) et ordonnancement Raft.
- SimulatedLedger : reproduit le contrat d'interface dans PostgreSQL pour le développement et les tests.
  Il n'apporte AUCUNE des garanties d'un registre partagé et est étiqueté comme tel dans l'interface.

Les deux respectent la même sémantique : RecordEvent idempotent par eventId (DUPLICATE si même
empreinte, CONFLICT sinon), vérification Ed25519 de la signature avec la clé enregistrée.
"""
from __future__ import annotations

import base64
import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from sqlalchemy import func, select

from app.config import get_settings
from app.db import SessionLocal


@dataclass
class LedgerResult:
    status: str  # RECORDED, DUPLICATE
    event_id: str
    tx_id: str
    payload_sha256: str
    tx_timestamp: datetime | None
    block_number: int | None


class LedgerError(Exception):
    def __init__(self, code: str, message: str, retryable: bool, http_status: int = 0, tx_id: str | None = None):
        super().__init__(f"{code}: {message}")
        self.code, self.message, self.retryable, self.http_status, self.tx_id = code, message, retryable, http_status, tx_id


def _parse_ts(v: Any) -> datetime | None:
    if not v:
        return None
    if isinstance(v, datetime):
        return v
    s = str(v).replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


class FabricGatewayAdapter:
    name = "fabric"
    distributed = True
    label = "Hyperledger Fabric — canal « tracabilite » (réseau permissionné multi-organisations)"

    def __init__(self, base_url: str | None = None, token: str | None = None, timeout: float | None = None,
                 msp_id: str | None = None):
        s = get_settings()
        self.base_url = (base_url or s.ledger_gateway_url).rstrip("/")
        self.token = token if token is not None else s.ledger_gateway_token
        self.timeout = timeout or s.ledger_timeout_s
        self.msp_id = msp_id or s.org_msp_id

    def _client(self, timeout: float | None = None) -> httpx.Client:
        return httpx.Client(base_url=self.base_url, timeout=timeout or self.timeout,
                            headers={"Authorization": f"Bearer {self.token}"})

    def _call(self, method: str, path: str, json_body: Any = None, timeout: float | None = None) -> httpx.Response:
        try:
            with self._client(timeout) as c:
                return c.request(method, path, json=json_body)
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.RemoteProtocolError) as e:
            raise LedgerError("LEDGER_UNAVAILABLE", f"Passerelle du registre injoignable ({e.__class__.__name__})", True)
        except httpx.ReadTimeout:
            raise LedgerError("COMMIT_UNKNOWN", "Délai dépassé : issue de la transaction inconnue", True)

    @staticmethod
    def _raise_for(r: httpx.Response) -> None:
        try:
            body = r.json()
        except Exception:
            body = {"message": r.text[:300]}
        code = body.get("code") or f"HTTP_{r.status_code}"
        msg = body.get("message") or body.get("error") or "erreur du registre"
        retry = bool(body.get("retryable", r.status_code in (409, 429, 502, 503, 504) and code != "CONFLICT"))
        if r.status_code == 409 and code == "CONFLICT":
            retry = False
        raise LedgerError(code, msg, retry, r.status_code, body.get("txId"))

    def health(self) -> dict:
        try:
            with httpx.Client(base_url=self.base_url, timeout=5) as c:
                r = c.get("/health")
            ok = r.status_code == 200
            return {"disponible": ok, **(r.json() if r.headers.get("content-type", "").startswith("application/json") else {})}
        except Exception as e:
            return {"disponible": False, "erreur": str(e)}

    def status(self) -> dict:
        r = self._call("GET", "/v1/status", timeout=10)
        if r.status_code != 200:
            self._raise_for(r)
        return r.json()

    def submit(self, envelope: str, signature_b64: str) -> LedgerResult:
        r = self._call("POST", "/v1/events", {"envelope": envelope, "signature": signature_b64})
        if r.status_code not in (200, 201):
            self._raise_for(r)
        b = r.json()
        return LedgerResult(b["status"], b["eventId"], b.get("txId", ""), b.get("payloadSha256", ""),
                            _parse_ts(b.get("txTimestamp")), b.get("blockNumber"))

    def get_event(self, event_id: str) -> dict | None:
        r = self._call("GET", f"/v1/events/{quote(event_id, safe='')}", timeout=15)
        if r.status_code == 404:
            return None
        if r.status_code != 200:
            self._raise_for(r)
        return r.json()

    def events_by_subject(self, ref: str) -> list[dict]:
        r = self._call("GET", f"/v1/subjects/{quote(ref, safe='')}/events", timeout=15)
        if r.status_code != 200:
            self._raise_for(r)
        return r.json()

    def register_key(self, key_id: str, public_key_b64: str, valid_from: datetime) -> dict:
        r = self._call("POST", "/v1/keys", {"keyId": key_id, "publicKeyBase64": public_key_b64,
                                             "validFrom": valid_from.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")})
        if r.status_code not in (200, 201):
            self._raise_for(r)
        return r.json()

    def get_key(self, key_id: str) -> dict | None:
        r = self._call("GET", f"/v1/keys/{quote(key_id, safe='')}", timeout=15)
        if r.status_code == 404:
            return None
        if r.status_code != 200:
            self._raise_for(r)
        return r.json()

    def retire_key(self, key_id: str, at: datetime) -> dict:
        r = self._call("POST", f"/v1/keys/{quote(key_id, safe='')}/retire", {"retiredAt": _z(at)})
        if r.status_code not in (200, 201):
            self._raise_for(r)
        return r.json()

    def revoke_key(self, key_id: str, at: datetime, reason: str) -> dict:
        r = self._call("POST", f"/v1/keys/{quote(key_id, safe='')}/revoke", {"revokedAt": _z(at), "reason": reason})
        if r.status_code not in (200, 201):
            self._raise_for(r)
        return r.json()


def _z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


ALLOWED_FIELDS = {"schemaVersion", "eventId", "eventType", "issuerOrg", "subject", "occurredAt", "declaredAt",
                  "previousEventId", "correctsEventId", "counterpartyOrg", "locationRef", "evidence",
                  "detailsDigest", "signerKeyId"}
EVENT_TYPES = {"LOT_CREATED", "SUPPLIER_SHIPMENT", "RECEIPT", "INSPECTION_RECORDED", "CUSTODY_TRANSFER",
               "TRANSFORMATION", "CUSTOMER_SHIPMENT", "RECALL", "CORRECTION", "DISPUTE"}


class SimulatedLedger:
    """Simulation locale du contrat (voir avertissement du module)."""

    name = "simulation"
    distributed = False
    label = "SIMULATION LOCALE — registre non distribué, sans valeur de preuve partagée"

    def __init__(self, msp_id: str | None = None, url: str | None = None):
        self.msp_id = msp_id or get_settings().org_msp_id
        url = url or get_settings().simulation_ledger_url
        self._sessions = None
        if url:  # base distincte (tests de restauration : le « registre » ne doit pas être restauré avec l'application)
            from sqlalchemy import create_engine
            from sqlalchemy.orm import sessionmaker

            from app.modules.traceability.models import SimulatedLedgerKey, SimulatedLedgerRecord

            eng = create_engine(url, pool_pre_ping=True)
            SimulatedLedgerRecord.__table__.create(eng, checkfirst=True)
            SimulatedLedgerKey.__table__.create(eng, checkfirst=True)
            self._sessions = sessionmaker(bind=eng, expire_on_commit=False)

    def _s(self):
        return self._sessions() if self._sessions else SessionLocal()

    def health(self) -> dict:
        return {"disponible": True, "mode": "simulation"}

    def status(self) -> dict:
        from app.modules.traceability.models import SimulatedLedgerRecord

        with self._s() as s:
            h = s.scalar(select(func.count()).select_from(SimulatedLedgerRecord))
        return {"mspId": self.msp_id, "channel": "simulation", "blockHeight": int(h or 0)}

    def submit(self, envelope: str, signature_b64: str) -> LedgerResult:
        from app.modules.traceability.models import SimulatedLedgerKey, SimulatedLedgerRecord

        try:
            ev = json.loads(envelope)
        except json.JSONDecodeError:
            raise LedgerError("INVALID_JSON", "enveloppe illisible", False, 422)
        unknown = set(ev) - ALLOWED_FIELDS
        if unknown:
            raise LedgerError("INVALID_FIELD", f"champs non autorisés : {sorted(unknown)}", False, 422)
        if ev.get("schemaVersion") != "1.0":
            raise LedgerError("INVALID_SCHEMA", "version de schéma non prise en charge", False, 422)
        if ev.get("eventType") not in EVENT_TYPES:
            raise LedgerError("INVALID_EVENT_TYPE", "type d'événement inconnu", False, 422)
        if ev.get("issuerOrg") != self.msp_id:
            raise LedgerError("ISSUER_MISMATCH", "l'émetteur déclaré ne correspond pas à l'identité soumettante", False, 422)
        sha = hashlib.sha256(envelope.encode()).hexdigest()
        with self._s() as s:
            key = s.get(SimulatedLedgerKey, ev.get("signerKeyId"))
            if key is None:
                raise LedgerError("UNKNOWN_KEY", "clé de signature inconnue", False, 422)
            if key.owner_msp != self.msp_id:
                raise LedgerError("KEY_OWNER_MISMATCH", "la clé appartient à une autre organisation", False, 422)
            declared = _parse_ts(ev.get("declaredAt"))
            if declared is None or declared < key.valid_from:
                raise LedgerError("KEY_NOT_YET_VALID", "clé pas encore valide à la date déclarée", False, 422)
            if key.revoked_at and declared >= key.revoked_at:
                raise LedgerError("KEY_REVOKED", "clé révoquée à la date déclarée", False, 422)
            if key.retired_at and declared > key.retired_at:
                raise LedgerError("KEY_RETIRED", "clé retirée à la date déclarée", False, 422)
            try:
                Ed25519PublicKey.from_public_bytes(base64.b64decode(key.public_key_b64)).verify(
                    base64.b64decode(signature_b64), envelope.encode())
            except (InvalidSignature, ValueError):
                raise LedgerError("BAD_SIGNATURE", "la signature ne correspond pas à la clé enregistrée", False, 422)
            existing = s.get(SimulatedLedgerRecord, ev["eventId"])
            if existing:
                if existing.payload_sha256 == sha:
                    return LedgerResult("DUPLICATE", existing.event_id, existing.tx_id, sha, existing.tx_timestamp,
                                        existing.block_number)
                raise LedgerError("CONFLICT", "un autre contenu existe déjà pour cet eventId", False, 409)
            for fld, code in (("previousEventId", "UNKNOWN_PREVIOUS"), ("correctsEventId", "UNKNOWN_CORRECTED")):
                if ev.get(fld) and not s.get(SimulatedLedgerRecord, ev[fld]):
                    raise LedgerError(code, f"événement référencé introuvable ({fld})", False, 422)
            if ev["eventType"] == "CORRECTION":
                corr = s.get(SimulatedLedgerRecord, ev.get("correctsEventId") or "")
                if corr is None:
                    raise LedgerError("UNKNOWN_CORRECTED", "correction sans événement corrigé", False, 422)
                if corr.submitter_msp != self.msp_id:
                    raise LedgerError("CORRECTION_NOT_OWNER", "on ne corrige que ses propres événements", False, 422)
            height = (s.scalar(select(func.max(SimulatedLedgerRecord.block_number))) or 0) + 1
            rec = SimulatedLedgerRecord(event_id=ev["eventId"], subject_ref=ev["subject"]["ref"], envelope=envelope,
                                        signature_b64=signature_b64, payload_sha256=sha, submitter_msp=self.msp_id,
                                        tx_id="sim-" + uuid.uuid4().hex, block_number=height,
                                        tx_timestamp=datetime.now(timezone.utc))
            s.add(rec)
            s.commit()
            return LedgerResult("RECORDED", rec.event_id, rec.tx_id, sha, rec.tx_timestamp, rec.block_number)

    def _rec(self, rec) -> dict:
        return {"eventId": rec.event_id, "envelope": rec.envelope, "signatureBase64": rec.signature_b64,
                "payloadSha256": rec.payload_sha256, "submitterMsp": rec.submitter_msp, "txId": rec.tx_id,
                "txTimestamp": _z(rec.tx_timestamp), "blockNumber": rec.block_number}

    def get_event(self, event_id: str) -> dict | None:
        from app.modules.traceability.models import SimulatedLedgerRecord

        with self._s() as s:
            rec = s.get(SimulatedLedgerRecord, event_id)
            return self._rec(rec) if rec else None

    def events_by_subject(self, ref: str) -> list[dict]:
        from app.modules.traceability.models import SimulatedLedgerRecord

        with self._s() as s:
            rows = s.scalars(select(SimulatedLedgerRecord).where(SimulatedLedgerRecord.subject_ref == ref)
                             .order_by(SimulatedLedgerRecord.block_number))
            return [self._rec(r) for r in rows]

    def register_key(self, key_id: str, public_key_b64: str, valid_from: datetime) -> dict:
        from app.modules.traceability.models import SimulatedLedgerKey

        with self._s() as s:
            if s.get(SimulatedLedgerKey, key_id):
                raise LedgerError("KEY_EXISTS", "clé déjà enregistrée", False, 409)
            s.add(SimulatedLedgerKey(key_id=key_id, owner_msp=self.msp_id, public_key_b64=public_key_b64,
                                     valid_from=valid_from))
            s.commit()
        return {"keyId": key_id, "txId": "sim-key-" + uuid.uuid4().hex}

    def get_key(self, key_id: str) -> dict | None:
        from app.modules.traceability.models import SimulatedLedgerKey

        with self._s() as s:
            k = s.get(SimulatedLedgerKey, key_id)
            if not k:
                return None
            return {"keyId": k.key_id, "ownerMsp": k.owner_msp, "publicKeyBase64": k.public_key_b64,
                    "validFrom": _z(k.valid_from), "retiredAt": _z(k.retired_at) if k.retired_at else None,
                    "revokedAt": _z(k.revoked_at) if k.revoked_at else None, "revocationReason": k.revocation_reason}

    def retire_key(self, key_id: str, at: datetime) -> dict:
        return self._key_update(key_id, retired_at=at)

    def revoke_key(self, key_id: str, at: datetime, reason: str) -> dict:
        return self._key_update(key_id, revoked_at=at, revocation_reason=reason)

    def _key_update(self, key_id: str, **values) -> dict:
        from app.modules.traceability.models import SimulatedLedgerKey

        with self._s() as s:
            k = s.get(SimulatedLedgerKey, key_id)
            if not k or k.owner_msp != self.msp_id:
                raise LedgerError("UNKNOWN_KEY", "clé inconnue pour cette organisation", False, 404)
            for a, v in values.items():
                setattr(k, a, v)
            s.commit()
        return {"keyId": key_id}


class OutageWrapper:
    """Injection de panne pour la démonstration : si le drapeau « ledger_outage » est actif, toute requête
    échoue comme si la passerelle était injoignable. Cela simule une coupure côté client uniquement."""

    def __init__(self, inner):
        self.inner = inner
        self.name, self.distributed, self.label = inner.name, inner.distributed, inner.label

    def _check(self):
        from app.core.common import get_flag

        with SessionLocal() as s:
            if get_flag(s, "ledger_outage") == "1":
                raise LedgerError("LEDGER_UNAVAILABLE", "Registre indisponible (panne simulée)", True, 503)

    def health(self):
        try:
            self._check()
        except LedgerError as e:
            return {"disponible": False, "erreur": e.message, "panne_simulee": True}
        return self.inner.health()

    def __getattr__(self, item):
        attr = getattr(self.inner, item)
        if callable(attr):
            def wrapped(*a, **k):
                self._check()
                return attr(*a, **k)
            return wrapped
        return attr


_adapter = None


def get_ledger():
    global _adapter
    if _adapter is None:
        mode = get_settings().ledger_mode
        inner = FabricGatewayAdapter() if mode == "fabric" else SimulatedLedger()
        _adapter = OutageWrapper(inner)
    return _adapter


def set_ledger(adapter) -> None:
    global _adapter
    _adapter = OutageWrapper(adapter) if adapter is not None and not isinstance(adapter, OutageWrapper) else adapter
