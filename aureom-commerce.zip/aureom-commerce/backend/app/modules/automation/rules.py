"""Règles transparentes (paramètres visibles et modifiables) et exécution des propositions approuvées."""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import DomainError, Forbidden, NotFound
from app.core.security import CurrentUser
from app.core.types import utcnow
from app.core.units import round_up_to_pack
from app.modules.admin.models import Organisation, Site
from app.modules.automation.alerts import raise_alert
from app.modules.automation.models import ActionProposal, AutomationRule
from app.modules.catalog.models import Packaging, Variant
from app.modules.inventory import service as inv
from app.modules.inventory.models import InventoryCount, Lot, StockBalance, StockPosition
from app.modules.iot.models import Device

DEFAULT_RULES = {
    "REAPPRO": ("Réapprovisionnement", "Si disponible + attendu < point de commande, proposer d'acheter jusqu'au "
                "stock maximum, arrondi au conditionnement d'achat supérieur.", {}),
    "STOCK_FAIBLE": ("Stock faible", "Alerte si le disponible est inférieur ou égal au seuil (en jours de vente "
                     "moyenne sur 28 jours).", {"jours_couverture_min": 3}),
    "PEREMPTION": ("Péremption", "Alerte pour les lots dont la date (DLC/DDM) est dans moins de N jours ; critique "
                   "si dépassée.", {"jours_alerte": 30}),
    "RETARD_FOURNISSEUR": ("Retard fournisseur", "Alerte si la date de livraison prévue est dépassée sans "
                           "réception complète.", {"tolerance_jours": 0}),
    "ECART_INVENTAIRE": ("Écart d'inventaire", "Alerte si un inventaire validé présente un écart absolu supérieur "
                         "au seuil (en % de l'attendu).", {"seuil_pourcent": 5}),
    "TEMPERATURE": ("Anomalie de température", "N lectures valides consécutives hors plage de l'emplacement. "
                    "Silence capteur > M minutes signalé.", {"lectures_consecutives": 3, "min_c": 0, "max_c": 25,
                                                             "silence_minutes": 30}),
}


def ensure_rules(db: Session) -> None:
    for code, (label, desc, params) in DEFAULT_RULES.items():
        if not db.get(AutomationRule, code):
            db.add(AutomationRule(code=code, label=label, description=desc, params=params))
    db.flush()


def _p(db: Session, code: str) -> dict | None:
    r = db.get(AutomationRule, code)
    if r is None or not r.enabled:
        return None
    r.last_run_at = utcnow()
    return r.params


def daily_demand(db: Session, variant_id: int, site_id: int, days: int = 28) -> Decimal:
    from app.modules.automation.models import DemandHistory

    since = date.today() - timedelta(days=days)
    s = db.scalar(select(func.coalesce(func.sum(DemandHistory.quantity), 0)).where(
        DemandHistory.variant_id == variant_id, DemandHistory.site_id == site_id, DemandHistory.day >= since))
    return Decimal(s or 0) / days


def run_all(db: Session) -> dict:
    out = {}
    for fn in (rule_reappro, rule_low_stock, rule_expiry, rule_supplier_delay, rule_inventory_variance,
               rule_sensor_silence):
        out[fn.__name__] = fn(db)
    return out


def rule_reappro(db: Session) -> int:
    if _p(db, "REAPPRO") is None:
        return 0
    from app.modules.purchasing.service import supplier_terms

    n = 0
    for pos in db.scalars(select(StockPosition).where(StockPosition.min_qty.is_not(None))):
        p = inv.position(db, pos.variant_id, pos.site_id)
        if p["disponible"] + p["attendu"] >= pos.min_qty:
            continue
        try:
            ps = supplier_terms(db, pos.variant_id)
        except DomainError:
            continue
        pack = db.get(Packaging, ps.purchase_packaging_id)
        target = (pos.max_qty or pos.min_qty * 2) - p["disponible"] - p["attendu"]
        packs = max(round_up_to_pack(target, pack.qty_in_base), ps.min_order_packs)
        v = db.get(Variant, pos.variant_id)
        site = db.get(Site, pos.site_id)
        key = f"reappro:{pos.variant_id}:{pos.site_id}"
        if db.scalar(select(ActionProposal).where(ActionProposal.dedup_key == key, ActionProposal.status == "PROPOSEE")):
            continue
        sup = db.get(Organisation, ps.supplier_id)
        why = (f"{v.label} à {site.name} : disponible {p['disponible']} + attendu {p['attendu']} < point de commande "
               f"{pos.min_qty}. Cible {pos.max_qty or pos.min_qty * 2} → {packs} {pack.label.lower()}(s) de "
               f"{pack.qty_in_base.normalize()} chez {sup.name}.")
        db.add(ActionProposal(kind="COMMANDE_FOURNISSEUR", source="REGLE", source_code="REAPPRO",
                              title=f"Réapprovisionner {v.label} ({site.code})", rationale=why,
                              payload={"supplier_id": ps.supplier_id, "site_id": pos.site_id,
                                       "lines": [{"variant_id": pos.variant_id, "pack_qty": packs}]},
                              estimated_value_cents=packs * ps.cost_cents_per_pack,
                              required_permission="purchase.write", site_id=pos.site_id, dedup_key=key))
        n += 1
    return n


def rule_low_stock(db: Session) -> int:
    params = _p(db, "STOCK_FAIBLE")
    if params is None:
        return 0
    n = 0
    for pos in db.scalars(select(StockPosition)):
        d = daily_demand(db, pos.variant_id, pos.site_id)
        if d <= 0:
            continue
        avail = pos.sellable - pos.reserved
        cover = avail / d
        if cover <= params.get("jours_couverture_min", 3):
            v, site = db.get(Variant, pos.variant_id), db.get(Site, pos.site_id)
            raise_alert(db, "STOCK_FAIBLE", "CRITIQUE" if avail <= 0 else "ATTENTION",
                        f"{'Rupture' if avail <= 0 else 'Stock faible'} — {v.label} ({site.code})",
                        f"Disponible {avail} pour une demande moyenne de {d:.1f}/jour (28 j) : couverture "
                        f"{max(cover, 0):.1f} jour(s), seuil {params.get('jours_couverture_min', 3)}.",
                        f"faible:{pos.variant_id}:{pos.site_id}", entity_type="variant", entity_id=v.id, site_id=site.id)
            n += 1
    return n


def rule_expiry(db: Session) -> int:
    params = _p(db, "PEREMPTION")
    if params is None:
        return 0
    limit = date.today() + timedelta(days=int(params.get("jours_alerte", 30)))
    n = 0
    rows = db.execute(select(Lot, func.sum(StockBalance.quantity), StockBalance.site_id).join(
        StockBalance, StockBalance.lot_id == Lot.id).where(Lot.expires_on.is_not(None), Lot.expires_on <= limit,
                                                          StockBalance.quantity > 0).group_by(Lot.id, StockBalance.site_id)).all()
    for lot, qty, site_id in rows:
        expired = lot.expires_on < date.today()
        days = (lot.expires_on - date.today()).days
        raise_alert(db, "PEREMPTION", "CRITIQUE" if expired else "ATTENTION",
                    f"{'Lot périmé' if expired else 'Péremption proche'} — lot {lot.lot_code}",
                    f"Lot {lot.lot_code} : {lot.expiry_kind} le {lot.expires_on:%d/%m/%Y} "
                    f"({'dépassée' if expired else f'dans {days} jour(s)'}), {qty} unité(s) en stock sur le site "
                    f"{db.get(Site, site_id).code}." + (" Retirer de la vente." if expired and lot.expiry_kind == "DLC" else ""),
                    f"peremption:{lot.id}:{site_id}", entity_type="lot", entity_id=lot.id, site_id=site_id)
        n += 1
    return n


def rule_supplier_delay(db: Session) -> int:
    params = _p(db, "RETARD_FOURNISSEUR")
    if params is None:
        return 0
    from app.modules.purchasing.service import overdue_orders

    n = 0
    for po in overdue_orders(db, date.today() - timedelta(days=int(params.get("tolerance_jours", 0)))):
        sup = db.get(Organisation, po.supplier_id)
        late = (date.today() - po.expected_on).days
        raise_alert(db, "RETARD_FOURNISSEUR", "ATTENTION", f"Retard fournisseur — {po.code}",
                    f"{sup.name} : livraison attendue le {po.expected_on:%d/%m/%Y}, {late} jour(s) de retard "
                    f"({po.status.lower().replace('_', ' ')}).", f"retard:{po.id}", entity_type="purchase_order",
                    entity_id=po.id, site_id=po.ship_to_site_id)
        n += 1
    return n


def rule_inventory_variance(db: Session) -> int:
    params = _p(db, "ECART_INVENTAIRE")
    if params is None:
        return 0
    seuil = Decimal(str(params.get("seuil_pourcent", 5)))
    n = 0
    for c in db.scalars(select(InventoryCount).where(InventoryCount.status == "VALIDE",
                                                     InventoryCount.validated_at >= utcnow() - timedelta(days=7))):
        exp = sum((l.expected_qty for l in c.lines), Decimal(0))
        var = sum((abs(l.variance or 0) for l in c.lines), Decimal(0))
        if exp > 0 and var * 100 / exp > seuil:
            raise_alert(db, "ECART_INVENTAIRE", "ATTENTION", f"Écart d'inventaire — {c.code}",
                        f"Écart absolu {var} sur {exp} attendus ({var * 100 / exp:.1f} % > {seuil} %).",
                        f"inv:{c.id}", entity_type="inventory_count", entity_id=c.id, site_id=c.site_id)
            n += 1
    return n


def rule_sensor_silence(db: Session) -> int:
    params = _p(db, "TEMPERATURE")
    if params is None:
        return 0
    limit = utcnow() - timedelta(minutes=int(params.get("silence_minutes", 30)))
    n = 0
    for d in db.scalars(select(Device).where(Device.kind == "CAPTEUR_TEMPERATURE", Device.authorized.is_(True))):
        if d.last_seen_at is not None and d.last_seen_at < limit:
            raise_alert(db, "TEMPERATURE", "ATTENTION", f"Capteur silencieux — {d.code}",
                        f"Aucune donnée de {d.label} depuis le {d.last_seen_at:%d/%m/%Y %H:%M} (UTC) : la "
                        f"surveillance de température n'est plus assurée.", f"silence:{d.code}", entity_type="device",
                        entity_id=d.id, site_id=d.site_id)
            n += 1
    return n


def decide_proposal(db: Session, pid: int, approve: bool, note: str, user: CurrentUser) -> dict:
    """Approuver exécute l'action via les services métier, avec les contrôles habituels
    (plafonds d'achat, séparation des tâches, disponibilité)."""
    p = db.get(ActionProposal, pid)
    if not p:
        raise NotFound("Proposition", pid)
    if p.status != "PROPOSEE":
        raise DomainError("ETAT_INVALIDE", "Proposition déjà traitée")
    if not user.has(p.required_permission) or not user.has("automation.approve"):
        raise Forbidden("Vous n'êtes pas habilité à décider de cette proposition")
    p.decided_by, p.decided_at, p.decision_note = user.id, utcnow(), note
    if not approve:
        p.status = "REJETEE"
        return {"statut": p.status}
    p.status = "APPROUVEE"
    ref = None
    if p.kind == "COMMANDE_FOURNISSEUR":
        from app.modules.purchasing.service import create_proposal

        pa = create_proposal(db, p.payload["supplier_id"], p.payload["site_id"], p.payload["lines"],
                             f"Issue de la proposition automatique n° {p.id} : {p.rationale}", user.id)
        ref = pa.code  # reste soumise à l'approbation d'achat (plafonds)
    elif p.kind == "TRANSFERT":
        t = inv.create_transfer(db, p.payload["from_site_id"], p.payload["to_site_id"], p.payload["lines"], user.id)
        ref = t.code
    elif p.kind == "QUARANTAINE":
        loc_id = p.payload["location_id"]
        from app.modules.admin.models import Location

        loc = db.get(Location, loc_id)
        quar = inv.site_location(db, loc.site_id, "QUARANTAINE")
        for l in p.payload["lots"]:
            bal = db.scalar(select(StockBalance).where(StockBalance.location_id == loc_id, StockBalance.lot_id == l["lot_id"],
                                                       StockBalance.quality_state == "DISPONIBLE"))
            if bal and bal.quantity > 0:
                inv.change_quality(db, variant_id=l["variant_id"], from_location_id=loc_id, lot_id=l["lot_id"],
                                   from_state="DISPONIBLE", to_state="QUARANTAINE", qty=bal.quantity, actor_id=user.id,
                                   movement_type="MISE_EN_QUARANTAINE", to_location_id=quar.id,
                                   reason=f"Proposition {p.id} approuvée : {note}")
        ref = f"quarantaine-{loc.code}"
    p.status, p.executed_ref = "EXECUTEE", ref
    return {"statut": p.status, "reference": ref}
