"""Prévision de demande, détection d'anomalies, risque de rupture, propositions de répartition.

Principes :
- évaluation sur une période DISTINCTE (dernières semaines tenues à l'écart), origine glissante ;
- comparaison systématique à des méthodes simples (naïf saisonnier hebdomadaire, moyenne mobile) ;
- incertitude : intervalles à 80 % issus des erreurs observées en validation ;
- un modèle « avancé » n'est retenu que s'il bat le naïf saisonnier d'au moins 5 % (MASE) ;
- les jours de rupture (demande censurée) sont exclus de l'évaluation ;
- les sorties sont des PROPOSITIONS : rien n'est commandé ni transféré sans approbation.
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import DomainError
from app.core.units import round_up_to_pack
from app.modules.admin.models import Site
from app.modules.automation.models import ActionProposal, DemandHistory, ForecastRun
from app.modules.catalog.models import Packaging, Variant
from app.modules.inventory import service as inv

SEASON = 7


def load_series(db: Session, variant_id: int, site_id: int, end: date | None = None, days: int = 180):
    end = end or date.today() - timedelta(days=1)
    start = end - timedelta(days=days - 1)
    rows = db.scalars(select(DemandHistory).where(DemandHistory.variant_id == variant_id,
                                                  DemandHistory.site_id == site_id, DemandHistory.day >= start,
                                                  DemandHistory.day <= end))
    by_day = {r.day: r for r in rows}
    dates = [start + timedelta(days=i) for i in range(days)]
    y = np.array([float(by_day[d].quantity) if d in by_day else np.nan for d in dates])
    stockout = np.array([bool(by_day[d].stockout) if d in by_day else False for d in dates])
    sources = {r.source for r in by_day.values()}
    return dates, y, stockout, sources


# --- Modèles --------------------------------------------------------------------------------------------
def f_seasonal_naive(train: np.ndarray, h: int) -> np.ndarray:
    last = train[-SEASON:]
    return np.array([last[i % SEASON] for i in range(h)])


def f_moving_average(train: np.ndarray, h: int, window: int = 28) -> np.ndarray:
    return np.full(h, np.nanmean(train[-window:]))


def _ets_fit(y: np.ndarray, alpha: float, gamma: float):
    level = np.nanmean(y[:SEASON])
    season = np.array([y[i] - level for i in range(SEASON)])
    sse = 0.0
    for t in range(SEASON, len(y)):
        s = season[t % SEASON]
        pred = level + s
        err = y[t] - pred
        sse += err * err
        level = level + alpha * err
        season[t % SEASON] = s + gamma * err
    return level, season, sse


def f_ets(train: np.ndarray, h: int) -> np.ndarray:
    """Lissage exponentiel avec saisonnalité additive hebdomadaire (ETS(A,N,A)), paramètres par grille."""
    best = None
    for a in (0.05, 0.1, 0.2, 0.3, 0.5):
        for g in (0.05, 0.1, 0.2, 0.3):
            lvl, sea, sse = _ets_fit(train, a, g)
            if best is None or sse < best[2]:
                best = (lvl, sea, sse)
    lvl, sea, _ = best
    n = len(train)
    return np.maximum(np.array([lvl + sea[(n + i) % SEASON] for i in range(h)]), 0)


MODELS = {"naif_saisonnier": f_seasonal_naive, "moyenne_mobile_28j": f_moving_average, "ets_hebdomadaire": f_ets}


def _impute(y: np.ndarray, stockout: np.ndarray) -> np.ndarray:
    """Jours manquants ou en rupture : remplacés par la valeur de la semaine précédente (sinon moyenne)."""
    y = y.copy()
    bad = np.isnan(y) | stockout
    for i in np.where(bad)[0]:
        y[i] = y[i - SEASON] if i >= SEASON and not np.isnan(y[i - SEASON]) else np.nanmean(y[~bad]) if (~bad).any() else 0
    return y


def evaluate(db: Session, variant_id: int, site_id: int, horizon: int = 7, test_weeks: int = 4) -> ForecastRun:
    dates, y_raw, stockout, sources = load_series(db, variant_id, site_id)
    valid_days = int((~np.isnan(y_raw)).sum())
    if valid_days < 8 * SEASON:
        raise DomainError("DONNEES_INSUFFISANTES", f"Historique insuffisant ({valid_days} jours) : au moins 56 jours "
                                                   f"requis pour une évaluation honnête")
    y = _impute(y_raw, stockout)
    test_len = test_weeks * SEASON
    n_train = len(y) - test_len
    # MASE : échelle = erreur absolue moyenne du naïf saisonnier sur l'apprentissage
    scale = np.mean(np.abs(y[SEASON:n_train] - y[:n_train - SEASON])) or 1.0
    errors: dict[str, list[float]] = {m: [] for m in MODELS}
    for origin in range(n_train, len(y), horizon):  # origine glissante, réestimation à chaque pas
        train = y[:origin]
        actual = y_raw[origin:origin + horizon]
        mask = ~(np.isnan(actual) | stockout[origin:origin + horizon])
        for name, fn in MODELS.items():
            pred = fn(train, len(actual))
            errors[name].extend((actual[mask] - pred[mask]).tolist())
    evaluation = {}
    for name, errs in errors.items():
        e = np.array(errs)
        evaluation[name] = {"mae": round(float(np.mean(np.abs(e))), 3), "rmse": round(float(np.sqrt(np.mean(e ** 2))), 3),
                            "biais": round(float(np.mean(e)), 3), "mase": round(float(np.mean(np.abs(e)) / scale), 3),
                            "n_points": int(len(e))}
    base = evaluation["naif_saisonnier"]["mase"]
    best = min(evaluation, key=lambda m: evaluation[m]["mase"])
    chosen = best if best == "naif_saisonnier" or evaluation[best]["mase"] <= base * 0.95 else "naif_saisonnier"
    errs = np.array(errors[chosen])
    lo_q, hi_q = (float(np.quantile(errs, 0.1)), float(np.quantile(errs, 0.9))) if len(errs) else (0.0, 0.0)
    coverage = float(np.mean((errs >= lo_q) & (errs <= hi_q))) if len(errs) else 0.0
    evaluation["_selection"] = {
        "retenu": chosen, "meilleur_mase": best,
        "regle": "modèle retenu seulement s'il améliore le MASE du naïf saisonnier d'au moins 5 %",
        "intervalle": "80 % empirique (quantiles 10 %/90 % des erreurs de validation)",
        "couverture_validation": round(coverage, 3),
    }
    point = MODELS[chosen](y, horizon)
    fc = [{"jour": (dates[-1] + timedelta(days=i + 1)).isoformat(), "prevision": round(float(p), 2),
           "bas": round(max(float(p) + lo_q, 0), 2), "haut": round(float(p) + hi_q, 2)} for i, p in enumerate(point)]
    run = ForecastRun(variant_id=variant_id, site_id=site_id, horizon_days=horizon, train_start=dates[0],
                      train_end=dates[n_train - 1], test_start=dates[n_train], test_end=dates[-1],
                      evaluation=evaluation, chosen_model=chosen, forecast=fc,
                      data_quality={"jours": len(y), "jours_valides": valid_days,
                                    "jours_rupture_exclus": int(stockout.sum()),
                                    "jours_manquants": int(np.isnan(y_raw).sum()),
                                    "sources": sorted(sources),
                                    "avertissement": "Données SYNTHÉTIQUES de démonstration" if "SYNTHETIQUE" in sources else None})
    db.add(run)
    db.flush()
    return run


def detect_anomalies(db: Session, variant_id: int, site_id: int, threshold: float = 3.5) -> list[dict]:
    """Score robuste (médiane / MAD) sur l'écart au naïf saisonnier."""
    dates, y_raw, stockout, _ = load_series(db, variant_id, site_id)
    y = _impute(y_raw, stockout)
    r = y[SEASON:] - y[:-SEASON]
    med = np.median(r)
    mad = np.median(np.abs(r - med)) * 1.4826 or 1.0
    z = (r - med) / mad
    return [{"jour": dates[i + SEASON].isoformat(), "valeur": float(y[i + SEASON]), "score": round(float(z[i]), 2),
             "sens": "hausse" if z[i] > 0 else "baisse"} for i in np.where(np.abs(z) > threshold)[0]]


def stockout_risk(db: Session, variant_id: int, site_id: int, lead_time_days: int, runs: int = 4000,
                  seed: int = 7) -> dict:
    """Probabilité que la demande sur le délai d'approvisionnement dépasse le disponible + attendu
    (simulation par rééchantillonnage des erreurs de validation)."""
    run = evaluate(db, variant_id, site_id, horizon=max(lead_time_days, 1))
    dates, y_raw, stockout, _ = load_series(db, variant_id, site_id)
    y = _impute(y_raw, stockout)
    point = MODELS[run.chosen_model](y, lead_time_days)
    n_train = len(y) - 28
    errs = []
    for origin in range(n_train, len(y) - lead_time_days + 1, SEASON):
        pred = MODELS[run.chosen_model](y[:origin], lead_time_days)
        errs.append(y[origin:origin + lead_time_days] - pred)
    errs = np.concatenate(errs) if errs else np.zeros(1)
    rng = np.random.default_rng(seed)
    sims = np.maximum(point[None, :] + rng.choice(errs, size=(runs, lead_time_days)), 0).sum(axis=1)
    pos = inv.position(db, variant_id, site_id)
    supply = float(pos["disponible"] + pos["attendu"])
    p = float(np.mean(sims > supply))
    return {"probabilite_rupture": round(p, 3), "demande_mediane": round(float(np.median(sims)), 1),
            "demande_p90": round(float(np.quantile(sims, 0.9)), 1), "offre": supply, "delai_jours": lead_time_days,
            "modele": run.chosen_model, "prevision_id": run.id,
            "limite": "Estimation fondée sur l'historique ; ne tient pas compte des promotions ou événements futurs."}


def propose_allocation(db: Session, variant_id: int, site_ids: list[int], min_cover_days: float = 7,
                       pack_level: str = "PAQUET") -> ActionProposal | None:
    """Rééquilibrage entre sites : du site le plus couvert vers le moins couvert, si l'écart de couverture
    est significatif. Quantité arrondie au conditionnement de transfert."""
    from app.modules.automation.rules import daily_demand

    stats = []
    for sid in site_ids:
        d = float(daily_demand(db, variant_id, sid)) or 0.01
        avail = float(inv.position(db, variant_id, sid)["disponible"])
        stats.append({"site_id": sid, "demande_jour": d, "disponible": avail, "couverture": avail / d})
    low = min(stats, key=lambda s: s["couverture"])
    high = max(stats, key=lambda s: s["couverture"])
    if low["couverture"] >= min_cover_days or high["couverture"] <= min_cover_days * 2 or low is high:
        return None
    pack = db.scalar(select(Packaging).where(Packaging.variant_id == variant_id, Packaging.level == pack_level)) or \
        db.scalar(select(Packaging).where(Packaging.variant_id == variant_id, Packaging.level == "PIECE"))
    need = low["demande_jour"] * min_cover_days - low["disponible"]
    spare = high["disponible"] - high["demande_jour"] * min_cover_days
    qty_units = min(need, spare)
    packs = round_up_to_pack(Decimal(str(max(qty_units, 0))), pack.qty_in_base)
    qty = packs * pack.qty_in_base
    if qty <= 0 or float(qty) > high["disponible"]:
        return None
    v = db.get(Variant, variant_id)
    src, dst = db.get(Site, high["site_id"]), db.get(Site, low["site_id"])
    rationale = (f"{v.label} : couverture {low['couverture']:.1f} j à {dst.name} contre {high['couverture']:.1f} j à "
                 f"{src.name} (demande moyenne 28 j). Transfert proposé : {packs} {pack.label.lower()}(s) "
                 f"= {qty.normalize()} unité(s), pour viser {min_cover_days} j de couverture.")
    p = ActionProposal(kind="TRANSFERT", source="MODELE", source_code="REPARTITION", title=f"Rééquilibrer {v.label}",
                       rationale=rationale, payload={"from_site_id": src.id, "to_site_id": dst.id,
                                                     "lines": [{"variant_id": variant_id, "quantity": str(qty)}]},
                       model_info={"methode": "équilibrage des jours de couverture", "statistiques": stats},
                       required_permission="stock.transfer", site_id=dst.id,
                       dedup_key=f"repart:{variant_id}:{src.id}:{dst.id}")
    db.add(p)
    db.flush()
    return p
