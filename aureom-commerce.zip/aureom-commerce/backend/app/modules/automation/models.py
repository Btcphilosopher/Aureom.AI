"""Règles transparentes, alertes, propositions d'action soumises à approbation, prévisions."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Boolean, Date, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.types import Qty, created_at, pk, ts
from app.db import Base


class AutomationRule(Base):
    __tablename__ = "automation_rules"
    code: Mapped[str] = mapped_column(String(40), primary_key=True)
    label: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text)
    params: Mapped[dict] = mapped_column(JSONB, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_run_at: Mapped[datetime | None] = ts()


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (Index("uq_alert_dedup_ouverte", "dedup_key", unique=True,
                            postgresql_where=text("status IN ('OUVERTE','PRISE_EN_CHARGE')")),)
    id: Mapped[int] = pk()
    rule_code: Mapped[str] = mapped_column(String(40))
    severity: Mapped[str] = mapped_column(String(10))  # INFO, ATTENTION, CRITIQUE
    title: Mapped[str] = mapped_column(String(200))
    message: Mapped[str] = mapped_column(Text)  # texte explicite, la couleur n'est qu'un complément
    explanation: Mapped[dict] = mapped_column(JSONB, default=dict)
    entity_type: Mapped[str | None] = mapped_column(String(40))
    entity_id: Mapped[str | None] = mapped_column(String(60))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"))
    dedup_key: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default="OUVERTE")  # OUVERTE, PRISE_EN_CHARGE, RESOLUE, IGNOREE
    created_at: Mapped[datetime] = created_at()
    resolved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    resolved_at: Mapped[datetime | None] = ts()


class ActionProposal(Base):
    """Une règle ou un modèle PROPOSE ; un humain habilité approuve ; l'exécution est tracée."""

    __tablename__ = "action_proposals"
    id: Mapped[int] = pk()
    kind: Mapped[str] = mapped_column(String(30))  # COMMANDE_FOURNISSEUR, TRANSFERT, QUARANTAINE
    source: Mapped[str] = mapped_column(String(10))  # REGLE, MODELE
    source_code: Mapped[str] = mapped_column(String(60))
    title: Mapped[str] = mapped_column(String(200))
    rationale: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSONB)
    model_info: Mapped[dict | None] = mapped_column(JSONB)
    estimated_value_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    required_permission: Mapped[str] = mapped_column(String(40))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"))
    dedup_key: Mapped[str | None] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default="PROPOSEE")  # PROPOSEE, APPROUVEE, REJETEE, EXECUTEE, EXPIREE
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = ts()
    decision_note: Mapped[str | None] = mapped_column(Text)
    executed_ref: Mapped[str | None] = mapped_column(String(60))
    created_at: Mapped[datetime] = created_at()


class DemandHistory(Base):
    """Historique quotidien de demande. source = REEL (ventes enregistrées) ou SYNTHETIQUE (jeu de démo)."""

    __tablename__ = "demand_history"
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"), primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), primary_key=True)
    day: Mapped[date] = mapped_column(Date, primary_key=True)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    stockout: Mapped[bool] = mapped_column(Boolean, default=False)  # demande censurée par une rupture
    source: Mapped[str] = mapped_column(String(12), default="REEL")


class ForecastRun(Base):
    __tablename__ = "forecast_runs"
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    created_at: Mapped[datetime] = created_at()
    horizon_days: Mapped[int] = mapped_column(Integer)
    train_start: Mapped[date] = mapped_column(Date)
    train_end: Mapped[date] = mapped_column(Date)
    test_start: Mapped[date] = mapped_column(Date)
    test_end: Mapped[date] = mapped_column(Date)
    evaluation: Mapped[dict] = mapped_column(JSONB)  # métriques par modèle (MAE, MASE, couverture)
    chosen_model: Mapped[str] = mapped_column(String(40))
    forecast: Mapped[list] = mapped_column(JSONB)  # [{jour, prevision, bas, haut}]
    data_quality: Mapped[dict] = mapped_column(JSONB)
