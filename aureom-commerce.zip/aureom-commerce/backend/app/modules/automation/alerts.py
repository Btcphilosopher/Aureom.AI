"""Création d'alertes dédupliquées (une seule alerte ouverte par clé)."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import notify
from app.modules.automation.models import Alert

SEVERITY_LABELS = {"INFO": "Information", "ATTENTION": "Attention", "CRITIQUE": "Critique"}


def raise_alert(db: Session, rule_code: str, severity: str, title: str, message: str, dedup_key: str, *,
                entity_type: str | None = None, entity_id=None, site_id: int | None = None,
                explanation: dict | None = None) -> Alert:
    existing = db.scalar(select(Alert).where(Alert.dedup_key == dedup_key,
                                             Alert.status.in_(("OUVERTE", "PRISE_EN_CHARGE"))))
    if existing:
        existing.message = message
        existing.explanation = explanation or existing.explanation
        return existing
    a = Alert(rule_code=rule_code, severity=severity, title=title, message=message, dedup_key=dedup_key,
              entity_type=entity_type, entity_id=str(entity_id) if entity_id is not None else None, site_id=site_id,
              explanation=explanation or {})
    db.add(a)
    db.flush()
    notify(db, "alerte", {"id": a.id, "gravite": severity, "niveau": SEVERITY_LABELS[severity], "titre": title,
                          "message": message})
    return a
