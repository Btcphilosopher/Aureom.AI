"""Stocks multisites : lots, numéros de série, journal de mouvements, soldes, positions, réservations,
transferts et inventaires."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (BigInteger, CheckConstraint, Date, ForeignKey, Index, Numeric, String, Text,
                        UniqueConstraint, text)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Cost, Qty, created_at, pk, ts
from app.db import Base

QUALITY_STATES = ("DISPONIBLE", "A_INSPECTER", "QUARANTAINE", "BLOQUE", "ENDOMMAGE")
QUALITY_LABELS = {"DISPONIBLE": "disponible", "A_INSPECTER": "à inspecter", "QUARANTAINE": "en quarantaine",
                  "BLOQUE": "bloqué (rappel)", "ENDOMMAGE": "endommagé"}

MOVEMENT_TYPES = {
    "RECEPTION": "Réception fournisseur",
    "TRANSFERT_SORTIE": "Transfert — sortie",
    "TRANSFERT_ENTREE": "Transfert — entrée",
    "PRELEVEMENT": "Prélèvement (préparation)",
    "EXPEDITION": "Expédition / remise client",
    "VENTE": "Vente en caisse",
    "RETOUR_CLIENT": "Retour client",
    "MISE_EN_QUARANTAINE": "Mise en quarantaine / blocage",
    "LEVEE_QUARANTAINE": "Levée de quarantaine",
    "CHANGEMENT_ETAT": "Changement d'état qualité",
    "PERTE": "Perte / casse / démarque",
    "CORRECTION": "Correction d'un mouvement",
    "ECART_INVENTAIRE": "Écart d'inventaire",
    "RETOUR_FOURNISSEUR": "Retour fournisseur",
    "DEPLACEMENT": "Déplacement interne",
}


class Lot(Base):
    __tablename__ = "lots"
    __table_args__ = (UniqueConstraint("variant_id", "supplier_id", "lot_code"),)
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("organisations.id"))
    lot_code: Mapped[str] = mapped_column(String(60))
    internal_code: Mapped[str] = mapped_column(String(60), unique=True)
    manufactured_on: Mapped[date | None] = mapped_column(Date)
    expires_on: Mapped[date | None] = mapped_column(Date)
    expiry_kind: Mapped[str | None] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default="ACTIF")  # ACTIF, BLOQUE, RAPPELE, EPUISE
    trace_ref: Mapped[str] = mapped_column(String(200), index=True)  # référence partagée gtin:…|lot:…
    created_at: Mapped[datetime] = created_at()


class SerialUnit(Base):
    __tablename__ = "serial_units"
    __table_args__ = (UniqueConstraint("variant_id", "serial"),)
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    serial: Mapped[str] = mapped_column(String(80))
    epc: Mapped[str | None] = mapped_column(String(64), unique=True)  # étiquette RFID éventuelle
    status: Mapped[str] = mapped_column(String(20), default="EN_STOCK")  # EN_STOCK, VENDU, RETOURNE, REBUT
    location_id: Mapped[int | None] = mapped_column(ForeignKey("locations.id"))


class StockMovement(Base):
    """Journal append-only. Une correction est un nouveau mouvement lié (corrects_movement_id) et attribué."""

    __tablename__ = "stock_movements"
    __table_args__ = (
        CheckConstraint("quantity <> 0", name="non_nul"),
        Index("ix_mvt_variant_site", "variant_id", "site_id", "recorded_at"),
    )
    id: Mapped[int] = pk()
    group_id: Mapped[str] = mapped_column(String(36), index=True)  # lignes d'une même opération
    movement_type: Mapped[str] = mapped_column(String(30))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    serial_unit_id: Mapped[int | None] = mapped_column(ForeignKey("serial_units.id"))
    quality_state: Mapped[str] = mapped_column(String(20))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # signé, unité de base
    unit_cost: Mapped[Decimal | None] = mapped_column(Cost)  # centimes HT par unité de base
    document_type: Mapped[str | None] = mapped_column(String(30))
    document_id: Mapped[int | None] = mapped_column(BigInteger)
    document_ref: Mapped[str | None] = mapped_column(String(60))
    corrects_movement_id: Mapped[int | None] = mapped_column(ForeignKey("stock_movements.id"))
    lot_attribution: Mapped[str | None] = mapped_column(String(20))  # SCANNE, FEFO_PRESUME, DECLARE
    reason: Mapped[str | None] = mapped_column(Text)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    occurred_at: Mapped[datetime] = created_at()
    recorded_at: Mapped[datetime] = created_at()
    idempotency_key: Mapped[str | None] = mapped_column(String(120))


class StockBalance(Base):
    """Solde détaillé : (variante, emplacement, lot, état qualité). Jamais négatif (contrainte)."""

    __tablename__ = "stock_balances"
    __table_args__ = (
        UniqueConstraint("variant_id", "location_id", "lot_id", "serial_unit_id", "quality_state",
                         name="uq_stock_balances_cle", postgresql_nulls_not_distinct=True),
        CheckConstraint("quantity >= 0", name="non_negatif"),
    )
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    serial_unit_id: Mapped[int | None] = mapped_column(ForeignKey("serial_units.id"))
    quality_state: Mapped[str] = mapped_column(String(20))
    quantity: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    updated_at: Mapped[datetime] = created_at()


class StockPosition(Base):
    """Synthèse par (variante, site) mise à jour dans la même transaction que les mouvements.
    physique = tout état ; vendable = état DISPONIBLE en emplacement vendable ; réservé = réservations actives.
    disponible = vendable − réservé (peut devenir négatif si un blocage survient après réservation :
    la situation est alors signalée comme « réservations à réaffecter »)."""

    __tablename__ = "stock_positions"
    __table_args__ = (
        CheckConstraint("reserved >= 0", name="reserve_positif"),
        CheckConstraint("on_hand >= 0 AND sellable >= 0", name="physique_positif"),
    )
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"), primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), primary_key=True)
    on_hand: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    sellable: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    reserved: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    avg_unit_cost: Mapped[Decimal | None] = mapped_column(Cost)  # coût moyen pondéré (centimes HT / unité)
    min_qty: Mapped[Decimal | None] = mapped_column(Qty)  # point de commande
    max_qty: Mapped[Decimal | None] = mapped_column(Qty)
    updated_at: Mapped[datetime] = created_at()


class Reservation(Base):
    __tablename__ = "reservations"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="positif"),
        Index("uq_reservation_ligne_active", "order_line_id", unique=True,
              postgresql_where=text("status = 'ACTIVE'")),
    )
    id: Mapped[int] = pk()
    order_line_id: Mapped[int] = mapped_column(ForeignKey("order_lines.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    status: Mapped[str] = mapped_column(String(20), default="ACTIVE")  # ACTIVE, CONSOMMEE, LIBEREE, EXPIREE
    expires_at: Mapped[datetime | None] = ts()
    created_at: Mapped[datetime] = created_at()
    closed_at: Mapped[datetime | None] = ts()


class Transfer(Base):
    __tablename__ = "transfers"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    from_site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    to_site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    status: Mapped[str] = mapped_column(String(20), default="BROUILLON")  # BROUILLON, EXPEDIE, RECU, ANNULE
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    shipped_at: Mapped[datetime | None] = ts()
    received_at: Mapped[datetime | None] = ts()
    lines: Mapped[list["TransferLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan")


class TransferLine(Base):
    __tablename__ = "transfer_lines"
    id: Mapped[int] = pk()
    transfer_id: Mapped[int] = mapped_column(ForeignKey("transfers.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    from_location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    received_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    unit_cost: Mapped[Decimal | None] = mapped_column(Cost)


class InventoryCount(Base):
    __tablename__ = "inventory_counts"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    location_id: Mapped[int | None] = mapped_column(ForeignKey("locations.id"))
    status: Mapped[str] = mapped_column(String(20), default="EN_COURS")  # EN_COURS, VALIDE
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    validated_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    validated_at: Mapped[datetime | None] = ts()
    lines: Mapped[list["InventoryCountLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan")


class InventoryCountLine(Base):
    __tablename__ = "inventory_count_lines"
    id: Mapped[int] = pk()
    count_id: Mapped[int] = mapped_column(ForeignKey("inventory_counts.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    expected_qty: Mapped[Decimal] = mapped_column(Qty)
    counted_qty: Mapped[Decimal | None] = mapped_column(Qty)
    variance: Mapped[Decimal | None] = mapped_column(Numeric(14, 3))


class StockException(Base):
    """Situation que le journal ne peut pas refléter sans intervention humaine :
    vente sans stock système, écart de transfert, réservations à réaffecter après blocage…"""

    __tablename__ = "stock_exceptions"
    id: Mapped[int] = pk()
    kind: Mapped[str] = mapped_column(String(40))  # VENTE_SANS_STOCK, ECART_TRANSFERT, RESERVATION_A_REAFFECTER
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    document_ref: Mapped[str | None] = mapped_column(String(60))
    message: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="OUVERTE")
    created_at: Mapped[datetime] = created_at()
    resolved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    resolved_at: Mapped[datetime | None] = ts()
