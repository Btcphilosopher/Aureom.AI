"""Moteur de stock : toute variation passe par post_movements(), dans la transaction de l'opération métier.

Garanties :
- soldes détaillés jamais négatifs (verrou de ligne + contrainte CHECK) ;
- réservation par UPDATE conditionnel atomique (pas de double allocation, même en concurrence) ;
- journal append-only ; corrections par mouvements liés et attribués.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import and_, func, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.common import next_code
from app.core.errors import DomainError, NotFound
from app.core.types import ZERO, utcnow
from app.core.units import check_quantity, format_qty
from app.db import notify
from app.modules.admin.models import Location, Site
from app.modules.catalog.models import Variant
from app.modules.inventory.models import (QUALITY_STATES, InventoryCount, InventoryCountLine, Lot, Reservation,
                                          StockBalance, StockException, StockMovement, StockPosition, Transfer,
                                          TransferLine)


@dataclass
class MoveLine:
    variant_id: int
    location_id: int
    quantity: Decimal  # signé
    quality_state: str = "DISPONIBLE"
    lot_id: int | None = None
    serial_unit_id: int | None = None
    unit_cost: Decimal | None = None


def _variant_unit(db: Session, variant_id: int) -> str:
    v = db.get(Variant, variant_id)
    if v is None:
        raise NotFound("Article", variant_id)
    return v.product.base_unit


def post_movements(db: Session, movement_type: str, lines: list[MoveLine], *, actor_id: int | None,
                   document_type: str | None = None, document_id: int | None = None, document_ref: str | None = None,
                   reason: str | None = None, corrects_movement_id: int | None = None,
                   lot_attribution: str | None = None, occurred_at: datetime | None = None) -> list[StockMovement]:
    if not lines:
        raise DomainError("MOUVEMENT_VIDE", "Aucune ligne de mouvement")
    group = str(uuid.uuid4())
    # Ordre de verrouillage déterministe → pas d'interblocage entre opérations concurrentes.
    ordered = sorted(lines, key=lambda l: (l.variant_id, l.location_id, l.lot_id or 0, l.quality_state,
                                           l.quantity > 0))
    out: list[StockMovement] = []
    for ln in ordered:
        if ln.quality_state not in QUALITY_STATES:
            raise DomainError("ETAT_INCONNU", f"État qualité inconnu : {ln.quality_state}")
        unit = _variant_unit(db, ln.variant_id)
        qty = check_quantity(Decimal(ln.quantity), unit)
        if qty == 0:
            continue
        loc = db.get(Location, ln.location_id)
        if loc is None:
            raise NotFound("Emplacement", ln.location_id)
        _apply_balance(db, ln, loc, qty, unit)
        cost = _apply_position(db, ln, loc, qty, movement_type)
        m = StockMovement(group_id=group, movement_type=movement_type, variant_id=ln.variant_id, site_id=loc.site_id,
                          location_id=loc.id, lot_id=ln.lot_id, serial_unit_id=ln.serial_unit_id,
                          quality_state=ln.quality_state, quantity=qty, unit_cost=cost, document_type=document_type,
                          document_id=document_id, document_ref=document_ref, reason=reason,
                          corrects_movement_id=corrects_movement_id, lot_attribution=lot_attribution,
                          actor_user_id=actor_id, occurred_at=occurred_at or utcnow())
        db.add(m)
        out.append(m)
    db.flush()
    notify(db, "stock.mouvement", {"type": movement_type, "groupe": group, "document": document_ref,
                                   "lignes": [{"variante": m.variant_id, "site": m.site_id, "qte": m.quantity}
                                              for m in out]})
    return out


def _apply_balance(db: Session, ln: MoveLine, loc: Location, qty: Decimal, unit: str) -> None:
    key = and_(StockBalance.variant_id == ln.variant_id, StockBalance.location_id == loc.id,
               StockBalance.lot_id.is_(None) if ln.lot_id is None else StockBalance.lot_id == ln.lot_id,
               StockBalance.serial_unit_id.is_(None) if ln.serial_unit_id is None
               else StockBalance.serial_unit_id == ln.serial_unit_id,
               StockBalance.quality_state == ln.quality_state)
    if qty < 0:
        bal = db.scalar(select(StockBalance).where(key).with_for_update())
        have = bal.quantity if bal else ZERO
        if have + qty < 0:
            raise DomainError("STOCK_INSUFFISANT",
                              f"Stock insuffisant à l'emplacement {loc.code} : {format_qty(have, unit)} "
                              f"disponible(s), {format_qty(-qty, unit)} demandé(s)",
                              variant_id=ln.variant_id, location_id=loc.id, lot_id=ln.lot_id)
        bal.quantity = have + qty
        bal.updated_at = utcnow()
    else:
        stmt = insert(StockBalance).values(variant_id=ln.variant_id, site_id=loc.site_id, location_id=loc.id,
                                           lot_id=ln.lot_id, serial_unit_id=ln.serial_unit_id,
                                           quality_state=ln.quality_state, quantity=qty, updated_at=utcnow())
        stmt = stmt.on_conflict_do_update(constraint="uq_stock_balances_cle",
                                          set_={"quantity": StockBalance.quantity + qty, "updated_at": utcnow()})
        db.execute(stmt)


def _apply_position(db: Session, ln: MoveLine, loc: Location, qty: Decimal, movement_type: str) -> Decimal | None:
    db.execute(insert(StockPosition).values(variant_id=ln.variant_id, site_id=loc.site_id, on_hand=0, sellable=0,
                                            reserved=0).on_conflict_do_nothing())
    pos = db.scalar(select(StockPosition).where(StockPosition.variant_id == ln.variant_id,
                                                StockPosition.site_id == loc.site_id).with_for_update())
    cost = pos.avg_unit_cost
    if qty > 0 and ln.unit_cost is not None and movement_type in ("RECEPTION", "TRANSFERT_ENTREE"):
        old_q = pos.on_hand
        old_c = pos.avg_unit_cost if pos.avg_unit_cost is not None else Decimal(ln.unit_cost)
        pos.avg_unit_cost = ((old_c * old_q + Decimal(ln.unit_cost) * qty) / (old_q + qty)).quantize(Decimal("0.0001"))
        cost = Decimal(ln.unit_cost)
    elif ln.unit_cost is not None:
        cost = Decimal(ln.unit_cost)
    pos.on_hand = pos.on_hand + qty
    if ln.quality_state == "DISPONIBLE" and loc.sellable:
        pos.sellable = pos.sellable + qty
    pos.updated_at = utcnow()
    if pos.on_hand < 0 or pos.sellable < 0:
        raise DomainError("INCOHERENCE_STOCK", "Position de stock incohérente (négative)")
    return cost


# --- Lecture -------------------------------------------------------------------------------------------
def position(db: Session, variant_id: int, site_id: int) -> dict:
    pos = db.get(StockPosition, (variant_id, site_id))
    expected = expected_qty(db, variant_id, site_id)
    if pos is None:
        return {"physique": ZERO, "vendable": ZERO, "reserve": ZERO, "disponible": ZERO, "attendu": expected,
                "non_vendable": ZERO}
    return {"physique": pos.on_hand, "vendable": pos.sellable, "reserve": pos.reserved,
            "disponible": pos.sellable - pos.reserved, "non_vendable": pos.on_hand - pos.sellable,
            "attendu": expected, "cout_moyen_centimes": pos.avg_unit_cost, "point_commande": pos.min_qty,
            "stock_max": pos.max_qty}


def expected_qty(db: Session, variant_id: int, site_id: int) -> Decimal:
    """Attendu = reliquats de commandes fournisseurs ouvertes + transferts expédiés non reçus."""
    from app.modules.purchasing.models import PurchaseOrder, PurchaseOrderLine

    po = db.scalar(select(func.coalesce(func.sum(PurchaseOrderLine.base_qty - PurchaseOrderLine.received_base_qty), 0))
                   .join(PurchaseOrder).where(PurchaseOrderLine.variant_id == variant_id,
                                              PurchaseOrder.ship_to_site_id == site_id,
                                              PurchaseOrder.status.in_(("ENVOYEE", "PARTIELLEMENT_RECUE"))))
    tr = db.scalar(select(func.coalesce(func.sum(TransferLine.quantity - TransferLine.received_qty), 0)).join(Transfer)
                   .where(TransferLine.variant_id == variant_id, Transfer.to_site_id == site_id,
                          Transfer.status == "EXPEDIE"))
    return Decimal(po or 0) + Decimal(tr or 0)


def fefo_candidates(db: Session, variant_id: int, site_id: int, quality: str = "DISPONIBLE",
                    sellable_only: bool = True, location_id: int | None = None,
                    exclude_kinds: tuple[str, ...] = ()) -> list[tuple[StockBalance, Lot | None, Location]]:
    """Premier expiré, premier sorti : lots à date la plus proche d'abord, puis lots sans date."""
    q = (select(StockBalance, Lot, Location).join(Location, Location.id == StockBalance.location_id)
         .outerjoin(Lot, Lot.id == StockBalance.lot_id)
         .where(StockBalance.variant_id == variant_id, StockBalance.site_id == site_id,
                StockBalance.quality_state == quality, StockBalance.quantity > 0))
    if sellable_only:
        q = q.where(Location.sellable.is_(True))
    if location_id:
        q = q.where(Location.id == location_id)
    if exclude_kinds:
        q = q.where(Location.kind.not_in(exclude_kinds))
    q = q.where((Lot.id.is_(None)) | (Lot.status == "ACTIF"))
    q = q.order_by(Lot.expires_on.asc().nulls_last(), StockBalance.lot_id.asc().nulls_last(), Location.id)
    return [(b, l, loc) for b, l, loc in db.execute(q).all()]


def allocate_fefo(db: Session, variant_id: int, site_id: int, qty: Decimal, **kw) -> tuple[list[MoveLine], Decimal]:
    """Construit des lignes de sortie FEFO ; retourne (lignes, quantité non couverte)."""
    remaining = Decimal(qty)
    lines: list[MoveLine] = []
    for bal, lot, loc in fefo_candidates(db, variant_id, site_id, **kw):
        if remaining <= 0:
            break
        take = min(bal.quantity, remaining)
        lines.append(MoveLine(variant_id, loc.id, -take, bal.quality_state, bal.lot_id, bal.serial_unit_id))
        remaining -= take
    return lines, remaining


def site_location(db: Session, site_id: int, kind: str) -> Location:
    loc = db.scalar(select(Location).where(Location.site_id == site_id, Location.kind == kind).order_by(Location.id))
    if loc is None:
        raise DomainError("EMPLACEMENT_ABSENT", f"Aucun emplacement de type {kind} sur ce site")
    return loc


# --- Réservations ----------------------------------------------------------------------------------------
def reserve(db: Session, order_line_id: int, variant_id: int, site_id: int, qty: Decimal,
            expires_at: datetime | None = None) -> Reservation:
    qty = check_quantity(Decimal(qty), _variant_unit(db, variant_id))
    db.execute(insert(StockPosition).values(variant_id=variant_id, site_id=site_id, on_hand=0, sellable=0,
                                            reserved=0).on_conflict_do_nothing())
    # UPDATE conditionnel : sous READ COMMITTED, PostgreSQL réévalue la condition sur la dernière version
    # de la ligne après attente du verrou → deux réservations concurrentes ne peuvent pas dépasser le vendable.
    row = db.execute(update(StockPosition).where(
        StockPosition.variant_id == variant_id, StockPosition.site_id == site_id,
        StockPosition.sellable - StockPosition.reserved >= qty).values(reserved=StockPosition.reserved + qty)
        .returning(StockPosition.reserved)).first()
    if row is None:
        avail = db.scalar(select(StockPosition.sellable - StockPosition.reserved).where(
            StockPosition.variant_id == variant_id, StockPosition.site_id == site_id)) or ZERO
        raise DomainError("STOCK_INSUFFISANT", f"Stock disponible insuffisant pour réserver ({avail} disponible(s), "
                                               f"{qty} demandé(s))", status_code=409, disponible=str(avail))
    r = Reservation(order_line_id=order_line_id, variant_id=variant_id, site_id=site_id, quantity=qty,
                    expires_at=expires_at)
    db.flush()
    try:
        with db.begin_nested():  # le point de sauvegarde précède l'insertion
            db.add(r)
            db.flush()
    except IntegrityError:
        raise DomainError("RESERVATION_EXISTANTE", "Cette ligne de commande a déjà une réservation active", 409)
    notify(db, "stock.reservation", {"variante": variant_id, "site": site_id, "qte": qty})
    return r


def release_reservation(db: Session, r: Reservation, status: str = "LIBEREE", qty: Decimal | None = None) -> None:
    if r.status != "ACTIVE":
        return
    q_ = r.quantity if qty is None else Decimal(qty)
    db.execute(update(StockPosition).where(StockPosition.variant_id == r.variant_id,
                                           StockPosition.site_id == r.site_id)
               .values(reserved=func.greatest(StockPosition.reserved - q_, 0)))
    r.status = status
    r.closed_at = utcnow()


# --- Opérations composées ----------------------------------------------------------------------------------
def change_quality(db: Session, *, variant_id: int, from_location_id: int, lot_id: int | None, from_state: str,
                   to_state: str, qty: Decimal, actor_id: int | None, movement_type: str,
                   to_location_id: int | None = None, reason: str | None = None, document_type: str | None = None,
                   document_id: int | None = None, document_ref: str | None = None) -> list[StockMovement]:
    return post_movements(db, movement_type, [
        MoveLine(variant_id, from_location_id, -Decimal(qty), from_state, lot_id),
        MoveLine(variant_id, to_location_id or from_location_id, Decimal(qty), to_state, lot_id),
    ], actor_id=actor_id, reason=reason, document_type=document_type, document_id=document_id,
        document_ref=document_ref)


def correct_movement(db: Session, movement_id: int, corrected_quantity: Decimal, reason: str,
                     actor_id: int) -> list[StockMovement]:
    """Correction liée : poste la différence (quantité corrigée − quantité d'origine), sans modifier l'original."""
    if not reason or len(reason.strip()) < 5:
        raise DomainError("MOTIF_REQUIS", "Une correction exige un motif explicite")
    orig = db.get(StockMovement, movement_id)
    if orig is None:
        raise NotFound("Mouvement", movement_id)
    already = db.scalar(select(func.coalesce(func.sum(StockMovement.quantity), 0)).where(
        StockMovement.corrects_movement_id == orig.id)) or 0
    effective = orig.quantity + Decimal(already)
    delta = Decimal(corrected_quantity) - effective
    if delta == 0:
        raise DomainError("CORRECTION_NULLE", "La quantité corrigée est identique à la quantité effective")
    return post_movements(db, "CORRECTION", [MoveLine(orig.variant_id, orig.location_id, delta, orig.quality_state,
                                                      orig.lot_id, orig.serial_unit_id)],
                          actor_id=actor_id, reason=reason, corrects_movement_id=orig.id,
                          document_type=orig.document_type, document_id=orig.document_id,
                          document_ref=orig.document_ref)


def record_exception(db: Session, kind: str, variant_id: int, site_id: int, qty: Decimal, ref: str | None,
                     message: str) -> StockException:
    e = StockException(kind=kind, variant_id=variant_id, site_id=site_id, quantity=qty, document_ref=ref,
                       message=message)
    db.add(e)
    db.flush()
    notify(db, "stock.exception", {"type": kind, "message": message})
    return e


def consume_for_sale(db: Session, variant_id: int, site_id: int, qty: Decimal, *, actor_id: int | None,
                     lot_id: int | None, document_type: str, document_id: int, document_ref: str,
                     movement_type: str = "VENTE") -> list[StockMovement]:
    """Sortie de stock d'une vente : lot scanné si connu, sinon FEFO présumé. Si le stock système est
    insuffisant, la vente n'est pas bloquée : la partie non couverte devient une exception à traiter."""
    lines: list[MoveLine] = []
    attribution = "FEFO_PRESUME"
    if lot_id:
        remaining = Decimal(qty)
        for bal, lot, loc in fefo_candidates(db, variant_id, site_id, exclude_kinds=("PREPARATION",)):
            if bal.lot_id != lot_id or remaining <= 0:
                continue
            take = min(bal.quantity, remaining)
            lines.append(MoveLine(variant_id, loc.id, -take, bal.quality_state, bal.lot_id))
            remaining -= take
        if remaining == 0:
            attribution, missing = "SCANNE", ZERO
        else:
            lines = []
    if not lines:
        lines, missing = allocate_fefo(db, variant_id, site_id, qty, exclude_kinds=("PREPARATION",))
    moves = post_movements(db, movement_type, lines, actor_id=actor_id, document_type=document_type,
                           document_id=document_id, document_ref=document_ref,
                           lot_attribution=attribution) if lines else []
    if missing > 0:
        record_exception(db, "VENTE_SANS_STOCK", variant_id, site_id, missing, document_ref,
                         f"{document_ref} : {missing} unité(s) vendue(s) sans stock système — inventaire à vérifier")
    return moves


def create_transfer(db: Session, from_site_id: int, to_site_id: int, lines: list[dict], actor_id: int) -> Transfer:
    if from_site_id == to_site_id:
        raise DomainError("TRANSFERT_INVALIDE", "Les sites d'origine et de destination doivent différer")
    t = Transfer(code=next_code(db, "TR"), from_site_id=from_site_id, to_site_id=to_site_id, created_by=actor_id)
    db.add(t)
    db.flush()
    for ln in lines:
        loc_id = ln.get("from_location_id") or site_location(db, from_site_id, "STOCKAGE").id
        t.lines.append(TransferLine(variant_id=ln["variant_id"], lot_id=ln.get("lot_id"), from_location_id=loc_id,
                                    quantity=Decimal(str(ln["quantity"]))))
    db.flush()
    return t


def ship_transfer(db: Session, t: Transfer, actor_id: int) -> None:
    if t.status != "BROUILLON":
        raise DomainError("ETAT_INVALIDE", f"Transfert {t.code} déjà {t.status.lower()}")
    mls = []
    for ln in t.lines:
        pos = db.get(StockPosition, (ln.variant_id, t.from_site_id))
        ln.unit_cost = pos.avg_unit_cost if pos else None
        mls.append(MoveLine(ln.variant_id, ln.from_location_id, -ln.quantity, "DISPONIBLE", ln.lot_id))
    post_movements(db, "TRANSFERT_SORTIE", mls, actor_id=actor_id, document_type="TRANSFERT", document_id=t.id,
                   document_ref=t.code)
    t.status, t.shipped_at = "EXPEDIE", utcnow()


def receive_transfer(db: Session, t: Transfer, received: dict[int, Decimal] | None, actor_id: int,
                     to_location_id: int | None = None) -> None:
    if t.status != "EXPEDIE":
        raise DomainError("ETAT_INVALIDE", f"Le transfert {t.code} n'est pas en transit")
    loc_id = to_location_id or site_location(db, t.to_site_id, "STOCKAGE").id
    mls = []
    for ln in t.lines:
        got = Decimal(received.get(ln.id, ln.quantity)) if received else ln.quantity
        ln.received_qty = got
        if got > 0:
            mls.append(MoveLine(ln.variant_id, loc_id, got, "DISPONIBLE", ln.lot_id, unit_cost=ln.unit_cost))
        if got != ln.quantity:
            record_exception(db, "ECART_TRANSFERT", ln.variant_id, t.to_site_id, ln.quantity - got, t.code,
                             f"Transfert {t.code} : écart de {ln.quantity - got} à la réception")
    if mls:
        post_movements(db, "TRANSFERT_ENTREE", mls, actor_id=actor_id, document_type="TRANSFERT",
                       document_id=t.id, document_ref=t.code)
    t.status, t.received_at = "RECU", utcnow()


def start_count(db: Session, site_id: int, location_id: int | None, actor_id: int) -> InventoryCount:
    c = InventoryCount(code=next_code(db, "INV"), site_id=site_id, location_id=location_id, created_by=actor_id)
    db.add(c)
    db.flush()
    q = select(StockBalance).where(StockBalance.site_id == site_id, StockBalance.quality_state == "DISPONIBLE",
                                   StockBalance.quantity > 0)
    if location_id:
        q = q.where(StockBalance.location_id == location_id)
    for b in db.scalars(q):
        c.lines.append(InventoryCountLine(variant_id=b.variant_id, location_id=b.location_id, lot_id=b.lot_id,
                                          expected_qty=b.quantity))
    db.flush()
    return c


def validate_count(db: Session, c: InventoryCount, counts: dict[int, Decimal], actor_id: int) -> list[dict]:
    if c.status != "EN_COURS":
        raise DomainError("ETAT_INVALIDE", "Inventaire déjà validé")
    variances = []
    mls = []
    for ln in c.lines:
        if ln.id not in counts:
            continue
        ln.counted_qty = Decimal(counts[ln.id])
        ln.variance = ln.counted_qty - ln.expected_qty
        if ln.variance != 0:
            mls.append(MoveLine(ln.variant_id, ln.location_id, ln.variance, "DISPONIBLE", ln.lot_id))
            variances.append({"ligne": ln.id, "variante": ln.variant_id, "ecart": ln.variance,
                              "attendu": ln.expected_qty, "compte": ln.counted_qty})
    if mls:
        post_movements(db, "ECART_INVENTAIRE", mls, actor_id=actor_id, document_type="INVENTAIRE",
                       document_id=c.id, document_ref=c.code, reason="Validation d'inventaire")
    c.status, c.validated_by, c.validated_at = "VALIDE", actor_id, utcnow()
    return variances


def new_lot(db: Session, variant_id: int, supplier_id: int | None, lot_code: str, expires_on: date | None,
            manufactured_on: date | None, expiry_kind: str | None) -> Lot:
    existing = db.scalar(select(Lot).where(Lot.variant_id == variant_id, Lot.supplier_id == supplier_id,
                                           Lot.lot_code == lot_code))
    if existing:
        if expires_on and existing.expires_on and existing.expires_on != expires_on:
            raise DomainError("LOT_INCOHERENT", f"Le lot {lot_code} existe déjà avec une autre date de péremption")
        return existing
    v = db.get(Variant, variant_id)
    ref = f"gtin:{v.gtin}|lot:{lot_code}" if v.gtin else f"sku:{v.sku}|lot:{lot_code}"
    lot = Lot(variant_id=variant_id, supplier_id=supplier_id, lot_code=lot_code, internal_code=next_code(db, "LOT"),
              expires_on=expires_on, manufactured_on=manufactured_on, expiry_kind=expiry_kind, trace_ref=ref)
    db.add(lot)
    db.flush()
    return lot


def sites(db: Session) -> list[Site]:
    return list(db.scalars(select(Site).order_by(Site.id)))


def check_consistency(db: Session) -> dict:
    """Contrôle d'intégrité (après restauration ou incident) : chaque solde doit égaler la somme des
    mouvements de sa clé, et chaque position la somme de ses soldes."""
    from sqlalchemy import text

    bal_diff = db.execute(text("""
        WITH m AS (SELECT variant_id, location_id, lot_id, serial_unit_id, quality_state, SUM(quantity) q
                   FROM stock_movements GROUP BY 1,2,3,4,5)
        SELECT COUNT(*) FROM m FULL JOIN stock_balances b
          ON b.variant_id = m.variant_id AND b.location_id = m.location_id
         AND b.lot_id IS NOT DISTINCT FROM m.lot_id AND b.serial_unit_id IS NOT DISTINCT FROM m.serial_unit_id
         AND b.quality_state = m.quality_state
        WHERE COALESCE(m.q, 0) <> COALESCE(b.quantity, 0)""")).scalar()
    pos_diff = db.execute(text("""
        WITH a AS (SELECT b.variant_id, b.site_id, SUM(b.quantity) on_hand,
                          SUM(CASE WHEN b.quality_state = 'DISPONIBLE' AND l.sellable THEN b.quantity ELSE 0 END) sellable
                   FROM stock_balances b JOIN locations l ON l.id = b.location_id GROUP BY 1,2)
        SELECT COUNT(*) FROM stock_positions p LEFT JOIN a ON a.variant_id = p.variant_id AND a.site_id = p.site_id
        WHERE COALESCE(a.on_hand, 0) <> p.on_hand OR COALESCE(a.sellable, 0) <> p.sellable""")).scalar()
    res_diff = db.execute(text("""
        SELECT COUNT(*) FROM stock_positions p LEFT JOIN (
            SELECT variant_id, site_id, SUM(quantity) q FROM reservations WHERE status = 'ACTIVE' GROUP BY 1,2) r
          ON r.variant_id = p.variant_id AND r.site_id = p.site_id
        WHERE COALESCE(r.q, 0) <> p.reserved""")).scalar()
    return {"soldes_incoherents": int(bal_diff), "positions_incoherentes": int(pos_diff),
            "reservations_incoherentes": int(res_diff), "coherent": not (bal_diff or pos_diff or res_diff)}
