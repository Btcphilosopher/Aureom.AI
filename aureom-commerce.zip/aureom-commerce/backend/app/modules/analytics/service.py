"""Indicateurs définis, avec fraîcheur et lacunes des données.

Chiffre d'affaires ≠ encaissements ≠ marge ≠ bénéfice :
- CA : valeur des ventes conclues (tickets terminés, commandes remises/livrées) sur la période ;
- encaissements : argent effectivement capturé moins remboursements, à leur date ;
- marge brute : CA HT − coût d'achat des marchandises vendues (coût moyen pondéré figé à la vente) ;
- bénéfice : NON calculé — il exige des charges (personnel, loyers, énergie…) absentes du système.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.money import format_eur
from app.core.types import utcnow
from app.modules.admin.models import Organisation
from app.modules.aftersales.models import ReturnLine, ReturnRequest
from app.modules.automation.models import Alert, ForecastRun
from app.modules.inventory.models import StockException, StockMovement, StockPosition
from app.modules.iot.models import Observation
from app.modules.orders.models import Order, OrderEvent, OrderLine
from app.modules.payments.models import Payment, Refund
from app.modules.pos.models import PosSession, Sale, SaleLine
from app.modules.purchasing.models import GoodsReceipt, PurchaseOrder, SupplierInvoice
from app.modules.traceability.models import ReconciliationRun, TraceEvent


def _ind(code, label, value, unit, definition, **kw):
    d = {"code": code, "libelle": label, "valeur": value, "unite": unit, "definition": definition}
    d.update(kw)
    return d


def indicators(db: Session, start: datetime | None = None, end: datetime | None = None,
               site_id: int | None = None) -> dict:
    end = end or utcnow()
    start = start or end - timedelta(days=30)
    gaps: list[str] = []

    def site_f(col):
        return (col == site_id) if site_id else True

    s_ttc, s_ht = db.execute(select(func.coalesce(func.sum(Sale.total_ttc_cents), 0),
                                    func.coalesce(func.sum(Sale.total_ht_cents), 0)).where(
        Sale.status == "TERMINEE", Sale.completed_at >= start, Sale.completed_at < end, site_f(Sale.site_id))).one()
    o_ttc, o_ht = db.execute(select(func.coalesce(func.sum(Order.total_ttc_cents - Order.shipping_cents), 0),
                                    func.coalesce(func.sum(Order.total_ht_cents), 0)).where(
        Order.status.in_(("REMISE", "LIVREE")), Order.completed_at >= start, Order.completed_at < end,
        site_f(Order.source_site_id))).one()
    ret_q = select(func.coalesce(func.sum(ReturnRequest.refund_cents), 0)).where(
        ReturnRequest.refund_status == "REMBOURSE", ReturnRequest.created_at >= start, ReturnRequest.created_at < end,
        site_f(ReturnRequest.site_id))
    returns_ttc = int(db.scalar(ret_q) or 0)

    captured = int(db.scalar(select(func.coalesce(func.sum(Payment.captured_cents), 0)).where(
        Payment.captured_at >= start, Payment.captured_at < end)) or 0)
    refunded = int(db.scalar(select(func.coalesce(func.sum(Refund.amount_cents), 0)).where(
        Refund.status == "REMBOURSE", Refund.completed_at >= start, Refund.completed_at < end)) or 0)
    if site_id:
        gaps.append("Encaissements : non ventilés par site dans le prototype (valeur tous sites)")

    # Marge brute : lignes vendues avec coût figé
    sl = db.execute(select(SaleLine.total_ht_cents, SaleLine.quantity, SaleLine.qty_in_base, SaleLine.unit_cost)
                    .join(Sale).where(Sale.status == "TERMINEE", Sale.completed_at >= start, Sale.completed_at < end,
                                      SaleLine.status == "ACTIVE", site_f(Sale.site_id))).all()
    ol = db.execute(select(OrderLine.total_ht_cents, OrderLine.quantity, OrderLine.qty_in_base, OrderLine.unit_cost)
                    .join(Order).where(Order.status.in_(("REMISE", "LIVREE")), Order.completed_at >= start,
                                       Order.completed_at < end, site_f(Order.source_site_id))).all()
    cogs, margin_base, missing_cost = Decimal(0), 0, 0
    for ht, q, qib, uc in list(sl) + list(ol):
        if uc is None:
            missing_cost += 1
            continue
        cogs += Decimal(q) * Decimal(qib) * Decimal(uc)
        margin_base += ht
    if missing_cost:
        gaps.append(f"Marge : {missing_cost} ligne(s) vendue(s) sans coût connu exclue(s) du calcul")
    margin = int(margin_base - cogs)

    pos = db.execute(select(StockPosition).where(site_f(StockPosition.site_id))).scalars().all()
    stock_value = int(sum((p.on_hand * (p.avg_unit_cost or 0) for p in pos), Decimal(0)))
    unvalued = sum(1 for p in pos if p.on_hand > 0 and p.avg_unit_cost is None)
    if unvalued:
        gaps.append(f"Valeur de stock : {unvalued} position(s) sans coût moyen")
    stockouts = sum(1 for p in pos if p.sellable - p.reserved <= 0 and p.min_qty is not None)
    negative_avail = sum(1 for p in pos if p.sellable - p.reserved < 0)

    losses = db.execute(select(StockMovement.quantity, StockMovement.unit_cost).where(
        StockMovement.movement_type.in_(("PERTE", "ECART_INVENTAIRE")), StockMovement.quantity < 0,
        StockMovement.recorded_at >= start, StockMovement.recorded_at < end, site_f(StockMovement.site_id))).all()
    loss_value = int(sum((-q * (c or 0) for q, c in losses), Decimal(0)))
    loss_qty = sum((-q for q, _ in losses), Decimal(0))

    # Délais fournisseurs
    lead = []
    on_time = 0
    for po, first in db.execute(select(PurchaseOrder, func.min(GoodsReceipt.received_at)).join(
            GoodsReceipt, GoodsReceipt.order_id == PurchaseOrder.id).where(PurchaseOrder.ordered_at >= start - timedelta(days=60))
            .group_by(PurchaseOrder.id)).all():
        lead.append((first - po.ordered_at).total_seconds() / 86400)
        on_time += 1 if po.expected_on is None or first.date() <= po.expected_on else 0
    # Préparation
    prep = []
    for o in db.scalars(select(Order).where(Order.created_at >= start, site_f(Order.source_site_id))):
        evs = {e.to_status: e.at for e in db.scalars(select(OrderEvent).where(OrderEvent.order_id == o.id))}
        if "RESERVEE" in evs and ("PRETE" in evs or "EXPEDIEE" in evs):
            prep.append(((evs.get("PRETE") or evs["EXPEDIEE"]) - evs["RESERVEE"]).total_seconds() / 60)
    # Retours
    sold_units = db.scalar(select(func.coalesce(func.sum(SaleLine.quantity * SaleLine.qty_in_base), 0)).join(Sale).where(
        Sale.status == "TERMINEE", Sale.completed_at >= start, Sale.completed_at < end, SaleLine.status == "ACTIVE")) or 0
    ret_units = db.scalar(select(func.coalesce(func.sum(ReturnLine.quantity), 0)).join(ReturnRequest).where(
        ReturnRequest.created_at >= start, ReturnRequest.created_at < end)) or 0
    # Traçabilité
    trace_counts = dict(db.execute(select(TraceEvent.ledger_status, func.count()).where(TraceEvent.origin == "LOCAL")
                                   .group_by(TraceEvent.ledger_status)).all())
    oldest_pending = db.scalar(select(func.min(TraceEvent.declared_at)).where(
        TraceEvent.ledger_status.in_(("EN_ATTENTE", "SOUMIS", "INCONNU"))))
    provisional = db.scalar(select(func.count()).select_from(TraceEvent).where(
        TraceEvent.counterparty_status == "EN_ATTENTE_CONTREPARTIE")) or 0
    # Rapprochements
    inv_gaps = db.scalar(select(func.count()).select_from(SupplierInvoice).where(SupplierInvoice.status == "ECART")) or 0
    cash = db.execute(select(func.count(), func.coalesce(func.sum(func.abs(PosSession.difference_cents)), 0)).where(
        PosSession.status == "CLOTUREE", PosSession.difference_cents != 0, PosSession.closed_at >= start)).one()
    exc = db.scalar(select(func.count()).select_from(StockException).where(StockException.status == "OUVERTE")) or 0
    last_rec = db.scalar(select(ReconciliationRun).order_by(ReconciliationRun.id.desc()).limit(1))

    fresh = {
        "dernier_mouvement_stock": db.scalar(select(func.max(StockMovement.recorded_at))),
        "derniere_vente": db.scalar(select(func.max(Sale.completed_at))),
        "derniere_confirmation_registre": db.scalar(select(func.max(TraceEvent.ledger_timestamp))),
        "derniere_observation_capteur": db.scalar(select(func.max(Observation.received_at))),
        "derniere_prevision": db.scalar(select(func.max(ForecastRun.created_at))),
        "derniere_reconciliation": last_rec.finished_at if last_rec else None,
    }
    if fresh["derniere_reconciliation"] is None:
        gaps.append("Aucune réconciliation du registre exécutée")
    if any(r.data_quality.get("avertissement") for r in db.scalars(select(ForecastRun).limit(50))):
        gaps.append("Les prévisions reposent sur un historique synthétique de démonstration")

    ca_ttc = int(s_ttc) + int(o_ttc)
    ca_ht = int(s_ht) + int(o_ht)
    inds = [
        _ind("ca_ttc", "Chiffre d'affaires TTC", ca_ttc, "centimes", "Tickets terminés + commandes remises ou livrées "
             "(hors frais de port), à la date de conclusion. Avant déduction des retours.", affichage=format_eur(ca_ttc)),
        _ind("ca_ht", "Chiffre d'affaires HT", ca_ht, "centimes", "Idem, hors taxes collectées.", affichage=format_eur(ca_ht)),
        _ind("retours_rembourses", "Retours remboursés (TTC)", returns_ttc, "centimes",
             "Montants remboursés sur retours, à la date du retour.", affichage=format_eur(returns_ttc)),
        _ind("encaissements_nets", "Encaissements nets", captured - refunded, "centimes",
             "Paiements capturés − remboursements effectués sur la période (tous moyens). Diffère du CA : "
             "acomptes, paiements à échéance, remboursements.", affichage=format_eur(captured - refunded)),
        _ind("marge_brute", "Marge brute (HT)", margin, "centimes", "CA HT des lignes dont le coût est connu − coût "
             "moyen pondéré d'achat figé à la vente.", affichage=format_eur(margin),
             taux=round(margin / margin_base * 100, 1) if margin_base else None),
        _ind("benefice", "Bénéfice", None, None, "Non calculé : nécessite les charges d'exploitation (personnel, loyers, "
             "énergie, logistique…) qui ne sont pas dans le système.", affichage="non disponible"),
        _ind("valeur_stock", "Valeur du stock (coût)", stock_value, "centimes", "Σ stock physique × coût moyen pondéré "
             "(centimes HT).", affichage=format_eur(stock_value)),
        _ind("ruptures", "Articles en rupture", stockouts, "articles×sites", "Positions suivies (point de commande "
             "défini) dont le disponible (vendable − réservé) est ≤ 0."),
        _ind("reservations_a_reaffecter", "Réservations à réaffecter", negative_avail, "positions",
             "Positions où les réservations dépassent le stock vendable (blocage, perte après réservation)."),
        _ind("rotation", "Rotation du stock (période)", round(float(cogs) / stock_value, 2) if stock_value else None,
             "fois", "Coût des ventes de la période ÷ valeur de stock actuelle (approximation : pas d'historique de "
             "valorisation journalier)."),
        _ind("pertes", "Pertes et démarque", loss_value, "centimes", "Mouvements PERTE et écarts d'inventaire négatifs "
             "valorisés au coût.", affichage=format_eur(loss_value), quantite=str(loss_qty)),
        _ind("delai_fournisseur", "Délai fournisseur moyen", round(sum(lead) / len(lead), 1) if lead else None, "jours",
             "Moyenne (première réception − date de commande).", ponctualite_pct=round(on_time / len(lead) * 100) if lead else None,
             echantillon=len(lead)),
        _ind("preparation", "Délai de préparation moyen", round(sum(prep) / len(prep), 1) if prep else None, "minutes",
             "De « stock réservé » à « prête » (retrait) ou « expédiée » (livraison).", echantillon=len(prep)),
        _ind("taux_retour", "Taux de retour", round(float(ret_units) / float(sold_units) * 100, 2) if sold_units else None,
             "%", "Unités retournées ÷ unités vendues en caisse sur la période."),
        _ind("tracabilite_en_attente", "Événements de traçabilité non confirmés",
             sum(v for k, v in trace_counts.items() if k in ("EN_ATTENTE", "SOUMIS", "INCONNU")), "événements",
             "Événements déclarés et signés localement, pas encore confirmés par le registre.",
             repartition=trace_counts, plus_ancien=oldest_pending, transferts_provisoires=provisional),
        _ind("ecarts_rapprochement", "Écarts de rapprochement ouverts", int(inv_gaps) + int(cash[0]) + int(exc), "écarts",
             "Factures fournisseurs en écart + sessions de caisse avec écart + exceptions de stock ouvertes.",
             factures=int(inv_gaps), caisses=int(cash[0]), ecart_caisse_total=int(cash[1]), exceptions_stock=int(exc),
             registre=last_rec.mismatches if last_rec else None),
        _ind("alertes_ouvertes", "Alertes ouvertes", db.scalar(select(func.count()).select_from(Alert).where(
            Alert.status == "OUVERTE")) or 0, "alertes", "Alertes de règles non résolues."),
    ]
    return {"periode": {"debut": start, "fin": end, "site_id": site_id}, "indicateurs": inds, "fraicheur": fresh,
            "lacunes": gaps, "genere_le": utcnow()}


def supplier_leadtimes(db: Session) -> list[dict]:
    out = []
    for org in db.scalars(select(Organisation).where(Organisation.kind == "FOURNISSEUR")):
        rows = db.execute(select(PurchaseOrder, func.min(GoodsReceipt.received_at)).join(GoodsReceipt).where(
            PurchaseOrder.supplier_id == org.id).group_by(PurchaseOrder.id)).all()
        d = [(r - po.ordered_at).total_seconds() / 86400 for po, r in rows]
        out.append({"fournisseur": org.name, "commandes_recues": len(d),
                    "delai_moyen_jours": round(sum(d) / len(d), 1) if d else None,
                    "promis_jours": org.default_lead_time_days})
    return out
