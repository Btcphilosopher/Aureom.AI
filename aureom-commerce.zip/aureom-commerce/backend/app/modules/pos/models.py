"""Caisse : postes, sessions (ouverture / clôture), ventes et lignes figées."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Cost, Qty, created_at, pk, ts
from app.db import Base


class CashRegister(Base):
    __tablename__ = "cash_registers"
    id: Mapped[int] = pk()
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    code: Mapped[str] = mapped_column(String(30), unique=True)
    label: Mapped[str] = mapped_column(String(100))


class PosSession(Base):
    __tablename__ = "pos_sessions"
    id: Mapped[int] = pk()
    register_id: Mapped[int] = mapped_column(ForeignKey("cash_registers.id"))
    status: Mapped[str] = mapped_column(String(15), default="OUVERTE")  # OUVERTE, CLOTUREE
    opened_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    opened_at: Mapped[datetime] = created_at()
    opening_float_cents: Mapped[int] = mapped_column(BigInteger)
    closed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    closed_at: Mapped[datetime | None] = ts()
    counted_cash_cents: Mapped[int | None] = mapped_column(BigInteger)
    expected_cash_cents: Mapped[int | None] = mapped_column(BigInteger)
    difference_cents: Mapped[int | None] = mapped_column(BigInteger)
    closing_report: Mapped[dict | None] = mapped_column(JSONB)


class Sale(Base):
    __tablename__ = "sales"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("pos_sessions.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    status: Mapped[str] = mapped_column(String(15), default="EN_COURS")  # EN_COURS, TERMINEE, ANNULEE
    cashier_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    total_ttc_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    total_tax_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    discount_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    tax_summary: Mapped[list] = mapped_column(JSONB, default=list)
    loyalty_points: Mapped[int] = mapped_column(Integer, default=0)
    idempotency_key: Mapped[str | None] = mapped_column(String(120), unique=True)
    void_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = created_at()
    completed_at: Mapped[datetime | None] = ts()
    lines: Mapped[list["SaleLine"]] = relationship(lazy="selectin", order_by="SaleLine.line_no",
                                                   cascade="all, delete-orphan")


class SaleLine(Base):
    """Toutes les données commerciales sont figées à l'ajout : un changement de catalogue ou de prix
    n'altère jamais une vente passée."""

    __tablename__ = "sale_lines"
    __table_args__ = (UniqueConstraint("sale_id", "line_no"),)
    id: Mapped[int] = pk()
    sale_id: Mapped[int] = mapped_column(ForeignKey("sales.id"))
    line_no: Mapped[int] = mapped_column(Integer)
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    sku: Mapped[str] = mapped_column(String(40))
    label: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    scanned_code: Mapped[str | None] = mapped_column(String(48))
    unit: Mapped[str] = mapped_column(String(10))
    packaging_level: Mapped[str] = mapped_column(String(10), default="PIECE")
    qty_in_base: Mapped[Decimal] = mapped_column(Qty)
    quantity: Mapped[Decimal] = mapped_column(Qty)  # en conditionnement vendu
    unit_price_ttc_cents: Mapped[int] = mapped_column(BigInteger)
    price_id: Mapped[int | None] = mapped_column(BigInteger)
    tax_rate_bp: Mapped[int] = mapped_column(Integer)
    tax_regime_code: Mapped[str] = mapped_column(String(40))
    gross_ttc_cents: Mapped[int] = mapped_column(BigInteger)
    discount_bp: Mapped[int] = mapped_column(Integer, default=0)
    discount_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    discount_reason: Mapped[str | None] = mapped_column(String(200))
    discount_authorized_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    total_ttc_cents: Mapped[int] = mapped_column(BigInteger)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger)
    total_tax_cents: Mapped[int] = mapped_column(BigInteger)
    unit_cost: Mapped[Decimal | None] = mapped_column(Cost)  # coût moyen figé, pour la marge
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    status: Mapped[str] = mapped_column(String(10), default="ACTIVE")  # ACTIVE, ANNULEE
    voided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    void_reason: Mapped[str | None] = mapped_column(Text)
    returned_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
