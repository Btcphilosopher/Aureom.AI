"""Caisse tactile : sessions, ventes, remises autorisées, annulations, paiements partiels, clôture.

AVERTISSEMENT : prototype NON certifié (voir docs/conformite-et-cadre.md). Les tickets portent la mention
« TICKET DE DÉMONSTRATION » et le système ne satisfait pas, à lui seul, les conditions d'inaltérabilité,
de sécurisation, de conservation et d'archivage exigées des logiciels de caisse en France.
"""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.common import audit, next_code
from app.core.errors import DomainError, Forbidden, NotFound
from app.core.security import CurrentUser, ROLE_PERMISSIONS, verify_password
from app.core.types import utcnow
from app.core.units import check_quantity
from app.core.money import apply_discount_bp, format_eur, format_rate, line_amount, split_ttc
from app.db import notify
from app.modules.admin.models import Role, Site, User
from app.modules.catalog import service as cat
from app.modules.customers import service as cust
from app.modules.inventory import service as inv
from app.modules.inventory.models import StockPosition
from app.modules.payments import service as pay
from app.modules.payments.models import Payment, Refund
from app.modules.pos.models import CashRegister, PosSession, Sale, SaleLine

PRICE_LIST = "MAGASIN"


def open_session(db: Session, register_id: int, float_cents: int, user: CurrentUser) -> PosSession:
    reg = db.get(CashRegister, register_id)
    if not reg:
        raise NotFound("Caisse", register_id)
    user.check_site(reg.site_id)
    if db.scalar(select(PosSession).where(PosSession.register_id == register_id, PosSession.status == "OUVERTE")):
        raise DomainError("SESSION_OUVERTE", "Une session est déjà ouverte sur cette caisse", 409)
    if float_cents < 0:
        raise DomainError("FOND_INVALIDE", "Fond de caisse négatif")
    s = PosSession(register_id=register_id, opened_by=user.id, opening_float_cents=float_cents)
    db.add(s)
    db.flush()
    audit(db, user.id, "caisse.ouverture", "pos_session", s.id, f"Ouverture {reg.code}, fond {format_eur(float_cents)}")
    return s


def _session(db: Session, sid: int) -> PosSession:
    s = db.get(PosSession, sid)
    if not s:
        raise NotFound("Session de caisse", sid)
    if s.status != "OUVERTE":
        raise DomainError("SESSION_CLOTUREE", "Session de caisse clôturée")
    return s


def create_sale(db: Session, session_id: int, user: CurrentUser, customer_id: int | None = None,
                idempotency_key: str | None = None) -> Sale:
    if idempotency_key:
        existing = db.scalar(select(Sale).where(Sale.idempotency_key == idempotency_key))
        if existing:
            return existing
    s = _session(db, session_id)
    reg = db.get(CashRegister, s.register_id)
    sale = Sale(code=next_code(db, reg.code.replace("CAISSE-", "T"), width=6), session_id=s.id, site_id=reg.site_id,
                customer_id=customer_id, cashier_id=user.id, idempotency_key=idempotency_key)
    db.add(sale)
    db.flush()
    return sale


def get_sale(db: Session, sale_id: int, lock: bool = False) -> Sale:
    q = select(Sale).where(Sale.id == sale_id)
    if lock:
        q = q.with_for_update()
    sale = db.scalar(q)
    if not sale:
        raise NotFound("Vente", sale_id)
    return sale


def _editable(db: Session, sale: Sale) -> None:
    if sale.status != "EN_COURS":
        raise DomainError("VENTE_FIGEE", f"La vente {sale.code} est {sale.status.lower()}")
    if pay.paid_cents(db, "VENTE", sale.id) or pay.pending_cents(db, "VENTE", sale.id):
        raise DomainError("PAIEMENT_ENGAGE", "Un paiement est engagé : annulez-le ou remboursez avant de modifier")


def add_line(db: Session, sale_id: int, code: str, quantity, user: CurrentUser, lot_code: str | None = None) -> SaleLine:
    sale = get_sale(db, sale_id, lock=True)
    _editable(db, sale)
    variant, packaging = cat.lookup_code(db, code)
    level = packaging.level if packaging else "PIECE"
    try:
        snap = cat.snapshot(db, PRICE_LIST, variant.id, packaging_level=level)
    except DomainError:
        if level == "PIECE":
            raise
        # pas de prix au conditionnement : prix pièce × contenance
        base = cat.snapshot(db, PRICE_LIST, variant.id)
        snap = base
        snap.packaging_level, snap.qty_in_base = level, packaging.qty_in_base
        snap.unit_price_cents = int(base.unit_price_cents * packaging.qty_in_base)
    qty = Decimal(str(quantity))
    if level != "PIECE" or snap.unit == "PCE":
        qty = check_quantity(qty, "PCE")
    else:
        qty = check_quantity(qty, snap.unit)
    if qty <= 0:
        raise DomainError("QUANTITE_INVALIDE", "Quantité strictement positive requise")
    lot_id = None
    if lot_code:
        from app.modules.inventory.models import Lot

        lot = db.scalar(select(Lot).where(Lot.variant_id == variant.id, Lot.lot_code == lot_code))
        if lot is None:
            raise DomainError("LOT_INCONNU", f"Lot {lot_code} inconnu pour cet article")
        if lot.status != "ACTIF":
            raise DomainError("LOT_BLOQUE", f"Le lot {lot_code} est {lot.status.lower()} : vente interdite")
        lot_id = lot.id
    pos = db.get(StockPosition, (variant.id, sale.site_id))
    n = (db.scalar(select(func.max(SaleLine.line_no)).where(SaleLine.sale_id == sale.id)) or 0) + 1
    gross = line_amount(snap.unit_price_cents, qty)
    ht, tax = split_ttc(gross, snap.tax_rate_bp)
    line = SaleLine(sale_id=sale.id, line_no=n, variant_id=variant.id, sku=snap.sku, label=snap.label,
                    description=snap.description, scanned_code=code, unit=snap.unit, packaging_level=level,
                    qty_in_base=snap.qty_in_base, quantity=qty, unit_price_ttc_cents=snap.unit_price_cents,
                    price_id=snap.price_id, tax_rate_bp=snap.tax_rate_bp, tax_regime_code=snap.tax_regime_code,
                    gross_ttc_cents=gross, total_ttc_cents=gross, total_ht_cents=ht, total_tax_cents=tax,
                    unit_cost=pos.avg_unit_cost if pos else None, lot_id=lot_id)
    db.add(line)
    db.flush()
    sale.lines.append(line) if line not in sale.lines else None
    recompute(sale)
    return line


def authorize_override(db: Session, username: str | None, password: str | None, perm: str) -> User:
    if not username or not password:
        raise Forbidden("Autorisation d'un responsable requise", permission=perm)
    u = db.scalar(select(User).where(User.username == username, User.active.is_(True)))
    if not u or not verify_password(password, u.password_hash):
        raise Forbidden("Identifiants du responsable invalides")
    perms = set().union(*(ROLE_PERMISSIONS.get(r.role_code, set()) for r in u.roles))
    if perm not in perms:
        raise Forbidden("Ce responsable n'a pas la permission requise", permission=perm)
    return u


def max_discount(db: Session, roles: list[str]) -> int:
    return max([r.max_discount_bp for r in db.scalars(select(Role).where(Role.code.in_(roles)))] or [0])


def discount_line(db: Session, line_id: int, discount_bp: int, reason: str, user: CurrentUser,
                  manager_username: str | None = None, manager_password: str | None = None) -> SaleLine:
    line = db.get(SaleLine, line_id)
    if not line or line.status != "ACTIVE":
        raise NotFound("Ligne", line_id)
    sale = get_sale(db, line.sale_id, lock=True)
    _editable(db, sale)
    if not reason or len(reason) < 3:
        raise DomainError("MOTIF_REQUIS", "Motif de remise requis")
    authorizer = user.id
    allowed = max_discount(db, user.roles) if user.has("pos.discount") else 0
    if discount_bp > allowed:
        mgr = authorize_override(db, manager_username, manager_password, "pos.discount")
        if discount_bp > max_discount(db, [r.role_code for r in mgr.roles]):
            raise Forbidden("Remise supérieure au plafond du responsable")
        authorizer = mgr.id
    net, disc = apply_discount_bp(line.gross_ttc_cents, discount_bp)
    line.discount_bp, line.discount_cents, line.discount_reason = discount_bp, disc, reason
    line.discount_authorized_by = authorizer
    line.total_ttc_cents = net
    line.total_ht_cents, line.total_tax_cents = split_ttc(net, line.tax_rate_bp)
    recompute(sale)
    audit(db, user.id, "caisse.remise", "sale_line", line.id,
          f"Remise {format_rate(discount_bp)} sur {line.label} ({reason}), autorisée par l'utilisateur {authorizer}")
    return line


def void_line(db: Session, line_id: int, reason: str, user: CurrentUser,
              manager_username: str | None = None, manager_password: str | None = None) -> SaleLine:
    line = db.get(SaleLine, line_id)
    if not line or line.status != "ACTIVE":
        raise NotFound("Ligne", line_id)
    sale = get_sale(db, line.sale_id, lock=True)
    _editable(db, sale)
    by = user.id
    # Annuler la dernière ligne saisie est libre ; une ligne antérieure exige pos.void.
    last = max(l.line_no for l in sale.lines if l.status == "ACTIVE")
    if line.line_no != last and not user.has("pos.void"):
        by = authorize_override(db, manager_username, manager_password, "pos.void").id
    line.status, line.voided_by, line.void_reason = "ANNULEE", by, reason
    recompute(sale)
    audit(db, user.id, "caisse.annulation_ligne", "sale_line", line.id, f"Annulation ligne {line.line_no} : {reason}")
    return line


def recompute(sale: Sale) -> None:
    active = [l for l in sale.lines if l.status == "ACTIVE"]
    sale.total_ttc_cents = sum(l.total_ttc_cents for l in active)
    sale.total_ht_cents = sum(l.total_ht_cents for l in active)
    sale.total_tax_cents = sum(l.total_tax_cents for l in active)
    sale.discount_cents = sum(l.discount_cents for l in active)
    by_rate: dict[int, list[int]] = defaultdict(lambda: [0, 0, 0])
    for l in active:
        by_rate[l.tax_rate_bp][0] += l.total_ht_cents
        by_rate[l.tax_rate_bp][1] += l.total_tax_cents
        by_rate[l.tax_rate_bp][2] += l.total_ttc_cents
    sale.tax_summary = [{"taux_pb": r, "taux": format_rate(r), "ht": v[0], "taxe": v[1], "ttc": v[2]}
                        for r, v in sorted(by_rate.items())]


def add_payment(db: Session, sale_id: int, method: str, amount_cents: int, idempotency_key: str, user: CurrentUser,
                card_token: str | None = None, cash_tendered_cents: int | None = None) -> Payment:
    sale = get_sale(db, sale_id, lock=True)  # verrou : pas de trop-perçu en concurrence
    if sale.status != "EN_COURS":
        existing = db.scalar(select(Payment).where(Payment.idempotency_key == idempotency_key))
        if existing:
            return existing
        raise DomainError("VENTE_FIGEE", f"La vente {sale.code} est {sale.status.lower()}")
    if not any(l.status == "ACTIVE" for l in sale.lines):
        raise DomainError("PANIER_VIDE", "Panier vide")
    return pay.create_payment(db, target_type="VENTE", target_id=sale.id, method=method, amount_cents=amount_cents,
                              idempotency_key=idempotency_key, due_cents=sale.total_ttc_cents, actor_id=user.id,
                              card_token=card_token, cash_tendered_cents=cash_tendered_cents,
                              session_id=sale.session_id)


def complete_sale(db: Session, sale_id: int, user: CurrentUser) -> Sale:
    """Clôt la vente si elle est intégralement payée, puis enregistre les sorties de stock (étape distincte)."""
    sale = get_sale(db, sale_id, lock=True)
    if sale.status == "TERMINEE":
        return sale  # idempotent
    if sale.status != "EN_COURS":
        raise DomainError("VENTE_FIGEE", f"Vente {sale.status.lower()}")
    paid = pay.paid_cents(db, "VENTE", sale.id)
    if pay.pending_cents(db, "VENTE", sale.id):
        raise DomainError("PAIEMENT_EN_ATTENTE", "Un paiement carte est en attente de confirmation du prestataire")
    if paid != sale.total_ttc_cents or sale.total_ttc_cents <= 0:
        raise DomainError("RESTE_A_PAYER", f"Reste à payer : {format_eur(sale.total_ttc_cents - paid)}",
                          reste=sale.total_ttc_cents - paid)
    for l in sale.lines:
        if l.status != "ACTIVE":
            continue
        inv.consume_for_sale(db, l.variant_id, sale.site_id, l.quantity * l.qty_in_base, actor_id=user.id,
                             lot_id=l.lot_id, document_type="VENTE", document_id=sale.id, document_ref=sale.code)
    sale.status, sale.completed_at = "TERMINEE", utcnow()
    credit = sum(p.captured_cents for p in pay.payments_for(db, "VENTE", sale.id) if p.method == "AVOIR")
    sale.loyalty_points = cust.earn(db, sale.customer_id, paid - credit, sale.code)
    audit(db, user.id, "caisse.vente", "sale", sale.id, f"Vente {sale.code} {format_eur(sale.total_ttc_cents)}")
    notify(db, "caisse.vente", {"code": sale.code, "site": sale.site_id, "total": sale.total_ttc_cents})
    return sale


def cancel_sale(db: Session, sale_id: int, reason: str, user: CurrentUser,
                manager_username: str | None = None, manager_password: str | None = None) -> Sale:
    sale = get_sale(db, sale_id, lock=True)
    if sale.status != "EN_COURS":
        raise DomainError("VENTE_FIGEE", "Seule une vente en cours peut être annulée ; sinon, utilisez un retour")
    if pay.paid_cents(db, "VENTE", sale.id) > 0:
        raise DomainError("PAIEMENT_A_REMBOURSER", "Remboursez d'abord les paiements capturés")
    if not user.has("pos.void"):
        authorize_override(db, manager_username, manager_password, "pos.void")
    for p in pay.payments_for(db, "VENTE", sale.id):
        if p.status in ("EN_ATTENTE", "AUTORISE"):
            p.status = "ANNULE"
    sale.status, sale.void_reason = "ANNULEE", reason
    audit(db, user.id, "caisse.annulation", "sale", sale.id, f"Annulation {sale.code} : {reason}")
    return sale


def close_session(db: Session, session_id: int, counted_cash_cents: int, user: CurrentUser) -> PosSession:
    s = _session(db, session_id)
    if db.scalar(select(func.count()).select_from(Sale).where(Sale.session_id == s.id, Sale.status == "EN_COURS")):
        raise DomainError("VENTES_EN_COURS", "Des ventes sont en cours : terminez-les ou annulez-les")
    pays = list(db.scalars(select(Payment).where(Payment.session_id == s.id)))
    refunds = list(db.scalars(select(Refund).where(Refund.session_id == s.id, Refund.status == "REMBOURSE")))
    by_method: dict[str, int] = defaultdict(int)
    for p in pays:
        if p.status == "CAPTURE":
            by_method[p.method] += p.captured_cents
    refunds_by_method: dict[str, int] = defaultdict(int)
    for r in refunds:
        refunds_by_method[db.get(Payment, r.payment_id).method] += r.amount_cents
    expected = s.opening_float_cents + by_method.get("ESPECES", 0) - refunds_by_method.get("ESPECES", 0)
    sales = list(db.scalars(select(Sale).where(Sale.session_id == s.id)))
    done = [x for x in sales if x.status == "TERMINEE"]
    s.expected_cash_cents, s.counted_cash_cents = expected, counted_cash_cents
    s.difference_cents = counted_cash_cents - expected
    s.status, s.closed_by, s.closed_at = "CLOTUREE", user.id, utcnow()
    s.closing_report = {
        "avertissement": "Rapport de clôture de DÉMONSTRATION — prototype non certifié",
        "ventes_terminees": len(done), "ventes_annulees": sum(1 for x in sales if x.status == "ANNULEE"),
        "chiffre_affaires_ttc": sum(x.total_ttc_cents for x in done),
        "chiffre_affaires_ht": sum(x.total_ht_cents for x in done),
        "taxes": sum(x.total_tax_cents for x in done), "remises": sum(x.discount_cents for x in done),
        "encaissements_par_moyen": dict(by_method), "remboursements_par_moyen": dict(refunds_by_method),
        "fond_de_caisse": s.opening_float_cents, "especes_attendues": expected, "especes_comptees": counted_cash_cents,
        "ecart": s.difference_cents,
    }
    if s.difference_cents != 0:
        from app.modules.automation.alerts import raise_alert

        reg = db.get(CashRegister, s.register_id)
        raise_alert(db, "CAISSE", "ATTENTION" if abs(s.difference_cents) < 2000 else "CRITIQUE",
                    f"Écart de caisse {reg.code}", f"Écart de {format_eur(s.difference_cents)} à la clôture de la "
                    f"session {s.id} (attendu {format_eur(expected)}, compté {format_eur(counted_cash_cents)}).",
                    f"caisse:{s.id}", entity_type="pos_session", entity_id=s.id, site_id=reg.site_id)
    audit(db, user.id, "caisse.cloture", "pos_session", s.id, f"Clôture, écart {format_eur(s.difference_cents)}")
    return s


def ticket_text(db: Session, sale: Sale) -> str:
    tz = ZoneInfo(get_settings().timezone)
    site = db.get(Site, sale.site_id)
    dt = (sale.completed_at or sale.created_at).astimezone(tz)
    w = 42
    out = ["*** TICKET DE DÉMONSTRATION ***".center(w), "Sans valeur fiscale — prototype".center(w), "",
           "MAISON & MARCHÉ".center(w), site.name.center(w), "", f"Ticket {sale.code}",
           f"Le {dt:%d/%m/%Y} à {dt:%H:%M}", "-" * w]
    for l in sale.lines:
        if l.status != "ACTIVE":
            continue
        qty = f"{l.quantity.normalize():f}".replace(".", ",")
        out.append(l.label[:w])
        left = f"  {qty} × {format_eur(l.unit_price_ttc_cents)}"
        out.append(left + format_eur(l.gross_ttc_cents).rjust(w - len(left)))
        if l.discount_cents:
            t = f"  Remise {format_rate(l.discount_bp)}"
            out.append(t + ("-" + format_eur(l.discount_cents)).rjust(w - len(t)))
    out += ["-" * w, "TOTAL TTC" + format_eur(sale.total_ttc_cents).rjust(w - 9)]
    for t in sale.tax_summary:
        s_ = f"TVA {t['taux']} sur {format_eur(t['ht'])} HT"
        out.append(s_ + format_eur(t["taxe"]).rjust(w - len(s_)))
    out.append("")
    for p in pay.payments_for(db, "VENTE", sale.id):
        if p.status == "CAPTURE":
            lab = ("Carte simulée" if p.method == "CARTE_SIMULEE" else pay.METHODS[p.method]) + \
                (f" ****{p.card_last4}" if p.card_last4 else "")
            out.append(lab[:30] + format_eur(p.captured_cents).rjust(w - len(lab[:30])))
            if p.change_cents:
                out.append("Rendu" + format_eur(p.change_cents).rjust(w - 5))
    if sale.loyalty_points:
        out.append(f"Points fidélité gagnés : {sale.loyalty_points}")
    out += ["", "Échange ou remboursement sur présentation".center(w), "du ticket sous 30 jours.".center(w)]
    return "\n".join(out)
