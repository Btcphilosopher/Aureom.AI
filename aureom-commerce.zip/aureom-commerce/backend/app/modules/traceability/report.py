"""Rapport de traçabilité d'un lot (JSON, HTML imprimable, CSV)."""
from __future__ import annotations

import csv
import html
import io
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.errors import NotFound
from app.core.types import utcnow
from app.core.units import format_qty
from app.modules.admin.models import Location, Organisation, Site
from app.modules.aftersales.models import Recall, RecallLot, RecallTask
from app.modules.catalog.models import Variant
from app.modules.inventory.models import MOVEMENT_TYPES, QUALITY_LABELS, Lot, StockBalance, StockMovement
from app.modules.purchasing.models import SupplierDocument
from app.modules.traceability.models import EVENT_TYPES, TraceEvent
from app.modules.traceability.service import proof_levels

LIMITS = [
    "Une signature identifie la clé qui a signé ; elle ne prouve ni l'identité de la personne, ni la réalité de l'événement.",
    "Une empreinte (SHA-256) permet de vérifier qu'un fichier correspond exactement à celui référencé ; elle ne dit rien "
    "de la véracité de son contenu.",
    "Le registre conserve des déclarations selon son protocole (endorsement par plusieurs organisations, ordonnancement "
    "Raft) ; il ne garantit pas qu'elles soient exactes.",
    "Aucun de ces mécanismes ne prouve, à lui seul, que l'événement physique a eu lieu : seul un contrôle indépendant "
    "documenté (contrôle physique, analyse, audit) peut l'étayer.",
    "Les ventes en caisse sans lecture du lot sont rattachées au lot par la règle FEFO : ces destinations sont PRÉSUMÉES.",
]


def build(db: Session, lot_id: int) -> dict:
    lot = db.get(Lot, lot_id)
    if not lot:
        raise NotFound("Lot", lot_id)
    v = db.get(Variant, lot.variant_id)
    sup = db.get(Organisation, lot.supplier_id) if lot.supplier_id else None
    events = list(db.scalars(select(TraceEvent).where(TraceEvent.subject_ref == lot.trace_ref)
                             .order_by(TraceEvent.occurred_at, TraceEvent.declared_at)))
    moves = list(db.scalars(select(StockMovement).where(StockMovement.lot_id == lot.id).order_by(StockMovement.id)))
    sites = {s.id: s for s in db.scalars(select(Site))}
    locs = {l.id: l for l in db.scalars(select(Location))}
    bals = list(db.scalars(select(StockBalance).where(StockBalance.lot_id == lot.id, StockBalance.quantity > 0)))
    docs = list(db.scalars(select(SupplierDocument).where(SupplierDocument.lot_id == lot.id)))
    recalls = [db.get(Recall, rl.recall_id) for rl in db.scalars(select(RecallLot).where(RecallLot.lot_id == lot.id))]
    unit = v.product.base_unit
    dests = []
    for m in moves:
        if m.quantity < 0 and m.movement_type in ("VENTE", "EXPEDITION", "TRANSFERT_SORTIE", "RETOUR_FOURNISSEUR"):
            dests.append({"type": MOVEMENT_TYPES[m.movement_type], "document": m.document_ref,
                          "site": sites[m.site_id].name, "quantite": format_qty(-m.quantity, unit),
                          "certitude": "lot scanné" if m.lot_attribution == "SCANNE" else
                          ("présumée (FEFO)" if m.lot_attribution == "FEFO_PRESUME" else "déclarée"),
                          "date": m.recorded_at})
    return {
        "genere_le": utcnow(), "mode_registre": events[0].ledger_backend if events else None,
        "lot": {"id": lot.id, "numero": lot.lot_code, "code_interne": lot.internal_code, "reference_partagee": lot.trace_ref,
                "statut": lot.status, "peremption": lot.expires_on, "type_date": lot.expiry_kind,
                "fabrication": lot.manufactured_on},
        "article": {"sku": v.sku, "libelle": v.label, "gtin": v.gtin, "unite": unit},
        "fournisseur": sup.name if sup else None,
        "evenements": [{
            "id": e.id, "type": EVENT_TYPES.get(e.event_type, e.event_type), "code_type": e.event_type,
            "emetteur": e.issuer_org, "origine": e.origin, "survenu_le": e.occurred_at, "declare_le": e.declared_at,
            "lieu": e.location_ref, "precedent": e.previous_event_id, "corrige": e.corrects_event_id,
            "contrepartie": e.counterparty_org, "etat_contrepartie": e.counterparty_status,
            "empreinte_contenu": e.payload_sha256, "pieces": e.evidence, "cle": e.signer_key_id,
            "registre": {"etat": e.ledger_status, "transaction": e.ledger_tx_id, "bloc": e.ledger_block,
                         "horodatage": e.ledger_timestamp, "erreur": e.ledger_error},
            "niveaux_de_preuve": proof_levels(db, e),
        } for e in events],
        "mouvements": [{"date": m.recorded_at, "type": MOVEMENT_TYPES.get(m.movement_type, m.movement_type),
                        "site": sites[m.site_id].name, "emplacement": locs[m.location_id].code,
                        "etat": QUALITY_LABELS[m.quality_state], "quantite": format_qty(m.quantity, unit),
                        "document": m.document_ref, "correction_de": m.corrects_movement_id} for m in moves],
        "stock_actuel": [{"site": sites[b.site_id].name, "emplacement": locs[b.location_id].code,
                          "etat": QUALITY_LABELS[b.quality_state], "quantite": format_qty(b.quantity, unit)} for b in bals],
        "destinations": dests,
        "documents": [{"type": d.kind, "emetteur_declare": d.claimed_issuer, "reference": d.claimed_reference,
                       "empreinte": d.sha256, "authenticite": d.authenticity_status,
                       "methode_verification": d.verification_method} for d in docs],
        "rappels": [{"code": r.code, "statut": r.status, "motif": r.reason,
                     "taches_ouvertes": len(db.scalars(select(RecallTask).where(RecallTask.recall_id == r.id,
                                                                                RecallTask.status == "A_FAIRE")).all())}
                    for r in recalls],
        "limites_de_la_preuve": LIMITS,
        "donnees_personnelles": "Aucune donnée personnelle dans ce rapport : les clients ne sont désignés que par les "
                                "références de documents.",
    }


def _fmt(dt) -> str:
    if dt is None:
        return "—"
    if hasattr(dt, "astimezone"):
        try:
            return dt.astimezone(ZoneInfo(get_settings().timezone)).strftime("%d/%m/%Y %H:%M")
        except (TypeError, ValueError):
            pass
    return dt.strftime("%d/%m/%Y")


def to_html(r: dict) -> str:
    e = html.escape
    rows = "".join(
        f"<tr><td>{e(ev['type'])}</td><td>{e(ev['emetteur'])}</td><td>{_fmt(ev['survenu_le'])}</td>"
        f"<td>{e(ev['registre']['etat'])}{(' — bloc ' + str(ev['registre']['bloc'])) if ev['registre']['bloc'] else ''}</td>"
        f"<td>{'<br>'.join(('✔ ' if n['atteint'] else '✘ ') + e(n['libelle']) for n in ev['niveaux_de_preuve'])}</td>"
        f"<td><code>{e(ev['empreinte_contenu'][:16])}…</code></td></tr>" for ev in r["evenements"])
    mv = "".join(f"<tr><td>{_fmt(m['date'])}</td><td>{e(m['type'])}</td><td>{e(m['site'])}</td><td>{e(m['emplacement'])}</td>"
                 f"<td>{e(m['etat'])}</td><td>{e(m['quantite'])}</td><td>{e(m['document'] or '')}</td></tr>"
                 for m in r["mouvements"])
    ds = "".join(f"<tr><td>{e(d['type'])}</td><td>{e(d['document'] or '')}</td><td>{e(d['site'])}</td>"
                 f"<td>{e(d['quantite'])}</td><td>{e(d['certitude'])}</td></tr>" for d in r["destinations"])
    docs = "".join(f"<tr><td>{e(d['type'])}</td><td>{e(d['emetteur_declare'] or '')}</td><td><code>{e(d['empreinte'][:16])}…</code></td>"
                   f"<td>{e(d['authenticite'])}</td></tr>" for d in r["documents"])
    lim = "".join(f"<li>{e(x)}</li>" for x in r["limites_de_la_preuve"])
    lot = r["lot"]
    return f"""<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Rapport de traçabilité — lot {e(lot['numero'])}</title>
<style>body{{font-family:system-ui,sans-serif;margin:2rem;color:#0b1b33}}h1{{color:#0b1b33}}h2{{border-bottom:2px solid #b87333;padding-bottom:.2rem}}
table{{border-collapse:collapse;width:100%;font-size:.85rem;margin-bottom:1rem}}td,th{{border:1px solid #cfd6e4;padding:.3rem .5rem;text-align:left;vertical-align:top}}
th{{background:#eef2fa}}.note{{background:#fff7ec;border-left:4px solid #b87333;padding:.6rem 1rem}}</style></head><body>
<h1>Rapport de traçabilité</h1><p>AUREOM COMMERCE — Maison &amp; Marché (enseigne fictive) · généré le {_fmt(r['genere_le'])}
· registre : {e(str(r['mode_registre'] or 'aucun événement'))}</p>
<h2>Lot</h2><table><tr><th>Article</th><td>{e(r['article']['libelle'])} ({e(r['article']['sku'])}, GTIN {e(r['article']['gtin'] or '—')})</td></tr>
<tr><th>Lot fournisseur</th><td>{e(lot['numero'])} · interne {e(lot['code_interne'])}</td></tr><tr><th>Fournisseur</th><td>{e(r['fournisseur'] or '—')}</td></tr>
<tr><th>Péremption</th><td>{e(lot['type_date'] or '')} {_fmt(lot['peremption']) if lot['peremption'] else '—'}</td></tr><tr><th>Statut</th><td>{e(lot['statut'])}</td></tr>
<tr><th>Référence partagée</th><td><code>{e(lot['reference_partagee'])}</code></td></tr></table>
<h2>Événements partagés</h2><table><tr><th>Type</th><th>Émetteur</th><th>Survenu le</th><th>Registre</th><th>Niveaux de preuve</th><th>Empreinte</th></tr>{rows}</table>
<h2>Mouvements internes (PostgreSQL, non partagés)</h2><table><tr><th>Date</th><th>Type</th><th>Site</th><th>Emplacement</th><th>État</th><th>Quantité</th><th>Document</th></tr>{mv}</table>
<h2>Destinations connues</h2><table><tr><th>Type</th><th>Document</th><th>Site</th><th>Quantité</th><th>Certitude</th></tr>{ds}</table>
<h2>Pièces fournies</h2><table><tr><th>Type</th><th>Émetteur déclaré</th><th>Empreinte</th><th>Authenticité</th></tr>{docs}</table>
<h2>Limites de la preuve</h2><div class="note"><ul>{lim}</ul></div><p>{e(r['donnees_personnelles'])}</p></body></html>"""


def to_csv(r: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["section", "date", "type", "emetteur_ou_site", "detail", "etat_registre", "quantite", "document"])
    for ev in r["evenements"]:
        w.writerow(["evenement", _fmt(ev["survenu_le"]), ev["type"], ev["emetteur"], ev["id"], ev["registre"]["etat"], "", ""])
    for m in r["mouvements"]:
        w.writerow(["mouvement", _fmt(m["date"]), m["type"], m["site"], m["emplacement"] + " / " + m["etat"], "",
                    m["quantite"], m["document"] or ""])
    for d in r["destinations"]:
        w.writerow(["destination", _fmt(d["date"]), d["type"], d["site"], d["certitude"], "", d["quantite"], d["document"] or ""])
    return buf.getvalue()
