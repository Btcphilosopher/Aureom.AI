"""Gestion des clés de signature applicatives (Ed25519).

La clé privée est lue depuis un fichier monté en secret (Docker secret / volume chiffré), hors dépôt
et jamais transmise au navigateur. En production, remplacer FileKeyProvider par un fournisseur
KMS/HSM (Vault Transit, PKCS#11) : seule l'opération sign() est nécessaire, la clé ne sort pas du module.
"""
from __future__ import annotations

import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from app.config import get_settings


class FileKeyProvider:
    custody = "fichier-secret"

    def __init__(self, path: str, key_id: str, create_if_missing: bool = False):
        self.path = Path(path)
        self.key_id = key_id
        if not self.path.exists():
            if not create_if_missing:
                raise FileNotFoundError(f"Clé de signature absente : {self.path}")
            self.path.parent.mkdir(parents=True, exist_ok=True)
            k = Ed25519PrivateKey.generate()
            pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                  serialization.NoEncryption())
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as f:
                f.write(pem)
        self._key = serialization.load_pem_private_key(self.path.read_bytes(), password=None)
        if not isinstance(self._key, Ed25519PrivateKey):
            raise ValueError("La clé de signature doit être de type Ed25519")

    def sign(self, data: bytes) -> str:
        return base64.b64encode(self._key.sign(data)).decode()

    def public_key_b64(self) -> str:
        raw = self._key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return base64.b64encode(raw).decode()


def verify(public_key_b64: str, data: bytes, signature_b64: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64)).verify(base64.b64decode(signature_b64), data)
        return True
    except Exception:
        return False


_provider: FileKeyProvider | None = None


def get_signer() -> FileKeyProvider:
    global _provider
    if _provider is None:
        s = get_settings()
        _provider = FileKeyProvider(s.signing_key_path, s.signing_key_id,
                                    create_if_missing=s.environment != "production")
    return _provider


def set_signer(p: FileKeyProvider | None) -> None:
    global _provider
    _provider = p
