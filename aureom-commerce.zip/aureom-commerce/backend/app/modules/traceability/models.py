"""Événements de traçabilité (copie locale), clés de signature, boîte d'envoi transactionnelle,
vérifications indépendantes et réconciliations avec le registre partagé."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.types import created_at, pk, ts
from app.db import Base

EVENT_TYPES = {
    "LOT_CREATED": "Création d'un lot",
    "SUPPLIER_SHIPMENT": "Expédition fournisseur",
    "RECEIPT": "Réception",
    "INSPECTION_RECORDED": "Contrôle enregistré",
    "CUSTODY_TRANSFER": "Transfert de garde",
    "TRANSFORMATION": "Transformation / reconditionnement",
    "CUSTOMER_SHIPMENT": "Expédition client",
    "RECALL": "Rappel",
    "CORRECTION": "Correction liée",
    "DISPUTE": "Contestation",
}

# Niveaux de preuve affichés — jamais un badge « authentique ».
PROOF_LEVELS = {
    "DECLARE": "Déclaré (enregistré localement, non signé)",
    "SIGNE": "Signé (la clé {key} a signé ce contenu)",
    "CONFIRME_REGISTRE": "Confirmé sur le registre (transaction validée par le réseau)",
    "VERIFIE_INDEPENDAMMENT": "Vérifié par contrôle indépendant",
}


class SigningKey(Base):
    __tablename__ = "signing_keys"
    key_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    org_msp: Mapped[str] = mapped_column(String(60))
    public_key_b64: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(20), default="ACTIVE")  # ACTIVE, RETIREE, REVOQUEE
    valid_from: Mapped[datetime] = ts(False)
    retired_at: Mapped[datetime | None] = ts()
    revoked_at: Mapped[datetime | None] = ts()
    revocation_reason: Mapped[str | None] = mapped_column(Text)
    custody: Mapped[str] = mapped_column(String(60), default="fichier-secret")  # fichier-secret, kms, hsm
    ledger_registered: Mapped[bool] = mapped_column(default=False)
    ledger_tx_id: Mapped[str | None] = mapped_column(String(80))
    created_at: Mapped[datetime] = created_at()


class TraceEvent(Base):
    __tablename__ = "trace_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)  # eventId (UUID)
    event_type: Mapped[str] = mapped_column(String(30))
    issuer_org: Mapped[str] = mapped_column(String(60))
    origin: Mapped[str] = mapped_column(String(10), default="LOCAL")  # LOCAL, EXTERNE
    subject_kind: Mapped[str] = mapped_column(String(10), default="LOT")
    subject_ref: Mapped[str] = mapped_column(String(200), index=True)
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    occurred_at: Mapped[datetime] = ts(False)
    declared_at: Mapped[datetime] = ts(False)
    schema_version: Mapped[str] = mapped_column(String(10), default="1.0")
    previous_event_id: Mapped[str | None] = mapped_column(String(36))
    corrects_event_id: Mapped[str | None] = mapped_column(String(36))
    counterparty_org: Mapped[str | None] = mapped_column(String(60))
    location_ref: Mapped[str | None] = mapped_column(String(100))
    evidence: Mapped[list] = mapped_column(JSONB, default=list)
    # Détails hors chaîne (peuvent contenir des informations commerciales) + sel de l'empreinte.
    details: Mapped[dict] = mapped_column(JSONB, default=dict)
    details_salt: Mapped[str | None] = mapped_column(String(64))
    details_digest: Mapped[str | None] = mapped_column(String(64))
    envelope: Mapped[str] = mapped_column(Text)  # chaîne exacte signée
    payload_sha256: Mapped[str] = mapped_column(String(64))
    signature_b64: Mapped[str | None] = mapped_column(String(120))
    signer_key_id: Mapped[str | None] = mapped_column(String(80))
    local_status: Mapped[str] = mapped_column(String(20), default="SIGNE")  # DECLARE, SIGNE
    # NON_PUBLIE, EN_ATTENTE, SOUMIS, INCONNU, CONFIRME, REJETE
    ledger_status: Mapped[str] = mapped_column(String(20), default="EN_ATTENTE")
    ledger_backend: Mapped[str | None] = mapped_column(String(20))
    ledger_tx_id: Mapped[str | None] = mapped_column(String(80))
    ledger_block: Mapped[int | None] = mapped_column(BigInteger)
    ledger_timestamp: Mapped[datetime | None] = ts()
    ledger_error_code: Mapped[str | None] = mapped_column(String(40))
    ledger_error: Mapped[str | None] = mapped_column(Text)
    # SANS_OBJET, EN_ATTENTE_CONTREPARTIE (provisoire), CONFIRME_PAR_CONTREPARTIE, CONTESTE
    counterparty_status: Mapped[str] = mapped_column(String(30), default="SANS_OBJET")
    verification_status: Mapped[str] = mapped_column(String(30), default="NON_VERIFIE")
    source_type: Mapped[str | None] = mapped_column(String(30))
    source_id: Mapped[int | None] = mapped_column(BigInteger)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()


class LedgerOutbox(Base):
    """Boîte d'envoi transactionnelle : la ligne est écrite dans la même transaction que l'opération
    métier ; un traitement en arrière-plan la publie, avec reprises et déduplication par eventId."""

    __tablename__ = "ledger_outbox"
    id: Mapped[int] = pk()
    trace_event_id: Mapped[str] = mapped_column(ForeignKey("trace_events.id"), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="EN_ATTENTE")  # EN_ATTENTE, EN_COURS, PUBLIE, ABANDONNE
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime] = created_at()
    locked_until: Mapped[datetime | None] = ts()
    last_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = created_at()
    done_at: Mapped[datetime | None] = ts()


class IndependentVerification(Base):
    __tablename__ = "independent_verifications"
    id: Mapped[int] = pk()
    trace_event_id: Mapped[str] = mapped_column(ForeignKey("trace_events.id"))
    method: Mapped[str] = mapped_column(String(40))  # CONTROLE_PHYSIQUE, ANALYSE_LABORATOIRE, AUDIT_FOURNISSEUR, CONTROLE_DOCUMENTAIRE_SOURCE
    verifier_name: Mapped[str] = mapped_column(String(120))
    verifier_org: Mapped[str] = mapped_column(String(120))
    result: Mapped[str] = mapped_column(String(20))  # CONFORME, NON_CONFORME, NON_CONCLUANT
    performed_at: Mapped[datetime] = ts(False)
    evidence_object_id: Mapped[int | None] = mapped_column(ForeignKey("stored_objects.id"))
    notes: Mapped[str] = mapped_column(Text, default="")
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()


class ReconciliationRun(Base):
    __tablename__ = "ledger_reconciliations"
    id: Mapped[int] = pk()
    started_at: Mapped[datetime] = created_at()
    finished_at: Mapped[datetime | None] = ts()
    backend: Mapped[str] = mapped_column(String(20))
    checked: Mapped[int] = mapped_column(Integer, default=0)
    confirmed: Mapped[int] = mapped_column(Integer, default=0)
    mismatches: Mapped[list] = mapped_column(JSONB, default=list)
    imported: Mapped[int] = mapped_column(Integer, default=0)
    summary: Mapped[str] = mapped_column(Text, default="")


class SimulatedLedgerRecord(Base):
    """Registre de SIMULATION (mode hors réseau). Ce n'est PAS une blockchain : un seul gestionnaire,
    aucune validation par d'autres organisations. Il reproduit seulement le contrat d'interface."""

    __tablename__ = "simulated_ledger_records"
    event_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    subject_ref: Mapped[str] = mapped_column(String(200), index=True)
    envelope: Mapped[str] = mapped_column(Text)
    signature_b64: Mapped[str] = mapped_column(String(120))
    payload_sha256: Mapped[str] = mapped_column(String(64))
    submitter_msp: Mapped[str] = mapped_column(String(60))
    tx_id: Mapped[str] = mapped_column(String(80))
    block_number: Mapped[int] = mapped_column(BigInteger)
    tx_timestamp: Mapped[datetime] = created_at()


class SimulatedLedgerKey(Base):
    __tablename__ = "simulated_ledger_keys"
    key_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    owner_msp: Mapped[str] = mapped_column(String(60))
    public_key_b64: Mapped[str] = mapped_column(String(80))
    valid_from: Mapped[datetime] = ts(False)
    retired_at: Mapped[datetime | None] = ts()
    revoked_at: Mapped[datetime | None] = ts()
    revocation_reason: Mapped[str | None] = mapped_column(Text)
