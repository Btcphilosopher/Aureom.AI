"""Déclaration, signature, publication (boîte d'envoi), réconciliation et vérification des événements.

États distincts, jamais confondus :
  1. déclaré localement (opération PostgreSQL validée) ;
  2. signé (clé applicative de l'organisation) ;
  3. confirmé sur le registre (transaction validée par le réseau Fabric) ;
  4. vérifié par contrôle indépendant (procédure humaine documentée).
Une opération locale peut être finalisée alors que sa publication est encore en attente.
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.common import audit
from app.core.errors import DomainError, NotFound
from app.core.types import utcnow
from app.db import SessionLocal, notify
from app.modules.admin.models import Organisation
from app.modules.automation.alerts import raise_alert
from app.modules.inventory.models import Lot
from app.modules.ledger.adapters import LedgerError, _parse_ts, get_ledger
from app.modules.traceability import keys
from app.modules.traceability.models import (EVENT_TYPES, IndependentVerification, LedgerOutbox, ReconciliationRun,
                                             SigningKey, TraceEvent)

REF_RE = re.compile(r"^[A-Za-z0-9:._\-|/]{1,200}$")
LOC_RE = re.compile(r"^[A-Za-z0-9:._\-]{1,100}$")


def z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def details_digest(details: dict, salt: str) -> str:
    """Empreinte salée des détails hors chaîne : permet de prouver plus tard la correspondance d'un
    document détaillé sans exposer son contenu, et empêche de deviner le contenu par force brute."""
    return hashlib.sha256((salt + canonical(details)).encode()).hexdigest()


def declare_event(db: Session, *, event_type: str, occurred_at: datetime, actor_id: int | None,
                  lot: Lot | None = None, subject_ref: str | None = None, subject_kind: str = "LOT",
                  gtin: str | None = None, lot_code: str | None = None, previous_event_id: str | None = None,
                  corrects_event_id: str | None = None, counterparty_org: str | None = None,
                  location_ref: str | None = None, evidence: list[dict] | None = None,
                  details: dict | None = None, source_type: str | None = None, source_id: int | None = None,
                  publish: bool = True) -> TraceEvent:
    s = get_settings()
    if event_type not in EVENT_TYPES:
        raise DomainError("TYPE_EVENEMENT_INCONNU", f"Type d'événement inconnu : {event_type}")
    if lot is not None:
        from app.modules.catalog.models import Variant

        v = db.get(Variant, lot.variant_id)
        subject_ref, gtin, lot_code = lot.trace_ref, v.gtin, lot.lot_code
    if not subject_ref or not REF_RE.match(subject_ref):
        raise DomainError("REFERENCE_INVALIDE", "Référence de lot/produit invalide pour le registre")
    if location_ref and not LOC_RE.match(location_ref):
        raise DomainError("LIEU_INVALIDE", "Le lieu doit être un code (GLN ou code site), pas un texte libre")
    if counterparty_org and not db.scalar(select(Organisation).where(Organisation.msp_id == counterparty_org)):
        raise DomainError("CONTREPARTIE_INCONNUE", f"Organisation inconnue sur le registre : {counterparty_org}")
    if event_type in ("CORRECTION", "DISPUTE") and not corrects_event_id:
        raise DomainError("CORRECTION_SANS_CIBLE", "Une correction ou contestation doit viser un événement existant")
    if event_type not in ("CORRECTION", "DISPUTE") and corrects_event_id:
        raise DomainError("CHAMP_INTERDIT", "correctsEventId réservé aux corrections et contestations")
    if previous_event_id and not db.get(TraceEvent, previous_event_id):
        _try_import(db, previous_event_id)  # événement d'une autre organisation : import depuis le registre
    for ref in (corrects_event_id,):
        if ref and not db.get(TraceEvent, ref):
            raise DomainError("EVENEMENT_INCONNU", f"Événement référencé inconnu : {ref}")
    if event_type == "CORRECTION":
        target = db.get(TraceEvent, corrects_event_id)
        if target.issuer_org != s.org_msp_id:
            raise DomainError("CORRECTION_NON_PROPRIETAIRE",
                              "On ne corrige que ses propres événements ; utilisez une contestation (DISPUTE)")
    ev_list = []
    for e in evidence or []:
        if not re.fullmatch(r"[0-9a-f]{64}", e.get("sha256", "")):
            raise DomainError("EMPREINTE_INVALIDE", "Empreinte SHA-256 de pièce justificative invalide")
        ev_list.append({"sha256": e["sha256"], "kind": e.get("kind", "DOCUMENT")[:50],
                        "mediaType": e.get("mediaType", "application/octet-stream")[:100]})
    if len(ev_list) > 20:
        raise DomainError("TROP_DE_PIECES", "20 pièces justificatives au maximum par événement")
    details = details or {}
    salt = secrets.token_hex(16)
    digest = details_digest(details, salt) if details else None
    signer = keys.get_signer()
    now = utcnow()
    eid = str(uuid.uuid4())
    subject = {"kind": subject_kind, "ref": subject_ref}
    if gtin:
        subject["gtin"] = gtin
    if lot_code:
        subject["lot"] = lot_code
    env = {"schemaVersion": "1.0", "eventId": eid, "eventType": event_type, "issuerOrg": s.org_msp_id,
           "subject": subject, "occurredAt": z(occurred_at), "declaredAt": z(now), "evidence": ev_list,
           "signerKeyId": signer.key_id}
    for k_, v_ in (("previousEventId", previous_event_id), ("correctsEventId", corrects_event_id),
                   ("counterpartyOrg", counterparty_org), ("locationRef", location_ref), ("detailsDigest", digest)):
        if v_:
            env[k_] = v_
    envelope = canonical(env)
    signature = signer.sign(envelope.encode())
    te = TraceEvent(id=eid, event_type=event_type, issuer_org=s.org_msp_id, origin="LOCAL", subject_kind=subject_kind,
                    subject_ref=subject_ref, lot_id=lot.id if lot else None, occurred_at=occurred_at, declared_at=now,
                    previous_event_id=previous_event_id, corrects_event_id=corrects_event_id,
                    counterparty_org=counterparty_org, location_ref=location_ref, evidence=ev_list, details=details,
                    details_salt=salt if details else None, details_digest=digest, envelope=envelope,
                    payload_sha256=hashlib.sha256(envelope.encode()).hexdigest(), signature_b64=signature,
                    signer_key_id=signer.key_id, local_status="SIGNE",
                    ledger_status="EN_ATTENTE" if publish else "NON_PUBLIE",
                    counterparty_status="EN_ATTENTE_CONTREPARTIE" if event_type == "CUSTODY_TRANSFER" and counterparty_org and counterparty_org != s.org_msp_id else "SANS_OBJET",
                    source_type=source_type, source_id=source_id, created_by=actor_id)
    db.add(te)
    db.flush()
    if publish:
        db.add(LedgerOutbox(trace_event_id=eid))
    audit(db, actor_id, "tracabilite.declaration", "trace_event", eid,
          f"Événement {EVENT_TYPES[event_type]} déclaré et signé pour {subject_ref}")
    notify(db, "tracabilite.declare", {"id": eid, "type": event_type, "reference": subject_ref})
    return te


def _try_import(db: Session, event_id: str) -> None:
    """Importe un événement d'une autre organisation référencé localement. Si le registre est indisponible,
    la référence est conservée telle quelle : le registre la validera à la publication."""
    try:
        adapter = get_ledger()
        rec = adapter.get_event(event_id)
        if rec:
            _import_or_link(db, adapter, rec)
    except LedgerError:
        pass


# --- Publication -------------------------------------------------------------------------------------------
def _backoff(attempts: int) -> timedelta:
    return timedelta(seconds=min(5 * 2 ** max(attempts - 1, 0), 900))


def process_outbox(limit: int = 20, adapter=None) -> dict:
    """Publie les événements en attente. Sûr en exécution concurrente (FOR UPDATE SKIP LOCKED) et
    après un arrêt brutal (les lignes EN_COURS expirées sont reprises en état « issue inconnue »)."""
    adapter = adapter or get_ledger()
    s = get_settings()
    stats = {"publies": 0, "doublons": 0, "rejetes": 0, "reportes": 0, "erreurs": 0}
    now = utcnow()
    with SessionLocal() as db:
        rows = list(db.scalars(select(LedgerOutbox).where(or_(
            (LedgerOutbox.status == "EN_ATTENTE") & (LedgerOutbox.next_attempt_at <= now),
            (LedgerOutbox.status == "EN_COURS") & (LedgerOutbox.locked_until < now))).order_by(LedgerOutbox.id)
            .limit(limit).with_for_update(skip_locked=True)))
        for r in rows:
            if r.status == "EN_COURS":  # reprise après interruption : issue inconnue
                ev = db.get(TraceEvent, r.trace_event_id)
                ev.ledger_status = "INCONNU"
            r.status, r.locked_until = "EN_COURS", now + timedelta(seconds=s.ledger_timeout_s + 30)
            r.attempts += 1
        ids = [r.id for r in rows]
        db.commit()
    for oid in ids:
        with SessionLocal() as db:
            r = db.get(LedgerOutbox, oid)
            ev = db.get(TraceEvent, r.trace_event_id)
            outcome = _publish_one(db, r, ev, adapter)
            stats[outcome] += 1
            db.commit()
    return stats


def _dependency_pending(db: Session, ev: TraceEvent) -> str | None:
    for dep in (ev.previous_event_id, ev.corrects_event_id):
        if dep:
            d = db.get(TraceEvent, dep)
            if d is not None and d.ledger_status != "CONFIRME":
                return dep
    return None


def _publish_one(db: Session, r: LedgerOutbox, ev: TraceEvent, adapter) -> str:
    s = get_settings()
    ev.ledger_backend = adapter.name
    dep = _dependency_pending(db, ev)
    if dep:
        r.status, r.next_attempt_at, r.attempts = "EN_ATTENTE", utcnow() + timedelta(seconds=5), max(r.attempts - 1, 0)
        r.last_error = f"En attente de la confirmation de l'événement {dep}"
        return "reportes"
    try:
        if ev.ledger_status == "INCONNU":
            onchain = adapter.get_event(ev.id)
            if onchain is not None:
                if onchain.get("payloadSha256") == ev.payload_sha256:
                    _confirm(db, r, ev, onchain.get("txId"), onchain.get("blockNumber"),
                             _parse_ts(onchain.get("txTimestamp")))
                    return "doublons"
                return _reject(db, r, ev, "CONFLICT", "Contenu différent déjà inscrit sous cet identifiant")
        ev.ledger_status = "SOUMIS"
        res = adapter.submit(ev.envelope, ev.signature_b64)
        if res.payload_sha256 and res.payload_sha256 != ev.payload_sha256:
            return _reject(db, r, ev, "EMPREINTE_DIVERGENTE", "Le registre a calculé une autre empreinte")
        _confirm(db, r, ev, res.tx_id, res.block_number, res.tx_timestamp)
        return "doublons" if res.status == "DUPLICATE" else "publies"
    except LedgerError as e:
        if e.retryable or (e.code == "UNKNOWN_PREVIOUS" and ev.previous_event_id):
            ev.ledger_status = "INCONNU" if e.code == "COMMIT_UNKNOWN" else "EN_ATTENTE"
            ev.ledger_error_code, ev.ledger_error = e.code, e.message
            r.last_error = f"{e.code}: {e.message}"
            if r.attempts >= s.ledger_max_attempts:
                r.status = "ABANDONNE"
                raise_alert(db, "REGISTRE", "CRITIQUE", "Publication abandonnée après plusieurs tentatives",
                            f"L'événement {ev.id} ({EVENT_TYPES[ev.event_type]}) n'a pas pu être publié après "
                            f"{r.attempts} tentatives. Dernière erreur : {e.message}. Relance manuelle requise.",
                            f"outbox:{ev.id}", entity_type="trace_event", entity_id=ev.id)
            else:
                r.status, r.next_attempt_at = "EN_ATTENTE", utcnow() + _backoff(r.attempts)
            return "erreurs"
        return _reject(db, r, ev, e.code, e.message)


def _confirm(db: Session, r: LedgerOutbox, ev: TraceEvent, tx_id, block, ts) -> None:
    ev.ledger_status, ev.ledger_tx_id, ev.ledger_block, ev.ledger_timestamp = "CONFIRME", tx_id, block, ts
    ev.ledger_error_code = ev.ledger_error = None
    r.status, r.done_at, r.last_error = "PUBLIE", utcnow(), None
    notify(db, "tracabilite.confirme", {"id": ev.id, "tx": tx_id, "bloc": block})


def _reject(db: Session, r: LedgerOutbox, ev: TraceEvent, code: str, message: str) -> str:
    ev.ledger_status, ev.ledger_error_code, ev.ledger_error = "REJETE", code, message
    r.status, r.last_error = "ABANDONNE", f"{code}: {message}"
    raise_alert(db, "REGISTRE", "CRITIQUE", "Événement rejeté par le registre",
                f"L'événement {ev.id} ({EVENT_TYPES[ev.event_type]}) a été rejeté : {code} — {message}. "
                f"L'opération locale reste valide ; une correction ou une analyse est nécessaire.",
                f"rejet:{ev.id}", entity_type="trace_event", entity_id=ev.id)
    notify(db, "tracabilite.rejete", {"id": ev.id, "code": code})
    return "rejetes"


def retry_event(db: Session, event_id: str, actor_id: int) -> None:
    r = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == event_id))
    if r is None:
        raise NotFound("Publication", event_id)
    ev = db.get(TraceEvent, event_id)
    if ev.ledger_status == "CONFIRME":
        raise DomainError("DEJA_CONFIRME", "Événement déjà confirmé sur le registre")
    if ev.ledger_status == "REJETE" and ev.ledger_error_code not in ("UNKNOWN_PREVIOUS",):
        raise DomainError("REJET_DEFINITIF", "Rejet définitif : créez un événement de correction lié")
    r.status, r.next_attempt_at, r.attempts = "EN_ATTENTE", utcnow(), 0
    ev.ledger_status = "INCONNU" if ev.ledger_status in ("SOUMIS", "INCONNU") else "EN_ATTENTE"
    audit(db, actor_id, "tracabilite.relance", "trace_event", event_id, "Relance manuelle de la publication")


# --- Réconciliation ---------------------------------------------------------------------------------------
def reconcile(adapter=None, import_external: bool = True) -> dict:
    """Compare l'état local et le registre :
    - événements locaux « en attente » ou « inconnus » déjà présents sur le registre → confirmés ;
    - événements confirmés dont l'empreinte diverge → anomalie critique ;
    - événements d'autres organisations sur nos lots → importés (non vérifiés) ;
    - transferts de garde provisoires → confirmés ou contestés par la contrepartie."""
    adapter = adapter or get_ledger()
    with SessionLocal() as db:
        run = ReconciliationRun(backend=adapter.name)
        db.add(run)
        db.flush()
        mismatches, checked, confirmed, imported = [], 0, 0, 0
        try:
            local = list(db.scalars(select(TraceEvent).where(TraceEvent.origin == "LOCAL",
                                                            TraceEvent.ledger_status != "NON_PUBLIE")))
            for ev in local:
                checked += 1
                onchain = adapter.get_event(ev.id)
                if onchain is None:
                    if ev.ledger_status == "CONFIRME":
                        mismatches.append({"evenement": ev.id, "anomalie": "confirmé localement mais absent du registre"})
                    continue
                if onchain.get("payloadSha256") != ev.payload_sha256:
                    mismatches.append({"evenement": ev.id, "anomalie": "empreinte différente sur le registre"})
                    continue
                if ev.ledger_status != "CONFIRME":
                    ev.ledger_status, ev.ledger_tx_id = "CONFIRME", onchain.get("txId")
                    ev.ledger_block = onchain.get("blockNumber")
                    ev.ledger_timestamp = _parse_ts(onchain.get("txTimestamp"))
                    ob = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == ev.id))
                    if ob and ob.status != "PUBLIE":
                        ob.status, ob.done_at = "PUBLIE", utcnow()
                    confirmed += 1
            if import_external:
                refs = {r for r in db.scalars(select(Lot.trace_ref))}
                for ref in refs:
                    for rec in adapter.events_by_subject(ref):
                        res = _import_or_link(db, adapter, rec)
                        if res == "ORPHELIN":
                            mismatches.append({"evenement": rec["eventId"], "anomalie":
                                               "événement de notre organisation présent sur le registre mais absent de "
                                               "la base locale (restauration de sauvegarde ? autre instance ?) — "
                                               "réimporté pour revue"})
                        elif res:
                            imported += 1
            _update_counterparty(db)
            run.summary = (f"{checked} événement(s) local(aux) vérifié(s), {confirmed} confirmé(s) par réconciliation, "
                           f"{imported} événement(s) externe(s) importé(s), {len(mismatches)} anomalie(s)")
        except LedgerError as e:
            run.summary = f"Réconciliation interrompue : {e.message}"
            mismatches.append({"anomalie": "registre indisponible", "detail": e.message})
        run.checked, run.confirmed, run.imported, run.mismatches = checked, confirmed, imported, mismatches
        run.finished_at = utcnow()
        for m in mismatches:
            if m.get("evenement"):
                raise_alert(db, "REGISTRE", "CRITIQUE", "Écart de réconciliation avec le registre",
                            f"Événement {m['evenement']} : {m['anomalie']}.", f"reconc:{m['evenement']}",
                            entity_type="trace_event", entity_id=m["evenement"])
        db.commit()
        return {"id": run.id, "resume": run.summary, "anomalies": mismatches, "controles": checked,
                "confirmes": confirmed, "importes": imported}


def _import_or_link(db: Session, adapter, rec: dict) -> str | None:
    """Importe un événement du registre inconnu localement. Retourne EXTERNE, ORPHELIN (émis par notre
    organisation mais absent localement) ou None (déjà connu)."""
    if db.get(TraceEvent, rec["eventId"]):
        return None
    env_s = rec["envelope"]
    env = json.loads(env_s)
    key = adapter.get_key(env["signerKeyId"])
    sig_ok = bool(key) and key.get("ownerMsp") == env["issuerOrg"] and keys.verify(
        key["publicKeyBase64"], env_s.encode(), rec["signatureBase64"])
    lot = db.scalar(select(Lot).where(Lot.trace_ref == env["subject"]["ref"]))
    origin = "ORPHELIN" if env["issuerOrg"] == get_settings().org_msp_id else "EXTERNE"
    te = TraceEvent(id=env["eventId"], event_type=env["eventType"], issuer_org=env["issuerOrg"], origin=origin,
                    subject_kind=env["subject"]["kind"], subject_ref=env["subject"]["ref"],
                    lot_id=lot.id if lot else None, occurred_at=_parse_ts(env["occurredAt"]),
                    declared_at=_parse_ts(env["declaredAt"]), schema_version=env["schemaVersion"],
                    previous_event_id=env.get("previousEventId"), corrects_event_id=env.get("correctsEventId"),
                    counterparty_org=env.get("counterpartyOrg"), location_ref=env.get("locationRef"),
                    evidence=env.get("evidence", []), details={}, details_digest=env.get("detailsDigest"),
                    envelope=env_s, payload_sha256=rec["payloadSha256"], signature_b64=rec["signatureBase64"],
                    signer_key_id=env["signerKeyId"], local_status="SIGNE" if sig_ok else "SIGNATURE_INVALIDE",
                    ledger_status="CONFIRME", ledger_backend=adapter.name, ledger_tx_id=rec.get("txId"),
                    ledger_block=rec.get("blockNumber"), ledger_timestamp=_parse_ts(rec.get("txTimestamp")))
    db.add(te)
    db.flush()
    return origin


def _update_counterparty(db: Session) -> None:
    pending = db.scalars(select(TraceEvent).where(TraceEvent.counterparty_status == "EN_ATTENTE_CONTREPARTIE"))
    for ev in pending:
        ack = db.scalar(select(TraceEvent).where(TraceEvent.previous_event_id == ev.id,
                                                 TraceEvent.issuer_org == ev.counterparty_org,
                                                 TraceEvent.event_type == "RECEIPT"))
        dispute = db.scalar(select(TraceEvent).where(TraceEvent.corrects_event_id == ev.id,
                                                     TraceEvent.event_type == "DISPUTE"))
        if dispute:
            ev.counterparty_status = "CONTESTE"
        elif ack:
            ev.counterparty_status = "CONFIRME_PAR_CONTREPARTIE"


# --- Vérification indépendante -------------------------------------------------------------------------------
VERIFICATION_METHODS = {
    "CONTROLE_PHYSIQUE": "Contrôle physique de la marchandise par une personne distincte du déclarant",
    "ANALYSE_LABORATOIRE": "Analyse par un laboratoire (rapport joint)",
    "AUDIT_FOURNISSEUR": "Audit sur site du fournisseur",
    "CONTROLE_DOCUMENTAIRE_SOURCE": "Vérification du certificat directement auprès de l'organisme émetteur",
}


def record_verification(db: Session, event_id: str, *, method: str, verifier_name: str, verifier_org: str,
                        result: str, performed_at: datetime, notes: str, evidence_object_id: int | None,
                        actor_id: int) -> IndependentVerification:
    ev = db.get(TraceEvent, event_id)
    if ev is None:
        raise NotFound("Événement", event_id)
    if method not in VERIFICATION_METHODS:
        raise DomainError("METHODE_INCONNUE", "Méthode de vérification non reconnue")
    if result not in ("CONFORME", "NON_CONFORME", "NON_CONCLUANT"):
        raise DomainError("RESULTAT_INCONNU", "Résultat : CONFORME, NON_CONFORME ou NON_CONCLUANT")
    if ev.created_by is not None and ev.created_by == actor_id:
        raise DomainError("SEPARATION_DES_TACHES",
                          "La personne qui a déclaré l'événement ne peut pas enregistrer sa vérification indépendante")
    if evidence_object_id is None and method in ("ANALYSE_LABORATOIRE", "CONTROLE_DOCUMENTAIRE_SOURCE"):
        raise DomainError("PIECE_REQUISE", "Cette méthode exige une pièce justificative (rapport, échange)")
    v = IndependentVerification(trace_event_id=event_id, method=method, verifier_name=verifier_name,
                                verifier_org=verifier_org, result=result, performed_at=performed_at, notes=notes,
                                evidence_object_id=evidence_object_id, recorded_by=actor_id)
    db.add(v)
    if result == "CONFORME":
        ev.verification_status = "VERIFIE_INDEPENDAMMENT"
    elif result == "NON_CONFORME":
        ev.verification_status = "CONTESTE"
    audit(db, actor_id, "tracabilite.verification", "trace_event", event_id,
          f"Vérification indépendante ({method}) : {result}")
    return v


def proof_levels(db: Session, ev: TraceEvent) -> list[dict]:
    key = db.get(SigningKey, ev.signer_key_id) if ev.signer_key_id else None
    sig_ok = False
    if ev.signature_b64 and ev.signer_key_id:
        pub = key.public_key_b64 if key else None
        if pub is None and ev.origin in ("EXTERNE", "ORPHELIN"):
            sig_ok = ev.local_status == "SIGNE"
        elif pub:
            sig_ok = keys.verify(pub, ev.envelope.encode(), ev.signature_b64)
    verifs = list(db.scalars(select(IndependentVerification).where(IndependentVerification.trace_event_id == ev.id)))
    return [
        {"niveau": "DECLARE", "atteint": True, "libelle": "Déclaré",
         "explication": f"Déclaration de {ev.issuer_org} enregistrée le {ev.declared_at:%d/%m/%Y à %H:%M} (UTC)."},
        {"niveau": "SIGNE", "atteint": sig_ok, "libelle": "Signé",
         "explication": (f"La clé « {ev.signer_key_id} » a signé exactement ce contenu. Cela identifie la clé, "
                         f"pas la personne ni la réalité physique de l'événement.") if sig_ok else
         "Signature absente ou invalide."},
        {"niveau": "CONFIRME_REGISTRE", "atteint": ev.ledger_status == "CONFIRME",
         "libelle": "Confirmé sur le registre" if ev.ledger_backend != "simulation" else "Confirmé (registre SIMULÉ)",
         "explication": (f"Transaction {ev.ledger_tx_id} (bloc {ev.ledger_block}) validée selon le protocole du "
                         f"réseau : la déclaration est conservée et partagée, sa véracité n'est pas établie."
                         if ev.ledger_status == "CONFIRME" else f"État de publication : {ev.ledger_status}.")},
        {"niveau": "VERIFIE_INDEPENDAMMENT", "atteint": ev.verification_status == "VERIFIE_INDEPENDAMMENT",
         "libelle": "Vérifié par contrôle indépendant",
         "explication": "; ".join(f"{v.method} par {v.verifier_name} ({v.verifier_org}) le {v.performed_at:%d/%m/%Y} : {v.result}"
                                  for v in verifs) or "Aucun contrôle indépendant enregistré."},
    ]


def register_own_key(db: Session, adapter=None) -> SigningKey:
    """Publie la clé publique de l'organisation sur le registre (idempotent)."""
    adapter = adapter or get_ledger()
    signer = keys.get_signer()
    s = get_settings()
    k = db.get(SigningKey, signer.key_id)
    if k is None:
        k = SigningKey(key_id=signer.key_id, org_msp=s.org_msp_id, public_key_b64=signer.public_key_b64(),
                       valid_from=utcnow() - timedelta(minutes=1), custody=signer.custody)
        db.add(k)
        db.flush()
    if not k.ledger_registered:
        existing = adapter.get_key(k.key_id)
        if existing:
            if existing.get("publicKeyBase64") != k.public_key_b64:
                raise DomainError("CLE_DIVERGENTE", "Une autre clé publique est déjà enregistrée sous cet identifiant")
            k.valid_from = _parse_ts(existing.get("validFrom")) or k.valid_from
        else:
            res = adapter.register_key(k.key_id, k.public_key_b64, k.valid_from)
            k.ledger_tx_id = res.get("txId")
        k.ledger_registered = True
    return k
