"""Besoin → proposition → approbation → commande → réception → contrôle → rapprochement."""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.common import audit, next_code
from app.core.errors import DomainError, Forbidden
from app.core.security import CurrentUser
from app.core.types import ZERO, utcnow
from app.core.units import check_quantity, format_qty, packs_to_base, round_up_to_pack
from app.db import notify
from app.modules.admin.models import Organisation, Role, Site
from app.modules.automation.alerts import raise_alert
from app.modules.catalog.models import Packaging, ProductSupplier, Variant
from app.modules.inventory import service as inv
from app.modules.purchasing.models import (GoodsReceipt, GoodsReceiptLine, PurchaseOrder, PurchaseOrderLine,
                                           PurchaseProposal, PurchaseProposalLine, ReplenishmentNeed,
                                           SupplierDocument, SupplierInvoice, SupplierReturn)
from app.modules.traceability import service as trace


def supplier_terms(db: Session, variant_id: int, supplier_id: int | None = None) -> ProductSupplier:
    q = select(ProductSupplier).where(ProductSupplier.variant_id == variant_id)
    q = q.where(ProductSupplier.supplier_id == supplier_id) if supplier_id else q.order_by(
        ProductSupplier.preferred.desc())
    ps = db.scalars(q).first()
    if not ps:
        raise DomainError("FOURNISSEUR_ABSENT", "Aucun fournisseur référencé pour cet article")
    return ps


def create_proposal(db: Session, supplier_id: int, site_id: int, lines: list[dict], rationale: str,
                    user_id: int | None) -> PurchaseProposal:
    """lines : [{variant_id, pack_qty} ou {variant_id, base_qty}] — une quantité en unités est arrondie au
    conditionnement d'achat supérieur (on n'achète pas 7 pièces d'un article vendu par carton de 24)."""
    p = PurchaseProposal(code=next_code(db, "PA"), supplier_id=supplier_id, site_id=site_id, rationale=rationale,
                         requested_by=user_id)
    db.add(p)
    db.flush()
    total = 0
    for ln in lines:
        ps = supplier_terms(db, ln["variant_id"], supplier_id)
        pack = db.get(Packaging, ps.purchase_packaging_id)
        packs = int(ln["pack_qty"]) if "pack_qty" in ln else round_up_to_pack(Decimal(str(ln["base_qty"])),
                                                                               pack.qty_in_base)
        packs = max(packs, ps.min_order_packs)
        p.lines.append(PurchaseProposalLine(variant_id=ln["variant_id"], packaging_id=pack.id, pack_qty=packs,
                                            unit_cost_cents=ps.cost_cents_per_pack, need_id=ln.get("need_id")))
        total += packs * ps.cost_cents_per_pack
        if ln.get("need_id"):
            need = db.get(ReplenishmentNeed, ln["need_id"])
            if need:
                need.status = "PROPOSE"
    p.total_cents = total
    audit(db, user_id, "achat.proposition", "purchase_proposal", p.id, f"Proposition {p.code} : {total} c HT")
    return p


def approval_limit(db: Session, user: CurrentUser) -> int:
    limits = [r.purchase_approval_limit_cents for r in db.scalars(select(Role).where(Role.code.in_(user.roles)))]
    return max(limits or [0])


def decide_proposal(db: Session, p: PurchaseProposal, user: CurrentUser, approve: bool, note: str = "") -> PurchaseOrder | None:
    if p.status != "PROPOSEE":
        raise DomainError("ETAT_INVALIDE", f"Proposition {p.code} déjà {p.status.lower()}")
    if not user.has("purchase.approve"):
        raise Forbidden("Approbation réservée aux responsables habilités")
    if approve:
        limit = approval_limit(db, user)
        if p.total_cents > limit:
            raise Forbidden(f"Montant ({p.total_cents / 100:.2f} €) supérieur à votre plafond d'approbation "
                            f"({limit / 100:.2f} €)".replace(".", ","))
        if p.requested_by == user.id and p.requested_by is not None:
            raise Forbidden("Séparation des tâches : vous ne pouvez pas approuver votre propre proposition")
    p.status = "APPROUVEE" if approve else "REJETEE"
    p.decided_by, p.decided_at, p.decision_note = user.id, utcnow(), note
    audit(db, user.id, "achat.decision", "purchase_proposal", p.id, f"{p.code} {p.status.lower()} — {note}")
    if not approve:
        return None
    return convert_to_order(db, p, user.id)


def convert_to_order(db: Session, p: PurchaseProposal, user_id: int) -> PurchaseOrder:
    if p.status != "APPROUVEE":
        raise DomainError("NON_APPROUVEE", "Seule une proposition approuvée devient une commande fournisseur")
    lead = max((supplier_terms(db, l.variant_id, p.supplier_id).lead_time_days for l in p.lines), default=5)
    po = PurchaseOrder(code=next_code(db, "CF"), supplier_id=p.supplier_id, ship_to_site_id=p.site_id,
                       proposal_id=p.id, status="ENVOYEE", ordered_at=utcnow(),
                       expected_on=date.today() + timedelta(days=lead), created_by=p.requested_by, approved_by=user_id)
    db.add(po)
    db.flush()
    total = 0
    for l in p.lines:
        pack = db.get(Packaging, l.packaging_id)
        v = db.get(Variant, l.variant_id)
        po.lines.append(PurchaseOrderLine(variant_id=l.variant_id, packaging_id=pack.id, pack_qty=l.pack_qty,
                                          base_qty=packs_to_base(Decimal(l.pack_qty), pack.qty_in_base,
                                                                 v.product.base_unit),
                                          unit_cost_cents=l.unit_cost_cents))
        total += l.pack_qty * l.unit_cost_cents
    po.total_ht_cents = total
    p.status = "CONVERTIE"
    audit(db, user_id, "achat.commande", "purchase_order", po.id, f"Commande fournisseur {po.code} émise (simulée)")
    notify(db, "achat.commande", {"code": po.code, "statut": po.status})
    return po


def receive(db: Session, po: PurchaseOrder, lines: list[dict], actor_id: int, *, delivery_note_ref: str | None = None,
            carrier: str | None = None, supplier_shipment_event_id: str | None = None,
            document_ids: list[int] | None = None) -> GoodsReceipt:
    """Réception (éventuellement partielle). lines : [{order_line_id, received_qty | received_packs, lot_code,
    expires_on, manufactured_on, damaged_qty, inspection_result, notes, temperature_c}]

    - CONFORME → stock DISPONIBLE (emplacement de stockage)
    - A_CONTROLER → À INSPECTER (zone de réception, non vendable)
    - NON_CONFORME → QUARANTAINE
    - endommagé → ENDOMMAGE (quarantaine), en attente de retour fournisseur
    """
    if po.status not in ("ENVOYEE", "PARTIELLEMENT_RECUE"):
        raise DomainError("ETAT_INVALIDE", f"La commande {po.code} n'attend pas de livraison ({po.status})")
    supplier = db.get(Organisation, po.supplier_id)
    site = db.get(Site, po.ship_to_site_id)
    gr = GoodsReceipt(code=next_code(db, "REC"), order_id=po.id, site_id=po.ship_to_site_id,
                      delivery_note_ref=delivery_note_ref, carrier=carrier,
                      supplier_shipment_event_id=supplier_shipment_event_id, received_by=actor_id)
    db.add(gr)
    db.flush()
    by_id = {l.id: l for l in po.lines}
    stock_loc = inv.site_location(db, site.id, "STOCKAGE")
    recep_loc = inv.site_location(db, site.id, "RECEPTION")
    quar_loc = inv.site_location(db, site.id, "QUARANTAINE")
    docs = [db.get(SupplierDocument, d) for d in (document_ids or [])]
    evidence = [{"sha256": d.sha256, "kind": d.kind, "mediaType": "application/pdf"} for d in docs if d]
    issues = []
    for ln in lines:
        pol = by_id.get(ln["order_line_id"])
        if pol is None:
            raise DomainError("LIGNE_INCONNUE", "Ligne de commande inconnue pour cette commande")
        v = db.get(Variant, pol.variant_id)
        unit = v.product.base_unit
        pack = db.get(Packaging, pol.packaging_id)
        if "received_packs" in ln:
            received = packs_to_base(Decimal(str(ln["received_packs"])), pack.qty_in_base, unit)
        else:
            received = check_quantity(Decimal(str(ln["received_qty"])), unit)
        damaged = check_quantity(Decimal(str(ln.get("damaged_qty", 0))), unit)
        if received <= 0 or damaged > received:
            raise DomainError("QUANTITE_INVALIDE", "Quantités reçues / endommagées incohérentes")
        remaining = pol.base_qty - pol.received_base_qty
        if received > remaining:
            raise DomainError("SURPLUS", f"Surplus non commandé ({format_qty(received - remaining, unit)}) : "
                                         f"refusez l'excédent ou faites établir un avenant à la commande")
        result = ln.get("inspection_result", "CONFORME")
        if result not in ("CONFORME", "NON_CONFORME", "A_CONTROLER"):
            raise DomainError("RESULTAT_INCONNU", "Résultat de contrôle inconnu")
        lot = None
        if v.product.lot_tracked:
            if not ln.get("lot_code"):
                raise DomainError("LOT_REQUIS", f"Numéro de lot requis pour {v.label}")
            exp = date.fromisoformat(ln["expires_on"]) if ln.get("expires_on") else None
            if v.product.expiry_kind and exp is None:
                raise DomainError("PEREMPTION_REQUISE", f"Date {v.product.expiry_kind} requise pour {v.label}")
            mfg = date.fromisoformat(ln["manufactured_on"]) if ln.get("manufactured_on") else None
            lot = inv.new_lot(db, v.id, supplier.id, ln["lot_code"], exp, mfg, v.product.expiry_kind)
        good = received - damaged
        unit_cost = Decimal(pol.unit_cost_cents) / pack.qty_in_base
        moves = []
        state, loc = {"CONFORME": ("DISPONIBLE", stock_loc), "A_CONTROLER": ("A_INSPECTER", recep_loc),
                      "NON_CONFORME": ("QUARANTAINE", quar_loc)}[result]
        if good > 0:
            moves.append(inv.MoveLine(v.id, loc.id, good, state, lot.id if lot else None, unit_cost=unit_cost))
        if damaged > 0:
            moves.append(inv.MoveLine(v.id, quar_loc.id, damaged, "ENDOMMAGE", lot.id if lot else None,
                                      unit_cost=unit_cost))
        inv.post_movements(db, "RECEPTION", moves, actor_id=actor_id, document_type="RECEPTION", document_id=gr.id,
                           document_ref=gr.code)
        grl = GoodsReceiptLine(order_line_id=pol.id, variant_id=v.id, lot_id=lot.id if lot else None,
                               received_base_qty=received, accepted_qty=good if result == "CONFORME" else ZERO,
                               damaged_qty=damaged, quarantined_qty=good if result != "CONFORME" else ZERO,
                               inspection_result=result, inspection_notes=ln.get("notes", ""),
                               temperature_c=ln.get("temperature_c"))
        gr.lines.append(grl)
        pol.received_base_qty += received
        pol.accepted_base_qty += grl.accepted_qty
        pol.rejected_base_qty += damaged
        for d in docs:
            if d and lot and d.lot_id is None:
                d.lot_id = lot.id
            if d:
                d.receipt_id = gr.id
        if damaged:
            issues.append(f"{format_qty(damaged, unit)} endommagée(s) — {v.label}")
        if result != "CONFORME":
            issues.append(f"{v.label} : {('à contrôler' if result == 'A_CONTROLER' else 'non conforme')}")
        if lot is not None:
            trace.declare_event(
                db, event_type="RECEIPT", occurred_at=utcnow(), actor_id=actor_id, lot=lot,
                previous_event_id=supplier_shipment_event_id,
                counterparty_org=supplier.msp_id if supplier.ledger_member else None,
                location_ref=site.gln or site.code, evidence=evidence,
                details={"reception": gr.code, "commande": po.code, "quantite_recue": str(received),
                         "quantite_endommagee": str(damaged), "unite": unit, "controle": result,
                         "bon_livraison": delivery_note_ref},
                source_type="RECEPTION", source_id=gr.id)
            if result == "NON_CONFORME":
                trace.declare_event(db, event_type="INSPECTION_RECORDED", occurred_at=utcnow(), actor_id=actor_id,
                                    lot=lot, location_ref=site.gln or site.code,
                                    details={"resultat": result, "notes": ln.get("notes", "")},
                                    source_type="RECEPTION", source_id=gr.id)
    po.status = "RECUE" if all(l.received_base_qty >= l.base_qty for l in po.lines) else "PARTIELLEMENT_RECUE"
    if po.status == "PARTIELLEMENT_RECUE":
        issues.append("livraison partielle : reliquat attendu")
    if issues:
        raise_alert(db, "RECEPTION", "ATTENTION", f"Écarts à la réception {gr.code}",
                    f"Commande {po.code} ({supplier.name}) : " + " ; ".join(issues) + ".", f"reception:{gr.code}",
                    entity_type="goods_receipt", entity_id=gr.id, site_id=site.id)
    audit(db, actor_id, "achat.reception", "goods_receipt", gr.id, f"Réception {gr.code} pour {po.code}")
    notify(db, "achat.reception", {"code": gr.code, "commande": po.code, "statut_commande": po.status})
    return gr


def release_inspection(db: Session, receipt_line: GoodsReceiptLine, result: str, notes: str, actor_id: int) -> None:
    """Contrôle différé d'une ligne « à contrôler » : libération en stock vendable ou quarantaine."""
    if receipt_line.inspection_result != "A_CONTROLER":
        raise DomainError("ETAT_INVALIDE", "Cette ligne n'est pas en attente de contrôle")
    gr = db.get(GoodsReceipt, receipt_line.receipt_id)
    recep = inv.site_location(db, gr.site_id, "RECEPTION")
    to = inv.site_location(db, gr.site_id, "STOCKAGE" if result == "CONFORME" else "QUARANTAINE")
    qty = receipt_line.quarantined_qty
    inv.change_quality(db, variant_id=receipt_line.variant_id, from_location_id=recep.id, lot_id=receipt_line.lot_id,
                       from_state="A_INSPECTER", to_state="DISPONIBLE" if result == "CONFORME" else "QUARANTAINE",
                       qty=qty, actor_id=actor_id, movement_type="LEVEE_QUARANTAINE" if result == "CONFORME"
                       else "MISE_EN_QUARANTAINE", to_location_id=to.id, reason=notes, document_type="RECEPTION",
                       document_id=gr.id, document_ref=gr.code)
    receipt_line.inspection_result, receipt_line.inspection_notes = result, notes
    if result == "CONFORME":
        receipt_line.accepted_qty, receipt_line.quarantined_qty = qty, ZERO
        pol = db.get(PurchaseOrderLine, receipt_line.order_line_id)
        pol.accepted_base_qty += qty
    if receipt_line.lot_id:
        from app.modules.inventory.models import Lot

        trace.declare_event(db, event_type="INSPECTION_RECORDED", occurred_at=utcnow(), actor_id=actor_id,
                            lot=db.get(Lot, receipt_line.lot_id),
                            details={"resultat": result, "notes": notes, "reception": gr.code},
                            source_type="RECEPTION", source_id=gr.id)


def attach_document(db: Session, *, supplier_id: int, kind: str, object_id: int, sha256: str,
                    claimed_issuer: str | None, claimed_reference: str | None, lot_id: int | None = None,
                    receipt_id: int | None = None) -> SupplierDocument:
    d = SupplierDocument(supplier_id=supplier_id, kind=kind, object_id=object_id, sha256=sha256,
                         claimed_issuer=claimed_issuer, claimed_reference=claimed_reference, lot_id=lot_id,
                         receipt_id=receipt_id)
    db.add(d)
    db.flush()
    return d


def verify_document(db: Session, doc: SupplierDocument, status: str, method: str, note: str, actor_id: int) -> None:
    if status not in ("VERIFIE", "REJETE"):
        raise DomainError("STATUT_INVALIDE", "Statut : VERIFIE ou REJETE")
    if len((method or "").strip()) < 10:
        raise DomainError("METHODE_REQUISE", "Décrivez la méthode de vérification (ex. confirmation écrite de "
                                             "l'organisme certificateur, numéro de dossier)")
    doc.authenticity_status, doc.verification_method, doc.verification_note = status, method, note
    doc.verified_by, doc.verified_at = actor_id, utcnow()
    audit(db, actor_id, "document.verification", "supplier_document", doc.id, f"Document {doc.kind} : {status}")


def record_invoice(db: Session, po: PurchaseOrder, invoice_number: str, invoice_date: date, lines: list[dict],
                   price_tolerance_bp: int = 100) -> SupplierInvoice:
    """Rapprochement à trois voies : commandé / accepté en réception / facturé."""
    by_id = {l.id: l for l in po.lines}
    result_lines, ok, total = [], True, 0
    for ln in lines:
        pol = by_id.get(ln["order_line_id"])
        if not pol:
            raise DomainError("LIGNE_INCONNUE", "Ligne de facture sans ligne de commande")
        pack = db.get(Packaging, pol.packaging_id)
        inv_qty = Decimal(str(ln["base_qty"]))
        inv_cost = int(ln["unit_cost_cents"])
        line_total = int((inv_qty / pack.qty_in_base) * inv_cost)
        total += line_total
        anomalies = []
        if inv_qty > pol.accepted_base_qty:
            anomalies.append(f"quantité facturée ({inv_qty}) > quantité acceptée ({pol.accepted_base_qty})")
        if abs(inv_cost - pol.unit_cost_cents) * 10000 > pol.unit_cost_cents * price_tolerance_bp:
            anomalies.append(f"prix facturé {inv_cost} c ≠ prix commandé {pol.unit_cost_cents} c")
        ok = ok and not anomalies
        result_lines.append({"ligne": pol.id, "commande": str(pol.base_qty), "recu": str(pol.received_base_qty),
                             "accepte": str(pol.accepted_base_qty), "facture": str(inv_qty),
                             "prix_commande": pol.unit_cost_cents, "prix_facture": inv_cost,
                             "anomalies": anomalies})
    invoice = SupplierInvoice(supplier_id=po.supplier_id, order_id=po.id, invoice_number=invoice_number,
                              invoice_date=invoice_date, total_ht_cents=total, lines=lines,
                              status="RAPPROCHEE" if ok else "ECART",
                              match_result={"conforme": ok, "lignes": result_lines})
    db.add(invoice)
    db.flush()
    if not ok:
        raise_alert(db, "RAPPROCHEMENT", "ATTENTION", f"Écart de rapprochement facture {invoice_number}",
                    f"Facture {invoice_number} / commande {po.code} : " +
                    " ; ".join(a for l in result_lines for a in l["anomalies"]) + ". Paiement à suspendre.",
                    f"facture:{invoice.id}", entity_type="supplier_invoice", entity_id=invoice.id)
    return invoice


def return_to_supplier(db: Session, *, supplier_id: int, site_id: int, variant_id: int, lot_id: int | None,
                       quantity: Decimal, from_state: str, reason: str, actor_id: int) -> SupplierReturn:
    loc = inv.site_location(db, site_id, "QUARANTAINE")
    sr = SupplierReturn(code=next_code(db, "RF"), supplier_id=supplier_id, site_id=site_id, variant_id=variant_id,
                        lot_id=lot_id, quantity=Decimal(quantity), reason=reason, created_by=actor_id)
    db.add(sr)
    db.flush()
    inv.post_movements(db, "RETOUR_FOURNISSEUR", [inv.MoveLine(variant_id, loc.id, -Decimal(quantity), from_state,
                                                               lot_id)],
                       actor_id=actor_id, document_type="RETOUR_FOURNISSEUR", document_id=sr.id, document_ref=sr.code,
                       reason=reason)
    sup = db.get(Organisation, supplier_id)
    if lot_id and sup.ledger_member:
        from app.modules.inventory.models import Lot

        trace.declare_event(db, event_type="CUSTODY_TRANSFER", occurred_at=utcnow(), actor_id=actor_id,
                            lot=db.get(Lot, lot_id), counterparty_org=sup.msp_id,
                            location_ref=db.get(Site, site_id).gln or db.get(Site, site_id).code,
                            details={"retour_fournisseur": sr.code, "quantite": str(quantity), "motif": reason},
                            source_type="RETOUR_FOURNISSEUR", source_id=sr.id)
    return sr


def overdue_orders(db: Session, today: date | None = None) -> list[PurchaseOrder]:
    today = today or date.today()
    return list(db.scalars(select(PurchaseOrder).where(PurchaseOrder.status.in_(("ENVOYEE", "PARTIELLEMENT_RECUE")),
                                                       PurchaseOrder.expected_on < today)))
