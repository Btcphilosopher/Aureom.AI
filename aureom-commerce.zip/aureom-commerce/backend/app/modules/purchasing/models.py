"""Achats : besoins, propositions, commandes fournisseurs, réceptions, contrôles, documents fournis,
factures, rapprochements et retours fournisseurs."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Date, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.types import Qty, created_at, pk, ts
from app.db import Base


class ReplenishmentNeed(Base):
    __tablename__ = "replenishment_needs"
    id: Mapped[int] = pk()
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    source: Mapped[str] = mapped_column(String(20))  # REGLE_REAPPRO, PREVISION, MANUEL
    explanation: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="OUVERT")  # OUVERT, PROPOSE, CLOS
    created_at: Mapped[datetime] = created_at()


class PurchaseProposal(Base):
    __tablename__ = "purchase_proposals"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    status: Mapped[str] = mapped_column(String(20), default="PROPOSEE")  # PROPOSEE, APPROUVEE, REJETEE, CONVERTIE
    total_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    rationale: Mapped[str] = mapped_column(Text, default="")
    requested_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = ts()
    decision_note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = created_at()
    lines: Mapped[list["PurchaseProposalLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan")


class PurchaseProposalLine(Base):
    __tablename__ = "purchase_proposal_lines"
    id: Mapped[int] = pk()
    proposal_id: Mapped[int] = mapped_column(ForeignKey("purchase_proposals.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    packaging_id: Mapped[int] = mapped_column(ForeignKey("packagings.id"))
    pack_qty: Mapped[int] = mapped_column(Integer)
    unit_cost_cents: Mapped[int] = mapped_column(BigInteger)  # HT par conditionnement
    need_id: Mapped[int | None] = mapped_column(ForeignKey("replenishment_needs.id"))


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    ship_to_site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    proposal_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_proposals.id"))
    # BROUILLON, ENVOYEE, PARTIELLEMENT_RECUE, RECUE, CLOTUREE, ANNULEE
    status: Mapped[str] = mapped_column(String(25), default="BROUILLON")
    ordered_at: Mapped[datetime | None] = ts()
    expected_on: Mapped[date | None] = mapped_column(Date)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    lines: Mapped[list["PurchaseOrderLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan",
                                                            order_by="PurchaseOrderLine.id")


class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"
    id: Mapped[int] = pk()
    order_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    packaging_id: Mapped[int] = mapped_column(ForeignKey("packagings.id"))
    pack_qty: Mapped[int] = mapped_column(Integer)
    base_qty: Mapped[Decimal] = mapped_column(Qty)
    unit_cost_cents: Mapped[int] = mapped_column(BigInteger)  # HT par conditionnement
    received_base_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    accepted_base_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    rejected_base_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))


class GoodsReceipt(Base):
    __tablename__ = "goods_receipts"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    delivery_note_ref: Mapped[str | None] = mapped_column(String(60))
    carrier: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20), default="VALIDEE")
    supplier_shipment_event_id: Mapped[str | None] = mapped_column(String(36))
    received_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    received_at: Mapped[datetime] = created_at()
    lines: Mapped[list["GoodsReceiptLine"]] = relationship(lazy="selectin", cascade="all, delete-orphan")


class GoodsReceiptLine(Base):
    __tablename__ = "goods_receipt_lines"
    id: Mapped[int] = pk()
    receipt_id: Mapped[int] = mapped_column(ForeignKey("goods_receipts.id"))
    order_line_id: Mapped[int] = mapped_column(ForeignKey("purchase_order_lines.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    received_base_qty: Mapped[Decimal] = mapped_column(Qty)
    accepted_qty: Mapped[Decimal] = mapped_column(Qty)
    damaged_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    quarantined_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    inspection_result: Mapped[str] = mapped_column(String(20))  # CONFORME, NON_CONFORME, A_CONTROLER
    inspection_notes: Mapped[str] = mapped_column(Text, default="")
    temperature_c: Mapped[Decimal | None] = mapped_column(Qty)


class SupplierDocument(Base):
    """Document réellement fourni par un fournisseur. Statut d'authenticité NON_VERIFIE par défaut :
    sa réception, sa signature ou son empreinte ne prouvent pas qu'il est authentique."""

    __tablename__ = "supplier_documents"
    id: Mapped[int] = pk()
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    receipt_id: Mapped[int | None] = mapped_column(ForeignKey("goods_receipts.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    kind: Mapped[str] = mapped_column(String(30))  # BON_LIVRAISON, CERTIFICAT_ANALYSE, CERTIFICAT_CONFORMITE, FACTURE, DECLARATION_CE
    claimed_issuer: Mapped[str | None] = mapped_column(String(200))
    claimed_reference: Mapped[str | None] = mapped_column(String(100))
    object_id: Mapped[int] = mapped_column(ForeignKey("stored_objects.id"))
    sha256: Mapped[str] = mapped_column(String(64))
    authenticity_status: Mapped[str] = mapped_column(String(20), default="NON_VERIFIE")  # NON_VERIFIE, VERIFIE, REJETE
    verification_method: Mapped[str | None] = mapped_column(String(200))
    verification_note: Mapped[str | None] = mapped_column(Text)
    verified_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    verified_at: Mapped[datetime | None] = ts()
    created_at: Mapped[datetime] = created_at()


class SupplierInvoice(Base):
    __tablename__ = "supplier_invoices"
    id: Mapped[int] = pk()
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    order_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id"))
    invoice_number: Mapped[str] = mapped_column(String(60))
    invoice_date: Mapped[date] = mapped_column(Date)
    total_ht_cents: Mapped[int] = mapped_column(BigInteger)
    lines: Mapped[list] = mapped_column(JSONB)  # [{order_line_id, base_qty, unit_cost_cents}]
    status: Mapped[str] = mapped_column(String(20), default="RECUE")  # RECUE, RAPPROCHEE, ECART
    match_result: Mapped[dict | None] = mapped_column(JSONB)
    created_at: Mapped[datetime] = created_at()


class SupplierReturn(Base):
    __tablename__ = "supplier_returns"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(30), unique=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("organisations.id"))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="EXPEDIE")
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
