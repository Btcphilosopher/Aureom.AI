"""Équipements et observations (Industrie 4.0), en LECTURE SEULE : une observation n'est jamais à elle
seule un mouvement de stock, une vente ou un transfert."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import Boolean, ForeignKey, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.types import created_at, pk, ts
from app.db import Base

DEVICE_KINDS = {
    "LECTEUR_CODE_BARRES": "Lecteur de codes-barres", "LECTEUR_RFID": "Lecteur RFID", "BALANCE": "Balance",
    "CAPTEUR_TEMPERATURE": "Capteur de température", "ETIQUETTE_ELECTRONIQUE": "Étiquette électronique",
    "CONVOYEUR": "Convoyeur", "SYSTEME_PREPARATION": "Système de préparation (pick-to-light)",
}


class Device(Base):
    __tablename__ = "devices"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), unique=True)
    kind: Mapped[str] = mapped_column(String(30))
    label: Mapped[str] = mapped_column(String(120))
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    location_id: Mapped[int | None] = mapped_column(ForeignKey("locations.id"))
    unit: Mapped[str | None] = mapped_column(String(10))  # CEL, KG, G…
    authorized: Mapped[bool] = mapped_column(Boolean, default=True)
    mode: Mapped[str] = mapped_column(String(20), default="LECTURE_SEULE")
    simulated: Mapped[bool] = mapped_column(Boolean, default=True)
    last_seen_at: Mapped[datetime | None] = ts()
    meta: Mapped[dict] = mapped_column(JSONB, default=dict)


class Observation(Base):
    __tablename__ = "observations"
    __table_args__ = (UniqueConstraint("device_id", "message_id"),)
    id: Mapped[int] = pk()
    device_id: Mapped[int] = mapped_column(ForeignKey("devices.id"), index=True)
    message_id: Mapped[str] = mapped_column(String(80))
    kind: Mapped[str] = mapped_column(String(30))
    observed_at: Mapped[datetime] = ts(False)  # heure de l'équipement
    received_at: Mapped[datetime] = created_at()  # heure de réception serveur
    value: Mapped[Decimal | None] = mapped_column(Numeric(14, 4))
    unit: Mapped[str | None] = mapped_column(String(10))
    payload: Mapped[dict] = mapped_column(JSONB, default=dict)
    quality: Mapped[str] = mapped_column(String(10), default="OK")  # OK, SUSPECT, INVALIDE
    quality_flags: Mapped[list] = mapped_column(JSONB, default=list)
    location_id: Mapped[int | None] = mapped_column(ForeignKey("locations.id"))


class RfidObservation(Base):
    """Lectures RFID agrégées : plusieurs lectures d'une même étiquette par le même lecteur dans la
    fenêtre de déduplication forment UNE observation (compteur de lectures)."""

    __tablename__ = "rfid_observations"
    id: Mapped[int] = pk()
    device_id: Mapped[int] = mapped_column(ForeignKey("devices.id"))
    epc: Mapped[str] = mapped_column(String(64), index=True)
    first_seen_at: Mapped[datetime] = ts(False)
    last_seen_at: Mapped[datetime] = ts(False)
    read_count: Mapped[int] = mapped_column(Integer, default=1)
    max_rssi: Mapped[Decimal | None] = mapped_column(Numeric(6, 2))
    variant_id: Mapped[int | None] = mapped_column(ForeignKey("variants.id"))
    serial_unit_id: Mapped[int | None] = mapped_column(ForeignKey("serial_units.id"))
    # OBSERVE (cohérent), ECART (incohérence à vérifier), INCONNU (étiquette non référencée)
    status: Mapped[str] = mapped_column(String(15), default="OBSERVE")
    suggestion: Mapped[str | None] = mapped_column(String(300))
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = ts()
