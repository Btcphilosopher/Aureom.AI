"""Ingestion des observations d'équipements (MQTT ou HTTP), contrôles qualité, déduplication RFID,
règle d'anomalie de température. Aucun effet direct sur le stock : uniquement des alertes et des
propositions soumises à approbation."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.errors import DomainError, Forbidden, NotFound
from app.core.types import utcnow
from app.db import notify
from app.modules.admin.models import Location
from app.modules.automation.alerts import raise_alert
from app.modules.automation.models import ActionProposal, AutomationRule
from app.modules.inventory.models import Lot, SerialUnit, StockBalance
from app.modules.iot.models import Device, Observation, RfidObservation

PLAUSIBLE = {"CEL": (Decimal(-40), Decimal(85)), "KG": (Decimal(0), Decimal(300)), "G": (Decimal(0), Decimal(300000))}


def _parse_dt(v) -> datetime | None:
    if not v:
        return None
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def ingest(db: Session, device_code: str, payload: dict, channel: str = "HTTP") -> dict:
    dev = db.scalar(select(Device).where(Device.code == device_code))
    if dev is None:
        raise NotFound("Équipement", device_code)
    if not dev.authorized:
        raise Forbidden("Équipement non autorisé : observation ignorée")
    now = utcnow()
    observed = _parse_dt(payload.get("observed_at"))
    flags = []
    if observed is None:
        observed, flags = now, ["horodatage_absent_heure_serveur_utilisee"]
    elif observed > now + timedelta(minutes=2):
        flags.append("horodatage_dans_le_futur")
    elif observed < now - timedelta(hours=24):
        flags.append("observation_tardive_plus_de_24h")
    dev.last_seen_at = now
    if dev.kind == "LECTEUR_RFID":
        return ingest_rfid(db, dev, payload, observed, flags)
    msg_id = str(payload.get("message_id") or f"{device_code}:{observed.isoformat()}")
    value, unit = payload.get("value"), payload.get("unit") or dev.unit
    dec = None
    quality = "OK"
    if value is not None:
        try:
            dec = Decimal(str(value))
        except InvalidOperation:
            quality, flags = "INVALIDE", flags + ["valeur_non_numerique"]
    if unit and dev.unit and unit != dev.unit:
        quality, flags = "INVALIDE", flags + [f"unite_inattendue_{unit}_au_lieu_de_{dev.unit}"]
    if dec is not None and unit in PLAUSIBLE:
        lo, hi = PLAUSIBLE[unit]
        if not lo <= dec <= hi:
            quality, flags = "INVALIDE", flags + ["valeur_physiquement_improbable"]
    if payload.get("sensor_status") not in (None, "ok", "OK"):
        quality = "SUSPECT" if quality == "OK" else quality
        flags.append(f"etat_capteur_{payload.get('sensor_status')}")
    if quality == "OK" and flags and any(f.startswith("horodatage") or f.startswith("observation_tardive") for f in flags):
        quality = "SUSPECT"
    obs = Observation(device_id=dev.id, message_id=msg_id, kind=dev.kind, observed_at=observed, value=dec, unit=unit,
                      payload={k: v for k, v in payload.items() if k not in ("value",)}, quality=quality,
                      quality_flags=flags, location_id=dev.location_id)
    db.flush()
    try:
        with db.begin_nested():  # le point de sauvegarde précède l'insertion
            db.add(obs)
            db.flush()
    except IntegrityError:
        return {"doublon": True, "message_id": msg_id, "effet": "aucun (message déjà reçu)"}
    result = {"doublon": False, "observation": obs.id, "qualite": quality, "indicateurs": flags, "canal": channel}
    if dev.kind == "CAPTEUR_TEMPERATURE" and quality == "OK":
        result["alerte"] = evaluate_temperature(db, dev)
    if dev.kind in ("CONVOYEUR", "SYSTEME_PREPARATION") and payload.get("state") in ("BOURRAGE", "ARRET_URGENCE", "DEFAUT"):
        raise_alert(db, "EQUIPEMENT", "ATTENTION", f"{dev.label} : {payload['state'].lower().replace('_', ' ')}",
                    f"L'équipement {dev.code} signale l'état « {payload['state']} » à {observed:%H:%M} (UTC). "
                    f"Lecture seule : aucune commande n'est envoyée à l'équipement.", f"equip:{dev.code}",
                    entity_type="device", entity_id=dev.id, site_id=dev.site_id)
    notify(db, "equipement.observation", {"equipement": dev.code, "type": dev.kind, "valeur": dec, "unite": unit,
                                          "qualite": quality})
    return result


def ingest_rfid(db: Session, dev: Device, payload: dict, observed: datetime, flags: list) -> dict:
    epc = str(payload.get("epc", "")).strip().upper()
    if not epc or len(epc) > 64:
        raise DomainError("EPC_INVALIDE", "Identifiant EPC manquant ou invalide")
    window = timedelta(seconds=get_settings().rfid_dedup_window_s)
    rssi = payload.get("rssi")
    # Verrou consultatif par (lecteur, EPC) : deux lectures simultanées ne créent pas deux observations.
    from sqlalchemy import text

    db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"rfid:{dev.id}:{epc}"})
    existing = db.scalar(select(RfidObservation).where(RfidObservation.device_id == dev.id, RfidObservation.epc == epc,
                                                       RfidObservation.last_seen_at >= observed - window)
                         .order_by(RfidObservation.last_seen_at.desc()).limit(1))
    if existing:
        existing.read_count += 1
        existing.last_seen_at = max(existing.last_seen_at, observed)
        if rssi is not None and (existing.max_rssi is None or Decimal(str(rssi)) > existing.max_rssi):
            existing.max_rssi = Decimal(str(rssi))
        return {"doublon": True, "observation": existing.id, "lectures": existing.read_count,
                "effet": "lecture agrégée à l'observation existante — aucun mouvement"}
    unit = db.scalar(select(SerialUnit).where(SerialUnit.epc == epc))
    obs = RfidObservation(device_id=dev.id, epc=epc, first_seen_at=observed, last_seen_at=observed,
                          max_rssi=Decimal(str(rssi)) if rssi is not None else None,
                          variant_id=unit.variant_id if unit else None, serial_unit_id=unit.id if unit else None)
    loc = db.get(Location, dev.location_id) if dev.location_id else None
    if unit is None:
        obs.status, obs.suggestion = "INCONNU", "Étiquette non référencée : vérifier l'encodage ou l'origine"
    elif loc and loc.kind == "EXPEDITION" and unit.status == "EN_STOCK":
        obs.status = "ECART"
        obs.suggestion = ("Passage en zone de sortie d'un article non vendu ni expédié : vérifier visuellement. "
                          "Aucune vente ni sortie n'est enregistrée automatiquement.")
    elif loc and unit.location_id and unit.location_id != loc.id and loc.kind != "EXPEDITION":
        obs.status = "ECART"
        obs.suggestion = (f"Article observé en {loc.code} alors que le stock l'indique ailleurs : proposer un "
                          f"déplacement après contrôle humain.")
    db.add(obs)
    db.flush()
    if obs.status == "ECART":
        raise_alert(db, "RFID", "INFO", "Observation RFID à vérifier", f"EPC {epc} lu par {dev.code} : {obs.suggestion}",
                    f"rfid:{epc}:{dev.id}", entity_type="rfid_observation", entity_id=obs.id, site_id=dev.site_id)
    notify(db, "equipement.rfid", {"equipement": dev.code, "epc": epc, "statut": obs.status})
    return {"doublon": False, "observation": obs.id, "statut": obs.status, "suggestion": obs.suggestion,
            "indicateurs": flags, "effet": "observation enregistrée — aucun mouvement de stock"}


def evaluate_temperature(db: Session, dev: Device) -> dict | None:
    """Règle transparente : N lectures valides consécutives hors plage (configurée sur l'emplacement ou
    à défaut dans la règle) déclenchent une alerte et une PROPOSITION de mise en quarantaine des lots
    présents. Les lectures SUSPECT/INVALIDE sont ignorées pour la décision, mais visibles."""
    rule = db.get(AutomationRule, "TEMPERATURE")
    if rule is not None and not rule.enabled:
        return None
    params = rule.params if rule else {}
    n = int(params.get("lectures_consecutives", 3))
    loc = db.get(Location, dev.location_id) if dev.location_id else None
    tmin = loc.temp_min_c if loc and loc.temp_min_c is not None else Decimal(str(params.get("min_c", 0)))
    tmax = loc.temp_max_c if loc and loc.temp_max_c is not None else Decimal(str(params.get("max_c", 25)))
    last = list(db.scalars(select(Observation).where(Observation.device_id == dev.id, Observation.quality == "OK")
                           .order_by(Observation.observed_at.desc()).limit(n)))
    if len(last) < n or not all(o.value is not None and (o.value > tmax or o.value < tmin) for o in last):
        return None
    span = (last[0].observed_at - last[-1].observed_at).total_seconds() / 60
    values = ", ".join(f"{o.value:.1f} °C".replace(".", ",") for o in reversed(last))
    lots = db.execute(select(StockBalance.lot_id, Lot.lot_code, StockBalance.quantity, StockBalance.variant_id)
                      .join(Lot, Lot.id == StockBalance.lot_id)
                      .where(StockBalance.location_id == dev.location_id, StockBalance.quantity > 0,
                             StockBalance.quality_state == "DISPONIBLE")).all() if dev.location_id else []
    msg = (f"{dev.label} ({loc.code if loc else 'emplacement inconnu'}) : {n} lectures consécutives hors plage "
           f"[{tmin} ; {tmax}] °C sur {span:.0f} min ({values}). Lots présents : "
           f"{', '.join(l.lot_code for l in lots) or 'aucun'}. Vérifier le capteur et les produits.")
    alert = raise_alert(db, "TEMPERATURE", "CRITIQUE", f"Anomalie de température — {loc.code if loc else dev.code}",
                        msg, f"temp:{dev.code}", entity_type="device", entity_id=dev.id, site_id=dev.site_id,
                        explanation={"seuil_min_c": str(tmin), "seuil_max_c": str(tmax), "lectures": n,
                                     "valeurs": [str(o.value) for o in reversed(last)],
                                     "regle": "N lectures valides consécutives hors plage"})
    if lots and not db.scalar(select(ActionProposal).where(ActionProposal.dedup_key == f"quar:{dev.code}",
                                                           ActionProposal.status == "PROPOSEE")):
        db.add(ActionProposal(kind="QUARANTAINE", source="REGLE", source_code="TEMPERATURE",
                              title=f"Mettre en quarantaine les lots de {loc.code}",
                              rationale=msg + " La décision revient au responsable qualité après contrôle.",
                              payload={"location_id": dev.location_id,
                                       "lots": [{"lot_id": l.lot_id, "variant_id": l.variant_id, "quantite": str(l.quantity)}
                                                for l in lots]},
                              required_permission="quality.inspect", site_id=dev.site_id, dedup_key=f"quar:{dev.code}"))
    return {"alerte": alert.id, "message": msg}


def latest_weight(db: Session, device_code: str) -> dict:
    dev = db.scalar(select(Device).where(Device.code == device_code, Device.kind == "BALANCE"))
    if not dev:
        raise NotFound("Balance", device_code)
    o = db.scalar(select(Observation).where(Observation.device_id == dev.id).order_by(Observation.observed_at.desc()).limit(1))
    if not o:
        raise DomainError("AUCUNE_PESEE", "Aucune pesée reçue")
    stable = bool(o.payload.get("stable")) and o.quality == "OK"
    age = (utcnow() - o.received_at).total_seconds()
    return {"valeur": o.value, "unite": o.unit, "stable": stable, "age_s": round(age, 1), "qualite": o.quality,
            "utilisable": stable and age < 30,
            "note": "Balance simulée, non vérifiée métrologiquement : ne pas utiliser pour la vente au poids réelle."}
