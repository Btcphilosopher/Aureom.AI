"""Paiement ≠ capture ≠ remboursement ≠ mouvement de stock.

- Création idempotente (clé unique en base) : un double clic ou une reprise réseau ne débite pas deux fois.
- L'état d'un paiement carte n'avance que sur un événement du prestataire dont la signature HMAC
  est vérifiée ; les événements rejoués sont ignorés (identifiant unique).
- Le prestataire est SIMULÉ ; aucune donnée brute de carte n'est acceptée.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import time
import uuid

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.common import audit
from app.core.errors import Conflict, DomainError, NotFound
from app.core.types import utcnow
from app.db import notify
from app.modules.payments.models import Payment, PaymentEvent, Refund

METHODS = {"CARTE_SIMULEE": "Carte (terminal simulé)", "ESPECES": "Espèces", "AVOIR": "Avoir",
           "VIREMENT_SIMULE": "Virement (simulé)"}

# Jetons de test du terminal simulé → comportement
SIM_TOKENS = {
    "tok_sim_accepte": ("accepte", "VISA", "4242"),
    "tok_sim_refuse": ("refuse", "MASTERCARD", "0002"),
    "tok_sim_attente": ("attente", "CB", "3155"),
}


def _luhn_ok(digits: str) -> bool:
    total, alt = 0, False
    for d in reversed(digits):
        n = int(d)
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        total += n
        alt = not alt
    return total % 10 == 0


def reject_card_data(*values) -> None:
    """Refuse toute valeur ressemblant à un numéro de carte (13 à 19 chiffres valides Luhn)."""
    for v in values:
        if v is None:
            continue
        s = re.sub(r"[ \-]", "", str(v))
        for m in re.findall(r"\d{13,19}", s):
            if _luhn_ok(m):
                raise DomainError("DONNEES_CARTE_INTERDITES",
                                  "Les numéros de carte ne doivent jamais être saisis ni transmis à l'application")


def paid_cents(db: Session, target_type: str, target_id: int) -> int:
    cap = db.scalar(select(func.coalesce(func.sum(Payment.captured_cents), 0)).where(
        Payment.target_type == target_type, Payment.target_id == target_id)) or 0
    ref = db.scalar(select(func.coalesce(func.sum(Refund.amount_cents), 0)).join(Payment).where(
        Payment.target_type == target_type, Payment.target_id == target_id, Refund.status == "REMBOURSE")) or 0
    return int(cap) - int(ref)


def pending_cents(db: Session, target_type: str, target_id: int) -> int:
    return int(db.scalar(select(func.coalesce(func.sum(Payment.amount_cents), 0)).where(
        Payment.target_type == target_type, Payment.target_id == target_id,
        Payment.status.in_(("EN_ATTENTE", "AUTORISE")))) or 0)


def create_payment(db: Session, *, target_type: str, target_id: int, method: str, amount_cents: int,
                   idempotency_key: str, due_cents: int, actor_id: int | None, card_token: str | None = None,
                   cash_tendered_cents: int | None = None, session_id: int | None = None) -> Payment:
    reject_card_data(card_token, idempotency_key)
    if not idempotency_key or len(idempotency_key) < 8:
        raise DomainError("IDEMPOTENCE_REQUISE", "Une clé d'idempotence (≥ 8 caractères) est requise")
    existing = db.scalar(select(Payment).where(Payment.idempotency_key == idempotency_key))
    if existing:
        if (existing.target_type, existing.target_id, existing.amount_cents, existing.method) != \
                (target_type, target_id, amount_cents, method):
            raise Conflict("IDEMPOTENCE_CONFLIT", "Clé d'idempotence déjà utilisée pour un autre paiement")
        return existing
    if method not in METHODS:
        raise DomainError("MOYEN_INCONNU", f"Moyen de paiement inconnu : {method}")
    if amount_cents <= 0:
        raise DomainError("MONTANT_INVALIDE", "Montant de paiement invalide")
    outstanding = due_cents - paid_cents(db, target_type, target_id) - pending_cents(db, target_type, target_id)
    if amount_cents > outstanding:
        raise DomainError("TROP_PERCU", f"Le paiement dépasse le reste à payer ({outstanding} c)",
                          reste_a_payer=outstanding)
    p = Payment(target_type=target_type, target_id=target_id, method=method, amount_cents=amount_cents,
                idempotency_key=idempotency_key, created_by=actor_id, session_id=session_id)
    if method == "ESPECES":
        tendered = cash_tendered_cents if cash_tendered_cents is not None else amount_cents
        if tendered < amount_cents:
            raise DomainError("ESPECES_INSUFFISANTES", "Montant remis inférieur au montant encaissé")
        p.cash_tendered_cents, p.change_cents = tendered, tendered - amount_cents
        p.status, p.captured_cents, p.captured_at = "CAPTURE", amount_cents, utcnow()
    elif method in ("AVOIR", "VIREMENT_SIMULE"):
        p.status, p.captured_cents, p.captured_at = "CAPTURE", amount_cents, utcnow()
    db.flush()
    try:
        with db.begin_nested():  # le point de sauvegarde précède l'insertion
            db.add(p)
            db.flush()
    except IntegrityError:
        # course entre deux requêtes portant la même clé : on renvoie le paiement gagnant
        db.expire_all()
        winner = db.scalar(select(Payment).where(Payment.idempotency_key == idempotency_key))
        if winner:
            return winner
        raise
    if method == "CARTE_SIMULEE":
        p.provider_ref = "simpay_" + uuid.uuid4().hex[:20]
        db.flush()
        simulate_terminal(db, p, card_token or "tok_sim_accepte")
    audit(db, actor_id, "paiement.creation", "payment", p.id, f"Paiement {METHODS[method]} {amount_cents} c")
    notify(db, "paiement", {"id": p.id, "statut": p.status, "cible": target_type, "cible_id": target_id})
    return p


# --- Prestataire simulé ------------------------------------------------------------------------------------
def sign_event(body: bytes, ts: int | None = None, secret: str | None = None) -> str:
    ts = ts or int(time.time())
    secret = secret or get_settings().psp_webhook_secret
    mac = hmac.new(secret.encode(), f"{ts}.".encode() + body, hashlib.sha256).hexdigest()
    return f"t={ts},v1={mac}"


def build_event(event_type: str, provider_ref: str, amount_cents: int, extra: dict | None = None) -> bytes:
    return json.dumps({"id": "evt_" + uuid.uuid4().hex[:24], "type": event_type, "provider_ref": provider_ref,
                       "amount_cents": amount_cents, "created": int(time.time()), **(extra or {})}).encode()


def simulate_terminal(db: Session, p: Payment, token: str) -> None:
    """Le terminal simulé émet des événements signés, traités par le même code que les webhooks HTTP."""
    behaviour, brand, last4 = SIM_TOKENS.get(token, ("refuse", None, None))
    p.card_brand, p.card_last4 = brand, last4
    if behaviour == "attente":
        return  # aucun événement : le paiement reste en attente (cas d'une réponse tardive)
    if behaviour == "refuse":
        body = build_event("payment.failed", p.provider_ref, p.amount_cents, {"reason": "refus_emetteur_simule"})
        handle_webhook(db, body, sign_event(body))
        return
    for t in ("payment.authorized", "payment.captured"):
        body = build_event(t, p.provider_ref, p.amount_cents)
        handle_webhook(db, body, sign_event(body))


def verify_signature(body: bytes, header: str | None, tolerance_s: int = 300) -> bool:
    if not header:
        return False
    try:
        parts = dict(kv.split("=", 1) for kv in header.split(","))
        ts, sig = int(parts["t"]), parts["v1"]
    except Exception:
        return False
    if abs(time.time() - ts) > tolerance_s:
        return False
    expected = hmac.new(get_settings().psp_webhook_secret.encode(), f"{ts}.".encode() + body,
                        hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)


def handle_webhook(db: Session, body: bytes, signature_header: str | None) -> dict:
    valid = verify_signature(body, signature_header)
    try:
        payload = json.loads(body)
        event_id = str(payload["id"])
    except Exception:
        raise DomainError("EVENEMENT_ILLISIBLE", "Événement de paiement illisible", 400)
    if not valid:
        # Journalisé pour l'investigation, jamais appliqué.
        db.add(PaymentEvent(provider_event_id="invalide-" + uuid.uuid4().hex[:12], event_type=str(payload.get("type")),
                            payload=payload, signature_valid=False, applied=False, note="signature invalide"))
        db.flush()
        raise DomainError("SIGNATURE_INVALIDE", "Signature de l'événement de paiement invalide", 400)
    if db.scalar(select(PaymentEvent).where(PaymentEvent.provider_event_id == event_id)):
        return {"statut": "deja_traite", "evenement": event_id}
    ev = PaymentEvent(provider_event_id=event_id, event_type=payload["type"], payload=payload, signature_valid=True)
    db.flush()
    try:
        with db.begin_nested():  # le point de sauvegarde précède l'insertion
            db.add(ev)
            db.flush()
    except IntegrityError:
        return {"statut": "deja_traite", "evenement": event_id}
    t = payload["type"]
    if t.startswith("payment."):
        p = db.scalar(select(Payment).where(Payment.provider_ref == payload["provider_ref"]).with_for_update())
        if p is None:
            ev.note = "paiement inconnu"
            return {"statut": "ignore", "raison": ev.note}
        ev.payment_id = p.id
        if int(payload.get("amount_cents", -1)) != p.amount_cents:
            ev.note = "montant différent du paiement : non appliqué"
            return {"statut": "anomalie", "raison": ev.note}
        if t == "payment.authorized" and p.status == "EN_ATTENTE":
            p.status, p.authorized_at = "AUTORISE", utcnow()
        elif t == "payment.captured" and p.status in ("EN_ATTENTE", "AUTORISE"):
            p.status, p.captured_cents, p.captured_at = "CAPTURE", p.amount_cents, utcnow()
        elif t == "payment.failed" and p.status in ("EN_ATTENTE", "AUTORISE"):
            p.status, p.failure_reason = "ECHOUE", payload.get("reason", "refus")
        else:
            ev.note = f"transition ignorée depuis l'état {p.status}"
            return {"statut": "ignore", "raison": ev.note}
        ev.applied = True
        notify(db, "paiement", {"id": p.id, "statut": p.status})
    elif t == "refund.succeeded":
        r = db.scalar(select(Refund).where(Refund.provider_ref == payload["provider_ref"]).with_for_update())
        if r is None or r.status != "EN_ATTENTE":
            ev.note = "remboursement inconnu ou déjà traité"
            return {"statut": "ignore"}
        ev.refund_id = r.id
        r.status, r.completed_at = "REMBOURSE", utcnow()
        ev.applied = True
    return {"statut": "applique", "evenement": event_id}


def refund(db: Session, payment: Payment, amount_cents: int, reason: str, idempotency_key: str,
           actor_id: int | None, return_id: int | None = None, session_id: int | None = None) -> Refund:
    existing = db.scalar(select(Refund).where(Refund.idempotency_key == idempotency_key))
    if existing:
        if existing.payment_id != payment.id or existing.amount_cents != amount_cents:
            raise Conflict("IDEMPOTENCE_CONFLIT", "Clé déjà utilisée pour un autre remboursement")
        return existing
    if payment.status != "CAPTURE":
        raise DomainError("NON_CAPTURE", "Seul un paiement capturé peut être remboursé")
    already = db.scalar(select(func.coalesce(func.sum(Refund.amount_cents), 0)).where(
        Refund.payment_id == payment.id, Refund.status.in_(("EN_ATTENTE", "REMBOURSE")))) or 0
    if amount_cents <= 0 or amount_cents + already > payment.captured_cents:
        raise DomainError("REMBOURSEMENT_EXCESSIF",
                          f"Remboursement supérieur au montant capturé restant ({payment.captured_cents - already} c)")
    r = Refund(payment_id=payment.id, amount_cents=amount_cents, reason=reason, idempotency_key=idempotency_key,
               created_by=actor_id, return_id=return_id, session_id=session_id)
    db.add(r)
    db.flush()
    if payment.method == "CARTE_SIMULEE":
        r.provider_ref = "simref_" + uuid.uuid4().hex[:20]
        db.flush()
        body = build_event("refund.succeeded", r.provider_ref, amount_cents)
        handle_webhook(db, body, sign_event(body))
    else:
        r.status, r.completed_at = "REMBOURSE", utcnow()
    audit(db, actor_id, "paiement.remboursement", "refund", r.id, f"Remboursement {amount_cents} c : {reason}")
    return r


def payments_for(db: Session, target_type: str, target_id: int) -> list[Payment]:
    return list(db.scalars(select(Payment).where(Payment.target_type == target_type, Payment.target_id == target_id)
                           .order_by(Payment.id)))


def get_payment(db: Session, pid: int) -> Payment:
    p = db.get(Payment, pid)
    if not p:
        raise NotFound("Paiement", pid)
    return p
