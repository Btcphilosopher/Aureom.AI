"""Paiements (simulés), événements du prestataire vérifiés, remboursements.

Aucune donnée brute de carte n'est stockée : seulement une référence du prestataire simulé,
la marque et les 4 derniers chiffres fournis par le terminal."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, CheckConstraint, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.types import created_at, pk, ts
from app.db import Base


class Payment(Base):
    __tablename__ = "payments"
    __table_args__ = (CheckConstraint("amount_cents > 0", name="positif"),)
    id: Mapped[int] = pk()
    target_type: Mapped[str] = mapped_column(String(10))  # VENTE, COMMANDE
    target_id: Mapped[int] = mapped_column(BigInteger, index=True)
    method: Mapped[str] = mapped_column(String(20))  # CARTE_SIMULEE, ESPECES, AVOIR, VIREMENT_SIMULE
    amount_cents: Mapped[int] = mapped_column(BigInteger)
    status: Mapped[str] = mapped_column(String(15), default="EN_ATTENTE")  # EN_ATTENTE, AUTORISE, CAPTURE, ECHOUE, ANNULE
    provider: Mapped[str] = mapped_column(String(20), default="SIMULATEUR")
    provider_ref: Mapped[str | None] = mapped_column(String(60), unique=True)
    card_brand: Mapped[str | None] = mapped_column(String(20))
    card_last4: Mapped[str | None] = mapped_column(String(4))
    cash_tendered_cents: Mapped[int | None] = mapped_column(BigInteger)
    change_cents: Mapped[int | None] = mapped_column(BigInteger)
    captured_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True)
    session_id: Mapped[int | None] = mapped_column(ForeignKey("pos_sessions.id"))
    failure_reason: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    authorized_at: Mapped[datetime | None] = ts()
    captured_at: Mapped[datetime | None] = ts()


class PaymentEvent(Base):
    """Événement reçu du prestataire. Enregistré une seule fois (provider_event_id unique) et appliqué
    uniquement si sa signature HMAC est valide."""

    __tablename__ = "payment_events"
    id: Mapped[int] = pk()
    provider_event_id: Mapped[str] = mapped_column(String(60), unique=True)
    event_type: Mapped[str] = mapped_column(String(40))
    payment_id: Mapped[int | None] = mapped_column(ForeignKey("payments.id"))
    refund_id: Mapped[int | None] = mapped_column(ForeignKey("refunds.id"))
    payload: Mapped[dict] = mapped_column(JSONB)
    signature_valid: Mapped[bool] = mapped_column(Boolean)
    applied: Mapped[bool] = mapped_column(Boolean, default=False)
    note: Mapped[str | None] = mapped_column(Text)
    received_at: Mapped[datetime] = created_at()


class Refund(Base):
    __tablename__ = "refunds"
    __table_args__ = (CheckConstraint("amount_cents > 0", name="positif"),)
    id: Mapped[int] = pk()
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id"))
    amount_cents: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(15), default="EN_ATTENTE")  # EN_ATTENTE, REMBOURSE, ECHOUE
    provider_ref: Mapped[str | None] = mapped_column(String(60), unique=True)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True)
    return_id: Mapped[int | None] = mapped_column(BigInteger)
    session_id: Mapped[int | None] = mapped_column(ForeignKey("pos_sessions.id"))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = created_at()
    completed_at: Mapped[datetime | None] = ts()
