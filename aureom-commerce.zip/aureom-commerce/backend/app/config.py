"""Configuration d'AUREOM COMMERCE (variables d'environnement, préfixe AUREOM_)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AUREOM_", env_file=".env", extra="ignore")

    app_name: str = "AUREOM COMMERCE"
    environment: str = "developpement"
    database_url: str = "postgresql+psycopg://aureom:aureom@localhost:5432/aureom"
    timezone: str = "Europe/Paris"
    cors_origins: str = "http://localhost:5173,http://localhost:8080"
    token_ttl_hours: int = 12

    # Organisation exploitante (identité sur le registre partagé)
    org_msp_id: str = "MaisonMarcheMSP"

    # Registre partagé : "fabric" (passerelle Hyperledger Fabric) ou "simulation"
    # (registre local de démonstration, explicitement NON distribué).
    ledger_mode: str = "simulation"
    ledger_gateway_url: str = "http://localhost:8800"
    ledger_gateway_token: str = ""
    ledger_timeout_s: float = 90.0
    ledger_max_attempts: int = 12
    # Mode simulation uniquement : base distincte pour le registre simulé (vide = même base)
    simulation_ledger_url: str = ""

    # Clé de signature applicative (Ed25519). Fichier hors dépôt, monté en secret.
    signing_key_path: str = "./secrets/maisonmarche-signing.key"
    signing_key_id: str = "maisonmarche-2026-01"

    # Stockage objet protégé : "local" (répertoire hors racine web) ou "s3"
    storage_backend: str = "local"
    storage_dir: str = "./var/objets"
    s3_endpoint: str = ""
    s3_bucket: str = "aureom-documents"
    s3_access_key: str = ""
    s3_secret_key: str = ""

    # Prestataire de paiement SIMULÉ : secret de signature des événements (webhooks)
    psp_webhook_secret: str = "demo-psp-secret-a-remplacer"

    # MQTT (télémétrie en lecture seule)
    mqtt_host: str = "localhost"
    mqtt_port: int = 1883
    mqtt_username: str = "aureom-bridge"
    mqtt_password: str = ""
    mqtt_topic_root: str = "aureom"

    # Fenêtre de déduplication des lectures RFID (secondes)
    rfid_dedup_window_s: int = 30

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir).resolve()


@lru_cache
def get_settings() -> Settings:
    return Settings()
