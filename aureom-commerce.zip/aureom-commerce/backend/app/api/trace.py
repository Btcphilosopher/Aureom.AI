"""Traçabilité, registre partagé, clés, rapports."""
from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, perm
from app.config import get_settings
from app.core.common import audit
from app.core.errors import DomainError
from app.core.serialize import deep, row, rows
from app.core.types import utcnow
from app.modules.inventory.models import Lot
from app.modules.ledger.adapters import LedgerError, get_ledger
from app.modules.traceability import keys, report
from app.modules.traceability import service as trace
from app.modules.traceability.models import (EVENT_TYPES, IndependentVerification, LedgerOutbox, ReconciliationRun,
                                             SigningKey, TraceEvent)

router = APIRouter(prefix="/api/tracabilite", tags=["Traçabilité et registre"])


def event_view(db: Session, e: TraceEvent, full: bool = False) -> dict:
    d = row(e, exclude={"details"} if not full else None)
    d["type_libelle"] = EVENT_TYPES.get(e.event_type, e.event_type)
    d["niveaux_de_preuve"] = trace.proof_levels(db, e)
    ob = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == e.id))
    d["publication"] = row(ob)
    if full:
        d["verifications"] = rows(db.scalars(select(IndependentVerification).where(
            IndependentVerification.trace_event_id == e.id)))
    return d


@router.get("/limites", summary="Ce que prouvent (et ne prouvent pas) signature, empreinte et registre")
def limits():
    return {"limites": report.LIMITS, "niveaux": {"DECLARE": "Déclaré", "SIGNE": "Signé",
                                                  "CONFIRME_REGISTRE": "Confirmé sur le registre",
                                                  "VERIFIE_INDEPENDAMMENT": "Vérifié par contrôle indépendant"},
            "methodes_verification": trace.VERIFICATION_METHODS}


@router.get("/evenements")
def events(ledger_status: str | None = None, lot_id: int | None = None, limit: int = 200,
           user: CurrentUser = perm("trace.read"), db: Session = DB):
    q = select(TraceEvent).order_by(TraceEvent.declared_at.desc()).limit(min(limit, 500))
    if ledger_status:
        q = q.where(TraceEvent.ledger_status == ledger_status)
    if lot_id:
        q = q.where(TraceEvent.lot_id == lot_id)
    return [event_view(db, e) for e in db.scalars(q)]


@router.get("/evenements/{eid}")
def event(eid: str, user: CurrentUser = perm("trace.read"), db: Session = DB):
    return event_view(db, get_or_404(db, TraceEvent, eid, "Événement"), full=True)


class DeclareIn(BaseModel):
    event_type: str
    lot_id: int
    occurred_at: datetime | None = None
    previous_event_id: str | None = None
    corrects_event_id: str | None = None
    counterparty_org: str | None = None
    location_ref: str | None = None
    details: dict = {}
    evidence: list[dict] = []


@router.post("/evenements", summary="Déclarer un événement (transformation, correction liée, contestation…)")
def declare(body: DeclareIn, user: CurrentUser = perm("trace.write"), db: Session = DB):
    lot = get_or_404(db, Lot, body.lot_id, "Lot")
    e = trace.declare_event(db, event_type=body.event_type, occurred_at=body.occurred_at or utcnow(), actor_id=user.id,
                            lot=lot, previous_event_id=body.previous_event_id, corrects_event_id=body.corrects_event_id,
                            counterparty_org=body.counterparty_org, location_ref=body.location_ref,
                            details=body.details, evidence=body.evidence, source_type="MANUEL")
    db.commit()
    return event_view(db, e, True)


class VerificationIn(BaseModel):
    method: str
    verifier_name: str
    verifier_org: str
    result: str
    performed_at: datetime
    notes: str = ""
    evidence_object_id: int | None = None


@router.post("/evenements/{eid}/verifications", summary="Enregistrer un contrôle indépendant")
def verify(eid: str, body: VerificationIn, user: CurrentUser = perm("trace.verify"), db: Session = DB):
    v = trace.record_verification(db, eid, actor_id=user.id, **body.model_dump())
    db.commit()
    return row(v)


@router.post("/evenements/{eid}/relancer")
def retry(eid: str, user: CurrentUser = perm("ledger.admin"), db: Session = DB):
    trace.retry_event(db, eid, user.id)
    db.commit()
    return {"relance": True}


@router.get("/registre/etat")
def ledger_state(user: CurrentUser = perm("trace.read"), db: Session = DB):
    lg = get_ledger()
    health = lg.health()
    st = None
    if health.get("disponible"):
        try:
            st = lg.status()
        except LedgerError as e:
            st = {"erreur": e.message}
    counts = dict(db.execute(select(LedgerOutbox.status, func.count()).group_by(LedgerOutbox.status)).all())
    last = db.scalar(select(ReconciliationRun).order_by(ReconciliationRun.id.desc()).limit(1))
    return {"mode": lg.name, "distribue": lg.distributed, "libelle": lg.label, "sante": health, "statut": st,
            "boite_envoi": counts, "derniere_reconciliation": row(last),
            "operations_en_cas_d_indisponibilite": {
                "continuent": ["ventes en caisse", "réceptions", "transferts internes", "commandes", "retours",
                               "blocages de rappel (stock bloqué localement immédiatement)"],
                "restent_provisoires": ["événements partagés : déclarés et signés, en attente de confirmation",
                                        "transferts de garde interentreprises : provisoires jusqu'à confirmation "
                                        "de la contrepartie"],
                "bloquees": ["aucune opération physique n'est bloquée par le registre ; seule l'affirmation "
                             "« confirmé sur le registre » est retardée"]}}


@router.post("/registre/publier", summary="Traiter la boîte d'envoi maintenant")
def publish(user: CurrentUser = perm("ledger.admin")):
    return trace.process_outbox(limit=100)


@router.post("/registre/reconcilier")
def reconcile(user: CurrentUser = perm("ledger.admin")):
    return deep(trace.reconcile())


@router.get("/registre/reconciliations")
def reconciliations(user: CurrentUser = perm("trace.read"), db: Session = DB):
    return rows(db.scalars(select(ReconciliationRun).order_by(ReconciliationRun.id.desc()).limit(50)))


@router.get("/cles")
def signing_keys(user: CurrentUser = perm("trace.read"), db: Session = DB):
    return {"cles": rows(db.scalars(select(SigningKey))), "conservation": "Clé privée dans un secret monté (fichier "
            "0600 hors dépôt) ; jamais exposée par l'API ni au navigateur. Production : KMS / HSM."}


@router.post("/cles/enregistrer", summary="Publier la clé publique de l'organisation sur le registre")
def register_key(user: CurrentUser = perm("ledger.admin"), db: Session = DB):
    k = trace.register_own_key(db)
    db.commit()
    return row(k)


@router.post("/cles/rotation", summary="Rotation : nouvelle clé active, ancienne retirée (signatures passées valides)")
def rotate(user: CurrentUser = perm("ledger.admin"), db: Session = DB):
    s = get_settings()
    if s.environment == "production":
        raise DomainError("ROTATION_HORS_LIGNE", "En production, la rotation se fait dans le KMS/HSM (procédure "
                                                 "docs/gouvernance.md)")
    old = keys.get_signer()
    new_id = f"{s.org_msp_id.lower().replace('msp', '')}-{utcnow():%Y%m%d%H%M%S}"
    path = f"{s.signing_key_path}.{new_id}"
    new = keys.FileKeyProvider(path, new_id, create_if_missing=True)
    lg = get_ledger()
    now = utcnow()
    lg.register_key(new_id, new.public_key_b64(), now - timedelta(seconds=5))
    db.add(SigningKey(key_id=new_id, org_msp=s.org_msp_id, public_key_b64=new.public_key_b64(),
                      valid_from=now - timedelta(seconds=5), ledger_registered=True))
    lg.retire_key(old.key_id, now)
    ok = db.get(SigningKey, old.key_id)
    if ok:
        ok.status, ok.retired_at = "RETIREE", now
    keys.set_signer(new)
    audit(db, user.id, "cle.rotation", "signing_key", new_id, f"Rotation {old.key_id} → {new_id}")
    db.commit()
    return {"ancienne": old.key_id, "nouvelle": new_id,
            "note": "Mettre à jour AUREOM_SIGNING_KEY_PATH / AUREOM_SIGNING_KEY_ID pour les redémarrages."}


class RevokeIn(BaseModel):
    reason: str
    revoked_at: datetime | None = None


@router.post("/cles/{key_id}/revocation", summary="Révocation (compromission) — les événements postérieurs sont rejetés")
def revoke(key_id: str, body: RevokeIn, user: CurrentUser = perm("ledger.admin"), db: Session = DB):
    k = get_or_404(db, SigningKey, key_id, "Clé")
    at = body.revoked_at or utcnow()
    get_ledger().revoke_key(key_id, at, body.reason)
    k.status, k.revoked_at, k.revocation_reason = "REVOQUEE", at, body.reason
    n = db.scalar(select(func.count()).select_from(TraceEvent).where(TraceEvent.signer_key_id == key_id))
    audit(db, user.id, "cle.revocation", "signing_key", key_id, body.reason)
    db.commit()
    return {"revoquee": key_id, "evenements_signes_avec_cette_cle": n,
            "note": "Les événements antérieurs restent inscrits ; à revoir au cas par cas, la date réelle de "
                    "compromission pouvant précéder la révocation."}


@router.get("/lots/{lot_id}/rapport", summary="Export du rapport de traçabilité (json, html, csv)")
def lot_report(lot_id: int, format: str = "json", user: CurrentUser = perm("trace.read"), db: Session = DB):
    r = report.build(db, lot_id)
    if format == "html":
        return HTMLResponse(report.to_html(r))
    if format == "csv":
        return PlainTextResponse(report.to_csv(r), media_type="text/csv; charset=utf-8",
                                 headers={"Content-Disposition": f'attachment; filename="tracabilite-lot-{lot_id}.csv"'})
    return deep(r)
