"""Stocks multisites, mouvements, transferts, inventaires, lots."""
from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, perm
from app.core.common import audit
from app.core.errors import DomainError, NotFound
from app.core.serialize import deep, row, rows
from app.modules.admin.models import Location, Site
from app.modules.catalog.models import Variant
from app.modules.inventory import service as inv
from app.modules.inventory.models import (MOVEMENT_TYPES, QUALITY_LABELS, InventoryCount, Lot, StockBalance,
                                          StockException, StockMovement, StockPosition, Transfer)

router = APIRouter(prefix="/api/stocks", tags=["Stocks"])


@router.get("/references")
def refs(user: CurrentUser = perm("stock.read")):
    return {"types_mouvement": MOVEMENT_TYPES, "etats_qualite": QUALITY_LABELS,
            "definitions": {"physique": "Quantité présente, tous états qualité confondus",
                            "vendable": "État « disponible » dans un emplacement vendable",
                            "reserve": "Réservations actives des commandes",
                            "disponible": "Vendable − réservé (peut être négatif après un blocage)",
                            "attendu": "Reliquats de commandes fournisseurs + transferts en transit"}}


@router.get("/positions")
def positions(site_id: int | None = None, user: CurrentUser = perm("stock.read"), db: Session = DB):
    user.check_site(site_id)
    q = select(StockPosition, Variant).join(Variant)
    if site_id:
        q = q.where(StockPosition.site_id == site_id)
    out = []
    for p, v in db.execute(q.order_by(Variant.sku, StockPosition.site_id)):
        d = deep(inv.position(db, p.variant_id, p.site_id))
        d.update({"variant_id": v.id, "sku": v.sku, "libelle": v.label, "unite": v.product.base_unit,
                  "site_id": p.site_id})
        out.append(d)
    return out


@router.get("/soldes")
def balances(variant_id: int | None = None, site_id: int | None = None, lot_id: int | None = None,
             user: CurrentUser = perm("stock.read"), db: Session = DB):
    q = select(StockBalance, Location, Lot).join(Location, Location.id == StockBalance.location_id).outerjoin(
        Lot, Lot.id == StockBalance.lot_id).where(StockBalance.quantity > 0)
    if variant_id:
        q = q.where(StockBalance.variant_id == variant_id)
    if site_id:
        q = q.where(StockBalance.site_id == site_id)
    if lot_id:
        q = q.where(StockBalance.lot_id == lot_id)
    return [row(b) | {"emplacement": loc.code, "type_emplacement": loc.kind, "lot": lot.lot_code if lot else None,
                      "peremption": lot.expires_on.isoformat() if lot and lot.expires_on else None,
                      "etat_libelle": QUALITY_LABELS[b.quality_state]} for b, loc, lot in db.execute(q)]


@router.get("/mouvements")
def movements(variant_id: int | None = None, site_id: int | None = None, lot_id: int | None = None,
              document_ref: str | None = None, limit: int = 200, user: CurrentUser = perm("stock.read"),
              db: Session = DB):
    q = select(StockMovement).order_by(StockMovement.id.desc()).limit(min(limit, 1000))
    for col, v in ((StockMovement.variant_id, variant_id), (StockMovement.site_id, site_id),
                   (StockMovement.lot_id, lot_id), (StockMovement.document_ref, document_ref)):
        if v:
            q = q.where(col == v)
    return [row(m) | {"type_libelle": MOVEMENT_TYPES.get(m.movement_type)} for m in db.scalars(q)]


class CorrectionIn(BaseModel):
    corrected_quantity: Decimal
    reason: str


@router.post("/mouvements/{movement_id}/correction", summary="Correction liée et attribuée (l'original reste)")
def correct(movement_id: int, body: CorrectionIn, user: CurrentUser = perm("stock.correct"), db: Session = DB):
    ms = inv.correct_movement(db, movement_id, body.corrected_quantity, body.reason, user.id)
    audit(db, user.id, "stock.correction", "stock_movement", movement_id, body.reason)
    db.commit()
    return rows(ms)


class QualityIn(BaseModel):
    variant_id: int
    location_id: int
    lot_id: int | None = None
    from_state: str
    to_state: str
    quantity: Decimal
    to_location_id: int | None = None
    reason: str


@router.post("/etat-qualite", summary="Quarantaine, levée, changement d'état")
def quality(body: QualityIn, user: CurrentUser = perm("quality.inspect"), db: Session = DB):
    mtype = "MISE_EN_QUARANTAINE" if body.to_state in ("QUARANTAINE", "BLOQUE") else \
        "LEVEE_QUARANTAINE" if body.to_state == "DISPONIBLE" else "CHANGEMENT_ETAT"
    if body.from_state == "BLOQUE":
        lot = db.get(Lot, body.lot_id) if body.lot_id else None
        if lot and lot.status == "RAPPELE":
            raise DomainError("LOT_RAPPELE", "Un lot rappelé ne peut pas être débloqué ici : clôturez le rappel")
    ms = inv.change_quality(db, variant_id=body.variant_id, from_location_id=body.location_id, lot_id=body.lot_id,
                            from_state=body.from_state, to_state=body.to_state, qty=body.quantity, actor_id=user.id,
                            movement_type=mtype, to_location_id=body.to_location_id, reason=body.reason)
    db.commit()
    return rows(ms)


class LossIn(BaseModel):
    variant_id: int
    location_id: int
    lot_id: int | None = None
    quality_state: str = "DISPONIBLE"
    quantity: Decimal
    reason: str


@router.post("/pertes")
def loss(body: LossIn, user: CurrentUser = perm("stock.move"), db: Session = DB):
    if len(body.reason) < 5:
        raise DomainError("MOTIF_REQUIS", "Motif de perte requis")
    ms = inv.post_movements(db, "PERTE", [inv.MoveLine(body.variant_id, body.location_id, -body.quantity,
                                                       body.quality_state, body.lot_id)],
                            actor_id=user.id, reason=body.reason)
    db.commit()
    return rows(ms)


class TransferLineIn(BaseModel):
    variant_id: int
    quantity: Decimal
    lot_id: int | None = None
    from_location_id: int | None = None


class TransferIn(BaseModel):
    from_site_id: int
    to_site_id: int
    lines: list[TransferLineIn]


@router.post("/transferts")
def create_transfer(body: TransferIn, user: CurrentUser = perm("stock.transfer"), db: Session = DB):
    user.check_site(body.from_site_id)
    t = inv.create_transfer(db, body.from_site_id, body.to_site_id, [l.model_dump() for l in body.lines], user.id)
    db.commit()
    return row(t, "lines")


@router.get("/transferts")
def transfers(user: CurrentUser = perm("stock.read"), db: Session = DB):
    return [row(t, "lines") for t in db.scalars(select(Transfer).order_by(Transfer.id.desc()).limit(100))]


@router.post("/transferts/{tid}/expedier")
def ship_transfer(tid: int, user: CurrentUser = perm("stock.transfer"), db: Session = DB):
    t = get_or_404(db, Transfer, tid, "Transfert")
    inv.ship_transfer(db, t, user.id)
    db.commit()
    return row(t, "lines")


@router.post("/transferts/{tid}/annuler")
def cancel_transfer(tid: int, user: CurrentUser = perm("stock.transfer"), db: Session = DB):
    t = get_or_404(db, Transfer, tid, "Transfert")
    inv.cancel_transfer(db, t)
    db.commit()
    return row(t, "lines")


class ReceiveTransferIn(BaseModel):
    received: dict[int, Decimal] | None = None
    to_location_id: int | None = None


@router.post("/transferts/{tid}/recevoir")
def receive_transfer(tid: int, body: ReceiveTransferIn, user: CurrentUser = perm("stock.transfer"), db: Session = DB):
    t = get_or_404(db, Transfer, tid, "Transfert")
    user.check_site(t.to_site_id)
    inv.receive_transfer(db, t, body.received, user.id, body.to_location_id)
    db.commit()
    return row(t, "lines")


class CountIn(BaseModel):
    site_id: int
    location_id: int | None = None


@router.post("/inventaires")
def start_count(body: CountIn, user: CurrentUser = perm("stock.move"), db: Session = DB):
    c = inv.start_count(db, body.site_id, body.location_id, user.id)
    db.commit()
    return row(c, "lines")


class CountValidateIn(BaseModel):
    counts: dict[int, Decimal]


@router.post("/inventaires/{cid}/valider")
def validate_count(cid: int, body: CountValidateIn, user: CurrentUser = perm("stock.correct"), db: Session = DB):
    c = get_or_404(db, InventoryCount, cid, "Inventaire")
    v = inv.validate_count(db, c, body.counts, user.id)
    db.commit()
    return {"inventaire": row(c, "lines"), "ecarts": deep(v)}


@router.get("/lots")
def lots(variant_id: int | None = None, user: CurrentUser = perm("stock.read"), db: Session = DB):
    q = select(Lot).order_by(Lot.id.desc())
    if variant_id:
        q = q.where(Lot.variant_id == variant_id)
    out = []
    for l in db.scalars(q.limit(300)):
        v = db.get(Variant, l.variant_id)
        out.append(row(l) | {"sku": v.sku, "libelle": v.label})
    return out


@router.get("/exceptions")
def exceptions(user: CurrentUser = perm("stock.read"), db: Session = DB):
    return rows(db.scalars(select(StockException).order_by(StockException.id.desc()).limit(200)))


class ResolveIn(BaseModel):
    note: str


@router.post("/exceptions/{eid}/resoudre")
def resolve_exception(eid: int, body: ResolveIn, user: CurrentUser = perm("stock.correct"), db: Session = DB):
    from app.core.types import utcnow

    e = get_or_404(db, StockException, eid, "Exception")
    e.status, e.resolved_by, e.resolved_at = "RESOLUE", user.id, utcnow()
    audit(db, user.id, "stock.exception", "stock_exception", eid, body.note)
    db.commit()
    return row(e)


@router.get("/sites/{site_id}/emplacements")
def locations(site_id: int, user: CurrentUser = perm("stock.read"), db: Session = DB):
    if not db.get(Site, site_id):
        raise NotFound("Site", site_id)
    return rows(db.scalars(select(Location).where(Location.site_id == site_id)))


@router.get("/controle-coherence", summary="Contrôle d'intégrité soldes / journal / réservations")
def consistency(user: CurrentUser = perm("stock.correct"), db: Session = DB):
    return inv.check_consistency(db)
