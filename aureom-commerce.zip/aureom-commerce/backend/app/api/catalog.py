"""Catalogue et tarification."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, File, Form, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, perm
from app.core import storage
from app.core.errors import NotFound
from app.core.money import format_eur
from app.core.serialize import row, rows
from app.core.units import PACKAGING_LABELS, UNITS, base_to_packs, convert, format_qty, packs_to_base
from app.modules.catalog import service as cat
from app.modules.catalog.models import (Barcode, Price, PriceList, Product, ProductDocument, ProductFamily, ProductSupplier,
                                        TaxRegime, Variant)
from app.modules.inventory import service as inv

router = APIRouter(prefix="/api/catalogue", tags=["Catalogue"])


@router.get("/unites")
def units(user: CurrentUser = perm("catalog.read")):
    return {"unites": [{"code": u.code, "libelle": u.label, "dimension": u.dimension, "entier": u.integer_only}
                       for u in UNITS.values()], "conditionnements": PACKAGING_LABELS}


@router.get("/conversion")
def conversion(valeur: Decimal, de: str, vers: str, user: CurrentUser = perm("catalog.read")):
    r = convert(valeur, de, vers)
    return {"resultat": str(r), "affichage": format_qty(r, vers)}


@router.get("/familles")
def families(user: CurrentUser = perm("catalog.read"), db: Session = DB):
    return rows(db.scalars(select(ProductFamily).order_by(ProductFamily.code)))


@router.get("/taxes")
def taxes(user: CurrentUser = perm("catalog.read"), db: Session = DB):
    return [row(t, "rates") for t in db.scalars(select(TaxRegime))]


@router.get("/listes-prix")
def price_lists(user: CurrentUser = perm("catalog.read"), db: Session = DB):
    return rows(db.scalars(select(PriceList)))


def variant_view(db: Session, v: Variant, site_id: int | None = None) -> dict:
    d = row(v)
    d["conditionnements"] = rows(v.packagings)
    d["codes_barres"] = rows(db.scalars(select(Barcode).where(Barcode.variant_id == v.id)))
    prices = {}
    for pl in db.scalars(select(PriceList)):
        try:
            p, _ = cat.price_at(db, pl.code, v.id)
            prices[pl.code] = {"montant": p.amount_cents, "affichage": format_eur(p.amount_cents),
                               "ttc": pl.tax_inclusive, "promotion": p.is_promotion, "depuis": p.valid_from.isoformat()}
            if p.is_promotion:
                ref = cat.reference_price(db, pl.code, v.id, p.valid_from)
                prices[pl.code]["prix_reference_30j"] = ref
        except Exception:
            prices[pl.code] = None
    d["prix"] = prices
    if site_id:
        d["stock"] = {k: (str(x) if isinstance(x, Decimal) else x) for k, x in inv.position(db, v.id, site_id).items()}
    return d


@router.get("/articles")
def products(q: str | None = None, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    stmt = select(Product).order_by(Product.code)
    if q:
        stmt = stmt.where(Product.name.ilike(f"%{q}%"))
    out = []
    for p in db.scalars(stmt):
        d = row(p)
        d["famille"] = db.get(ProductFamily, p.family_id).name
        d["variantes"] = [variant_view(db, v) for v in p.variants]
        out.append(d)
    return out


@router.get("/articles/{product_id}")
def product(product_id: int, site_id: int | None = None, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    p = db.get(Product, product_id)
    if not p:
        raise NotFound("Article", product_id)
    d = row(p)
    d["variantes"] = [variant_view(db, v, site_id) for v in p.variants]
    d["fournisseurs"] = rows(db.scalars(select(ProductSupplier).join(Variant).where(Variant.product_id == p.id)))
    d["documents"] = rows(db.scalars(select(ProductDocument).where(ProductDocument.product_id == p.id)))
    return d


class PackIn(BaseModel):
    level: str
    label: str | None = None
    qty_in_base: Decimal
    gtin: str | None = None


class VariantIn(BaseModel):
    sku: str
    label: str
    gtin: str | None = None
    attributes: dict = Field(default_factory=dict)
    packagings: list[PackIn] = Field(default_factory=list)


class ProductIn(BaseModel):
    code: str
    name: str
    description: str = ""
    brand: str | None = None
    family_code: str
    tax_regime_code: str
    base_unit: str = "PCE"
    lot_tracked: bool = False
    serial_tracked: bool = False
    expiry_kind: str | None = None
    variants: list[VariantIn]


@router.post("/articles", summary="Créer un article, ses variantes et conditionnements")
def create_product(body: ProductIn, user: CurrentUser = perm("catalog.write"), db: Session = DB):
    data = body.model_dump()
    for v in data["variants"]:
        v["packagings"] = [{k: x for k, x in pk.items() if x is not None} for pk in v["packagings"]]
    p = cat.create_product(db, data, user.id)
    db.commit()
    return product(p.id, None, user, db)


class PriceIn(BaseModel):
    price_list_code: str
    variant_id: int
    amount_cents: int
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    packaging_level: str = "PIECE"
    is_promotion: bool = False


@router.post("/prix", summary="Publier un prix daté (nouvelle ligne, historique conservé)")
def set_price(body: PriceIn, user: CurrentUser = perm("price.write"), db: Session = DB):
    p = cat.set_price(db, body.price_list_code, body.variant_id, body.amount_cents, body.valid_from, user.id,
                      body.packaging_level, body.is_promotion, body.valid_to)
    db.commit()
    return row(p)


@router.get("/prix/{variant_id}/historique")
def price_history(variant_id: int, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    q = select(Price, PriceList.code).join(PriceList).where(Price.variant_id == variant_id).order_by(
        PriceList.code, Price.valid_from)
    return [row(p) | {"liste": code, "affichage": format_eur(p.amount_cents)} for p, code in db.execute(q)]


@router.get("/recherche")
def search(q: str, site_id: int | None = None, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    return [variant_view(db, v, site_id) for v in cat.search(db, q)]


@router.get("/scan/{code}", summary="Résoudre un code-barres (pièce ou carton) ou un SKU")
def scan(code: str, site_id: int | None = None, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    v, pack = cat.lookup_code(db, code)
    d = variant_view(db, v, site_id)
    d["conditionnement_scanne"] = row(pack) if pack else None
    return d


@router.get("/conditionnements/{variant_id}/convertir")
def pack_convert(variant_id: int, quantite: Decimal, niveau: str, user: CurrentUser = perm("catalog.read"),
                 db: Session = DB):
    v = db.get(Variant, variant_id)
    pack = cat.packaging(db, variant_id, niveau)
    base = packs_to_base(quantite, pack.qty_in_base, v.product.base_unit)
    detail = []
    rest = base
    for p in sorted(v.packagings, key=lambda x: x.qty_in_base, reverse=True):
        n, rest = base_to_packs(rest, p.qty_in_base)
        if n:
            detail.append(f"{n} {p.label.lower()}")
    return {"unite_base": str(base), "affichage": format_qty(base, v.product.base_unit), "decomposition": detail}


@router.post("/articles/{product_id}/documents")
async def upload_doc(product_id: int, kind: str = Form(...), title: str = Form(...), file: UploadFile = File(...),
                     user: CurrentUser = perm("catalog.write"), db: Session = DB):
    data = await file.read()
    obj = storage.store(db, data, file.filename or "document", file.content_type or "application/pdf", user.id)
    d = ProductDocument(product_id=product_id, kind=kind, title=title, object_id=obj.id)
    db.add(d)
    db.commit()
    return row(d) | {"sha256": obj.sha256}


class SupplierLinkIn(BaseModel):
    variant_id: int
    supplier_id: int
    supplier_ref: str
    purchase_packaging_level: str = "CARTON"
    cost_cents_per_pack: int
    min_order_packs: int = 1
    lead_time_days: int = 5


@router.post("/fournisseurs", summary="Référencer un fournisseur pour une variante (conditionnement et coût d'achat HT)")
def link_supplier(body: SupplierLinkIn, user: CurrentUser = perm("catalog.write"), db: Session = DB):
    pack = cat.packaging(db, body.variant_id, body.purchase_packaging_level)
    ps = ProductSupplier(variant_id=body.variant_id, supplier_id=body.supplier_id, supplier_ref=body.supplier_ref,
                         purchase_packaging_id=pack.id, cost_cents_per_pack=body.cost_cents_per_pack,
                         min_order_packs=body.min_order_packs, lead_time_days=body.lead_time_days)
    db.add(ps)
    db.commit()
    return row(ps)
