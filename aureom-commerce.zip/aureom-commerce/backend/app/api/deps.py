from __future__ import annotations

from fastapi import Depends, Header
from sqlalchemy.orm import Session

from app.core.security import CurrentUser, current_user, require_perm
from app.db import get_db

DB = Depends(get_db)
User = Depends(current_user)


def perm(*p: str):
    return Depends(require_perm(*p))


def _idem_key(idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")) -> str | None:
    return idempotency_key


idem_key = Depends(_idem_key)


__all__ = ["DB", "User", "perm", "idem_key", "Session", "CurrentUser"]


def get_or_404(db: Session, model, ident, label: str):
    from app.core.errors import NotFound

    obj = db.get(model, ident)
    if obj is None:
        raise NotFound(label, ident)
    return obj
