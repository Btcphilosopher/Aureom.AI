"""Authentification, administration, organisations et sites."""
from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, User, perm
from app.core.common import audit, get_flag, set_flag
from app.core.errors import DomainError, NotFound
from app.core.security import PERMISSIONS, ROLE_PERMISSIONS, hash_password, issue_token, verify_password
from app.core.serialize import row, rows
from app.modules.admin.models import AuditLog, Location, Organisation, Role, Site, User as UserModel, UserRole

router = APIRouter(prefix="/api", tags=["Administration"])


class LoginIn(BaseModel):
    username: str
    password: str


@router.post("/auth/connexion", summary="Connexion (jeton opaque)")
def login(body: LoginIn, db: Session = DB):
    u = db.scalar(select(UserModel).where(UserModel.username == body.username))
    if not u or not u.active or u.is_service or not verify_password(body.password, u.password_hash):
        raise DomainError("IDENTIFIANTS_INVALIDES", "Identifiant ou mot de passe incorrect", 401)
    token = issue_token(db, u.id)
    audit(db, u.id, "auth.connexion", "user", u.id, f"Connexion de {u.username}")
    db.commit()
    return {"jeton": token, "utilisateur": me_dict(u)}


def me_dict(u: UserModel) -> dict:
    roles = [r.role_code for r in u.roles]
    perms = sorted(set().union(*(ROLE_PERMISSIONS.get(r, set()) for r in roles)))
    return {"id": u.id, "identifiant": u.username, "nom": u.full_name, "roles": roles, "permissions": perms,
            "sites": [s.site_id for s in u.sites]}


@router.get("/auth/moi")
def me(user: CurrentUser = User, db: Session = DB):
    return me_dict(db.get(UserModel, user.id))


@router.get("/admin/permissions")
def permissions(user: CurrentUser = User, db: Session = DB):
    return {"permissions": PERMISSIONS, "roles": [{**row(r), "permissions": sorted(ROLE_PERMISSIONS.get(r.code, []))}
                                                  for r in db.scalars(select(Role))]}


@router.get("/admin/utilisateurs")
def users(user: CurrentUser = perm("admin.users"), db: Session = DB):
    return [me_dict(u) | {"actif": u.active, "compte_equipement": u.is_service} for u in db.scalars(select(UserModel))]


class UserIn(BaseModel):
    username: str
    full_name: str
    password: str
    roles: list[str]


@router.post("/admin/utilisateurs")
def create_user(body: UserIn, user: CurrentUser = perm("admin.users"), db: Session = DB):
    if len(body.password) < 10:
        raise DomainError("MOT_DE_PASSE_FAIBLE", "Mot de passe : 10 caractères minimum")
    u = UserModel(username=body.username, full_name=body.full_name, password_hash=hash_password(body.password))
    db.add(u)
    db.flush()
    for r in body.roles:
        if not db.get(Role, r):
            raise NotFound("Rôle", r)
        db.add(UserRole(user_id=u.id, role_code=r))
    audit(db, user.id, "admin.utilisateur", "user", u.id, f"Création de {u.username} ({', '.join(body.roles)})")
    db.commit()
    return {"id": u.id}


@router.get("/admin/journal")
def audit_log(limit: int = 100, user: CurrentUser = perm("admin.users"), db: Session = DB):
    return rows(db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(min(limit, 500))))


@router.get("/organisations")
def organisations(user: CurrentUser = User, db: Session = DB):
    return rows(db.scalars(select(Organisation).order_by(Organisation.id)))


@router.get("/sites")
def sites(user: CurrentUser = User, db: Session = DB):
    out = []
    for s in db.scalars(select(Site).order_by(Site.id)):
        d = row(s)
        d["emplacements"] = rows(db.scalars(select(Location).where(Location.site_id == s.id).order_by(Location.id)))
        out.append(d)
    return out


class OrgStatusIn(BaseModel):
    ledger_status: str
    note: str


@router.post("/organisations/{org_id}/statut-registre", summary="Gouvernance : admission / suspension / retrait")
def org_status(org_id: int, body: OrgStatusIn, user: CurrentUser = perm("ledger.admin"), db: Session = DB):
    """Trace localement la décision de gouvernance. La modification effective du canal Fabric
    (mise à jour de configuration signée par la majorité des administrateurs) est une procédure
    hors application, décrite dans docs/gouvernance.md."""
    o = db.get(Organisation, org_id)
    if not o:
        raise NotFound("Organisation", org_id)
    if body.ledger_status not in ("CANDIDATE", "ADMISE", "SUSPENDUE", "RETIREE"):
        raise DomainError("STATUT_INCONNU", "Statut : CANDIDATE, ADMISE, SUSPENDUE ou RETIREE")
    o.ledger_status = body.ledger_status
    o.ledger_member = body.ledger_status == "ADMISE"
    audit(db, user.id, "gouvernance.statut", "organisation", o.id, f"{o.name} → {body.ledger_status} : {body.note}")
    db.commit()
    return row(o)


class FlagIn(BaseModel):
    actif: bool


@router.post("/admin/demo/panne-registre", summary="Démo : simuler l'indisponibilité du registre")
def ledger_outage(body: FlagIn, user: CurrentUser = perm("admin.demo"), db: Session = DB):
    set_flag(db, "ledger_outage", "1" if body.actif else "0")
    audit(db, user.id, "demo.panne_registre", "flag", "ledger_outage", f"Panne simulée : {body.actif}")
    db.commit()
    return {"panne_simulee": body.actif}


@router.get("/admin/demo/panne-registre")
def ledger_outage_state(user: CurrentUser = User, db: Session = DB):
    return {"panne_simulee": get_flag(db, "ledger_outage") == "1"}


@router.post("/admin/comptes-equipement/{username}/jeton", summary="Émettre un jeton pour un compte d'équipement")
def device_token(username: str, user: CurrentUser = perm("admin.users"), db: Session = DB):
    u = db.scalar(select(UserModel).where(UserModel.username == username, UserModel.is_service.is_(True)))
    if not u:
        raise NotFound("Compte d'équipement", username)
    token = issue_token(db, u.id)
    audit(db, user.id, "admin.jeton_equipement", "user", u.id, f"Jeton émis pour {username}")
    db.commit()
    return {"jeton": token, "note": "À stocker dans le secret de la passerelle d'équipements ; affiché une seule fois."}
