"""Équipements, automatisations, analyses."""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, perm
from app.core.errors import DomainError
from app.core.money import format_eur
from app.core.serialize import deep, row, rows
from app.core.types import utcnow
from app.modules.analytics import service as ana
from app.modules.automation import forecasting as fc
from app.modules.automation import rules
from app.modules.automation.models import ActionProposal, Alert, AutomationRule, ForecastRun
from app.modules.catalog import service as cat
from app.modules.catalog.models import Variant
from app.modules.iot import service as iot
from app.modules.iot.models import DEVICE_KINDS, Device, Observation, RfidObservation

iot_router = APIRouter(prefix="/api/equipements", tags=["Équipements (lecture seule)"])
auto_router = APIRouter(prefix="/api/automatisations", tags=["Automatisations"])
ana_router = APIRouter(prefix="/api/analyses", tags=["Analyses"])


@iot_router.get("")
def devices(user: CurrentUser = perm("iot.read"), db: Session = DB):
    return [row(d) | {"type_libelle": DEVICE_KINDS.get(d.kind)} for d in db.scalars(select(Device).order_by(Device.id))]


class ObservationIn(BaseModel):
    device_code: str
    payload: dict


@iot_router.post("/observations", summary="Ingestion HTTP (compte d'équipement) — même traitement que MQTT")
def ingest(body: ObservationIn, user: CurrentUser = perm("iot.ingest"), db: Session = DB):
    res = iot.ingest(db, body.device_code, body.payload, "HTTP")
    db.commit()
    return deep(res)


@iot_router.get("/{code}/observations")
def observations(code: str, limit: int = 100, user: CurrentUser = perm("iot.read"), db: Session = DB):
    d = db.scalar(select(Device).where(Device.code == code))
    if not d:
        raise DomainError("INTROUVABLE", "Équipement inconnu", 404)
    return rows(db.scalars(select(Observation).where(Observation.device_id == d.id)
                           .order_by(Observation.observed_at.desc()).limit(min(limit, 1000))))


@iot_router.get("/observations-rfid")
def rfid(user: CurrentUser = perm("iot.read"), db: Session = DB):
    return rows(db.scalars(select(RfidObservation).order_by(RfidObservation.id.desc()).limit(200)))


@iot_router.get("/balances/{code}/pesee")
def weight(code: str, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    return deep(iot.latest_weight(db, code))


@iot_router.get("/etiquettes/{variant_id}", summary="Contenu proposé pour une étiquette électronique (non poussé)")
def esl(variant_id: int, user: CurrentUser = perm("catalog.read"), db: Session = DB):
    v = get_or_404(db, Variant, variant_id, "Article")
    p, pl = cat.price_at(db, "MAGASIN", v.id)
    ref = cat.reference_price(db, "MAGASIN", v.id, p.valid_from) if p.is_promotion else None
    return {"sku": v.sku, "libelle": v.label, "prix": format_eur(p.amount_cents), "ttc": pl.tax_inclusive,
            "promotion": p.is_promotion, "prix_reference_30j": format_eur(ref) if ref else None,
            "mode": "LECTURE_SEULE : contenu calculé, aucun envoi vers les étiquettes dans le prototype"}


# --- Automatisations -------------------------------------------------------------------------------------
@auto_router.get("/regles")
def list_rules(user: CurrentUser = perm("automation.read"), db: Session = DB):
    return rows(db.scalars(select(AutomationRule).order_by(AutomationRule.code)))


class RuleIn(BaseModel):
    enabled: bool | None = None
    params: dict | None = None


@auto_router.patch("/regles/{code}")
def update_rule(code: str, body: RuleIn, user: CurrentUser = perm("automation.approve"), db: Session = DB):
    r = get_or_404(db, AutomationRule, code, "Règle")
    if body.enabled is not None:
        r.enabled = body.enabled
    if body.params is not None:
        r.params = {**r.params, **body.params}
    db.commit()
    return row(r)


@auto_router.post("/executer", summary="Évaluer toutes les règles maintenant")
def run_rules(user: CurrentUser = perm("automation.read"), db: Session = DB):
    res = rules.run_all(db)
    db.commit()
    return res


@auto_router.get("/alertes")
def alerts(status: str | None = "OUVERTE", user: CurrentUser = perm("automation.read"), db: Session = DB):
    q = select(Alert).order_by(Alert.id.desc()).limit(300)
    if status:
        q = q.where(Alert.status == status)
    return rows(db.scalars(q))


class AlertIn(BaseModel):
    status: str


@auto_router.post("/alertes/{aid}")
def update_alert(aid: int, body: AlertIn, user: CurrentUser = perm("automation.read"), db: Session = DB):
    a = get_or_404(db, Alert, aid, "Alerte")
    if body.status not in ("PRISE_EN_CHARGE", "RESOLUE", "IGNOREE"):
        raise DomainError("STATUT_INCONNU", "Statut : PRISE_EN_CHARGE, RESOLUE ou IGNOREE")
    a.status = body.status
    if body.status in ("RESOLUE", "IGNOREE"):
        a.resolved_by, a.resolved_at = user.id, utcnow()
    db.commit()
    return row(a)


@auto_router.get("/propositions")
def proposals(status: str | None = "PROPOSEE", user: CurrentUser = perm("automation.read"), db: Session = DB):
    q = select(ActionProposal).order_by(ActionProposal.id.desc()).limit(200)
    if status:
        q = q.where(ActionProposal.status == status)
    return [row(p) | {"valeur_affichage": format_eur(p.estimated_value_cents)} for p in db.scalars(q)]


class DecideIn(BaseModel):
    approve: bool
    note: str = ""


@auto_router.post("/propositions/{pid}/decision", summary="Approbation humaine obligatoire")
def decide(pid: int, body: DecideIn, user: CurrentUser = perm("automation.read"), db: Session = DB):
    res = rules.decide_proposal(db, pid, body.approve, body.note, user)
    db.commit()
    return res


class ForecastIn(BaseModel):
    variant_id: int
    site_id: int
    horizon_days: int = 7


@auto_router.post("/previsions", summary="Prévision évaluée sur période distincte, comparée aux méthodes simples")
def forecast(body: ForecastIn, user: CurrentUser = perm("analytics.read"), db: Session = DB):
    r = fc.evaluate(db, body.variant_id, body.site_id, body.horizon_days)
    db.commit()
    return row(r)


@auto_router.get("/previsions")
def forecasts(user: CurrentUser = perm("analytics.read"), db: Session = DB):
    return rows(db.scalars(select(ForecastRun).order_by(ForecastRun.id.desc()).limit(50)))


@auto_router.post("/risque-rupture")
def risk(body: ForecastIn, user: CurrentUser = perm("analytics.read"), db: Session = DB):
    res = fc.stockout_risk(db, body.variant_id, body.site_id, body.horizon_days)
    db.commit()
    return deep(res)


@auto_router.post("/anomalies")
def anomalies(body: ForecastIn, user: CurrentUser = perm("analytics.read"), db: Session = DB):
    return fc.detect_anomalies(db, body.variant_id, body.site_id)


class AllocIn(BaseModel):
    variant_id: int
    site_ids: list[int]
    min_cover_days: float = 7


@auto_router.post("/repartition", summary="Proposer un rééquilibrage entre magasins (soumis à approbation)")
def allocation(body: AllocIn, user: CurrentUser = perm("automation.read"), db: Session = DB):
    p = fc.propose_allocation(db, body.variant_id, body.site_ids, body.min_cover_days)
    db.commit()
    return row(p) if p else {"proposition": None, "raison": "Couvertures équilibrées : aucun transfert justifié"}


# --- Analyses --------------------------------------------------------------------------------------------
@ana_router.get("/indicateurs")
def indicators(debut: datetime | None = None, fin: datetime | None = None, site_id: int | None = None,
               user: CurrentUser = perm("analytics.read"), db: Session = DB):
    return deep(ana.indicators(db, debut, fin, site_id))


@ana_router.get("/fournisseurs")
def suppliers(user: CurrentUser = perm("analytics.read"), db: Session = DB):
    return ana.supplier_leadtimes(db)
