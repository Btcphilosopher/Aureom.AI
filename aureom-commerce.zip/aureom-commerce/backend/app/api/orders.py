"""Commandes omnicanales, clients, retours, rappels."""
from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, idem_key, perm
from app.core.errors import DomainError
from app.core.serialize import deep, row, rows
from app.modules.aftersales import service as after
from app.modules.aftersales.models import CONDITIONS, DISPOSITIONS, Recall, RecallLog, RecallLot, RecallTask, ReturnRequest
from app.modules.customers import service as cust
from app.modules.customers.models import Customer, LoyaltyAccount, LoyaltyEntry
from app.modules.orders import service as ords
from app.modules.orders.models import ORDER_STATUSES, Order, OrderEvent, PickTask, Shipment
from app.modules.payments import service as pay

router = APIRouter(prefix="/api/commandes", tags=["Commandes"])
cust_router = APIRouter(prefix="/api/clients", tags=["Clients"])
ret_router = APIRouter(prefix="/api/retours", tags=["Retours"])
rec_router = APIRouter(prefix="/api/rappels", tags=["Rappels"])


def order_view(db: Session, o: Order, with_pii: bool = False) -> dict:
    d = row(o, "lines", exclude=None if with_pii else {"shipping_address"})
    d["statut_libelle"] = ORDER_STATUSES[o.status]
    d["historique"] = rows(db.scalars(select(OrderEvent).where(OrderEvent.order_id == o.id).order_by(OrderEvent.id)))
    d["taches"] = rows(db.scalars(select(PickTask).where(PickTask.order_id == o.id).order_by(PickTask.id)))
    d["paiements"] = rows(pay.payments_for(db, "COMMANDE", o.id))
    d["expeditions"] = rows(db.scalars(select(Shipment).where(Shipment.order_id == o.id)))
    d["paye"] = pay.paid_cents(db, "COMMANDE", o.id)
    return d


class OrderLineIn(BaseModel):
    variant_id: int | None = None
    code: str | None = None
    quantity: Decimal
    packaging_level: str = "PIECE"


class OrderIn(BaseModel):
    channel: str
    fulfilment: str
    source_site_id: int
    pickup_site_id: int | None = None
    customer_id: int | None = None
    shipping_cents: int = 0
    shipping_address: dict | None = None
    customer_po_ref: str | None = None
    lines: list[OrderLineIn]


@router.post("")
def create(body: OrderIn, key: str | None = idem_key, user: CurrentUser = perm("order.write"), db: Session = DB):
    data = body.model_dump()
    data["lines"] = [{k: v for k, v in l.items() if v is not None} for l in data["lines"]]
    data["idempotency_key"] = key
    o = ords.create_order(db, data, user.id)
    db.commit()
    return order_view(db, o, user.has("customer.pii"))


@router.get("")
def list_orders(status: str | None = None, site_id: int | None = None, user: CurrentUser = perm("order.read"),
                db: Session = DB):
    q = select(Order).order_by(Order.id.desc()).limit(200)
    if status:
        q = q.where(Order.status == status)
    if site_id:
        q = q.where(Order.source_site_id == site_id)
    return [row(o, exclude={"shipping_address"}) | {"statut_libelle": ORDER_STATUSES[o.status]} for o in db.scalars(q)]


@router.get("/{oid}")
def get(oid: int, user: CurrentUser = perm("order.read"), db: Session = DB):
    return order_view(db, ords.get_order(db, oid), user.has("customer.pii"))


def _act(db, oid, fn, *a):
    o = ords.get_order(db, oid, lock=True)
    res = fn(db, o, *a)
    db.commit()
    return o, res


@router.post("/{oid}/valider")
def validate(oid: int, user: CurrentUser = perm("order.write"), db: Session = DB):
    o, _ = _act(db, oid, ords.validate, user.id)
    return order_view(db, o)


@router.post("/{oid}/reserver", summary="Réservation tout-ou-rien du stock de la source")
def reserve(oid: int, user: CurrentUser = perm("order.write"), db: Session = DB):
    o, _ = _act(db, oid, ords.reserve, user.id)
    return order_view(db, o)


@router.post("/{oid}/preparer")
def prepare(oid: int, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    o, _ = _act(db, oid, ords.start_preparation, user.id)
    return order_view(db, o)


class PickIn(BaseModel):
    picked_qty: Decimal
    scanned_code: str


@router.post("/taches/{tid}/prelever", summary="Confirmer un prélèvement par scan")
def pick(tid: int, body: PickIn, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    t = ords.confirm_pick(db, tid, body.picked_qty, body.scanned_code, user.id)
    db.commit()
    return row(t)


@router.post("/{oid}/prete", summary="Commande prête au retrait (code de retrait renvoyé une seule fois)")
def ready(oid: int, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    o, code = _act(db, oid, ords.mark_ready, user.id)
    return order_view(db, o) | {"code_retrait": code, "note": "Communiqué au client par message (simulé)."}


class HandoverIn(BaseModel):
    pickup_code: str


@router.post("/{oid}/remettre")
def handover(oid: int, body: HandoverIn, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    o, _ = _act(db, oid, ords.handover, body.pickup_code, user.id)
    return order_view(db, o)


class ShipIn(BaseModel):
    carrier: str = "Transporteur simulé"
    parcels: int = 1


@router.post("/{oid}/expedier")
def ship(oid: int, body: ShipIn, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    o = ords.get_order(db, oid, lock=True)
    ords.ship(db, o, body.carrier, user.id, body.parcels)
    db.commit()
    return order_view(db, o)


@router.post("/{oid}/livree")
def delivered(oid: int, user: CurrentUser = perm("order.fulfil"), db: Session = DB):
    o, _ = _act(db, oid, ords.deliver, user.id)
    return order_view(db, o)


class CancelIn(BaseModel):
    reason: str


@router.post("/{oid}/annuler")
def cancel(oid: int, body: CancelIn, user: CurrentUser = perm("order.write"), db: Session = DB):
    o, _ = _act(db, oid, ords.cancel, body.reason, user.id)
    return order_view(db, o)


class OrderPayIn(BaseModel):
    method: str
    amount_cents: int
    card_token: str | None = None


@router.post("/{oid}/paiements")
def pay_order(oid: int, body: OrderPayIn, key: str | None = idem_key, user: CurrentUser = perm("order.write"),
              db: Session = DB):
    if not key:
        raise DomainError("IDEMPOTENCE_REQUISE", "En-tête Idempotency-Key requis")
    o = ords.get_order(db, oid)
    p = ords.pay_order(db, o, body.method, body.amount_cents, key, user, body.card_token)
    db.commit()
    return {"paiement": row(p), "commande": order_view(db, ords.get_order(db, oid))}


class SplitIn(BaseModel):
    lines: list[dict]
    site_ids: list[int]


@router.post("/fractionnement/proposition", summary="Proposition de fractionnement (règle explicite, sans effet)")
def split(body: SplitIn, user: CurrentUser = perm("order.read"), db: Session = DB):
    return deep(ords.propose_split(db, body.lines, body.site_ids))


# --- Clients ---------------------------------------------------------------------------------------------
class CustomerIn(BaseModel):
    kind: str = "PARTICULIER"
    first_name: str | None = None
    last_name: str | None = None
    company_name: str | None = None
    siret: str | None = None
    email: str | None = None
    phone: str | None = None
    payment_terms_days: int | None = None
    email_marketing: bool | None = None
    sms_marketing: bool | None = None
    loyalty: bool = False
    source: str = "CAISSE"


@cust_router.post("")
def create_customer(body: CustomerIn, user: CurrentUser = perm("customer.write"), db: Session = DB):
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    c = cust.create_customer(db, data, user.id)
    db.commit()
    return cust.public_view(c, user.has("customer.pii"))


@cust_router.get("")
def customers(q: str | None = None, user: CurrentUser = perm("customer.read"), db: Session = DB):
    stmt = select(Customer).order_by(Customer.id.desc()).limit(200)
    if q:
        stmt = stmt.where((Customer.last_name.ilike(f"%{q}%")) | (Customer.company_name.ilike(f"%{q}%")) |
                          (Customer.code == q))
    return [cust.public_view(c, user.has("customer.pii")) for c in db.scalars(stmt)]


@cust_router.get("/{cid}")
def customer(cid: int, user: CurrentUser = perm("customer.read"), db: Session = DB):
    c = get_or_404(db, Customer, cid, "Client")
    acc = db.scalar(select(LoyaltyAccount).where(LoyaltyAccount.customer_id == c.id))
    return cust.public_view(c, user.has("customer.pii")) | {
        "consentements_marketing": deep(cust.current_consents(db, c.id)),
        "fidelite": None if not acc else {"solde": cust.balance(db, acc.id), "regles": cust.LOYALTY_RULES_TEXT,
                                          "mouvements": rows(db.scalars(select(LoyaltyEntry).where(
                                              LoyaltyEntry.account_id == acc.id).order_by(LoyaltyEntry.id)))},
        "note": "Le consentement marketing est indépendant des achats et de la fidélité."}


class ConsentIn(BaseModel):
    channel: str
    granted: bool
    source: str = "CAISSE"


@cust_router.post("/{cid}/consentements")
def consent(cid: int, body: ConsentIn, user: CurrentUser = perm("customer.write"), db: Session = DB):
    get_or_404(db, Customer, cid, "Client")
    cust.set_consent(db, cid, body.channel, body.granted, body.source, user.id)
    db.commit()
    return deep(cust.current_consents(db, cid))


@cust_router.post("/{cid}/fidelite")
def enroll(cid: int, user: CurrentUser = perm("customer.write"), db: Session = DB):
    acc = cust.enroll(db, cid)
    db.commit()
    return row(acc) | {"regles": cust.LOYALTY_RULES_TEXT}


@cust_router.post("/{cid}/anonymiser")
def anonymize(cid: int, user: CurrentUser = perm("customer.pii", "customer.write"), db: Session = DB):
    cust.anonymize(db, cid, user.id)
    db.commit()
    return {"anonymise": True}


# --- Retours ---------------------------------------------------------------------------------------------
class ReturnLineIn(BaseModel):
    line_id: int
    quantity: Decimal
    reason: str = ""
    lot_id: int | None = None


class ReturnIn(BaseModel):
    origin: str
    source_id: int
    site_id: int
    lines: list[ReturnLineIn]


@ret_router.get("/references")
def ret_refs(user: CurrentUser = perm("return.manage")):
    return {"etats": CONDITIONS, "dispositions": DISPOSITIONS}


@ret_router.post("")
def create_return(body: ReturnIn, user: CurrentUser = perm("return.manage"), db: Session = DB):
    r = after.create_return(db, origin=body.origin, source_id=body.source_id, site_id=body.site_id,
                            lines=[l.model_dump() for l in body.lines], actor_id=user.id)
    db.commit()
    return row(r, "lines")


@ret_router.get("")
def returns(user: CurrentUser = perm("return.manage"), db: Session = DB):
    return [row(r, "lines") for r in db.scalars(select(ReturnRequest).order_by(ReturnRequest.id.desc()).limit(100))]


class InspectIn(BaseModel):
    condition: str
    disposition: str
    notes: str = ""


@ret_router.post("/lignes/{lid}/inspection", summary="Inspection et disposition explicite")
def inspect(lid: int, body: InspectIn, user: CurrentUser = perm("quality.inspect"), db: Session = DB):
    ln = after.inspect_line(db, lid, body.condition, body.disposition, body.notes, user.id)
    db.commit()
    return row(ln)


class RefundRetIn(BaseModel):
    session_id: int | None = None


@ret_router.post("/{rid}/remboursement", summary="Rembourser (indépendant de la remise en stock)")
def refund_return(rid: int, body: RefundRetIn, key: str | None = idem_key, user: CurrentUser = perm("pos.refund"),
                  db: Session = DB):
    if not key:
        raise DomainError("IDEMPOTENCE_REQUISE", "En-tête Idempotency-Key requis")
    res = after.refund_return(db, rid, key, user.id, body.session_id)
    db.commit()
    return res


# --- Rappels ---------------------------------------------------------------------------------------------
class RecallIn(BaseModel):
    lot_ids: list[int]
    reason: str
    severity: str = "RAPPEL_CONSOMMATEURS"


@rec_router.post("")
def open_recall(body: RecallIn, user: CurrentUser = perm("recall.manage"), db: Session = DB):
    rc = after.open_recall(db, body.lot_ids, body.reason, body.severity, user.id)
    db.commit()
    return recall_view(db, rc)


def recall_view(db: Session, rc: Recall) -> dict:
    return row(rc) | {"lots": rows(db.scalars(select(RecallLot).where(RecallLot.recall_id == rc.id))),
                      "taches": rows(db.scalars(select(RecallTask).where(RecallTask.recall_id == rc.id).order_by(RecallTask.id))),
                      "journal": rows(db.scalars(select(RecallLog).where(RecallLog.recall_id == rc.id).order_by(RecallLog.id)))}


@rec_router.get("")
def recalls(user: CurrentUser = perm("trace.read"), db: Session = DB):
    return rows(db.scalars(select(Recall).order_by(Recall.id.desc())))


@rec_router.get("/{rid}")
def recall(rid: int, user: CurrentUser = perm("trace.read"), db: Session = DB):
    return recall_view(db, get_or_404(db, Recall, rid, "Rappel"))


class TaskIn(BaseModel):
    notes: str
    status: str = "FAITE"


@rec_router.post("/taches/{tid}")
def task(tid: int, body: TaskIn, user: CurrentUser = perm("recall.manage"), db: Session = DB):
    t = after.complete_task(db, tid, body.notes, user.id, body.status)
    db.commit()
    return row(t)


class LogIn(BaseModel):
    kind: str
    content: str
    channel: str | None = None
    audience: str | None = None
    count: int = 0


@rec_router.post("/{rid}/journal")
def log(rid: int, body: LogIn, user: CurrentUser = perm("recall.manage"), db: Session = DB):
    lg = after.log_recall(db, rid, body.kind, body.content, user.id, body.channel, body.audience, body.count)
    db.commit()
    return row(lg)


class CloseRecallIn(BaseModel):
    note: str = Field(min_length=3)


@rec_router.post("/{rid}/cloture")
def close(rid: int, body: CloseRecallIn, user: CurrentUser = perm("recall.manage"), db: Session = DB):
    rc = after.close_recall(db, rid, user.id, body.note)
    db.commit()
    return recall_view(db, rc)
