"""Caisse et paiements."""
from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter, Header, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, idem_key, perm
from app.core.errors import DomainError
from app.core.serialize import row, rows
from app.db import get_db
from app.modules.payments import service as pay
from app.modules.payments.models import Payment
from app.modules.pos import service as pos
from app.modules.pos.models import CashRegister, PosSession, Sale
from fastapi import Depends

router = APIRouter(prefix="/api/caisse", tags=["Caisse"])
pay_router = APIRouter(prefix="/api/paiements", tags=["Paiements"])

NOTICE = ("Prototype de caisse NON certifié : ne pas utiliser pour encaisser réellement. Voir "
          "docs/conformite-et-cadre.md.")


def sale_view(db: Session, s: Sale) -> dict:
    d = row(s, "lines")
    d["paiements"] = rows(pay.payments_for(db, "VENTE", s.id))
    paid = pay.paid_cents(db, "VENTE", s.id)
    d["paye"] = paid
    d["en_attente"] = pay.pending_cents(db, "VENTE", s.id)
    d["reste_a_payer"] = s.total_ttc_cents - paid
    d["avertissement"] = NOTICE
    return d


@router.get("/postes")
def registers(user: CurrentUser = perm("pos.sell"), db: Session = DB):
    out = []
    for r in db.scalars(select(CashRegister)):
        s = db.scalar(select(PosSession).where(PosSession.register_id == r.id, PosSession.status == "OUVERTE"))
        out.append(row(r) | {"session_ouverte": row(s)})
    return out


class OpenIn(BaseModel):
    register_id: int
    opening_float_cents: int


@router.post("/sessions")
def open_session(body: OpenIn, user: CurrentUser = perm("pos.session"), db: Session = DB):
    s = pos.open_session(db, body.register_id, body.opening_float_cents, user)
    db.commit()
    return row(s)


class CloseIn(BaseModel):
    counted_cash_cents: int


@router.post("/sessions/{sid}/cloture", summary="Clôture et rapprochement de caisse")
def close_session(sid: int, body: CloseIn, user: CurrentUser = perm("pos.session"), db: Session = DB):
    s = pos.close_session(db, sid, body.counted_cash_cents, user)
    db.commit()
    return row(s)


@router.get("/sessions/{sid}")
def get_session(sid: int, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    s = get_or_404(db, PosSession, sid, "Session")
    return row(s) | {"ventes": [row(v) for v in db.scalars(select(Sale).where(Sale.session_id == sid))]}


class SaleIn(BaseModel):
    session_id: int
    customer_id: int | None = None


@router.post("/ventes")
def create_sale(body: SaleIn, key: str | None = idem_key, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    s = pos.create_sale(db, body.session_id, user, body.customer_id, key)
    db.commit()
    return sale_view(db, s)


@router.get("/ventes/{sale_id}")
def get_sale(sale_id: int, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    return sale_view(db, pos.get_sale(db, sale_id))


class LineIn(BaseModel):
    code: str
    quantity: Decimal = Decimal(1)
    lot_code: str | None = None


@router.post("/ventes/{sale_id}/lignes", summary="Ajouter un article (scan ou recherche)")
def add_line(sale_id: int, body: LineIn, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    pos.add_line(db, sale_id, body.code, body.quantity, user, body.lot_code)
    db.commit()
    return sale_view(db, pos.get_sale(db, sale_id))


class DiscountIn(BaseModel):
    discount_bp: int
    reason: str
    manager_username: str | None = None
    manager_password: str | None = None


@router.post("/lignes/{line_id}/remise")
def discount(line_id: int, body: DiscountIn, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    ln = pos.discount_line(db, line_id, body.discount_bp, body.reason, user, body.manager_username,
                           body.manager_password)
    db.commit()
    return sale_view(db, pos.get_sale(db, ln.sale_id))


class VoidIn(BaseModel):
    reason: str
    manager_username: str | None = None
    manager_password: str | None = None


@router.post("/lignes/{line_id}/annulation")
def void_line(line_id: int, body: VoidIn, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    ln = pos.void_line(db, line_id, body.reason, user, body.manager_username, body.manager_password)
    db.commit()
    return sale_view(db, pos.get_sale(db, ln.sale_id))


class PayIn(BaseModel):
    method: str
    amount_cents: int
    card_token: str | None = None
    cash_tendered_cents: int | None = None


@router.post("/ventes/{sale_id}/paiements", summary="Paiement (partiel possible) — en-tête Idempotency-Key requis")
def add_payment(sale_id: int, body: PayIn, key: str | None = idem_key, user: CurrentUser = perm("pos.sell"),
                db: Session = DB):
    if not key:
        raise DomainError("IDEMPOTENCE_REQUISE", "En-tête Idempotency-Key requis pour un paiement")
    p = pos.add_payment(db, sale_id, body.method, body.amount_cents, key, user, body.card_token,
                        body.cash_tendered_cents)
    db.commit()
    return {"paiement": row(p), "vente": sale_view(db, pos.get_sale(db, sale_id))}


@router.post("/ventes/{sale_id}/valider", summary="Terminer la vente (intégralement payée) puis sortir le stock")
def complete(sale_id: int, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    s = pos.complete_sale(db, sale_id, user)
    db.commit()
    return sale_view(db, s) | {"ticket": pos.ticket_text(db, s)}


@router.post("/ventes/{sale_id}/annuler")
def cancel(sale_id: int, body: VoidIn, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    s = pos.cancel_sale(db, sale_id, body.reason, user, body.manager_username, body.manager_password)
    db.commit()
    return sale_view(db, s)


@router.get("/ventes/{sale_id}/ticket", response_class=PlainTextResponse)
def ticket(sale_id: int, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    return pos.ticket_text(db, pos.get_sale(db, sale_id))


# --- Paiements -------------------------------------------------------------------------------------------
@pay_router.post("/webhook", summary="Événements du prestataire (signature HMAC vérifiée, rejeu ignoré)")
async def webhook(request: Request, sim_signature: str | None = Header(default=None, alias="Sim-Signature"),
                  db: Session = Depends(get_db)):
    body = await request.body()
    try:
        res = pay.handle_webhook(db, body, sim_signature)
        db.commit()
        return res
    except DomainError:
        db.commit()  # conserve la trace de l'événement invalide
        raise


@pay_router.get("/{pid}")
def payment(pid: int, user: CurrentUser = perm("pos.sell"), db: Session = DB):
    return row(pay.get_payment(db, pid))


class RefundIn(BaseModel):
    amount_cents: int
    reason: str


@pay_router.post("/{pid}/remboursement", summary="Remboursement (n'affecte pas le stock)")
def refund(pid: int, body: RefundIn, key: str | None = idem_key, user: CurrentUser = perm("pos.refund"),
           db: Session = DB):
    if not key:
        raise DomainError("IDEMPOTENCE_REQUISE", "En-tête Idempotency-Key requis")
    p = pay.get_payment(db, pid)
    r = pay.refund(db, p, body.amount_cents, body.reason, key, user.id)
    db.commit()
    return row(r)


@pay_router.post("/simulateur/evenement", summary="Simulateur : émettre un événement signé tardif")
def sim_event(provider_ref: str, event_type: str = "payment.captured", user: CurrentUser = perm("admin.demo"),
              db: Session = DB):
    p = db.scalar(select(Payment).where(Payment.provider_ref == provider_ref))
    if not p:
        raise DomainError("INCONNU", "Référence inconnue")
    body = pay.build_event(event_type, provider_ref, p.amount_cents)
    res = pay.handle_webhook(db, body, pay.sign_event(body))
    db.commit()
    return res
