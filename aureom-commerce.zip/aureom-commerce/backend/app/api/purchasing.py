"""Achats et réception."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from fastapi import APIRouter, File, Form, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import DB, CurrentUser, get_or_404, perm
from app.core import storage
from app.core.serialize import row, rows
from app.modules.admin.models import Organisation
from app.modules.purchasing import service as pur
from app.modules.purchasing.models import (GoodsReceipt, GoodsReceiptLine, PurchaseOrder, PurchaseProposal,
                                           ReplenishmentNeed, SupplierDocument, SupplierInvoice, SupplierReturn)

router = APIRouter(prefix="/api/achats", tags=["Achats"])


@router.get("/fournisseurs")
def suppliers(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return rows(db.scalars(select(Organisation).where(Organisation.kind == "FOURNISSEUR")))


@router.get("/besoins")
def needs(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return rows(db.scalars(select(ReplenishmentNeed).order_by(ReplenishmentNeed.id.desc()).limit(200)))


class ProposalLineIn(BaseModel):
    variant_id: int
    pack_qty: int | None = None
    base_qty: Decimal | None = None


class ProposalIn(BaseModel):
    supplier_id: int
    site_id: int
    rationale: str = ""
    lines: list[ProposalLineIn]


@router.post("/propositions")
def create_proposal(body: ProposalIn, user: CurrentUser = perm("purchase.write"), db: Session = DB):
    lines = [{k: v for k, v in l.model_dump().items() if v is not None} for l in body.lines]
    p = pur.create_proposal(db, body.supplier_id, body.site_id, lines, body.rationale, user.id)
    db.commit()
    return row(p, "lines")


@router.get("/propositions")
def proposals(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return [row(p, "lines") for p in db.scalars(select(PurchaseProposal).order_by(PurchaseProposal.id.desc()).limit(100))]


class DecisionIn(BaseModel):
    approve: bool
    note: str = ""


@router.post("/propositions/{pid}/decision", summary="Approuver (plafond par rôle, séparation des tâches) ou rejeter")
def decide(pid: int, body: DecisionIn, user: CurrentUser = perm("purchase.read"), db: Session = DB):
    p = get_or_404(db, PurchaseProposal, pid, "Proposition")
    po = pur.decide_proposal(db, p, user, body.approve, body.note)
    db.commit()
    return {"proposition": row(p), "commande": row(po, "lines") if po else None}


@router.get("/commandes")
def orders(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return [row(o, "lines") for o in db.scalars(select(PurchaseOrder).order_by(PurchaseOrder.id.desc()).limit(100))]


@router.get("/commandes/{oid}")
def order(oid: int, user: CurrentUser = perm("purchase.read"), db: Session = DB):
    o = get_or_404(db, PurchaseOrder, oid, "Commande fournisseur")
    d = row(o, "lines")
    d["receptions"] = [row(r, "lines") for r in db.scalars(select(GoodsReceipt).where(GoodsReceipt.order_id == o.id))]
    d["factures"] = rows(db.scalars(select(SupplierInvoice).where(SupplierInvoice.order_id == o.id)))
    return d


class ReceiptLineIn(BaseModel):
    order_line_id: int
    received_qty: Decimal | None = None
    received_packs: Decimal | None = None
    damaged_qty: Decimal = Decimal(0)
    lot_code: str | None = None
    expires_on: str | None = None
    manufactured_on: str | None = None
    inspection_result: str = "CONFORME"
    notes: str = ""
    temperature_c: Decimal | None = None


class ReceiptIn(BaseModel):
    lines: list[ReceiptLineIn]
    delivery_note_ref: str | None = None
    carrier: str | None = None
    supplier_shipment_event_id: str | None = None
    document_ids: list[int] = []


@router.post("/commandes/{oid}/receptions", summary="Réception (partielle possible) avec lots et contrôle")
def receive(oid: int, body: ReceiptIn, user: CurrentUser = perm("receipt.write"), db: Session = DB):
    o = get_or_404(db, PurchaseOrder, oid, "Commande fournisseur")
    user.check_site(o.ship_to_site_id)
    lines = [{k: v for k, v in l.model_dump().items() if v is not None} for l in body.lines]
    gr = pur.receive(db, o, lines, user.id, delivery_note_ref=body.delivery_note_ref, carrier=body.carrier,
                     supplier_shipment_event_id=body.supplier_shipment_event_id, document_ids=body.document_ids)
    db.commit()
    return {"reception": row(gr, "lines"), "commande": row(o, "lines")}


class InspectionIn(BaseModel):
    result: str
    notes: str


@router.post("/receptions/lignes/{lid}/controle", summary="Contrôle différé d'une ligne « à contrôler »")
def inspect(lid: int, body: InspectionIn, user: CurrentUser = perm("quality.inspect"), db: Session = DB):
    ln = get_or_404(db, GoodsReceiptLine, lid, "Ligne de réception")
    pur.release_inspection(db, ln, body.result, body.notes, user.id)
    db.commit()
    return row(ln)


@router.post("/documents", summary="Déposer un document fourni (statut : non vérifié)")
async def upload(supplier_id: int = Form(...), kind: str = Form(...), claimed_issuer: str | None = Form(None),
                 claimed_reference: str | None = Form(None), lot_id: int | None = Form(None),
                 file: UploadFile = File(...), user: CurrentUser = perm("receipt.write"), db: Session = DB):
    data = await file.read()
    obj = storage.store(db, data, file.filename or "document.pdf", file.content_type or "application/pdf", user.id)
    d = pur.attach_document(db, supplier_id=supplier_id, kind=kind, object_id=obj.id, sha256=obj.sha256,
                            claimed_issuer=claimed_issuer, claimed_reference=claimed_reference, lot_id=lot_id)
    db.commit()
    return row(d) | {"avertissement": "Document enregistré comme NON VÉRIFIÉ : son dépôt, son empreinte ou une "
                                      "signature ne prouvent pas son authenticité."}


@router.get("/documents")
def documents(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return rows(db.scalars(select(SupplierDocument).order_by(SupplierDocument.id.desc())))


class VerifyDocIn(BaseModel):
    status: str
    method: str
    note: str = ""


@router.post("/documents/{did}/verification")
def verify_doc(did: int, body: VerifyDocIn, user: CurrentUser = perm("quality.inspect"), db: Session = DB):
    d = get_or_404(db, SupplierDocument, did, "Document")
    pur.verify_document(db, d, body.status, body.method, body.note, user.id)
    db.commit()
    return row(d)


class InvoiceLineIn(BaseModel):
    order_line_id: int
    base_qty: Decimal
    unit_cost_cents: int


class InvoiceIn(BaseModel):
    invoice_number: str
    invoice_date: date
    lines: list[InvoiceLineIn]


@router.post("/commandes/{oid}/factures", summary="Facture fournisseur et rapprochement à trois voies")
def invoice(oid: int, body: InvoiceIn, user: CurrentUser = perm("purchase.write"), db: Session = DB):
    o = get_or_404(db, PurchaseOrder, oid, "Commande fournisseur")
    inv_ = pur.record_invoice(db, o, body.invoice_number, body.invoice_date,
                              [{**l.model_dump(), "base_qty": str(l.base_qty)} for l in body.lines])
    db.commit()
    return row(inv_)


class SupplierReturnIn(BaseModel):
    supplier_id: int
    site_id: int
    variant_id: int
    lot_id: int | None = None
    quantity: Decimal
    from_state: str = "ENDOMMAGE"
    reason: str


@router.post("/retours-fournisseurs")
def supplier_return(body: SupplierReturnIn, user: CurrentUser = perm("purchase.write"), db: Session = DB):
    sr = pur.return_to_supplier(db, **body.model_dump(), actor_id=user.id)
    db.commit()
    return row(sr)


@router.get("/retours-fournisseurs")
def supplier_returns(user: CurrentUser = perm("purchase.read"), db: Session = DB):
    return rows(db.scalars(select(SupplierReturn).order_by(SupplierReturn.id.desc())))
