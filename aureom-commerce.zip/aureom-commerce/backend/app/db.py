"""Accès PostgreSQL (SQLAlchemy 2) et diffusion d'événements opérationnels (LISTEN/NOTIFY)."""
from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import MetaData, create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings

NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


_engine = None
_SessionLocal: sessionmaker[Session] | None = None


def get_engine():
    global _engine, _SessionLocal
    if _engine is None:
        _engine = create_engine(get_settings().database_url, pool_pre_ping=True, pool_size=10, max_overflow=20)
        _SessionLocal = sessionmaker(bind=_engine, expire_on_commit=False, autoflush=True)
    return _engine


def reset_engine(url: str | None = None) -> None:
    """Utilisé par les tests pour pointer vers une autre base."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None
    if url:
        get_settings.cache_clear()
        import os

        os.environ["AUREOM_DATABASE_URL"] = url
    get_engine()


def SessionLocal() -> Session:  # noqa: N802 - fabrique
    get_engine()
    assert _SessionLocal is not None
    return _SessionLocal()


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _json_default(o: Any):
    if isinstance(o, (datetime, date)):
        return o.isoformat()
    if isinstance(o, Decimal):
        return str(o)
    return str(o)


OPS_CHANNEL = "aureom_ops"


def notify(db: Session, kind: str, payload: dict[str, Any]) -> None:
    """Publie un événement opérationnel. NOTIFY n'est délivré qu'au COMMIT de la transaction :
    aucun écran ne voit une opération annulée."""
    body = json.dumps({"type": kind, "data": payload}, default=_json_default, ensure_ascii=False)
    if len(body.encode()) > 7900:  # limite NOTIFY ~8000 octets
        body = json.dumps({"type": kind, "data": {"tronque": True}})
    db.execute(text("SELECT pg_notify(:c, :b)"), {"c": OPS_CHANNEL, "b": body})
