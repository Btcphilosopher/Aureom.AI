"""AUREOM COMMERCE — application FastAPI (monolithe modulaire)."""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from contextlib import asynccontextmanager

import psycopg
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app import models  # noqa: F401 — enregistre toutes les tables
from app.api import admin, catalog, inventory, ops, orders, pos, purchasing, trace
from app.api.deps import DB, CurrentUser, perm
from app.config import get_settings
from app.core.errors import DomainError
from app.core.security import user_from_token
from app.core.serialize import deep
from app.db import OPS_CHANNEL, SessionLocal
from app.modules.automation.models import ActionProposal, Alert
from app.modules.inventory.models import StockException
from app.modules.orders.models import Order
from app.modules.purchasing.models import PurchaseOrder
from app.modules.traceability.models import TraceEvent

log = logging.getLogger("aureom")


class Hub:
    def __init__(self):
        self.clients: set[WebSocket] = set()

    async def broadcast(self, message: str):
        dead = []
        for ws in list(self.clients):
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.clients.discard(ws)


hub = Hub()


async def listen_forever():
    """Relaye les NOTIFY PostgreSQL (émis au commit des opérations, y compris par le worker) vers les WebSockets."""
    url = get_settings().database_url.replace("postgresql+psycopg://", "postgresql://")
    while True:
        try:
            async with await psycopg.AsyncConnection.connect(url, autocommit=True) as conn:
                await conn.execute(f"LISTEN {OPS_CHANNEL}")
                async for n in conn.notifies():
                    await hub.broadcast(n.payload)
        except asyncio.CancelledError:
            raise
        except Exception as e:  # reconnexion
            log.warning("Écoute PostgreSQL interrompue : %s", e)
            await asyncio.sleep(3)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(listen_forever())
    yield
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task


app = FastAPI(
    title="AUREOM COMMERCE — API",
    description=("Gestion du commerce connecté (prototype). Montants en centimes d'euro (entiers), quantités en "
                 "unité de base avec 3 décimales, dates ISO 8601 (UTC). Caisse NON certifiée. Le registre partagé "
                 "conserve des déclarations signées ; il ne prouve pas la réalité des événements physiques."),
    version="1.0.0", lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=get_settings().cors_list, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])


@app.exception_handler(DomainError)
async def domain_error(request: Request, exc: DomainError):
    return JSONResponse(status_code=exc.status_code, content=deep(exc.to_dict()))


@app.exception_handler(IntegrityError)
async def integrity_error(request: Request, exc: IntegrityError):
    msg = str(exc.orig).split("\n")[0] if exc.orig else str(exc)
    return JSONResponse(status_code=409, content={"code": "CONTRAINTE_BASE",
                                                  "message": "Opération refusée par une contrainte de la base de données",
                                                  "details": {"contrainte": msg[:300]}})


for r in (admin.router, catalog.router, inventory.router, purchasing.router, pos.router, pos.pay_router, orders.router,
          orders.cust_router, orders.ret_router, orders.rec_router, trace.router, ops.iot_router, ops.auto_router,
          ops.ana_router):
    app.include_router(r)


@app.get("/api/sante", tags=["Système"])
def health():
    with SessionLocal() as db:
        db.execute(select(1))
    from app.modules.ledger.adapters import get_ledger

    lg = get_ledger()
    return {"application": "ok", "base": "ok", "registre": {"mode": lg.name, "distribue": lg.distributed,
                                                            **lg.health()}}


@app.get("/api/tableau-de-bord", tags=["Système"])
def dashboard(site_id: int | None = None, user: CurrentUser = perm("stock.read"), db=DB):
    def count(model, *conds):
        return db.scalar(select(func.count()).select_from(model).where(*conds)) or 0

    def osite(col):
        return col == site_id if site_id else True

    flow = [
        {"etape": "Achats", "code": "achats", "valeur": count(PurchaseOrder, PurchaseOrder.status.in_(("ENVOYEE", "PARTIELLEMENT_RECUE")), osite(PurchaseOrder.ship_to_site_id)), "libelle": "commandes fournisseurs attendues"},
        {"etape": "Réception", "code": "reception", "valeur": count(PurchaseOrder, PurchaseOrder.status == "PARTIELLEMENT_RECUE", osite(PurchaseOrder.ship_to_site_id)), "libelle": "livraisons partielles"},
        {"etape": "Commandes", "code": "commandes", "valeur": count(Order, Order.status.in_(("RECUE", "VALIDEE")), osite(Order.source_site_id)), "libelle": "à valider / réserver"},
        {"etape": "Préparation", "code": "preparation", "valeur": count(Order, Order.status.in_(("RESERVEE", "EN_PREPARATION")), osite(Order.source_site_id)), "libelle": "à préparer"},
        {"etape": "Retrait / expédition", "code": "remise", "valeur": count(Order, Order.status.in_(("PRETE", "EXPEDIEE")), osite(Order.source_site_id)), "libelle": "prêtes ou en transit"},
        {"etape": "Traçabilité", "code": "tracabilite", "valeur": count(TraceEvent, TraceEvent.ledger_status.in_(("EN_ATTENTE", "SOUMIS", "INCONNU"))), "libelle": "événements non confirmés"},
        {"etape": "Rapprochement", "code": "rapprochement", "valeur": count(StockException, StockException.status == "OUVERTE", osite(StockException.site_id)), "libelle": "exceptions de stock"},
    ]
    alerts = db.scalars(select(Alert).where(Alert.status == "OUVERTE", osite(Alert.site_id) if site_id else True)
                        .order_by(Alert.id.desc()).limit(8))
    return deep({"flux": flow, "alertes": [{"id": a.id, "gravite": a.severity, "titre": a.title, "message": a.message,
                                            "date": a.created_at} for a in alerts],
                 "propositions_en_attente": count(ActionProposal, ActionProposal.status == "PROPOSEE"),
                 "commandes_rejetees_registre": count(TraceEvent, TraceEvent.ledger_status == "REJETE")})


@app.websocket("/ws")
async def ws(websocket: WebSocket, token: str | None = None):
    with SessionLocal() as db:
        try:
            u = user_from_token(db, token or "")
        except DomainError:
            await websocket.close(code=4401)
            return
    await websocket.accept()
    hub.clients.add(websocket)
    await websocket.send_text(json.dumps({"type": "connexion", "data": {"utilisateur": u.username}}))
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        hub.clients.discard(websocket)
