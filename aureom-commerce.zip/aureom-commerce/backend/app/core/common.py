"""Services transverses : audit, numérotation, idempotence, drapeaux d'exécution."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.core.errors import Conflict
from app.core.types import utcnow
from app.db import _json_default
from app.modules.admin.models import AuditLog, DemoFlag, IdempotencyRecord, Sequence


def audit(db: Session, actor_id: int | None, action: str, entity_type: str, entity_id: Any, summary: str,
          data: dict | None = None) -> None:
    db.add(AuditLog(actor_user_id=actor_id, action=action, entity_type=entity_type,
                    entity_id=str(entity_id) if entity_id is not None else None, summary=summary,
                    data=json.loads(json.dumps(data, default=_json_default)) if data else None))


def next_code(db: Session, prefix: str, year: int | None = None, width: int = 5) -> str:
    year = year or utcnow().year
    name = f"{prefix}-{year}"
    stmt = insert(Sequence).values(name=name, value=1).on_conflict_do_update(
        index_elements=[Sequence.name], set_={"value": Sequence.value + 1}
    ).returning(Sequence.value)
    value = db.execute(stmt).scalar_one()
    return f"{prefix}-{year}-{value:0{width}d}"


def request_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=_json_default).encode()).hexdigest()


def idempotent(db: Session, scope: str, key: str | None, payload: Any, fn: Callable[[], Any]) -> Any:
    """Exécute fn() au plus une fois par (scope, clé).

    - Même clé + même requête → réponse enregistrée renvoyée, aucun nouvel effet.
    - Même clé + requête différente → 409.
    La réservation de la clé se fait par INSERT … ON CONFLICT DO NOTHING dans la même transaction
    que l'effet : deux requêtes concurrentes ne peuvent pas toutes deux réussir.
    """
    if not key:
        return fn()
    h = request_hash(payload)
    ins = insert(IdempotencyRecord).values(scope=scope, key=key, request_hash=h, response=None) \
        .on_conflict_do_nothing(index_elements=["scope", "key"]).returning(IdempotencyRecord.id)
    new_id = db.execute(ins).scalar_one_or_none()
    if new_id is None:
        rec = db.execute(
            select(IdempotencyRecord).where(IdempotencyRecord.scope == scope, IdempotencyRecord.key == key)
            .with_for_update()
        ).scalar_one()
        if rec.request_hash != h:
            raise Conflict("IDEMPOTENCE_CONFLIT",
                           "Cette clé d'idempotence a déjà servi pour une requête différente")
        return {"_rejeu": True, **(rec.response or {})}
    result = fn()
    rec = db.get(IdempotencyRecord, new_id)
    rec.response = json.loads(json.dumps(result, default=_json_default))
    return result


def get_flag(db: Session, name: str, default: str = "") -> str:
    f = db.get(DemoFlag, name)
    return f.value if f else default


def set_flag(db: Session, name: str, value: str) -> None:
    stmt = insert(DemoFlag).values(name=name, value=value, updated_at=utcnow()).on_conflict_do_update(
        index_elements=[DemoFlag.name], set_={"value": value, "updated_at": utcnow()})
    db.execute(stmt)


def iso(dt: datetime | None) -> str | None:
    return dt.isoformat() if dt else None
