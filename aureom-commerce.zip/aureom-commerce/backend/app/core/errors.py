"""Erreurs métier : code stable + message en français."""
from __future__ import annotations

from typing import Any


class DomainError(Exception):
    status_code = 400

    def __init__(self, code: str, message: str, status_code: int | None = None, **details: Any):
        super().__init__(message)
        self.code = code
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.details = details

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message, "details": self.details}


class NotFound(DomainError):
    status_code = 404

    def __init__(self, what: str, ident: Any = None):
        super().__init__("INTROUVABLE", f"{what} introuvable" + (f" ({ident})" if ident is not None else ""))


class Forbidden(DomainError):
    status_code = 403

    def __init__(self, message: str = "Action non autorisée pour votre rôle", **details: Any):
        super().__init__("NON_AUTORISE", message, **details)


class Conflict(DomainError):
    status_code = 409


def require(cond: bool, code: str, message: str, **details: Any) -> None:
    if not cond:
        raise DomainError(code, message, **details)
