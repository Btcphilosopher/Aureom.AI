"""Unités et conversions exactes (Decimal).

- Unités de mesure : conversion uniquement à l'intérieur d'une même dimension (masse, volume…).
- Conditionnements : pièce, paquet, carton, palette — exprimés en quantité d'unité de base.
  Une unité de comptage (pièce) n'accepte pas de quantité fractionnaire.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from app.core.errors import DomainError

QTY_PLACES = Decimal("0.001")


@dataclass(frozen=True)
class UnitDef:
    code: str
    label: str
    dimension: str  # COMPTAGE, MASSE, VOLUME, LONGUEUR
    factor: Decimal  # facteur vers l'unité de référence de la dimension
    integer_only: bool = False


UNITS: dict[str, UnitDef] = {
    "PCE": UnitDef("PCE", "pièce", "COMPTAGE", Decimal(1), True),
    "G": UnitDef("G", "gramme", "MASSE", Decimal("0.001")),
    "KG": UnitDef("KG", "kilogramme", "MASSE", Decimal(1)),
    "ML": UnitDef("ML", "millilitre", "VOLUME", Decimal("0.001")),
    "CL": UnitDef("CL", "centilitre", "VOLUME", Decimal("0.01")),
    "L": UnitDef("L", "litre", "VOLUME", Decimal(1)),
    "M": UnitDef("M", "mètre", "LONGUEUR", Decimal(1)),
    "CM": UnitDef("CM", "centimètre", "LONGUEUR", Decimal("0.01")),
}

PACKAGING_LEVELS = ("PIECE", "PAQUET", "CARTON", "PALETTE")
PACKAGING_LABELS = {"PIECE": "pièce", "PAQUET": "paquet", "CARTON": "carton", "PALETTE": "palette"}


def q(value) -> Decimal:
    return Decimal(str(value)).quantize(QTY_PLACES)


def convert(value: Decimal, from_unit: str, to_unit: str) -> Decimal:
    try:
        a, b = UNITS[from_unit], UNITS[to_unit]
    except KeyError as e:
        raise DomainError("UNITE_INCONNUE", f"Unité inconnue : {e.args[0]}") from None
    if a.dimension != b.dimension:
        raise DomainError(
            "CONVERSION_IMPOSSIBLE",
            f"Conversion impossible de « {a.label} » vers « {b.label} » (dimensions différentes)",
        )
    result = Decimal(value) * a.factor / b.factor
    return check_quantity(result, to_unit)


def check_quantity(value: Decimal, unit: str) -> Decimal:
    u = UNITS.get(unit)
    if u is None:
        raise DomainError("UNITE_INCONNUE", f"Unité inconnue : {unit}")
    value = Decimal(value)
    if u.integer_only and value != value.to_integral_value():
        raise DomainError(
            "QUANTITE_FRACTIONNAIRE",
            f"La quantité {value} n'est pas un nombre entier de {u.label}s",
        )
    if value.quantize(QTY_PLACES) != value:
        raise DomainError("PRECISION_EXCESSIVE", f"Précision maximale : 0,001 {u.label}")
    return value.quantize(QTY_PLACES)


def packs_to_base(pack_qty: Decimal, qty_in_base: Decimal, base_unit: str) -> Decimal:
    """Quantité de conditionnements → quantité en unité de base (ex. 3 cartons de 24 → 72 pièces)."""
    return check_quantity(Decimal(pack_qty) * Decimal(qty_in_base), base_unit)


def base_to_packs(base_qty: Decimal, qty_in_base: Decimal) -> tuple[int, Decimal]:
    """Décomposition : (nombre de conditionnements complets, reliquat en unité de base)."""
    full = int(Decimal(base_qty) // Decimal(qty_in_base))
    return full, (Decimal(base_qty) - full * Decimal(qty_in_base)).quantize(QTY_PLACES)


def round_up_to_pack(base_qty: Decimal, qty_in_base: Decimal) -> int:
    """Nombre minimal de conditionnements couvrant la quantité demandée (arrondi supérieur)."""
    base_qty, qty_in_base = Decimal(base_qty), Decimal(qty_in_base)
    n = int(base_qty // qty_in_base)
    if n * qty_in_base < base_qty:
        n += 1
    return n


def format_qty(value: Decimal, unit: str) -> str:
    u = UNITS.get(unit)
    v = Decimal(value)
    if u and u.integer_only:
        s = str(int(v))
    else:
        s = f"{v.normalize():f}".replace(".", ",")
    label = u.label if u else unit
    if u and u.integer_only and abs(v) > 1:
        label += "s"
    return f"{s} {label}"
