"""Stockage objet protégé.

- `local` : répertoire hors de la racine web, fichiers nommés par empreinte SHA-256, servis
  uniquement par une route authentifiée.
- `s3` : tout service compatible S3 (ex. SeaweedFS en démonstration), bucket privé.
L'empreinte calculée ici permet de vérifier qu'un fichier correspond à une empreinte publiée ;
elle ne dit rien de l'authenticité de son contenu.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.errors import DomainError
from app.modules.admin.models import StoredObject

MAX_BYTES = 20 * 1024 * 1024
ALLOWED_TYPES = {"application/pdf", "image/png", "image/jpeg", "text/plain", "application/json", "text/csv",
                 "application/xml", "text/html"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class LocalStorage:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, key: str, data: bytes) -> None:
        p = self.root / key[:2] / key
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_bytes(data)
            p.chmod(0o640)

    def get(self, key: str) -> bytes:
        return (self.root / key[:2] / key).read_bytes()


class S3Storage:  # pragma: no cover - dépend d'un service externe
    def __init__(self):
        import boto3  # dépendance optionnelle

        s = get_settings()
        self.bucket = s.s3_bucket
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint, aws_access_key_id=s.s3_access_key,
                                   aws_secret_access_key=s.s3_secret_key, region_name="us-east-1")
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:
            self.client.create_bucket(Bucket=self.bucket)  # bucket privé (aucune politique publique)

    def put(self, key: str, data: bytes) -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data)

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()


def backend():
    s = get_settings()
    return S3Storage() if s.storage_backend == "s3" else LocalStorage(s.storage_path)


def store(db: Session, data: bytes, name: str, media_type: str, user_id: int | None,
          classification: str = "INTERNE") -> StoredObject:
    if len(data) > MAX_BYTES:
        raise DomainError("FICHIER_TROP_VOLUMINEUX", "Fichier limité à 20 Mo")
    if media_type not in ALLOWED_TYPES:
        raise DomainError("TYPE_NON_ACCEPTE", f"Type de fichier non accepté : {media_type}")
    digest = sha256_bytes(data)
    backend().put(digest, data)
    obj = StoredObject(sha256=digest, size_bytes=len(data), media_type=media_type, original_name=name[:255],
                       storage_key=digest, classification=classification, uploaded_by=user_id)
    db.add(obj)
    db.flush()
    return obj


def read(obj: StoredObject) -> bytes:
    data = backend().get(obj.storage_key)
    if sha256_bytes(data) != obj.sha256:
        raise DomainError("INTEGRITE_FICHIER", "Le fichier stocké ne correspond plus à son empreinte", 500)
    return data
