"""Types de colonnes communs."""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime, Identity, Numeric, func
from sqlalchemy.orm import Mapped, mapped_column

Qty = Numeric(14, 3)  # quantité en unité de base, 3 décimales
Cost = Numeric(16, 4)  # coût unitaire en centimes avec 4 décimales (valorisation)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def pk() -> Mapped[int]:
    return mapped_column(BigInteger, Identity(always=False), primary_key=True)


def created_at() -> Mapped[datetime]:
    return mapped_column(DateTime(timezone=True), server_default=func.now(), default=utcnow, nullable=False)


def ts(nullable: bool = True) -> Mapped[datetime | None]:
    return mapped_column(DateTime(timezone=True), nullable=nullable)


ZERO = Decimal("0.000")
