"""Sérialisation simple des entités (colonnes uniquement), Decimal → chaîne, dates ISO 8601."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import inspect

HIDDEN = {"password_hash", "token_hash", "details_salt", "pickup_code_hash"}


def val(v: Any) -> Any:
    if isinstance(v, Decimal):
        return format(v.normalize(), "f") if v == v.to_integral_value() else format(v, "f")
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def row(obj, *extra: str, exclude: set[str] | None = None) -> dict:
    if obj is None:
        return None
    out = {}
    for c in inspect(obj).mapper.column_attrs:
        if c.key in HIDDEN or (exclude and c.key in exclude):
            continue
        out[c.key] = val(getattr(obj, c.key))
    for e in extra:
        v = getattr(obj, e)
        out[e] = [row(x) for x in v] if isinstance(v, list) else row(v) if hasattr(v, "__table__") else val(v)
    return out


def rows(objs, *extra: str) -> list[dict]:
    return [row(o, *extra) for o in objs]


def deep(v: Any) -> Any:
    if isinstance(v, dict):
        return {k: deep(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [deep(x) for x in v]
    return val(v)
