"""Montants en centimes entiers (int) ; calculs intermédiaires en Decimal, arrondi au demi supérieur.

Les taux de taxe sont exprimés en points de base (2000 = 20,00 %) et proviennent de la
configuration (table tax_rates), jamais de constantes du code.
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

BP = Decimal(10000)


def round_cents(value: Decimal) -> int:
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def line_amount(unit_cents: int, quantity: Decimal) -> int:
    """Montant d'une ligne = prix unitaire × quantité (quantité éventuellement décimale, ex. 1,250 kg)."""
    return round_cents(Decimal(unit_cents) * Decimal(quantity))


def apply_discount_bp(amount_cents: int, discount_bp: int) -> tuple[int, int]:
    """Retourne (montant_remisé, remise). Remise arrondie au centime."""
    if not 0 <= discount_bp <= 10000:
        raise ValueError("remise hors bornes")
    discount = round_cents(Decimal(amount_cents) * Decimal(discount_bp) / BP)
    return amount_cents - discount, discount


def split_ttc(ttc_cents: int, rate_bp: int) -> tuple[int, int]:
    """Décompose un montant TTC en (HT, taxe). HT arrondi, taxe = TTC − HT (somme exacte)."""
    ht = round_cents(Decimal(ttc_cents) * BP / (BP + Decimal(rate_bp)))
    return ht, ttc_cents - ht


def ttc_from_ht(ht_cents: int, rate_bp: int) -> tuple[int, int]:
    tax = round_cents(Decimal(ht_cents) * Decimal(rate_bp) / BP)
    return ht_cents + tax, tax


def allocate_proportionally(total_cents: int, weights: list[int]) -> list[int]:
    """Répartit un montant entier selon des poids, sans perte de centime (méthode du plus fort reste)."""
    if total_cents == 0 or not weights:
        return [0 for _ in weights]
    s = sum(weights)
    if s == 0:
        return [0 for _ in weights]
    raw = [Decimal(total_cents) * Decimal(w) / Decimal(s) for w in weights]
    floors = [int(r) for r in raw]
    rest = total_cents - sum(floors)
    order = sorted(range(len(raw)), key=lambda i: raw[i] - floors[i], reverse=True)
    for i in order[:rest]:
        floors[i] += 1
    return floors


NBSP = " "
NNBSP = " "


def format_eur(cents: int) -> str:
    """Format français : 1 234,56 € (espace fine insécable pour les milliers)."""
    sign = "-" if cents < 0 else ""
    cents = abs(int(cents))
    euros, rest = divmod(cents, 100)
    groups = f"{euros:,}".replace(",", NNBSP)
    return f"{sign}{groups},{rest:02d}{NBSP}€"


def format_rate(rate_bp: int) -> str:
    v = Decimal(rate_bp) / Decimal(100)
    s = f"{v.normalize():f}".replace(".", ",")
    return f"{s}{NBSP}%"
