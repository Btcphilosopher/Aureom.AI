"""Authentification par jeton opaque (haché en base), rôles et permissions."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from dataclasses import dataclass, field
from datetime import timedelta

from fastapi import Depends, Header, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.core.errors import DomainError, Forbidden
from app.core.types import utcnow
from app.db import get_db

# --- Permissions -----------------------------------------------------------------------------
PERMISSIONS: dict[str, str] = {
    "catalog.read": "Consulter le catalogue",
    "catalog.write": "Modifier le catalogue",
    "price.write": "Publier des prix",
    "stock.read": "Consulter les stocks",
    "stock.move": "Enregistrer des mouvements courants",
    "stock.correct": "Corriger un mouvement / valider un inventaire",
    "stock.transfer": "Transférer entre sites",
    "purchase.read": "Consulter les achats",
    "purchase.write": "Préparer des achats",
    "purchase.approve": "Approuver des achats",
    "receipt.write": "Réceptionner",
    "quality.inspect": "Contrôler la qualité / statuer sur un retour",
    "pos.sell": "Vendre en caisse",
    "pos.discount": "Accorder une remise",
    "pos.void": "Annuler une ligne ou un ticket",
    "pos.refund": "Rembourser",
    "pos.session": "Ouvrir / clôturer une session de caisse",
    "order.read": "Consulter les commandes",
    "order.write": "Créer / valider des commandes",
    "order.fulfil": "Préparer, expédier, remettre",
    "customer.read": "Consulter les clients (sans coordonnées)",
    "customer.pii": "Voir les coordonnées des clients",
    "customer.write": "Modifier les clients et consentements",
    "trace.read": "Consulter la traçabilité",
    "trace.write": "Déclarer des événements de traçabilité",
    "trace.verify": "Enregistrer une vérification indépendante",
    "ledger.admin": "Administrer le registre (clés, réconciliation)",
    "recall.manage": "Gérer les rappels",
    "return.manage": "Gérer les retours",
    "iot.read": "Consulter les équipements",
    "iot.ingest": "Transmettre des observations (compte d'équipement)",
    "automation.read": "Consulter alertes et propositions",
    "automation.approve": "Approuver des propositions automatiques",
    "analytics.read": "Consulter les analyses",
    "admin.users": "Gérer les utilisateurs",
    "admin.demo": "Réinitialiser la démonstration / injecter des pannes",
}

ALL = set(PERMISSIONS)
ROLE_PERMISSIONS: dict[str, set[str]] = {
    "admin": ALL,
    "directeur": ALL - {"admin.users", "iot.ingest"},
    "responsable_magasin": {
        "catalog.read", "stock.read", "stock.move", "stock.correct", "stock.transfer", "purchase.read",
        "receipt.write", "pos.sell", "pos.discount", "pos.void", "pos.refund", "pos.session", "order.read",
        "order.write", "order.fulfil", "customer.read", "customer.pii", "customer.write", "trace.read",
        "return.manage", "quality.inspect", "iot.read", "automation.read", "automation.approve", "analytics.read",
        "recall.manage",
    },
    "caissier": {"catalog.read", "stock.read", "pos.sell", "pos.discount", "pos.session", "order.read",
                 "order.fulfil", "customer.read", "customer.write", "return.manage"},
    "preparateur": {"catalog.read", "stock.read", "stock.move", "order.read", "order.fulfil", "receipt.write",
                    "stock.transfer", "iot.read"},
    "acheteur": {"catalog.read", "catalog.write", "stock.read", "purchase.read", "purchase.write",
                 "automation.read", "analytics.read", "trace.read"},
    "responsable_achats": {"catalog.read", "catalog.write", "price.write", "stock.read", "purchase.read",
                           "purchase.write", "purchase.approve", "automation.read", "automation.approve",
                           "analytics.read", "trace.read"},
    "qualite": {"catalog.read", "stock.read", "stock.move", "quality.inspect", "trace.read", "trace.write",
                "trace.verify", "recall.manage", "return.manage", "iot.read", "automation.read", "automation.approve",
                "purchase.read"},
    "analyste": {"catalog.read", "stock.read", "purchase.read", "order.read", "trace.read", "automation.read",
                 "analytics.read", "iot.read"},
    "equipement": {"iot.ingest"},
}


# --- Mots de passe (scrypt, bibliothèque standard) ---------------------------------------------
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(password: str, stored: str) -> bool:
    try:
        _, s, h = stored.split("$")
        dk = hashlib.scrypt(password.encode(), salt=base64.b64decode(s), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(dk, base64.b64decode(h))
    except Exception:
        return False


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


@dataclass
class CurrentUser:
    id: int
    username: str
    full_name: str
    roles: list[str]
    site_ids: list[int] = field(default_factory=list)  # vide = tous les sites

    @property
    def permissions(self) -> set[str]:
        perms: set[str] = set()
        for r in self.roles:
            perms |= ROLE_PERMISSIONS.get(r, set())
        return perms

    def has(self, perm: str) -> bool:
        return perm in self.permissions

    def check_site(self, site_id: int | None) -> None:
        if site_id is not None and self.site_ids and site_id not in self.site_ids:
            raise Forbidden("Ce site n'est pas dans votre périmètre", site_id=site_id)


def issue_token(db: Session, user_id: int) -> str:
    from app.modules.admin.models import ApiToken

    token = secrets.token_urlsafe(32)
    db.add(ApiToken(user_id=user_id, token_hash=_hash_token(token),
                    expires_at=utcnow() + timedelta(hours=get_settings().token_ttl_hours)))
    return token


def user_from_token(db: Session, token: str) -> CurrentUser:
    from app.modules.admin.models import ApiToken, User

    row = db.execute(
        select(ApiToken, User).join(User, User.id == ApiToken.user_id).where(ApiToken.token_hash == _hash_token(token))
    ).first()
    if not row:
        raise DomainError("AUTH_REQUISE", "Jeton invalide", status_code=401)
    tok, user = row
    if tok.revoked_at is not None or tok.expires_at < utcnow() or not user.active:
        raise DomainError("AUTH_EXPIREE", "Session expirée ou révoquée", status_code=401)
    return CurrentUser(user.id, user.username, user.full_name, [r.role_code for r in user.roles],
                       [s.site_id for s in user.sites])


def current_user(
    authorization: str | None = Header(default=None), db: Session = Depends(get_db)
) -> CurrentUser:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise DomainError("AUTH_REQUISE", "Authentification requise", status_code=401)
    return user_from_token(db, authorization.split(" ", 1)[1].strip())


def require_perm(*perms: str):
    def dep(user: CurrentUser = Depends(current_user)) -> CurrentUser:
        missing = [p for p in perms if not user.has(p)]
        if missing:
            raise Forbidden(
                "Permission manquante : " + ", ".join(PERMISSIONS.get(p, p) for p in missing), permissions=missing
            )
        return user

    return dep


def ws_user(db: Session, token: str | None = Query(default=None)) -> CurrentUser:
    if not token:
        raise DomainError("AUTH_REQUISE", "Jeton requis", status_code=401)
    return user_from_token(db, token)
