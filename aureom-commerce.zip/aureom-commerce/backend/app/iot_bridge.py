"""Adaptateur MQTT → observations (lecture seule).

Abonnement à aureom/<site>/<type>/<équipement>. Le broker (Mosquitto) authentifie les équipements et
restreint par ACL chaque équipement à son propre sujet ; le pont vérifie en plus que l'équipement est
enregistré et autorisé, et que le sujet correspond à son enregistrement.
Usage : python -m app.iot_bridge
"""
from __future__ import annotations

import json
import logging

import paho.mqtt.client as mqtt
from sqlalchemy import select

from app import models  # noqa: F401
from app.config import get_settings
from app.core.errors import DomainError
from app.db import SessionLocal
from app.modules.iot.models import Device
from app.modules.iot.service import ingest

logging.basicConfig(level=logging.INFO, format='{"t":"%(asctime)s","niveau":"%(levelname)s","msg":"%(message)s"}')
log = logging.getLogger("aureom.mqtt")


def handle(topic: str, raw: bytes) -> dict | None:
    parts = topic.split("/")
    if len(parts) != 4:
        log.warning("Sujet ignoré : %s", topic)
        return None
    _, site_code, kind, device_code = parts
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        log.warning("Message illisible sur %s", topic)
        return None
    with SessionLocal() as db:
        dev = db.scalar(select(Device).where(Device.code == device_code))
        if dev is None or dev.meta.get("topic") != topic:
            log.warning("Sujet non conforme à l'enregistrement de l'équipement : %s", topic)
            return None
        try:
            res = ingest(db, device_code, payload, "MQTT")
            db.commit()
            return res
        except DomainError as e:
            db.rollback()
            log.warning("Observation refusée (%s) : %s", device_code, e.message)
            return None


def main():
    s = get_settings()
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="aureom-bridge")
    if s.mqtt_password:
        client.username_pw_set(s.mqtt_username, s.mqtt_password)

    def on_connect(c, userdata, flags, reason_code, properties):
        log.info("Connecté au broker (%s)", reason_code)
        c.subscribe(f"{s.mqtt_topic_root}/+/+/+", qos=1)

    def on_message(c, userdata, msg):
        res = handle(msg.topic, msg.payload)
        if res:
            log.info("%s → %s", msg.topic, res)

    client.on_connect = on_connect
    client.on_message = on_message
    client.reconnect_delay_set(1, 30)
    client.connect(s.mqtt_host, s.mqtt_port, keepalive=30)
    client.loop_forever(retry_first_connection=True)


if __name__ == "__main__":
    main()
