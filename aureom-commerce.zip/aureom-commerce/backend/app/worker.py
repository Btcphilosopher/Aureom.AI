"""Traitements en arrière-plan : publication de la boîte d'envoi, réconciliation, règles, expirations.

Plusieurs instances peuvent tourner : la boîte d'envoi est consommée avec FOR UPDATE SKIP LOCKED et
les tâches périodiques sont protégées par des verrous consultatifs PostgreSQL.
Usage : python -m app.worker
"""
from __future__ import annotations

import logging
import signal
import time

from sqlalchemy import text

from app import models  # noqa: F401
from app.db import SessionLocal
from app.modules.automation import rules
from app.modules.ledger.adapters import LedgerError
from app.modules.orders.service import expire_reservations
from app.modules.traceability import service as trace

logging.basicConfig(level=logging.INFO, format='{"t":"%(asctime)s","niveau":"%(levelname)s","msg":"%(message)s"}')
log = logging.getLogger("aureom.worker")
RUNNING = True


def _stop(*_):
    global RUNNING
    RUNNING = False


def periodic(lock_id: int, fn, label: str):
    with SessionLocal() as db:
        got = db.execute(text("SELECT pg_try_advisory_lock(:k)"), {"k": lock_id}).scalar()
        if not got:
            return
        try:
            res = fn(db)
            db.commit()
            if res:
                log.info("%s : %s", label, res)
        except Exception as e:
            db.rollback()
            log.warning("%s en échec : %s", label, e)
        finally:
            db.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": lock_id})
            db.commit()


def ensure_key() -> bool:
    try:
        with SessionLocal() as db:
            trace.register_own_key(db)
            db.commit()
        return True
    except (LedgerError, Exception) as e:  # registre indisponible au démarrage : on réessaiera
        log.warning("Enregistrement de la clé publique différé : %s", e)
        return False


def main():
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    key_ok = ensure_key()
    last = {"reconc": 0.0, "rules": 0.0, "expire": 0.0}
    log.info("Worker démarré")
    while RUNNING:
        now = time.monotonic()
        if not key_ok:
            key_ok = ensure_key()
        try:
            stats = trace.process_outbox(limit=50)
            if any(stats.values()):
                log.info("Boîte d'envoi : %s", stats)
        except Exception as e:
            log.warning("Boîte d'envoi : %s", e)
        if now - last["reconc"] > 60:
            last["reconc"] = now
            try:
                r = trace.reconcile()
                log.info("Réconciliation : %s", r["resume"])
            except Exception as e:
                log.warning("Réconciliation : %s", e)
        if now - last["rules"] > 300:
            last["rules"] = now
            periodic(910001, rules.run_all, "Règles")
        if now - last["expire"] > 60:
            last["expire"] = now
            periodic(910002, expire_reservations, "Expiration des réservations")
        time.sleep(2)
    log.info("Worker arrêté proprement")


if __name__ == "__main__":
    main()
