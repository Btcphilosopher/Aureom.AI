"""Importe tous les modèles (métadonnées complètes pour Alembic et la création des tables)."""
from app.modules.admin import models as admin  # noqa: F401
from app.modules.catalog import models as catalog  # noqa: F401
from app.modules.inventory import models as inventory  # noqa: F401
from app.modules.purchasing import models as purchasing  # noqa: F401
from app.modules.customers import models as customers  # noqa: F401
from app.modules.payments import models as payments  # noqa: F401
from app.modules.pos import models as pos  # noqa: F401
from app.modules.orders import models as orders  # noqa: F401
from app.modules.aftersales import models as aftersales  # noqa: F401
from app.modules.traceability import models as traceability  # noqa: F401
from app.modules.iot import models as iot  # noqa: F401
from app.modules.automation import models as automation  # noqa: F401
from app.db import Base

metadata = Base.metadata
