"""Simulateur du système d'information d'un FOURNISSEUR membre du réseau.

Il possède sa propre clé Ed25519 et soumet ses événements via SA passerelle (en mode Fabric : la
passerelle de son organisation, avec son identité MSP). Il ne passe jamais par la base de Maison & Marché.
"""
from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.config import get_settings
from app.modules.ledger.adapters import FabricGatewayAdapter, LedgerError, SimulatedLedger
from app.modules.traceability.keys import FileKeyProvider
from app.modules.traceability.service import canonical, z

GATEWAYS = {"AtelierLumiereMSP": "AUREOM_GATEWAY_ATELIER_URL", "ConserverieValMSP": "AUREOM_GATEWAY_CONSERVERIE_URL"}
DEFAULT_URLS = {"AtelierLumiereMSP": "http://localhost:8801", "ConserverieValMSP": "http://localhost:8802"}


class SupplierNode:
    def __init__(self, msp_id: str, key_dir: str | None = None):
        import os

        s = get_settings()
        self.msp_id = msp_id
        key_dir = key_dir or str(Path(s.signing_key_path).parent)
        self.key_id = f"{msp_id.replace('MSP', '').lower()}-2026-01"
        self.signer = FileKeyProvider(str(Path(key_dir) / f"{self.key_id}.key"), self.key_id, create_if_missing=True)
        if s.ledger_mode == "fabric":
            url = os.environ.get(GATEWAYS[msp_id], DEFAULT_URLS[msp_id])
            self.ledger = FabricGatewayAdapter(base_url=url, token=os.environ.get("AUREOM_GATEWAY_SUPPLIER_TOKEN",
                                                                                  s.ledger_gateway_token), msp_id=msp_id)
        else:
            self.ledger = SimulatedLedger(msp_id=msp_id)

    def ensure_key(self) -> None:
        if self.ledger.get_key(self.key_id) is None:
            try:
                self.ledger.register_key(self.key_id, self.signer.public_key_b64(),
                                         datetime.now(timezone.utc) - timedelta(minutes=1))
            except LedgerError as e:
                if e.code != "KEY_EXISTS":
                    raise

    def emit(self, event_type: str, gtin: str, lot: str, occurred_at: datetime, *, previous: str | None = None,
             counterparty: str | None = None, location: str | None = None, evidence: list[dict] | None = None,
             details: dict | None = None) -> dict:
        eid = str(uuid.uuid4())
        env = {"schemaVersion": "1.0", "eventId": eid, "eventType": event_type, "issuerOrg": self.msp_id,
               "subject": {"kind": "LOT", "ref": f"gtin:{gtin}|lot:{lot}", "gtin": gtin, "lot": lot},
               "occurredAt": z(occurred_at), "declaredAt": z(datetime.now(timezone.utc)), "evidence": evidence or [],
               "signerKeyId": self.key_id}
        if previous:
            env["previousEventId"] = previous
        if counterparty:
            env["counterpartyOrg"] = counterparty
        if location:
            env["locationRef"] = location
        if details:
            env["detailsDigest"] = hashlib.sha256(canonical(details).encode()).hexdigest()
        s = canonical(env)
        res = self.ledger.submit(s, self.signer.sign(s.encode()))
        return {"eventId": eid, "txId": res.tx_id, "statut": res.status, "bloc": res.block_number}
