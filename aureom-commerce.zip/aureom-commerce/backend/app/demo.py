"""Démonstration reproductible « Maison & Marché » — 14 étapes, exécutées via l'API HTTP réelle.

Usage :
    python -m app.demo                 # registre simulé (ou AUREOM_LEDGER_MODE=fabric pour le réseau Fabric)
    python -m app.demo --sortie ./demo-sortie
Chaque étape vérifie ses résultats (assertions) et le journal complet est écrit dans le dossier de sortie.
"""
from __future__ import annotations

import json
import sys
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import func, select

from app.config import get_settings
from app.core.money import format_eur
from app.db import SessionLocal
from app.modules.inventory.models import StockMovement
from app.modules.traceability.models import LedgerOutbox
from app.seed import DEMO_PASSWORD, reset_schema, seed
from app.simulators.supplier import SupplierNode

LOG: list[str] = []


def say(msg: str = "") -> None:
    print(msg, flush=True)
    LOG.append(msg)


class Api:
    def __init__(self, client: TestClient):
        self.c = client
        self.tokens: dict[str, str] = {}

    def login(self, user: str) -> str:
        if user == "capteurs" and user not in self.tokens:
            self.tokens[user] = self.call("POST", "/api/admin/comptes-equipement/capteurs/jeton", "admin")["jeton"]
        if user not in self.tokens:
            r = self.c.post("/api/auth/connexion", json={"username": user, "password": DEMO_PASSWORD})
            assert r.status_code == 200, r.text
            self.tokens[user] = r.json()["jeton"]
        return self.tokens[user]

    def call(self, method: str, path: str, user: str, body=None, expect: int | tuple = 200, key: str | None = None,
             raw: bool = False, **kw):
        h = {"Authorization": f"Bearer {self.login(user)}"}
        if key:
            h["Idempotency-Key"] = key
        r = self.c.request(method, path, json=body, headers=h, **kw)
        exp = expect if isinstance(expect, tuple) else (expect,)
        assert r.status_code in exp, f"{method} {path} → {r.status_code} : {r.text[:500]}"
        return r if raw else r.json()


def wait_confirmed(api: Api, event_id: str, tries: int = 30) -> dict:
    for _ in range(tries):
        api.call("POST", "/api/tracabilite/registre/publier", "admin")
        ev = api.call("GET", f"/api/tracabilite/evenements/{event_id}", "admin")
        if ev["ledger_status"] in ("CONFIRME", "REJETE"):
            return ev
        time.sleep(1)
    return ev


def movements_count() -> int:
    with SessionLocal() as db:
        return db.scalar(select(func.count()).select_from(StockMovement))


def run(out_dir: Path) -> None:
    s = get_settings()
    out_dir.mkdir(parents=True, exist_ok=True)
    started = time.time()
    say("# Démonstration AUREOM COMMERCE — Maison & Marché (enseigne fictive)")
    say(f"Date d'exécution : {datetime.now(timezone.utc):%d/%m/%Y %H:%M} UTC · registre : {s.ledger_mode}")
    reset_schema()
    ids = seed()
    P, E = ids["sites"]["paris"], ids["sites"]["entrepot"]
    CV = ids["fournisseurs"]["conserverie"]
    V = ids["variantes"]
    from app.main import app

    with TestClient(app) as client:
        api = Api(client)
        api.call("POST", "/api/tracabilite/cles/enregistrer", "admin")
        conserverie = SupplierNode("ConserverieValMSP")
        conserverie.ensure_key()
        health = api.call("GET", "/api/tracabilite/registre/etat", "admin")
        say(f"Registre : {health['libelle']} — disponible : {health['sante'].get('disponible')}")

        # 1 ----------------------------------------------------------------------------------------------
        say("\n## 1. Création d'un produit et de ses conditionnements")
        gtin = "2002000000040"
        prod = api.call("POST", "/api/catalogue/articles", "achats", {
            "code": "MIEL-LAV", "name": "Miel de lavande 250 g", "family_code": "CONFITURES",
            "tax_regime_code": "TVA_FR_REDUIT", "base_unit": "PCE", "lot_tracked": True, "expiry_kind": "DDM",
            "brand": "Conserverie du Val", "description": "Miel de lavande, pot verre 250 g.",
            "variants": [{"sku": "MIEL-LAV-250", "label": "Miel de lavande 250 g", "gtin": gtin, "packagings": [
                {"level": "PIECE", "label": "Pot", "qty_in_base": 1, "gtin": gtin},
                {"level": "PAQUET", "label": "Paquet de 6", "qty_in_base": 6, "gtin": "12002000000047"},
                {"level": "CARTON", "label": "Carton de 24", "qty_in_base": 24, "gtin": "22002000000044"},
                {"level": "PALETTE", "label": "Palette de 60 cartons", "qty_in_base": 1440}]}]})
        miel = prod["variantes"][0]["id"]
        api.call("POST", "/api/catalogue/fournisseurs", "achats", {"variant_id": miel, "supplier_id": CV,
                 "supplier_ref": "CDV-MIEL-250", "purchase_packaging_level": "CARTON", "cost_cents_per_pack": 8640,
                 "lead_time_days": 4})
        for pl, amount, lvl in (("MAGASIN", 790, "PIECE"), ("WEB", 790, "PIECE"), ("PRO", 13900, "CARTON")):
            api.call("POST", "/api/catalogue/prix", "achats.resp", {"price_list_code": pl, "variant_id": miel,
                     "amount_cents": amount, "packaging_level": lvl,
                     "valid_from": (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()})
        conv = api.call("GET", f"/api/catalogue/conditionnements/{miel}/convertir?quantite=3&niveau=CARTON", "achats")
        bad = api.call("POST", "/api/catalogue/articles", "achats", {"code": "X", "name": "X", "family_code": "VRAC",
                       "tax_regime_code": "TVA_FR_REDUIT", "variants": [{"sku": "X1", "label": "X", "packagings": [
                           {"level": "PIECE", "qty_in_base": 1}, {"level": "CARTON", "qty_in_base": 10},
                           {"level": "PAQUET", "qty_in_base": 4}]}]}, expect=400)
        say(f"✔ Article MIEL-LAV-250 créé (pot / paquet 6 / carton 24 / palette 1 440). 3 cartons = {conv['affichage']}.")
        say(f"✔ Chaîne incohérente refusée : « {bad['message']} »")
        say(f"✔ Prix magasin {format_eur(790)} TTC, tarif pro {format_eur(13900)} HT le carton (TVA 5,5 % configurée).")

        # 2 ----------------------------------------------------------------------------------------------
        say("\n## 2. Commande fournisseur")
        prop = api.call("POST", "/api/achats/propositions", "achats", {"supplier_id": CV, "site_id": E,
                        "rationale": "Lancement du miel de lavande", "lines": [
                            {"variant_id": miel, "pack_qty": 10}, {"variant_id": V["CONF-ABR-370"], "base_qty": 100}]})
        denied = api.call("POST", f"/api/achats/propositions/{prop['id']}/decision", "achats",
                          {"approve": True}, expect=403)
        dec = api.call("POST", f"/api/achats/propositions/{prop['id']}/decision", "achats.resp",
                       {"approve": True, "note": "Budget lancement validé"})
        po = dec["commande"]
        conf_line = next(l for l in po["lines"] if l["variant_id"] == V["CONF-ABR-370"])
        say(f"✔ Proposition {prop['code']} : 100 pots de confiture arrondis à {conf_line['pack_qty']} cartons "
            f"({conf_line['base_qty']} pots). Total {format_eur(prop['total_cents'])} HT.")
        say(f"✔ Approbation par l'acheteur refusée ({denied['code']}) ; approuvée par la responsable des achats.")
        say(f"✔ Commande fournisseur {po['code']} émise (envoi simulé), livraison prévue le "
            f"{date.fromisoformat(po['expected_on']):%d/%m/%Y}.")

        # 3 ----------------------------------------------------------------------------------------------
        say("\n## 3. Réception d'un lot")
        lot_code = "CV-MIEL-2611" if s.ledger_mode != "fabric" else f"CV-MIEL-{uuid.uuid4().hex[:4].upper()}"
        made = datetime.now(timezone.utc) - timedelta(days=3)
        e1 = conserverie.emit("LOT_CREATED", gtin, lot_code, made, location="2000000002010")
        e2 = conserverie.emit("SUPPLIER_SHIPMENT", gtin, lot_code, datetime.now(timezone.utc) - timedelta(hours=20),
                              previous=e1["eventId"], counterparty="MaisonMarcheMSP", location="2000000002010",
                              details={"bl": "BL-CDV-77812", "cartons": 10})
        say(f"✔ Le fournisseur a publié depuis SON nœud : création du lot ({e1['statut']}, tx {e1['txId'][:16]}…) puis "
            f"expédition ({e2['statut']}).")
        cert = b"%PDF-1.4\n% Certificat d'analyse (DEMONSTRATION) lot CV-MIEL-2611 - Conserverie du Val\n%%EOF"
        doc = client.post("/api/achats/documents", headers={"Authorization": f"Bearer {api.login('prepa.orleans')}"},
                          data={"supplier_id": str(CV), "kind": "CERTIFICAT_ANALYSE", "claimed_issuer": "Laboratoire Exemple",
                                "claimed_reference": "LAB-2026-4412"},
                          files={"file": ("certificat.pdf", cert, "application/pdf")}).json()
        miel_line = next(l for l in po["lines"] if l["variant_id"] == miel)
        rec = api.call("POST", f"/api/achats/commandes/{po['id']}/receptions", "prepa.orleans", {
            "delivery_note_ref": "BL-CDV-77812", "carrier": "Transports simulés",
            "supplier_shipment_event_id": e2["eventId"], "document_ids": [doc["id"]],
            "lines": [{"order_line_id": miel_line["id"], "received_packs": 9, "damaged_qty": 6, "lot_code": lot_code,
                       "expires_on": (date.today() + timedelta(days=700)).isoformat(),
                       "manufactured_on": made.date().isoformat(), "inspection_result": "CONFORME"},
                      {"order_line_id": conf_line["id"], "received_packs": conf_line["pack_qty"], "lot_code": "CV-2705-C",
                       "expires_on": (date.today() + timedelta(days=330)).isoformat()}]})
        say(f"✔ Réception {rec['reception']['code']} : 9 cartons sur 10 (livraison partielle), 6 pots endommagés mis "
            f"en quarantaine, statut commande « {rec['commande']['status']} ».")
        say(f"✔ Certificat déposé : statut d'authenticité « {doc['authenticity_status']} » (non présumé authentique).")
        pos = api.call("GET", f"/api/stocks/positions?site_id={E}", "admin")
        pm = next(p for p in pos if p["variant_id"] == miel)
        say(f"✔ Stock entrepôt miel : physique {pm['physique']}, vendable {pm['vendable']}, attendu {pm['attendu']} "
            f"(reliquat 1 carton).")

        # 4 ----------------------------------------------------------------------------------------------
        say("\n## 4. Publication d'un événement signé")
        lots = api.call("GET", f"/api/stocks/lots?variant_id={miel}", "admin")
        lot_id = lots[0]["id"]
        events = api.call("GET", f"/api/tracabilite/evenements?lot_id={lot_id}", "admin")
        receipt_ev = next(e for e in events if e["event_type"] == "RECEIPT")
        say(f"Avant publication : registre « {receipt_ev['ledger_status']} » (opération locale déjà finalisée).")
        t0 = time.time()
        ev = wait_confirmed(api, receipt_ev["id"])
        assert ev["ledger_status"] == "CONFIRME", ev
        say(f"✔ Événement RECEIPT {ev['id']} signé par la clé « {ev['signer_key_id']} », confirmé : transaction "
            f"{(ev['ledger_tx_id'] or '')[:20]}…, bloc {ev['ledger_block']} ({time.time() - t0:.1f} s).")
        say(f"  Précédent (expédition fournisseur) : {ev['previous_event_id']}")
        api.call("POST", f"/api/tracabilite/evenements/{ev['id']}/verifications", "qualite", {
            "method": "CONTROLE_PHYSIQUE", "verifier_name": "Nadia Roussel", "verifier_org": "Maison & Marché — Qualité",
            "result": "CONFORME", "performed_at": datetime.now(timezone.utc).isoformat(),
            "notes": "Comptage contradictoire de 3 cartons, étiquetage du lot conforme au bon de livraison."})
        ev = api.call("GET", f"/api/tracabilite/evenements/{ev['id']}", "admin")
        for n in ev["niveaux_de_preuve"]:
            say(f"  {'✔' if n['atteint'] else '✘'} {n['libelle']} — {n['explication']}")

        # 5 ----------------------------------------------------------------------------------------------
        say("\n## 5. Transfert vers un magasin")
        tr = api.call("POST", "/api/stocks/transferts", "prepa.orleans", {"from_site_id": E, "to_site_id": P,
                      "lines": [{"variant_id": miel, "quantity": 48, "lot_id": lot_id}]})
        api.call("POST", f"/api/stocks/transferts/{tr['id']}/expedier", "prepa.orleans")
        mid = api.call("GET", f"/api/stocks/positions?site_id={P}", "admin")
        say(f"✔ {tr['code']} expédié : attendu à Paris = "
            f"{next((p['attendu'] for p in mid if p['variant_id'] == miel), '48')} pots (en transit).")
        api.call("POST", f"/api/stocks/transferts/{tr['id']}/recevoir", "magasin.paris", {})
        pp = next(p for p in api.call("GET", f"/api/stocks/positions?site_id={P}", "admin") if p["variant_id"] == miel)
        say(f"✔ Reçu à Paris : vendable {pp['vendable']} pots. Transfert interne : PostgreSQL seulement (pas "
            f"d'événement sur le registre, une seule organisation concernée).")

        # 6 ----------------------------------------------------------------------------------------------
        say("\n## 6. Vente en caisse")
        cli = api.call("POST", "/api/clients", "caisse.paris", {"first_name": "Camille", "last_name": "Durand",
                       "email": "camille.durand@example.invalid", "loyalty": True, "email_marketing": False})
        reg = next(r for r in api.call("GET", "/api/caisse/postes", "caisse.paris") if r["site_id"] == P)
        sess = api.call("POST", "/api/caisse/sessions", "caisse.paris", {"register_id": reg["id"],
                        "opening_float_cents": 15000})
        sale = api.call("POST", "/api/caisse/ventes", "caisse.paris", {"session_id": sess["id"], "customer_id": cli["id"]},
                        key=f"vente-{uuid.uuid4()}")
        api.call("POST", f"/api/caisse/ventes/{sale['id']}/lignes", "caisse.paris", {"code": gtin, "quantity": 2})
        sale = api.call("POST", f"/api/caisse/ventes/{sale['id']}/lignes", "caisse.paris",
                        {"code": "2001000000012", "quantity": 1})
        bl = sale["lines"][-1]
        over = api.call("POST", f"/api/caisse/lignes/{bl['id']}/remise", "caisse.paris",
                        {"discount_bp": 2000, "reason": "Geste commercial"}, expect=403)
        sale = api.call("POST", f"/api/caisse/lignes/{bl['id']}/remise", "caisse.paris",
                        {"discount_bp": 1000, "reason": "Carton abîmé (exposition)"})
        total = sale["total_ttc_cents"]
        k_cash = f"pay-{uuid.uuid4()}"
        api.call("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                 {"method": "ESPECES", "amount_cents": 2000, "cash_tendered_cents": 2000}, key=k_cash)
        k_card = f"pay-{uuid.uuid4()}"
        p1 = api.call("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                      {"method": "CARTE_SIMULEE", "amount_cents": total - 2000, "card_token": "tok_sim_accepte"}, key=k_card)
        p2 = api.call("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                      {"method": "CARTE_SIMULEE", "amount_cents": total - 2000, "card_token": "tok_sim_accepte"}, key=k_card)
        assert p1["paiement"]["id"] == p2["paiement"]["id"]
        pan = api.call("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                       {"method": "CARTE_SIMULEE", "amount_cents": 100, "card_token": "4111 1111 1111 1111"},
                       key=f"pay-{uuid.uuid4()}", expect=400)
        before = movements_count()
        done = api.call("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")
        say(f"✔ Ticket {done['code']} : {format_eur(total)} TTC dont remise {format_eur(done['discount_cents'])} (10 % "
            f"autorisés au caissier ; 20 % refusés sans responsable : {over['code']}).")
        say(f"✔ Paiement partiel : 20,00 € espèces + {format_eur(total - 2000)} carte simulée ****"
            f"{p1['paiement']['card_last4']}. Requête carte rejouée avec la même clé : même paiement "
            f"(id {p2['paiement']['id']}), aucun double débit.")
        say(f"✔ Numéro de carte saisi refusé : {pan['code']}.")
        say(f"✔ Vente terminée puis {movements_count() - before} mouvement(s) de stock VENTE (étape distincte), "
            f"{done['loyalty_points']} point(s) fidélité.")
        (out_dir / "ticket-demo.txt").write_text(done["ticket"], encoding="utf-8")
        from app.modules.payments.service import build_event, sign_event
        from app.modules.payments.models import PaymentEvent

        with SessionLocal() as db:
            pe = db.scalar(select(PaymentEvent).where(PaymentEvent.payment_id == p1["paiement"]["id"],
                                                      PaymentEvent.event_type == "payment.captured"))
            replay = json.dumps(pe.payload).encode()
        rr = client.post("/api/paiements/webhook", content=replay, headers={"Sim-Signature": sign_event(replay)}).json()
        forged = client.post("/api/paiements/webhook", content=build_event("payment.captured", "simpay_x", 1),
                             headers={"Sim-Signature": "t=1,v1=00"})
        say(f"✔ Événement de capture rejoué : « {rr['statut']} » ; événement à signature falsifiée : HTTP {forged.status_code}.")

        # 7 ----------------------------------------------------------------------------------------------
        say("\n## 7. Commande en ligne avec réservation")
        web = api.call("POST", "/api/commandes", "admin", {"channel": "WEB", "fulfilment": "RETRAIT",
                       "source_site_id": P, "customer_id": cli["id"], "lines": [
                           {"variant_id": miel, "quantity": 3}, {"variant_id": V["HUILE-OLV-75"], "quantity": 1}]},
                       key=f"web-{uuid.uuid4()}")
        api.call("POST", f"/api/commandes/{web['id']}/valider", "admin")
        api.call("POST", f"/api/commandes/{web['id']}/reserver", "admin")
        pp = next(p for p in api.call("GET", f"/api/stocks/positions?site_id={P}", "admin") if p["variant_id"] == miel)
        greedy = api.call("POST", "/api/commandes", "admin", {"channel": "WEB", "fulfilment": "RETRAIT",
                          "source_site_id": P, "lines": [{"variant_id": miel, "quantity": int(float(pp["disponible"])) + 1}]})
        api.call("POST", f"/api/commandes/{greedy['id']}/valider", "admin")
        refused = api.call("POST", f"/api/commandes/{greedy['id']}/reserver", "admin", expect=409)
        pay = api.call("POST", f"/api/commandes/{web['id']}/paiements", "admin", {"method": "CARTE_SIMULEE",
                       "amount_cents": web["total_ttc_cents"], "card_token": "tok_sim_accepte"}, key=f"wp-{uuid.uuid4()}")
        say(f"✔ Commande {web['code']} réservée : miel à Paris physique {pp['physique']}, réservé {pp['reserve']}, "
            f"disponible {pp['disponible']}.")
        say(f"✔ Seconde commande dépassant le disponible : réservation refusée ({refused['code']}).")
        say(f"✔ Paiement capturé ({pay['commande']['payment_status']}) mais statut toujours « "
            f"{pay['commande']['statut_libelle']} » : payé ≠ prêt.")

        # 8 ----------------------------------------------------------------------------------------------
        say("\n## 8. Préparation et retrait")
        o = api.call("POST", f"/api/commandes/{web['id']}/preparer", "prepa.paris")
        wrong = api.call("POST", f"/api/commandes/taches/{o['taches'][0]['id']}/prelever", "prepa.paris",
                         {"picked_qty": 1, "scanned_code": "2001000000012"}, expect=400)
        codes = {miel: gtin, V["HUILE-OLV-75"]: "2002000000026"}
        line_variant = {l["id"]: l["variant_id"] for l in o["lines"]}
        for t in o["taches"]:
            api.call("POST", f"/api/commandes/taches/{t['id']}/prelever", "prepa.paris",
                     {"picked_qty": t["quantity"], "scanned_code": codes[line_variant[t["order_line_id"]]]})
        ready = api.call("POST", f"/api/commandes/{web['id']}/prete", "prepa.paris")
        badcode = api.call("POST", f"/api/commandes/{web['id']}/remettre", "caisse.paris", {"pickup_code": "000000"},
                           expect=403)
        final = api.call("POST", f"/api/commandes/{web['id']}/remettre", "caisse.paris", {"pickup_code": ready["code_retrait"]})
        say(f"✔ Scan d'un mauvais article refusé ({wrong['code']}). {len(o['taches'])} prélèvement(s) FEFO confirmés par scan.")
        say(f"✔ Prête : code de retrait communiqué (simulé). Mauvais code refusé ({badcode['code']}). "
            f"Statut final « {final['statut_libelle']} ».")
        say("  Historique : " + " → ".join(h["to_status"] for h in final["historique"]))

        # 9 ----------------------------------------------------------------------------------------------
        say("\n## 9. Observation RFID dupliquée sans double mouvement")
        before = movements_count()
        epc = "3074257BF7194E4000000001"
        res = []
        for i in range(5):
            res.append(api.call("POST", "/api/equipements/observations", "capteurs", {"device_code": "RFID-PAR-SORTIE",
                       "payload": {"epc": epc, "rssi": -52 - i, "antenna": 1,
                                   "observed_at": (datetime.now(timezone.utc) + timedelta(seconds=i)).isoformat()}}))
        obs = api.call("GET", "/api/equipements/observations-rfid", "admin")[0]
        assert movements_count() == before
        say(f"✔ 5 lectures du même EPC → {sum(1 for r in res if not r['doublon'])} observation, {obs['read_count']} "
            f"lectures agrégées, 0 mouvement de stock.")
        say(f"✔ Statut « {obs['status']} » : {obs['suggestion']}")

        # 10 ---------------------------------------------------------------------------------------------
        say("\n## 10. Alerte de température simulée")
        base = datetime.now(timezone.utc) - timedelta(minutes=25)
        temps = [22.4, 23.1, 150.0, 27.5, 28.1, 28.6]
        for i, t in enumerate(temps):
            r = api.call("POST", "/api/equipements/observations", "capteurs", {"device_code": "TEMP-ENT-EPI", "payload": {
                "message_id": f"temp-{i}", "value": t, "unit": "CEL", "observed_at": (base + timedelta(minutes=5 * i)).isoformat()}})
            if t == 150.0:
                say(f"  Lecture 150 °C : qualité « {r['qualite']} » ({', '.join(r['indicateurs'])}) — ignorée pour la décision.")
        dup = api.call("POST", "/api/equipements/observations", "capteurs", {"device_code": "TEMP-ENT-EPI", "payload": {
            "message_id": "temp-5", "value": 28.6, "unit": "CEL"}})
        alerts = [a for a in api.call("GET", "/api/automatisations/alertes", "admin") if a["rule_code"] == "TEMPERATURE"]
        props = [p for p in api.call("GET", "/api/automatisations/propositions", "qualite") if p["kind"] == "QUARANTAINE"]
        say(f"✔ Alerte « {alerts[0]['title']} » : {alerts[0]['message']}")
        say(f"✔ Message MQTT/HTTP répété : doublon={dup['doublon']}. Proposition de quarantaine en attente de décision humaine.")
        d = api.call("POST", f"/api/automatisations/propositions/{props[0]['id']}/decision", "qualite",
                     {"approve": True, "note": "Contrôle visuel : pots exposés, analyse demandée"})
        say(f"✔ Décision de la responsable qualité : {d['statut']} ({d['reference']}).")

        # 11 ---------------------------------------------------------------------------------------------
        say("\n## 11. Retour avec inspection")
        sale_full = api.call("GET", f"/api/caisse/ventes/{sale['id']}", "caisse.paris")
        bline = next(l for l in sale_full["lines"] if l["sku"] == "BOUIL-17-INOX")
        pos_b = lambda: next(p for p in api.call("GET", f"/api/stocks/positions?site_id={P}", "admin")
                             if p["variant_id"] == V["BOUIL-17-INOX"])
        v0 = pos_b()["vendable"]
        ret = api.call("POST", "/api/retours", "caisse.paris", {"origin": "VENTE", "source_id": sale["id"], "site_id": P,
                       "lines": [{"line_id": bline["id"], "quantity": 1, "reason": "Ne correspond pas à l'usage"}]})
        refund = api.call("POST", f"/api/retours/{ret['id']}/remboursement", "magasin.paris",
                          {"session_id": sess["id"]}, key=f"rmb-{uuid.uuid4()}")
        v1 = pos_b()["vendable"]
        api.call("POST", f"/api/retours/lignes/{ret['lines'][0]['id']}/inspection", "magasin.paris",
                 {"condition": "OUVERT_COMPLET", "disposition": "REMISE_EN_VENTE", "notes": "Testé, complet"})
        v2 = pos_b()["vendable"]
        fid = api.call("GET", f"/api/clients/{cli['id']}", "magasin.paris")["fidelite"]
        say(f"✔ Retour {ret['code']} : remboursé {format_eur(refund['rembourse'])} ; vendable {v0} → {v1} après "
            f"remboursement (inchangé), → {v2} après inspection « ouvert, complet » + remise en vente.")
        say(f"✔ Fidélité : {refund['points_retires']} point(s) retiré(s), solde {fid['solde']}.")
        # Le remboursement a d'abord recrédité la carte, puis le solde en espèces : le tiroir contient
        # 150 € de fond + 20 € encaissés − la part remboursée en espèces. La caissière compte 165,80 €.
        close = api.call("POST", f"/api/caisse/sessions/{sess['id']}/cloture", "caisse.paris",
                         {"counted_cash_cents": 16580})
        say(f"✔ Clôture de caisse : espèces attendues {format_eur(close['expected_cash_cents'])}, comptées "
            f"{format_eur(close['counted_cash_cents'])}, écart {format_eur(close['difference_cents'])}.")

        # 12 ---------------------------------------------------------------------------------------------
        say("\n## 12. Rappel de lot")
        rc = api.call("POST", "/api/rappels", "qualite", {"lot_ids": [lot_id], "severity": "RAPPEL_CONSOMMATEURS",
                      "reason": "Signalement fournisseur : défaut d'opercule possible sur le lot CV-MIEL-2611"})
        api.call("POST", f"/api/rappels/{rc['id']}/journal", "qualite", {"kind": "COMMUNICATION", "channel": "EMAIL",
                 "audience": "clients identifiés", "content": "Message de rappel (simulé) envoyé", "count": 1})
        sell = api.call("POST", "/api/caisse/ventes", "caisse.paris", {"session_id": api.call(
            "POST", "/api/caisse/sessions", "caisse.paris", {"register_id": reg["id"], "opening_float_cents": 10000})["id"]})
        blocked = api.call("POST", f"/api/caisse/ventes/{sell['id']}/lignes", "caisse.paris",
                           {"code": gtin, "quantity": 1, "lot_code": lot_code}, expect=400)
        say(f"✔ Rappel {rc['code']} : stock bloqué {', '.join(f'{k} : {v}' for k, v in rc['impact']['stock_bloque'].items())} ; ventes {rc['impact']['ventes']}, "
            f"commandes {rc['impact']['commandes']}, clients identifiés {rc['impact']['clients_identifies']}.")
        for t in rc["taches"]:
            say(f"  • [{t['kind']}] {t['description']}" + (f" — certitude {t['confidence'].lower()}" if t["confidence"] else ""))
        say(f"✔ Vente d'un pot du lot rappelé refusée en caisse ({blocked['code']}).")

        # 13 ---------------------------------------------------------------------------------------------
        say("\n## 13. Indisponibilité puis réconciliation du registre")
        import os
        import subprocess

        real = s.ledger_mode == "fabric" and os.environ.get("AUREOM_DEMO_PANNE_REELLE") == "1"
        if real:  # coupure réelle : arrêt du conteneur de la passerelle de Maison & Marché
            subprocess.run(["docker", "stop", "gateway-maisonmarche"], check=True, capture_output=True)
            say("  (coupure RÉELLE : conteneur gateway-maisonmarche arrêté)")
        else:
            api.call("POST", "/api/admin/demo/panne-registre", "admin", {"actif": True})
        rec2 = api.call("POST", f"/api/achats/commandes/{po['id']}/receptions", "prepa.orleans", {
            "delivery_note_ref": "BL-CDV-77840", "lines": [{"order_line_id": miel_line["id"], "received_packs": 1,
                                                            "lot_code": "CV-MIEL-2612", "expires_on": (date.today() + timedelta(days=700)).isoformat()}]})
        pub = api.call("POST", "/api/tracabilite/registre/publier", "admin")
        pend = [e for e in api.call("GET", "/api/tracabilite/evenements", "admin") if e["ledger_status"] != "CONFIRME"]
        say(f"✔ Registre indisponible : la réception {rec2['reception']['code']} est finalisée localement (commande "
            f"« {rec2['commande']['status']} »). Publication : {pub}.")
        for e in pend[:4]:
            say(f"  {e['type_libelle']} {e['id'][:8]}… : registre « {e['ledger_status']} », tentatives "
                f"{e['publication']['attempts'] if e['publication'] else 0}, erreur « {e['ledger_error_code']} »")
        if real:
            subprocess.run(["docker", "start", "gateway-maisonmarche"], check=True, capture_output=True)
            for _ in range(60):
                if api.call("GET", "/api/tracabilite/registre/etat", "admin")["sante"].get("disponible"):
                    break
                time.sleep(1)
            say("  (passerelle redémarrée)")
        else:
            api.call("POST", "/api/admin/demo/panne-registre", "admin", {"actif": False})
        with SessionLocal() as db:  # avance l'échéance de reprise (sinon : attente de la temporisation exponentielle)
            for ob in db.scalars(select(LedgerOutbox).where(LedgerOutbox.status == "EN_ATTENTE")):
                ob.next_attempt_at = datetime.now(timezone.utc)
            db.commit()
        for _ in range(20):
            api.call("POST", "/api/tracabilite/registre/publier", "admin")
            left = [e for e in api.call("GET", "/api/tracabilite/evenements", "admin")
                    if e["ledger_status"] not in ("CONFIRME", "REJETE")]
            if not left:
                break
            time.sleep(1)
        recon = api.call("POST", "/api/tracabilite/registre/reconcilier", "admin")
        allev = api.call("GET", "/api/tracabilite/evenements", "admin")
        mine = [e for e in allev if e["origin"] == "LOCAL"]
        orphans = [e for e in allev if e["origin"] == "ORPHELIN"]
        say(f"✔ Retour du registre : {sum(1 for e in mine if e['ledger_status'] == 'CONFIRME')}/{len(mine)} "
            f"événements de cette exécution confirmés. Réconciliation : {recon['resume']}.")
        if orphans:
            say(f"  Dont {len(orphans)} anomalie(s) « orphelin » : événements de Maison & Marché laissés sur le registre "
                f"Fabric par des exécutions précédentes de la démo (la base locale a été réinitialisée, pas le "
                f"registre). C'est exactement le cas d'une restauration de sauvegarde : ils sont signalés et réimportés.")

        # 14 ---------------------------------------------------------------------------------------------
        say("\n## 14. Export d'un rapport de traçabilité")
        rep = api.call("GET", f"/api/tracabilite/lots/{lot_id}/rapport", "qualite")
        html = api.call("GET", f"/api/tracabilite/lots/{lot_id}/rapport?format=html", "qualite", raw=True).text
        csv_ = api.call("GET", f"/api/tracabilite/lots/{lot_id}/rapport?format=csv", "qualite", raw=True).text
        (out_dir / "rapport-tracabilite-miel.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), "utf-8")
        (out_dir / "rapport-tracabilite-miel.html").write_text(html, "utf-8")
        (out_dir / "rapport-tracabilite-miel.csv").write_text(csv_, "utf-8")
        say(f"✔ Rapport du lot {lot_code} : {len(rep['evenements'])} événements partagés (dont "
            f"{sum(1 for e in rep['evenements'] if e['origine'] == 'EXTERNE')} émis par le fournisseur), "
            f"{len(rep['mouvements'])} mouvements internes, {len(rep['destinations'])} destination(s).")
        say("  Fichiers : rapport-tracabilite-miel.json / .html / .csv")
        ind = api.call("GET", "/api/analyses/indicateurs", "analyste")
        say("\n## Indicateurs (extrait)")
        for i in ind["indicateurs"][:6]:
            say(f"  {i['libelle']} : {i.get('affichage', i['valeur'])}")
        say("  Lacunes : " + ("; ".join(ind["lacunes"]) or "aucune"))
    say(f"\nDémonstration terminée en {time.time() - started:.1f} s — toutes les vérifications ont réussi.")
    (out_dir / "journal-demo.md").write_text("\n".join(LOG) + "\n", encoding="utf-8")


if __name__ == "__main__":
    out = Path(sys.argv[sys.argv.index("--sortie") + 1]) if "--sortie" in sys.argv else Path("demo-sortie")
    run(out)
