"""Jeu de démonstration « Maison & Marché » (enseigne FICTIVE).

Les GTIN et GLN utilisent le préfixe GS1 « 2 » (diffusion restreinte, usage interne) afin de ne
correspondre à aucun produit ni lieu réel. Les noms de personnes et d'entreprises sont fictifs.
L'historique de ventes servant aux prévisions est SYNTHÉTIQUE et étiqueté comme tel.

Usage : python -m app.seed [--reset]
"""
from __future__ import annotations

import sys
from datetime import date, timedelta
from decimal import Decimal

import numpy as np
from sqlalchemy import text

from app import models  # noqa: F401
from app.core.security import hash_password
from app.core.types import utcnow
from app.db import Base, SessionLocal, get_engine
from app.modules.admin.models import Location, Organisation, Role, Site, User, UserRole, UserSite
from app.modules.automation.models import DemandHistory
from app.modules.automation.rules import ensure_rules
from app.modules.catalog import service as cat
from app.modules.catalog.models import Packaging, PriceList, ProductFamily, ProductSupplier, TaxRate, TaxRegime
from app.modules.inventory import service as inv
from app.modules.inventory.models import SerialUnit, StockPosition
from app.modules.iot.models import Device
from app.modules.pos.models import CashRegister

DEMO_PASSWORD = "demo-aureom-2026"


def g13(body12: str) -> str:
    return cat.gtin_with_check(body12)


def g14(indicator: str, body12: str) -> str:
    return cat.gtin_with_check(indicator + body12)


def reset_schema() -> None:
    eng = get_engine()
    with eng.begin() as c:
        c.execute(text("CREATE EXTENSION IF NOT EXISTS btree_gist"))
    Base.metadata.drop_all(eng)
    Base.metadata.create_all(eng)


def seed(with_history: bool = True) -> dict:
    db = SessionLocal()
    try:
        return _seed(db, with_history)
    finally:
        db.close()


def _seed(db, with_history: bool) -> dict:
    # --- Organisations --------------------------------------------------------------------------------
    mm = Organisation(code="MM", name="Maison & Marché", kind="ENSEIGNE", msp_id="MaisonMarcheMSP", is_self=True,
                      ledger_member=True, ledger_status="ADMISE", gln=g13("200000000001"), siret=None, city="Paris")
    al = Organisation(code="ATL", name="Atelier Lumière", kind="FOURNISSEUR", msp_id="AtelierLumiereMSP",
                      ledger_member=True, ledger_status="ADMISE", gln=g13("200000000101"), city="Limoges",
                      default_lead_time_days=6)
    cv = Organisation(code="CDV", name="Conserverie du Val", kind="FOURNISSEUR", msp_id="ConserverieValMSP",
                      ledger_member=True, ledger_status="ADMISE", gln=g13("200000000201"), city="Valence",
                      default_lead_time_days=4)
    cafe = Organisation(code="CDH", name="Café des Halles (client professionnel)", kind="CLIENT_PRO", city="Lyon")
    db.add_all([mm, al, cv, cafe])
    db.flush()

    # --- Sites et emplacements -------------------------------------------------------------------------
    def site(code, name, kind, city, gln, cc, ships, locs):
        s = Site(code=code, name=name, kind=kind, org_id=mm.id, gln=gln, city=city, allows_click_collect=cc,
                 ships_online=ships)
        db.add(s)
        db.flush()
        for lc, label, lk, sellable, tmin, tmax in locs:
            db.add(Location(site_id=s.id, code=lc, label=label, kind=lk, sellable=sellable, temp_min_c=tmin,
                            temp_max_c=tmax))
        db.flush()
        return s

    common = [("RECEP", "Zone de réception", "RECEPTION", False, None, None),
              ("PREPA", "Zone de préparation", "PREPARATION", True, None, None),
              ("QUAR", "Quarantaine", "QUARANTAINE", False, None, None),
              ("RETOURS", "Retours clients", "RETOURS", False, None, None)]
    ent = site("ENT-ORL", "Entrepôt Orléans-Saran", "ENTREPOT", "Saran", g13("200000000011"), False, True,
               [("STOCK-A", "Allée A — équipement", "STOCKAGE", True, None, None),
                ("STOCK-EPI", "Cellule épicerie (15–25 °C)", "STOCKAGE", True, Decimal(15), Decimal(25)),
                ("QUAI", "Quai d'expédition", "EXPEDITION", False, None, None)] + common)
    par = site("MAG-PAR", "Magasin Paris Oberkampf", "MAGASIN", "Paris", g13("200000000021"), True, False,
               [("RESERVE", "Réserve", "STOCKAGE", True, Decimal(10), Decimal(26)),
                ("SORTIE", "Portique de sortie", "EXPEDITION", False, None, None)] + common)
    lyo = site("MAG-LYO", "Magasin Lyon Croix-Rousse", "MAGASIN", "Lyon", g13("200000000031"), True, False,
               [("RESERVE", "Réserve", "STOCKAGE", True, None, None)] + common)

    # --- Rôles et utilisateurs -------------------------------------------------------------------------
    roles = [("admin", "Administrateur", 10000, 10**12), ("directeur", "Direction", 5000, 5_000_000),
             ("responsable_magasin", "Responsable de magasin", 3000, 0), ("caissier", "Caissier·ère", 1000, 0),
             ("preparateur", "Préparateur·rice", 0, 0), ("acheteur", "Acheteur·se", 0, 0),
             ("responsable_achats", "Responsable des achats", 0, 500_000), ("qualite", "Responsable qualité", 0, 0),
             ("analyste", "Analyste", 0, 0), ("equipement", "Compte d'équipement", 0, 0)]
    for code, label, disc, lim in roles:
        db.add(Role(code=code, label=label, max_discount_bp=disc, purchase_approval_limit_cents=lim))
    db.flush()
    users = {}
    for uname, full, rs, sites, service in [
        ("admin", "Admin Démo", ["admin"], [], False),
        ("direction", "Hélène Garnier", ["directeur"], [], False),
        ("magasin.paris", "Karim Benali", ["responsable_magasin"], [par.id], False),
        ("caisse.paris", "Léa Moreau", ["caissier"], [par.id], False),
        ("caisse.lyon", "Hugo Lambert", ["caissier"], [lyo.id], False),
        ("prepa.orleans", "Inès Fontaine", ["preparateur"], [ent.id], False),
        ("prepa.paris", "Tom Rivière", ["preparateur"], [par.id], False),
        ("achats", "Julien Perrin", ["acheteur"], [], False),
        ("achats.resp", "Sophie Lefèvre", ["responsable_achats"], [], False),
        ("qualite", "Nadia Roussel", ["qualite"], [], False),
        ("analyste", "Paul Mercier", ["analyste"], [], False),
        ("capteurs", "Passerelle équipements", ["equipement"], [], True),
    ]:
        u = User(username=uname, full_name=full, password_hash=hash_password(DEMO_PASSWORD), is_service=service)
        db.add(u)
        db.flush()
        for r in rs:
            db.add(UserRole(user_id=u.id, role_code=r))
        for s in sites:
            db.add(UserSite(user_id=u.id, site_id=s))
        users[uname] = u
    db.flush()

    # --- Taxes (configurées, sources à vérifier) ---------------------------------------------------------
    regimes = {}
    for code, label, bp in [("TVA_FR_NORMAL", "TVA taux normal", 2000), ("TVA_FR_INTERMEDIAIRE", "TVA taux intermédiaire", 1000),
                            ("TVA_FR_REDUIT", "TVA taux réduit", 550), ("TVA_FR_PARTICULIER", "TVA taux particulier", 210)]:
        r = TaxRegime(code=code, label=label)
        db.add(r)
        db.flush()
        db.add(TaxRate(regime_id=r.id, rate_bp=bp, valid_from=date(2014, 1, 1),
                       source_note="Configuration de démonstration — vérifier le CGI (art. 278 et suivants) avant usage"))
        regimes[code] = r
    db.flush()

    for code, name, parent in [("MAISON", "Équipement de la maison", None), ("CUISINE", "Cuisine", "MAISON"),
                               ("LUMINAIRE", "Luminaires", "MAISON"), ("EPICERIE", "Épicerie fine", None),
                               ("CONFITURES", "Confitures et miels", "EPICERIE"), ("HUILES", "Huiles", "EPICERIE"),
                               ("VRAC", "Vrac", "EPICERIE")]:
        db.add(ProductFamily(code=code, name=name,
                             parent_id=db.query(ProductFamily).filter_by(code=parent).one().id if parent else None))
        db.flush()

    for code, label, ch, ttc in [("MAGASIN", "Prix magasin (TTC)", "MAGASIN", True), ("WEB", "Prix en ligne (TTC)", "WEB", True),
                                 ("PRO", "Tarif professionnel (HT)", "PRO", False)]:
        db.add(PriceList(code=code, label=label, channel=ch, tax_inclusive=ttc))
    db.flush()

    # --- Catalogue ------------------------------------------------------------------------------------------
    start = utcnow() - timedelta(days=200)
    catalogue = [
        # code, nom, famille, régime, unité, lot, péremption, fournisseur, sku, gtin body, packs, prix mag, web, pro(HT, carton), coût/pack, niveau d'achat
        ("BOUIL-17", "Bouilloire inox 1,7 L", "CUISINE", "TVA_FR_NORMAL", "PCE", True, None, al, "BOUIL-17-INOX",
         "200100000001", [("PIECE", 1), ("CARTON", 4), ("PALETTE", 160)], 4990, 4790, ("CARTON", 13600), 8800, "CARTON"),
        ("LAMPE-LIN", "Lampe de table abat-jour lin", "LUMINAIRE", "TVA_FR_NORMAL", "PCE", True, None, al, "LAMPE-LIN-NAT",
         "200100000002", [("PIECE", 1), ("CARTON", 6)], 3900, 3900, ("CARTON", 16200), 10800, "CARTON"),
        ("POELE-28", "Poêle en fonte 28 cm", "CUISINE", "TVA_FR_NORMAL", "PCE", True, None, al, "POELE-28-FONTE",
         "200100000003", [("PIECE", 1), ("CARTON", 4), ("PALETTE", 120)], 5900, 5600, ("CARTON", 16800), 10400, "CARTON"),
        ("CONF-ABR", "Confiture d'abricot 370 g", "CONFITURES", "TVA_FR_REDUIT", "PCE", True, "DDM", cv, "CONF-ABR-370",
         "200200000001", [("PIECE", 1), ("PAQUET", 6), ("CARTON", 24), ("PALETTE", 960)], 490, 490, ("CARTON", 7920), 5040, "CARTON"),
        ("HUILE-75", "Huile d'olive vierge extra 75 cl", "HUILES", "TVA_FR_REDUIT", "PCE", True, "DDM", cv, "HUILE-OLV-75",
         "200200000002", [("PIECE", 1), ("CARTON", 6)], 1250, 1190, ("CARTON", 5400), 3900, "CARTON"),
        ("AMANDE-VRAC", "Amandes décortiquées (vrac)", "VRAC", "TVA_FR_REDUIT", "KG", True, "DDM", cv, "AMANDE-VRAC-KG",
         "200200000003", [("PIECE", 1), ("CARTON", 5)], 2490, 2490, ("CARTON", 9500), 6500, "CARTON"),
    ]
    variants = {}
    for (code, name, fam, reg, unit, lot, exp, sup, sku, gb, packs, pmag, pweb, (pro_lvl, pro_ht), cost, buy_lvl) in catalogue:
        pk_list = []
        for i, (lvl, q) in enumerate(packs):
            entry = {"level": lvl, "label": {"PIECE": "Pièce" if unit == "PCE" else "Kilogramme", "PAQUET": "Paquet",
                                             "CARTON": "Carton", "PALETTE": "Palette"}[lvl], "qty_in_base": q}
            if lvl == "PIECE":
                entry["gtin"] = g13(gb)
            else:
                entry["gtin"] = g14(str(i), gb)
            pk_list.append(entry)
        p = cat.create_product(db, {"code": code, "name": name, "family_code": fam, "tax_regime_code": reg,
                                    "base_unit": unit, "lot_tracked": lot, "expiry_kind": exp, "brand": sup.name,
                                    "description": f"{name} — gamme Maison & Marché (fictive).",
                                    "variants": [{"sku": sku, "label": name, "gtin": g13(gb), "packagings": pk_list}]},
                               users["admin"].id)
        v = p.variants[0]
        variants[sku] = v
        cat.set_price(db, "MAGASIN", v.id, pmag, start, users["admin"].id)
        cat.set_price(db, "WEB", v.id, pweb, start, users["admin"].id)
        cat.set_price(db, "PRO", v.id, pro_ht, start, users["admin"].id, packaging_level=pro_lvl)
        buy = db.query(Packaging).filter_by(variant_id=v.id, level=buy_lvl).one()
        db.add(ProductSupplier(variant_id=v.id, supplier_id=sup.id, supplier_ref=f"{sup.code}-{code}",
                               purchase_packaging_id=buy.id, cost_cents_per_pack=cost, min_order_packs=1,
                               lead_time_days=sup.default_lead_time_days))
    db.flush()

    # --- Stock initial (reprise de données de démonstration) ------------------------------------------------
    def loc(site_, code):
        return db.query(Location).filter_by(site_id=site_.id, code=code).one()

    initial = [
        ("BOUIL-17-INOX", ent, "STOCK-A", 64, "AL-24-0901", None, 2200), ("BOUIL-17-INOX", par, "RESERVE", 10, "AL-24-0901", None, 2200),
        ("BOUIL-17-INOX", lyo, "RESERVE", 6, "AL-24-0901", None, 2200),
        ("LAMPE-LIN-NAT", ent, "STOCK-A", 36, "AL-24-0812", None, 1800), ("LAMPE-LIN-NAT", par, "RESERVE", 8, "AL-24-0812", None, 1800),
        ("POELE-28-FONTE", ent, "STOCK-A", 24, "AL-24-0777", None, 2600), ("POELE-28-FONTE", lyo, "RESERVE", 5, "AL-24-0777", None, 2600),
        ("CONF-ABR-370", ent, "STOCK-EPI", 240, "CV-2611-A", date.today() + timedelta(days=20), 210),
        ("CONF-ABR-370", ent, "STOCK-EPI", 480, "CV-2702-B", date.today() + timedelta(days=300), 210),
        ("CONF-ABR-370", par, "RESERVE", 36, "CV-2611-A", date.today() + timedelta(days=20), 210),
        ("CONF-ABR-370", lyo, "RESERVE", 30, "CV-2702-B", date.today() + timedelta(days=300), 210),
        ("HUILE-OLV-75", ent, "STOCK-EPI", 90, "CV-H-2604", date.today() + timedelta(days=400), 650),
        ("HUILE-OLV-75", par, "RESERVE", 12, "CV-H-2604", date.today() + timedelta(days=400), 650),
        ("AMANDE-VRAC-KG", par, "RESERVE", 15, "CV-AM-118", date.today() + timedelta(days=150), 1300),
    ]
    for sku, s, lc, q, lot_code, exp, cost in initial:
        v = variants[sku]
        lot = inv.new_lot(db, v.id, db.query(ProductSupplier).filter_by(variant_id=v.id).one().supplier_id, lot_code,
                          exp, None, v.product.expiry_kind)
        inv.post_movements(db, "ECART_INVENTAIRE", [inv.MoveLine(v.id, loc(s, lc).id, Decimal(q), "DISPONIBLE", lot.id,
                                                                 unit_cost=Decimal(cost))],
                           actor_id=users["admin"].id, reason="Reprise de stock initial (données de démonstration)",
                           document_type="REPRISE", document_ref="REPRISE-INITIALE")
        # le coût moyen n'est initialisé que par une réception : on le fixe explicitement pour la reprise
        pos = db.get(StockPosition, (v.id, s.id))
        pos.avg_unit_cost = Decimal(cost)
    minmax = [("BOUIL-17-INOX", par, 6, 16), ("BOUIL-17-INOX", lyo, 4, 12), ("BOUIL-17-INOX", ent, 40, 120),
              ("CONF-ABR-370", par, 24, 72), ("CONF-ABR-370", lyo, 24, 72), ("CONF-ABR-370", ent, 480, 1440),
              ("HUILE-OLV-75", par, 12, 36), ("LAMPE-LIN-NAT", par, 4, 12), ("POELE-28-FONTE", ent, 16, 48)]
    for sku, s, mn, mx in minmax:
        db.execute(text("INSERT INTO stock_positions (variant_id, site_id, on_hand, sellable, reserved, min_qty, max_qty, updated_at) "
                        "VALUES (:v,:s,0,0,0,:mn,:mx,now()) ON CONFLICT (variant_id, site_id) DO UPDATE SET min_qty=:mn, max_qty=:mx"),
                   {"v": variants[sku].id, "s": s.id, "mn": mn, "mx": mx})

    # Étiquettes RFID (registre EPC → unité) pour les bouilloires de Paris
    bouil = variants["BOUIL-17-INOX"]
    for i in range(1, 11):
        db.add(SerialUnit(variant_id=bouil.id, serial=f"BL17-{i:05d}", epc=f"3074257BF7194E4000{i:06X}",
                          location_id=loc(par, "RESERVE").id))

    # --- Caisses et équipements ------------------------------------------------------------------------------
    db.add_all([CashRegister(site_id=par.id, code="CAISSE-PAR-01", label="Caisse 1 — Paris"),
                CashRegister(site_id=lyo.id, code="CAISSE-LYO-01", label="Caisse 1 — Lyon")])
    devs = [("RFID-PAR-SORTIE", "LECTEUR_RFID", "Portique RFID sortie Paris", par, "SORTIE", None),
            ("RFID-ENT-QUAI", "LECTEUR_RFID", "Lecteur RFID quai Orléans", ent, "RECEP", None),
            ("TEMP-ENT-EPI", "CAPTEUR_TEMPERATURE", "Sonde cellule épicerie Orléans", ent, "STOCK-EPI", "CEL"),
            ("TEMP-PAR-RES", "CAPTEUR_TEMPERATURE", "Sonde réserve Paris", par, "RESERVE", "CEL"),
            ("BAL-PAR-01", "BALANCE", "Balance caisse Paris", par, None, "KG"),
            ("SCAN-PAR-01", "LECTEUR_CODE_BARRES", "Douchette caisse Paris", par, None, None),
            ("ESL-PAR-RAYON", "ETIQUETTE_ELECTRONIQUE", "Étiquettes électroniques rayon Paris", par, "RESERVE", None),
            ("CONV-ENT-01", "CONVOYEUR", "Convoyeur préparation Orléans", ent, "PREPA", None),
            ("PTL-ENT-01", "SYSTEME_PREPARATION", "Pick-to-light Orléans", ent, "PREPA", None)]
    for code, kind, label, s, lc, unit in devs:
        db.add(Device(code=code, kind=kind, label=label, site_id=s.id, location_id=loc(s, lc).id if lc else None,
                      unit=unit, meta={"topic": f"aureom/{s.code}/{kind.lower()}/{code}"}))
    ensure_rules(db)

    # --- Historique de demande SYNTHÉTIQUE (prévisions) ------------------------------------------------------
    if with_history:
        rng = np.random.default_rng(2026)
        weekly = np.array([0.8, 0.85, 0.9, 1.0, 1.2, 1.6, 0.65])  # lundi → dimanche
        for sku, base_level in [("CONF-ABR-370", 6.0), ("BOUIL-17-INOX", 1.2), ("HUILE-OLV-75", 2.5)]:
            for s, mult in ((par, 1.0), (lyo, 0.7)):
                for i in range(180):
                    d = date.today() - timedelta(days=180 - i)
                    lam = base_level * mult * weekly[d.weekday()] * (1 + 0.15 * np.sin(i / 30))
                    qty = int(rng.poisson(lam))
                    stockout = bool(rng.random() < 0.02)
                    db.add(DemandHistory(variant_id=variants[sku].id, site_id=s.id, day=d,
                                         quantity=Decimal(0 if stockout else qty), stockout=stockout, source="SYNTHETIQUE"))
    db.commit()
    return {"sites": {"entrepot": ent.id, "paris": par.id, "lyon": lyo.id},
            "fournisseurs": {"atelier": al.id, "conserverie": cv.id}, "client_pro_org": cafe.id,
            "variantes": {k: v.id for k, v in variants.items()}}


if __name__ == "__main__":
    if "--reset" in sys.argv:
        reset_schema()
    print(seed())
