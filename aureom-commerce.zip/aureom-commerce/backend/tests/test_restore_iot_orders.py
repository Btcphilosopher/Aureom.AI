"""Restauration de sauvegarde, équipements (RFID, température), commandes, retours, prévisions."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
from sqlalchemy import func, select

from app.core.types import utcnow
from app.db import SessionLocal, get_engine
from app.modules.inventory import service as inv
from app.modules.inventory.models import Lot, StockMovement
from app.modules.iot.models import RfidObservation
from app.modules.traceability import service as trace
from app.modules.traceability.models import TraceEvent

from .conftest import TEST_DB, key


def _pg_url():
    return TEST_DB.replace("postgresql+psycopg://", "postgresql://")


@pytest.mark.skipif(not shutil.which("pg_dump"), reason="pg_dump absent")
def test_restauration_puis_reconciliation(api, ids):
    with SessionLocal() as db:
        lot = db.scalar(select(Lot).where(Lot.lot_code == "AL-24-0901"))
        a = trace.declare_event(db, event_type="INSPECTION_RECORDED", occurred_at=utcnow(), actor_id=1, lot=lot,
                                details={"r": "a"})
        db.commit()
        a_id = a.id
    trace.process_outbox()
    dump = os.path.join(tempfile.mkdtemp(), "sauvegarde.dump")
    subprocess.run(["pg_dump", "-Fc", "-f", dump, _pg_url()], check=True)
    # activité postérieure à la sauvegarde
    with SessionLocal() as db:
        lot = db.scalar(select(Lot).where(Lot.lot_code == "AL-24-0901"))
        b = trace.declare_event(db, event_type="INSPECTION_RECORDED", occurred_at=utcnow(), actor_id=1, lot=lot,
                                details={"r": "b"})
        loc = inv.fefo_candidates(db, lot.variant_id, ids["sites"]["paris"])[0][2]
        inv.post_movements(db, "PERTE", [inv.MoveLine(lot.variant_id, loc.id, Decimal(-1), "DISPONIBLE", lot.id)],
                           actor_id=1, reason="casse après sauvegarde")
        db.commit()
        b_id = b.id
    trace.process_outbox()
    get_engine().dispose()
    # l'extension btree_gist appartient au superutilisateur : on l'exclut de la liste de restauration
    toc = subprocess.run(["pg_restore", "-l", dump], check=True, capture_output=True, text=True).stdout
    lst = dump + ".list"
    with open(lst, "w") as f:
        f.write("\n".join(l for l in toc.splitlines() if " EXTENSION " not in l))
    subprocess.run(["pg_restore", "--clean", "--if-exists", "--no-owner", "-L", lst, "-d", _pg_url(), dump], check=True)
    with SessionLocal() as db:
        assert db.get(TraceEvent, b_id) is None and db.get(TraceEvent, a_id).ledger_status == "CONFIRME"
        assert inv.check_consistency(db)["coherent"]
    res = trace.reconcile()
    assert any(m.get("evenement") == b_id for m in res["anomalies"])  # détecté comme orphelin
    with SessionLocal() as db:
        assert db.get(TraceEvent, b_id).origin == "ORPHELIN"
        assert db.get(TraceEvent, a_id).ledger_status == "CONFIRME"


def test_rfid_doublons_et_concurrence_sans_mouvement(api, ids):
    tok = api.ok("POST", "/api/admin/comptes-equipement/capteurs/jeton")["jeton"]
    with SessionLocal() as db:
        before = db.scalar(select(func.count()).select_from(StockMovement))
    t0 = datetime.now(timezone.utc)

    def read(i):
        api.c.post("/api/equipements/observations", headers={"Authorization": f"Bearer {tok}"},
                   json={"device_code": "RFID-PAR-SORTIE", "payload": {"epc": "3074257BF7194E4000000002",
                         "observed_at": (t0 + timedelta(milliseconds=50 * i)).isoformat(), "rssi": -60}})

    th = [threading.Thread(target=read, args=(i,)) for i in range(12)]
    [t.start() for t in th]
    [t.join() for t in th]
    with SessionLocal() as db:
        obs = db.scalars(select(RfidObservation)).all()
        assert len(obs) == 1 and obs[0].read_count == 12
        assert db.scalar(select(func.count()).select_from(StockMovement)) == before
    # hors fenêtre de déduplication : nouvelle observation
    api.c.post("/api/equipements/observations", headers={"Authorization": f"Bearer {tok}"},
               json={"device_code": "RFID-PAR-SORTIE", "payload": {"epc": "3074257BF7194E4000000002",
                     "observed_at": (t0 + timedelta(seconds=120)).isoformat()}})
    with SessionLocal() as db:
        assert db.scalar(select(func.count()).select_from(RfidObservation)) == 2


def test_temperature_qualite_et_unites(api, ids):
    tok = api.ok("POST", "/api/admin/comptes-equipement/capteurs/jeton")["jeton"]
    h = {"Authorization": f"Bearer {tok}"}
    base = datetime.now(timezone.utc) - timedelta(minutes=30)

    def send(i, v, unit="CEL", **extra):
        return api.c.post("/api/equipements/observations", headers=h, json={"device_code": "TEMP-PAR-RES", "payload": {
            "message_id": f"m{i}", "value": v, "unit": unit, "observed_at": (base + timedelta(minutes=i)).isoformat(), **extra}}).json()

    assert send(1, 80.2, unit="FAH")["qualite"] == "INVALIDE"  # unité inattendue
    assert send(2, 31, sensor_status="batterie_faible")["qualite"] == "SUSPECT"
    send(3, 30)
    send(4, 30.5)
    assert not [a for a in api.ok("GET", "/api/automatisations/alertes") if a["rule_code"] == "TEMPERATURE"]
    r = send(5, 31)
    assert r.get("alerte")  # 3 lectures valides consécutives > 26 °C (plage de la réserve)
    assert send(5, 31)["doublon"] is True


def test_commande_paye_n_est_pas_prete_et_remise_exige_paiement(api, ids):
    site = ids["sites"]["paris"]
    o = api.ok("POST", "/api/commandes", "admin", {"channel": "WEB", "fulfilment": "RETRAIT", "source_site_id": site,
               "lines": [{"variant_id": ids["variantes"]["CONF-ABR-370"], "quantity": 2}]}, key=key())
    for step in ("valider", "reserver", "preparer"):
        o = api.ok("POST", f"/api/commandes/{o['id']}/{step}", "admin")
    for t in o["taches"]:
        api.ok("POST", f"/api/commandes/taches/{t['id']}/prelever", "prepa.paris",
               {"picked_qty": t["quantity"], "scanned_code": "2002000000019"})
    code = api.ok("POST", f"/api/commandes/{o['id']}/prete", "prepa.paris")["code_retrait"]
    r = api.req("POST", f"/api/commandes/{o['id']}/remettre", "caisse.paris", {"pickup_code": code})
    assert r.json()["code"] == "PAIEMENT_REQUIS"
    api.ok("POST", f"/api/commandes/{o['id']}/paiements", "admin", {"method": "CARTE_SIMULEE",
           "amount_cents": o["total_ttc_cents"], "card_token": "tok_sim_accepte"}, key=key())
    done = api.ok("POST", f"/api/commandes/{o['id']}/remettre", "caisse.paris", {"pickup_code": code})
    assert done["status"] == "REMISE"
    with SessionLocal() as db:
        assert inv.check_consistency(db)["coherent"]
    # transition interdite
    assert api.req("POST", f"/api/commandes/{o['id']}/annuler", "admin", {"reason": "x"}).status_code == 400


def test_commande_pro_ht_et_fractionnement(api, ids):
    cli = api.ok("POST", "/api/clients", "admin", {"kind": "PROFESSIONNEL", "company_name": "Café des Halles",
                 "payment_terms_days": 30})
    o = api.ok("POST", "/api/commandes", "admin", {"channel": "PRO", "fulfilment": "LIVRAISON",
               "source_site_id": ids["sites"]["entrepot"], "customer_id": cli["id"],
               "lines": [{"variant_id": ids["variantes"]["CONF-ABR-370"], "quantity": 2, "packaging_level": "CARTON"}]})
    ln = o["lines"][0]
    assert ln["tax_inclusive"] is False and ln["total_ht_cents"] == 15840 and ln["total_tax_cents"] == 871
    plan = api.ok("POST", "/api/commandes/fractionnement/proposition", "admin", {
        "lines": [{"variant_id": ids["variantes"]["LAMPE-LIN-NAT"], "quantity": 40}],
        "site_ids": [ids["sites"]["entrepot"], ids["sites"]["paris"]]})
    assert plan["fractionnement"] is True and len(plan["plan"]) == 2


def test_retour_rembourse_ne_remet_pas_en_stock(api, ids):
    site = ids["sites"]["paris"]
    reg = next(r for r in api.ok("GET", "/api/caisse/postes", "caisse.paris") if r["site_id"] == site)
    sess = api.ok("POST", "/api/caisse/sessions", "caisse.paris", {"register_id": reg["id"], "opening_float_cents": 0})
    sale = api.ok("POST", "/api/caisse/ventes", "caisse.paris", {"session_id": sess["id"]})
    sale = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/lignes", "caisse.paris", {"code": "2002000000019", "quantity": 2})
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris", {"method": "ESPECES", "amount_cents": 980}, key=key())
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")
    pos = lambda: next(p for p in api.ok("GET", f"/api/stocks/positions?site_id={site}") if p["sku"] == "CONF-ABR-370")
    v0 = pos()["vendable"]
    ret = api.ok("POST", "/api/retours", "caisse.paris", {"origin": "VENTE", "source_id": sale["id"], "site_id": site,
                 "lines": [{"line_id": sale["lines"][0]["id"], "quantity": 2, "reason": "pot fêlé"}]})
    api.ok("POST", f"/api/retours/{ret['id']}/remboursement", "magasin.paris", {}, key=key())
    assert pos()["vendable"] == v0 and pos()["non_vendable"] != "0"
    r = api.req("POST", f"/api/retours/lignes/{ret['lines'][0]['id']}/inspection", "magasin.paris",
                {"condition": "ENDOMMAGE", "disposition": "REMISE_EN_VENTE"})
    assert r.json()["code"] == "REMISE_EN_VENTE_INTERDITE"
    api.ok("POST", f"/api/retours/lignes/{ret['lines'][0]['id']}/inspection", "magasin.paris",
           {"condition": "ENDOMMAGE", "disposition": "DESTRUCTION"})
    assert pos()["vendable"] == v0
    over = api.req("POST", "/api/retours", "caisse.paris", {"origin": "VENTE", "source_id": sale["id"], "site_id": site,
                   "lines": [{"line_id": sale["lines"][0]["id"], "quantity": 1}]})
    assert over.json()["code"] == "QUANTITE_RETOUR"


def test_prevision_evaluee_sur_periode_distincte(ids_hist):
    from app.modules.automation import forecasting as fc

    with SessionLocal() as db:
        run = fc.evaluate(db, ids_hist["variantes"]["CONF-ABR-370"], ids_hist["sites"]["paris"])
        db.commit()
        assert run.train_end < run.test_start  # périodes disjointes
        ev = run.evaluation
        assert {"naif_saisonnier", "moyenne_mobile_28j", "ets_hebdomadaire"} <= set(ev)
        assert ev["_selection"]["retenu"] in ev
        base = ev["naif_saisonnier"]["mase"]
        chosen = ev["_selection"]["retenu"]
        assert chosen == "naif_saisonnier" or ev[chosen]["mase"] <= base * 0.95
        assert all(p["bas"] <= p["prevision"] <= p["haut"] for p in run.forecast)
        assert run.data_quality["avertissement"]  # données synthétiques signalées
        risk = fc.stockout_risk(db, ids_hist["variantes"]["CONF-ABR-370"], ids_hist["sites"]["paris"], 4)
        assert 0 <= risk["probabilite_rupture"] <= 1
