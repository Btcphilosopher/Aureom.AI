"""Tests sur une vraie base PostgreSQL (contraintes, verrous et concurrence ne sont pas simulables en SQLite).

Variables : AUREOM_TEST_DATABASE_URL (défaut : base locale aureom_test) et, pour le registre simulé,
AUREOM_TEST_LEDGER_URL (base distincte, défaut aureom_test_ledger) afin que les tests de restauration
ne restaurent pas le « registre » avec l'application.
"""
from __future__ import annotations

import os
import tempfile
import uuid

import pytest

TEST_DB = os.environ.get("AUREOM_TEST_DATABASE_URL", "postgresql+psycopg://aureom:aureom@localhost:5432/aureom_test")
TEST_LEDGER = os.environ.get("AUREOM_TEST_LEDGER_URL",
                             "postgresql+psycopg://aureom:aureom@localhost:5432/aureom_test_ledger")
os.environ["AUREOM_DATABASE_URL"] = TEST_DB
os.environ["AUREOM_SIMULATION_LEDGER_URL"] = TEST_LEDGER
os.environ.setdefault("AUREOM_LEDGER_MODE", "simulation")
if os.environ["AUREOM_LEDGER_MODE"] == "fabric":  # le registre réel persiste : identifiant de clé unique par session
    os.environ["AUREOM_SIGNING_KEY_ID"] = "mm-test-" + uuid.uuid4().hex[:10]
os.environ["AUREOM_SIGNING_KEY_PATH"] = os.path.join(tempfile.mkdtemp(prefix="aureom-keys-"), "mm.key")
os.environ["AUREOM_STORAGE_DIR"] = tempfile.mkdtemp(prefix="aureom-obj-")

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.config import get_settings  # noqa: E402

get_settings.cache_clear()
from app.db import SessionLocal  # noqa: E402
from app.modules.ledger import adapters  # noqa: E402
from app.seed import DEMO_PASSWORD, reset_schema, seed  # noqa: E402


def _reset_ledger():
    from sqlalchemy import create_engine

    eng = create_engine(TEST_LEDGER)
    with eng.begin() as c:
        c.execute(text("DROP TABLE IF EXISTS simulated_ledger_records, simulated_ledger_keys"))
    eng.dispose()
    adapters.set_ledger(None)


@pytest.fixture()
def ids():
    """Base réinitialisée et jeu Maison & Marché (sans historique de demande, sauf besoin)."""
    _reset_ledger()
    reset_schema()
    out = seed(with_history=False)
    with SessionLocal() as db:
        from app.modules.traceability.service import register_own_key

        register_own_key(db)
        db.commit()
    return out


@pytest.fixture()
def ids_hist():
    _reset_ledger()
    reset_schema()
    return seed(with_history=True)


class Api:
    def __init__(self, client):
        self.c = client
        self.tokens = {}

    def tok(self, user):
        if user not in self.tokens:
            r = self.c.post("/api/auth/connexion", json={"username": user, "password": DEMO_PASSWORD})
            assert r.status_code == 200, r.text
            self.tokens[user] = r.json()["jeton"]
        return self.tokens[user]

    def req(self, method, path, user="admin", body=None, key=None, **kw):
        h = {"Authorization": f"Bearer {self.tok(user)}"}
        if key:
            h["Idempotency-Key"] = key
        return self.c.request(method, path, json=body, headers=h, **kw)

    def ok(self, method, path, user="admin", body=None, key=None, expect=200):
        r = self.req(method, path, user, body, key)
        assert r.status_code == expect, f"{method} {path} → {r.status_code} {r.text[:400]}"
        return r.json()


@pytest.fixture()
def api(ids):
    from app.main import app

    with TestClient(app) as c:
        yield Api(c)


def key() -> str:
    return "test-" + uuid.uuid4().hex
