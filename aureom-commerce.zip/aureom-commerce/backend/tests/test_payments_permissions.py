"""Paiements dupliqués, événements rejoués/falsifiés, données de carte, remboursements ; permissions."""
from __future__ import annotations

import json
import threading

from sqlalchemy import func, select

from app.db import SessionLocal
from app.modules.payments.models import Payment, PaymentEvent
from app.modules.payments.service import build_event, sign_event

from .conftest import key

HUILE = "2002000000026"


def _sale(api, ids, user="caisse.paris", code=HUILE, qty=1):
    site = ids["sites"]["paris"]
    reg = next(r for r in api.ok("GET", "/api/caisse/postes", user) if r["site_id"] == site)
    sess = reg["session_ouverte"] or api.ok("POST", "/api/caisse/sessions", user,
                                            {"register_id": reg["id"], "opening_float_cents": 5000})
    sale = api.ok("POST", "/api/caisse/ventes", user, {"session_id": sess["id"]})
    return api.ok("POST", f"/api/caisse/ventes/{sale['id']}/lignes", user, {"code": code, "quantity": qty}), sess


def test_paiement_duplique_meme_cle_concurrent(api, ids):
    sale, _ = _sale(api, ids)
    k = key()
    codes = []

    def go():
        r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                    {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "tok_sim_accepte"}, key=k)
        codes.append((r.status_code, r.json().get("paiement", {}).get("id")))

    th = [threading.Thread(target=go) for _ in range(8)]
    [t.start() for t in th]
    [t.join() for t in th]
    ok_ids = {pid for code, pid in codes if code == 200}
    assert len(ok_ids) == 1, codes
    with SessionLocal() as db:
        n = db.scalar(select(func.count()).select_from(Payment).where(Payment.target_id == sale["id"]))
        assert n == 1
        assert db.scalar(select(func.sum(Payment.captured_cents)).where(Payment.target_id == sale["id"])) == 1250


def test_meme_cle_autre_montant_refusee(api, ids):
    sale, _ = _sale(api, ids, qty=2)
    k = key()
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
           {"method": "ESPECES", "amount_cents": 1000}, key=k)
    r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                {"method": "ESPECES", "amount_cents": 1500}, key=k)
    assert r.status_code == 409 and r.json()["code"] == "IDEMPOTENCE_CONFLIT"


def test_trop_percu_et_paiement_partiel(api, ids):
    sale, _ = _sale(api, ids)
    r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                {"method": "ESPECES", "amount_cents": 5000}, key=key())
    assert r.json()["code"] == "TROP_PERCU"
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
           {"method": "ESPECES", "amount_cents": 250}, key=key())
    r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")
    assert r.json()["code"] == "RESTE_A_PAYER"
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
           {"method": "CARTE_SIMULEE", "amount_cents": 1000, "card_token": "tok_sim_accepte"}, key=key())
    assert api.ok("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")["status"] == "TERMINEE"


def test_carte_refusee_et_paiement_en_attente(api, ids):
    sale, _ = _sale(api, ids)
    p = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
               {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "tok_sim_refuse"}, key=key())
    assert p["paiement"]["status"] == "ECHOUE"
    p = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
               {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "tok_sim_attente"}, key=key())
    assert p["paiement"]["status"] == "EN_ATTENTE"
    r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")
    assert r.json()["code"] == "PAIEMENT_EN_ATTENTE"
    # l'événement tardif signé arrive : le paiement est capturé
    ref = p["paiement"]["provider_ref"]
    for t in ("payment.authorized", "payment.captured"):
        body = build_event(t, ref, 1250)
        assert api.c.post("/api/paiements/webhook", content=body, headers={"Sim-Signature": sign_event(body)}).status_code == 200
    assert api.ok("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")["status"] == "TERMINEE"


def test_evenement_rejoue_falsifie_ou_montant_errone(api, ids):
    sale, _ = _sale(api, ids)
    p = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
               {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "tok_sim_attente"}, key=key())
    ref = p["paiement"]["provider_ref"]
    body = build_event("payment.captured", ref, 1250)
    forged = api.c.post("/api/paiements/webhook", content=body, headers={"Sim-Signature": sign_event(body, secret="x")})
    assert forged.status_code == 400 and forged.json()["code"] == "SIGNATURE_INVALIDE"
    old = api.c.post("/api/paiements/webhook", content=body, headers={"Sim-Signature": sign_event(body, ts=1000)})
    assert old.status_code == 400  # horodatage hors tolérance (rejeu tardif)
    wrong = build_event("payment.captured", ref, 99999)
    assert api.c.post("/api/paiements/webhook", content=wrong, headers={"Sim-Signature": sign_event(wrong)}).json()["statut"] == "anomalie"
    first = api.c.post("/api/paiements/webhook", content=body, headers={"Sim-Signature": sign_event(body)}).json()
    replay = api.c.post("/api/paiements/webhook", content=body, headers={"Sim-Signature": sign_event(body)}).json()
    assert first["statut"] == "applique" and replay["statut"] == "deja_traite"
    with SessionLocal() as db:
        pay = db.scalar(select(Payment).where(Payment.provider_ref == ref))
        assert pay.status == "CAPTURE" and pay.captured_cents == 1250
        assert db.scalar(select(func.count()).select_from(PaymentEvent).where(PaymentEvent.signature_valid.is_(False))) == 2


def test_aucune_donnee_de_carte(api, ids):
    sale, _ = _sale(api, ids)
    r = api.req("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
                {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "4111111111111111"}, key=key())
    assert r.json()["code"] == "DONNEES_CARTE_INTERDITES"
    with SessionLocal() as db:
        for p in db.scalars(select(Payment)):
            assert "4111" not in json.dumps({c.key: str(getattr(p, c.key)) for c in Payment.__table__.columns})


def test_remboursement_plafonne(api, ids):
    sale, _ = _sale(api, ids)
    p = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.paris",
               {"method": "CARTE_SIMULEE", "amount_cents": 1250, "card_token": "tok_sim_accepte"}, key=key())
    pid = p["paiement"]["id"]
    assert api.req("POST", f"/api/paiements/{pid}/remboursement", "caisse.paris",
                   {"amount_cents": 100, "reason": "x"}, key=key()).status_code == 403  # caissier : pas pos.refund
    k = key()
    r1 = api.ok("POST", f"/api/paiements/{pid}/remboursement", "magasin.paris", {"amount_cents": 1000, "reason": "geste"}, key=k)
    r2 = api.ok("POST", f"/api/paiements/{pid}/remboursement", "magasin.paris", {"amount_cents": 1000, "reason": "geste"}, key=k)
    assert r1["id"] == r2["id"] and r1["status"] == "REMBOURSE"
    r = api.req("POST", f"/api/paiements/{pid}/remboursement", "magasin.paris", {"amount_cents": 300, "reason": "x"}, key=key())
    assert r.json()["code"] == "REMBOURSEMENT_EXCESSIF"


# --- Permissions -------------------------------------------------------------------------------------
def test_permissions_par_role(api, ids):
    assert api.req("GET", "/api/admin/utilisateurs", "caisse.paris").status_code == 403
    assert api.req("POST", "/api/catalogue/prix", "caisse.paris", {"price_list_code": "MAGASIN", "variant_id": 1,
                                                                    "amount_cents": 1}).status_code == 403
    assert api.req("GET", "/api/analyses/indicateurs", "prepa.orleans").status_code == 403
    assert api.req("POST", "/api/tracabilite/registre/reconcilier", "analyste").status_code == 403
    assert api.c.get("/api/stocks/positions").status_code == 401
    assert api.c.get("/api/stocks/positions", headers={"Authorization": "Bearer faux"}).status_code == 401
    r = api.c.post("/api/auth/connexion", json={"username": "capteurs", "password": "demo-aureom-2026"})
    assert r.status_code == 401  # un compte d'équipement ne se connecte pas par mot de passe


def test_perimetre_site(api, ids):
    lyon_reg = next(r for r in api.ok("GET", "/api/caisse/postes", "admin") if r["site_id"] == ids["sites"]["lyon"])
    r = api.req("POST", "/api/caisse/sessions", "caisse.paris", {"register_id": lyon_reg["id"], "opening_float_cents": 0})
    assert r.status_code == 403
    assert api.req("GET", f"/api/stocks/positions?site_id={ids['sites']['lyon']}", "caisse.paris").status_code == 403


def test_donnees_personnelles_masquees(api, ids):
    c = api.ok("POST", "/api/clients", "magasin.paris", {"first_name": "Alice", "last_name": "Martin",
                                                          "email": "alice@example.invalid"})
    assert c["email"] == "alice@example.invalid"
    seen = api.ok("GET", f"/api/clients/{c['id']}", "caisse.paris")
    assert "email" not in seen and seen["nom_affiche"] == "A. M."


def test_plafonds_et_separation_des_taches(api, ids):
    cv = ids["fournisseurs"]["conserverie"]
    big = api.ok("POST", "/api/achats/propositions", "achats.resp", {"supplier_id": cv, "site_id": ids["sites"]["entrepot"],
                 "lines": [{"variant_id": ids["variantes"]["CONF-ABR-370"], "pack_qty": 200}]})
    r = api.req("POST", f"/api/achats/propositions/{big['id']}/decision", "achats.resp", {"approve": True})
    assert r.status_code == 403  # 10 080 € > plafond 5 000 € (et auto-approbation)
    small = api.ok("POST", "/api/achats/propositions", "achats.resp", {"supplier_id": cv, "site_id": ids["sites"]["entrepot"],
                   "lines": [{"variant_id": ids["variantes"]["CONF-ABR-370"], "pack_qty": 2}]})
    r = api.req("POST", f"/api/achats/propositions/{small['id']}/decision", "achats.resp", {"approve": True})
    assert r.status_code == 403 and "Séparation" in r.json()["message"]
    assert api.ok("POST", f"/api/achats/propositions/{big['id']}/decision", "direction", {"approve": True})["commande"]


def test_remise_au_dela_du_plafond(api, ids):
    sale, _ = _sale(api, ids)
    lid = sale["lines"][0]["id"]
    r = api.req("POST", f"/api/caisse/lignes/{lid}/remise", "caisse.paris", {"discount_bp": 2500, "reason": "test"})
    assert r.status_code == 403
    r = api.req("POST", f"/api/caisse/lignes/{lid}/remise", "caisse.paris", {"discount_bp": 2500, "reason": "test",
                "manager_username": "magasin.paris", "manager_password": "faux"})
    assert r.status_code == 403
    ok = api.ok("POST", f"/api/caisse/lignes/{lid}/remise", "caisse.paris", {"discount_bp": 2500, "reason": "test",
                "manager_username": "magasin.paris", "manager_password": "demo-aureom-2026"})
    assert ok["lines"][0]["discount_cents"] == 313 and ok["total_ttc_cents"] == 937
