"""Conversions d'unités, conditionnements et montants (tests purs, sans base)."""
from decimal import Decimal

import pytest

from app.core.errors import DomainError
from app.core.money import allocate_proportionally, apply_discount_bp, format_eur, line_amount, split_ttc, ttc_from_ht
from app.core.units import base_to_packs, check_quantity, convert, packs_to_base, round_up_to_pack
from app.modules.catalog.service import gtin_check_digit_ok, gtin_with_check, validate_packaging_chain


def test_conversions_meme_dimension():
    assert convert(Decimal("1250"), "G", "KG") == Decimal("1.250")
    assert convert(Decimal("75"), "CL", "L") == Decimal("0.750")
    assert convert(Decimal("1.5"), "L", "ML") == Decimal("1500.000")


def test_conversion_entre_dimensions_refusee():
    with pytest.raises(DomainError) as e:
        convert(Decimal(1), "KG", "L")
    assert e.value.code == "CONVERSION_IMPOSSIBLE"


def test_pieces_entieres_et_precision():
    with pytest.raises(DomainError):
        check_quantity(Decimal("2.5"), "PCE")
    with pytest.raises(DomainError):
        check_quantity(Decimal("1.0005"), "KG")
    assert check_quantity(Decimal("1.250"), "KG") == Decimal("1.250")


def test_conditionnements_piece_paquet_carton_palette():
    assert packs_to_base(Decimal(3), Decimal(24), "PCE") == Decimal(72)
    assert packs_to_base(Decimal(1), Decimal(960), "PCE") == Decimal(960)
    assert base_to_packs(Decimal(100), Decimal(24)) == (4, Decimal("4.000"))
    assert round_up_to_pack(Decimal(100), Decimal(24)) == 5
    assert round_up_to_pack(Decimal(96), Decimal(24)) == 4
    validate_packaging_chain([{"level": "PIECE", "qty_in_base": 1}, {"level": "PAQUET", "qty_in_base": 6},
                              {"level": "CARTON", "qty_in_base": 24}, {"level": "PALETTE", "qty_in_base": 960}], "PCE")
    with pytest.raises(DomainError):  # 10 n'est pas un multiple de 4
        validate_packaging_chain([{"level": "PIECE", "qty_in_base": 1}, {"level": "PAQUET", "qty_in_base": 4},
                                  {"level": "CARTON", "qty_in_base": 10}], "PCE")
    with pytest.raises(DomainError):  # carton plus petit que le paquet
        validate_packaging_chain([{"level": "PAQUET", "qty_in_base": 6}, {"level": "CARTON", "qty_in_base": 6}], "PCE")


def test_montants_centimes_exacts():
    assert line_amount(490, Decimal(3)) == 1470
    assert line_amount(2490, Decimal("1.235")) == 3075  # 30,7515 → 30,75
    assert line_amount(2490, Decimal("0.125")) == 311  # 3,1125 → 3,11
    assert apply_discount_bp(4990, 1000) == (4491, 499)
    ht, tva = split_ttc(4990, 2000)
    assert (ht, tva) == (4158, 832) and ht + tva == 4990
    ht, tva = split_ttc(490, 550)
    assert ht + tva == 490 and ht == 464
    assert ttc_from_ht(13900, 550) == (14665, 765)
    parts = allocate_proportionally(1000, [1, 1, 1])
    assert sum(parts) == 1000 and sorted(parts) == [333, 333, 334]
    # pas d'erreur de flottant : 0,1 + 0,2
    assert line_amount(10, Decimal(1)) + line_amount(20, Decimal(1)) == 30


def test_format_francais():
    assert format_eur(123456) == "1 234,56 €"
    assert format_eur(-5) == "-0,05 €"


def test_gtin():
    assert gtin_with_check("200200000002") == "2002000000026"
    assert gtin_check_digit_ok("2002000000026")
    assert not gtin_check_digit_ok("2002000000027")
