"""Intégration avec le réseau Hyperledger Fabric réel (3 organisations).

Lancement : AUREOM_TEST_FABRIC=1 AUREOM_LEDGER_MODE=fabric AUREOM_LEDGER_GATEWAY_URL=http://localhost:8800 \\
  AUREOM_LEDGER_GATEWAY_TOKEN=... AUREOM_GATEWAY_CONSERVERIE_URL=http://localhost:8802 \\
  AUREOM_GATEWAY_SUPPLIER_TOKEN=... pytest tests/test_fabric_integration.py
"""
from __future__ import annotations

import json
import os
import time
import uuid

import pytest
from sqlalchemy import select

from app.core.types import utcnow
from app.db import SessionLocal
from app.modules.inventory.models import Lot
from app.modules.ledger.adapters import FabricGatewayAdapter, LedgerError, get_ledger
from app.modules.traceability import keys
from app.modules.traceability import service as trace
from app.modules.traceability.models import TraceEvent

pytestmark = pytest.mark.skipif(os.environ.get("AUREOM_TEST_FABRIC") != "1", reason="réseau Fabric non demandé")


def test_cycle_complet_sur_fabric(ids):
    lg = get_ledger()
    assert lg.name == "fabric" and lg.distributed
    with SessionLocal() as db:
        lot = db.scalar(select(Lot).where(Lot.lot_code == "AL-24-0901"))
        ev = trace.declare_event(db, event_type="INSPECTION_RECORDED", occurred_at=utcnow(), actor_id=1, lot=lot,
                                 details={"test": uuid.uuid4().hex})
        db.commit()
        eid = ev.id
    t0 = time.time()
    assert trace.process_outbox()["publies"] == 1
    latency = time.time() - t0
    with SessionLocal() as db:
        e = db.get(TraceEvent, eid)
        assert e.ledger_status == "CONFIRME" and e.ledger_block and len(e.ledger_tx_id) == 64
        envelope, sig = e.envelope, e.signature_b64
    print(f"latence publication Fabric : {latency * 1000:.0f} ms")
    assert lg.submit(envelope, sig).status == "DUPLICATE"
    env = json.loads(envelope)
    env["locationRef"] = "AUTRE"
    s = trace.canonical(env)
    with pytest.raises(LedgerError) as err:
        lg.submit(s, keys.get_signer().sign(s.encode()))
    assert err.value.code == "CONFLICT" and err.value.http_status == 409
    env2 = dict(json.loads(envelope), eventId=str(uuid.uuid4()), clientEmail="x@example.invalid")
    s2 = trace.canonical(env2)
    with pytest.raises(LedgerError) as err:
        lg.submit(s2, keys.get_signer().sign(s2.encode()))
    assert err.value.http_status == 422
    # lecture depuis la passerelle d'une AUTRE organisation : registre partagé
    other = FabricGatewayAdapter(base_url=os.environ.get("AUREOM_GATEWAY_CONSERVERIE_URL", "http://localhost:8802"),
                                 token=os.environ["AUREOM_GATEWAY_SUPPLIER_TOKEN"], msp_id="ConserverieValMSP")
    rec = other.get_event(eid)
    assert rec and rec["payloadSha256"] == e.payload_sha256 and rec["submitterMsp"] == "MaisonMarcheMSP"
    assert keys.verify(keys.get_signer().public_key_b64(), rec["envelope"].encode(), rec["signatureBase64"])
