"""Stocks : réservations concurrentes, non-négativité, corrections liées, figement des prix."""
from __future__ import annotations

import threading
from datetime import timedelta
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.core.errors import DomainError
from app.core.types import utcnow
from app.db import SessionLocal
from app.modules.admin.models import Location
from app.modules.catalog import service as cat
from app.modules.inventory import service as inv
from app.modules.inventory.models import StockMovement, StockPosition
from app.modules.orders import service as ords

from .conftest import key


def _order_line(db, ids, variant, qty, site):
    o = ords.create_order(db, {"channel": "WEB", "fulfilment": "RETRAIT", "source_site_id": site,
                               "lines": [{"variant_id": variant, "quantity": qty}]}, None)
    ords.validate(db, o, None)
    db.commit()
    return o.id


def test_reservations_concurrentes_sans_double_allocation(ids):
    """20 commandes de 3 pièces se disputent 10 bouilloires à Paris : au plus 3 réussissent (9 ≤ 10)."""
    v, site = ids["variantes"]["BOUIL-17-INOX"], ids["sites"]["paris"]
    with SessionLocal() as db:
        order_ids = [_order_line(db, ids, v, 3, site) for _ in range(20)]
    ok, ko, errors = [], [], []
    barrier = threading.Barrier(len(order_ids))

    def worker(oid):
        with SessionLocal() as db:
            try:
                barrier.wait()
                o = ords.get_order(db, oid, lock=True)
                ords.reserve(db, o, None)
                db.commit()
                ok.append(oid)
            except DomainError as e:
                db.rollback()
                ko.append(e.code)
            except Exception as e:  # pragma: no cover
                errors.append(repr(e))

    th = [threading.Thread(target=worker, args=(o,)) for o in order_ids]
    [t.start() for t in th]
    [t.join() for t in th]
    assert not errors, errors
    assert len(ok) == 3 and all(c == "STOCK_INSUFFISANT" for c in ko)
    with SessionLocal() as db:
        pos = db.get(StockPosition, (v, site))
        assert pos.reserved == Decimal(9) and pos.reserved <= pos.sellable
        assert inv.check_consistency(db)["coherent"]


def test_solde_jamais_negatif_et_sorties_concurrentes(ids):
    v, site = ids["variantes"]["LAMPE-LIN-NAT"], ids["sites"]["paris"]
    with SessionLocal() as db:
        loc = db.scalar(select(Location).where(Location.site_id == site, Location.code == "RESERVE"))
        lot_id = inv.fefo_candidates(db, v, site)[0][0].lot_id
    res = []

    def worker():
        with SessionLocal() as db:
            try:
                inv.post_movements(db, "PERTE", [inv.MoveLine(v, loc.id, Decimal(-3), "DISPONIBLE", lot_id)],
                                   actor_id=None, reason="test casse")
                db.commit()
                res.append("ok")
            except DomainError:
                db.rollback()
                res.append("refus")

    th = [threading.Thread(target=worker) for _ in range(6)]  # 6 × 3 = 18 > 8 en stock
    [t.start() for t in th]
    [t.join() for t in th]
    assert res.count("ok") == 2
    with SessionLocal() as db:
        assert db.get(StockPosition, (v, site)).on_hand == Decimal(2)
        assert inv.check_consistency(db)["coherent"]


def test_correction_liee_sans_reecriture(ids):
    v, site = ids["variantes"]["POELE-28-FONTE"], ids["sites"]["lyon"]
    with SessionLocal() as db:
        loc = db.scalar(select(Location).where(Location.site_id == site, Location.code == "RESERVE"))
        lot_id = inv.fefo_candidates(db, v, site)[0][0].lot_id
        m = inv.post_movements(db, "PERTE", [inv.MoveLine(v, loc.id, Decimal(-2), "DISPONIBLE", lot_id)], actor_id=1,
                               reason="casse déclarée")[0]
        db.commit()
        with pytest.raises(DomainError):
            inv.correct_movement(db, m.id, Decimal(-1), "", 1)  # motif requis
        corr = inv.correct_movement(db, m.id, Decimal(-1), "Une seule poêle cassée après recomptage", 1)[0]
        db.commit()
        orig = db.get(StockMovement, m.id)
        assert orig.quantity == Decimal(-2)  # l'original n'est pas modifié
        assert corr.corrects_movement_id == m.id and corr.quantity == Decimal(1) and corr.actor_user_id == 1
        assert db.get(StockPosition, (v, site)).on_hand == Decimal(4)
        assert inv.check_consistency(db)["coherent"]


def test_prix_fige_a_la_vente(api, ids):
    v, site = ids["variantes"]["HUILE-OLV-75"], ids["sites"]["paris"]
    reg = next(r for r in api.ok("GET", "/api/caisse/postes", "caisse.paris") if r["site_id"] == site)
    sess = api.ok("POST", "/api/caisse/sessions", "caisse.paris", {"register_id": reg["id"], "opening_float_cents": 0})
    sale = api.ok("POST", "/api/caisse/ventes", "caisse.paris", {"session_id": sess["id"]})
    sale = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/lignes", "caisse.paris", {"code": "2002000000026"})
    assert sale["lines"][0]["unit_price_ttc_cents"] == 1250
    api.ok("POST", "/api/caisse/ventes/" + str(sale["id"]) + "/paiements", "caisse.paris",
           {"method": "ESPECES", "amount_cents": 1250}, key=key())
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.paris")
    # nouveau prix + changement de libellé au catalogue
    api.ok("POST", "/api/catalogue/prix", "achats.resp", {"price_list_code": "MAGASIN", "variant_id": v,
                                                           "amount_cents": 1390})
    with SessionLocal() as db:
        from app.modules.catalog.models import Variant

        db.get(Variant, v).label = "Huile d'olive — nouveau libellé"
        db.commit()
    again = api.ok("GET", f"/api/caisse/ventes/{sale['id']}", "caisse.paris")
    assert again["lines"][0]["unit_price_ttc_cents"] == 1250
    assert again["lines"][0]["label"] == "Huile d'olive vierge extra 75 cl"
    assert again["lines"][0]["tax_rate_bp"] == 550
    hist = api.ok("GET", f"/api/catalogue/prix/{v}/historique")
    mag = [h for h in hist if h["liste"] == "MAGASIN"]
    assert len(mag) == 2 and mag[0]["valid_to"] is not None  # l'ancien prix est borné, pas écrasé


def test_chevauchement_de_prix_interdit_par_la_base(ids):
    v = ids["variantes"]["HUILE-OLV-75"]
    with SessionLocal() as db:
        from sqlalchemy.exc import IntegrityError

        from app.modules.catalog.models import Price, PriceList

        pl = db.scalar(select(PriceList).where(PriceList.code == "MAGASIN"))
        db.add(Price(price_list_id=pl.id, variant_id=v, packaging_level="PIECE", amount_cents=1,
                     valid_from=utcnow() - timedelta(days=1)))
        with pytest.raises(IntegrityError):
            db.flush()


def test_vente_sans_stock_systeme_cree_une_exception(api, ids):
    """Le stock système ne bloque pas une vente physique : l'écart devient une exception à traiter."""
    site = ids["sites"]["lyon"]
    reg = next(r for r in api.ok("GET", "/api/caisse/postes", "caisse.lyon") if r["site_id"] == site)
    sess = api.ok("POST", "/api/caisse/sessions", "caisse.lyon", {"register_id": reg["id"], "opening_float_cents": 0})
    sale = api.ok("POST", "/api/caisse/ventes", "caisse.lyon", {"session_id": sess["id"]})
    sale = api.ok("POST", f"/api/caisse/ventes/{sale['id']}/lignes", "caisse.lyon",
                  {"code": cat.gtin_with_check("200100000002"), "quantity": 1})  # lampe : aucun stock à Lyon
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/paiements", "caisse.lyon",
           {"method": "ESPECES", "amount_cents": sale["total_ttc_cents"]}, key=key())
    api.ok("POST", f"/api/caisse/ventes/{sale['id']}/valider", "caisse.lyon")
    exc = api.ok("GET", "/api/stocks/exceptions")
    assert exc[0]["kind"] == "VENTE_SANS_STOCK"


def test_transfert_sans_lot_affecte_en_fefo_et_annulable(api, ids):
    v, e, p = ids["variantes"]["CONF-ABR-370"], ids["sites"]["entrepot"], ids["sites"]["paris"]
    t = api.ok("POST", "/api/stocks/transferts", "prepa.orleans", {"from_site_id": e, "to_site_id": p,
               "lines": [{"variant_id": v, "quantity": 300}]})
    # 240 pots du lot le plus proche de sa date (CV-2611-A) puis 60 du suivant
    assert sorted(float(l["quantity"]) for l in t["lines"]) == [60.0, 240.0]
    assert all(l["lot_id"] for l in t["lines"])
    assert api.ok("POST", f"/api/stocks/transferts/{t['id']}/annuler", "prepa.orleans")["status"] == "ANNULE"
    t2 = api.ok("POST", "/api/stocks/transferts", "prepa.orleans", {"from_site_id": e, "to_site_id": p,
                "lines": [{"variant_id": v, "quantity": 24}]})
    api.ok("POST", f"/api/stocks/transferts/{t2['id']}/expedier", "prepa.orleans")
    api.ok("POST", f"/api/stocks/transferts/{t2['id']}/recevoir", "magasin.paris", {})
    with SessionLocal() as db:
        assert inv.check_consistency(db)["coherent"]
