"""Registre : signatures, rejeu, conflits, pannes, issue inconnue, reprise après interruption, clés,
données personnelles, ordre de publication. Exécuté contre le registre SIMULÉ (même contrat que la
passerelle Fabric ; voir test_fabric_integration.py pour le réseau réel)."""
from __future__ import annotations

import base64
import json
from datetime import timedelta

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from sqlalchemy import select

from app.core.common import set_flag
from app.core.errors import DomainError
from app.core.types import utcnow
from app.db import SessionLocal
from app.modules.inventory.models import Lot
from app.modules.ledger.adapters import LedgerError, get_ledger
from app.modules.traceability import service as trace
from app.modules.traceability.models import LedgerOutbox, TraceEvent


def _declare(lot_code="AL-24-0901", **kw):
    with SessionLocal() as db:
        lot = db.scalar(select(Lot).where(Lot.lot_code == lot_code))
        ev = trace.declare_event(db, event_type=kw.pop("event_type", "INSPECTION_RECORDED"), occurred_at=utcnow(),
                                 actor_id=kw.pop("actor_id", 1), lot=lot, details=kw.pop("details", {"resultat": "OK"}), **kw)
        db.commit()
        return ev.id


def _ev(eid):
    with SessionLocal() as db:
        return db.get(TraceEvent, eid)


def test_publication_signature_et_rejeu(ids):
    eid = _declare()
    assert _ev(eid).ledger_status == "EN_ATTENTE"
    assert trace.process_outbox()["publies"] == 1
    ev = _ev(eid)
    assert ev.ledger_status == "CONFIRME" and ev.ledger_tx_id
    # rejeu exact du même contenu : DUPLICATE, pas de nouvelle écriture
    res = get_ledger().submit(ev.envelope, ev.signature_b64)
    assert res.status == "DUPLICATE" and res.tx_id == ev.ledger_tx_id
    # contenu modifié avec le même eventId : signature invalide
    tampered = ev.envelope.replace("INSPECTION_RECORDED", "RECALL")
    with pytest.raises(LedgerError) as e:
        get_ledger().submit(tampered, ev.signature_b64)
    assert e.value.code == "BAD_SIGNATURE"


def test_conflit_meme_identifiant_contenu_different(ids):
    from app.modules.traceability import keys

    eid = _declare()
    trace.process_outbox()
    ev = _ev(eid)
    env = json.loads(ev.envelope)
    env["locationRef"] = "AUTRE"
    s = trace.canonical(env)
    with pytest.raises(LedgerError) as e:
        get_ledger().submit(s, keys.get_signer().sign(s.encode()))
    assert e.value.code == "CONFLICT" and not e.value.retryable


def test_champs_non_autorises_et_donnees_personnelles(ids):
    from app.modules.traceability import keys

    env = {"schemaVersion": "1.0", "eventId": "x-1", "eventType": "RECEIPT", "issuerOrg": "MaisonMarcheMSP",
           "subject": {"kind": "LOT", "ref": "gtin:1|lot:2"}, "occurredAt": "2026-01-01T00:00:00Z",
           "declaredAt": trace.z(utcnow()), "evidence": [], "signerKeyId": keys.get_signer().key_id,
           "customerEmail": "client@example.invalid"}
    s = trace.canonical(env)
    with pytest.raises(LedgerError) as e:
        get_ledger().submit(s, keys.get_signer().sign(s.encode()))
    assert e.value.code == "INVALID_FIELD"
    with pytest.raises(DomainError):  # texte libre interdit comme lieu
        _declare(location_ref="Chez M. Dupont, 3 rue X")
    # les détails restent hors chaîne : seule une empreinte salée est publiée
    eid = _declare(details={"commentaire": "secret commercial : remise 12 %"})
    ev = _ev(eid)
    assert "secret" not in ev.envelope and json.loads(ev.envelope)["detailsDigest"] == ev.details_digest
    assert trace.details_digest(ev.details, ev.details_salt) == ev.details_digest


def test_panne_reprise_et_confirmation(ids):
    with SessionLocal() as db:
        set_flag(db, "ledger_outage", "1")
        db.commit()
    eid = _declare()
    st = trace.process_outbox()
    assert st["erreurs"] == 1
    ev = _ev(eid)
    assert ev.ledger_status == "EN_ATTENTE" and ev.ledger_error_code == "LEDGER_UNAVAILABLE"
    with SessionLocal() as db:
        ob = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == eid))
        assert ob.attempts == 1 and ob.next_attempt_at > utcnow()  # temporisation exponentielle
        set_flag(db, "ledger_outage", "0")
        ob.next_attempt_at = utcnow()
        db.commit()
    assert trace.process_outbox()["publies"] == 1
    assert _ev(eid).ledger_status == "CONFIRME"


def test_issue_inconnue_resolue_par_lecture_du_registre(ids):
    """La passerelle a enregistré la transaction mais la réponse s'est perdue (timeout)."""
    eid = _declare()
    ev = _ev(eid)
    get_ledger().submit(ev.envelope, ev.signature_b64)  # écrit sur le registre « dans notre dos »
    with SessionLocal() as db:
        e = db.get(TraceEvent, eid)
        e.ledger_status = "INCONNU"
        db.commit()
    st = trace.process_outbox()
    assert st["doublons"] == 1 and _ev(eid).ledger_status == "CONFIRME"


def test_reprise_apres_arret_brutal_du_worker(ids):
    eid = _declare()
    with SessionLocal() as db:  # simulation : ligne réservée par un worker mort
        ob = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == eid))
        ob.status, ob.locked_until = "EN_COURS", utcnow() - timedelta(seconds=1)
        db.commit()
    trace.process_outbox()
    assert _ev(eid).ledger_status == "CONFIRME"


def test_ordre_de_publication_respecte(ids):
    first = _declare()
    second = _declare(event_type="CORRECTION", corrects_event_id=first, details={"motif": "erreur de saisie"})
    with SessionLocal() as db:  # le second passe avant dans la file
        o1 = db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == first))
        o1.next_attempt_at = utcnow() + timedelta(minutes=5)
        db.commit()
    st = trace.process_outbox()
    assert st["reportes"] == 1 and _ev(second).ledger_status == "EN_ATTENTE"
    with SessionLocal() as db:
        db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == first)).next_attempt_at = utcnow()
        db.commit()
    trace.process_outbox()
    with SessionLocal() as db:  # l'événement dépendant avait été reporté de 5 s
        db.scalar(select(LedgerOutbox).where(LedgerOutbox.trace_event_id == second)).next_attempt_at = utcnow()
        db.commit()
    trace.process_outbox()
    assert _ev(first).ledger_status == "CONFIRME" and _ev(second).ledger_status == "CONFIRME"
    assert _ev(first).envelope != _ev(second).envelope  # la correction est un nouvel événement lié


def test_correction_d_un_evenement_d_une_autre_organisation_refusee(ids):
    from app.simulators.supplier import SupplierNode

    node = SupplierNode("AtelierLumiereMSP")
    node.ensure_key()
    with SessionLocal() as db:
        lot = db.scalar(select(Lot).where(Lot.lot_code == "AL-24-0901"))
        from app.modules.catalog.models import Variant

        gtin = db.get(Variant, lot.variant_id).gtin
    e = node.emit("SUPPLIER_SHIPMENT", gtin, "AL-24-0901", utcnow(), counterparty="MaisonMarcheMSP")
    trace.reconcile()
    assert _ev(e["eventId"]).origin == "EXTERNE" and _ev(e["eventId"]).local_status == "SIGNE"
    with pytest.raises(DomainError) as err:
        _declare(event_type="CORRECTION", corrects_event_id=e["eventId"])
    assert err.value.code == "CORRECTION_NON_PROPRIETAIRE"
    d = _declare(event_type="DISPUTE", corrects_event_id=e["eventId"], details={"motif": "quantité contestée"})
    trace.process_outbox()
    assert _ev(d).ledger_status == "CONFIRME"


def test_transfert_de_garde_provisoire_puis_confirme(ids):
    from app.simulators.supplier import SupplierNode

    eid = _declare(event_type="CUSTODY_TRANSFER", counterparty_org="AtelierLumiereMSP")
    trace.process_outbox()
    assert _ev(eid).counterparty_status == "EN_ATTENTE_CONTREPARTIE"
    node = SupplierNode("AtelierLumiereMSP")
    node.ensure_key()
    env = json.loads(_ev(eid).envelope)
    node.emit("RECEIPT", env["subject"]["gtin"], env["subject"]["lot"], utcnow(), previous=eid)
    trace.reconcile()
    assert _ev(eid).counterparty_status == "CONFIRME_PAR_CONTREPARTIE"


def test_cle_inconnue_ou_revoquee(ids):
    k = Ed25519PrivateKey.generate()
    env = {"schemaVersion": "1.0", "eventId": "k-1", "eventType": "RECEIPT", "issuerOrg": "MaisonMarcheMSP",
           "subject": {"kind": "LOT", "ref": "gtin:1|lot:2"}, "occurredAt": trace.z(utcnow()),
           "declaredAt": trace.z(utcnow()), "evidence": [], "signerKeyId": "cle-pirate"}
    s = trace.canonical(env)
    with pytest.raises(LedgerError) as e:
        get_ledger().submit(s, base64.b64encode(k.sign(s.encode())).decode())
    assert e.value.code == "UNKNOWN_KEY"
    from app.modules.traceability import keys

    get_ledger().revoke_key(keys.get_signer().key_id, utcnow() - timedelta(seconds=1), "test de compromission")
    eid = _declare()
    trace.process_outbox()
    assert _ev(eid).ledger_status == "REJETE" and _ev(eid).ledger_error_code == "KEY_REVOKED"


def test_verification_independante_separation_des_taches(ids):
    eid = _declare(actor_id=1)
    with SessionLocal() as db:
        with pytest.raises(DomainError):
            trace.record_verification(db, eid, method="CONTROLE_PHYSIQUE", verifier_name="x", verifier_org="y",
                                      result="CONFORME", performed_at=utcnow(), notes="", evidence_object_id=None,
                                      actor_id=1)
        with pytest.raises(DomainError):  # une analyse exige une pièce
            trace.record_verification(db, eid, method="ANALYSE_LABORATOIRE", verifier_name="x", verifier_org="y",
                                      result="CONFORME", performed_at=utcnow(), notes="", evidence_object_id=None,
                                      actor_id=2)
        trace.record_verification(db, eid, method="CONTROLE_PHYSIQUE", verifier_name="x", verifier_org="y",
                                  result="CONFORME", performed_at=utcnow(), notes="ok", evidence_object_id=None, actor_id=2)
        db.commit()
        levels = trace.proof_levels(db, db.get(TraceEvent, eid))
    assert [l["atteint"] for l in levels] == [True, True, False, True]  # pas encore confirmé sur le registre
