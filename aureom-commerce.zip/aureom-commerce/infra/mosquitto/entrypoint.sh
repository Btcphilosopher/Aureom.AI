#!/bin/sh
# Génère le fichier de mots de passe à partir des variables (jamais versionné).
set -e
cp /config-src/mosquitto.conf /config-src/acl /mosquitto/config/
: > /mosquitto/config/passwd
mosquitto_passwd -b /mosquitto/config/passwd aureom-bridge "$MQTT_BRIDGE_PASSWORD"
for d in $MQTT_DEVICES; do mosquitto_passwd -b /mosquitto/config/passwd "$d" "$MQTT_DEVICE_PASSWORD"; done
chmod 0700 /mosquitto/config/passwd
chown -R mosquitto:mosquitto /mosquitto/config /mosquitto/data 2>/dev/null || true
exec mosquitto -c /mosquitto/config/mosquitto.conf
