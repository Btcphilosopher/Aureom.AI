#!/usr/bin/env bash
# Restauration puis contrôles : cohérence du stock et réconciliation avec le registre.
# Usage : scripts/restauration.sh sauvegardes/aureom-….dump
set -euo pipefail
cd "$(dirname "$0")/.."
dump="$1"
docker compose stop backend worker iot-bridge
docker compose exec -T postgres sh -c 'cat > /tmp/r.dump' < "$dump"
# L'extension btree_gist appartient au superutilisateur : exclue de la liste de restauration.
docker compose exec -T postgres sh -c 'pg_restore -l /tmp/r.dump | grep -v " EXTENSION " > /tmp/r.list && \
  pg_restore -U aureom --clean --if-exists --no-owner -L /tmp/r.list -d aureom /tmp/r.dump'
docker compose start backend worker iot-bridge
sleep 10
docker compose exec -T backend python -c "
from app import models
from app.db import SessionLocal
from app.modules.inventory.service import check_consistency
from app.modules.traceability.service import reconcile
with SessionLocal() as db: print('Cohérence stock :', check_consistency(db))
print('Réconciliation :', reconcile()['resume'])"
