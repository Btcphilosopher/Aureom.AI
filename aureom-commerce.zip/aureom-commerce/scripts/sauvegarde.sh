#!/usr/bin/env bash
# Sauvegarde PostgreSQL (format custom) depuis le conteneur Compose. Usage : scripts/sauvegarde.sh [fichier]
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:-sauvegardes/aureom-$(date -u +%Y%m%dT%H%M%SZ).dump}"
mkdir -p "$(dirname "$out")"
docker compose exec -T postgres pg_dump -U aureom -Fc aureom > "$out"
echo "Sauvegarde : $out ($(du -h "$out" | cut -f1))"
echo "Rappel : le registre Fabric n'est pas dans cette sauvegarde (il est répliqué par le réseau)."
