#!/usr/bin/env bash
# Crée les secrets locaux de démonstration (hors dépôt) : clé Ed25519 de Maison & Marché, fichier .env.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p secrets && chmod 700 secrets
if [ ! -f secrets/maisonmarche-signing.key ]; then
  openssl genpkey -algorithm ed25519 -out secrets/maisonmarche-signing.key
  chmod 600 secrets/maisonmarche-signing.key
  echo "Clé de signature créée : secrets/maisonmarche-signing.key"
fi
if [ ! -f .env ]; then
  cp .env.example .env
  sed -i "s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$(openssl rand -hex 16)/" .env
  sed -i "s/^AUREOM_PSP_WEBHOOK_SECRET=.*/AUREOM_PSP_WEBHOOK_SECRET=$(openssl rand -hex 24)/" .env
  sed -i "s/^MQTT_BRIDGE_PASSWORD=.*/MQTT_BRIDGE_PASSWORD=$(openssl rand -hex 16)/" .env
  sed -i "s/^MQTT_DEVICE_PASSWORD=.*/MQTT_DEVICE_PASSWORD=$(openssl rand -hex 16)/" .env
  sed -i "s/^S3_SECRET_KEY=.*/S3_SECRET_KEY=$(openssl rand -hex 20)/" .env
  echo "Fichier .env créé avec des secrets aléatoires"
fi
# Configuration S3 de SeaweedFS alignée sur les identifiants du .env
set -a; . ./.env; set +a
mkdir -p secrets
cat > secrets/seaweedfs-s3.json <<JSON
{"identities":[{"name":"aureom","credentials":[{"accessKey":"${S3_ACCESS_KEY}","secretKey":"${S3_SECRET_KEY}"}],"actions":["Read","Write","List","Tagging","Admin"]}]}
JSON
chmod 600 secrets/seaweedfs-s3.json

# Les secrets « fichier » de Docker Compose sont montés avec les droits de l'hôte : on attribue chaque
# fichier à l'utilisateur non-root du conteneur qui le lit (10001 = aureom, 1000 = seaweed).
give() { chown "$2" "$1" 2>/dev/null || sudo -n chown "$2" "$1" 2>/dev/null || {
  chmod 644 "$1"; echo "AVERTISSEMENT : $1 rendu lisible par tous (chown impossible sans droits root)"; }; }
give secrets/maisonmarche-signing.key 10001
give secrets/seaweedfs-s3.json 1000
