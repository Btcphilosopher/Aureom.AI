# AUREOM COMMERCE — interface web

Interface web du prototype **AUREOM COMMERCE — Gestion du commerce connecté**, pour l'enseigne fictive
**Maison & Marché**. Elle consomme exclusivement l'API FastAPI du dossier `backend/` (routes `/api/…` et
WebSocket `/ws`).

> Prototype : la caisse n'est **pas certifiée** (bandeau permanent « Prototype non certifié — ne pas utiliser
> pour encaisser réellement »), le terminal de paiement est simulé (jetons `tok_sim_*`, jamais de numéro de
> carte) et le registre de traçabilité peut être **simulé** (badge « Registre SIMULÉ (non distribué) »).

## Pile technique

- React 19 + TypeScript strict + Vite 7, routage `react-router` 7.
- Aucune bibliothèque d'interface ni de graphiques : composants et CSS écrits à la main (variables CSS),
  graphiques en SVG (`src/components/charts.tsx`).
- Dépendances d'exécution : `react`, `react-dom`, `react-router` uniquement.

## Démarrage

Prérequis : Node 22, backend lancé sur `http://localhost:8000`.

```bash
cd frontend
npm install
npm run dev            # http://localhost:5173 — proxy /api et /ws → localhost:8000
npm run build          # vérification TypeScript (tsc -b) + build de production dans dist/
npm run preview        # sert dist/ avec le même proxy
```

Autre adresse de backend : `AUREOM_BACKEND=http://hote:8000 npm run dev`.

Comptes de démonstration (mot de passe commun `demo-aureom-2026`) : `admin`, `direction`, `magasin.paris`,
`caisse.paris`, `caisse.lyon`, `prepa.orleans`, `prepa.paris`, `achats`, `achats.resp`, `qualite`,
`analyste`. L'écran de connexion propose de les pré-remplir.

Pour disposer de données riches (commandes, rappel, alertes, événements signés), rejouer la démonstration du
backend : `python -m app.demo --sortie /tmp/demo-front` (voir `backend/`).

### Conteneur

`Dockerfile` multi-étapes : `node:22-alpine` (build) puis `nginx:alpine` (service de `dist/`).
`nginx.conf` relaie `/api/` et `/ws` (en-têtes `Upgrade`/`Connection` pour le WebSocket) vers le service
`backend:8000` et renvoie `index.html` pour les routes de l'application.

```bash
# Docker Hub limite les téléchargements anonymes : registre surchargeable
docker build --build-arg REGISTRY=mirror.gcr.io/library -t aureom/frontend:1.0.0 .
docker run --rm -p 8080:80 --network <réseau-du-backend> aureom/frontend:1.0.0
```

Derrière un proxy qui inspecte TLS, fournir son certificat d'autorité (facultatif) et le réseau de l'hôte :

```bash
docker build --network host --secret id=npm_ca,src=/chemin/ca.crt \
  --build-arg REGISTRY=mirror.gcr.io/library -t aureom/frontend:1.0.0 .
```

Image vérifiée : `index.html`, liens profonds (`/tracabilite/rappels/1`), `/api/sante` et le WebSocket `/ws`
répondent au travers de nginx (`--add-host backend:host-gateway` pour un backend lancé sur l'hôte).

## Structure

```
src/
  main.tsx, App.tsx          point d'entrée, routes, garde de permissions par écran
  api/client.ts              fetch + jeton Bearer + erreurs {code, message, details} + Idempotency-Key
  api/types.ts               types des réponses utilisées
  state/auth.tsx             connexion, /api/auth/moi, permissions (can / canAny)
  state/site.tsx             sites (/api/sites), site courant, organisations, libellés d'emplacements
  state/live.tsx             WebSocket /ws?token=… (reconnexion exponentielle 1 → 15 s), abonnements
  state/toast.tsx            notifications
  lib/format.ts              €, dates Europe/Paris, quantités avec unité (pièces, kg, cartons…)
  lib/hooks.ts               useApi (rechargement sur événements temps réel), useAction (anti double clic),
                             useIntentKey / withIntent (clé d'idempotence par intention), useQueryState
  lib/labels.ts, liveText.ts libellés français des statuts et des événements temps réel
  lib/catalogIndex.ts        index des variantes (SKU, libellé, unité, codes-barres)
  components/                Shell (navigation, en-tête), ui (cartes, tableaux, fenêtres, badges…),
                             ProofStepper (4 niveaux de preuve), charts (SVG), forms (transfert, réception)
  pages/                     un fichier par module : Dashboard, Pos, Catalog, Stocks, Purchasing, Orders,
                             Warehouse, Customers, Traceability, Automation, Analytics, Admin, Login
  styles/                    global.css (jetons, bureau), pos.css (caisse), warehouse.css (tablette)
```

## Trois dispositions

1. **Bureau** (toutes les pages sauf Caisse et Entrepôts) : barre latérale bleu nuit, zones de travail
   blanches, accents bleu électrique et cuivre. En-tête : sélecteur de site, badge du registre
   (« Registre SIMULÉ (non distribué) » ou « Hyperledger Fabric — n organisations », état de panne), indicateur
   de connexion temps réel, fil des événements, utilisateur. La navigation masque les entrées non autorisées.
2. **Caisse** (`/caisse`, plein écran tactile) : cibles ≥ 48 px, champ de scan qui garde le focus (douchette en
   émulation clavier, scans mis en file pour ne rien perdre), pavé numérique (quantité, montant remis,
   fond de caisse), panier à droite, panneau de paiement (espèces avec rendu, carte simulée acceptée / refusée /
   différée, paiements partiels), remise et annulation de ligne avec autorisation d'un responsable si le serveur
   répond `NON_AUTORISE`, ticket monospace « TICKET DE DÉMONSTRATION », clôture avec rapport et écart.
3. **Entrepôt** (`/entrepots`, tablette) : gros onglets Prélèvements / Transferts / Réceptions, champ de scan,
   tâches de prélèvement FEFO confirmées par le scan de l'article attendu, « Prête au retrait » (code de
   retrait affiché une seule fois), réception des transferts entrants, réception fournisseur.

Toutes les pages s'adaptent jusqu'à 768 px (tablette) et restent utilisables sur téléphone (navigation en
tiroir, grilles empilées, tableaux défilants).

## Règles d'interface respectées

- Messages d'erreur : le `message` français de l'API est toujours affiché (avec le code en complément).
- Montants en centimes → « 1 234,56 € » ; dates UTC → « 28/11/2026 14:05 » (Europe/Paris) ; quantités
  toujours suivies de leur unité.
- Paiements, ventes et commandes : en-tête `Idempotency-Key` généré une fois par intention
  (`crypto.randomUUID()`), réutilisé en cas de nouvelle tentative après erreur réseau / 5xx, renouvelé après
  une réponse définitive. Les boutons sont verrouillés pendant l'appel (un double clic n'envoie qu'une requête).
- Commandes : statut logistique et statut de paiement affichés séparément (« Payée » ≠ « Prête »).
- Traçabilité : quatre niveaux de preuve (Déclaré / Signé / Confirmé sur le registre / Vérifié par contrôle
  indépendant) avec ✔/✘ et explications ; **jamais** de badge « authentique » ; limites de la preuve
  affichées en bandeau et dans un onglet dédié ; documents fournisseurs « Non vérifié » mis en évidence.
- Rapports de lot HTML/CSV/JSON récupérés avec le jeton (Blob) puis ouverts ou téléchargés.
- Analyses : CA, encaissements, marge et bénéfice distingués (bénéfice « non disponible » avec explication),
  fraîcheur des données et lacunes visibles. Prévisions : tableau d'évaluation (MAE, RMSE, biais, MASE),
  modèle retenu et règle de choix, intervalle à 80 % en bande SVG, avertissement « données synthétiques ».

## Accessibilité

- Alertes : icône **et** libellé texte (« Critique », « Attention », « Information ») ; statuts toujours
  écrits, jamais portés par la couleur seule.
- Contrastes AA sur fond blanc et sur la navigation bleu nuit ; focus visible (double anneau) sur tous les
  éléments interactifs ; lien d'évitement « Aller au contenu ».
- Fenêtres modales `role="dialog"` + `aria-modal`, focus piégé, fermeture par Échap, retour du focus.
- Onglets `role="tablist"` navigables aux flèches ; définitions de stock en infobulles accessibles au clavier
  et au toucher ; tableaux avec légende ; graphiques avec titre, points focusables et tableau de valeurs.
- Zones `aria-live` pour les messages de scan, les totaux de caisse et les notifications ;
  `prefers-reduced-motion` respecté.

## Captures

Les captures (Playwright, facteur 2) sont dans `docs/captures/` : tableau de bord, caisse pendant une vente,
paiement, ticket, clôture, tablette d'entrepôt, détail d'un événement de traçabilité avec niveaux de preuve,
prévision, détail d'un rappel, analyses, etc.
