import { type ReactNode } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes } from "react-router";
import { LiveToasts, NAV, OfficeShell, useNav } from "./components/Shell";
import { Loading, Notice } from "./components/ui";
import { useAuth, AuthProvider } from "./state/auth";
import { LiveProvider } from "./state/live";
import { SiteProvider } from "./state/site";
import { ToastProvider } from "./state/toast";
import LoginPage from "./pages/Login";
import DashboardPage from "./pages/Dashboard";
import PosPage from "./pages/Pos";
import CatalogPage from "./pages/Catalog";
import StocksPage from "./pages/Stocks";
import PurchasingPage from "./pages/Purchasing";
import OrdersPage, { OrderDetailPage } from "./pages/Orders";
import WarehousePage from "./pages/Warehouse";
import CustomersPage, { CustomerDetailPage } from "./pages/Customers";
import TraceabilityPage, { EventDetailPage, RecallDetailPage } from "./pages/Traceability";
import AutomationPage from "./pages/Automation";
import AnalyticsPage from "./pages/Analytics";
import AdminPage from "./pages/Admin";

function Guard({ path, children, bare }: { path: string; children: ReactNode; bare?: boolean }) {
  const { canAny } = useAuth();
  const item = NAV.find((n) => n.to === path);
  const ok = !item || canAny(...item.perms);
  const content = ok ? (
    children
  ) : (
    <Notice tone="warning" title="Accès non autorisé">
      Votre rôle ne donne pas accès à « {item?.label} ». <Link to="/">Revenir à l'accueil</Link>
    </Notice>
  );
  return bare && ok ? <>{content}</> : <OfficeShell>{content}</OfficeShell>;
}

function Home() {
  const nav = useNav();
  const { can } = useAuth();
  if (can("stock.read")) return <DashboardPage />;
  if (nav.length > 0) return <Navigate to={nav[0].to} replace />;
  return (
    <Notice tone="warning" title="Aucun module accessible">
      Ce compte n'a accès à aucun écran de l'application.
    </Notice>
  );
}

function Authenticated() {
  const { token } = useAuth();
  return (
    <LiveProvider token={token}>
      <SiteProvider>
        <LiveToasts />
        <Routes>
          <Route path="/" element={<Guard path="/"><Home /></Guard>} />
          <Route path="/caisse" element={<Guard path="/caisse" bare><PosPage /></Guard>} />
          <Route path="/catalogue" element={<Guard path="/catalogue"><CatalogPage /></Guard>} />
          <Route path="/stocks" element={<Guard path="/stocks"><StocksPage /></Guard>} />
          <Route path="/achats" element={<Guard path="/achats"><PurchasingPage /></Guard>} />
          <Route path="/commandes" element={<Guard path="/commandes"><OrdersPage /></Guard>} />
          <Route path="/commandes/:id" element={<Guard path="/commandes"><OrderDetailPage /></Guard>} />
          <Route path="/entrepots" element={<Guard path="/entrepots" bare><WarehousePage /></Guard>} />
          <Route path="/clients" element={<Guard path="/clients"><CustomersPage /></Guard>} />
          <Route path="/clients/:id" element={<Guard path="/clients"><CustomerDetailPage /></Guard>} />
          <Route path="/tracabilite" element={<Guard path="/tracabilite"><TraceabilityPage /></Guard>} />
          <Route path="/tracabilite/evenements/:id" element={<Guard path="/tracabilite"><EventDetailPage /></Guard>} />
          <Route path="/tracabilite/rappels/:id" element={<Guard path="/tracabilite"><RecallDetailPage /></Guard>} />
          <Route path="/automatisations" element={<Guard path="/automatisations"><AutomationPage /></Guard>} />
          <Route path="/analyses" element={<Guard path="/analyses"><AnalyticsPage /></Guard>} />
          <Route path="/administration" element={<Guard path="/administration"><AdminPage /></Guard>} />
          <Route
            path="*"
            element={
              <OfficeShell>
                <Notice tone="warning" title="Page introuvable">
                  <Link to="/">Revenir au tableau de bord</Link>
                </Notice>
              </OfficeShell>
            }
          />
        </Routes>
      </SiteProvider>
    </LiveProvider>
  );
}

function Root() {
  const { ready, user } = useAuth();
  if (!ready) return <Loading label="Ouverture de la session…" />;
  if (!user) return <LoginPage />;
  return <Authenticated />;
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <Root />
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
