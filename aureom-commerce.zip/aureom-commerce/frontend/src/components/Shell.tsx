import { useEffect, useState, type ReactNode } from "react";
import { NavLink, useLocation } from "react-router";
import { api } from "../api/client";
import type { Health, Organisation } from "../api/types";
import { useInterval } from "../lib/hooks";
import { ROLE_LABELS } from "../lib/labels";
import { describeLive } from "../lib/liveText";
import { timeOnly } from "../lib/format";
import { useAuth } from "../state/auth";
import { useLive, useLiveEvents } from "../state/live";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";
import { Icon } from "./Icon";

export interface NavItem {
  to: string;
  label: string;
  icon: string;
  perms: string[]; // au moins une
}

export const NAV: NavItem[] = [
  { to: "/", label: "Tableau de bord", icon: "dashboard", perms: ["stock.read"] },
  { to: "/caisse", label: "Caisse", icon: "pos", perms: ["pos.sell"] },
  { to: "/catalogue", label: "Catalogue", icon: "catalog", perms: ["catalog.read"] },
  { to: "/stocks", label: "Stocks", icon: "stock", perms: ["stock.read"] },
  { to: "/achats", label: "Achats", icon: "purchase", perms: ["purchase.read"] },
  { to: "/commandes", label: "Commandes", icon: "orders", perms: ["order.read"] },
  { to: "/entrepots", label: "Entrepôts", icon: "warehouse", perms: ["order.fulfil", "receipt.write", "stock.transfer"] },
  { to: "/clients", label: "Clients", icon: "customers", perms: ["customer.read"] },
  { to: "/tracabilite", label: "Traçabilité", icon: "trace", perms: ["trace.read"] },
  { to: "/automatisations", label: "Automatisations", icon: "automation", perms: ["automation.read"] },
  { to: "/analyses", label: "Analyses", icon: "analytics", perms: ["analytics.read"] },
  { to: "/administration", label: "Administration", icon: "admin", perms: ["admin.users", "admin.demo", "ledger.admin"] },
];

export function useNav(): NavItem[] {
  const { canAny } = useAuth();
  return NAV.filter((n) => canAny(...n.perms));
}

/* ---- Indicateurs d'en-tête -------------------------------------------------------------------------- */

export function LiveIndicator() {
  const { status, retryIn } = useLive();
  const label = status === "connecte" ? "Temps réel : connecté" : status === "connexion" ? "Temps réel : connexion…" : `Temps réel : déconnecté${retryIn ? ` (nouvel essai dans ${retryIn} s)` : ""}`;
  return (
    <span className={`live-ind live-${status}`} role="status" aria-live="polite" title={label}>
      <Icon name={status === "deconnecte" ? "wifi-off" : "wifi"} size={16} />
      <span className="live-dot" aria-hidden="true" />
      <span className="live-text">{status === "connecte" ? "Temps réel" : status === "connexion" ? "Connexion…" : "Hors ligne"}</span>
      <span className="sr-only">{label}</span>
    </span>
  );
}

export function RegistryBadge() {
  const [health, setHealth] = useState<Health | null>(null);
  const [outage, setOutage] = useState<boolean>(false);
  const [orgs, setOrgs] = useState<Organisation[]>([]);
  const load = () => {
    api<Health>("/api/sante").then(setHealth).catch(() => setHealth(null));
    api<{ panne_simulee: boolean }>("/api/admin/demo/panne-registre").then((r) => setOutage(r.panne_simulee)).catch(() => undefined);
  };
  useEffect(() => {
    load();
    api<Organisation[]>("/api/organisations").then(setOrgs).catch(() => undefined);
  }, []);
  useInterval(load, 30000);
  useLiveEvents(["tracabilite.confirme", "tracabilite.rejete"], load);
  useEffect(() => {
    const h = () => load();
    window.addEventListener("aureom:registre", h);
    return () => window.removeEventListener("aureom:registre", h);
  }, []);
  if (!health) {
    return (
      <span className="reg-badge reg-unknown" role="status">
        <Icon name="ledger" size={16} /> Registre : état inconnu
      </span>
    );
  }
  const r = health.registre;
  const down = outage || r.disponible === false;
  const members = orgs.filter((o) => o.ledger_member).length;
  const main = r.distribue ? `Hyperledger Fabric — ${members} organisation${members > 1 ? "s" : ""}` : "Registre SIMULÉ (non distribué)";
  return (
    <span className={`reg-badge ${r.distribue ? "reg-fabric" : "reg-sim"} ${down ? "reg-down" : ""}`} role="status" title={down ? "Registre indisponible : les opérations continuent, les événements partagés restent « en attente »." : main}>
      <Icon name={down ? "warning" : "ledger"} size={16} />
      <span>{main}</span>
      {down && <strong className="reg-out">{outage ? "Panne simulée — indisponible" : "Indisponible"}</strong>}
    </span>
  );
}

export function SiteSelector({ compact }: { compact?: boolean }) {
  const { mySites, siteId, setSiteId, sites } = useSite();
  const { user } = useAuth();
  const restricted = (user?.sites.length ?? 0) > 0;
  if (sites.length === 0) return null;
  return (
    <label className={`site-sel ${compact ? "compact" : ""}`}>
      <span className="sr-only">Site courant</span>
      <Icon name="warehouse" size={16} />
      <select value={siteId ?? ""} onChange={(e) => setSiteId(e.target.value ? Number(e.target.value) : null)} aria-label="Site courant">
        {!restricted && <option value="">Tous les sites</option>}
        {mySites.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </select>
    </label>
  );
}

export function UserMenu() {
  const { user, logout } = useAuth();
  if (!user) return null;
  return (
    <div className="user-menu">
      <span className="user-avatar" aria-hidden="true">
        {user.nom
          .split(" ")
          .map((p) => p[0])
          .slice(0, 2)
          .join("")}
      </span>
      <span className="user-info">
        <strong>{user.nom}</strong>
        <span className="muted small">{user.roles.map((r) => ROLE_LABELS[r] ?? r).join(", ")}</span>
      </span>
      <button className="icon-btn" onClick={() => logout()} aria-label="Se déconnecter" title="Se déconnecter">
        <Icon name="logout" />
      </button>
    </div>
  );
}

/** Fil des événements temps réel (panneau latéral). */
export function LiveFeed({ onClose }: { onClose: () => void }) {
  const { events } = useLive();
  return (
    <aside className="feed" aria-label="Fil des événements temps réel">
      <div className="feed-head">
        <h2>Fil temps réel</h2>
        <button className="icon-btn" onClick={onClose} aria-label="Fermer le fil">
          <Icon name="close" />
        </button>
      </div>
      {events.length === 0 && <p className="muted">Aucun événement reçu depuis l'ouverture de la page.</p>}
      <ol className="feed-list">
        {events.map((e) => {
          const d = describeLive(e);
          return (
            <li key={e.id}>
              <time className="muted small">{timeOnly(e.recu_le)}</time>
              <strong>{d.title}</strong>
              <span>{d.text}</span>
            </li>
          );
        })}
      </ol>
    </aside>
  );
}

/** Transforme certains événements temps réel en notifications. */
export function LiveToasts() {
  const { push } = useToast();
  useLiveEvents(["*"], (e) => {
    const d = describeLive(e);
    if (d.toast) push(d.toast, d.title, d.text);
  });
  return null;
}

/* ---- Mise en page bureau ---------------------------------------------------------------------------- */

export function OfficeShell({ children }: { children: ReactNode }) {
  const nav = useNav();
  const [open, setOpen] = useState(false);
  const [feed, setFeed] = useState(false);
  const { events } = useLive();
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  return (
    <div className={`shell ${open ? "nav-open" : ""}`}>
      <a href="#contenu" className="skip-link">
        Aller au contenu
      </a>
      <aside className="sidebar" aria-label="Navigation principale">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 64 64" width="34" height="34">
              <rect width="64" height="64" rx="14" fill="#13294d" />
              <path d="M18 46 32 16l14 30" fill="none" stroke="#4d8bff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M24 36h16" stroke="#d08a4b" strokeWidth="6" strokeLinecap="round" />
            </svg>
          </span>
          <span className="brand-text">
            <strong>AUREOM COMMERCE</strong>
            <span>Gestion du commerce connecté</span>
          </span>
        </div>
        <p className="brand-retailer">Maison &amp; Marché <span>(enseigne fictive)</span></p>
        <nav>
          <ul>
            {nav.map((n) => (
              <li key={n.to}>
                <NavLink to={n.to} end={n.to === "/"} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                  <Icon name={n.icon} />
                  <span>{n.label}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <p className="sidebar-foot">Prototype — données de démonstration</p>
      </aside>
      {open && <div className="nav-scrim" onClick={() => setOpen(false)} aria-hidden="true" />}
      <div className="main-col">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={() => setOpen((o) => !o)} aria-label="Ouvrir la navigation" aria-expanded={open}>
            <Icon name="menu" />
          </button>
          <SiteSelector />
          <div className="topbar-spacer" />
          <RegistryBadge />
          <LiveIndicator />
          <button className={`icon-btn feed-btn ${feed ? "active" : ""}`} onClick={() => setFeed((f) => !f)} aria-label={`Fil temps réel (${events.length} événements)`} aria-expanded={feed}>
            <Icon name="bell" />
            {events.length > 0 && <span className="feed-count">{Math.min(99, events.length)}</span>}
          </button>
          <UserMenu />
        </header>
        <main id="contenu" className="content" tabIndex={-1}>
          {children}
        </main>
      </div>
      {feed && <LiveFeed onClose={() => setFeed(false)} />}
    </div>
  );
}
