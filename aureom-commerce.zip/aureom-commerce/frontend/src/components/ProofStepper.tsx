import type { ProofLevel } from "../api/types";
import { Icon } from "./Icon";

const ORDER = ["DECLARE", "SIGNE", "CONFIRME_REGISTRE", "VERIFIE_INDEPENDAMMENT"];
const DEFAULT_LABEL: Record<string, string> = {
  DECLARE: "Déclaré",
  SIGNE: "Signé",
  CONFIRME_REGISTRE: "Confirmé sur le registre",
  VERIFIE_INDEPENDAMMENT: "Vérifié par contrôle indépendant",
};
const WHAT_IT_MEANS: Record<string, string> = {
  DECLARE: "Une organisation affirme que l'événement a eu lieu.",
  SIGNE: "Le contenu n'a pas été modifié depuis sa signature par la clé indiquée.",
  CONFIRME_REGISTRE: "La déclaration est conservée et partagée selon le protocole du registre ; sa véracité n'est pas établie.",
  VERIFIE_INDEPENDAMMENT: "Une personne distincte du déclarant a documenté un contrôle (physique, analyse, audit).",
};

/** Les 4 niveaux de preuve, cumulatifs. Aucun niveau ne signifie « authentique ». */
export function ProofStepper({ levels, compact }: { levels: ProofLevel[]; compact?: boolean }) {
  const byCode = new Map(levels.map((l) => [l.niveau, l]));
  const items = ORDER.map((c) => byCode.get(c) ?? { niveau: c, atteint: false, libelle: DEFAULT_LABEL[c], explication: "Non atteint." });
  if (compact) {
    return (
      <ol className="proof-mini" aria-label="Niveaux de preuve">
        {items.map((l) => (
          <li key={l.niveau} className={l.atteint ? "ok" : "ko"} title={`${l.libelle} : ${l.atteint ? "atteint" : "non atteint"}`}>
            <span aria-hidden="true">{l.atteint ? "✔" : "✘"}</span>
            <span className="sr-only">
              {l.libelle} : {l.atteint ? "atteint" : "non atteint"}
            </span>
          </li>
        ))}
      </ol>
    );
  }
  return (
    <ol className="proof-stepper" aria-label="Niveaux de preuve de l'événement">
      {items.map((l, i) => (
        <li key={l.niveau} className={l.atteint ? "ok" : "ko"}>
          <div className="proof-marker" aria-hidden="true">
            <Icon name={l.atteint ? "check" : "cross"} size={18} />
          </div>
          <div className="proof-body">
            <div className="proof-title">
              <span className="muted small">Niveau {i + 1}</span>
              <strong>{l.libelle}</strong>
              <span className={`proof-state ${l.atteint ? "ok" : "ko"}`}>{l.atteint ? "✔ atteint" : "✘ non atteint"}</span>
            </div>
            <p>{l.explication}</p>
            <p className="muted small">Ce que cela signifie : {WHAT_IT_MEANS[l.niveau]}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}
