import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { ApiError } from "../api/client";
import { SEVERITY, statusLabel, statusTone, type Tone } from "../lib/labels";
import { Icon } from "./Icon";

export function Badge({ tone = "neutral", children, icon, title }: { tone?: Tone; children: ReactNode; icon?: string; title?: string }) {
  return (
    <span className={`badge badge-${tone}`} title={title}>
      {icon && <Icon name={icon} size={14} />}
      {children}
    </span>
  );
}

/** Pastille de statut : libellé français + couleur (jamais la couleur seule). */
export function StatusChip({ status, label, prefix }: { status: string | null | undefined; label?: string; prefix?: string }) {
  const tone = statusTone(status);
  const icon = tone === "success" ? "check" : tone === "danger" ? "critical" : tone === "warning" ? "clock" : undefined;
  return (
    <Badge tone={tone} icon={icon}>
      {prefix && <span className="badge-prefix">{prefix}</span>}
      {label ?? statusLabel(status)}
    </Badge>
  );
}

/** Gravité d'alerte : icône + texte « Critique », « Attention », « Information ». */
export function SeverityBadge({ severity }: { severity: string }) {
  const s = SEVERITY[severity] ?? { label: severity, tone: "neutral" as Tone, icon: "info" as const };
  return (
    <span className={`sev sev-${s.tone}`}>
      <Icon name={s.icon} size={16} />
      <span>{s.label}</span>
    </span>
  );
}

export function ErrorBox({ error, title }: { error: unknown; title?: string }) {
  if (!error) return null;
  const msg = error instanceof Error ? error.message : String(error);
  const code = error instanceof ApiError ? error.code : null;
  const details = error instanceof ApiError ? error.details : null;
  return (
    <div className="error-box" role="alert">
      <Icon name="critical" />
      <div>
        <strong>{title ?? "Opération refusée"}</strong>
        <p>{msg}</p>
        {code && (
          <p className="muted small">
            Code : <code>{code}</code>
            {details && Object.keys(details).length > 0 && <> · {Object.entries(details).map(([k, v]) => `${k} : ${typeof v === "object" ? JSON.stringify(v) : String(v)}`).join(" ; ")}</>}
          </p>
        )}
      </div>
    </div>
  );
}

export function Notice({ tone = "info", title, children, icon }: { tone?: Tone; title?: string; children: ReactNode; icon?: string }) {
  const ic = icon ?? (tone === "danger" ? "critical" : tone === "warning" ? "warning" : tone === "success" ? "check" : "info");
  return (
    <div className={`notice notice-${tone}`} role={tone === "danger" ? "alert" : "note"}>
      <Icon name={ic} />
      <div>
        {title && <strong>{title}</strong>}
        <div>{children}</div>
      </div>
    </div>
  );
}

export function Loading({ label = "Chargement…" }: { label?: string }) {
  return (
    <div className="loading" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      {label}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>;
}

/** Affiche chargement / erreur / contenu. */
export function Async<T>({ state, children, empty }: { state: { data: T | null; error: unknown; loading: boolean }; children: (d: T) => ReactNode; empty?: (d: T) => boolean }) {
  if (state.error && !state.data) return <ErrorBox error={state.error} title="Chargement impossible" />;
  if (state.data === null) return state.loading ? <Loading /> : null;
  if (empty && empty(state.data)) return <Empty>Aucun élément à afficher.</Empty>;
  return <>{children(state.data)}</>;
}

export function PageHeader({ title, subtitle, actions, icon }: { title: string; subtitle?: ReactNode; actions?: ReactNode; icon?: string }) {
  return (
    <header className="page-header">
      <div className="page-title">
        {icon && (
          <span className="page-icon">
            <Icon name={icon} size={22} />
          </span>
        )}
        <div>
          <h1>{title}</h1>
          {subtitle && <p className="muted">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

export function Card({ title, actions, children, className, subtitle, id }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; subtitle?: ReactNode; id?: string }) {
  return (
    <section className={`card ${className ?? ""}`} aria-labelledby={title && id ? `${id}-t` : undefined} id={id}>
      {(title || actions) && (
        <div className="card-head">
          <div>
            {title && <h2 id={id ? `${id}-t` : undefined}>{title}</h2>}
            {subtitle && <p className="muted small">{subtitle}</p>}
          </div>
          {actions && <div className="card-actions">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function KV({ items }: { items: [ReactNode, ReactNode][] }) {
  return (
    <dl className="kv">
      {items.map(([k, v], i) => (
        <div key={i}>
          <dt>{k}</dt>
          <dd>{v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Tabs({ tabs, value, onChange, label }: { tabs: { id: string; label: string; count?: number; hidden?: boolean }[]; value: string; onChange: (v: string) => void; label: string }) {
  const visible = tabs.filter((t) => !t.hidden);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const onKey = (e: React.KeyboardEvent, i: number) => {
    let n = -1;
    if (e.key === "ArrowRight") n = (i + 1) % visible.length;
    if (e.key === "ArrowLeft") n = (i - 1 + visible.length) % visible.length;
    if (n >= 0) {
      e.preventDefault();
      onChange(visible[n].id);
      refs.current[n]?.focus();
    }
  };
  return (
    <div className="tabs" role="tablist" aria-label={label}>
      {visible.map((t, i) => (
        <button
          key={t.id}
          ref={(el) => {
            refs.current[i] = el;
          }}
          role="tab"
          aria-selected={value === t.id}
          tabIndex={value === t.id ? 0 : -1}
          className={value === t.id ? "tab active" : "tab"}
          onClick={() => onChange(t.id)}
          onKeyDown={(e) => onKey(e, i)}
        >
          {t.label}
          {t.count !== undefined && <span className="tab-count">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

/** Terme avec définition accessible (survol, focus clavier, toucher). */
export function Term({ children, def }: { children: ReactNode; def: string | undefined }) {
  const id = useId();
  const [open, setOpen] = useState(false);
  if (!def) return <>{children}</>;
  return (
    <span className="term" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <button type="button" className="term-btn" aria-describedby={id} onFocus={() => setOpen(true)} onBlur={() => setOpen(false)} onClick={() => setOpen((o) => !o)}>
        {children}
        <Icon name="info" size={13} />
      </button>
      <span role="tooltip" id={id} className={open ? "tooltip open" : "tooltip"}>
        {def}
      </span>
    </span>
  );
}

export function Modal({ title, onClose, children, footer, wide }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const el = ref.current;
    const first = el?.querySelector<HTMLElement>("input, select, textarea, button:not(.modal-close)");
    (first ?? el)?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && el) {
        const f = Array.from(el.querySelectorAll<HTMLElement>("button, input, select, textarea, a[href], [tabindex]:not([tabindex='-1'])")).filter((x) => !x.hasAttribute("disabled"));
        if (f.length === 0) return;
        if (e.shiftKey && document.activeElement === f[0]) {
          e.preventDefault();
          f[f.length - 1].focus();
        } else if (!e.shiftKey && document.activeElement === f[f.length - 1]) {
          e.preventDefault();
          f[0].focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      prev?.focus?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby={titleId} ref={ref} tabIndex={-1} data-modal="1">
        <div className="modal-head">
          <h2 id={titleId}>{title}</h2>
          <button className="icon-btn modal-close" onClick={onClose} aria-label="Fermer">
            <Icon name="close" />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Field({ label, hint, children, required, error }: { label: string; hint?: ReactNode; children: ReactNode; required?: boolean; error?: string | null }) {
  return (
    <label className="field">
      <span className="field-label">
        {label}
        {required && (
          <span className="req" aria-hidden="true">
            {" "}
            *
          </span>
        )}
      </span>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
      {error && (
        <span className="field-error" role="alert">
          {error}
        </span>
      )}
    </label>
  );
}

export function Button({
  children,
  onClick,
  variant = "secondary",
  busy,
  disabled,
  icon,
  type = "button",
  size,
  title,
  ariaLabel,
  className,
}: {
  children?: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "ghost" | "copper" | "success";
  busy?: boolean;
  disabled?: boolean;
  icon?: string;
  type?: "button" | "submit";
  size?: "sm" | "lg" | "xl";
  title?: string;
  ariaLabel?: string;
  className?: string;
}) {
  return (
    <button
      type={type}
      className={`btn btn-${variant} ${size ? `btn-${size}` : ""} ${className ?? ""}`}
      onClick={onClick}
      disabled={disabled || busy}
      aria-busy={busy || undefined}
      title={title}
      aria-label={ariaLabel}
    >
      {busy ? <span className="spinner spinner-sm" aria-hidden="true" /> : icon ? <Icon name={icon} size={size === "xl" ? 24 : 18} /> : null}
      {children}
    </button>
  );
}

export function Mono({ children, wrap }: { children: ReactNode; wrap?: boolean }) {
  return <code className={wrap ? "mono wrap" : "mono"}>{children}</code>;
}

export function Copyable({ text, short }: { text: string; short?: number }) {
  const [ok, setOk] = useState(false);
  return (
    <span className="copyable">
      <code className="mono" title={text}>
        {short && text.length > short ? text.slice(0, short) + "…" : text}
      </code>
      <button
        type="button"
        className="icon-btn sm"
        aria-label="Copier la valeur"
        onClick={() => {
          void navigator.clipboard?.writeText(text).then(() => {
            setOk(true);
            window.setTimeout(() => setOk(false), 1500);
          });
        }}
      >
        <Icon name={ok ? "check" : "file"} size={14} />
      </button>
    </span>
  );
}

export function Stat({ label, value, hint, tone, icon }: { label: ReactNode; value: ReactNode; hint?: ReactNode; tone?: Tone; icon?: string }) {
  return (
    <div className={`stat ${tone ? `stat-${tone}` : ""}`}>
      <div className="stat-label">
        {icon && <Icon name={icon} size={16} />}
        {label}
      </div>
      <div className="stat-value">{value}</div>
      {hint && <div className="stat-hint">{hint}</div>}
    </div>
  );
}

/** Tableau simple accessible avec légende masquée. */
export function Table({ caption, head, children, className }: { caption: string; head: ReactNode[]; children: ReactNode; className?: string }) {
  return (
    <div className="table-wrap" tabIndex={0} role="region" aria-label={caption}>
      <table className={`table ${className ?? ""}`}>
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr>
            {head.map((h, i) => (
              <th key={i} scope="col">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}
