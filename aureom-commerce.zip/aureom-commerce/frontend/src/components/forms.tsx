import { useMemo, useState } from "react";
import { post } from "../api/client";
import type { Lot, PurchaseOrder, Transfer } from "../api/types";
import { useCatalogIndex, variantName, type VariantInfo } from "../lib/catalogIndex";
import { dateOnly, packLabel, packs, parseQty, qty, unitLabel } from "../lib/format";
import { useAction, useApi } from "../lib/hooks";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";
import { Icon } from "./Icon";
import { Button, ErrorBox, Field, Modal, Notice, Table } from "./ui";

export function VariantSelect({ value, onChange, label = "Article", required, filter }: { value: number | ""; onChange: (v: number | "") => void; label?: string; required?: boolean; filter?: (v: VariantInfo) => boolean }) {
  const idx = useCatalogIndex();
  const list = useMemo(() => [...idx.values()].filter((v) => !filter || filter(v)).sort((a, b) => a.label.localeCompare(b.label, "fr")), [idx, filter]);
  return (
    <Field label={label} required={required}>
      <select value={value} onChange={(e) => onChange(e.target.value ? Number(e.target.value) : "")} required={required}>
        <option value="">{required ? "— choisir —" : "Tous les articles"}</option>
        {list.map((v) => (
          <option key={v.id} value={v.id}>
            {v.label} ({v.sku})
          </option>
        ))}
      </select>
    </Field>
  );
}

/* ---- Transferts ------------------------------------------------------------------------------------- */

export function TransferCreateModal({ onClose, onDone, defaultFrom }: { onClose: () => void; onDone: (t: Transfer) => void; defaultFrom?: number | null }) {
  const { mySites, sites } = useSite();
  const idx = useCatalogIndex();
  const [from, setFrom] = useState<number | "">(defaultFrom ?? mySites[0]?.id ?? "");
  const [to, setTo] = useState<number | "">("");
  const [lines, setLines] = useState<{ variant: number | ""; qty: string; lot: number | "" }[]>([{ variant: "", qty: "", lot: "" }]);
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const act = useAction();
  const { push } = useToast();
  const valid = from !== "" && to !== "" && from !== to && lines.every((l) => l.variant !== "" && parseQty(l.qty));
  const submit = () =>
    act.run(async () => {
      const t = await post<Transfer>("/api/stocks/transferts", {
        from_site_id: from,
        to_site_id: to,
        lines: lines.map((l) => ({ variant_id: l.variant, quantity: parseQty(l.qty), lot_id: l.lot === "" ? null : l.lot })),
      });
      push("success", `Transfert ${t.code} créé`, "À expédier depuis le site d'origine.");
      onDone(t);
    });
  return (
    <Modal
      title="Nouveau transfert entre sites"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={act.busy} disabled={!valid} onClick={submit}>
            Créer le transfert
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label="Site d'origine" required>
          <select value={from} onChange={(e) => setFrom(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {mySites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Site de destination" required>
          <select value={to} onChange={(e) => setTo(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {sites
              .filter((s) => s.id !== from)
              .map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
          </select>
        </Field>
      </div>
      {lines.map((l, i) => {
        const v = l.variant !== "" ? idx.get(l.variant) : undefined;
        return (
          <div key={i} className="form-grid line-row">
            <VariantSelect required value={l.variant} onChange={(nv) => setLines(lines.map((x, j) => (j === i ? { ...x, variant: nv, lot: "" } : x)))} />
            <Field label={`Quantité (${v ? unitLabel(v.unit) : "unité de base"})`} required>
              <input inputMode="decimal" value={l.qty} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, qty: e.target.value } : x)))} />
            </Field>
            {v?.lotTracked && (
              <Field label="Lot" hint="Vide = FEFO (premier périmé, premier sorti)">
                <select value={l.lot} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, lot: e.target.value ? Number(e.target.value) : "" } : x)))}>
                  <option value="">Automatique (FEFO)</option>
                  {(lots.data ?? [])
                    .filter((x) => x.variant_id === l.variant && x.status === "ACTIF")
                    .map((x) => (
                      <option key={x.id} value={x.id}>
                        {x.lot_code} {x.expires_on ? `· ${x.expiry_kind} ${dateOnly(x.expires_on)}` : ""}
                      </option>
                    ))}
                </select>
              </Field>
            )}
            {lines.length > 1 && (
              <button type="button" className="icon-btn" aria-label="Retirer la ligne" onClick={() => setLines(lines.filter((_, j) => j !== i))}>
                <Icon name="trash" />
              </button>
            )}
          </div>
        );
      })}
      <Button size="sm" icon="plus" onClick={() => setLines([...lines, { variant: "", qty: "", lot: "" }])}>
        Ajouter une ligne
      </Button>
      <ErrorBox error={act.error} />
    </Modal>
  );
}

export function TransferReceiveModal({ transfer, onClose, onDone, big }: { transfer: Transfer; onClose: () => void; onDone: () => void; big?: boolean }) {
  const idx = useCatalogIndex();
  const { sites, siteName } = useSite();
  const [rec, setRec] = useState<Record<number, string>>(() => Object.fromEntries(transfer.lines.map((l) => [l.id, String(Number(l.quantity))])));
  const [loc, setLoc] = useState<number | "">("");
  const act = useAction();
  const { push } = useToast();
  const locations = sites.find((s) => s.id === transfer.to_site_id)?.emplacements ?? [];
  const valid = transfer.lines.every((l) => parseQty(rec[l.id] ?? "") !== null);
  const submit = () =>
    act.run(async () => {
      await post(`/api/stocks/transferts/${transfer.id}/recevoir`, {
        received: Object.fromEntries(transfer.lines.map((l) => [l.id, parseQty(rec[l.id])])),
        to_location_id: loc === "" ? null : loc,
      });
      const gaps = transfer.lines.filter((l) => Number(parseQty(rec[l.id])) !== Number(l.quantity)).length;
      push(gaps ? "warning" : "success", `Transfert ${transfer.code} reçu`, gaps ? `${gaps} écart(s) enregistré(s) en exception de stock.` : "Quantités conformes.");
      onDone();
    });
  return (
    <Modal
      title={`Recevoir le transfert ${transfer.code}`}
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" size={big ? "xl" : undefined} onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" size={big ? "xl" : undefined} busy={act.busy} disabled={!valid} onClick={submit} icon="check">
            Confirmer la réception
          </Button>
        </>
      }
    >
      <p>
        De <strong>{siteName(transfer.from_site_id)}</strong> vers <strong>{siteName(transfer.to_site_id)}</strong>. Saisissez la quantité réellement reçue : tout écart crée une exception de stock à traiter.
      </p>
      <Table caption="Lignes du transfert" head={["Article", "Expédié", "Reçu"]}>
        {transfer.lines.map((l) => {
          const v = idx.get(l.variant_id);
          return (
            <tr key={l.id}>
              <td>{variantName(idx, l.variant_id)}</td>
              <td>{qty(l.quantity, v?.unit)}</td>
              <td>
                <input className={big ? "wh-input" : ""} aria-label={`Quantité reçue pour ${variantName(idx, l.variant_id)}`} inputMode="decimal" value={rec[l.id] ?? ""} onChange={(e) => setRec({ ...rec, [l.id]: e.target.value })} />
              </td>
            </tr>
          );
        })}
      </Table>
      <Field label="Emplacement de destination" hint="Vide = zone de stockage par défaut du site">
        <select value={loc} onChange={(e) => setLoc(e.target.value ? Number(e.target.value) : "")}>
          <option value="">Par défaut</option>
          {locations.map((l) => (
            <option key={l.id} value={l.id}>
              {l.code} — {l.label}
            </option>
          ))}
        </select>
      </Field>
      <ErrorBox error={act.error} />
    </Modal>
  );
}

/* ---- Réception fournisseur -------------------------------------------------------------------------- */

interface RLine {
  include: boolean;
  mode: "packs" | "base";
  value: string;
  damaged: string;
  lot: string;
  expires: string;
  made: string;
  result: "CONFORME" | "A_CONTROLER" | "NON_CONFORME";
  notes: string;
  temp: string;
}

export function ReceiptModal({ order, onClose, onDone, big }: { order: PurchaseOrder; onClose: () => void; onDone: () => void; big?: boolean }) {
  const idx = useCatalogIndex();
  const { siteName, orgName } = useSite();
  const remaining = (l: PurchaseOrder["lines"][number]) => Math.max(0, Number(l.base_qty) - Number(l.received_base_qty));
  const [lines, setLines] = useState<Record<number, RLine>>(() =>
    Object.fromEntries(order.lines.map((l) => [l.id, { include: remaining(l) > 0, mode: "base", value: String(remaining(l)), damaged: "0", lot: "", expires: "", made: "", result: "CONFORME", notes: "", temp: "" } as RLine])),
  );
  const [bl, setBl] = useState("");
  const [carrier, setCarrier] = useState("");
  const act = useAction();
  const { push } = useToast();
  const set = (id: number, p: Partial<RLine>) => setLines((x) => ({ ...x, [id]: { ...x[id], ...p } }));
  const chosen = order.lines.filter((l) => lines[l.id]?.include);
  const submit = () =>
    act.run(async () => {
      const body = {
        delivery_note_ref: bl || null,
        carrier: carrier || null,
        lines: chosen.map((l) => {
          const r = lines[l.id];
          const v = idx.get(l.variant_id);
          if (v?.lotTracked && !r.lot.trim()) throw new Error(`${v.label} est suivi par lot : saisissez le numéro de lot`);
          const val = parseQty(r.value);
          if (val === null) throw new Error(`Quantité reçue invalide pour ${variantName(idx, l.variant_id)}`);
          return {
            order_line_id: l.id,
            ...(r.mode === "packs" ? { received_packs: val } : { received_qty: val }),
            damaged_qty: parseQty(r.damaged) ?? "0",
            lot_code: r.lot.trim() || null,
            expires_on: r.expires || null,
            manufactured_on: r.made || null,
            inspection_result: r.result,
            notes: r.notes,
            temperature_c: r.temp ? r.temp.replace(",", ".") : null,
          };
        }),
      };
      const res = await post<{ reception: { code: string }; commande: { status: string } }>(`/api/achats/commandes/${order.id}/receptions`, body);
      push("success", `Réception ${res.reception.code} enregistrée`, `Commande ${order.code} : ${res.commande.status === "RECUE" ? "intégralement reçue" : "partiellement reçue"}.`);
      onDone();
    });
  return (
    <Modal
      title={`Réceptionner ${order.code} — ${orgName(order.supplier_id)}`}
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" size={big ? "xl" : undefined} onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" size={big ? "xl" : undefined} busy={act.busy} disabled={chosen.length === 0} onClick={submit} icon="check">
            Valider la réception
          </Button>
        </>
      }
    >
      <p className="muted">
        Livraison attendue à {siteName(order.ship_to_site_id)}
        {order.expected_on && ` le ${dateOnly(order.expected_on)}`}. Réception partielle possible ; les quantités endommagées sont mises en quarantaine.
      </p>
      <div className="form-grid">
        <Field label="N° de bon de livraison">
          <input value={bl} onChange={(e) => setBl(e.target.value)} />
        </Field>
        <Field label="Transporteur">
          <input value={carrier} onChange={(e) => setCarrier(e.target.value)} />
        </Field>
      </div>
      {order.lines.map((l) => {
        const r = lines[l.id];
        const v = idx.get(l.variant_id);
        const pack = v?.variant.conditionnements.find((c) => c.id === l.packaging_id);
        const rem = remaining(l);
        return (
          <fieldset key={l.id} className={`receipt-line ${r.include ? "" : "off"}`}>
            <legend>
              <label className="check">
                <input type="checkbox" checked={r.include} onChange={(e) => set(l.id, { include: e.target.checked })} /> {variantName(idx, l.variant_id)}
              </label>
            </legend>
            <p className="muted small">
              Commandé : {packs(l.pack_qty, pack?.level ?? "CARTON")} = {qty(l.base_qty, v?.unit)} · déjà reçu : {qty(l.received_base_qty, v?.unit)} · reste : {qty(rem, v?.unit)}
            </p>
            {r.include && (
              <div className="form-grid">
                <Field label="Saisie en">
                  <select value={r.mode} onChange={(e) => set(l.id, { mode: e.target.value as RLine["mode"], value: e.target.value === "packs" && pack ? String(Math.floor(rem / Number(pack.qty_in_base))) : String(rem) })}>
                    <option value="base">{v ? unitLabel(v.unit) : "unité de base"}</option>
                    {pack && <option value="packs">{packLabel(pack.level)} ({pack.label})</option>}
                  </select>
                </Field>
                <Field label="Quantité reçue" required>
                  <input className={big ? "wh-input" : ""} inputMode="decimal" value={r.value} onChange={(e) => set(l.id, { value: e.target.value })} />
                </Field>
                <Field label={`Dont endommagé (${v ? unitLabel(v.unit) : ""})`}>
                  <input inputMode="decimal" value={r.damaged} onChange={(e) => set(l.id, { damaged: e.target.value })} />
                </Field>
                <Field label="N° de lot" required={v?.lotTracked}>
                  <input value={r.lot} onChange={(e) => set(l.id, { lot: e.target.value })} />
                </Field>
                <Field label="DLC / DDM">
                  <input type="date" value={r.expires} onChange={(e) => set(l.id, { expires: e.target.value })} />
                </Field>
                <Field label="Date de fabrication">
                  <input type="date" value={r.made} onChange={(e) => set(l.id, { made: e.target.value })} />
                </Field>
                <Field label="Contrôle à réception">
                  <select value={r.result} onChange={(e) => set(l.id, { result: e.target.value as RLine["result"] })}>
                    <option value="CONFORME">Conforme → stock disponible</option>
                    <option value="A_CONTROLER">À contrôler → zone de réception, non vendable</option>
                    <option value="NON_CONFORME">Non conforme → quarantaine</option>
                  </select>
                </Field>
                <Field label="Température relevée (°C)">
                  <input inputMode="decimal" value={r.temp} onChange={(e) => set(l.id, { temp: e.target.value })} />
                </Field>
                <Field label="Observations">
                  <input value={r.notes} onChange={(e) => set(l.id, { notes: e.target.value })} />
                </Field>
              </div>
            )}
          </fieldset>
        );
      })}
      <Notice>Les documents fournis (certificats…) se déposent dans Achats › Documents et restent « Non vérifiés » jusqu'à vérification.</Notice>
      <ErrorBox error={act.error} />
    </Modal>
  );
}
