/* Icônes SVG au trait (24×24), décoratives par défaut : le sens est toujours porté par un texte voisin. */

const P: Record<string, string> = {
  dashboard: "M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z",
  pos: "M4 4h16v10H4zM8 18h8M12 14v4M7 8h4M7 11h2",
  catalog: "M4 5a2 2 0 0 1 2-2h12v16H6a2 2 0 0 0-2 2zM4 21V5M8 7h6M8 11h6",
  stock: "M3 7l9-4 9 4-9 4zM3 7v10l9 4 9-4V7M12 11v10",
  purchase: "M6 6h15l-1.5 9h-12zM6 6 5 3H2M9 20a1 1 0 1 0 0-.01M18 20a1 1 0 1 0 0-.01",
  orders: "M9 4h6l1 2h3v15H5V6h3zM9 11h6M9 15h4",
  warehouse: "M3 21V9l9-6 9 6v12M7 21v-8h10v8M7 17h10",
  customers: "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM2 21a7 7 0 0 1 14 0M17 11a3 3 0 1 0 0-6M22 21a6 6 0 0 0-4-5.6",
  trace: "M4 6h4v4H4zM16 14h4v4h-4zM10 4h4v4h-4zM8 8l2-2M14 6l3 8M6 10l10 6",
  automation: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1",
  analytics: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  admin: "M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5zM9 12l2 2 4-4",
  check: "M5 12.5l4.5 4.5L19 7.5",
  cross: "M6 6l12 12M18 6 6 18",
  close: "M6 6l12 12M18 6 6 18",
  critical: "M12 2 2 21h20zM12 9v5M12 17.5v.01",
  warning: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7.5v6M12 16.5v.01",
  info: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.01",
  logout: "M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5",
  scan: "M3 7V3h4M17 3h4v4M21 17v4h-4M7 21H3v-4M7 8v8M10 8v8M13 8v8M16 8v8",
  plus: "M12 5v14M5 12h14",
  minus: "M5 12h14",
  refresh: "M20 11a8 8 0 0 0-14.8-3.8L3 9M3 4v5h5M4 13a8 8 0 0 0 14.8 3.8L21 15M21 20v-5h-5",
  "arrow-right": "M4 12h15M13 6l6 6-6 6",
  chevron: "M9 6l6 6-6 6",
  "chevron-down": "M6 9l6 6 6-6",
  link: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1",
  download: "M12 3v12M7 10l5 5 5-5M4 19h16",
  lock: "M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4",
  wifi: "M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M12 19.5v.01",
  "wifi-off": "M2 9a15 15 0 0 1 6-3.3M22 9a15 15 0 0 0-8.5-3.9M5 12.5a10 10 0 0 1 3.5-2.2M19 12.5a10 10 0 0 0-2.4-1.7M8.5 16a5 5 0 0 1 7 0M12 19.5v.01M3 3l18 18",
  ledger: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  user: "M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zM4 21a8 8 0 0 1 16 0",
  trash: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3",
  edit: "M4 20h4L19 9l-4-4L4 16zM14 6l4 4",
  clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2",
  box: "M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10",
  truck: "M2 6h12v10H2zM14 10h4l3 3v3h-7M6 19a2 2 0 1 0 0-.01M17 19a2 2 0 1 0 0-.01",
  euro: "M17 6.5A7 7 0 1 0 17 17.5M4 10h9M4 14h9",
  tag: "M3 12V3h9l9 9-9 9zM7.5 7.5v.01",
  eye: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
  "eye-off": "M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.2M6.6 6.6C3.7 8.4 2 12 2 12s3.5 7 10 7a9.7 9.7 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2",
  menu: "M4 6h16M4 12h16M4 18h16",
  back: "M15 6l-6 6 6 6",
  external: "M14 4h6v6M20 4l-9 9M18 14v6H4V6h6",
  cart: "M3 4h2l2.4 11h11L21 8H6.2M9 20a1 1 0 1 0 0-.01M18 20a1 1 0 1 0 0-.01",
  card: "M3 6h18v12H3zM3 10h18M7 15h4",
  cash: "M2 7h20v10H2zM12 9.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM6 12h.01M18 12h.01",
  receipt: "M6 3h12v18l-2-1.5L14 21l-2-1.5L10 21l-2-1.5L6 21zM9 8h6M9 12h6M9 16h3",
  shield: "M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5z",
  file: "M6 2h8l5 5v15H6zM14 2v5h5",
  flow: "M4 12h3M17 12h3M7 8h10v8H7z",
  bell: "M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 21h4",
  play: "M7 4l12 8-12 8z",
  pause: "M7 4h4v16H7zM13 4h4v16h-4z",
  percent: "M19 5 5 19M7 7.01V7M17 17.01V17M7 4.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM17 14.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z",
  hash: "M5 9h14M5 15h14M10 4 8 20M16 4l-2 16",
  backspace: "M8 5h12v14H8l-6-7zM12 9l5 6M17 9l-5 6",
};

export function Icon({ name, size = 20, label, className }: { name: string; size?: number; label?: string; className?: string }) {
  const d = P[name] ?? P.info;
  return (
    <svg
      className={`icon ${className ?? ""}`}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden={label ? undefined : true}
      role={label ? "img" : undefined}
      aria-label={label}
      focusable="false"
    >
      <path d={d} />
    </svg>
  );
}
