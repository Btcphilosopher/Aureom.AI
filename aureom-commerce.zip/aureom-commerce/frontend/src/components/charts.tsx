import { useId, useState } from "react";
import { dateOnly, num } from "../lib/format";

/* Graphiques SVG faits main : une seule série par graphique (identité portée par le titre), axes discrets,
   info-bulle au survol/focus, et toujours une vue tableau à côté dans les pages. */

export interface BandPoint {
  x: string; // date calendaire AAAA-MM-JJ
  y: number;
  lo: number;
  hi: number;
}

/** Prévision avec intervalle à 80 % (bande) — ligne 2 px, bande translucide, info-bulle par jour. */
export function BandChart({ points, unit, title, height = 260 }: { points: BandPoint[]; unit: string; title: string; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const descId = useId();
  if (points.length === 0) return null;
  const W = 720;
  const H = height;
  const m = { l: 48, r: 16, t: 16, b: 36 };
  const maxY = Math.max(1, ...points.map((p) => p.hi)) * 1.1;
  const step = (W - m.l - m.r) / Math.max(1, points.length - 1);
  const x = (i: number) => m.l + i * step;
  const y = (v: number) => H - m.b - (v / maxY) * (H - m.t - m.b);
  const ticks = niceTicks(maxY, 4);
  const band = points.map((p, i) => `${x(i)},${y(p.hi)}`).join(" ") + " " + [...points].reverse().map((p, j) => `${x(points.length - 1 - j)},${y(p.lo)}`).join(" ");
  const line = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(p.y)}`).join(" ");
  const hp = hover !== null ? points[hover] : null;
  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-labelledby={descId} className="chart-svg">
        <title id={descId}>{`${title} — ${points.length} jours, prévision et intervalle à 80 %`}</title>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={m.l} x2={W - m.r} y1={y(t)} y2={y(t)} className="grid" />
            <text x={m.l - 8} y={y(t) + 4} textAnchor="end" className="axis-label">
              {num(t, 1)}
            </text>
          </g>
        ))}
        <line x1={m.l} x2={W - m.r} y1={y(0)} y2={y(0)} className="axis" />
        <polygon points={band} className="band" />
        <path d={line} className="line" fill="none" />
        {points.map((p, i) => (
          <g key={p.x}>
            <circle cx={x(i)} cy={y(p.y)} r={hover === i ? 6 : 4} className="dot" />
            <text x={x(i)} y={H - m.b + 18} textAnchor="middle" className="axis-label">
              {dateOnly(p.x).slice(0, 5)}
            </text>
            <rect
              x={x(i) - step / 2}
              y={m.t}
              width={step}
              height={H - m.t - m.b}
              fill="transparent"
              tabIndex={0}
              aria-label={`${dateOnly(p.x)} : prévision ${num(p.y, 1)} ${unit}, intervalle ${num(p.lo, 1)} à ${num(p.hi, 1)}`}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
              onFocus={() => setHover(i)}
              onBlur={() => setHover(null)}
            />
          </g>
        ))}
        {hp && hover !== null && <line x1={x(hover)} x2={x(hover)} y1={m.t} y2={H - m.b} className="crosshair" />}
      </svg>
      {hp && hover !== null && (
        <div className="chart-tip" style={{ left: `${(x(hover) / W) * 100}%` }} role="status">
          <strong>{dateOnly(hp.x)}</strong>
          <span>
            Prévision : {num(hp.y, 1)} {unit}
          </span>
          <span>
            Intervalle 80 % : {num(hp.lo, 1)} – {num(hp.hi, 1)}
          </span>
        </div>
      )}
      <figcaption className="chart-legend">
        <span className="lg-line" aria-hidden="true" /> Prévision (médiane)
        <span className="lg-band" aria-hidden="true" /> Intervalle à 80 % (empirique)
      </figcaption>
    </figure>
  );
}

/** Barres horizontales (une série) avec valeur en texte. */
export function HBars({ rows, format, title, highlight }: { rows: { label: string; value: number | null; note?: string }[]; format: (v: number) => string; title: string; highlight?: string }) {
  const max = Math.max(1e-9, ...rows.map((r) => r.value ?? 0));
  return (
    <div className="hbars" role="list" aria-label={title}>
      {rows.map((r) => (
        <div className="hbar-row" role="listitem" key={r.label}>
          <span className="hbar-label">
            {r.label}
            {highlight === r.label && <span className="badge badge-accent">retenu</span>}
          </span>
          <span className="hbar-track" aria-hidden="true">
            {r.value !== null && <span className={`hbar-fill ${highlight === r.label ? "hl" : ""}`} style={{ width: `${Math.max(2, (r.value / max) * 100)}%` }} />}
          </span>
          <span className="hbar-value">{r.value === null ? "non disponible" : format(r.value)}</span>
          {r.note && <span className="hbar-note muted small">{r.note}</span>}
        </div>
      ))}
    </div>
  );
}

/** Jauge de probabilité (0–1) avec texte. */
export function Gauge({ value, label }: { value: number; label: string }) {
  const pct = Math.round(value * 100);
  const tone = value >= 0.6 ? "danger" : value >= 0.3 ? "warning" : "success";
  const text = value >= 0.6 ? "Risque élevé" : value >= 0.3 ? "Risque modéré" : "Risque faible";
  return (
    <div className="gauge" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label={label}>
      <div className="gauge-track">
        <div className={`gauge-fill gauge-${tone}`} style={{ width: `${pct}%` }} />
      </div>
      <div className="gauge-text">
        <strong>{pct} %</strong> — {text}
      </div>
    </div>
  );
}

function niceTicks(max: number, n: number): number[] {
  const raw = max / n;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((s) => s * mag).find((s) => s >= raw) ?? raw;
  const out: number[] = [];
  for (let v = 0; v <= max + 1e-9; v += step) out.push(Math.round(v * 1000) / 1000);
  return out;
}
