/**
 * Client HTTP minimal pour l'API AUREOM COMMERCE.
 * - Jeton opaque en en-tête Authorization: Bearer.
 * - Erreurs métier normalisées : {code, message (français), details} → ApiError.
 * - En-tête Idempotency-Key transmis lorsqu'une clé d'intention est fournie.
 */

export interface ApiErrorBody {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export class ApiError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details: Record<string, unknown>;
  /** true si la requête n'a pas obtenu de réponse définitive du serveur (réseau, 5xx) : la même clé d'idempotence doit être réutilisée. */
  readonly retryable: boolean;

  constructor(status: number, body: ApiErrorBody, retryable = false) {
    super(body.message);
    this.name = "ApiError";
    this.code = body.code;
    this.status = status;
    this.details = body.details ?? {};
    this.retryable = retryable;
  }
}

let token: string | null = null;
let onUnauthorized: (() => void) | null = null;

export function setToken(t: string | null): void {
  token = t;
}
export function getToken(): string | null {
  return token;
}
export function setUnauthorizedHandler(fn: (() => void) | null): void {
  onUnauthorized = fn;
}

export interface RequestOptions {
  method?: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  body?: unknown;
  /** Clé d'idempotence (générée une fois par intention utilisateur, réutilisée en cas de nouvelle tentative). */
  idempotencyKey?: string;
  signal?: AbortSignal;
  /** FormData envoyé tel quel (dépôt de documents). */
  form?: FormData;
}

function validationMessage(detail: unknown): string {
  if (Array.isArray(detail)) {
    const parts = detail.map((d: { loc?: unknown[]; msg?: string }) => {
      const loc = Array.isArray(d.loc) ? d.loc.filter((x) => x !== "body").join(" › ") : "";
      return loc ? `${loc} : ${d.msg ?? ""}` : (d.msg ?? "");
    });
    return "Données invalides — " + parts.join(" ; ");
  }
  return "Données invalides";
}

async function toError(res: Response): Promise<ApiError> {
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    /* corps non JSON */
  }
  const retryable = res.status >= 500;
  if (body && typeof body === "object") {
    const b = body as Record<string, unknown>;
    if (typeof b.message === "string" && typeof b.code === "string") {
      return new ApiError(res.status, { code: b.code, message: b.message, details: (b.details as Record<string, unknown>) ?? {} }, retryable);
    }
    if ("detail" in b) {
      return new ApiError(res.status, { code: res.status === 422 ? "VALIDATION" : "ERREUR", message: validationMessage(b.detail) }, retryable);
    }
  }
  return new ApiError(res.status, {
    code: `HTTP_${res.status}`,
    message: res.status >= 500 ? "Le serveur a rencontré une erreur. Réessayez dans un instant." : `Erreur HTTP ${res.status}`,
  }, retryable);
}

async function send(path: string, opts: RequestOptions): Promise<Response> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.idempotencyKey) headers["Idempotency-Key"] = opts.idempotencyKey;
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  let res: Response;
  try {
    res = await fetch(path, { method: opts.method ?? (body ? "POST" : "GET"), headers, body, signal: opts.signal });
  } catch (e) {
    if (e instanceof DOMException && e.name === "AbortError") throw e;
    throw new ApiError(0, { code: "RESEAU", message: "Serveur injoignable : vérifiez la connexion puis réessayez (la même opération sera rejouée sans doublon)." }, true);
  }
  if (res.status === 401 && token && !path.endsWith("/auth/connexion")) {
    const err = await toError(res);
    onUnauthorized?.();
    throw err;
  }
  if (!res.ok) throw await toError(res);
  return res;
}

export async function api<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const res = await send(path, opts);
  const ct = res.headers.get("content-type") ?? "";
  if (ct.includes("application/json")) return (await res.json()) as T;
  return (await res.text()) as unknown as T;
}

export const post = <T>(path: string, body: unknown = {}, idempotencyKey?: string) =>
  api<T>(path, { method: "POST", body, idempotencyKey });

export const patch = <T>(path: string, body: unknown) => api<T>(path, { method: "PATCH", body });

/** Récupère une ressource authentifiée sous forme de Blob (rapports HTML/CSV). */
export async function apiBlob(path: string): Promise<{ blob: Blob; filename: string | null }> {
  const res = await send(path, {});
  const cd = res.headers.get("content-disposition");
  const m = cd ? /filename="?([^";]+)"?/i.exec(cd) : null;
  return { blob: await res.blob(), filename: m ? m[1] : null };
}

export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== null && v !== undefined && v !== "") p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : "";
}

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return String(e);
}
