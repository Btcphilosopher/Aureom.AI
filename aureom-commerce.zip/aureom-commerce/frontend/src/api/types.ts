/* Types des réponses de l'API (champs utilisés par l'interface). Montants en centimes, quantités en chaînes décimales. */

export type Id = number;
export type Qty = string;
export type IsoDate = string;

export interface Me {
  id: Id;
  identifiant: string;
  nom: string;
  roles: string[];
  permissions: string[];
  sites: Id[];
}
export interface LoginResponse {
  jeton: string;
  utilisateur: Me;
}

export interface Location {
  id: Id;
  site_id: Id;
  code: string;
  label: string;
  kind: string;
  sellable: boolean;
  temp_min_c: string | null;
  temp_max_c: string | null;
}
export interface Site {
  id: Id;
  code: string;
  name: string;
  kind: string;
  city: string;
  gln: string;
  allows_click_collect: boolean;
  ships_online: boolean;
  emplacements: Location[];
}
export interface Organisation {
  id: Id;
  code: string;
  name: string;
  kind: string;
  msp_id: string | null;
  is_self: boolean;
  ledger_member: boolean;
  ledger_status: string;
  city: string | null;
  gln: string | null;
  default_lead_time_days: number | null;
}

export interface Health {
  application: string;
  base: string;
  registre: { mode: string; distribue: boolean; disponible?: boolean; [k: string]: unknown };
}
export interface LedgerState {
  mode: string;
  distribue: boolean;
  libelle: string;
  sante: { disponible?: boolean; mode?: string; erreur?: string; [k: string]: unknown };
  statut: Record<string, unknown> | null;
  boite_envoi: Record<string, number>;
  derniere_reconciliation: Reconciliation | null;
  operations_en_cas_d_indisponibilite: { continuent: string[]; restent_provisoires: string[]; bloquees: string[] };
}
export interface Reconciliation {
  id: Id;
  started_at: IsoDate;
  finished_at: IsoDate | null;
  backend: string;
  checked: number;
  confirmed: number;
  mismatches: unknown[];
  imported: number;
  summary: string;
}

/* Catalogue */
export interface Packaging {
  id: Id;
  variant_id: Id;
  level: string;
  label: string;
  qty_in_base: Qty;
  contains_level: string | null;
  contains_qty: Qty | null;
  gtin: string | null;
}
export interface Barcode {
  id: Id;
  code: string;
  symbology: string;
  variant_id: Id;
  packaging_id: Id | null;
}
export interface ChannelPrice {
  montant: number;
  affichage: string;
  ttc: boolean;
  promotion: boolean;
  depuis: IsoDate;
  prix_reference_30j?: number | null;
}
export interface StockPositionLite {
  physique: Qty;
  vendable: Qty;
  reserve: Qty;
  disponible: Qty;
  non_vendable: Qty;
  attendu: Qty;
  point_commande: Qty | null;
  stock_max: Qty | null;
}
export interface Variant {
  id: Id;
  product_id: Id;
  sku: string;
  label: string;
  gtin: string | null;
  status: string;
  attributes: Record<string, unknown>;
  conditionnements: Packaging[];
  codes_barres: Barcode[];
  prix: Record<string, ChannelPrice | null>;
  stock?: StockPositionLite;
}
export interface Product {
  id: Id;
  code: string;
  name: string;
  description: string;
  brand: string | null;
  family_id: Id;
  famille?: string;
  base_unit: string;
  lot_tracked: boolean;
  serial_tracked: boolean;
  expiry_kind: string | null;
  status: string;
  variantes: Variant[];
}
export interface PriceList {
  id: Id;
  code: string;
  label: string;
  channel: string;
  tax_inclusive: boolean;
}
export interface PriceHistoryRow {
  id: Id;
  liste: string;
  packaging_level: string;
  amount_cents: number;
  affichage: string;
  valid_from: IsoDate;
  valid_to: IsoDate | null;
  is_promotion: boolean;
  created_at: IsoDate;
}
export interface Family {
  id: Id;
  code: string;
  name: string;
  parent_id: Id | null;
}
export interface TaxRegime {
  id: Id;
  code: string;
  label: string;
  rates: { rate_bp: number; valid_from: string; source_note: string }[];
}
export interface Unit {
  code: string;
  libelle: string;
  dimension: string;
  entier: boolean;
}

/* Stocks */
export interface StockRefs {
  types_mouvement: Record<string, string>;
  etats_qualite: Record<string, string>;
  definitions: Record<string, string>;
}
export interface StockPosition extends StockPositionLite {
  variant_id: Id;
  sku: string;
  libelle: string;
  unite: string;
  site_id: Id;
  cout_moyen_centimes: string | null;
}
export interface StockBalance {
  id: Id;
  variant_id: Id;
  site_id: Id;
  location_id: Id;
  lot_id: Id | null;
  quality_state: string;
  quantity: Qty;
  emplacement: string;
  type_emplacement: string;
  lot: string | null;
  peremption: string | null;
  etat_libelle: string;
}
export interface StockMovement {
  id: Id;
  group_id: string;
  movement_type: string;
  type_libelle: string | null;
  variant_id: Id;
  site_id: Id;
  location_id: Id;
  lot_id: Id | null;
  quality_state: string;
  quantity: Qty;
  document_type: string | null;
  document_ref: string | null;
  corrects_movement_id: Id | null;
  reason: string | null;
  actor_user_id: Id | null;
  occurred_at: IsoDate;
  lot_attribution: string | null;
}
export interface TransferLine {
  id: Id;
  variant_id: Id;
  lot_id: Id | null;
  quantity: Qty;
  received_qty: Qty | null;
}
export interface Transfer {
  id: Id;
  code: string;
  from_site_id: Id;
  to_site_id: Id;
  status: string;
  created_at: IsoDate;
  shipped_at: IsoDate | null;
  received_at: IsoDate | null;
  lines: TransferLine[];
}
export interface Lot {
  id: Id;
  variant_id: Id;
  supplier_id: Id | null;
  lot_code: string;
  internal_code: string;
  manufactured_on: string | null;
  expires_on: string | null;
  expiry_kind: string | null;
  status: string;
  trace_ref: string;
  sku: string;
  libelle: string;
}
export interface StockException {
  id: Id;
  kind?: string;
  site_id: Id | null;
  status: string;
  message?: string;
  description?: string;
  created_at: IsoDate;
  [k: string]: unknown;
}

/* Achats */
export interface ProposalLine {
  id: Id;
  variant_id: Id;
  packaging_id: Id;
  pack_qty: number;
  unit_cost_cents: number;
}
export interface PurchaseProposal {
  id: Id;
  code: string;
  supplier_id: Id;
  site_id: Id;
  status: string;
  total_cents: number;
  rationale: string;
  decision_note: string | null;
  created_at: IsoDate;
  decided_at: IsoDate | null;
  lines: ProposalLine[];
}
export interface PurchaseOrderLine {
  id: Id;
  variant_id: Id;
  packaging_id: Id;
  pack_qty: number;
  base_qty: Qty;
  unit_cost_cents: number;
  received_base_qty: Qty;
  accepted_base_qty: Qty;
  rejected_base_qty: Qty;
}
export interface ReceiptLine {
  id: Id;
  order_line_id: Id;
  variant_id: Id;
  lot_id: Id | null;
  received_base_qty: Qty;
  accepted_qty: Qty;
  damaged_qty: Qty;
  quarantined_qty: Qty;
  inspection_result: string;
  inspection_notes: string;
}
export interface Receipt {
  id: Id;
  code: string;
  delivery_note_ref: string | null;
  carrier: string | null;
  status: string;
  received_at: IsoDate;
  lines: ReceiptLine[];
}
export interface SupplierInvoice {
  id: Id;
  invoice_number: string;
  invoice_date: string;
  total_ht_cents: number;
  status: string;
  match_result: { conforme: boolean; lignes: { ligne: Id; commande: string; recu: string; accepte: string; facture: string; prix_commande: number; prix_facture: number; anomalies: string[] }[] } | null;
}
export interface PurchaseOrder {
  id: Id;
  code: string;
  supplier_id: Id;
  ship_to_site_id: Id;
  status: string;
  ordered_at: IsoDate | null;
  expected_on: string | null;
  total_ht_cents: number;
  lines: PurchaseOrderLine[];
  receptions?: Receipt[];
  factures?: SupplierInvoice[];
}
export interface SupplierDocument {
  id: Id;
  supplier_id: Id;
  receipt_id: Id | null;
  lot_id: Id | null;
  kind: string;
  claimed_issuer: string | null;
  claimed_reference: string | null;
  sha256: string;
  authenticity_status: string;
  verification_method: string | null;
  verification_note: string | null;
  verified_at: IsoDate | null;
  created_at: IsoDate;
}

/* Caisse */
export interface Register {
  id: Id;
  site_id: Id;
  code: string;
  label: string;
  session_ouverte: PosSession | null;
}
export interface ClosingReport {
  ecart: number;
  taxes: number;
  remises: number;
  avertissement: string;
  fond_de_caisse: number;
  ventes_annulees: number;
  especes_comptees: number;
  ventes_terminees: number;
  especes_attendues: number;
  chiffre_affaires_ht: number;
  chiffre_affaires_ttc: number;
  encaissements_par_moyen: Record<string, number>;
  remboursements_par_moyen: Record<string, number>;
}
export interface PosSession {
  id: Id;
  register_id: Id;
  status: string;
  opened_by: Id;
  opened_at: IsoDate;
  opening_float_cents: number;
  closed_at: IsoDate | null;
  counted_cash_cents: number | null;
  expected_cash_cents: number | null;
  difference_cents: number | null;
  closing_report: ClosingReport | null;
  ventes?: { id: Id; code: string; status: string; total_ttc_cents: number }[];
}
export interface SaleLine {
  id: Id;
  line_no: number;
  variant_id: Id;
  sku: string;
  label: string;
  scanned_code: string;
  unit: string;
  packaging_level: string;
  qty_in_base: Qty;
  quantity: Qty;
  unit_price_ttc_cents: number;
  gross_ttc_cents: number;
  discount_bp: number;
  discount_cents: number;
  discount_reason: string | null;
  total_ttc_cents: number;
  status: string;
  void_reason: string | null;
}
export interface Payment {
  id: Id;
  method: string;
  amount_cents: number;
  status: string;
  provider_ref: string | null;
  card_brand: string | null;
  card_last4: string | null;
  cash_tendered_cents: number | null;
  change_cents: number | null;
  captured_cents: number;
  failure_reason: string | null;
  created_at: IsoDate;
}
export interface Sale {
  id: Id;
  code: string;
  session_id: Id;
  site_id: Id;
  customer_id: Id | null;
  status: string;
  total_ttc_cents: number;
  total_ht_cents: number;
  total_tax_cents: number;
  discount_cents: number;
  loyalty_points: number;
  lines: SaleLine[];
  paiements: Payment[];
  paye: number;
  en_attente: number;
  reste_a_payer: number;
  avertissement: string;
  ticket?: string;
}

/* Commandes */
export interface OrderLine {
  id: Id;
  variant_id: Id;
  sku: string;
  label: string;
  unit: string;
  packaging_level: string;
  quantity: Qty;
  qty_in_base: Qty;
  unit_price_cents: number;
  total_ttc_cents: number;
  picked_base_qty: Qty;
  delivered_base_qty: Qty;
}
export interface OrderEvent {
  id: Id;
  from_status: string | null;
  to_status: string;
  actor_user_id: Id | null;
  note: string | null;
  at: IsoDate;
}
export interface PickTask {
  id: Id;
  order_id: Id;
  order_line_id: Id;
  site_id: Id;
  location_id: Id;
  lot_id: Id | null;
  quantity: Qty;
  picked_qty: Qty | null;
  status: string;
  scanned_code: string | null;
}
export interface Order {
  id: Id;
  code: string;
  channel: string;
  fulfilment: string;
  source_site_id: Id;
  pickup_site_id: Id | null;
  customer_id: Id | null;
  status: string;
  statut_libelle: string;
  payment_status: string;
  total_ttc_cents: number;
  shipping_cents: number;
  created_at: IsoDate;
  promised_at: IsoDate | null;
  ready_at: IsoDate | null;
  completed_at: IsoDate | null;
  lines?: OrderLine[];
  historique?: OrderEvent[];
  taches?: PickTask[];
  paiements?: Payment[];
  expeditions?: { id: Id; carrier: string; tracking_ref?: string; parcels?: number; shipped_at?: IsoDate }[];
  paye?: number;
  code_retrait?: string;
  note?: string;
}

/* Clients */
export interface Customer {
  id: Id;
  code: string;
  type: string;
  societe: string | null;
  anonymise: boolean;
  prenom?: string | null;
  nom?: string | null;
  email?: string | null;
  telephone?: string | null;
  siret?: string | null;
}
export interface CustomerDetail extends Customer {
  consentements_marketing: Record<string, { accorde: boolean; depuis: IsoDate | null; source: string | null }>;
  fidelite: null | {
    solde: number;
    regles: string;
    mouvements: { id: Id; kind: string; points: number; reference: string; explanation: string; created_at: IsoDate }[];
  };
  note: string;
}

/* Traçabilité */
export interface ProofLevel {
  niveau: string;
  atteint: boolean;
  libelle: string;
  explication: string;
}
export interface TraceEvent {
  id: string;
  event_type: string;
  type_libelle: string;
  issuer_org: string;
  origin: string;
  subject_kind: string;
  subject_ref: string;
  lot_id: Id | null;
  occurred_at: IsoDate;
  declared_at: IsoDate;
  previous_event_id: string | null;
  corrects_event_id: string | null;
  counterparty_org: string | null;
  location_ref: string | null;
  evidence: { kind: string; sha256: string; mediaType?: string }[];
  details?: Record<string, unknown>;
  details_digest: string;
  envelope: string;
  payload_sha256: string;
  signature_b64: string;
  signer_key_id: string;
  local_status: string;
  ledger_status: string;
  ledger_backend: string | null;
  ledger_tx_id: string | null;
  ledger_block: number | null;
  ledger_timestamp: IsoDate | null;
  ledger_error_code: string | null;
  ledger_error: string | null;
  counterparty_status: string;
  verification_status: string;
  source_type: string;
  niveaux_de_preuve: ProofLevel[];
  publication: { status: string; attempts: number; next_attempt_at: IsoDate | null; last_error: string | null; done_at: IsoDate | null } | null;
  verifications?: {
    id: Id;
    method: string;
    verifier_name: string;
    verifier_org: string;
    result: string;
    performed_at: IsoDate;
    notes: string;
  }[];
}
export interface Limits {
  limites: string[];
  niveaux: Record<string, string>;
  methodes_verification: Record<string, string>;
}
export interface Recall {
  id: Id;
  code: string;
  reason: string;
  severity: string;
  status: string;
  impact: {
    lots: string[];
    sites: string[];
    ventes: number;
    commandes: number;
    stock_bloque: Record<string, string>;
    ventes_anonymes: number;
    clients_identifies: number;
  } | null;
  opened_at: IsoDate;
  closed_at: IsoDate | null;
  lots?: { lot_id: Id; blocked_qty: Qty; trace_event_id: string | null }[];
  taches?: {
    id: Id;
    kind: string;
    description: string;
    site_id: Id | null;
    customer_id: Id | null;
    reference: string | null;
    confidence: string | null;
    status: string;
    done_at: IsoDate | null;
    notes: string | null;
  }[];
  journal?: { id: Id; kind: string; channel: string | null; audience: string | null; content: string; at: IsoDate; count: number }[];
}

/* Automatisations */
export interface Rule {
  code: string;
  label: string;
  description: string;
  params: Record<string, unknown>;
  enabled: boolean;
  last_run_at: IsoDate | null;
}
export interface Alert {
  id: Id;
  rule_code: string;
  severity: string;
  title: string;
  message: string;
  explanation: Record<string, unknown>;
  entity_type: string | null;
  entity_id: string | null;
  site_id: Id | null;
  status: string;
  created_at: IsoDate;
  resolved_at: IsoDate | null;
}
export interface ActionProposal {
  id: Id;
  kind: string;
  source: string;
  source_code: string | null;
  title: string;
  rationale: string;
  payload: Record<string, unknown>;
  model_info: Record<string, unknown> | null;
  estimated_value_cents: number;
  valeur_affichage: string;
  required_permission: string | null;
  site_id: Id | null;
  status: string;
  decision_note: string | null;
  executed_ref: string | null;
  created_at: IsoDate;
}
export interface ModelEval {
  mae: number;
  rmse: number;
  biais: number;
  mase: number;
  n_points: number;
}
export interface ForecastRun {
  id: Id;
  variant_id: Id;
  site_id: Id;
  created_at: IsoDate;
  horizon_days: number;
  train_start: string;
  train_end: string;
  test_start: string;
  test_end: string;
  evaluation: Record<string, ModelEval | Record<string, unknown>>;
  chosen_model: string;
  forecast: { jour: string; prevision: number; bas: number; haut: number }[];
  data_quality: { jours: number; jours_valides: number; jours_rupture_exclus: number; jours_manquants: number; sources: string[]; avertissement?: string | null };
}
export interface StockoutRisk {
  probabilite_rupture: number;
  demande_mediane: number;
  demande_p90: number;
  offre: number;
  delai_jours: number;
  modele: string;
  limite: string;
}

/* Analyses */
export interface Indicator {
  code: string;
  libelle: string;
  valeur: number | null;
  unite: string | null;
  definition: string;
  affichage?: string;
  [k: string]: unknown;
}
export interface Indicators {
  periode: { debut: IsoDate; fin: IsoDate; site_id: Id | null };
  indicateurs: Indicator[];
  fraicheur: Record<string, IsoDate | null>;
  lacunes: string[];
  genere_le: IsoDate;
}
export interface Dashboard {
  flux: { etape: string; code: string; valeur: number; libelle: string }[];
  alertes: { id: Id; gravite: string; titre: string; message: string; date: IsoDate }[];
  propositions_en_attente: number;
  commandes_rejetees_registre: number;
}

/* Administration */
export interface AdminUser extends Me {
  actif: boolean;
  compte_equipement: boolean;
}
export interface RoleInfo {
  code: string;
  label: string;
  max_discount_bp: number;
  purchase_approval_limit_cents: number;
  permissions: string[];
}
export interface AuditEntry {
  id: Id;
  at: IsoDate;
  actor_user_id: Id | null;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  summary: string;
}
export interface Device {
  id: Id;
  code: string;
  kind: string;
  label: string;
  site_id: Id;
  mode: string;
  simulated: boolean;
  last_seen_at: IsoDate | null;
  type_libelle: string | null;
}

export interface LiveEvent {
  type: string;
  data: Record<string, unknown>;
  recu_le: number;
  id: number;
}
