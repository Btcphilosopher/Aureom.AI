import { useState } from "react";
import { api, post, qs } from "../api/client";
import type { Family, PriceHistoryRow, PriceList, Product, TaxRegime, Unit, Variant } from "../api/types";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, Empty, ErrorBox, Field, Modal, Notice, PageHeader, Table, Tabs } from "../components/ui";
import { invalidateCatalog } from "../lib/catalogIndex";
import { bp, dateTime, eur, num, packLabel, parseEuros, qty, unitLabel } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";

const LEVELS = ["PIECE", "PAQUET", "CARTON", "PALETTE"];

export default function CatalogPage() {
  const { can } = useAuth();
  const [tab, setTab] = useQueryState("onglet", "articles");
  return (
    <>
      <PageHeader icon="catalog" title="Catalogue" subtitle="Articles, variantes, conditionnements, codes-barres et prix datés par canal." />
      <Tabs
        label="Sections du catalogue"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "articles", label: "Articles" },
          { id: "nouveau", label: "Nouvel article", hidden: !can("catalog.write") },
          { id: "conversion", label: "Conversion d'unités" },
        ]}
      />
      {tab === "articles" && <ProductList />}
      {tab === "nouveau" && <ProductForm onCreated={() => setTab("articles")} />}
      {tab === "conversion" && <ConversionTool />}
    </>
  );
}

function ProductList() {
  const [q, setQ] = useState("");
  const [query, setQuery] = useState("");
  const products = useApi<Product[]>(`/api/catalogue/articles${qs({ q: query })}`);
  const [open, setOpen] = useState<number | null>(null);
  const [priceFor, setPriceFor] = useState<Variant | null>(null);
  const [historyFor, setHistoryFor] = useState<Variant | null>(null);
  const [convertFor, setConvertFor] = useState<{ v: Variant; unit: string } | null>(null);
  const { can } = useAuth();
  return (
    <Card>
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          setQuery(q);
        }}
        role="search"
      >
        <Field label="Rechercher un article">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nom de l'article…" />
        </Field>
        <Button type="submit" icon="search">
          Rechercher
        </Button>
      </form>
      <Async state={products} empty={(d) => d.length === 0}>
        {(list) => (
          <ul className="product-list">
            {list.map((p) => (
              <li key={p.id} className="product">
                <button className="product-head" aria-expanded={open === p.id} onClick={() => setOpen(open === p.id ? null : p.id)}>
                  <Icon name={open === p.id ? "chevron-down" : "chevron"} />
                  <span className="product-name">
                    <strong>{p.name}</strong>
                    <span className="muted small">
                      {p.code} · {p.famille} · {p.brand ?? "sans marque"} · unité de base : {unitLabel(p.base_unit, 1)}
                    </span>
                  </span>
                  <span className="product-flags">
                    {p.lot_tracked && <Badge tone="accent">Suivi par lot</Badge>}
                    {p.expiry_kind && <Badge tone="copper">{p.expiry_kind}</Badge>}
                    <Badge tone="neutral">{p.variantes.length} variante(s)</Badge>
                  </span>
                  <span className="product-price">{p.variantes[0]?.prix.MAGASIN?.affichage ?? "—"}</span>
                </button>
                {open === p.id && (
                  <div className="product-body">
                    {p.description && <p className="muted">{p.description}</p>}
                    {p.variantes.map((v) => (
                      <div key={v.id} className="variant">
                        <div className="variant-head">
                          <h3>
                            {v.label} <span className="muted small">SKU {v.sku}</span>
                          </h3>
                          <div className="btn-row">
                            <Button size="sm" icon="clock" onClick={() => setHistoryFor(v)}>
                              Historique des prix
                            </Button>
                            <Button size="sm" icon="refresh" onClick={() => setConvertFor({ v, unit: p.base_unit })}>
                              Convertir
                            </Button>
                            {can("price.write") && (
                              <Button size="sm" variant="primary" icon="tag" onClick={() => setPriceFor(v)}>
                                Publier un prix daté
                              </Button>
                            )}
                          </div>
                        </div>
                        <div className="grid-3">
                          <div>
                            <h4>Prix par canal</h4>
                            <ul className="price-list">
                              {Object.entries(v.prix).map(([code, pr]) => (
                                <li key={code}>
                                  <span>{code === "MAGASIN" ? "Magasin" : code === "WEB" ? "En ligne" : code === "PRO" ? "Professionnel" : code}</span>
                                  {pr ? (
                                    <>
                                      <strong>
                                        {pr.affichage} {pr.ttc ? "TTC" : "HT"}
                                      </strong>
                                      {pr.promotion && <Badge tone="copper">Promotion{pr.prix_reference_30j ? ` · réf. 30 j ${eur(pr.prix_reference_30j)}` : ""}</Badge>}
                                      <span className="muted small">depuis le {dateTime(pr.depuis)}</span>
                                    </>
                                  ) : (
                                    <span className="muted">non tarifé</span>
                                  )}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4>Conditionnements</h4>
                            <Table caption={`Conditionnements de ${v.label}`} head={["Niveau", "Libellé", "Contenu", "GTIN"]}>
                              {v.conditionnements.map((c) => (
                                <tr key={c.id}>
                                  <td>{packLabel(c.level, 1)}</td>
                                  <td>{c.label}</td>
                                  <td>
                                    {qty(c.qty_in_base, p.base_unit)}
                                    {c.contains_level && c.contains_qty && <span className="muted small"> ({num(c.contains_qty)} × {packLabel(c.contains_level, Number(c.contains_qty))})</span>}
                                  </td>
                                  <td>
                                    <code>{c.gtin ?? "—"}</code>
                                  </td>
                                </tr>
                              ))}
                            </Table>
                          </div>
                          <div>
                            <h4>Codes-barres</h4>
                            <ul className="barcodes">
                              {v.codes_barres.map((b) => (
                                <li key={b.id}>
                                  <code>{b.code}</code>
                                  <span className="muted small">
                                    {b.symbology} · {packLabel(v.conditionnements.find((c) => c.id === b.packaging_id)?.level ?? "PIECE", 1)}
                                  </span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </Async>
      {priceFor && (
        <PriceModal
          variant={priceFor}
          onClose={() => setPriceFor(null)}
          onDone={() => {
            setPriceFor(null);
            products.reload();
          }}
        />
      )}
      {historyFor && <HistoryModal variant={historyFor} onClose={() => setHistoryFor(null)} />}
      {convertFor && <ConvertModal variant={convertFor.v} unit={convertFor.unit} onClose={() => setConvertFor(null)} />}
    </Card>
  );
}

function toIso(local: string): string | null {
  if (!local) return null;
  const d = new Date(local);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function PriceModal({ variant, onClose, onDone }: { variant: Variant; onClose: () => void; onDone: () => void }) {
  const lists = useApi<PriceList[]>("/api/catalogue/listes-prix");
  const [list, setList] = useState("MAGASIN");
  const [amount, setAmount] = useState("");
  const [level, setLevel] = useState("PIECE");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [promo, setPromo] = useState(false);
  const act = useAction();
  const { push } = useToast();
  const cents = parseEuros(amount);
  const pl = lists.data?.find((l) => l.code === list);
  const submit = () =>
    act.run(async () => {
      if (cents === null) throw new Error("Montant invalide");
      await post("/api/catalogue/prix", { price_list_code: list, variant_id: variant.id, amount_cents: cents, packaging_level: level, valid_from: toIso(from), valid_to: toIso(to), is_promotion: promo });
      push("success", "Prix publié", `${variant.label} — ${eur(cents)} (${list}). L'ancien prix reste dans l'historique.`);
      invalidateCatalog();
      onDone();
    });
  return (
    <Modal
      title={`Publier un prix — ${variant.label}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={act.busy} disabled={cents === null} onClick={submit}>
            Publier
          </Button>
        </>
      }
    >
      <Notice>Un prix publié crée une nouvelle ligne datée ; l'historique est conservé (aucune modification rétroactive).</Notice>
      <div className="form-grid">
        <Field label="Liste de prix">
          <select value={list} onChange={(e) => setList(e.target.value)}>
            {(lists.data ?? []).map((l) => (
              <option key={l.code} value={l.code}>
                {l.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label={`Montant (€ ${pl ? (pl.tax_inclusive ? "TTC" : "HT") : ""})`} required>
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Conditionnement tarifé">
          <select value={level} onChange={(e) => setLevel(e.target.value)}>
            {variant.conditionnements.map((c) => (
              <option key={c.level} value={c.level}>
                {c.label} ({packLabel(c.level, 1)})
              </option>
            ))}
          </select>
        </Field>
        <Field label="Valable à partir du" hint="Vide = immédiatement (heure locale du poste)">
          <input type="datetime-local" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="Valable jusqu'au" hint="Vide = sans fin">
          <input type="datetime-local" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <label className="check">
          <input type="checkbox" checked={promo} onChange={(e) => setPromo(e.target.checked)} /> Prix promotionnel (le prix de référence des 30 derniers jours sera affiché)
        </label>
      </div>
      <ErrorBox error={act.error} />
    </Modal>
  );
}

function HistoryModal({ variant, onClose }: { variant: Variant; onClose: () => void }) {
  const h = useApi<PriceHistoryRow[]>(`/api/catalogue/prix/${variant.id}/historique`);
  return (
    <Modal title={`Historique des prix — ${variant.label}`} onClose={onClose} wide>
      <Async state={h} empty={(d) => d.length === 0}>
        {(rows) => (
          <Table caption="Historique des prix" head={["Liste", "Conditionnement", "Montant", "Du", "Au", "Promotion", "Saisi le"]}>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.liste}</td>
                <td>{packLabel(r.packaging_level, 1)}</td>
                <td className="num">{r.affichage}</td>
                <td>{dateTime(r.valid_from)}</td>
                <td>{r.valid_to ? dateTime(r.valid_to) : "sans fin"}</td>
                <td>{r.is_promotion ? <Badge tone="copper">Oui</Badge> : "Non"}</td>
                <td>{dateTime(r.created_at)}</td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
    </Modal>
  );
}

function ConvertModal({ variant, unit, onClose }: { variant: Variant; unit: string; onClose: () => void }) {
  const [n, setN] = useState("1");
  const [level, setLevel] = useState(variant.conditionnements[variant.conditionnements.length - 1]?.level ?? "PIECE");
  const [res, setRes] = useState<{ unite_base: string; affichage: string; decomposition: string[] } | null>(null);
  const act = useAction();
  const run = () => act.run(async () => setRes(await api(`/api/catalogue/conditionnements/${variant.id}/convertir${qs({ quantite: n.replace(",", "."), niveau: level })}`)));
  return (
    <Modal title={`Conversion de conditionnements — ${variant.label}`} onClose={onClose}>
      <div className="form-grid">
        <Field label="Quantité">
          <input inputMode="decimal" value={n} onChange={(e) => setN(e.target.value)} />
        </Field>
        <Field label="Conditionnement">
          <select value={level} onChange={(e) => setLevel(e.target.value)}>
            {variant.conditionnements.map((c) => (
              <option key={c.level} value={c.level}>
                {c.label}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Button variant="primary" onClick={run} busy={act.busy}>
        Convertir en unité de base ({unitLabel(unit)})
      </Button>
      <ErrorBox error={act.error} />
      {res && (
        <p className="result-line" role="status">
          = <strong>{res.affichage}</strong>
          {res.decomposition.length > 0 && <span className="muted"> · décomposition : {res.decomposition.join(" + ")}</span>}
        </p>
      )}
    </Modal>
  );
}

function ConversionTool() {
  const units = useApi<{ unites: Unit[]; conditionnements: Record<string, string> }>("/api/catalogue/unites");
  const [v, setV] = useState("1,5");
  const [from, setFrom] = useState("KG");
  const [to, setTo] = useState("G");
  const [res, setRes] = useState<string | null>(null);
  const act = useAction();
  const list = units.data?.unites ?? [];
  const dim = list.find((u) => u.code === from)?.dimension;
  return (
    <Card title="Conversion entre unités" subtitle="Conversions de même dimension uniquement (masse, volume, longueur, comptage).">
      <div className="form-grid">
        <Field label="Valeur">
          <input inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} />
        </Field>
        <Field label="De">
          <select value={from} onChange={(e) => setFrom(e.target.value)}>
            {list.map((u) => (
              <option key={u.code} value={u.code}>
                {u.libelle} ({u.code})
              </option>
            ))}
          </select>
        </Field>
        <Field label="Vers">
          <select value={to} onChange={(e) => setTo(e.target.value)}>
            {list
              .filter((u) => !dim || u.dimension === dim)
              .map((u) => (
                <option key={u.code} value={u.code}>
                  {u.libelle} ({u.code})
                </option>
              ))}
          </select>
        </Field>
      </div>
      <Button variant="primary" busy={act.busy} onClick={() => act.run(async () => setRes((await api<{ affichage: string }>(`/api/catalogue/conversion${qs({ valeur: v.replace(",", "."), de: from, vers: to })}`)).affichage))}>
        Convertir
      </Button>
      <ErrorBox error={act.error} />
      {res && (
        <p className="result-line" role="status">
          {v} {unitLabel(from)} = <strong>{res}</strong>
        </p>
      )}
    </Card>
  );
}

/* ---- Création d'article ----------------------------------------------------------------------------- */

interface PackRow {
  level: string;
  label: string;
  qty: string;
  gtin: string;
}
interface VariantRow {
  sku: string;
  label: string;
  gtin: string;
  packs: PackRow[];
}

function ProductForm({ onCreated }: { onCreated: () => void }) {
  const fams = useApi<Family[]>("/api/catalogue/familles");
  const taxes = useApi<TaxRegime[]>("/api/catalogue/taxes");
  const units = useApi<{ unites: Unit[] }>("/api/catalogue/unites");
  const [f, setF] = useState({ code: "", name: "", description: "", brand: "", family_code: "", tax_regime_code: "TVA_FR_NORMAL", base_unit: "PCE", lot_tracked: false, expiry_kind: "" });
  const [variants, setVariants] = useState<VariantRow[]>([{ sku: "", label: "", gtin: "", packs: [{ level: "PIECE", label: "Pièce", qty: "1", gtin: "" }, { level: "CARTON", label: "Carton de 12", qty: "12", gtin: "" }] }]);
  const act = useAction();
  const { push } = useToast();
  const set = (k: keyof typeof f, v: string | boolean) => setF((x) => ({ ...x, [k]: v }));
  const setVar = (i: number, patch: Partial<VariantRow>) => setVariants((vs) => vs.map((v, j) => (j === i ? { ...v, ...patch } : v)));
  const setPack = (i: number, k: number, patch: Partial<PackRow>) => setVar(i, { packs: variants[i].packs.map((p, j) => (j === k ? { ...p, ...patch } : p)) });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    void act.run(async () => {
      const body = {
        ...f,
        brand: f.brand || null,
        expiry_kind: f.expiry_kind || null,
        variants: variants.map((v) => ({
          sku: v.sku,
          label: v.label || f.name,
          gtin: v.gtin || null,
          attributes: {},
          packagings: v.packs.map((p) => ({ level: p.level, label: p.label || null, qty_in_base: p.qty.replace(",", "."), gtin: p.gtin || null })),
        })),
      };
      const p = await post<Product>("/api/catalogue/articles", body);
      push("success", "Article créé", `${p.name} (${p.variantes.length} variante·s). Pensez à publier ses prix.`);
      invalidateCatalog();
      onCreated();
    });
  };

  return (
    <Card title="Nouvel article" subtitle="La chaîne de conditionnements doit être cohérente (chaque niveau contient un nombre entier du niveau inférieur).">
      <form onSubmit={submit} className="stack">
        <div className="form-grid">
          <Field label="Code article" required>
            <input value={f.code} onChange={(e) => set("code", e.target.value.toUpperCase())} required />
          </Field>
          <Field label="Désignation" required>
            <input value={f.name} onChange={(e) => set("name", e.target.value)} required />
          </Field>
          <Field label="Marque">
            <input value={f.brand} onChange={(e) => set("brand", e.target.value)} />
          </Field>
          <Field label="Famille" required>
            <select value={f.family_code} onChange={(e) => set("family_code", e.target.value)} required>
              <option value="">— choisir —</option>
              {(fams.data ?? []).map((x) => (
                <option key={x.code} value={x.code}>
                  {x.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Régime de TVA" required>
            <select value={f.tax_regime_code} onChange={(e) => set("tax_regime_code", e.target.value)}>
              {(taxes.data ?? []).map((t) => (
                <option key={t.code} value={t.code}>
                  {t.label} ({t.rates[0] ? bp(t.rates[0].rate_bp) : "?"})
                </option>
              ))}
            </select>
          </Field>
          <Field label="Unité de base">
            <select value={f.base_unit} onChange={(e) => set("base_unit", e.target.value)}>
              {(units.data?.unites ?? []).map((u) => (
                <option key={u.code} value={u.code}>
                  {u.libelle}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Date limite">
            <select value={f.expiry_kind} onChange={(e) => set("expiry_kind", e.target.value)}>
              <option value="">Aucune</option>
              <option value="DLC">DLC (date limite de consommation)</option>
              <option value="DDM">DDM (date de durabilité minimale)</option>
            </select>
          </Field>
          <label className="check">
            <input type="checkbox" checked={f.lot_tracked} onChange={(e) => set("lot_tracked", e.target.checked)} /> Suivi par lot (traçabilité)
          </label>
        </div>
        <Field label="Description">
          <textarea rows={2} value={f.description} onChange={(e) => set("description", e.target.value)} />
        </Field>

        {variants.map((v, i) => (
          <fieldset key={i} className="variant-form">
            <legend>Variante {i + 1}</legend>
            <div className="form-grid">
              <Field label="SKU" required>
                <input value={v.sku} onChange={(e) => setVar(i, { sku: e.target.value.toUpperCase() })} required />
              </Field>
              <Field label="Libellé">
                <input value={v.label} onChange={(e) => setVar(i, { label: e.target.value })} placeholder={f.name} />
              </Field>
              <Field label="GTIN (pièce)">
                <input value={v.gtin} onChange={(e) => setVar(i, { gtin: e.target.value })} inputMode="numeric" />
              </Field>
            </div>
            <Table caption={`Conditionnements de la variante ${i + 1}`} head={["Niveau", "Libellé", `Contenu (${unitLabel(f.base_unit)})`, "GTIN", ""]}>
              {v.packs.map((p, k) => (
                <tr key={k}>
                  <td>
                    <select aria-label="Niveau" value={p.level} onChange={(e) => setPack(i, k, { level: e.target.value })}>
                      {LEVELS.map((l) => (
                        <option key={l} value={l}>
                          {packLabel(l, 1)}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <input aria-label="Libellé du conditionnement" value={p.label} onChange={(e) => setPack(i, k, { label: e.target.value })} />
                  </td>
                  <td>
                    <input aria-label="Quantité en unité de base" inputMode="decimal" value={p.qty} onChange={(e) => setPack(i, k, { qty: e.target.value })} />
                  </td>
                  <td>
                    <input aria-label="GTIN du conditionnement" value={p.gtin} onChange={(e) => setPack(i, k, { gtin: e.target.value })} />
                  </td>
                  <td>
                    <button type="button" className="icon-btn" aria-label="Supprimer ce conditionnement" onClick={() => setVar(i, { packs: v.packs.filter((_, j) => j !== k) })}>
                      <Icon name="trash" />
                    </button>
                  </td>
                </tr>
              ))}
            </Table>
            <div className="btn-row">
              <Button size="sm" icon="plus" onClick={() => setVar(i, { packs: [...v.packs, { level: "PALETTE", label: "Palette", qty: "", gtin: "" }] })}>
                Ajouter un conditionnement
              </Button>
              {variants.length > 1 && (
                <Button size="sm" variant="ghost" icon="trash" onClick={() => setVariants(variants.filter((_, j) => j !== i))}>
                  Retirer la variante
                </Button>
              )}
            </div>
          </fieldset>
        ))}
        <div className="btn-row">
          <Button icon="plus" onClick={() => setVariants([...variants, { sku: "", label: "", gtin: "", packs: [{ level: "PIECE", label: "Pièce", qty: "1", gtin: "" }] }])}>
            Ajouter une variante
          </Button>
          <Button type="submit" variant="primary" busy={act.busy} icon="check">
            Créer l'article
          </Button>
        </div>
        <ErrorBox error={act.error} />
        {variants.length === 0 && <Empty>Au moins une variante est requise.</Empty>}
      </form>
    </Card>
  );
}
