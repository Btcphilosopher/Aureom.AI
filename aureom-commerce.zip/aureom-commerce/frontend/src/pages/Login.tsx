import { useState } from "react";
import { errorMessage } from "../api/client";
import { Icon } from "../components/Icon";
import { Button, ErrorBox, Field, Notice } from "../components/ui";
import { DEMO_USERS } from "../lib/labels";
import { useAuth } from "../state/auth";

export default function LoginPage() {
  const { login, notice } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      await login(username.trim(), password);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <section className="login-hero" aria-hidden="true">
        <div className="login-brand">
          <svg viewBox="0 0 64 64" width="56" height="56">
            <rect width="64" height="64" rx="14" fill="#13294d" />
            <path d="M18 46 32 16l14 30" fill="none" stroke="#4d8bff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M24 36h16" stroke="#d08a4b" strokeWidth="6" strokeLinecap="round" />
          </svg>
          <div>
            <strong>AUREOM COMMERCE</strong>
            <span>Gestion du commerce connecté</span>
          </div>
        </div>
        <ol className="login-flow">
          {["Achats", "Réception", "Stock", "Commandes", "Préparation", "Retrait / expédition", "Traçabilité", "Rapprochement"].map((s, i) => (
            <li key={s}>
              <span>{i + 1}</span>
              {s}
            </li>
          ))}
        </ol>
        <p>Maison &amp; Marché — enseigne fictive de démonstration. Prototype : caisse non certifiée, registre de traçabilité simulé ou Fabric.</p>
      </section>
      <main className="login-panel">
        <form className="login-form" onSubmit={submit} aria-labelledby="login-title">
          <h1 id="login-title">Connexion</h1>
          {notice && <Notice tone="warning">{notice}</Notice>}
          <Field label="Identifiant" required>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required autoFocus />
          </Field>
          <Field label="Mot de passe" required>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
          </Field>
          {error && <ErrorBox error={new Error(error)} title="Connexion refusée" />}
          <Button type="submit" variant="primary" size="lg" busy={busy} icon="lock">
            Se connecter
          </Button>
        </form>
        <section className="demo-accounts" aria-labelledby="demo-title">
          <h2 id="demo-title">
            <Icon name="user" size={18} /> Comptes de démonstration
          </h2>
          <p className="muted small">
            Mot de passe commun : <code>demo-aureom-2026</code>. Cliquez pour pré-remplir.
          </p>
          <div className="demo-grid">
            {DEMO_USERS.map((u) => (
              <button
                key={u.username}
                type="button"
                className="demo-user"
                onClick={() => {
                  setUsername(u.username);
                  setPassword("demo-aureom-2026");
                }}
              >
                <strong>{u.username}</strong>
                <span>{u.label}</span>
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
