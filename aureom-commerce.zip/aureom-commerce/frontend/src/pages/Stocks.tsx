import { useState } from "react";
import { Link } from "react-router";
import { post, qs } from "../api/client";
import type { Lot, StockBalance, StockException, StockMovement, StockPosition, StockRefs, Transfer } from "../api/types";
import { TransferCreateModal, TransferReceiveModal, VariantSelect } from "../components/forms";
import { Async, Badge, Button, Card, ErrorBox, Field, Modal, Notice, PageHeader, StatusChip, Table, Tabs, Term } from "../components/ui";
import { useCatalogIndex, variantName } from "../lib/catalogIndex";
import { dateOnly, dateTime, num, parseQty, qty } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { MOVEMENT_SIGN_HELP } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

export default function StocksPage() {
  const [tab, setTab] = useQueryState("onglet", "positions");
  const refs = useApi<StockRefs>("/api/stocks/references");
  const exc = useApi<StockException[]>("/api/stocks/exceptions", ["stock.exception"]);
  const open = (exc.data ?? []).filter((e) => e.status === "OUVERTE").length;
  return (
    <>
      <PageHeader icon="stock" title="Stocks" subtitle="Positions multisites, soldes par lot / emplacement / état, journal des mouvements, transferts, lots et exceptions." />
      <Tabs
        label="Sections des stocks"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "positions", label: "Positions" },
          { id: "soldes", label: "Soldes détaillés" },
          { id: "mouvements", label: "Journal des mouvements" },
          { id: "transferts", label: "Transferts" },
          { id: "lots", label: "Lots" },
          { id: "exceptions", label: "Exceptions", count: open },
        ]}
      />
      {tab === "positions" && <Positions refs={refs.data} />}
      {tab === "soldes" && <Balances refs={refs.data} />}
      {tab === "mouvements" && <Movements refs={refs.data} />}
      {tab === "transferts" && <Transfers />}
      {tab === "lots" && <Lots />}
      {tab === "exceptions" && <Exceptions state={exc} />}
    </>
  );
}

function Positions({ refs }: { refs: StockRefs | null }) {
  const { siteId, siteName } = useSite();
  const pos = useApi<StockPosition[]>(`/api/stocks/positions${qs({ site_id: siteId })}`, ["stock.mouvement", "stock.reservation", "achat.reception"]);
  const d = refs?.definitions ?? {};
  return (
    <Card title="Positions de stock" subtitle="Quantités en unité de base de l'article. Survolez ou sélectionnez un en-tête pour sa définition.">
      <Async state={pos} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table
            caption="Positions de stock par article et par site"
            head={[
              "Article",
              "Site",
              <Term key="p" def={d.physique}>Physique</Term>,
              <Term key="v" def={d.vendable}>Vendable</Term>,
              <Term key="r" def={d.reserve}>Réservé</Term>,
              <Term key="d" def={d.disponible}>Disponible</Term>,
              <Term key="a" def={d.attendu}>Attendu</Term>,
              "Point de commande",
              "Situation",
            ]}
          >
            {rows.map((p) => {
              const neg = Number(p.disponible) < 0;
              const low = p.point_commande !== null && Number(p.disponible) + Number(p.attendu) < Number(p.point_commande);
              return (
                <tr key={`${p.variant_id}-${p.site_id}`} className={neg ? "row-danger" : ""}>
                  <td>
                    <strong>{p.libelle}</strong>
                    <div className="muted small">{p.sku}</div>
                  </td>
                  <td>{siteName(p.site_id)}</td>
                  <td className="num">{qty(p.physique, p.unite)}</td>
                  <td className="num">{qty(p.vendable, p.unite)}</td>
                  <td className="num">{qty(p.reserve, p.unite)}</td>
                  <td className={`num ${neg ? "neg" : ""}`}>
                    {qty(p.disponible, p.unite)}
                    {neg && <span className="neg-label"> (négatif)</span>}
                  </td>
                  <td className="num">{qty(p.attendu, p.unite)}</td>
                  <td className="num">{p.point_commande !== null ? qty(p.point_commande, p.unite) : "—"}</td>
                  <td>
                    {neg ? (
                      <Badge tone="danger" icon="critical">
                        Disponible négatif : réservations à réaffecter
                      </Badge>
                    ) : low ? (
                      <Badge tone="warning" icon="warning">
                        Sous le point de commande
                      </Badge>
                    ) : Number(p.non_vendable) > 0 ? (
                      <Badge tone="info" icon="info">
                        {qty(p.non_vendable, p.unite)} non vendable(s)
                      </Badge>
                    ) : (
                      <Badge tone="success" icon="check">
                        Normal
                      </Badge>
                    )}
                  </td>
                </tr>
              );
            })}
          </Table>
        )}
      </Async>
    </Card>
  );
}

function Balances({ refs }: { refs: StockRefs | null }) {
  const { siteId, siteName } = useSite();
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const [variant, setVariant] = useState<number | "">("");
  const bal = useApi<StockBalance[]>(`/api/stocks/soldes${qs({ site_id: siteId, variant_id: variant })}`, ["stock.mouvement"]);
  const [act, setAct] = useState<StockBalance | null>(null);
  return (
    <Card title="Soldes par lot, emplacement et état qualité">
      <div className="toolbar">
        <VariantSelect value={variant} onChange={setVariant} />
      </div>
      <Async state={bal} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Soldes de stock détaillés" head={["Article", "Site", "Emplacement", "Lot", "Péremption", "État qualité", "Quantité", ""]}>
            {rows.map((b) => (
              <tr key={b.id}>
                <td>{variantName(idx, b.variant_id)}</td>
                <td>{siteName(b.site_id)}</td>
                <td>
                  <code>{b.emplacement}</code> <span className="muted small">{b.type_emplacement.toLowerCase()}</span>
                </td>
                <td>{b.lot ?? "—"}</td>
                <td>{b.peremption ? dateOnly(b.peremption) : "—"}</td>
                <td>
                  <StatusChip status={b.quality_state} label={refs?.etats_qualite[b.quality_state] ?? b.etat_libelle} />
                </td>
                <td className="num">{qty(b.quantity, idx.get(b.variant_id)?.unit)}</td>
                <td>
                  {(can("stock.move") || can("quality.inspect")) && (
                    <Button size="sm" onClick={() => setAct(b)}>
                      État / perte
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {act && (
        <BalanceActionModal
          balance={act}
          refs={refs}
          onClose={() => setAct(null)}
          onDone={() => {
            setAct(null);
            bal.reload();
          }}
        />
      )}
    </Card>
  );
}

function BalanceActionModal({ balance, refs, onClose, onDone }: { balance: StockBalance; refs: StockRefs | null; onClose: () => void; onDone: () => void }) {
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const [kind, setKind] = useState<"etat" | "perte">(can("quality.inspect") ? "etat" : "perte");
  const [toState, setToState] = useState(balance.quality_state === "DISPONIBLE" ? "QUARANTAINE" : "DISPONIBLE");
  const [q, setQ] = useState(String(Number(balance.quantity)));
  const [reason, setReason] = useState("");
  const a = useAction();
  const { push } = useToast();
  const unit = idx.get(balance.variant_id)?.unit;
  const submit = () =>
    a.run(async () => {
      const quantity = parseQty(q);
      if (!quantity) throw new Error("Quantité invalide");
      if (kind === "etat")
        await post("/api/stocks/etat-qualite", { variant_id: balance.variant_id, location_id: balance.location_id, lot_id: balance.lot_id, from_state: balance.quality_state, to_state: toState, quantity, reason });
      else await post("/api/stocks/pertes", { variant_id: balance.variant_id, location_id: balance.location_id, lot_id: balance.lot_id, quality_state: balance.quality_state, quantity, reason });
      push("success", kind === "etat" ? "État qualité modifié" : "Perte enregistrée", `${variantName(idx, balance.variant_id)} — ${qty(quantity, unit)}`);
      onDone();
    });
  return (
    <Modal
      title={`${variantName(idx, balance.variant_id)} — ${balance.emplacement}${balance.lot ? ` · lot ${balance.lot}` : ""}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant={kind === "perte" ? "danger" : "primary"} busy={a.busy} disabled={reason.trim().length < 5} onClick={submit}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="seg" role="radiogroup" aria-label="Type d'opération">
        {can("quality.inspect") && (
          <button role="radio" aria-checked={kind === "etat"} className={kind === "etat" ? "on" : ""} onClick={() => setKind("etat")}>
            Changer l'état qualité
          </button>
        )}
        {can("stock.move") && (
          <button role="radio" aria-checked={kind === "perte"} className={kind === "perte" ? "on" : ""} onClick={() => setKind("perte")}>
            Déclarer une perte / casse
          </button>
        )}
      </div>
      <p>
        Solde actuel : <strong>{qty(balance.quantity, unit)}</strong> en état « {refs?.etats_qualite[balance.quality_state] ?? balance.etat_libelle} ».
      </p>
      <div className="form-grid">
        {kind === "etat" && (
          <Field label="Nouvel état">
            <select value={toState} onChange={(e) => setToState(e.target.value)}>
              {Object.entries(refs?.etats_qualite ?? {})
                .filter(([k]) => k !== balance.quality_state)
                .map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
            </select>
          </Field>
        )}
        <Field label="Quantité" required>
          <input inputMode="decimal" value={q} onChange={(e) => setQ(e.target.value)} />
        </Field>
      </div>
      <Field label="Motif (obligatoire, 5 caractères minimum)" required>
        <input value={reason} onChange={(e) => setReason(e.target.value)} />
      </Field>
      {balance.quality_state === "BLOQUE" && <Notice tone="warning">Un lot bloqué par un rappel ne peut être débloqué qu'à la clôture du rappel.</Notice>}
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Movements({ refs }: { refs: StockRefs | null }) {
  const { siteId, locationCode } = useSite();
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const [variant, setVariant] = useState<number | "">("");
  const [doc, setDoc] = useState("");
  const [docQ, setDocQ] = useState("");
  const [type, setType] = useState("");
  const [limit, setLimit] = useState(100);
  const mv = useApi<StockMovement[]>(`/api/stocks/mouvements${qs({ site_id: siteId, variant_id: variant, document_ref: docQ, limit })}`, ["stock.mouvement"]);
  const [corr, setCorr] = useState<StockMovement | null>(null);
  const rows = (mv.data ?? []).filter((m) => !type || m.movement_type === type);
  return (
    <Card title="Journal des mouvements" subtitle={`Journal immuable : une correction crée un mouvement lié, l'original reste visible. ${MOVEMENT_SIGN_HELP}`}>
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          setDocQ(doc.trim());
        }}
      >
        <VariantSelect value={variant} onChange={setVariant} />
        <Field label="Type de mouvement">
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">Tous</option>
            {Object.entries(refs?.types_mouvement ?? {}).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Document (référence exacte)">
          <input value={doc} onChange={(e) => setDoc(e.target.value)} placeholder="ex. REC-2026-00001" />
        </Field>
        <Field label="Nombre max.">
          <select value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
            {[50, 100, 200, 500].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </Field>
        <Button type="submit" icon="search">
          Filtrer
        </Button>
      </form>
      <Async state={mv}>
        {() => (
          <Table caption="Journal des mouvements de stock" head={["N°", "Date", "Type", "Article", "Emplacement", "État", "Quantité", "Document", "Motif / lien", ""]}>
            {rows.map((m) => {
              const unit = idx.get(m.variant_id)?.unit;
              const n = Number(m.quantity);
              return (
                <tr key={m.id}>
                  <td className="muted">{m.id}</td>
                  <td>{dateTime(m.occurred_at)}</td>
                  <td>{m.type_libelle ?? m.movement_type}</td>
                  <td>{variantName(idx, m.variant_id)}</td>
                  <td>
                    <code>{locationCode(m.location_id)}</code>
                  </td>
                  <td>{refs?.etats_qualite[m.quality_state] ?? m.quality_state}</td>
                  <td className={`num ${n < 0 ? "neg" : "plus"}`}>
                    {n > 0 ? "+" : ""}
                    {qty(m.quantity, unit)}
                  </td>
                  <td>{m.document_ref ?? "—"}</td>
                  <td className="small">
                    {m.reason ?? ""}
                    {m.corrects_movement_id && <Badge tone="copper">corrige le n° {m.corrects_movement_id}</Badge>}
                    {m.lot_attribution && <span className="muted"> lot {m.lot_attribution.toLowerCase()}</span>}
                  </td>
                  <td>
                    {can("stock.correct") && !m.corrects_movement_id && (
                      <Button size="sm" onClick={() => setCorr(m)}>
                        Corriger
                      </Button>
                    )}
                  </td>
                </tr>
              );
            })}
          </Table>
        )}
      </Async>
      {corr && (
        <CorrectionModal
          m={corr}
          onClose={() => setCorr(null)}
          onDone={() => {
            setCorr(null);
            mv.reload();
          }}
        />
      )}
    </Card>
  );
}

function CorrectionModal({ m, onClose, onDone }: { m: StockMovement; onClose: () => void; onDone: () => void }) {
  const idx = useCatalogIndex();
  const [q, setQ] = useState(String(Number(m.quantity)));
  const [reason, setReason] = useState("");
  const a = useAction();
  const { push } = useToast();
  const unit = idx.get(m.variant_id)?.unit;
  const submit = () =>
    a.run(async () => {
      const v = q.replace(",", ".").trim();
      if (!/^-?\d+(\.\d{1,3})?$/.test(v)) throw new Error("Quantité corrigée invalide");
      await post(`/api/stocks/mouvements/${m.id}/correction`, { corrected_quantity: v, reason });
      push("success", `Mouvement n° ${m.id} corrigé`, "Un mouvement de correction lié et attribué a été ajouté au journal.");
      onDone();
    });
  return (
    <Modal
      title={`Corriger le mouvement n° ${m.id}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={reason.trim().length < 5} onClick={submit}>
            Enregistrer la correction
          </Button>
        </>
      }
    >
      <p>
        {m.type_libelle} · {variantName(idx, m.variant_id)} · quantité enregistrée : <strong>{qty(m.quantity, unit)}</strong> ({m.document_ref ?? "sans document"}).
      </p>
      <Notice>Le mouvement d'origine n'est pas modifié : la différence est passée en mouvement « Correction » lié, avec votre nom et le motif.</Notice>
      <Field label="Quantité correcte (signée)" required hint={MOVEMENT_SIGN_HELP}>
        <input inputMode="decimal" value={q} onChange={(e) => setQ(e.target.value)} />
      </Field>
      <Field label="Motif de la correction (obligatoire)" required>
        <textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Transfers() {
  const { siteName, siteId } = useSite();
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const tr = useApi<Transfer[]>("/api/stocks/transferts", ["stock.mouvement"]);
  const [create, setCreate] = useState(false);
  const [receive, setReceive] = useState<Transfer | null>(null);
  const a = useAction();
  const { push } = useToast();
  const rows = (tr.data ?? []).filter((t) => !siteId || t.from_site_id === siteId || t.to_site_id === siteId);
  return (
    <Card
      title="Transferts entre sites"
      subtitle="Brouillon → expédié (en transit, compté en « attendu » à destination) → reçu."
      actions={
        can("stock.transfer") && (
          <Button variant="primary" icon="plus" onClick={() => setCreate(true)}>
            Nouveau transfert
          </Button>
        )
      }
    >
      <ErrorBox error={a.error} />
      <Async state={tr}>
        {() => (
          <Table caption="Transferts" head={["Code", "Statut", "Origine → destination", "Lignes", "Créé", "Expédié", "Reçu", ""]}>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>
                  <strong>{t.code}</strong>
                </td>
                <td>
                  <StatusChip status={t.status} />
                </td>
                <td>
                  {siteName(t.from_site_id)} → {siteName(t.to_site_id)}
                </td>
                <td className="small">
                  {t.lines.map((l) => (
                    <div key={l.id}>
                      {variantName(idx, l.variant_id)} : {qty(l.quantity, idx.get(l.variant_id)?.unit)}
                      {l.received_qty !== null && Number(l.received_qty) !== Number(l.quantity) && <Badge tone="danger">reçu {num(l.received_qty)}</Badge>}
                    </div>
                  ))}
                </td>
                <td>{dateTime(t.created_at)}</td>
                <td>{dateTime(t.shipped_at)}</td>
                <td>{dateTime(t.received_at)}</td>
                <td>
                  {can("stock.transfer") && t.status === "BROUILLON" && (
                    <Button
                      size="sm"
                      variant="primary"
                      busy={a.busy}
                      onClick={() =>
                        a.run(async () => {
                          await post(`/api/stocks/transferts/${t.id}/expedier`);
                          push("success", `Transfert ${t.code} expédié`);
                          tr.reload();
                        })
                      }
                    >
                      Expédier
                    </Button>
                  )}
                  {can("stock.transfer") && t.status === "EXPEDIE" && (
                    <Button size="sm" variant="primary" onClick={() => setReceive(t)}>
                      Recevoir
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {create && (
        <TransferCreateModal
          defaultFrom={siteId}
          onClose={() => setCreate(false)}
          onDone={() => {
            setCreate(false);
            tr.reload();
          }}
        />
      )}
      {receive && (
        <TransferReceiveModal
          transfer={receive}
          onClose={() => setReceive(null)}
          onDone={() => {
            setReceive(null);
            tr.reload();
          }}
        />
      )}
    </Card>
  );
}

function Lots() {
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const { orgName } = useSite();
  return (
    <Card title="Lots" subtitle="Les lots rappelés sont bloqués à la vente et en préparation.">
      <Async state={lots} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Lots" head={["Lot fournisseur", "Code interne", "Article", "Fournisseur", "Fabrication", "Péremption", "Statut", "Traçabilité"]}>
            {rows.map((l) => (
              <tr key={l.id} className={l.status === "RAPPELE" ? "row-danger" : ""}>
                <td>
                  <strong>{l.lot_code}</strong>
                </td>
                <td className="muted">{l.internal_code}</td>
                <td>{l.libelle}</td>
                <td>{orgName(l.supplier_id)}</td>
                <td>{dateOnly(l.manufactured_on)}</td>
                <td>{l.expires_on ? `${l.expiry_kind ?? ""} ${dateOnly(l.expires_on)}` : "—"}</td>
                <td>
                  <StatusChip status={l.status} />
                </td>
                <td>
                  <Link to={`/tracabilite?onglet=rapports&lot=${l.id}`}>Rapport du lot</Link>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
    </Card>
  );
}

function Exceptions({ state }: { state: ReturnType<typeof useApi<StockException[]>> }) {
  const { siteName } = useSite();
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const [resolve, setResolve] = useState<StockException | null>(null);
  const [note, setNote] = useState("");
  const a = useAction();
  return (
    <Card title="Exceptions de stock" subtitle="Situations que le journal ne peut refléter sans décision humaine (vente sans stock système, écart de transfert, réservations à réaffecter).">
      <Async state={state} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Exceptions de stock" head={["Date", "Type", "Article", "Site", "Quantité", "Message", "Statut", ""]}>
            {rows.map((e) => (
              <tr key={e.id}>
                <td>{dateTime(e.created_at)}</td>
                <td>{String(e.kind ?? "").replaceAll("_", " ").toLowerCase()}</td>
                <td>{variantName(idx, e.variant_id as number)}</td>
                <td>{siteName(e.site_id)}</td>
                <td className="num">{qty(e.quantity as string, idx.get(e.variant_id as number)?.unit)}</td>
                <td className="small">{e.message}</td>
                <td>
                  <StatusChip status={e.status} />
                </td>
                <td>
                  {can("stock.correct") && e.status === "OUVERTE" && (
                    <Button size="sm" onClick={() => setResolve(e)}>
                      Résoudre
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {resolve && (
        <Modal
          title="Résoudre l'exception"
          onClose={() => setResolve(null)}
          footer={
            <Button
              variant="primary"
              busy={a.busy}
              disabled={note.trim().length < 3}
              onClick={() =>
                a.run(async () => {
                  await post(`/api/stocks/exceptions/${resolve.id}/resoudre`, { note });
                  setResolve(null);
                  setNote("");
                  state.reload();
                })
              }
            >
              Marquer résolue
            </Button>
          }
        >
          <p>{resolve.message}</p>
          <Field label="Note de résolution (obligatoire)" required>
            <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
          </Field>
          <ErrorBox error={a.error} />
        </Modal>
      )}
    </Card>
  );
}
