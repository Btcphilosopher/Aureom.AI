import { Link } from "react-router";
import { qs } from "../api/client";
import type { ActionProposal, Dashboard, Indicators, PurchaseProposal, StockPosition } from "../api/types";
import { Icon } from "../components/Icon";
import { Async, Card, Empty, PageHeader, SeverityBadge, Stat, StatusChip, Term } from "../components/ui";
import { ago, dateTime, eur, num } from "../lib/format";
import { useApi } from "../lib/hooks";
import { describeLive } from "../lib/liveText";
import { timeOnly } from "../lib/format";
import { useAuth } from "../state/auth";
import { useLive } from "../state/live";
import { useSite } from "../state/site";

const FLOW: { code: string; etape: string; to: string; icon: string; perm: string; libelle?: string }[] = [
  { code: "achats", etape: "Achats", to: "/achats", icon: "purchase", perm: "purchase.read" },
  { code: "reception", etape: "Réception", to: "/entrepots?onglet=receptions", icon: "truck", perm: "receipt.write" },
  { code: "stock", etape: "Stock", to: "/stocks", icon: "stock", perm: "stock.read", libelle: "positions sous le point de commande" },
  { code: "commandes", etape: "Commandes", to: "/commandes", icon: "orders", perm: "order.read" },
  { code: "preparation", etape: "Préparation", to: "/entrepots", icon: "box", perm: "order.fulfil" },
  { code: "remise", etape: "Retrait / expédition", to: "/commandes?statut=PRETE", icon: "truck", perm: "order.read" },
  { code: "tracabilite", etape: "Traçabilité", to: "/tracabilite", icon: "trace", perm: "trace.read" },
  { code: "rapprochement", etape: "Rapprochement", to: "/stocks?onglet=exceptions", icon: "check", perm: "stock.read" },
];

const KEY_INDICATORS = ["ca_ttc", "encaissements_nets", "marge_brute", "valeur_stock", "ruptures", "alertes_ouvertes", "tracabilite_en_attente", "ecarts_rapprochement"];

export default function DashboardPage() {
  const { can } = useAuth();
  const { siteId, site } = useSite();
  const live = ["stock.mouvement", "commande.statut", "alerte", "achat.reception", "achat.commande", "tracabilite.confirme", "tracabilite.declare", "stock.exception", "rappel"];
  const dash = useApi<Dashboard>(`/api/tableau-de-bord${qs({ site_id: siteId })}`, live);
  const positions = useApi<StockPosition[]>(`/api/stocks/positions${qs({ site_id: siteId })}`, ["stock.mouvement", "stock.reservation"]);
  const ind = useApi<Indicators>(can("analytics.read") ? `/api/analyses/indicateurs${qs({ site_id: siteId })}` : null, ["caisse.vente", "alerte", "stock.mouvement"]);
  const autoProps = useApi<ActionProposal[]>(can("automation.read") ? "/api/automatisations/propositions" : null, ["alerte"]);
  const purProps = useApi<PurchaseProposal[]>(can("purchase.read") ? "/api/achats/propositions" : null, ["achat.commande"]);
  const { events } = useLive();

  const belowReorder = (positions.data ?? []).filter((p) => p.point_commande !== null && Number(p.disponible) + Number(p.attendu) < Number(p.point_commande)).length;
  const values: Record<string, { valeur: number; libelle: string }> = {};
  for (const f of dash.data?.flux ?? []) values[f.code] = { valeur: f.valeur, libelle: f.libelle };
  values.stock = { valeur: belowReorder, libelle: "positions sous le point de commande" };
  const pendingPurchase = (purProps.data ?? []).filter((p) => p.status === "PROPOSEE");

  return (
    <>
      <PageHeader
        icon="dashboard"
        title="Tableau de bord"
        subtitle={<>Vue opérationnelle — {site ? site.name : "tous les sites"} · mise à jour en temps réel</>}
      />

      <Card title="Flux logistique" subtitle="Cliquez sur une étape pour ouvrir l'écran correspondant. Les valeurs sont des volumes à traiter." id="flux">
        <ol className="flow">
          {FLOW.map((f, i) => {
            const v = values[f.code];
            const allowed = can(f.perm);
            const body = (
              <>
                <span className="flow-step">
                  <span className="flow-num">{i + 1}</span>
                  <Icon name={f.icon} size={18} />
                </span>
                <strong className="flow-name">{f.etape}</strong>
                <span className={`flow-value ${v && v.valeur > 0 ? "has" : ""}`}>{v ? num(v.valeur) : "…"}</span>
                <span className="flow-label">{v?.libelle ?? f.libelle ?? ""}</span>
              </>
            );
            return (
              <li key={f.code} className="flow-item">
                {allowed ? (
                  <Link to={f.to} className="flow-card" aria-label={`${f.etape} : ${v ? v.valeur : "…"} ${v?.libelle ?? ""}`}>
                    {body}
                  </Link>
                ) : (
                  <div className="flow-card disabled" aria-disabled="true" title="Écran non accessible avec votre rôle">
                    {body}
                  </div>
                )}
                {i < FLOW.length - 1 && <Icon name="arrow-right" className="flow-arrow" size={16} />}
              </li>
            );
          })}
        </ol>
        {dash.data && dash.data.commandes_rejetees_registre > 0 && (
          <p className="sev-line">
            <SeverityBadge severity="ATTENTION" /> {dash.data.commandes_rejetees_registre} événement(s) de traçabilité rejeté(s) par le registre.
          </p>
        )}
      </Card>

      {ind.data && (
        <section className="stats-grid" aria-label="Indicateurs clés">
          {KEY_INDICATORS.map((c) => {
            const i = ind.data!.indicateurs.find((x) => x.code === c);
            if (!i) return null;
            return (
              <Stat
                key={c}
                label={<Term def={i.definition}>{i.libelle}</Term>}
                value={i.affichage ?? (i.valeur === null ? "non disponible" : `${num(i.valeur)} ${i.unite ?? ""}`)}
                hint={c === "marge_brute" && typeof i.taux === "number" ? `taux ${num(i.taux as number, 1)} %` : undefined}
                tone={(c === "ruptures" || c === "alertes_ouvertes") && (i.valeur ?? 0) > 0 ? "warning" : undefined}
              />
            );
          })}
        </section>
      )}

      <div className="grid-2">
        <Card
          title="Dernières alertes"
          actions={can("automation.read") ? <Link to="/automatisations" className="link-btn">Toutes les alertes <Icon name="chevron" size={14} /></Link> : undefined}
        >
          <Async state={dash}>
            {(d) =>
              d.alertes.length === 0 ? (
                <Empty>Aucune alerte ouverte.</Empty>
              ) : (
                <ul className="alert-list">
                  {d.alertes.map((a) => (
                    <li key={a.id} className={`alert-item alert-${a.gravite.toLowerCase()}`}>
                      <SeverityBadge severity={a.gravite} />
                      <div>
                        <strong>{a.titre}</strong>
                        <p>{a.message}</p>
                        <span className="muted small">
                          {dateTime(a.date)} · {ago(a.date)}
                        </span>
                      </div>
                    </li>
                  ))}
                </ul>
              )
            }
          </Async>
        </Card>

        <div className="stack">
          <Card title="Décisions en attente" subtitle="Toute action automatique exige une validation humaine.">
            <ul className="todo-list">
              <li>
                <Icon name="automation" />
                <span>
                  <strong>{dash.data ? num(dash.data.propositions_en_attente) : "…"}</strong> proposition(s) d'automatisation à décider
                </span>
                {can("automation.read") && <Link to="/automatisations?onglet=propositions">Ouvrir</Link>}
              </li>
              {can("purchase.read") && (
                <li>
                  <Icon name="purchase" />
                  <span>
                    <strong>{num(pendingPurchase.length)}</strong> proposition(s) d'achat à approuver
                  </span>
                  <Link to="/achats">Ouvrir</Link>
                </li>
              )}
            </ul>
            {(autoProps.data ?? []).slice(0, 4).map((p) => (
              <div key={p.id} className="mini-prop">
                <StatusChip status={p.status} />
                <span>{p.title}</span>
                <span className="muted small">{p.valeur_affichage}</span>
              </div>
            ))}
            {pendingPurchase.slice(0, 3).map((p) => (
              <div key={p.id} className="mini-prop">
                <StatusChip status={p.status} />
                <span>
                  {p.code} — {p.rationale || "sans justification"}
                </span>
                <span className="muted small">{eur(p.total_cents)} HT</span>
              </div>
            ))}
          </Card>

          <Card title="Activité temps réel" subtitle="Derniers événements reçus par WebSocket.">
            {events.length === 0 ? (
              <Empty>En attente d'événements…</Empty>
            ) : (
              <ol className="feed-list compact">
                {events.slice(0, 6).map((e) => {
                  const d = describeLive(e);
                  return (
                    <li key={e.id}>
                      <time className="muted small">{timeOnly(e.recu_le)}</time>
                      <strong>{d.title}</strong>
                      <span>{d.text}</span>
                    </li>
                  );
                })}
              </ol>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
