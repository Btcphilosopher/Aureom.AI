import { useState } from "react";
import { post } from "../api/client";
import type { AdminUser, AuditEntry, Device, Organisation, RoleInfo } from "../api/types";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, Copyable, ErrorBox, Field, Modal, Notice, PageHeader, StatusChip, Table, Tabs } from "../components/ui";
import { bp, dateTime, eur } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { ROLE_LABELS } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

export default function AdminPage() {
  const { can } = useAuth();
  const first = can("admin.users") ? "utilisateurs" : can("admin.demo") ? "demo" : "organisations";
  const [tab, setTab] = useQueryState("onglet", first);
  return (
    <>
      <PageHeader icon="admin" title="Administration" subtitle="Utilisateurs, rôles et permissions, journal d'audit, gouvernance du registre, démonstration et équipements." />
      <Tabs
        label="Sections de l'administration"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "utilisateurs", label: "Utilisateurs", hidden: !can("admin.users") },
          { id: "roles", label: "Rôles et permissions" },
          { id: "journal", label: "Journal d'audit", hidden: !can("admin.users") },
          { id: "organisations", label: "Organisations et registre" },
          { id: "demo", label: "Démonstration", hidden: !can("admin.demo") },
          { id: "equipements", label: "Équipements", hidden: !can("admin.users") && !can("iot.read") },
        ]}
      />
      {tab === "utilisateurs" && can("admin.users") && <Users />}
      {tab === "roles" && <Roles />}
      {tab === "journal" && can("admin.users") && <Audit />}
      {tab === "organisations" && <Orgs />}
      {tab === "demo" && can("admin.demo") && <Demo />}
      {tab === "equipements" && <Devices />}
    </>
  );
}

function Users() {
  const users = useApi<AdminUser[]>("/api/admin/utilisateurs");
  const { siteName } = useSite();
  const [create, setCreate] = useState(false);
  return (
    <Card
      title="Utilisateurs"
      actions={
        <Button variant="primary" icon="plus" onClick={() => setCreate(true)}>
          Nouvel utilisateur
        </Button>
      }
    >
      <Async state={users}>
        {(rows) => (
          <Table caption="Utilisateurs" head={["Identifiant", "Nom", "Rôles", "Périmètre", "Type", "État"]}>
            {rows.map((u) => (
              <tr key={u.id}>
                <td>
                  <code>{u.identifiant}</code>
                </td>
                <td>{u.nom}</td>
                <td>{u.roles.map((r) => ROLE_LABELS[r] ?? r).join(", ")}</td>
                <td>{u.sites.length === 0 ? "Tous les sites" : u.sites.map(siteName).join(", ")}</td>
                <td>{u.compte_equipement ? <Badge tone="copper">Compte d'équipement</Badge> : "Personne"}</td>
                <td>
                  <Badge tone={u.actif ? "success" : "neutral"} icon={u.actif ? "check" : "cross"}>
                    {u.actif ? "Actif" : "Inactif"}
                  </Badge>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {create && (
        <CreateUser
          onClose={() => setCreate(false)}
          onDone={() => {
            setCreate(false);
            users.reload();
          }}
        />
      )}
    </Card>
  );
}

function CreateUser({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const perms = useApi<{ roles: RoleInfo[] }>("/api/admin/permissions");
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [pwd, setPwd] = useState("");
  const [roles, setRoles] = useState<string[]>([]);
  const a = useAction();
  const { push } = useToast();
  return (
    <Modal
      title="Nouvel utilisateur"
      onClose={onClose}
      footer={
        <Button
          variant="primary"
          busy={a.busy}
          disabled={!username || !name || pwd.length < 10 || roles.length === 0}
          onClick={() =>
            a.run(async () => {
              await post("/api/admin/utilisateurs", { username, full_name: name, password: pwd, roles });
              push("success", `Utilisateur ${username} créé`);
              onDone();
            })
          }
        >
          Créer
        </Button>
      }
    >
      <div className="form-grid">
        <Field label="Identifiant" required>
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="off" />
        </Field>
        <Field label="Nom complet" required>
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Mot de passe initial" required hint="10 caractères minimum">
          <input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} autoComplete="new-password" />
        </Field>
      </div>
      <fieldset className="inline-checks">
        <legend>Rôles</legend>
        {(perms.data?.roles ?? [])
          .filter((r) => r.code !== "equipement")
          .map((r) => (
            <label key={r.code} className="check">
              <input type="checkbox" checked={roles.includes(r.code)} onChange={(e) => setRoles(e.target.checked ? [...roles, r.code] : roles.filter((x) => x !== r.code))} /> {r.label}
            </label>
          ))}
      </fieldset>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Roles() {
  const perms = useApi<{ permissions: Record<string, string>; roles: RoleInfo[] }>("/api/admin/permissions");
  return (
    <Card title="Matrice des rôles et permissions" subtitle="✔ = permission accordée. Plafonds de remise et d'approbation d'achat par rôle.">
      <Async state={perms}>
        {(d) => (
          <div className="table-wrap matrix-wrap" tabIndex={0} role="region" aria-label="Matrice des permissions">
            <table className="table matrix">
              <caption className="sr-only">Permissions par rôle</caption>
              <thead>
                <tr>
                  <th scope="col">Permission</th>
                  {d.roles.map((r) => (
                    <th key={r.code} scope="col" className="rot">
                      <span>{r.label}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.entries(d.permissions).map(([p, label]) => (
                  <tr key={p}>
                    <th scope="row">
                      {label}
                      <div className="muted small mono">{p}</div>
                    </th>
                    {d.roles.map((r) => {
                      const has = r.permissions.includes(p);
                      return (
                        <td key={r.code} className={has ? "yes" : "no"}>
                          <span aria-hidden="true">{has ? "✔" : "·"}</span>
                          <span className="sr-only">{has ? "oui" : "non"}</span>
                        </td>
                      );
                    })}
                  </tr>
                ))}
                <tr className="row-hl">
                  <th scope="row">Remise maximale</th>
                  {d.roles.map((r) => (
                    <td key={r.code}>{bp(r.max_discount_bp)}</td>
                  ))}
                </tr>
                <tr className="row-hl">
                  <th scope="row">Plafond d'approbation d'achat (HT)</th>
                  {d.roles.map((r) => (
                    <td key={r.code} className="small">
                      {r.purchase_approval_limit_cents >= 1e11 ? "illimité" : eur(r.purchase_approval_limit_cents)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </Async>
    </Card>
  );
}

function Audit() {
  const [limit, setLimit] = useState(100);
  const log = useApi<AuditEntry[]>(`/api/admin/journal?limit=${limit}`);
  const users = useApi<AdminUser[]>("/api/admin/utilisateurs");
  const [filter, setFilter] = useState("");
  const name = (id: number | null) => (id === null ? "système" : (users.data?.find((u) => u.id === id)?.identifiant ?? `#${id}`));
  return (
    <Card title="Journal d'audit" subtitle="Toutes les actions sensibles sont tracées (connexions, corrections, décisions, gouvernance…).">
      <div className="toolbar">
        <Field label="Filtrer (action ou résumé)">
          <input value={filter} onChange={(e) => setFilter(e.target.value)} />
        </Field>
        <Field label="Nombre d'entrées">
          <select value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
            {[50, 100, 200, 500].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Async state={log}>
        {(rows) => (
          <Table caption="Journal d'audit" head={["Date", "Acteur", "Action", "Objet", "Résumé"]}>
            {rows
              .filter((r) => !filter || `${r.action} ${r.summary}`.toLowerCase().includes(filter.toLowerCase()))
              .map((r) => (
                <tr key={r.id}>
                  <td className="nowrap">{dateTime(r.at, true)}</td>
                  <td>{name(r.actor_user_id)}</td>
                  <td>
                    <code>{r.action}</code>
                  </td>
                  <td className="small">
                    {r.entity_type} {r.entity_id}
                  </td>
                  <td className="small">{r.summary}</td>
                </tr>
              ))}
          </Table>
        )}
      </Async>
    </Card>
  );
}

function Orgs() {
  const { can } = useAuth();
  const orgs = useApi<Organisation[]>("/api/organisations");
  const [edit, setEdit] = useState<Organisation | null>(null);
  return (
    <Card title="Organisations et gouvernance du registre" subtitle="Statut d'admission au registre partagé. La modification effective du canal Fabric est une procédure signée hors application ; ici, la décision est tracée.">
      <Async state={orgs}>
        {(rows) => (
          <Table caption="Organisations" head={["Organisation", "Type", "MSP", "Ville", "Membre du registre", "Statut de gouvernance", ""]}>
            {rows.map((o) => (
              <tr key={o.id}>
                <td>
                  <strong>{o.name}</strong> {o.is_self && <Badge tone="accent">nous</Badge>}
                  <div className="muted small">GLN {o.gln ?? "—"}</div>
                </td>
                <td>{o.kind.toLowerCase()}</td>
                <td>
                  <code>{o.msp_id ?? "—"}</code>
                </td>
                <td>{o.city ?? "—"}</td>
                <td>{o.ledger_member ? <Badge tone="success" icon="check">Oui</Badge> : <Badge tone="neutral">Non</Badge>}</td>
                <td>
                  <StatusChip status={o.ledger_status} />
                </td>
                <td>
                  {can("ledger.admin") && !o.is_self && (
                    <Button size="sm" onClick={() => setEdit(o)}>
                      Modifier le statut
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {edit && (
        <OrgStatusModal
          org={edit}
          onClose={() => setEdit(null)}
          onDone={() => {
            setEdit(null);
            orgs.reload();
          }}
        />
      )}
    </Card>
  );
}

function OrgStatusModal({ org, onClose, onDone }: { org: Organisation; onClose: () => void; onDone: () => void }) {
  const [status, setStatus] = useState(org.ledger_status);
  const [note, setNote] = useState("");
  const a = useAction();
  return (
    <Modal
      title={`Gouvernance — ${org.name}`}
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={note.trim().length < 3} onClick={() => a.run(async () => { await post(`/api/organisations/${org.id}/statut-registre`, { ledger_status: status, note }); onDone(); })}>
          Enregistrer la décision
        </Button>
      }
    >
      <Field label="Statut">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="CANDIDATE">Candidate</option>
          <option value="ADMISE">Admise</option>
          <option value="SUSPENDUE">Suspendue</option>
          <option value="RETIREE">Retirée</option>
        </select>
      </Field>
      <Field label="Motif de la décision (obligatoire)" required>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <Notice>Décision tracée localement ; la mise à jour de configuration du canal Fabric reste à signer par la majorité des administrateurs (procédure hors application).</Notice>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Demo() {
  const flag = useApi<{ panne_simulee: boolean }>("/api/admin/demo/panne-registre");
  const a = useAction();
  const { push } = useToast();
  const set = (actif: boolean) =>
    a.run(async () => {
      await post("/api/admin/demo/panne-registre", { actif });
      flag.reload();
      window.dispatchEvent(new Event("aureom:registre"));
      push(actif ? "warning" : "success", actif ? "Panne du registre simulée" : "Registre rétabli", actif ? "Les opérations continuent ; les événements partagés restent en attente." : "Les événements en attente seront publiés par la boîte d'envoi.");
    });
  const on = flag.data?.panne_simulee;
  return (
    <Card title="Contrôles de démonstration" subtitle="Réservé à la démonstration : injecter une indisponibilité du registre pour montrer la continuité des opérations.">
      <div className={`registry-mode ${on ? "down" : "sim"}`}>
        <Icon name={on ? "critical" : "ledger"} size={28} />
        <div>
          <strong>Panne simulée du registre : {on === undefined ? "…" : on ? "ACTIVE" : "inactive"}</strong>
          <p>{on ? "Le registre est considéré indisponible : ventes, réceptions, transferts continuent ; les événements restent « en attente »." : "Le registre fonctionne normalement."}</p>
        </div>
      </div>
      <div className="btn-row">
        <Button variant="danger" icon="pause" busy={a.busy} disabled={on === true} onClick={() => set(true)}>
          Activer la panne simulée
        </Button>
        <Button variant="success" icon="play" busy={a.busy} disabled={on === false} onClick={() => set(false)}>
          Rétablir le registre
        </Button>
      </div>
      <p className="muted small">Après rétablissement, utilisez « Publier maintenant » puis « Réconcilier » dans Traçabilité › État du registre.</p>
      <ErrorBox error={a.error} />
    </Card>
  );
}

function Devices() {
  const { can } = useAuth();
  const { siteName } = useSite();
  const devices = useApi<Device[]>(can("iot.read") ? "/api/equipements" : null, ["equipement.observation", "equipement.rfid"]);
  const users = useApi<AdminUser[]>(can("admin.users") ? "/api/admin/utilisateurs" : null);
  const [token, setToken] = useState<{ user: string; jeton: string; note: string } | null>(null);
  const a = useAction();
  const accounts = (users.data ?? []).filter((u) => u.compte_equipement);
  return (
    <>
      {can("admin.users") && (
        <Card title="Comptes d'équipement et jetons" subtitle="Un jeton permet à une passerelle (MQTT/HTTP) de transmettre des observations. Il n'est affiché qu'une seule fois.">
          <Async state={users}>
            {() => (
              <Table caption="Comptes d'équipement" head={["Compte", "Nom", "État", ""]}>
                {accounts.map((u) => (
                  <tr key={u.id}>
                    <td>
                      <code>{u.identifiant}</code>
                    </td>
                    <td>{u.nom}</td>
                    <td>{u.actif ? "Actif" : "Inactif"}</td>
                    <td>
                      <Button
                        size="sm"
                        icon="lock"
                        busy={a.busy}
                        onClick={() =>
                          a.run(async () => {
                            const r = await post<{ jeton: string; note: string }>(`/api/admin/comptes-equipement/${encodeURIComponent(u.identifiant)}/jeton`);
                            setToken({ user: u.identifiant, ...r });
                          })
                        }
                      >
                        Émettre un jeton
                      </Button>
                    </td>
                  </tr>
                ))}
              </Table>
            )}
          </Async>
          <ErrorBox error={a.error} />
        </Card>
      )}
      {can("iot.read") && (
        <Card title="Équipements connectés (lecture seule)" subtitle="Aucun équipement n'est piloté par le prototype : les observations sont lues et interprétées, jamais transformées automatiquement en mouvement de stock.">
          <Async state={devices}>
            {(rows) => (
              <Table caption="Équipements" head={["Code", "Type", "Libellé", "Site", "Mode", "Dernière observation"]}>
                {rows.map((d) => (
                  <tr key={d.id}>
                    <td>
                      <code>{d.code}</code>
                    </td>
                    <td>{d.type_libelle ?? d.kind}</td>
                    <td>
                      {d.label} {d.simulated && <Badge tone="neutral">simulé</Badge>}
                    </td>
                    <td>{siteName(d.site_id)}</td>
                    <td>{d.mode.replaceAll("_", " ").toLowerCase()}</td>
                    <td>{dateTime(d.last_seen_at)}</td>
                  </tr>
                ))}
              </Table>
            )}
          </Async>
        </Card>
      )}
      {token && (
        <Modal title={`Jeton pour ${token.user}`} onClose={() => setToken(null)}>
          <Notice tone="warning">{token.note}</Notice>
          <Copyable text={token.jeton} />
        </Modal>
      )}
    </>
  );
}
