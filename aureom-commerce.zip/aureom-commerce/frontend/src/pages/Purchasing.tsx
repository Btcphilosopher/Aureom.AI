import { useState } from "react";
import { api, post } from "../api/client";
import type { Lot, Organisation, PurchaseOrder, PurchaseProposal, RoleInfo, SupplierDocument, SupplierInvoice } from "../api/types";
import { ReceiptModal, VariantSelect } from "../components/forms";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, Copyable, Empty, ErrorBox, Field, KV, Modal, Notice, PageHeader, StatusChip, Table, Tabs } from "../components/ui";
import { useCatalogIndex, variantName } from "../lib/catalogIndex";
import { dateOnly, dateTime, eur, packs, parseEuros, parseQty, qty, unitLabel } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

const DOC_KINDS: Record<string, string> = {
  CERTIFICAT_ANALYSE: "Certificat d'analyse",
  CERTIFICAT_CONFORMITE: "Certificat de conformité",
  BON_LIVRAISON: "Bon de livraison",
  FACTURE: "Facture",
  DECLARATION_CE: "Déclaration CE",
};

export default function PurchasingPage() {
  const [tab, setTab] = useQueryState("onglet", "propositions");
  const docs = useApi<SupplierDocument[]>("/api/achats/documents");
  const unverified = (docs.data ?? []).filter((d) => d.authenticity_status === "NON_VERIFIE").length;
  return (
    <>
      <PageHeader icon="purchase" title="Achats" subtitle="Propositions d'achat (plafonds d'approbation par rôle, séparation des tâches), commandes fournisseurs, réceptions, documents et factures." />
      <Tabs
        label="Sections des achats"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "propositions", label: "Propositions" },
          { id: "commandes", label: "Commandes fournisseurs" },
          { id: "documents", label: "Documents fournisseurs", count: unverified },
          { id: "besoins", label: "Besoins de réapprovisionnement" },
        ]}
      />
      {tab === "propositions" && <Proposals />}
      {tab === "commandes" && <Orders />}
      {tab === "documents" && <Documents state={docs} />}
      {tab === "besoins" && <Needs />}
    </>
  );
}

function useMyLimit(): number | null {
  const { user } = useAuth();
  const perms = useApi<{ roles: RoleInfo[] }>("/api/admin/permissions");
  if (!perms.data || !user) return null;
  const mine = perms.data.roles.filter((r) => user.roles.includes(r.code));
  return mine.length ? Math.max(...mine.map((r) => r.purchase_approval_limit_cents)) : 0;
}

function Proposals() {
  const { can } = useAuth();
  const { orgName, siteName } = useSite();
  const idx = useCatalogIndex();
  const props = useApi<PurchaseProposal[]>("/api/achats/propositions", ["achat.commande"]);
  const limit = useMyLimit();
  const [create, setCreate] = useState(false);
  const [decide, setDecide] = useState<{ p: PurchaseProposal; approve: boolean } | null>(null);
  return (
    <Card
      title="Propositions d'achat"
      subtitle={
        <>
          Une proposition approuvée devient une commande fournisseur (envoi simulé).{" "}
          {can("purchase.approve") && limit !== null && <>Votre plafond d'approbation : <strong>{limit >= 1e11 ? "illimité" : eur(limit) + " HT"}</strong>.</>}
          {!can("purchase.approve") && " Votre rôle ne permet pas d'approuver."}
        </>
      }
      actions={
        can("purchase.write") && (
          <Button variant="primary" icon="plus" onClick={() => setCreate(true)}>
            Nouvelle proposition
          </Button>
        )
      }
    >
      <Async state={props} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Propositions d'achat" head={["Code", "Statut", "Fournisseur", "Livraison", "Lignes", "Total HT", "Justification / décision", ""]}>
            {rows.map((p) => (
              <tr key={p.id}>
                <td>
                  <strong>{p.code}</strong>
                  <div className="muted small">{dateTime(p.created_at)}</div>
                </td>
                <td>
                  <StatusChip status={p.status} />
                </td>
                <td>{orgName(p.supplier_id)}</td>
                <td>{siteName(p.site_id)}</td>
                <td className="small">
                  {p.lines.map((l) => {
                    const v = idx.get(l.variant_id);
                    const pk = v?.variant.conditionnements.find((c) => c.id === l.packaging_id);
                    return (
                      <div key={l.id}>
                        {variantName(idx, l.variant_id)} : {packs(l.pack_qty, pk?.level ?? "CARTON")}
                        {pk && <span className="muted"> ({qty(Number(pk.qty_in_base) * l.pack_qty, v?.unit)})</span>} à {eur(l.unit_cost_cents)}
                      </div>
                    );
                  })}
                </td>
                <td className="num">
                  <strong>{eur(p.total_cents)}</strong>
                  {limit !== null && can("purchase.approve") && p.status === "PROPOSEE" && p.total_cents > limit && (
                    <div>
                      <Badge tone="warning" icon="warning">
                        Au-dessus de votre plafond
                      </Badge>
                    </div>
                  )}
                </td>
                <td className="small">
                  {p.rationale || <span className="muted">—</span>}
                  {p.decision_note && <div className="muted">Décision : {p.decision_note}</div>}
                </td>
                <td>
                  {p.status === "PROPOSEE" && (
                    <div className="btn-col">
                      <Button size="sm" variant="primary" onClick={() => setDecide({ p, approve: true })}>
                        Approuver
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setDecide({ p, approve: false })}>
                        Rejeter
                      </Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {create && (
        <ProposalModal
          onClose={() => setCreate(false)}
          onDone={() => {
            setCreate(false);
            props.reload();
          }}
        />
      )}
      {decide && (
        <DecisionModal
          {...decide}
          onClose={() => setDecide(null)}
          onDone={() => {
            setDecide(null);
            props.reload();
          }}
        />
      )}
    </Card>
  );
}

function DecisionModal({ p, approve, onClose, onDone }: { p: PurchaseProposal; approve: boolean; onClose: () => void; onDone: () => void }) {
  const [note, setNote] = useState("");
  const a = useAction();
  const { push } = useToast();
  const submit = () =>
    a.run(async () => {
      const r = await post<{ commande: PurchaseOrder | null }>(`/api/achats/propositions/${p.id}/decision`, { approve, note });
      push("success", approve ? `Proposition ${p.code} approuvée` : `Proposition ${p.code} rejetée`, r.commande ? `Commande fournisseur ${r.commande.code} émise (envoi simulé).` : undefined);
      onDone();
    });
  return (
    <Modal
      title={`${approve ? "Approuver" : "Rejeter"} ${p.code}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant={approve ? "primary" : "danger"} busy={a.busy} onClick={submit}>
            {approve ? "Approuver" : "Rejeter"}
          </Button>
        </>
      }
    >
      <p>
        Montant : <strong>{eur(p.total_cents)} HT</strong>. Le serveur vérifie votre plafond et la séparation des tâches (on ne peut pas approuver sa propre proposition).
      </p>
      <Field label="Note de décision">
        <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} title="Décision refusée" />
    </Modal>
  );
}

function ProposalModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const sup = useApi<Organisation[]>("/api/achats/fournisseurs");
  const { sites } = useSite();
  const idx = useCatalogIndex();
  const [supplier, setSupplier] = useState<number | "">("");
  const [site, setSite] = useState<number | "">("");
  const [rationale, setRationale] = useState("");
  const [lines, setLines] = useState<{ variant: number | ""; mode: "packs" | "base"; q: string }[]>([{ variant: "", mode: "packs", q: "" }]);
  const a = useAction();
  const { push } = useToast();
  const submit = () =>
    a.run(async () => {
      const p = await post<PurchaseProposal>("/api/achats/propositions", {
        supplier_id: supplier,
        site_id: site,
        rationale,
        lines: lines.map((l) => (l.mode === "packs" ? { variant_id: l.variant, pack_qty: Number(l.q) } : { variant_id: l.variant, base_qty: parseQty(l.q) })),
      });
      push("success", `Proposition ${p.code} créée`, `Total ${eur(p.total_cents)} HT — en attente d'approbation.`);
      onDone();
    });
  const valid = supplier !== "" && site !== "" && lines.every((l) => l.variant !== "" && (l.mode === "packs" ? /^\d+$/.test(l.q) && Number(l.q) > 0 : parseQty(l.q)));
  return (
    <Modal
      title="Nouvelle proposition d'achat"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={!valid} onClick={submit}>
            Créer la proposition
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label="Fournisseur" required>
          <select value={supplier} onChange={(e) => setSupplier(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {(sup.data ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Site de livraison" required>
          <select value={site} onChange={(e) => setSite(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Field label="Justification">
        <input value={rationale} onChange={(e) => setRationale(e.target.value)} />
      </Field>
      {lines.map((l, i) => {
        const v = l.variant !== "" ? idx.get(l.variant) : undefined;
        return (
          <div className="form-grid line-row" key={i}>
            <VariantSelect required value={l.variant} onChange={(nv) => setLines(lines.map((x, j) => (j === i ? { ...x, variant: nv } : x)))} />
            <Field label="Saisie">
              <select value={l.mode} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, mode: e.target.value as "packs" | "base" } : x)))}>
                <option value="packs">En conditionnements d'achat</option>
                <option value="base">En unité de base (arrondi au conditionnement supérieur)</option>
              </select>
            </Field>
            <Field label={l.mode === "packs" ? "Nombre de conditionnements" : `Quantité (${v ? unitLabel(v.unit) : "unité"})`} required>
              <input inputMode="decimal" value={l.q} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, q: e.target.value } : x)))} />
            </Field>
            {lines.length > 1 && (
              <button className="icon-btn" aria-label="Retirer la ligne" onClick={() => setLines(lines.filter((_, j) => j !== i))}>
                <Icon name="trash" />
              </button>
            )}
          </div>
        );
      })}
      <Button size="sm" icon="plus" onClick={() => setLines([...lines, { variant: "", mode: "packs", q: "" }])}>
        Ajouter une ligne
      </Button>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Orders() {
  const { orgName, siteName } = useSite();
  const pos = useApi<PurchaseOrder[]>("/api/achats/commandes", ["achat.commande", "achat.reception"]);
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Card title="Commandes fournisseurs">
      <Async state={pos} empty={(x) => x.length === 0}>
        {(rows) => (
          <ul className="product-list">
            {rows.map((o) => (
              <li key={o.id} className="product">
                <button className="product-head" aria-expanded={open === o.id} onClick={() => setOpen(open === o.id ? null : o.id)}>
                  <Icon name={open === o.id ? "chevron-down" : "chevron"} />
                  <span className="product-name">
                    <strong>{o.code}</strong>
                    <span className="muted small">
                      {orgName(o.supplier_id)} → {siteName(o.ship_to_site_id)} · commandée le {dateTime(o.ordered_at)} · attendue le {dateOnly(o.expected_on)}
                    </span>
                  </span>
                  <StatusChip status={o.status} />
                  <span className="product-price">{eur(o.total_ht_cents)} HT</span>
                </button>
                {open === o.id && <OrderDetail id={o.id} onChange={pos.reload} />}
              </li>
            ))}
          </ul>
        )}
      </Async>
    </Card>
  );
}

function OrderDetail({ id, onChange }: { id: number; onChange: () => void }) {
  const { can } = useAuth();
  const idx = useCatalogIndex();
  const o = useApi<PurchaseOrder>(`/api/achats/commandes/${id}`, ["achat.reception"]);
  const [receive, setReceive] = useState(false);
  const [invoice, setInvoice] = useState(false);
  const [inspect, setInspect] = useState<number | null>(null);
  return (
    <div className="product-body">
      <Async state={o}>
        {(po) => (
          <>
            <div className="btn-row">
              {can("receipt.write") && ["ENVOYEE", "PARTIELLEMENT_RECUE"].includes(po.status) && (
                <Button variant="primary" icon="truck" onClick={() => setReceive(true)}>
                  Réceptionner
                </Button>
              )}
              {can("purchase.write") && (po.receptions?.length ?? 0) > 0 && (
                <Button icon="receipt" onClick={() => setInvoice(true)}>
                  Saisir une facture fournisseur
                </Button>
              )}
            </div>
            <Table caption={`Lignes de ${po.code}`} head={["Article", "Commandé", "Reçu", "Accepté", "Refusé / endommagé", "Coût unitaire HT"]}>
              {po.lines.map((l) => {
                const v = idx.get(l.variant_id);
                const pk = v?.variant.conditionnements.find((c) => c.id === l.packaging_id);
                return (
                  <tr key={l.id}>
                    <td>{variantName(idx, l.variant_id)}</td>
                    <td>
                      {packs(l.pack_qty, pk?.level ?? "CARTON")} = {qty(l.base_qty, v?.unit)}
                    </td>
                    <td>{qty(l.received_base_qty, v?.unit)}</td>
                    <td>{qty(l.accepted_base_qty, v?.unit)}</td>
                    <td className={Number(l.rejected_base_qty) > 0 ? "neg" : ""}>{qty(l.rejected_base_qty, v?.unit)}</td>
                    <td className="num">
                      {eur(l.unit_cost_cents)} / {pk?.label.toLowerCase() ?? "conditionnement"}
                    </td>
                  </tr>
                );
              })}
            </Table>
            <h3>Réceptions</h3>
            {(po.receptions ?? []).length === 0 ? (
              <Empty>Aucune réception.</Empty>
            ) : (
              po.receptions!.map((r) => (
                <div key={r.id} className="sub-card">
                  <p>
                    <strong>{r.code}</strong> · {dateTime(r.received_at)} · BL {r.delivery_note_ref ?? "—"} · {r.carrier ?? "transporteur non renseigné"}
                  </p>
                  <Table caption={`Lignes de ${r.code}`} head={["Article", "Reçu", "Accepté", "Endommagé", "Quarantaine", "Contrôle", ""]}>
                    {r.lines.map((l) => {
                      const u = idx.get(l.variant_id)?.unit;
                      return (
                        <tr key={l.id}>
                          <td>{variantName(idx, l.variant_id)}</td>
                          <td>{qty(l.received_base_qty, u)}</td>
                          <td>{qty(l.accepted_qty, u)}</td>
                          <td>{qty(l.damaged_qty, u)}</td>
                          <td>{qty(l.quarantined_qty, u)}</td>
                          <td>
                            <StatusChip status={l.inspection_result} />
                            {l.inspection_notes && <div className="muted small">{l.inspection_notes}</div>}
                          </td>
                          <td>
                            {l.inspection_result === "A_CONTROLER" && can("quality.inspect") && (
                              <Button size="sm" onClick={() => setInspect(l.id)}>
                                Contrôle différé
                              </Button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </Table>
                </div>
              ))
            )}
            <h3>Factures et rapprochement à trois voies</h3>
            {(po.factures ?? []).length === 0 ? <Empty>Aucune facture saisie.</Empty> : po.factures!.map((f) => <InvoiceResult key={f.id} inv={f} />)}
            {receive && (
              <ReceiptModal
                order={po}
                onClose={() => setReceive(false)}
                onDone={() => {
                  setReceive(false);
                  o.reload();
                  onChange();
                }}
              />
            )}
            {invoice && (
              <InvoiceModal
                po={po}
                onClose={() => setInvoice(false)}
                onDone={() => {
                  setInvoice(false);
                  o.reload();
                }}
              />
            )}
            {inspect !== null && (
              <InspectModal
                lineId={inspect}
                onClose={() => setInspect(null)}
                onDone={() => {
                  setInspect(null);
                  o.reload();
                }}
              />
            )}
          </>
        )}
      </Async>
    </div>
  );
}

function InvoiceResult({ inv }: { inv: SupplierInvoice }) {
  const ok = inv.status === "RAPPROCHEE";
  return (
    <div className={`sub-card ${ok ? "" : "sub-danger"}`}>
      <p>
        <strong>Facture {inv.invoice_number}</strong> du {dateOnly(inv.invoice_date)} — {eur(inv.total_ht_cents)} HT · <StatusChip status={inv.status} />
        {!ok && <span className="neg"> Paiement à suspendre jusqu'à résolution de l'écart.</span>}
      </p>
      {inv.match_result && (
        <Table caption="Rapprochement commandé / accepté / facturé" head={["Ligne", "Commandé", "Reçu", "Accepté", "Facturé", "Prix commandé", "Prix facturé", "Anomalies"]}>
          {inv.match_result.lignes.map((l) => (
            <tr key={l.ligne}>
              <td>{l.ligne}</td>
              <td>{l.commande}</td>
              <td>{l.recu}</td>
              <td>{l.accepte}</td>
              <td>{l.facture}</td>
              <td>{eur(l.prix_commande)}</td>
              <td>{eur(l.prix_facture)}</td>
              <td className={l.anomalies.length ? "neg" : ""}>{l.anomalies.length ? l.anomalies.join(" ; ") : "Aucune"}</td>
            </tr>
          ))}
        </Table>
      )}
    </div>
  );
}

function InvoiceModal({ po, onClose, onDone }: { po: PurchaseOrder; onClose: () => void; onDone: () => void }) {
  const idx = useCatalogIndex();
  const [num, setNum] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState(() => po.lines.map((l) => ({ id: l.id, q: String(Number(l.accepted_base_qty)), cost: (l.unit_cost_cents / 100).toFixed(2).replace(".", ",") })));
  const [result, setResult] = useState<SupplierInvoice | null>(null);
  const a = useAction();
  const submit = () =>
    a.run(async () => {
      const r = await post<SupplierInvoice>(`/api/achats/commandes/${po.id}/factures`, {
        invoice_number: num,
        invoice_date: date,
        lines: lines.map((l) => {
          const c = parseEuros(l.cost);
          if (c === null || !parseQty(l.q)) throw new Error("Quantité ou prix invalide");
          return { order_line_id: l.id, base_qty: parseQty(l.q), unit_cost_cents: c };
        }),
      });
      setResult(r);
    });
  return (
    <Modal
      title={`Facture fournisseur — ${po.code}`}
      onClose={result ? onDone : onClose}
      wide
      footer={
        result ? (
          <Button variant="primary" onClick={onDone}>
            Fermer
          </Button>
        ) : (
          <>
            <Button variant="ghost" onClick={onClose}>
              Annuler
            </Button>
            <Button variant="primary" busy={a.busy} disabled={!num} onClick={submit}>
              Enregistrer et rapprocher
            </Button>
          </>
        )
      }
    >
      {result ? (
        <InvoiceResult inv={result} />
      ) : (
        <>
          <div className="form-grid">
            <Field label="N° de facture" required>
              <input value={num} onChange={(e) => setNum(e.target.value)} />
            </Field>
            <Field label="Date de facture" required>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
          </div>
          <Table caption="Lignes facturées" head={["Article", "Quantité facturée (unité de base)", "Prix unitaire HT facturé (par conditionnement d'achat)"]}>
            {po.lines.map((l, i) => (
              <tr key={l.id}>
                <td>{variantName(idx, l.variant_id)}</td>
                <td>
                  <input aria-label="Quantité facturée" inputMode="decimal" value={lines[i].q} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, q: e.target.value } : x)))} />
                </td>
                <td>
                  <input aria-label="Prix facturé" inputMode="decimal" value={lines[i].cost} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, cost: e.target.value } : x)))} /> €
                </td>
              </tr>
            ))}
          </Table>
          <Notice>Le rapprochement compare commandé / accepté en réception / facturé (tolérance de prix 1 %).</Notice>
        </>
      )}
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function InspectModal({ lineId, onClose, onDone }: { lineId: number; onClose: () => void; onDone: () => void }) {
  const [result, setResult] = useState("CONFORME");
  const [notes, setNotes] = useState("");
  const a = useAction();
  return (
    <Modal
      title="Contrôle différé de la ligne de réception"
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={notes.trim().length < 3} onClick={() => a.run(async () => { await post(`/api/achats/receptions/lignes/${lineId}/controle`, { result, notes }); onDone(); })}>
          Enregistrer le contrôle
        </Button>
      }
    >
      <Field label="Résultat">
        <select value={result} onChange={(e) => setResult(e.target.value)}>
          <option value="CONFORME">Conforme → stock disponible</option>
          <option value="NON_CONFORME">Non conforme → quarantaine</option>
        </select>
      </Field>
      <Field label="Observations (obligatoire)" required>
        <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Documents({ state }: { state: ReturnType<typeof useApi<SupplierDocument[]>> }) {
  const { can } = useAuth();
  const { orgName } = useSite();
  const [upload, setUpload] = useState(false);
  const [verify, setVerify] = useState<SupplierDocument | null>(null);
  return (
    <Card
      title="Documents fournis par les fournisseurs"
      subtitle="Un document déposé est « Non vérifié » : son dépôt, son empreinte SHA-256 ou une signature ne prouvent pas son authenticité."
      actions={
        can("receipt.write") && (
          <Button variant="primary" icon="plus" onClick={() => setUpload(true)}>
            Déposer un document
          </Button>
        )
      }
    >
      <Async state={state} empty={(x) => x.length === 0}>
        {(rows) => (
          <ul className="doc-list">
            {rows.map((d) => (
              <li key={d.id} className={`doc doc-${d.authenticity_status.toLowerCase()}`}>
                <div className="doc-status">
                  {d.authenticity_status === "NON_VERIFIE" ? (
                    <span className="doc-unverified">
                      <Icon name="warning" size={22} /> Non vérifié
                    </span>
                  ) : (
                    <StatusChip status={d.authenticity_status} />
                  )}
                </div>
                <div className="doc-main">
                  <strong>{DOC_KINDS[d.kind] ?? d.kind}</strong> — {orgName(d.supplier_id)}
                  <KV
                    items={[
                      ["Émetteur déclaré", d.claimed_issuer ?? "—"],
                      ["Référence déclarée", d.claimed_reference ?? "—"],
                      ["Lot", d.lot_id ?? "—"],
                      ["Empreinte SHA-256", <Copyable key="h" text={d.sha256} short={20} />],
                      ["Déposé le", dateTime(d.created_at)],
                      ...(d.verified_at ? ([["Vérification", `${d.verification_method} (${dateTime(d.verified_at)})${d.verification_note ? ` — ${d.verification_note}` : ""}`]] as [string, string][]) : []),
                    ]}
                  />
                </div>
                {can("quality.inspect") && d.authenticity_status === "NON_VERIFIE" && (
                  <Button onClick={() => setVerify(d)} icon="shield">
                    Enregistrer une vérification
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
      </Async>
      {upload && (
        <UploadModal
          onClose={() => setUpload(false)}
          onDone={() => {
            setUpload(false);
            state.reload();
          }}
        />
      )}
      {verify && (
        <VerifyDocModal
          doc={verify}
          onClose={() => setVerify(null)}
          onDone={() => {
            setVerify(null);
            state.reload();
          }}
        />
      )}
    </Card>
  );
}

function UploadModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const sup = useApi<Organisation[]>("/api/achats/fournisseurs");
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const [supplier, setSupplier] = useState<number | "">("");
  const [kind, setKind] = useState("CERTIFICAT_ANALYSE");
  const [issuer, setIssuer] = useState("");
  const [ref, setRef] = useState("");
  const [lot, setLot] = useState<number | "">("");
  const [file, setFile] = useState<File | null>(null);
  const a = useAction();
  const { push } = useToast();
  const submit = () =>
    a.run(async () => {
      if (!file || supplier === "") throw new Error("Fournisseur et fichier requis");
      const fd = new FormData();
      fd.set("supplier_id", String(supplier));
      fd.set("kind", kind);
      if (issuer) fd.set("claimed_issuer", issuer);
      if (ref) fd.set("claimed_reference", ref);
      if (lot !== "") fd.set("lot_id", String(lot));
      fd.set("file", file);
      const r = await api<SupplierDocument & { avertissement: string }>("/api/achats/documents", { method: "POST", form: fd });
      push("warning", "Document enregistré — Non vérifié", r.avertissement);
      onDone();
    });
  return (
    <Modal
      title="Déposer un document fournisseur"
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={!file || supplier === ""} onClick={submit}>
            Déposer
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label="Fournisseur" required>
          <select value={supplier} onChange={(e) => setSupplier(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {(sup.data ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Type de document">
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            {Object.entries(DOC_KINDS).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Émetteur déclaré">
          <input value={issuer} onChange={(e) => setIssuer(e.target.value)} />
        </Field>
        <Field label="Référence déclarée">
          <input value={ref} onChange={(e) => setRef(e.target.value)} />
        </Field>
        <Field label="Lot concerné">
          <select value={lot} onChange={(e) => setLot(e.target.value ? Number(e.target.value) : "")}>
            <option value="">Aucun</option>
            {(lots.data ?? []).map((l) => (
              <option key={l.id} value={l.id}>
                {l.lot_code} — {l.libelle}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Fichier (PDF, image)" required>
          <input type="file" accept="application/pdf,image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        </Field>
      </div>
      <Notice tone="warning">Le document sera enregistré comme NON VÉRIFIÉ. Seule une vérification documentée (ex. confirmation écrite de l'organisme émetteur) change ce statut.</Notice>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function VerifyDocModal({ doc, onClose, onDone }: { doc: SupplierDocument; onClose: () => void; onDone: () => void }) {
  const [status, setStatus] = useState("VERIFIE");
  const [method, setMethod] = useState("");
  const [note, setNote] = useState("");
  const a = useAction();
  return (
    <Modal
      title={`Vérifier — ${DOC_KINDS[doc.kind] ?? doc.kind}`}
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={method.trim().length < 10} onClick={() => a.run(async () => { await post(`/api/achats/documents/${doc.id}/verification`, { status, method, note }); onDone(); })}>
          Enregistrer
        </Button>
      }
    >
      <Field label="Résultat">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="VERIFIE">Vérifié auprès de la source</option>
          <option value="REJETE">Rejeté (faux, incohérent, non confirmé)</option>
        </select>
      </Field>
      <Field label="Méthode de vérification (10 caractères minimum)" required hint="ex. confirmation écrite de l'organisme certificateur, n° de dossier">
        <input value={method} onChange={(e) => setMethod(e.target.value)} />
      </Field>
      <Field label="Note">
        <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function Needs() {
  const needs = useApi<{ id: number; variant_id: number; site_id: number; quantity: string; source: string; explanation: string; status: string; created_at: string }[]>("/api/achats/besoins");
  const idx = useCatalogIndex();
  const { siteName } = useSite();
  return (
    <Card title="Besoins de réapprovisionnement" subtitle="Générés par la règle de réapprovisionnement ou les prévisions ; ils alimentent les propositions d'achat.">
      <Async state={needs} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Besoins" head={["Date", "Article", "Site", "Quantité", "Source", "Explication", "Statut"]}>
            {rows.map((n) => (
              <tr key={n.id}>
                <td>{dateTime(n.created_at)}</td>
                <td>{variantName(idx, n.variant_id)}</td>
                <td>{siteName(n.site_id)}</td>
                <td>{qty(n.quantity, idx.get(n.variant_id)?.unit)}</td>
                <td>{n.source}</td>
                <td className="small">{n.explanation}</td>
                <td>
                  <StatusChip status={n.status} />
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
    </Card>
  );
}
