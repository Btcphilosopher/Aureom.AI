import { useEffect, useState } from "react";
import { patch, post } from "../api/client";
import type { ActionProposal, Alert, ForecastRun, ModelEval, Rule, StockoutRisk } from "../api/types";
import { BandChart, Gauge, HBars } from "../components/charts";
import { VariantSelect } from "../components/forms";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, Empty, ErrorBox, Field, KV, Modal, Notice, PageHeader, SeverityBadge, StatusChip, Table, Tabs } from "../components/ui";
import { useCatalogIndex, variantName } from "../lib/catalogIndex";
import { dateOnly, dateTime, eur, num, pct, unitLabel } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { statusLabel } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

const MODEL_LABELS: Record<string, string> = {
  naif_saisonnier: "Naïf saisonnier (même jour, semaine précédente)",
  moyenne_mobile_28j: "Moyenne mobile 28 jours",
  ets_hebdomadaire: "Lissage exponentiel avec saisonnalité hebdomadaire",
};

export default function AutomationPage() {
  const [tab, setTab] = useQueryState("onglet", "alertes");
  const { can } = useAuth();
  return (
    <>
      <PageHeader icon="automation" title="Automatisations" subtitle="Règles explicites, alertes, propositions soumises à approbation humaine, prévisions évaluées." />
      <Notice>Aucune action automatique n'est exécutée sans décision humaine : les règles et modèles produisent des alertes et des propositions motivées.</Notice>
      <Tabs
        label="Sections des automatisations"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "alertes", label: "Alertes" },
          { id: "propositions", label: "Propositions" },
          { id: "regles", label: "Règles" },
          { id: "previsions", label: "Prévisions", hidden: !can("analytics.read") },
          { id: "risque", label: "Risque de rupture et répartition", hidden: !can("analytics.read") },
        ]}
      />
      {tab === "alertes" && <Alerts />}
      {tab === "propositions" && <Proposals />}
      {tab === "regles" && <Rules />}
      {tab === "previsions" && <Forecasts />}
      {tab === "risque" && <Risk />}
    </>
  );
}

function Alerts() {
  const [status, setStatus] = useState("OUVERTE");
  const { siteName } = useSite();
  const alerts = useApi<Alert[]>(`/api/automatisations/alertes?status=${status}`, ["alerte"]);
  const a = useAction();
  const { push } = useToast();
  const update = (al: Alert, s: string) =>
    a.run(async () => {
      await post(`/api/automatisations/alertes/${al.id}`, { status: s });
      push("success", `Alerte ${statusLabel(s).toLowerCase()}`, al.title);
      alerts.reload();
    });
  return (
    <Card
      title="Alertes"
      actions={
        <Button
          icon="play"
          busy={a.busy}
          onClick={() =>
            a.run(async () => {
              const r = await post<Record<string, unknown>>("/api/automatisations/executer");
              push("info", "Règles évaluées", Object.entries(r).map(([k, v]) => `${k} : ${typeof v === "object" ? JSON.stringify(v) : String(v)}`).join(" · ").slice(0, 200));
              alerts.reload();
            })
          }
        >
          Évaluer toutes les règles maintenant
        </Button>
      }
    >
      <div className="toolbar">
        <Field label="Statut">
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="OUVERTE">Ouvertes</option>
            <option value="PRISE_EN_CHARGE">Prises en charge</option>
            <option value="RESOLUE">Résolues</option>
            <option value="IGNOREE">Ignorées</option>
            <option value="">Toutes</option>
          </select>
        </Field>
      </div>
      <ErrorBox error={a.error} />
      <Async state={alerts} empty={(x) => x.length === 0}>
        {(rows) => (
          <ul className="alert-list big">
            {rows.map((al) => (
              <li key={al.id} className={`alert-item alert-${al.severity.toLowerCase()}`}>
                <SeverityBadge severity={al.severity} />
                <div className="alert-body">
                  <strong>{al.title}</strong>
                  <p>{al.message}</p>
                  {Object.keys(al.explanation ?? {}).length > 0 && (
                    <details>
                      <summary>Explication de la règle</summary>
                      <KV items={Object.entries(al.explanation).map(([k, v]) => [k.replaceAll("_", " "), Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : String(v)])} />
                    </details>
                  )}
                  <span className="muted small">
                    Règle {al.rule_code} · {al.site_id ? siteName(al.site_id) : "tous sites"} · {dateTime(al.created_at)} · <StatusChip status={al.status} />
                  </span>
                </div>
                <div className="btn-col">
                  {al.status === "OUVERTE" && (
                    <Button size="sm" onClick={() => update(al, "PRISE_EN_CHARGE")}>
                      Prendre en charge
                    </Button>
                  )}
                  {["OUVERTE", "PRISE_EN_CHARGE"].includes(al.status) && (
                    <>
                      <Button size="sm" variant="primary" onClick={() => update(al, "RESOLUE")}>
                        Résoudre
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => update(al, "IGNOREE")}>
                        Ignorer
                      </Button>
                    </>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Async>
    </Card>
  );
}

function Proposals() {
  const [status, setStatus] = useState("PROPOSEE");
  const { siteName } = useSite();
  const props = useApi<ActionProposal[]>(`/api/automatisations/propositions?status=${status}`, ["alerte"]);
  const [decide, setDecide] = useState<{ p: ActionProposal; approve: boolean } | null>(null);
  return (
    <Card title="Propositions d'action" subtitle="Chaque proposition est motivée ; l'approbation exige la permission indiquée.">
      <div className="toolbar">
        <Field label="Statut">
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="PROPOSEE">À décider</option>
            <option value="EXECUTEE">Exécutées</option>
            <option value="REJETEE">Rejetées</option>
            <option value="">Toutes</option>
          </select>
        </Field>
      </div>
      <Async state={props} empty={(x) => x.length === 0}>
        {(rows) => (
          <ul className="prop-list">
            {rows.map((p) => (
              <li key={p.id} className="prop">
                <div className="prop-head">
                  <Badge tone="accent">{p.kind.replaceAll("_", " ").toLowerCase()}</Badge>
                  <strong>{p.title}</strong>
                  <StatusChip status={p.status} />
                </div>
                <p>
                  <span className="muted small">Justification : </span>
                  {p.rationale}
                </p>
                <KV
                  items={[
                    ["Source", `${p.source}${p.source_code ? ` · ${p.source_code}` : ""}`],
                    ["Site", p.site_id ? siteName(p.site_id) : "—"],
                    ["Valeur estimée", p.valeur_affichage],
                    ["Permission requise", p.required_permission ?? "—"],
                    ["Créée le", dateTime(p.created_at)],
                    ...(p.decision_note ? ([["Décision", `${p.decision_note}${p.executed_ref ? ` (${p.executed_ref})` : ""}`]] as [string, string][]) : []),
                  ]}
                />
                <details>
                  <summary>Contenu proposé (données)</summary>
                  <pre className="json">{JSON.stringify(p.payload, null, 2)}</pre>
                  {p.model_info && <pre className="json">{JSON.stringify(p.model_info, null, 2)}</pre>}
                </details>
                {p.status === "PROPOSEE" && (
                  <div className="btn-row">
                    <Button variant="primary" icon="check" onClick={() => setDecide({ p, approve: true })}>
                      Approuver
                    </Button>
                    <Button variant="ghost" icon="cross" onClick={() => setDecide({ p, approve: false })}>
                      Rejeter
                    </Button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </Async>
      {decide && (
        <DecideModal
          {...decide}
          onClose={() => setDecide(null)}
          onDone={() => {
            setDecide(null);
            props.reload();
          }}
        />
      )}
    </Card>
  );
}

function DecideModal({ p, approve, onClose, onDone }: { p: ActionProposal; approve: boolean; onClose: () => void; onDone: () => void }) {
  const [note, setNote] = useState("");
  const a = useAction();
  const { push } = useToast();
  return (
    <Modal
      title={`${approve ? "Approuver" : "Rejeter"} : ${p.title}`}
      onClose={onClose}
      footer={
        <Button
          variant={approve ? "primary" : "danger"}
          busy={a.busy}
          disabled={approve && note.trim().length < 3}
          onClick={() =>
            a.run(async () => {
              const r = await post<{ statut: string; reference?: string }>(`/api/automatisations/propositions/${p.id}/decision`, { approve, note });
              push("success", `Proposition ${statusLabel(r.statut).toLowerCase()}`, r.reference);
              onDone();
            })
          }
        >
          {approve ? "Approuver et exécuter" : "Rejeter"}
        </Button>
      }
    >
      <p>{p.rationale}</p>
      <Field label={approve ? "Constat / justification de la décision (obligatoire)" : "Motif du rejet"} required={approve}>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} title="Décision refusée" />
    </Modal>
  );
}

function Rules() {
  const { can } = useAuth();
  const rules = useApi<Rule[]>("/api/automatisations/regles");
  const [edit, setEdit] = useState<Rule | null>(null);
  const a = useAction();
  return (
    <Card title="Règles" subtitle={can("automation.approve") ? "Activez, désactivez ou ajustez les paramètres." : "Lecture seule : la modification exige la permission « Approuver des propositions automatiques »."}>
      <ErrorBox error={a.error} />
      <Async state={rules}>
        {(rows) => (
          <Table caption="Règles d'automatisation" head={["Règle", "Description", "Paramètres", "Dernière exécution", "État", ""]}>
            {rows.map((r) => (
              <tr key={r.code}>
                <td>
                  <strong>{r.label}</strong>
                  <div className="muted small">{r.code}</div>
                </td>
                <td className="small">{r.description}</td>
                <td className="small">
                  {Object.keys(r.params).length === 0
                    ? "—"
                    : Object.entries(r.params).map(([k, v]) => (
                        <div key={k}>
                          {k.replaceAll("_", " ")} : <strong>{String(v)}</strong>
                        </div>
                      ))}
                </td>
                <td>{dateTime(r.last_run_at)}</td>
                <td>
                  <Badge tone={r.enabled ? "success" : "neutral"} icon={r.enabled ? "check" : "pause"}>
                    {r.enabled ? "Active" : "Désactivée"}
                  </Badge>
                </td>
                <td>
                  {can("automation.approve") && (
                    <div className="btn-col">
                      <Button
                        size="sm"
                        busy={a.busy}
                        onClick={() =>
                          a.run(async () => {
                            await patch(`/api/automatisations/regles/${r.code}`, { enabled: !r.enabled });
                            rules.reload();
                          })
                        }
                      >
                        {r.enabled ? "Désactiver" : "Activer"}
                      </Button>
                      {Object.keys(r.params).length > 0 && (
                        <Button size="sm" icon="edit" onClick={() => setEdit(r)}>
                          Paramètres
                        </Button>
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {edit && (
        <RuleModal
          rule={edit}
          onClose={() => setEdit(null)}
          onDone={() => {
            setEdit(null);
            rules.reload();
          }}
        />
      )}
    </Card>
  );
}

function RuleModal({ rule, onClose, onDone }: { rule: Rule; onClose: () => void; onDone: () => void }) {
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(Object.entries(rule.params).map(([k, v]) => [k, String(v)])));
  const a = useAction();
  const submit = () =>
    a.run(async () => {
      const params: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(vals)) {
        const orig = rule.params[k];
        if (typeof orig === "number") {
          const n = Number(v.replace(",", "."));
          if (Number.isNaN(n)) throw new Error(`Valeur numérique attendue pour « ${k} »`);
          params[k] = n;
        } else if (typeof orig === "boolean") params[k] = v === "true";
        else params[k] = v;
      }
      await patch(`/api/automatisations/regles/${rule.code}`, { params });
      onDone();
    });
  return (
    <Modal
      title={`Paramètres — ${rule.label}`}
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} onClick={submit}>
          Enregistrer
        </Button>
      }
    >
      <p className="muted">{rule.description}</p>
      {Object.entries(vals).map(([k, v]) => (
        <Field key={k} label={k.replaceAll("_", " ")}>
          {typeof rule.params[k] === "boolean" ? (
            <select value={v} onChange={(e) => setVals({ ...vals, [k]: e.target.value })}>
              <option value="true">Oui</option>
              <option value="false">Non</option>
            </select>
          ) : (
            <input value={v} inputMode={typeof rule.params[k] === "number" ? "decimal" : undefined} onChange={(e) => setVals({ ...vals, [k]: e.target.value })} />
          )}
        </Field>
      ))}
      <ErrorBox error={a.error} />
    </Modal>
  );
}

/* ---- Prévisions ------------------------------------------------------------------------------------- */

function ForecastForm({ onRun, busy, label, withHorizon = true }: { onRun: (v: number, s: number, h: number) => void; busy: boolean; label: string; withHorizon?: boolean }) {
  const { mySites, siteId } = useSite();
  const idx = useCatalogIndex();
  const [variant, setVariant] = useState<number | "">("");
  const [site, setSite] = useState<number | "">(siteId ?? "");
  const [h, setH] = useState(7);
  useEffect(() => {
    if (variant === "" && idx.size > 0) {
      const huile = [...idx.values()].find((v) => v.sku === "HUILE-OLV-75");
      if (huile) setVariant(huile.id);
    }
  }, [idx, variant]);
  useEffect(() => {
    if (site === "" && mySites.length) setSite(mySites.find((s) => s.kind === "MAGASIN")?.id ?? mySites[0].id);
  }, [mySites, site]);
  return (
    <form
      className="toolbar"
      onSubmit={(e) => {
        e.preventDefault();
        if (variant !== "" && site !== "") onRun(variant, site, h);
      }}
    >
      <VariantSelect required value={variant} onChange={setVariant} />
      <Field label="Site">
        <select value={site} onChange={(e) => setSite(e.target.value ? Number(e.target.value) : "")}>
          {mySites.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </Field>
      {withHorizon && (
        <Field label="Horizon (jours)">
          <select value={h} onChange={(e) => setH(Number(e.target.value))}>
            {[7, 14, 28].map((n) => (
              <option key={n} value={n}>
                {n} jours
              </option>
            ))}
          </select>
        </Field>
      )}
      <Button type="submit" variant="primary" icon="play" busy={busy} disabled={variant === "" || site === ""}>
        {label}
      </Button>
    </form>
  );
}

function Forecasts() {
  const a = useAction();
  const [run, setRun] = useState<ForecastRun | null>(null);
  const history = useApi<ForecastRun[]>("/api/automatisations/previsions");
  const idx = useCatalogIndex();
  const { siteName } = useSite();
  return (
    <>
      <Card title="Prévision de la demande" subtitle="Évaluée sur une période de test distincte de l'apprentissage et comparée aux méthodes simples.">
        <ForecastForm
          label="Calculer la prévision"
          busy={a.busy}
          onRun={(variant_id, site_id, horizon_days) =>
            a.run(async () => {
              setRun(await post<ForecastRun>("/api/automatisations/previsions", { variant_id, site_id, horizon_days }));
              history.reload();
            })
          }
        />
        <ErrorBox error={a.error} />
        {run ? <ForecastView run={run} /> : <Empty>Choisissez un article et un site puis lancez le calcul (ex. huile d'olive à Paris).</Empty>}
      </Card>
      <Card title="Prévisions précédentes">
        <Async state={history} empty={(x) => x.length === 0}>
          {(rows) => (
            <Table caption="Historique des prévisions" head={["Date", "Article", "Site", "Horizon", "Modèle retenu", ""]}>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>{dateTime(r.created_at)}</td>
                  <td>{variantName(idx, r.variant_id)}</td>
                  <td>{siteName(r.site_id)}</td>
                  <td>{r.horizon_days} j</td>
                  <td>{MODEL_LABELS[r.chosen_model] ?? r.chosen_model}</td>
                  <td>
                    <Button size="sm" onClick={() => setRun(r)}>
                      Afficher
                    </Button>
                  </td>
                </tr>
              ))}
            </Table>
          )}
        </Async>
      </Card>
    </>
  );
}

function ForecastView({ run }: { run: ForecastRun }) {
  const idx = useCatalogIndex();
  const { siteName } = useSite();
  const unit = idx.get(run.variant_id)?.unit ?? "PCE";
  const sel = run.evaluation._selection as { retenu: string; meilleur_mase: string; regle: string; intervalle: string; couverture_validation: number } | undefined;
  const models = Object.entries(run.evaluation).filter(([k]) => !k.startsWith("_")) as [string, ModelEval][];
  const dq = run.data_quality;
  const synthetic = dq.sources.includes("SYNTHETIQUE");
  const total = run.forecast.reduce((s, p) => s + p.prevision, 0);
  return (
    <div className="stack forecast">
      <h3>
        {variantName(idx, run.variant_id)} — {siteName(run.site_id)} · {run.horizon_days} jours
      </h3>
      <div className="dq">
        {synthetic && (
          <Notice tone="warning" title="Données synthétiques">
            {dq.avertissement ?? "Données SYNTHÉTIQUES de démonstration"} : les performances affichées ne préjugent pas du comportement sur des ventes réelles.
          </Notice>
        )}
        <Notice tone={dq.jours_manquants > 0 || dq.jours_rupture_exclus > 0 ? "warning" : "info"} title="Qualité des données">
          {num(dq.jours)} jours d'historique, {num(dq.jours_valides)} valides, {num(dq.jours_rupture_exclus)} jour(s) de rupture exclu(s) (demande non observable), {num(dq.jours_manquants)} jour(s) manquant(s). Sources : {dq.sources.join(", ")}.
        </Notice>
      </div>
      <KV
        items={[
          ["Apprentissage", `${dateOnly(run.train_start)} → ${dateOnly(run.train_end)}`],
          ["Test (évaluation)", `${dateOnly(run.test_start)} → ${dateOnly(run.test_end)}`],
          ["Modèle retenu", <strong key="m">{MODEL_LABELS[run.chosen_model] ?? run.chosen_model}</strong>],
          ["Règle de choix", sel?.regle ?? "—"],
          ["Meilleur MASE en test", sel ? (MODEL_LABELS[sel.meilleur_mase] ?? sel.meilleur_mase) : "—"],
          ["Intervalle", sel?.intervalle ?? "—"],
          ["Couverture observée en validation", sel ? pct(sel.couverture_validation * 100, 1) + " (cible 80 %)" : "—"],
        ]}
      />
      <div className="grid-2">
        <div>
          <h4>Évaluation sur la période de test</h4>
          <Table caption="Évaluation des modèles" head={["Modèle", "MAE", "RMSE", "Biais", "MASE", "Points"]}>
            {models.map(([k, m]) => (
              <tr key={k} className={k === run.chosen_model ? "row-hl" : ""}>
                <td>
                  {MODEL_LABELS[k] ?? k} {k === run.chosen_model && <Badge tone="accent">retenu</Badge>}
                </td>
                <td className="num">{num(m.mae, 3)}</td>
                <td className="num">{num(m.rmse, 3)}</td>
                <td className="num">{num(m.biais, 3)}</td>
                <td className="num">
                  <strong>{num(m.mase, 3)}</strong>
                </td>
                <td className="num">{m.n_points}</td>
              </tr>
            ))}
          </Table>
          <p className="muted small">MAE : erreur absolue moyenne ({unitLabel(unit)}/jour). MASE &lt; 1 : meilleur que la prévision naïve de référence. Biais négatif : sous-prévision.</p>
        </div>
        <div>
          <h4>MASE par modèle (plus bas = meilleur)</h4>
          <HBars title="MASE par modèle" rows={models.map(([k, m]) => ({ label: MODEL_LABELS[k] ?? k, value: m.mase }))} format={(v) => num(v, 3)} highlight={MODEL_LABELS[run.chosen_model] ?? run.chosen_model} />
        </div>
      </div>
      <h4>
        Prévision journalière avec intervalle à 80 % — total sur l'horizon : {num(total, 1)} {unitLabel(unit, total)}
      </h4>
      <BandChart title={`Prévision ${variantName(idx, run.variant_id)}`} unit={unitLabel(unit)} points={run.forecast.map((p) => ({ x: p.jour, y: p.prevision, lo: p.bas, hi: p.haut }))} />
      <details>
        <summary>Valeurs de la prévision (tableau)</summary>
        <Table caption="Valeurs de la prévision" head={["Jour", "Prévision", "Borne basse (10 %)", "Borne haute (90 %)"]}>
          {run.forecast.map((p) => (
            <tr key={p.jour}>
              <td>{dateOnly(p.jour)}</td>
              <td className="num">{num(p.prevision, 1)}</td>
              <td className="num">{num(p.bas, 1)}</td>
              <td className="num">{num(p.haut, 1)}</td>
            </tr>
          ))}
        </Table>
      </details>
    </div>
  );
}

/* ---- Risque et répartition -------------------------------------------------------------------------- */

function Risk() {
  const a = useAction();
  const b = useAction();
  const c = useAction();
  const idx = useCatalogIndex();
  const { mySites } = useSite();
  const [risk, setRisk] = useState<StockoutRisk | null>(null);
  const [anom, setAnom] = useState<{ jour: string; valeur: number; score: number; sens: string }[] | null>(null);
  const [variant, setVariant] = useState<number | "">("");
  const [sites, setSites] = useState<number[]>([]);
  const [cover, setCover] = useState("7");
  const [alloc, setAlloc] = useState<ActionProposal | { proposition: null; raison: string } | null>(null);
  useEffect(() => {
    if (sites.length === 0) setSites(mySites.filter((s) => s.kind === "MAGASIN").map((s) => s.id));
  }, [mySites, sites.length]);
  return (
    <>
      <div className="grid-2">
        <Card title="Risque de rupture" subtitle="Probabilité que la demande sur le délai de réapprovisionnement dépasse l'offre (disponible + attendu).">
          <ForecastForm
            label="Estimer le risque"
            busy={a.busy}
            onRun={(variant_id, site_id, horizon_days) => a.run(async () => setRisk(await post<StockoutRisk>("/api/automatisations/risque-rupture", { variant_id, site_id, horizon_days })))}
          />
          <ErrorBox error={a.error} />
          {risk && (
            <div className="stack">
              <Gauge value={risk.probabilite_rupture} label="Probabilité de rupture" />
              <KV
                items={[
                  ["Demande médiane sur le délai", num(risk.demande_mediane, 1)],
                  ["Demande au 90e centile", num(risk.demande_p90, 1)],
                  ["Offre (disponible + attendu)", num(risk.offre, 1)],
                  ["Délai considéré", `${risk.delai_jours} jours`],
                  ["Modèle", MODEL_LABELS[risk.modele] ?? risk.modele],
                ]}
              />
              <Notice tone="warning">{risk.limite}</Notice>
            </div>
          )}
        </Card>
        <Card title="Anomalies de ventes" subtitle="Jours dont la demande s'écarte fortement du profil habituel (score robuste).">
          <ForecastForm label="Détecter" withHorizon={false} busy={b.busy} onRun={(variant_id, site_id) => b.run(async () => setAnom(await post("/api/automatisations/anomalies", { variant_id, site_id })))} />
          <ErrorBox error={b.error} />
          {anom &&
            (anom.length === 0 ? (
              <Empty>Aucune anomalie détectée.</Empty>
            ) : (
              <Table caption="Anomalies" head={["Jour", "Valeur", "Score", "Sens"]}>
                {anom.map((x) => (
                  <tr key={x.jour}>
                    <td>{dateOnly(x.jour)}</td>
                    <td className="num">{num(x.valeur)}</td>
                    <td className="num">{num(x.score, 2)}</td>
                    <td>
                      <Badge tone={x.sens === "hausse" ? "copper" : "info"} icon={x.sens === "hausse" ? "plus" : "minus"}>
                        {x.sens}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </Table>
            ))}
        </Card>
      </div>
      <Card title="Proposition de répartition entre magasins" subtitle="Rééquilibrage par couverture (jours de vente) — crée une proposition soumise à approbation, sans transfert automatique.">
        <form
          className="toolbar"
          onSubmit={(e) => {
            e.preventDefault();
            void c.run(async () => setAlloc(await post("/api/automatisations/repartition", { variant_id: variant, site_ids: sites, min_cover_days: Number(cover.replace(",", ".")) || 7 })));
          }}
        >
          <VariantSelect required value={variant} onChange={setVariant} />
          <fieldset className="inline-checks">
            <legend>Sites</legend>
            {mySites.map((s) => (
              <label key={s.id} className="check">
                <input type="checkbox" checked={sites.includes(s.id)} onChange={(e) => setSites(e.target.checked ? [...sites, s.id] : sites.filter((x) => x !== s.id))} /> {s.name}
              </label>
            ))}
          </fieldset>
          <Field label="Couverture minimale (jours)">
            <input inputMode="decimal" value={cover} onChange={(e) => setCover(e.target.value)} />
          </Field>
          <Button type="submit" variant="primary" busy={c.busy} disabled={variant === "" || sites.length < 2}>
            Proposer
          </Button>
        </form>
        <ErrorBox error={c.error} />
        {alloc &&
          ("proposition" in alloc && alloc.proposition === null ? (
            <Notice tone="success" title="Aucun transfert justifié">
              {alloc.raison}
            </Notice>
          ) : (
            <div className="prop">
              <div className="prop-head">
                <Icon name="truck" />
                <strong>{(alloc as ActionProposal).title}</strong>
                <StatusChip status={(alloc as ActionProposal).status} />
              </div>
              <p>{(alloc as ActionProposal).rationale}</p>
              <p className="muted small">
                Valeur estimée {eur((alloc as ActionProposal).estimated_value_cents)} — à approuver dans l'onglet « Propositions » ({variantName(idx, variant === "" ? null : variant)}).
              </p>
            </div>
          ))}
      </Card>
    </>
  );
}
