import { useState } from "react";
import { qs } from "../api/client";
import type { Indicator, Indicators } from "../api/types";
import { HBars } from "../components/charts";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, Field, Notice, PageHeader, Table } from "../components/ui";
import { ago, dateTime, num } from "../lib/format";
import { useApi } from "../lib/hooks";
import { useSite } from "../state/site";

const FINANCE = ["ca_ttc", "ca_ht", "encaissements_nets", "marge_brute", "benefice", "retours_rembourses"];
const FRESH_LABELS: Record<string, string> = {
  dernier_mouvement_stock: "Dernier mouvement de stock",
  derniere_vente: "Dernière vente",
  derniere_confirmation_registre: "Dernière confirmation du registre",
  derniere_observation_capteur: "Dernière observation de capteur",
  derniere_prevision: "Dernière prévision calculée",
  derniere_reconciliation: "Dernière réconciliation du registre",
};

function isoDay(d: Date) {
  return d.toISOString().slice(0, 10);
}

function value(i: Indicator): string {
  if (i.affichage) return i.affichage;
  if (i.valeur === null) return "non disponible";
  return `${num(i.valeur, 2)} ${i.unite ?? ""}`.trim();
}

function extras(i: Indicator): string[] {
  const out: string[] = [];
  for (const [k, v] of Object.entries(i)) {
    if (["code", "libelle", "valeur", "unite", "definition", "affichage"].includes(k)) continue;
    if (v === null || v === undefined) continue;
    const label = k.replaceAll("_", " ");
    if (typeof v === "object") {
      const entries = Object.entries(v as Record<string, unknown>);
      if (entries.length) out.push(`${label} : ${entries.map(([a, b]) => `${a} ${String(b)}`).join(", ")}`);
      else if (Array.isArray(v)) out.push(`${label} : aucun`);
    } else out.push(`${label} : ${typeof v === "number" ? num(v, 2) : String(v)}`);
  }
  return out;
}

export default function AnalyticsPage() {
  const { siteId, site } = useSite();
  const [from, setFrom] = useState(() => isoDay(new Date(Date.now() - 30 * 86400000)));
  const [to, setTo] = useState(() => isoDay(new Date()));
  const [period, setPeriod] = useState({ from, to });
  const ind = useApi<Indicators>(`/api/analyses/indicateurs${qs({ debut: `${period.from}T00:00:00Z`, fin: `${period.to}T23:59:59Z`, site_id: siteId })}`, ["caisse.vente", "stock.mouvement"]);
  const sup = useApi<{ fournisseur: string; commandes_recues: number; delai_moyen_jours: number | null; promis_jours: number | null }[]>("/api/analyses/fournisseurs");
  return (
    <>
      <PageHeader icon="analytics" title="Analyses" subtitle={`Indicateurs définis, datés et sourcés — ${site ? site.name : "tous les sites"}.`} />
      <Card>
        <form
          className="toolbar"
          onSubmit={(e) => {
            e.preventDefault();
            setPeriod({ from, to });
          }}
        >
          <Field label="Du">
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label="Au">
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
          <Button type="submit" icon="refresh">
            Recalculer
          </Button>
          {ind.data && (
            <span className="muted small">
              Période calculée : {dateTime(ind.data.periode.debut)} → {dateTime(ind.data.periode.fin)} · générée le {dateTime(ind.data.genere_le)}
            </span>
          )}
        </form>
      </Card>
      <Async state={ind}>
        {(d) => {
          const by = new Map(d.indicateurs.map((i) => [i.code, i]));
          const others = d.indicateurs.filter((i) => !FINANCE.includes(i.code));
          return (
            <>
              <Card title="Chiffre d'affaires, encaissements, marge, bénéfice" subtitle="Quatre notions différentes, à ne pas confondre.">
                <div className="finance-grid">
                  {FINANCE.map((c) => {
                    const i = by.get(c);
                    if (!i) return null;
                    const na = i.valeur === null;
                    return (
                      <div key={c} className={`fin-card ${na ? "na" : ""}`}>
                        <span className="fin-label">{i.libelle}</span>
                        <strong className="fin-value">{value(i)}</strong>
                        {typeof i.taux === "number" && <span className="fin-extra">taux de marge {num(i.taux as number, 1)} %</span>}
                        <p className="fin-def">
                          {na && <Icon name="info" size={14} />} {i.definition}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </Card>
              <div className="grid-2 wide-left">
                <Card title="Indicateurs opérationnels">
                  <Table caption="Indicateurs opérationnels" head={["Indicateur", "Valeur", "Définition", "Détails"]}>
                    {others.map((i) => (
                      <tr key={i.code}>
                        <td>
                          <strong>{i.libelle}</strong>
                        </td>
                        <td className="num nowrap">{value(i)}</td>
                        <td className="small">{i.definition}</td>
                        <td className="small muted">{extras(i).join(" · ") || "—"}</td>
                      </tr>
                    ))}
                  </Table>
                </Card>
                <div className="stack">
                  <Card title="Fraîcheur des données" subtitle="Date de la donnée la plus récente utilisée par chaque source.">
                    <ul className="fresh">
                      {Object.entries(d.fraicheur).map(([k, v]) => {
                        const stale = !v || Date.now() - new Date(v).getTime() > 24 * 3600 * 1000;
                        return (
                          <li key={k}>
                            <span>{FRESH_LABELS[k] ?? k.replaceAll("_", " ")}</span>
                            {v ? (
                              <span>
                                {dateTime(v)} <span className="muted small">({ago(v)})</span>
                              </span>
                            ) : (
                              <span className="muted">jamais</span>
                            )}
                            {stale ? (
                              <Badge tone="warning" icon="warning">
                                {v ? "Ancienne" : "Absente"}
                              </Badge>
                            ) : (
                              <Badge tone="success" icon="check">
                                Récente
                              </Badge>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </Card>
                  <Card title="Lacunes">
                    {d.lacunes.length === 0 ? (
                      <Notice tone="success">Aucune lacune signalée pour cette période (les définitions ci-contre restent valables).</Notice>
                    ) : (
                      <ul className="bullets">
                        {d.lacunes.map((l) => (
                          <li key={l}>
                            <Icon name="warning" size={16} /> {l}
                          </li>
                        ))}
                      </ul>
                    )}
                  </Card>
                </div>
              </div>
            </>
          );
        }}
      </Async>
      <Card title="Délais fournisseurs" subtitle="Délai moyen observé (commande → première réception) comparé au délai promis.">
        <Async state={sup} empty={(x) => x.length === 0}>
          {(rows) => (
            <div className="grid-2">
              <HBars
                title="Délai moyen observé par fournisseur (jours)"
                rows={rows.map((r) => ({ label: r.fournisseur, value: r.delai_moyen_jours, note: r.promis_jours !== null ? `promis : ${r.promis_jours} j` : undefined }))}
                format={(v) => `${num(v, 1)} j`}
              />
              <Table caption="Délais fournisseurs" head={["Fournisseur", "Commandes reçues", "Délai moyen observé", "Délai promis"]}>
                {rows.map((r) => (
                  <tr key={r.fournisseur}>
                    <td>{r.fournisseur}</td>
                    <td className="num">{r.commandes_recues}</td>
                    <td className="num">{r.delai_moyen_jours === null ? "non disponible (aucune réception)" : `${num(r.delai_moyen_jours, 1)} jours`}</td>
                    <td className="num">{r.promis_jours !== null ? `${r.promis_jours} jours` : "—"}</td>
                  </tr>
                ))}
              </Table>
            </div>
          )}
        </Async>
      </Card>
    </>
  );
}
