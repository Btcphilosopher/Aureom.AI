import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { post, qs } from "../api/client";
import type { Customer, Order } from "../api/types";
import { VariantSelect } from "../components/forms";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, ErrorBox, Field, KV, Modal, Notice, PageHeader, StatusChip, Table } from "../components/ui";
import { useCatalogIndex, variantName } from "../lib/catalogIndex";
import { dateTime, eur, packLabel, parseEuros, parseQty, qty } from "../lib/format";
import { useAction, useApi, useIntentKey, useQueryState, withIntent } from "../lib/hooks";
import { CHANNELS, FULFILMENT, PAYMENT_METHODS, statusLabel } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

const FLOW_RETRAIT = ["RECUE", "VALIDEE", "RESERVEE", "EN_PREPARATION", "PRETE", "REMISE"];
const FLOW_LIVRAISON = ["RECUE", "VALIDEE", "RESERVEE", "EN_PREPARATION", "EXPEDIEE", "LIVREE"];
const ALL = ["RECUE", "VALIDEE", "RESERVEE", "EN_PREPARATION", "PRETE", "EXPEDIEE", "REMISE", "LIVREE", "ANNULEE"];

function PaymentChip({ status }: { status: string }) {
  return <StatusChip status={status} prefix="Paiement : " />;
}

export default function OrdersPage() {
  const { siteId, siteName } = useSite();
  const { can } = useAuth();
  const [status, setStatus] = useQueryState("statut", "");
  const orders = useApi<Order[]>(`/api/commandes${qs({ status, site_id: siteId })}`, ["commande.statut", "paiement"]);
  const all = useApi<Order[]>(`/api/commandes${qs({ site_id: siteId })}`, ["commande.statut"]);
  const [create, setCreate] = useState(false);
  const nav = useNavigate();
  const counts: Record<string, number> = {};
  for (const o of all.data ?? []) counts[o.status] = (counts[o.status] ?? 0) + 1;
  return (
    <>
      <PageHeader
        icon="orders"
        title="Commandes"
        subtitle="Commandes omnicanales (en ligne, magasin, professionnels). Le statut logistique et le statut de paiement sont indépendants : « Payée » ne veut pas dire « Prête »."
        actions={
          can("order.write") && (
            <Button variant="primary" icon="plus" onClick={() => setCreate(true)}>
              Nouvelle commande
            </Button>
          )
        }
      />
      <Card title="Flux des commandes" subtitle="Cliquez sur une étape pour filtrer.">
        <ol className="status-flow">
          <li>
            <button className={status === "" ? "on" : ""} onClick={() => setStatus("")}>
              <span>Toutes</span>
              <strong>{(all.data ?? []).length}</strong>
            </button>
          </li>
          {ALL.map((s) => (
            <li key={s}>
              <button className={status === s ? "on" : ""} onClick={() => setStatus(s)} aria-pressed={status === s}>
                <span>{statusLabel(s)}</span>
                <strong>{counts[s] ?? 0}</strong>
              </button>
            </li>
          ))}
        </ol>
      </Card>
      <Card>
        <Async state={orders} empty={(x) => x.length === 0}>
          {(rows) => (
            <Table caption="Liste des commandes" head={["Commande", "Canal", "Mode", "Site", "Statut logistique", "Paiement", "Total TTC", "Créée", "Promise"]}>
              {rows.map((o) => (
                <tr key={o.id} className="clickable" onClick={() => nav(`/commandes/${o.id}`)}>
                  <td>
                    <Link to={`/commandes/${o.id}`} onClick={(e) => e.stopPropagation()}>
                      <strong>{o.code}</strong>
                    </Link>
                  </td>
                  <td>{CHANNELS[o.channel] ?? o.channel}</td>
                  <td>{FULFILMENT[o.fulfilment] ?? o.fulfilment}</td>
                  <td>{siteName(o.source_site_id)}</td>
                  <td>
                    <StatusChip status={o.status} label={o.statut_libelle} />
                  </td>
                  <td>
                    <PaymentChip status={o.payment_status} />
                  </td>
                  <td className="num">{eur(o.total_ttc_cents)}</td>
                  <td>{dateTime(o.created_at)}</td>
                  <td>{dateTime(o.promised_at)}</td>
                </tr>
              ))}
            </Table>
          )}
        </Async>
      </Card>
      {create && (
        <CreateOrderModal
          onClose={() => setCreate(false)}
          onDone={(o) => {
            setCreate(false);
            nav(`/commandes/${o.id}`);
          }}
        />
      )}
    </>
  );
}

export function OrderDetailPage() {
  const { id } = useParams();
  const { can } = useAuth();
  const { siteName, locationCode } = useSite();
  const idx = useCatalogIndex();
  const order = useApi<Order>(`/api/commandes/${id}`, ["commande.statut", "commande.preparation", "paiement"]);
  const a = useAction();
  const { push } = useToast();
  const [modal, setModal] = useState<null | "annuler" | "remettre" | "expedier" | "payer">(null);
  const [pickup, setPickup] = useState<string | null>(null);

  const act = (path: string, body: unknown = {}, msg?: string) =>
    a.run(async () => {
      const o = await post<Order>(`/api/commandes/${id}/${path}`, body);
      order.setData(o);
      if (o.code_retrait) setPickup(o.code_retrait);
      if (msg) push("success", msg, `${o.code} : ${o.statut_libelle}`);
      return o;
    });

  return (
    <Async state={order}>
      {(o) => {
        const flow = o.fulfilment === "LIVRAISON" ? FLOW_LIVRAISON : FLOW_RETRAIT;
        const cur = flow.indexOf(o.status);
        return (
          <>
            <PageHeader
              icon="orders"
              title={`Commande ${o.code}`}
              subtitle={
                <>
                  <Link to="/commandes">← Toutes les commandes</Link> · {CHANNELS[o.channel] ?? o.channel} · {FULFILMENT[o.fulfilment] ?? o.fulfilment} · {siteName(o.source_site_id)}
                </>
              }
            />
            <div className="dual-status" role="group" aria-label="Statuts de la commande">
              <div className="dual">
                <span className="muted small">Statut logistique</span>
                <StatusChip status={o.status} label={o.statut_libelle} />
              </div>
              <div className="dual">
                <span className="muted small">Statut de paiement</span>
                <PaymentChip status={o.payment_status} />
                <span className="muted small">
                  payé {eur(o.paye ?? 0)} / {eur(o.total_ttc_cents)}
                </span>
              </div>
              <p className="dual-note">
                <Icon name="info" size={16} /> Deux informations distinctes : une commande peut être payée sans être prête, ou prête sans être payée (la remise exige un paiement capturé).
              </p>
            </div>

            {o.status !== "ANNULEE" && (
              <ol className="stepper" aria-label="Progression de la commande">
                {flow.map((s, i) => (
                  <li key={s} className={i < cur ? "done" : i === cur ? "current" : ""} aria-current={i === cur ? "step" : undefined}>
                    <span className="step-dot">{i < cur ? <Icon name="check" size={14} /> : i + 1}</span>
                    <span>{statusLabel(s)}</span>
                  </li>
                ))}
              </ol>
            )}

            <Card title="Actions disponibles">
              <div className="btn-row">
                {o.status === "RECUE" && can("order.write") && (
                  <Button variant="primary" busy={a.busy} onClick={() => act("valider", {}, "Commande validée")}>
                    Valider
                  </Button>
                )}
                {o.status === "VALIDEE" && can("order.write") && (
                  <Button variant="primary" busy={a.busy} onClick={() => act("reserver", {}, "Stock réservé")}>
                    Réserver le stock (tout ou rien)
                  </Button>
                )}
                {o.status === "RESERVEE" && can("order.fulfil") && (
                  <Button variant="primary" busy={a.busy} onClick={() => act("preparer", {}, "Préparation lancée")}>
                    Lancer la préparation
                  </Button>
                )}
                {o.status === "EN_PREPARATION" && (
                  <>
                    <Link className="btn btn-secondary" to="/entrepots">
                      <Icon name="warehouse" size={18} /> Prélever dans l'écran Entrepôts
                    </Link>
                    {o.fulfilment === "RETRAIT" && can("order.fulfil") && (
                      <Button variant="primary" busy={a.busy} onClick={() => act("prete", {}, "Commande prête au retrait")}>
                        Marquer prête au retrait
                      </Button>
                    )}
                    {o.fulfilment === "LIVRAISON" && can("order.fulfil") && (
                      <Button variant="primary" onClick={() => setModal("expedier")}>
                        Expédier
                      </Button>
                    )}
                  </>
                )}
                {o.status === "PRETE" && can("order.fulfil") && (
                  <Button variant="primary" onClick={() => setModal("remettre")}>
                    Remettre au client (code de retrait)
                  </Button>
                )}
                {o.status === "EXPEDIEE" && can("order.fulfil") && (
                  <Button variant="primary" busy={a.busy} onClick={() => act("livree", {}, "Livraison confirmée")}>
                    Confirmer la livraison
                  </Button>
                )}
                {o.payment_status !== "PAYEE" && o.status !== "ANNULEE" && can("order.write") && (
                  <Button variant="copper" icon="card" onClick={() => setModal("payer")}>
                    Enregistrer un paiement
                  </Button>
                )}
                {["RECUE", "VALIDEE", "RESERVEE", "EN_PREPARATION", "PRETE"].includes(o.status) && can("order.write") && (
                  <Button variant="ghost" icon="cross" onClick={() => setModal("annuler")}>
                    Annuler la commande
                  </Button>
                )}
                {["REMISE", "LIVREE", "ANNULEE"].includes(o.status) && <span className="muted">Commande terminée : aucune action logistique.</span>}
              </div>
              <ErrorBox error={a.error} />
            </Card>

            <div className="grid-2">
              <Card title="Lignes">
                <Table caption="Lignes de la commande" head={["Article", "Quantité", "Prix unitaire", "Total TTC", "Prélevé", "Remis"]}>
                  {(o.lines ?? []).map((l) => (
                    <tr key={l.id}>
                      <td>
                        {l.label}
                        <div className="muted small">{l.sku}</div>
                      </td>
                      <td>
                        {qty(l.quantity, l.packaging_level === "PIECE" ? l.unit : null)}
                        {l.packaging_level !== "PIECE" && ` ${packLabel(l.packaging_level, Number(l.quantity))}`}
                      </td>
                      <td className="num">{eur(l.unit_price_cents)}</td>
                      <td className="num">{eur(l.total_ttc_cents)}</td>
                      <td>{qty(l.picked_base_qty, l.unit)}</td>
                      <td>{qty(l.delivered_base_qty, l.unit)}</td>
                    </tr>
                  ))}
                </Table>
                <KV items={[["Frais de port", eur(o.shipping_cents)], ["Total TTC", <strong key="t">{eur(o.total_ttc_cents)}</strong>], ["Promise le", dateTime(o.promised_at)], ["Client", o.customer_id ? <Link key="c" to={`/clients/${o.customer_id}`}>Client n° {o.customer_id}</Link> : "Anonyme"]]} />
              </Card>
              <Card title="Historique">
                <ol className="timeline">
                  {(o.historique ?? []).map((h) => (
                    <li key={h.id}>
                      <time>{dateTime(h.at, true)}</time>
                      <span>
                        {h.from_status ? `${statusLabel(h.from_status)} → ` : ""}
                        <strong>{statusLabel(h.to_status)}</strong>
                      </span>
                      {h.note && <span className="muted small">{h.note}</span>}
                    </li>
                  ))}
                </ol>
              </Card>
            </div>
            <div className="grid-2">
              <Card title="Tâches de prélèvement (FEFO)">
                {(o.taches ?? []).length === 0 ? (
                  <p className="muted">Créées au lancement de la préparation.</p>
                ) : (
                  <Table caption="Tâches de prélèvement" head={["Article", "Emplacement", "Quantité", "Statut", "Code scanné"]}>
                    {o.taches!.map((t) => {
                      const line = o.lines?.find((l) => l.id === t.order_line_id);
                      return (
                        <tr key={t.id}>
                          <td>{line?.label ?? variantName(idx, null)}</td>
                          <td>
                            <code>{locationCode(t.location_id)}</code>
                          </td>
                          <td>{qty(t.quantity, line?.unit)}</td>
                          <td>
                            <StatusChip status={t.status} />
                          </td>
                          <td>
                            <code>{t.scanned_code ?? "—"}</code>
                          </td>
                        </tr>
                      );
                    })}
                  </Table>
                )}
              </Card>
              <Card title="Paiements" subtitle="Indépendants du statut logistique.">
                {(o.paiements ?? []).length === 0 ? (
                  <p className="muted">Aucun paiement.</p>
                ) : (
                  <Table caption="Paiements de la commande" head={["Date", "Moyen", "Montant", "Statut"]}>
                    {o.paiements!.map((p) => (
                      <tr key={p.id}>
                        <td>{dateTime(p.created_at)}</td>
                        <td>
                          {PAYMENT_METHODS[p.method] ?? p.method}
                          {p.card_last4 && ` ****${p.card_last4}`}
                        </td>
                        <td className="num">{eur(p.amount_cents)}</td>
                        <td>
                          <StatusChip status={p.status} />
                        </td>
                      </tr>
                    ))}
                  </Table>
                )}
                {(o.expeditions ?? []).length > 0 && (
                  <p>
                    <Badge tone="accent" icon="truck">
                      Expédiée par {o.expeditions![0].carrier}
                    </Badge>
                  </p>
                )}
              </Card>
            </div>

            {pickup && (
              <Modal title="Code de retrait" onClose={() => setPickup(null)}>
                <Notice tone="warning">Ce code n'est affiché qu'une seule fois. Il est communiqué au client par message (envoi simulé).</Notice>
                <p className="pickup-code" aria-label={`Code de retrait ${pickup.split("").join(" ")}`}>
                  {pickup}
                </p>
              </Modal>
            )}
            {modal === "annuler" && <ReasonModal title="Annuler la commande" label="Motif d'annulation" onClose={() => setModal(null)} onSubmit={(reason) => act("annuler", { reason }, "Commande annulée").then((r) => r && setModal(null))} busy={a.busy} error={a.error} />}
            {modal === "remettre" && <ReasonModal title="Remise au client" label="Code de retrait présenté par le client" onClose={() => setModal(null)} onSubmit={(code) => act("remettre", { pickup_code: code }, "Commande remise").then((r) => r && setModal(null))} busy={a.busy} error={a.error} numeric />}
            {modal === "expedier" && <ShipModal onClose={() => setModal(null)} onSubmit={(b) => act("expedier", b, "Commande expédiée").then((r) => r && setModal(null))} busy={a.busy} error={a.error} />}
            {modal === "payer" && (
              <OrderPayModal
                order={o}
                onClose={() => setModal(null)}
                onDone={(no) => {
                  order.setData(no);
                  setModal(null);
                }}
              />
            )}
          </>
        );
      }}
    </Async>
  );
}

function ReasonModal({ title, label, onClose, onSubmit, busy, error, numeric }: { title: string; label: string; onClose: () => void; onSubmit: (v: string) => void; busy: boolean; error: unknown; numeric?: boolean }) {
  const [v, setV] = useState("");
  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Fermer
          </Button>
          <Button variant="primary" busy={busy} disabled={v.trim().length < (numeric ? 4 : 3)} onClick={() => onSubmit(v.trim())}>
            Confirmer
          </Button>
        </>
      }
    >
      <Field label={label} required>
        <input value={v} onChange={(e) => setV(e.target.value)} inputMode={numeric ? "numeric" : undefined} autoComplete="off" className={numeric ? "code-input" : ""} />
      </Field>
      <ErrorBox error={error} />
    </Modal>
  );
}

function ShipModal({ onClose, onSubmit, busy, error }: { onClose: () => void; onSubmit: (b: { carrier: string; parcels: number }) => void; busy: boolean; error: unknown }) {
  const [carrier, setCarrier] = useState("Transporteur simulé");
  const [parcels, setParcels] = useState("1");
  return (
    <Modal
      title="Expédier la commande"
      onClose={onClose}
      footer={
        <Button variant="primary" busy={busy} onClick={() => onSubmit({ carrier, parcels: Number(parcels) || 1 })}>
          Expédier
        </Button>
      }
    >
      <div className="form-grid">
        <Field label="Transporteur">
          <input value={carrier} onChange={(e) => setCarrier(e.target.value)} />
        </Field>
        <Field label="Nombre de colis">
          <input inputMode="numeric" value={parcels} onChange={(e) => setParcels(e.target.value)} />
        </Field>
      </div>
      <ErrorBox error={error} />
    </Modal>
  );
}

function OrderPayModal({ order, onClose, onDone }: { order: Order; onClose: () => void; onDone: (o: Order) => void }) {
  const due = order.total_ttc_cents - (order.paye ?? 0);
  const [amount, setAmount] = useState((due / 100).toFixed(2).replace(".", ","));
  const [method, setMethod] = useState("CARTE_SIMULEE");
  const [token, setToken] = useState("tok_sim_accepte");
  const intent = useIntentKey("cmd-paiement");
  const a = useAction();
  const { push } = useToast();
  const cents = parseEuros(amount);
  const submit = () =>
    a.run(async () => {
      if (cents === null) throw new Error("Montant invalide");
      const r = await withIntent(intent, (key) => post<{ paiement: { status: string }; commande: Order }>(`/api/commandes/${order.id}/paiements`, { method, amount_cents: cents, card_token: method === "CARTE_SIMULEE" ? token : null }, key));
      push(r.paiement.status === "CAPTURE" ? "success" : "warning", `Paiement ${statusLabel(r.paiement.status).toLowerCase()}`, `Statut logistique inchangé : ${r.commande.statut_libelle}`);
      onDone(r.commande);
    });
  return (
    <Modal
      title={`Paiement — ${order.code}`}
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={cents === null} onClick={submit}>
          Enregistrer le paiement
        </Button>
      }
    >
      <p>Reste à payer : {eur(due)}</p>
      <div className="form-grid">
        <Field label="Moyen">
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option value="CARTE_SIMULEE">Carte (terminal simulé)</option>
            <option value="VIREMENT_SIMULE">Virement (simulé)</option>
          </select>
        </Field>
        <Field label="Montant (€)">
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        {method === "CARTE_SIMULEE" && (
          <Field label="Scénario du terminal" hint="Aucun numéro de carte n'est saisi.">
            <select value={token} onChange={(e) => setToken(e.target.value)}>
              <option value="tok_sim_accepte">Carte acceptée</option>
              <option value="tok_sim_refuse">Carte refusée</option>
              <option value="tok_sim_attente">Réponse différée</option>
            </select>
          </Field>
        )}
      </div>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function CreateOrderModal({ onClose, onDone }: { onClose: () => void; onDone: (o: Order) => void }) {
  const { sites, siteId } = useSite();
  const { can } = useAuth();
  const customers = useApi<Customer[]>(can("customer.read") ? "/api/clients" : null);
  const [channel, setChannel] = useState("WEB");
  const [fulfilment, setFulfilment] = useState("RETRAIT");
  const [source, setSource] = useState<number | "">(siteId ?? "");
  const [customer, setCustomer] = useState<number | "">("");
  const [shipping, setShipping] = useState("0");
  const [lines, setLines] = useState<{ variant: number | ""; q: string; level: string }[]>([{ variant: "", q: "1", level: "PIECE" }]);
  const idx = useCatalogIndex();
  const intent = useIntentKey("commande");
  const a = useAction();
  const valid = source !== "" && lines.every((l) => l.variant !== "" && parseQty(l.q));
  const submit = () =>
    a.run(async () => {
      const o = await withIntent(intent, (key) =>
        post<Order>(
          "/api/commandes",
          {
            channel,
            fulfilment,
            source_site_id: source,
            pickup_site_id: fulfilment === "RETRAIT" ? source : null,
            customer_id: customer === "" ? null : customer,
            shipping_cents: parseEuros(shipping) ?? 0,
            lines: lines.map((l) => ({ variant_id: l.variant, quantity: parseQty(l.q), packaging_level: l.level })),
          },
          key,
        ),
      );
      onDone(o);
    });
  const eligible = sites.filter((s) => (fulfilment === "RETRAIT" ? s.allows_click_collect : s.ships_online));
  return (
    <Modal
      title="Nouvelle commande"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={!valid} onClick={submit}>
            Créer la commande
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label="Canal">
          <select value={channel} onChange={(e) => setChannel(e.target.value)}>
            {Object.entries(CHANNELS).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Mode">
          <select value={fulfilment} onChange={(e) => setFulfilment(e.target.value)}>
            {Object.entries(FULFILMENT).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label={fulfilment === "RETRAIT" ? "Magasin de retrait (stock source)" : "Site expéditeur"} required>
          <select value={source} onChange={(e) => setSource(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {eligible.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Client" hint={channel === "PRO" ? "Obligatoire pour une commande professionnelle" : "Facultatif"}>
          <select value={customer} onChange={(e) => setCustomer(e.target.value ? Number(e.target.value) : "")}>
            <option value="">Anonyme</option>
            {(customers.data ?? []).map((c) => (
              <option key={c.id} value={c.id}>
                {c.code} {c.societe ?? [c.prenom, c.nom].filter(Boolean).join(" ")}
              </option>
            ))}
          </select>
        </Field>
        {fulfilment === "LIVRAISON" && (
          <Field label="Frais de port (€)">
            <input inputMode="decimal" value={shipping} onChange={(e) => setShipping(e.target.value)} />
          </Field>
        )}
      </div>
      {lines.map((l, i) => {
        const v = l.variant !== "" ? idx.get(l.variant) : undefined;
        return (
          <div key={i} className="form-grid line-row">
            <VariantSelect required value={l.variant} onChange={(nv) => setLines(lines.map((x, j) => (j === i ? { ...x, variant: nv, level: "PIECE" } : x)))} />
            <Field label="Conditionnement">
              <select value={l.level} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, level: e.target.value } : x)))}>
                {(v?.variant.conditionnements ?? [{ level: "PIECE", label: "Pièce" }]).map((c) => (
                  <option key={c.level} value={c.level}>
                    {c.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Quantité" required>
              <input inputMode="decimal" value={l.q} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, q: e.target.value } : x)))} />
            </Field>
            {lines.length > 1 && (
              <button className="icon-btn" aria-label="Retirer la ligne" onClick={() => setLines(lines.filter((_, j) => j !== i))}>
                <Icon name="trash" />
              </button>
            )}
          </div>
        );
      })}
      <Button size="sm" icon="plus" onClick={() => setLines([...lines, { variant: "", q: "1", level: "PIECE" }])}>
        Ajouter une ligne
      </Button>
      <p className="muted small">Une clé d'idempotence protège contre la création en double (double clic, nouvelle tentative après coupure).</p>
      <ErrorBox error={a.error} />
    </Modal>
  );
}
