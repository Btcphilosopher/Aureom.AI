import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router";
import { api, post, qs } from "../api/client";
import type { Order, PickTask, PurchaseOrder, Transfer } from "../api/types";
import { ReceiptModal, TransferReceiveModal } from "../components/forms";
import { Icon } from "../components/Icon";
import { LiveIndicator, RegistryBadge, SiteSelector, UserMenu } from "../components/Shell";
import { Button, ErrorBox, Loading, Modal, Notice, StatusChip } from "../components/ui";
import { useCatalogIndex, variantName } from "../lib/catalogIndex";
import { dateOnly, dateTime, num, parseQty, qty, unitLabel } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { FULFILMENT } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useLiveEvents } from "../state/live";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

interface TaskView {
  task: PickTask;
  order: Order;
  label: string;
  sku: string;
  unit: string;
  codes: string[];
}

export default function WarehousePage() {
  const { site, siteId, mySites, setSiteId } = useSite();
  const { can } = useAuth();
  const [tab, setTab] = useQueryState("onglet", "prelevements");
  useEffect(() => {
    if (siteId === null && mySites.length > 0) setSiteId(mySites.find((s) => s.kind === "ENTREPOT")?.id ?? mySites[0].id);
  }, [siteId, mySites, setSiteId]);
  const tabs = [
    { id: "prelevements", label: "Prélèvements", icon: "box", show: can("order.fulfil") },
    { id: "transferts", label: "Transferts", icon: "truck", show: can("stock.transfer") },
    { id: "receptions", label: "Réceptions", icon: "purchase", show: can("receipt.write") },
  ].filter((t) => t.show);
  const current = tabs.find((t) => t.id === tab) ? tab : (tabs[0]?.id ?? "");
  return (
    <div className="wh">
      <header className="pos-top wh-top">
        <Link to="/" className="pos-back" aria-label="Revenir au bureau">
          <Icon name="back" /> Bureau
        </Link>
        <div className="pos-title">
          <Icon name="warehouse" />
          <div>
            <strong>Entrepôt — poste tablette</strong>
            <span>{site ? site.name : "Choisissez un site"}</span>
          </div>
        </div>
        <div className="topbar-spacer" />
        <SiteSelector compact />
        <RegistryBadge />
        <LiveIndicator />
        <UserMenu />
      </header>
      <nav className="wh-tabs" aria-label="Tâches d'entrepôt">
        {tabs.map((t) => (
          <button key={t.id} className={current === t.id ? "on" : ""} aria-current={current === t.id ? "page" : undefined} onClick={() => setTab(t.id)}>
            <Icon name={t.icon} size={26} />
            {t.label}
          </button>
        ))}
      </nav>
      <main className="wh-main" id="contenu">
        {!siteId ? (
          <Notice tone="warning">Choisissez un site dans le sélecteur ci-dessus.</Notice>
        ) : current === "prelevements" ? (
          <Picking siteId={siteId} />
        ) : current === "transferts" ? (
          <Transfers siteId={siteId} />
        ) : current === "receptions" ? (
          <Receptions siteId={siteId} />
        ) : (
          <Notice tone="warning">Aucune tâche d'entrepôt accessible avec votre rôle.</Notice>
        )}
      </main>
    </div>
  );
}

/* ---- Prélèvements ----------------------------------------------------------------------------------- */

function Picking({ siteId }: { siteId: number }) {
  const idx = useCatalogIndex();
  const { locationCode } = useSite();
  const { push } = useToast();
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [reserved, setReserved] = useState<Order[]>([]);
  const [err, setErr] = useState<unknown>(null);
  const [scan, setScan] = useState("");
  const [selected, setSelected] = useState<number | null>(null);
  const [pickQty, setPickQty] = useState("");
  const [pickup, setPickup] = useState<{ code: string; order: string } | null>(null);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const scanRef = useRef<HTMLInputElement>(null);
  const a = useAction();

  const load = useCallback(async () => {
    try {
      const list = await api<Order[]>(`/api/commandes${qs({ status: "EN_PREPARATION", site_id: siteId })}`);
      const full = await Promise.all(list.map((o) => api<Order>(`/api/commandes/${o.id}`)));
      setOrders(full);
      setReserved(await api<Order[]>(`/api/commandes${qs({ status: "RESERVEE", site_id: siteId })}`));
      setErr(null);
    } catch (e) {
      setErr(e);
    }
  }, [siteId]);
  useEffect(() => {
    void load();
  }, [load]);
  useLiveEvents(["commande.statut", "commande.preparation"], () => void load());

  const tasks: TaskView[] = useMemo(
    () =>
      (orders ?? []).flatMap((o) =>
        (o.taches ?? []).map((t) => {
          const line = o.lines?.find((l) => l.id === t.order_line_id);
          const v = line ? idx.get(line.variant_id) : undefined;
          return { task: t, order: o, label: line?.label ?? variantName(idx, null), sku: line?.sku ?? "", unit: line?.unit ?? "PCE", codes: v?.codes ?? [] };
        }),
      ),
    [orders, idx],
  );
  const pending = tasks.filter((t) => t.task.status !== "PRELEVE");
  const sel = tasks.find((t) => t.task.id === selected) ?? null;

  useEffect(() => {
    if (sel) setPickQty(String(Number(sel.task.quantity) - Number(sel.task.picked_qty ?? 0)));
  }, [sel?.task.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const focusScan = () => window.setTimeout(() => scanRef.current?.focus(), 0);
  useEffect(() => {
    focusScan();
    a.setError(null);
  }, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

  const confirm = (t: TaskView, code: string) =>
    a.run(async () => {
      const q = parseQty(pickQty);
      if (!q) throw new Error("Quantité invalide");
      try {
        await post(`/api/commandes/taches/${t.task.id}/prelever`, { picked_qty: q, scanned_code: code });
        setFeedback({ ok: true, text: `Prélevé : ${t.label} — ${qty(q, t.unit)} (${t.order.code})` });
        push("success", "Prélèvement confirmé", `${t.label} — ${qty(q, t.unit)}`);
        setSelected(null);
        setScan("");
        await load();
      } catch (e) {
        setFeedback({ ok: false, text: e instanceof Error ? e.message : String(e) });
        throw e;
      } finally {
        focusScan();
      }
    });

  const onScan = (e: React.FormEvent) => {
    e.preventDefault();
    const code = scan.trim();
    if (!code) return;
    if (sel) {
      void confirm(sel, code);
      return;
    }
    const match = pending.find((t) => t.codes.includes(code) || t.sku === code);
    if (match) {
      setSelected(match.task.id);
      setFeedback({ ok: true, text: `Article reconnu : ${match.label}. Vérifiez la quantité puis confirmez.` });
    } else setFeedback({ ok: false, text: `Aucune tâche en attente pour le code ${code}.` });
  };

  const finish = (o: Order) =>
    a.run(async () => {
      if (o.fulfilment === "RETRAIT") {
        const r = await post<Order>(`/api/commandes/${o.id}/prete`);
        if (r.code_retrait) setPickup({ code: r.code_retrait, order: r.code });
      } else {
        await post(`/api/commandes/${o.id}/expedier`, { carrier: "Transporteur simulé", parcels: 1 });
        push("success", `${o.code} expédiée`);
      }
      await load();
    });

  const startPrep = (o: Order) =>
    a.run(async () => {
      await post(`/api/commandes/${o.id}/preparer`);
      push("success", `Préparation de ${o.code} lancée`, "Tâches de prélèvement créées (FEFO).");
      await load();
    });

  if (err) return <ErrorBox error={err} />;
  if (!orders) return <Loading />;

  return (
    <div className="wh-grid">
      <section className="wh-col">
        <form className="wh-scan" onSubmit={onScan} role="search">
          <label htmlFor="wh-scan">{sel ? `Scanner « ${sel.label} » pour confirmer` : "Scanner un article à prélever"}</label>
          <div className="wh-scan-row">
            <Icon name="scan" size={30} />
            <input id="wh-scan" ref={scanRef} value={scan} onChange={(e) => setScan(e.target.value)} autoComplete="off" spellCheck={false} placeholder="Code-barres…" />
            <Button type="submit" size="xl" variant="primary">
              {sel ? "Confirmer" : "Valider"}
            </Button>
          </div>
          <p className={`wh-feedback ${feedback ? (feedback.ok ? "ok" : "ko") : ""}`} role="status" aria-live="polite">
            {feedback ? (
              <>
                <Icon name={feedback.ok ? "check" : "critical"} /> {feedback.text}
              </>
            ) : (
              "Le prélèvement est confirmé uniquement par le scan de l'article attendu."
            )}
          </p>
        </form>

        {sel && (
          <div className="wh-current" aria-live="polite">
            <h2>Tâche en cours</h2>
            <p className="wh-big">{sel.label}</p>
            <p>
              Emplacement <strong className="wh-loc">{locationCode(sel.task.location_id)}</strong> · commande {sel.order.code}
            </p>
            <div className="wh-qty" role="group" aria-label="Quantité prélevée">
              <Button size="xl" icon="minus" ariaLabel="Diminuer" onClick={() => setPickQty(String(Math.max(0, Number(pickQty || 0) - 1)))} />
              <input className="wh-input" inputMode="decimal" value={pickQty} onChange={(e) => setPickQty(e.target.value)} aria-label={`Quantité (${sel.unit})`} />
              <Button size="xl" icon="plus" ariaLabel="Augmenter" onClick={() => setPickQty(String(Number(pickQty || 0) + 1))} />
              <span>{unitLabel(sel.unit, Number(pickQty || 0))} sur {qty(sel.task.quantity, sel.unit)}</span>
            </div>
            <ErrorBox error={a.error} />
            <Button size="xl" variant="ghost" onClick={() => setSelected(null)}>
              Abandonner
            </Button>
          </div>
        )}

        <h2 className="wh-h2">Tâches à prélever ({pending.length})</h2>
        {pending.length === 0 && <p className="muted">Aucune tâche en attente sur ce site.</p>}
        <ul className="wh-tasks">
          {pending.map((t) => (
            <li key={t.task.id}>
              <button className={`wh-task ${selected === t.task.id ? "on" : ""}`} onClick={() => setSelected(t.task.id)} aria-pressed={selected === t.task.id}>
                <span className="wh-loc">{locationCode(t.task.location_id)}</span>
                <span className="wh-task-main">
                  <strong>{t.label}</strong>
                  <span className="muted">
                    {t.sku} · {t.order.code} · {t.codes[0] ? `EAN ${t.codes[0]}` : ""}
                  </span>
                </span>
                <span className="wh-task-qty">{qty(t.task.quantity, t.unit)}</span>
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section className="wh-col">
        <h2 className="wh-h2">Commandes en préparation</h2>
        {orders.length === 0 && <p className="muted">Aucune commande en préparation.</p>}
        {orders.map((o) => {
          const total = o.taches?.length ?? 0;
          const done = (o.taches ?? []).filter((t) => t.status === "PRELEVE").length;
          return (
            <div key={o.id} className="wh-order">
              <div>
                <strong>{o.code}</strong> <span className="muted">· {FULFILMENT[o.fulfilment]}</span>
                <div className="wh-progress" role="progressbar" aria-valuemin={0} aria-valuemax={total} aria-valuenow={done} aria-label={`${done} tâche(s) sur ${total}`}>
                  <span style={{ width: `${total ? (done / total) * 100 : 0}%` }} />
                </div>
                <span className="small">
                  {done} / {total} prélèvement(s) · promise {dateTime(o.promised_at)}
                </span>
              </div>
              <Button size="xl" variant="success" disabled={done < total} busy={a.busy} onClick={() => finish(o)} icon={o.fulfilment === "RETRAIT" ? "check" : "truck"}>
                {o.fulfilment === "RETRAIT" ? "Prête au retrait" : "Expédier"}
              </Button>
            </div>
          );
        })}
        {reserved.length > 0 && (
          <>
            <h2 className="wh-h2">Réservées, à lancer</h2>
            {reserved.map((o) => (
              <div key={o.id} className="wh-order">
                <div>
                  <strong>{o.code}</strong> <span className="muted">· {FULFILMENT[o.fulfilment]}</span>
                  <div className="small">Créée {dateTime(o.created_at)}</div>
                </div>
                <Button size="xl" variant="primary" busy={a.busy} onClick={() => startPrep(o)} icon="play">
                  Lancer la préparation
                </Button>
              </div>
            ))}
          </>
        )}
      </section>

      {pickup && (
        <Modal title={`Commande ${pickup.order} prête`} onClose={() => setPickup(null)}>
          <Notice tone="warning">Code de retrait affiché une seule fois — communiqué au client par message (simulé).</Notice>
          <p className="pickup-code">{pickup.code}</p>
        </Modal>
      )}
    </div>
  );
}

/* ---- Transferts ------------------------------------------------------------------------------------- */

function Transfers({ siteId }: { siteId: number }) {
  const { siteName } = useSite();
  const idx = useCatalogIndex();
  const tr = useApi<Transfer[]>("/api/stocks/transferts", ["stock.mouvement"]);
  const [receive, setReceive] = useState<Transfer | null>(null);
  const a = useAction();
  const { push } = useToast();
  const incoming = (tr.data ?? []).filter((t) => t.to_site_id === siteId && t.status === "EXPEDIE");
  const outgoing = (tr.data ?? []).filter((t) => t.from_site_id === siteId && t.status === "BROUILLON");
  return (
    <div className="wh-grid">
      <section className="wh-col">
        <h2 className="wh-h2">Transferts entrants à recevoir ({incoming.length})</h2>
        {incoming.length === 0 && <p className="muted">Aucun transfert en transit vers ce site.</p>}
        {incoming.map((t) => (
          <div key={t.id} className="wh-order">
            <div>
              <strong>{t.code}</strong> <span className="muted">depuis {siteName(t.from_site_id)}</span>
              <ul className="small">
                {t.lines.map((l) => (
                  <li key={l.id}>
                    {variantName(idx, l.variant_id)} : {qty(l.quantity, idx.get(l.variant_id)?.unit)}
                  </li>
                ))}
              </ul>
              <span className="small muted">Expédié {dateTime(t.shipped_at)}</span>
            </div>
            <Button size="xl" variant="primary" icon="check" onClick={() => setReceive(t)}>
              Recevoir
            </Button>
          </div>
        ))}
      </section>
      <section className="wh-col">
        <h2 className="wh-h2">Transferts sortants à expédier ({outgoing.length})</h2>
        {outgoing.length === 0 && <p className="muted">Aucun transfert en brouillon depuis ce site.</p>}
        <ErrorBox error={a.error} />
        {outgoing.map((t) => (
          <div key={t.id} className="wh-order">
            <div>
              <strong>{t.code}</strong> <span className="muted">vers {siteName(t.to_site_id)}</span>
              <ul className="small">
                {t.lines.map((l) => (
                  <li key={l.id}>
                    {variantName(idx, l.variant_id)} : {qty(l.quantity, idx.get(l.variant_id)?.unit)}
                  </li>
                ))}
              </ul>
            </div>
            <Button
              size="xl"
              variant="primary"
              icon="truck"
              busy={a.busy}
              onClick={() =>
                a.run(async () => {
                  await post(`/api/stocks/transferts/${t.id}/expedier`);
                  push("success", `${t.code} expédié`);
                  tr.reload();
                })
              }
            >
              Expédier
            </Button>
          </div>
        ))}
      </section>
      {receive && (
        <TransferReceiveModal
          big
          transfer={receive}
          onClose={() => setReceive(null)}
          onDone={() => {
            setReceive(null);
            tr.reload();
          }}
        />
      )}
    </div>
  );
}

/* ---- Réceptions fournisseurs ------------------------------------------------------------------------ */

function Receptions({ siteId }: { siteId: number }) {
  const { can } = useAuth();
  const { orgName } = useSite();
  const idx = useCatalogIndex();
  const pos = useApi<PurchaseOrder[]>(can("purchase.read") ? "/api/achats/commandes" : null, ["achat.reception", "achat.commande"]);
  const [open, setOpen] = useState<PurchaseOrder | null>(null);
  if (!can("purchase.read"))
    return (
      <Notice tone="warning" title="Liste des réceptions indisponible pour ce rôle">
        Votre rôle peut enregistrer une réception (permission « Réceptionner ») mais pas consulter les commandes fournisseurs (« Consulter les achats ») : l'API ne permet donc pas de lister les livraisons attendues. Un responsable de magasin, un acheteur ou la direction peut les afficher et les réceptionner.
      </Notice>
    );
  if (pos.error) return <ErrorBox error={pos.error} />;
  if (!pos.data) return <Loading />;
  const todo = pos.data.filter((o) => o.ship_to_site_id === siteId && ["ENVOYEE", "PARTIELLEMENT_RECUE"].includes(o.status));
  return (
    <section className="wh-col wide">
      <h2 className="wh-h2">Livraisons fournisseurs attendues ({todo.length})</h2>
      {todo.length === 0 && <p className="muted">Aucune commande fournisseur à réceptionner sur ce site.</p>}
      {todo.map((o) => (
        <div key={o.id} className="wh-order">
          <div>
            <strong>{o.code}</strong> <StatusChip status={o.status} /> <span className="muted">· {orgName(o.supplier_id)} · attendue le {dateOnly(o.expected_on)}</span>
            <ul className="small">
              {o.lines.map((l) => (
                <li key={l.id}>
                  {variantName(idx, l.variant_id)} : reçu {num(l.received_base_qty)} / {qty(l.base_qty, idx.get(l.variant_id)?.unit)}
                </li>
              ))}
            </ul>
          </div>
          <Button size="xl" variant="primary" icon="truck" onClick={() => setOpen(o)}>
            Réceptionner
          </Button>
        </div>
      ))}
      {open && (
        <ReceiptModal
          big
          order={open}
          onClose={() => setOpen(null)}
          onDone={() => {
            setOpen(null);
            pos.reload();
          }}
        />
      )}
    </section>
  );
}
