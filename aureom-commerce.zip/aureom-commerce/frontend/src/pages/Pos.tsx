import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router";
import { api, ApiError, post, qs } from "../api/client";
import type { PosSession, Register, Sale, SaleLine, Variant } from "../api/types";
import { Icon } from "../components/Icon";
import { LiveIndicator, RegistryBadge, SiteSelector, UserMenu } from "../components/Shell";
import { Button, ErrorBox, Field, KV, Loading, Modal, Notice, StatusChip } from "../components/ui";
import { bp, centsToInput, dateTime, eur, eurSigned, num, parseEuros, parseQty, qty } from "../lib/format";
import { useAction, useIntentKey, withIntent } from "../lib/hooks";
import { PAYMENT_METHODS } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useLiveEvents } from "../state/live";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

const REG_KEY = "aureom.caisse.poste";
const DISCLAIMER = "Prototype non certifié — ne pas utiliser pour encaisser réellement";

type Mode = "articles" | "paiement";
type PayMethod = "ESPECES" | "CARTE_SIMULEE";
const CARD_SCENARIOS = [
  { token: "tok_sim_accepte", label: "Carte acceptée", hint: "Autorisation puis capture immédiates" },
  { token: "tok_sim_refuse", label: "Carte refusée", hint: "Refus de l'émetteur (simulé)" },
  { token: "tok_sim_attente", label: "Réponse différée", hint: "Le prestataire confirme plus tard (webhook signé)" },
] as const;

function readReg(): number | null {
  try {
    const v = localStorage.getItem(REG_KEY);
    return v ? Number(v) : null;
  } catch {
    return null;
  }
}

/* ===================================================================================================== */

export default function PosPage() {
  const { siteId, siteName } = useSite();
  const { user } = useAuth();
  const [registers, setRegisters] = useState<Register[] | null>(null);
  const [regError, setRegError] = useState<unknown>(null);
  const [registerId, setRegisterIdState] = useState<number | null>(readReg);
  const [session, setSession] = useState<PosSession | null>(null);
  const [closed, setClosed] = useState<PosSession | null>(null);

  const loadRegisters = useCallback(() => {
    api<Register[]>("/api/caisse/postes")
      .then((r) => {
        setRegisters(r);
        setRegError(null);
      })
      .catch(setRegError);
  }, []);
  useEffect(loadRegisters, [loadRegisters]);

  const setRegisterId = (id: number | null) => {
    setRegisterIdState(id);
    try {
      if (id === null) localStorage.removeItem(REG_KEY);
      else localStorage.setItem(REG_KEY, String(id));
    } catch {
      /* préférence non conservée */
    }
  };

  const visible = useMemo(() => {
    const mine = (registers ?? []).filter((r) => !user || user.sites.length === 0 || user.sites.includes(r.site_id));
    return siteId ? mine.filter((r) => r.site_id === siteId) : mine;
  }, [registers, user, siteId]);
  const register = (registers ?? []).find((r) => r.id === registerId) ?? null;

  // Session ouverte du poste choisi
  useEffect(() => {
    if (!register) {
      setSession(null);
      return;
    }
    if (register.session_ouverte) {
      api<PosSession>(`/api/caisse/sessions/${register.session_ouverte.id}`).then(setSession).catch(() => setSession(register.session_ouverte));
    } else setSession(null);
  }, [register]);

  return (
    <div className="pos">
      <header className="pos-top">
        <Link to="/" className="pos-back" aria-label="Revenir au bureau">
          <Icon name="back" /> Bureau
        </Link>
        <div className="pos-title">
          <Icon name="pos" />
          <div>
            <strong>Caisse{register ? ` — ${register.label}` : ""}</strong>
            <span>{register ? siteName(register.site_id) : "Choisissez un poste"}</span>
          </div>
        </div>
        <div className="topbar-spacer" />
        <SiteSelector compact />
        <RegistryBadge />
        <LiveIndicator />
        <UserMenu />
      </header>
      <div className="pos-banner" role="note">
        <Icon name="warning" size={18} />
        <strong>{DISCLAIMER}</strong>
        <span>Ticket et clôture de démonstration, sans valeur fiscale. Aucune donnée de carte n'est saisie : le terminal est simulé.</span>
      </div>

      {regError ? (
        <div className="pos-center">
          <ErrorBox error={regError} title="Postes de caisse indisponibles" />
        </div>
      ) : registers === null ? (
        <div className="pos-center">
          <Loading />
        </div>
      ) : !register ? (
        <RegisterPicker registers={visible} onPick={setRegisterId} />
      ) : !session || session.status !== "OUVERTE" ? (
        <OpenSession
          register={register}
          onOpened={(s) => {
            setClosed(null);
            setSession(s);
            loadRegisters();
          }}
          onChangeRegister={() => setRegisterId(null)}
          lastClosed={closed && closed.register_id === register.id ? closed : null}
        />
      ) : (
        <SaleScreen
          register={register}
          session={session}
          onClosed={(s) => {
            setClosed(s);
            setSession(null);
            loadRegisters();
          }}
          onChangeRegister={() => setRegisterId(null)}
        />
      )}
    </div>
  );
}

/* ---- Choix du poste --------------------------------------------------------------------------------- */

function RegisterPicker({ registers, onPick }: { registers: Register[]; onPick: (id: number) => void }) {
  const { siteName } = useSite();
  return (
    <div className="pos-center">
      <h1 className="pos-h1">Choisir un poste de caisse</h1>
      {registers.length === 0 && <Notice tone="warning">Aucun poste de caisse sur le site sélectionné.</Notice>}
      <div className="pos-registers">
        {registers.map((r) => (
          <button key={r.id} className="pos-register" onClick={() => onPick(r.id)}>
            <Icon name="pos" size={32} />
            <strong>{r.label}</strong>
            <span>{siteName(r.site_id)}</span>
            {r.session_ouverte ? <StatusChip status="OUVERTE" label={`Session ouverte depuis ${dateTime(r.session_ouverte.opened_at)}`} /> : <StatusChip status="CLOTUREE" label="Aucune session ouverte" />}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---- Pavé numérique --------------------------------------------------------------------------------- */

function Keypad({ value, onChange, label, maxDecimals = 2 }: { value: string; onChange: (v: string) => void; label: string; maxDecimals?: number }) {
  const press = (k: string) => {
    if (k === "C") return onChange("");
    if (k === "⌫") return onChange(value.slice(0, -1));
    if (k === ",") return value.includes(",") ? undefined : onChange((value || "0") + ",");
    const dec = value.split(",")[1];
    if (dec !== undefined && dec.length >= maxDecimals) return;
    if (value === "0") return onChange(k);
    if (value.length >= 9) return;
    onChange(value + k);
  };
  const keys = ["7", "8", "9", "4", "5", "6", "1", "2", "3", ",", "0", "⌫"];
  return (
    <div className="keypad" role="group" aria-label={label}>
      {keys.map((k) => (
        <button
          key={k}
          type="button"
          className="key"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => press(k)}
          aria-label={k === "⌫" ? "Effacer le dernier chiffre" : k === "," ? "Virgule" : k}
        >
          {k === "⌫" ? <Icon name="backspace" size={24} /> : k}
        </button>
      ))}
      <button type="button" className="key key-clear" onMouseDown={(e) => e.preventDefault()} onClick={() => press("C")}>
        Effacer
      </button>
    </div>
  );
}

/* ---- Ouverture de session --------------------------------------------------------------------------- */

function OpenSession({ register, onOpened, onChangeRegister, lastClosed }: { register: Register; onOpened: (s: PosSession) => void; onChangeRegister: () => void; lastClosed: PosSession | null }) {
  const { can } = useAuth();
  const [float, setFloat] = useState("150,00");
  const act = useAction();
  const cents = parseEuros(float);
  const open = () =>
    act.run(async () => {
      if (cents === null) throw new Error("Montant du fond de caisse invalide");
      const s = await post<PosSession>("/api/caisse/sessions", { register_id: register.id, opening_float_cents: cents });
      onOpened(s);
    });
  return (
    <div className="pos-center pos-open">
      {lastClosed?.closing_report && <ClosingReportView session={lastClosed} />}
      <section className="pos-panel">
        <h1 className="pos-h1">Ouvrir la session — {register.label}</h1>
        {!can("pos.session") && <Notice tone="warning">Votre rôle ne permet pas d'ouvrir une session de caisse.</Notice>}
        <Field label="Fond de caisse (espèces dans le tiroir)" hint="En euros, compté avant la première vente.">
          <input className="pos-input" inputMode="decimal" value={float} onChange={(e) => setFloat(e.target.value)} aria-describedby="float-preview" />
        </Field>
        <p id="float-preview" className="pos-big">{cents === null ? "Montant invalide" : eur(cents)}</p>
        <Keypad value={float} onChange={setFloat} label="Pavé numérique du fond de caisse" />
        <ErrorBox error={act.error} />
        <div className="pos-row">
          <Button size="xl" variant="ghost" onClick={onChangeRegister} icon="back">
            Changer de poste
          </Button>
          <Button size="xl" variant="primary" onClick={open} busy={act.busy} disabled={cents === null || !can("pos.session")} icon="play">
            Ouvrir la caisse
          </Button>
        </div>
      </section>
    </div>
  );
}

function ClosingReportView({ session }: { session: PosSession }) {
  const r = session.closing_report;
  if (!r) return null;
  const diff = session.difference_cents ?? r.ecart;
  return (
    <section className="pos-panel report" aria-labelledby="rep-t">
      <h2 id="rep-t">Rapport de clôture — session n° {session.id}</h2>
      <Notice tone="warning">{r.avertissement}</Notice>
      <KV
        items={[
          ["Fond de caisse", eur(r.fond_de_caisse)],
          ["Ventes terminées", num(r.ventes_terminees)],
          ["Ventes annulées", num(r.ventes_annulees)],
          ["Chiffre d'affaires TTC", eur(r.chiffre_affaires_ttc)],
          ["Chiffre d'affaires HT", eur(r.chiffre_affaires_ht)],
          ["TVA collectée", eur(r.taxes)],
          ["Remises accordées", eur(r.remises)],
          ["Encaissements", Object.entries(r.encaissements_par_moyen).map(([k, v]) => `${PAYMENT_METHODS[k] ?? k} ${eur(v)}`).join(" · ") || "—"],
          ["Remboursements", Object.entries(r.remboursements_par_moyen).map(([k, v]) => `${PAYMENT_METHODS[k] ?? k} ${eur(v)}`).join(" · ") || "—"],
          ["Espèces attendues", eur(r.especes_attendues)],
          ["Espèces comptées", eur(r.especes_comptees)],
        ]}
      />
      <p className={`ecart ${diff === 0 ? "ok" : "ko"}`} role="status">
        <Icon name={diff === 0 ? "check" : "warning"} />
        Écart de caisse : <strong>{eurSigned(diff)}</strong> {diff === 0 ? "(aucun écart)" : diff < 0 ? "(manque dans le tiroir)" : "(excédent dans le tiroir)"}
      </p>
    </section>
  );
}

/* ---- Écran de vente --------------------------------------------------------------------------------- */

function SaleScreen({ register, session, onClosed, onChangeRegister }: { register: Register; session: PosSession; onClosed: (s: PosSession) => void; onChangeRegister: () => void }) {
  const { can } = useAuth();
  const { push } = useToast();
  const [sale, setSale] = useState<Sale | null>(null);
  const [mode, setMode] = useState<Mode>("articles");
  const [scan, setScan] = useState("");
  const [qtyBuf, setQtyBuf] = useState("");
  const [results, setResults] = useState<Variant[] | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [message, setMessage] = useState<{ tone: "ok" | "ko"; text: string } | null>(null);
  const [modal, setModal] = useState<null | "remise" | "annulation" | "vente" | "cloture" | "ticket">(null);
  const [ticket, setTicket] = useState<{ code: string; text: string } | null>(null);
  const scanRef = useRef<HTMLInputElement>(null);
  const saleIntent = useIntentKey("vente");
  const act = useAction();

  // Reprise d'une vente en cours de la session (rechargement de la page)
  useEffect(() => {
    const open = (session.ventes ?? []).filter((v) => v.status === "EN_COURS").sort((a, b) => b.id - a.id)[0];
    if (open) api<Sale>(`/api/caisse/ventes/${open.id}`).then(setSale).catch(() => undefined);
  }, [session]);

  const refreshSale = useCallback(() => {
    if (sale) api<Sale>(`/api/caisse/ventes/${sale.id}`).then(setSale).catch(() => undefined);
  }, [sale]);
  useLiveEvents(["paiement"], (e) => {
    if (sale && (e.data.cible_id === sale.id || sale.paiements.some((p) => p.id === e.data.id))) refreshSale();
  });

  // Le champ de scan garde le focus (douchette en émulation clavier), sauf si un autre champ ou une fenêtre est actif.
  const refocus = useCallback(() => {
    window.setTimeout(() => {
      const a = document.activeElement as HTMLElement | null;
      if (document.querySelector("[data-modal]")) return;
      if (a && a !== document.body && ["INPUT", "SELECT", "TEXTAREA"].includes(a.tagName) && a !== scanRef.current) return;
      scanRef.current?.focus();
    }, 0);
  }, []);
  useEffect(() => {
    refocus();
  }, [refocus, mode, modal, sale?.id]);

  // Référence toujours à jour de la vente : les scans en file ne doivent jamais créer deux ventes.
  const saleRef = useRef<Sale | null>(null);
  useEffect(() => {
    saleRef.current = sale;
  }, [sale]);
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const [pending, setPending] = useState(0);

  const ensureSale = async (): Promise<Sale> => {
    const cur = saleRef.current;
    if (cur && cur.status === "EN_COURS") return cur;
    const s = await withIntent(saleIntent, (key) => post<Sale>("/api/caisse/ventes", { session_id: session.id }, key));
    saleRef.current = s;
    setSale(s);
    return s;
  };

  const doAdd = async (code: string, quantity: string): Promise<boolean> => {
    try {
      const s = await ensureSale();
      const updated = await post<Sale>(`/api/caisse/ventes/${s.id}/lignes`, { code, quantity });
      saleRef.current = updated;
      setSale(updated);
      const last = updated.lines[updated.lines.length - 1];
      setMessage({ tone: "ok", text: `Ajouté : ${last.label} — ${qty(last.quantity, last.unit)} × ${eur(last.unit_price_ttc_cents)}` });
      setSelected(last.id);
      setResults(null);
      setMode("articles");
      act.setError(null);
      return true;
    } catch (e) {
      setMessage({ tone: "ko", text: e instanceof Error ? e.message : String(e) });
      act.setError(e instanceof Error ? e : new Error(String(e)));
      return false;
    } finally {
      refocus();
    }
  };

  /** Les scans sont mis en file d'attente : une douchette rapide ne perd aucun article. */
  const addCode = (code: string): Promise<boolean> => {
    const quantity = qtyBuf ? parseQty(qtyBuf) : "1";
    if (!quantity || Number(quantity) <= 0) {
      setMessage({ tone: "ko", text: "Quantité invalide sur le pavé numérique" });
      return Promise.resolve(false);
    }
    setQtyBuf("");
    setPending((n) => n + 1);
    const p = queue.current.then(() => doAdd(code, quantity)).finally(() => setPending((n) => n - 1));
    queue.current = p.catch(() => undefined);
    return p;
  };

  const search = async (q: string) => {
    if (q.trim().length < 2) {
      setResults(null);
      return;
    }
    try {
      setResults(await api<Variant[]>(`/api/catalogue/recherche${qs({ q: q.trim(), site_id: register.site_id })}`));
    } catch {
      setResults([]);
    }
  };
  // Recherche à la frappe pour du texte (les codes-barres numériques arrivent d'un bloc et sont validés par Entrée).
  useEffect(() => {
    if (!scan || /^\d+$/.test(scan)) return;
    const t = window.setTimeout(() => void search(scan), 300);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scan]);

  const onScanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = scan.trim();
    if (!code) return;
    setScan("");
    const ok = await addCode(code);
    if (!ok && !/^\d{8,14}$/.test(code)) {
      act.setError(null);
      setScan(code);
      await search(code);
      setMessage({ tone: "ko", text: `Aucun code ne correspond exactement à « ${code} » : choisissez dans les résultats.` });
    }
  };

  const active = sale?.lines.filter((l) => l.status === "ACTIVE") ?? [];
  const selectedLine = sale?.lines.find((l) => l.id === selected && l.status === "ACTIVE") ?? null;
  const engaged = (sale?.paiements ?? []).some((p) => ["CAPTURE", "AUTORISE", "EN_ATTENTE"].includes(p.status));
  const editable = !!sale && sale.status === "EN_COURS" && !engaged;
  const canValidate = !!sale && sale.status === "EN_COURS" && active.length > 0 && sale.reste_a_payer <= 0 && sale.en_attente === 0;

  const validate = () =>
    act.run(async () => {
      if (!sale) return;
      const done = await post<Sale>(`/api/caisse/ventes/${sale.id}/valider`);
      setTicket({ code: done.code, text: done.ticket ?? (await api<string>(`/api/caisse/ventes/${sale.id}/ticket`)) });
      setModal("ticket");
      setSale(done);
      push("success", `Vente ${done.code} terminée`, `${eur(done.total_ttc_cents)} TTC — stock mis à jour`);
    });

  const newSale = () => {
    setSale(null);
    setTicket(null);
    setModal(null);
    setMode("articles");
    setMessage(null);
    setSelected(null);
    saleIntent.consume();
  };

  return (
    <div className="pos-main">
      {/* ---------------- Colonne gauche : scan, recherche, pavé / paiement ---------------- */}
      <section className="pos-left" aria-label={mode === "articles" ? "Saisie des articles" : "Encaissement"}>
        <form className="pos-scan" onSubmit={onScanSubmit} role="search">
          <label htmlFor="scan" className="sr-only">
            Scanner un code-barres ou rechercher un article
          </label>
          <Icon name="scan" size={26} />
          <input
            id="scan"
            ref={scanRef}
            value={scan}
            onChange={(e) => setScan(e.target.value)}
            onBlur={refocus}
            placeholder="Scanner un code-barres ou taper un nom / SKU, puis Entrée"
            autoComplete="off"
            spellCheck={false}
            inputMode="search"
            aria-describedby="scan-msg"
            disabled={sale?.status === "TERMINEE" && modal === "ticket"}
          />
          {qtyBuf && (
            <span className="pos-qtybuf" aria-live="polite">
              × {qtyBuf}
            </span>
          )}
          <Button type="submit" size="lg" variant="primary" icon={pending > 0 ? "clock" : "plus"}>
            {pending > 0 ? `Ajout… (${pending})` : "Ajouter"}
          </Button>
        </form>
        <div id="scan-msg" className={`pos-msg ${message?.tone ?? ""} ${mode === "paiement" ? "sr-only" : ""}`} role="status" aria-live="polite">
          {message ? (
            <>
              <Icon name={message.tone === "ok" ? "check" : "critical"} size={18} />
              {message.text}
            </>
          ) : (
            <span className="muted">Prêt à scanner. Quantité par défaut : 1 (saisissez-la sur le pavé avant de scanner).</span>
          )}
        </div>

        {mode === "articles" ? (
          <div className="pos-articles">
            <div className="pos-results" aria-label="Résultats de recherche">
              {results === null ? (
                <QuickPicks onPick={(c) => void addCode(c)} siteId={register.site_id} />
              ) : results.length === 0 ? (
                <p className="muted">Aucun article trouvé.</p>
              ) : (
                <ul className="pos-result-list">
                  {results.map((v) => (
                    <li key={v.id}>
                      <button className="pos-result" onClick={() => { setScan(""); void addCode(v.gtin ?? v.sku); }}>
                        <strong>{v.label}</strong>
                        <span className="muted">
                          {v.sku} · {v.gtin}
                        </span>
                        <span className="pos-price">{v.prix.MAGASIN?.affichage ?? "prix non défini"}</span>
                        {v.stock && <span className="muted small">Disponible : {num(v.stock.disponible)}</span>}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="pos-keypad-box">
              <div className="pos-keypad-head">
                <span>Quantité pour le prochain article</span>
                <strong aria-live="polite">{qtyBuf || "1"}</strong>
              </div>
              <Keypad value={qtyBuf} onChange={setQtyBuf} label="Pavé numérique de quantité" maxDecimals={3} />
            </div>
          </div>
        ) : (
          sale && (
            <PaymentPanel
              sale={sale}
              onSale={setSale}
              onBack={() => setMode("articles")}
              onRefresh={refreshSale}
            />
          )
        )}
      </section>

      {/* ---------------- Colonne droite : panier et totaux ---------------- */}
      <section className="pos-right" aria-label="Panier">
        <div className="pos-cart-head">
          <h2>
            <Icon name="cart" /> Panier {sale && <span className="muted">· {sale.code}</span>}
          </h2>
          {sale && <StatusChip status={sale.status} />}
        </div>
        <ol className="pos-lines" aria-label="Lignes de la vente">
          {(sale?.lines ?? []).length === 0 && <li className="muted pos-empty">Panier vide — scannez un article pour commencer une vente.</li>}
          {(sale?.lines ?? []).map((l) => (
            <CartLine key={l.id} line={l} selected={selected === l.id} onSelect={() => setSelected(l.id === selected ? null : l.id)} />
          ))}
        </ol>
        <div className="pos-line-actions">
          <Button size="lg" icon="percent" disabled={!selectedLine || !editable} onClick={() => setModal("remise")}>
            Remise ligne
          </Button>
          <Button size="lg" icon="trash" variant="danger" disabled={!selectedLine || !editable} onClick={() => setModal("annulation")}>
            Annuler la ligne
          </Button>
        </div>
        <div className="pos-totals" aria-live="polite">
          <div className="pos-subtotals">
          <div>
            <span>Remises</span>
            <span>{eur(sale?.discount_cents ?? 0)}</span>
          </div>
          <div>
            <span>dont TVA</span>
            <span>{eur(sale?.total_tax_cents ?? 0)}</span>
          </div>
          <div>
            <span>Payé</span>
            <span>{eur(sale?.paye ?? 0)}</span>
          </div>
          </div>
          {(sale?.en_attente ?? 0) > 0 && (
            <div className="warn">
              <span>En attente de confirmation</span>
              <span>{eur(sale?.en_attente ?? 0)}</span>
            </div>
          )}
          <div className="pos-total">
            <span>Total TTC</span>
            <strong>{eur(sale?.total_ttc_cents ?? 0)}</strong>
          </div>
          <div className="pos-due">
            <span>Reste à payer</span>
            <strong>{eur(sale ? Math.max(0, sale.reste_a_payer) : 0)}</strong>
          </div>
        </div>
        <ErrorBox error={act.error} />
        <div className="pos-actions">
          {mode === "articles" ? (
            <Button size="xl" variant="primary" icon="euro" disabled={!sale || active.length === 0 || sale.status !== "EN_COURS"} onClick={() => setMode("paiement")}>
              Encaisser
            </Button>
          ) : (
            <Button size="xl" variant="success" icon="check" disabled={!canValidate} busy={act.busy} onClick={validate}>
              Valider la vente
            </Button>
          )}
          <div className="pos-row">
            <Button size="lg" variant="ghost" icon="cross" disabled={!sale || sale.status !== "EN_COURS"} onClick={() => setModal("vente")}>
              Annuler la vente
            </Button>
            <Button size="lg" variant="ghost" icon="lock" disabled={!can("pos.session") || (!!sale && sale.status === "EN_COURS")} onClick={() => setModal("cloture")}>
              Clôturer la caisse
            </Button>
          </div>
          <p className="muted small">
            Session n° {session.id} ouverte le {dateTime(session.opened_at)} · fond {eur(session.opening_float_cents)} ·{" "}
            <button className="link-btn" onClick={onChangeRegister}>
              changer de poste
            </button>
          </p>
        </div>
      </section>

      {modal === "remise" && selectedLine && <DiscountModal line={selectedLine} onClose={() => setModal(null)} onDone={setSale} />}
      {modal === "annulation" && selectedLine && <VoidModal line={selectedLine} onClose={() => setModal(null)} onDone={setSale} />}
      {modal === "vente" && sale && (
        <CancelSaleModal
          sale={sale}
          onClose={() => setModal(null)}
          onDone={() => {
            push("info", `Vente ${sale.code} annulée`);
            newSale();
          }}
        />
      )}
      {modal === "cloture" && <CloseModal session={session} onClose={() => setModal(null)} onDone={onClosed} />}
      {modal === "ticket" && ticket && (
        <Modal
          title={`Ticket ${ticket.code}`}
          onClose={newSale}
          footer={
            <Button size="xl" variant="primary" icon="plus" onClick={newSale}>
              Nouvelle vente
            </Button>
          }
        >
          <Notice tone="warning">Ticket de démonstration — sans valeur fiscale (prototype non certifié).</Notice>
          <pre className="ticket" aria-label="Texte du ticket">
            {ticket.text}
          </pre>
        </Modal>
      )}
    </div>
  );
}

function CartLine({ line, selected, onSelect }: { line: SaleLine; selected: boolean; onSelect: () => void }) {
  const voided = line.status !== "ACTIVE";
  return (
    <li className={`pos-line ${selected ? "selected" : ""} ${voided ? "voided" : ""}`}>
      <button onClick={onSelect} disabled={voided} aria-pressed={selected} aria-label={`${line.label}, ${qty(line.quantity, line.unit)}, ${eur(line.total_ttc_cents)}${voided ? ", ligne annulée" : ""}`}>
        <span className="pos-line-main">
          <strong>{line.label}</strong>
          <span className="muted">
            {qty(line.quantity, line.unit)} × {eur(line.unit_price_ttc_cents)}
            {line.unit !== "PCE" && ` / ${line.unit.toLowerCase()}`}
          </span>
          {line.discount_cents > 0 && (
            <span className="pos-disc">
              Remise {bp(line.discount_bp)} : −{eur(line.discount_cents)} ({line.discount_reason})
            </span>
          )}
          {voided && <span className="pos-void">Ligne annulée{line.void_reason ? ` — ${line.void_reason}` : ""}</span>}
        </span>
        <span className="pos-line-total">{eur(voided ? 0 : line.total_ttc_cents)}</span>
      </button>
    </li>
  );
}

/** Articles fréquents du magasin (raccourcis tactiles). */
function QuickPicks({ onPick, siteId }: { onPick: (code: string) => void; siteId: number }) {
  const [items, setItems] = useState<Variant[]>([]);
  useEffect(() => {
    api<Variant[]>(`/api/catalogue/recherche${qs({ q: "e", site_id: siteId })}`)
      .then((r) => setItems(r.filter((v) => v.prix.MAGASIN).slice(0, 8)))
      .catch(() => setItems([]));
  }, [siteId]);
  if (items.length === 0) return <p className="muted">Scannez un article ou tapez au moins 2 caractères pour rechercher.</p>;
  return (
    <>
      <p className="muted small">Raccourcis — articles du catalogue</p>
      <div className="pos-quick">
        {items.map((v) => (
          <button key={v.id} className="pos-quick-btn" onClick={() => onPick(v.gtin ?? v.sku)}>
            <strong>{v.label}</strong>
            <span>{v.prix.MAGASIN?.affichage}</span>
          </button>
        ))}
      </div>
    </>
  );
}

/* ---- Paiement --------------------------------------------------------------------------------------- */

function PaymentPanel({ sale, onSale, onBack, onRefresh }: { sale: Sale; onSale: (s: Sale) => void; onBack: () => void; onRefresh: () => void }) {
  const { can } = useAuth();
  const [method, setMethod] = useState<PayMethod>("ESPECES");
  const due = Math.max(0, sale.reste_a_payer - sale.en_attente);
  const [amount, setAmount] = useState(centsToInput(due));
  const [tendered, setTendered] = useState("");
  const [target, setTarget] = useState<"remis" | "montant">("remis");
  const [token, setToken] = useState<string>("tok_sim_accepte");
  const payIntent = useIntentKey("paiement");
  const act = useAction();
  const { push } = useToast();

  useEffect(() => {
    setAmount(centsToInput(due));
  }, [due]);

  // Toute modification des paramètres = nouvelle intention (nouvelle clé) ; un simple « réessayer » garde la clé.
  useEffect(() => {
    payIntent.consume();
  }, [method, amount, tendered, token, payIntent]);

  const amountCents = parseEuros(amount);
  const tenderedCents = tendered ? parseEuros(tendered) : amountCents;
  const change = amountCents !== null && tenderedCents !== null ? tenderedCents - amountCents : null;

  const pay = () =>
    act.run(async () => {
      if (amountCents === null || amountCents <= 0) throw new Error("Montant à encaisser invalide");
      const body =
        method === "ESPECES"
          ? { method, amount_cents: amountCents, cash_tendered_cents: tenderedCents ?? amountCents }
          : { method, amount_cents: amountCents, card_token: token };
      const r = await withIntent(payIntent, (key) => post<{ paiement: { status: string; failure_reason: string | null; change_cents: number | null }; vente: Sale }>(`/api/caisse/ventes/${sale.id}/paiements`, body, key));
      onSale(r.vente);
      setTendered("");
      const st = r.paiement.status;
      if (st === "CAPTURE") push("success", "Paiement enregistré", `${PAYMENT_METHODS[method]} ${eur(amountCents)}${r.paiement.change_cents ? ` — rendu ${eur(r.paiement.change_cents)}` : ""}`);
      else if (st === "ECHOUE") push("warning", "Paiement refusé", r.paiement.failure_reason ?? "Refus du terminal simulé");
      else push("info", "Paiement en attente", "Le prestataire confirmera plus tard (webhook).");
    });

  const simulateLate = (ref: string) =>
    act.run(async () => {
      await api(`/api/paiements/simulateur/evenement${qs({ provider_ref: ref, event_type: "payment.captured" })}`, { method: "POST" });
      onRefresh();
    });

  const quick = [due, ...[500, 1000, 2000, 5000, 10000].filter((v) => v > due)].slice(0, 5);

  return (
    <div className="pos-pay">
      <div className="pos-methods">
        <button type="button" className="pos-method pos-method-back" onClick={onBack} aria-label="Revenir à la saisie des articles">
          <Icon name="back" size={24} /> Articles
        </button>
        <div className="pos-methods-group" role="radiogroup" aria-label={`Moyen de paiement — reste à payer ${eur(due)}`}>
        <button role="radio" aria-checked={method === "ESPECES"} className={`pos-method ${method === "ESPECES" ? "on" : ""}`} onClick={() => setMethod("ESPECES")}>
          <Icon name="cash" size={28} /> Espèces
        </button>
        <button role="radio" aria-checked={method === "CARTE_SIMULEE"} className={`pos-method ${method === "CARTE_SIMULEE" ? "on" : ""}`} onClick={() => setMethod("CARTE_SIMULEE")}>
          <Icon name="card" size={28} /> Carte (terminal simulé)
        </button>
        </div>
      </div>

      <div className="pos-pay-body">
        <div className="pos-pay-fields">
          <Field label="Montant à encaisser" hint="Paiement partiel possible : réduisez le montant.">
            <input className={`pos-input ${target === "montant" ? "kp-target" : ""}`} inputMode="decimal" value={amount} onFocus={() => setTarget("montant")} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          {method === "ESPECES" ? (
            <>
              <Field label="Montant remis par le client">
                <input className={`pos-input ${target === "remis" ? "kp-target" : ""}`} inputMode="decimal" value={tendered} placeholder={amount} onFocus={() => setTarget("remis")} onChange={(e) => setTendered(e.target.value)} />
              </Field>
              <div className="pos-quick-cash" role="group" aria-label="Montants remis rapides">
                {quick.map((v) => (
                  <button key={v} type="button" className="chip-btn" onClick={() => setTendered(centsToInput(v))}>
                    {v === due ? "Compte juste" : eur(v)}
                  </button>
                ))}
              </div>
              <p className={`pos-change ${change !== null && change < 0 ? "ko" : ""}`} aria-live="polite">
                {change === null ? "Montant invalide" : change < 0 ? `Montant remis insuffisant (manque ${eur(-change)})` : <>Rendu monnaie : <strong>{eur(change)}</strong></>}
              </p>
            </>
          ) : (
            <fieldset className="pos-card-scen">
              <legend>Scénario du terminal simulé</legend>
              <p className="muted small">
                <Icon name="lock" size={14} /> Aucune saisie de numéro de carte : le terminal fournit un jeton de test.
              </p>
              {CARD_SCENARIOS.map((c) => (
                <label key={c.token} className={`scen ${token === c.token ? "on" : ""}`}>
                  <input type="radio" name="scen" value={c.token} checked={token === c.token} onChange={() => setToken(c.token)} />
                  <span>
                    <strong>{c.label}</strong>
                    <span className="muted small">
                      {c.hint} · <code>{c.token}</code>
                    </span>
                  </span>
                </label>
              ))}
            </fieldset>
          )}
          <ErrorBox error={act.error} title="Paiement refusé" />
          <Button size="xl" variant="primary" icon={method === "ESPECES" ? "cash" : "card"} busy={act.busy} disabled={due <= 0 || amountCents === null || (method === "ESPECES" && (change ?? -1) < 0)} onClick={pay}>
            {method === "ESPECES" ? `Encaisser ${amountCents !== null ? eur(amountCents) : ""} en espèces` : `Envoyer ${amountCents !== null ? eur(amountCents) : ""} au terminal`}
          </Button>
        </div>
        <div className="pos-pay-keypad">
          <Keypad
            value={target === "remis" && method === "ESPECES" ? tendered : amount}
            onChange={target === "remis" && method === "ESPECES" ? setTendered : setAmount}
            label={target === "remis" && method === "ESPECES" ? "Pavé numérique : montant remis" : "Pavé numérique : montant à encaisser"}
          />
        </div>
      </div>

      {sale.paiements.length > 0 && (
        <div className="pos-payments">
          <h3>Paiements de la vente</h3>
          <ul>
            {sale.paiements.map((p) => (
              <li key={p.id}>
                <span>
                  {PAYMENT_METHODS[p.method] ?? p.method}
                  {p.card_last4 && ` ****${p.card_last4}`}
                </span>
                <strong>{eur(p.amount_cents)}</strong>
                <StatusChip status={p.status} />
                {p.change_cents ? <span className="muted small">rendu {eur(p.change_cents)}</span> : null}
                {p.failure_reason && <span className="muted small">{p.failure_reason}</span>}
                {["EN_ATTENTE", "AUTORISE"].includes(p.status) && (
                  <span className="pos-pending">
                    <Button size="sm" icon="refresh" onClick={onRefresh}>
                      Actualiser
                    </Button>
                    {can("admin.demo") && p.provider_ref && (
                      <Button size="sm" variant="copper" onClick={() => void simulateLate(p.provider_ref!)}>
                        Simuler la confirmation du prestataire
                      </Button>
                    )}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

/* ---- Fenêtres : remise, annulation, clôture --------------------------------------------------------- */

function ManagerFields({ show, user, setUser, pwd, setPwd }: { show: boolean; user: string; setUser: (v: string) => void; pwd: string; setPwd: (v: string) => void }) {
  if (!show) return null;
  return (
    <fieldset className="manager">
      <legend>Autorisation d'un responsable</legend>
      <p className="muted small">Le responsable saisit lui-même ses identifiants ; ils ne sont pas conservés.</p>
      <Field label="Identifiant du responsable">
        <input value={user} onChange={(e) => setUser(e.target.value)} autoComplete="off" />
      </Field>
      <Field label="Mot de passe du responsable">
        <input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} autoComplete="off" />
      </Field>
    </fieldset>
  );
}

function needsManager(e: unknown): boolean {
  return e instanceof ApiError && e.code === "NON_AUTORISE";
}

function DiscountModal({ line, onClose, onDone }: { line: SaleLine; onClose: () => void; onDone: (s: Sale) => void }) {
  const [pct, setPct] = useState("10");
  const [reason, setReason] = useState("");
  const [mgr, setMgr] = useState(false);
  const [mu, setMu] = useState("");
  const [mp, setMp] = useState("");
  const act = useAction();
  const pctNum = Number(pct.replace(",", "."));
  const valid = pctNum > 0 && pctNum <= 100 && reason.trim().length >= 3;
  const submit = () =>
    act.run(async () => {
      try {
        const s = await post<Sale>(`/api/caisse/lignes/${line.id}/remise`, {
          discount_bp: Math.round(pctNum * 100),
          reason: reason.trim(),
          manager_username: mgr ? mu : null,
          manager_password: mgr ? mp : null,
        });
        onDone(s);
        onClose();
      } catch (e) {
        if (needsManager(e)) setMgr(true);
        throw e;
      }
    });
  return (
    <Modal
      title={`Remise — ${line.label}`}
      onClose={onClose}
      footer={
        <>
          <Button size="lg" variant="ghost" onClick={onClose}>
            Fermer
          </Button>
          <Button size="lg" variant="primary" busy={act.busy} disabled={!valid} onClick={submit}>
            Appliquer la remise
          </Button>
        </>
      }
    >
      <p>
        Ligne : {qty(line.quantity, line.unit)} × {eur(line.unit_price_ttc_cents)} = {eur(line.gross_ttc_cents)}
      </p>
      <Field label="Remise (%)" hint={valid ? `Soit −${eur(Math.round((line.gross_ttc_cents * pctNum) / 100))}` : "Entre 0 et 100 %"}>
        <input className="pos-input" inputMode="decimal" value={pct} onChange={(e) => setPct(e.target.value)} />
      </Field>
      <Field label="Motif (obligatoire)" required>
        <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="ex. Carton abîmé (exposition)" />
      </Field>
      {act.error && needsManager(act.error) && !mu && <Notice tone="warning">Cette remise dépasse votre plafond : un responsable doit l'autoriser.</Notice>}
      <ManagerFields show={mgr} user={mu} setUser={setMu} pwd={mp} setPwd={setMp} />
      {!mgr && (
        <button className="link-btn" onClick={() => setMgr(true)}>
          Faire autoriser par un responsable
        </button>
      )}
      <ErrorBox error={act.error} />
    </Modal>
  );
}

function VoidModal({ line, onClose, onDone }: { line: SaleLine; onClose: () => void; onDone: (s: Sale) => void }) {
  const [reason, setReason] = useState("");
  const [mgr, setMgr] = useState(false);
  const [mu, setMu] = useState("");
  const [mp, setMp] = useState("");
  const act = useAction();
  const submit = () =>
    act.run(async () => {
      try {
        const s = await post<Sale>(`/api/caisse/lignes/${line.id}/annulation`, { reason: reason.trim(), manager_username: mgr ? mu : null, manager_password: mgr ? mp : null });
        onDone(s);
        onClose();
      } catch (e) {
        if (needsManager(e)) setMgr(true);
        throw e;
      }
    });
  return (
    <Modal
      title={`Annuler la ligne — ${line.label}`}
      onClose={onClose}
      footer={
        <>
          <Button size="lg" variant="ghost" onClick={onClose}>
            Fermer
          </Button>
          <Button size="lg" variant="danger" busy={act.busy} disabled={reason.trim().length < 3} onClick={submit}>
            Annuler la ligne
          </Button>
        </>
      }
    >
      <p>La ligne reste visible sur la vente avec la mention « annulée » (traçabilité de l'opération).</p>
      <Field label="Motif (obligatoire)" required>
        <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="ex. Erreur de scan" />
      </Field>
      <ManagerFields show={mgr} user={mu} setUser={setMu} pwd={mp} setPwd={setMp} />
      {!mgr && (
        <button className="link-btn" onClick={() => setMgr(true)}>
          Faire autoriser par un responsable
        </button>
      )}
      <ErrorBox error={act.error} />
    </Modal>
  );
}

function CancelSaleModal({ sale, onClose, onDone }: { sale: Sale; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [mgr, setMgr] = useState(false);
  const [mu, setMu] = useState("");
  const [mp, setMp] = useState("");
  const act = useAction();
  const submit = () =>
    act.run(async () => {
      try {
        await post<Sale>(`/api/caisse/ventes/${sale.id}/annuler`, { reason: reason.trim(), manager_username: mgr ? mu : null, manager_password: mgr ? mp : null });
        onDone();
      } catch (e) {
        if (needsManager(e)) setMgr(true);
        throw e;
      }
    });
  return (
    <Modal
      title={`Annuler la vente ${sale.code}`}
      onClose={onClose}
      footer={
        <>
          <Button size="lg" variant="ghost" onClick={onClose}>
            Fermer
          </Button>
          <Button size="lg" variant="danger" busy={act.busy} disabled={reason.trim().length < 3} onClick={submit}>
            Annuler la vente
          </Button>
        </>
      }
    >
      <Field label="Motif (obligatoire)" required>
        <input value={reason} onChange={(e) => setReason(e.target.value)} />
      </Field>
      <ManagerFields show={mgr} user={mu} setUser={setMu} pwd={mp} setPwd={setMp} />
      {!mgr && (
        <button className="link-btn" onClick={() => setMgr(true)}>
          Faire autoriser par un responsable
        </button>
      )}
      <ErrorBox error={act.error} />
    </Modal>
  );
}

function CloseModal({ session, onClose, onDone }: { session: PosSession; onClose: () => void; onDone: (s: PosSession) => void }) {
  const [counted, setCounted] = useState("");
  const act = useAction();
  const cents = parseEuros(counted);
  const submit = () =>
    act.run(async () => {
      if (cents === null) throw new Error("Montant compté invalide");
      const s = await post<PosSession>(`/api/caisse/sessions/${session.id}/cloture`, { counted_cash_cents: cents });
      onDone(s);
      onClose();
    });
  return (
    <Modal
      title="Clôturer la caisse"
      onClose={onClose}
      footer={
        <>
          <Button size="lg" variant="ghost" onClick={onClose}>
            Fermer
          </Button>
          <Button size="lg" variant="primary" busy={act.busy} disabled={cents === null} onClick={submit} icon="lock">
            Clôturer et rapprocher
          </Button>
        </>
      }
    >
      <p>Comptez les espèces du tiroir (fond de caisse inclus) avant de connaître le montant attendu : le rapprochement est fait par le serveur.</p>
      <Field label="Espèces comptées (€)" required>
        <input className="pos-input" inputMode="decimal" value={counted} onChange={(e) => setCounted(e.target.value)} />
      </Field>
      <p className="pos-big">{cents === null ? "—" : eur(cents)}</p>
      <Keypad value={counted} onChange={setCounted} label="Pavé numérique des espèces comptées" />
      <ErrorBox error={act.error} />
    </Modal>
  );
}
