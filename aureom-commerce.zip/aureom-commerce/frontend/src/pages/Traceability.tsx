import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { apiBlob, post, qs } from "../api/client";
import type { LedgerState, Limits, Lot, Recall, Reconciliation, TraceEvent } from "../api/types";
import { Icon } from "../components/Icon";
import { ProofStepper } from "../components/ProofStepper";
import { Async, Badge, Button, Card, Copyable, Empty, ErrorBox, Field, KV, Loading, Modal, Notice, PageHeader, StatusChip, Table, Tabs } from "../components/ui";
import { dateOnly, dateTime, num, shortId } from "../lib/format";
import { useAction, useApi, useQueryState } from "../lib/hooks";
import { statusLabel } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useSite } from "../state/site";
import { useToast } from "../state/toast";

const LEDGER_STATUSES = ["EN_ATTENTE", "SOUMIS", "CONFIRME", "REJETE", "INCONNU"];
const EVENT_TYPES: Record<string, string> = {
  LOT_CREATED: "Création d'un lot",
  SUPPLIER_SHIPMENT: "Expédition fournisseur",
  RECEIPT: "Réception",
  INSPECTION_RECORDED: "Contrôle enregistré",
  CUSTODY_TRANSFER: "Transfert de garde",
  TRANSFORMATION: "Transformation / reconditionnement",
  CUSTOMER_SHIPMENT: "Expédition client",
  RECALL: "Rappel",
  CORRECTION: "Correction liée",
  DISPUTE: "Contestation",
};

function LimitsBanner() {
  return (
    <div className="limits-banner" role="note">
      <Icon name="shield" size={22} />
      <p>
        <strong>Ce que prouve la traçabilité — et ce qu'elle ne prouve pas.</strong> Une signature identifie une clé, une empreinte identifie un fichier, le registre conserve des déclarations : aucun ne prouve à lui seul qu'un événement physique a eu lieu. Seul un contrôle indépendant documenté l'étaye.{" "}
        <Link to="/tracabilite?onglet=limites">Lire les limites de la preuve</Link>
      </p>
    </div>
  );
}

export default function TraceabilityPage() {
  const [tab, setTab] = useQueryState("onglet", "evenements");
  return (
    <>
      <PageHeader icon="trace" title="Traçabilité" subtitle="Événements partagés signés, registre, rapports de lot et rappels." />
      <LimitsBanner />
      <Tabs
        label="Sections de la traçabilité"
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "evenements", label: "Événements" },
          { id: "registre", label: "État du registre" },
          { id: "rapports", label: "Rapports de lot" },
          { id: "rappels", label: "Rappels" },
          { id: "limites", label: "Limites de la preuve" },
        ]}
      />
      {tab === "evenements" && <Events />}
      {tab === "registre" && <Registry />}
      {tab === "rapports" && <Reports />}
      {tab === "rappels" && <Recalls />}
      {tab === "limites" && <LimitsView />}
    </>
  );
}

/* ---- Événements ------------------------------------------------------------------------------------- */

function Events() {
  const { can } = useAuth();
  const [status, setStatus] = useState("");
  const [lot, setLot] = useState<number | "">("");
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const ev = useApi<TraceEvent[]>(`/api/tracabilite/evenements${qs({ ledger_status: status, lot_id: lot, limit: 200 })}`, ["tracabilite.declare", "tracabilite.confirme", "tracabilite.rejete"]);
  const [declare, setDeclare] = useState(false);
  const nav = useNavigate();
  const lotCode = (id: number | null) => lots.data?.find((l) => l.id === id)?.lot_code ?? (id ? `lot ${id}` : "—");
  return (
    <Card
      title="Événements de traçabilité"
      subtitle="Chaque événement passe par 4 niveaux de preuve cumulatifs : déclaré, signé, confirmé sur le registre, vérifié par contrôle indépendant."
      actions={
        can("trace.write") && (
          <Button variant="primary" icon="plus" onClick={() => setDeclare(true)}>
            Déclarer un événement
          </Button>
        )
      }
    >
      <div className="toolbar">
        <Field label="Statut sur le registre">
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Tous</option>
            {LEDGER_STATUSES.map((s) => (
              <option key={s} value={s}>
                {statusLabel(s)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Lot">
          <select value={lot} onChange={(e) => setLot(e.target.value ? Number(e.target.value) : "")}>
            <option value="">Tous les lots</option>
            {(lots.data ?? []).map((l) => (
              <option key={l.id} value={l.id}>
                {l.lot_code} — {l.libelle}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Async state={ev} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Événements de traçabilité" head={["Déclaré le", "Type", "Lot", "Émetteur", "Origine", "Niveaux de preuve", "Registre", ""]}>
            {rows.map((e) => (
              <tr key={e.id} className="clickable" onClick={() => nav(`/tracabilite/evenements/${e.id}`)}>
                <td>{dateTime(e.declared_at)}</td>
                <td>
                  <strong>{e.type_libelle}</strong>
                  <div className="muted small mono">{shortId(e.id)}</div>
                </td>
                <td>{lotCode(e.lot_id)}</td>
                <td>{e.issuer_org}</td>
                <td>{e.origin === "EXTERNE" ? <Badge tone="copper">Externe (fournisseur)</Badge> : <Badge tone="neutral">Local</Badge>}</td>
                <td>
                  <ProofStepper levels={e.niveaux_de_preuve} compact />
                </td>
                <td>
                  <StatusChip status={e.ledger_status} />
                  {e.ledger_error_code && <div className="muted small">{e.ledger_error_code}</div>}
                </td>
                <td>
                  <Link to={`/tracabilite/evenements/${e.id}`} onClick={(x) => x.stopPropagation()}>
                    Détail
                  </Link>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {declare && (
        <DeclareModal
          lots={lots.data ?? []}
          onClose={() => setDeclare(false)}
          onDone={(e) => {
            setDeclare(false);
            nav(`/tracabilite/evenements/${e.id}`);
          }}
        />
      )}
    </Card>
  );
}

function DeclareModal({ lots, onClose, onDone }: { lots: Lot[]; onClose: () => void; onDone: (e: TraceEvent) => void }) {
  const [type, setType] = useState("INSPECTION_RECORDED");
  const [lot, setLot] = useState<number | "">("");
  const [prev, setPrev] = useState("");
  const [corrects, setCorrects] = useState("");
  const [counterparty, setCounterparty] = useState("");
  const [location, setLocation] = useState("");
  const [note, setNote] = useState("");
  const a = useAction();
  const submit = () =>
    a.run(async () => {
      const e = await post<TraceEvent>("/api/tracabilite/evenements", {
        event_type: type,
        lot_id: lot,
        previous_event_id: prev || null,
        corrects_event_id: corrects || null,
        counterparty_org: counterparty || null,
        location_ref: location || null,
        details: note ? { commentaire: note } : {},
      });
      onDone(e);
    });
  return (
    <Modal
      title="Déclarer un événement de traçabilité"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={lot === ""} onClick={submit}>
            Déclarer et signer
          </Button>
        </>
      }
    >
      <Notice>L'événement sera signé avec la clé de l'organisation puis publié sur le registre par la boîte d'envoi. Une déclaration n'établit pas la réalité de l'événement.</Notice>
      <div className="form-grid">
        <Field label="Type d'événement">
          <select value={type} onChange={(e) => setType(e.target.value)}>
            {Object.entries(EVENT_TYPES).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Lot" required>
          <select value={lot} onChange={(e) => setLot(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir —</option>
            {lots.map((l) => (
              <option key={l.id} value={l.id}>
                {l.lot_code} — {l.libelle}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Événement précédent (identifiant)">
          <input value={prev} onChange={(e) => setPrev(e.target.value)} className="mono" />
        </Field>
        {(type === "CORRECTION" || type === "DISPUTE") && (
          <Field label="Événement corrigé / contesté (identifiant)" required>
            <input value={corrects} onChange={(e) => setCorrects(e.target.value)} className="mono" />
          </Field>
        )}
        <Field label="Contrepartie (MSP)">
          <input value={counterparty} onChange={(e) => setCounterparty(e.target.value)} placeholder="ex. ConserverieValMSP" />
        </Field>
        <Field label="Lieu (GLN)">
          <input value={location} onChange={(e) => setLocation(e.target.value)} />
        </Field>
      </div>
      <Field label="Commentaire (détails)">
        <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

export function EventDetailPage() {
  const { id } = useParams();
  const { can } = useAuth();
  const ev = useApi<TraceEvent>(`/api/tracabilite/evenements/${id}`, ["tracabilite.confirme", "tracabilite.rejete"]);
  const limits = useApi<Limits>("/api/tracabilite/limites");
  const [verify, setVerify] = useState(false);
  const [showEnv, setShowEnv] = useState(true);
  const a = useAction();
  const { push } = useToast();
  return (
    <Async state={ev}>
      {(e) => {
        let envelope: string = e.envelope;
        try {
          envelope = JSON.stringify(JSON.parse(e.envelope), null, 2);
        } catch {
          /* enveloppe non JSON : affichée brute */
        }
        const simulated = e.ledger_backend === "simulation";
        return (
          <>
            <PageHeader
              icon="trace"
              title={`${e.type_libelle} — ${e.subject_ref.split("|lot:")[1] ?? e.subject_ref}`}
              subtitle={
                <>
                  <Link to="/tracabilite">← Événements</Link> · identifiant <code>{e.id}</code>
                </>
              }
              actions={
                <>
                  {can("trace.verify") && (
                    <Button variant="primary" icon="shield" onClick={() => setVerify(true)}>
                      Enregistrer un contrôle indépendant
                    </Button>
                  )}
                  {can("ledger.admin") && e.ledger_status !== "CONFIRME" && (
                    <Button
                      icon="refresh"
                      busy={a.busy}
                      onClick={() =>
                        a.run(async () => {
                          await post(`/api/tracabilite/evenements/${e.id}/relancer`);
                          push("info", "Publication relancée");
                          ev.reload();
                        })
                      }
                    >
                      Relancer la publication
                    </Button>
                  )}
                </>
              }
            />
            <ErrorBox error={a.error} />
            <div className="grid-2 wide-left">
              <Card title="Niveaux de preuve" subtitle="Cumulatifs. Aucun niveau ne signifie « authentique » ni « vrai ».">
                <ProofStepper levels={e.niveaux_de_preuve} />
                {simulated && (
                  <Notice tone="warning" title="Registre SIMULÉ">
                    La confirmation provient d'un registre local non distribué : elle n'a aucune valeur de preuve partagée entre organisations.
                  </Notice>
                )}
              </Card>
              <Card title="Déclaration">
                <KV
                  items={[
                    ["Type", `${e.type_libelle} (${e.event_type})`],
                    ["Émetteur", e.issuer_org],
                    ["Origine", e.origin === "EXTERNE" ? "Externe — publié par le nœud du fournisseur" : "Locale"],
                    ["Sujet", <code key="s">{e.subject_ref}</code>],
                    ["Lot", e.lot_id ? <Link key="l" to={`/tracabilite?onglet=rapports&lot=${e.lot_id}`}>Rapport du lot</Link> : "—"],
                    ["Survenu le", dateTime(e.occurred_at, true)],
                    ["Déclaré le", dateTime(e.declared_at, true)],
                    ["Contrepartie", e.counterparty_org ? `${e.counterparty_org} (${statusLabel(e.counterparty_status)})` : "—"],
                    ["Lieu (GLN)", e.location_ref ?? "—"],
                    ["Source", e.source_type],
                    [
                      "Événement précédent",
                      e.previous_event_id ? (
                        <Link key="p" to={`/tracabilite/evenements/${e.previous_event_id}`}>
                          {shortId(e.previous_event_id, 13)}
                        </Link>
                      ) : (
                        "aucun"
                      ),
                    ],
                    ["Corrige / conteste", e.corrects_event_id ? <Link key="c" to={`/tracabilite/evenements/${e.corrects_event_id}`}>{shortId(e.corrects_event_id, 13)}</Link> : "—"],
                  ]}
                />
              </Card>
            </div>
            <div className="grid-2">
              <Card title="Registre">
                <KV
                  items={[
                    ["Statut", <StatusChip key="s" status={e.ledger_status} />],
                    ["Registre", e.ledger_backend === "simulation" ? "Simulation locale (non distribué)" : (e.ledger_backend ?? "—")],
                    ["Transaction", e.ledger_tx_id ? <Copyable key="t" text={e.ledger_tx_id} short={28} /> : "—"],
                    ["Bloc", e.ledger_block !== null ? num(e.ledger_block) : "—"],
                    ["Horodatage du registre", dateTime(e.ledger_timestamp, true)],
                    ["Erreur", e.ledger_error_code ? `${e.ledger_error_code} — ${e.ledger_error ?? ""}` : "aucune"],
                    ["Boîte d'envoi", e.publication ? `${statusLabel(e.publication.status)} · ${e.publication.attempts} tentative(s)${e.publication.last_error ? ` · ${e.publication.last_error}` : ""}` : "—"],
                  ]}
                />
              </Card>
              <Card title="Empreintes et signature" subtitle="Elles garantissent l'intégrité du contenu signé, pas sa véracité.">
                <KV
                  items={[
                    ["Empreinte de l'enveloppe (SHA-256)", <Copyable key="a" text={e.payload_sha256} short={24} />],
                    ["Empreinte des détails", <Copyable key="b" text={e.details_digest} short={24} />],
                    ["Clé de signature", <code key="k">{e.signer_key_id}</code>],
                    ["Signature (Ed25519, base64)", <Copyable key="g" text={e.signature_b64} short={24} />],
                  ]}
                />
                {e.evidence.length > 0 && (
                  <>
                    <h3>Pièces référencées</h3>
                    <ul className="barcodes">
                      {e.evidence.map((x, i) => (
                        <li key={i}>
                          {x.kind} <Copyable text={x.sha256} short={16} /> <span className="muted small">{x.mediaType}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="muted small">Pièce citée par son empreinte : cela prouve qu'un fichier donné est référencé, pas que son contenu est vrai.</p>
                  </>
                )}
              </Card>
            </div>
            <Card title="Contrôles indépendants">
              {(e.verifications ?? []).length === 0 ? (
                <Empty>Aucun contrôle indépendant enregistré : le niveau 4 n'est pas atteint.</Empty>
              ) : (
                <Table caption="Contrôles indépendants" head={["Date", "Méthode", "Contrôleur", "Résultat", "Notes"]}>
                  {e.verifications!.map((v) => (
                    <tr key={v.id}>
                      <td>{dateTime(v.performed_at)}</td>
                      <td>{limits.data?.methodes_verification[v.method] ?? v.method}</td>
                      <td>
                        {v.verifier_name} <span className="muted small">({v.verifier_org})</span>
                      </td>
                      <td>
                        <StatusChip status={v.result} />
                      </td>
                      <td className="small">{v.notes}</td>
                    </tr>
                  ))}
                </Table>
              )}
            </Card>
            <Card
              title="Enveloppe signée (JSON canonique)"
              actions={
                <Button size="sm" onClick={() => setShowEnv(!showEnv)}>
                  {showEnv ? "Masquer" : "Afficher"}
                </Button>
              }
            >
              {showEnv && <pre className="json">{envelope}</pre>}
              {e.details && (
                <>
                  <h3>Détails (hors enveloppe, référencés par leur empreinte)</h3>
                  <pre className="json">{JSON.stringify(e.details, null, 2)}</pre>
                </>
              )}
            </Card>
            {verify && (
              <VerificationModal
                event={e}
                methods={limits.data?.methodes_verification ?? {}}
                onClose={() => setVerify(false)}
                onDone={() => {
                  setVerify(false);
                  ev.reload();
                }}
              />
            )}
          </>
        );
      }}
    </Async>
  );
}

function VerificationModal({ event, methods, onClose, onDone }: { event: TraceEvent; methods: Record<string, string>; onClose: () => void; onDone: () => void }) {
  const { user } = useAuth();
  const [method, setMethod] = useState("CONTROLE_PHYSIQUE");
  const [name, setName] = useState(user?.nom ?? "");
  const [org, setOrg] = useState("Maison & Marché — Qualité");
  const [result, setResult] = useState("CONFORME");
  const [at, setAt] = useState(() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  });
  const [notes, setNotes] = useState("");
  const a = useAction();
  const { push } = useToast();
  const submit = () =>
    a.run(async () => {
      await post(`/api/tracabilite/evenements/${event.id}/verifications`, { method, verifier_name: name, verifier_org: org, result, performed_at: new Date(at).toISOString(), notes });
      push("success", "Contrôle indépendant enregistré", result === "CONFORME" ? "Niveau 4 atteint pour cet événement." : "Résultat enregistré.");
      onDone();
    });
  return (
    <Modal
      title="Enregistrer un contrôle indépendant"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} disabled={!name || !org || notes.trim().length < 5} onClick={submit}>
            Enregistrer
          </Button>
        </>
      }
    >
      <Notice>Le contrôleur doit être une personne distincte du déclarant (séparation des tâches vérifiée par le serveur). Les méthodes « analyse » et « contrôle documentaire » exigent une pièce justificative.</Notice>
      <div className="form-grid">
        <Field label="Méthode">
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            {Object.entries(methods).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Résultat">
          <select value={result} onChange={(e) => setResult(e.target.value)}>
            <option value="CONFORME">Conforme</option>
            <option value="NON_CONFORME">Non conforme</option>
            <option value="NON_CONCLUANT">Non concluant</option>
          </select>
        </Field>
        <Field label="Nom du contrôleur" required>
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Organisme du contrôleur" required>
          <input value={org} onChange={(e) => setOrg(e.target.value)} />
        </Field>
        <Field label="Réalisé le" required>
          <input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} />
        </Field>
      </div>
      <Field label="Constat (obligatoire)" required>
        <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ex. Comptage contradictoire de 3 cartons, étiquetage conforme au bon de livraison" />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

/* ---- Registre --------------------------------------------------------------------------------------- */

function Registry() {
  const { can } = useAuth();
  const st = useApi<LedgerState>("/api/tracabilite/registre/etat", ["tracabilite.confirme", "tracabilite.rejete", "tracabilite.declare"]);
  const recs = useApi<Reconciliation[]>("/api/tracabilite/registre/reconciliations");
  const outage = useApi<{ panne_simulee: boolean }>("/api/admin/demo/panne-registre");
  const keys = useApi<{ cles: { key_id: string; org_msp: string; status: string; valid_from: string; ledger_registered: boolean; custody: string }[]; conservation: string }>("/api/tracabilite/cles");
  const a = useAction();
  const [last, setLast] = useState<string | null>(null);
  const refresh = () => {
    st.reload();
    recs.reload();
    outage.reload();
    window.dispatchEvent(new Event("aureom:registre"));
  };
  return (
    <Async state={st}>
      {(s) => {
        const down = outage.data?.panne_simulee || s.sante.disponible === false;
        return (
          <>
            <div className="grid-2">
              <Card title="Mode et santé du registre">
                <div className={`registry-mode ${s.distribue ? "fabric" : "sim"}`}>
                  <Icon name="ledger" size={28} />
                  <div>
                    <strong>{s.distribue ? "Hyperledger Fabric (distribué)" : "Registre SIMULÉ (non distribué)"}</strong>
                    <p>{s.libelle}</p>
                  </div>
                </div>
                <p className={`ecart ${down ? "ko" : "ok"}`} role="status">
                  <Icon name={down ? "critical" : "check"} />
                  {down ? (outage.data?.panne_simulee ? "Indisponible — panne simulée (démonstration)" : "Indisponible") : "Disponible"}
                  {s.sante.erreur && ` — ${s.sante.erreur}`}
                </p>
                <KV
                  items={[
                    ["Mode", s.mode],
                    ...(s.statut ? Object.entries(s.statut).map(([k, v]) => [k, typeof v === "object" ? JSON.stringify(v) : String(v)] as [string, string]) : []),
                  ]}
                />
                {can("ledger.admin") && (
                  <div className="btn-row">
                    <Button
                      variant="primary"
                      icon="play"
                      busy={a.busy}
                      onClick={() =>
                        a.run(async () => {
                          const r = await post<Record<string, number>>("/api/tracabilite/registre/publier");
                          setLast(`Publication : ${Object.entries(r).map(([k, v]) => `${k} ${v}`).join(", ")}`);
                          refresh();
                        })
                      }
                    >
                      Publier maintenant
                    </Button>
                    <Button
                      icon="refresh"
                      busy={a.busy}
                      onClick={() =>
                        a.run(async () => {
                          const r = await post<{ resume?: string }>("/api/tracabilite/registre/reconcilier");
                          setLast(`Réconciliation : ${r.resume ?? "terminée"}`);
                          refresh();
                        })
                      }
                    >
                      Réconcilier
                    </Button>
                  </div>
                )}
                {last && (
                  <p className="result-line" role="status">
                    {last}
                  </p>
                )}
                <ErrorBox error={a.error} />
              </Card>
              <Card title="Boîte d'envoi (publication asynchrone)" subtitle="Les opérations locales sont finalisées immédiatement ; la publication sur le registre suit.">
                <div className="stats-grid small">
                  {Object.keys(s.boite_envoi).length === 0 && <Empty>Boîte d'envoi vide.</Empty>}
                  {Object.entries(s.boite_envoi).map(([k, v]) => (
                    <div key={k} className="stat">
                      <div className="stat-label">
                        <StatusChip status={k} />
                      </div>
                      <div className="stat-value">{num(v)}</div>
                    </div>
                  ))}
                </div>
                <h3>Dernière réconciliation</h3>
                {s.derniere_reconciliation ? (
                  <p>
                    {dateTime(s.derniere_reconciliation.finished_at ?? s.derniere_reconciliation.started_at)} — {s.derniere_reconciliation.summary}
                  </p>
                ) : (
                  <p className="muted">Jamais réalisée.</p>
                )}
              </Card>
            </div>
            <Card title="En cas d'indisponibilité du registre" subtitle="Rien de physique n'est bloqué par le registre.">
              <div className="grid-3">
                <div>
                  <h3>
                    <Icon name="check" /> Continuent
                  </h3>
                  <ul className="bullets">
                    {s.operations_en_cas_d_indisponibilite.continuent.map((x) => (
                      <li key={x}>{x}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>
                    <Icon name="clock" /> Restent provisoires
                  </h3>
                  <ul className="bullets">
                    {s.operations_en_cas_d_indisponibilite.restent_provisoires.map((x) => (
                      <li key={x}>{x}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>
                    <Icon name="lock" /> Bloquées
                  </h3>
                  <ul className="bullets">
                    {s.operations_en_cas_d_indisponibilite.bloquees.map((x) => (
                      <li key={x}>{x}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
            <div className="grid-2">
              <Card title="Historique des réconciliations">
                <Async state={recs} empty={(x) => x.length === 0}>
                  {(rows) => (
                    <Table caption="Réconciliations" head={["Date", "Vérifiés", "Confirmés", "Importés", "Anomalies", "Résumé"]}>
                      {rows.map((r) => (
                        <tr key={r.id}>
                          <td>{dateTime(r.started_at)}</td>
                          <td className="num">{r.checked}</td>
                          <td className="num">{r.confirmed}</td>
                          <td className="num">{r.imported}</td>
                          <td className={`num ${r.mismatches.length ? "neg" : ""}`}>{r.mismatches.length}</td>
                          <td className="small">{r.summary}</td>
                        </tr>
                      ))}
                    </Table>
                  )}
                </Async>
              </Card>
              <Card title="Clés de signature" subtitle={keys.data?.conservation}>
                <Async state={keys}>
                  {(k) => (
                    <Table caption="Clés de signature" head={["Clé", "Organisation", "Statut", "Depuis", "Publiée sur le registre"]}>
                      {k.cles.map((c) => (
                        <tr key={c.key_id}>
                          <td>
                            <code>{c.key_id}</code>
                          </td>
                          <td>{c.org_msp}</td>
                          <td>
                            <StatusChip status={c.status} />
                          </td>
                          <td>{dateTime(c.valid_from)}</td>
                          <td>{c.ledger_registered ? "Oui" : "Non"}</td>
                        </tr>
                      ))}
                    </Table>
                  )}
                </Async>
              </Card>
            </div>
          </>
        );
      }}
    </Async>
  );
}

/* ---- Rapports --------------------------------------------------------------------------------------- */

interface LotReport {
  genere_le: string;
  mode_registre: string;
  lot: { id: number; numero: string; code_interne: string; statut: string; peremption: string | null; type_date: string | null; fabrication: string | null; reference_partagee: string };
  article: { sku: string; libelle: string; gtin: string; unite: string };
  fournisseur: string | null;
  evenements: { id: string; type: string; emetteur: string; origine: string; survenu_le: string; registre: { etat: string } }[];
  mouvements: { date: string; type: string; site: string; emplacement: string; etat: string; quantite: string; document: string | null }[];
  stock_actuel: { site: string; emplacement: string; etat: string; quantite: string }[];
  destinations: { type: string; document: string; site: string; quantite: string; certitude: string; date: string }[];
  documents: { type: string; emetteur_declare: string | null; reference: string | null; authenticite: string }[];
  rappels: { code: string; statut: string; motif: string; taches_ouvertes: number }[];
  limites_de_la_preuve: string[];
  donnees_personnelles: string;
}

function Reports() {
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const [lotQ, setLotQ] = useQueryState("lot", "");
  const lot: number | "" = lotQ ? Number(lotQ) : "";
  const setLot = (v: number | "") => setLotQ(v === "" ? "" : String(v));
  const rep = useApi<LotReport>(lot === "" ? null : `/api/tracabilite/lots/${lot}/rapport`);
  const a = useAction();
  const open = (format: "html" | "csv" | "json") =>
    a.run(async () => {
      // Le rapport exige l'authentification : récupéré en Blob puis ouvert / téléchargé localement.
      const { blob, filename } = await apiBlob(`/api/tracabilite/lots/${lot}/rapport${qs({ format })}`);
      const url = URL.createObjectURL(blob);
      if (format === "html") {
        const w = window.open(url, "_blank", "noopener");
        if (!w) {
          const link = document.createElement("a");
          link.href = url;
          link.download = `tracabilite-lot-${lot}.html`;
          link.click();
        }
      } else {
        const link = document.createElement("a");
        link.href = url;
        link.download = filename ?? `tracabilite-lot-${lot}.${format}`;
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
      window.setTimeout(() => URL.revokeObjectURL(url), 60000);
    });
  return (
    <Card title="Rapport de traçabilité d'un lot" subtitle="Événements partagés, mouvements internes, stock actuel, destinations (avec niveau de certitude), documents et rappels. Sans donnée personnelle.">
      <div className="toolbar">
        <Field label="Lot">
          <select value={lot} onChange={(e) => setLot(e.target.value ? Number(e.target.value) : "")}>
            <option value="">— choisir un lot —</option>
            {(lots.data ?? []).map((l) => (
              <option key={l.id} value={l.id}>
                {l.lot_code} — {l.libelle} ({statusLabel(l.status)})
              </option>
            ))}
          </select>
        </Field>
        <Button icon="external" disabled={lot === ""} busy={a.busy} onClick={() => open("html")}>
          Ouvrir le rapport HTML
        </Button>
        <Button icon="download" disabled={lot === ""} busy={a.busy} onClick={() => open("csv")}>
          Télécharger CSV
        </Button>
        <Button icon="download" disabled={lot === ""} busy={a.busy} onClick={() => open("json")}>
          Télécharger JSON
        </Button>
      </div>
      <ErrorBox error={a.error} />
      {lot === "" ? (
        <Empty>Choisissez un lot pour afficher son rapport.</Empty>
      ) : rep.loading && !rep.data ? (
        <Loading />
      ) : rep.error ? (
        <ErrorBox error={rep.error} />
      ) : rep.data ? (
        <ReportView r={rep.data} />
      ) : null}
    </Card>
  );
}

function ReportView({ r }: { r: LotReport }) {
  return (
    <div className="stack">
      {r.mode_registre === "simulation" && <Notice tone="warning">Rapport produit avec un registre SIMULÉ (non distribué).</Notice>}
      <KV
        items={[
          ["Lot", `${r.lot.numero} (${r.lot.code_interne})`],
          ["Article", `${r.article.libelle} — ${r.article.sku} · GTIN ${r.article.gtin}`],
          ["Fournisseur", r.fournisseur ?? "—"],
          ["Statut", <StatusChip key="s" status={r.lot.statut} />],
          ["Fabrication", dateOnly(r.lot.fabrication)],
          ["Péremption", r.lot.peremption ? `${r.lot.type_date ?? ""} ${dateOnly(r.lot.peremption)}` : "—"],
          ["Généré le", dateTime(r.genere_le)],
        ]}
      />
      <h3>Événements partagés ({r.evenements.length})</h3>
      <Table caption="Événements du lot" head={["Survenu le", "Type", "Émetteur", "Origine", "Registre", ""]}>
        {r.evenements.map((e) => (
          <tr key={e.id}>
            <td>{dateTime(e.survenu_le)}</td>
            <td>{e.type}</td>
            <td>{e.emetteur}</td>
            <td>{e.origine === "EXTERNE" ? "Externe" : "Local"}</td>
            <td>
              <StatusChip status={e.registre.etat} />
            </td>
            <td>
              <Link to={`/tracabilite/evenements/${e.id}`}>Détail</Link>
            </td>
          </tr>
        ))}
      </Table>
      <div className="grid-2">
        <div>
          <h3>Destinations ({r.destinations.length})</h3>
          <Table caption="Destinations du lot" head={["Date", "Type", "Document", "Site", "Quantité", "Certitude"]}>
            {r.destinations.map((d, i) => (
              <tr key={i}>
                <td>{dateTime(d.date)}</td>
                <td>{d.type}</td>
                <td>{d.document}</td>
                <td>{d.site}</td>
                <td>{d.quantite}</td>
                <td>{d.certitude.startsWith("présumée") ? <Badge tone="warning" icon="warning">{d.certitude}</Badge> : <Badge tone="info">{d.certitude}</Badge>}</td>
              </tr>
            ))}
          </Table>
        </div>
        <div>
          <h3>Stock actuel</h3>
          <Table caption="Stock actuel du lot" head={["Site", "Emplacement", "État", "Quantité"]}>
            {r.stock_actuel.map((s, i) => (
              <tr key={i}>
                <td>{s.site}</td>
                <td>{s.emplacement}</td>
                <td>{s.etat}</td>
                <td>{s.quantite}</td>
              </tr>
            ))}
          </Table>
          <h3>Documents</h3>
          {r.documents.length === 0 ? (
            <p className="muted">Aucun.</p>
          ) : (
            <ul className="bullets">
              {r.documents.map((d, i) => (
                <li key={i}>
                  {d.type} — {d.emetteur_declare ?? "émetteur non déclaré"} {d.reference && `(${d.reference})`} · <StatusChip status={d.authenticite} />
                </li>
              ))}
            </ul>
          )}
          {r.rappels.length > 0 && (
            <>
              <h3>Rappels</h3>
              <ul className="bullets">
                {r.rappels.map((x) => (
                  <li key={x.code}>
                    {x.code} — <StatusChip status={x.statut} /> {x.motif} ({x.taches_ouvertes} tâche(s) ouverte(s))
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>
      <h3>Mouvements internes ({r.mouvements.length})</h3>
      <Table caption="Mouvements internes du lot" head={["Date", "Type", "Site", "Emplacement", "État", "Quantité", "Document"]}>
        {r.mouvements.map((m, i) => (
          <tr key={i}>
            <td>{dateTime(m.date)}</td>
            <td>{m.type}</td>
            <td>{m.site}</td>
            <td>{m.emplacement}</td>
            <td>{m.etat}</td>
            <td>{m.quantite}</td>
            <td>{m.document ?? "—"}</td>
          </tr>
        ))}
      </Table>
      <p className="muted small">{r.donnees_personnelles}</p>
    </div>
  );
}

/* ---- Rappels ---------------------------------------------------------------------------------------- */

function Recalls() {
  const { can } = useAuth();
  const list = useApi<Recall[]>("/api/rappels", ["rappel"]);
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  return (
    <Card
      title="Rappels et retraits"
      actions={
        can("recall.manage") && (
          <Button variant="danger" icon="critical" onClick={() => setOpen(true)}>
            Ouvrir un rappel
          </Button>
        )
      }
    >
      <Async state={list} empty={(x) => x.length === 0}>
        {(rows) => (
          <Table caption="Rappels" head={["Code", "Statut", "Gravité", "Lots", "Motif", "Ouvert le", "Impact"]}>
            {rows.map((r) => (
              <tr key={r.id} className="clickable" onClick={() => nav(`/tracabilite/rappels/${r.id}`)}>
                <td>
                  <Link to={`/tracabilite/rappels/${r.id}`} onClick={(e) => e.stopPropagation()}>
                    <strong>{r.code}</strong>
                  </Link>
                </td>
                <td>
                  <StatusChip status={r.status} />
                </td>
                <td>{r.severity === "RAPPEL_CONSOMMATEURS" ? <Badge tone="danger" icon="critical">Rappel consommateurs</Badge> : <Badge tone="warning" icon="warning">Retrait</Badge>}</td>
                <td>{r.impact?.lots.join(", ")}</td>
                <td className="small">{r.reason}</td>
                <td>{dateTime(r.opened_at)}</td>
                <td className="small">{r.impact ? `${r.impact.ventes} vente(s), ${r.impact.commandes} commande(s), ${r.impact.clients_identifies} client(s) identifié(s)` : "—"}</td>
              </tr>
            ))}
          </Table>
        )}
      </Async>
      {open && (
        <OpenRecallModal
          onClose={() => setOpen(false)}
          onDone={(r) => {
            setOpen(false);
            nav(`/tracabilite/rappels/${r.id}`);
          }}
        />
      )}
    </Card>
  );
}

function OpenRecallModal({ onClose, onDone }: { onClose: () => void; onDone: (r: Recall) => void }) {
  const lots = useApi<Lot[]>("/api/stocks/lots");
  const [chosen, setChosen] = useState<number[]>([]);
  const [severity, setSeverity] = useState("RAPPEL_CONSOMMATEURS");
  const [reason, setReason] = useState("");
  const a = useAction();
  return (
    <Modal
      title="Ouvrir un rappel de lot"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="danger" busy={a.busy} disabled={chosen.length === 0 || reason.trim().length < 5} onClick={() => a.run(async () => onDone(await post<Recall>("/api/rappels", { lot_ids: chosen, severity, reason })))}>
            Ouvrir le rappel et bloquer le stock
          </Button>
        </>
      }
    >
      <Notice tone="warning">Le stock des lots choisis est bloqué immédiatement dans tous les sites (vente et préparation refusées), même si le registre est indisponible.</Notice>
      <fieldset className="lot-pick">
        <legend>Lots concernés</legend>
        {(lots.data ?? [])
          .filter((l) => l.status === "ACTIF")
          .map((l) => (
            <label key={l.id} className="check">
              <input type="checkbox" checked={chosen.includes(l.id)} onChange={(e) => setChosen(e.target.checked ? [...chosen, l.id] : chosen.filter((x) => x !== l.id))} /> {l.lot_code} — {l.libelle}
              {l.expires_on && <span className="muted small"> · {l.expiry_kind} {dateOnly(l.expires_on)}</span>}
            </label>
          ))}
      </fieldset>
      <Field label="Gravité">
        <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
          <option value="RAPPEL_CONSOMMATEURS">Rappel consommateurs (produits déjà vendus)</option>
          <option value="RETRAIT">Retrait (avant vente)</option>
        </select>
      </Field>
      <Field label="Motif (obligatoire)" required>
        <textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

export function RecallDetailPage() {
  const { id } = useParams();
  const { can } = useAuth();
  const { siteName } = useSite();
  const rc = useApi<Recall>(`/api/rappels/${id}`, ["rappel"]);
  const [task, setTask] = useState<{ id: number; description: string } | null>(null);
  const [log, setLog] = useState(false);
  const [close, setClose] = useState(false);
  return (
    <Async state={rc}>
      {(r) => {
        const open = (r.taches ?? []).filter((t) => t.status === "A_FAIRE").length;
        return (
          <>
            <PageHeader
              icon="critical"
              title={`Rappel ${r.code}`}
              subtitle={
                <>
                  <Link to="/tracabilite?onglet=rappels">← Rappels</Link> · ouvert le {dateTime(r.opened_at)}
                  {r.closed_at && ` · clos le ${dateTime(r.closed_at)}`}
                </>
              }
              actions={
                can("recall.manage") &&
                r.status !== "CLOS" && (
                  <>
                    <Button icon="plus" onClick={() => setLog(true)}>
                      Ajouter au journal
                    </Button>
                    <Button variant="primary" icon="check" onClick={() => setClose(true)}>
                      Clôturer le rappel
                    </Button>
                  </>
                )
              }
            />
            <div className="recall-head">
              <StatusChip status={r.status} />
              {r.severity === "RAPPEL_CONSOMMATEURS" ? <Badge tone="danger" icon="critical">Critique — rappel consommateurs</Badge> : <Badge tone="warning" icon="warning">Attention — retrait</Badge>}
              <p>{r.reason}</p>
            </div>
            {r.impact && (
              <section className="stats-grid" aria-label="Impact du rappel">
                <div className="stat stat-danger">
                  <div className="stat-label">Stock bloqué</div>
                  <div className="stat-value small">
                    {Object.entries(r.impact.stock_bloque).map(([k, v]) => (
                      <div key={k}>
                        {k} : {v}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="stat">
                  <div className="stat-label">Ventes concernées</div>
                  <div className="stat-value">{r.impact.ventes}</div>
                  <div className="stat-hint">dont {r.impact.ventes_anonymes} sans client identifié</div>
                </div>
                <div className="stat">
                  <div className="stat-label">Commandes concernées</div>
                  <div className="stat-value">{r.impact.commandes}</div>
                </div>
                <div className="stat">
                  <div className="stat-label">Clients identifiés</div>
                  <div className="stat-value">{r.impact.clients_identifies}</div>
                </div>
                <div className="stat">
                  <div className="stat-label">Sites</div>
                  <div className="stat-value small">{r.impact.sites.join(", ") || "—"}</div>
                </div>
                <div className={`stat ${open ? "stat-warning" : "stat-success"}`}>
                  <div className="stat-label">Tâches ouvertes</div>
                  <div className="stat-value">
                    {open} / {(r.taches ?? []).length}
                  </div>
                </div>
              </section>
            )}
            <div className="grid-2 wide-left">
              <Card title="Tâches" subtitle="« Certitude présumée » : rattachement au lot par la règle FEFO (vente sans lecture du lot).">
                <ul className="task-list">
                  {(r.taches ?? []).map((t) => (
                    <li key={t.id} className={t.status === "A_FAIRE" ? "todo" : "done"}>
                      <span className="task-status">
                        <StatusChip status={t.status} />
                      </span>
                      <div>
                        <span className="muted small">{t.kind.replaceAll("_", " ").toLowerCase()}</span>
                        <p>{t.description}</p>
                        <p className="muted small">
                          {t.site_id && siteName(t.site_id)}
                          {t.confidence && (
                            <>
                              {" "}
                              · certitude{" "}
                              {t.confidence === "PRESUMEE" ? (
                                <Badge tone="warning" icon="warning">
                                  présumée
                                </Badge>
                              ) : (
                                <Badge tone="info">{t.confidence.toLowerCase()}</Badge>
                              )}
                            </>
                          )}
                          {t.done_at && ` · faite le ${dateTime(t.done_at)}`}
                          {t.notes && ` — ${t.notes}`}
                        </p>
                      </div>
                      {can("recall.manage") && t.status === "A_FAIRE" && (
                        <Button size="sm" onClick={() => setTask({ id: t.id, description: t.description })}>
                          Traiter
                        </Button>
                      )}
                    </li>
                  ))}
                </ul>
              </Card>
              <Card title="Journal du rappel">
                <ol className="timeline">
                  {(r.journal ?? []).map((j) => (
                    <li key={j.id}>
                      <time>{dateTime(j.at)}</time>
                      <span>
                        <Badge tone={j.kind === "DECISION" ? "accent" : "copper"}>{j.kind === "DECISION" ? "Décision" : "Communication"}</Badge> {j.content}
                      </span>
                      {(j.channel || j.audience) && (
                        <span className="muted small">
                          {j.channel} {j.audience && `→ ${j.audience}`} {j.count ? `(${j.count})` : ""}
                        </span>
                      )}
                    </li>
                  ))}
                </ol>
                <h3>Lots bloqués</h3>
                <ul className="bullets">
                  {(r.lots ?? []).map((l) => (
                    <li key={l.lot_id}>
                      Lot n° {l.lot_id} : {num(l.blocked_qty)} unité(s) bloquée(s) ·{" "}
                      <Link to={`/tracabilite?onglet=rapports&lot=${l.lot_id}`}>rapport du lot</Link>
                      {l.trace_event_id && (
                        <>
                          {" "}
                          · <Link to={`/tracabilite/evenements/${l.trace_event_id}`}>événement RAPPEL</Link>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
              </Card>
            </div>
            {task && (
              <TaskModal
                task={task}
                onClose={() => setTask(null)}
                onDone={() => {
                  setTask(null);
                  rc.reload();
                }}
              />
            )}
            {log && (
              <LogModal
                recallId={r.id}
                onClose={() => setLog(false)}
                onDone={() => {
                  setLog(false);
                  rc.reload();
                }}
              />
            )}
            {close && (
              <CloseRecallModal
                recallId={r.id}
                openTasks={open}
                onClose={() => setClose(false)}
                onDone={() => {
                  setClose(false);
                  rc.reload();
                }}
              />
            )}
          </>
        );
      }}
    </Async>
  );
}

function TaskModal({ task, onClose, onDone }: { task: { id: number; description: string }; onClose: () => void; onDone: () => void }) {
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("FAITE");
  const a = useAction();
  return (
    <Modal
      title="Traiter la tâche"
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={notes.trim().length < 3} onClick={() => a.run(async () => { await post(`/api/rappels/taches/${task.id}`, { notes, status }); onDone(); })}>
          Enregistrer
        </Button>
      }
    >
      <p>{task.description}</p>
      <Field label="Résultat">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="FAITE">Faite</option>
          <option value="SANS_OBJET">Sans objet</option>
        </select>
      </Field>
      <Field label="Compte rendu (obligatoire)" required>
        <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function LogModal({ recallId, onClose, onDone }: { recallId: number; onClose: () => void; onDone: () => void }) {
  const [kind, setKind] = useState("COMMUNICATION");
  const [channel, setChannel] = useState("EMAIL");
  const [audience, setAudience] = useState("");
  const [content, setContent] = useState("");
  const [count, setCount] = useState("0");
  const a = useAction();
  return (
    <Modal
      title="Ajouter une entrée au journal"
      onClose={onClose}
      footer={
        <Button
          variant="primary"
          busy={a.busy}
          disabled={content.trim().length < 3}
          onClick={() => a.run(async () => { await post(`/api/rappels/${recallId}/journal`, { kind, content, channel: kind === "COMMUNICATION" ? channel : null, audience: audience || null, count: Number(count) || 0 }); onDone(); })}
        >
          Ajouter
        </Button>
      }
    >
      <div className="form-grid">
        <Field label="Type">
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="COMMUNICATION">Communication</option>
            <option value="DECISION">Décision</option>
          </select>
        </Field>
        {kind === "COMMUNICATION" && (
          <>
            <Field label="Canal">
              <select value={channel} onChange={(e) => setChannel(e.target.value)}>
                <option value="EMAIL">E-mail</option>
                <option value="SMS">SMS</option>
                <option value="AFFICHAGE">Affichage magasin</option>
                <option value="TELEPHONE">Téléphone</option>
              </select>
            </Field>
            <Field label="Destinataires">
              <input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="ex. clients identifiés" />
            </Field>
            <Field label="Nombre de destinataires">
              <input inputMode="numeric" value={count} onChange={(e) => setCount(e.target.value)} />
            </Field>
          </>
        )}
      </div>
      <Field label="Contenu" required>
        <textarea rows={3} value={content} onChange={(e) => setContent(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

function CloseRecallModal({ recallId, openTasks, onClose, onDone }: { recallId: number; openTasks: number; onClose: () => void; onDone: () => void }) {
  const [note, setNote] = useState("");
  const a = useAction();
  return (
    <Modal
      title="Clôturer le rappel"
      onClose={onClose}
      footer={
        <Button variant="primary" busy={a.busy} disabled={note.trim().length < 3} onClick={() => a.run(async () => { await post(`/api/rappels/${recallId}/cloture`, { note }); onDone(); })}>
          Clôturer
        </Button>
      }
    >
      {openTasks > 0 && <Notice tone="warning">{openTasks} tâche(s) encore ouverte(s) : le serveur peut refuser la clôture.</Notice>}
      <Field label="Note de clôture (obligatoire)" required>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorBox error={a.error} />
    </Modal>
  );
}

/* ---- Limites ---------------------------------------------------------------------------------------- */

function LimitsView() {
  const l = useApi<Limits>("/api/tracabilite/limites");
  return (
    <Async state={l}>
      {(d) => (
        <>
          <Card title="Limites de la preuve" className="limits-card">
            <ol className="limits">
              {d.limites.map((x, i) => (
                <li key={i}>
                  <Icon name="warning" />
                  <span>{x}</span>
                </li>
              ))}
            </ol>
          </Card>
          <div className="grid-2">
            <Card title="Les 4 niveaux de preuve">
              <ol className="bullets numbered">
                {Object.entries(d.niveaux).map(([k, v]) => (
                  <li key={k}>
                    <strong>{v}</strong> <span className="muted small">({k})</span>
                  </li>
                ))}
              </ol>
              <p className="muted">Aucun badge « authentique » n'est jamais affiché : les niveaux décrivent ce qui a été déclaré, signé, conservé et contrôlé.</p>
            </Card>
            <Card title="Méthodes de contrôle indépendant reconnues">
              <ul className="bullets">
                {Object.entries(d.methodes_verification).map(([k, v]) => (
                  <li key={k}>
                    <strong>{v}</strong> <span className="muted small">({k})</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </>
      )}
    </Async>
  );
}
