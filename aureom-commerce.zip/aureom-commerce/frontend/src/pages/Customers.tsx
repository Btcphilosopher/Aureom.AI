import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { post, qs } from "../api/client";
import type { Customer, CustomerDetail } from "../api/types";
import { Icon } from "../components/Icon";
import { Async, Badge, Button, Card, ErrorBox, Field, KV, Modal, Notice, PageHeader, Table } from "../components/ui";
import { dateTime, num } from "../lib/format";
import { useAction, useApi } from "../lib/hooks";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";

function displayName(c: Customer & { nom_affiche?: string }): string {
  if (c.anonymise) return "Client anonymisé";
  if (c.societe) return c.societe;
  if (c.nom !== undefined) return [c.prenom, c.nom].filter(Boolean).join(" ") || c.code;
  return c.nom_affiche ?? c.code;
}

function Masked() {
  return (
    <span className="masked" title="Permission « Voir les coordonnées des clients » requise">
      <Icon name="eye-off" size={14} /> masqué
    </span>
  );
}

export default function CustomersPage() {
  const { can } = useAuth();
  const pii = can("customer.pii");
  const [q, setQ] = useState("");
  const [query, setQuery] = useState("");
  const list = useApi<(Customer & { nom_affiche?: string })[]>(`/api/clients${qs({ q: query })}`);
  const [create, setCreate] = useState(false);
  const nav = useNavigate();
  return (
    <>
      <PageHeader
        icon="customers"
        title="Clients"
        subtitle="Comptes particuliers et professionnels. Consentements marketing et fidélité sont gérés séparément."
        actions={
          can("customer.write") && (
            <Button variant="primary" icon="plus" onClick={() => setCreate(true)}>
              Nouveau client
            </Button>
          )
        }
      />
      {!pii && <Notice tone="info">Coordonnées masquées : votre rôle ne donne pas accès aux données personnelles (nom complet, e-mail, téléphone).</Notice>}
      <Card>
        <form
          className="toolbar"
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            setQuery(q.trim());
          }}
        >
          <Field label="Rechercher (nom, société ou code client exact)">
            <input value={q} onChange={(e) => setQ(e.target.value)} />
          </Field>
          <Button type="submit" icon="search">
            Rechercher
          </Button>
        </form>
        <Async state={list} empty={(x) => x.length === 0}>
          {(rows) => (
            <Table caption="Clients" head={["Code", "Type", "Nom", "E-mail", "Téléphone", ""]}>
              {rows.map((c) => (
                <tr key={c.id} className="clickable" onClick={() => nav(`/clients/${c.id}`)}>
                  <td>
                    <Link to={`/clients/${c.id}`} onClick={(e) => e.stopPropagation()}>
                      {c.code}
                    </Link>
                  </td>
                  <td>{c.type === "PROFESSIONNEL" ? "Professionnel" : "Particulier"}</td>
                  <td>{displayName(c)}</td>
                  <td>{pii ? (c.email ?? "—") : <Masked />}</td>
                  <td>{pii ? (c.telephone ?? "—") : <Masked />}</td>
                  <td>{c.anonymise && <Badge tone="neutral">Anonymisé</Badge>}</td>
                </tr>
              ))}
            </Table>
          )}
        </Async>
      </Card>
      {create && (
        <CreateCustomer
          onClose={() => setCreate(false)}
          onDone={(c) => {
            setCreate(false);
            nav(`/clients/${c.id}`);
          }}
        />
      )}
    </>
  );
}

export function CustomerDetailPage() {
  const { id } = useParams();
  const { can } = useAuth();
  const pii = can("customer.pii");
  const c = useApi<CustomerDetail & { nom_affiche?: string }>(`/api/clients/${id}`);
  const a = useAction();
  const { push } = useToast();
  const [anon, setAnon] = useState(false);
  const setConsent = (channel: string, granted: boolean) =>
    a.run(async () => {
      await post(`/api/clients/${id}/consentements`, { channel, granted, source: "BUREAU" });
      push("success", `Consentement ${channel} ${granted ? "accordé" : "retiré"}`, "Horodaté et conservé avec la formulation présentée.");
      c.reload();
    });
  return (
    <Async state={c}>
      {(d) => (
        <>
          <PageHeader icon="customers" title={displayName(d)} subtitle={<><Link to="/clients">← Clients</Link> · {d.code} · {d.type === "PROFESSIONNEL" ? "Professionnel" : "Particulier"}</>} />
          <div className="grid-3">
            <Card title="Coordonnées">
              {pii ? (
                <KV items={[["Prénom", d.prenom ?? "—"], ["Nom", d.nom ?? "—"], ["Société", d.societe ?? "—"], ["E-mail", d.email ?? "—"], ["Téléphone", d.telephone ?? "—"], ["SIRET", d.siret ?? "—"]]} />
              ) : (
                <Notice>Coordonnées masquées (permission « Voir les coordonnées des clients » requise).</Notice>
              )}
              {d.anonymise && <Badge tone="neutral">Client anonymisé (RGPD)</Badge>}
              {can("customer.pii") && can("customer.write") && !d.anonymise && (
                <Button variant="danger" icon="eye-off" onClick={() => setAnon(true)}>
                  Anonymiser
                </Button>
              )}
            </Card>
            <Card title="Consentements marketing" subtitle={d.note}>
              <ul className="consents">
                {Object.entries(d.consentements_marketing).map(([ch, v]) => (
                  <li key={ch}>
                    <span>
                      <strong>{ch === "EMAIL" ? "E-mail" : ch}</strong>
                      <span className="muted small">{v.depuis ? `depuis le ${dateTime(v.depuis)} (${v.source})` : "jamais recueilli"}</span>
                    </span>
                    <Badge tone={v.accorde ? "success" : "neutral"} icon={v.accorde ? "check" : "cross"}>
                      {v.accorde ? "Accordé" : "Non accordé"}
                    </Badge>
                    {can("customer.write") && !d.anonymise && (
                      <Button size="sm" busy={a.busy} onClick={() => setConsent(ch, !v.accorde)}>
                        {v.accorde ? "Retirer" : "Recueillir"}
                      </Button>
                    )}
                  </li>
                ))}
              </ul>
              <ErrorBox error={a.error} />
            </Card>
            <Card title="Fidélité" subtitle="Programme distinct du consentement marketing.">
              {d.fidelite ? (
                <>
                  <p className="big-number">
                    {num(d.fidelite.solde)} <span>point(s)</span>
                  </p>
                  <p className="muted small">{d.fidelite.regles}</p>
                </>
              ) : (
                <>
                  <p className="muted">Non inscrit au programme.</p>
                  {can("customer.write") && (
                    <Button
                      busy={a.busy}
                      onClick={() =>
                        a.run(async () => {
                          await post(`/api/clients/${id}/fidelite`);
                          c.reload();
                        })
                      }
                    >
                      Inscrire au programme
                    </Button>
                  )}
                </>
              )}
            </Card>
          </div>
          {d.fidelite && (
            <Card title="Mouvements de points">
              <Table caption="Mouvements de fidélité" head={["Date", "Type", "Points", "Référence", "Explication"]}>
                {d.fidelite.mouvements.map((m) => (
                  <tr key={m.id}>
                    <td>{dateTime(m.created_at)}</td>
                    <td>{m.kind.replaceAll("_", " ").toLowerCase()}</td>
                    <td className={`num ${m.points < 0 ? "neg" : "pos"}`}>
                      {m.points > 0 ? "+" : ""}
                      {num(m.points)}
                    </td>
                    <td>{m.reference}</td>
                    <td className="small">{m.explanation}</td>
                  </tr>
                ))}
              </Table>
            </Card>
          )}
          {anon && (
            <Modal
              title="Anonymiser le client"
              onClose={() => setAnon(false)}
              footer={
                <Button
                  variant="danger"
                  busy={a.busy}
                  onClick={() =>
                    a.run(async () => {
                      await post(`/api/clients/${id}/anonymiser`);
                      setAnon(false);
                      c.reload();
                    })
                  }
                >
                  Anonymiser définitivement
                </Button>
              }
            >
              <Notice tone="warning">Les données personnelles seront effacées de façon irréversible. Les ventes et la traçabilité conservent une référence anonyme.</Notice>
              <ErrorBox error={a.error} />
            </Modal>
          )}
        </>
      )}
    </Async>
  );
}

function CreateCustomer({ onClose, onDone }: { onClose: () => void; onDone: (c: Customer) => void }) {
  const [f, setF] = useState({ kind: "PARTICULIER", first_name: "", last_name: "", company_name: "", siret: "", email: "", phone: "", payment_terms_days: "", email_marketing: false, sms_marketing: false, loyalty: false });
  const a = useAction();
  const set = (k: keyof typeof f, v: string | boolean) => setF((x) => ({ ...x, [k]: v }));
  const submit = () =>
    a.run(async () => {
      const body: Record<string, unknown> = { kind: f.kind, loyalty: f.loyalty, email_marketing: f.email_marketing, sms_marketing: f.sms_marketing, source: "BUREAU" };
      for (const k of ["first_name", "last_name", "company_name", "siret", "email", "phone"] as const) if (f[k]) body[k] = f[k];
      if (f.payment_terms_days) body.payment_terms_days = Number(f.payment_terms_days);
      onDone(await post<Customer>("/api/clients", body));
    });
  return (
    <Modal
      title="Nouveau client"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button variant="primary" busy={a.busy} onClick={submit}>
            Créer
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label="Type">
          <select value={f.kind} onChange={(e) => set("kind", e.target.value)}>
            <option value="PARTICULIER">Particulier</option>
            <option value="PROFESSIONNEL">Professionnel</option>
          </select>
        </Field>
        <Field label="Prénom">
          <input value={f.first_name} onChange={(e) => set("first_name", e.target.value)} />
        </Field>
        <Field label="Nom">
          <input value={f.last_name} onChange={(e) => set("last_name", e.target.value)} />
        </Field>
        {f.kind === "PROFESSIONNEL" && (
          <>
            <Field label="Raison sociale">
              <input value={f.company_name} onChange={(e) => set("company_name", e.target.value)} />
            </Field>
            <Field label="SIRET">
              <input value={f.siret} onChange={(e) => set("siret", e.target.value)} inputMode="numeric" />
            </Field>
            <Field label="Délai de paiement (jours)">
              <input value={f.payment_terms_days} onChange={(e) => set("payment_terms_days", e.target.value)} inputMode="numeric" />
            </Field>
          </>
        )}
        <Field label="E-mail">
          <input type="email" value={f.email} onChange={(e) => set("email", e.target.value)} />
        </Field>
        <Field label="Téléphone">
          <input type="tel" value={f.phone} onChange={(e) => set("phone", e.target.value)} />
        </Field>
      </div>
      <fieldset className="consent-box">
        <legend>Consentements (cases non pré-cochées, indépendants de la fidélité)</legend>
        <label className="check">
          <input type="checkbox" checked={f.email_marketing} onChange={(e) => set("email_marketing", e.target.checked)} /> Accepte de recevoir des offres par e-mail
        </label>
        <label className="check">
          <input type="checkbox" checked={f.sms_marketing} onChange={(e) => set("sms_marketing", e.target.checked)} /> Accepte de recevoir des offres par SMS
        </label>
      </fieldset>
      <label className="check">
        <input type="checkbox" checked={f.loyalty} onChange={(e) => set("loyalty", e.target.checked)} /> Inscrire au programme de fidélité
      </label>
      <ErrorBox error={a.error} />
    </Modal>
  );
}
