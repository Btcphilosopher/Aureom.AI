import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, setToken, setUnauthorizedHandler } from "../api/client";
import type { LoginResponse, Me } from "../api/types";

interface AuthCtx {
  user: Me | null;
  token: string | null;
  ready: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: (reason?: string) => void;
  can: (...perms: string[]) => boolean;
  canAny: (...perms: string[]) => boolean;
  notice: string | null;
}

const Ctx = createContext<AuthCtx | null>(null);
const KEY = "aureom.jeton";

function readStored(): string | null {
  try {
    return sessionStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setTok] = useState<string | null>(() => {
    const t = readStored();
    setToken(t);
    return t;
  });
  const [user, setUser] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const logout = useCallback((reason?: string) => {
    try {
      sessionStorage.removeItem(KEY);
    } catch {
      /* stockage indisponible */
    }
    setToken(null);
    setTok(null);
    setUser(null);
    setNotice(reason ?? null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => logout("Votre session a expiré : reconnectez-vous."));
    return () => setUnauthorizedHandler(null);
  }, [logout]);

  useEffect(() => {
    if (!token) {
      setReady(true);
      return;
    }
    setToken(token);
    api<Me>("/api/auth/moi")
      .then((me) => setUser(me))
      .catch(() => logout())
      .finally(() => setReady(true));
  }, [token, logout]);

  const login = useCallback(async (username: string, password: string) => {
    const r = await api<LoginResponse>("/api/auth/connexion", { method: "POST", body: { username, password } });
    try {
      sessionStorage.setItem(KEY, r.jeton);
    } catch {
      /* stockage indisponible : session en mémoire seulement */
    }
    setToken(r.jeton);
    setUser(r.utilisateur);
    setTok(r.jeton);
    setNotice(null);
  }, []);

  const value = useMemo<AuthCtx>(() => {
    const perms = new Set(user?.permissions ?? []);
    return {
      user,
      token,
      ready,
      login,
      logout,
      notice,
      can: (...p) => p.every((x) => perms.has(x)),
      canAny: (...p) => p.some((x) => perms.has(x)),
    };
  }, [user, token, ready, login, logout, notice]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("AuthProvider manquant");
  return c;
}
