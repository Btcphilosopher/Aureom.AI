import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { LiveEvent } from "../api/types";

/**
 * Connexion WebSocket temps réel (/ws?token=…) : événements opérationnels {type, data}.
 * Reconnexion automatique avec temporisation exponentielle (1 s → 15 s).
 */
export type LiveStatus = "connexion" | "connecte" | "deconnecte";

type Handler = (e: LiveEvent) => void;

interface LiveCtx {
  status: LiveStatus;
  events: LiveEvent[];
  subscribe: (h: Handler) => () => void;
  lastAt: number | null;
  retryIn: number | null;
}

const Ctx = createContext<LiveCtx | null>(null);

export function LiveProvider({ token, children }: { token: string | null; children: ReactNode }) {
  const [status, setStatus] = useState<LiveStatus>("connexion");
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const [lastAt, setLastAt] = useState<number | null>(null);
  const [retryIn, setRetryIn] = useState<number | null>(null);
  const handlers = useRef(new Set<Handler>());
  const seq = useRef(0);

  useEffect(() => {
    if (!token) return;
    let ws: WebSocket | null = null;
    let stopped = false;
    let attempt = 0;
    let timer: number | null = null;

    const connect = () => {
      if (stopped) return;
      setStatus("connexion");
      setRetryIn(null);
      const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
      ws = new WebSocket(`${proto}//${window.location.host}/ws?token=${encodeURIComponent(token)}`);
      ws.onopen = () => {
        attempt = 0;
        setStatus("connecte");
      };
      ws.onmessage = (m) => {
        let parsed: { type?: string; data?: Record<string, unknown> };
        try {
          parsed = JSON.parse(String(m.data));
        } catch {
          return;
        }
        if (!parsed.type) return;
        const ev: LiveEvent = { type: parsed.type, data: parsed.data ?? {}, recu_le: Date.now(), id: ++seq.current };
        setLastAt(ev.recu_le);
        setEvents((prev) => [ev, ...prev].slice(0, 60));
        handlers.current.forEach((h) => {
          try {
            h(ev);
          } catch {
            /* un abonné défaillant ne doit pas interrompre les autres */
          }
        });
      };
      ws.onclose = (e) => {
        ws = null;
        if (stopped) return;
        setStatus("deconnecte");
        if (e.code === 4401) return; // jeton refusé : pas de reconnexion
        const delay = Math.min(15000, 1000 * 2 ** attempt);
        attempt += 1;
        setRetryIn(Math.round(delay / 1000));
        timer = window.setTimeout(connect, delay);
      };
      ws.onerror = () => ws?.close();
    };
    // Connexion différée d'un tour de boucle : en développement, le double montage de StrictMode
    // annule ainsi le minuteur au lieu d'ouvrir puis fermer immédiatement une socket.
    timer = window.setTimeout(connect, 0);
    return () => {
      stopped = true;
      if (timer) window.clearTimeout(timer);
      ws?.close();
    };
  }, [token]);

  const subscribe = useCallback((h: Handler) => {
    handlers.current.add(h);
    return () => {
      handlers.current.delete(h);
    };
  }, []);

  const value = useMemo(() => ({ status, events, subscribe, lastAt, retryIn }), [status, events, subscribe, lastAt, retryIn]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useLive(): LiveCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("LiveProvider manquant");
  return c;
}

/** Abonnement à des types d'événements ("*" = tous). Le gestionnaire le plus récent est toujours utilisé. */
export function useLiveEvents(types: string[], handler: (e: LiveEvent) => void): void {
  const c = useContext(Ctx);
  const subscribe = c?.subscribe;
  const h = useRef(handler);
  h.current = handler;
  const key = types.join(",");
  useEffect(() => {
    if (!subscribe || !key) return;
    const list = key.split(",");
    return subscribe((e) => {
      if (list.includes("*") || list.includes(e.type) || list.some((t) => t.endsWith(".*") && e.type.startsWith(t.slice(0, -1)))) h.current(e);
    });
  }, [key, subscribe]);
}
