import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api } from "../api/client";
import type { Organisation, Site } from "../api/types";
import { useAuth } from "./auth";

interface SiteCtx {
  sites: Site[];
  /** Sites du périmètre de l'utilisateur (tous si aucun périmètre). */
  mySites: Site[];
  siteId: number | null;
  site: Site | null;
  setSiteId: (id: number | null) => void;
  siteName: (id: number | null | undefined) => string;
  orgs: Organisation[];
  orgName: (id: number | null | undefined) => string;
  locationCode: (id: number | null | undefined) => string;
}

const Ctx = createContext<SiteCtx | null>(null);
const KEY = "aureom.site";

export function SiteProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [sites, setSites] = useState<Site[]>([]);
  const [orgs, setOrgs] = useState<Organisation[]>([]);
  const [siteId, setSiteIdState] = useState<number | null>(() => {
    try {
      const v = localStorage.getItem(KEY);
      return v ? Number(v) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (!user) return;
    api<Site[]>("/api/sites").then(setSites).catch(() => setSites([]));
    api<Organisation[]>("/api/organisations").then(setOrgs).catch(() => setOrgs([]));
  }, [user]);

  const mySites = useMemo(() => {
    if (!user || user.sites.length === 0) return sites;
    return sites.filter((s) => user.sites.includes(s.id));
  }, [sites, user]);

  // Un utilisateur restreint à des sites ne peut pas choisir « tous les sites » ni un site hors périmètre.
  useEffect(() => {
    if (!user || mySites.length === 0) return;
    const restricted = user.sites.length > 0;
    if (restricted && (siteId === null || !user.sites.includes(siteId))) setSiteIdState(mySites[0].id);
    if (!restricted && siteId !== null && !sites.some((s) => s.id === siteId)) setSiteIdState(null);
  }, [user, mySites, siteId, sites]);

  const setSiteId = useCallback((id: number | null) => {
    setSiteIdState(id);
    try {
      if (id === null) localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, String(id));
    } catch {
      /* préférence locale non conservée */
    }
  }, []);

  const value = useMemo<SiteCtx>(() => {
    const byId = new Map(sites.map((s) => [s.id, s]));
    const locs = new Map(sites.flatMap((s) => s.emplacements.map((l) => [l.id, `${s.code} · ${l.code}`] as const)));
    const orgById = new Map(orgs.map((o) => [o.id, o]));
    return {
      sites,
      mySites,
      siteId,
      site: siteId !== null ? (byId.get(siteId) ?? null) : null,
      setSiteId,
      siteName: (id) => (id === null || id === undefined ? "—" : (byId.get(id)?.name ?? `Site ${id}`)),
      orgs,
      orgName: (id) => (id === null || id === undefined ? "—" : (orgById.get(id)?.name ?? `Organisation ${id}`)),
      locationCode: (id) => (id === null || id === undefined ? "—" : (locs.get(id) ?? `Emplacement ${id}`)),
    };
  }, [sites, mySites, siteId, setSiteId, orgs]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSite(): SiteCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("SiteProvider manquant");
  return c;
}
