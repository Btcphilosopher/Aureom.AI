import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { Icon } from "../components/Icon";

export type ToastKind = "success" | "error" | "info" | "warning";
interface Toast {
  id: number;
  kind: ToastKind;
  title: string;
  message?: string;
}
interface ToastCtx {
  push: (kind: ToastKind, title: string, message?: string) => void;
}
const Ctx = createContext<ToastCtx | null>(null);
let seq = 0;

const KIND_LABEL: Record<ToastKind, string> = { success: "Succès", error: "Erreur", info: "Information", warning: "Attention" };
const KIND_ICON = { success: "check", error: "critical", info: "info", warning: "warning" } as const;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const push = useCallback(
    (kind: ToastKind, title: string, message?: string) => {
      const id = ++seq;
      setToasts((t) => [...t.slice(-4), { id, kind, title, message }]);
      window.setTimeout(() => dismiss(id), kind === "error" ? 9000 : 5500);
    },
    [dismiss],
  );
  const value = useMemo(() => ({ push }), [push]);
  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toasts" role="region" aria-label="Notifications" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.kind}`} role={t.kind === "error" ? "alert" : "status"}>
            <Icon name={KIND_ICON[t.kind]} />
            <div className="toast-body">
              <strong>
                <span className="sr-only">{KIND_LABEL[t.kind]} : </span>
                {t.title}
              </strong>
              {t.message && <p>{t.message}</p>}
            </div>
            <button className="icon-btn" onClick={() => dismiss(t.id)} aria-label="Fermer la notification">
              <Icon name="close" />
            </button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast(): ToastCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("ToastProvider manquant");
  return c;
}
