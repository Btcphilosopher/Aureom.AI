import type { LiveEvent } from "../api/types";
import { eur } from "./format";
import { LIVE_LABELS, SEVERITY, statusLabel } from "./labels";

export interface LiveText {
  title: string;
  text: string;
  /** Faut-il afficher une notification éphémère (en plus du fil) ? */
  toast: "info" | "warning" | "error" | "success" | null;
}

const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));

export function describeLive(e: LiveEvent): LiveText {
  const d = e.data;
  const title = LIVE_LABELS[e.type] ?? e.type;
  switch (e.type) {
    case "connexion":
      return { title, text: `Connecté en tant que ${s(d.utilisateur)}`, toast: null };
    case "alerte": {
      const sev = SEVERITY[s(d.gravite)]?.label ?? s(d.niveau);
      return { title: `Alerte — ${sev}`, text: s(d.titre), toast: d.gravite === "CRITIQUE" ? "error" : "warning" };
    }
    case "commande.statut":
      return { title, text: `${s(d.code)} → ${s(d.libelle) || statusLabel(s(d.statut))}`, toast: "info" };
    case "commande.preparation":
      return { title, text: `Tâche ${s(d.tache)} : ${statusLabel(s(d.statut))}`, toast: null };
    case "paiement":
      return { title, text: `Paiement ${s(d.id)} : ${statusLabel(s(d.statut))}`, toast: d.statut === "ECHOUE" ? "warning" : null };
    case "caisse.vente":
      return { title, text: `${s(d.code)} — ${eur(Number(d.total))}`, toast: null };
    case "stock.mouvement":
      return { title, text: `${s(d.type)}${d.document ? ` · ${s(d.document)}` : ""}`, toast: null };
    case "stock.exception":
      return { title, text: s(d.message), toast: "warning" };
    case "rappel":
      return { title, text: `${s(d.code)} — lots ${Array.isArray(d.lots) ? d.lots.join(", ") : ""}`, toast: "error" };
    case "tracabilite.confirme":
      return { title, text: `Événement ${s(d.id).slice(0, 8)}… bloc ${s(d.bloc)}`, toast: null };
    case "tracabilite.rejete":
      return { title, text: `Événement ${s(d.id).slice(0, 8)}… (${s(d.code)})`, toast: "warning" };
    case "tracabilite.declare":
      return { title, text: `${s(d.type)} · ${s(d.reference)}`, toast: null };
    case "achat.reception":
      return { title, text: `${s(d.code)} (commande ${s(d.commande)} : ${statusLabel(s(d.statut_commande))})`, toast: "info" };
    case "achat.commande":
      return { title, text: `${s(d.code)} : ${statusLabel(s(d.statut))}`, toast: null };
    case "equipement.observation":
      return { title, text: `${s(d.equipement)} : ${s(d.valeur)} ${s(d.unite)}`, toast: null };
    case "equipement.rfid":
      return { title, text: `${s(d.equipement)} · EPC ${s(d.epc)} (${statusLabel(s(d.statut))})`, toast: null };
    default:
      return { title, text: JSON.stringify(d).slice(0, 120), toast: null };
  }
}
