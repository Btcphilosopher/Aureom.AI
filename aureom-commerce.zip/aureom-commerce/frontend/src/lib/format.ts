/* Formats français : montants en euros (centimes entiers), dates Europe/Paris, quantités avec unité explicite. */

const TZ = "Europe/Paris";

const eurFmt = new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" });

/** 123456 → « 1 234,56 € » */
export function eur(cents: number | null | undefined): string {
  if (cents === null || cents === undefined || Number.isNaN(cents)) return "—";
  return eurFmt.format(cents / 100);
}

/** Montant signé, avec + explicite pour les écarts. */
export function eurSigned(cents: number | null | undefined): string {
  if (cents === null || cents === undefined) return "—";
  return (cents > 0 ? "+" : "") + eur(cents);
}

const dtFmt = new Intl.DateTimeFormat("fr-FR", {
  timeZone: TZ,
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});
const dtsFmt = new Intl.DateTimeFormat("fr-FR", {
  timeZone: TZ,
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});
const tFmt = new Intl.DateTimeFormat("fr-FR", { timeZone: TZ, hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" });

function parts(fmt: Intl.DateTimeFormat, d: Date): Record<string, string> {
  const out: Record<string, string> = {};
  for (const p of fmt.formatToParts(d)) out[p.type] = p.value;
  return out;
}

/** ISO UTC → « 28/11/2026 14:05 » (heure de Paris) */
export function dateTime(iso: string | null | undefined, withSeconds = false): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const p = parts(withSeconds ? dtsFmt : dtFmt, d);
  return `${p.day}/${p.month}/${p.year} ${p.hour}:${p.minute}${withSeconds ? ":" + p.second : ""}`;
}

/** Date calendaire « 2026-12-02 » → « 02/12/2026 » (sans conversion de fuseau). ISO complet → date de Paris. */
export function dateOnly(s: string | null | undefined): string {
  if (!s) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  const p = parts(dtFmt, d);
  return `${p.day}/${p.month}/${p.year}`;
}

export function timeOnly(ms: number): string {
  return tFmt.format(new Date(ms));
}

/** Durée relative courte (« il y a 3 min »). */
export function ago(iso: string | null | undefined): string {
  if (!iso) return "—";
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 0) return "à l'instant";
  if (diff < 60) return "il y a moins d'une minute";
  if (diff < 3600) return `il y a ${Math.round(diff / 60)} min`;
  if (diff < 86400) return `il y a ${Math.round(diff / 3600)} h`;
  return `il y a ${Math.round(diff / 86400)} j`;
}

const numFmt = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 3 });
export function num(v: number | string | null | undefined, maxDigits = 3): string {
  if (v === null || v === undefined || v === "") return "—";
  const n = typeof v === "number" ? v : Number(v);
  if (Number.isNaN(n)) return String(v);
  return maxDigits === 3 ? numFmt.format(n) : new Intl.NumberFormat("fr-FR", { maximumFractionDigits: maxDigits }).format(n);
}

const UNIT_LABELS: Record<string, [string, string]> = {
  PCE: ["pièce", "pièces"],
  G: ["g", "g"],
  KG: ["kg", "kg"],
  ML: ["ml", "ml"],
  CL: ["cl", "cl"],
  L: ["L", "L"],
  M: ["m", "m"],
  CM: ["cm", "cm"],
};
const PACK_LABELS: Record<string, [string, string]> = {
  PIECE: ["pièce", "pièces"],
  PAQUET: ["paquet", "paquets"],
  CARTON: ["carton", "cartons"],
  PALETTE: ["palette", "palettes"],
};

export function unitLabel(unit: string | null | undefined, n = 2): string {
  if (!unit) return "";
  const u = UNIT_LABELS[unit.toUpperCase()];
  if (!u) return unit.toLowerCase();
  return Math.abs(n) >= 2 ? u[1] : u[0];
}
export function packLabel(level: string, n = 2): string {
  const p = PACK_LABELS[level.toUpperCase()];
  if (!p) return level.toLowerCase();
  return Math.abs(n) >= 2 ? p[1] : p[0];
}

/** « 12.000 », « PCE » → « 12 pièces » ; « 1.5 », « KG » → « 1,5 kg » */
export function qty(v: string | number | null | undefined, unit: string | null | undefined): string {
  if (v === null || v === undefined || v === "") return "—";
  const n = typeof v === "number" ? v : Number(v);
  return `${num(n)} ${unitLabel(unit, n)}`.trim();
}

/** Nombre de conditionnements : « 3 cartons » */
export function packs(n: number | string, level: string): string {
  const x = typeof n === "number" ? n : Number(n);
  return `${num(x)} ${packLabel(level, x)}`;
}

/** Points de base → pourcentage « 10 % » */
export function bp(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return `${num(v / 100, 2)} %`;
}

export function pct(v: number | null | undefined, digits = 1): string {
  if (v === null || v === undefined) return "—";
  return `${num(v, digits)} %`;
}

/** Saisie « 12,5 » ou « 12.50 » (euros) → centimes ; null si invalide. */
export function parseEuros(input: string): number | null {
  const s = input.replace(/\s/g, "").replace("€", "").replace(",", ".");
  if (s === "" || !/^-?\d+(\.\d{0,2})?$/.test(s)) return null;
  return Math.round(Number(s) * 100);
}

/** Saisie quantité « 1,5 » → « 1.5 » (chaîne décimale envoyée à l'API) ; null si invalide. */
export function parseQty(input: string): string | null {
  const s = input.replace(/\s/g, "").replace(",", ".");
  if (s === "" || !/^\d+(\.\d{1,3})?$/.test(s)) return null;
  return s;
}

export function centsToInput(cents: number): string {
  return (cents / 100).toFixed(2).replace(".", ",");
}

export function shortId(id: string | null | undefined, n = 8): string {
  if (!id) return "—";
  return id.length > n ? id.slice(0, n) + "…" : id;
}

export function plural(n: number, one: string, many: string): string {
  return `${num(n)} ${Math.abs(n) >= 2 ? many : one}`;
}
