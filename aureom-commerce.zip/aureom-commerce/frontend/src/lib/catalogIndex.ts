import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { Product, Variant } from "../api/types";

export interface VariantInfo {
  id: number;
  sku: string;
  label: string;
  unit: string;
  gtin: string | null;
  codes: string[];
  productId: number;
  lotTracked: boolean;
  variant: Variant;
}

let cache: Promise<Map<number, VariantInfo>> | null = null;
const listeners = new Set<() => void>();

function load(): Promise<Map<number, VariantInfo>> {
  if (!cache) {
    cache = api<Product[]>("/api/catalogue/articles")
      .then((products) => {
        const m = new Map<number, VariantInfo>();
        for (const p of products)
          for (const v of p.variantes)
            m.set(v.id, {
              id: v.id,
              sku: v.sku,
              label: v.label,
              unit: p.base_unit,
              gtin: v.gtin,
              codes: v.codes_barres.map((b) => b.code),
              productId: p.id,
              lotTracked: p.lot_tracked,
              variant: v,
            });
        return m;
      })
      .catch((e) => {
        cache = null;
        throw e;
      });
  }
  return cache;
}

export function invalidateCatalog(): void {
  cache = null;
  listeners.forEach((l) => l());
}

/** Index des variantes (id → SKU, libellé, unité de base, codes-barres), chargé une fois. */
export function useCatalogIndex(): Map<number, VariantInfo> {
  const [m, setM] = useState<Map<number, VariantInfo>>(new Map());
  const [v, setV] = useState(0);
  useEffect(() => {
    const l = () => setV((x) => x + 1);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);
  useEffect(() => {
    let alive = true;
    load()
      .then((r) => alive && setM(r))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [v]);
  return m;
}

export function variantName(m: Map<number, VariantInfo>, id: number | null | undefined): string {
  if (id === null || id === undefined) return "—";
  const v = m.get(id);
  return v ? `${v.label}` : `Article ${id}`;
}
