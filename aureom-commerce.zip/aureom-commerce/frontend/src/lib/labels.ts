/* Libellés français des codes renvoyés par l'API et « tonalité » visuelle (toujours accompagnée du texte). */

export type Tone = "neutral" | "info" | "success" | "warning" | "danger" | "accent" | "copper";

const S: Record<string, [string, Tone]> = {
  // Commandes clients
  RECUE: ["Reçue", "info"],
  VALIDEE: ["Validée", "info"],
  RESERVEE: ["Stock réservé", "accent"],
  EN_PREPARATION: ["En préparation", "warning"],
  PRETE: ["Prête au retrait", "success"],
  EXPEDIEE: ["Expédiée", "accent"],
  REMISE: ["Remise au client", "success"],
  LIVREE: ["Livrée", "success"],
  ANNULEE: ["Annulée", "neutral"],
  // Paiement
  NON_PAYEE: ["Non payée", "warning"],
  PARTIELLEMENT_PAYEE: ["Partiellement payée", "warning"],
  PAYEE: ["Payée", "success"],
  REMBOURSEE: ["Remboursée", "neutral"],
  EN_ATTENTE: ["En attente", "warning"],
  AUTORISE: ["Autorisé", "info"],
  CAPTURE: ["Capturé", "success"],
  ECHOUE: ["Échoué", "danger"],
  ANNULE: ["Annulé", "neutral"],
  REMBOURSE: ["Remboursé", "neutral"],
  // Caisse
  OUVERTE: ["Ouverte", "success"],
  CLOTUREE: ["Clôturée", "neutral"],
  EN_COURS: ["En cours", "warning"],
  TERMINEE: ["Terminée", "success"],
  ACTIVE: ["Active", "success"],
  // Achats
  BROUILLON: ["Brouillon", "neutral"],
  PROPOSEE: ["Proposée", "warning"],
  APPROUVEE: ["Approuvée", "success"],
  REJETEE: ["Rejetée", "danger"],
  CONVERTIE: ["Convertie en commande", "success"],
  ENVOYEE: ["Envoyée", "info"],
  PARTIELLEMENT_RECUE: ["Partiellement reçue", "warning"],
  CLOSE: ["Close", "neutral"],
  RAPPROCHEE: ["Rapprochée", "success"],
  ECART: ["Écart", "danger"],
  NON_VERIFIE: ["Non vérifié", "warning"],
  VERIFIE: ["Vérifié", "success"],
  REJETE: ["Rejeté", "danger"],
  CONFORME: ["Conforme", "success"],
  NON_CONFORME: ["Non conforme", "danger"],
  A_CONTROLER: ["À contrôler", "warning"],
  NON_CONCLUANT: ["Non concluant", "warning"],
  // Stocks
  EXPEDIE: ["Expédié", "accent"],
  RECU: ["Reçu", "success"],
  ACTIF: ["Actif", "success"],
  BLOQUE: ["Bloqué", "danger"],
  RAPPELE: ["Rappelé", "danger"],
  EPUISE: ["Épuisé", "neutral"],
  DISPONIBLE: ["Disponible", "success"],
  A_INSPECTER: ["À inspecter", "warning"],
  QUARANTAINE: ["En quarantaine", "warning"],
  ENDOMMAGE: ["Endommagé", "danger"],
  RESOLUE: ["Résolue", "success"],
  // Registre
  SOUMIS: ["Soumis", "info"],
  CONFIRME: ["Confirmé", "success"],
  INCONNU: ["Inconnu", "warning"],
  PUBLIE: ["Publié", "success"],
  ERREUR: ["Erreur", "danger"],
  SANS_OBJET: ["Sans objet", "neutral"],
  VERIFIE_INDEPENDAMMENT: ["Vérifié indépendamment", "success"],
  SIGNE: ["Signé", "info"],
  ADMISE: ["Admise", "success"],
  CANDIDATE: ["Candidate", "warning"],
  SUSPENDUE: ["Suspendue", "danger"],
  RETIREE: ["Retirée", "neutral"],
  REVOQUEE: ["Révoquée", "danger"],
  // Automatisations
  PRISE_EN_CHARGE: ["Prise en charge", "info"],
  IGNOREE: ["Ignorée", "neutral"],
  EXECUTEE: ["Exécutée", "success"],
  EXPIREE: ["Expirée", "neutral"],
  // Rappels / retours
  OUVERT: ["Ouvert", "warning"],
  CLOS: ["Clos", "neutral"],
  A_FAIRE: ["À faire", "warning"],
  FAITE: ["Faite", "success"],
  INSPECTE: ["Inspecté", "info"],
  NON_REMBOURSE: ["Non remboursé", "warning"],
  PRELEVE: ["Prélevé", "success"],
  A_PRELEVER: ["À prélever", "warning"],
};

export function statusLabel(code: string | null | undefined): string {
  if (!code) return "—";
  return S[code]?.[0] ?? code.replaceAll("_", " ").toLowerCase().replace(/^./, (c) => c.toUpperCase());
}
export function statusTone(code: string | null | undefined): Tone {
  if (!code) return "neutral";
  return S[code]?.[1] ?? "neutral";
}

export const PAYMENT_METHODS: Record<string, string> = {
  ESPECES: "Espèces",
  CARTE_SIMULEE: "Carte (terminal simulé)",
  AVOIR: "Avoir",
  VIREMENT_SIMULE: "Virement (simulé)",
};

export const CHANNELS: Record<string, string> = { MAGASIN: "Magasin", WEB: "En ligne", PRO: "Professionnel" };
export const FULFILMENT: Record<string, string> = { RETRAIT: "Retrait en magasin", LIVRAISON: "Livraison" };

export const ROLE_LABELS: Record<string, string> = {
  admin: "Administrateur",
  directeur: "Direction",
  responsable_magasin: "Responsable de magasin",
  caissier: "Caissier·ère",
  preparateur: "Préparateur·rice",
  acheteur: "Acheteur·se",
  responsable_achats: "Responsable des achats",
  qualite: "Qualité",
  analyste: "Analyste",
  equipement: "Compte d'équipement",
};

export const DEMO_USERS: { username: string; label: string }[] = [
  { username: "admin", label: "Administration (toutes permissions)" },
  { username: "direction", label: "Direction" },
  { username: "magasin.paris", label: "Responsable magasin Paris" },
  { username: "caisse.paris", label: "Caisse Paris" },
  { username: "caisse.lyon", label: "Caisse Lyon" },
  { username: "prepa.orleans", label: "Préparation entrepôt Orléans" },
  { username: "prepa.paris", label: "Préparation Paris" },
  { username: "achats", label: "Acheteur" },
  { username: "achats.resp", label: "Responsable des achats" },
  { username: "qualite", label: "Qualité" },
  { username: "analyste", label: "Analyste" },
];

export const SEVERITY: Record<string, { label: string; tone: Tone; icon: "critical" | "warning" | "info" }> = {
  CRITIQUE: { label: "Critique", tone: "danger", icon: "critical" },
  ATTENTION: { label: "Attention", tone: "warning", icon: "warning" },
  INFO: { label: "Information", tone: "info", icon: "info" },
  INFORMATION: { label: "Information", tone: "info", icon: "info" },
};

export const LIVE_LABELS: Record<string, string> = {
  connexion: "Connexion temps réel",
  "stock.mouvement": "Mouvement de stock",
  "stock.reservation": "Réservation de stock",
  "stock.exception": "Exception de stock",
  "commande.statut": "Commande : changement de statut",
  "commande.preparation": "Préparation de commande",
  "achat.commande": "Commande fournisseur",
  "achat.reception": "Réception fournisseur",
  alerte: "Alerte",
  paiement: "Paiement",
  rappel: "Rappel de lot",
  "tracabilite.confirme": "Traçabilité : confirmé sur le registre",
  "tracabilite.declare": "Traçabilité : événement déclaré",
  "tracabilite.rejete": "Traçabilité : rejeté par le registre",
  "equipement.observation": "Observation d'équipement",
  "equipement.rfid": "Lecture RFID",
  "caisse.vente": "Vente en caisse",
};

export const MOVEMENT_SIGN_HELP = "Quantité signée : positive = entrée dans l'emplacement, négative = sortie.";
