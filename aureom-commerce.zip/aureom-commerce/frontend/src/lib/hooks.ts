import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, ApiError, errorMessage } from "../api/client";
import { useLiveEvents } from "../state/live";

export interface ApiState<T> {
  data: T | null;
  error: ApiError | Error | null;
  loading: boolean;
  reload: () => void;
  setData: (d: T | null) => void;
}

/**
 * Charge une ressource GET. `path` null = ne rien charger.
 * `live` : types d'événements WebSocket qui déclenchent un rechargement (regroupés sur 500 ms).
 */
export function useApi<T>(path: string | null, live?: string[]): ApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | Error | null>(null);
  const [loading, setLoading] = useState<boolean>(path !== null);
  const [tick, setTick] = useState(0);
  const reload = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => {
    if (path === null) {
      setLoading(false);
      return;
    }
    const ctl = new AbortController();
    setLoading(true);
    api<T>(path, { signal: ctl.signal })
      .then((d) => {
        setData(d);
        setError(null);
      })
      .catch((e: unknown) => {
        if (e instanceof DOMException && e.name === "AbortError") return;
        setError(e instanceof Error ? e : new Error(errorMessage(e)));
      })
      .finally(() => {
        if (!ctl.signal.aborted) setLoading(false);
      });
    return () => ctl.abort();
  }, [path, tick]);

  const timer = useRef<number | null>(null);
  useLiveEvents(live ?? [], () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(reload, 500);
  });
  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current);
  }, []);

  return { data, error, loading, reload, setData };
}

/**
 * Clé d'idempotence liée à UNE intention utilisateur (un paiement, une vente, une commande…).
 * - get() : crée la clé au premier appel, puis renvoie toujours la même tant que l'intention n'est pas « consommée ».
 * - consume() : à appeler après une réponse définitive du serveur (succès ou refus métier) ; la prochaine intention aura une nouvelle clé.
 * En cas d'erreur réseau / 5xx, NE PAS consommer : une nouvelle tentative réutilise la même clé (aucun double encaissement).
 */
export function useIntentKey(prefix: string) {
  const ref = useRef<string | null>(null);
  const get = useCallback(() => {
    if (!ref.current) ref.current = `${prefix}-${crypto.randomUUID()}`;
    return ref.current;
  }, [prefix]);
  const consume = useCallback(() => {
    ref.current = null;
  }, []);
  const peek = useCallback(() => ref.current, []);
  return useMemo(() => ({ get, consume, peek }), [get, consume, peek]);
}

export interface Action {
  busy: boolean;
  error: ApiError | Error | null;
  setError: (e: ApiError | Error | null) => void;
  /** Exécute fn sauf si une exécution est déjà en cours (protection double clic). */
  run: <R>(fn: () => Promise<R>) => Promise<R | undefined>;
}

export function useAction(): Action {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | Error | null>(null);
  const inflight = useRef(false);
  const run = useCallback(async <R,>(fn: () => Promise<R>): Promise<R | undefined> => {
    if (inflight.current) return undefined;
    inflight.current = true;
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } catch (e) {
      setError(e instanceof Error ? e : new Error(errorMessage(e)));
      return undefined;
    } finally {
      inflight.current = false;
      setBusy(false);
    }
  }, []);
  return { busy, error, setError, run };
}

/** Exécute une requête idempotente : consomme la clé sauf erreur « rejouable ». */
export async function withIntent<R>(intent: { get: () => string; consume: () => void }, fn: (key: string) => Promise<R>): Promise<R> {
  const key = intent.get();
  try {
    const r = await fn(key);
    intent.consume();
    return r;
  } catch (e) {
    if (!(e instanceof ApiError && e.retryable)) intent.consume();
    throw e;
  }
}

export function useInterval(fn: () => void, ms: number): void {
  const saved = useRef(fn);
  saved.current = fn;
  useEffect(() => {
    const id = window.setInterval(() => saved.current(), ms);
    return () => window.clearInterval(id);
  }, [ms]);
}

/** Paramètre d'URL « onglet » persistant. */
export function useQueryState(name: string, initial: string): [string, (v: string) => void] {
  const read = () => new URLSearchParams(window.location.search).get(name) ?? initial;
  const [v, setV] = useState(read);
  const set = useCallback(
    (nv: string) => {
      const p = new URLSearchParams(window.location.search);
      if (nv === initial) p.delete(name);
      else p.set(name, nv);
      const s = p.toString();
      window.history.replaceState(null, "", window.location.pathname + (s ? `?${s}` : ""));
      setV(nv);
    },
    [name, initial],
  );
  return [v, set];
}
