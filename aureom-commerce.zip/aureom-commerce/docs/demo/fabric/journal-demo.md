# Démonstration AUREOM COMMERCE — Maison & Marché (enseigne fictive)
Date d'exécution : 28/11/2026 12:46 UTC · registre : fabric
Registre : Hyperledger Fabric — canal « tracabilite » (réseau permissionné multi-organisations) — disponible : True

## 1. Création d'un produit et de ses conditionnements
✔ Article MIEL-LAV-250 créé (pot / paquet 6 / carton 24 / palette 1 440). 3 cartons = 72 pièces.
✔ Chaîne incohérente refusée : « Le niveau carton doit contenir un nombre entier du niveau inférieur (rapport 2,5) »
✔ Prix magasin 7,90 € TTC, tarif pro 139,00 € HT le carton (TVA 5,5 % configurée).

## 2. Commande fournisseur
✔ Proposition PA-2026-00001 : 100 pots de confiture arrondis à 5 cartons (120 pots). Total 1 116,00 € HT.
✔ Approbation par l'acheteur refusée (NON_AUTORISE) ; approuvée par la responsable des achats.
✔ Commande fournisseur CF-2026-00001 émise (envoi simulé), livraison prévue le 02/12/2026.

## 3. Réception d'un lot
✔ Le fournisseur a publié depuis SON nœud : création du lot (RECORDED, tx b52310fd8df1a5ce…) puis expédition (RECORDED).
✔ Réception REC-2026-00001 : 9 cartons sur 10 (livraison partielle), 6 pots endommagés mis en quarantaine, statut commande « PARTIELLEMENT_RECUE ».
✔ Certificat déposé : statut d'authenticité « NON_VERIFIE » (non présumé authentique).
✔ Stock entrepôt miel : physique 216, vendable 210, attendu 24 (reliquat 1 carton).

## 4. Publication d'un événement signé
Avant publication : registre « EN_ATTENTE » (opération locale déjà finalisée).
✔ Événement RECEIPT 411c21a4-811e-4660-8b40-8bf30c67f202 signé par la clé « maisonmarche-2026-01 », confirmé : transaction 0fb56023178d378d7813…, bloc 65 (0.7 s).
  Précédent (expédition fournisseur) : 0956671e-62ef-44a8-8511-b8451633b23e
  ✔ Déclaré — Déclaration de MaisonMarcheMSP enregistrée le 28/11/2026 à 12:46 (UTC).
  ✔ Signé — La clé « maisonmarche-2026-01 » a signé exactement ce contenu. Cela identifie la clé, pas la personne ni la réalité physique de l'événement.
  ✔ Confirmé sur le registre — Transaction 0fb56023178d378d7813fe65c33ab6624cd8f04b4c4a2b0a7be92cf3ada8649a (bloc 65) validée selon le protocole du réseau : la déclaration est conservée et partagée, sa véracité n'est pas établie.
  ✔ Vérifié par contrôle indépendant — CONTROLE_PHYSIQUE par Nadia Roussel (Maison & Marché — Qualité) le 28/11/2026 : CONFORME

## 5. Transfert vers un magasin
✔ TR-2026-00001 expédié : attendu à Paris = 48 pots (en transit).
✔ Reçu à Paris : vendable 48 pots. Transfert interne : PostgreSQL seulement (pas d'événement sur le registre, une seule organisation concernée).

## 6. Vente en caisse
✔ Ticket TPAR-01-2026-000001 : 60,71 € TTC dont remise 4,99 € (10 % autorisés au caissier ; 20 % refusés sans responsable : NON_AUTORISE).
✔ Paiement partiel : 20,00 € espèces + 40,71 € carte simulée ****4242. Requête carte rejouée avec la même clé : même paiement (id 2), aucun double débit.
✔ Numéro de carte saisi refusé : DONNEES_CARTE_INTERDITES.
✔ Vente terminée puis 2 mouvement(s) de stock VENTE (étape distincte), 60 point(s) fidélité.
✔ Événement de capture rejoué : « deja_traite » ; événement à signature falsifiée : HTTP 400.

## 7. Commande en ligne avec réservation
✔ Commande CMD-2026-00001 réservée : miel à Paris physique 46, réservé 3, disponible 43.
✔ Seconde commande dépassant le disponible : réservation refusée (STOCK_INSUFFISANT).
✔ Paiement capturé (PAYEE) mais statut toujours « Stock réservé » : payé ≠ prêt.

## 8. Préparation et retrait
✔ Scan d'un mauvais article refusé (MAUVAIS_ARTICLE). 2 prélèvement(s) FEFO confirmés par scan.
✔ Prête : code de retrait communiqué (simulé). Mauvais code refusé (CODE_RETRAIT_INVALIDE). Statut final « Remise au client ».
  Historique : RECUE → VALIDEE → RESERVEE → EN_PREPARATION → PRETE → REMISE

## 9. Observation RFID dupliquée sans double mouvement
✔ 5 lectures du même EPC → 1 observation, 5 lectures agrégées, 0 mouvement de stock.
✔ Statut « ECART » : Passage en zone de sortie d'un article non vendu ni expédié : vérifier visuellement. Aucune vente ni sortie n'est enregistrée automatiquement.

## 10. Alerte de température simulée
  Lecture 150 °C : qualité « INVALIDE » (valeur_physiquement_improbable) — ignorée pour la décision.
✔ Alerte « Anomalie de température — STOCK-EPI » : Sonde cellule épicerie Orléans (STOCK-EPI) : 3 lectures consécutives hors plage [15.00 ; 25.00] °C sur 10 min (27,5 °C, 28,1 °C, 28,6 °C). Lots présents : CV-2611-A, CV-2702-B, CV-H-2604. Vérifier le capteur et les produits.
✔ Message MQTT/HTTP répété : doublon=True. Proposition de quarantaine en attente de décision humaine.
✔ Décision de la responsable qualité : EXECUTEE (quarantaine-STOCK-EPI).

## 11. Retour avec inspection
✔ Retour RET-2026-00001 : remboursé 44,91 € ; vendable 9 → 9 après remboursement (inchangé), → 10 après inspection « ouvert, complet » + remise en vente.
✔ Fidélité : 44 point(s) retiré(s), solde 16.
✔ Clôture de caisse : espèces attendues 165,80 €, comptées 165,80 €, écart 0,00 €.

## 12. Rappel de lot
✔ Rappel RAP-2026-00001 : stock bloqué CV-MIEL-4CA3 : 205 pièces ; ventes 1, commandes 1, clients identifiés 2.
  • [RETIRER_RAYON] Entrepôt Orléans-Saran : retirer physiquement 162 pièces du lot CV-MIEL-4CA3 et les isoler (stock système déjà bloqué) — certitude certaine
  • [RETIRER_RAYON] Magasin Paris Oberkampf : retirer physiquement 43 pièces du lot CV-MIEL-4CA3 et les isoler (stock système déjà bloqué) — certitude certaine
  • [CONTACTER_CLIENT] Contacter le client du ticket TPAR-01-2026-000001 (lot présumé par FEFO) — certitude presumee
  • [CONTACTER_CLIENT] Contacter le client de la commande CMD-2026-00001 — certitude certaine
  • [INFORMER_FOURNISSEUR] Informer Conserverie du Val et obtenir l'analyse de cause
  • [DECLARER_RAPPELCONSO] Vérifier/déclarer la fiche sur RappelConso (démarche manuelle hors prototype)
  • [AFFICHAGE_MAGASIN] Afficher l'avis de rappel dans les magasins concernés
✔ Vente d'un pot du lot rappelé refusée en caisse (LOT_BLOQUE).

## 13. Indisponibilité puis réconciliation du registre
  (coupure RÉELLE : conteneur gateway-maisonmarche arrêté)
✔ Registre indisponible : la réception REC-2026-00002 est finalisée localement (commande « RECUE »). Publication : {'publies': 0, 'doublons': 0, 'rejetes': 0, 'reportes': 0, 'erreurs': 4}.
  Réception e370aa1b… : registre « EN_ATTENTE », tentatives 1, erreur « LEDGER_UNAVAILABLE »
  Rappel 3a570c31… : registre « EN_ATTENTE », tentatives 1, erreur « LEDGER_UNAVAILABLE »
  Expédition client 107b63c6… : registre « EN_ATTENTE », tentatives 1, erreur « LEDGER_UNAVAILABLE »
  Expédition client 17993d38… : registre « EN_ATTENTE », tentatives 1, erreur « LEDGER_UNAVAILABLE »
  (passerelle redémarrée)
✔ Retour du registre : 6/6 événements de cette exécution confirmés. Réconciliation : 6 événement(s) local(aux) vérifié(s), 0 confirmé(s) par réconciliation, 1 événement(s) externe(s) importé(s), 11 anomalie(s).
  Dont 11 anomalie(s) « orphelin » : événements de Maison & Marché laissés sur le registre Fabric par des exécutions précédentes de la démo (la base locale a été réinitialisée, pas le registre). C'est exactement le cas d'une restauration de sauvegarde : ils sont signalés et réimportés.

## 14. Export d'un rapport de traçabilité
✔ Rapport du lot CV-MIEL-4CA3 : 5 événements partagés (dont 2 émis par le fournisseur), 12 mouvements internes, 3 destination(s).
  Fichiers : rapport-tracabilite-miel.json / .html / .csv

## Indicateurs (extrait)
  Chiffre d'affaires TTC : 96,31 €
  Chiffre d'affaires HT : 86,15 €
  Retours remboursés (TTC) : 44,91 €
  Encaissements nets : 51,40 €
  Marge brute (HT) : 39,65 €
  Bénéfice : non disponible
  Lacunes : aucune

Démonstration terminée en 11.2 s — toutes les vérifications ont réussi.
