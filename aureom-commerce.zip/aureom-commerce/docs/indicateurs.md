# Indicateurs (`GET /api/analyses/indicateurs?debut=&fin=&site_id=`)

Chaque indicateur est renvoyé avec sa définition. La réponse inclut aussi la **fraîcheur** des données (dernier mouvement, dernière vente, dernière confirmation sur le registre, dernière observation de capteur, dernière prévision, dernière réconciliation) et la liste des **lacunes** (calculs partiels, données manquantes ou synthétiques).

| Code | Indicateur | Définition |
|---|---|---|
| `ca_ttc` / `ca_ht` | Chiffre d'affaires | Tickets terminés + commandes remises ou livrées sur la période, hors frais de port, **avant** retours |
| `retours_rembourses` | Retours remboursés | Montants TTC remboursés sur retours, à la date du retour |
| `encaissements_nets` | Encaissements | Paiements **capturés** − remboursements effectués sur la période. Diffère du CA : acomptes, échéances professionnelles, décalages |
| `marge_brute` | Marge brute HT | CA HT des lignes dont le coût est connu − coût moyen pondéré d'achat **figé à la vente**. Les lignes sans coût sont exclues et signalées |
| `benefice` | Bénéfice | **Non calculé** : les charges d'exploitation (personnel, loyers, énergie, logistique) ne sont pas dans le système |
| `valeur_stock` | Valeur du stock | Σ physique × coût moyen pondéré |
| `ruptures` | Ruptures | Positions suivies (point de commande défini) dont le disponible est ≤ 0 |
| `reservations_a_reaffecter` | Réservations à réaffecter | Positions où les réservations dépassent le vendable (blocage ou perte après réservation) |
| `rotation` | Rotation | Coût des ventes de la période ÷ valeur actuelle du stock (approximation : pas d'historique de valorisation quotidien) |
| `pertes` | Pertes et démarque | Mouvements PERTE et écarts d'inventaire négatifs, valorisés au coût |
| `delai_fournisseur` | Délai fournisseur | Moyenne (première réception − date de commande) et ponctualité par rapport à la date promise |
| `preparation` | Délai de préparation | De « stock réservé » à « prête » (retrait) ou « expédiée » (livraison) |
| `taux_retour` | Taux de retour | Unités retournées ÷ unités vendues en caisse |
| `tracabilite_en_attente` | Traçabilité non confirmée | Événements déclarés et signés mais pas encore confirmés sur le registre, avec répartition par état, ancienneté du plus vieux et transferts de garde provisoires |
| `ecarts_rapprochement` | Écarts de rapprochement | Factures fournisseurs en écart + sessions de caisse avec écart + exceptions de stock ouvertes (+ anomalies de la dernière réconciliation du registre) |
| `alertes_ouvertes` | Alertes | Alertes de règles non résolues |

Conventions : montants en centimes d'euro (affichage `1 234,56 €`), quantités en unité de base, dates en UTC dans l'API et affichées en heure de Paris dans l'interface.
