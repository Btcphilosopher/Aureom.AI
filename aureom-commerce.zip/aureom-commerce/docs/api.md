# API AUREOM COMMERCE

- Spécification complète : `docs/openapi.json` (133 routes, générée depuis le code). En fonctionnement, Swagger est sur `http://localhost:8000/docs` et ReDoc sur `/redoc`.
- La passerelle du registre a sa propre API REST : `ledger/README.md` §5.

## Conventions

| Sujet | Règle |
|---|---|
| Authentification | `POST /api/auth/connexion {username, password}` → `{jeton}` ; ensuite `Authorization: Bearer <jeton>`. Le jeton est opaque et haché en base, il expire (12 h) et peut être révoqué. Les comptes d'équipement n'ont pas de mot de passe utilisable : leur jeton est émis par un administrateur (`POST /api/admin/comptes-equipement/{compte}/jeton`). |
| Permissions | Permissions par rôle (`GET /api/admin/permissions`) et périmètre de sites par utilisateur. Réponse 403 avec `{code: "NON_AUTORISE", message}`. |
| Erreurs | `{code, message (français), details}`. 400 pour une règle métier, 401, 403, 404, 409 pour un conflit (idempotence, contrainte, stock). |
| Idempotence | En-tête `Idempotency-Key` **obligatoire** pour les paiements, remboursements et remboursements de retour ; recommandé pour les créations de vente et de commande. Même clé et même requête : même résultat, sans nouvel effet. Même clé et requête différente : 409 `IDEMPOTENCE_CONFLIT`. |
| Montants | Entiers en centimes d'euro. Un prix est TTC si la liste `tax_inclusive` (MAGASIN, WEB), HT sinon (PRO). |
| Quantités | Chaînes décimales en unité de base (pièce, kg…), 3 décimales au plus ; pièces entières. |
| Dates | ISO 8601 UTC. |
| Temps réel | `ws://…/ws?token=<jeton>` : messages `{type, data}`, émis au commit — `stock.mouvement`, `stock.reservation`, `stock.exception`, `commande.statut`, `commande.preparation`, `paiement`, `caisse.vente`, `alerte`, `tracabilite.declare`, `tracabilite.confirme`, `tracabilite.rejete`, `equipement.observation`, `equipement.rfid`, `rappel`, `achat.commande`, `achat.reception`. |

## Parcours principaux

```
Catalogue   POST /api/catalogue/articles → POST /api/catalogue/fournisseurs → POST /api/catalogue/prix
Achats      POST /api/achats/propositions → POST /api/achats/propositions/{id}/decision (→ commande)
            POST /api/achats/documents (multipart) → POST /api/achats/commandes/{id}/receptions
            POST /api/achats/receptions/lignes/{id}/controle → POST /api/achats/commandes/{id}/factures
Stocks      GET /api/stocks/positions · /soldes · /mouvements · /lots · /exceptions · /controle-coherence
            POST /api/stocks/transferts (lot affecté en FEFO si absent) → /{id}/expedier → /{id}/recevoir · /{id}/annuler
            POST /api/stocks/mouvements/{id}/correction · /etat-qualite · /pertes · /inventaires
Caisse      POST /api/caisse/sessions → POST /api/caisse/ventes → /{id}/lignes → /lignes/{id}/remise|annulation
            → /{id}/paiements (Idempotency-Key) → /{id}/valider (ticket) ; POST /api/caisse/sessions/{id}/cloture
Paiements   POST /api/paiements/webhook (en-tête Sim-Signature: t=…,v1=HMAC-SHA256) · /{id}/remboursement
Commandes   POST /api/commandes → /{id}/valider → /reserver → /preparer → /taches/{id}/prelever
            → /{id}/prete (code de retrait) → /{id}/remettre | /{id}/expedier → /{id}/livree ; /{id}/paiements
            POST /api/commandes/fractionnement/proposition
Clients     POST /api/clients · GET /api/clients/{id} · /{id}/consentements · /{id}/fidelite · /{id}/anonymiser
Retours     POST /api/retours → /lignes/{id}/inspection → /{id}/remboursement
Rappels     POST /api/rappels · GET /api/rappels/{id} · /taches/{id} · /{id}/journal · /{id}/cloture
Traçabilité GET /api/tracabilite/evenements[/{id}] · POST /evenements · /evenements/{id}/verifications
            GET /registre/etat · POST /registre/publier · /registre/reconcilier · /cles/* · /lots/{id}/rapport?format=json|html|csv
            GET /api/tracabilite/limites
Équipements POST /api/equipements/observations (compte d'équipement) · GET /api/equipements/observations-rfid
            GET /api/equipements/balances/{code}/pesee · /etiquettes/{variante}
Automat.    GET/PATCH /api/automatisations/regles · POST /executer · /alertes · /propositions/{id}/decision
            POST /previsions · /risque-rupture · /anomalies · /repartition
Analyses    GET /api/analyses/indicateurs · /fournisseurs ; GET /api/tableau-de-bord
Admin       /api/admin/utilisateurs · /journal · /permissions · /demo/panne-registre ; /api/organisations · /api/sites
```

## Exemple : paiement idempotent

```bash
curl -X POST http://localhost:8000/api/caisse/ventes/12/paiements \
  -H "Authorization: Bearer $JETON" -H "Idempotency-Key: 6f1c…" -H "Content-Type: application/json" \
  -d '{"method":"CARTE_SIMULEE","amount_cents":4071,"card_token":"tok_sim_accepte"}'
```

Jetons du terminal simulé : `tok_sim_accepte`, `tok_sim_refuse`, `tok_sim_attente` (aucun événement : le paiement reste en attente jusqu'à un événement signé tardif). Toute valeur ressemblant à un numéro de carte (13 à 19 chiffres valides selon Luhn) est refusée (`DONNEES_CARTE_INTERDITES`).
