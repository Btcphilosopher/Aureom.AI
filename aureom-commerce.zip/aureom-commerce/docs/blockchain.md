# Base de données, registre partagé et limites de la preuve

## 1. Qui fait quoi

| Donnée / opération | PostgreSQL | Registre Fabric |
|---|---|---|
| Catalogue, prix, taxes, clients, consentements, commandes, réservations, stocks, paiements, documents, permissions | ✔ (source de vérité) | ✘ |
| Mouvements internes (transfert entrepôt → magasin, préparation, inventaire) | ✔ | ✘ : une seule organisation est concernée, aucun intérêt à partager |
| Événements de traçabilité partagés entre organisations : création de lot, expédition fournisseur, réception, contrôle, transfert de garde, transformation, expédition client, rappel, correction, contestation | ✔ (copie locale, détails hors chaîne) | ✔ (enveloppe signée, empreintes) |
| Pièces justificatives (certificats, bons de livraison) | ✔ stockage objet privé | empreinte SHA-256 seulement |
| Données personnelles, coordonnées, prix d'achat, quantités commerciales | ✔ | **jamais**. Le chaincode refuse tout champ hors schéma, les détails ne sont publiés que sous forme d'empreinte **salée**, et les lieux sont des codes GLN ou site, pas du texte libre |

## 2. Ce que la blockchain apporte, et ce qu'elle coûte

**Apports, dans ce périmètre :**
- **Historique partagé** : Maison & Marché, Atelier Lumière et la Conserverie du Val lisent le même historique, sans dépendre de la base de l'un d'eux.
- **Pas de réécriture unilatérale** : un événement validé (politique d'endossement MAJORITY, 2 organisations sur 3, puis ordonnancement Raft) ne peut pas être modifié ni retiré par une seule organisation. Une correction est un nouvel événement lié.
- **Imputabilité** : chaque événement porte la signature Ed25519 de l'organisation émettrice, vérifiée par le chaincode avec la clé publique inscrite sur le registre, en plus de l'identité X.509 Fabric de la soumission.
- **Chaînage interentreprises** : par exemple « expédition du fournisseur → notre réception » (`previousEventId`). Un transfert de garde reste provisoire tant que la contrepartie ne l'a pas confirmé.

**Coûts mesurés ou connus :**
- **Latence** : environ 280 ms par aller-retour `RecordEvent` jusqu'à la validation du bloc (médiane mesurée, `BatchTimeout` fixé à 250 ms pour la démonstration ; 2 s par défaut dans Fabric). Elle est sans effet sur les opérations, qui n'attendent jamais le registre.
- **Exploitation** : 3 orderers, 1 pair par organisation, 3 serveurs de chaincode et 3 passerelles, soit 12 conteneurs. Il faut aussi gérer les certificats (Fabric CA et HSM en production), les sauvegardes, les montées de version et la supervision.
- **Gouvernance** : admission et retrait des membres, signatures multiples des mises à jour de canal, règlement des litiges, évolution des schémas (`gouvernance.md`).
- **Complexité applicative** : boîte d'envoi, reprises, issue inconnue, réconciliation, états intermédiaires visibles dans l'interface.

**Quand la blockchain n'est pas utile** : opérations internes, ventes, prix, stocks. Pour une traçabilité purement interne, un journal append-only PostgreSQL suffit. Si toutes les parties font confiance à un même opérateur, une base partagée suffit aussi.

## 3. Limites de la preuve (affichées dans l'interface et dans chaque rapport)

- Une **signature** identifie la **clé** qui a signé. Elle ne prouve ni qui tenait la clé, ni ce qui s'est réellement passé.
- Une **empreinte** permet de vérifier qu'un fichier est **exactement** celui qui a été référencé. Elle ne dit rien de la véracité de son contenu.
- Le **registre** conserve des **déclarations** selon son protocole (endossement, ordonnancement). Il ne garantit pas qu'elles soient vraies.
- **Aucun** de ces mécanismes ne prouve à lui seul qu'un événement physique a eu lieu.

L'application distingue quatre niveaux, toujours affichés séparément. Il n'y a aucun badge « authentique ».

| Niveau | Condition | Ce qui est établi |
|---|---|---|
| Déclaré | enregistré localement | une déclaration existe, avec son auteur et son heure |
| Signé | signature Ed25519 valide pour la clé indiquée | le contenu n'a pas changé depuis la signature par cette clé |
| Confirmé sur le registre | transaction validée, avec n° de transaction et n° de bloc | la déclaration est inscrite et partagée selon le protocole Fabric |
| Vérifié par contrôle indépendant | `IndependentVerification` CONFORME, enregistrée par une personne distincte du déclarant, avec méthode (contrôle physique, analyse de laboratoire, audit, confirmation auprès de l'émetteur) et pièce si la méthode l'exige | un contrôle humain documenté étaye la déclaration |

En mode simulation, le niveau 3 est libellé « Confirmé (registre SIMULÉ) ». Un document fournisseur déposé est `NON_VERIFIE` jusqu'à une vérification décrite.

## 4. Enveloppe (schéma 1.0)

Chaîne JSON canonique (clés triées, sans espaces), signée telle quelle (Ed25519 sur les octets UTF-8). Champs : `schemaVersion, eventId, eventType, issuerOrg, subject{kind, ref, gtin?, lot?}, occurredAt, declaredAt, previousEventId?, correctsEventId?, counterpartyOrg?, locationRef?, evidence[{sha256, kind, mediaType}], detailsDigest?, signerKeyId`. La date d'enregistrement sur le registre est l'horodatage de la transaction Fabric. L'état de confirmation est conservé localement (`ledger_status`, `ledger_tx_id`, `ledger_block`). Le contrat complet et les codes d'erreur figurent dans `ledger/README.md` §4.

## 5. Synchronisation : boîte d'envoi transactionnelle

1. L'opération métier (réception, rappel, expédition client…) écrit dans la **même transaction** l'événement signé (`trace_events`) et une ligne `ledger_outbox`. Si la transaction échoue, rien n'est publié. Si elle réussit, la publication est garantie (au moins une fois).
2. Le worker prend les lignes dues par `FOR UPDATE SKIP LOCKED` (plusieurs workers possibles), les marque `EN_COURS` avec une échéance, valide, puis appelle la passerelle.
3. Résultats :

| Réponse | État local | Suite |
|---|---|---|
| 201 RECORDED | CONFIRME (tx, bloc, horodatage) | — |
| 201 DUPLICATE (même eventId, même empreinte) | CONFIRME | rejeu sans effet : déduplication par eventId |
| 409 CONFLICT (même eventId, autre contenu) | REJETE + alerte critique | analyse humaine |
| 422 (signature, clé révoquée, champ interdit…) | REJETE + alerte | l'opération locale reste valide ; il faut corriger par un nouvel événement lié |
| 409 retryable (MVCC), 503 indisponible | EN_ATTENTE | nouvel essai avec délai exponentiel (5 s → 15 min), alerte après 12 tentatives |
| 504 / délai dépassé (issue inconnue) | INCONNU | au prochain essai, **lecture** de l'événement sur le registre avant toute resoumission |
| arrêt brutal du worker | ligne `EN_COURS` expirée → INCONNU | même traitement |

4. **Ordre** : un événement qui référence un événement local non encore confirmé (`previousEventId`, `correctsEventId`) est reporté.
5. **Réconciliation** (toutes les 60 s et à la demande) :
   - les événements locaux sont comparés au registre (absence, empreinte divergente) ;
   - les événements des autres organisations portant sur nos lots sont importés avec leur signature vérifiée hors chaîne ;
   - les événements de **notre** organisation présents sur le registre mais absents localement (après une restauration de sauvegarde, par exemple) sont signalés comme **orphelins** et réimportés pour revue ;
   - les transferts de garde provisoires sont confirmés ou contestés selon les événements de la contrepartie.

## 6. Quand le registre est indisponible

- **Continuent normalement** : ventes, paiements, réceptions, transferts internes, commandes, retours. Les blocages de rappel sont immédiats en local.
- **Restent provisoires** : les événements partagés (déclarés et signés, « en attente » dans l'interface) et les transferts de garde interentreprises, jusqu'à la confirmation de la contrepartie.
- **Jamais affiché** : « confirmé sur le registre » pour une écriture seulement locale.

Ce comportement a été démontré par une coupure **réelle** (arrêt du conteneur `gateway-maisonmarche`, étape 13 de la démo en mode Fabric), puis vérifié par des tests automatisés (panne simulée, issue inconnue, arrêt brutal du worker, restauration de sauvegarde).
