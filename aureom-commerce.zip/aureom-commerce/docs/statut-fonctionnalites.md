# Statut des fonctionnalités

Légende :
- **Opérationnel** : implémenté et testé dans ce prototype.
- **Simulé** : fonctionne avec un simulateur à la place du système réel.
- **Intégré** : relié à un composant réel tiers et testé avec lui.
- **Partiel** : une partie seulement est réalisée (précisée dans la ligne).
- **Reporté** : non réalisé.

| Domaine | Fonction | Statut | Remarque |
|---|---|---|---|
| Catalogue | Familles, articles, variantes, SKU, GTIN, conditionnements pièce/paquet/carton/palette, unités, fournisseurs, documents | Opérationnel | ratios entiers et clés GTIN contrôlés |
| Catalogue | Prix par canal datés, historique non modifiable, régimes de TVA datés, prix de référence 30 j | Opérationnel | taux de TVA **configurés** (à vérifier, art. 278 et suivants du CGI) |
| Stocks | Multisite, emplacements, lots, DLC/DDM, états qualité, journal, corrections liées, transferts, inventaires, FEFO | Opérationnel | numéros de série : registre EPC/série, sans solde par numéro de série (partiel) |
| Stocks | Physique / vendable / réservé / disponible / attendu, réservations concurrentes sans double allocation | Opérationnel | testé avec 20 réservations concurrentes |
| Achats | Besoin → proposition → approbation (plafonds, séparation des tâches) → commande → réception partielle → contrôle → rapprochement à 3 voies → retour fournisseur | Opérationnel | l'envoi de la commande au fournisseur est **simulé** (pas d'EDI) |
| Achats | Documents fournis, statut d'authenticité « non vérifié » par défaut, vérification décrite | Opérationnel | |
| Caisse | Session, scan et recherche, remises autorisées, annulations, paiements partiels, ticket de démonstration, clôture et écart | Opérationnel | **non certifié** (NF525 ou équivalent), voir `conformite-et-cadre.md` |
| Paiements | Prestataire et terminal carte | Simulé | HMAC, rejeu et idempotence réellement implémentés ; aucun prestataire réel |
| Paiements | Espèces, avoir, remboursements plafonnés | Opérationnel | l'avoir n'émet pas de bon (reporté) |
| Commandes | Magasin, en ligne, livraison, retrait, professionnelle (HT, échéance) ; états explicites ; paiement ≠ prêt | Opérationnel | transporteur et notification client **simulés** |
| Commandes | Commandes fractionnées | Partiel | règle de proposition explicite ; création multi-commandes manuelle |
| Clients | Coordonnées protégées, consentements séparés, fidélité ajustée au remboursement, anonymisation | Opérationnel | utilisation des points (bons) reportée |
| Retours | Inspection, disposition explicite, remboursement distinct sans remise en stock | Opérationnel | |
| Rappels | Blocage multisite, destinations avec certitude, tâches, journal, événement RECALL | Opérationnel | déclaration RappelConso et envoi des messages : **manuels / simulés** |
| Registre | Hyperledger Fabric 2.5.16, 3 organisations, 3 orderers Raft, chaincode Go, passerelles REST | Intégré | testé de bout en bout (45/45) et avec l'application (démo complète, test d'intégration) |
| Registre | Mode simulation (PostgreSQL) | Simulé | étiqueté « non distribué » dans l'interface et les rapports |
| Registre | Boîte d'envoi, reprises, doublons, issue inconnue, réconciliation, orphelins, transferts provisoires | Opérationnel | |
| Registre | Clés : inscription, rotation, révocation | Opérationnel | stockage en fichier secret ; KMS/HSM **reporté** |
| Équipements | RFID, température, balance, convoyeur, pick-to-light via MQTT (Mosquitto, ACL) | Simulé + intégré | simulateurs ; broker et pont réels testés |
| Équipements | Lecteur de codes-barres | Opérationnel | mode « clavier » dans l'interface caisse et préparation |
| Équipements | Étiquettes électroniques | Partiel | contenu calculé (prix, prix de référence) ; envoi vers les étiquettes reporté |
| Automatisation | Règles réappro, stock faible, péremption, retard fournisseur, écart d'inventaire, température | Opérationnel | |
| Modèles | Prévision évaluée (période distincte, MASE, intervalles), anomalies, risque de rupture, répartition | Opérationnel | historique **synthétique** : aucune valeur prédictive démontrée |
| Analyses | Indicateurs définis, fraîcheur, lacunes | Opérationnel | rotation approximative (pas d'historique de valorisation) |
| Stockage | SeaweedFS S3 privé, stockage local protégé | Intégré | testé dans Docker Compose |
| Sécurité | TLS de bout en bout, SSO, MFA, chiffrement des colonnes sensibles | Reporté | à prévoir avant tout usage réel |
| Conformité | Certification de caisse, archivage fiscal 6 ans, signature des clôtures | Reporté | |
