# Automatisations, prévisions et modèles

## Règles transparentes (`app/modules/automation/rules.py`)

Les paramètres sont visibles et modifiables (`PATCH /api/automatisations/regles/{code}`). Les alertes sont dédupliquées : une seule alerte ouverte par clé. Leur message en français contient les chiffres qui les justifient.

| Règle | Déclencheur | Sortie |
|---|---|---|
| REAPPRO | disponible + attendu < point de commande | **proposition** d'achat jusqu'au stock maximum, arrondie au conditionnement d'achat, avec fournisseur préféré et coût estimé |
| STOCK_FAIBLE | couverture (disponible ÷ demande moyenne sur 28 j) ≤ N jours | alerte « Attention », ou « Critique » si le disponible est ≤ 0 |
| PEREMPTION | DLC/DDM dans moins de N jours (30 par défaut) | alerte « Attention », ou « Critique » si la date est dépassée (retrait de vente pour une DLC) |
| RETARD_FOURNISSEUR | date prévue dépassée sans réception complète | alerte |
| ECART_INVENTAIRE | écart absolu > N % de l'attendu (5 par défaut) | alerte |
| TEMPERATURE | N lectures **valides** consécutives hors de la plage de l'emplacement (3 par défaut) ; silence du capteur > M minutes | alerte « Critique » et **proposition** de quarantaine des lots présents |

Une lecture `SUSPECT` ou `INVALIDE` (valeur improbable, unité inattendue, horodatage futur ou tardif, capteur en défaut) reste visible mais n'entre jamais dans une décision.

## Approbations

| Proposition | Permission requise | Exécution |
|---|---|---|
| COMMANDE_FOURNISSEUR | `purchase.write` + `automation.approve` | crée une **proposition d'achat**, encore soumise au plafond d'approbation du rôle et à la séparation des tâches |
| TRANSFERT | `stock.transfer` + `automation.approve` | crée un transfert à l'état brouillon |
| QUARANTAINE | `quality.inspect` + `automation.approve` | déplace les lots en quarantaine |

Aucun modèle ni aucune règle n'engage seul une dépense ou ne modifie le stock.

## Prévision de demande (`forecasting.py`)

- **Données** : historique quotidien par article et par site (`demand_history`). Dans la démo, cet historique est **synthétique** (180 jours, saisonnalité hebdomadaire et bruit de Poisson). C'est indiqué dans chaque résultat (`data_quality.avertissement`) et dans les lacunes des analyses. Les jours de rupture (demande censurée) sont exclus de l'évaluation et imputés pour l'apprentissage.
- **Modèles comparés** : naïf saisonnier (même jour de la semaine précédente), moyenne mobile sur 28 jours, et lissage exponentiel à saisonnalité hebdomadaire additive (ETS(A,N,A), paramètres choisis par grille sur l'apprentissage).
- **Évaluation** : les 4 dernières semaines sont tenues à l'écart (période distincte, `train_end < test_start` vérifié par un test). L'évaluation se fait à origine glissante par pas de 7 jours, avec réestimation à chaque pas. Métriques : MAE, RMSE, biais et **MASE** (erreur rapportée à celle du naïf saisonnier sur l'apprentissage).
- **Sélection** : un modèle n'est retenu que s'il améliore le MASE du naïf saisonnier d'**au moins 5 %**. Sinon le naïf est conservé et le motif est affiché.
- **Incertitude** : intervalle à 80 % tiré des quantiles 10 % et 90 % des erreurs de validation. La couverture observée est publiée.

## Autres modèles

- **Anomalies** : score robuste (médiane / MAD × 1,4826) sur l'écart au naïf saisonnier, seuil |z| > 3,5.
- **Risque de rupture** : simulation (4 000 tirages) de la demande sur le délai d'approvisionnement, par rééchantillonnage des erreurs de validation, comparée à disponible + attendu. Résultat : probabilité, demande médiane et demande au 90e centile. Limite affichée : promotions et événements futurs non modélisés.
- **Répartition entre magasins** : équilibrage des jours de couverture du site le plus couvert vers le moins couvert, arrondi au paquet, proposé uniquement si l'écart est significatif. C'est une proposition de transfert soumise à approbation.

## Limites

- Historique synthétique : les métriques obtenues **ne disent rien** de la performance sur des données réelles.
- Pas de variables explicatives (prix, promotions, météo, calendrier scolaire).
- Une demande censurée par une rupture est exclue, pas reconstruite.
- Les modèles sont volontairement simples et lisibles. Un modèle plus riche ne serait justifié qu'à données réelles suffisantes et s'il bat les méthodes simples selon le même protocole.
