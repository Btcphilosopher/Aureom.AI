# AUREOM COMMERCE — Dépendances, versions et licences

Recherche effectuée le **2026-11-28**.

## Convention de vérification

- **vérifié le 2026-11-28** : l'information a été lue directement à la source officielle ce jour (API JSON PyPI, registre npm, proxy Go `proxy.golang.org`, tags Git via `git ls-remote`, page GitHub du projet, fichier `LICENSE` brut, API Docker Hub), ou testée en local (`docker pull` / `docker run`, import Python).
- **non vérifié** : la page officielle n'a **pas pu être chargée** depuis cet environnement (le réseau du bac à sable bloque notamment `python.org`, `devguide.python.org`, `postgresql.org`, `mosquitto.org`, `hyperledger-fabric.readthedocs.io`, `docs.docker.com`, `min.io`, `garagehq.deuxfleurs.fr`, `git.deuxfleurs.fr`, `cryptography.io`). L'information vient alors d'extraits de moteur de recherche portant sur la page officielle citée, ou de connaissances antérieures. Elle doit être relue à la source avant toute décision.

« Version retenue » = dernière version stable que l'on a pu confirmer au 2026-11-28. Un verrouillage (lockfile) est requis : ne pas utiliser `latest` en production.

---

## 1. Backend Python

| Composant | Version retenue | Licence | Capacité pertinente / remarque | Source |
|---|---|---|---|---|
| **Python** | **3.13** (image `python:3.13-slim` testée : 3.13.18) ; 3.14 possible | PSF-2.0 | Statut des branches (extraits de devguide) : **3.14 = bugfix** (fin de vie 2030-10) ; **3.13 = sécurité uniquement** (fin de vie 2029-10) ; **3.12 = sécurité uniquement**, plus d'installeurs binaires (fin de vie 2028-10). Toutes les dépendances ci-dessous déclarent 3.12, 3.13 et 3.14. `numpy` 2.5 exige Python ≥ 3.12 ; FastAPI, Starlette et SQLAlchemy 2.1 exigent ≥ 3.11. Recommandation : 3.13 (ou 3.14 pour un projet neuf), éviter 3.12. | https://devguide.python.org/versions/ (non vérifié : page non chargeable) ; classifieurs PyPI de chaque paquet (vérifié le 2026-11-28) ; image `mirror.gcr.io/library/python:3.13-slim` (vérifié le 2026-11-28) |
| **FastAPI** | **0.165.0** (publiée le 2026-11-18) | MIT | Framework API ; `requires_python >=3.11`. Toujours en 0.x : fixer la version exacte. | https://pypi.org/pypi/fastapi/json (vérifié le 2026-11-28) |
| **Starlette** | **1.10.0** (2026-10-24) | BSD-3-Clause | Couche ASGI sous FastAPI ; laisser FastAPI choisir la version compatible. | https://pypi.org/pypi/starlette/json (vérifié le 2026-11-28) |
| **Uvicorn** | **0.54.0** (2026-09-25) | BSD-3-Clause | Serveur ASGI ; `>=3.10`. | https://pypi.org/pypi/uvicorn/json (vérifié le 2026-11-28) |
| **Pydantic v2** | **2.14.4** (2026-11-19) | MIT | Validation/sérialisation ; utiliser `Decimal` pour les montants. | https://pypi.org/pypi/pydantic/json (vérifié le 2026-11-28) |
| **SQLAlchemy 2.x** | **2.1.9** (2026-11-16) | MIT | ORM style 2.0 (`select()`, `Mapped[]`), support async ; `>=3.11`. | https://pypi.org/pypi/sqlalchemy/json (vérifié le 2026-11-28) |
| **Alembic** | **1.20.1** (2026-10-22) | MIT | Migrations de schéma. | https://pypi.org/pypi/alembic/json (vérifié le 2026-11-28) |
| **psycopg 3** | **3.3.9** (2026-11-12) | **LGPL-3.0-only** | Pilote PostgreSQL (sync + async). LGPL : usage comme bibliothèque dynamique sans obligation de publier notre code ; toute modification de psycopg lui-même devrait être redistribuée sous LGPL. | https://pypi.org/pypi/psycopg/json (vérifié le 2026-11-28) |
| **cryptography** | **50.0.2** (2026-09-30) | Apache-2.0 OR BSD-3-Clause | **Ed25519** disponible (`cryptography.hazmat.primitives.asymmetric.ed25519`) : génération de clé, signature 64 octets et vérification testées en local avec 50.0.2. | https://pypi.org/pypi/cryptography/json (vérifié le 2026-11-28) ; test local (vérifié le 2026-11-28) ; doc https://cryptography.io (non vérifié : page non chargeable) |
| **PyJWT** (si JWT nécessaires) | **2.15.1** (2026-09-28) | MIT | Jetons d'accès API. L'algorithme `EdDSA` repose sur `cryptography` (connaissance antérieure, non vérifié). Toujours imposer la liste `algorithms=[...]` au décodage. | https://pypi.org/pypi/pyjwt/json (vérifié le 2026-11-28) |
| **paho-mqtt 2.x** | **2.2.0** (2026-11-04) | **EPL-2.0 OR BSD-3-Clause** (EDL-1.0 = BSD-3-Clause) | **Changement d'API v2** : `Client(mqtt.CallbackAPIVersion.VERSION2)` ; nouvelles signatures `on_connect(client, userdata, flags, reason_code, properties)`, `on_disconnect(client, userdata, flags, reason_code, properties)`, `on_subscribe(client, userdata, mid, reason_codes, properties)`, `on_publish(client, userdata, mid, reason_codes, properties)` ; `on_message` inchangé. « Version 1 of the callback is deprecated, but is still supported in version 2.x. » Testé en local : avec 2.2.0, `Client()` sans argument retombe sur VERSION1 avec un `DeprecationWarning`. **Toujours passer VERSION2 explicitement.** | https://pypi.org/pypi/paho-mqtt/json (vérifié le 2026-11-28) ; https://github.com/eclipse-paho/paho.mqtt.python/blob/master/docs/migrations.rst (vérifié le 2026-11-28) ; https://raw.githubusercontent.com/eclipse-paho/paho.mqtt.python/master/LICENSE.txt (vérifié le 2026-11-28) ; test local (vérifié le 2026-11-28) |
| **httpx** | **0.29.0** (2026-11-26) | BSD-3-Clause | Client HTTP pour les tests (`ASGITransport`) et les appels sortants. Toujours en 0.x : fixer la version exacte. | https://pypi.org/pypi/httpx/json (vérifié le 2026-11-28) |
| **pytest** | **9.2.0** (2026-10-27) | MIT | Tests. | https://pypi.org/pypi/pytest/json (vérifié le 2026-11-28) |
| **numpy** | **2.5.5** (2026-11-15) | BSD-3-Clause AND 0BSD AND MIT AND Zlib AND CC0-1.0 | Calculs de prévision/stock ; **exige Python ≥ 3.12**. Ne jamais l'utiliser pour les montants monétaires (flottants) : utiliser `decimal.Decimal`. | https://pypi.org/pypi/numpy/json (vérifié le 2026-11-28) |

## 2. Données et messagerie

| Composant | Version retenue | Licence | Capacité pertinente / remarque | Source |
|---|---|---|---|---|
| **PostgreSQL** | **17.12** (recommandé) ou **18.7** ; 16.16 encore supporté | PostgreSQL License | Fins de support (politique : 5 ans par version majeure) : **16 → 9 novembre 2028**, **17 → 8 novembre 2029**, 18 → 14 novembre 2030. Une 19.0 apparaît sur Docker Hub, mais sa sortie officielle n'a pas été confirmée. Images `postgres:17` (17.12) et `postgres:18` (18.7) tirées et testées. | https://www.postgresql.org/support/versioning/ (non vérifié : page non chargeable, extraits de recherche) ; API Docker Hub `library/postgres` et `docker run postgres --version` (vérifié le 2026-11-28) |
| **Eclipse Mosquitto 2.x** | **2.1.4** (image `eclipse-mosquitto:2`, testée : `mosquitto version 2.1.4`) ; branche 2.0 encore publiée (2.0.23) | **EPL-2.0 OR EDL-1.0** (SPDX : `EPL-2.0 OR BSD-3-Clause`) | Broker MQTT 3.1.1/5. Depuis la 2.0, aucun accès anonyme sans `listener` et `allow_anonymous` explicites (connaissance antérieure, non vérifié). Prévoir mot de passe/ACL et TLS. | https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/master/LICENSE.txt (vérifié le 2026-11-28) ; tags Git v2.1.4 (vérifié le 2026-11-28) ; https://mosquitto.org (non vérifié : page non chargeable) |

## 3. Frontend

| Composant | Version retenue | Licence | Capacité pertinente / remarque | Source |
|---|---|---|---|---|
| **React** / react-dom | **19.3.1** (2026-10-14) | MIT | UI. | https://registry.npmjs.org/react (vérifié le 2026-11-28) |
| **TypeScript** | **7.0.2** (`latest`, 2026-07-08) ; dernière 6.x = 6.0.3, dernière 5.x = 5.9.3 | Apache-2.0 | Changement de version majeure : vérifier la compatibilité de l'outillage (lint, plugins) avant d'adopter 7.x. Sinon rester sur 6.0.3. | https://registry.npmjs.org/typescript (vérifié le 2026-11-28) |
| **Vite** | **8.4.0** (2026-11-26) | MIT | Bundler/dev server ; `engines.node: ^20.19.0 \|\| >=22.12.0`. | https://registry.npmjs.org/vite (vérifié le 2026-11-28) |
| **react-router** | **8.5.3** (2026-11-24) | MIT | Routage ; `engines.node >=22.22.0`, peer `react >=19.2.7`. La branche 7 (7.18.7) reste publiée. | https://registry.npmjs.org/react-router (vérifié le 2026-11-28) |

**Node.js minimal conseillé** : ≥ 22.22 (contrainte la plus forte, celle de react-router 8). La doc Node n'a pas été consultée (non vérifié).

## 4. Hyperledger Fabric

| Composant | Version retenue | Licence | Capacité pertinente / remarque | Source |
|---|---|---|---|---|
| **Fabric 2.5 (LTS)** | **v2.5.16** (17-18 juin 2026), images `hyperledger/fabric-peer:2.5.16` et `fabric-orderer:2.5.16` | Apache-2.0 | « Hyperledger Fabric v2.5 remains the long-term support (LTS) release for production users. » Ordering Raft. | https://github.com/hyperledger/fabric/blob/main/docs/source/whatsnew.rst (vérifié le 2026-11-28) ; https://github.com/hyperledger/fabric/releases (vérifié le 2026-11-28) ; API Docker Hub (vérifié le 2026-11-28) |
| **Fabric 3.x** | **v3.1.5** (18 juin 2026, marquée « Latest » sur GitHub) | Apache-2.0 | v3.0.0 (17 sept. 2024) : **ordering BFT (SmartBFT)**, qui tolère moins d'un tiers d'opérateurs d'orderers malveillants, et **Ed25519** pour les MSP. Ces deux fonctions exigent la capability de canal `V3_0`. **Retirés** en v3 : system channel, Solo, Kafka, ancien cycle de vie des chaincodes, image `fabric-tools`. La diffusion des blocs par gossip est dépréciée. v3.1 : lectures/écritures groupées dans le chaincode (`GetMultipleStates`, write batch). La v3 n'est pas désignée LTS. | https://github.com/hyperledger/fabric/releases/tag/v3.0.0 (vérifié le 2026-11-28) ; whatsnew.rst (vérifié le 2026-11-28) |
| **fabric-contract-api-go** | **v2.2.4** (2026-10-12), module `github.com/hyperledger/fabric-contract-api-go/v2` | Apache-2.0 (doc CC-BY-4.0) | API de contrat Go ; « Fabric v2.1 or later » ; `go.mod` : `go 1.26.7`. Dépend de `fabric-chaincode-go/v2` (dernière v2.3.0). | https://proxy.golang.org/github.com/hyperledger/fabric-contract-api-go/v2/@latest (vérifié le 2026-11-28) ; https://github.com/hyperledger/fabric-contract-api-go (vérifié le 2026-11-28) |
| **@hyperledger/fabric-gateway** | **1.13.0** (2026-10-12) ; module Go `github.com/hyperledger/fabric-gateway` v1.13.0 | Apache-2.0 | Client applicatif (Go, Node/TypeScript, Java) pour Fabric v2.4+ via le service Gateway du peer ; `engines.node >=22.12.0`. | https://registry.npmjs.org/@hyperledger/fabric-gateway (vérifié le 2026-11-28) ; https://github.com/hyperledger/fabric-gateway (vérifié le 2026-11-28) |
| **fabric-sdk-node** (`fabric-network` 2.2.20) | **À NE PAS UTILISER** | Apache-2.0 | README : « This API is deprecated as of Fabric v2.5 » ; pour Fabric v2.4 et suivants, utiliser la Fabric Gateway client API. Dépôt archivé le 22 avril 2025. | https://github.com/hyperledger/fabric-sdk-node (vérifié le 2026-11-28) ; https://registry.npmjs.org/fabric-network (vérifié le 2026-11-28) |
| **Chaincode-as-a-service** | Builder `ccaas` intégré à l'image peer depuis **Fabric 2.4.1** | Apache-2.0 | Le chaincode tourne comme un **serveur** (Go : `shim.ChaincodeServer`) que le peer contacte. `connection.json` : `address` (host:port), `dial_timeout` (défaut 3s), `tls_required` (défaut true), `client_auth_required`, `client_key`, `client_cert`, `root_cert`, `domain`. `core.yaml` v2.5.16 déclare `externalBuilders: - name: ccaas_builder, path: /opt/hyperledger/ccaas_builder`. | https://github.com/hyperledger/fabric/blob/main/docs/source/cc_service.md (vérifié le 2026-11-28) ; https://github.com/hyperledger/fabric-samples/blob/main/test-network/CHAINCODE_AS_A_SERVICE_TUTORIAL.md (vérifié le 2026-11-28) ; https://raw.githubusercontent.com/hyperledger/fabric/v2.5.16/sampleconfig/core.yaml (vérifié le 2026-11-28) |

**Choix pour le prototype** : Fabric **2.5.16 (LTS)** avec ordering Raft, Fabric Gateway 1.13.0 et chaincode Go en mode CCaaS. Passer à 3.1.x seulement si l'ordering BFT ou les certificats Ed25519 deviennent nécessaires : cela demande la capability `V3_0` et l'abandon des fonctions retirées. Note : si l'application signe en Ed25519 côté AUREOM, cela ne vaut pas pour les identités MSP de Fabric 2.5, qui restent en ECDSA.

## 5. Docker Compose

| Composant | Version | Licence | Capacité pertinente | Source |
|---|---|---|---|---|
| **Compose Specification** | Docker Compose v5.7.1 installé localement (Docker Engine 29.9.3) | Apache-2.0 (connaissance antérieure, non vérifié) | **`include`** (depuis Compose v2.20.0) : chaque chemin est chargé comme une application Compose distincte, avec son propre répertoire de projet. Ses ressources sont copiées dans le modèle courant, et un conflit de noms produit un avertissement, sans fusion. Le mécanisme est récursif et accepte l'interpolation (`${VAR:?err}`). **`profiles`** : les services sans `profiles` sont toujours actifs. Un service est ignoré si aucun de ses profils n'est actif, sauf s'il est ciblé explicitement. Une référence vers un service désactivé produit une erreur. L'attribut top-level **`version`** est obsolète : il ne sert qu'à titre informatif et déclenche un avertissement. | https://raw.githubusercontent.com/compose-spec/compose-spec/main/14-include.md (vérifié le 2026-11-28) ; https://raw.githubusercontent.com/compose-spec/compose-spec/main/15-profiles.md (vérifié le 2026-11-28) ; https://github.com/compose-spec/compose-spec/blob/main/spec.md (vérifié le 2026-11-28) ; `docker compose version` (vérifié le 2026-11-28) |

Suggestion : un profil `core` (api, postgres, mosquitto, stockage objet) et un profil `ledger` (peers, orderers, CCaaS), pour que la démo démarre sans Fabric.

## 6. Stockage objet compatible S3

| Composant | Version | Licence | Statut / capacité | Source |
|---|---|---|---|---|
| **MinIO (community edition)** | Dernier tag Git : `RELEASE.2025-10-15T17-29-55Z` | **AGPL-3.0** | **Dépôt archivé le 25 avril 2026** (lecture seule). README : « THIS REPOSITORY IS NO LONGER MAINTAINED », édition communautaire « distributed as source code only », « We will no longer provide pre-compiled binary releases for the community version », binaires existants figés. Il renvoie vers AIStor Free/Enterprise. La release `RELEASE.2025-05-24T17-08-30Z` indique : « Embedded UI Console is now deprecated and moved to object-browser » et « External IDP logins via LDAP/OIDC are removed ». **Images** : `mirror.gcr.io/minio/minio` = *not found* ici, et l'API Docker Hub renvoie « object not found » pour `minio/minio`. | https://github.com/minio/minio (vérifié le 2026-11-28) ; https://github.com/minio/minio/releases/tag/RELEASE.2025-05-24T17-08-30Z (vérifié le 2026-11-28) ; https://raw.githubusercontent.com/minio/minio/master/LICENSE (vérifié le 2026-11-28) ; tests `docker pull` (vérifié le 2026-11-28) |
| **SeaweedFS** | **4.55** (tag Git le plus élevé et image `chrislusf/seaweedfs:4.55`) | **Apache-2.0** | README : « The most complete S3 API », passerelle S3 (objets, buckets, IAM, STS…), SDK et CLI AWS utilisables tels quels. Il existe une édition Enterprise séparée (seaweedfs.com). **Image tirable ici** : `mirror.gcr.io/chrislusf/seaweedfs:4.55`, digest `sha256:7ca46aeae2f223b37e5d91593c17ab37738eec6df6ab69b48a0487f7643342b9`. | https://github.com/seaweedfs/seaweedfs (vérifié le 2026-11-28) ; https://raw.githubusercontent.com/seaweedfs/seaweedfs/master/LICENSE (vérifié le 2026-11-28) ; `docker pull` (vérifié le 2026-11-28) |
| **Garage** (Deuxfleurs) | **v2.6.0** (image Docker Hub `dxflrs/garage:v2.6.0` du 2026-11-24 ; `garage --version` → `garage v2.6.0`) ; une v3.0.0-beta1 existe | **AGPL-3.0** | « S3-compatible object store for small self-hosted geo-distributed deployments ». Dépôt principal sur git.deuxfleurs.fr (non chargeable ici), miroir GitHub consulté. **Image tirable ici** : `mirror.gcr.io/dxflrs/garage:v2.6.0`, digest `sha256:4b5a318fc9fe2fbec5d3af590eeafe05d83492e6411266fa0b9e215c20264013`. | https://github.com/deuxfleurs-org/garage (vérifié le 2026-11-28) ; API Docker Hub `dxflrs/garage` (vérifié le 2026-11-28) ; `docker pull` / `docker run` (vérifié le 2026-11-28) ; https://garagehq.deuxfleurs.fr (non vérifié : page non chargeable) |

### Recommandation pour un stockage S3 « protégé » en démo auto-hébergée

1. **Retenu : SeaweedFS 4.55**, image **`mirror.gcr.io/chrislusf/seaweedfs:4.55`** (épingler le digest ci-dessus).
   - Licence **Apache-2.0**, permissive. Aucune obligation de publier le code d'AUREOM COMMERCE, même si le service est exposé sur le réseau. Il faut conserver les mentions de licence et le fichier NOTICE s'il est redistribué.
   - API S3 complète. Des identités ou clés S3 et des politiques IAM permettent un bucket privé (factures, archives de clôture, preuves signées).
   - Image tirable ici et projet actif.
2. **Alternative : Garage v2.6.0** (`mirror.gcr.io/dxflrs/garage:v2.6.0`). Elle est légère et adaptée au multi-site, mais sous **AGPL-3.0** : si l'on modifie Garage et qu'on l'expose à des utilisateurs via le réseau, il faut leur fournir le code source modifié. Utilisé tel quel comme service séparé, Garage n'impose pas l'AGPL au code d'AUREOM (point d'interprétation juridique, non vérifié auprès d'un juriste).
3. **À écarter : MinIO community edition.** Le dépôt est archivé et non maintenu, il n'y a plus de binaires ni d'image officielle (non tirable ici), la console d'administration a été retirée et la licence est AGPL-3.0. Pour une démo neuve, cela signifie aucun correctif de sécurité et une compilation à faire soi-même.
4. Quel que soit le moteur, côté AUREOM : chiffrement côté application ou SSE si disponible, bucket non public, clés distinctes par service, **empreinte SHA-256 de chaque objet ancrée dans Fabric** (jamais le contenu ni des données personnelles en clair), et versionnement ou immutabilité applicative pour les archives fiscales.

## 7. Récapitulatif des images testées localement (`docker pull`, le 2026-11-28)

| Image | Résultat |
|---|---|
| `mirror.gcr.io/chrislusf/seaweedfs:4.55` (= `:latest`) | OK |
| `mirror.gcr.io/dxflrs/garage:v2.6.0` | OK (`v2.1.0` également OK) |
| `mirror.gcr.io/minio/minio:latest` | **Échec** : not found |
| `mirror.gcr.io/minio/minio:RELEASE.2025-09-07T16-13-09Z` | **Échec** : not found |
| `mirror.gcr.io/library/eclipse-mosquitto:2` | OK (mosquitto 2.1.4) |
| `mirror.gcr.io/library/postgres:17` | OK (17.12) |
| `mirror.gcr.io/library/postgres:18` | OK (18.7) |
| `mirror.gcr.io/library/python:3.13-slim` | OK (3.13.18) |

Les images Fabric (`hyperledger/fabric-peer`, `fabric-orderer` 2.5.16 / 3.1.5) existent sur Docker Hub (API vérifiée le 2026-11-28). Leur téléchargement via `mirror.gcr.io` n'a pas été testé.
