# Gouvernance du registre et gestion des clés

Cadre proposé pour le consortium de démonstration (Maison & Marché, Atelier Lumière, Conserverie du Val). Les procédures Fabric détaillées (mises à jour de canal, cycle de vie du chaincode) se trouvent dans `ledger/README.md` §10 à §14.

## Organisations et rôles

| Rôle | Qui | Droits |
|---|---|---|
| Membre du canal | chaque organisation admise (un MSP, au moins un pair) | soumettre ses propres événements, lire tout le canal, endosser |
| Administrateur d'organisation | identité X.509 avec NodeOU `admin` | inscrire, retirer ou révoquer **ses** clés de signature applicatives ; signer les mises à jour de canal |
| Comité du consortium | un représentant par organisation | admission et retrait, politique d'endossement, évolution des schémas, litiges |
| Opérateur d'orderer | dans la démo, organisation d'ordonnancement dédiée | exploitation Raft, sans droit métier |

Dans l'application, ces décisions sont **tracées** (`POST /api/organisations/{id}/statut-registre` : CANDIDATE → ADMISE → SUSPENDUE / RETIREE, avec journal d'audit). La modification effective du canal reste une procédure Fabric multi-signataire, hors application.

## Admission et retrait

1. Candidature : la nouvelle organisation fournit son MSP (certificats d'AC), son point d'accès pair et un engagement écrit sur la charte (schémas, données interdites, délais de confirmation, litiges).
2. Le comité vote. L'administrateur prépare la mise à jour de configuration du canal (`configtxlator`), qui est signée par la **majorité** des administrateurs (politique `Admins` MAJORITY), puis soumise.
3. Le pair rejoint le canal, installe et approuve le chaincode. La politique d'endossement MAJORITY s'ajuste automatiquement au nouveau nombre de membres. L'organisation inscrit ensuite sa clé applicative.
4. **Retrait** : mise à jour du canal retirant le MSP (signée par la majorité), révocation de ses clés applicatives à la date de sortie. L'historique reste lisible : ses événements passés ne sont **ni supprimés ni réécrits**.
5. **Suspension** (incident de sécurité) : révocation immédiate des clés applicatives par l'organisation elle-même, ou retrait de ses certificats par mise à jour de canal si elle n'est plus joignable.

## Validation des événements

- **Chaincode** : schéma strict (champs inconnus refusés), émetteur = MSP soumettant, clé appartenant à l'émetteur et valide à `declaredAt`, signature Ed25519, idempotence et conflit par `eventId`, existence des événements référencés. Une organisation ne corrige que ses propres événements (`CORRECTION`) ; elle **conteste** ceux des autres (`DISPUTE`).
- **Endossement** : MAJORITY (2 sur 3). Aucune organisation seule ne peut écrire, et une organisation indisponible ne bloque pas les deux autres (test de bout en bout : arrêt d'un pair).
- **Contrôle humain** : la vérification indépendante reste une procédure interne documentée, jamais déduite de l'inscription sur le registre.

## Clés de signature applicatives

| Étape | Procédure |
|---|---|
| Conservation | Démo : fichier PKCS#8 dans un secret Docker (`secrets/`, droits 0600, propriétaire = utilisateur du conteneur), jamais dans le dépôt ni dans le navigateur, jamais exposé par l'API. Production : KMS ou HSM (Vault Transit, PKCS#11). Seule l'opération `sign()` est requise, la clé ne sort pas du module (interface `FileKeyProvider`). |
| Inscription | `RegisterSigningKey(keyId, publicKey, validFrom)`, réservée à un administrateur de l'organisation (`POST /api/tracabilite/cles/enregistrer`, fait automatiquement par le worker au démarrage). |
| Rotation planifiée | Nouvelle clé inscrite, l'ancienne est **retirée** (`RetireSigningKey`) : les signatures antérieures restent valides, les postérieures sont refusées (`KEY_RETIRED`). API de démonstration `POST /api/tracabilite/cles/rotation`. En production, la rotation se fait dans le KMS. |
| Révocation (compromission) | `RevokeSigningKey(keyId, revokedAt, reason)` : tout événement déclaré à partir de `revokedAt` est rejeté (`KEY_REVOKED`, testé). Les événements antérieurs restent inscrits avec `keyStatus=REVOKED`, et l'application liste ceux à revoir, car la compromission réelle peut précéder la révocation. |
| Identités Fabric | Démo : `cryptogen`, passerelles connectées avec l'Admin de leur organisation. Production : Fabric CA, HSM via BCCSP PKCS#11, identités séparées pour l'administration des clés et pour la soumission d'événements, mTLS entre l'application et la passerelle. |

## Litiges

1. Une partie émet un événement `DISPUTE` visant l'événement contesté (`correctsEventId`), avec une empreinte salée de son argumentaire. Le transfert de garde concerné passe à l'état « contesté ».
2. Le comité examine les pièces hors chaîne. Les empreintes publiées permettent de vérifier que les documents produits sont bien ceux référencés.
3. L'issue est inscrite par l'émetteur d'origine (`CORRECTION` liée) ou consignée dans le procès-verbal du comité. Rien n'est effacé.

## Évolution des schémas

- `schemaVersion` est obligatoire. Le chaincode n'accepte que les versions déclarées.
- Pour une nouvelle version, le comité approuve le schéma, puis une mise à jour du chaincode est déployée par le cycle de vie Fabric (nouvelle `sequence`, approbation par la majorité des organisations).
- Les anciennes versions restent lisibles. L'application décode selon `schemaVersion`.
- Aucun champ ajouté ne peut contenir de donnée personnelle ou de secret commercial en clair. Toute nouvelle donnée sensible passe par `detailsDigest`.

## Récupération

| Incident | Procédure | Testé |
|---|---|---|
| Registre indisponible | Les opérations continuent ; la boîte d'envoi reprend automatiquement | ✔ coupure réelle de la passerelle et panne simulée |
| Issue de transaction inconnue | Lecture par `eventId` avant resoumission | ✔ |
| Arrêt brutal du worker | Les lignes `EN_COURS` expirées sont reprises en « issue inconnue » | ✔ |
| Restauration d'une sauvegarde PostgreSQL | `pg_restore` (liste sans l'extension), puis `GET /api/stocks/controle-coherence`, puis réconciliation : les événements postérieurs à la sauvegarde, présents sur le registre, sont signalés comme **orphelins** et réimportés | ✔ `test_restauration_puis_reconciliation` |
| Perte d'un pair | Le pair se resynchronise depuis l'ordonnancement ; les autres organisations continuent | ✔ (test de bout en bout du registre) |
| Perte du matériel cryptographique | Sauvegarde chiffrée hors site des MSP et des clés ; à défaut, révocation et réinscription de nouvelles clés, puis mise à jour du canal | procédure documentée, non testée |

Aucun jeton négociable n'est utilisé ni nécessaire.
