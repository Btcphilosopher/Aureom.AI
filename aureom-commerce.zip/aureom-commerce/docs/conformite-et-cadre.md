# AUREOM COMMERCE — Conformité et cadre réglementaire (France / UE)

Recherche effectuée le **2026-11-28**. Ce document est une synthèse technique destinée à orienter la conception d'un **prototype**. Ce n'est pas un avis juridique.

## Avertissement sur la vérification

Depuis l'environnement de recherche, **aucun des sites officiels demandés n'a pu être chargé directement** : legifrance.gouv.fr, bofip.impots.gouv.fr, impots.gouv.fr, economie.gouv.fr, cnil.fr, entreprendre.service-public.fr, pcisecuritystandards.org, gs1.org / ref.gs1.org, rappel.conso.gouv.fr et eur-lex.europa.eu sont tous refusés par le réseau du bac à sable. Les contenus ci-dessous viennent donc **d'extraits de moteur de recherche portant sur ces pages officielles** (les URL citées sont celles des pages officielles indexées) et, ponctuellement, de connaissances antérieures signalées comme telles.

- Sauf mention contraire, chaque fait est marqué **non vérifié (page non chargeable)** : l'URL officielle est donnée, mais la page n'a pas été lue intégralement ce jour.
- Avant toute mise en production, relire chaque source, en priorité la version en vigueur de l'article 286 du CGI et du BOI-TVA-DECLA-30-10-30.

---

## a) Logiciels et systèmes de caisse (CGI art. 286, I-3° bis)

### Qui est concerné
- Les **assujettis à la TVA** qui enregistrent les règlements de leurs clients **non assujettis** (particuliers) au moyen d'un **logiciel ou système de caisse**. Sont visés tous les logiciels dotés d'une fonctionnalité de caisse, quelle que soit leur appellation (caisse, gestion, comptabilité, facturation).
- **Exclus** (extraits impots.gouv.fr / BOFiP) : les assujettis en **franchise en base** (dont la plupart des micro-entrepreneurs), ceux au **remboursement forfaitaire agricole**, ceux qui réalisent **exclusivement des opérations exonérées** et ceux qui travaillent **exclusivement entre professionnels (B2B)**. Une tolérance existe aussi lorsque tous les paiements passent par un établissement de crédit.
- Sources : https://www.impots.gouv.fr/professionnel/questions/quel-est-le-champ-dapplication-de-lobligation-de-detenir-un-logiciel-de ; https://bofip.impots.gouv.fr/bofip/10691-PGP.html/identifiant=BOI-TVA-DECLA-30-10-30-20260325 (non vérifié, page non chargeable).

### Obligations : inaltérabilité, sécurisation, conservation, archivage
D'après le BOI-TVA-DECLA-30-10-30 (version du 25 mars 2026, d'après les extraits) :
- le logiciel doit **enregistrer toutes les données d'origine des encaissements**, les rendre **inaltérables**, les **conserver de façon sécurisée** et permettre leur **archivage** ;
- les données peuvent rester dans le logiciel ou être archivées sur un support externe ou distant. Les données de preuve doivent être **conservées 6 ans** ;
- les **cumuls et totaux de contrôle** (données de clôture) restent dans le logiciel et **ne sont jamais purgés**. Avant toute purge, une archive complète doit être produite sur un support externe sécurisé ;
- **toute modification** qui touche à ces fonctions invalide le certificat ou l'attestation, et la nouvelle version doit à nouveau être mise en conformité.
- Détail technique tiré de connaissances antérieures du BOFiP et du référentiel NF525, **non vérifié** : correction des erreurs par écritures d'annulation traçées, jamais par modification ; procédé de sécurisation (chaînage, signature) ; clôtures périodiques (au minimum mensuelle et annuelle / d'exercice) avec grand total cumulatif ; archives datées, intègres et lisibles.
- Source : https://bofip.impots.gouv.fr/bofip/10691-PGP.html/identifiant=BOI-TVA-DECLA-30-10-30-20260325 (non vérifié, page non chargeable).

### Preuve de conformité : évolution 2025 puis 2026
| Étape | Contenu | Source (non vérifié, page non chargeable) |
|---|---|---|
| **LF 2025** : loi n° 2025-127 du 14 février 2025, **art. 43** | **Suppression de l'attestation individuelle de l'éditeur.** Seul un **certificat délivré par un organisme accrédité** (COFRAC) reste admis, **à compter du 16 février 2025**. | https://bofip.impots.gouv.fr/bofip/14667-PGP.html/ACTU-2025-00075 |
| Transition | Du 1er septembre 2025 au 28 février 2026, l'éditeur devait au moins avoir **demandé** la certification. Le délai d'obtention du certificat a ensuite été **prorogé au 31 août 2026** (BOFiP, actualité du 1er octobre 2025). | https://bofip.impots.gouv.fr/bofip/14826-PGP.html/ACTU-2025-00160 ; https://bofip.impots.gouv.fr/bofip/10691-PGP.html/identifiant=BOI-TVA-DECLA-30-10-30-20251001 |
| **LF 2026** : loi n° 2026-103 du 19 février 2026, **art. 125** | **Rétablissement de l'attestation individuelle de l'éditeur** (modèle administratif BOI-LETTRE-000242), **à compter du 21 février 2026**, à côté du certificat. Le BOI a été mis à jour le 25 mars 2026. | https://bofip.impots.gouv.fr/bofip/10691-PGP.html/identifiant=BOI-TVA-DECLA-30-10-30-20260325 ; https://www.economie.gouv.fr/entreprises/gerer-son-entreprise-au-quotidien/gerer-sa-comptabilite-et-ses-demarches/ce-quil-faut-savoir-sur-la-certification-des-logiciels-de-caisse |
| Organismes de certification | Historiquement : **AFNOR Certification** (marque **NF525**, avec **INFOCERT** comme opérateur technique) et **LNE** (référentiel de certification des systèmes de caisse). La liste actuelle des accréditations doit être confirmée auprès du COFRAC. | https://www.impots.gouv.fr/actualite/obligation-dutiliser-un-logiciel-de-comptabilite-ou-de-gestion-ou-un-systeme-de-caisse |

Point d'attention : les sources consultées ne concordent pas toutes. Une version d'octobre 2025 du BOI imposait un certificat à compter du 1er septembre 2026, ce que la LF 2026 semble avoir remis en cause. **L'état du droit au 2026-11-28 n'a pas pu être confirmé sur Légifrance.**

### Sanction (CGI art. 1770 duodecies)
- Amende de **7 500 € par logiciel ou système de caisse** pour lequel l'assujetti ne peut pas justifier de la conformité. L'administration n'a pas à démontrer d'usage frauduleux. L'assujetti dispose ensuite de **60 jours** pour se mettre en conformité, faute de quoi il est à nouveau passible de l'amende.
- Sources : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000051203251 ; https://www.economie.gouv.fr/entreprises/gerer-son-entreprise-au-quotidien/gerer-sa-comptabilite-et-ses-demarches/ce-quil-faut-savoir-sur-la-certification-des-logiciels-de-caisse (non vérifié, page non chargeable).

### Conclusion
> **Le prototype AUREOM COMMERCE n'est ni certifié (NF525, LNE ou autre organisme accrédité) ni couvert par une attestation d'éditeur conforme au modèle administratif. Il ne doit pas être utilisé, en l'état, pour enregistrer des encaissements réels auprès de clients particuliers.** Son usage est limité à la démonstration, sur des données fictives, avec la mention visible « Prototype — non conforme CGI art. 286 I-3° bis — ne pas utiliser pour des ventes réelles ».

### Ce que cela implique pour le prototype
- Concevoir dès maintenant selon le modèle ISCA : journal d'encaissement en **ajout seul** (aucun `UPDATE` ni `DELETE` sur les tickets ; annulation par contre-écriture), **chaînage par empreinte** et signature Ed25519 de chaque ticket et de chaque clôture, **clôtures** périodiques avec grand total perpétuel, **archives** exportables et vérifiables, conservation de 6 ans.
- L'ancrage des empreintes dans Fabric peut renforcer l'inaltérabilité. Il **ne remplace pas** une certification.
- Versionner le logiciel et tracer toute modification des modules fiscaux : en cas d'usage réel, toute modification invalide le certificat.
- Ajouter un bandeau « non certifié » sur l'interface caisse et sur les tickets générés.

---

## b) Paiement par carte : PCI DSS v4.0.1

- **Version** : PCI DSS **v4.0.1** a été publiée en juin 2024 (révision limitée, sans exigence ajoutée ni supprimée). La v4.0 a été retirée le **31 décembre 2024**. Les 51 exigences « future-dated » sont obligatoires depuis le **31 mars 2025**. Source : https://blog.pcisecuritystandards.org/just-published-pci-dss-v4-0-1 (non vérifié, page non chargeable). Aucune version ultérieure n'a été confirmée.
- **Données d'authentification sensibles (SAD)** : la piste magnétique complète, le **code de vérification (CVV/CVC/CID)** et le **PIN/PIN block** ne doivent **jamais être conservés après autorisation**, même chiffrés (exigence 3.3.1 de la v4.0.x). Source : https://listings.pcisecuritystandards.org/pdfs/pci_fs_data_storage.pdf ; numéro d'exigence tiré de connaissances antérieures (non vérifié, page non chargeable).
- **Affichage du PAN (exigence 3.4.1)** : masquage, avec au maximum « **BIN et 4 derniers chiffres** ». Cette formulation remplace le « 6 premiers / 4 derniers » de la v3.2.1. Source : SAQ v4.0.1, https://docs-prv.pcisecuritystandards.org/SAQ%20(Assessment)/SAQ/PCI-DSS-v4-0-1-SAQ-D-Merchant.pdf (non vérifié, page non chargeable).
- **Troncature (stockage)** : la FAQ PCI SSC prend comme base **6 premiers et 4 derniers chiffres**. Pour un PAN de 16 chiffres, les réseaux (Visa, Mastercard, Discover, JCB, UnionPay) admettent au maximum **8 premiers et 4 autres chiffres**, et au moins 4 chiffres doivent être retirés. Pour American Express (15 chiffres), le format est 6 premiers / 4 derniers. Si des formats tronqués différents ou des empreintes du même PAN coexistent, il faut des contrôles empêchant la corrélation. Source : https://www.pcisecuritystandards.org/faq/articles/Frequently_Asked_Question/What-are-acceptable-formats-for-truncation-of-primary-account-numbers/ ; https://blog.pcisecuritystandards.org/8-digit-bins-and-pci-dss-what-you-need-to-know (non vérifié, page non chargeable).

### Ce que cela implique pour le prototype
- **Ne jamais saisir, transmettre, journaliser ni stocker de PAN complet, de CVV ou de PIN.** Aucun champ de formulaire carte dans l'UI React.
- Modéliser le paiement carte comme un **résultat renvoyé par un TPE ou un PSP externe** (statut, montant, horodatage, référence d'autorisation, **4 derniers chiffres** et marque). Pour la démo, se limiter aux 4 derniers chiffres plutôt qu'au BIN, ce qui réduit le périmètre.
- Aucune donnée carte dans MQTT, Fabric, les logs, les traces ou le stockage objet. Prévoir des tests automatisés qui détectent les motifs de PAN (Luhn) dans les logs et les payloads.
- Utiliser uniquement des cartes et jetons de test fournis par un PSP. Le prototype n'est pas évalué PCI DSS.

---

## c) Ticket de caisse : règles depuis le 1er août 2023

- **Fin de l'impression systématique** (pas de suppression) des tickets de caisse, tickets de carte bancaire, tickets d'automates, bons d'achat et tickets promotionnels. Le ticket est **remis à la demande du client**. Base : loi AGEC (2020), **décret n° 2022-1565 du 14 décembre 2022**, modifié par le **décret n° 2023-237 du 31 mars 2023** ; code de l'environnement, articles **D541-370 à D541-372** ; entrée en vigueur le **1er août 2023**.
- **Exceptions** (impression automatique maintenue) : produits sous **garantie légale de conformité**, **produits pesés**, **prestations de services ≥ 25 €**, notes et additions en **hôtellerie-restauration**, tickets d'accès (péage, parking), opérations de paiement par carte **annulées ou non abouties**. La liste exacte se trouve à l'article D541-371.
- Le commerçant doit **informer le client en caisse**. Il **ne peut pas refuser l'impression** demandée, même si un ticket dématérialisé a déjà été transmis. La dématérialisation est facultative.
- Sources : https://www.economie.gouv.fr/dgccrf/les-fiches-pratiques/ticket-de-caisse-et-de-carte-bancaire ; https://www.economie.gouv.fr/entreprises/gerer-son-entreprise-au-quotidien/gerer-un-commerce/ticket-de-caisse-professionnels-quelles-sont-vos-obligations ; https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046739215 (non vérifié, pages non chargeables).

### Ce que cela implique pour le prototype
- Paramètre « impression : à la demande » par défaut, avec règles d'**impression forcée** : produit sous garantie, article pesé, service ≥ 25 €, restauration, paiement CB refusé ou annulé. Le seuil et la liste doivent être configurables.
- Le ticket reste **toujours généré et archivé** dans le journal fiscal, même s'il n'est pas imprimé.
- Ticket dématérialisé (e-mail/SMS) : collecter le contact uniquement pour cet envoi. Toute réutilisation marketing exige un consentement distinct (voir d).

---

## d) RGPD et blockchain ; prospection électronique

### Blockchain (CNIL, « Premiers éléments d'analyse », 2018)
- La grille RGPD habituelle s'applique (responsable de traitement, droits des personnes, garanties, sécurité). La CNIL recommande que les **données personnelles soient enregistrées hors de la blockchain** ou, à défaut, sous une forme qui ne constitue pas une donnée personnelle. L'inscription de données personnelles sur une **blockchain publique** est jugée particulièrement problématique.
- Recommandations, selon des connaissances antérieures du document (**non vérifié**) : sur la chaîne, préférer un **engagement cryptographique**, une **empreinte obtenue par fonction de hachage à clé** ou un chiffré, les données et clés restant hors chaîne. Pour l'**effacement**, supprimer les données hors chaîne et la clé ou le secret rend l'empreinte inexploitable. Privilégier une **blockchain à permission** lorsque c'est possible.
- **Un hash n'est pas une anonymisation** : la CNIL rappelle que, même si les fonctions de hachage sont à sens unique, la donnée peut être retrouvée à partir de son empreinte (dictionnaires précalculés). L'empreinte d'une donnée personnelle reste donc une **donnée personnelle** (pseudonymisée).
- Sources : https://www.cnil.fr/fr/blockchain-et-rgpd-quelles-solutions-pour-un-usage-responsable-en-presence-de-donnees-personnelles ; https://www.cnil.fr/sites/default/files/2025-08/la_blockchain_chaine_blocs.pdf ; https://www.cnil.fr/fr/definition/hachage (non vérifié, pages non chargeables).

### Prospection électronique (CPCE art. L34-5)
- **B2C par e-mail ou SMS : consentement préalable** libre, spécifique, éclairé et univoque. Les cases pré-cochées sont interdites.
- **Exception « produits ou services analogues »** : elle vaut uniquement pour un **client existant** (achat effectif ; la simple création de compte ne suffit pas, cf. sanction CNIL SAN-2021-008), pour des produits analogues **de la même entreprise**. Le client doit être informé et pouvoir s'opposer simplement à la collecte et dans chaque message.
- Transmission à des partenaires : consentement spécifique requis, et le partenaire doit pouvoir en apporter la preuve.
- Sources : https://www.cnil.fr/fr/communication-electronique-quelles-regles ; https://www.cnil.fr/fr/la-prospection-b-to-c-quelles-regles-pour-transmettre-des-donnees-des-partenaires (non vérifié, pages non chargeables).

### Ce que cela implique pour le prototype
- **Aucune donnée personnelle en clair sur Fabric**, et pas non plus de hash simple (SHA-256 nu) d'un e-mail, d'un téléphone ou d'un nom. Sur la chaîne, n'inscrire que des **empreintes de documents ou d'événements métier** (ticket, clôture, lot), des identifiants techniques non signifiants, ou au besoin un HMAC avec une clé hors chaîne destructible.
- Données clients dans PostgreSQL uniquement, avec durée de conservation, procédure d'effacement et journal des consentements (date, canal, finalité, preuve, retrait).
- Consentement marketing : opt-in explicite par canal (e-mail, SMS), non pré-coché, séparé de l'envoi du ticket dématérialisé. Lien de désinscription dans chaque envoi.
- Données de démo exclusivement fictives.

---

## e) Prix, affichage et TVA

- **Prix TTC en euros** : selon l'arrêté du 3 décembre 1987 (art. 1), toute information sur les prix doit faire apparaître, quel que soit le support, la **somme totale toutes taxes comprises** que le consommateur devra payer, **exprimée en euros**. L'art. 3 exige de signaler tout élément indispensable non inclus dans le prix. La DGCCRF mentionne une amende administrative pouvant aller jusqu'à 3 000 € (personne physique) ou 15 000 € (personne morale) en cas de manquement. Sources : https://www.legifrance.gouv.fr/loda/id/LEGITEXT000006057893/ ; https://www.economie.gouv.fr/dgccrf/les-fiches-pratiques/linformation-sur-les-prix (non vérifié, pages non chargeables).
- **Prix de référence des réductions (art. L112-1-1 C. conso., directive « Omnibus »)** : toute annonce de réduction de prix doit indiquer le **prix antérieur pratiqué**, c'est-à-dire le **prix le plus bas pratiqué au cours des 30 jours précédant** l'application de la réduction (jours calendaires). Pour des **réductions successives** sur une même période, le prix de référence reste celui d'avant la première réduction. Une exception existe pour les produits périssables menacés d'altération rapide. La CJUE (26 septembre 2024) a jugé que **la réduction annoncée doit être calculée à partir de ce prix de référence**. Sources : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044549592 ; https://www.economie.gouv.fr/dgccrf/les-fiches-pratiques/annonces-de-reduction-de-prix-ce-que-vous-devez-savoir ; https://www.economie.gouv.fr/daj/lettre-de-la-daj-la-cjue-juge-quune-reduction-de-prix-annoncee-dans-une-publicite-doit-etre (non vérifié, pages non chargeables).
- **Taux de TVA (France métropolitaine)** : **20 %** (taux normal), **10 %** (taux intermédiaire, par ex. restauration sur place, transport de voyageurs, hébergement), **5,5 %** (taux réduit, par ex. la plupart des denrées alimentaires, livres), **2,1 %** (taux particulier, médicaments remboursables, presse). Les taux applicables changent régulièrement par catégorie : depuis le 1er août 2025, les abonnements gaz/électricité passent à 20 % ; depuis le 1er mars 2025, les chaudières à combustibles fossiles relèvent de 20 %. Les DOM ont d'autres taux (8,5 % / 2,1 %…). Source : https://www.economie.gouv.fr/particuliers/impots-et-fiscalite/gerer-mes-autres-impots-et-taxes/tva-quels-sont-les-taux-de-votre-quotidien (non vérifié, page non chargeable).

### Ce que cela implique pour le prototype
- **Taux de TVA en table de référence** (taux, catégorie, territoire, `valid_from`/`valid_to`), jamais codés en dur. Le taux est rattaché à l'article et figé sur la ligne de ticket au moment de la vente.
- Montants en `Decimal` (jamais en `float`). Arrondi documenté (par ligne ou par total) et test de cohérence HT + TVA = TTC par taux.
- Prix public stocké et affiché **TTC en euros**.
- **Historique des prix** horodaté par article et par canal, pour calculer automatiquement le **prix le plus bas sur 30 jours** et l'imposer comme prix barré, avec calcul du pourcentage de remise sur cette base.

---

## f) Rappels de produits

- **RappelConso** : depuis le **1er avril 2021**, les professionnels doivent **déclarer tout rappel** de produits, denrées alimentaires ou aliments pour animaux sur **pro.rappel.conso.gouv.fr** (publication sur **rappel.conso.gouv.fr**), dès la mise en œuvre du rappel, qu'il soit d'initiative privée ou imposé par l'administration, puis mettre à jour la déclaration. Le texte de référence trouvé est l'**arrêté du 20 janvier 2021** relatif à la déclaration dématérialisée des rappels. Le défaut de déclaration est passible d'une amende pouvant aller jusqu'à **1 500 €** (art. R452-5 C. conso.). **Le numéro de décret « 2021-… » évoqué dans la demande n'a pas pu être confirmé.** Sources : https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000043038659 ; https://www.economie.gouv.fr/entreprises/rappels-produits-rappel-conso ; https://www.economie.gouv.fr/dgccrf/alerte-et-rappel-de-produits-mode-demploi (non vérifié, pages non chargeables).
- **Règlement (UE) 2023/988 (GPSR)**, applicable à compter du **13 décembre 2024** (date tirée de connaissances antérieures, non confirmée par les extraits ; version consolidée EUR-Lex du 29 mai 2026 existante). Pour les **distributeurs** :
  - avant la mise à disposition, **vérifier** que le fabricant et, le cas échéant, l'importateur ont respecté leurs obligations (art. 12) ;
  - s'ils ont des raisons de croire qu'un produit est dangereux : **informer immédiatement** le fabricant ou l'importateur, veiller aux **mesures correctives** (y compris retrait ou rappel) et informer les autorités via le **Safety Business Gateway** ;
  - **traçabilité (art. 17)** : être capable d'identifier, sur demande, **le fournisseur** et **le client professionnel** du produit, et conserver ces informations pendant **10 ans** ;
  - **rappel (art. 35-36)** : notifier **directement et sans retard injustifié** les consommateurs identifiables, et à défaut diffuser un avis de rappel clair et visible. L'avis doit décrire clairement le danger, sans termes minimisants tels que « volontaire » ou « par précaution ».
  - Sources : https://eur-lex.europa.eu/legal-content/FR/TXT/?uri=CELEX:32023R0988 ; https://eur-lex.europa.eu/FR/legal-content/summary/general-product-safety-regulation-2023.html ; https://eur-lex.europa.eu/legal-content/FR/TXT/?uri=CELEX%3A02023R0988-20260529 (non vérifié, pages non chargeables).

### Ce que cela implique pour le prototype
- Lier chaque mouvement de stock et chaque ligne de vente à **GTIN + lot (+ DLC/DDM)**, et conserver **fournisseur → réception → magasin → vente** pendant 10 ans.
- Module « rappel » : à partir d'un GTIN et d'un lot, **blocage immédiat en caisse** (refus de vente), liste des magasins et stocks concernés, liste des clients identifiables (uniquement ceux qui ont consenti ou dont le contact existe pour un motif légitime), génération d'un brouillon de déclaration RappelConso. Le prototype **ne transmet rien** au portail officiel.
- Journaliser chaque rappel comme un événement EPCIS (`bizStep` de type retrait ou rappel) ancré par empreinte dans Fabric.

---

## g) Traçabilité : GS1 EPCIS 2.0 / CBV 2.0 et identifiants GS1

- **EPCIS 2.0 et CBV 2.0** : ratifiés en **juin 2022** (CBV Release 2.0 « Ratified, Jun 2022 ») ; guide de mise en œuvre EPCIS/CBV Release 2.0 de mars 2023. Types d'événements :
  - **ObjectEvent** : événement survenu à un ou plusieurs objets (réception, vente, contrôle) ;
  - **AggregationEvent** : agrégation ou désagrégation d'objets, avec un **parent** (ex. palette SSCC) et des **enfants** ;
  - **TransformationEvent** : entrées consommées en tout ou partie et sorties produites (découpe, reconditionnement) ;
  - **AssociationEvent** (nouveau en 2.0) : rattachement permanent ou semi-permanent (ex. capteur IoT fixé à un contenant) ;
  - (TransactionEvent existe également, d'après des connaissances antérieures, non vérifié.)
- **Dimensions** : *what* (EPC / classe + quantité, ex. GTIN + lot), *when* (`eventTime`, `eventTimeZoneOffset`, `recordTime`), *where* (`readPoint`, `bizLocation`, en général des GLN), *why* (`bizStep`, `disposition`, `bizTransactionList` du vocabulaire CBV). EPCIS 2.0 ajoute une sérialisation **JSON / JSON-LD** officielle (schéma JSON publié par GS1) et une API REST. La correspondance explicite dimension/champ n'a pas été lue directement dans la norme : elle provient d'exemples et de connaissances antérieures.
- **Identifiants** : **GTIN** (article commercial), **GLN** (lieu / partie), **SSCC**, AI **(00)**, seul identifiant GS1 admis pour une **unité logistique**.
- **GS1-128 / Application Identifiers** : **AI (10)** = numéro de lot (BATCH/LOT) ; **AI (17)** = date limite (**USE BY / EXPIRY**, format AAMMJJ), c'est-à-dire la DLC ; **AI (15)** = date de durabilité minimale (**BEST BEFORE**, AAMMJJ), c'est-à-dire la DDM ; AI (16) = date de vente limite (sell-by). La GS1 General Specifications en vigueur est la Release 26.0 (janvier 2026).
- Sources : https://ref.gs1.org/standards/cbv/2.0.0/ ; https://ref.gs1.org/guidelines/epcis-cbv/ ; https://github.com/gs1/EPCIS/blob/master/EPCIS-JSON-Schema.json ; https://ref.gs1.org/ai/ ; https://ref.gs1.org/standards/genspecs/ (non vérifié, pages non chargeables).

### Ce que cela implique pour le prototype
- Utiliser EPCIS 2.0 (JSON-LD) comme **format pivot d'échange**. En interne, conserver des tables relationnelles et un export/import EPCIS. Les payloads MQTT de capteurs peuvent devenir des `ObjectEvent` ou des `sensorElementList`.
- Valider les **clés de contrôle** GTIN, GLN et SSCC (modulo 10 GS1) dès la saisie et à l'import.
- Parser les codes **GS1-128 / GS1 DataMatrix** pour extraire AI 01 (GTIN), 10 (lot), 17 (DLC) et 15 (DDM), et bloquer la vente d'un article dont la DLC est dépassée (paramétrable).
- Sur Fabric, n'ancrer que l'**empreinte canonique de l'événement EPCIS** (hors données personnelles), l'événement complet restant dans PostgreSQL ou le stockage objet.
- Les identifiants GS1 réels supposent une adhésion à GS1 France. Pour la démo, utiliser des préfixes d'entreprise fictifs clairement signalés.

---

## Synthèse des points à re-vérifier en priorité
1. Article 286 I-3° bis du CGI et BOI-TVA-DECLA-30-10-30 : la version en vigueur au 2026-11-28, après la LF 2026, décide si l'attestation de l'éditeur suffit.
2. Article 1770 duodecies du CGI : montant et délai actuels.
3. Article D541-371 du code de l'environnement : liste exacte des exceptions d'impression.
4. Document CNIL blockchain : formulations exactes sur l'engagement cryptographique et le hachage à clé.
5. Date d'application du GPSR (13/12/2024) et articles 12, 17, 35 et 36 sur EUR-Lex.
6. Ouvrir l'accès réseau du bac à sable (legifrance.gouv.fr, bofip.impots.gouv.fr, cnil.fr, economie.gouv.fr, eur-lex.europa.eu, pcisecuritystandards.org, ref.gs1.org) pour passer ces éléments en « vérifié ».
