# Architecture d'AUREOM COMMERCE

## Vue d'ensemble

```
                    ┌──────────────── Navigateur (React + TypeScript) ────────────────┐
                    │  Bureau · Caisse tactile · Tablette d'entrepôt   (WebSocket /ws) │
                    └───────────────┬──────────────────────────────────────┬───────────┘
                                    │ HTTPS /api (jeton opaque)            │ notifications
┌───────────────────────────────────▼──────────────────────────────────────┴──────────────┐
│ Monolithe modulaire FastAPI (backend/app)                                                │
│  catalogue │ stocks │ achats │ caisse │ paiements │ commandes │ clients │ retours/rappels │
│  traçabilité (événements, signature, boîte d'envoi) │ registre (adaptateurs) │ équipements │
│  automatisations (règles, prévisions) │ analyses │ administration                         │
└───────┬───────────────────────────┬──────────────────────┬──────────────────┬────────────┘
        │ SQL (transactions)        │ LISTEN/NOTIFY        │ S3 (privé)       │
┌───────▼────────┐   ┌──────────────▼───────┐   ┌──────────▼─────────┐  ┌─────▼──────────────┐
│ PostgreSQL 16  │   │ Worker (arrière-plan) │   │ SeaweedFS (objets) │  │ Pont MQTT (lecture)│
│ données opéra- │◄──┤ boîte d'envoi, récon- │   └────────────────────┘  └─────▲──────────────┘
│ tionnelles     │   │ ciliation, règles     │                                  │ ACL par équipement
└────────────────┘   └──────────┬────────────┘                          ┌───────┴──────────────┐
                                │ REST + jeton                          │ Mosquitto ◄ capteurs │
                     ┌──────────▼──────────────────────────────┐        │ (simulateurs)        │
                     │ Passerelle Fabric (Node, fabric-gateway) │        └──────────────────────┘
                     └──────────┬──────────────────────────────┘
          ┌─────────────────────▼─────────────────────────────────────────────┐
          │ Hyperledger Fabric 2.5 LTS — canal « tracabilite »                 │
          │ Maison & Marché · Atelier Lumière · Conserverie du Val (3 pairs)   │
          │ 3 orderers Raft · chaincode Go « tracabilite » (CCaaS)             │
          └───────────────────────────────────────────────────────────────────┘
```

## Choix structurants

| Sujet | Choix | Raison |
|---|---|---|
| Découpage | Monolithe modulaire (`app/modules/<domaine>/{models,service}.py`, routes dans `app/api/`) | Transactions ACID entre stock, vente et boîte d'envoi ; découpage en services possible plus tard le long des frontières de modules |
| Base | PostgreSQL 16 | Contraintes `CHECK`, contraintes d'exclusion (`btree_gist`) sur les prix datés et les taux, index uniques partiels, `NULLS NOT DISTINCT`, `FOR UPDATE SKIP LOCKED`, `LISTEN/NOTIFY` |
| Montants | Centimes entiers (`BIGINT`), calculs en `Decimal`, arrondi au demi supérieur | Aucun flottant ; TVA ventilée ligne par ligne, somme exacte |
| Quantités | `NUMERIC(14,3)` en unité de base | Pièces entières contrôlées, poids et volumes au gramme ou au millilitre |
| Arrière-plan | Processus `app.worker` (pas de broker additionnel) | La file est la table `ledger_outbox`, verrouillée par `SKIP LOCKED` ; tâches périodiques sous verrous consultatifs |
| Temps réel | `pg_notify` émis dans la transaction → relais WebSocket | Une notification n'est délivrée qu'au commit : aucun écran ne voit une opération annulée |
| Registre | Hyperledger Fabric 2.5 LTS (voir `ledger/README.md`) | Permissionné, maintenu, consensus Raft éprouvé, pas de jeton |
| Stockage objet | SeaweedFS (Apache-2.0, API S3) ; `local` en développement | MinIO community archivé (voir `dependances-et-licences.md`) |
| Télémétrie | Mosquitto + pont `app.iot_bridge` (paho-mqtt 2) | Authentification par équipement, ACL par sujet, lecture seule |

## Modules et responsabilités

- **catalogue** : familles, articles, variantes (SKU), codes-barres GTIN (clé de contrôle vérifiée), conditionnements pièce < paquet < carton < palette (ratios entiers contrôlés), fournisseurs référencés, documents. Les listes de prix sont propres à chaque canal (MAGASIN TTC, WEB TTC, PRO HT) et datées. Un prix n'est jamais modifié : une nouvelle ligne borne la précédente, et la base interdit tout chevauchement. Le prix de référence sur 30 jours est disponible pour les promotions. Les régimes de TVA sont configurés avec leurs dates d'effet.
- **stocks** : `post_movements()` est l'unique point d'écriture. Journal append-only, soldes détaillés (variante × emplacement × lot × n° de série × état qualité, jamais négatifs) et positions par site (physique / vendable / réservé). Disponible = vendable − réservé ; attendu = reliquats d'achat + transferts en transit. Réservation par `UPDATE … WHERE vendable − réservé ≥ q` atomique. Corrections liées, transferts, inventaires, exceptions (vente sans stock système, écart de transfert, réservations à réaffecter). Prélèvement FEFO.
- **achats** : besoin → proposition (arrondi au conditionnement d'achat) → approbation (plafond par rôle, séparation des tâches) → commande → réception partielle (lots, DLC/DDM, endommagés, contrôle) → contrôle différé → rapprochement à trois voies → retour fournisseur. Un document déposé est toujours « non vérifié » ; seule une vérification décrite le fait changer de statut.
- **caisse / paiements** : sessions (fond, clôture, écart). Les lignes sont figées au moment de la vente (libellé, prix, taux, coût). Remises plafonnées par rôle, avec autorisation d'un responsable au-delà. Annulations. Paiements partiels et idempotents. Terminal simulé dont l'état n'avance que sur des événements HMAC vérifiés ; un événement rejoué est ignoré. Remboursements plafonnés. Ticket de démonstration.
- **commandes** : machine à états explicite (transitions interdites refusées) et paiement suivi séparément. Réservation tout-ou-rien, préparation par scan, code de retrait haché, expédition, livraison. Proposition de fractionnement par règle explicite, sans effet automatique.
- **clients** : coordonnées visibles seulement avec `customer.pii`. Consentements marketing en historique append-only, indépendants des achats et de la fidélité. Fidélité facultative à règles lisibles, ajustée lors d'un remboursement. Anonymisation.
- **retours / rappels** : un retour entre en zone RETOURS « à inspecter ». L'inspection fixe une disposition explicite, et le remboursement reste distinct. Un rappel bloque le stock sur tous les sites, retrouve les destinations avec leur niveau de certitude (lot scanné ou FEFO présumé), crée des tâches et tient un journal des décisions et communications. Il publie aussi un événement RECALL.
- **traçabilité / registre** : voir `blockchain.md`.
- **équipements** : observations horodatées (heure de l'équipement et heure serveur), unité, emplacement, indicateurs qualité (`OK` / `SUSPECT` / `INVALIDE`) et déduplication par `message_id`. Les lectures RFID sont agrégées dans une fenêtre de 30 s sous verrou consultatif. Une observation ne crée jamais de mouvement de stock.
- **automatisations** : règles paramétrables et alertes dédupliquées. Les propositions d'action passent par une approbation humaine. Prévisions, anomalies, risque de rupture et répartition : voir `automatisation-et-modeles.md`.
- **analyses** : indicateurs définis, fraîcheur et lacunes des données (`indicateurs.md`).

## Garanties transactionnelles testées

| Garantie | Mécanisme | Test |
|---|---|---|
| Pas de double allocation | UPDATE conditionnel + réévaluation PostgreSQL sous verrou ; index unique partiel « une réservation active par ligne » | `test_reservations_concurrentes_sans_double_allocation` (20 commandes concurrentes, 10 pièces) |
| Stock jamais négatif | `SELECT … FOR UPDATE` + `CHECK quantity >= 0`, ordre de verrouillage déterministe | `test_solde_jamais_negatif_et_sorties_concurrentes` |
| Paiement unique | clé d'idempotence unique en base + point de sauvegarde | `test_paiement_duplique_meme_cle_concurrent` (8 requêtes simultanées) |
| Historique intact | prix datés à exclusion de chevauchement, lignes de vente figées | `test_prix_fige_a_la_vente`, `test_chevauchement_de_prix_interdit_par_la_base` |
| Cohérence après incident | `check_consistency()` : soldes = Σ mouvements, positions = Σ soldes, réservé = Σ réservations | utilisé dans plusieurs tests et après restauration |
