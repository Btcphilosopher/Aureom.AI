# Résultats de tests réellement obtenus

Exécutions du 28/11/2026, dans le conteneur de développement : Linux, Python 3.13.18, PostgreSQL 16.15, Docker 29.9.3, Hyperledger Fabric 2.5.16 (images via `mirror.gcr.io`). Aucun chiffre ci-dessous n'est estimé : tous proviennent de ces exécutions.

## 1. Backend : `pytest` (PostgreSQL réel, registre simulé)

Résumé : **44 passed, 1 skipped in 74.97s** (le test ignoré est l'intégration Fabric, exécutée à part, §2)

| Fichier | Test | Résultat |
|---|---|---|
| `test_fabric_integration.py` | `test_cycle_complet_sur_fabric` | ignoré (Fabric, exécuté à part) |
| `test_ledger_sync.py` | `test_publication_signature_et_rejeu` | ✔ réussi |
| `test_ledger_sync.py` | `test_conflit_meme_identifiant_contenu_different` | ✔ réussi |
| `test_ledger_sync.py` | `test_champs_non_autorises_et_donnees_personnelles` | ✔ réussi |
| `test_ledger_sync.py` | `test_panne_reprise_et_confirmation` | ✔ réussi |
| `test_ledger_sync.py` | `test_issue_inconnue_resolue_par_lecture_du_registre` | ✔ réussi |
| `test_ledger_sync.py` | `test_reprise_apres_arret_brutal_du_worker` | ✔ réussi |
| `test_ledger_sync.py` | `test_ordre_de_publication_respecte` | ✔ réussi |
| `test_ledger_sync.py` | `test_correction_d_un_evenement_d_une_autre_organisation_refusee` | ✔ réussi |
| `test_ledger_sync.py` | `test_transfert_de_garde_provisoire_puis_confirme` | ✔ réussi |
| `test_ledger_sync.py` | `test_cle_inconnue_ou_revoquee` | ✔ réussi |
| `test_ledger_sync.py` | `test_verification_independante_separation_des_taches` | ✔ réussi |
| `test_payments_permissions.py` | `test_paiement_duplique_meme_cle_concurrent` | ✔ réussi |
| `test_payments_permissions.py` | `test_meme_cle_autre_montant_refusee` | ✔ réussi |
| `test_payments_permissions.py` | `test_trop_percu_et_paiement_partiel` | ✔ réussi |
| `test_payments_permissions.py` | `test_carte_refusee_et_paiement_en_attente` | ✔ réussi |
| `test_payments_permissions.py` | `test_evenement_rejoue_falsifie_ou_montant_errone` | ✔ réussi |
| `test_payments_permissions.py` | `test_aucune_donnee_de_carte` | ✔ réussi |
| `test_payments_permissions.py` | `test_remboursement_plafonne` | ✔ réussi |
| `test_payments_permissions.py` | `test_permissions_par_role` | ✔ réussi |
| `test_payments_permissions.py` | `test_perimetre_site` | ✔ réussi |
| `test_payments_permissions.py` | `test_donnees_personnelles_masquees` | ✔ réussi |
| `test_payments_permissions.py` | `test_plafonds_et_separation_des_taches` | ✔ réussi |
| `test_payments_permissions.py` | `test_remise_au_dela_du_plafond` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_restauration_puis_reconciliation` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_rfid_doublons_et_concurrence_sans_mouvement` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_temperature_qualite_et_unites` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_commande_paye_n_est_pas_prete_et_remise_exige_paiement` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_commande_pro_ht_et_fractionnement` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_retour_rembourse_ne_remet_pas_en_stock` | ✔ réussi |
| `test_restore_iot_orders.py` | `test_prevision_evaluee_sur_periode_distincte` | ✔ réussi |
| `test_stock_concurrency.py` | `test_reservations_concurrentes_sans_double_allocation` | ✔ réussi |
| `test_stock_concurrency.py` | `test_solde_jamais_negatif_et_sorties_concurrentes` | ✔ réussi |
| `test_stock_concurrency.py` | `test_correction_liee_sans_reecriture` | ✔ réussi |
| `test_stock_concurrency.py` | `test_prix_fige_a_la_vente` | ✔ réussi |
| `test_stock_concurrency.py` | `test_chevauchement_de_prix_interdit_par_la_base` | ✔ réussi |
| `test_stock_concurrency.py` | `test_vente_sans_stock_systeme_cree_une_exception` | ✔ réussi |
| `test_stock_concurrency.py` | `test_transfert_sans_lot_affecte_en_fefo_et_annulable` | ✔ réussi |
| `test_units_money.py` | `test_conversions_meme_dimension` | ✔ réussi |
| `test_units_money.py` | `test_conversion_entre_dimensions_refusee` | ✔ réussi |
| `test_units_money.py` | `test_pieces_entieres_et_precision` | ✔ réussi |
| `test_units_money.py` | `test_conditionnements_piece_paquet_carton_palette` | ✔ réussi |
| `test_units_money.py` | `test_montants_centimes_exacts` | ✔ réussi |
| `test_units_money.py` | `test_format_francais` | ✔ réussi |
| `test_units_money.py` | `test_gtin` | ✔ réussi |

Couverture fonctionnelle des points demandés :

| Exigence de test | Tests |
|---|---|
| Conversions d'unités et de conditionnements | `test_conversions_meme_dimension`, `test_conversion_entre_dimensions_refusee`, `test_pieces_entieres_et_precision`, `test_conditionnements_piece_paquet_carton_palette` |
| Montants | `test_montants_centimes_exacts`, `test_format_francais`, `test_commande_pro_ht_et_fractionnement`, `test_remise_au_dela_du_plafond` |
| Réservations concurrentes | `test_reservations_concurrentes_sans_double_allocation` (20 fils, 10 pièces : 3 réservations de 3 acceptées, 17 refusées), `test_solde_jamais_negatif_et_sorties_concurrentes` |
| Paiements dupliqués | `test_paiement_duplique_meme_cle_concurrent` (8 requêtes simultanées → 1 paiement), `test_meme_cle_autre_montant_refusee`, `test_remboursement_plafonne` |
| Permissions | `test_permissions_par_role`, `test_perimetre_site`, `test_donnees_personnelles_masquees`, `test_plafonds_et_separation_des_taches`, `test_remise_au_dela_du_plafond` |
| Signatures | `test_publication_signature_et_rejeu` (contenu altéré → BAD_SIGNATURE), `test_cle_inconnue_ou_revoquee`, `test_correction_d_un_evenement_d_une_autre_organisation_refusee` (signature fournisseur vérifiée hors chaîne) |
| Événements rejoués | `test_publication_signature_et_rejeu` (DUPLICATE), `test_conflit_meme_identifiant_contenu_different` (CONFLICT), `test_evenement_rejoue_falsifie_ou_montant_errone` (webhook rejoué, falsifié, horodatage ancien, montant erroné) |
| Pertes de connexion | `test_panne_reprise_et_confirmation`, `test_issue_inconnue_resolue_par_lecture_du_registre`, `test_reprise_apres_arret_brutal_du_worker`, `test_ordre_de_publication_respecte` |
| Restauration | `test_restauration_puis_reconciliation` (pg_dump → activité → pg_restore → cohérence → orphelin détecté et réimporté) |

## 2. Intégration avec Hyperledger Fabric

`AUREOM_TEST_FABRIC=1 … pytest tests/test_fabric_integration.py -s` :

```
tests/test_fabric_integration.py::test_cycle_complet_sur_fabric latence publication Fabric : 321 ms
PASSED
============================== 1 passed in 3.04s ===============================
```

Le test couvre : publication par la boîte d'envoi, numéro de bloc, rejeu identique → DUPLICATE, même eventId et contenu différent → 409 CONFLICT, champ non autorisé (`clientEmail`) → 422, lecture du même événement depuis la passerelle d'une **autre** organisation, et vérification de la signature hors chaîne.

## 3. Registre : chaincode et passerelle (`ledger/`)

- `go test ./...` (chaincode) : `ok …/contract`, 7 tests et 27 sous-tests, couverture de 80,9 % (mesurée par l'agent de construction du registre).
- `npm run build` (passerelle TypeScript strict) : sans erreur.
- `node ledger/tests/e2e.mjs` : **45/45 vérifications réussies** (sortie complète dans `ledger/tests/e2e-resultats.txt`). Latence `RecordEvent`, de l'aller-retour HTTP jusqu'à la validation du bloc : min 279 ms, médiane 284 ms, p95 295 ms (BatchTimeout 250 ms, 3 orderers Raft, endossement 2 sur 3, même hôte). L'arrêt d'un pair donne 503 retryable, les 2 autres organisations continuent, puis le pair rattrape les blocs.

## 4. Démonstration en 14 étapes

| Mode | Durée | Résultat | Journal |
|---|---|---|---|
| Registre simulé | ~6 s | toutes les assertions réussies | `docs/demo/simulation/journal-demo.md` |
| Fabric, coupure **réelle** de la passerelle à l'étape 13 | ~11 s | toutes les assertions réussies | `docs/demo/fabric/journal-demo.md` |

Fichiers produits : ticket de démonstration et rapport de traçabilité du lot de miel (JSON, HTML, CSV) dans chaque dossier.
En mode Fabric, la réconciliation signale comme « orphelins » les événements laissés sur le registre par les exécutions précédentes de la démo : la base a été réinitialisée, pas le registre. C'est le comportement attendu, identique à celui d'une restauration de sauvegarde.

## 5. Pile Docker Compose

Vérifié avec `REGISTRY=mirror.gcr.io/library` :
- construction de l'image backend ; démarrage de `postgres`, `objets` (SeaweedFS 4.55), `mqtt` (Mosquitto 2), `backend` (sain), `worker`, `iot-bridge` ;
- migrations Alembic et jeu de démonstration au premier démarrage ;
- simulateurs MQTT → pont → base : 11 relevés de température (1 marqué invalide), 4 pesées, 4 états convoyeur, 3 prélèvements, lectures RFID agrégées (4 et 10 lectures en 2 observations), alertes température, convoyeur et RFID créées ;
- ACL Mosquitto : un équipement qui publie sur le sujet d'un autre est ignoré (0 observation), un identifiant inconnu est refusé ;
- stockage S3 : dépôt d'un certificat par l'API, relecture depuis SeaweedFS avec contrôle d'empreinte ;
- surcouche Fabric : événement déclaré par l'API, publié par le worker conteneurisé, confirmé (bloc 54) ;
- `scripts/sauvegarde.sh` puis `scripts/restauration.sh` : stock cohérent, réconciliation sans anomalie.

## 6. Interface web (React 19 + TypeScript)

- `npm run build` : 0 erreur TypeScript (mode strict) ; `npm audit` : 0 vulnérabilité signalée.
- Parcours joués avec Playwright contre l'API réelle :
  - vente complète en caisse : ouverture au pavé numérique, deux scans rapides mis en file d'attente, remise de 20 % refusée puis 10 % acceptée, paiement partiel carte (double clic → une seule requête), espèces avec rendu, ticket, clôture avec écart ;
  - préparation en entrepôt : mauvais article refusé, prélèvements, code de retrait, réception d'un transfert.
- Image Docker `aureom/frontend` construite par Compose et servie par nginx. Dans la pile complète : index et lien profond en 200, `/api` relayé, connexion et tableau de bord sans erreur console.
- 24 captures au facteur 2 dans `docs/captures/` (bureau 1440×900, caisse tactile 1280×800, tablette 1024×768, mobile 390 px).
- Défauts relevés par ces essais puis corrigés côté backend : transfert d'un article suivi par lot sans lot indiqué (affectation FEFO dès la création, nouveau test) ; 4 derniers chiffres de la carte tronqués sur le ticket ; permission de lecture des achats pour le rôle préparateur ; « reste à payer » erroné après remboursement d'une vente terminée.

## 7. Migrations

`alembic upgrade head` sur base vide, puis `alembic check` (« No new upgrade operations detected » : aucun écart avec les modèles), puis jeu de démonstration, puis `alembic downgrade base` : tout réussit.

## 8. Non testé ou limites

- Le cas 504 `COMMIT_UNKNOWN` n'a pas été provoqué sur le réseau réel. Son traitement est testé en simulation (`test_issue_inconnue_resolue_par_lecture_du_registre`).
- Pas de test de charge au-delà de la concurrence indiquée ci-dessus.
- Les réponses de l'OpenAPI n'ont pas de schéma typé (entrées typées, sorties en JSON libre).
- Le fonctionnement sans proxy ni miroir n'est pas vérifié : la construction a eu lieu derrière le proxy du bac à sable.
- Les exigences réglementaires n'ont pas pu être vérifiées sur les sites officiels, inaccessibles depuis le bac à sable (voir `conformite-et-cadre.md`).
