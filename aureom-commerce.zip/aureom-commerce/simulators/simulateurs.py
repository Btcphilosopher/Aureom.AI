"""Simulateurs d'équipements (lecture seule) publiant sur MQTT — AUREOM COMMERCE.

Chaque équipement publie sur aureom/<site>/<type>/<code> avec son identifiant MQTT = son code.
Scénarios :
  temperature  : sonde cellule épicerie, dérive puis excursion au-dessus de 25 °C, une valeur aberrante
  rfid         : portique de sortie, lectures dupliquées d'une même étiquette (rafales)
  balance      : pesées instables puis stables (kg)
  convoyeur    : états de marche, un bourrage
  preparation  : pick-to-light, confirmations de prélèvement
  tout         : tous les scénarios en parallèle
Usage : python simulateurs.py tout --host localhost --port 1883 --password …
Les valeurs sont SIMULÉES ; aucun équipement réel n'est piloté.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import threading
import time
import uuid
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

DEVICES = {
    "temperature": ("ENT-ORL", "capteur_temperature", "TEMP-ENT-EPI"),
    "rfid": ("MAG-PAR", "lecteur_rfid", "RFID-PAR-SORTIE"),
    "balance": ("MAG-PAR", "balance", "BAL-PAR-01"),
    "convoyeur": ("ENT-ORL", "convoyeur", "CONV-ENT-01"),
    "preparation": ("ENT-ORL", "systeme_preparation", "PTL-ENT-01"),
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def client_for(code: str, args) -> mqtt.Client:
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"sim-{code}-{uuid.uuid4().hex[:4]}")
    c.username_pw_set(code, args.password)
    c.connect(args.host, args.port, keepalive=30)
    c.loop_start()
    return c


def publish(c, kind, payload):
    site, typ, code = DEVICES[kind]
    topic = f"aureom/{site}/{typ}/{code}"
    info = c.publish(topic, json.dumps(payload), qos=1)
    info.wait_for_publish(5)
    print(f"[{kind}] {topic} {payload}", flush=True)


def temperature(args):
    c = client_for(DEVICES["temperature"][2], args)
    values = [21.8, 22.3, 22.9, 23.6, 24.4, 150.0, 25.8, 26.9, 27.4, 26.1, 23.2]
    for i, v in enumerate(values * args.cycles):
        publish(c, "temperature", {"message_id": str(uuid.uuid4()), "value": v, "unit": "CEL",
                                   "observed_at": now(), "sensor_status": "ok"})
        time.sleep(args.interval)


def rfid(args):
    c = client_for(DEVICES["rfid"][2], args)
    tags = [f"3074257BF7194E4000{i:06X}" for i in range(1, 4)]
    for _ in range(args.cycles * 3):
        tag = random.choice(tags)
        for burst in range(random.randint(3, 8)):  # un passage = plusieurs lectures du même EPC
            publish(c, "rfid", {"epc": tag, "antenna": 1 + burst % 2, "rssi": round(random.uniform(-70, -45), 1),
                                "observed_at": now()})
            time.sleep(0.1)
        time.sleep(args.interval)


def balance(args):
    c = client_for(DEVICES["balance"][2], args)
    for _ in range(args.cycles):
        target = round(random.uniform(0.2, 1.5), 3)
        for k in range(4):
            stable = k == 3
            v = target if stable else round(target + random.uniform(-0.05, 0.05), 3)
            publish(c, "balance", {"message_id": str(uuid.uuid4()), "value": v, "unit": "KG", "stable": stable,
                                   "observed_at": now()})
            time.sleep(0.3)
        time.sleep(args.interval)


def convoyeur(args):
    c = client_for(DEVICES["convoyeur"][2], args)
    for i in range(args.cycles * 4):
        state = "BOURRAGE" if i == 2 else "MARCHE"
        publish(c, "convoyeur", {"message_id": str(uuid.uuid4()), "state": state, "value": 0 if state != "MARCHE" else 0.8,
                                 "unit": None, "observed_at": now()})
        time.sleep(args.interval)


def preparation(args):
    c = client_for(DEVICES["preparation"][2], args)
    for i in range(args.cycles * 3):
        publish(c, "preparation", {"message_id": str(uuid.uuid4()), "state": "PRELEVEMENT_CONFIRME",
                                   "slot": f"A-{i % 12:02d}", "observed_at": now()})
        time.sleep(args.interval)


SCENARIOS = {"temperature": temperature, "rfid": rfid, "balance": balance, "convoyeur": convoyeur,
             "preparation": preparation}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("scenario", choices=[*SCENARIOS, "tout"])
    p.add_argument("--host", default=os.environ.get("MQTT_HOST", "localhost"))
    p.add_argument("--port", type=int, default=int(os.environ.get("MQTT_PORT", 1883)))
    p.add_argument("--password", default=os.environ.get("MQTT_PASSWORD", ""))
    p.add_argument("--interval", type=float, default=float(os.environ.get("SIM_INTERVAL", 2)))
    p.add_argument("--cycles", type=int, default=int(os.environ.get("SIM_CYCLES", 1)))
    args = p.parse_args()
    if args.scenario == "tout":
        th = [threading.Thread(target=f, args=(args,)) for f in SCENARIOS.values()]
        [t.start() for t in th]
        [t.join() for t in th]
    else:
        SCENARIOS[args.scenario](args)


if __name__ == "__main__":
    main()
