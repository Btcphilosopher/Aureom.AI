import { createPrivateKey } from 'node:crypto';
import * as grpc from '@grpc/grpc-js';
import { connect, hash, signers, type Contract, type Gateway, type Network } from '@hyperledger/fabric-gateway';
import { readPemFile, type Config } from './config.js';
import { ApiError, commitFailure, mapFabricError } from './errors.js';
import { log } from './log.js';
import { decodeBlockNumber, decodeBlockchainInfo } from './protobuf.js';

const utf8 = new TextDecoder();

export interface SubmitOutcome {
    result: unknown;
    txId: string;
    blockNumber: bigint;
    timings: { endorseAndSubmitMs: number; commitMs: number };
}

export interface ChainInfo {
    height: bigint;
    currentBlockHash: string;
    previousBlockHash: string;
}

/** Accès au canal Fabric via le service Gateway du pair de l'organisation. */
export class Ledger {
    private readonly client: grpc.Client;
    private readonly gateway: Gateway;
    private readonly network: Network;
    private readonly contract: Contract;
    private readonly qscc: Contract;

    constructor(private readonly cfg: Config) {
        const tlsRoot = readPemFile(cfg.tlsCertPath);
        this.client = new grpc.Client(cfg.peerEndpoint, grpc.credentials.createSsl(tlsRoot), {
            'grpc.ssl_target_name_override': cfg.peerHostAlias,
            'grpc.default_authority': cfg.peerHostAlias,
            'grpc.keepalive_time_ms': 30_000,
            'grpc.keepalive_timeout_ms': 10_000,
            'grpc.initial_reconnect_backoff_ms': 500,
            'grpc.max_reconnect_backoff_ms': 5_000,
        });
        const credentials = readPemFile(cfg.certPath);
        const privateKey = createPrivateKey(readPemFile(cfg.keyPath));
        const d = cfg.deadlines;
        this.gateway = connect({
            client: this.client,
            identity: { mspId: cfg.mspId, credentials },
            signer: signers.newPrivateKeySigner(privateKey),
            hash: hash.sha256,
            evaluateOptions: () => ({ deadline: Date.now() + d.evaluateMs }),
            endorseOptions: () => ({ deadline: Date.now() + d.endorseMs }),
            submitOptions: () => ({ deadline: Date.now() + d.submitMs }),
            commitStatusOptions: () => ({ deadline: Date.now() + d.commitStatusMs }),
        });
        this.network = this.gateway.getNetwork(cfg.channel);
        this.contract = this.network.getContract(cfg.chaincode);
        this.qscc = this.network.getContract('qscc');
    }

    /**
     * Échec rapide si le pair local est injoignable : sans cela, gRPC met
     * l'appel en attente jusqu'à l'échéance (15 s pour l'endossement).
     */
    private async ensureConnected(): Promise<void> {
        const state = this.client.getChannel().getConnectivityState(true);
        if (state === grpc.connectivityState.READY) {
            return;
        }
        await new Promise<void>((resolve, reject) => {
            this.client.waitForReady(Date.now() + this.cfg.deadlines.healthMs, (err) => (err ? reject(err) : resolve()));
        }).catch(() => {
            throw new ApiError(
                503,
                'LEDGER_UNAVAILABLE',
                `pair ${this.cfg.peerEndpoint} injoignable (état gRPC ${grpc.connectivityState[this.client.getChannel().getConnectivityState(false)]})`,
                true,
            );
        });
    }

    /** Évalue (lecture seule, non ordonnée) une transaction du chaincode. */
    async evaluate(fn: string, args: string[]): Promise<unknown> {
        await this.ensureConnected();
        try {
            const bytes = await this.contract.evaluate(fn, { arguments: args });
            return parseJson(bytes);
        } catch (err) {
            throw mapFabricError(err);
        }
    }

    /**
     * Endosse, soumet puis attend le statut de validation de la transaction.
     * Les délais (endossement 15 s, envoi 5 s, statut 60 s) viennent de la config.
     */
    async submit(fn: string, args: string[]): Promise<SubmitOutcome> {
        await this.ensureConnected();
        const t0 = performance.now();
        let txId = '';
        try {
            const submitted = await this.contract.submitAsync(fn, { arguments: args });
            txId = submitted.getTransactionId();
            const t1 = performance.now();
            const result = parseJson(submitted.getResult());
            const status = await submitted.getStatus();
            const t2 = performance.now();
            if (!status.successful) {
                throw commitFailure(status.code, status.transactionId);
            }
            return {
                result,
                txId,
                blockNumber: status.blockNumber,
                timings: { endorseAndSubmitMs: round(t1 - t0), commitMs: round(t2 - t1) },
            };
        } catch (err) {
            const mapped = mapFabricError(err);
            if (txId !== '' && mapped.extra.txId === undefined) {
                mapped.extra.txId = txId;
            }
            throw mapped;
        }
    }

    /** Hauteur et empreinte du dernier bloc (qscc GetChainInfo). */
    async chainInfo(): Promise<ChainInfo> {
        try {
            const bytes = await this.qscc.evaluate('GetChainInfo', { arguments: [this.cfg.channel] });
            return decodeBlockchainInfo(bytes);
        } catch (err) {
            throw mapFabricError(err);
        }
    }

    /** Sonde de santé avec un délai court, indépendant des délais par défaut. */
    async probe(): Promise<ChainInfo> {
        await this.ensureConnected();
        const proposal = this.qscc.newProposal('GetChainInfo', { arguments: [this.cfg.channel] });
        try {
            const bytes = await proposal.evaluate({ deadline: Date.now() + this.cfg.deadlines.healthMs });
            return decodeBlockchainInfo(bytes);
        } catch (err) {
            throw mapFabricError(err);
        }
    }

    /** Numéro du bloc contenant une transaction (qscc GetBlockByTxID), ou null. */
    async blockNumberOfTx(txId: string): Promise<bigint | null> {
        try {
            const bytes = await this.qscc.evaluate('GetBlockByTxID', { arguments: [this.cfg.channel, txId] });
            return decodeBlockNumber(bytes);
        } catch (err) {
            log.warn('numéro de bloc introuvable', { txId, error: err instanceof Error ? err.message : String(err) });
            return null;
        }
    }

    close(): void {
        this.gateway.close();
        this.client.close();
    }
}

function parseJson(bytes: Uint8Array): unknown {
    const text = utf8.decode(bytes);
    if (text === '') {
        return null;
    }
    try {
        return JSON.parse(text) as unknown;
    } catch {
        throw new ApiError(502, 'BAD_CHAINCODE_RESPONSE', 'réponse du chaincode non JSON', false);
    }
}

function round(ms: number): number {
    return Math.round(ms * 10) / 10;
}
