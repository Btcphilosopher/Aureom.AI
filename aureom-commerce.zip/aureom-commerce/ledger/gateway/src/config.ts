import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

/** Configuration de la passerelle, lue exclusivement depuis l'environnement. */
export interface Config {
    mspId: string;
    peerEndpoint: string;
    peerHostAlias: string;
    tlsCertPath: string;
    certPath: string;
    keyPath: string;
    channel: string;
    chaincode: string;
    port: number;
    host: string;
    gatewayToken: string;
    deadlines: {
        endorseMs: number;
        submitMs: number;
        commitStatusMs: number;
        evaluateMs: number;
        healthMs: number;
    };
}

function required(name: string): string {
    const v = process.env[name];
    if (v === undefined || v.trim() === '') {
        throw new Error(`variable d'environnement ${name} manquante`);
    }
    return v.trim();
}

function optional(name: string, fallback: string): string {
    const v = process.env[name];
    return v === undefined || v.trim() === '' ? fallback : v.trim();
}

function intEnv(name: string, fallback: number): number {
    const raw = optional(name, String(fallback));
    const n = Number.parseInt(raw, 10);
    if (!Number.isFinite(n) || n <= 0) {
        throw new Error(`variable d'environnement ${name} invalide : ${raw}`);
    }
    return n;
}

export function loadConfig(): Config {
    const gatewayToken = required('GATEWAY_TOKEN');
    if (gatewayToken.length < 16) {
        throw new Error('GATEWAY_TOKEN doit contenir au moins 16 caractères');
    }
    return {
        mspId: required('MSP_ID'),
        peerEndpoint: required('PEER_ENDPOINT'),
        peerHostAlias: optional('PEER_HOST_ALIAS', required('PEER_ENDPOINT').split(':')[0] ?? ''),
        tlsCertPath: required('TLS_CERT_PATH'),
        certPath: required('CERT_PATH'),
        keyPath: required('KEY_PATH'),
        channel: optional('CHANNEL', 'tracabilite'),
        chaincode: optional('CHAINCODE', 'tracabilite'),
        port: intEnv('PORT', 8800),
        host: optional('HOST', '0.0.0.0'),
        gatewayToken,
        deadlines: {
            endorseMs: intEnv('ENDORSE_TIMEOUT_MS', 15_000),
            submitMs: intEnv('SUBMIT_TIMEOUT_MS', 5_000),
            commitStatusMs: intEnv('COMMIT_STATUS_TIMEOUT_MS', 60_000),
            evaluateMs: intEnv('EVALUATE_TIMEOUT_MS', 5_000),
            healthMs: intEnv('HEALTH_TIMEOUT_MS', 3_000),
        },
    };
}

/**
 * Lit un fichier PEM ; si le chemin est un répertoire (ex. « keystore » ou
 * « signcerts » produits par cryptogen / Fabric CA), le premier fichier
 * régulier (ordre alphabétique) est utilisé.
 */
export function readPemFile(p: string): Buffer {
    const st = statSync(p);
    if (st.isDirectory()) {
        const files = readdirSync(p)
            .filter((f) => statSync(path.join(p, f)).isFile())
            .sort();
        const first = files[0];
        if (first === undefined) {
            throw new Error(`aucun fichier dans le répertoire ${p}`);
        }
        return readFileSync(path.join(p, first));
    }
    return readFileSync(p);
}
