/**
 * Journalisation en JSON Lines sur la sortie standard. Ne jamais y passer de
 * clé privée, de jeton ni de corps de requête complet.
 */
type Level = 'debug' | 'info' | 'warn' | 'error';

const order: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };
const minLevel: Level = ((): Level => {
    const v = (process.env.LOG_LEVEL ?? 'info').toLowerCase();
    return v === 'debug' || v === 'warn' || v === 'error' ? v : 'info';
})();

function write(level: Level, msg: string, fields: Record<string, unknown> = {}): void {
    if (order[level] < order[minLevel]) {
        return;
    }
    const line = JSON.stringify(
        { ts: new Date().toISOString(), level, msg, ...fields },
        (_k, v: unknown) => (typeof v === 'bigint' ? v.toString() : v),
    );
    process.stdout.write(line + '\n');
}

export const log = {
    debug: (msg: string, fields?: Record<string, unknown>) => write('debug', msg, fields),
    info: (msg: string, fields?: Record<string, unknown>) => write('info', msg, fields),
    warn: (msg: string, fields?: Record<string, unknown>) => write('warn', msg, fields),
    error: (msg: string, fields?: Record<string, unknown>) => write('error', msg, fields),
};
