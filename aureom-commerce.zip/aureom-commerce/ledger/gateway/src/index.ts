import { loadConfig } from './config.js';
import { Ledger } from './fabric.js';
import { log } from './log.js';
import { buildServer } from './server.js';

function main(): void {
    const cfg = loadConfig();
    const ledger = new Ledger(cfg);
    const server = buildServer(cfg, ledger);
    server.keepAliveTimeout = 65_000;
    server.requestTimeout = cfg.deadlines.endorseMs + cfg.deadlines.submitMs + cfg.deadlines.commitStatusMs + 10_000;

    server.listen(cfg.port, cfg.host, () => {
        log.info('passerelle registre démarrée', {
            mspId: cfg.mspId,
            peerEndpoint: cfg.peerEndpoint,
            peerHostAlias: cfg.peerHostAlias,
            channel: cfg.channel,
            chaincode: cfg.chaincode,
            port: cfg.port,
            deadlines: cfg.deadlines,
        });
    });

    let stopping = false;
    const stop = (signal: string): void => {
        if (stopping) {
            return;
        }
        stopping = true;
        log.info('arrêt demandé', { signal });
        server.close(() => {
            ledger.close();
            log.info('passerelle arrêtée');
            process.exit(0);
        });
        setTimeout(() => process.exit(0), 10_000).unref();
    };
    process.on('SIGTERM', () => stop('SIGTERM'));
    process.on('SIGINT', () => stop('SIGINT'));
}

try {
    main();
} catch (err) {
    log.error('démarrage impossible', { error: err instanceof Error ? err.message : String(err) });
    process.exit(1);
}
