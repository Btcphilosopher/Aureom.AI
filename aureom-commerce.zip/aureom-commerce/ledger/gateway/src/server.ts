import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { Config } from './config.js';
import { ApiError } from './errors.js';
import type { Ledger } from './fabric.js';
import { log } from './log.js';

const MAX_BODY_BYTES = 256 * 1024;

type Handler = (ctx: RequestContext) => Promise<Reply>;

interface RequestContext {
    req: IncomingMessage;
    params: string[];
    body: () => Promise<Record<string, unknown>>;
    requestId: string;
}

interface Reply {
    status: number;
    body: unknown;
    headers?: Record<string, string>;
    logFields?: Record<string, unknown>;
}

interface Route {
    method: 'GET' | 'POST';
    pattern: string[]; // segments ; ':x' = paramètre
    auth: boolean;
    handler: Handler;
}

function jsonReplacer(_k: string, v: unknown): unknown {
    return typeof v === 'bigint' ? Number(v) : v;
}

function bad(message: string): ApiError {
    return new ApiError(400, 'BAD_REQUEST', message, false);
}

function str(body: Record<string, unknown>, field: string): string {
    const v = body[field];
    if (typeof v !== 'string' || v === '') {
        throw bad(`le champ « ${field} » (chaîne non vide) est obligatoire`);
    }
    return v;
}

function asRecord(v: unknown): Record<string, unknown> {
    return typeof v === 'object' && v !== null && !Array.isArray(v) ? (v as Record<string, unknown>) : {};
}

function param(ctx: RequestContext, i: number): string {
    const v = ctx.params[i];
    if (v === undefined || v === '') {
        throw bad('paramètre de chemin manquant');
    }
    return v;
}

export function buildServer(cfg: Config, ledger: Ledger): Server {
    const expectedToken = createHash('sha256').update(cfg.gatewayToken).digest();

    const routes: Route[] = [
        {
            method: 'GET',
            pattern: ['health'],
            auth: false,
            handler: async () => {
                try {
                    const info = await ledger.probe();
                    return {
                        status: 200,
                        body: {
                            status: 'ok',
                            mspId: cfg.mspId,
                            channel: cfg.channel,
                            chaincode: cfg.chaincode,
                            peerEndpoint: cfg.peerEndpoint,
                            blockHeight: info.height,
                        },
                    };
                } catch (err) {
                    const e = err instanceof ApiError ? err : new ApiError(503, 'LEDGER_UNAVAILABLE', String(err), true);
                    return {
                        status: 503,
                        body: { status: 'indisponible', error: e.message, mspId: cfg.mspId, peerEndpoint: cfg.peerEndpoint },
                    };
                }
            },
        },
        {
            method: 'GET',
            pattern: ['v1', 'status'],
            auth: true,
            handler: async () => {
                const info = await ledger.chainInfo();
                return {
                    status: 200,
                    body: {
                        mspId: cfg.mspId,
                        channel: cfg.channel,
                        chaincode: cfg.chaincode,
                        blockHeight: info.height,
                        currentBlockHash: info.currentBlockHash,
                        previousBlockHash: info.previousBlockHash,
                    },
                };
            },
        },
        {
            method: 'POST',
            pattern: ['v1', 'events'],
            auth: true,
            handler: async (ctx) => {
                const body = await ctx.body();
                const envelope = str(body, 'envelope');
                const signature = str(body, 'signature');
                const out = await ledger.submit('RecordEvent', [envelope, signature]);
                const r = asRecord(out.result);
                const timing = `endorse_submit;dur=${out.timings.endorseAndSubmitMs}, commit;dur=${out.timings.commitMs}`;
                if (r.status === 'DUPLICATE') {
                    const originalTxId = typeof r.txId === 'string' ? r.txId : '';
                    const blockNumber = originalTxId !== '' ? await ledger.blockNumberOfTx(originalTxId) : null;
                    return {
                        status: 201,
                        headers: { 'Server-Timing': timing },
                        body: {
                            status: 'DUPLICATE',
                            eventId: r.eventId,
                            txId: originalTxId,
                            payloadSha256: r.payloadSha256,
                            txTimestamp: r.txTimestamp,
                            blockNumber,
                            submissionTxId: out.txId,
                            keyStatus: r.keyStatus,
                        },
                        logFields: { eventId: r.eventId, txId: out.txId, outcome: 'DUPLICATE', ...out.timings },
                    };
                }
                return {
                    status: 201,
                    headers: { 'Server-Timing': timing },
                    body: {
                        status: r.status,
                        eventId: r.eventId,
                        txId: r.txId,
                        payloadSha256: r.payloadSha256,
                        txTimestamp: r.txTimestamp,
                        blockNumber: out.blockNumber,
                    },
                    logFields: { eventId: r.eventId, txId: out.txId, blockNumber: out.blockNumber, outcome: r.status, ...out.timings },
                };
            },
        },
        {
            method: 'GET',
            pattern: ['v1', 'events', ':eventId'],
            auth: true,
            handler: async (ctx) => {
                const view = asRecord(await ledger.evaluate('GetEvent', [param(ctx, 0)]));
                const txId = typeof view.txId === 'string' ? view.txId : '';
                const blockNumber = txId !== '' ? await ledger.blockNumberOfTx(txId) : null;
                return { status: 200, body: { ...view, blockNumber } };
            },
        },
        {
            method: 'GET',
            pattern: ['v1', 'subjects', ':ref', 'events'],
            auth: true,
            handler: async (ctx) => ({ status: 200, body: await ledger.evaluate('QueryEventsBySubject', [param(ctx, 0)]) }),
        },
        {
            method: 'POST',
            pattern: ['v1', 'events', 'batch-get'],
            auth: true,
            handler: async (ctx) => {
                const body = await ctx.body();
                const ids = body.eventIds;
                if (!Array.isArray(ids) || !ids.every((x) => typeof x === 'string')) {
                    throw bad('le champ « eventIds » (tableau de chaînes) est obligatoire');
                }
                return { status: 200, body: await ledger.evaluate('GetEventsByIds', [JSON.stringify(ids)]) };
            },
        },
        {
            method: 'POST',
            pattern: ['v1', 'keys'],
            auth: true,
            handler: async (ctx) => {
                const body = await ctx.body();
                const out = await ledger.submit('RegisterSigningKey', [
                    str(body, 'keyId'),
                    str(body, 'publicKeyBase64'),
                    str(body, 'validFrom'),
                ]);
                return { status: 201, body: { ...asRecord(out.result), txId: out.txId, blockNumber: out.blockNumber } };
            },
        },
        {
            method: 'POST',
            pattern: ['v1', 'keys', ':keyId', 'retire'],
            auth: true,
            handler: async (ctx) => {
                const body = await ctx.body();
                const out = await ledger.submit('RetireSigningKey', [param(ctx, 0), str(body, 'retiredAt')]);
                return { status: 200, body: { ...asRecord(out.result), txId: out.txId, blockNumber: out.blockNumber } };
            },
        },
        {
            method: 'POST',
            pattern: ['v1', 'keys', ':keyId', 'revoke'],
            auth: true,
            handler: async (ctx) => {
                const body = await ctx.body();
                const out = await ledger.submit('RevokeSigningKey', [param(ctx, 0), str(body, 'revokedAt'), str(body, 'reason')]);
                return { status: 200, body: { ...asRecord(out.result), txId: out.txId, blockNumber: out.blockNumber } };
            },
        },
        {
            method: 'GET',
            pattern: ['v1', 'keys', ':keyId'],
            auth: true,
            handler: async (ctx) => ({ status: 200, body: await ledger.evaluate('GetSigningKey', [param(ctx, 0)]) }),
        },
    ];

    function match(method: string, segments: string[]): { route: Route; params: string[] } | 'method' | undefined {
        let methodMismatch = false;
        for (const route of routes) {
            if (route.pattern.length !== segments.length) {
                continue;
            }
            const params: string[] = [];
            const ok = route.pattern.every((p, i) => {
                const s = segments[i] ?? '';
                if (p.startsWith(':')) {
                    params.push(s);
                    return s !== '';
                }
                return p === s;
            });
            if (!ok) {
                continue;
            }
            if (route.method !== method) {
                methodMismatch = true;
                continue;
            }
            return { route, params };
        }
        return methodMismatch ? 'method' : undefined;
    }

    function authorized(req: IncomingMessage): boolean {
        const h = req.headers.authorization ?? '';
        const m = /^Bearer\s+(.+)$/i.exec(h);
        if (m?.[1] === undefined) {
            return false;
        }
        const got = createHash('sha256').update(m[1].trim()).digest();
        return timingSafeEqual(got, expectedToken);
    }

    function readBody(req: IncomingMessage): Promise<Record<string, unknown>> {
        return new Promise((resolve, reject) => {
            const chunks: Buffer[] = [];
            let size = 0;
            req.on('data', (c: Buffer) => {
                size += c.length;
                if (size > MAX_BODY_BYTES) {
                    reject(new ApiError(413, 'PAYLOAD_TOO_LARGE', `corps de requête limité à ${MAX_BODY_BYTES} octets`, false));
                    req.destroy();
                    return;
                }
                chunks.push(c);
            });
            req.on('end', () => {
                try {
                    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'));
                    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
                        reject(bad('un objet JSON est attendu'));
                        return;
                    }
                    resolve(parsed as Record<string, unknown>);
                } catch {
                    reject(bad('corps JSON invalide'));
                }
            });
            req.on('error', reject);
        });
    }

    function send(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
        const payload = JSON.stringify(body, jsonReplacer);
        res.writeHead(status, {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store',
            'X-Content-Type-Options': 'nosniff',
            ...headers,
        });
        res.end(payload);
    }

    return createServer((req, res) => {
        const started = performance.now();
        const headerId = req.headers['x-request-id'];
        const requestId = typeof headerId === 'string' && /^[\w.:-]{1,100}$/.test(headerId) ? headerId : randomUUID();
        const url = new URL(req.url ?? '/', 'http://localhost');
        const method = req.method ?? 'GET';
        let logFields: Record<string, unknown> = {};

        const finish = (status: number, body: unknown, headers: Record<string, string> = {}): void => {
            send(res, status, body, { 'X-Request-Id': requestId, ...headers });
            const durationMs = Math.round((performance.now() - started) * 10) / 10;
            const level = status >= 500 ? 'warn' : 'info';
            log[level]('requête HTTP', { requestId, method, path: url.pathname, status, durationMs, ...logFields });
        };

        void (async () => {
            try {
                let segments: string[];
                try {
                    segments = url.pathname.split('/').filter((s) => s !== '').map((s) => decodeURIComponent(s));
                } catch {
                    throw bad('chemin mal encodé');
                }
                const m = match(method, segments);
                if (m === undefined) {
                    throw new ApiError(404, 'ROUTE_NOT_FOUND', `route inconnue : ${method} ${url.pathname}`, false);
                }
                if (m === 'method') {
                    throw new ApiError(405, 'METHOD_NOT_ALLOWED', `méthode ${method} non autorisée`, false);
                }
                if (m.route.auth && !authorized(req)) {
                    throw new ApiError(401, 'UNAUTHORIZED', 'jeton Bearer absent ou invalide', false);
                }
                const reply = await m.route.handler({ req, params: m.params, body: () => readBody(req), requestId });
                logFields = reply.logFields ?? {};
                finish(reply.status, reply.body, reply.headers);
            } catch (err) {
                const e = err instanceof ApiError ? err : new ApiError(500, 'INTERNAL', err instanceof Error ? err.message : String(err), false);
                logFields = { code: e.code, error: e.message, ...e.extra };
                finish(e.httpStatus, e.toBody());
            }
        })();
    });
}
