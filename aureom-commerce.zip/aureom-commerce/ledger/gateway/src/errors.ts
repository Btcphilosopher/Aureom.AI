import { status as GrpcStatus } from '@grpc/grpc-js';
import { CommitStatusError, EndorseError, GatewayError, StatusCode } from '@hyperledger/fabric-gateway';

/** Erreur prête à être renvoyée au client HTTP. */
export class ApiError extends Error {
    constructor(
        readonly httpStatus: number,
        readonly code: string,
        message: string,
        readonly retryable: boolean,
        readonly extra: Record<string, unknown> = {},
    ) {
        super(message);
        this.name = 'ApiError';
    }

    toBody(): Record<string, unknown> {
        return { code: this.code, message: this.message, retryable: this.retryable, ...this.extra };
    }
}

/** Codes métier renvoyés par le chaincode (préfixe « CODE: » du message). */
const CHAINCODE_CODE = /(?:^|[\s,:])((?:INVALID|UNKNOWN|KEY)_[A-Z_]+|BAD_SIGNATURE|ISSUER_MISMATCH|CORRECTION_NOT_OWNER|CONFLICT|ACCESS_DENIED|NOT_FOUND|INTERNAL): (.*)$/s;

/** Pas assez de pairs joignables pour satisfaire la politique d'endossement (panne, gossip en cours de convergence). */
const NOT_ENOUGH_PEERS = /no (?:combination of peers|peer combination) can|no endorsers? (?:found|available)/i;

const validationNames: Record<number, string> = Object.fromEntries(
    Object.entries(StatusCode).map(([name, code]) => [code as number, name]),
);

/** Codes de validation de bloc pour lesquels une nouvelle soumission a des chances d'aboutir. */
const RETRYABLE_VALIDATION = new Set(['MVCC_READ_CONFLICT', 'PHANTOM_READ_CONFLICT', 'ENDORSEMENT_POLICY_FAILURE']);

export function validationCodeName(code: number): string {
    return validationNames[code] ?? `VALIDATION_${code}`;
}

export function commitFailure(code: number, txId: string): ApiError {
    const name = validationCodeName(code);
    const retryable = RETRYABLE_VALIDATION.has(name);
    return new ApiError(
        409,
        name,
        retryable
            ? `transaction ${txId} invalidée à la validation (${name}) : resoumettre la même enveloppe`
            : `transaction ${txId} invalidée à la validation (${name})`,
        retryable,
        { txId, validationCode: code },
    );
}

function chaincodeCode(err: GatewayError | Error): { code: string; message: string } | undefined {
    const candidates: string[] = [];
    if (err instanceof GatewayError) {
        for (const d of err.details) {
            candidates.push(d.message);
        }
    }
    candidates.push(err.message);
    for (const c of candidates) {
        const m = CHAINCODE_CODE.exec(c);
        if (m?.[1] !== undefined) {
            return { code: m[1], message: (m[2] ?? '').trim() };
        }
    }
    return undefined;
}

function businessError(code: string, message: string): ApiError {
    if (code === 'CONFLICT') {
        return new ApiError(409, code, message, false);
    }
    if (code === 'NOT_FOUND') {
        return new ApiError(404, code, message, false);
    }
    if (code === 'ACCESS_DENIED') {
        return new ApiError(403, code, message, false);
    }
    if (code === 'INTERNAL') {
        return new ApiError(500, code, message, false);
    }
    return new ApiError(422, code, message, false);
}

function isUnavailable(code: number): boolean {
    return code === GrpcStatus.UNAVAILABLE || code === GrpcStatus.DEADLINE_EXCEEDED || code === GrpcStatus.CANCELLED;
}

function ledgerUnavailable(err: GatewayError, extra: Record<string, unknown> = {}): ApiError {
    return new ApiError(
        503,
        'LEDGER_UNAVAILABLE',
        `registre injoignable (${GrpcStatus[err.code] ?? err.code}) : ${summarize(err)}`,
        true,
        extra,
    );
}

function summarize(err: GatewayError): string {
    const parts = [err.message, ...err.details.map((d) => `${d.mspId}@${d.address}: ${d.message}`)];
    const s = parts.join(' | ');
    return s.length > 600 ? s.slice(0, 600) + '…' : s;
}

/**
 * Convertit une erreur du client Fabric Gateway en ApiError.
 * - erreur métier du chaincode → 4xx (422 par défaut)
 * - pair / orderer injoignable, délai dépassé à l'endossement → 503
 * - délai dépassé APRÈS l'envoi à l'orderer ou pendant l'attente du statut → 504 COMMIT_UNKNOWN
 */
export function mapFabricError(err: unknown): ApiError {
    if (err instanceof ApiError) {
        return err;
    }
    if (err instanceof GatewayError) {
        const txId = (err as GatewayError & { transactionId?: string }).transactionId;
        const extra: Record<string, unknown> = txId !== undefined ? { txId } : {};

        if (err instanceof CommitStatusError) {
            return new ApiError(
                504,
                'COMMIT_UNKNOWN',
                `issue de la transaction inconnue (statut de validation non obtenu) : réconcilier par eventId`,
                true,
                extra,
            );
        }
        if (err.name === 'SubmitError') {
            if (err.code === GrpcStatus.DEADLINE_EXCEEDED || err.code === GrpcStatus.CANCELLED) {
                return new ApiError(
                    504,
                    'COMMIT_UNKNOWN',
                    `délai dépassé lors de l'envoi à l'orderer : la transaction a pu être ordonnée, réconcilier par eventId`,
                    true,
                    extra,
                );
            }
            if (isUnavailable(err.code)) {
                return ledgerUnavailable(err, extra);
            }
            return new ApiError(502, 'SUBMIT_FAILED', `envoi à l'orderer refusé : ${summarize(err)}`, true, extra);
        }

        const business = chaincodeCode(err);
        if (business !== undefined) {
            return businessError(business.code, business.message);
        }
        if (isUnavailable(err.code) || NOT_ENOUGH_PEERS.test(summarize(err))) {
            return ledgerUnavailable(err, extra);
        }
        const phase = err instanceof EndorseError ? "de l'endossement" : 'de la requête';
        return new ApiError(502, 'LEDGER_ERROR', `échec ${phase} : ${summarize(err)}`, true, extra);
    }
    if (err instanceof Error) {
        const business = chaincodeCode(err);
        if (business !== undefined) {
            return businessError(business.code, business.message);
        }
        return new ApiError(500, 'INTERNAL', err.message, false);
    }
    return new ApiError(500, 'INTERNAL', String(err), false);
}
