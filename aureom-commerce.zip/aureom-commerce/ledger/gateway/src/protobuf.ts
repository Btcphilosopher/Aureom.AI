/**
 * Décodeur protobuf minimal (varint + champs délimités), suffisant pour lire
 * common.BlockchainInfo et l'en-tête de common.Block renvoyés par le
 * chaincode système qscc, sans dépendance supplémentaire.
 */
export type Field = { wire: 0; value: bigint } | { wire: 2; value: Uint8Array } | { wire: 1 | 5; value: Uint8Array };

export function decodeFields(buf: Uint8Array): Map<number, Field[]> {
    const out = new Map<number, Field[]>();
    let pos = 0;
    const varint = (): bigint => {
        let result = 0n;
        let shift = 0n;
        for (;;) {
            if (pos >= buf.length) {
                throw new Error('protobuf tronqué');
            }
            const b = buf[pos++] ?? 0;
            result |= BigInt(b & 0x7f) << shift;
            if ((b & 0x80) === 0) {
                return result;
            }
            shift += 7n;
            if (shift > 63n) {
                throw new Error('varint trop long');
            }
        }
    };
    while (pos < buf.length) {
        const tag = varint();
        const fieldNo = Number(tag >> 3n);
        const wire = Number(tag & 7n);
        let field: Field;
        switch (wire) {
            case 0:
                field = { wire: 0, value: varint() };
                break;
            case 2: {
                const len = Number(varint());
                if (pos + len > buf.length) {
                    throw new Error('protobuf tronqué');
                }
                field = { wire: 2, value: buf.subarray(pos, pos + len) };
                pos += len;
                break;
            }
            case 1:
                field = { wire: 1, value: buf.subarray(pos, pos + 8) };
                pos += 8;
                break;
            case 5:
                field = { wire: 5, value: buf.subarray(pos, pos + 4) };
                pos += 4;
                break;
            default:
                throw new Error(`type de champ protobuf non pris en charge : ${wire}`);
        }
        const list = out.get(fieldNo) ?? [];
        list.push(field);
        out.set(fieldNo, list);
    }
    return out;
}

function varintField(fields: Map<number, Field[]>, n: number): bigint {
    const f = fields.get(n)?.[0];
    return f !== undefined && f.wire === 0 ? f.value : 0n;
}

function bytesField(fields: Map<number, Field[]>, n: number): Uint8Array {
    const f = fields.get(n)?.[0];
    return f !== undefined && f.wire === 2 ? f.value : new Uint8Array();
}

/** common.BlockchainInfo { uint64 height = 1; bytes currentBlockHash = 2; bytes previousBlockHash = 3; } */
export function decodeBlockchainInfo(buf: Uint8Array): { height: bigint; currentBlockHash: string; previousBlockHash: string } {
    const f = decodeFields(buf);
    return {
        height: varintField(f, 1),
        currentBlockHash: Buffer.from(bytesField(f, 2)).toString('hex'),
        previousBlockHash: Buffer.from(bytesField(f, 3)).toString('hex'),
    };
}

/** common.Block { BlockHeader header = 1; ... } ; BlockHeader { uint64 number = 1; ... } */
export function decodeBlockNumber(buf: Uint8Array): bigint {
    const header = bytesField(decodeFields(buf), 1);
    return varintField(decodeFields(header), 1);
}
