#!/usr/bin/env bash
# Démarre (ou complète) le réseau Fabric de démonstration AUREOM COMMERCE :
#   matériel cryptographique → orderers/pairs → canal « tracabilite » →
#   chaincode CCaaS (paquet, installation, approbation x3, validation) → passerelles REST.
# Idempotent : chaque étape déjà réalisée est détectée et sautée.
#
# Variables utiles : FORCE_BUILD=1 (reconstruit les images), CC_VERSION / CC_SEQUENCE
# (mise à jour du chaincode via le cycle de vie), BUILD_CA_FILE (AC d'un proxy TLS).
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
load_env

command -v docker >/dev/null || die "docker est introuvable"
docker info >/dev/null 2>&1 || die "le démon Docker ne répond pas"
mkdir -p "${GEN_DIR}" "${ARTIFACTS_DIR}"

# ----------------------------------------------------------------- 1. images
build_image() {
  local tag="$1" ctx="$2"; shift 2
  if [[ "${FORCE_BUILD:-0}" != "1" ]] && docker image inspect "${tag}" >/dev/null 2>&1; then
    ok "image ${tag} déjà présente"
    return
  fi
  info "construction de l'image ${tag}"
  local secret=()
  [[ -n "${BUILD_CA_FILE:-}" && -f "${BUILD_CA_FILE}" ]] && secret=(--secret "id=extra_ca,src=${BUILD_CA_FILE}")
  DOCKER_BUILDKIT=1 docker build "${secret[@]}" "$@" -t "${tag}" "${ctx}"
}
build_image "aureom/tracabilite-ccaas:${CHAINCODE_IMAGE_TAG:-1.0.0}" "${LEDGER_DIR}/chaincode/tracabilite" \
  --build-arg "GO_IMAGE=${LIBRARY_REGISTRY}/golang:1.26-alpine" \
  --build-arg "RUNTIME_IMAGE=${LIBRARY_REGISTRY}/alpine:3.22"
build_image "aureom/ledger-gateway:${GATEWAY_IMAGE_TAG:-1.0.0}" "${LEDGER_DIR}/gateway" \
  --build-arg "NODE_IMAGE=${LIBRARY_REGISTRY}/node:22-alpine"

# ------------------------------------------------ 2. matériel cryptographique
if [[ -d "${ORG_DIR}/peerOrganizations" ]]; then
  ok "matériel cryptographique déjà généré (${ORG_DIR})"
else
  info "génération du matériel cryptographique de démonstration (cryptogen)"
  tools_offline cryptogen generate --config=config/crypto-config.yaml --output=organizations >/dev/null
  ok "organisations générées"
fi

# ------------------------------------------------------- 3. bloc de genèse
BLOCK="${ARTIFACTS_DIR}/${CHANNEL_NAME}.block"
if [[ -f "${BLOCK}" ]]; then
  ok "bloc de genèse du canal déjà présent"
else
  info "création du bloc de genèse du canal ${CHANNEL_NAME} (configtxgen)"
  docker run --rm --network none -v "${NET_DIR}:/work" -w /work -e FABRIC_CFG_PATH=/work/config "${TOOLS_IMAGE}" \
    configtxgen -profile TracabiliteChannel -channelID "${CHANNEL_NAME}" \
    -outputBlock "channel-artifacts/${CHANNEL_NAME}.block"
fi

# ------------------------------------------------------ 4. orderers et pairs
# core.yaml extrait de l'image du pair (même version), avec vm.endpoint vidé :
# pas de démon Docker dans les pairs (chaincode en CCaaS), donc pas de contrôle
# de santé « docker » en échec sur /healthz.
mkdir -p "${GEN_DIR}/peercfg"
docker run --rm --entrypoint cat "${FABRIC_REGISTRY}/fabric-peer:${FABRIC_VERSION}" /etc/hyperledger/fabric/core.yaml \
  | sed 's#^\(    endpoint:\) unix:///var/run/docker.sock#\1 ""#' >"${GEN_DIR}/peercfg/core.yaml.tmp"
grep -q '^    endpoint: ""' "${GEN_DIR}/peercfg/core.yaml.tmp" || die "impossible d'adapter core.yaml (vm.endpoint)"
mv "${GEN_DIR}/peercfg/core.yaml.tmp" "${GEN_DIR}/peercfg/core.yaml"

info "démarrage des orderers et des pairs"
ORDERER_SVCS=(); for o in "${ORDERERS[@]}"; do ORDERER_SVCS+=("${o}.${ORDERER_DOMAIN}"); done
PEER_SVCS=(); for org in "${ORGS[@]}"; do PEER_SVCS+=("peer0.$(org_domain "${org}")"); done
compose up -d "${ORDERER_SVCS[@]}" "${PEER_SVCS[@]}"
wait_healthy 120 "${ORDERER_SVCS[@]}" "${PEER_SVCS[@]}"

# ------------------------------------- 5. canal : API de participation (osnadmin)
osn() { tools osnadmin channel "$@" --ca-file "${ORDERER_CA}" --client-cert "${ORDERER_ADMIN_CERT}" --client-key "${ORDERER_ADMIN_KEY}"; }
for o in "${ORDERERS[@]}"; do
  host="${o}.${ORDERER_DOMAIN}:7053"
  if osn list --channelID "${CHANNEL_NAME}" -o "${host}" 2>/dev/null | grep -q '"name": *"'"${CHANNEL_NAME}"'"'; then
    ok "${o} : déjà membre du canal"
  else
    info "${o} rejoint le canal ${CHANNEL_NAME}"
    osn join --channelID "${CHANNEL_NAME}" --config-block "channel-artifacts/${CHANNEL_NAME}.block" -o "${host}" >/dev/null
    ok "${o} : canal rejoint"
  fi
done

raft_ready() {
  local out
  out=$(osn list --channelID "${CHANNEL_NAME}" -o "orderer0.${ORDERER_DOMAIN}:7053" 2>/dev/null || true)
  grep -q '"status": *"active"' <<<"${out}" && grep -q '"consensusRelation": *"consenter"' <<<"${out}"
}
retry 20 2 raft_ready || die "le canal n'est pas actif sur orderer0"
ok "canal actif côté orderers (Raft, 3 consenters)"

for org in "${ORGS[@]}"; do
  if peer_as "${org}" "peer channel list 2>/dev/null" | grep -qx "${CHANNEL_NAME}"; then
    ok "peer0.${org} : déjà membre du canal"
  else
    info "peer0.${org} rejoint le canal"
    retry 5 3 peer_as "${org}" "peer channel join -b channel-artifacts/${CHANNEL_NAME}.block" >/dev/null
    ok "peer0.${org} : canal rejoint"
  fi
done

# --------------------------------------------- 6. chaincode CCaaS : paquets
mkdir -p "${GEN_DIR}/packages"
declare -A PKG_ID
for org in "${ORGS[@]}"; do
  d=$(org_domain "${org}")
  pkg="${GEN_DIR}/packages/${CC_LABEL}-${org}.tar.gz"
  if [[ ! -f "${pkg}" ]]; then
    info "paquet CCaaS pour ${org} (adresse tracabilite.${d}:${CC_PORT})"
    tmp=$(mktemp -d)
    cat >"${tmp}/connection.json" <<EOF
{
  "address": "tracabilite.${d}:${CC_PORT}",
  "dial_timeout": "10s",
  "tls_required": false
}
EOF
    cat >"${tmp}/metadata.json" <<EOF
{ "type": "ccaas", "label": "${CC_LABEL}" }
EOF
    tar -C "${tmp}" --owner=0 --group=0 --mtime='2026-01-01 00:00:00' -czf "${tmp}/code.tar.gz" connection.json
    tar -C "${tmp}" --owner=0 --group=0 --mtime='2026-01-01 00:00:00' -czf "${pkg}" metadata.json code.tar.gz
    rm -rf "${tmp}"
  fi
  PKG_ID[$org]=$(tools peer lifecycle chaincode calculatepackageid "/work/.generated/packages/$(basename "${pkg}")")
  echo "CHAINCODE_ID=${PKG_ID[$org]}" >"${GEN_DIR}/chaincode-${org}.env"
  ok "${org} : identifiant de paquet ${PKG_ID[$org]}"
done

# ------------------------------------------- 7. installation sur les 3 pairs
for org in "${ORGS[@]}"; do
  if peer_as "${org}" "peer lifecycle chaincode queryinstalled --output json" | grep -q "\"${PKG_ID[$org]}\""; then
    ok "peer0.${org} : paquet déjà installé"
  else
    info "installation du paquet sur peer0.${org}"
    peer_as "${org}" "peer lifecycle chaincode install /work/.generated/packages/${CC_LABEL}-${org}.tar.gz" >/dev/null
    ok "peer0.${org} : paquet installé"
  fi
done

info "démarrage des serveurs de chaincode (CCaaS)"
CC_SVCS=(); for org in "${ORGS[@]}"; do CC_SVCS+=("tracabilite.$(org_domain "${org}")"); done
compose up -d "${CC_SVCS[@]}"
wait_healthy 60 "${CC_SVCS[@]}"

# ------------------------------- 8. approbation par les 3 organisations, validation
ORDERER_ARGS="-o orderer0.${ORDERER_DOMAIN}:7050 --tls --cafile ${ORDERER_CA}"
committed_seq() {
  peer_as maisonmarche "peer lifecycle chaincode querycommitted -C ${CHANNEL_NAME} -n ${CC_NAME} --output json 2>/dev/null | jq -r '.sequence // empty'" || true
}
if [[ "$(committed_seq)" == "${CC_SEQUENCE}" ]]; then
  ok "chaincode ${CC_NAME} déjà validé sur le canal (séquence ${CC_SEQUENCE})"
else
  for org in "${ORGS[@]}"; do
    if peer_as "${org}" "peer lifecycle chaincode queryapproved -C ${CHANNEL_NAME} -n ${CC_NAME} --sequence ${CC_SEQUENCE} --output json" 2>/dev/null | grep -q "\"${PKG_ID[$org]}\""; then
      ok "${MSP[$org]} : définition déjà approuvée"
    else
      info "${MSP[$org]} approuve la définition (séquence ${CC_SEQUENCE})"
      retry 6 5 peer_as "${org}" "peer lifecycle chaincode approveformyorg ${ORDERER_ARGS} -C ${CHANNEL_NAME} -n ${CC_NAME} --version ${CC_VERSION} --sequence ${CC_SEQUENCE} --package-id ${PKG_ID[$org]} --waitForEvent" >/dev/null
      ok "${MSP[$org]} : approuvé"
    fi
  done
  peer_as maisonmarche "peer lifecycle chaincode checkcommitreadiness -C ${CHANNEL_NAME} -n ${CC_NAME} --version ${CC_VERSION} --sequence ${CC_SEQUENCE} --output json"
  PEER_ARGS=""
  for org in "${ORGS[@]}"; do
    PEER_ARGS+=" --peerAddresses peer0.$(org_domain "${org}"):7051 --tlsRootCertFiles $(peer_tls_ca "${org}")"
  done
  info "validation (commit) de la définition du chaincode"
  retry 6 5 peer_as maisonmarche "peer lifecycle chaincode commit ${ORDERER_ARGS} -C ${CHANNEL_NAME} -n ${CC_NAME} --version ${CC_VERSION} --sequence ${CC_SEQUENCE} ${PEER_ARGS}" >/dev/null
  ok "chaincode ${CC_NAME} ${CC_VERSION} validé (séquence ${CC_SEQUENCE})"
fi

# ------------------------------------------------- 9. passerelles REST
# Identité de la passerelle = Admin de l'organisation (démo uniquement : en
# production, séparer l'identité « administrateur des clés » de l'identité
# « soumission d'événements »). Copiée avec un propriétaire non-root (uid 1000).
for org in "${ORGS[@]}"; do
  d=$(org_domain "${org}")
  src="${ORG_DIR}/peerOrganizations/${d}"
  dst="${GEN_DIR}/gateway-${org}"
  mkdir -p "${dst}/signcerts" "${dst}/keystore"   # mise à jour en place (montage bind des conteneurs)
  cp "${src}/peers/peer0.${d}/tls/ca.crt" "${dst}/tls-ca.crt"
  cp "${src}/users/Admin@${d}/msp/signcerts/"*.pem "${dst}/signcerts/cert.pem"
  cp "${src}/users/Admin@${d}/msp/keystore/"* "${dst}/keystore/key.pem"
  chmod 700 "${dst}/keystore"; chmod 600 "${dst}/keystore/key.pem"
  chown -R 1000:1000 "${dst}"
done

info "démarrage des passerelles REST"
compose up -d gateway-maisonmarche gateway-atelierlumiere gateway-conserverieval
wait_healthy 90 gateway-maisonmarche gateway-atelierlumiere gateway-conserverieval

# Préchauffage : première connexion pair → serveur de chaincode.
for org in "${ORGS[@]}"; do
  tok_var="GATEWAY_TOKEN_${org^^}"
  code=$(curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer ${!tok_var}" \
    "http://127.0.0.1:${GATEWAY_PORT[$org]}/v1/keys/prechauffage" || true)
  [[ "${code}" == "404" ]] && ok "passerelle ${org} → chaincode : opérationnelle" || warn "préchauffage ${org} : HTTP ${code}"
done

echo
ok "réseau prêt — canal ${CHANNEL_NAME}, chaincode ${CC_NAME} ${CC_VERSION}"
for org in "${ORGS[@]}"; do
  echo "    ${MSP[$org]}  →  http://localhost:${GATEWAY_PORT[$org]}  (réseau Docker aureom_fabric : http://gateway-${org}:8800)"
done
