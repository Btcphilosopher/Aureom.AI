#!/usr/bin/env bash
# Arrête le réseau de démonstration et PURGE tout son état : conteneurs,
# volumes (registres des pairs et des orderers), matériel cryptographique,
# bloc de genèse, paquets chaincode et identités des passerelles.
#   --keep-images : ne supprime pas les images aureom/* construites localement (défaut)
#   --rmi         : supprime aussi les images aureom/tracabilite-ccaas et aureom/ledger-gateway
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
load_env

RMI=0
for a in "$@"; do
  case "$a" in
    --rmi) RMI=1 ;;
    --keep-images) RMI=0 ;;
    *) die "option inconnue : $a" ;;
  esac
done

info "arrêt des conteneurs et suppression des volumes"
compose down --volumes --remove-orphans

info "purge des artefacts générés"
# Fichiers créés en root par les conteneurs : suppression via un conteneur si nécessaire.
for p in "${ORG_DIR}" "${ARTIFACTS_DIR}" "${GEN_DIR}"; do
  [[ -e "$p" ]] || continue
  rm -rf "$p" 2>/dev/null || docker run --rm -v "${NET_DIR}:/work" "${TOOLS_IMAGE}" rm -rf "/work/$(basename "$p")"
done

if [[ "${RMI}" == "1" ]]; then
  docker image rm -f "aureom/tracabilite-ccaas:${CHAINCODE_IMAGE_TAG:-1.0.0}" "aureom/ledger-gateway:${GATEWAY_IMAGE_TAG:-1.0.0}" 2>/dev/null || true
fi
ok "réseau arrêté et purgé (le fichier .env est conservé)"
