#!/usr/bin/env bash
# État du réseau de démonstration : conteneurs, canal côté orderers et pairs,
# définition du chaincode, santé des passerelles REST.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
load_env
set +e

info "conteneurs"
compose ps --format 'table {{.Name}}\t{{.Status}}\t{{.Ports}}'

if ! docker network inspect aureom_fabric >/dev/null 2>&1; then
  warn "réseau Docker aureom_fabric absent : le réseau Fabric n'est pas démarré"
  exit 1
fi

echo; info "canal ${CHANNEL_NAME} côté orderers (API de participation)"
for o in "${ORDERERS[@]}"; do
  out=$(tools osnadmin channel list --channelID "${CHANNEL_NAME}" -o "${o}.${ORDERER_DOMAIN}:7053" \
    --ca-file "${ORDERER_CA}" --client-cert "${ORDERER_ADMIN_CERT}" --client-key "${ORDERER_ADMIN_KEY}" 2>&1 | sed -n '/{/,$p' | tr -d '\n ')
  echo "    ${o}: ${out:-injoignable}"
done

echo; info "canal ${CHANNEL_NAME} côté pairs"
for org in "${ORGS[@]}"; do
  out=$(peer_as "${org}" "peer channel getinfo -c ${CHANNEL_NAME} 2>&1 | sed -n 's/^Blockchain info: //p'")
  echo "    peer0.${org}: ${out:-injoignable}"
done

echo; info "définition du chaincode ${CC_NAME}"
peer_as maisonmarche "peer lifecycle chaincode querycommitted -C ${CHANNEL_NAME} -n ${CC_NAME} 2>&1" | sed 's/^/    /'

echo; info "passerelles REST"
for org in "${ORGS[@]}"; do
  out=$(curl -s -m 6 "http://127.0.0.1:${GATEWAY_PORT[$org]}/health" || echo '{"status":"injoignable"}')
  echo "    ${org} (:${GATEWAY_PORT[$org]}): ${out}"
done
