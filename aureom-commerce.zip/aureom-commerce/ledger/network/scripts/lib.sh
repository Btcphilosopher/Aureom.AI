#!/usr/bin/env bash
# Fonctions communes aux scripts du réseau Fabric de démonstration.
# shellcheck disable=SC2034

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NET_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
LEDGER_DIR="$(cd "${NET_DIR}/.." && pwd)"
COMPOSE_FILE="${NET_DIR}/compose.fabric.yaml"
GEN_DIR="${NET_DIR}/.generated"
ORG_DIR="${NET_DIR}/organizations"
ARTIFACTS_DIR="${NET_DIR}/channel-artifacts"

CHANNEL_NAME="tracabilite"
CC_NAME="tracabilite"
CC_VERSION="${CC_VERSION:-1.0}"
CC_SEQUENCE="${CC_SEQUENCE:-1}"
CC_LABEL="${CC_NAME}_${CC_VERSION}"
CC_PORT=9999

ORGS=(maisonmarche atelierlumiere conserverieval)
ORDERERS=(orderer0 orderer1 orderer2)
ORDERER_DOMAIN="ordering.example"

declare -A MSP=(
  [maisonmarche]=MaisonMarcheMSP
  [atelierlumiere]=AtelierLumiereMSP
  [conserverieval]=ConserverieValMSP
)
declare -A GATEWAY_PORT=(
  [maisonmarche]=8800
  [atelierlumiere]=8801
  [conserverieval]=8802
)

# --------------------------------------------------------------------- .env
load_env() {
  if [[ ! -f "${NET_DIR}/.env" ]]; then
    cp "${NET_DIR}/.env.example" "${NET_DIR}/.env"
    warn ".env absent : copie de .env.example (jetons de DÉMONSTRATION)"
  fi
  set -a
  # shellcheck disable=SC1091
  source "${NET_DIR}/.env"
  set +a
  FABRIC_REGISTRY="${FABRIC_REGISTRY:-hyperledger}"
  FABRIC_VERSION="${FABRIC_VERSION:-2.5.16}"
  LIBRARY_REGISTRY="${LIBRARY_REGISTRY:-docker.io/library}"
  TOOLS_IMAGE="${FABRIC_REGISTRY}/fabric-tools:${FABRIC_VERSION}"
}

# ------------------------------------------------------------------ journal
c_info=$'\033[1;34m'; c_ok=$'\033[1;32m'; c_warn=$'\033[1;33m'; c_err=$'\033[1;31m'; c_off=$'\033[0m'
[[ -t 1 ]] || { c_info=""; c_ok=""; c_warn=""; c_err=""; c_off=""; }
info() { echo "${c_info}==>${c_off} $*"; }
ok()   { echo "${c_ok} ✔${c_off} $*"; }
warn() { echo "${c_warn} !${c_off} $*" >&2; }
die()  { echo "${c_err} ✘ $*${c_off}" >&2; exit 1; }

compose() { docker compose -f "${COMPOSE_FILE}" --project-directory "${NET_DIR}" "$@"; }

# Exécute une commande dans un conteneur fabric-tools éphémère.
# Le répertoire network/ est monté sous /work.
tools() {
  docker run --rm --network aureom_fabric \
    -v "${NET_DIR}:/work" -w /work \
    -e FABRIC_CFG_PATH=/etc/hyperledger/fabric \
    "${TOOLS_IMAGE}" "$@"
}

tools_offline() {
  docker run --rm --network none -v "${NET_DIR}:/work" -w /work "${TOOLS_IMAGE}" "$@"
}

org_domain() { echo "$1.example"; }

ORDERER_CA="/work/organizations/ordererOrganizations/${ORDERER_DOMAIN}/tlsca/tlsca.${ORDERER_DOMAIN}-cert.pem"
ORDERER_ADMIN_CERT="/work/organizations/ordererOrganizations/${ORDERER_DOMAIN}/users/Admin@${ORDERER_DOMAIN}/tls/client.crt"
ORDERER_ADMIN_KEY="/work/organizations/ordererOrganizations/${ORDERER_DOMAIN}/users/Admin@${ORDERER_DOMAIN}/tls/client.key"

peer_tls_ca() { local d; d=$(org_domain "$1"); echo "/work/organizations/peerOrganizations/${d}/peers/peer0.${d}/tls/ca.crt"; }

# Commande `peer` exécutée avec l'identité admin de l'organisation $1.
peer_as() {
  local org="$1"; shift
  local d; d=$(org_domain "${org}")
  docker run --rm --network aureom_fabric \
    -v "${NET_DIR}:/work" -w /work \
    -e FABRIC_CFG_PATH=/etc/hyperledger/fabric \
    -e FABRIC_LOGGING_SPEC=WARN \
    -e CORE_PEER_TLS_ENABLED=true \
    -e CORE_PEER_LOCALMSPID="${MSP[$org]}" \
    -e CORE_PEER_TLS_ROOTCERT_FILE="$(peer_tls_ca "${org}")" \
    -e CORE_PEER_MSPCONFIGPATH="/work/organizations/peerOrganizations/${d}/users/Admin@${d}/msp" \
    -e CORE_PEER_ADDRESS="peer0.${d}:7051" \
    "${TOOLS_IMAGE}" sh -c "$*"
}

# Réessaie une commande (utile le temps de l'élection Raft / du gossip).
retry() {
  local n="$1" delay="$2"; shift 2
  local i
  for ((i = 1; i <= n; i++)); do
    if "$@"; then return 0; fi
    [[ $i -lt $n ]] && { warn "tentative ${i}/${n} échouée, nouvel essai dans ${delay}s"; sleep "${delay}"; }
  done
  return 1
}

wait_healthy() {
  local timeout="$1"; shift
  local svc start status
  start=$(date +%s)
  for svc in "$@"; do
    while true; do
      status=$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "${svc}" 2>/dev/null || echo absent)
      [[ "${status}" == "healthy" ]] && break
      if (( $(date +%s) - start > timeout )); then
        die "le conteneur ${svc} n'est pas sain après ${timeout}s (état : ${status}) — voir 'docker logs ${svc}'"
      fi
      sleep 2
    done
    ok "${svc} : sain"
  done
}
