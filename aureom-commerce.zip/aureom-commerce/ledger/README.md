# AUREOM COMMERCE — Registre de traçabilité permissionné (Hyperledger Fabric)

Ce répertoire contient la brique « blockchain permissionnée » d'AUREOM COMMERCE :
un registre partagé entre le distributeur fictif **Maison & Marché** et deux
fournisseurs fictifs, **Atelier Lumière** (équipement de la maison) et
**Conserverie du Val** (épicerie / conserves). Chaque organisation y ancre des
événements de traçabilité (création de lot, expédition, réception, contrôle,
rappel, correction, contestation…) **signés** et **horodatés**, lisibles par
toutes, modifiables par aucune.

```
ledger/
├── chaincode/tracabilite/   chaincode Go (fabric-contract-api-go v2), exécuté en CCaaS
├── gateway/                 passerelle REST Node.js/TypeScript (une instance par organisation)
├── network/                 réseau Fabric 2.5 de démonstration (compose + scripts)
│   ├── compose.fabric.yaml
│   ├── config/              crypto-config.yaml (cryptogen), configtx.yaml (canal)
│   ├── scripts/             up.sh, down.sh, status.sh, lib.sh
│   └── .env.example         variables et jetons de DÉMONSTRATION
└── tests/                   e2e.mjs (bout en bout) et e2e-resultats.txt (sortie réelle)
```

---

## 1. Architecture

```
            application AUREOM COMMERCE (backend Python)
              │  HTTP + Bearer                        │
              ▼                                       ▼
   gateway-maisonmarche :8800          gateway-atelierlumiere :8801     gateway-conserverieval :8802
   (identité MaisonMarcheMSP)          (identité AtelierLumiereMSP)     (identité ConserverieValMSP)
              │ gRPC/TLS (Fabric Gateway)            │                                │
              ▼                                      ▼                                ▼
   peer0.maisonmarche.example ◄──gossip──► peer0.atelierlumiere.example ◄──► peer0.conserverieval.example
      │ CCaaS                                  │ CCaaS                              │ CCaaS
   tracabilite.maisonmarche.example:9999   tracabilite.atelierlumiere…:9999   tracabilite.conserverieval…:9999
              │                                      │                                │
              └──────────────── ordonnancement Raft (OrdererMSP) ─────────────────────┘
                  orderer0.ordering.example   orderer1.ordering.example   orderer2.ordering.example
```

* **Canal** `tracabilite`, créé avec l'API de participation des orderers
  (`osnadmin channel join`) — aucun canal système.
* **Ordonnancement** : Raft (`etcdraft`) à **3 orderers** (tolère la perte d'un
  nœud). En production, répartir les orderers sur des hôtes — idéalement des
  organisations — distincts ; 3 nœuds minimum, 5 pour tolérer deux pannes.
* **Organisations pairs** : `MaisonMarcheMSP`, `AtelierLumiereMSP`,
  `ConserverieValMSP`, un pair chacune, base d'état LevelDB, TLS partout, NodeOUs
  activés (rôles `admin`, `peer`, `client`, `orderer` portés par les certificats).
* **Politique d'endossement** : politique par défaut du canal
  `/Channel/Application/Endorsement = MAJORITY Endorsement`, soit **2 organisations
  sur 3**. Une transaction n'est valide que si les pairs de deux organisations
  distinctes ont exécuté le chaincode et obtenu exactement le même résultat. Les
  approbations de définition de chaincode suivent la même règle
  (`LifecycleEndorsement = MAJORITY`) ; la démo fait approuver les 3 organisations.
* **Chaincode-as-a-Service** : chaque organisation exploite son propre serveur
  de chaincode (image construite depuis `golang:1.26-alpine`, sans
  `fabric-ccenv`/`fabric-baseos`). Le paquet installé sur chaque pair ne contient
  qu'un `connection.json` (adresse du serveur de l'organisation) et un
  `metadata.json` de type `ccaas` ; les identifiants de paquet diffèrent donc
  d'une organisation à l'autre (chacune approuve le sien).
* **Passerelles REST** : une par organisation, utilisant le client officiel
  `@hyperledger/fabric-gateway` ; le service Gateway du pair local se charge de
  la découverte des endosseurs, de l'endossement, de l'envoi à l'orderer et du
  suivi de validation.
* **Réseau Docker** nommé `aureom_fabric` : la composition principale de
  l'application peut le rejoindre (`networks: { aureom_fabric: { external: true } }`)
  et joindre `http://gateway-maisonmarche:8800`.

## 2. Pourquoi Hyperledger Fabric

* **Permissionné** : seuls les membres identifiés (certificats X.509 émis par
  l'AC de chaque organisation) lisent et écrivent ; aucune donnée n'est publique,
  aucun jeton ni frais de transaction.
* **Maintenu** : projet de la Linux Foundation (LF Decentralized Trust), licence
  Apache-2.0, branche **2.5 LTS** avec correctifs réguliers (2.5.16 utilisée ici).
* **Consensus éprouvé** : Raft (crash fault tolerant), implémentation etcd. Nous
  n'écrivons **aucun consensus maison** : l'ordre des transactions, la
  réplication et la reprise sont assurés par Fabric.
* **Politiques d'endossement** : la règle « 2 organisations sur 3 » est imposée
  par le protocole et vérifiée par chaque pair à la validation des blocs, pas
  par notre code applicatif.
* **Pas de minage, finalité immédiate** : une transaction validée dans un bloc
  est définitive (pas de réorganisation de chaîne).

## 3. Ce qu'un enregistrement prouve… et ne prouve pas

Un enregistrement `RECORDED` prouve :

1. que l'organisation `submitterMsp` (identité Fabric authentifiée) a soumis
   l'enveloppe, et que `issuerOrg` lui est égal ;
2. que l'enveloppe a été signée (Ed25519) par une clé applicative enregistrée
   par cette même organisation, valide à la date `declaredAt` ;
3. que les octets exacts de l'enveloppe (`payloadSha256`) existaient au plus
   tard à `txTimestamp` et n'ont pas été modifiés depuis (bloc chaîné, répliqué
   chez les trois organisations et les trois orderers) ;
4. que les liens `previousEventId` / `correctsEventId` désignaient des événements
   déjà présents ;
5. qu'au moins deux organisations sur trois ont exécuté les mêmes contrôles.

Il **ne prouve pas** :

* que le fait décrit est **vrai** (un lot peut être déclaré expédié sans l'être) :
  le registre garantit l'**imputabilité** (qui a affirmé quoi, quand), pas la
  véracité. Les contestations passent par des événements `DISPUTE` ;
* que `occurredAt` / `declaredAt` sont exacts : ce sont des dates **déclarées**.
  Seul `txTimestamp` est attesté (il est fixé par le client soumetteur et borné
  par les pairs) ; le chaincode refuse un `declaredAt` postérieur de plus de
  5 minutes à `txTimestamp` ;
* le contenu des pièces justificatives : seuls leurs condensés SHA-256
  (`evidence[].sha256`, `detailsDigest`) sont ancrés ; les documents restent hors
  chaîne, dans le système de chaque organisation ;
* qu'un événement signé par une clé révoquée **antérieurement** à `revokedAt`
  était légitime (voir `keyStatus`) : c'est au lecteur d'en tenir compte.

**Données personnelles** : l'enveloppe est décodée strictement (clés exactes,
sensibles à la casse, sans doublon, sans champ inconnu, sans donnée superflue,
taille ≤ 32 Kio). Aucun champ prévu pour des données personnelles ; un registre
répliqué et immuable ne permet pas d'exercer le droit à l'effacement (RGPD), il
ne doit donc jamais en contenir.

## 4. Contrat de données (schéma d'enveloppe 1.0)

L'enveloppe est un objet JSON transmis **sous forme de chaîne** ; la signature
Ed25519 porte sur les octets UTF-8 exacts de cette chaîne (aucune
re-canonicalisation) et `payloadSha256` = SHA-256 hexadécimal de ces octets.

| Champ | Type | Règle |
|---|---|---|
| `schemaVersion` | `"1.0"` | seule valeur acceptée, sinon `INVALID_SCHEMA` |
| `eventId` | UUID | identifiant d'idempotence |
| `eventType` | énumération | `LOT_CREATED`, `SUPPLIER_SHIPMENT`, `RECEIPT`, `INSPECTION_RECORDED`, `CUSTODY_TRANSFER`, `TRANSFORMATION`, `CUSTOMER_SHIPMENT`, `RECALL`, `CORRECTION`, `DISPUTE` |
| `issuerOrg` | MSP id | doit être le MSP de l'appelant (`ISSUER_MISMATCH`) |
| `subject` | objet | `{kind: "LOT"\|"PRODUCT", ref (1–200 car.), gtin? (8–14 chiffres), lot? (1–100)}` |
| `occurredAt`, `declaredAt` | RFC 3339 | `declaredAt` ≤ horodatage de transaction + 5 min |
| `previousEventId` | UUID \| null | doit exister (`UNKNOWN_PREVIOUS`) |
| `correctsEventId` | UUID \| null | obligatoire pour `CORRECTION` (même émetteur, sinon `CORRECTION_NOT_OWNER`) et `DISPUTE` (tout émetteur) ; interdit sinon ; doit exister (`UNKNOWN_CORRECTED`) |
| `counterpartyOrg` | MSP id \| null | |
| `locationRef` | chaîne \| null | 1–100 caractères |
| `evidence` | tableau (≤ 20) | `{sha256: 64 hex minuscules, kind (≤ 50), mediaType (≤ 100)}`, peut être vide, **obligatoire** |
| `detailsDigest` | 64 hex \| null | |
| `signerKeyId` | chaîne | `[A-Za-z0-9._:@-]{1,128}` |

Ordre des contrôles de `RecordEvent(envelope, signatureBase64)` : structure →
émetteur → clé (existence, propriétaire, `validFrom ≤ declaredAt`, retrait,
révocation) → signature → idempotence (`DUPLICATE` si même `eventId` et même
`payloadSha256`, sans écriture ; `CONFLICT` sinon) → liens → écriture de
`EVT_<eventId>` et de l'index composite `subject~event` `[subject.ref, eventId]`.

Enregistrement stocké : `{eventId, envelope, signatureBase64, payloadSha256,
submitterMsp, signerKeyId, txId, txTimestamp}`. Les lectures (`GetEvent`,
`QueryEventsBySubject`, `GetEventsByIds`, réponse `DUPLICATE`) y ajoutent
`keyStatus` (`ACTIVE` | `RETIRED` | `REVOKED` | `UNKNOWN`, état **actuel** de la
clé) et `keyDetails {keyId, ownerMsp, validFrom, retiredAt, revokedAt, revocationReason}`.

### Codes d'erreur du chaincode

Message = `CODE: explication en français`.

| Code | Signification | HTTP (passerelle) |
|---|---|---|
| `INVALID_ENVELOPE` | JSON invalide, champ inconnu/dupliqué/manquant, mauvais type, taille | 422 |
| `INVALID_SCHEMA` | `schemaVersion` ≠ `1.0` | 422 |
| `INVALID_EVENT_TYPE`, `INVALID_SUBJECT`, `INVALID_TIMESTAMP`, `INVALID_EVIDENCE`, `INVALID_FIELD`, `INVALID_ARGUMENT`, `INVALID_KEY` | validation d'un champ ou d'un argument | 422 |
| `ISSUER_MISMATCH` | `issuerOrg` ≠ MSP appelant | 422 |
| `UNKNOWN_KEY`, `KEY_OWNER_MISMATCH`, `KEY_NOT_YET_VALID`, `KEY_RETIRED`, `KEY_REVOKED`, `KEY_EXISTS`, `KEY_ALREADY_RETIRED`, `KEY_ALREADY_REVOKED` | registre des clés | 422 |
| `BAD_SIGNATURE` | signature mal encodée ou invalide | 422 |
| `UNKNOWN_PREVIOUS`, `UNKNOWN_CORRECTED`, `CORRECTION_NOT_OWNER` | liens | 422 |
| `CONFLICT` | même `eventId`, contenu différent | 409 (`retryable:false`) |
| `ACCESS_DENIED` | opération réservée à une identité admin (NodeOU `admin`) | 403 |
| `NOT_FOUND` | événement / clé absent | 404 |
| `INTERNAL` | état illisible | 500 |

### Registre des clés de signature applicatives

Clés Ed25519 propres à l'application (distinctes des identités X.509 Fabric) :

* `RegisterSigningKey(keyId, publicKeyBase64, validFrom)` — clé publique brute de
  32 octets en base64 ; identité **admin** de l'organisation ; propriétaire = MSP
  appelant ; `KEY_EXISTS` si l'identifiant existe déjà (espace de noms global).
* `RetireSigningKey(keyId, retiredAt)` — rotation normale : signatures dont
  `declaredAt > retiredAt` refusées (`KEY_RETIRED`), les antérieures restent valides.
* `RevokeSigningKey(keyId, revokedAt, reason)` — compromission : événements dont
  `declaredAt ≥ revokedAt` refusés (`KEY_REVOKED`) ; les anciens restent mais
  sont signalés `keyStatus: "REVOKED"`. `revokedAt` peut être antidaté à la date
  présumée de compromission.
* `GetSigningKey(keyId)` → `{keyId, ownerMsp, publicKeyBase64, validFrom,
  retiredAt, revokedAt, revocationReason, registeredTxId}`.

Seul le propriétaire (admin de l'organisation) peut retirer ou révoquer sa clé.
Pour la démo, l'identité de chaque passerelle **est** l'admin de son
organisation ; **en production, séparer** l'identité « administration des clés »
(rare, protégée, idéalement en HSM) de l'identité « soumission d'événements »
(NodeOU `client`), et exposer les routes `/v1/keys` sur une passerelle distincte.

Limite connue : comme `declaredAt` est déclaratif, une clé compromise mais non
révoquée permet d'antidater des événements. La protection réelle est la
combinaison clé applicative **et** identité Fabric de l'organisation ; révoquer
rapidement et antidater `revokedAt` à la compromission présumée.

## 5. API REST de la passerelle

Toutes les routes sauf `/health` exigent `Authorization: Bearer $GATEWAY_TOKEN`.
Réponses JSON ; erreurs `{code, message, retryable, …}` ; en-tête `X-Request-Id`.

| Méthode et route | Réponse |
|---|---|
| `GET /health` | 200 `{status:"ok", mspId, channel, chaincode, peerEndpoint, blockHeight}` ou 503 `{status:"indisponible", error}` — sonde réelle (qscc `GetChainInfo`, délai 3 s) |
| `GET /v1/status` | `{mspId, channel, chaincode, blockHeight, currentBlockHash, previousBlockHash}` |
| `POST /v1/events` `{envelope, signature}` | 201 `{status:"RECORDED"\|"DUPLICATE", eventId, txId, payloadSha256, txTimestamp, blockNumber}` après validation du bloc. Pour `DUPLICATE` : `txId`, `txTimestamp`, `blockNumber` de l'enregistrement **d'origine**, plus `submissionTxId` et `keyStatus`. En-tête `Server-Timing` (endossement+envoi / attente de validation) |
| `GET /v1/events/:eventId` | 200 enregistrement + `keyStatus` + `keyDetails` + `blockNumber`, ou 404 `NOT_FOUND` |
| `GET /v1/subjects/:ref/events` | tableau trié par `txTimestamp` (`ref` encodé URL) |
| `POST /v1/events/batch-get` `{eventIds:[…]}` | tableau des événements trouvés (≤ 100 identifiants) |
| `POST /v1/keys` `{keyId, publicKeyBase64, validFrom}` | 201 clé + `txId`, `blockNumber` |
| `POST /v1/keys/:keyId/retire` `{retiredAt}` | 200 clé |
| `POST /v1/keys/:keyId/revoke` `{revokedAt, reason}` | 200 clé |
| `GET /v1/keys/:keyId` | 200 clé ou 404 |

Correspondance des erreurs :

* erreurs métier : voir tableau ci-dessus (422 / 409 / 403 / 404) ;
* invalidation au commit `MVCC_READ_CONFLICT`, `PHANTOM_READ_CONFLICT`,
  `ENDORSEMENT_POLICY_FAILURE` → 409 `{code, retryable:true, txId, validationCode}` :
  resoumettre **la même** enveloppe (le chaincode répondra `DUPLICATE` si la
  première a finalement été validée) ; autres codes de validation → 409
  `retryable:false` ;
* pair local injoignable (échec rapide en ~3 s), délai d'endossement dépassé,
  pas assez de pairs pour satisfaire la politique → 503
  `{code:"LEDGER_UNAVAILABLE", retryable:true}` ;
* délai dépassé **après** l'envoi à l'orderer ou pendant l'attente du statut →
  504 `{code:"COMMIT_UNKNOWN", txId, retryable:true}` : l'appelant réconcilie par
  `GET /v1/events/:eventId` puis resoumet si absent (idempotent) ;
* corps invalide → 400 `BAD_REQUEST` ; jeton absent/faux → 401.

Délais : endossement 15 s, envoi 5 s, statut de validation 60 s, évaluation 5 s,
sonde de santé 3 s (variables `ENDORSE_TIMEOUT_MS`, `SUBMIT_TIMEOUT_MS`,
`COMMIT_STATUS_TIMEOUT_MS`, `EVALUATE_TIMEOUT_MS`, `HEALTH_TIMEOUT_MS`).
Configuration : `MSP_ID`, `PEER_ENDPOINT`, `PEER_HOST_ALIAS`, `TLS_CERT_PATH`,
`CERT_PATH` et `KEY_PATH` (fichier ou répertoire), `CHANNEL=tracabilite`,
`CHAINCODE=tracabilite`, `PORT=8800`, `GATEWAY_TOKEN` (≥ 16 caractères),
`LOG_LEVEL`. Journaux en JSON Lines, sans clé privée, jeton ni corps de requête.

## 6. Démarrer, arrêter, diagnostiquer

Prérequis : Docker (avec Compose v2.24+ et BuildKit), `bash`, `curl`. Go et Node
ne sont nécessaires que pour les tests hors conteneur.

```bash
cd aureom-commerce/ledger/network
cp .env.example .env        # puis adapter ; up.sh le fait si .env est absent
# Docker Hub limité ? dans .env :
#   FABRIC_REGISTRY=mirror.gcr.io/hyperledger
#   LIBRARY_REGISTRY=mirror.gcr.io/library
# Proxy TLS d'entreprise pendant la construction des images :
#   BUILD_CA_FILE=/chemin/ca-bundle.pem

./scripts/up.sh             # idempotent : génère, démarre, crée le canal, déploie, lance les passerelles (~45 s à froid)
./scripts/status.sh         # conteneurs, canal (orderers/pairs), définition du chaincode, santé des passerelles
./scripts/down.sh           # arrêt + PURGE (volumes, cryptographie, blocs, paquets) ; --rmi supprime aussi les images

# Redémarrage sans purge (conserve le registre) :
docker compose -f compose.fabric.yaml stop
docker compose -f compose.fabric.yaml start      # ou ./scripts/up.sh
# Reconstruire les images après modification du code :
FORCE_BUILD=1 ./scripts/up.sh
```

| Service | Adresse |
|---|---|
| gateway-maisonmarche | `http://localhost:8800` (`http://gateway-maisonmarche:8800` sur `aureom_fabric`) |
| gateway-atelierlumiere | `http://localhost:8801` |
| gateway-conserverieval | `http://localhost:8802` |

Les passerelles écoutent sur `127.0.0.1` par défaut (`GATEWAY_BIND`). Les pairs et
orderers ne publient aucun port sur l'hôte ; l'outillage (`peer`, `osnadmin`)
s'exécute dans des conteneurs `fabric-tools` éphémères sur `aureom_fabric`.

**Jetons de démonstration** (`.env.example`, valeurs publiques, à remplacer hors
démo par `openssl rand -hex 32` dans un `.env` non versionné) :

| Variable | Valeur de démo |
|---|---|
| `GATEWAY_TOKEN_MAISONMARCHE` | `demo-maisonmarche-4f9c2e7a1b8d6053` |
| `GATEWAY_TOKEN_ATELIERLUMIERE` | `demo-atelierlumiere-8b3e5d0c7a2f9164` |
| `GATEWAY_TOKEN_CONSERVERIEVAL` | `demo-conserverieval-2d7a9f4c6e1b0385` |

### Matériel cryptographique

`up.sh` génère avec **cryptogen** un matériel de **démonstration** dans
`network/organizations/` (ignoré par git, comme `channel-artifacts/` et
`.generated/`). **Production** : une Fabric CA (ou la PKI de l'entreprise) par
organisation, clés privées en **HSM via PKCS#11** (le client Gateway propose
`signers.newHSMSignerFactory`), renouvellement des certificats, listes de
révocation (CRL) dans les MSP du canal, et **jamais** de clé versionnée ou copiée
hors de son organisation. Chaque organisation génère ses clés chez elle et ne
partage que ses certificats d'AC (définition MSP).

## 7. Tests

```bash
cd ledger/chaincode/tracabilite && go test ./...     # tests unitaires (doublures écrites à la main)
cd ledger/gateway && npm ci && npm run build          # TypeScript strict
node ledger/tests/e2e.mjs                             # bout en bout (réseau démarré) → tests/e2e-resultats.txt
E2E_SKIP_OUTAGE=1 node ledger/tests/e2e.mjs           # sans le scénario d'arrêt d'un pair
```

Les tests unitaires couvrent le décodage strict (champ inconnu, casse, doublon,
données superflues, types), chaque code d'erreur, l'idempotence, les
corrections/contestations, l'ordre des requêtes par sujet, le cycle de vie des
clés et l'absence d'écriture en cas d'erreur (doublure de registre transactionnelle).

Le test de bout en bout (45 vérifications) exerce le réseau
réel : enregistrement de clé, `RECORDED`, `DUPLICATE`, `CONFLICT`,
`BAD_SIGNATURE`, `ISSUER_MISMATCH`, refus d'un champ personnel, chaîne
`SUPPLIER_SHIPMENT` (Atelier Lumière) → `RECEIPT` (Maison & Marché), lecture
croisée depuis la passerelle d'une autre organisation et vérification de
signature hors chaîne, requête par sujet, `CORRECTION_NOT_OWNER` / `DISPUTE`,
soumissions concurrentes (`MVCC_READ_CONFLICT` → 409 retryable puis
`DUPLICATE`), retrait et révocation, arrêt de `peer0.conserverieval` (503 sur sa
passerelle, les deux autres organisations continuent d'écrire), redémarrage et
rattrapage des blocs.

## 8. Coûts

* **Exploitation** : 3 orderers + 3 pairs + 3 serveurs de chaincode + 3
  passerelles = 12 conteneurs (≈ 350 Mio de RAM mesurés au repos après le test e2e, ≈ 1,6 Go d'images). En
  réel, chaque organisation exploite au minimum un pair (deux pour la haute
  disponibilité), son serveur de chaincode, sa passerelle, son AC, ses
  sauvegardes, la supervision (`/metrics` Prometheus sur le port 9443 des
  nœuds) et les mises à jour de sécurité Fabric ; l'ordonnancement est opéré
  par un ou plusieurs membres (ou un tiers de confiance).
* **Latence** (mesurée par `tests/e2e.mjs`, même hôte Docker) : aller-retour HTTP
  complet de `POST /v1/events`, attente de validation incluse : **≈ 280 ms
  (médiane ≈ 285 ms, p95 ≈ 300 ms)**, dont ~15–25 ms d'endossement (2 pairs)
  et d'envoi, le reste étant l'attente du bloc, dominée par `BatchTimeout =
  250 ms`. 10 soumissions parallèles aboutissent en ≈ 310 ms au total (même
  bloc). Avec le `BatchTimeout` par défaut de Fabric (2 s), compter ~2 s ; entre
  sites distants, ajouter les RTT réseau. Conclusion : à soumettre de façon
  **asynchrone** (file d'attente / outbox côté backend), jamais dans le chemin
  critique d'un encaissement.
* **Gouvernance** : toute modification (ajout/retrait d'organisation, politique,
  nouvelle version de chaincode) requiert la signature de la majorité des admins
  des organisations ; il faut une charte (qui opère les orderers, délais de
  validation, procédure de litige via `DISPUTE`, gestion des incidents de clés,
  conditions de sortie et de conservation des données).

## 9. Versions et licences (vérifiées le 28/11/2026)

| Composant | Version | Licence | Vérification |
|---|---|---|---|
| Hyperledger Fabric (peer, orderer, tools) | **2.5.16** (dernier correctif de la LTS 2.5) | Apache-2.0 | `git ls-remote --tags github.com/hyperledger/fabric` (v2.5.16 ; la branche 3.x est en 3.1.5) ; images `mirror.gcr.io/hyperledger/fabric-*:2.5.16` téléchargées, `peer version` → v2.5.16 |
| fabric-contract-api-go | v2.2.4 (12/10/2026, exige Go ≥ 1.26.7) | Apache-2.0 | proxy.golang.org |
| fabric-chaincode-go | v2 v2.3.1-0.20260831054443-83a556592560 (imposée par contract-api v2.2.4 ; dernière étiquette v2.3.0) | Apache-2.0 | go.mod |
| fabric-protos-go-apiv2 | v0.3.7 | Apache-2.0 | go.mod |
| @hyperledger/fabric-gateway | 1.13.0 | Apache-2.0 | npm |
| @grpc/grpc-js | 1.14.7 | Apache-2.0 | npm |
| TypeScript | 5.9.3 (choix conservateur ; la 7.0 native existe) | Apache-2.0 | npm |
| Go (construction du chaincode) | 1.26 (`golang:1.26-alpine`, 1.26.11) | BSD-3-Clause | image |
| Node.js (passerelle) | 22 (`node:22-alpine`) | MIT | image |

Dépendances transitives notables : `@hyperledger/fabric-protos` 0.3.7
(Apache-2.0), `google-protobuf` 3.21.4 (BSD-3-Clause/Apache-2.0),
`@noble/curves` 2.4.0 (MIT). Aucune image `fabric-ccenv`/`fabric-baseos` n'est
requise (CCaaS).

## 10. Arrivée et départ d'une organisation

Procédure de mise à jour de la configuration du canal (pour Fabric 2.5) :

1. **Préparer** : la nouvelle organisation crée son AC, ses identités (admin,
   pair, client) et fournit sa définition MSP (certificats d'AC, NodeOUs,
   politiques, pair d'ancrage) — générée par exemple avec
   `configtxgen -printOrg <Org> > org.json`.
2. **Récupérer** la configuration courante :
   `peer channel fetch config config_block.pb -c tracabilite` puis
   `configtxlator proto_decode --type common.Block` et extraction de
   `.data.data[0].payload.data.config`.
3. **Modifier** le JSON : ajout de l'organisation sous
   `channel_group.groups.Application.groups` (ou retrait pour un départ).
4. **Calculer la mise à jour** : `configtxlator compute_update` entre l'ancienne
   et la nouvelle configuration, encapsulation en enveloppe `CONFIG_UPDATE`.
5. **Signer** : `peer channel signconfigtx` par les admins requis — la politique
   `Application/Admins` est `MAJORITY Admins` (2 sur 3 aujourd'hui, 3 sur 4 après
   l'ajout d'une quatrième organisation) — puis `peer channel update`.
6. **Rejoindre** : la nouvelle organisation fait rejoindre son pair
   (`peer channel fetch 0` puis `peer channel join`), installe le paquet CCaaS
   pointant vers **son** serveur de chaincode et approuve la définition
   existante (même séquence).
7. **Effets** : `MAJORITY Endorsement` s'adapte automatiquement au nombre
   d'organisations (3 sur 4 avec quatre membres — à rediscuter : on peut fixer
   une politique explicite par chaincode via une nouvelle séquence).

**Départ** : même procédure (retrait du groupe MSP), puis révocation de ses clés
applicatives par elle-même ou, à défaut, constat par les autres membres (les
événements passés restent attribuables et vérifiables : le registre conserve
l'historique ; la copie détenue par l'organisation sortante ne reçoit plus de
nouveaux blocs). Retirer aussi un éventuel orderer qu'elle opérait
(mise à jour des consenters Raft, une modification à la fois).

## 11. Rotation et révocation

* **Clés applicatives Ed25519** : enregistrer la nouvelle clé (`validFrom` = date
  de bascule), basculer le backend, puis `retire` l'ancienne. En cas de
  compromission : `revoke` immédiat avec `revokedAt` = date présumée de
  compromission ; les lecteurs voient `keyStatus: "REVOKED"` sur les
  événements antérieurs et décident de leur traitement (réémission via
  `CORRECTION` signée par une nouvelle clé).
* **Identités X.509 Fabric** : renouvellement par l'AC de l'organisation ;
  révocation par publication d'une CRL dans la définition MSP du canal (mise à
  jour de configuration, section 10) et dans les MSP locaux des nœuds ; les
  certificats TLS des orderers Raft se renouvellent un consenter à la fois.

## 12. Évolution du schéma

* `schemaVersion` est contrôlé par le chaincode : la version 1.0 n'accepte que
  `"1.0"`. Ajouter un champ ou une version `1.1` / `2.0` = **nouvelle version de
  chaincode** (qui accepte les anciennes et nouvelles versions, et sait relire
  les enregistrements existants, jamais réécrits) déployée par le cycle de vie
  Fabric :
  1. construire l'image `aureom/tracabilite-ccaas:<nouvelle-version>` ;
  2. empaqueter (nouveau label, ex. `tracabilite_1.1`), installer sur les trois
     pairs, démarrer le nouveau serveur CCaaS de chaque organisation ;
  3. `approveformyorg` par une majorité d'organisations avec `--version 1.1
     --sequence 2` et l'identifiant de paquet propre à chacune ;
  4. `commit` : la bascule est atomique pour tout le canal au bloc de validation.
  Avec les scripts : `CC_VERSION=1.1 CC_SEQUENCE=2 CHAINCODE_IMAGE_TAG=1.1.0 FORCE_BUILD=1 ./scripts/up.sh`.
* Les passerelles n'interprètent pas l'enveloppe : elles n'ont pas à changer
  pour une évolution de schéma.

## 13. Reprise et sauvegarde

* **Pair perdu ou corrompu** : recréer le conteneur avec un volume vide, le faire
  rejoindre le canal à partir du bloc de genèse ; il **resynchronise** tous les
  blocs depuis les orderers (ou ses pairs via gossip) et reconstruit son état.
  Démontré par `e2e.mjs` (arrêt/redémarrage de `peer0.conserverieval`). Pour un
  gros registre, utiliser les instantanés (`peer snapshot submitrequest` puis
  `peer channel joinbysnapshot`).
* **Orderer perdu** : Raft continue avec 2 nœuds sur 3 ; un nœud recréé rejoint
  le canal via `osnadmin` et se resynchronise depuis le leader.
* **À sauvegarder par chaque organisation** : son matériel cryptographique (AC,
  clés des nœuds et des admins — idéalement déjà en HSM, à sauvegarder selon la
  procédure du HSM), les volumes `/var/hyperledger/production` (pairs) et
  `/var/hyperledger/production/orderer` (orderers) — arrêt du nœud ou
  instantané de volume cohérent —, le bloc de genèse
  (`channel-artifacts/tracabilite.block`), les paquets chaincode et leurs
  identifiants, la configuration (`compose`, `.env`), ainsi que les pièces
  justificatives hors chaîne dont seuls les condensés sont ancrés. Les
  registres sont répliqués chez chaque membre : la perte d'un site ne fait pas
  perdre l'historique, mais la perte de sa **clé privée** l'empêche de signer.

## 14. Écarts entre la démo et la production

| Démo | Production |
|---|---|
| cryptogen, clés sur disque | Fabric CA / PKI par organisation, HSM (PKCS#11), CRL |
| 3 orderers sur un hôte, opérés par `OrdererMSP` | ≥ 3 (idéalement 5) orderers sur des hôtes/organisations distincts |
| Passerelle = admin de l'organisation | identités séparées admin des clés / soumission (`client`) |
| Pair ↔ serveur CCaaS sans TLS (réseau Docker isolé) | TLS (mutuel) : `CHAINCODE_TLS_DISABLED=false`, `CHAINCODE_TLS_KEY_FILE`, `CHAINCODE_TLS_CERT_FILE`, `CHAINCODE_CLIENT_CA_FILE` et `tls_required: true` + `root_cert` dans `connection.json` |
| Jetons Bearer statiques de démo | secrets aléatoires, rotation, mTLS ou OIDC entre backend et passerelle, TLS sur l'API |
| `BatchTimeout` 250 ms | à calibrer (débit / latence), 1–2 s typique |
| Un pair par organisation | ≥ 2 pairs par organisation pour la disponibilité |

Non testé en réel : le chemin 504 `COMMIT_UNKNOWN` (délai dépassé après envoi à
l'orderer), difficile à provoquer de façon déterministe ; sa logique est
couverte par la correspondance d'erreurs de la passerelle (`src/errors.ts`).
