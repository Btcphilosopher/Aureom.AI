// Package contract implémente le chaincode « tracabilite » d'AUREOM COMMERCE :
// un registre d'événements de traçabilité signés (Ed25519) et un registre de
// clés de signature applicatives, partagés entre le distributeur et ses
// fournisseurs sur un canal Hyperledger Fabric.
package contract

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"sort"
	"strings"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

const (
	eventKeyPrefix   = "EVT_"
	signKeyPrefix    = "SIGNKEY_"
	subjectIndexName = "subject~event"
	adminOU          = "admin"
	maxIdsPerQuery   = 100
	maxReasonLength  = 500
)

// Contract est le contrat par défaut du chaincode.
type Contract struct {
	contractapi.Contract
}

// EventRecord est ce qui est écrit dans l'état mondial pour chaque événement.
type EventRecord struct {
	EventID         string `json:"eventId"`
	Envelope        string `json:"envelope"`
	SignatureBase64 string `json:"signatureBase64"`
	PayloadSha256   string `json:"payloadSha256"`
	SubmitterMsp    string `json:"submitterMsp"`
	SignerKeyID     string `json:"signerKeyId"`
	TxID            string `json:"txId"`
	TxTimestamp     string `json:"txTimestamp"`

	txTime time.Time
}

// KeyDetails résume l'état actuel de la clé ayant signé un événement.
type KeyDetails struct {
	KeyID            string  `json:"keyId"`
	OwnerMsp         string  `json:"ownerMsp"`
	ValidFrom        string  `json:"validFrom"`
	RetiredAt        *string `json:"retiredAt"`
	RevokedAt        *string `json:"revokedAt"`
	RevocationReason *string `json:"revocationReason"`
}

// EventView est la réponse des requêtes : l'enregistrement + l'état de la clé.
// keyStatus vaut ACTIVE, RETIRED, REVOKED (ou UNKNOWN si la clé est absente).
type EventView struct {
	EventRecord
	KeyStatus  string      `json:"keyStatus"`
	KeyDetails *KeyDetails `json:"keyDetails"`
}

// RecordResult est la réponse de RecordEvent lors d'une première écriture.
type RecordResult struct {
	Status        string `json:"status"`
	EventID       string `json:"eventId"`
	TxID          string `json:"txId"`
	PayloadSha256 string `json:"payloadSha256"`
	TxTimestamp   string `json:"txTimestamp"`
}

// DuplicateResult est la réponse de RecordEvent quand l'événement existe déjà
// avec exactement le même contenu (rejeu idempotent).
type DuplicateResult struct {
	Status string `json:"status"`
	EventView
}

// SigningKey est une clé de signature applicative Ed25519 d'une organisation.
type SigningKey struct {
	KeyID            string  `json:"keyId"`
	OwnerMsp         string  `json:"ownerMsp"`
	PublicKeyBase64  string  `json:"publicKeyBase64"`
	ValidFrom        string  `json:"validFrom"`
	RetiredAt        *string `json:"retiredAt"`
	RevokedAt        *string `json:"revokedAt"`
	RevocationReason *string `json:"revocationReason"`
	RegisteredTxID   string  `json:"registeredTxId"`
}

// ---------------------------------------------------------------------------
// Registre des clés de signature
// ---------------------------------------------------------------------------

// RegisterSigningKey enregistre une clé publique Ed25519 (32 octets bruts en
// base64) pour l'organisation de l'appelant. Réservé à une identité admin.
func (c *Contract) RegisterSigningKey(ctx contractapi.TransactionContextInterface, keyID, publicKeyBase64, validFrom string) (string, error) {
	msp, err := requireAdmin(ctx)
	if err != nil {
		return "", err
	}
	if !reKeyID.MatchString(keyID) {
		return "", newErr(ErrInvalidArgument, "keyId invalide (1 à 128 caractères parmi A-Z a-z 0-9 . _ : @ -)")
	}
	pub, err := base64.StdEncoding.DecodeString(publicKeyBase64)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return "", newErr(ErrInvalidKey, "publicKeyBase64 doit encoder en base64 une clé Ed25519 brute de 32 octets")
	}
	if _, err := parseTime(validFrom, "validFrom"); err != nil {
		return "", err
	}
	stub := ctx.GetStub()
	existing, err := stub.GetState(signKeyPrefix + keyID)
	if err != nil {
		return "", newErr(ErrInternal, "lecture de l'état impossible : %v", err)
	}
	if existing != nil {
		return "", newErr(ErrKeyExists, "la clé %q est déjà enregistrée", keyID)
	}
	key := SigningKey{
		KeyID:           keyID,
		OwnerMsp:        msp,
		PublicKeyBase64: base64.StdEncoding.EncodeToString(pub),
		ValidFrom:       validFrom,
		RegisteredTxID:  stub.GetTxID(),
	}
	if err := putJSON(ctx, signKeyPrefix+keyID, key); err != nil {
		return "", err
	}
	return marshal(key)
}

// RetireSigningKey retire une clé (rotation normale) : les signatures dont
// declaredAt est postérieur à retiredAt sont refusées, les plus anciennes
// restent valides.
func (c *Contract) RetireSigningKey(ctx contractapi.TransactionContextInterface, keyID, retiredAt string) (string, error) {
	key, err := ownedKeyForAdmin(ctx, keyID)
	if err != nil {
		return "", err
	}
	t, err := parseTime(retiredAt, "retiredAt")
	if err != nil {
		return "", err
	}
	if vf, _ := time.Parse(time.RFC3339Nano, key.ValidFrom); t.Before(vf) {
		return "", newErr(ErrInvalidTimestamp, "retiredAt ne peut pas précéder validFrom")
	}
	if key.RetiredAt != nil {
		return "", newErr(ErrKeyAlreadyRetired, "la clé %q est déjà retirée depuis %s", keyID, *key.RetiredAt)
	}
	key.RetiredAt = &retiredAt
	if err := putJSON(ctx, signKeyPrefix+keyID, key); err != nil {
		return "", err
	}
	return marshal(key)
}

// RevokeSigningKey révoque une clé (compromission) : les événements dont
// declaredAt >= revokedAt sont refusés ; les événements antérieurs restent
// mais les requêtes signalent keyStatus = REVOKED.
func (c *Contract) RevokeSigningKey(ctx contractapi.TransactionContextInterface, keyID, revokedAt, reason string) (string, error) {
	key, err := ownedKeyForAdmin(ctx, keyID)
	if err != nil {
		return "", err
	}
	if _, err := parseTime(revokedAt, "revokedAt"); err != nil {
		return "", err
	}
	reason = strings.TrimSpace(reason)
	if reason == "" || len([]rune(reason)) > maxReasonLength {
		return "", newErr(ErrInvalidArgument, "le motif de révocation doit contenir de 1 à %d caractères", maxReasonLength)
	}
	if key.RevokedAt != nil {
		return "", newErr(ErrKeyAlreadyRevoked, "la clé %q est déjà révoquée depuis %s", keyID, *key.RevokedAt)
	}
	key.RevokedAt = &revokedAt
	key.RevocationReason = &reason
	if err := putJSON(ctx, signKeyPrefix+keyID, key); err != nil {
		return "", err
	}
	return marshal(key)
}

// GetSigningKey renvoie une clé de signature enregistrée.
func (c *Contract) GetSigningKey(ctx contractapi.TransactionContextInterface, keyID string) (string, error) {
	key, err := loadKey(ctx, keyID)
	if err != nil {
		return "", err
	}
	if key == nil {
		return "", newErr(ErrNotFound, "clé %q introuvable", keyID)
	}
	return marshal(key)
}

// ---------------------------------------------------------------------------
// Événements
// ---------------------------------------------------------------------------

// RecordEvent ancre une enveloppe d'événement signée. L'enveloppe est la
// chaîne JSON exacte qui a été signée ; elle n'est jamais re-canonicalisée.
func (c *Contract) RecordEvent(ctx contractapi.TransactionContextInterface, envelope, signatureBase64 string) (string, error) {
	stub := ctx.GetStub()
	txTime, err := txTimestamp(ctx)
	if err != nil {
		return "", err
	}

	// 1. Structure.
	env, err := ParseEnvelope(envelope, txTime)
	if err != nil {
		return "", err
	}

	// 2. L'émetteur déclaré doit être l'organisation qui soumet.
	callerMsp, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", newErr(ErrInternal, "identité de l'appelant illisible : %v", err)
	}
	if env.IssuerOrg != callerMsp {
		return "", newErr(ErrIssuerMismatch, "issuerOrg %q ne correspond pas à l'organisation appelante %q", env.IssuerOrg, callerMsp)
	}

	// 3. Clé de signature : existence, propriétaire, période de validité.
	key, err := loadKey(ctx, env.SignerKeyID)
	if err != nil {
		return "", err
	}
	if key == nil {
		return "", newErr(ErrUnknownKey, "la clé de signature %q n'est pas enregistrée", env.SignerKeyID)
	}
	if key.OwnerMsp != callerMsp {
		return "", newErr(ErrKeyOwnerMismatch, "la clé %q appartient à %s et non à %s", key.KeyID, key.OwnerMsp, callerMsp)
	}
	if err := checkKeyValidity(key, env.declaredAt); err != nil {
		return "", err
	}

	// 4. Signature Ed25519 sur les octets UTF-8 exacts de l'enveloppe.
	sig, err := base64.StdEncoding.DecodeString(signatureBase64)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return "", newErr(ErrBadSignature, "la signature doit être une signature Ed25519 de 64 octets encodée en base64")
	}
	pub, err := base64.StdEncoding.DecodeString(key.PublicKeyBase64)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return "", newErr(ErrInternal, "clé publique enregistrée corrompue")
	}
	if !ed25519.Verify(ed25519.PublicKey(pub), []byte(envelope), sig) {
		return "", newErr(ErrBadSignature, "la signature ne correspond pas à la clé enregistrée")
	}
	digest := sha256.Sum256([]byte(envelope))
	payloadSha := hex.EncodeToString(digest[:])

	// 5. Idempotence : même eventId + même contenu = DUPLICATE, sinon CONFLICT.
	existing, err := loadEvent(ctx, env.EventID)
	if err != nil {
		return "", err
	}
	if existing != nil {
		if existing.PayloadSha256 != payloadSha {
			return "", newErr(ErrConflict, "l'événement %s existe déjà avec un contenu différent (sha256 %s)", env.EventID, existing.PayloadSha256)
		}
		view, err := viewOf(ctx, existing)
		if err != nil {
			return "", err
		}
		return marshal(DuplicateResult{Status: "DUPLICATE", EventView: *view})
	}

	// 6. Liens vers des événements antérieurs.
	if env.PreviousEventID != nil {
		prev, err := loadEvent(ctx, *env.PreviousEventID)
		if err != nil {
			return "", err
		}
		if prev == nil {
			return "", newErr(ErrUnknownPrevious, "l'événement précédent %s est absent du registre", *env.PreviousEventID)
		}
	}
	if env.CorrectsEventID != nil {
		target, err := loadEvent(ctx, *env.CorrectsEventID)
		if err != nil {
			return "", err
		}
		if target == nil {
			return "", newErr(ErrUnknownCorrected, "l'événement visé %s est absent du registre", *env.CorrectsEventID)
		}
		if env.EventType == "CORRECTION" && target.SubmitterMsp != callerMsp {
			return "", newErr(ErrCorrectionOwner, "seule l'organisation émettrice (%s) peut corriger l'événement %s ; utilisez DISPUTE pour contester", target.SubmitterMsp, target.EventID)
		}
	}

	// 7. Écriture.
	rec := EventRecord{
		EventID:         env.EventID,
		Envelope:        envelope,
		SignatureBase64: signatureBase64,
		PayloadSha256:   payloadSha,
		SubmitterMsp:    callerMsp,
		SignerKeyID:     env.SignerKeyID,
		TxID:            stub.GetTxID(),
		TxTimestamp:     txTime.Format(time.RFC3339Nano),
	}
	if err := putJSON(ctx, eventKeyPrefix+env.EventID, rec); err != nil {
		return "", err
	}
	idx, err := stub.CreateCompositeKey(subjectIndexName, []string{env.Subject.Ref, env.EventID})
	if err != nil {
		return "", newErr(ErrInvalidSubject, "subject.ref inutilisable comme clé d'index : %v", err)
	}
	if err := stub.PutState(idx, []byte{0x00}); err != nil {
		return "", newErr(ErrInternal, "écriture de l'index impossible : %v", err)
	}
	return marshal(RecordResult{
		Status:        "RECORDED",
		EventID:       rec.EventID,
		TxID:          rec.TxID,
		PayloadSha256: rec.PayloadSha256,
		TxTimestamp:   rec.TxTimestamp,
	})
}

// GetEvent renvoie un événement et l'état actuel de sa clé de signature.
func (c *Contract) GetEvent(ctx contractapi.TransactionContextInterface, eventID string) (string, error) {
	if !reUUID.MatchString(eventID) {
		return "", newErr(ErrInvalidArgument, "eventId doit être un UUID")
	}
	rec, err := loadEvent(ctx, eventID)
	if err != nil {
		return "", err
	}
	if rec == nil {
		return "", newErr(ErrNotFound, "événement %s introuvable", eventID)
	}
	view, err := viewOf(ctx, rec)
	if err != nil {
		return "", err
	}
	return marshal(view)
}

// QueryEventsBySubject renvoie les événements d'un sujet, triés par
// horodatage de transaction croissant.
func (c *Contract) QueryEventsBySubject(ctx contractapi.TransactionContextInterface, ref string) (string, error) {
	if err := validateSubjectRef(ref); err != nil {
		return "", err
	}
	it, err := ctx.GetStub().GetStateByPartialCompositeKey(subjectIndexName, []string{ref})
	if err != nil {
		return "", newErr(ErrInternal, "requête d'index impossible : %v", err)
	}
	defer it.Close()
	var ids []string
	for it.HasNext() {
		kv, err := it.Next()
		if err != nil {
			return "", newErr(ErrInternal, "lecture de l'index impossible : %v", err)
		}
		_, attrs, err := ctx.GetStub().SplitCompositeKey(kv.Key)
		if err != nil || len(attrs) != 2 {
			return "", newErr(ErrInternal, "clé d'index mal formée")
		}
		ids = append(ids, attrs[1])
	}
	views, err := viewsOf(ctx, ids)
	if err != nil {
		return "", err
	}
	sort.SliceStable(views, func(i, j int) bool {
		if !views[i].txTime.Equal(views[j].txTime) {
			return views[i].txTime.Before(views[j].txTime)
		}
		return views[i].EventID < views[j].EventID
	})
	return marshal(views)
}

// GetEventsByIds renvoie les événements trouvés parmi une liste JSON d'identifiants
// (au plus 100). Les identifiants inconnus sont simplement absents du résultat.
func (c *Contract) GetEventsByIds(ctx contractapi.TransactionContextInterface, idsJSON string) (string, error) {
	var ids []string
	if err := json.Unmarshal([]byte(idsJSON), &ids); err != nil {
		return "", newErr(ErrInvalidArgument, "un tableau JSON de chaînes est attendu")
	}
	if len(ids) > maxIdsPerQuery {
		return "", newErr(ErrInvalidArgument, "au plus %d identifiants par requête", maxIdsPerQuery)
	}
	for _, id := range ids {
		if !reUUID.MatchString(id) {
			return "", newErr(ErrInvalidArgument, "identifiant %q invalide (UUID attendu)", truncate(id, 40))
		}
	}
	views, err := viewsOf(ctx, ids)
	if err != nil {
		return "", err
	}
	return marshal(views)
}

// ---------------------------------------------------------------------------
// Fonctions internes (non exportées : elles ne sont pas des transactions)
// ---------------------------------------------------------------------------

func checkKeyValidity(key *SigningKey, declared time.Time) error {
	vf, err := time.Parse(time.RFC3339Nano, key.ValidFrom)
	if err != nil {
		return newErr(ErrInternal, "validFrom enregistré illisible")
	}
	if declared.Before(vf) {
		return newErr(ErrKeyNotYetValid, "la clé %q n'est valide qu'à partir de %s", key.KeyID, key.ValidFrom)
	}
	if key.RevokedAt != nil {
		ra, err := time.Parse(time.RFC3339Nano, *key.RevokedAt)
		if err == nil && !declared.Before(ra) {
			return newErr(ErrKeyRevoked, "la clé %q est révoquée depuis %s", key.KeyID, *key.RevokedAt)
		}
	}
	if key.RetiredAt != nil {
		ra, err := time.Parse(time.RFC3339Nano, *key.RetiredAt)
		if err == nil && declared.After(ra) {
			return newErr(ErrKeyRetired, "la clé %q est retirée depuis %s", key.KeyID, *key.RetiredAt)
		}
	}
	return nil
}

func requireAdmin(ctx contractapi.TransactionContextInterface) (string, error) {
	cid := ctx.GetClientIdentity()
	msp, err := cid.GetMSPID()
	if err != nil {
		return "", newErr(ErrInternal, "identité de l'appelant illisible : %v", err)
	}
	cert, err := cid.GetX509Certificate()
	if err != nil || cert == nil {
		return "", newErr(ErrAccessDenied, "certificat X.509 de l'appelant introuvable")
	}
	for _, ou := range cert.Subject.OrganizationalUnit {
		if strings.EqualFold(ou, adminOU) {
			return msp, nil
		}
	}
	return "", newErr(ErrAccessDenied, "opération réservée à une identité administrateur (NodeOU admin) de l'organisation")
}

func ownedKeyForAdmin(ctx contractapi.TransactionContextInterface, keyID string) (*SigningKey, error) {
	msp, err := requireAdmin(ctx)
	if err != nil {
		return nil, err
	}
	key, err := loadKey(ctx, keyID)
	if err != nil {
		return nil, err
	}
	if key == nil {
		return nil, newErr(ErrUnknownKey, "la clé %q n'est pas enregistrée", keyID)
	}
	if key.OwnerMsp != msp {
		return nil, newErr(ErrKeyOwnerMismatch, "la clé %q appartient à %s ; seul son propriétaire peut la modifier", keyID, key.OwnerMsp)
	}
	return key, nil
}

func loadKey(ctx contractapi.TransactionContextInterface, keyID string) (*SigningKey, error) {
	if !reKeyID.MatchString(keyID) {
		return nil, newErr(ErrInvalidArgument, "keyId invalide")
	}
	raw, err := ctx.GetStub().GetState(signKeyPrefix + keyID)
	if err != nil {
		return nil, newErr(ErrInternal, "lecture de l'état impossible : %v", err)
	}
	if raw == nil {
		return nil, nil
	}
	var k SigningKey
	if err := json.Unmarshal(raw, &k); err != nil {
		return nil, newErr(ErrInternal, "clé enregistrée illisible")
	}
	return &k, nil
}

func loadEvent(ctx contractapi.TransactionContextInterface, eventID string) (*EventRecord, error) {
	raw, err := ctx.GetStub().GetState(eventKeyPrefix + eventID)
	if err != nil {
		return nil, newErr(ErrInternal, "lecture de l'état impossible : %v", err)
	}
	if raw == nil {
		return nil, nil
	}
	var r EventRecord
	if err := json.Unmarshal(raw, &r); err != nil {
		return nil, newErr(ErrInternal, "événement enregistré illisible")
	}
	r.txTime, _ = time.Parse(time.RFC3339Nano, r.TxTimestamp)
	return &r, nil
}

func viewOf(ctx contractapi.TransactionContextInterface, rec *EventRecord) (*EventView, error) {
	view := &EventView{EventRecord: *rec, KeyStatus: "UNKNOWN"}
	key, err := loadKey(ctx, rec.SignerKeyID)
	if err != nil {
		return nil, err
	}
	if key != nil {
		view.KeyDetails = &KeyDetails{
			KeyID:            key.KeyID,
			OwnerMsp:         key.OwnerMsp,
			ValidFrom:        key.ValidFrom,
			RetiredAt:        key.RetiredAt,
			RevokedAt:        key.RevokedAt,
			RevocationReason: key.RevocationReason,
		}
		switch {
		case key.RevokedAt != nil:
			view.KeyStatus = "REVOKED"
		case key.RetiredAt != nil:
			view.KeyStatus = "RETIRED"
		default:
			view.KeyStatus = "ACTIVE"
		}
	}
	return view, nil
}

func viewsOf(ctx contractapi.TransactionContextInterface, ids []string) ([]EventView, error) {
	views := make([]EventView, 0, len(ids))
	seen := map[string]bool{}
	for _, id := range ids {
		if seen[id] {
			continue
		}
		seen[id] = true
		rec, err := loadEvent(ctx, id)
		if err != nil {
			return nil, err
		}
		if rec == nil {
			continue
		}
		v, err := viewOf(ctx, rec)
		if err != nil {
			return nil, err
		}
		views = append(views, *v)
	}
	return views, nil
}

func txTimestamp(ctx contractapi.TransactionContextInterface) (time.Time, error) {
	ts, err := ctx.GetStub().GetTxTimestamp()
	if err != nil || ts == nil {
		return time.Time{}, newErr(ErrInternal, "horodatage de transaction indisponible")
	}
	return ts.AsTime().UTC(), nil
}

func putJSON(ctx contractapi.TransactionContextInterface, key string, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return newErr(ErrInternal, "sérialisation impossible : %v", err)
	}
	if err := ctx.GetStub().PutState(key, b); err != nil {
		return newErr(ErrInternal, "écriture de l'état impossible : %v", err)
	}
	return nil
}

func marshal(v any) (string, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return "", newErr(ErrInternal, "sérialisation impossible : %v", err)
	}
	return string(b), nil
}
