package contract

// Doublures de test écrites à la main : un registre en mémoire qui imite la
// sémantique de Fabric (les écritures d'une transaction ne sont visibles
// qu'après validation, et sont abandonnées si la fonction renvoie une erreur).

import (
	"crypto/x509"
	"fmt"
	"crypto/x509/pkix"
	"sort"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/hyperledger/fabric-chaincode-go/v2/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/v2/shim"
	"github.com/hyperledger/fabric-protos-go-apiv2/ledger/queryresult"
	"google.golang.org/protobuf/types/known/timestamppb"
)

type memLedger struct {
	state map[string][]byte
	txSeq int
	clock time.Time
}

func newLedger() *memLedger {
	return &memLedger{state: map[string][]byte{}, clock: time.Date(2026, 11, 20, 9, 0, 0, 0, time.UTC)}
}

// mockStub implémente le sous-ensemble de shim.ChaincodeStubInterface utilisé
// par le contrat. Toute autre méthode provoque une panique (interface nil).
type mockStub struct {
	shim.ChaincodeStubInterface
	ledger *memLedger
	txID   string
	txTime time.Time
	writes map[string][]byte
}

func (s *mockStub) GetTxID() string { return s.txID }

func (s *mockStub) GetTxTimestamp() (*timestamppb.Timestamp, error) {
	return timestamppb.New(s.txTime), nil
}

func (s *mockStub) GetState(key string) ([]byte, error) {
	v, ok := s.ledger.state[key]
	if !ok {
		return nil, nil
	}
	return append([]byte(nil), v...), nil
}

func (s *mockStub) PutState(key string, value []byte) error {
	s.writes[key] = append([]byte(nil), value...)
	return nil
}

func (s *mockStub) CreateCompositeKey(objectType string, attributes []string) (string, error) {
	return shim.CreateCompositeKey(objectType, attributes)
}

func (s *mockStub) SplitCompositeKey(key string) (string, []string, error) {
	parts := strings.Split(strings.TrimSuffix(strings.TrimPrefix(key, "\x00"), "\x00"), "\x00")
	return parts[0], parts[1:], nil
}

func (s *mockStub) GetStateByPartialCompositeKey(objectType string, attrs []string) (shim.StateQueryIteratorInterface, error) {
	prefix, err := shim.CreateCompositeKey(objectType, attrs)
	if err != nil {
		return nil, err
	}
	end := prefix + string(utf8.MaxRune)
	var keys []string
	for k := range s.ledger.state {
		if k >= prefix && k < end {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	it := &mockIterator{}
	for _, k := range keys {
		it.items = append(it.items, &queryresult.KV{Key: k, Value: s.ledger.state[k]})
	}
	return it, nil
}

type mockIterator struct {
	items []*queryresult.KV
	pos   int
}

func (it *mockIterator) HasNext() bool { return it.pos < len(it.items) }
func (it *mockIterator) Close() error  { return nil }
func (it *mockIterator) Next() (*queryresult.KV, error) {
	kv := it.items[it.pos]
	it.pos++
	return kv, nil
}

// mockIdentity implémente cid.ClientIdentity.
type mockIdentity struct {
	msp string
	ou  string
}

func (m *mockIdentity) GetID() (string, error)    { return "x509::CN=test::" + m.msp, nil }
func (m *mockIdentity) GetMSPID() (string, error) { return m.msp, nil }
func (m *mockIdentity) GetAttributeValue(string) (string, bool, error) {
	return "", false, nil
}
func (m *mockIdentity) AssertAttributeValue(string, string) error { return nil }
func (m *mockIdentity) GetX509Certificate() (*x509.Certificate, error) {
	return &x509.Certificate{Subject: pkix.Name{CommonName: "test", OrganizationalUnit: []string{m.ou}}}, nil
}

type mockContext struct {
	stub *mockStub
	id   cid.ClientIdentity
}

func (c *mockContext) GetStub() shim.ChaincodeStubInterface { return c.stub }
func (c *mockContext) GetClientIdentity() cid.ClientIdentity { return c.id }

// invoke exécute fn dans une « transaction » : écritures validées si succès.
func (l *memLedger) invoke(msp, ou string, fn func(ctx *mockContext) (string, error)) (string, error) {
	l.txSeq++
	l.clock = l.clock.Add(time.Second)
	stub := &mockStub{ledger: l, txID: fmt.Sprintf("tx%04d", l.txSeq), txTime: l.clock, writes: map[string][]byte{}}
	ctx := &mockContext{stub: stub, id: &mockIdentity{msp: msp, ou: ou}}
	out, err := fn(ctx)
	if err == nil {
		for k, v := range stub.writes {
			l.state[k] = v
		}
	}
	return out, err
}
