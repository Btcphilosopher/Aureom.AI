package contract

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"
)

// SchemaVersion est la seule version de schéma d'enveloppe acceptée par cette
// version du chaincode. Une nouvelle version implique une mise à jour du
// chaincode via le cycle de vie Fabric (nouvelle « sequence »).
const SchemaVersion = "1.0"

// MaxEnvelopeBytes borne la taille d'une enveloppe (les détails métier restent
// hors chaîne : seul leur condensé detailsDigest est ancré).
const MaxEnvelopeBytes = 32 * 1024

// MaxFutureSkew : tolérance d'horloge entre declaredAt et l'horodatage de la
// transaction Fabric (fixé par le client qui soumet la proposition).
const MaxFutureSkew = 5 * time.Minute

var (
	reUUID   = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)
	reMSP    = regexp.MustCompile(`^[A-Za-z0-9._-]{1,100}$`)
	reGTIN   = regexp.MustCompile(`^[0-9]{8,14}$`)
	reSHA256 = regexp.MustCompile(`^[0-9a-f]{64}$`)
	reKeyID  = regexp.MustCompile(`^[A-Za-z0-9._:@-]{1,128}$`)
)

// EventTypes liste les types d'événements autorisés par le schéma 1.0.
var EventTypes = map[string]bool{
	"LOT_CREATED":         true,
	"SUPPLIER_SHIPMENT":   true,
	"RECEIPT":             true,
	"INSPECTION_RECORDED": true,
	"CUSTODY_TRANSFER":    true,
	"TRANSFORMATION":      true,
	"CUSTOMER_SHIPMENT":   true,
	"RECALL":              true,
	"CORRECTION":          true,
	"DISPUTE":             true,
}

// Subject identifie l'objet tracé (lot ou produit). Aucune donnée personnelle.
type Subject struct {
	Kind string  `json:"kind"`
	Ref  string  `json:"ref"`
	GTIN *string `json:"gtin,omitempty"`
	Lot  *string `json:"lot,omitempty"`
}

// Evidence référence une pièce justificative stockée hors chaîne par son condensé.
type Evidence struct {
	SHA256    string `json:"sha256"`
	Kind      string `json:"kind"`
	MediaType string `json:"mediaType"`
}

// Envelope est l'enveloppe d'événement, schéma 1.0.
type Envelope struct {
	SchemaVersion   string     `json:"schemaVersion"`
	EventID         string     `json:"eventId"`
	EventType       string     `json:"eventType"`
	IssuerOrg       string     `json:"issuerOrg"`
	Subject         *Subject   `json:"subject"`
	OccurredAt      string     `json:"occurredAt"`
	DeclaredAt      string     `json:"declaredAt"`
	PreviousEventID *string    `json:"previousEventId,omitempty"`
	CorrectsEventID *string    `json:"correctsEventId,omitempty"`
	CounterpartyOrg *string    `json:"counterpartyOrg,omitempty"`
	LocationRef     *string    `json:"locationRef,omitempty"`
	Evidence        []Evidence `json:"evidence"`
	DetailsDigest   *string    `json:"detailsDigest,omitempty"`
	SignerKeyID     string     `json:"signerKeyId"`

	declaredAt time.Time
}

// Clés autorisées, par chemin dans le document. Toute autre clé est refusée :
// c'est un garde-fou contre la fuite de données personnelles sur la chaîne.
var allowedKeys = map[string]map[string]bool{
	"": set("schemaVersion", "eventId", "eventType", "issuerOrg", "subject", "occurredAt",
		"declaredAt", "previousEventId", "correctsEventId", "counterpartyOrg", "locationRef",
		"evidence", "detailsDigest", "signerKeyId"),
	"subject":    set("kind", "ref", "gtin", "lot"),
	"evidence[]": set("sha256", "kind", "mediaType"),
}

var requiredKeys = map[string][]string{
	"":           {"schemaVersion", "eventId", "eventType", "issuerOrg", "subject", "occurredAt", "declaredAt", "evidence", "signerKeyId"},
	"subject":    {"kind", "ref"},
	"evidence[]": {"sha256", "kind", "mediaType"},
}

func set(keys ...string) map[string]bool {
	m := make(map[string]bool, len(keys))
	for _, k := range keys {
		m[k] = true
	}
	return m
}

// ParseEnvelope décode strictement l'enveloppe : JSON valide, UTF-8, clés
// exactes (sensibles à la casse), sans doublon, sans clé inconnue, sans
// donnée en trop, puis valide chaque champ. txTime sert à borner declaredAt.
func ParseEnvelope(raw string, txTime time.Time) (*Envelope, error) {
	if len(raw) == 0 {
		return nil, newErr(ErrInvalidEnvelope, "l'enveloppe est vide")
	}
	if len(raw) > MaxEnvelopeBytes {
		return nil, newErr(ErrInvalidEnvelope, "l'enveloppe dépasse %d octets", MaxEnvelopeBytes)
	}
	if !utf8.ValidString(raw) {
		return nil, newErr(ErrInvalidEnvelope, "l'enveloppe n'est pas de l'UTF-8 valide")
	}
	if err := strictScan([]byte(raw)); err != nil {
		return nil, err
	}
	dec := json.NewDecoder(bytes.NewReader([]byte(raw)))
	dec.DisallowUnknownFields()
	var env Envelope
	if err := dec.Decode(&env); err != nil {
		return nil, newErr(ErrInvalidEnvelope, "structure JSON invalide : %s", sanitize(err.Error()))
	}
	if err := env.validate(txTime); err != nil {
		return nil, err
	}
	return &env, nil
}

// strictScan parcourt le JSON jeton par jeton pour contrôler les clés.
func strictScan(data []byte) error {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return newErr(ErrInvalidEnvelope, "JSON illisible : %s", sanitize(err.Error()))
	}
	if d, ok := tok.(json.Delim); !ok || d != '{' {
		return newErr(ErrInvalidEnvelope, "l'enveloppe doit être un objet JSON")
	}
	if err := scanObject(dec, ""); err != nil {
		return err
	}
	if _, err := dec.Token(); !errors.Is(err, io.EOF) {
		return newErr(ErrInvalidEnvelope, "données superflues après l'objet JSON")
	}
	return nil
}

func scanObject(dec *json.Decoder, path string) error {
	allowed, ok := allowedKeys[path]
	if !ok {
		return newErr(ErrInvalidEnvelope, "objet inattendu au chemin %q", path)
	}
	seen := map[string]bool{}
	nulls := map[string]bool{}
	for dec.More() {
		tok, err := dec.Token()
		if err != nil {
			return newErr(ErrInvalidEnvelope, "JSON illisible : %s", sanitize(err.Error()))
		}
		key, _ := tok.(string)
		if !allowed[key] {
			return newErr(ErrInvalidEnvelope, "champ inconnu %q refusé (chemin %q)", truncate(key, 40), path)
		}
		if seen[key] {
			return newErr(ErrInvalidEnvelope, "champ %q présent plusieurs fois", key)
		}
		seen[key] = true
		child := key
		if path != "" {
			child = path + "." + key
		}
		isNull, err := scanValue(dec, child)
		if err != nil {
			return err
		}
		nulls[key] = isNull
	}
	if _, err := dec.Token(); err != nil { // '}'
		return newErr(ErrInvalidEnvelope, "JSON illisible : %s", sanitize(err.Error()))
	}
	for _, k := range requiredKeys[path] {
		if !seen[k] || nulls[k] {
			return newErr(ErrInvalidEnvelope, "champ obligatoire %q manquant ou nul (chemin %q)", k, path)
		}
	}
	return nil
}

func scanValue(dec *json.Decoder, path string) (bool, error) {
	tok, err := dec.Token()
	if err != nil {
		return false, newErr(ErrInvalidEnvelope, "JSON illisible : %s", sanitize(err.Error()))
	}
	switch v := tok.(type) {
	case json.Delim:
		switch v {
		case '{':
			return false, scanObject(dec, path)
		case '[':
			for dec.More() {
				if _, err := scanValue(dec, path+"[]"); err != nil {
					return false, err
				}
			}
			if _, err := dec.Token(); err != nil {
				return false, newErr(ErrInvalidEnvelope, "JSON illisible : %s", sanitize(err.Error()))
			}
			return false, nil
		}
		return false, newErr(ErrInvalidEnvelope, "JSON mal formé")
	case nil:
		return true, nil
	default:
		return false, nil
	}
}

func (e *Envelope) validate(txTime time.Time) error {
	if e.SchemaVersion != SchemaVersion {
		return newErr(ErrInvalidSchema, "version de schéma %q non prise en charge (attendu %q)", truncate(e.SchemaVersion, 20), SchemaVersion)
	}
	if !reUUID.MatchString(e.EventID) {
		return newErr(ErrInvalidField, "eventId doit être un UUID")
	}
	if !EventTypes[e.EventType] {
		return newErr(ErrInvalidEventType, "type d'événement %q inconnu", truncate(e.EventType, 40))
	}
	if !reMSP.MatchString(e.IssuerOrg) {
		return newErr(ErrInvalidField, "issuerOrg doit être un identifiant MSP")
	}
	if err := e.Subject.validate(); err != nil {
		return err
	}
	if _, err := parseTime(e.OccurredAt, "occurredAt"); err != nil {
		return err
	}
	declared, err := parseTime(e.DeclaredAt, "declaredAt")
	if err != nil {
		return err
	}
	if !txTime.IsZero() && declared.After(txTime.Add(MaxFutureSkew)) {
		return newErr(ErrInvalidTimestamp, "declaredAt est dans le futur par rapport à l'horodatage de la transaction")
	}
	e.declaredAt = declared
	if e.PreviousEventID != nil && !reUUID.MatchString(*e.PreviousEventID) {
		return newErr(ErrInvalidField, "previousEventId doit être un UUID ou null")
	}
	if e.PreviousEventID != nil && *e.PreviousEventID == e.EventID {
		return newErr(ErrInvalidField, "previousEventId ne peut pas désigner l'événement lui-même")
	}
	needsCorrects := e.EventType == "CORRECTION" || e.EventType == "DISPUTE"
	switch {
	case needsCorrects && e.CorrectsEventID == nil:
		return newErr(ErrInvalidField, "correctsEventId est obligatoire pour un événement %s", e.EventType)
	case !needsCorrects && e.CorrectsEventID != nil:
		return newErr(ErrInvalidField, "correctsEventId est interdit pour un événement %s", e.EventType)
	}
	if e.CorrectsEventID != nil {
		if !reUUID.MatchString(*e.CorrectsEventID) {
			return newErr(ErrInvalidField, "correctsEventId doit être un UUID")
		}
		if *e.CorrectsEventID == e.EventID {
			return newErr(ErrInvalidField, "correctsEventId ne peut pas désigner l'événement lui-même")
		}
	}
	if e.CounterpartyOrg != nil && !reMSP.MatchString(*e.CounterpartyOrg) {
		return newErr(ErrInvalidField, "counterpartyOrg doit être un identifiant MSP ou null")
	}
	if e.LocationRef != nil && (len(*e.LocationRef) == 0 || utf8.RuneCountInString(*e.LocationRef) > 100) {
		return newErr(ErrInvalidField, "locationRef doit contenir de 1 à 100 caractères")
	}
	if len(e.Evidence) > 20 {
		return newErr(ErrInvalidEvidence, "au plus 20 pièces justificatives (reçu %d)", len(e.Evidence))
	}
	for i, ev := range e.Evidence {
		if !reSHA256.MatchString(ev.SHA256) {
			return newErr(ErrInvalidEvidence, "evidence[%d].sha256 doit faire 64 caractères hexadécimaux minuscules", i)
		}
		if ev.Kind == "" || utf8.RuneCountInString(ev.Kind) > 50 {
			return newErr(ErrInvalidEvidence, "evidence[%d].kind doit contenir de 1 à 50 caractères", i)
		}
		if ev.MediaType == "" || utf8.RuneCountInString(ev.MediaType) > 100 {
			return newErr(ErrInvalidEvidence, "evidence[%d].mediaType doit contenir de 1 à 100 caractères", i)
		}
	}
	if e.DetailsDigest != nil && !reSHA256.MatchString(*e.DetailsDigest) {
		return newErr(ErrInvalidField, "detailsDigest doit faire 64 caractères hexadécimaux minuscules ou être null")
	}
	if !reKeyID.MatchString(e.SignerKeyID) {
		return newErr(ErrInvalidField, "signerKeyId invalide (1 à 128 caractères parmi A-Z a-z 0-9 . _ : @ -)")
	}
	return nil
}

func (s *Subject) validate() error {
	if s == nil {
		return newErr(ErrInvalidSubject, "subject est obligatoire")
	}
	if s.Kind != "LOT" && s.Kind != "PRODUCT" {
		return newErr(ErrInvalidSubject, "subject.kind doit valoir LOT ou PRODUCT")
	}
	if err := validateSubjectRef(s.Ref); err != nil {
		return err
	}
	if s.GTIN != nil && !reGTIN.MatchString(*s.GTIN) {
		return newErr(ErrInvalidSubject, "subject.gtin doit comporter de 8 à 14 chiffres")
	}
	if s.Lot != nil && (len(*s.Lot) == 0 || utf8.RuneCountInString(*s.Lot) > 100) {
		return newErr(ErrInvalidSubject, "subject.lot doit contenir de 1 à 100 caractères")
	}
	return nil
}

func validateSubjectRef(ref string) error {
	if ref == "" || utf8.RuneCountInString(ref) > 200 {
		return newErr(ErrInvalidSubject, "subject.ref doit contenir de 1 à 200 caractères")
	}
	if !utf8.ValidString(ref) || strings.ContainsRune(ref, 0) || strings.ContainsRune(ref, utf8.MaxRune) {
		return newErr(ErrInvalidSubject, "subject.ref contient des caractères interdits")
	}
	return nil
}

func parseTime(v, field string) (time.Time, error) {
	t, err := time.Parse(time.RFC3339Nano, v)
	if err != nil {
		return time.Time{}, newErr(ErrInvalidTimestamp, "%s doit être une date RFC 3339", field)
	}
	return t, nil
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}

// sanitize évite de recopier de longues portions de l'enveloppe dans les
// messages d'erreur (qui finissent dans des journaux).
func sanitize(s string) string { return truncate(fmt.Sprint(s), 160) }
