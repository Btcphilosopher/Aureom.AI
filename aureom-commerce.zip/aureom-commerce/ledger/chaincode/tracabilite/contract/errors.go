package contract

import "fmt"

// Codes d'erreur renvoyés par le chaincode. Le message d'erreur commence
// toujours par le code suivi de ": " puis d'une explication en français, afin
// que la passerelle REST puisse le convertir en statut HTTP.
const (
	ErrInvalidEnvelope   = "INVALID_ENVELOPE"
	ErrInvalidSchema     = "INVALID_SCHEMA"
	ErrInvalidEventType  = "INVALID_EVENT_TYPE"
	ErrInvalidSubject    = "INVALID_SUBJECT"
	ErrInvalidTimestamp  = "INVALID_TIMESTAMP"
	ErrInvalidEvidence   = "INVALID_EVIDENCE"
	ErrInvalidField      = "INVALID_FIELD"
	ErrInvalidArgument   = "INVALID_ARGUMENT"
	ErrInvalidKey        = "INVALID_KEY"
	ErrIssuerMismatch    = "ISSUER_MISMATCH"
	ErrUnknownKey        = "UNKNOWN_KEY"
	ErrKeyOwnerMismatch  = "KEY_OWNER_MISMATCH"
	ErrKeyNotYetValid    = "KEY_NOT_YET_VALID"
	ErrKeyRetired        = "KEY_RETIRED"
	ErrKeyRevoked        = "KEY_REVOKED"
	ErrKeyExists         = "KEY_EXISTS"
	ErrKeyAlreadyRetired = "KEY_ALREADY_RETIRED"
	ErrKeyAlreadyRevoked = "KEY_ALREADY_REVOKED"
	ErrBadSignature      = "BAD_SIGNATURE"
	ErrConflict          = "CONFLICT"
	ErrUnknownPrevious   = "UNKNOWN_PREVIOUS"
	ErrUnknownCorrected  = "UNKNOWN_CORRECTED"
	ErrCorrectionOwner   = "CORRECTION_NOT_OWNER"
	ErrAccessDenied      = "ACCESS_DENIED"
	ErrNotFound          = "NOT_FOUND"
	ErrInternal          = "INTERNAL"
)

// LedgerError est une erreur métier codée.
type LedgerError struct {
	Code    string
	Message string
}

func (e *LedgerError) Error() string { return e.Code + ": " + e.Message }

func newErr(code, format string, args ...any) error {
	return &LedgerError{Code: code, Message: fmt.Sprintf(format, args...)}
}
