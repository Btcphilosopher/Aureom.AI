package contract

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"strings"
	"testing"

	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

const (
	mspMM = "MaisonMarcheMSP"
	mspAL = "AtelierLumiereMSP"
)

type signer struct {
	keyID string
	priv  ed25519.PrivateKey
	pub   ed25519.PublicKey
}

func newSigner(t *testing.T, keyID string) signer {
	t.Helper()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return signer{keyID: keyID, priv: priv, pub: pub}
}

func (s signer) sign(env string) string {
	return base64.StdEncoding.EncodeToString(ed25519.Sign(s.priv, []byte(env)))
}

type fixture struct {
	t  *testing.T
	l  *memLedger
	cc *Contract
}

func newFixture(t *testing.T) *fixture {
	return &fixture{t: t, l: newLedger(), cc: &Contract{}}
}

func (f *fixture) register(msp string, s signer, validFrom string) {
	f.t.Helper()
	_, err := f.l.invoke(msp, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RegisterSigningKey(ctx, s.keyID, base64.StdEncoding.EncodeToString(s.pub), validFrom)
	})
	if err != nil {
		f.t.Fatalf("RegisterSigningKey: %v", err)
	}
}

func (f *fixture) record(msp, env, sig string) (map[string]any, error) {
	out, err := f.l.invoke(msp, "client", func(ctx *mockContext) (string, error) {
		return f.cc.RecordEvent(ctx, env, sig)
	})
	if err != nil {
		return nil, err
	}
	var m map[string]any
	if jerr := json.Unmarshal([]byte(out), &m); jerr != nil {
		f.t.Fatalf("réponse non JSON : %s", out)
	}
	return m, nil
}

func (f *fixture) evaluate(fn func(ctx *mockContext) (string, error)) (string, error) {
	return f.l.invoke(mspMM, "client", fn)
}

var uuidSeq = 0

func newUUID() string {
	uuidSeq++
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	h := hex.EncodeToString(b)
	return h[0:8] + "-" + h[8:12] + "-4" + h[13:16] + "-a" + h[17:20] + "-" + h[20:32]
}

func baseEnvelope(issuer, keyID string) map[string]any {
	return map[string]any{
		"schemaVersion": "1.0",
		"eventId":       newUUID(),
		"eventType":     "LOT_CREATED",
		"issuerOrg":     issuer,
		"subject": map[string]any{
			"kind": "LOT", "ref": "gtin:03770000000011|lot:L24-118", "gtin": "03770000000011", "lot": "L24-118",
		},
		"occurredAt":      "2026-11-20T08:00:00Z",
		"declaredAt":      "2026-11-20T08:30:00+01:00",
		"previousEventId": nil,
		"correctsEventId": nil,
		"counterpartyOrg": nil,
		"locationRef":     "entrepot:lyon-01",
		"evidence": []any{
			map[string]any{"sha256": strings.Repeat("ab", 32), "kind": "bon_de_livraison", "mediaType": "application/pdf"},
		},
		"detailsDigest": strings.Repeat("0f", 32),
		"signerKeyId":   keyID,
	}
}

func toJSON(t *testing.T, v any) string {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}

func expectCode(t *testing.T, err error, code string) {
	t.Helper()
	if err == nil {
		t.Fatalf("erreur %s attendue, succès obtenu", code)
	}
	if !strings.HasPrefix(err.Error(), code+": ") {
		t.Fatalf("erreur %s attendue, obtenu : %v", code, err)
	}
}

func TestChaincodeMetadataBuilds(t *testing.T) {
	cc, err := contractapi.NewChaincode(&Contract{})
	if err != nil {
		t.Fatalf("NewChaincode : %v", err)
	}
	if cc == nil {
		t.Fatal("chaincode nil")
	}
}

func TestRecordEventHappyPathDuplicateConflict(t *testing.T) {
	f := newFixture(t)
	s := newSigner(t, "mm-ed25519-2026-01")
	f.register(mspMM, s, "2026-01-01T00:00:00Z")

	envMap := baseEnvelope(mspMM, s.keyID)
	env := toJSON(t, envMap)
	res, err := f.record(mspMM, env, s.sign(env))
	if err != nil {
		t.Fatalf("RecordEvent : %v", err)
	}
	sum := sha256.Sum256([]byte(env))
	if res["status"] != "RECORDED" || res["payloadSha256"] != hex.EncodeToString(sum[:]) || res["eventId"] != envMap["eventId"] {
		t.Fatalf("réponse inattendue : %v", res)
	}
	if res["txId"] == "" || res["txTimestamp"] == "" {
		t.Fatalf("txId/txTimestamp manquants : %v", res)
	}

	// Rejeu identique : DUPLICATE, sans écriture.
	before := len(f.l.state)
	dup, err := f.record(mspMM, env, s.sign(env))
	if err != nil {
		t.Fatalf("rejeu : %v", err)
	}
	if dup["status"] != "DUPLICATE" || dup["txId"] != res["txId"] || dup["keyStatus"] != "ACTIVE" {
		t.Fatalf("DUPLICATE attendu avec le txId d'origine : %v", dup)
	}
	if len(f.l.state) != before {
		t.Fatal("un rejeu ne doit rien écrire")
	}

	// Même eventId, contenu différent : CONFLICT.
	envMap["locationRef"] = "entrepot:lyon-02"
	env2 := toJSON(t, envMap)
	_, err = f.record(mspMM, env2, s.sign(env2))
	expectCode(t, err, ErrConflict)

	// Lecture.
	out, err := f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetEvent(ctx, envMap["eventId"].(string)) })
	if err != nil {
		t.Fatal(err)
	}
	var view map[string]any
	_ = json.Unmarshal([]byte(out), &view)
	if view["envelope"] != env || view["submitterMsp"] != mspMM || view["keyStatus"] != "ACTIVE" {
		t.Fatalf("GetEvent inattendu : %s", out)
	}
	_, err = f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetEvent(ctx, newUUID()) })
	expectCode(t, err, ErrNotFound)
}

func TestSignatureAndIdentityChecks(t *testing.T) {
	f := newFixture(t)
	mm := newSigner(t, "mm-1")
	al := newSigner(t, "al-1")
	f.register(mspMM, mm, "2026-01-01T00:00:00Z")
	f.register(mspAL, al, "2026-01-01T00:00:00Z")

	env := toJSON(t, baseEnvelope(mspMM, mm.keyID))

	// Signature d'une autre clé.
	_, err := f.record(mspMM, env, al.sign(env))
	expectCode(t, err, ErrBadSignature)
	// Signature mal encodée.
	_, err = f.record(mspMM, env, "pas-du-base64!")
	expectCode(t, err, ErrBadSignature)
	// Enveloppe modifiée d'un octet après signature.
	sig := mm.sign(env)
	tampered := strings.Replace(env, "lyon-01", "lyon-09", 1)
	_, err = f.record(mspMM, tampered, sig)
	expectCode(t, err, ErrBadSignature)

	// issuerOrg différent de l'appelant.
	_, err = f.record(mspAL, env, sig)
	expectCode(t, err, ErrIssuerMismatch)

	// Clé inconnue.
	envUnknown := toJSON(t, baseEnvelope(mspMM, "inconnue"))
	_, err = f.record(mspMM, envUnknown, mm.sign(envUnknown))
	expectCode(t, err, ErrUnknownKey)

	// Clé d'une autre organisation.
	envOther := toJSON(t, baseEnvelope(mspMM, al.keyID))
	_, err = f.record(mspMM, envOther, al.sign(envOther))
	expectCode(t, err, ErrKeyOwnerMismatch)

	// Clé pas encore valide.
	late := newSigner(t, "mm-futur")
	f.register(mspMM, late, "2026-11-20T12:00:00Z")
	envLate := toJSON(t, baseEnvelope(mspMM, late.keyID))
	_, err = f.record(mspMM, envLate, late.sign(envLate))
	expectCode(t, err, ErrKeyNotYetValid)
}

func TestStrictDecoding(t *testing.T) {
	f := newFixture(t)
	s := newSigner(t, "mm-1")
	f.register(mspMM, s, "2026-01-01T00:00:00Z")

	cases := []struct {
		name   string
		mutate func(m map[string]any)
		raw    func(env string) string
		code   string
	}{
		{name: "champ inconnu (donnée personnelle)", mutate: func(m map[string]any) { m["customerEmail"] = "jean@example.fr" }, code: ErrInvalidEnvelope},
		{name: "champ inconnu dans subject", mutate: func(m map[string]any) { m["subject"].(map[string]any)["nom"] = "Dupont" }, code: ErrInvalidEnvelope},
		{name: "champ inconnu dans evidence", mutate: func(m map[string]any) {
			m["evidence"].([]any)[0].(map[string]any)["url"] = "https://x"
		}, code: ErrInvalidEnvelope},
		{name: "casse différente", raw: func(env string) string { return strings.Replace(env, `"eventId"`, `"EventId"`, 1) }, code: ErrInvalidEnvelope},
		{name: "clé dupliquée", raw: func(env string) string {
			return strings.Replace(env, `{"correctsEventId"`, `{"locationRef":"x","correctsEventId"`, 1)
		}, code: ErrInvalidEnvelope},
		{name: "données superflues", raw: func(env string) string { return env + ` {}` }, code: ErrInvalidEnvelope},
		{name: "pas un objet", raw: func(string) string { return `["a"]` }, code: ErrInvalidEnvelope},
		{name: "evidence absent", mutate: func(m map[string]any) { delete(m, "evidence") }, code: ErrInvalidEnvelope},
		{name: "evidence null", mutate: func(m map[string]any) { m["evidence"] = nil }, code: ErrInvalidEnvelope},
		{name: "subject.ref absent", mutate: func(m map[string]any) { delete(m["subject"].(map[string]any), "ref") }, code: ErrInvalidEnvelope},
		{name: "type incorrect", mutate: func(m map[string]any) { m["eventId"] = 42 }, code: ErrInvalidEnvelope},
		{name: "version de schéma", mutate: func(m map[string]any) { m["schemaVersion"] = "2.0" }, code: ErrInvalidSchema},
		{name: "type d'événement", mutate: func(m map[string]any) { m["eventType"] = "SALE" }, code: ErrInvalidEventType},
		{name: "eventId non UUID", mutate: func(m map[string]any) { m["eventId"] = "evt-1" }, code: ErrInvalidField},
		{name: "subject.kind", mutate: func(m map[string]any) { m["subject"].(map[string]any)["kind"] = "PERSON" }, code: ErrInvalidSubject},
		{name: "gtin", mutate: func(m map[string]any) { m["subject"].(map[string]any)["gtin"] = "12AB" }, code: ErrInvalidSubject},
		{name: "ref trop longue", mutate: func(m map[string]any) { m["subject"].(map[string]any)["ref"] = strings.Repeat("x", 201) }, code: ErrInvalidSubject},
		{name: "date", mutate: func(m map[string]any) { m["occurredAt"] = "20/11/2026" }, code: ErrInvalidTimestamp},
		{name: "declaredAt futur", mutate: func(m map[string]any) { m["declaredAt"] = "2027-01-01T00:00:00Z" }, code: ErrInvalidTimestamp},
		{name: "sha256 majuscules", mutate: func(m map[string]any) {
			m["evidence"].([]any)[0].(map[string]any)["sha256"] = strings.Repeat("AB", 32)
		}, code: ErrInvalidEvidence},
		{name: "trop de pièces", mutate: func(m map[string]any) {
			var ev []any
			for i := 0; i < 21; i++ {
				ev = append(ev, map[string]any{"sha256": strings.Repeat("cd", 32), "kind": "photo", "mediaType": "image/jpeg"})
			}
			m["evidence"] = ev
		}, code: ErrInvalidEvidence},
		{name: "locationRef trop long", mutate: func(m map[string]any) { m["locationRef"] = strings.Repeat("l", 101) }, code: ErrInvalidField},
		{name: "detailsDigest", mutate: func(m map[string]any) { m["detailsDigest"] = "abc" }, code: ErrInvalidField},
		{name: "correctsEventId interdit", mutate: func(m map[string]any) { m["correctsEventId"] = newUUID() }, code: ErrInvalidField},
		{name: "correctsEventId requis", mutate: func(m map[string]any) { m["eventType"] = "CORRECTION" }, code: ErrInvalidField},
		{name: "previous inconnu", mutate: func(m map[string]any) { m["previousEventId"] = newUUID() }, code: ErrUnknownPrevious},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			m := baseEnvelope(mspMM, s.keyID)
			if tc.mutate != nil {
				tc.mutate(m)
			}
			env := toJSON(t, m)
			if tc.raw != nil {
				env = tc.raw(env)
			}
			_, err := f.record(mspMM, env, s.sign(env))
			expectCode(t, err, tc.code)
		})
	}

	// Une enveloppe minimale (champs optionnels absents, evidence vide) est acceptée.
	m := baseEnvelope(mspMM, s.keyID)
	for _, k := range []string{"previousEventId", "correctsEventId", "counterpartyOrg", "locationRef", "detailsDigest"} {
		delete(m, k)
	}
	m["evidence"] = []any{}
	delete(m["subject"].(map[string]any), "gtin")
	delete(m["subject"].(map[string]any), "lot")
	env := toJSON(t, m)
	if _, err := f.record(mspMM, env, s.sign(env)); err != nil {
		t.Fatalf("enveloppe minimale refusée : %v", err)
	}
}

func TestCorrectionDisputeAndChain(t *testing.T) {
	f := newFixture(t)
	mm := newSigner(t, "mm-1")
	al := newSigner(t, "al-1")
	f.register(mspMM, mm, "2026-01-01T00:00:00Z")
	f.register(mspAL, al, "2026-01-01T00:00:00Z")

	ship := baseEnvelope(mspAL, al.keyID)
	ship["eventType"] = "SUPPLIER_SHIPMENT"
	ship["counterpartyOrg"] = mspMM
	shipEnv := toJSON(t, ship)
	if _, err := f.record(mspAL, shipEnv, al.sign(shipEnv)); err != nil {
		t.Fatalf("expédition : %v", err)
	}

	rcpt := baseEnvelope(mspMM, mm.keyID)
	rcpt["eventType"] = "RECEIPT"
	rcpt["previousEventId"] = ship["eventId"]
	rcptEnv := toJSON(t, rcpt)
	if _, err := f.record(mspMM, rcptEnv, mm.sign(rcptEnv)); err != nil {
		t.Fatalf("réception : %v", err)
	}

	// Le distributeur ne peut pas CORRIGER l'événement du fournisseur…
	corr := baseEnvelope(mspMM, mm.keyID)
	corr["eventType"] = "CORRECTION"
	corr["correctsEventId"] = ship["eventId"]
	corrEnv := toJSON(t, corr)
	_, err := f.record(mspMM, corrEnv, mm.sign(corrEnv))
	expectCode(t, err, ErrCorrectionOwner)

	// … mais il peut le CONTESTER.
	disp := baseEnvelope(mspMM, mm.keyID)
	disp["eventType"] = "DISPUTE"
	disp["correctsEventId"] = ship["eventId"]
	dispEnv := toJSON(t, disp)
	if _, err := f.record(mspMM, dispEnv, mm.sign(dispEnv)); err != nil {
		t.Fatalf("contestation : %v", err)
	}

	// Le fournisseur corrige son propre événement.
	fix := baseEnvelope(mspAL, al.keyID)
	fix["eventType"] = "CORRECTION"
	fix["correctsEventId"] = ship["eventId"]
	fixEnv := toJSON(t, fix)
	if _, err := f.record(mspAL, fixEnv, al.sign(fixEnv)); err != nil {
		t.Fatalf("correction : %v", err)
	}

	// Correction d'un événement inexistant.
	ghost := baseEnvelope(mspAL, al.keyID)
	ghost["eventType"] = "CORRECTION"
	ghost["correctsEventId"] = newUUID()
	ghostEnv := toJSON(t, ghost)
	_, err = f.record(mspAL, ghostEnv, al.sign(ghostEnv))
	expectCode(t, err, ErrUnknownCorrected)

	// Requête par sujet : 4 événements, dans l'ordre des transactions.
	out, err := f.evaluate(func(ctx *mockContext) (string, error) {
		return f.cc.QueryEventsBySubject(ctx, "gtin:03770000000011|lot:L24-118")
	})
	if err != nil {
		t.Fatal(err)
	}
	var list []map[string]any
	_ = json.Unmarshal([]byte(out), &list)
	want := []any{ship["eventId"], rcpt["eventId"], disp["eventId"], fix["eventId"]}
	if len(list) != len(want) {
		t.Fatalf("%d événements attendus, %d obtenus", len(want), len(list))
	}
	for i := range want {
		if list[i]["eventId"] != want[i] {
			t.Fatalf("ordre inattendu à l'index %d : %v", i, list[i]["eventId"])
		}
	}

	// Un autre sujet ne renvoie rien (pas de confusion de préfixe).
	out, _ = f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.QueryEventsBySubject(ctx, "gtin:03770000000011") })
	if out != "[]" {
		t.Fatalf("aucun événement attendu, obtenu %s", out)
	}

	// GetEventsByIds.
	ids := toJSON(t, []any{ship["eventId"], newUUID(), rcpt["eventId"]})
	out, err = f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetEventsByIds(ctx, ids) })
	if err != nil {
		t.Fatal(err)
	}
	_ = json.Unmarshal([]byte(out), &list)
	if len(list) != 2 {
		t.Fatalf("2 événements attendus, obtenu %s", out)
	}
}

func TestKeyRegistryLifecycle(t *testing.T) {
	f := newFixture(t)
	s := newSigner(t, "mm-rotation")
	pub := base64.StdEncoding.EncodeToString(s.pub)

	// Réservé aux administrateurs.
	_, err := f.l.invoke(mspMM, "client", func(ctx *mockContext) (string, error) {
		return f.cc.RegisterSigningKey(ctx, s.keyID, pub, "2026-01-01T00:00:00Z")
	})
	expectCode(t, err, ErrAccessDenied)

	// Clé mal formée.
	_, err = f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RegisterSigningKey(ctx, s.keyID, base64.StdEncoding.EncodeToString([]byte("court")), "2026-01-01T00:00:00Z")
	})
	expectCode(t, err, ErrInvalidKey)

	f.register(mspMM, s, "2026-01-01T00:00:00Z")
	_, err = f.l.invoke(mspAL, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RegisterSigningKey(ctx, s.keyID, pub, "2026-01-01T00:00:00Z")
	})
	expectCode(t, err, ErrKeyExists)

	out, err := f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetSigningKey(ctx, s.keyID) })
	if err != nil {
		t.Fatal(err)
	}
	var key SigningKey
	_ = json.Unmarshal([]byte(out), &key)
	if key.OwnerMsp != mspMM || key.PublicKeyBase64 != pub || key.RegisteredTxID == "" || key.RetiredAt != nil {
		t.Fatalf("clé inattendue : %s", out)
	}

	// Événement signé avant le retrait.
	before := baseEnvelope(mspMM, s.keyID)
	before["declaredAt"] = "2026-11-20T08:00:00Z"
	beforeEnv := toJSON(t, before)
	if _, err := f.record(mspMM, beforeEnv, s.sign(beforeEnv)); err != nil {
		t.Fatal(err)
	}

	// Seul le propriétaire peut retirer.
	_, err = f.l.invoke(mspAL, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RetireSigningKey(ctx, s.keyID, "2026-11-20T08:10:00Z")
	})
	expectCode(t, err, ErrKeyOwnerMismatch)

	if _, err := f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RetireSigningKey(ctx, s.keyID, "2026-11-20T08:10:00Z")
	}); err != nil {
		t.Fatal(err)
	}
	_, err = f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RetireSigningKey(ctx, s.keyID, "2026-11-20T08:20:00Z")
	})
	expectCode(t, err, ErrKeyAlreadyRetired)

	// Après le retrait : refusé ; avant : accepté.
	after := baseEnvelope(mspMM, s.keyID)
	after["declaredAt"] = "2026-11-20T08:15:00Z"
	afterEnv := toJSON(t, after)
	_, err = f.record(mspMM, afterEnv, s.sign(afterEnv))
	expectCode(t, err, ErrKeyRetired)
	old := baseEnvelope(mspMM, s.keyID)
	old["declaredAt"] = "2026-11-20T08:05:00Z"
	oldEnv := toJSON(t, old)
	if _, err := f.record(mspMM, oldEnv, s.sign(oldEnv)); err != nil {
		t.Fatalf("signature antérieure au retrait refusée : %v", err)
	}

	// Révocation.
	_, err = f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RevokeSigningKey(ctx, s.keyID, "2026-11-20T08:02:00Z", "")
	})
	expectCode(t, err, ErrInvalidArgument)
	if _, err := f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RevokeSigningKey(ctx, s.keyID, "2026-11-20T08:02:00Z", "clé exposée sur un poste compromis")
	}); err != nil {
		t.Fatal(err)
	}
	_, err = f.record(mspMM, oldEnv, s.sign(oldEnv))
	expectCode(t, err, ErrKeyRevoked)

	// Les événements antérieurs restent, mais signalent la révocation.
	out, err = f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetEvent(ctx, before["eventId"].(string)) })
	if err != nil {
		t.Fatal(err)
	}
	var view EventView
	_ = json.Unmarshal([]byte(out), &view)
	if view.KeyStatus != "REVOKED" || view.KeyDetails == nil || view.KeyDetails.RevocationReason == nil {
		t.Fatalf("keyStatus REVOKED attendu : %s", out)
	}
	_, err = f.l.invoke(mspMM, "admin", func(ctx *mockContext) (string, error) {
		return f.cc.RevokeSigningKey(ctx, s.keyID, "2026-11-20T08:03:00Z", "doublon")
	})
	expectCode(t, err, ErrKeyAlreadyRevoked)

	_, err = f.evaluate(func(ctx *mockContext) (string, error) { return f.cc.GetSigningKey(ctx, "absente") })
	expectCode(t, err, ErrNotFound)
}

func TestFailedTransactionWritesNothing(t *testing.T) {
	f := newFixture(t)
	s := newSigner(t, "mm-1")
	f.register(mspMM, s, "2026-01-01T00:00:00Z")
	n := len(f.l.state)
	env := toJSON(t, baseEnvelope(mspMM, s.keyID))
	_, err := f.record(mspMM, env, newSigner(t, "x").sign(env))
	expectCode(t, err, ErrBadSignature)
	if len(f.l.state) != n {
		t.Fatal("une transaction en erreur ne doit rien écrire")
	}
}
