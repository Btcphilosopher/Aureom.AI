// Commande tracabilite : serveur de chaincode externe (Chaincode-as-a-Service).
//
// Variables d'environnement :
//
//	CHAINCODE_ID              identifiant du paquet installé (label:sha256), obligatoire
//	CHAINCODE_SERVER_ADDRESS  adresse d'écoute, ex. 0.0.0.0:9999 (obligatoire)
//	CHAINCODE_TLS_DISABLED    "true" pour désactiver TLS (défaut : true pour la démo)
//	CHAINCODE_TLS_KEY_FILE    clé privée TLS du serveur (si TLS activé)
//	CHAINCODE_TLS_CERT_FILE   certificat TLS du serveur (si TLS activé)
//	CHAINCODE_CLIENT_CA_FILE  AC des clients (pairs) pour le TLS mutuel (optionnel)
package main

import (
	"log"
	"os"
	"strings"

	"github.com/aureom/aureom-commerce/ledger/chaincode/tracabilite/contract"
	"github.com/hyperledger/fabric-chaincode-go/v2/shim"
	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

func main() {
	cc, err := contractapi.NewChaincode(&contract.Contract{})
	if err != nil {
		log.Fatalf("création du chaincode impossible : %v", err)
	}
	cc.Info.Title = "tracabilite"
	cc.Info.Version = "1.0.0"

	ccid := os.Getenv("CHAINCODE_ID")
	addr := os.Getenv("CHAINCODE_SERVER_ADDRESS")
	if ccid == "" || addr == "" {
		log.Fatal("CHAINCODE_ID et CHAINCODE_SERVER_ADDRESS sont obligatoires")
	}

	tls, err := tlsProperties()
	if err != nil {
		log.Fatalf("configuration TLS invalide : %v", err)
	}
	server := &shim.ChaincodeServer{CCID: ccid, Address: addr, CC: cc, TLSProps: tls}
	log.Printf("serveur de chaincode tracabilite en écoute sur %s (TLS désactivé : %v)", addr, tls.Disabled)
	if err := server.Start(); err != nil {
		log.Fatalf("arrêt du serveur de chaincode : %v", err)
	}
}

func tlsProperties() (shim.TLSProperties, error) {
	disabled := strings.ToLower(os.Getenv("CHAINCODE_TLS_DISABLED"))
	if disabled == "" || disabled == "true" || disabled == "1" {
		return shim.TLSProperties{Disabled: true}, nil
	}
	key, err := os.ReadFile(os.Getenv("CHAINCODE_TLS_KEY_FILE"))
	if err != nil {
		return shim.TLSProperties{}, err
	}
	cert, err := os.ReadFile(os.Getenv("CHAINCODE_TLS_CERT_FILE"))
	if err != nil {
		return shim.TLSProperties{}, err
	}
	props := shim.TLSProperties{Key: key, Cert: cert}
	if caFile := os.Getenv("CHAINCODE_CLIENT_CA_FILE"); caFile != "" {
		ca, err := os.ReadFile(caFile)
		if err != nil {
			return shim.TLSProperties{}, err
		}
		props.ClientCACerts = ca
	}
	return props, nil
}
