#!/usr/bin/env node
// Test de bout en bout du registre de traçabilité AUREOM COMMERCE.
// Prérequis : réseau démarré par ledger/network/scripts/up.sh.
// Usage : node ledger/tests/e2e.mjs            (résultats aussi écrits dans tests/e2e-resultats.txt)
//         E2E_SKIP_OUTAGE=1 node ledger/tests/e2e.mjs   (sans arrêt de pair)
// Dépendances : uniquement les modules intégrés de Node.js ≥ 22 et la commande docker.

import { createHash, generateKeyPairSync, randomUUID, sign as edSign, verify as edVerify } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const netDir = join(here, '..', 'network');

// --------------------------------------------------------------- configuration
function readEnvFile(p) {
    const out = {};
    if (!existsSync(p)) return out;
    for (const line of readFileSync(p, 'utf8').split('\n')) {
        const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
        if (m) out[m[1]] = m[2];
    }
    return out;
}
const envFile = { ...readEnvFile(join(netDir, '.env.example')), ...readEnvFile(join(netDir, '.env')) };
const conf = (k, d) => process.env[k] ?? envFile[k] ?? d;

const ORGS = {
    mm: { name: 'Maison & Marché', msp: 'MaisonMarcheMSP', url: conf('E2E_URL_MAISONMARCHE', 'http://localhost:8800'), token: conf('GATEWAY_TOKEN_MAISONMARCHE') },
    al: { name: 'Atelier Lumière', msp: 'AtelierLumiereMSP', url: conf('E2E_URL_ATELIERLUMIERE', 'http://localhost:8801'), token: conf('GATEWAY_TOKEN_ATELIERLUMIERE') },
    cv: { name: 'Conserverie du Val', msp: 'ConserverieValMSP', url: conf('E2E_URL_CONSERVERIEVAL', 'http://localhost:8802'), token: conf('GATEWAY_TOKEN_CONSERVERIEVAL') },
};

// ------------------------------------------------------------------ sortie
const lines = [];
function out(s = '') {
    lines.push(s);
    console.log(s);
}
const results = [];
function check(label, cond, detail = '') {
    results.push({ label, ok: !!cond });
    out(`  ${cond ? '[OK]  ' : '[ÉCHEC]'} ${label}${detail ? ' — ' + detail : ''}`);
    return !!cond;
}
function section(t) {
    out('');
    out(`## ${t}`);
}
const short = (o) => {
    const s = JSON.stringify(o);
    return s.length > 260 ? s.slice(0, 260) + '…' : s;
};

// ------------------------------------------------------------------ HTTP
async function call(org, method, path, body, { auth = true, timeoutMs = 90_000 } = {}) {
    const t0 = performance.now();
    const headers = { 'Content-Type': 'application/json' };
    if (auth) headers.Authorization = `Bearer ${org.token}`;
    try {
        const res = await fetch(org.url + path, {
            method,
            headers,
            body: body === undefined ? undefined : JSON.stringify(body),
            signal: AbortSignal.timeout(timeoutMs),
        });
        const text = await res.text();
        let json;
        try {
            json = JSON.parse(text);
        } catch {
            json = { raw: text };
        }
        return { status: res.status, body: json, ms: performance.now() - t0, timing: res.headers.get('server-timing') };
    } catch (err) {
        return { status: 0, body: { error: String(err?.cause?.code ?? err) }, ms: performance.now() - t0 };
    }
}

// ------------------------------------------------------- clés et enveloppes
function newKey(keyId) {
    const { publicKey, privateKey } = generateKeyPairSync('ed25519');
    const raw = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
    return { keyId, privateKey, publicKey, publicKeyBase64: raw.toString('base64') };
}
const signB64 = (key, envelope) => edSign(null, Buffer.from(envelope, 'utf8'), key.privateKey).toString('base64');
const sha256hex = (s) => createHash('sha256').update(Buffer.from(s, 'utf8')).digest('hex');

const RUN = Date.now().toString(36);
const LOT = { gtin: '03770000000011', lot: `L24-118-${RUN}` };
const SUBJECT_REF = `gtin:${LOT.gtin}|lot:${LOT.lot}`;

function envelope(fields) {
    const now = new Date().toISOString();
    // Ordre des clés fixe ; la signature porte sur la chaîne exacte produite ici.
    return JSON.stringify({
        schemaVersion: '1.0',
        eventId: fields.eventId ?? randomUUID(),
        eventType: fields.eventType,
        issuerOrg: fields.issuerOrg,
        subject: { kind: 'LOT', ref: fields.ref ?? SUBJECT_REF, gtin: LOT.gtin, lot: LOT.lot },
        occurredAt: fields.occurredAt ?? now,
        declaredAt: fields.declaredAt ?? now,
        previousEventId: fields.previousEventId ?? null,
        correctsEventId: fields.correctsEventId ?? null,
        counterpartyOrg: fields.counterpartyOrg ?? null,
        locationRef: fields.locationRef ?? 'entrepot:lyon-01',
        evidence: fields.evidence ?? [{ sha256: sha256hex(`bon-livraison-${RUN}`), kind: 'bon_de_livraison', mediaType: 'application/pdf' }],
        detailsDigest: fields.detailsDigest ?? sha256hex(`details-${RUN}-${fields.eventType}`),
        signerKeyId: fields.signerKeyId,
        ...(fields.extra ?? {}),
    });
}
const idOf = (env) => JSON.parse(env).eventId;

async function record(org, env, sig) {
    return call(org, 'POST', '/v1/events', { envelope: env, signature: sig });
}

/** Première soumission : laisse le temps au gossip / à la découverte de converger. */
async function withWarmup(fn, label) {
    for (let i = 1; i <= 10; i++) {
        const r = await fn();
        if (r.status !== 502 && r.status !== 503) return r;
        out(`  (préchauffage ${label} : HTTP ${r.status}, nouvel essai ${i}/10)`);
        await new Promise((s) => setTimeout(s, 3000));
    }
    return fn();
}

const percentile = (arr, p) => {
    const s = [...arr].sort((a, b) => a - b);
    return s[Math.min(s.length - 1, Math.ceil((p / 100) * s.length) - 1)];
};
const fmt = (ms) => `${ms.toFixed(0)} ms`;

function docker(...args) {
    return execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
}

async function waitFor(fn, timeoutMs, stepMs = 2000) {
    const end = Date.now() + timeoutMs;
    for (;;) {
        const r = await fn();
        if (r) return true;
        if (Date.now() > end) return false;
        await new Promise((s) => setTimeout(s, stepMs));
    }
}

// =================================================================== scénario
const latencies = { record: [], parallel: [] };

async function main() {
    const { mm, al, cv } = ORGS;
    out(`# Test de bout en bout — registre « tracabilite » (exécution ${RUN}, ${new Date().toISOString()})`);
    out(`Sujet de test : ${SUBJECT_REF}`);

    section('1. Santé des passerelles');
    for (const org of [mm, al, cv]) {
        const r = await call(org, 'GET', '/health', undefined, { auth: false });
        check(`${org.name} (${org.url}) répond 200`, r.status === 200 && r.body.status === 'ok', short(r.body));
    }
    const st = await call(mm, 'GET', '/v1/status');
    check('GET /v1/status (hauteur, empreinte du dernier bloc)', st.status === 200 && st.body.blockHeight > 0, short(st.body));
    const noAuth = await call(mm, 'GET', '/v1/status', undefined, { auth: false });
    check('requête sans jeton refusée (401)', noAuth.status === 401, short(noAuth.body));

    section('2. Registre des clés de signature (Ed25519)');
    const validFrom = new Date(Date.now() - 3600_000).toISOString();
    const mmKey = newKey(`mm-e2e-${RUN}`);
    const alKey = newKey(`al-e2e-${RUN}`);
    let r = await withWarmup(() => call(mm, 'POST', '/v1/keys', { keyId: mmKey.keyId, publicKeyBase64: mmKey.publicKeyBase64, validFrom }), 'enregistrement clé');
    check('Maison & Marché enregistre sa clé (201)', r.status === 201 && r.body.ownerMsp === mm.msp, short(r.body));
    r = await call(mm, 'POST', '/v1/keys', { keyId: mmKey.keyId, publicKeyBase64: mmKey.publicKeyBase64, validFrom });
    check('double enregistrement refusé (422 KEY_EXISTS)', r.status === 422 && r.body.code === 'KEY_EXISTS', short(r.body));
    r = await withWarmup(() => call(al, 'POST', '/v1/keys', { keyId: alKey.keyId, publicKeyBase64: alKey.publicKeyBase64, validFrom }), 'clé fournisseur');
    check('Atelier Lumière enregistre sa clé (201)', r.status === 201 && r.body.ownerMsp === al.msp, short(r.body));
    r = await call(al, 'GET', `/v1/keys/${encodeURIComponent(mmKey.keyId)}`);
    check('la clé du distributeur est lisible depuis la passerelle du fournisseur', r.status === 200 && r.body.publicKeyBase64 === mmKey.publicKeyBase64, short(r.body));

    section('3. Enregistrement, idempotence, conflit');
    const created = envelope({ eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: mmKey.keyId });
    const createdSig = signB64(mmKey, created);
    r = await record(mm, created, createdSig);
    latencies.record.push(r.ms);
    const firstTx = r.body.txId;
    check(
        'LOT_CREATED enregistré (201 RECORDED, payloadSha256 = sha256 de la chaîne signée)',
        r.status === 201 && r.body.status === 'RECORDED' && r.body.payloadSha256 === sha256hex(created) && typeof r.body.blockNumber === 'number',
        `${fmt(r.ms)} ${short(r.body)} [${r.timing}]`,
    );
    r = await record(mm, created, createdSig);
    check('rejeu identique → 201 DUPLICATE (txId et bloc d’origine)', r.status === 201 && r.body.status === 'DUPLICATE' && r.body.txId === firstTx, short(r.body));
    const conflicting = envelope({ eventId: idOf(created), eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, locationRef: 'entrepot:lyon-02' });
    r = await record(mm, conflicting, signB64(mmKey, conflicting));
    check('même eventId, contenu différent → 409 CONFLICT', r.status === 409 && r.body.code === 'CONFLICT' && r.body.retryable === false, short(r.body));

    // Deux soumissions simultanées du même événement : l'une est validée, l'autre
    // est invalidée au commit (MVCC_READ_CONFLICT → 409 retryable) ou voit le doublon.
    const racy = envelope({ eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, locationRef: 'entrepot:course', ref: `${SUBJECT_REF}|course` });
    const racySig = signB64(mmKey, racy);
    const [ra, rb] = await Promise.all([record(mm, racy, racySig), record(mm, racy, racySig)]);
    const outcomes = [ra, rb].map((x) => (x.status === 201 ? x.body.status : `${x.status} ${x.body.code}${x.body.retryable ? ' (retryable)' : ''}`));
    const oneRecorded = outcomes.filter((o) => o === 'RECORDED').length === 1;
    const otherOk = outcomes.some((o) => o === 'DUPLICATE' || o === '409 MVCC_READ_CONFLICT (retryable)');
    check('soumissions concurrentes du même eventId : un seul RECORDED, l’autre MVCC_READ_CONFLICT retryable ou DUPLICATE', oneRecorded && otherOk, outcomes.join(' / '));
    const retried = await record(mm, racy, racySig);
    check('… et la resoumission renvoie DUPLICATE', retried.status === 201 && retried.body.status === 'DUPLICATE', short(retried.body));

    section('4. Rejets de validation (422)');
    const other = envelope({ eventType: 'INSPECTION_RECORDED', issuerOrg: mm.msp, signerKeyId: mmKey.keyId });
    r = await record(mm, other, signB64(alKey, other));
    check('signature d’une autre clé → 422 BAD_SIGNATURE', r.status === 422 && r.body.code === 'BAD_SIGNATURE', short(r.body));
    const mismatch = envelope({ eventType: 'LOT_CREATED', issuerOrg: al.msp, signerKeyId: mmKey.keyId });
    r = await record(mm, mismatch, signB64(mmKey, mismatch));
    check('issuerOrg ≠ organisation appelante → 422 ISSUER_MISMATCH', r.status === 422 && r.body.code === 'ISSUER_MISMATCH', short(r.body));
    const pii = envelope({ eventType: 'CUSTOMER_SHIPMENT', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, extra: { customerEmail: 'client@example.fr' } });
    r = await record(mm, pii, signB64(mmKey, pii));
    check('champ inconnu (donnée personnelle) → 422 INVALID_ENVELOPE', r.status === 422 && r.body.code === 'INVALID_ENVELOPE', short(r.body));
    const foreignKey = envelope({ eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: alKey.keyId });
    r = await record(mm, foreignKey, signB64(alKey, foreignKey));
    check('clé d’une autre organisation → 422 KEY_OWNER_MISMATCH', r.status === 422 && r.body.code === 'KEY_OWNER_MISMATCH', short(r.body));
    const orphan = envelope({ eventType: 'RECEIPT', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, previousEventId: randomUUID() });
    r = await record(mm, orphan, signB64(mmKey, orphan));
    check('previousEventId inconnu → 422 UNKNOWN_PREVIOUS', r.status === 422 && r.body.code === 'UNKNOWN_PREVIOUS', short(r.body));
    r = await call(mm, 'POST', '/v1/events', { envelope: 42 });
    check('corps de requête invalide → 400 BAD_REQUEST', r.status === 400, short(r.body));

    section('5. Chaîne fournisseur → distributeur (registre partagé)');
    const shipment = envelope({ eventType: 'SUPPLIER_SHIPMENT', issuerOrg: al.msp, signerKeyId: alKey.keyId, counterpartyOrg: mm.msp, locationRef: 'usine:annecy' });
    r = await record(al, shipment, signB64(alKey, shipment));
    latencies.record.push(r.ms);
    check('Atelier Lumière enregistre SUPPLIER_SHIPMENT via sa propre passerelle', r.status === 201 && r.body.status === 'RECORDED', `${fmt(r.ms)} ${short(r.body)}`);
    const receipt = envelope({ eventType: 'RECEIPT', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, previousEventId: idOf(shipment), counterpartyOrg: al.msp });
    r = await record(mm, receipt, signB64(mmKey, receipt));
    latencies.record.push(r.ms);
    check('Maison & Marché enregistre RECEIPT avec previousEventId = expédition', r.status === 201 && r.body.status === 'RECORDED', `${fmt(r.ms)} ${short(r.body)}`);

    r = await call(al, 'GET', `/v1/events/${idOf(receipt)}`);
    check('la réception (Maison & Marché) est lisible depuis la passerelle Atelier Lumière', r.status === 200 && r.body.envelope === receipt && r.body.submitterMsp === mm.msp, short({ ...r.body, envelope: '…' }));
    r = await call(cv, 'GET', `/v1/events/${idOf(shipment)}`);
    const verified =
        r.status === 200 &&
        edVerify(null, Buffer.from(r.body.envelope, 'utf8'), alKey.publicKey, Buffer.from(r.body.signatureBase64, 'base64'));
    check('l’expédition est lisible par la Conserverie du Val (tiers) et sa signature se vérifie hors chaîne', verified, `keyStatus=${r.body.keyStatus}, bloc ${r.body.blockNumber}`);
    r = await call(mm, 'GET', `/v1/events/${randomUUID()}`);
    check('événement inconnu → 404 NOT_FOUND', r.status === 404 && r.body.code === 'NOT_FOUND', short(r.body));

    r = await call(cv, 'GET', `/v1/subjects/${encodeURIComponent(SUBJECT_REF)}/events`);
    const types = Array.isArray(r.body) ? r.body.map((e) => JSON.parse(e.envelope).eventType) : [];
    check('requête par sujet : LOT_CREATED → SUPPLIER_SHIPMENT → RECEIPT, triés par horodatage', r.status === 200 && types.join(',') === 'LOT_CREATED,SUPPLIER_SHIPMENT,RECEIPT', types.join(' → '));

    section('6. Corrections et contestations');
    const badCorrection = envelope({ eventType: 'CORRECTION', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, correctsEventId: idOf(shipment) });
    r = await record(mm, badCorrection, signB64(mmKey, badCorrection));
    check('le distributeur ne peut pas CORRIGER l’événement du fournisseur → 422 CORRECTION_NOT_OWNER', r.status === 422 && r.body.code === 'CORRECTION_NOT_OWNER', short(r.body));
    const dispute = envelope({ eventType: 'DISPUTE', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, correctsEventId: idOf(shipment) });
    r = await record(mm, dispute, signB64(mmKey, dispute));
    check('… mais il peut le CONTESTER (DISPUTE → 201)', r.status === 201 && r.body.status === 'RECORDED', short(r.body));
    const correction = envelope({ eventType: 'CORRECTION', issuerOrg: al.msp, signerKeyId: alKey.keyId, correctsEventId: idOf(shipment) });
    r = await record(al, correction, signB64(alKey, correction));
    check('le fournisseur corrige son propre événement (CORRECTION → 201)', r.status === 201 && r.body.status === 'RECORDED', short(r.body));

    section('7. Latence d’un aller-retour RecordEvent (endossement 2/3 + ordonnancement Raft + validation)');
    for (let i = 0; i < 10; i++) {
        const e = envelope({ eventType: 'CUSTODY_TRANSFER', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, locationRef: `quai:${i}` });
        const rr = await record(mm, e, signB64(mmKey, e));
        if (rr.status === 201) latencies.record.push(rr.ms);
    }
    const t0 = performance.now();
    const par = await Promise.all(
        Array.from({ length: 10 }, (_, i) => {
            const e = envelope({ eventType: 'CUSTODY_TRANSFER', issuerOrg: mm.msp, signerKeyId: mmKey.keyId, locationRef: `quai:p${i}` });
            return record(mm, e, signB64(mmKey, e));
        }),
    );
    const parWall = performance.now() - t0;
    for (const p of par) if (p.status === 201) latencies.parallel.push(p.ms);
    const L = latencies.record;
    check(
        `${L.length} soumissions séquentielles réussies`,
        L.length >= 12,
        `min ${fmt(Math.min(...L))}, médiane ${fmt(percentile(L, 50))}, p95 ${fmt(percentile(L, 95))}, max ${fmt(Math.max(...L))}`,
    );
    check(
        `10 soumissions parallèles : ${latencies.parallel.length} réussies`,
        latencies.parallel.length === 10,
        `durée totale ${fmt(parWall)}, médiane ${fmt(percentile(latencies.parallel, 50))} ; statuts ${par.map((p) => p.status).join(',')}`,
    );

    section('8. Rotation et révocation de clé');
    const mmKey2 = newKey(`mm-e2e-${RUN}-b`);
    r = await call(mm, 'POST', '/v1/keys', { keyId: mmKey2.keyId, publicKeyBase64: mmKey2.publicKeyBase64, validFrom });
    check('nouvelle clé enregistrée (rotation)', r.status === 201, short(r.body));
    const retiredAt = new Date().toISOString();
    r = await call(mm, 'POST', `/v1/keys/${encodeURIComponent(mmKey2.keyId)}/retire`, { retiredAt });
    check('retrait de la clé (POST …/retire)', r.status === 200 && r.body.retiredAt === retiredAt, short(r.body));
    await new Promise((s) => setTimeout(s, 20));
    const afterRetire = envelope({ eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: mmKey2.keyId });
    r = await record(mm, afterRetire, signB64(mmKey2, afterRetire));
    check('signature postérieure au retrait → 422 KEY_RETIRED', r.status === 422 && r.body.code === 'KEY_RETIRED', short(r.body));
    const beforeRetire = envelope({ eventType: 'LOT_CREATED', issuerOrg: mm.msp, signerKeyId: mmKey2.keyId, declaredAt: new Date(Date.parse(retiredAt) - 60_000).toISOString() });
    r = await record(mm, beforeRetire, signB64(mmKey2, beforeRetire));
    check('signature antérieure au retrait toujours acceptée', r.status === 201, short(r.body));

    const revokedAt = new Date().toISOString();
    r = await call(al, 'POST', `/v1/keys/${encodeURIComponent(mmKey.keyId)}/revoke`, { revokedAt, reason: 'test' });
    check('une autre organisation ne peut pas révoquer la clé → 422 KEY_OWNER_MISMATCH', r.status === 422 && r.body.code === 'KEY_OWNER_MISMATCH', short(r.body));
    r = await call(mm, 'POST', `/v1/keys/${encodeURIComponent(mmKey.keyId)}/revoke`, { revokedAt, reason: 'poste de signature compromis (test e2e)' });
    check('révocation de la clé par son propriétaire', r.status === 200 && r.body.revokedAt === revokedAt, short(r.body));
    await new Promise((s) => setTimeout(s, 20));
    const afterRevoke = envelope({ eventType: 'RECALL', issuerOrg: mm.msp, signerKeyId: mmKey.keyId });
    r = await record(mm, afterRevoke, signB64(mmKey, afterRevoke));
    check('événement signé après la révocation → 422 KEY_REVOKED', r.status === 422 && r.body.code === 'KEY_REVOKED', short(r.body));
    r = await call(al, 'GET', `/v1/events/${idOf(created)}`);
    check('les événements antérieurs restent, avec keyStatus = REVOKED', r.status === 200 && r.body.keyStatus === 'REVOKED', `keyStatus=${r.body.keyStatus}, motif=${r.body.keyDetails?.revocationReason}`);

    if (process.env.E2E_SKIP_OUTAGE === '1') {
        out('');
        out('(scénario de panne ignoré : E2E_SKIP_OUTAGE=1)');
    } else {
        section('9. Panne d’une organisation (peer0.conserverieval arrêté)');
        docker('stop', '-t', '5', 'peer0.conserverieval.example');
        out('  docker stop peer0.conserverieval.example');
        await new Promise((s) => setTimeout(s, 1000));
        r = await call(cv, 'GET', '/health', undefined, { auth: false });
        check('GET /health de la passerelle Conserverie → 503 indisponible', r.status === 503 && r.body.status === 'indisponible', short(r.body));
        const cvKey = newKey(`cv-e2e-${RUN}`);
        r = await call(cv, 'POST', '/v1/keys', { keyId: cvKey.keyId, publicKeyBase64: cvKey.publicKeyBase64, validFrom });
        check('écriture via la passerelle Conserverie → 503 LEDGER_UNAVAILABLE, retryable', r.status === 503 && r.body.code === 'LEDGER_UNAVAILABLE' && r.body.retryable === true, `${fmt(r.ms)} ${short(r.body)}`);
        const during = envelope({ eventType: 'SUPPLIER_SHIPMENT', issuerOrg: al.msp, signerKeyId: alKey.keyId, counterpartyOrg: mm.msp });
        r = await record(al, during, signB64(alKey, during));
        check('les 2 autres organisations (majorité 2/3) continuent d’écrire', r.status === 201 && r.body.status === 'RECORDED', `${fmt(r.ms)} ${short(r.body)}`);

        docker('start', 'peer0.conserverieval.example');
        out('  docker start peer0.conserverieval.example');
        const back = await waitFor(async () => (await call(cv, 'GET', '/health', undefined, { auth: false })).status === 200, 90_000);
        check('la passerelle Conserverie redevient saine', back);
        const caught = await waitFor(async () => (await call(cv, 'GET', `/v1/events/${idOf(during)}`)).status === 200, 60_000);
        check('le pair redémarré a rattrapé les blocs manquants depuis les orderers', caught);
        // Après redémarrage, le gossip doit reconverger avant que la découverte
        // (utilisée par le service Gateway) propose une combinaison d'endosseurs.
        const tRecover = performance.now();
        let attempts = 0;
        await waitFor(async () => {
            attempts++;
            r = await call(cv, 'POST', '/v1/keys', { keyId: cvKey.keyId, publicKeyBase64: cvKey.publicKeyBase64, validFrom });
            return !(r.body?.retryable === true && (r.status === 503 || r.status === 502));
        }, 120_000, 3000);
        check(
            'la Conserverie peut de nouveau écrire (après reconvergence du gossip)',
            r.status === 201,
            `${attempts} tentative(s), ${fmt(performance.now() - tRecover)} — ${short(r.body)}`,
        );
    }

    // ------------------------------------------------------------------ bilan
    const failed = results.filter((x) => !x.ok);
    section('Bilan');
    out(`  ${results.length - failed.length}/${results.length} vérifications réussies.`);
    const L2 = latencies.record;
    out(`  Latence RecordEvent (aller-retour HTTP complet, attente de la validation du bloc) sur ${L2.length} soumissions séquentielles :`);
    out(`    min ${fmt(Math.min(...L2))} · médiane ${fmt(percentile(L2, 50))} · p95 ${fmt(percentile(L2, 95))} · max ${fmt(Math.max(...L2))}`);
    out(`  (BatchTimeout de l’orderer : 250 ms ; 3 orderers Raft, 3 pairs, endossement MAJORITY 2/3, même hôte Docker.)`);
    if (failed.length > 0) {
        out('  Échecs :');
        for (const f of failed) out(`    - ${f.label}`);
    } else {
        out('  Tous les scénarios attendus se comportent comme prévu.');
    }
    writeFileSync(join(here, 'e2e-resultats.txt'), lines.join('\n') + '\n');
    process.exit(failed.length > 0 ? 1 : 0);
}

main().catch((err) => {
    out(`ERREUR FATALE : ${err?.stack ?? err}`);
    writeFileSync(join(here, 'e2e-resultats.txt'), lines.join('\n') + '\n');
    process.exit(2);
});
