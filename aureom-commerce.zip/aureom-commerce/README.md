# AUREOM COMMERCE — Gestion du commerce connecté

Prototype de suite de gestion pour enseignes, magasins indépendants, grossistes et réseaux multisites, entièrement en français. Il relie achats, réceptions, lots, stocks, caisse, commandes en ligne, entrepôts, fournisseurs et traçabilité. Les opérations quotidiennes reposent sur **PostgreSQL**. Les seuls événements partagés entre organisations sont inscrits sur un **registre permissionné Hyperledger Fabric**.

Démonstration : **Maison & Marché**, enseigne **fictive** (équipement de la maison et épicerie fine) avec deux magasins (Paris, Lyon), un entrepôt (Orléans-Saran) et deux fournisseurs (Atelier Lumière, Conserverie du Val). Ces deux fournisseurs sont aussi membres du réseau Fabric.

> **Avertissements.**
> - La caisse est un **prototype non certifié**. Elle ne doit pas servir à encaisser réellement (`docs/conformite-et-cadre.md`). Les paiements sont **simulés** et aucune donnée de carte n'est acceptée.
> - Le registre conserve des **déclarations signées**. Il ne prouve pas, à lui seul, qu'un événement physique a eu lieu (`docs/blockchain.md`).
> - L'historique de ventes utilisé par les prévisions est **synthétique**.

## Contenu

```
backend/      API FastAPI (monolithe modulaire), worker, pont MQTT, migrations Alembic, jeu de démo, démo, tests
frontend/     Interface React + TypeScript (bureau, caisse tactile, tablette d'entrepôt)
ledger/       Hyperledger Fabric : chaincode Go, passerelle REST Node/TS, réseau 3 organisations, tests de bout en bout
simulators/   Simulateurs d'équipements MQTT (température, RFID, balance, convoyeur, pick-to-light)
infra/        Configuration Mosquitto (ACL), PostgreSQL
scripts/      Secrets locaux, sauvegarde, restauration
docs/         Architecture, registre, gouvernance, API (openapi.json), indicateurs, modèles, conformité,
              dépendances et licences, statut des fonctionnalités, résultats de tests, captures, sorties de démo
```

## Démarrage rapide (Docker Compose)

Prérequis : Docker 24+ avec Compose v2, `openssl`.

```bash
./scripts/generer-secrets.sh
```

```bash
docker compose up -d --build
```

- Interface : http://localhost:8080 ; API et Swagger : http://localhost:8000/docs.
- Le premier démarrage applique les migrations et charge Maison & Marché. Le registre est alors en mode **simulation**, affiché comme tel.
- Simulateurs d'équipements : `docker compose --profile simulateurs up simulateurs`.
- Docker Hub limité (erreur 429) : dans `.env`, `REGISTRY=mirror.gcr.io/library`, `REGISTRY_MQTT=mirror.gcr.io` et `SEAWEEDFS_IMAGE=mirror.gcr.io/chrislusf/seaweedfs:4.55`. Derrière un proxy TLS d'entreprise : `BUILD_CA_FILE=/chemin/ca.pem`.

### Avec le réseau Hyperledger Fabric (3 organisations)

```bash
./ledger/network/scripts/up.sh
```

```bash
docker compose -f docker-compose.yml -f docker-compose.fabric.yml up -d --build
```

`up.sh` génère le matériel cryptographique, démarre 3 orderers Raft, 3 pairs et le chaincode CCaaS, crée le canal `tracabilite` et démarre les passerelles (environ 40 s à froid). Détails dans `ledger/README.md`.

## Comptes de démonstration

Mot de passe commun : `demo-aureom-2026` (démonstration uniquement).

| Identifiant | Rôle | Périmètre |
|---|---|---|
| `admin` | administration | tous sites |
| `direction` | direction (approbation jusqu'à 50 000 €) | tous sites |
| `magasin.paris` | responsable de magasin (remise ≤ 30 %) | Paris |
| `caisse.paris`, `caisse.lyon` | caisse (remise ≤ 10 %) | leur magasin |
| `prepa.orleans`, `prepa.paris` | préparation et réception | leur site |
| `achats` / `achats.resp` | acheteur / responsable des achats (approbation ≤ 5 000 €) | — |
| `qualite` | qualité, rappels, vérifications indépendantes | — |
| `analyste` | analyses (lecture) | — |

## Développement local (sans Docker)

Prérequis : Python 3.13, PostgreSQL 16 avec l'extension `btree_gist`, Node 22.

```bash
cd backend && python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
```

```bash
export AUREOM_DATABASE_URL=postgresql+psycopg://aureom:aureom@localhost:5432/aureom
```

```bash
alembic upgrade head && python -m app.seed
```

```bash
uvicorn app.main:app --reload
```

```bash
python -m app.worker
```

```bash
cd frontend && npm ci && npm run dev
```

## Démonstration reproductible (14 étapes)

```bash
cd backend && python -m app.demo --sortie ./demo-sortie
```

La commande réinitialise la base, recharge Maison & Marché et joue les 14 étapes **par l'API HTTP réelle**. Chaque étape vérifie ses résultats par des assertions. Elle produit le journal, le ticket et le rapport de traçabilité (JSON, HTML, CSV).

| # | Étape | Ce qui est démontré |
|---|---|---|
| 1 | Produit et conditionnements | pot / paquet de 6 / carton de 24 / palette ; chaîne incohérente refusée ; prix datés par canal |
| 2 | Commande fournisseur | arrondi au carton ; refus d'approbation de l'acheteur, approbation par la responsable des achats |
| 3 | Réception d'un lot | événements du fournisseur depuis **son** nœud ; livraison partielle ; produits endommagés ; certificat « non vérifié » |
| 4 | Événement signé | RECEIPT chaîné à l'expédition fournisseur, confirmé (n° de transaction, n° de bloc) ; 4 niveaux de preuve |
| 5 | Transfert vers un magasin | stock attendu puis reçu ; opération interne non publiée sur le registre |
| 6 | Vente en caisse | remise plafonnée ; paiement partiel ; rejeu de requête idempotent ; numéro de carte refusé ; événement rejoué ou falsifié |
| 7 | Commande en ligne | réservation ; réservation concurrente refusée ; payée ≠ prête |
| 8 | Préparation et retrait | scan d'un mauvais article refusé ; code de retrait ; historique d'états |
| 9 | RFID dupliqué | 5 lectures → 1 observation, 0 mouvement |
| 10 | Température | valeur aberrante écartée ; alerte ; quarantaine proposée puis approuvée |
| 11 | Retour | remboursement sans remise en stock ; inspection puis remise en vente ; fidélité ajustée ; clôture de caisse |
| 12 | Rappel | blocage multisite ; destinations certaines ou présumées ; tâches ; vente du lot rappelé refusée |
| 13 | Indisponibilité du registre | opérations locales finalisées, événements en attente puis confirmés, réconciliation |
| 14 | Rapport de traçabilité | export JSON / HTML / CSV avec limites de la preuve |

En mode Fabric (variables `AUREOM_LEDGER_MODE=fabric`, `AUREOM_LEDGER_GATEWAY_URL`, `AUREOM_LEDGER_GATEWAY_TOKEN`, `AUREOM_GATEWAY_CONSERVERIE_URL`, `AUREOM_GATEWAY_SUPPLIER_TOKEN`), `AUREOM_DEMO_PANNE_REELLE=1` arrête réellement le conteneur de la passerelle à l'étape 13.

## Tests

```bash
cd backend && pytest
```

```bash
AUREOM_TEST_FABRIC=1 AUREOM_LEDGER_MODE=fabric pytest tests/test_fabric_integration.py
```

```bash
cd ledger/chaincode/tracabilite && go test ./...
```

```bash
node ledger/tests/e2e.mjs
```

La deuxième commande attend aussi les variables de passerelle indiquées pour la démonstration en mode Fabric. Les résultats réellement obtenus sont dans `docs/resultats-tests.md`.

## Documentation

- `docs/architecture.md` : modules, choix techniques, garanties transactionnelles
- `docs/blockchain.md` : répartition base/registre, apports et coûts, limites de la preuve, synchronisation
- `docs/gouvernance.md` : organisations, admission, clés, litiges, schémas, récupération
- `docs/api.md` et `docs/openapi.json` : conventions et parcours de l'API
- `docs/indicateurs.md` : définitions des indicateurs
- `docs/automatisation-et-modeles.md` : règles, prévisions, évaluation
- `docs/conformite-et-cadre.md` : caisse, PCI DSS, RGPD, prix, rappels, GS1 (sources à vérifier)
- `docs/dependances-et-licences.md` : versions et licences vérifiées
- `docs/statut-fonctionnalites.md` : fonctions opérationnelles, simulées, intégrées, reportées
- `ledger/README.md` : réseau Fabric, chaincode, passerelle
- `frontend/README.md` : interface
