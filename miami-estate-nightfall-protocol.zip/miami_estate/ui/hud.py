"""
ui.hud
======

Per-player heads-up display: their role, capabilities, current zone, and
what's happening around them right now.
"""

from __future__ import annotations

from miami_estate.players.player_state import PlayerState
from miami_estate.players.roles import ROLE_DIRECTORY
from miami_estate.security.monitoring import MonitoringSystem


def render_hud(player: PlayerState, monitoring: MonitoringSystem) -> str:
    definition = ROLE_DIRECTORY[player.role]
    zone = monitoring.estate.zone(player.zone)
    lines = [
        f"[{player.name}] {player.role.value} — {player.zone.value}",
        f"  {definition.description}",
        f"  Zone alert: {zone.alert_state.value} | Security: {zone.security_level:.1f}% "
        f"| Camera coverage: {zone.camera_coverage:.1f}%",
        f"  Capabilities: {', '.join(sorted(definition.capabilities))}",
        f"  Actions: {player.actions_taken} | Alerts responded: {player.alerts_responded} "
        f"| Repairs: {player.repairs_completed}",
    ]
    return "\n".join(lines)
