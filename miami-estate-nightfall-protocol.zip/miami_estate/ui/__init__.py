"""Text-mode UI renderers: digital-twin map, command center, per-player HUD."""
