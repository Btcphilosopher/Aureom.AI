"""
ui.estate_map
==============

Renders a text digital-twin of the property: zones, occupancy, cameras,
alert state — the "DIGITAL-TWIN ESTATE MAP" view.
"""

from __future__ import annotations

from miami_estate.estate.property import Estate
from miami_estate.security.monitoring import MonitoringSystem


def render_estate_map(estate: Estate, monitoring: MonitoringSystem) -> str:
    lines = ["=" * 72, f"  DIGITAL TWIN — {estate.name}".ljust(72), "=" * 72]
    for zone in estate.zones.values():
        cams = monitoring.cameras.by_zone(zone.zone_id)
        cam_health = round(sum(c.coverage for c in cams) / len(cams), 1) if cams else 0.0
        occ = ", ".join(zone.occupancy) if zone.occupancy else "—"
        lines.append(
            f"{zone.zone_id.value:<28} | ALERT:{zone.alert_state.value:<9} "
            f"| SEC:{zone.security_level:5.1f}% | CAM:{cam_health:5.1f}% | OCC: {occ}"
        )
    lines.append("-" * 72)
    lines.append(
        f"MARINA integrity {estate.marina.integrity:.1f}%   "
        f"GARAGE integrity {estate.garage.integrity:.1f}%   "
        f"Population on-site: {estate.population()}"
    )
    lines.append("=" * 72)
    return "\n".join(lines)
