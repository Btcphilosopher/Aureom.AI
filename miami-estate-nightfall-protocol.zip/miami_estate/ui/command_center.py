"""
ui.command_center
===================

Renders the strategic ESTATE STATUS command center screen:
percentage board + active-alerts board, exactly as sketched in the
design brief.
"""

from __future__ import annotations

from miami_estate.estate.property import Estate
from miami_estate.infrastructure.smart_home import SmartHomeHub


def render_command_center(hub: SmartHomeHub, tick: int, clock_label: str) -> str:
    board = hub.estate_status_board()
    lines = [
        "=" * 60,
        f"  ESTATE COMMAND CENTER — TICK {tick:04d} — {clock_label}",
        "=" * 60,
        "ESTATE STATUS",
        "",
    ]
    for key in ("SECURITY", "POWER", "NETWORK", "CAMERAS", "ACCESS", "STRUCTURE"):
        lines.append(f"  {key:<14} {board[key]:5.1f}%")
    lines.append("")
    lines.append("ACTIVE ALERTS")
    lines.append("")
    for entry in hub.monitoring.active_alerts_board():
        lines.append(f"  {entry['zone']:<28} — {entry['state']}")
    lines.append("=" * 60)
    return "\n".join(lines)
