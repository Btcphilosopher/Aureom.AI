"""
events.incidents
=================

The `Incident` model: one fictional, abstracted estate event. Incidents
are the atomic unit raid scenarios are built from — they never describe
real intrusion techniques, only abstract game triggers and effects.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List

from miami_estate.core.state import DamageCategory, Severity
from miami_estate.estate.zones import ZoneId


class IncidentType(str, Enum):
    UNKNOWN_VEHICLE = "UNKNOWN VEHICLE"
    UNAUTHORISED_ENTRY = "UNAUTHORISED ENTRY"
    WATERFRONT_INTRUSION = "WATERFRONT INTRUSION"
    GARAGE_ALERT = "GARAGE ALERT"
    PERIMETER_ALERT = "PERIMETER ALERT"
    POWER_FAILURE = "POWER FAILURE"
    COMMUNICATION_FAILURE = "COMMUNICATION FAILURE"
    MULTI_ZONE_EVENT = "MULTI-ZONE EVENT"


# Fictional per-type default damage template, applied to the primary zone.
DEFAULT_DAMAGE_TEMPLATE: Dict[IncidentType, Dict[DamageCategory, float]] = {
    IncidentType.UNKNOWN_VEHICLE: {DamageCategory.SECURITY: 3},
    IncidentType.UNAUTHORISED_ENTRY: {
        DamageCategory.SECURITY: 10,
        DamageCategory.STRUCTURAL: 4,
    },
    IncidentType.WATERFRONT_INTRUSION: {
        DamageCategory.SECURITY: 8,
        DamageCategory.DECORATIVE: 5,
    },
    IncidentType.GARAGE_ALERT: {
        DamageCategory.STRUCTURAL: 18,
        DamageCategory.SECURITY: 12,
        DamageCategory.NETWORK: 5,
        DamageCategory.VEHICLE: 7,
    },
    IncidentType.PERIMETER_ALERT: {DamageCategory.SECURITY: 6},
    IncidentType.POWER_FAILURE: {DamageCategory.ELECTRICAL: 20},
    IncidentType.COMMUNICATION_FAILURE: {DamageCategory.NETWORK: 20},
    IncidentType.MULTI_ZONE_EVENT: {
        DamageCategory.SECURITY: 10,
        DamageCategory.STRUCTURAL: 6,
        DamageCategory.NETWORK: 6,
    },
}


@dataclass
class Incident:
    incident_id: str
    incident_type: IncidentType
    zone: ZoneId
    severity: Severity
    started_tick: int
    duration_ticks: int
    affected_systems: List[str] = field(default_factory=list)
    concurrent_with: List[str] = field(default_factory=list)
    resolved: bool = False

    def is_active(self, tick: int) -> bool:
        return not self.resolved and self.started_tick <= tick < self.started_tick + self.duration_ticks

    def damage_template(self) -> Dict[DamageCategory, float]:
        base = DEFAULT_DAMAGE_TEMPLATE.get(self.incident_type, {})
        multiplier = {
            Severity.LOW: 0.6,
            Severity.MEDIUM: 1.0,
            Severity.HIGH: 1.5,
            Severity.CRITICAL: 2.2,
        }[self.severity]
        return {cat: amt * multiplier for cat, amt in base.items()}

    def snapshot(self) -> Dict[str, object]:
        return {
            "id": self.incident_id,
            "type": self.incident_type.value,
            "zone": self.zone.value,
            "severity": self.severity.value,
            "started_tick": self.started_tick,
            "duration_ticks": self.duration_ticks,
            "affected_systems": list(self.affected_systems),
            "resolved": self.resolved,
        }
