"""Procedural, fictional estate event generation: incidents, raids, scenarios."""
