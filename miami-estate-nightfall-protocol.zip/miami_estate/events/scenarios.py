"""
events.scenarios
=================

Named, pre-tuned scenario presets — including the "MIAMI NIGHTFALL"
demo scenario used by `main.py` and the playable-demo tests.
"""

from __future__ import annotations

from dataclasses import dataclass

from miami_estate.events.raid_generator import RaidConfig, RaidGenerator, RaidScenario


@dataclass
class ScenarioPreset:
    name: str
    description: str
    config: RaidConfig

    def build(self) -> RaidScenario:
        return RaidGenerator(self.config).generate()


MIAMI_NIGHTFALL = ScenarioPreset(
    name="MIAMI NIGHTFALL",
    description=(
        "23:47 — heavy rain, low visibility. Main house secure, garage active, "
        "marina active. Multiple simultaneous estate events develop across the "
        "property, forcing coordinated response before infrastructure begins to fail."
    ),
    config=RaidConfig(
        seed=19472026,
        difficulty=3,
        player_count=4,
        weather="STORM",
        hour=23,
        phases=3,
    ),
)

QUIET_NIGHT = ScenarioPreset(
    name="QUIET NIGHT",
    description="A calm night with a single low-severity perimeter check.",
    config=RaidConfig(seed=101, difficulty=1, player_count=2, weather="CLEAR", hour=22, phases=1),
)

STORM_SURGE = ScenarioPreset(
    name="STORM SURGE",
    description="Severe weather masks a coordinated multi-zone incursion attempt.",
    config=RaidConfig(seed=7788, difficulty=5, player_count=8, weather="STORM", hour=2, phases=3),
)

ALL_PRESETS = {p.name: p for p in (MIAMI_NIGHTFALL, QUIET_NIGHT, STORM_SURGE)}
