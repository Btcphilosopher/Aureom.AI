"""
events.raid_generator
======================

The procedural raid system. Given a seed, this builds a deterministic,
*evolving* sequence of incidents (not random enemy spawns): an opening
probe, an escalation into simultaneous zone alerts, and — at higher
difficulty — an infrastructure-targeting phase. The same seed always
reproduces the same scenario, which keeps the simulation deterministic
and testable.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import List

from miami_estate.core.state import Severity
from miami_estate.estate.zones import ZoneId
from miami_estate.events.incidents import Incident, IncidentType

_WATERSIDE_ZONES = [ZoneId.MARINA, ZoneId.POOL]
_LAND_APPROACH_ZONES = [ZoneId.FRONT_ENTRANCE, ZoneId.GARDENS, ZoneId.GARAGE]
_INTERIOR_ZONES = [ZoneId.MAIN_HOUSE, ZoneId.WEST_WING, ZoneId.EAST_WING]

_SEVERITY_ORDER = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]


@dataclass
class RaidConfig:
    seed: int
    difficulty: int = 2          # 1-5
    player_count: int = 4
    weather: str = "CLEAR"       # CLEAR / RAIN / STORM / FOG
    hour: int = 23
    phases: int = 3


@dataclass
class RaidScenario:
    config: RaidConfig
    incidents: List[Incident] = field(default_factory=list)

    def incidents_starting_at(self, tick: int) -> List[Incident]:
        return [i for i in self.incidents if i.started_tick == tick]

    def all_active_at(self, tick: int) -> List[Incident]:
        return [i for i in self.incidents if i.is_active(tick)]

    def peak_simultaneous_incidents(self) -> int:
        if not self.incidents:
            return 0
        span = max(i.started_tick + i.duration_ticks for i in self.incidents)
        return max(len(self.all_active_at(t)) for t in range(span))


class RaidGenerator:
    """Builds deterministic, escalating RaidScenario objects from a seed."""

    def __init__(self, config: RaidConfig):
        self.config = config
        self.rng = random.Random(config.seed)
        self._counter = 0

    def _next_id(self) -> str:
        self._counter += 1
        return f"INC-{self._counter:04d}"

    def _weather_severity_bump(self) -> int:
        return {"CLEAR": 0, "RAIN": 1, "FOG": 1, "STORM": 2}.get(self.config.weather, 0)

    def _severity_for_phase(self, phase: int) -> Severity:
        idx = min(
            len(_SEVERITY_ORDER) - 1,
            max(0, phase - 1 + (self.config.difficulty - 2) + self._weather_severity_bump() // 2),
        )
        return _SEVERITY_ORDER[idx]

    def generate(self) -> RaidScenario:
        scenario = RaidScenario(config=self.config)
        tick_cursor = 0

        # Phase 1 — probe: a single low-key approach, testing the perimeter.
        probe_zone = self.rng.choice(_LAND_APPROACH_ZONES)
        probe = Incident(
            incident_id=self._next_id(),
            incident_type=IncidentType.UNKNOWN_VEHICLE,
            zone=probe_zone,
            severity=self._severity_for_phase(1),
            started_tick=tick_cursor,
            duration_ticks=3,
            affected_systems=["CAMERAS"],
        )
        scenario.incidents.append(probe)
        tick_cursor += 2

        # Phase 2 — escalation: simultaneous alerts across land + water,
        # sized to the player count so a solo player never faces more
        # concurrent zones than they can plausibly triage.
        concurrent_zones = min(2 + self.config.difficulty // 2, max(2, self.config.player_count))
        land = self.rng.choice(_LAND_APPROACH_ZONES)
        water = self.rng.choice(_WATERSIDE_ZONES)
        escalation_types = [
            (land, IncidentType.PERIMETER_ALERT),
            (water, IncidentType.WATERFRONT_INTRUSION),
            (ZoneId.GARAGE, IncidentType.GARAGE_ALERT),
        ][:concurrent_zones]
        concurrent_ids = []
        for zone, itype in escalation_types:
            inc = Incident(
                incident_id=self._next_id(),
                incident_type=itype,
                zone=zone,
                severity=self._severity_for_phase(2),
                started_tick=tick_cursor,
                duration_ticks=5,
                affected_systems=["CAMERAS", "SENSORS", "ACCESS_CONTROL"],
            )
            scenario.incidents.append(inc)
            concurrent_ids.append(inc.incident_id)
        for inc in scenario.incidents[-len(escalation_types):]:
            inc.concurrent_with = [i for i in concurrent_ids if i != inc.incident_id]
        tick_cursor += 4

        # Phase 3 (difficulty >= 2) — infrastructure exploitation: an
        # attempt to exploit a temporarily degraded system, plus a
        # multi-zone event that forces coordinated response.
        if self.config.phases >= 3 and self.config.difficulty >= 2:
            infra_type = self.rng.choice(
                [IncidentType.POWER_FAILURE, IncidentType.COMMUNICATION_FAILURE]
            )
            infra_zone = ZoneId.SERVICE_AREA
            infra = Incident(
                incident_id=self._next_id(),
                incident_type=infra_type,
                zone=infra_zone,
                severity=self._severity_for_phase(3),
                started_tick=tick_cursor,
                duration_ticks=4,
                affected_systems=["POWER", "NETWORK"],
            )
            scenario.incidents.append(infra)

            multi_zone = Incident(
                incident_id=self._next_id(),
                incident_type=IncidentType.MULTI_ZONE_EVENT,
                zone=self.rng.choice(_INTERIOR_ZONES),
                severity=self._severity_for_phase(3),
                started_tick=tick_cursor + 1,
                duration_ticks=6,
                affected_systems=["CAMERAS", "ACCESS_CONTROL", "ALARMS"],
                concurrent_with=[infra.incident_id],
            )
            scenario.incidents.append(multi_zone)

        return scenario
