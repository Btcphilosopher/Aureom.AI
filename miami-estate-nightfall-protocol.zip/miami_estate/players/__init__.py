"""Cooperative player roles, per-player state, and coordination scoring."""
