"""
players.roles
==============

The five cooperative player roles and the estate systems each role is
permitted to operate.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, FrozenSet


class Role(str, Enum):
    SECURITY_OPERATOR = "SECURITY OPERATOR"
    ESTATE_MANAGER = "ESTATE MANAGER"
    MOBILE_RESPONDER = "MOBILE RESPONDER"
    TECHNICIAN = "TECHNICIAN"
    MARINA_OPERATOR = "MARINA OPERATOR"


ROLE_CAPABILITIES: Dict[Role, FrozenSet[str]] = {
    Role.SECURITY_OPERATOR: frozenset(
        {"CAMERAS", "ALARMS", "ACCESS_CONTROL", "ESTATE_MAP", "COMMUNICATIONS"}
    ),
    Role.ESTATE_MANAGER: frozenset(
        {"SYSTEM_PRIORITIES", "EMERGENCY_RESPONSE", "REPAIRS", "PROPERTY_SYSTEMS", "BUDGET"}
    ),
    Role.MOBILE_RESPONDER: frozenset({"MOVEMENT", "ALERT_RESPONSE", "NPC_ESCORT"}),
    Role.TECHNICIAN: frozenset(
        {"REPAIR_CAMERAS", "REPAIR_DOORS", "REPAIR_SENSORS", "REPAIR_POWER", "REPAIR_COMMS"}
    ),
    Role.MARINA_OPERATOR: frozenset(
        {"WATERFRONT_SYSTEMS", "DOCK_ACCESS", "BOAT_MONITORING", "MARINA_ALERTS"}
    ),
}


@dataclass(frozen=True)
class RoleDefinition:
    role: Role
    description: str
    capabilities: FrozenSet[str]


ROLE_DIRECTORY: Dict[Role, RoleDefinition] = {
    Role.SECURITY_OPERATOR: RoleDefinition(
        Role.SECURITY_OPERATOR,
        "Runs the command center: camera grid, alarms, access control, comms.",
        ROLE_CAPABILITIES[Role.SECURITY_OPERATOR],
    ),
    Role.ESTATE_MANAGER: RoleDefinition(
        Role.ESTATE_MANAGER,
        "Sets system priorities, directs emergency response, oversees repairs and budget.",
        ROLE_CAPABILITIES[Role.ESTATE_MANAGER],
    ),
    Role.MOBILE_RESPONDER: RoleDefinition(
        Role.MOBILE_RESPONDER,
        "Moves through the estate responding to in-game alerts on the ground.",
        ROLE_CAPABILITIES[Role.MOBILE_RESPONDER],
    ),
    Role.TECHNICIAN: RoleDefinition(
        Role.TECHNICIAN,
        "Repairs cameras, doors, sensors, power and communications systems.",
        ROLE_CAPABILITIES[Role.TECHNICIAN],
    ),
    Role.MARINA_OPERATOR: RoleDefinition(
        Role.MARINA_OPERATOR,
        "Manages waterfront systems, dock access, boat monitoring and marina alerts.",
        ROLE_CAPABILITIES[Role.MARINA_OPERATOR],
    ),
}


def can_perform(role: Role, capability: str) -> bool:
    return capability in ROLE_CAPABILITIES.get(role, frozenset())
