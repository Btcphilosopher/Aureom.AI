"""
players.cooperation
=====================

Tracks the 1-8 player cooperative session and produces a coordination
score: how well zone alerts were covered by an appropriately-positioned
player during the scenario.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.core.state import AlertLevel
from miami_estate.estate.property import Estate
from miami_estate.players.player_state import PlayerState


@dataclass
class CooperationTracker:
    estate: Estate
    players: List[PlayerState]
    zones_covered_when_alerted: int = 0
    zones_uncovered_when_alerted: int = 0

    def sample_tick(self) -> None:
        occupied_zones = {p.zone for p in self.players}
        for zone in self.estate.zones.values():
            if zone.alert_state in (AlertLevel.ALERT, AlertLevel.LOCKDOWN, AlertLevel.EMERGENCY):
                if zone.zone_id in occupied_zones:
                    self.zones_covered_when_alerted += 1
                else:
                    self.zones_uncovered_when_alerted += 1

    def coordination_score(self) -> float:
        total = self.zones_covered_when_alerted + self.zones_uncovered_when_alerted
        if total == 0:
            return 100.0
        return round(100 * self.zones_covered_when_alerted / total, 1)

    def roster_snapshot(self) -> List[Dict[str, object]]:
        return [p.snapshot() for p in self.players]
