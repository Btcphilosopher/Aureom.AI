"""
players.player_state
=====================

Per-player runtime state: identity, role, current zone and a small
personal performance ledger used for the end-of-scenario score.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.estate.zones import ZoneId
from miami_estate.players.roles import Role, can_perform


@dataclass
class PlayerState:
    player_id: str
    name: str
    role: Role
    zone: ZoneId
    actions_taken: int = 0
    alerts_responded: int = 0
    repairs_completed: int = 0

    def move_to(self, zone: ZoneId) -> None:
        self.zone = zone
        self.actions_taken += 1

    def perform(self, capability: str) -> bool:
        allowed = can_perform(self.role, capability)
        if allowed:
            self.actions_taken += 1
        return allowed

    def respond_to_alert(self) -> None:
        self.alerts_responded += 1
        self.actions_taken += 1

    def complete_repair(self) -> None:
        self.repairs_completed += 1
        self.actions_taken += 1

    def snapshot(self) -> Dict[str, object]:
        return {
            "player": self.name,
            "role": self.role.value,
            "zone": self.zone.value,
            "actions_taken": self.actions_taken,
            "alerts_responded": self.alerts_responded,
            "repairs_completed": self.repairs_completed,
        }


def default_roster(names: List[str]) -> List[PlayerState]:
    """Assigns up to 8 players to the five roles, cycling for larger groups."""
    roles = list(Role)
    zones_by_role = {
        Role.SECURITY_OPERATOR: ZoneId.SECURITY_ROOM,
        Role.ESTATE_MANAGER: ZoneId.MAIN_HOUSE,
        Role.MOBILE_RESPONDER: ZoneId.GARDENS,
        Role.TECHNICIAN: ZoneId.GARAGE,
        Role.MARINA_OPERATOR: ZoneId.MARINA,
    }
    roster = []
    for i, name in enumerate(names[:8]):
        role = roles[i % len(roles)]
        roster.append(
            PlayerState(
                player_id=f"P{i + 1}",
                name=name,
                role=role,
                zone=zones_by_role[role],
            )
        )
    return roster
