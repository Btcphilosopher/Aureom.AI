"""
ai.event_ai
===========

Abstracted "raid AI" that decides high-level, symbolic actions for an
active incident, reacting to the estate's security-state model and to
player presence. It never generates or references real intrusion
technique, evasion, or weapon content — its vocabulary is limited to
the fictional game actions below.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId
from miami_estate.events.incidents import Incident


class RaidAction(str, Enum):
    APPROACH = "APPROACH"
    DISTRACT = "DISTRACT"
    EXPLOIT_OPENING = "EXPLOIT OPENING"
    CHANGE_ROUTE = "CHANGE ROUTE"
    RETREAT = "RETREAT"
    REGROUP = "REGROUP"
    HOLD = "HOLD"


@dataclass
class RaidActorState:
    incident_id: str
    zone: ZoneId
    momentum: float = 0.5  # 0-1, abstract "how committed" the event is
    last_action: RaidAction = RaidAction.APPROACH


@dataclass
class EventAI:
    """One decision-maker per active incident group, driven by zone state."""

    estate: Estate
    rng: random.Random = field(default_factory=random.Random)
    actors: Dict[str, RaidActorState] = field(default_factory=dict)

    def _actor_for(self, incident: Incident) -> RaidActorState:
        if incident.incident_id not in self.actors:
            self.actors[incident.incident_id] = RaidActorState(
                incident_id=incident.incident_id, zone=incident.zone
            )
        return self.actors[incident.incident_id]

    def decide(self, incident: Incident, responders_in_zone: int) -> RaidAction:
        """Pick the next symbolic action for this incident's actor.

        Rules (all abstract game logic, not real tactics):
          - unattended zones with low security -> the event presses forward
          - a zone that gains a responder -> the event tends to retreat or
            change route to an adjacent, weaker zone
          - a zone whose systems are already degraded -> the event exploits
            the opening (keeps pressure rather than moving on)
        """

        actor = self._actor_for(incident)
        zone = self.estate.zone(incident.zone)

        if responders_in_zone > 0:
            if zone.security_level > 40:
                action = RaidAction.RETREAT
                actor.momentum = max(0.1, actor.momentum - 0.25)
            else:
                action = RaidAction.CHANGE_ROUTE
                actor.momentum = max(0.2, actor.momentum - 0.1)
        elif zone.system_health < 60:
            action = RaidAction.EXPLOIT_OPENING
            actor.momentum = min(1.0, actor.momentum + 0.2)
        elif actor.momentum < 0.3:
            action = RaidAction.REGROUP
            actor.momentum = min(1.0, actor.momentum + 0.15)
        elif self.rng.random() < 0.2:
            action = RaidAction.DISTRACT
        else:
            action = RaidAction.APPROACH
            actor.momentum = min(1.0, actor.momentum + 0.1)

        actor.last_action = action
        return action

    def suggest_reroute_zone(self, incident: Incident) -> Optional[ZoneId]:
        """When an actor changes route, suggest a connected, weaker zone."""
        zone = self.estate.zone(incident.zone)
        candidates = [
            (nz, self.estate.zone(nz).security_level) for nz in zone.connected_zones
        ]
        if not candidates:
            return None
        candidates.sort(key=lambda pair: pair[1])
        return candidates[0][0]

    def summary(self) -> List[Dict[str, object]]:
        return [
            {
                "incident": a.incident_id,
                "zone": a.zone.value,
                "momentum": round(a.momentum, 2),
                "last_action": a.last_action.value,
            }
            for a in self.actors.values()
        ]
