"""Fictional game AI: abstracted raid-event behaviour, NPCs, autonomous response."""
