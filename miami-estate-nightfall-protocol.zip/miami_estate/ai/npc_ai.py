"""
ai.npc_ai
=========

Simple behaviour for non-player residents, guests and staff: they seek
safety when a zone alerts, and drift back to normal routines during
recovery. Purely cosmetic/systemic — no combat, no real behaviour model.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List

from miami_estate.core.state import AlertLevel
from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId


class NPCState(str, Enum):
    ROUTINE = "ROUTINE"
    SHELTERING = "SHELTERING"
    EVACUATED = "EVACUATED"


@dataclass
class NPC:
    name: str
    role: str  # RESIDENT / GUEST / STAFF
    zone: ZoneId
    state: NPCState = NPCState.ROUTINE


@dataclass
class NPCDirector:
    """Moves NPCs toward the security room when their zone alerts."""

    estate: Estate
    npcs: List[NPC]

    def tick(self) -> None:
        safe_zone = ZoneId.SECURITY_ROOM
        for npc in self.npcs:
            zone = self.estate.zone(npc.zone)
            if zone.alert_state in (AlertLevel.ALERT, AlertLevel.LOCKDOWN, AlertLevel.EMERGENCY):
                if npc.zone != safe_zone:
                    self.estate.place_person(npc.name, safe_zone)
                    npc.zone = safe_zone
                npc.state = (
                    NPCState.EVACUATED
                    if zone.alert_state == AlertLevel.EMERGENCY
                    else NPCState.SHELTERING
                )
            elif zone.alert_state == AlertLevel.RECOVERY:
                npc.state = NPCState.ROUTINE

    def all_safe(self) -> bool:
        return all(n.state != NPCState.EVACUATED or n.zone == ZoneId.SECURITY_ROOM for n in self.npcs)

    def snapshot(self) -> Dict[str, List[str]]:
        by_state: Dict[str, List[str]] = {}
        for npc in self.npcs:
            by_state.setdefault(npc.state.value, []).append(npc.name)
        return by_state
