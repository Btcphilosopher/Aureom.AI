"""
ai.response_ai
===============

Simplified autonomous response AI for fictional units (security drones,
inspection robots, autonomous cameras, robotic patrol units). It deploys
units toward alerting zones and, once on-station, contributes a modest
passive repair/coverage boost — never anything resembling a real
weapon or use-of-force system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from miami_estate.core.state import AlertLevel, DamageCategory
from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId


class UnitType(str, Enum):
    SECURITY_DRONE = "SECURITY DRONE"
    INSPECTION_ROBOT = "INSPECTION ROBOT"
    AUTONOMOUS_CAMERA = "AUTONOMOUS CAMERA"
    ROBOTIC_PATROL_UNIT = "ROBOTIC PATROL UNIT"


class UnitState(str, Enum):
    IDLE = "IDLE"
    DEPLOYING = "DEPLOYING"
    ON_STATION = "ON STATION"
    RETURNING = "RETURNING"
    CHARGING = "CHARGING"


@dataclass
class AutonomousUnit:
    unit_id: str
    unit_type: UnitType
    home_zone: ZoneId
    current_zone: ZoneId
    state: UnitState = UnitState.IDLE
    energy: float = 100.0
    coverage_bonus: float = 8.0
    repair_rate: float = 3.0

    def snapshot(self) -> Dict[str, object]:
        return {
            "unit": self.unit_id,
            "type": self.unit_type.value,
            "zone": self.current_zone.value,
            "state": self.state.value,
            "energy": round(self.energy, 1),
        }


@dataclass
class ResponseAI:
    """Assigns idle autonomous units toward the highest-alert zone."""

    estate: Estate
    units: List[AutonomousUnit] = field(default_factory=list)

    @classmethod
    def default_fleet(cls, estate: Estate) -> "ResponseAI":
        fleet = [
            AutonomousUnit("DRONE-01", UnitType.SECURITY_DRONE, ZoneId.SECURITY_ROOM, ZoneId.SECURITY_ROOM),
            AutonomousUnit("DRONE-02", UnitType.SECURITY_DRONE, ZoneId.SECURITY_ROOM, ZoneId.SECURITY_ROOM),
            AutonomousUnit("ROBOT-01", UnitType.INSPECTION_ROBOT, ZoneId.GARAGE, ZoneId.GARAGE),
            AutonomousUnit("PATROL-01", UnitType.ROBOTIC_PATROL_UNIT, ZoneId.GARDENS, ZoneId.GARDENS),
        ]
        return cls(estate=estate, units=fleet)

    def _priority_zones(self) -> List[ZoneId]:
        order = list(AlertLevel)
        zones = sorted(
            self.estate.zones.values(),
            key=lambda z: order.index(z.alert_state),
            reverse=True,
        )
        return [z.zone_id for z in zones if z.alert_state != AlertLevel.NORMAL]

    def tick(self) -> None:
        priority = self._priority_zones()
        idle_units = [u for u in self.units if u.state in (UnitState.IDLE, UnitState.ON_STATION)]
        for target_zone in priority:
            if not idle_units:
                break
            unit = min(idle_units, key=lambda u: 0 if u.current_zone == target_zone else 1)
            idle_units.remove(unit)
            if unit.current_zone != target_zone:
                unit.current_zone = target_zone
                unit.state = UnitState.DEPLOYING
                unit.energy = max(5.0, unit.energy - 5.0)
            else:
                unit.state = UnitState.ON_STATION
                self.estate.zone(target_zone).apply_damage(DamageCategory.SECURITY, -unit.repair_rate * 0.2)

        for unit in self.units:
            if unit.energy < 15 and unit.state != UnitState.CHARGING:
                unit.state = UnitState.CHARGING
                unit.current_zone = unit.home_zone
            elif unit.state == UnitState.CHARGING:
                unit.energy = min(100.0, unit.energy + 20.0)
                if unit.energy >= 100.0:
                    unit.state = UnitState.IDLE

    def units_in(self, zone: ZoneId) -> List[AutonomousUnit]:
        return [u for u in self.units if u.current_zone == zone and u.state == UnitState.ON_STATION]

    def snapshot(self) -> List[Dict[str, object]]:
        return [u.snapshot() for u in self.units]
