from miami_estate.events.raid_generator import RaidConfig, RaidGenerator


def test_raid_generation_is_deterministic_for_a_seed():
    config = RaidConfig(seed=42, difficulty=3, player_count=4, weather="STORM", phases=3)
    scenario_a = RaidGenerator(config).generate()
    scenario_b = RaidGenerator(config).generate()

    ids_a = [(i.incident_type, i.zone, i.severity, i.started_tick) for i in scenario_a.incidents]
    ids_b = [(i.incident_type, i.zone, i.severity, i.started_tick) for i in scenario_b.incidents]
    assert ids_a == ids_b


def test_higher_difficulty_adds_infrastructure_phase():
    low = RaidGenerator(RaidConfig(seed=1, difficulty=1, phases=3)).generate()
    high = RaidGenerator(RaidConfig(seed=1, difficulty=4, phases=3)).generate()
    assert len(high.incidents) >= len(low.incidents)


def test_scenario_reports_peak_simultaneous_incidents():
    config = RaidConfig(seed=5, difficulty=3, player_count=4, phases=3)
    scenario = RaidGenerator(config).generate()
    assert scenario.peak_simultaneous_incidents() >= 1
