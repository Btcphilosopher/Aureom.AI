from miami_estate.core.state import AlertLevel, DamageCategory
from miami_estate.estate.zones import ZoneId, default_zone_graph


def test_default_zone_graph_has_ten_zones():
    zones = default_zone_graph()
    assert len(zones) == 10
    assert ZoneId.SECURITY_ROOM in zones


def test_zone_damage_and_repair_round_trip():
    zones = default_zone_graph()
    zone = zones[ZoneId.GARAGE]
    zone.apply_damage(DamageCategory.STRUCTURAL, 20)
    assert zone.damage.total(DamageCategory.STRUCTURAL) == 20
    assert zone.system_health < 100
    zone.repair(DamageCategory.STRUCTURAL, 20)
    assert zone.damage.total(DamageCategory.STRUCTURAL) == 0


def test_zone_alert_escalation_only_increases_via_raise_alert():
    zones = default_zone_graph()
    zone = zones[ZoneId.MARINA]
    zone.raise_alert(AlertLevel.ALERT)
    zone.raise_alert(AlertLevel.MONITOR)  # should not downgrade
    assert zone.alert_state == AlertLevel.ALERT
    zone.clear_alert()
    assert zone.alert_state == AlertLevel.NORMAL
