from miami_estate.core.game_loop import GameLoop
from miami_estate.core.simulation import Simulation
from miami_estate.events.scenarios import MIAMI_NIGHTFALL, QUIET_NIGHT


def _run(preset, players):
    scenario = preset.build()
    simulation = Simulation.build(
        estate_name="Test Villa",
        address="Test Address",
        player_names=players,
        scenario=scenario,
    )
    loop = GameLoop(simulation=simulation, scenario_name=preset.name)
    return loop.run()


def test_quiet_night_resolves_without_destroying_estate():
    report = _run(QUIET_NIGHT, ["Solo"])
    assert report.damage_report["structural_integrity"] > 80
    assert report.ticks_run > 0


def test_miami_nightfall_runs_to_completion_and_reports():
    report = _run(MIAMI_NIGHTFALL, ["P1", "P2", "P3", "P4"])
    assert report.ticks_run > 0
    assert 0 <= report.performance_score <= 100
    assert "structural_integrity" in report.damage_report
    assert "security_score" in report.security_report
    assert "balance" in report.financial_report
    assert isinstance(report.victory, bool)


def test_simulation_is_deterministic_for_same_seed():
    report_a = _run(MIAMI_NIGHTFALL, ["P1", "P2", "P3", "P4"])
    report_b = _run(MIAMI_NIGHTFALL, ["P1", "P2", "P3", "P4"])
    assert report_a.damage_report == report_b.damage_report
    assert report_a.performance_score == report_b.performance_score


def test_reject_more_than_eight_players():
    from miami_estate.multiplayer.local_session import LocalSession
    import pytest

    with pytest.raises(ValueError):
        LocalSession.start("session-1", [f"P{i}" for i in range(9)])
