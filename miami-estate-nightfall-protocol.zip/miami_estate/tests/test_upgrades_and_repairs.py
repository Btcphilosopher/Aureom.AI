from miami_estate.core.state import DamageCategory
from miami_estate.economy.budget import Budget
from miami_estate.economy.repairs import RepairManager
from miami_estate.economy.upgrades import UpgradeTree
from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId


def test_upgrade_purchase_raises_zone_security():
    estate = Estate(name="Test Estate", address="Nowhere")
    budget = Budget(balance=1_000_000)
    tree = UpgradeTree(estate=estate, budget=budget)

    before = estate.zone(ZoneId.GARAGE).security_level
    assert tree.purchase("basic_cameras")
    after = estate.zone(ZoneId.GARAGE).security_level
    assert after >= before


def test_repair_job_completes_and_heals_zone():
    estate = Estate(name="Test Estate", address="Nowhere")
    budget = Budget(balance=100_000)
    repairs = RepairManager(estate=estate, budget=budget)

    zone = estate.zone(ZoneId.GARAGE)
    zone.apply_damage(DamageCategory.STRUCTURAL, 30)
    job = repairs.queue_repair(ZoneId.GARAGE, DamageCategory.STRUCTURAL, 30)
    assert job is not None

    for _ in range(20):
        repairs.tick()
        if job.completed:
            break

    assert job.completed
    assert zone.damage.total(DamageCategory.STRUCTURAL) == 0


def test_repair_rejected_when_insufficient_funds():
    estate = Estate(name="Test Estate", address="Nowhere")
    budget = Budget(balance=1)
    repairs = RepairManager(estate=estate, budget=budget)
    job = repairs.queue_repair(ZoneId.GARAGE, DamageCategory.STRUCTURAL, 30)
    assert job is None
