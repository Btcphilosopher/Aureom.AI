from miami_estate.estate.property import Estate
from miami_estate.infrastructure.smart_home import SmartHomeHub
from miami_estate.security.monitoring import MonitoringSystem


def test_power_failure_degrades_camera_network():
    estate = Estate(name="Test Estate", address="Nowhere")
    monitoring = MonitoringSystem.build(estate)
    hub = SmartHomeHub.build(estate, monitoring)

    before = monitoring.cameras.network_health()
    hub.power_failure(40)
    after = monitoring.cameras.network_health()

    assert hub.power.grid < 100
    assert after < before


def test_restore_power_recovers_camera_network():
    estate = Estate(name="Test Estate", address="Nowhere")
    monitoring = MonitoringSystem.build(estate)
    hub = SmartHomeHub.build(estate, monitoring)

    hub.power_failure(50)
    degraded = monitoring.cameras.network_health()
    hub.restore_power(50)
    restored = monitoring.cameras.network_health()

    assert restored > degraded
