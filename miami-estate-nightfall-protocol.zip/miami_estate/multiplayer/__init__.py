"""Local-first cooperative multiplayer session management (1-8 players, same process)."""
