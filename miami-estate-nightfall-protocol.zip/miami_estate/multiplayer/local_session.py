"""
multiplayer.local_session
===========================

A local-first cooperative session: 1-8 players sharing one simulation
instance and tick clock, no network transport. This is the seam where a
future networked transport could be added without touching game logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.players.cooperation import CooperationTracker
from miami_estate.players.player_state import PlayerState, default_roster


@dataclass
class LocalSession:
    session_id: str
    players: List[PlayerState] = field(default_factory=list)
    cooperation: CooperationTracker | None = None
    log: List[str] = field(default_factory=list)

    @classmethod
    def start(cls, session_id: str, player_names: List[str]) -> "LocalSession":
        if not (1 <= len(player_names) <= 8):
            raise ValueError("LocalSession supports 1-8 players.")
        return cls(session_id=session_id, players=default_roster(player_names))

    def broadcast(self, message: str) -> None:
        self.log.append(message)

    def player_by_name(self, name: str) -> PlayerState | None:
        return next((p for p in self.players if p.name == name), None)

    def roster(self) -> List[Dict[str, object]]:
        return [p.snapshot() for p in self.players]
