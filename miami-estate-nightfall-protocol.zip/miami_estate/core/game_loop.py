"""
core.game_loop
================

A thin, deterministic driver over `Simulation` + `SimulationEngine`. It
exists to give `main.py` (and any future front end — CLI, web, etc.) a
single call that steps the simulation, optionally narrates each tick,
and returns the final `NightReport`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional

from miami_estate.core.engine import NightReport, SimulationEngine
from miami_estate.core.simulation import Simulation, TickReport

Narrator = Callable[[Simulation, TickReport], None]


@dataclass
class GameLoop:
    simulation: Simulation
    scenario_name: str
    narrator: Optional[Narrator] = None

    def run(self) -> NightReport:
        engine = SimulationEngine(self.simulation, self.scenario_name)
        span = self._planned_span()
        for _ in range(span):
            report = self.simulation.step()
            if self.narrator:
                self.narrator(self.simulation, report)
        return engine._compile_report()  # noqa: SLF001 - engine + loop are one unit

    def _planned_span(self) -> int:
        incidents = self.simulation.scenario.incidents
        if not incidents:
            return 1
        last_end = max(i.started_tick + i.duration_ticks for i in incidents)
        return last_end + 4
