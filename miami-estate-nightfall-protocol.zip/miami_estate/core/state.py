"""
core.state
==========

Shared, fictional game-state vocabulary used across every subsystem.
Every "system" in the estate (a camera, a door, a power feed, a zone...)
reports its status using the enums below. Nothing here maps to any
real-world security product, protocol, or procedure.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict


class SystemStatus(str, Enum):
    """Generic operating status for any smart-estate subsystem."""

    ONLINE = "ONLINE"
    OFFLINE = "OFFLINE"
    DAMAGED = "DAMAGED"
    ALERT = "ALERT"
    LOCKED = "LOCKED"
    UNLOCKED = "UNLOCKED"
    DEGRADED = "DEGRADED"


class AlertLevel(str, Enum):
    """Zone / estate wide alert posture."""

    NORMAL = "NORMAL"
    MONITOR = "MONITOR"
    ALERT = "ALERT"
    LOCKDOWN = "LOCKDOWN"
    EMERGENCY = "EMERGENCY"
    RECOVERY = "RECOVERY"


class SecurityMode(str, Enum):
    """Estate-wide access-control mode, set by the Estate Manager."""

    DAY = "DAY"
    NIGHT = "NIGHT"
    PARTY = "PARTY"
    AWAY = "AWAY"
    ALERT = "ALERT"
    LOCKDOWN = "LOCKDOWN"


class DoorState(str, Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    LOCKED = "LOCKED"
    SECURED = "SECURED"
    DAMAGED = "DAMAGED"
    OVERRIDDEN = "OVERRIDDEN"


class DamageCategory(str, Enum):
    STRUCTURAL = "STRUCTURAL"
    ELECTRICAL = "ELECTRICAL"
    NETWORK = "NETWORK"
    SECURITY = "SECURITY"
    VEHICLE = "VEHICLE"
    DECORATIVE = "DECORATIVE"


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class DamageProfile:
    """Abstract, per-category damage accumulator, clamped to 0-100."""

    values: Dict[DamageCategory, float] = field(
        default_factory=lambda: {c: 0.0 for c in DamageCategory}
    )

    def apply(self, category: DamageCategory, amount: float) -> float:
        current = self.values.get(category, 0.0)
        updated = max(0.0, min(100.0, current + amount))
        self.values[category] = updated
        return updated

    def repair(self, category: DamageCategory, amount: float) -> float:
        return self.apply(category, -abs(amount))

    def total(self, category: DamageCategory) -> float:
        return self.values.get(category, 0.0)

    def integrity(self, category: DamageCategory) -> float:
        """Inverse of damage: 100 = pristine, 0 = destroyed."""
        return 100.0 - self.total(category)

    def overall_integrity(self) -> float:
        if not self.values:
            return 100.0
        return sum(100.0 - v for v in self.values.values()) / len(self.values)


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))
