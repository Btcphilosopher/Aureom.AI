"""
core.simulation
=================

`Simulation` is the single object that wires every subsystem to a shared
`Estate` and drives one deterministic tick at a time: incident
start/damage/resolution, autonomous + adversary AI decisions, NPC
safety routines, infrastructure cascades, lighting sync, repairs, and
cooperation scoring. `core.engine` and `core.game_loop` build on top of
this to run a full scenario and produce end-of-night reports.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from miami_estate.ai.event_ai import EventAI, RaidAction
from miami_estate.ai.npc_ai import NPC, NPCDirector
from miami_estate.ai.response_ai import ResponseAI
from miami_estate.core.state import AlertLevel, DamageCategory, Severity
from miami_estate.economy.budget import Budget
from miami_estate.economy.repairs import RepairManager
from miami_estate.economy.upgrades import UpgradeTree
from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId, default_zone_graph
from miami_estate.events.incidents import Incident, IncidentType
from miami_estate.events.raid_generator import RaidScenario
from miami_estate.infrastructure.smart_home import SmartHomeHub
from miami_estate.players.cooperation import CooperationTracker
from miami_estate.players.player_state import PlayerState, default_roster
from miami_estate.security.monitoring import MonitoringSystem
from miami_estate.vehicles.garage import FleetManager

_SEVERITY_TO_ALERT = {
    Severity.LOW: AlertLevel.MONITOR,
    Severity.MEDIUM: AlertLevel.ALERT,
    Severity.HIGH: AlertLevel.LOCKDOWN,
    Severity.CRITICAL: AlertLevel.EMERGENCY,
}
RECOVERY_TICKS = 2
MAX_REROUTE_SPAWNS = 2


@dataclass
class TickReport:
    tick: int
    started: List[str] = field(default_factory=list)
    resolved: List[str] = field(default_factory=list)
    neutralized: List[str] = field(default_factory=list)
    active_alert_zones: List[str] = field(default_factory=list)
    emergency_mode: bool = False


@dataclass
class Simulation:
    estate: Estate
    monitoring: MonitoringSystem
    hub: SmartHomeHub
    scenario: RaidScenario
    event_ai: EventAI
    response_ai: ResponseAI
    npc_director: NPCDirector
    budget: Budget
    repairs: RepairManager
    upgrades: UpgradeTree
    fleet: FleetManager
    players: List[PlayerState]
    cooperation: CooperationTracker
    tick: int = 0
    start_hour: int = 23
    start_minute: int = 47
    emergency_mode: bool = False
    _recovery_countdown: Dict[ZoneId, int] = field(default_factory=dict)
    _reroute_spawns: int = 0
    _dynamic_incidents: List[Incident] = field(default_factory=list)
    _reroute_used: Dict[str, bool] = field(default_factory=dict)
    tick_reports: List[TickReport] = field(default_factory=list)

    @classmethod
    def build(
        cls,
        estate_name: str,
        address: str,
        player_names: List[str],
        scenario: RaidScenario,
        residents: Optional[List[str]] = None,
        guests: Optional[List[str]] = None,
        staff: Optional[List[str]] = None,
    ) -> "Simulation":
        estate = Estate(name=estate_name, address=address, zones=default_zone_graph())
        estate.residents = residents or ["Owner"]
        estate.guests = guests or []
        estate.staff = staff or ["Housekeeper", "Dockmaster"]
        for person in estate.residents:
            estate.place_person(person, ZoneId.MAIN_HOUSE)
        for person in estate.guests:
            estate.place_person(person, ZoneId.POOL)
        for person in estate.staff:
            estate.place_person(person, ZoneId.SERVICE_AREA)

        monitoring = MonitoringSystem.build(estate)
        hub = SmartHomeHub.build(estate, monitoring)
        budget = Budget()
        repairs = RepairManager(estate=estate, budget=budget)
        upgrades = UpgradeTree(estate=estate, budget=budget)
        fleet = FleetManager(garage=estate.garage)
        fleet.sync_to_garage()

        players = default_roster(player_names)
        cooperation = CooperationTracker(estate=estate, players=players)

        npcs = [NPC(name=p, role="RESIDENT", zone=ZoneId.MAIN_HOUSE) for p in estate.residents]
        npcs += [NPC(name=g, role="GUEST", zone=ZoneId.POOL) for g in estate.guests]
        npcs += [NPC(name=s, role="STAFF", zone=ZoneId.SERVICE_AREA) for s in estate.staff]
        npc_director = NPCDirector(estate=estate, npcs=npcs)

        event_ai = EventAI(estate=estate, rng=random.Random(scenario.config.seed))
        response_ai = ResponseAI.default_fleet(estate)

        return cls(
            estate=estate,
            monitoring=monitoring,
            hub=hub,
            scenario=scenario,
            event_ai=event_ai,
            response_ai=response_ai,
            npc_director=npc_director,
            budget=budget,
            repairs=repairs,
            upgrades=upgrades,
            fleet=fleet,
            players=players,
            cooperation=cooperation,
            start_hour=scenario.config.hour,
        )

    # -- clock -----------------------------------------------------------

    def clock_label(self) -> str:
        total_minutes = self.start_minute + self.tick * 3
        hour = (self.start_hour + total_minutes // 60) % 24
        minute = total_minutes % 60
        return f"{hour:02d}:{minute:02d}"

    # -- incident lifecycle ------------------------------------------------

    def _all_incidents(self) -> List[Incident]:
        return self.scenario.incidents + self._dynamic_incidents

    def responders_in_zone(self, zone: ZoneId) -> int:
        return sum(1 for p in self.players if p.zone == zone)

    def _apply_incident_tick_damage(self, incident: Incident) -> None:
        per_tick = {
            cat: amount / incident.duration_ticks
            for cat, amount in incident.damage_template().items()
        }
        zone = self.estate.zone(incident.zone)
        for category, amount in per_tick.items():
            zone.apply_damage(category, amount)

        if incident.incident_type == IncidentType.POWER_FAILURE:
            self.hub.power_failure(6.0 / incident.duration_ticks)
        elif incident.incident_type == IncidentType.COMMUNICATION_FAILURE:
            self.hub.network.degrade(6.0 / incident.duration_ticks)
        else:
            self.monitoring.cameras.degrade_zone(incident.zone, 1.5 / incident.duration_ticks)

    def _start_incident(self, incident: Incident, report: TickReport) -> None:
        level = _SEVERITY_TO_ALERT[incident.severity]
        self.monitoring.raise_zone_alert(
            incident.zone, incident.incident_type.value, incident.severity, self.tick, level
        )
        report.started.append(incident.incident_id)

    def _resolve_zone_if_clear(self, zone_id: ZoneId) -> None:
        still_active = any(
            i.is_active(self.tick) for i in self._all_incidents() if i.zone == zone_id
        )
        if still_active:
            return
        zone = self.estate.zone(zone_id)
        if zone.alert_state == AlertLevel.NORMAL:
            return
        countdown = self._recovery_countdown.get(zone_id, RECOVERY_TICKS)
        if zone.alert_state != AlertLevel.RECOVERY:
            zone.alert_state = AlertLevel.RECOVERY
            self._recovery_countdown[zone_id] = RECOVERY_TICKS
            return
        countdown -= 1
        self._recovery_countdown[zone_id] = countdown
        if countdown <= 0:
            zone.clear_alert()
            for alarm in self.monitoring.alarms.active_by_zone(zone_id):
                self.monitoring.alarms.clear(alarm.alarm_id)

    def _run_event_ai(self, incident: Incident, report: TickReport) -> None:
        responders = self.responders_in_zone(incident.zone)
        action = self.event_ai.decide(incident, responders)
        if action == RaidAction.RETREAT and self.event_ai.actors[incident.incident_id].momentum <= 0.15:
            incident.resolved = True
            report.neutralized.append(incident.incident_id)
            return
        if (
            action == RaidAction.CHANGE_ROUTE
            and not self._reroute_used.get(incident.incident_id, False)
            and self._reroute_spawns < MAX_REROUTE_SPAWNS
        ):
            target = self.event_ai.suggest_reroute_zone(incident)
            self._reroute_used[incident.incident_id] = True
            if target is not None:
                self._reroute_spawns += 1
                new_incident = Incident(
                    incident_id=f"{incident.incident_id}-R{self._reroute_spawns}",
                    incident_type=incident.incident_type,
                    zone=target,
                    severity=incident.severity,
                    started_tick=self.tick + 1,
                    duration_ticks=3,
                    affected_systems=list(incident.affected_systems),
                )
                self._dynamic_incidents.append(new_incident)

    # -- main loop step ----------------------------------------------------

    def step(self) -> TickReport:
        report = TickReport(tick=self.tick)

        for incident in self._all_incidents():
            if incident.started_tick == self.tick and not incident.resolved:
                self._start_incident(incident, report)

        active = [i for i in self._all_incidents() if i.is_active(self.tick)]
        for incident in active:
            self._apply_incident_tick_damage(incident)
            self._run_event_ai(incident, report)

        for incident in self._all_incidents():
            if incident.started_tick + incident.duration_ticks - 1 == self.tick and not incident.resolved:
                incident.resolved = True
                report.resolved.append(incident.incident_id)

        touched_zones = {i.zone for i in self._all_incidents()}
        for zone_id in touched_zones:
            self._resolve_zone_if_clear(zone_id)

        self.npc_director.tick()
        self.response_ai.tick()
        self.hub.sync_lighting()
        self.repairs.tick()
        self.cooperation.sample_tick()

        alerted_zones = [
            z.zone_id.value
            for z in self.estate.zones.values()
            if z.alert_state != AlertLevel.NORMAL
        ]
        report.active_alert_zones = alerted_zones
        self.emergency_mode = len(alerted_zones) >= 3
        report.emergency_mode = self.emergency_mode

        self.tick_reports.append(report)
        self.tick += 1
        return report

    def run_scenario(self) -> None:
        span = max(
            (i.started_tick + i.duration_ticks for i in self.scenario.incidents),
            default=1,
        )
        # A couple of extra recovery ticks after the last scripted incident.
        for _ in range(span + RECOVERY_TICKS + 2):
            self.step()
