"""Core simulation primitives: shared state model, engine and game loop."""
