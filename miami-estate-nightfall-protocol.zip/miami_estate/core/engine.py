"""
core.engine
============

`SimulationEngine` runs a `Simulation` to completion and compiles the
end-of-night reports: damage, security, financial, repair, and the
overall performance score used to evaluate victory conditions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from miami_estate.core.simulation import Simulation
from miami_estate.core.state import DamageCategory

# Victory thresholds — abstract game balance numbers, not a claim about
# real-world security effectiveness.
MIN_STRUCTURAL_INTEGRITY = 55.0
MIN_SECURITY_SCORE = 50.0
MIN_RESIDENT_SAFETY = 1.0  # fraction of NPCs kept out of a lost state


@dataclass
class NightReport:
    scenario_name: str
    ticks_run: int
    damage_report: Dict[str, object]
    security_report: Dict[str, object]
    financial_report: Dict[str, object]
    repair_report: Dict[str, object]
    coordination_score: float
    performance_score: float
    victory: bool
    victory_reasons: List[str]


class SimulationEngine:
    def __init__(self, simulation: Simulation, scenario_name: str):
        self.simulation = simulation
        self.scenario_name = scenario_name

    def run(self) -> NightReport:
        self.simulation.run_scenario()
        return self._compile_report()

    # -- report sections -----------------------------------------------

    def _damage_report(self) -> Dict[str, object]:
        per_zone = {}
        for zone in self.simulation.estate.zones.values():
            per_zone[zone.zone_id.value] = {
                cat.value: round(zone.damage.total(cat), 1) for cat in DamageCategory
            }
        return {
            "structural_integrity": self.simulation.estate.overall_structural_integrity(),
            "by_zone": per_zone,
            "marina_integrity": round(self.simulation.estate.marina.integrity, 1),
            "garage_integrity": round(self.simulation.estate.garage.integrity, 1),
        }

    def _security_report(self) -> Dict[str, object]:
        return {
            "security_score": self.simulation.monitoring.security_score(),
            "camera_network_health": self.simulation.monitoring.cameras.network_health(),
            "estate_status_board": self.simulation.hub.estate_status_board(),
            "alarms_raised": len(self.simulation.monitoring.alarms.records),
            "alarms_still_active": len(self.simulation.monitoring.alarms.active()),
            "incidents_neutralized": sum(
                len(r.neutralized) for r in self.simulation.tick_reports
            ),
        }

    def _financial_report(self) -> Dict[str, object]:
        return self.simulation.budget.net_worth_report()

    def _repair_report(self) -> Dict[str, object]:
        return self.simulation.repairs.snapshot()

    def _response_time_score(self) -> float:
        """Average ticks between an alert starting and a responder reaching it."""
        # Approximated from cooperation coverage as a stand-in "response speed" proxy.
        return self.simulation.cooperation.coordination_score()

    def _performance_score(self, damage: Dict[str, object], security: Dict[str, object]) -> float:
        structural = damage["structural_integrity"]
        sec = security["security_score"]
        coordination = self.simulation.cooperation.coordination_score()
        energy_efficiency = self.simulation.hub.power.overall_output()
        repair_efficiency = 100.0 if not self.simulation.repairs.jobs else round(
            100
            * sum(1 for j in self.simulation.repairs.jobs if j.completed)
            / len(self.simulation.repairs.jobs),
            1,
        )
        weights = {
            "structural": 0.25,
            "security": 0.2,
            "coordination": 0.2,
            "energy": 0.15,
            "repair": 0.2,
        }
        score = (
            structural * weights["structural"]
            + sec * weights["security"]
            + coordination * weights["coordination"]
            + energy_efficiency * weights["energy"]
            + repair_efficiency * weights["repair"]
        )
        return round(score, 1)

    def _victory_check(self, damage: Dict[str, object], security: Dict[str, object]) -> tuple[bool, List[str]]:
        reasons = []
        ok = True
        if damage["structural_integrity"] < MIN_STRUCTURAL_INTEGRITY:
            ok = False
            reasons.append(
                f"Structural integrity {damage['structural_integrity']}% below "
                f"required {MIN_STRUCTURAL_INTEGRITY}%."
            )
        if security["security_score"] < MIN_SECURITY_SCORE:
            ok = False
            reasons.append(
                f"Security score {security['security_score']}% below required "
                f"{MIN_SECURITY_SCORE}%."
            )
        if not self.simulation.npc_director.all_safe():
            ok = False
            reasons.append("One or more residents/guests/staff were not kept safe.")
        if ok:
            reasons.append("Residents protected, estate integrity and systems held.")
        return ok, reasons

    def _compile_report(self) -> NightReport:
        damage = self._damage_report()
        security = self._security_report()
        financial = self._financial_report()
        repair = self._repair_report()
        victory, reasons = self._victory_check(damage, security)
        return NightReport(
            scenario_name=self.scenario_name,
            ticks_run=self.simulation.tick,
            damage_report=damage,
            security_report=security,
            financial_report=financial,
            repair_report=repair,
            coordination_score=self.simulation.cooperation.coordination_score(),
            performance_score=self._performance_score(damage, security),
            victory=victory,
            victory_reasons=reasons,
        )
