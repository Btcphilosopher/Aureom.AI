"""The physical, fictional Miami waterfront estate: zones, rooms, marina, garage."""
