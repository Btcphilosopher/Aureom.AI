"""
estate.garage
=============

The underground garage as an estate *system* (bay states, door,
capacity). Vehicle objects themselves live in `vehicles/`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from miami_estate.core.state import DoorState, clamp


@dataclass
class GarageBay:
    bay_id: str
    vehicle: Optional[str] = None


@dataclass
class Garage:
    door: DoorState = DoorState.CLOSED
    bays: List[GarageBay] = field(default_factory=list)
    guest_parking_spaces: int = 6
    guest_parking_used: int = 0
    integrity: float = 100.0

    @classmethod
    def default(cls, bay_count: int = 6) -> "Garage":
        return cls(bays=[GarageBay(f"BAY-{i:02d}") for i in range(1, bay_count + 1)])

    def park(self, bay_id: str, vehicle_name: str) -> bool:
        for bay in self.bays:
            if bay.bay_id == bay_id and bay.vehicle is None:
                bay.vehicle = vehicle_name
                return True
        return False

    def release(self, bay_id: str) -> bool:
        for bay in self.bays:
            if bay.bay_id == bay_id:
                bay.vehicle = None
                return True
        return False

    def free_bays(self) -> int:
        return sum(1 for b in self.bays if b.vehicle is None)

    def apply_breach(self, severity_factor: float) -> None:
        self.integrity = clamp(self.integrity - 20 * severity_factor)
        if self.integrity < 50:
            self.door = DoorState.DAMAGED

    def repair(self, amount: float) -> None:
        self.integrity = clamp(self.integrity + amount)
        if self.integrity > 40 and self.door == DoorState.DAMAGED:
            self.door = DoorState.CLOSED

    def snapshot(self) -> Dict[str, object]:
        return {
            "door": self.door.value,
            "integrity": round(self.integrity, 1),
            "free_bays": self.free_bays(),
            "total_bays": len(self.bays),
            "guest_parking": f"{self.guest_parking_used}/{self.guest_parking_spaces}",
        }
