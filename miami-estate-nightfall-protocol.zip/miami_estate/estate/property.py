"""
estate.property
================

`Estate` is the top-level fictional property object: the ten zones, the
marina, the garage, and the roster of people currently on the grounds.
Every other subsystem (security, infrastructure, economy...) attaches to
an Estate instance.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.core.state import DamageCategory
from miami_estate.estate.garage import Garage
from miami_estate.estate.marina import Marina
from miami_estate.estate.rooms import build_room_directory
from miami_estate.estate.zones import Zone, ZoneId, default_zone_graph


@dataclass
class Estate:
    name: str
    address: str
    zones: Dict[ZoneId, Zone] = field(default_factory=default_zone_graph)
    marina: Marina = field(default_factory=Marina.default)
    garage: Garage = field(default_factory=Garage.default)
    residents: List[str] = field(default_factory=list)
    guests: List[str] = field(default_factory=list)
    staff: List[str] = field(default_factory=list)
    tier: int = 1

    def __post_init__(self) -> None:
        self.rooms = build_room_directory()

    def zone(self, zone_id: ZoneId) -> Zone:
        return self.zones[zone_id]

    def place_person(self, person: str, zone_id: ZoneId) -> None:
        for z in self.zones.values():
            if person in z.occupancy:
                z.occupancy.remove(person)
        self.zone(zone_id).occupancy.append(person)

    def overall_structural_integrity(self) -> float:
        totals = [
            z.damage.integrity(DamageCategory.STRUCTURAL) for z in self.zones.values()
        ]
        return round(sum(totals) / len(totals), 1) if totals else 100.0

    def overall_security_level(self) -> float:
        levels = [z.security_level for z in self.zones.values()]
        return round(sum(levels) / len(levels), 1) if levels else 100.0

    def zone_status_board(self) -> List[Dict[str, object]]:
        return [z.snapshot() for z in self.zones.values()]

    def population(self) -> int:
        return len(self.residents) + len(self.guests) + len(self.staff)
