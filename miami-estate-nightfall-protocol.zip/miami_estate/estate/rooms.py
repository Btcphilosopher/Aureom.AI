"""
estate.rooms
============

Fine-grained interior/exterior rooms that flesh out each zone for the
digital-twin map and flavour text. Rooms are cosmetic/organisational —
gameplay state lives on the owning Zone.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from miami_estate.estate.zones import ZoneId

MAIN_RESIDENCE_ROOMS: List[str] = [
    "Entrance Hall",
    "Living Room",
    "Dining Room",
    "Kitchen",
    "Primary Bedroom",
    "Guest Bedrooms",
    "Home Office",
    "Entertainment Room",
    "Security Room",
    "Underground Garage",
    "Service Areas",
]

EXTERIOR_FEATURES: List[str] = [
    "Tropical Gardens",
    "Swimming Pool",
    "Pool House",
    "Outdoor Entertainment Area",
    "Tennis / Padel Court",
    "Driveway",
    "Perimeter Landscaping",
]

WATERFRONT_FEATURES: List[str] = [
    "Private Marina",
    "Yacht Dock",
    "Boat House",
    "Waterfront Terrace",
    "Service Dock",
]

VEHICLE_FEATURES: List[str] = [
    "Underground Garage",
    "Luxury-Car Storage",
    "Guest Parking",
    "Service Entrance",
]


@dataclass(frozen=True)
class Room:
    name: str
    zone: ZoneId
    category: str  # RESIDENCE / EXTERIOR / WATERFRONT / VEHICLE


def build_room_directory() -> Dict[str, Room]:
    """Maps every named room/feature onto its owning zone."""

    layout = {
        ZoneId.MAIN_HOUSE: [
            "Entrance Hall",
            "Living Room",
            "Dining Room",
            "Kitchen",
        ],
        ZoneId.WEST_WING: ["Guest Bedrooms", "Home Office"],
        ZoneId.EAST_WING: ["Primary Bedroom", "Entertainment Room"],
        ZoneId.SECURITY_ROOM: ["Security Room"],
        ZoneId.GARAGE: ["Underground Garage", "Luxury-Car Storage", "Guest Parking"],
        ZoneId.SERVICE_AREA: ["Service Areas", "Service Entrance"],
        ZoneId.GARDENS: [
            "Tropical Gardens",
            "Perimeter Landscaping",
            "Tennis / Padel Court",
            "Driveway",
        ],
        ZoneId.POOL: ["Swimming Pool", "Pool House", "Outdoor Entertainment Area"],
        ZoneId.MARINA: [
            "Private Marina",
            "Yacht Dock",
            "Boat House",
            "Waterfront Terrace",
            "Service Dock",
        ],
        ZoneId.FRONT_ENTRANCE: ["Driveway", "Perimeter Landscaping"],
    }

    def category_of(name: str) -> str:
        if name in MAIN_RESIDENCE_ROOMS:
            return "RESIDENCE"
        if name in WATERFRONT_FEATURES:
            return "WATERFRONT"
        if name in VEHICLE_FEATURES:
            return "VEHICLE"
        return "EXTERIOR"

    directory: Dict[str, Room] = {}
    for zone, rooms in layout.items():
        for name in rooms:
            directory[name] = Room(name=name, zone=zone, category=category_of(name))
    return directory
