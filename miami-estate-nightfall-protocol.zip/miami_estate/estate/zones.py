"""
estate.zones
============

The property is partitioned into ten fictional zones. Each zone carries
its own security posture, occupancy, system health and camera coverage,
and is the unit that raid events, player assignments, and repairs all
operate on.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List

from miami_estate.core.state import AlertLevel, DamageCategory, DamageProfile, clamp


class ZoneId(str, Enum):
    FRONT_ENTRANCE = "ZONE 01 — FRONT ENTRANCE"
    MAIN_HOUSE = "ZONE 02 — MAIN HOUSE"
    WEST_WING = "ZONE 03 — WEST WING"
    EAST_WING = "ZONE 04 — EAST WING"
    GARAGE = "ZONE 05 — GARAGE"
    GARDENS = "ZONE 06 — GARDENS"
    POOL = "ZONE 07 — POOL"
    MARINA = "ZONE 08 — MARINA"
    SERVICE_AREA = "ZONE 09 — SERVICE AREA"
    SECURITY_ROOM = "ZONE 10 — SECURITY ROOM"


@dataclass
class Zone:
    """A single fictional estate zone and its live simulation state."""

    zone_id: ZoneId
    description: str
    security_level: float = 90.0          # 0-100, higher = better hardened
    occupancy: List[str] = field(default_factory=list)
    camera_coverage: float = 90.0          # 0-100, % of zone under camera view
    access_state: str = "NORMAL"           # NORMAL / RESTRICTED / SECURED / OVERRIDDEN
    alert_state: AlertLevel = AlertLevel.NORMAL
    damage: DamageProfile = field(default_factory=DamageProfile)
    connected_zones: List[ZoneId] = field(default_factory=list)

    @property
    def system_health(self) -> float:
        return round(self.damage.overall_integrity(), 1)

    def raise_alert(self, level: AlertLevel) -> None:
        order = list(AlertLevel)
        if order.index(level) > order.index(self.alert_state):
            self.alert_state = level

    def clear_alert(self) -> None:
        self.alert_state = AlertLevel.NORMAL

    def apply_damage(self, category: DamageCategory, amount: float) -> None:
        self.damage.apply(category, amount)
        self.security_level = clamp(self.security_level - amount * 0.35)
        if category in (DamageCategory.SECURITY, DamageCategory.ELECTRICAL):
            self.camera_coverage = clamp(self.camera_coverage - amount * 0.4)

    def repair(self, category: DamageCategory, amount: float) -> None:
        self.damage.repair(category, amount)
        self.security_level = clamp(self.security_level + amount * 0.2)
        self.camera_coverage = clamp(self.camera_coverage + amount * 0.15)

    def snapshot(self) -> Dict[str, object]:
        return {
            "zone": self.zone_id.value,
            "security_level": round(self.security_level, 1),
            "occupancy": list(self.occupancy),
            "camera_coverage": round(self.camera_coverage, 1),
            "access_state": self.access_state,
            "alert_state": self.alert_state.value,
            "system_health": self.system_health,
        }


def default_zone_graph() -> Dict[ZoneId, Zone]:
    """Builds the ten standard estate zones with plausible adjacency."""

    zones: Dict[ZoneId, Zone] = {
        ZoneId.FRONT_ENTRANCE: Zone(
            ZoneId.FRONT_ENTRANCE,
            "Gated motor court, limestone archway, primary vehicle approach.",
        ),
        ZoneId.MAIN_HOUSE: Zone(
            ZoneId.MAIN_HOUSE,
            "Entrance hall, living/dining rooms, kitchen, family quarters.",
        ),
        ZoneId.WEST_WING: Zone(
            ZoneId.WEST_WING, "Guest bedrooms, home office, private study."
        ),
        ZoneId.EAST_WING: Zone(
            ZoneId.EAST_WING, "Primary suite, entertainment room, security room access."
        ),
        ZoneId.GARAGE: Zone(
            ZoneId.GARAGE, "Underground garage, luxury-car storage, service entrance."
        ),
        ZoneId.GARDENS: Zone(
            ZoneId.GARDENS, "Tropical gardens, perimeter landscaping, padel court."
        ),
        ZoneId.POOL: Zone(
            ZoneId.POOL, "Swimming pool, pool house, outdoor entertainment deck."
        ),
        ZoneId.MARINA: Zone(
            ZoneId.MARINA, "Private marina, yacht dock, boat house, service dock."
        ),
        ZoneId.SERVICE_AREA: Zone(
            ZoneId.SERVICE_AREA, "Staff areas, utility plant, deliveries."
        ),
        ZoneId.SECURITY_ROOM: Zone(
            ZoneId.SECURITY_ROOM,
            "Command center: camera grid, alarms, access control, comms.",
            security_level=98.0,
            camera_coverage=100.0,
        ),
    }

    adjacency = {
        ZoneId.FRONT_ENTRANCE: [ZoneId.MAIN_HOUSE, ZoneId.GARAGE, ZoneId.GARDENS],
        ZoneId.MAIN_HOUSE: [
            ZoneId.FRONT_ENTRANCE,
            ZoneId.WEST_WING,
            ZoneId.EAST_WING,
            ZoneId.POOL,
            ZoneId.SECURITY_ROOM,
        ],
        ZoneId.WEST_WING: [ZoneId.MAIN_HOUSE, ZoneId.GARDENS],
        ZoneId.EAST_WING: [ZoneId.MAIN_HOUSE, ZoneId.SECURITY_ROOM],
        ZoneId.GARAGE: [ZoneId.FRONT_ENTRANCE, ZoneId.SERVICE_AREA],
        ZoneId.GARDENS: [ZoneId.FRONT_ENTRANCE, ZoneId.WEST_WING, ZoneId.POOL],
        ZoneId.POOL: [ZoneId.MAIN_HOUSE, ZoneId.GARDENS, ZoneId.MARINA],
        ZoneId.MARINA: [ZoneId.POOL, ZoneId.SERVICE_AREA],
        ZoneId.SERVICE_AREA: [ZoneId.GARAGE, ZoneId.MARINA],
        ZoneId.SECURITY_ROOM: [ZoneId.MAIN_HOUSE, ZoneId.EAST_WING],
    }
    for zid, neighbours in adjacency.items():
        zones[zid].connected_zones = neighbours

    return zones
