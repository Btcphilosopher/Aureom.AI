"""
estate.marina
=============

The waterfront gameplay system: dock, boats, water access, marina
lighting/cameras/gates. Purely a fictional game system — no real marina
security procedures are modelled.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.core.state import DoorState, SystemStatus, clamp


@dataclass
class DockSlip:
    slip_id: str
    occupied_by: str | None = None
    lighting: SystemStatus = SystemStatus.ONLINE
    camera: SystemStatus = SystemStatus.ONLINE


@dataclass
class Marina:
    """Waterfront systems: dock slips, service dock, water-side gate."""

    slips: List[DockSlip] = field(default_factory=list)
    water_gate: DoorState = DoorState.LOCKED
    service_access: DoorState = DoorState.SECURED
    water_visibility: float = 95.0  # 0-100, affected by weather/night/fog
    integrity: float = 100.0

    @classmethod
    def default(cls) -> "Marina":
        return cls(slips=[DockSlip(f"SLIP-{i:02d}") for i in range(1, 5)])

    def dock(self, slip_id: str, vessel_name: str) -> bool:
        for slip in self.slips:
            if slip.slip_id == slip_id and slip.occupied_by is None:
                slip.occupied_by = vessel_name
                return True
        return False

    def release(self, slip_id: str) -> bool:
        for slip in self.slips:
            if slip.slip_id == slip_id:
                slip.occupied_by = None
                return True
        return False

    def apply_water_intrusion(self, severity_factor: float) -> None:
        self.integrity = clamp(self.integrity - 15 * severity_factor)
        self.water_visibility = clamp(self.water_visibility - 20 * severity_factor)
        for slip in self.slips:
            if slip.occupied_by:
                slip.camera = SystemStatus.DEGRADED

    def repair(self, amount: float) -> None:
        self.integrity = clamp(self.integrity + amount)
        self.water_visibility = clamp(self.water_visibility + amount * 0.5)
        for slip in self.slips:
            if slip.camera != SystemStatus.ONLINE:
                slip.camera = SystemStatus.ONLINE

    def snapshot(self) -> Dict[str, object]:
        return {
            "integrity": round(self.integrity, 1),
            "water_visibility": round(self.water_visibility, 1),
            "water_gate": self.water_gate.value,
            "service_access": self.service_access.value,
            "slips": [
                {
                    "slip": s.slip_id,
                    "occupied_by": s.occupied_by,
                    "camera": s.camera.value,
                }
                for s in self.slips
            ],
        }
