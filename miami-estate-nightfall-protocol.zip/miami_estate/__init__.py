"""
MIAMI ESTATE: NIGHTFALL PROTOCOL
=================================

A fully fictional, modular cooperative luxury-estate security and raid
simulation game engine set in a hypermodern Miami waterfront property.

This package is a game simulation. Nothing in it models, teaches, or
enables real-world security bypass, weapons, or surveillance deployment.
All "raid", "threat", "damage" and "security" mechanics are abstracted
game systems operating on fictional numeric state.
"""

__version__ = "1.0.0"
__title__ = "Miami Estate: Nightfall Protocol"
