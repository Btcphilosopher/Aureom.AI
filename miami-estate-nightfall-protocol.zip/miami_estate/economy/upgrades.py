"""
economy.upgrades
==================

The four-tier estate upgrade tree. Purchasing every upgrade in a tier
unlocks the next tier and raises baseline zone security/camera coverage
across the property.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.economy.budget import Budget
from miami_estate.estate.property import Estate


@dataclass(frozen=True)
class Upgrade:
    key: str
    name: str
    tier: int
    cost: float
    security_bonus: float
    coverage_bonus: float


UPGRADE_TREE: List[Upgrade] = [
    # Tier 1
    Upgrade("basic_cameras", "Basic Cameras", 1, 15_000, 2, 5),
    Upgrade("smart_locks", "Smart Locks", 1, 12_000, 3, 0),
    Upgrade("motion_sensors", "Motion Sensors", 1, 10_000, 2, 2),
    Upgrade("basic_command_room", "Basic Command Room", 1, 20_000, 3, 3),
    # Tier 2
    Upgrade("integrated_surveillance", "Integrated Surveillance", 2, 40_000, 4, 10),
    Upgrade("automated_lighting", "Automated Lighting", 2, 18_000, 1, 2),
    Upgrade("advanced_access_control", "Advanced Access Control", 2, 35_000, 5, 0),
    Upgrade("backup_power", "Backup Power", 2, 30_000, 2, 3),
    # Tier 3
    Upgrade("ai_monitoring", "AI-Assisted Monitoring", 3, 80_000, 6, 12),
    Upgrade("autonomous_inspection", "Autonomous Inspection Systems", 3, 70_000, 4, 6),
    Upgrade("digital_twin", "Advanced Digital Twin", 3, 90_000, 3, 8),
    Upgrade("smart_infrastructure", "Smart Infrastructure", 3, 75_000, 4, 4),
    # Tier 4
    Upgrade("full_smart_estate", "Fully Integrated Miami Smart Estate", 4, 250_000, 15, 20),
]


@dataclass
class UpgradeTree:
    estate: Estate
    budget: Budget
    purchased: List[str] = field(default_factory=list)
    unlocked_tier: int = 1

    def available(self) -> List[Upgrade]:
        return [
            u
            for u in UPGRADE_TREE
            if u.tier <= self.unlocked_tier and u.key not in self.purchased
        ]

    def purchase(self, key: str) -> bool:
        upgrade = next((u for u in UPGRADE_TREE if u.key == key), None)
        if not upgrade or upgrade.key in self.purchased:
            return False
        if upgrade.tier > self.unlocked_tier:
            return False
        if not self.budget.expense(f"Upgrade: {upgrade.name}", upgrade.cost, "UPGRADES"):
            return False
        self.purchased.append(upgrade.key)
        for zone in self.estate.zones.values():
            zone.security_level = min(100.0, zone.security_level + upgrade.security_bonus)
            zone.camera_coverage = min(100.0, zone.camera_coverage + upgrade.coverage_bonus)
        self._maybe_unlock_next_tier()
        return True

    def _maybe_unlock_next_tier(self) -> None:
        current_tier_keys = {u.key for u in UPGRADE_TREE if u.tier == self.unlocked_tier}
        if current_tier_keys.issubset(set(self.purchased)) and self.unlocked_tier < 4:
            self.unlocked_tier += 1
            self.estate.tier = self.unlocked_tier

    def snapshot(self) -> Dict[str, object]:
        return {
            "unlocked_tier": self.unlocked_tier,
            "purchased": list(self.purchased),
            "available": [u.key for u in self.available()],
        }
