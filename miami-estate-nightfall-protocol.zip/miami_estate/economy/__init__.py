"""Estate economy: budget/income/expenses, repair jobs, and the upgrade tree."""
