"""
economy.budget
===============

The estate's fictional operating budget: income sources (business
operations, property investment, events, tourism) versus expenses
(maintenance, repairs, upgrades, energy, staff, technology).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Transaction:
    label: str
    amount: float  # positive = income, negative = expense
    category: str


@dataclass
class Budget:
    balance: float = 250_000.0
    ledger: List[Transaction] = field(default_factory=list)

    def income(self, label: str, amount: float, category: str = "OPERATIONS") -> None:
        amount = abs(amount)
        self.balance += amount
        self.ledger.append(Transaction(label, amount, category))

    def expense(self, label: str, amount: float, category: str = "MAINTENANCE") -> bool:
        amount = abs(amount)
        if amount > self.balance:
            return False
        self.balance -= amount
        self.ledger.append(Transaction(label, -amount, category))
        return True

    def force_expense(self, label: str, amount: float, category: str = "MAINTENANCE") -> None:
        """Allows the balance to go negative (e.g. emergency repairs)."""
        amount = abs(amount)
        self.balance -= amount
        self.ledger.append(Transaction(label, -amount, category))

    def totals_by_category(self) -> Dict[str, float]:
        totals: Dict[str, float] = {}
        for t in self.ledger:
            totals[t.category] = totals.get(t.category, 0.0) + t.amount
        return {k: round(v, 2) for k, v in totals.items()}

    def net_worth_report(self) -> Dict[str, object]:
        return {
            "balance": round(self.balance, 2),
            "total_income": round(sum(t.amount for t in self.ledger if t.amount > 0), 2),
            "total_expense": round(-sum(t.amount for t in self.ledger if t.amount < 0), 2),
            "by_category": self.totals_by_category(),
        }
