"""
economy.repairs
================

Repair jobs consume time, money, materials and engineering capacity, and
apply healing to a zone's damage categories (and, through the smart-home
hub, back into camera coverage / access control). This is the estate's
long-term management loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from miami_estate.core.state import DamageCategory
from miami_estate.economy.budget import Budget
from miami_estate.estate.property import Estate
from miami_estate.estate.zones import ZoneId

# Fictional per-unit-of-damage cost, in estate currency.
COST_PER_POINT = 180.0
MATERIALS_PER_POINT = 1.2
ENGINEERING_PER_POINT = 0.8
TICKS_PER_10_POINTS = 1


@dataclass
class RepairJob:
    job_id: str
    zone: ZoneId
    category: DamageCategory
    amount_requested: float
    ticks_remaining: int
    completed: bool = False


@dataclass
class RepairManager:
    estate: Estate
    budget: Budget
    materials: float = 500.0
    engineering_capacity: float = 40.0  # capacity consumed per tick across active jobs
    jobs: List[RepairJob] = field(default_factory=list)
    _counter: int = 0

    def queue_repair(
        self, zone: ZoneId, category: DamageCategory, amount: float
    ) -> Optional[RepairJob]:
        cost = amount * COST_PER_POINT
        materials_needed = amount * MATERIALS_PER_POINT
        if cost > self.budget.balance or materials_needed > self.materials:
            return None
        self.budget.expense(f"Repair {category.value} in {zone.value}", cost, "REPAIRS")
        self.materials -= materials_needed
        self._counter += 1
        job = RepairJob(
            job_id=f"RPR-{self._counter:04d}",
            zone=zone,
            category=category,
            amount_requested=amount,
            ticks_remaining=max(1, round(amount / 10) * TICKS_PER_10_POINTS),
        )
        self.jobs.append(job)
        return job

    def tick(self) -> List[RepairJob]:
        completed_now = []
        active = [j for j in self.jobs if not j.completed]
        # Engineering capacity limits how many jobs progress per tick.
        capacity_left = self.engineering_capacity
        for job in active:
            unit_cost = ENGINEERING_PER_POINT * (job.amount_requested / max(1, job.ticks_remaining))
            if capacity_left < unit_cost:
                continue
            capacity_left -= unit_cost
            job.ticks_remaining -= 1
            if job.ticks_remaining <= 0:
                self.estate.zone(job.zone).repair(job.category, job.amount_requested)
                job.completed = True
                completed_now.append(job)
        return completed_now

    def restock_materials(self, amount: float) -> None:
        self.materials += amount

    def snapshot(self) -> Dict[str, object]:
        return {
            "materials": round(self.materials, 1),
            "engineering_capacity": self.engineering_capacity,
            "active_jobs": [
                {
                    "job": j.job_id,
                    "zone": j.zone.value,
                    "category": j.category.value,
                    "ticks_remaining": j.ticks_remaining,
                }
                for j in self.jobs
                if not j.completed
            ],
        }
