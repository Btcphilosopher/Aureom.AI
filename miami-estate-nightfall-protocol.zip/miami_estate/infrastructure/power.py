"""
infrastructure.power
=====================

Fictional power infrastructure: grid, solar, battery, generator and
per-consumer feeds (house, security, marina). Damage here is what
propagates into cameras/network/lighting degradation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from miami_estate.core.state import SystemStatus, clamp


@dataclass
class PowerFeed:
    name: str
    load: float = 100.0  # 0-100 % powered
    status: SystemStatus = SystemStatus.ONLINE

    def degrade(self, amount: float) -> None:
        self.load = clamp(self.load - amount)
        if self.load <= 0:
            self.status = SystemStatus.OFFLINE
        elif self.load < 50:
            self.status = SystemStatus.DEGRADED

    def restore(self, amount: float) -> None:
        self.load = clamp(self.load + amount)
        if self.load >= 80:
            self.status = SystemStatus.ONLINE


@dataclass
class PowerGrid:
    grid: float = 100.0
    solar: float = 100.0
    battery: float = 100.0
    generator_online: bool = False
    feeds: Dict[str, PowerFeed] = field(
        default_factory=lambda: {
            "HOUSE": PowerFeed("HOUSE POWER"),
            "SECURITY": PowerFeed("SECURITY POWER"),
            "MARINA": PowerFeed("MARINA POWER"),
        }
    )

    def fail_grid(self, amount: float) -> None:
        self.grid = clamp(self.grid - amount)
        if self.grid < 40 and self.battery > 10:
            self.battery = clamp(self.battery - amount * 0.5)
        if self.grid < 20:
            self.generator_online = True
        for feed in self.feeds.values():
            feed.degrade(amount * 0.6)

    def restore_grid(self, amount: float) -> None:
        self.grid = clamp(self.grid + amount)
        self.battery = clamp(self.battery + amount * 0.3)
        if self.grid > 70:
            self.generator_online = False
        for feed in self.feeds.values():
            feed.restore(amount * 0.5)

    def overall_output(self) -> float:
        base = max(self.grid, self.battery if self.generator_online else 0, self.solar * 0.4)
        return round(clamp(base), 1)

    def snapshot(self) -> Dict[str, object]:
        return {
            "grid": round(self.grid, 1),
            "solar": round(self.solar, 1),
            "battery": round(self.battery, 1),
            "generator_online": self.generator_online,
            "output": self.overall_output(),
            "feeds": {
                key: {"load": round(f.load, 1), "status": f.status.value}
                for key, f in self.feeds.items()
            },
        }
