"""
infrastructure.lighting
========================

Smart lighting network: path, pool, garden, architectural, driveway and
emergency circuits. Lighting mode follows the estate's alert posture:
NORMAL -> ALERT -> LOCKDOWN -> EMERGENCY -> RECOVERY.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict

from miami_estate.core.state import AlertLevel


class LightingMode(str, Enum):
    NORMAL = "NORMAL"
    ALERT = "ALERT"
    LOCKDOWN = "LOCKDOWN"
    EMERGENCY = "EMERGENCY"
    RECOVERY = "RECOVERY"


_ALERT_TO_LIGHTING = {
    AlertLevel.NORMAL: LightingMode.NORMAL,
    AlertLevel.MONITOR: LightingMode.NORMAL,
    AlertLevel.ALERT: LightingMode.ALERT,
    AlertLevel.LOCKDOWN: LightingMode.LOCKDOWN,
    AlertLevel.EMERGENCY: LightingMode.EMERGENCY,
    AlertLevel.RECOVERY: LightingMode.RECOVERY,
}

_CIRCUITS = [
    "PATH LIGHTING",
    "POOL LIGHTING",
    "GARDEN LIGHTING",
    "ARCHITECTURAL LIGHTING",
    "DRIVEWAY LIGHTING",
    "EMERGENCY LIGHTING",
]


@dataclass
class LightingSystem:
    mode: LightingMode = LightingMode.NORMAL
    circuits_online: Dict[str, bool] = field(
        default_factory=lambda: {c: (c != "EMERGENCY LIGHTING") for c in _CIRCUITS}
    )

    def sync_to_alert(self, highest_alert: AlertLevel) -> None:
        self.mode = _ALERT_TO_LIGHTING[highest_alert]
        if self.mode in (LightingMode.LOCKDOWN, LightingMode.EMERGENCY):
            self.circuits_online["EMERGENCY LIGHTING"] = True
        elif self.mode == LightingMode.NORMAL:
            self.circuits_online["EMERGENCY LIGHTING"] = False

    def scene_for_time(self, hour: int) -> str:
        """Cosmetic Miami lighting scene descriptor for the HUD/flavour text."""
        if 6 <= hour < 11:
            return "DAY — Miami sunshine, white architecture, blue water"
        if 11 <= hour < 17:
            return "DAY — high sun, limestone glare, turquoise pool"
        if 17 <= hour < 20:
            return "SUNSET — orange sky, warm architectural lighting"
        return "NIGHT — deep blue, turquoise pool glow, subtle neon"

    def snapshot(self) -> Dict[str, object]:
        return {"mode": self.mode.value, "circuits": dict(self.circuits_online)}
