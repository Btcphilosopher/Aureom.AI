"""
infrastructure.network
=======================

Fictional estate communications/data network. Cameras, alarms and access
control all depend on network health; a network failure degrades their
effectiveness rather than granting the raid AI any real-world exploit.
"""

from __future__ import annotations

from dataclasses import dataclass

from miami_estate.core.state import SystemStatus, clamp


@dataclass
class NetworkSystem:
    strength: float = 100.0
    status: SystemStatus = SystemStatus.ONLINE
    communications_online: bool = True

    def degrade(self, amount: float) -> None:
        self.strength = clamp(self.strength - amount)
        if self.strength <= 0:
            self.status = SystemStatus.OFFLINE
            self.communications_online = False
        elif self.strength < 55:
            self.status = SystemStatus.DEGRADED
            self.communications_online = self.strength > 25

    def restore(self, amount: float) -> None:
        self.strength = clamp(self.strength + amount)
        if self.strength >= 80:
            self.status = SystemStatus.ONLINE
            self.communications_online = True
        elif self.strength >= 25:
            self.communications_online = True

    def snapshot(self) -> dict:
        return {
            "strength": round(self.strength, 1),
            "status": self.status.value,
            "communications_online": self.communications_online,
        }
