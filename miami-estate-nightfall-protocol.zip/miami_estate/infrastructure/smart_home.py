"""
infrastructure.smart_home
==========================

The SmartHomeHub wires power, network and lighting together and is
responsible for the cascade rule that makes the estate feel like one
living system:

    POWER FAILURE -> CAMERA NETWORK DEGRADED -> LOWER DETECTION -> MORE RISK

It also computes the estate-status percentages shown on the command
center (SECURITY / POWER / NETWORK / CAMERAS / ACCESS / STRUCTURE).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from miami_estate.core.state import AlertLevel
from miami_estate.estate.property import Estate
from miami_estate.infrastructure.lighting import LightingSystem
from miami_estate.infrastructure.network import NetworkSystem
from miami_estate.infrastructure.power import PowerGrid
from miami_estate.security.access_control import AccessControlSystem
from miami_estate.security.monitoring import MonitoringSystem


@dataclass
class SmartHomeHub:
    estate: Estate
    monitoring: MonitoringSystem
    access_control: AccessControlSystem
    power: PowerGrid = field(default_factory=PowerGrid)
    network: NetworkSystem = field(default_factory=NetworkSystem)
    lighting: LightingSystem = field(default_factory=LightingSystem)

    @classmethod
    def build(cls, estate: Estate, monitoring: MonitoringSystem) -> "SmartHomeHub":
        access_control = AccessControlSystem.default_for_zones(list(estate.zones.keys()))
        return cls(estate=estate, monitoring=monitoring, access_control=access_control)

    def power_failure(self, amount: float) -> None:
        """Applies a power failure and cascades it into camera/network health."""
        self.power.fail_grid(amount)
        self.network.degrade(amount * 0.5)
        cascade = amount * 0.4
        for zone in self.estate.zones.keys():
            self.monitoring.cameras.degrade_zone(zone, cascade)

    def restore_power(self, amount: float) -> None:
        self.power.restore_grid(amount)
        self.network.restore(amount * 0.5)
        for zone in self.estate.zones.keys():
            self.monitoring.cameras.restore_zone(zone, amount * 0.3)

    def sync_lighting(self) -> None:
        levels = [z.alert_state for z in self.estate.zones.values()]
        order = list(AlertLevel)
        highest = max(levels, key=lambda lvl: order.index(lvl)) if levels else AlertLevel.NORMAL
        self.lighting.sync_to_alert(highest)

    def estate_status_board(self) -> Dict[str, float]:
        return {
            "SECURITY": self.monitoring.security_score(),
            "POWER": self.power.overall_output(),
            "NETWORK": round(self.network.strength, 1),
            "CAMERAS": self.monitoring.cameras.network_health(),
            "ACCESS": round(self.access_control.secured_fraction() * 100, 1),
            "STRUCTURE": self.estate.overall_structural_integrity(),
        }
