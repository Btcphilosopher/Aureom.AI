"""Estate infrastructure: power, network, lighting and the smart-home hub."""
