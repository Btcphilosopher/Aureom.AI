"""
vehicles.cars
=============

Fictional Miami luxury cars: supercars, SUVs, EVs, and estate security
vehicles. Purely cosmetic/game objects with a small state machine.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict


class VehicleClass(str, Enum):
    SUPERCAR = "SUPERCAR"
    SUV = "SUV"
    ELECTRIC = "ELECTRIC"
    SECURITY_VEHICLE = "SECURITY VEHICLE"


class VehicleState(str, Enum):
    PARKED = "PARKED"
    MOVING = "MOVING"
    ARRIVING = "ARRIVING"
    DEPARTING = "DEPARTING"
    DAMAGED = "DAMAGED"
    LOCKED = "LOCKED"


@dataclass
class Car:
    name: str
    vehicle_class: VehicleClass
    state: VehicleState = VehicleState.PARKED
    bay: str | None = None
    integrity: float = 100.0

    def arrive(self) -> None:
        self.state = VehicleState.ARRIVING

    def park(self, bay: str) -> None:
        self.bay = bay
        self.state = VehicleState.PARKED

    def depart(self) -> None:
        self.state = VehicleState.DEPARTING
        self.bay = None

    def lock(self) -> None:
        if self.state == VehicleState.PARKED:
            self.state = VehicleState.LOCKED

    def damage(self, amount: float) -> None:
        self.integrity = max(0.0, self.integrity - amount)
        if self.integrity <= 40:
            self.state = VehicleState.DAMAGED

    def repair(self, amount: float) -> None:
        self.integrity = min(100.0, self.integrity + amount)
        if self.integrity > 40 and self.state == VehicleState.DAMAGED:
            self.state = VehicleState.PARKED

    def snapshot(self) -> Dict[str, object]:
        return {
            "name": self.name,
            "class": self.vehicle_class.value,
            "state": self.state.value,
            "bay": self.bay,
            "integrity": round(self.integrity, 1),
        }


def default_fleet() -> list[Car]:
    return [
        Car("Aurelia Spyder", VehicleClass.SUPERCAR, bay="BAY-01"),
        Car("Tidewater SUV", VehicleClass.SUV, bay="BAY-02"),
        Car("Voltaire EV", VehicleClass.ELECTRIC, bay="BAY-03"),
        Car("Sentinel Patrol Unit", VehicleClass.SECURITY_VEHICLE, bay="BAY-04"),
    ]
