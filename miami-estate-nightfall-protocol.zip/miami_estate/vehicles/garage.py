"""
vehicles.garage
================

Fleet management on top of `estate.garage.Garage`: parks/departs cars
into physical bays and keeps the two in sync.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.estate.garage import Garage
from miami_estate.vehicles.cars import Car, VehicleState, default_fleet


@dataclass
class FleetManager:
    garage: Garage
    cars: List[Car] = field(default_factory=default_fleet)

    def sync_to_garage(self) -> None:
        for car in self.cars:
            if car.bay:
                self.garage.park(car.bay, car.name)

    def depart(self, car_name: str) -> bool:
        for car in self.cars:
            if car.name == car_name and car.state == VehicleState.PARKED:
                if car.bay:
                    self.garage.release(car.bay)
                car.depart()
                return True
        return False

    def arrive_and_park(self, car_name: str, bay_id: str) -> bool:
        for car in self.cars:
            if car.name == car_name:
                if self.garage.park(bay_id, car_name):
                    car.park(bay_id)
                    return True
        return False

    def damage_parked_fleet(self, amount: float) -> None:
        for car in self.cars:
            if car.state in (VehicleState.PARKED, VehicleState.LOCKED):
                car.damage(amount)

    def repair_fleet(self, amount: float) -> None:
        for car in self.cars:
            car.repair(amount)

    def snapshot(self) -> Dict[str, object]:
        return {"garage": self.garage.snapshot(), "cars": [c.snapshot() for c in self.cars]}
