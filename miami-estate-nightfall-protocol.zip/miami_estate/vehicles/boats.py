"""
vehicles.boats
===============

Fictional yachts/boats moored at the marina.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional


class BoatClass(str, Enum):
    YACHT = "YACHT"
    TENDER = "TENDER"
    PATROL_BOAT = "PATROL BOAT"


class BoatState(str, Enum):
    DOCKED = "DOCKED"
    MOVING = "MOVING"
    ARRIVING = "ARRIVING"
    DEPARTING = "DEPARTING"
    DAMAGED = "DAMAGED"


@dataclass
class Boat:
    name: str
    boat_class: BoatClass
    state: BoatState = BoatState.DOCKED
    slip: Optional[str] = None
    integrity: float = 100.0

    def damage(self, amount: float) -> None:
        self.integrity = max(0.0, self.integrity - amount)
        if self.integrity <= 40:
            self.state = BoatState.DAMAGED

    def repair(self, amount: float) -> None:
        self.integrity = min(100.0, self.integrity + amount)
        if self.integrity > 40 and self.state == BoatState.DAMAGED:
            self.state = BoatState.DOCKED

    def snapshot(self) -> Dict[str, object]:
        return {
            "name": self.name,
            "class": self.boat_class.value,
            "state": self.state.value,
            "slip": self.slip,
            "integrity": round(self.integrity, 1),
        }


def default_fleet() -> list[Boat]:
    return [
        Boat("Sunset Mariner", BoatClass.YACHT, slip="SLIP-01"),
        Boat("Reef Runner", BoatClass.TENDER, slip="SLIP-02"),
        Boat("Estate Sentinel", BoatClass.PATROL_BOAT, slip="SLIP-03"),
    ]
