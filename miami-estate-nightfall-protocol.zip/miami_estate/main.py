"""
main.py
=======

Runs the "MIAMI NIGHTFALL" demo scenario end-to-end: a cooperative team
defends a fictional Miami waterfront estate through an escalating,
procedurally generated raid event, then prints the full end-of-night
report set (damage / security / financial / repair / performance).

This is a fictional game simulation. Nothing here models, teaches, or
enables real-world security bypass, weapons, or surveillance deployment.

Run with:  python -m miami_estate.main
"""

from __future__ import annotations

from miami_estate.core.game_loop import GameLoop
from miami_estate.core.simulation import Simulation
from miami_estate.core.state import SecurityMode
from miami_estate.economy.upgrades import UPGRADE_TREE
from miami_estate.estate.zones import ZoneId
from miami_estate.events.scenarios import MIAMI_NIGHTFALL
from miami_estate.ui.command_center import render_command_center
from miami_estate.ui.estate_map import render_estate_map

_ZONE_BY_LABEL = {z.value: z for z in ZoneId}


def dispatch_players(simulation, report, clock: str) -> None:
    """A lightweight coordinator: sends idle players toward alerting zones,
    approximating the Mobile Responder / Estate Manager coordination loop
    the cooperative mode expects a human team to run manually."""
    covered = {p.zone for p in simulation.players}
    for zone_label in report.active_alert_zones:
        zone_id = _ZONE_BY_LABEL[zone_label]
        if zone_id in covered:
            continue
        idle = sorted(simulation.players, key=lambda p: p.alerts_responded)
        if not idle:
            break
        responder = idle[0]
        if responder.zone != zone_id:
            print(f"[{clock}] DISPATCH — {responder.name} ({responder.role.value}) -> {zone_label}")
            responder.move_to(zone_id)
        responder.respond_to_alert()
        covered.add(zone_id)


def narrate(simulation, report) -> None:
    clock = simulation.clock_label()
    if report.started:
        for incident_id in report.started:
            incident = next(i for i in simulation._all_incidents() if i.incident_id == incident_id)
            print(
                f"[{clock}] EVENT — {incident.incident_type.value} "
                f"@ {incident.zone.value} (severity: {incident.severity.value})"
            )
    dispatch_players(simulation, report, clock)
    for incident_id in report.neutralized:
        print(f"[{clock}] RESPONSE — incident {incident_id} neutralized by player response.")
    for incident_id in report.resolved:
        print(f"[{clock}] RESOLVED — incident {incident_id} concluded.")
    if report.emergency_mode:
        print(f"[{clock}] ESTATE ENTERING EMERGENCY MODE — {len(report.active_alert_zones)} zones alerting.")


def print_report_section(title: str, data: dict) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    for key, value in data.items():
        print(f"  {key}: {value}")


def main() -> None:
    print("=" * 72)
    print("  MIAMI ESTATE: NIGHTFALL PROTOCOL")
    print(f"  Scenario: {MIAMI_NIGHTFALL.name}")
    print(f"  {MIAMI_NIGHTFALL.description}")
    print("=" * 72)

    scenario = MIAMI_NIGHTFALL.build()
    player_names = ["Operator-1", "Manager-1", "Responder-1", "Technician-1", "Marina-1", "Responder-2"]
    simulation = Simulation.build(
        estate_name="Villa Meridian",
        address="1 Nightfall Cay, Biscayne Bay, Miami, FL",
        player_names=player_names,
        scenario=scenario,
        residents=["Mr. Alvarez", "Mrs. Alvarez"],
        guests=["Guest — R. Soto"],
        staff=["Housekeeper — I. Duarte", "Dockmaster — J. Reyes"],
    )
    simulation.hub.access_control.set_mode(SecurityMode.NIGHT)

    print("\nINITIAL STATE")
    print("-------------")
    board = simulation.hub.estate_status_board()
    for key in ("SECURITY", "POWER", "NETWORK", "CAMERAS", "ACCESS", "STRUCTURE"):
        print(f"  {key:<10} {board[key]:5.1f}%")

    print("\n--- SCENARIO IN PROGRESS ---\n")
    loop = GameLoop(simulation=simulation, scenario_name=MIAMI_NIGHTFALL.name, narrator=narrate)
    report = loop.run()

    print("\n" + render_command_center(simulation.hub, simulation.tick, simulation.clock_label()))
    print("\n" + render_estate_map(simulation.estate, simulation.monitoring))

    print("\n" + "=" * 72)
    print("  END OF NIGHT REPORT")
    print("=" * 72)
    print_report_section("DAMAGE REPORT", report.damage_report)
    print_report_section("SECURITY REPORT", report.security_report)
    print_report_section("FINANCIAL REPORT", report.financial_report)
    print_report_section("REPAIR REPORT", report.repair_report)

    print("\nPERFORMANCE SCORE")
    print("-----------------")
    print(f"  Overall score: {report.performance_score}/100")
    print(f"  Coordination score: {report.coordination_score}/100")
    print(f"  Outcome: {'VICTORY' if report.victory else 'ESTATE COMPROMISED'}")
    for reason in report.victory_reasons:
        print(f"    - {reason}")

    print(f"\nUpgrade tree unlocked through tier {simulation.upgrades.unlocked_tier} "
          f"of {max(u.tier for u in UPGRADE_TREE)}.")
    print("=" * 72)


if __name__ == "__main__":
    main()
