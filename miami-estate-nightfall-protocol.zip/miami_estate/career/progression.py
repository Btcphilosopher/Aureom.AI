"""
career.progression
====================

Tracks the solo Estate Manager's career across scenarios: nights
survived, reputation, and unlocked career stages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


CAREER_STAGES: List[Dict[str, object]] = [
    {"stage": 1, "name": "Waterfront Starter", "nights_required": 0},
    {"stage": 2, "name": "Rising Estate Manager", "nights_required": 3},
    {"stage": 3, "name": "Established Property Operator", "nights_required": 8},
    {"stage": 4, "name": "Miami Luxury Estate Director", "nights_required": 15},
    {"stage": 5, "name": "Ultra-Luxury Smart Estate Owner", "nights_required": 25},
]


@dataclass
class CareerProgression:
    nights_survived: int = 0
    reputation: float = 50.0
    scenario_history: List[Dict[str, object]] = field(default_factory=list)

    def record_scenario(self, name: str, score: float, survived: bool) -> None:
        self.scenario_history.append({"scenario": name, "score": score, "survived": survived})
        if survived:
            self.nights_survived += 1
            self.reputation = min(100.0, self.reputation + score / 20)
        else:
            self.reputation = max(0.0, self.reputation - 5)

    def current_stage(self) -> Dict[str, object]:
        eligible = [s for s in CAREER_STAGES if self.nights_survived >= s["nights_required"]]
        return eligible[-1] if eligible else CAREER_STAGES[0]

    def next_stage(self) -> Dict[str, object] | None:
        current = self.current_stage()
        idx = CAREER_STAGES.index(current)
        return CAREER_STAGES[idx + 1] if idx + 1 < len(CAREER_STAGES) else None

    def snapshot(self) -> Dict[str, object]:
        nxt = self.next_stage()
        return {
            "nights_survived": self.nights_survived,
            "reputation": round(self.reputation, 1),
            "current_stage": self.current_stage()["name"],
            "next_stage": nxt["name"] if nxt else None,
            "nights_to_next_stage": (
                max(0, nxt["nights_required"] - self.nights_survived) if nxt else 0
            ),
        }
