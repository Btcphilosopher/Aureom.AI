"""
career.estate_expansion
=========================

Unlocks additional estate features as the career progresses: guest
houses, extra garage bays, an expanded marina, and larger grounds.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.career.progression import CareerProgression
from miami_estate.estate.garage import GarageBay
from miami_estate.estate.marina import DockSlip
from miami_estate.estate.property import Estate

EXPANSIONS: List[Dict[str, object]] = [
    {"key": "guest_house", "name": "Guest House", "stage_required": 2},
    {"key": "extra_garage_bays", "name": "Extra Garage Bays (+3)", "stage_required": 2},
    {"key": "expanded_marina", "name": "Expanded Marina (+2 slips)", "stage_required": 3},
    {"key": "landscaped_grounds", "name": "Landscaped Grounds", "stage_required": 3},
    {"key": "second_building", "name": "Second Building", "stage_required": 4},
    {"key": "private_helipad", "name": "Private Helipad", "stage_required": 5},
]


@dataclass
class ExpansionManager:
    estate: Estate
    career: CareerProgression
    unlocked: List[str] = field(default_factory=list)

    def available(self) -> List[Dict[str, object]]:
        current_stage = self.career.current_stage()["stage"]
        return [
            e
            for e in EXPANSIONS
            if e["stage_required"] <= current_stage and e["key"] not in self.unlocked
        ]

    def apply(self, key: str) -> bool:
        expansion = next((e for e in EXPANSIONS if e["key"] == key), None)
        if not expansion or expansion not in self.available():
            return False
        if key == "extra_garage_bays":
            start = len(self.estate.garage.bays) + 1
            for i in range(3):
                self.estate.garage.bays.append(GarageBay(f"BAY-{start + i:02d}"))
        elif key == "expanded_marina":
            start = len(self.estate.marina.slips) + 1
            for i in range(2):
                self.estate.marina.slips.append(DockSlip(f"SLIP-{start + i:02d}"))
        self.unlocked.append(key)
        return True

    def snapshot(self) -> Dict[str, object]:
        return {"unlocked": list(self.unlocked), "available": [e["key"] for e in self.available()]}
