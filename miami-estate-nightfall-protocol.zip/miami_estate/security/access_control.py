"""
security.access_control
========================

Fictional smart-lock / gate network and the estate-wide `SecurityMode`
that governs default door behaviour (DAY / NIGHT / PARTY / AWAY / ALERT
/ LOCKDOWN). This is an abstract game system, not a real access-control
product.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from miami_estate.core.state import DoorState, SecurityMode
from miami_estate.estate.zones import ZoneId

# Default door disposition per estate-wide security mode.
_MODE_DEFAULT_DOOR_STATE: Dict[SecurityMode, DoorState] = {
    SecurityMode.DAY: DoorState.CLOSED,
    SecurityMode.NIGHT: DoorState.LOCKED,
    SecurityMode.PARTY: DoorState.CLOSED,
    SecurityMode.AWAY: DoorState.SECURED,
    SecurityMode.ALERT: DoorState.LOCKED,
    SecurityMode.LOCKDOWN: DoorState.SECURED,
}


@dataclass
class AccessPoint:
    point_id: str
    zone: ZoneId
    state: DoorState = DoorState.CLOSED

    def apply_mode(self, mode: SecurityMode) -> None:
        if self.state == DoorState.DAMAGED:
            return
        self.state = _MODE_DEFAULT_DOOR_STATE[mode]

    def override(self, state: DoorState) -> None:
        self.state = state

    def damage(self) -> None:
        self.state = DoorState.DAMAGED

    def snapshot(self) -> Dict[str, object]:
        return {"point": self.point_id, "zone": self.zone.value, "state": self.state.value}


@dataclass
class AccessControlSystem:
    mode: SecurityMode = SecurityMode.DAY
    points: List[AccessPoint] = field(default_factory=list)
    _history: List[SecurityMode] = field(default_factory=list)

    @classmethod
    def default_for_zones(cls, zones: List[ZoneId]) -> "AccessControlSystem":
        points = [AccessPoint(f"DOOR-{i + 1:02d}", zone) for i, zone in enumerate(zones)]
        return cls(points=points)

    def set_mode(self, mode: SecurityMode) -> None:
        self._history.append(self.mode)
        self.mode = mode
        for point in self.points:
            point.apply_mode(mode)

    def by_zone(self, zone: ZoneId) -> List[AccessPoint]:
        return [p for p in self.points if p.zone == zone]

    def override_zone(self, zone: ZoneId, state: DoorState) -> None:
        for p in self.by_zone(zone):
            p.override(state)

    def secured_fraction(self) -> float:
        if not self.points:
            return 1.0
        secured = sum(
            1 for p in self.points if p.state in (DoorState.LOCKED, DoorState.SECURED)
        )
        return round(secured / len(self.points), 2)

    def snapshot(self) -> Dict[str, object]:
        return {
            "mode": self.mode.value,
            "secured_fraction": self.secured_fraction(),
            "points": [p.snapshot() for p in self.points],
        }
