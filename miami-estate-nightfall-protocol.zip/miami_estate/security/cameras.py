"""
security.cameras
=================

The fictional surveillance network. Cameras are simulation objects with
location, orientation, field of view and a confidence score — there is no
real image data, computer vision, or video anywhere in this package.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from miami_estate.core.state import SystemStatus, clamp
from miami_estate.estate.zones import ZoneId


@dataclass
class Camera:
    camera_id: str
    zone: ZoneId
    orientation: str          # e.g. "NORTH", "WATERFRONT", "DRIVEWAY"
    field_of_view: int        # degrees, cosmetic
    status: SystemStatus = SystemStatus.ONLINE
    coverage: float = 95.0    # 0-100 % of assigned area actually observed
    confidence: float = 0.95  # 0-1 detection confidence for this feed

    def degrade(self, amount: float) -> None:
        self.coverage = clamp(self.coverage - amount)
        self.confidence = round(max(0.05, self.confidence - amount / 150), 3)
        if self.coverage <= 0:
            self.status = SystemStatus.OFFLINE
        elif self.coverage < 60:
            self.status = SystemStatus.DEGRADED

    def restore(self, amount: float) -> None:
        self.coverage = clamp(self.coverage + amount)
        self.confidence = round(min(0.99, self.confidence + amount / 150), 3)
        if self.coverage >= 80:
            self.status = SystemStatus.ONLINE

    def damage(self) -> None:
        self.status = SystemStatus.DAMAGED
        self.coverage = 0.0
        self.confidence = 0.0

    def snapshot(self) -> Dict[str, object]:
        return {
            "camera": self.camera_id,
            "zone": self.zone.value,
            "orientation": self.orientation,
            "field_of_view": self.field_of_view,
            "status": self.status.value,
            "coverage": round(self.coverage, 1),
            "confidence": self.confidence,
        }


@dataclass
class CameraNetwork:
    """The full camera grid, with a live-view 'focused' camera."""

    cameras: List[Camera] = field(default_factory=list)
    focused: Optional[str] = None

    @classmethod
    def default_for_zones(cls, zones: List[ZoneId]) -> "CameraNetwork":
        cameras: List[Camera] = []
        orientations = ["NORTH", "SOUTH", "EAST", "WEST", "WATERFRONT", "DRIVEWAY"]
        for i, zone in enumerate(zones):
            cameras.append(
                Camera(
                    camera_id=f"CAM-{i + 1:02d}",
                    zone=zone,
                    orientation=orientations[i % len(orientations)],
                    field_of_view=90 + (i % 3) * 30,
                )
            )
        network = cls(cameras=cameras)
        network.focused = cameras[0].camera_id if cameras else None
        return network

    def by_zone(self, zone: ZoneId) -> List[Camera]:
        return [c for c in self.cameras if c.zone == zone]

    def focus(self, camera_id: str) -> Optional[Camera]:
        for c in self.cameras:
            if c.camera_id == camera_id:
                self.focused = camera_id
                return c
        return None

    def network_health(self) -> float:
        if not self.cameras:
            return 100.0
        return round(sum(c.coverage for c in self.cameras) / len(self.cameras), 1)

    def grid_snapshot(self) -> List[Dict[str, object]]:
        return [c.snapshot() for c in self.cameras]

    def alert_feed(self) -> List[Dict[str, object]]:
        return [c.snapshot() for c in self.cameras if c.status == SystemStatus.ALERT]

    def degrade_zone(self, zone: ZoneId, amount: float) -> None:
        for c in self.by_zone(zone):
            c.degrade(amount)

    def restore_zone(self, zone: ZoneId, amount: float) -> None:
        for c in self.by_zone(zone):
            c.restore(amount)
