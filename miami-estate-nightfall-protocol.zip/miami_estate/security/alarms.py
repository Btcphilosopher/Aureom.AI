"""
security.alarms
================

Fictional zone/estate alarm system. Tracks active alarms and their
acknowledgement by players, purely as abstract game state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from miami_estate.core.state import Severity
from miami_estate.estate.zones import ZoneId


@dataclass
class AlarmRecord:
    alarm_id: str
    zone: ZoneId
    reason: str
    severity: Severity
    raised_at_tick: int
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    cleared: bool = False

    def snapshot(self) -> Dict[str, object]:
        return {
            "alarm": self.alarm_id,
            "zone": self.zone.value,
            "reason": self.reason,
            "severity": self.severity.value,
            "raised_at_tick": self.raised_at_tick,
            "acknowledged": self.acknowledged,
            "acknowledged_by": self.acknowledged_by,
            "cleared": self.cleared,
        }


@dataclass
class AlarmSystem:
    records: List[AlarmRecord] = field(default_factory=list)
    _counter: int = 0

    def raise_alarm(
        self, zone: ZoneId, reason: str, severity: Severity, tick: int
    ) -> AlarmRecord:
        self._counter += 1
        record = AlarmRecord(
            alarm_id=f"ALM-{self._counter:04d}",
            zone=zone,
            reason=reason,
            severity=severity,
            raised_at_tick=tick,
        )
        self.records.append(record)
        return record

    def acknowledge(self, alarm_id: str, player: str) -> bool:
        for r in self.records:
            if r.alarm_id == alarm_id and not r.cleared:
                r.acknowledged = True
                r.acknowledged_by = player
                return True
        return False

    def clear(self, alarm_id: str) -> bool:
        for r in self.records:
            if r.alarm_id == alarm_id:
                r.cleared = True
                return True
        return False

    def active(self) -> List[AlarmRecord]:
        return [r for r in self.records if not r.cleared]

    def active_by_zone(self, zone: ZoneId) -> List[AlarmRecord]:
        return [r for r in self.active() if r.zone == zone]

    def feed(self) -> List[Dict[str, object]]:
        return [r.snapshot() for r in sorted(self.active(), key=lambda r: r.raised_at_tick)]
