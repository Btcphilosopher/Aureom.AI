"""
security.sensors
=================

Motion and environmental sensors — abstract fictional triggers, not real
detection hardware or algorithms.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List

from miami_estate.core.state import SystemStatus
from miami_estate.estate.zones import ZoneId


class SensorType(str, Enum):
    MOTION = "MOTION"
    ENVIRONMENTAL = "ENVIRONMENTAL"
    PRESSURE = "PRESSURE"
    ACOUSTIC = "ACOUSTIC"
    WATER = "WATER"


@dataclass
class Sensor:
    sensor_id: str
    zone: ZoneId
    sensor_type: SensorType
    status: SystemStatus = SystemStatus.ONLINE
    triggered: bool = False
    sensitivity: float = 0.7  # 0-1

    def trigger(self) -> None:
        if self.status == SystemStatus.ONLINE:
            self.triggered = True
            self.status = SystemStatus.ALERT

    def reset(self) -> None:
        self.triggered = False
        if self.status == SystemStatus.ALERT:
            self.status = SystemStatus.ONLINE

    def disable(self) -> None:
        self.status = SystemStatus.OFFLINE
        self.triggered = False

    def snapshot(self) -> Dict[str, object]:
        return {
            "sensor": self.sensor_id,
            "zone": self.zone.value,
            "type": self.sensor_type.value,
            "status": self.status.value,
            "triggered": self.triggered,
        }


@dataclass
class SensorArray:
    sensors: List[Sensor] = field(default_factory=list)

    @classmethod
    def default_for_zones(cls, zones: List[ZoneId]) -> "SensorArray":
        sensors: List[Sensor] = []
        cycle = list(SensorType)
        for i, zone in enumerate(zones):
            sensors.append(
                Sensor(f"SEN-{i + 1:02d}", zone, cycle[i % len(cycle)])
            )
        return cls(sensors=sensors)

    def by_zone(self, zone: ZoneId) -> List[Sensor]:
        return [s for s in self.sensors if s.zone == zone]

    def any_triggered(self, zone: ZoneId) -> bool:
        return any(s.triggered for s in self.by_zone(zone))

    def reset_zone(self, zone: ZoneId) -> None:
        for s in self.by_zone(zone):
            s.reset()

    def snapshot(self) -> List[Dict[str, object]]:
        return [s.snapshot() for s in self.sensors]
