"""
security.monitoring
====================

Aggregates cameras, sensors and alarms into a single "MonitoringSystem"
that the Security Operator role and the command center read from.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from miami_estate.core.state import AlertLevel, Severity
from miami_estate.estate.property import Estate
from miami_estate.security.alarms import AlarmSystem
from miami_estate.security.cameras import CameraNetwork
from miami_estate.security.sensors import SensorArray


@dataclass
class MonitoringSystem:
    estate: Estate
    cameras: CameraNetwork
    sensors: SensorArray
    alarms: AlarmSystem

    @classmethod
    def build(cls, estate: Estate) -> "MonitoringSystem":
        zones = list(estate.zones.keys())
        return cls(
            estate=estate,
            cameras=CameraNetwork.default_for_zones(zones),
            sensors=SensorArray.default_for_zones(zones),
            alarms=AlarmSystem(),
        )

    def active_alerts_board(self) -> List[Dict[str, str]]:
        board = []
        for zone in self.estate.zones.values():
            board.append({"zone": zone.zone_id.value, "state": zone.alert_state.value})
        return board

    def security_score(self) -> float:
        cam = self.cameras.network_health()
        zone_levels = [z.security_level for z in self.estate.zones.values()]
        avg_zone = sum(zone_levels) / len(zone_levels) if zone_levels else 100.0
        return round((cam + avg_zone) / 2, 1)

    def raise_zone_alert(
        self, zone_id, reason: str, severity: Severity, tick: int, level: AlertLevel
    ) -> None:
        zone = self.estate.zone(zone_id)
        zone.raise_alert(level)
        self.alarms.raise_alarm(zone_id, reason, severity, tick)

    def alert_feed(self) -> List[Dict[str, object]]:
        return self.alarms.feed()
