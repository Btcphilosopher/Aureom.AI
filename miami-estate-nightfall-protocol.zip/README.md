# Miami Estate: Nightfall Protocol

A fully modular, deterministic, cooperative luxury-estate security and
raid **simulation game engine**, written in Python 3.11+.

Set on a fictional hypermodern Miami waterfront property in the
mid-2020s, the game is built around one idea: **the house is the game**.
The estate is a living computational system — zones, cameras, sensors,
access control, power, network, lighting, marina, garage, vehicles,
economy and career progression — and every raid event, repair and
upgrade changes how the next night unfolds.

> This is a fictional game/simulation, not real-world security software.
> Nothing in this codebase models, teaches, or enables real-world
> intrusion techniques, weapons, or surveillance deployment. All
> "raid", "threat" and "damage" mechanics are abstract numeric game
> systems operating on a Python data model.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt   # only needed to run the test suite

python -m miami_estate.main       # plays the MIAMI NIGHTFALL demo scenario end-to-end
python -m pytest miami_estate/tests -q
```

`main.py` builds a fictional estate ("Villa Meridian"), assembles a
6-player cooperative roster across all five roles, runs the procedurally
generated **MIAMI NIGHTFALL — 23:47** raid scenario tick by tick,
narrates events/dispatch/resolution as they happen, then prints the
command center, the digital-twin map, and the full end-of-night report
set (damage / security / financial / repair / performance score).

## Architecture

```
miami_estate/
├── core/            engine.py, game_loop.py, simulation.py, state.py
├── estate/          property.py, rooms.py, zones.py, marina.py, garage.py
├── security/        cameras.py, sensors.py, access_control.py, alarms.py, monitoring.py
├── infrastructure/  power.py, network.py, lighting.py, smart_home.py
├── events/          raid_generator.py, incidents.py, scenarios.py
├── ai/              event_ai.py, npc_ai.py, response_ai.py
├── players/         roles.py, player_state.py, cooperation.py
├── vehicles/        cars.py, boats.py, garage.py
├── economy/         budget.py, repairs.py, upgrades.py
├── career/          progression.py, estate_expansion.py
├── ui/              estate_map.py, command_center.py, hud.py
├── multiplayer/     local_session.py
├── tests/           pytest suite covering every subsystem
└── main.py
```

Every module is independently importable and independently testable —
there is no placeholder architecture. `core.state` defines the shared
vocabulary (`SystemStatus`, `AlertLevel`, `SecurityMode`, `DoorState`,
`DamageCategory`, `Severity`) that every subsystem reports through.

## Core game loop

```
DESIGN ESTATE → INSTALL SECURITY SYSTEMS → MONITOR PROPERTY →
DETECT RAID EVENT → IDENTIFY THREAT ZONES → ASSIGN PLAYERS/SYSTEMS →
PROTECT PEOPLE + PROPERTY → RESPOND TO BREACHES → REPAIR DAMAGE →
UPGRADE ESTATE → SURVIVE ESCALATING EVENTS → EXPAND PROPERTY
```

`core.simulation.Simulation` is the single object every subsystem
attaches to; `core.engine.SimulationEngine` runs it to completion and
compiles the end-of-night reports; `core.game_loop.GameLoop` is the thin
driver `main.py` calls.

## Key systems

- **Ten estate zones** (`estate.zones`), each with security level,
  occupancy, camera coverage, access state, alert state and a
  per-category damage profile.
- **Deterministic procedural raid generator** (`events.raid_generator`):
  given a seed, builds an *evolving* three-phase scenario (probe →
  simultaneous multi-zone escalation → infrastructure exploitation),
  not random enemy spawns. Same seed → same scenario, every time.
- **Infrastructure cascade** (`infrastructure.smart_home`): a power
  failure degrades the network, which degrades camera coverage, which
  lowers detection — one system failing makes the whole estate more at
  risk, exactly as sketched in the design brief.
- **Abstracted raid AI** (`ai.event_ai`): a symbolic decision-maker per
  incident (`APPROACH` / `DISTRACT` / `EXPLOIT OPENING` / `CHANGE ROUTE`
  / `RETREAT` / `REGROUP`) that reacts to zone security and player
  presence — never real intrusion tactics.
- **Five cooperative roles** (`players.roles`): Security Operator,
  Estate Manager, Mobile Responder, Technician, Marina Operator — for
  1-8 local players (`multiplayer.local_session`).
- **Autonomous response fleet** (`ai.response_ai`): drones/robots/patrol
  units that self-deploy toward the highest-alert zone.
- **Economy** (`economy.budget/repairs/upgrades`): a real budget ledger,
  repair jobs that consume time/money/materials/engineering capacity,
  and a four-tier upgrade tree from basic cameras to a fully integrated
  smart estate.
- **Career mode** (`career.progression/estate_expansion`): five career
  stages from "Waterfront Starter" to "Ultra-Luxury Smart Estate Owner",
  unlocking guest houses, extra garage bays, an expanded marina, and more.

## Constraints honoured

- Python 3.11+, stdlib-only runtime (pytest only needed for tests)
- Deterministic simulation (seeded RNG throughout)
- Modular architecture matching the specified package layout
- Local-first multiplayer (1-8 players, no network transport required)
- Fictional game environment only — no real-world security, weapons, or
  surveillance instruction anywhere in the codebase
- Abstract game mechanics for raids and damage (0-100 category damage,
  not weapon effectiveness simulation)
- Every system functions end-to-end — no placeholder/stub architecture
