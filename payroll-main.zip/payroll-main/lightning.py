"""
BTCFlowPayroll – Lightning Network payment simulation
"""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Optional

from btcflow_payroll.config import LIGHTNING_MAX_SATS, SIMULATE_FAILURE_RATE
from btcflow_payroll.utils import (
    btc_to_sats, fake_ln_payment_hash, get_logger, sats_to_btc, utcnow,
)

log = get_logger("payments.lightning")


@dataclass
class LNInvoice:
    payment_request: str      # BOLT11 encoded invoice (simulated)
    payment_hash: str
    amount_sats: int
    expiry: int               # Unix timestamp
    description: str

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expiry


@dataclass
class LNPaymentResult:
    success: bool
    payment_hash: Optional[str]
    preimage: Optional[str]
    amount_sats: int
    fee_sats: int
    error: Optional[str] = None
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = utcnow().isoformat()

    @property
    def amount_btc(self) -> float:
        return sats_to_btc(self.amount_sats)


class LightningPaymentEngine:
    """
    Simulates Lightning Network invoice generation and payment.
    
    In production this wraps LND (lnrpc), c-lightning, or Eclair
    via gRPC or REST.
    """

    INVOICE_EXPIRY_SECONDS = 3600      # 1 hour
    BASE_FEE_SATS          = 1        # base routing fee
    FEE_PPM                = 1_000    # 0.1% routing fee (parts-per-million)

    # ── Invoice generation ─────────────────────────────────────────────────────

    def create_invoice(self, amount_sats: int, description: str = "") -> LNInvoice:
        """Generate a BOLT11-compatible invoice (simulated)."""
        if amount_sats > LIGHTNING_MAX_SATS:
            raise ValueError(
                f"Amount {amount_sats} sats exceeds LN max {LIGHTNING_MAX_SATS} sats"
            )

        payment_hash = fake_ln_payment_hash()

        # Realistic-looking BOLT11 prefix
        encoded = (
            f"lnbc{amount_sats}n1p"
            + fake_ln_payment_hash()[:52]
            + "xqfppq"
            + payment_hash[:40]
        )

        invoice = LNInvoice(
            payment_request=encoded,
            payment_hash=payment_hash,
            amount_sats=amount_sats,
            expiry=int(time.time()) + self.INVOICE_EXPIRY_SECONDS,
            description=description,
        )

        log.info(
            "LN invoice created: %d sats | hash=%s… | desc=%s",
            amount_sats, payment_hash[:12], description,
        )
        return invoice

    # ── Payment ────────────────────────────────────────────────────────────────

    async def pay_invoice(self, invoice: LNInvoice) -> LNPaymentResult:
        """Pay a Lightning invoice and return result."""
        if invoice.is_expired:
            return LNPaymentResult(
                success=False, payment_hash=invoice.payment_hash,
                preimage=None, amount_sats=invoice.amount_sats, fee_sats=0,
                error="Invoice expired",
            )

        # Simulate routing latency (20–150 ms — LN is fast!)
        await asyncio.sleep(random.uniform(0.02, 0.15))

        # Simulate failure
        if random.random() < SIMULATE_FAILURE_RATE:
            log.warning("Simulated LN payment failure: hash=%s", invoice.payment_hash[:12])
            return LNPaymentResult(
                success=False, payment_hash=invoice.payment_hash,
                preimage=None, amount_sats=invoice.amount_sats, fee_sats=0,
                error="Route not found (simulated)",
            )

        fee_sats = self.BASE_FEE_SATS + (invoice.amount_sats * self.FEE_PPM // 1_000_000)
        preimage = fake_ln_payment_hash()   # reveal pre-image = proof of payment

        log.info(
            "LN payment settled: %d sats | hash=%s… | fee=%d sats",
            invoice.amount_sats, invoice.payment_hash[:12], fee_sats,
        )

        return LNPaymentResult(
            success=True,
            payment_hash=invoice.payment_hash,
            preimage=preimage,
            amount_sats=invoice.amount_sats,
            fee_sats=fee_sats,
        )

    async def send_to_node(
        self,
        node_pubkey: str,
        amount_btc: float,
        description: str = "",
    ) -> LNPaymentResult:
        """Create invoice for a node and pay it (keysend / pull payment simulation)."""
        sats = btc_to_sats(amount_btc)
        invoice = self.create_invoice(sats, description)
        return await self.pay_invoice(invoice)

    async def batch_send(
        self,
        payments: list[dict],   # [{node_pubkey, amount_btc, label}]
    ) -> list[LNPaymentResult]:
        """Send multiple LN payments concurrently."""
        tasks = [
            self.send_to_node(p["node_pubkey"], p["amount_btc"], p.get("label", ""))
            for p in payments
        ]
        return list(await asyncio.gather(*tasks))
