"""
BTCFlowPayroll – Core payroll engine

Orchestrates:
  1. Payroll run creation
  2. Multi-sig approval gating
  3. Batch payment execution
  4. Payslip generation
  5. Audit logging
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from btcflow_payroll.config import MULTISIG_THRESHOLD, MULTISIG_TOTAL
from btcflow_payroll.models import (
    Approval, Employee, Payment, PaymentMethod,
    PaymentStatus, PayrollRun, PayrollStatus,
)
from btcflow_payroll.multisig import (
    DEMO_APPROVERS, MultiSigWorkflow,
    build_signing_payload, verify_signature,
)
from btcflow_payroll.payments.bitcoin import BitcoinPaymentEngine
from btcflow_payroll.payments.lightning import LightningPaymentEngine
from btcflow_payroll.payments.usdt import USDTPaymentEngine
from btcflow_payroll.payslip import PayslipData, PayslipGenerator
from btcflow_payroll.utils import (
    get_btc_usd_price, get_logger, iso_now, usd_to_btc, utcnow,
)

log = get_logger("payroll")

# Payment engine singletons
_btc = BitcoinPaymentEngine()
_ln  = LightningPaymentEngine()
_usdt = USDTPaymentEngine()
_slip = PayslipGenerator()
_msig = MultiSigWorkflow(MULTISIG_THRESHOLD, MULTISIG_TOTAL)


# ── Payroll creation ──────────────────────────────────────────────────────────

async def create_payroll_run(
    db: AsyncSession,
    label: str,
    employee_ids: list[int],
    notes: str = "",
) -> PayrollRun:
    """
    Create a new payroll run for the given employees.
    Calculates totals and sets status to PENDING (awaiting approval).
    """
    # Load employees
    result = await db.execute(
        select(Employee).where(Employee.id.in_(employee_ids), Employee.is_active == True)
    )
    employees: list[Employee] = result.scalars().all()

    if not employees:
        raise ValueError("No active employees found for given IDs")

    btc_price = await get_btc_usd_price()
    total_usd = sum(e.salary_usd for e in employees)
    total_btc = usd_to_btc(total_usd, btc_price)

    run = PayrollRun(
        label=label,
        total_usd=round(total_usd, 2),
        total_btc=round(total_btc, 8),
        btc_usd_rate=btc_price,
        status=PayrollStatus.PENDING,
        notes=notes,
    )
    db.add(run)
    await db.flush()   # get run.id

    # Create per-employee payment stubs
    for emp in employees:
        amount_crypto = _calc_crypto(emp.salary_usd, emp.payment_preference, btc_price)
        payment = Payment(
            run_id=run.id,
            employee_id=emp.id,
            amount_usd=emp.salary_usd,
            amount_crypto=amount_crypto,
            currency=emp.payment_preference,
            btc_usd_rate=btc_price,
            status=PaymentStatus.PENDING,
        )
        db.add(payment)

    await db.commit()
    await db.refresh(run)

    log.info(
        "Payroll run #%d created | %d employees | $%.2f | rate $%.0f/BTC",
        run.id, len(employees), total_usd, btc_price,
    )
    return run


def _calc_crypto(usd: float, method: str, btc_price: float) -> float:
    """Convert USD salary to the correct crypto amount."""
    if method in (PaymentMethod.BITCOIN, PaymentMethod.LIGHTNING):
        return usd_to_btc(usd, btc_price)
    else:  # USDT – 1:1 with USD
        return round(usd, 2)


# ── Approval ──────────────────────────────────────────────────────────────────

async def add_approval(
    db: AsyncSession,
    run_id: int,
    approver_name: str,
    signature_hex: str,
    public_key_hex: str,
) -> dict:
    """
    Add a multi-sig approval for a payroll run.
    Promotes run to APPROVED if threshold is met.
    """
    run: Optional[PayrollRun] = await db.get(PayrollRun, run_id)
    if run is None:
        raise ValueError(f"Payroll run #{run_id} not found")

    if run.status not in (PayrollStatus.PENDING, PayrollStatus.DRAFT):
        raise ValueError(f"Run #{run_id} status is {run.status} – cannot approve")

    # Verify signature
    payload = build_signing_payload(run_id, run.total_usd, run.label)
    if not verify_signature(public_key_hex, signature_hex, payload):
        raise ValueError("Invalid cryptographic signature")

    # Check for duplicate approver
    existing = await db.execute(
        select(Approval).where(Approval.run_id == run_id, Approval.approver == approver_name)
    )
    if existing.scalar_one_or_none():
        raise ValueError(f"Approver '{approver_name}' has already signed this run")

    approval = Approval(
        run_id=run_id,
        approver=approver_name,
        signature=signature_hex,
        public_key=public_key_hex,
        timestamp=utcnow(),
    )
    db.add(approval)
    await db.flush()

    # Count valid approvals
    approvals_result = await db.execute(
        select(Approval).where(Approval.run_id == run_id)
    )
    all_approvals = approvals_result.scalars().all()
    valid_count = len(all_approvals)   # all stored = valid (verified on insert)

    if valid_count >= MULTISIG_THRESHOLD:
        run.status = PayrollStatus.APPROVED
        log.info(
            "Payroll run #%d APPROVED (%d/%d signatures)",
            run_id, valid_count, MULTISIG_TOTAL,
        )

    await db.commit()
    return {
        "run_id": run_id,
        "approver": approver_name,
        "valid_count": valid_count,
        "threshold": MULTISIG_THRESHOLD,
        "approved": run.status == PayrollStatus.APPROVED,
    }


# ── Payment execution ─────────────────────────────────────────────────────────

async def execute_payroll(db: AsyncSession, run_id: int) -> dict:
    """
    Execute all pending payments for an approved payroll run.
    Returns summary statistics.
    """
    # Load run with payments and employees
    result = await db.execute(
        select(PayrollRun)
        .where(PayrollRun.id == run_id)
        .options(
            selectinload(PayrollRun.payments).selectinload(Payment.employee)
        )
    )
    run: Optional[PayrollRun] = result.scalar_one_or_none()

    if run is None:
        raise ValueError(f"Payroll run #{run_id} not found")

    if run.status != PayrollStatus.APPROVED:
        raise ValueError(
            f"Run #{run_id} must be APPROVED before execution (current: {run.status})"
        )

    run.status = PayrollStatus.EXECUTING
    await db.commit()

    log.info("Executing payroll run #%d | %d payments", run_id, len(run.payments))

    success_count = 0
    fail_count    = 0

    for payment in run.payments:
        if payment.status != PaymentStatus.PENDING:
            continue

        emp = payment.employee
        method = payment.currency

        try:
            if method == PaymentMethod.BITCOIN:
                res = await _btc.send(
                    emp.wallet_address or "1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf8N",  # genesis addr fallback
                    payment.amount_crypto,
                    label=f"{emp.name} | run#{run_id}",
                )
                if res.success:
                    payment.tx_id   = res.txid
                    payment.status  = PaymentStatus.CONFIRMED
                    payment.paid_at = utcnow()
                    success_count  += 1
                else:
                    payment.status    = PaymentStatus.FAILED
                    payment.error_msg = res.error
                    fail_count       += 1

            elif method == PaymentMethod.LIGHTNING:
                res = await _ln.send_to_node(
                    emp.lightning_node or "02778f4a4eb3a2344b9fd8ee72e7ec5f03f803e5",
                    payment.amount_crypto,
                    description=f"{emp.name} | run#{run_id}",
                )
                if res.success:
                    payment.tx_id       = res.payment_hash
                    payment.invoice_ref = res.preimage
                    payment.status      = PaymentStatus.CONFIRMED
                    payment.paid_at     = utcnow()
                    success_count      += 1
                else:
                    payment.status    = PaymentStatus.FAILED
                    payment.error_msg = res.error
                    fail_count       += 1

            elif method in (PaymentMethod.USDT_ERC, PaymentMethod.USDT_TRC):
                addr = emp.usdt_address or (
                    "0x742d35Cc6634C0532925a3b8D4C9C0c7d6F1a1b" if method == PaymentMethod.USDT_ERC
                    else "TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9"
                )
                res = await _usdt.send(addr, payment.amount_crypto, method, label=emp.name)
                if res.success:
                    payment.tx_id   = res.tx_hash
                    payment.status  = PaymentStatus.CONFIRMED
                    payment.paid_at = utcnow()
                    success_count  += 1
                else:
                    payment.status    = PaymentStatus.FAILED
                    payment.error_msg = res.error
                    fail_count       += 1

        except Exception as exc:
            log.error("Payment error for employee %d: %s", emp.id, exc)
            payment.status    = PaymentStatus.FAILED
            payment.error_msg = str(exc)
            fail_count       += 1

        await db.commit()

    # Update run status
    run.status      = PayrollStatus.COMPLETED if fail_count == 0 else PayrollStatus.COMPLETED
    run.executed_at = utcnow()
    await db.commit()

    # Generate payslips
    await _generate_payslips(db, run)

    summary = {
        "run_id":        run_id,
        "total_payments": len(run.payments),
        "success":        success_count,
        "failed":         fail_count,
        "total_usd":      run.total_usd,
        "executed_at":    run.executed_at.isoformat(),
        "status":         run.status,
    }
    log.info("Payroll run #%d completed | %s", run_id, summary)
    return summary


# ── Payslip generation ────────────────────────────────────────────────────────

async def _generate_payslips(db: AsyncSession, run: PayrollRun) -> None:
    """Generate payslips for all confirmed payments in a run."""
    now = iso_now()
    for payment in run.payments:
        emp = payment.employee
        data = PayslipData(
            employee_id=emp.id,
            employee_name=emp.name,
            employee_email=emp.email,
            department=emp.department or "",
            role=emp.role or "",
            run_id=run.id,
            run_label=run.label,
            pay_period=run.created_at.strftime("%B %Y"),
            gross_pay_usd=payment.amount_usd,
            payment_method=payment.currency,
            amount_crypto=payment.amount_crypto,
            crypto_unit=_crypto_unit(payment.currency),
            btc_usd_rate=payment.btc_usd_rate,
            tx_id=payment.tx_id,
            invoice_ref=payment.invoice_ref,
            status=payment.status,
            paid_at=payment.paid_at.isoformat() if payment.paid_at else None,
            generated_at=now,
        )
        _slip.generate(data, pdf=True)


def _crypto_unit(method: str) -> str:
    if method == PaymentMethod.LIGHTNING:
        return "BTC"  # we store BTC, not sats, in the DB
    if method == PaymentMethod.BITCOIN:
        return "BTC"
    return "USDT"


# ── Status helpers ────────────────────────────────────────────────────────────

async def get_run_status(db: AsyncSession, run_id: int) -> dict:
    """Return full status of a payroll run."""
    result = await db.execute(
        select(PayrollRun)
        .where(PayrollRun.id == run_id)
        .options(
            selectinload(PayrollRun.payments).selectinload(Payment.employee),
            selectinload(PayrollRun.approvals),
        )
    )
    run = result.scalar_one_or_none()
    if run is None:
        raise ValueError(f"Run #{run_id} not found")

    return {
        "run_id":        run.id,
        "label":         run.label,
        "status":        run.status,
        "total_usd":     run.total_usd,
        "total_btc":     run.total_btc,
        "btc_rate":      run.btc_usd_rate,
        "created_at":    run.created_at.isoformat(),
        "executed_at":   run.executed_at.isoformat() if run.executed_at else None,
        "approvals": [
            {"approver": a.approver, "ts": a.timestamp.isoformat()}
            for a in run.approvals
        ],
        "approvals_needed": max(0, MULTISIG_THRESHOLD - len(run.approvals)),
        "payments": [
            {
                "employee":  p.employee.name,
                "usd":       p.amount_usd,
                "crypto":    p.amount_crypto,
                "currency":  p.currency,
                "status":    p.status,
                "tx_id":     p.tx_id,
            }
            for p in run.payments
        ],
    }
