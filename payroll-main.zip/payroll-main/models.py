"""
BTCFlowPayroll – ORM Models (SQLAlchemy 2.x async)
"""
from __future__ import annotations
from datetime import datetime
from enum import Enum as PyEnum
from typing import Optional

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Enum, Float,
    ForeignKey, Integer, String, Text, func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


# ── Enumerations ──────────────────────────────────────────────────────────────

class PaymentMethod(str, PyEnum):
    BITCOIN   = "bitcoin"
    LIGHTNING = "lightning"
    USDT_ERC  = "usdt_erc20"
    USDT_TRC  = "usdt_trc20"

class PaymentStatus(str, PyEnum):
    PENDING   = "pending"
    CONFIRMED = "confirmed"
    FAILED    = "failed"

class PayrollStatus(str, PyEnum):
    DRAFT     = "draft"
    PENDING   = "pending"      # awaiting approvals
    APPROVED  = "approved"     # threshold met, ready to execute
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED    = "failed"


# ── Base ──────────────────────────────────────────────────────────────────────

class Base(DeclarativeBase):
    pass


# ── Employee ──────────────────────────────────────────────────────────────────

class Employee(Base):
    __tablename__ = "employees"

    id: Mapped[int]                          = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str]                        = mapped_column(String(120), nullable=False)
    email: Mapped[str]                       = mapped_column(String(200), unique=True, nullable=False)
    department: Mapped[Optional[str]]        = mapped_column(String(80))
    role: Mapped[Optional[str]]              = mapped_column(String(80))

    # Payment details
    payment_preference: Mapped[str]          = mapped_column(
        Enum(PaymentMethod), default=PaymentMethod.BITCOIN, nullable=False
    )
    wallet_address: Mapped[Optional[str]]    = mapped_column(String(200))   # BTC/USDT address
    lightning_node: Mapped[Optional[str]]    = mapped_column(String(200))   # LN node pubkey or LNURL
    usdt_address: Mapped[Optional[str]]      = mapped_column(String(200))   # ERC-20 / TRC-20

    # Salary
    salary_usd: Mapped[float]                = mapped_column(Float, default=0.0)
    is_active: Mapped[bool]                  = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime]             = mapped_column(DateTime, server_default=func.now())

    payments: Mapped[list["Payment"]]        = relationship("Payment", back_populates="employee")


# ── PayrollRun ────────────────────────────────────────────────────────────────

class PayrollRun(Base):
    __tablename__ = "payroll_runs"

    id: Mapped[int]                          = mapped_column(Integer, primary_key=True, index=True)
    label: Mapped[str]                       = mapped_column(String(200), default="")
    created_at: Mapped[datetime]             = mapped_column(DateTime, server_default=func.now())
    executed_at: Mapped[Optional[datetime]]  = mapped_column(DateTime, nullable=True)

    total_usd: Mapped[float]                 = mapped_column(Float, default=0.0)
    total_btc: Mapped[float]                 = mapped_column(Float, default=0.0)
    btc_usd_rate: Mapped[float]              = mapped_column(Float, default=0.0)

    status: Mapped[str]                      = mapped_column(
        Enum(PayrollStatus), default=PayrollStatus.DRAFT, nullable=False
    )
    notes: Mapped[Optional[str]]             = mapped_column(Text)

    payments:  Mapped[list["Payment"]]       = relationship("Payment",  back_populates="run")
    approvals: Mapped[list["Approval"]]      = relationship("Approval", back_populates="run")


# ── Payment ───────────────────────────────────────────────────────────────────

class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int]                          = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int]                      = mapped_column(ForeignKey("payroll_runs.id"), nullable=False)
    employee_id: Mapped[int]                 = mapped_column(ForeignKey("employees.id"), nullable=False)

    amount_usd: Mapped[float]                = mapped_column(Float, default=0.0)
    amount_crypto: Mapped[float]             = mapped_column(Float, default=0.0)
    currency: Mapped[str]                    = mapped_column(Enum(PaymentMethod), nullable=False)
    btc_usd_rate: Mapped[float]              = mapped_column(Float, default=0.0)

    tx_id: Mapped[Optional[str]]             = mapped_column(String(256))
    invoice_ref: Mapped[Optional[str]]       = mapped_column(String(500))
    status: Mapped[str]                      = mapped_column(
        Enum(PaymentStatus), default=PaymentStatus.PENDING, nullable=False
    )
    error_msg: Mapped[Optional[str]]         = mapped_column(Text)
    paid_at: Mapped[Optional[datetime]]      = mapped_column(DateTime, nullable=True)

    run:      Mapped["PayrollRun"]           = relationship("PayrollRun", back_populates="payments")
    employee: Mapped["Employee"]             = relationship("Employee",   back_populates="payments")


# ── Approval ──────────────────────────────────────────────────────────────────

class Approval(Base):
    __tablename__ = "approvals"

    id: Mapped[int]                          = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int]                      = mapped_column(ForeignKey("payroll_runs.id"), nullable=False)
    approver: Mapped[str]                    = mapped_column(String(120), nullable=False)
    signature: Mapped[str]                   = mapped_column(Text, nullable=False)   # hex-encoded ECDSA sig
    public_key: Mapped[str]                  = mapped_column(Text, nullable=False)   # hex-encoded pubkey
    timestamp: Mapped[datetime]              = mapped_column(DateTime, server_default=func.now())

    run: Mapped["PayrollRun"]                = relationship("PayrollRun", back_populates="approvals")
