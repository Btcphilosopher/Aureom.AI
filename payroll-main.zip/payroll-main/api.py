"""
BTCFlowPayroll – FastAPI application
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from btcflow_payroll.config import APP_NAME, APP_VERSION, MULTISIG_THRESHOLD, MULTISIG_TOTAL
from btcflow_payroll.db import get_db, init_db
from btcflow_payroll.models import (
    Approval, Employee, Payment, PaymentStatus, PayrollRun, PayrollStatus,
)
from btcflow_payroll.multisig import DEMO_APPROVERS, build_signing_payload
from btcflow_payroll.payroll import (
    add_approval, create_payroll_run, execute_payroll, get_run_status,
)
from btcflow_payroll.schemas import (
    ApprovalRequest, DemoApproverOut, DemoSignRequest,
    EmployeeCreate, EmployeeOut, ExecuteRequest,
    PayrollCreateRequest, PayrollStatusOut,
)
from btcflow_payroll.utils import get_btc_usd_price, get_logger

log = get_logger("api")

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description="Enterprise Bitcoin & Lightning Network payroll system",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static SPA
STATIC_DIR = Path(__file__).parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.on_event("startup")
async def startup():
    await init_db()
    log.info("%s v%s started", APP_NAME, APP_VERSION)


# ── Router ────────────────────────────────────────────────────────────────────

router = APIRouter(prefix="/api")


# ══════════════════════════════════════════════════════════════════════════════
# EMPLOYEES
# ══════════════════════════════════════════════════════════════════════════════

@router.post("/employees", response_model=EmployeeOut, status_code=201)
async def create_employee(
    payload: EmployeeCreate,
    db: AsyncSession = Depends(get_db),
):
    """Register a new employee."""
    emp = Employee(**payload.model_dump())
    db.add(emp)
    await db.commit()
    await db.refresh(emp)
    return emp


@router.get("/employees", response_model=List[EmployeeOut])
async def list_employees(
    active_only: bool = True,
    db: AsyncSession = Depends(get_db),
):
    """List all employees."""
    q = select(Employee)
    if active_only:
        q = q.where(Employee.is_active == True)
    result = await db.execute(q.order_by(Employee.name))
    return result.scalars().all()


@router.get("/employees/{employee_id}", response_model=EmployeeOut)
async def get_employee(employee_id: int, db: AsyncSession = Depends(get_db)):
    emp = await db.get(Employee, employee_id)
    if not emp:
        raise HTTPException(404, f"Employee {employee_id} not found")
    return emp


@router.delete("/employees/{employee_id}", status_code=204)
async def deactivate_employee(employee_id: int, db: AsyncSession = Depends(get_db)):
    emp = await db.get(Employee, employee_id)
    if not emp:
        raise HTTPException(404, f"Employee {employee_id} not found")
    emp.is_active = False
    await db.commit()


# ══════════════════════════════════════════════════════════════════════════════
# PAYROLL
# ══════════════════════════════════════════════════════════════════════════════

@router.post("/payroll/create", status_code=201)
async def payroll_create(
    payload: PayrollCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create a new payroll run (status=PENDING, awaiting multi-sig approval)."""
    try:
        run = await create_payroll_run(
            db, payload.label, payload.employee_ids, payload.notes or ""
        )
        return {
            "run_id": run.id,
            "label":  run.label,
            "status": run.status,
            "total_usd": run.total_usd,
            "total_btc": run.total_btc,
            "btc_rate":  run.btc_usd_rate,
            "approvals_needed": MULTISIG_THRESHOLD,
        }
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.post("/payroll/approve")
async def payroll_approve(
    payload: ApprovalRequest,
    db: AsyncSession = Depends(get_db),
):
    """Submit a multi-sig approval for a payroll run."""
    try:
        result = await add_approval(
            db,
            payload.run_id,
            payload.approver,
            payload.signature_hex,
            payload.public_key_hex,
        )
        return result
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.post("/payroll/execute")
async def payroll_execute(
    payload: ExecuteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Execute an approved payroll run (broadcast all payments)."""
    try:
        summary = await execute_payroll(db, payload.run_id)
        return summary
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.get("/payroll/runs")
async def list_runs(db: AsyncSession = Depends(get_db)):
    """List all payroll runs with summary."""
    result = await db.execute(
        select(PayrollRun)
        .options(selectinload(PayrollRun.approvals), selectinload(PayrollRun.payments))
        .order_by(PayrollRun.created_at.desc())
    )
    runs = result.scalars().all()
    return [
        {
            "id":              r.id,
            "label":           r.label,
            "status":          r.status,
            "total_usd":       r.total_usd,
            "total_btc":       r.total_btc,
            "approvals":       len(r.approvals),
            "payments":        len(r.payments),
            "created_at":      r.created_at.isoformat(),
            "executed_at":     r.executed_at.isoformat() if r.executed_at else None,
        }
        for r in runs
    ]


@router.get("/payroll/status")
async def payroll_status_latest(db: AsyncSession = Depends(get_db)):
    """Status of the most recent payroll run."""
    result = await db.execute(
        select(PayrollRun).order_by(PayrollRun.created_at.desc()).limit(1)
    )
    run = result.scalar_one_or_none()
    if not run:
        return {"message": "No payroll runs yet"}
    return await get_run_status(db, run.id)


@router.get("/payroll/{run_id}/status")
async def payroll_run_status(run_id: int, db: AsyncSession = Depends(get_db)):
    """Detailed status of a specific payroll run."""
    try:
        return await get_run_status(db, run_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc))


# ══════════════════════════════════════════════════════════════════════════════
# PAYSLIPS
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/payslip/{employee_id}")
async def get_payslip(employee_id: int, run_id: int | None = None, db: AsyncSession = Depends(get_db)):
    """Retrieve the latest (or specific run) payslip for an employee."""
    q = select(Payment).where(Payment.employee_id == employee_id)
    if run_id:
        q = q.where(Payment.run_id == run_id)
    q = q.order_by(Payment.id.desc()).limit(1)

    result = await db.execute(q.options(selectinload(Payment.employee), selectinload(Payment.run)))
    payment = result.scalar_one_or_none()

    if not payment:
        raise HTTPException(404, "No payslip found for this employee")

    # Try to serve PDF first
    pdf_path = Path(f"payslips/payslip_{payment.run_id}_{employee_id}.pdf")
    if pdf_path.exists():
        return FileResponse(str(pdf_path), media_type="application/pdf")

    # Fallback: JSON payslip file
    json_path = Path(f"payslips/payslip_{payment.run_id}_{employee_id}.json")
    if json_path.exists():
        return JSONResponse(json.loads(json_path.read_text()))

    raise HTTPException(404, "Payslip file not generated yet – execute the payroll run first")


# ══════════════════════════════════════════════════════════════════════════════
# UTILITIES / DEMO HELPERS
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/btc-price")
async def btc_price():
    """Current BTC/USD price."""
    price = await get_btc_usd_price()
    return {"btc_usd": price}


@router.get("/multisig/approvers", response_model=List[DemoApproverOut])
async def demo_approvers():
    """
    Return the public keys of pre-seeded demo approvers.
    (Dev/demo endpoint – in production approvers manage their own keys.)
    """
    return [
        DemoApproverOut(name=a.name, public_key_hex=a.public_key_hex())
        for a in DEMO_APPROVERS
    ]


@router.post("/multisig/demo-sign")
async def demo_sign(payload: DemoSignRequest, db: AsyncSession = Depends(get_db)):
    """
    Have a demo approver sign a payroll run (development convenience endpoint).
    In production, signing happens off-server using a hardware wallet or HSM.
    """
    run = await db.get(PayrollRun, payload.run_id)
    if not run:
        raise HTTPException(404, f"Run #{payload.run_id} not found")

    approver = DEMO_APPROVERS[payload.approver_index]
    signing_payload = build_signing_payload(payload.run_id, run.total_usd, run.label)
    sig_hex = approver.sign_hex(signing_payload)

    try:
        result = await add_approval(
            db,
            payload.run_id,
            approver.name,
            sig_hex,
            approver.public_key_hex(),
        )
        return result
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.get("/stats")
async def dashboard_stats(db: AsyncSession = Depends(get_db)):
    """Aggregate stats for dashboard."""
    emp_count = (await db.execute(select(func.count(Employee.id)).where(Employee.is_active == True))).scalar()
    run_count = (await db.execute(select(func.count(PayrollRun.id)))).scalar()
    total_paid = (await db.execute(
        select(func.sum(PayrollRun.total_usd)).where(PayrollRun.status == PayrollStatus.COMPLETED)
    )).scalar() or 0.0
    pending_runs = (await db.execute(
        select(func.count(PayrollRun.id)).where(PayrollRun.status.in_([PayrollStatus.PENDING, PayrollStatus.APPROVED]))
    )).scalar()
    btc_price = await get_btc_usd_price()

    return {
        "employees":    emp_count,
        "total_runs":   run_count,
        "total_paid_usd": round(total_paid, 2),
        "pending_runs": pending_runs,
        "btc_usd":      btc_price,
        "multisig":     f"{MULTISIG_THRESHOLD}-of-{MULTISIG_TOTAL}",
    }


# ── Serve SPA ─────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    spa = STATIC_DIR / "index.html"
    if spa.exists():
        return FileResponse(str(spa))
    return {"name": APP_NAME, "version": APP_VERSION, "docs": "/docs"}


app.include_router(router)
