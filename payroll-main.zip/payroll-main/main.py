"""
BTCFlowPayroll – Application entry point

Usage:
    python main.py                    # run with uvicorn (auto-reload)
    uvicorn btcflow_payroll.api:app   # production
"""
import asyncio
import sys
import uvicorn

from btcflow_payroll.config import APP_NAME, APP_VERSION


def main():
    print(f"""
╔══════════════════════════════════════════════════════════╗
║   ⚡  {APP_NAME} v{APP_VERSION}                        ║
║   Enterprise Bitcoin & Lightning Network Payroll         ║
╚══════════════════════════════════════════════════════════╝

  API Docs  →  http://127.0.0.1:8000/docs
  Dashboard →  http://127.0.0.1:8000/
  ReDoc     →  http://127.0.0.1:8000/redoc

  Multi-sig: 2-of-3 approvals required before execution
""")

    uvicorn.run(
        "btcflow_payroll.api:app",
        host="0.0.0.0",
        port=8000,
        reload="--reload" in sys.argv,
        log_level="info",
    )


if __name__ == "__main__":
    main()
