"""
BTCFlowPayroll – Payslip generation (JSON + PDF via reportlab)
"""
from __future__ import annotations

import json
import os
import textwrap
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from btcflow_payroll.utils import get_logger

log = get_logger("payslip")

PAYSLIP_DIR = Path("payslips")
PAYSLIP_DIR.mkdir(exist_ok=True)


@dataclass
class PayslipData:
    # Employee
    employee_id: int
    employee_name: str
    employee_email: str
    department: str
    role: str

    # Payroll run
    run_id: int
    run_label: str
    pay_period: str           # e.g. "April 2025"

    # Financials
    gross_pay_usd: float
    payment_method: str       # "bitcoin" | "lightning" | "usdt_erc20" | "usdt_trc20"
    amount_crypto: float
    crypto_unit: str          # "BTC" | "SATS" | "USDT"
    btc_usd_rate: float

    # Transaction
    tx_id: Optional[str]
    invoice_ref: Optional[str]
    status: str
    paid_at: Optional[str]
    generated_at: str


class PayslipGenerator:

    # ── JSON payslip ──────────────────────────────────────────────────────────

    def generate_json(self, data: PayslipData) -> dict:
        """Return payslip as a Python dict (also saved to disk)."""
        doc = asdict(data)
        path = PAYSLIP_DIR / f"payslip_{data.run_id}_{data.employee_id}.json"
        path.write_text(json.dumps(doc, indent=2))
        log.info("JSON payslip written: %s", path)
        return doc

    # ── PDF payslip ───────────────────────────────────────────────────────────

    def generate_pdf(self, data: PayslipData) -> Optional[Path]:
        """
        Generate a PDF payslip using reportlab.
        Returns None if reportlab is not installed.
        """
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import mm
            from reportlab.platypus import (
                SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable,
            )
        except ImportError:
            log.warning("reportlab not installed – PDF payslip skipped")
            return None

        path = PAYSLIP_DIR / f"payslip_{data.run_id}_{data.employee_id}.pdf"
        doc  = SimpleDocTemplate(str(path), pagesize=A4, topMargin=20*mm, bottomMargin=20*mm)

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "Title2", parent=styles["Title"],
            fontSize=20, spaceAfter=4, textColor=colors.HexColor("#f7931a"),
        )
        sub_style = ParagraphStyle(
            "Sub", parent=styles["Normal"],
            fontSize=9, textColor=colors.grey,
        )
        heading_style = ParagraphStyle(
            "Heading2", parent=styles["Heading2"],
            fontSize=11, textColor=colors.HexColor("#1a1a2e"),
        )

        # ── Build content ──────────────────────────────────────────────────────
        story = []

        # Header
        story.append(Paragraph("⚡ BTCFlowPayroll", title_style))
        story.append(Paragraph("Enterprise Crypto Payroll System", sub_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#f7931a")))
        story.append(Spacer(1, 6*mm))
        story.append(Paragraph("PAYSLIP", heading_style))
        story.append(Spacer(1, 4*mm))

        # Employee details
        emp_data = [
            ["Employee",   data.employee_name],
            ["Email",      data.employee_email],
            ["Department", data.department or "—"],
            ["Role",       data.role or "—"],
            ["Pay Period", data.pay_period],
        ]
        emp_table = Table(emp_data, colWidths=[45*mm, 130*mm])
        emp_table.setStyle(TableStyle([
            ("FONTNAME",  (0, 0), (-1, -1), "Helvetica"),
            ("FONTSIZE",  (0, 0), (-1, -1), 10),
            ("FONTNAME",  (0, 0), (0, -1),  "Helvetica-Bold"),
            ("TEXTCOLOR", (0, 0), (0, -1),  colors.HexColor("#1a1a2e")),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(emp_table)
        story.append(Spacer(1, 6*mm))
        story.append(Paragraph("Payment Details", heading_style))
        story.append(Spacer(1, 3*mm))

        pay_data = [
            ["Gross Pay (USD)", f"${data.gross_pay_usd:,.2f}"],
            ["Payment Method",  data.payment_method.upper()],
            ["Crypto Amount",   f"{data.amount_crypto:.8f} {data.crypto_unit}"],
            ["BTC/USD Rate",    f"${data.btc_usd_rate:,.2f}"],
            ["Transaction ID",  data.tx_id or data.invoice_ref or "—"],
            ["Status",          data.status.upper()],
            ["Paid At",         data.paid_at or "—"],
        ]
        pay_table = Table(pay_data, colWidths=[55*mm, 120*mm])
        pay_table.setStyle(TableStyle([
            ("FONTNAME",     (0, 0), (-1, -1), "Helvetica"),
            ("FONTSIZE",     (0, 0), (-1, -1), 10),
            ("FONTNAME",     (0, 0), (0, -1),  "Helvetica-Bold"),
            ("BACKGROUND",   (0, 0), (-1, 0),  colors.HexColor("#f7931a")),
            ("TEXTCOLOR",    (0, 0), (-1, 0),  colors.white),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [colors.HexColor("#f9f9f9"), colors.white]),
            ("GRID",         (0, 0), (-1, -1), 0.5, colors.lightgrey),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(pay_table)

        story.append(Spacer(1, 10*mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey))
        story.append(Spacer(1, 3*mm))
        story.append(Paragraph(
            f"Generated: {data.generated_at}  |  Run #{data.run_id}: {data.run_label}",
            sub_style,
        ))
        story.append(Paragraph(
            "This is a digitally generated payslip. All transactions are recorded on-chain.",
            sub_style,
        ))

        doc.build(story)
        log.info("PDF payslip written: %s", path)
        return path

    # ── Combined ──────────────────────────────────────────────────────────────

    def generate(self, data: PayslipData, pdf: bool = True) -> dict:
        """Generate both JSON and (optionally) PDF payslip."""
        result = self.generate_json(data)
        if pdf:
            pdf_path = self.generate_pdf(data)
            result["pdf_path"] = str(pdf_path) if pdf_path else None
        return result
