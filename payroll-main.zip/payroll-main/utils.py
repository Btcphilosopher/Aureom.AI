"""
BTCFlowPayroll – Utilities
"""
from __future__ import annotations

import hashlib
import logging
import random
import string
import time
from datetime import datetime, timezone
from typing import Optional

import httpx

from btcflow_payroll.config import BTC_PRICE_API, LOG_LEVEL, MOCK_BTC_USD

# ── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"btcflow.{name}")


log = get_logger("utils")


# ── BTC Price Feed ────────────────────────────────────────────────────────────

_price_cache: dict[str, float | float] = {"price": MOCK_BTC_USD, "ts": 0.0}
CACHE_TTL = 60  # seconds


async def get_btc_usd_price() -> float:
    """Fetch BTC/USD price with a 60-second cache. Falls back to mock value."""
    now = time.time()
    if now - _price_cache["ts"] < CACHE_TTL:
        return _price_cache["price"]

    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(BTC_PRICE_API)
            resp.raise_for_status()
            price = float(resp.json()["bitcoin"]["usd"])
            _price_cache["price"] = price
            _price_cache["ts"] = now
            log.info("BTC/USD price refreshed: $%.2f", price)
            return price
    except Exception as exc:
        log.warning("BTC price fetch failed (%s); using mock $%.2f", exc, MOCK_BTC_USD)
        return MOCK_BTC_USD


def usd_to_btc(usd: float, btc_price: float) -> float:
    """Convert USD amount to BTC (8 decimal places)."""
    if btc_price <= 0:
        raise ValueError("BTC price must be positive")
    return round(usd / btc_price, 8)


def btc_to_sats(btc: float) -> int:
    """Convert BTC to satoshis."""
    return int(round(btc * 1e8))


def sats_to_btc(sats: int) -> float:
    return round(sats / 1e8, 8)


# ── ID / Hash helpers ─────────────────────────────────────────────────────────

def random_hex(length: int = 32) -> str:
    """Return a random lowercase hex string of given byte length."""
    return hashlib.sha256(
        (str(time.time_ns()) + "".join(random.choices(string.ascii_letters, k=16))).encode()
    ).hexdigest()[:length * 2]


def fake_txid() -> str:
    """Generate a realistic-looking fake Bitcoin transaction ID."""
    return random_hex(32)


def fake_ln_payment_hash() -> str:
    """Generate a fake Lightning payment hash (32-byte hex)."""
    return random_hex(32)


def fake_usdt_txhash() -> str:
    """Generate a fake USDT transaction hash."""
    return "0x" + random_hex(32)


# ── Timestamp helpers ─────────────────────────────────────────────────────────

def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utcnow().isoformat()


# ── Validation ────────────────────────────────────────────────────────────────

def validate_btc_address(address: Optional[str]) -> bool:
    """Minimal BTC address syntax check (length + prefix, not full Base58Check)."""
    if not address:
        return False
    address = address.strip()
    if address.startswith(("1", "3", "bc1")) and 25 <= len(address) <= 62:
        return True
    return False


def validate_eth_address(address: Optional[str]) -> bool:
    """Minimal ERC-20 address check (0x + 38-40 hex chars for checksum flexibility)."""
    if not address:
        return False
    address = address.strip()
    if not address.startswith("0x"):
        return False
    hex_part = address[2:]
    return 38 <= len(hex_part) <= 40 and all(
        c in "0123456789abcdefABCDEF" for c in hex_part
    )


def validate_tron_address(address: Optional[str]) -> bool:
    """Minimal TRC-20 address check."""
    if not address:
        return False
    return address.startswith("T") and len(address) == 34
