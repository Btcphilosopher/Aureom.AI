"""
BTCFlowPayroll – Configuration
"""
from __future__ import annotations
import os

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./btcflow.db")

# ── Multi-sig ─────────────────────────────────────────────────────────────────
MULTISIG_THRESHOLD: int = int(os.getenv("MULTISIG_THRESHOLD", "2"))   # M
MULTISIG_TOTAL: int    = int(os.getenv("MULTISIG_TOTAL", "3"))         # N

# ── BTC Price Feed ────────────────────────────────────────────────────────────
BTC_PRICE_API: str = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
MOCK_BTC_USD: float = 65_000.0   # fallback when API unavailable

# ── Payment simulation ────────────────────────────────────────────────────────
SIMULATE_FAILURE_RATE: float = 0.05          # 5 % simulated failure rate
LIGHTNING_MAX_SATS: int      = 50_000_000   # max sats per LN payment

# ── App ───────────────────────────────────────────────────────────────────────
APP_NAME: str    = "BTCFlowPayroll"
APP_VERSION: str = "1.0.0"
LOG_LEVEL: str   = os.getenv("LOG_LEVEL", "INFO")
