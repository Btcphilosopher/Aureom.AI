"""
BTCFlowPayroll – Multi-signature approval workflow

Uses secp256k1 ECDSA (via the `cryptography` library) to simulate
enterprise multi-sig payroll authorization.

Flow:
  1. CFO / Treasurer creates payroll run (status=DRAFT → PENDING)
  2. N approvers each sign the run_id + amount with their private key
  3. Once M-of-N threshold is met, status → APPROVED
  4. Payroll engine executes
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Optional

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import (
    decode_dss_signature, encode_dss_signature,
)
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature

from btcflow_payroll.config import MULTISIG_THRESHOLD, MULTISIG_TOTAL
from btcflow_payroll.utils import get_logger

log = get_logger("multisig")


# ── Key management ────────────────────────────────────────────────────────────

@dataclass
class ApproverKeyPair:
    name: str
    private_key: ec.EllipticCurvePrivateKey
    public_key: ec.EllipticCurvePublicKey

    def public_key_hex(self) -> str:
        return self.public_key.public_bytes(
            serialization.Encoding.X962,
            serialization.PublicFormat.UncompressedPoint,
        ).hex()

    def sign(self, message: bytes) -> bytes:
        """Return DER-encoded ECDSA signature over SHA-256(message)."""
        return self.private_key.sign(message, ec.ECDSA(hashes.SHA256()))

    def sign_hex(self, message: bytes) -> str:
        return self.sign(message).hex()


def generate_approver_keypair(name: str) -> ApproverKeyPair:
    """Generate a secp256k1 key pair for a named approver."""
    priv = ec.generate_private_key(ec.SECP256K1())
    return ApproverKeyPair(
        name=name,
        private_key=priv,
        public_key=priv.public_key(),
    )


# ── Payload to sign ───────────────────────────────────────────────────────────

def build_signing_payload(run_id: int, total_usd: float, label: str) -> bytes:
    """
    Canonical message that approvers sign.
    JSON-canonicalized, then SHA-256 hashed.
    """
    payload = json.dumps(
        {"run_id": run_id, "total_usd": round(total_usd, 2), "label": label},
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).digest()


# ── Verification ──────────────────────────────────────────────────────────────

def verify_signature(
    public_key_hex: str,
    signature_hex: str,
    message: bytes,
) -> bool:
    """Verify a hex-encoded ECDSA signature against a hex-encoded public key."""
    try:
        pub_bytes = bytes.fromhex(public_key_hex)
        sig_bytes  = bytes.fromhex(signature_hex)

        pub_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256K1(), pub_bytes)
        pub_key.verify(sig_bytes, message, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError, Exception) as exc:
        log.warning("Signature verification failed: %s", exc)
        return False


# ── Multi-sig state machine ───────────────────────────────────────────────────

class MultiSigWorkflow:
    """
    Stateless helper: checks whether a payroll run has enough valid approvals.
    DB persistence is handled in payroll.py / api.py.
    """

    def __init__(
        self,
        threshold: int = MULTISIG_THRESHOLD,
        total: int = MULTISIG_TOTAL,
    ):
        if threshold < 1 or threshold > total:
            raise ValueError(f"Invalid multisig config: {threshold}-of-{total}")
        self.threshold = threshold
        self.total     = total

    def is_approved(self, approvals: list[dict]) -> bool:
        """Return True if valid approval count >= threshold."""
        valid = sum(1 for a in approvals if a.get("valid", True))
        return valid >= self.threshold

    def remaining(self, approvals: list[dict]) -> int:
        valid = sum(1 for a in approvals if a.get("valid", True))
        return max(0, self.threshold - valid)

    def verify_and_count(
        self,
        approvals: list[dict],
        run_id: int,
        total_usd: float,
        label: str,
    ) -> tuple[int, list[str]]:
        """
        Verify signatures in approval records.
        Returns (valid_count, list_of_errors).
        """
        payload  = build_signing_payload(run_id, total_usd, label)
        valid    = 0
        errors: list[str] = []

        for a in approvals:
            if verify_signature(a["public_key"], a["signature"], payload):
                valid += 1
            else:
                errors.append(f"Invalid signature from {a['approver']}")

        return valid, errors


# ── Pre-seeded demo approvers ─────────────────────────────────────────────────
# Generated once at module import; used by example_data.py and tests.

DEMO_APPROVERS: list[ApproverKeyPair] = [
    generate_approver_keypair("Alice (CFO)"),
    generate_approver_keypair("Bob (Treasurer)"),
    generate_approver_keypair("Carol (CEO)"),
]
