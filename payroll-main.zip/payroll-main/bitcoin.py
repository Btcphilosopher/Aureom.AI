"""
BTCFlowPayroll – Bitcoin on-chain payment simulation
"""
from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass
from typing import Optional

from btcflow_payroll.config import SIMULATE_FAILURE_RATE
from btcflow_payroll.utils import fake_txid, get_logger, utcnow, validate_btc_address

log = get_logger("payments.bitcoin")


@dataclass
class BTCPaymentResult:
    success: bool
    txid: Optional[str]
    amount_btc: float
    fee_btc: float
    confirmations: int
    error: Optional[str] = None
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = utcnow().isoformat()


class BitcoinPaymentEngine:
    """
    Simulates Bitcoin on-chain payment broadcasting.
    
    In production this would interface with Bitcoin Core RPC, Electrum,
    or a custody API (e.g., BitGo, Fireblocks).
    """

    # Typical on-chain fee: ~0.0002 BTC (can be dynamic)
    BASE_FEE_BTC = 0.000_05
    CONF_BLOCKS  = 1   # simulate 1-confirmation finality for payroll

    async def send(
        self,
        recipient_address: str,
        amount_btc: float,
        label: str = "",
    ) -> BTCPaymentResult:
        """Broadcast a BTC payment and return the result."""

        # Validation
        if not validate_btc_address(recipient_address):
            log.error("Invalid BTC address: %s", recipient_address)
            return BTCPaymentResult(
                success=False, txid=None,
                amount_btc=amount_btc, fee_btc=0.0, confirmations=0,
                error=f"Invalid BTC address: {recipient_address}",
            )

        if amount_btc <= 0:
            return BTCPaymentResult(
                success=False, txid=None,
                amount_btc=amount_btc, fee_btc=0.0, confirmations=0,
                error="Payment amount must be positive",
            )

        # Simulate network latency (50–300 ms)
        await asyncio.sleep(random.uniform(0.05, 0.30))

        # Simulate occasional failures
        if random.random() < SIMULATE_FAILURE_RATE:
            log.warning("Simulated BTC payment failure for %s", recipient_address)
            return BTCPaymentResult(
                success=False, txid=None,
                amount_btc=amount_btc, fee_btc=0.0, confirmations=0,
                error="Network broadcast failed (simulated)",
            )

        fee = self.BASE_FEE_BTC + (amount_btc * 0.0001)  # small proportional fee
        txid = fake_txid()

        log.info(
            "BTC sent: %.8f BTC → %s…%s | txid=%s | label=%s",
            amount_btc, recipient_address[:8], recipient_address[-4:], txid[:12], label,
        )

        return BTCPaymentResult(
            success=True,
            txid=txid,
            amount_btc=amount_btc,
            fee_btc=round(fee, 8),
            confirmations=self.CONF_BLOCKS,
        )

    async def batch_send(
        self,
        payments: list[dict],          # [{address, amount_btc, label}]
    ) -> list[BTCPaymentResult]:
        """Send multiple BTC payments concurrently."""
        tasks = [
            self.send(p["address"], p["amount_btc"], p.get("label", ""))
            for p in payments
        ]
        return list(await asyncio.gather(*tasks))
