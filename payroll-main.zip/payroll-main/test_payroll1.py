"""
BTCFlowPayroll – Test suite
Run: pytest tests/ -v
"""
from __future__ import annotations

import asyncio
import pytest
import pytest_asyncio

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from btcflow_payroll.models import Base, PaymentMethod, PayrollStatus
from btcflow_payroll.db import init_db
from btcflow_payroll import config

# ── Test database ─────────────────────────────────────────────────────────────
TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()

@pytest_asyncio.fixture(scope="session")
async def engine():
    eng = create_async_engine(TEST_DB_URL, echo=False)
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield eng
    await eng.dispose()

@pytest_asyncio.fixture
async def db(engine):
    factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()


# ── Unit: utils ───────────────────────────────────────────────────────────────

def test_usd_to_btc():
    from btcflow_payroll.utils import usd_to_btc
    assert usd_to_btc(65000, 65000) == 1.0
    assert usd_to_btc(6500, 65000) == 0.1
    with pytest.raises(ValueError):
        usd_to_btc(100, 0)

def test_btc_sats_roundtrip():
    from btcflow_payroll.utils import btc_to_sats, sats_to_btc
    assert btc_to_sats(1.0)   == 100_000_000
    assert sats_to_btc(100_000_000) == 1.0

def test_validate_btc_address():
    from btcflow_payroll.utils import validate_btc_address
    assert validate_btc_address("bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq")
    assert validate_btc_address("1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf8N")
    assert not validate_btc_address("")
    assert not validate_btc_address("notanaddress")

def test_validate_eth_address():
    from btcflow_payroll.utils import validate_eth_address
    assert validate_eth_address("0x742d35Cc6634C0532925a3b8D4C9C0c7d6F1a1b")
    assert not validate_eth_address("0x123")

def test_validate_tron_address():
    from btcflow_payroll.utils import validate_tron_address
    assert validate_tron_address("TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9")
    assert not validate_tron_address("notTRON")


# ── Unit: multi-sig ───────────────────────────────────────────────────────────

def test_multisig_keygen():
    from btcflow_payroll.multisig import generate_approver_keypair
    kp = generate_approver_keypair("TestApprover")
    assert kp.name == "TestApprover"
    assert len(kp.public_key_hex()) > 60

def test_multisig_sign_verify():
    from btcflow_payroll.multisig import (
        generate_approver_keypair, build_signing_payload, verify_signature,
    )
    kp = generate_approver_keypair("Tester")
    payload = build_signing_payload(run_id=42, total_usd=50000.0, label="Test Run")
    sig = kp.sign(payload)
    assert verify_signature(kp.public_key_hex(), sig.hex(), payload)

def test_multisig_bad_signature():
    from btcflow_payroll.multisig import (
        generate_approver_keypair, build_signing_payload, verify_signature,
    )
    kp1 = generate_approver_keypair("A")
    kp2 = generate_approver_keypair("B")
    payload = build_signing_payload(1, 1000.0, "X")
    sig = kp1.sign(payload)
    # kp2's pubkey should not verify kp1's signature
    assert not verify_signature(kp2.public_key_hex(), sig.hex(), payload)

def test_multisig_workflow_threshold():
    from btcflow_payroll.multisig import MultiSigWorkflow
    wf = MultiSigWorkflow(threshold=2, total=3)
    assert not wf.is_approved([{"valid": True}])
    assert wf.is_approved([{"valid": True}, {"valid": True}])
    assert wf.is_approved([{"valid": True}, {"valid": True}, {"valid": True}])


# ── Unit: Bitcoin payment engine ──────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bitcoin_payment_success():
    from btcflow_payroll.payments.bitcoin import BitcoinPaymentEngine
    engine = BitcoinPaymentEngine()
    result = await engine.send("bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq", 0.1)
    # Should be success or simulated failure (5% chance)
    assert result.amount_btc == 0.1
    if result.success:
        assert result.txid and len(result.txid) >= 10
        assert result.fee_btc > 0

@pytest.mark.asyncio
async def test_bitcoin_invalid_address():
    from btcflow_payroll.payments.bitcoin import BitcoinPaymentEngine
    engine = BitcoinPaymentEngine()
    result = await engine.send("INVALID_ADDRESS", 0.1)
    assert not result.success
    assert "Invalid" in result.error

@pytest.mark.asyncio
async def test_bitcoin_zero_amount():
    from btcflow_payroll.payments.bitcoin import BitcoinPaymentEngine
    engine = BitcoinPaymentEngine()
    result = await engine.send("bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq", 0)
    assert not result.success


# ── Unit: Lightning payment engine ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_lightning_invoice_creation():
    from btcflow_payroll.payments.lightning import LightningPaymentEngine
    engine = LightningPaymentEngine()
    invoice = engine.create_invoice(100_000, "Test payment")
    assert invoice.amount_sats == 100_000
    assert invoice.payment_request.startswith("lnbc")
    assert not invoice.is_expired

@pytest.mark.asyncio
async def test_lightning_payment():
    from btcflow_payroll.payments.lightning import LightningPaymentEngine
    engine = LightningPaymentEngine()
    invoice = engine.create_invoice(50_000, "Salary")
    result = await engine.pay_invoice(invoice)
    assert result.amount_sats == 50_000
    # success or simulated failure
    if result.success:
        assert result.preimage is not None

@pytest.mark.asyncio
async def test_lightning_over_limit():
    from btcflow_payroll.payments.lightning import LightningPaymentEngine
    from btcflow_payroll.config import LIGHTNING_MAX_SATS
    engine = LightningPaymentEngine()
    with pytest.raises(ValueError):
        engine.create_invoice(LIGHTNING_MAX_SATS + 1)


# ── Unit: USDT payment engine ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_usdt_erc20_success():
    from btcflow_payroll.payments.usdt import USDTPaymentEngine
    engine = USDTPaymentEngine()
    result = await engine.send_erc20("0x742d35Cc6634C0532925a3b8D4C9C0c7d6F1a1b", 5000.0)
    assert result.network == "ERC-20"
    assert result.amount_usdt == 5000.0

@pytest.mark.asyncio
async def test_usdt_trc20_success():
    from btcflow_payroll.payments.usdt import USDTPaymentEngine
    engine = USDTPaymentEngine()
    result = await engine.send_trc20("TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9", 3000.0)
    assert result.network == "TRC-20"

@pytest.mark.asyncio
async def test_usdt_bad_address():
    from btcflow_payroll.payments.usdt import USDTPaymentEngine
    engine = USDTPaymentEngine()
    result = await engine.send_erc20("INVALID", 1000.0)
    assert not result.success


# ── Integration: payroll workflow ─────────────────────────────────────────────

_emp_counter = 0

@pytest_asyncio.fixture
async def seeded_employees(db):
    """Insert a set of test employees with unique emails per test run."""
    import uuid
    from btcflow_payroll.models import Employee
    tag = uuid.uuid4().hex[:8]
    employees = [
        Employee(
            name=f"Test BTC {tag}", email=f"btc_{tag}@test.com",
            payment_preference=PaymentMethod.BITCOIN,
            wallet_address="bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq",
            salary_usd=5000.0,
        ),
        Employee(
            name=f"Test LN {tag}", email=f"ln_{tag}@test.com",
            payment_preference=PaymentMethod.LIGHTNING,
            lightning_node="03a5e5fa51c3c8b050b1832b434d1b8e4a0e7c9c42b",
            salary_usd=4000.0,
        ),
        Employee(
            name=f"Test USDT {tag}", email=f"usdt_{tag}@test.com",
            payment_preference=PaymentMethod.USDT_ERC,
            usdt_address="0x742d35Cc6634C0532925a3b8D4C9C0c7d6F1a1b",
            salary_usd=3500.0,
        ),
    ]
    for e in employees:
        db.add(e)
    await db.commit()
    for e in employees:
        await db.refresh(e)
    return [e.id for e in employees]


@pytest.mark.asyncio
async def test_full_payroll_workflow(db, seeded_employees):
    """End-to-end: create → approve × 2 → execute."""
    from btcflow_payroll.payroll import (
        create_payroll_run, add_approval, execute_payroll, get_run_status,
    )
    from btcflow_payroll.multisig import (
        DEMO_APPROVERS, build_signing_payload,
    )

    # 1. Create run
    run = await create_payroll_run(db, "Integration Test Run", seeded_employees)
    assert run.id is not None
    assert run.status == PayrollStatus.PENDING

    # 2. First approval
    approver0 = DEMO_APPROVERS[0]
    payload   = build_signing_payload(run.id, run.total_usd, run.label)
    res = await add_approval(
        db, run.id, approver0.name,
        approver0.sign_hex(payload), approver0.public_key_hex(),
    )
    assert res["valid_count"] == 1
    assert not res["approved"]

    # 3. Second approval (threshold met)
    approver1 = DEMO_APPROVERS[1]
    res2 = await add_approval(
        db, run.id, approver1.name,
        approver1.sign_hex(payload), approver1.public_key_hex(),
    )
    assert res2["valid_count"] == 2
    assert res2["approved"]

    # 4. Execute
    summary = await execute_payroll(db, run.id)
    assert summary["total_payments"] == 3
    assert summary["success"] + summary["failed"] == 3

    # 5. Status check
    status = await get_run_status(db, run.id)
    assert status["status"] in (PayrollStatus.COMPLETED,)
    assert len(status["payments"]) == 3


@pytest.mark.asyncio
async def test_duplicate_approver_rejected(db, seeded_employees):
    """Same approver cannot sign twice."""
    from btcflow_payroll.payroll import create_payroll_run, add_approval
    from btcflow_payroll.multisig import DEMO_APPROVERS, build_signing_payload

    run = await create_payroll_run(db, "Dup Test", seeded_employees[:1])
    approver = DEMO_APPROVERS[0]
    payload  = build_signing_payload(run.id, run.total_usd, run.label)

    await add_approval(db, run.id, approver.name, approver.sign_hex(payload), approver.public_key_hex())

    with pytest.raises(ValueError, match="already signed"):
        await add_approval(db, run.id, approver.name, approver.sign_hex(payload), approver.public_key_hex())


@pytest.mark.asyncio
async def test_execute_without_approval_fails(db, seeded_employees):
    """Cannot execute a PENDING (unapproved) run."""
    from btcflow_payroll.payroll import create_payroll_run, execute_payroll

    run = await create_payroll_run(db, "No Approval Test", seeded_employees[:1])
    with pytest.raises(ValueError, match="APPROVED"):
        await execute_payroll(db, run.id)
