"""BTCFlowPayroll – Enterprise Crypto Payroll System"""
__version__ = "1.0.0"
