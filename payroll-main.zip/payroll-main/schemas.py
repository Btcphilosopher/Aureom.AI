"""
BTCFlowPayroll – Pydantic request/response schemas
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field, field_validator


# ── Employee ──────────────────────────────────────────────────────────────────

class EmployeeCreate(BaseModel):
    name:                str               = Field(..., min_length=2, max_length=120)
    email:               str               = Field(..., max_length=200)
    department:          Optional[str]     = None
    role:                Optional[str]     = None
    payment_preference:  str               = "bitcoin"
    wallet_address:      Optional[str]     = None
    lightning_node:      Optional[str]     = None
    usdt_address:        Optional[str]     = None
    salary_usd:          float             = Field(..., gt=0)


class EmployeeOut(BaseModel):
    id:                  int
    name:                str
    email:               str
    department:          Optional[str]
    role:                Optional[str]
    payment_preference:  str
    wallet_address:      Optional[str]
    lightning_node:      Optional[str]
    usdt_address:        Optional[str]
    salary_usd:          float
    is_active:           bool
    created_at:          datetime

    model_config = {"from_attributes": True}


# ── Payroll ───────────────────────────────────────────────────────────────────

class PayrollCreateRequest(BaseModel):
    label:        str           = Field(..., min_length=1, max_length=200)
    employee_ids: list[int]     = Field(..., min_length=1)
    notes:        Optional[str] = None


class ApprovalRequest(BaseModel):
    run_id:        int
    approver:      str
    signature_hex: str   = Field(..., min_length=64)
    public_key_hex: str  = Field(..., min_length=66)


class ExecuteRequest(BaseModel):
    run_id: int


# ── Status / Response ─────────────────────────────────────────────────────────

class PaymentSummary(BaseModel):
    employee:  str
    usd:       float
    crypto:    float
    currency:  str
    status:    str
    tx_id:     Optional[str]


class ApprovalSummary(BaseModel):
    approver: str
    ts:       str


class PayrollStatusOut(BaseModel):
    run_id:           int
    label:            str
    status:           str
    total_usd:        float
    total_btc:        float
    btc_rate:         float
    created_at:       str
    executed_at:      Optional[str]
    approvals:        list[ApprovalSummary]
    approvals_needed: int
    payments:         list[PaymentSummary]


# ── Demo / Approver helpers ───────────────────────────────────────────────────

class DemoApproverOut(BaseModel):
    name:           str
    public_key_hex: str


class DemoSignRequest(BaseModel):
    """Ask the server to sign a run on behalf of a demo approver (dev only)."""
    run_id:         int
    approver_index: int = Field(..., ge=0, le=2)   # 0=Alice, 1=Bob, 2=Carol
