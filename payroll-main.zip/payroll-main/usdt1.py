"""
BTCFlowPayroll – USDT payment simulation (ERC-20 & TRC-20)
"""
from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass
from typing import Optional

from btcflow_payroll.config import SIMULATE_FAILURE_RATE
from btcflow_payroll.models import PaymentMethod
from btcflow_payroll.utils import (
    fake_usdt_txhash, get_logger, utcnow,
    validate_eth_address, validate_tron_address,
)

log = get_logger("payments.usdt")

# USDT contract addresses (mainnet reference)
USDT_ERC20_CONTRACT = "0xdAC17F958D2ee523a2206206994597C13D831ec7"
USDT_TRC20_CONTRACT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"


@dataclass
class USDTPaymentResult:
    success: bool
    tx_hash: Optional[str]
    amount_usdt: float
    network: str                   # "ERC-20" | "TRC-20"
    gas_fee_usd: float
    error: Optional[str] = None
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = utcnow().isoformat()


class USDTPaymentEngine:
    """
    Simulates USDT stablecoin transfers on both Ethereum (ERC-20)
    and TRON (TRC-20) networks.
    
    In production, integrate with:
      - ERC-20: web3.py + Infura/Alchemy
      - TRC-20: tronpy + TronGrid API
    """

    # Approximate gas costs
    ERC20_GAS_USD = 2.50    # ~$2.50 per ERC-20 transfer at moderate gas
    TRC20_GAS_USD = 0.10    # TRON is cheap (~1 TRX ≈ $0.10)

    # Simulated block confirmations
    ERC20_CONFIRMATIONS = 12
    TRC20_CONFIRMATIONS = 20

    async def _simulate_blockchain_delay(self, network: str) -> None:
        """Simulate block confirmation time."""
        if network == "ERC-20":
            await asyncio.sleep(random.uniform(0.08, 0.40))   # ~15s blocks (mocked)
        else:
            await asyncio.sleep(random.uniform(0.03, 0.15))   # ~3s blocks (TRON)

    async def send_erc20(
        self,
        recipient: str,
        amount_usdt: float,
        label: str = "",
    ) -> USDTPaymentResult:
        """Send USDT on Ethereum network."""

        if not validate_eth_address(recipient):
            return USDTPaymentResult(
                success=False, tx_hash=None,
                amount_usdt=amount_usdt, network="ERC-20",
                gas_fee_usd=0.0,
                error=f"Invalid ERC-20 address: {recipient}",
            )

        await self._simulate_blockchain_delay("ERC-20")

        if random.random() < SIMULATE_FAILURE_RATE:
            log.warning("Simulated ERC-20 failure for %s", recipient)
            return USDTPaymentResult(
                success=False, tx_hash=None,
                amount_usdt=amount_usdt, network="ERC-20",
                gas_fee_usd=self.ERC20_GAS_USD,
                error="Transaction reverted (simulated)",
            )

        tx_hash = fake_usdt_txhash()
        log.info(
            "USDT ERC-20 sent: $%.2f → %s…%s | tx=%s | label=%s",
            amount_usdt, recipient[:10], recipient[-4:], tx_hash[:14], label,
        )

        return USDTPaymentResult(
            success=True,
            tx_hash=tx_hash,
            amount_usdt=amount_usdt,
            network="ERC-20",
            gas_fee_usd=self.ERC20_GAS_USD,
        )

    async def send_trc20(
        self,
        recipient: str,
        amount_usdt: float,
        label: str = "",
    ) -> USDTPaymentResult:
        """Send USDT on TRON network."""

        if not validate_tron_address(recipient):
            return USDTPaymentResult(
                success=False, tx_hash=None,
                amount_usdt=amount_usdt, network="TRC-20",
                gas_fee_usd=0.0,
                error=f"Invalid TRC-20 address: {recipient}",
            )

        await self._simulate_blockchain_delay("TRC-20")

        if random.random() < SIMULATE_FAILURE_RATE:
            log.warning("Simulated TRC-20 failure for %s", recipient)
            return USDTPaymentResult(
                success=False, tx_hash=None,
                amount_usdt=amount_usdt, network="TRC-20",
                gas_fee_usd=self.TRC20_GAS_USD,
                error="Bandwidth insufficient (simulated)",
            )

        tx_hash = fake_usdt_txhash()
        log.info(
            "USDT TRC-20 sent: $%.2f → %s…%s | tx=%s | label=%s",
            amount_usdt, recipient[:8], recipient[-4:], tx_hash[:14], label,
        )

        return USDTPaymentResult(
            success=True,
            tx_hash=tx_hash,
            amount_usdt=amount_usdt,
            network="TRC-20",
            gas_fee_usd=self.TRC20_GAS_USD,
        )

    async def send(
        self,
        recipient: str,
        amount_usdt: float,
        network: PaymentMethod,
        label: str = "",
    ) -> USDTPaymentResult:
        """Route to ERC-20 or TRC-20 based on payment method."""
        if network == PaymentMethod.USDT_ERC:
            return await self.send_erc20(recipient, amount_usdt, label)
        elif network == PaymentMethod.USDT_TRC:
            return await self.send_trc20(recipient, amount_usdt, label)
        else:
            raise ValueError(f"Not a USDT payment method: {network}")

    async def batch_send(
        self,
        payments: list[dict],   # [{recipient, amount_usdt, network, label}]
    ) -> list[USDTPaymentResult]:
        """Send multiple USDT payments concurrently."""
        tasks = [
            self.send(p["recipient"], p["amount_usdt"], p["network"], p.get("label", ""))
            for p in payments
        ]
        return list(await asyncio.gather(*tasks))
