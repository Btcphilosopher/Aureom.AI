"""
BTCFlowPayroll – Example seed data

Run:  python -m btcflow_payroll.example_data
"""
from __future__ import annotations

import asyncio

from btcflow_payroll.db import AsyncSessionLocal, init_db
from btcflow_payroll.models import Employee, PaymentMethod

SAMPLE_EMPLOYEES = [
    {
        "name":               "Alice Zhang",
        "email":              "alice@btcflowcorp.com",
        "department":         "Engineering",
        "role":               "Senior Blockchain Engineer",
        "payment_preference": PaymentMethod.BITCOIN,
        "wallet_address":     "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq",
        "salary_usd":         12_000.0,
    },
    {
        "name":               "Bob Nakamoto",
        "email":              "bob@btcflowcorp.com",
        "department":         "Engineering",
        "role":               "Lightning Network Specialist",
        "payment_preference": PaymentMethod.LIGHTNING,
        "lightning_node":     "03a5e5fa51c3c8b050b1832b434d1b8e4a0e7c9c42b3a9f2c5d1e4b6a8c0d2f456",
        "salary_usd":         10_500.0,
    },
    {
        "name":               "Carol DeFi",
        "email":              "carol@btcflowcorp.com",
        "department":         "Finance",
        "role":               "Head of Treasury",
        "payment_preference": PaymentMethod.USDT_ERC,
        "usdt_address":       "0x742d35Cc6634C0532925a3b8D4C9C0c7d6F1a1b",
        "salary_usd":         15_000.0,
    },
    {
        "name":               "Dave Tron",
        "email":              "dave@btcflowcorp.com",
        "department":         "Operations",
        "role":               "Ops Manager",
        "payment_preference": PaymentMethod.USDT_TRC,
        "usdt_address":       "TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9",
        "salary_usd":         9_000.0,
    },
    {
        "name":               "Eve Satoshi",
        "email":              "eve@btcflowcorp.com",
        "department":         "Product",
        "role":               "Product Manager",
        "payment_preference": PaymentMethod.BITCOIN,
        "wallet_address":     "1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2",
        "salary_usd":         11_000.0,
    },
    {
        "name":               "Frank Lightning",
        "email":              "frank@btcflowcorp.com",
        "department":         "DevOps",
        "role":               "Infrastructure Lead",
        "payment_preference": PaymentMethod.LIGHTNING,
        "lightning_node":     "02c3e8e5dbef9b2a7e3b5f1d9c8a4b6c0d2e4f6a8b0c2d4e6f8a0b2c4d6e8f0a2b4",
        "salary_usd":         13_000.0,
    },
]


async def seed():
    await init_db()
    async with AsyncSessionLocal() as db:
        for data in SAMPLE_EMPLOYEES:
            emp = Employee(**data)
            db.add(emp)
        await db.commit()
    print(f"✅ Seeded {len(SAMPLE_EMPLOYEES)} employees")


if __name__ == "__main__":
    asyncio.run(seed())
