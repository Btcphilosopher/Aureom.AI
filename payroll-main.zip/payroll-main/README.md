# ⚡ BTCFlowPayroll

**Enterprise-grade automated payroll system powered by Bitcoin, Lightning Network, and USDT.**

Execute instant global payroll across multiple currencies with cryptographic multi-signature authorization, automated wage slip generation, and a full audit trail — all from a single broadcast command.

---

## Architecture

```
btcflow_payroll/
├── main.py              # Uvicorn entry point
├── config.py            # Environment-driven configuration
├── db.py                # Async SQLAlchemy engine & session factory
├── models.py            # ORM: Employee, PayrollRun, Payment, Approval
├── schemas.py           # Pydantic request/response schemas
├── api.py               # FastAPI application + all REST endpoints
├── payroll.py           # Core payroll engine (create → approve → execute)
├── multisig.py          # ECDSA multi-sig workflow (secp256k1)
├── payslip.py           # JSON + PDF payslip generator
├── utils.py             # BTC price feed, address validators, logging
├── example_data.py      # Seed 6 demo employees
├── payments/
│   ├── bitcoin.py       # On-chain BTC payment engine
│   ├── lightning.py     # Lightning Network invoice + payment engine
│   └── usdt.py          # USDT ERC-20 & TRC-20 payment engine
├── static/
│   └── index.html       # Anglo-futurist SPA dashboard
└── tests/
    └── test_payroll.py  # 21 unit + integration tests
```

---

## Features

| Feature | Details |
|---|---|
| **Multi-currency payroll** | Bitcoin (on-chain), Lightning Network (instant), USDT ERC-20, USDT TRC-20 |
| **Multi-sig authorization** | 2-of-3 ECDSA secp256k1 signatures required before execution |
| **Batch broadcast** | All payments execute concurrently via asyncio.gather |
| **Payslip generation** | JSON + PDF (reportlab) per employee per run |
| **BTC price feed** | Live CoinGecko API with 60-second cache and mock fallback |
| **Audit logging** | Every run, approval, and payment logged with timestamps |
| **REST API** | Full FastAPI with automatic OpenAPI docs at /docs |
| **SPA Dashboard** | Dark Anglo-futurist UI with real-time status |

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Seed example employees (optional)

```bash
python -m btcflow_payroll.example_data
```

This creates 6 employees across all payment methods:
- Alice Zhang — Bitcoin (bc1q...)
- Bob Nakamoto — Lightning Network
- Carol DeFi — USDT ERC-20
- Dave Tron — USDT TRC-20
- Eve Satoshi — Bitcoin
- Frank Lightning — Lightning Network

### 3. Start the server

```bash
python btcflow_payroll/main.py
# or
uvicorn btcflow_payroll.api:app --reload
```

- Dashboard  → http://localhost:8000/
- API Docs   → http://localhost:8000/docs
- ReDoc      → http://localhost:8000/redoc

---

## API Reference

### Employees
```
POST   /api/employees          Register employee
GET    /api/employees          List employees
GET    /api/employees/{id}     Get employee
DELETE /api/employees/{id}     Deactivate employee
```

### Payroll
```
POST /api/payroll/create       Create payroll batch (status: PENDING)
POST /api/payroll/approve      Submit multi-sig approval
POST /api/payroll/execute      Execute approved payroll
GET  /api/payroll/runs         List all runs
GET  /api/payroll/{id}/status  Detailed run status
```

### Utilities
```
GET  /api/btc-price                  Live BTC/USD price
GET  /api/stats                      Dashboard aggregate stats
GET  /api/multisig/approvers         Demo approver public keys
POST /api/multisig/demo-sign         Sign run as a demo approver
GET  /api/payslip/{employee_id}      PDF or JSON payslip
```

---

## Payroll Workflow

```
1. POST /api/payroll/create       run created (status: PENDING)
2. POST /api/multisig/demo-sign x2      (status: APPROVED)
3. POST /api/payroll/execute      payments broadcast (status: COMPLETED)
4. GET  /api/payslip/{id}         PDF payslip per employee
```

### Multi-Sig Config

```bash
MULTISIG_THRESHOLD=2   # approvals required (M)
MULTISIG_TOTAL=3       # total approvers (N)
```

---

## Example: Full Run via cURL

```bash
# 1. Create run
curl -X POST http://localhost:8000/api/payroll/create \
  -H "Content-Type: application/json" \
  -d '{"label": "April 2025", "employee_ids": [1,2,3,4,5,6]}'

# 2. Sign (x2)
curl -X POST http://localhost:8000/api/multisig/demo-sign \
  -H "Content-Type: application/json" \
  -d '{"run_id": 1, "approver_index": 0}'

curl -X POST http://localhost:8000/api/multisig/demo-sign \
  -H "Content-Type: application/json" \
  -d '{"run_id": 1, "approver_index": 1}'

# 3. Execute
curl -X POST http://localhost:8000/api/payroll/execute \
  -H "Content-Type: application/json" \
  -d '{"run_id": 1}'

# 4. Get payslip
curl http://localhost:8000/api/payslip/1 -o payslip.pdf
```

---

## Tests

```bash
pytest btcflow_payroll/tests/ -v
# 21 passed
```

Tests cover: utils, address validation, ECDSA signing/verification, multi-sig threshold logic, BTC/LN/USDT payment engines, full end-to-end payroll workflow, duplicate approver rejection, unauthorized execution prevention.

---

## Configuration

| Variable | Default | Description |
|---|---|---|
| DATABASE_URL | sqlite+aiosqlite:///./btcflow.db | Database connection |
| MULTISIG_THRESHOLD | 2 | Approvals required (M) |
| MULTISIG_TOTAL | 3 | Total approvers (N) |
| LOG_LEVEL | INFO | Logging verbosity |
| SIMULATE_FAILURE_RATE | 0.05 | 5% simulated failure rate |

---

## Production Checklist

- Replace simulated payments with Bitcoin Core RPC, LND gRPC, web3.py
- Remove demo-sign endpoint; approvers sign offline via HSM/hardware wallet
- Switch to PostgreSQL: DATABASE_URL=postgresql+asyncpg://...
- Add JWT/OAuth2 authentication to all endpoints
- Add rate limiting (slowapi)
- KYC/AML hooks before payment execution
- Email PDF payslips via SendGrid/SES

---

*BTCFlowPayroll — Instant. Global. Trustless.*
