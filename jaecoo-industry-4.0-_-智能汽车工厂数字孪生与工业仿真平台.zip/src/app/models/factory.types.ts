export type Language = 'zh' | 'en';

export type FactoryZoneId =
  | 'press_shop'
  | 'body_shop'
  | 'paint_shop'
  | 'battery_plant'
  | 'powertrain'
  | 'general_assembly'
  | 'quality_inspection'
  | 'vehicle_test'
  | 'finished_storage'
  | 'smart_warehouse'
  | 'logistics_yard'
  | 'charging_area'
  | 'utilities'
  | 'energy_centre'
  | 'maintenance'
  | 'administration';

export type RobotState =
  | 'RUNNING'
  | 'IDLE'
  | 'WAITING'
  | 'TOOL_CHANGE'
  | 'FAULT'
  | 'MAINTENANCE'
  | 'EMERGENCY_STOP'
  | 'OFFLINE';

export interface RobotEntity {
  id: string;
  name: string;
  nameZh: string;
  zone: FactoryZoneId;
  cell: string;
  cellZh: string;
  manufacturer: string;
  model: string;
  position: [number, number, number];
  jointAngles: number[]; // 6 axes in degrees
  cycleTimeSec: number;
  targetCycleTimeSec: number;
  temperatureC: number;
  vibrationRms: number; // mm/s
  utilizationPct: number;
  state: RobotState;
  currentTask: string;
  currentTaskZh: string;
  weldPointsCount: number;
  weldsCompleted: number;
  healthScorePct: number;
  operatingHours: number;
  payloadKg: number;
}

export interface StationTool {
  id: string;
  name: string;
  nameZh: string;
  type: 'TORQUE_WRENCH' | 'VISION_SENSOR' | 'LEAK_TESTER' | 'RIVETER' | 'ADHESIVE_GUN';
  targetTorqueNm?: number;
  actualTorqueNm?: number;
  toleranceNm?: number;
  angleDeg?: number;
  status: 'PASS' | 'WARN' | 'FAIL';
  calibrationDate: string;
}

export interface WorkStep {
  step: number;
  title: string;
  titleZh: string;
  detail: string;
  detailZh: string;
  standardSec: number;
  completed: boolean;
}

export interface AssemblyStation {
  id: string;
  number: number;
  name: string;
  nameZh: string;
  line: string;
  workersCount: number;
  robotsCount: number;
  cycleTimeSec: number;
  taktTimeSec: number;
  utilizationPct: number;
  status: 'RUNNING' | 'BLOCKED' | 'STARVED' | 'MAINTENANCE' | 'FAULT';
  currentVin: string | null;
  bufferCapacity: number;
  currentBufferCount: number;
  tools: StationTool[];
  workInstructions: WorkStep[];
  defectCountShift: number;
  operatorName: string;
}

export interface DimensionalPoint {
  feature: string;
  featureZh: string;
  nominalMm: number;
  measuredMm: number;
  deviationMm: number;
  toleranceMm: number;
  status: 'PASS' | 'WARN' | 'FAIL';
}

export interface PaintQualityPoint {
  stage: string;
  stageZh: string;
  thicknessMicron: number;
  nominalMicron: number;
  glossGu: number;
  orangePeelDoi: number;
  defectsCount: number;
  status: 'PASS' | 'FAIL';
}

export interface TraceabilityNode {
  id: string;
  component: string;
  componentZh: string;
  partNumber: string;
  supplier: string;
  batchId: string;
  timestamp: string;
  status: 'PASS' | 'WARN';
}

export interface TorqueRecord {
  toolId: string;
  boltLocation: string;
  boltLocationZh: string;
  targetNm: number;
  actualNm: number;
  angleDeg: number;
  status: 'PASS' | 'FAIL';
  timestamp: string;
}

export interface VisionInspectRecord {
  id: string;
  area: string;
  areaZh: string;
  box: [number, number, number, number]; // [x, y, w, h] %
  confidence: number;
  label: string;
  labelZh: string;
  severity: 'OK' | 'MINOR' | 'CRITICAL';
}

export interface VehicleTwin {
  vin: string;
  orderId: string;
  model: 'JAECOO 7' | 'JAECOO 8' | 'JAECOO J7 PHEV' | 'JAECOO J8 AWD' | 'JAECOO EV';
  powertrain: 'ICE' | 'HEV' | 'PHEV' | 'BEV';
  batteryPackId: string;
  colorName: string;
  colorNameZh: string;
  colorHex: string;
  trim: string;
  trimZh: string;
  destination: string;
  destinationZh: string;
  currentStationId: string;
  currentZone: FactoryZoneId;
  progressPct: number;
  status: 'IN_PRODUCTION' | 'QUALITY_HOLD' | 'REWORK' | 'FINISHED' | 'TESTING';
  dimensionalInspection: DimensionalPoint[];
  paintInspection: PaintQualityPoint[];
  traceability: TraceabilityNode[];
  torqueRecords: TorqueRecord[];
  visionInspections: VisionInspectRecord[];
  startTime: string;
  estimatedFinish: string;
  stageHistory: {
    stage: string;
    stageZh: string;
    status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
    time: string;
  }[];
}

export interface BatteryPackTwin {
  packId: string;
  chemistry: 'NMC 811' | 'LFP Blade' | 'Solid State Preview';
  capacityKwh: number;
  cellConfig: string;
  nominalVoltageV: number;
  measuredVoltageV: number;
  currentA: number;
  maxCellDeviationMv: number;
  insulationResistanceMohm: number;
  avgTempC: number;
  maxTempC: number;
  socPct: number;
  sohPct: number;
  weldIntegrityPct: number;
  bmsFirmware: string;
  batchId: string;
  cells: { id: number; voltageV: number; tempC: number; status: 'NORMAL' | 'WARN' }[];
  status: 'TESTING' | 'PASS' | 'ALERT' | 'ASSEMBLED';
}

export interface PowertrainTwin {
  unitId: string;
  type: 'ICE_2.0TGDI' | 'PHEV_SUPER_HYBRID' | 'BEV_DUAL_MOTOR';
  typeZh: string;
  torqueMaxNm: number;
  testedTorqueNm: number;
  testedPowerKw: number;
  testedRpm: number;
  efficiencyPct: number;
  inverterTempC: number;
  vibrationRms: number;
  testResult: 'PASS' | 'RUNNING' | 'FAIL';
  components: { name: string; nameZh: string; serial: string; status: 'OK' | 'WARN' }[];
}

export interface AGVUnit {
  id: string;
  model: string;
  x: number;
  z: number;
  targetX: number;
  targetZ: number;
  speedMps: number;
  batteryPct: number;
  payloadType: string;
  payloadTypeZh: string;
  status: 'AVAILABLE' | 'MOVING' | 'LOADING' | 'UNLOADING' | 'CHARGING' | 'FAULT';
  destinationName: string;
  destinationNameZh: string;
  missionId: string;
  totalTripsToday: number;
}

export interface WarehouseRack {
  id: string;
  aisle: string;
  capacity: number;
  occupied: number;
  category: string;
  categoryZh: string;
  rfidScansPerHour: number;
  shortageAlert: boolean;
  criticalItem: string;
  criticalItemZh: string;
  stockLevelPct: number;
}

export interface EnergyTelemetry {
  gridImportMw: number;
  solarPvKw: number;
  essDischargeMw: number;
  totalFactoryLoadMw: number;
  peakLoadMw: number;
  dailyConsumptionMwh: number;
  energyCostYuanPerKwh: number;
  energyCostPerVehicleYuan: number;
  co2PerVehicleKg: number;
  waterRecycledPct: number;
  compressedAirPressureBar: number;
  dailyWaterM3: number;
  renewableSharePct: number;
}

export interface PredictiveMaintenanceMachine {
  machineId: string;
  name: string;
  nameZh: string;
  zone: FactoryZoneId;
  zoneZh: string;
  vibrationRmsMmS: number;
  vibrationThresholdMmS: number;
  tempC: number;
  tempThresholdC: number;
  currentA: number;
  operatingHours: number;
  mtbfHours: number;
  rulDays: number; // Remaining Useful Life
  healthScorePct: number;
  status: 'NORMAL' | 'ATTENTION' | 'MAINTENANCE_RECOMMENDED' | 'CRITICAL';
  recommendedAction: string;
  recommendedActionZh: string;
  failureRiskPct: number;
}

export interface IIoTGateway {
  id: string;
  name: string;
  protocol: 'OPC-UA' | 'MQTT' | 'Modbus-TCP' | 'Profinet';
  ip: string;
  connectedNodes: number;
  packetRateMsgS: number;
  latencyMs: number;
  status: 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
  zone: string;
  zoneZh: string;
}

export interface SimulationScenario {
  id: string;
  name: string;
  nameZh: string;
  description: string;
  descriptionZh: string;
  taktTimeSec: number;
  failureMultiplier: number;
  demandVolumeShift: number;
  activeDisruptions: string[];
}

export interface ShiftReport {
  shiftId: string;
  date: string;
  shiftName: string;
  shiftNameZh: string;
  planVolume: number;
  actualVolume: number;
  oee: {
    availability: number;
    performance: number;
    quality: number;
    totalOee: number;
  };
  fpy: number; // First Pass Yield %
  downtimeMinutes: number;
  energyUsedMwh: number;
  scrapRatePct: number;
  topBottleneck: string;
  topBottleneckZh: string;
  criticalAlarms: string[];
  vehiclesProduced: number;
  costPerVehicleYuan: number;
}

export interface FactoryEvent {
  id: string;
  timestamp: string;
  type: 'STATION_ENTER' | 'ROBOT_WELD' | 'ROBOT_FAULT' | 'QUALITY_PASS' | 'QUALITY_DEFECT' | 'BATTERY_TEST' | 'AGV_DISPATCH' | 'MAINTENANCE_ALERT' | 'CHANGE_OVER';
  title: string;
  titleZh: string;
  details: string;
  detailsZh: string;
  severity: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR';
}

export type ViewPerspective = 'EXECUTIVE' | 'ENGINEERING' | 'OPERATOR' | 'MAINTENANCE' | 'LOGISTICS';
