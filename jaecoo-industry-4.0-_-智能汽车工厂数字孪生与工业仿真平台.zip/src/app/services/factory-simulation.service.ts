import { Injectable, signal, computed } from '@angular/core';
import {
  RobotEntity,
  AssemblyStation,
  VehicleTwin,
  BatteryPackTwin,
  PowertrainTwin,
  AGVUnit,
  WarehouseRack,
  EnergyTelemetry,
  PredictiveMaintenanceMachine,
  IIoTGateway,
  SimulationScenario,
  ShiftReport,
  FactoryEvent,
  ViewPerspective
} from '../models/factory.types';

@Injectable({
  providedIn: 'root'
})
export class FactorySimulationService {
  // Clock & Playback
  simSeconds = signal<number>(6 * 3600 + 42 * 60); // 06:42:00 AM
  isPlaying = signal<boolean>(true);
  speedMultiplier = signal<number>(1); // 1, 5, 10, 50, 100
  activePerspective = signal<ViewPerspective>('ENGINEERING');
  selectedObjectId = signal<{ type: 'robot' | 'station' | 'vehicle' | 'agv' | 'machine' | 'rack'; id: string } | null>(null);

  // Time Machine Snapshots (History recording every 10 min)
  historySnapshots = signal<{ timeStr: string; oee: number; fpy: number; uph: number; vehicles: number }[]>([]);

  // Simulation Scenarios
  scenarios: SimulationScenario[] = [
    {
      id: 'NORMAL_PRODUCTION',
      name: '标准精益生产',
      nameZh: '标准精益生产模式',
      description: 'Standard 60s takt time, balanced buffers, continuous AGV flow.',
      descriptionZh: '标准 60秒 节拍设计，工位平衡良好，AGV物流准时化配送 (JIT)。',
      taktTimeSec: 60,
      failureMultiplier: 1.0,
      demandVolumeShift: 480,
      activeDisruptions: []
    },
    {
      id: 'HIGH_DEMAND',
      name: '高负荷超产模式 (+20%)',
      nameZh: '高负荷超产模式 (+20%)',
      description: 'Accelerated takt to 50s, higher line load, tight buffer safety margins.',
      descriptionZh: '产线节拍压缩至 50秒，产线负荷提升20%，考验缓存区与机器人峰值温升。',
      taktTimeSec: 50,
      failureMultiplier: 1.3,
      demandVolumeShift: 576,
      activeDisruptions: ['Higher thermal stress on welding cells']
    },
    {
      id: 'ROBOT_FAILURE',
      name: '焊装机器人偶发故障 (RB-204)',
      nameZh: '焊装机器人偶发故障 (RB-204)',
      description: 'Body Shop RB-204 weld gun servo fault, causing bottleneck ripple.',
      descriptionZh: '焊装车间 RB-204 伺服电机高温报警，导致地板总成焊接减速。',
      taktTimeSec: 60,
      failureMultiplier: 2.5,
      demandVolumeShift: 480,
      activeDisruptions: ['RB-204 Servo Overheat (E-701)', 'Body framing buffer starved']
    },
    {
      id: 'PAINT_DOWNTIME',
      name: '涂装烘烤炉固化超温瓶颈',
      nameZh: '涂装烘烤炉固化超温瓶颈',
      description: 'Paint Shop Booth 02 curing cycle delayed to 78s, stalling upstream skids.',
      descriptionZh: '涂装 2号烘烤区热风风机风压异常，固化周期延长至 78秒，造成前序滑撬堆积。',
      taktTimeSec: 60,
      failureMultiplier: 1.8,
      demandVolumeShift: 480,
      activeDisruptions: ['Curing oven heat exchanger valve sticking']
    },
    {
      id: 'BATTERY_SHORTAGE',
      name: '动力电池模组来料物流延迟',
      nameZh: '动力电池模组来料物流延迟',
      description: 'External supplier cell batch delay 4h, AGV delivery buffer reduced to 1 pack.',
      descriptionZh: '外协电芯到货延误，总装车间 09工位（电池合装）安全库存告急。',
      taktTimeSec: 60,
      failureMultiplier: 1.5,
      demandVolumeShift: 480,
      activeDisruptions: ['Cell batch arrival latency', 'Station 09 low buffer']
    },
    {
      id: 'AGV_FAILURE',
      name: 'AGV 物流小车底盘通讯异常',
      nameZh: 'AGV 物流小车底盘通讯异常',
      description: 'AGV-03 laser LiDAR occlusion in aisle 4, pausing kitting parts transport.',
      descriptionZh: 'AGV-03 激光雷达受遮挡触发保护制动，分装线物料配送暂缓。',
      taktTimeSec: 60,
      failureMultiplier: 1.6,
      demandVolumeShift: 480,
      activeDisruptions: ['AGV-03 Safety stop triggered']
    },
    {
      id: 'POWER_PRICE_SPIKE',
      name: '微电网峰谷电价负荷削峰',
      nameZh: '微电网峰谷电价负荷削峰',
      description: 'Grid electricity price peak at 10:00, factory triggers BESS discharge & HVAC shaving.',
      descriptionZh: '电网处于尖峰电价时段，工厂启动 10MWh 储能电站削峰填谷，降低单车电费。',
      taktTimeSec: 60,
      failureMultiplier: 1.0,
      demandVolumeShift: 480,
      activeDisruptions: ['BESS Peak Shaving active']
    }
  ];

  activeScenario = signal<SimulationScenario>(this.scenarios[0]);

  // What-If Sandbox Parameters
  whatIfTakt = signal<number>(60);
  whatIfBufferMultiplier = signal<number>(1.0);
  whatIfSpeedMultiplier = signal<number>(1.0);
  whatIfWorkerCount = signal<number>(42);

  // Entities
  robots = signal<RobotEntity[]>([]);
  stations = signal<AssemblyStation[]>([]);
  vehicles = signal<VehicleTwin[]>([]);
  finishedVehiclesCount = signal<number>(142);
  batteryPacks = signal<BatteryPackTwin[]>([]);
  powertrains = signal<PowertrainTwin[]>([]);
  agvs = signal<AGVUnit[]>([]);
  warehouseRacks = signal<WarehouseRack[]>([]);
  maintenanceMachines = signal<PredictiveMaintenanceMachine[]>([]);
  iiotGateways = signal<IIoTGateway[]>([]);
  events = signal<FactoryEvent[]>([]);

  // Energy & Environment
  energy = signal<EnergyTelemetry>({
    gridImportMw: 12.4,
    solarPvKw: 2850,
    essDischargeMw: 1.8,
    totalFactoryLoadMw: 15.6,
    peakLoadMw: 18.2,
    dailyConsumptionMwh: 98.4,
    energyCostYuanPerKwh: 0.68,
    energyCostPerVehicleYuan: 412.5,
    co2PerVehicleKg: 86.4,
    waterRecycledPct: 92.4,
    compressedAirPressureBar: 7.2,
    dailyWaterM3: 410,
    renewableSharePct: 29.8
  });

  private timerHandle: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.initEntities();
    this.initHistory();
    this.startSimulationLoop();
  }

  // Computed Properties
  simTimeFormatted = computed(() => {
    const totalSec = this.simSeconds();
    const h = Math.floor((totalSec / 3600) % 24).toString().padStart(2, '0');
    const m = Math.floor((totalSec % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(totalSec % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  });

  currentShift = computed(() => {
    const totalSec = this.simSeconds();
    const hour = (totalSec / 3600) % 24;
    if (hour >= 6 && hour < 14) {
      return { id: 'SHIFT_1', name: '早班 (06:00–14:00)', nameEn: 'Morning Shift (06:00–14:00)' };
    } else if (hour >= 14 && hour < 22) {
      return { id: 'SHIFT_2', name: '中班 (14:00–22:00)', nameEn: 'Afternoon Shift (14:00–22:00)' };
    } else {
      return { id: 'SHIFT_3', name: '夜班 (22:00–06:00)', nameEn: 'Night Shift (22:00–06:00)' };
    }
  });

  // Factory KPIs
  vehiclesInProductionCount = computed(() => this.vehicles().length);

  lineUtilisationPct = computed(() => {
    const st = this.stations();
    if (st.length === 0) return 91.4;
    const avg = st.reduce((acc, cur) => acc + cur.utilizationPct, 0) / st.length;
    return Number(avg.toFixed(1));
  });

  oeeMetrics = computed(() => {
    const scenario = this.activeScenario();
    let avail = 0.942;
    let perf = 0.948;
    const qual = 0.987;

    if (scenario.id === 'ROBOT_FAILURE') {
      avail = 0.865;
      perf = 0.892;
    } else if (scenario.id === 'PAINT_DOWNTIME') {
      perf = 0.884;
    } else if (scenario.id === 'HIGH_DEMAND') {
      perf = 0.978;
      avail = 0.912;
    }

    const total = avail * perf * qual * 100;
    return {
      availability: Number((avail * 100).toFixed(1)),
      performance: Number((perf * 100).toFixed(1)),
      quality: Number((qual * 100).toFixed(1)),
      oee: Number(total.toFixed(1))
    };
  });

  firstPassYieldPct = computed(() => {
    const scenario = this.activeScenario();
    if (scenario.id === 'ROBOT_FAILURE') return 96.8;
    return 98.7;
  });

  currentTaktTimeSec = computed(() => {
    return this.activeScenario().taktTimeSec;
  });

  productionRateUph = computed(() => {
    const takt = this.currentTaktTimeSec();
    const eff = this.oeeMetrics().oee / 100;
    return Math.round((3600 / takt) * eff);
  });

  criticalBottleneckStation = computed(() => {
    const st = this.stations();
    if (st.length === 0) return null;
    let max = st[0];
    for (const s of st) {
      if (s.cycleTimeSec > max.cycleTimeSec) {
        max = s;
      }
    }
    return max;
  });

  robotFleetHealthPct = computed(() => {
    const rbs = this.robots();
    if (rbs.length === 0) return 96.5;
    const avg = rbs.reduce((acc, cur) => acc + cur.healthScorePct, 0) / rbs.length;
    return Number(avg.toFixed(1));
  });

  activeAlarmsCount = computed(() => {
    const rbs = this.robots().filter(r => r.state === 'FAULT' || r.state === 'EMERGENCY_STOP').length;
    const mach = this.maintenanceMachines().filter(m => m.status === 'CRITICAL' || m.status === 'MAINTENANCE_RECOMMENDED').length;
    const agv = this.agvs().filter(a => a.status === 'FAULT').length;
    return rbs + mach + agv;
  });

  // Initialization
  private initEntities() {
    // 1. Robots (16 units)
    const initialRobots: RobotEntity[] = [
      {
        id: 'RB-101',
        name: '冲压上下料机器人 RB-101',
        nameZh: '冲压上下料机器人 RB-101',
        zone: 'press_shop',
        cell: 'Press Line A - Destacker',
        cellZh: 'A冲压线 - 拆垛工位',
        manufacturer: 'KUKA',
        model: 'KR 500 FORTEC',
        position: [-45, 0, -25],
        jointAngles: [12, -45, 60, 0, 45, 10],
        cycleTimeSec: 14.2,
        targetCycleTimeSec: 15.0,
        temperatureC: 48.5,
        vibrationRms: 1.2,
        utilizationPct: 92.4,
        state: 'RUNNING',
        currentTask: 'Transferring roof stamping panel to conveyor',
        currentTaskZh: '抓取车顶外板冲压件放置于出料皮带',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 97.2,
        operatingHours: 4280,
        payloadKg: 380
      },
      {
        id: 'RB-201',
        name: '下车体主焊机器人 RB-201',
        nameZh: '下车体主焊机器人 RB-201',
        zone: 'body_shop',
        cell: 'Floor Underbody Cell 01',
        cellZh: '下车身总成焊接 01工位',
        manufacturer: 'FANUC',
        model: 'M-900iB/700',
        position: [-20, 0, -18],
        jointAngles: [-32, 28, -15, 45, -60, 90],
        cycleTimeSec: 54.8,
        targetCycleTimeSec: 56.0,
        temperatureC: 56.4,
        vibrationRms: 1.8,
        utilizationPct: 94.6,
        state: 'RUNNING',
        currentTask: 'Resistance spot welding front longitudinal beam',
        currentTaskZh: '执行前纵梁与吸能盒电阻中频点焊',
        weldPointsCount: 48,
        weldsCompleted: 36,
        healthScorePct: 94.8,
        operatingHours: 6150,
        payloadKg: 650
      },
      {
        id: 'RB-204',
        name: '侧围合拼焊接机器人 RB-204',
        nameZh: '侧围合拼焊接机器人 RB-204',
        zone: 'body_shop',
        cell: 'Body Side Framing Cell 03',
        cellZh: '主车身总成侧围合拼 03工位',
        manufacturer: 'ABB',
        model: 'IRB 6700-245',
        position: [-10, 0, -18],
        jointAngles: [48, -12, 40, -85, 20, 15],
        cycleTimeSec: 62.4,
        targetCycleTimeSec: 58.0,
        temperatureC: 64.2,
        vibrationRms: 3.4,
        utilizationPct: 97.2,
        state: 'RUNNING',
        currentTask: 'Laser braze welding B-pillar ultra-high strength steel',
        currentTaskZh: '执行B柱热成型钢激光飞行焊 (2000MPa)',
        weldPointsCount: 64,
        weldsCompleted: 42,
        healthScorePct: 82.5,
        operatingHours: 7420,
        payloadKg: 245
      },
      {
        id: 'RB-208',
        name: '车身涂胶密封机器人 RB-208',
        nameZh: '车身涂胶密封机器人 RB-208',
        zone: 'body_shop',
        cell: 'Hemming & Sealing Cell 04',
        cellZh: '车身四门两盖涂胶包边 04工位',
        manufacturer: 'KUKA',
        model: 'KR 210 R2700',
        position: [2, 0, -18],
        jointAngles: [0, -30, 75, 10, -45, 0],
        cycleTimeSec: 46.5,
        targetCycleTimeSec: 50.0,
        temperatureC: 44.1,
        vibrationRms: 0.9,
        utilizationPct: 88.5,
        state: 'RUNNING',
        currentTask: 'Applying structural acoustic polyurethane sealant',
        currentTaskZh: '涂布高强度结构胶与车顶折边阻尼胶',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 98.6,
        operatingHours: 3200,
        payloadKg: 210
      },
      {
        id: 'RB-301',
        name: '电泳清洗抓取机器人 RB-301',
        nameZh: '电泳清洗抓取机器人 RB-301',
        zone: 'paint_shop',
        cell: 'E-Coat Immersion Zone',
        cellZh: '电泳槽出入口滑撬转运',
        manufacturer: 'ABB',
        model: 'IRB 5500',
        position: [-25, 0, 15],
        jointAngles: [-15, 60, -30, 0, 90, 0],
        cycleTimeSec: 58.0,
        targetCycleTimeSec: 60.0,
        temperatureC: 38.2,
        vibrationRms: 1.1,
        utilizationPct: 86.4,
        state: 'RUNNING',
        currentTask: 'Lowering skid into cathodic electrodeposition bath',
        currentTaskZh: '引导车身进入阴极电泳漆槽循环浸润',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 95.0,
        operatingHours: 5120,
        payloadKg: 500
      },
      {
        id: 'RB-304',
        name: '车身面漆静电喷涂机器人 RB-304',
        nameZh: '车身面漆静电喷涂机器人 RB-304',
        zone: 'paint_shop',
        cell: 'Basecoat Paint Booth 02',
        cellZh: '2号色漆自动喷涂静电旋杯站',
        manufacturer: 'Dürr',
        model: 'EcoRP L033',
        position: [-10, 0, 15],
        jointAngles: [25, -40, 50, 120, -30, 45],
        cycleTimeSec: 68.5,
        targetCycleTimeSec: 60.0,
        temperatureC: 42.8,
        vibrationRms: 1.4,
        utilizationPct: 96.8,
        state: 'RUNNING',
        currentTask: 'Applying Obsidian Black metallic basecoat (EcoBell3)',
        currentTaskZh: '高速旋杯雾化喷涂曜石黑金属面漆 (70,000 rpm)',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 91.3,
        operatingHours: 6840,
        payloadKg: 35
      },
      {
        id: 'RB-401',
        name: '电池电芯极耳激光焊接机 RB-401',
        nameZh: '电池电芯极耳激光焊接机 RB-401',
        zone: 'battery_plant',
        cell: 'Module Assembly Station 01',
        cellZh: '模组激光总装 01工位',
        manufacturer: 'TRUMPF / JAECOO',
        model: 'TruLaser Cell 3000',
        position: [35, 0, -25],
        jointAngles: [0, 0, 90, 0, 0, 0],
        cycleTimeSec: 38.2,
        targetCycleTimeSec: 40.0,
        temperatureC: 36.5,
        vibrationRms: 0.6,
        utilizationPct: 93.0,
        state: 'RUNNING',
        currentTask: 'Laser welding aluminum busbar to prismatic cell terminals',
        currentTaskZh: '电芯正负极极耳铝铜汇流排激光精密缝焊',
        weldPointsCount: 192,
        weldsCompleted: 144,
        healthScorePct: 99.1,
        operatingHours: 2100,
        payloadKg: 80
      },
      {
        id: 'RB-405',
        name: '电池上盖自动紧固机器人 RB-405',
        nameZh: '电池上盖自动紧固机器人 RB-405',
        zone: 'battery_plant',
        cell: 'Pack Top Cover Fastening 03',
        cellZh: '电池包上盖螺栓自动拧紧 03工位',
        manufacturer: 'FANUC',
        model: 'CRX-25iA Collaborative',
        position: [48, 0, -25],
        jointAngles: [30, -50, 60, -10, 80, 0],
        cycleTimeSec: 44.0,
        targetCycleTimeSec: 45.0,
        temperatureC: 39.1,
        vibrationRms: 0.8,
        utilizationPct: 89.2,
        state: 'RUNNING',
        currentTask: 'Tightening 36 M6 IP68 sealing bolts with torque check',
        currentTaskZh: '拧紧36颗上盖密封螺栓并采集扭矩角度曲线',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 97.4,
        operatingHours: 3400,
        payloadKg: 25
      },
      {
        id: 'RB-501',
        name: '底盘一体化合装工作站 RB-501',
        nameZh: '底盘一体化合装工作站 RB-501',
        zone: 'general_assembly',
        cell: 'Marriage Station 09',
        cellZh: '总装车间 - 动力底盘一体化合装工位',
        manufacturer: 'KUKA',
        model: 'KR 1000 TITAN',
        position: [15, 0, 0],
        jointAngles: [-10, -20, 45, 0, 65, 0],
        cycleTimeSec: 58.4,
        targetCycleTimeSec: 60.0,
        temperatureC: 51.2,
        vibrationRms: 1.5,
        utilizationPct: 95.2,
        state: 'RUNNING',
        currentTask: 'Automated marriage of battery, powertrain & body shell',
        currentTaskZh: '高精度视觉定位实现车身、动力总成与电池包合装',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 96.0,
        operatingHours: 5800,
        payloadKg: 1000
      },
      {
        id: 'RB-506',
        name: '前后挡风玻璃全自动涂胶机器人 RB-506',
        nameZh: '前后挡风玻璃全自动涂胶机器人 RB-506',
        zone: 'general_assembly',
        cell: 'Glass Installation Station 03',
        cellZh: '总装车间 - 前后挡风玻璃自动涂胶安装',
        manufacturer: 'ABB',
        model: 'IRB 4600',
        position: [-10, 0, 0],
        jointAngles: [15, -35, 55, 45, -70, 0],
        cycleTimeSec: 52.0,
        targetCycleTimeSec: 55.0,
        temperatureC: 41.5,
        vibrationRms: 0.9,
        utilizationPct: 90.1,
        state: 'RUNNING',
        currentTask: 'Applying fast-cure windshield primer and adhesive',
        currentTaskZh: '风挡玻璃全周涂布快固型双组份聚氨酯胶',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 98.2,
        operatingHours: 4100,
        payloadKg: 60
      },
      {
        id: 'RB-508',
        name: '车轮四轮全自动拧紧机器人 RB-508',
        nameZh: '车轮四轮全自动拧紧机器人 RB-508',
        zone: 'general_assembly',
        cell: 'Wheel Assembly Station 07',
        cellZh: '总装车间 - 四轮自动安装拧紧工位',
        manufacturer: 'FANUC',
        model: 'M-710iC/50',
        position: [5, 0, 0],
        jointAngles: [0, 45, -45, 0, 90, 0],
        cycleTimeSec: 48.2,
        targetCycleTimeSec: 50.0,
        temperatureC: 45.3,
        vibrationRms: 1.3,
        utilizationPct: 91.8,
        state: 'RUNNING',
        currentTask: 'Simultaneous 5-bolt fastening per hub (140 Nm)',
        currentTaskZh: '五轴伺服同步拧紧四轮轮毂螺栓 (140±5 Nm)',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 96.5,
        operatingHours: 4900,
        payloadKg: 50
      },
      {
        id: 'RB-601',
        name: '整车间隙面差激光在线测量机器人 RB-601',
        nameZh: '整车间隙面差激光在线测量机器人 RB-601',
        zone: 'quality_inspection',
        cell: 'Vision & Gap Quality Station 11',
        cellZh: '质检车间 - 激光在线间隙平整度检测站',
        manufacturer: 'Perceptron / KUKA',
        model: 'KR CYBERTECH nano',
        position: [28, 0, 15],
        jointAngles: [10, -25, 40, -10, 60, 20],
        cycleTimeSec: 55.6,
        targetCycleTimeSec: 60.0,
        temperatureC: 35.8,
        vibrationRms: 0.5,
        utilizationPct: 93.4,
        state: 'RUNNING',
        currentTask: '3D Optical scanning 42 critical flush & gap coordinates',
        currentTaskZh: '3D蓝光光学扫描全车42处门缝与灯缝面差',
        weldPointsCount: 0,
        weldsCompleted: 0,
        healthScorePct: 99.4,
        operatingHours: 1950,
        payloadKg: 10
      }
    ];
    this.robots.set(initialRobots);

    // 2. Assembly Stations (12 Main General Assembly Stations)
    const initialStations: AssemblyStation[] = [
      {
        id: 'ST-01',
        number: 1,
        name: '内饰底板线束铺设工位',
        nameZh: '内饰底板线束铺设工位',
        line: 'General Assembly Trim Line',
        workersCount: 4,
        robotsCount: 0,
        cycleTimeSec: 56,
        taktTimeSec: 60,
        utilizationPct: 93.3,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000189',
        bufferCapacity: 3,
        currentBufferCount: 2,
        tools: [
          { id: 'TL-101', name: '线束端子插接导通仪', nameZh: '线束端子插接导通仪', type: 'TORQUE_WRENCH', status: 'PASS', calibrationDate: '2026-09-15' }
        ],
        workInstructions: [
          { step: 1, title: 'Retrieve main harness', titleZh: '取出高低压主线束并扫描条码', detail: 'Verify harness part number against vehicle configuration', detailZh: '核对高低压线束总成料号与车辆配置清单', standardSec: 15, completed: true },
          { step: 2, title: 'Layout floor harness', titleZh: '底板线束走向布置与卡扣固定', detail: 'Secure 24 retention clips into body chassis grommets', detailZh: '将24处尼龙卡扣压入底盘钣金定位孔', standardSec: 25, completed: true },
          { step: 3, title: 'Ground terminal torque', titleZh: '搭铁接地板螺栓定扭紧固', detail: 'Torque ground stud to 9.5 Nm with electric driver', detailZh: '使用伺服定扭扳手紧固搭铁螺母至 9.5 Nm', standardSec: 16, completed: false }
        ],
        defectCountShift: 0,
        operatorName: '李伟 / 组长'
      },
      {
        id: 'ST-02',
        number: 2,
        name: '防火墙隔音棉与制动踏板总成',
        nameZh: '防火墙隔音棉与制动踏板总成',
        line: 'General Assembly Trim Line',
        workersCount: 2,
        robotsCount: 1,
        cycleTimeSec: 54,
        taktTimeSec: 60,
        utilizationPct: 90.0,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000188',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-102', name: '踏板支架多轴定扭机', nameZh: '踏板支架多轴定扭机', type: 'TORQUE_WRENCH', targetTorqueNm: 24, actualTorqueNm: 23.8, angleDeg: 180, status: 'PASS', calibrationDate: '2026-09-20' }
        ],
        workInstructions: [
          { step: 1, title: 'Position firewall damping mat', titleZh: '贴合防火墙吸音隔热棉', detail: 'Verify alignment with steering column port', detailZh: '确认隔音棉转向管柱孔位居中对齐', standardSec: 20, completed: true },
          { step: 2, title: 'Fasten brake pedal box', titleZh: '紧固电子制动踏板总成', detail: 'Tighten 4x M8 flanged nuts to 24 Nm', detailZh: '紧固4颗M8法兰螺母至 24 Nm 并记录曲线', standardSec: 34, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '张建军'
      },
      {
        id: 'ST-03',
        number: 3,
        name: '前后挡风玻璃与全景天幕安装',
        nameZh: '前后挡风玻璃与全景天幕安装',
        line: 'General Assembly Trim Line',
        workersCount: 1,
        robotsCount: 2,
        cycleTimeSec: 52,
        taktTimeSec: 60,
        utilizationPct: 86.7,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000187',
        bufferCapacity: 2,
        currentBufferCount: 2,
        tools: [
          { id: 'TL-103', name: '视觉涂胶轨迹在线检测仪', nameZh: '视觉涂胶轨迹在线检测仪', type: 'VISION_SENSOR', status: 'PASS', calibrationDate: '2026-09-28' }
        ],
        workInstructions: [
          { step: 1, title: 'Plasma clean glass edge', titleZh: '玻璃边框等离子清洗活化', detail: 'Run atmospheric plasma nozzle along ceramic frit', detailZh: '等离子喷枪沿黑边涂层均匀活化表面', standardSec: 18, completed: true },
          { step: 2, title: 'Robot auto-glazing', titleZh: '机器人自动涂胶并精准抓取贴合', detail: 'ABB robot presses glass at 120N until adhesive bead sets', detailZh: '机器人以 120N 压力贴合玻璃，胶条连续无断胶', standardSec: 34, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '王强'
      },
      {
        id: 'ST-04',
        number: 4,
        name: '仪表板 IP 总成一体化抓取合装',
        nameZh: '仪表板 IP 总成一体化抓取合装',
        line: 'General Assembly Trim Line',
        workersCount: 2,
        robotsCount: 1,
        cycleTimeSec: 58,
        taktTimeSec: 60,
        utilizationPct: 96.7,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000186',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-104', name: '仪表板横梁伺服拧紧枪', nameZh: '仪表板横梁伺服拧紧枪', type: 'TORQUE_WRENCH', targetTorqueNm: 42, actualTorqueNm: 41.8, angleDeg: 120, status: 'PASS', calibrationDate: '2026-09-22' }
        ],
        workInstructions: [
          { step: 1, title: 'Retrieve IP assembly from AGV', titleZh: '从AGV载具对接抓取仪表板总成', detail: 'Verify HUD and 14.8-inch screen specs', detailZh: '核对HUD抬头显示与14.8吋中控车机配置', standardSec: 20, completed: true },
          { step: 2, title: 'Align and torque crossmember', titleZh: '机械手导引旋入并紧固两侧立柱螺栓', detail: 'Fasten 4x M10 structural bolts to 42 Nm', detailZh: '紧固两侧A柱承载螺栓至 42 Nm，角度校验通过', standardSec: 38, completed: true }
        ],
        defectCountShift: 1,
        operatorName: '陈磊'
      },
      {
        id: 'ST-05',
        number: 5,
        name: '全车前后排座椅与中央扶手箱安装',
        nameZh: '全车前后排座椅与中央扶手箱安装',
        line: 'General Assembly Trim Line',
        workersCount: 3,
        robotsCount: 1,
        cycleTimeSec: 55,
        taktTimeSec: 60,
        utilizationPct: 91.7,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000185',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-105', name: '座椅滑轨多轴定扭机', nameZh: '座椅滑轨多轴定扭机', type: 'TORQUE_WRENCH', targetTorqueNm: 45, actualTorqueNm: 45.2, angleDeg: 160, status: 'PASS', calibrationDate: '2026-09-18' }
        ],
        workInstructions: [
          { step: 1, title: 'Mount front ventilated seats', titleZh: '机械臂辅助吊装前排通风加热座椅', detail: 'Plug in side airbag & heating harnesses', detailZh: '连接侧气囊、座椅加热通风及电动调节线束', standardSec: 25, completed: true },
          { step: 2, title: 'Torque floor seat rail bolts', titleZh: '定扭紧固底板4处滑轨螺栓 (45 Nm)', detail: 'Record torque angle curve into MES', detailZh: '四点同步定扭紧固，数据实时上传MES系统', standardSec: 30, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '刘志成'
      },
      {
        id: 'ST-06',
        number: 6,
        name: '四门总成对接安装与间隙初调',
        nameZh: '四门总成对接安装与间隙初调',
        line: 'General Assembly Door Line',
        workersCount: 4,
        robotsCount: 0,
        cycleTimeSec: 57,
        taktTimeSec: 60,
        utilizationPct: 95.0,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000184',
        bufferCapacity: 2,
        currentBufferCount: 2,
        tools: [
          { id: 'TL-106', name: '门铰链电动扭矩扳手', nameZh: '门铰链电动扭矩扳手', type: 'TORQUE_WRENCH', targetTorqueNm: 32, actualTorqueNm: 31.9, angleDeg: 95, status: 'PASS', calibrationDate: '2026-09-25' }
        ],
        workInstructions: [
          { step: 1, title: 'Door subassembly transfer', titleZh: '门分装线输送带对接四门总成', detail: 'Check door seal rubber weatherstrip continuity', detailZh: '检查四门双层隔音密封条无扭曲卡接牢固', standardSec: 22, completed: true },
          { step: 2, title: 'Hinge bolt fastening & gap gauge', titleZh: '铰链螺栓紧固与电子塞尺面差初检', detail: 'Tighten upper/lower hinges to 32 Nm', detailZh: '拧紧上下铰链螺栓至 32 Nm，确保面差在 ±0.5mm 范围内', standardSec: 35, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '赵晓东'
      },
      {
        id: 'ST-07',
        number: 7,
        name: '四轮制动盘与车轮自动拧紧',
        nameZh: '四轮制动盘与车轮自动拧紧',
        line: 'General Assembly Chassis Line',
        workersCount: 2,
        robotsCount: 2,
        cycleTimeSec: 48,
        taktTimeSec: 60,
        utilizationPct: 80.0,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000183',
        bufferCapacity: 3,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-107', name: '五轴伺服轮毂螺栓拧紧机', nameZh: '五轴伺服轮毂螺栓拧紧机', type: 'TORQUE_WRENCH', targetTorqueNm: 140, actualTorqueNm: 140.4, angleDeg: 360, status: 'PASS', calibrationDate: '2026-09-29' }
        ],
        workInstructions: [
          { step: 1, title: 'Wheel rim alignment', titleZh: '视觉对中轮毂中心孔与刹车盘定位销', detail: 'Automated optical centering', detailZh: '光学传感器识别PCD节圆与气门嘴朝向', standardSec: 18, completed: true },
          { step: 2, title: '5-lug nut simultaneous torquing', titleZh: '机器人五轴同步拧紧 140 Nm', detail: 'Verify final torque window (135 - 145 Nm)', detailZh: '五轴同步加载至 140 Nm，100%防错防漏拧', standardSec: 30, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '孙浩'
      },
      {
        id: 'ST-08',
        number: 8,
        name: '全车制动液/冷却液/制冷剂真空加注',
        nameZh: '全车制动液/冷却液/制冷剂真空加注',
        line: 'General Assembly Fluid Line',
        workersCount: 2,
        robotsCount: 0,
        cycleTimeSec: 51,
        taktTimeSec: 60,
        utilizationPct: 85.0,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000182',
        bufferCapacity: 2,
        currentBufferCount: 2,
        tools: [
          { id: 'TL-108', name: '真空加注泄漏率监测枪', nameZh: '真空加注泄漏率监测枪', type: 'LEAK_TESTER', status: 'PASS', calibrationDate: '2026-09-27' }
        ],
        workInstructions: [
          { step: 1, title: 'Vacuum evacuation test', titleZh: '管路抽真空保压气密性测试 (-95 kPa)', detail: 'Hold 15s to confirm leak rate < 0.5 mbar/s', detailZh: '保压15秒确认回路泄漏率小于 0.5 mbar/s', standardSec: 25, completed: true },
          { step: 2, title: 'Quantitative fluid injection', titleZh: '定量加注DOT4制动液与乙二醇冷却液', detail: 'Fill battery thermal loop and motor cooling', detailZh: '加注动力电池冷却液回路并自动排出微气泡', standardSec: 26, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '马洪涛'
      },
      {
        id: 'ST-09',
        number: 9,
        name: '动力总成与动力电池一体化底盘合装 (Marriage)',
        nameZh: '动力总成与动力电池一体化底盘合装 (Marriage)',
        line: 'General Assembly Marriage Line',
        workersCount: 3,
        robotsCount: 2,
        cycleTimeSec: 59,
        taktTimeSec: 60,
        utilizationPct: 98.3,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000181',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-109', name: '底盘电池合装大扭矩多轴群', nameZh: '底盘电池合装大扭矩多轴群', type: 'TORQUE_WRENCH', targetTorqueNm: 95, actualTorqueNm: 94.6, angleDeg: 240, status: 'PASS', calibrationDate: '2026-09-30' }
        ],
        workInstructions: [
          { step: 1, title: 'AGV battery pack docking', titleZh: 'AGV重载小车精确定位托举电池包与副车架', detail: 'Vision-guided ±0.2mm precision alignment', detailZh: '3D视觉引导，托盘以 ±0.2mm 精度对准底盘定位销', standardSec: 24, completed: true },
          { step: 2, title: '18-point chassis fastening', titleZh: '18轴自动拧紧机同步紧固底盘主结构螺栓', detail: 'Torque 18x M12 bolts to 95 Nm with angle audit', detailZh: '18颗M12高强螺栓同步定扭紧固至 95 Nm', standardSec: 35, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '周鹏 / 工艺工程师'
      },
      {
        id: 'ST-10',
        number: 10,
        name: '高压电安全测试与整车低压通电',
        nameZh: '高压电安全测试与整车低压通电',
        line: 'General Assembly Electrical Line',
        workersCount: 2,
        robotsCount: 0,
        cycleTimeSec: 53,
        taktTimeSec: 60,
        utilizationPct: 88.3,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000180',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-110', name: '高压绝缘耐压综合测试仪', nameZh: '高压绝缘耐压综合测试仪', type: 'LEAK_TESTER', status: 'PASS', calibrationDate: '2026-10-01' }
        ],
        workInstructions: [
          { step: 1, title: 'HV insulation & equipotential check', titleZh: '高压回路5000V绝缘耐压与等电位跨接阻抗', detail: 'Confirm insulation resistance > 100 MΩ', detailZh: '确认高压正负极对地绝缘电阻大于 500 MΩ', standardSec: 28, completed: true },
          { step: 2, title: '12V power-on and wake-up', titleZh: '12V蓄电池上电与全车网络唤醒', detail: 'Check CAN-FD and Automotive Ethernet link', detailZh: '唤醒域控制器，检查以太网通信正常', standardSec: 25, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '杨明'
      },
      {
        id: 'ST-11',
        number: 11,
        name: '整车软件刷写与 ADAS 智驾传感器标定 (OTA/EOL)',
        nameZh: '整车软件刷写与 ADAS 智驾传感器标定 (OTA/EOL)',
        line: 'General Assembly Software Line',
        workersCount: 2,
        robotsCount: 1,
        cycleTimeSec: 64,
        taktTimeSec: 60,
        utilizationPct: 106.7,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000179',
        bufferCapacity: 3,
        currentBufferCount: 3,
        tools: [
          { id: 'TL-111', name: '高通/英伟达双域控高速刷写台', nameZh: '高通/英伟达双域控高速刷写台', type: 'LEAK_TESTER', status: 'PASS', calibrationDate: '2026-09-26' }
        ],
        workInstructions: [
          { step: 1, title: 'High-speed firmware flashing', titleZh: '千兆以太网高速灌装座舱与智驾固件 (v4.2.0)', detail: 'Flash Cockpit IVI, VCU, BMS and ADAS images', detailZh: '并行刷写座舱系统、整车控制器及智能驾驶固件', standardSec: 36, completed: true },
          { step: 2, title: 'Camera & radar optical target calibration', titleZh: '前视双目相机与毫米波雷达动态靶标校准', detail: 'Zero-point calibration against laser chart', detailZh: '激光投靶校准相机内参及雷达俯仰角度', standardSec: 28, completed: true }
        ],
        defectCountShift: 2,
        operatorName: '郭峰 / 软件标定师'
      },
      {
        id: 'ST-12',
        number: 12,
        name: '终检下线与激光间隙动态路试前检',
        nameZh: '终检下线与激光间隙动态路试前检',
        line: 'General Assembly Inspection Line',
        workersCount: 3,
        robotsCount: 1,
        cycleTimeSec: 55,
        taktTimeSec: 60,
        utilizationPct: 91.7,
        status: 'RUNNING',
        currentVin: 'JCO-2026-000178',
        bufferCapacity: 2,
        currentBufferCount: 1,
        tools: [
          { id: 'TL-112', name: '全自动车轮转鼓四轮定位仪', nameZh: '全自动车轮转鼓四轮定位仪', type: 'VISION_SENSOR', status: 'PASS', calibrationDate: '2026-10-02' }
        ],
        workInstructions: [
          { step: 1, title: 'Dynamic roll & brake test', titleZh: '转鼓试验台制动性能与最高车速动态检测', detail: 'Verify ABS/ESP trigger and regenerative braking', detailZh: '测试四轮制动力分配、动能回收及ABS干预', standardSec: 30, completed: true },
          { step: 2, title: 'Final cosmetic & gap sign-off', titleZh: '全车外观与漆膜面差终检确认签单', detail: 'Generate factory digital birth certificate', detailZh: '核签下线，生成整车数字化出厂合格孪生档案', standardSec: 25, completed: true }
        ],
        defectCountShift: 0,
        operatorName: '徐敏 / 质检主管'
      }
    ];
    this.stations.set(initialStations);

    // 3. Vehicles in Production (Active WIP Queue)
    const initialVehicles: VehicleTwin[] = [
      {
        vin: 'JCO-2026-000184',
        orderId: 'ORD-EU-8841',
        model: 'JAECOO J7 PHEV',
        powertrain: 'PHEV',
        batteryPackId: 'BAT-2026-90412',
        colorName: 'Obsidian Black',
        colorNameZh: '曜石黑 (金属面漆)',
        colorHex: '#18181b',
        trim: 'Ultra Prestige AWD',
        trimZh: '四驱旗舰版',
        destination: 'Germany / Frankfurt Hub',
        destinationZh: '欧洲 / 德国法兰克福分拨中心',
        currentStationId: 'ST-06',
        currentZone: 'general_assembly',
        progressPct: 50,
        status: 'IN_PRODUCTION',
        dimensionalInspection: [
          { feature: 'Front Left Door Gap', featureZh: '左前门前缝间隙', nominalMm: 3.5, measuredMm: 3.62, deviationMm: 0.12, toleranceMm: 0.5, status: 'PASS' },
          { feature: 'Front Right Door Gap', featureZh: '右前门前缝间隙', nominalMm: 3.5, measuredMm: 3.48, deviationMm: -0.02, toleranceMm: 0.5, status: 'PASS' },
          { feature: 'Engine Hood Flushness', featureZh: '发动机机盖平整面差', nominalMm: 0.0, measuredMm: 0.18, deviationMm: 0.18, toleranceMm: 0.4, status: 'PASS' },
          { feature: 'Tailgate Left Gap', featureZh: '后尾门左侧缝隙', nominalMm: 4.0, measuredMm: 4.15, deviationMm: 0.15, toleranceMm: 0.6, status: 'PASS' },
          { feature: 'Roof Beam Alignment', featureZh: '车顶横梁纵向平行度', nominalMm: 0.0, measuredMm: -0.08, deviationMm: -0.08, toleranceMm: 0.3, status: 'PASS' },
          { feature: 'A-Pillar Windshield Step', featureZh: 'A柱风挡玻璃阶差', nominalMm: 1.2, measuredMm: 1.25, deviationMm: 0.05, toleranceMm: 0.3, status: 'PASS' }
        ],
        paintInspection: [
          { stage: 'E-Coat (ED Primer)', stageZh: '阴极电泳底漆', thicknessMicron: 21.4, nominalMicron: 20.0, glossGu: 65, orangePeelDoi: 88, defectsCount: 0, status: 'PASS' },
          { stage: 'Primer Surfacer', stageZh: '中涂底漆', thicknessMicron: 34.8, nominalMicron: 35.0, glossGu: 78, orangePeelDoi: 90, defectsCount: 0, status: 'PASS' },
          { stage: 'Basecoat Black', stageZh: '色漆层 (曜石黑)', thicknessMicron: 16.5, nominalMicron: 15.0, glossGu: 88, orangePeelDoi: 92, defectsCount: 0, status: 'PASS' },
          { stage: '2K High-Gloss Clearcoat', stageZh: '双组份高光清漆', thicknessMicron: 48.2, nominalMicron: 45.0, glossGu: 96, orangePeelDoi: 95, defectsCount: 0, status: 'PASS' }
        ],
        traceability: [
          { id: 'TR-01', component: 'Battery Pack 34kWh', componentZh: '34kWh 超能混动电池包', partNumber: 'JCO-BAT-PHEV-34', supplier: 'JAECOO Power Systems (Wuhu)', batchId: 'BAT-2609-B12', timestamp: '06:12:40', status: 'PASS' },
          { id: 'TR-02', component: '1.5TGDI Hybrid Dedicated Engine', componentZh: '第五代 1.5TGDI 混动专用发动机', partNumber: 'JCO-ENG-15TGDI-H', supplier: 'ACTECO Powertrain', batchId: 'ENG-2609-44A', timestamp: '05:48:15', status: 'PASS' },
          { id: 'TR-03', component: '3-DHT Hybrid Transmission', componentZh: '三挡超级电混 DHT 变速箱', partNumber: 'JCO-DHT-3SP', supplier: 'JAECOO E-Drive Corp', batchId: 'DHT-2609-18', timestamp: '05:52:30', status: 'PASS' },
          { id: 'TR-04', component: 'Cockpit Domain Controller 8155', componentZh: '高通8155智能座舱域控制器', partNumber: 'JCO-ECU-CDC8155', supplier: 'Neusoft / JAECOO Auto', batchId: 'ECU-2608-99K', timestamp: '06:22:10', status: 'PASS' },
          { id: 'TR-05', component: 'Brembo Front Brake Calipers', componentZh: '前轮四活塞通风制动卡钳', partNumber: 'JCO-BRK-F4P', supplier: 'Brembo Automotive', batchId: 'BRK-2609-02', timestamp: '06:30:45', status: 'PASS' }
        ],
        torqueRecords: [
          { toolId: 'TL-104', boltLocation: 'Instrument Panel Crossmember LH', boltLocationZh: '仪表板横梁左侧主安装螺栓', targetNm: 42.0, actualNm: 41.8, angleDeg: 121, status: 'PASS', timestamp: '06:32:10' },
          { toolId: 'TL-105', boltLocation: 'Driver Seat Front Inboard Rail', boltLocationZh: '主驾座椅前内侧固定螺栓', targetNm: 45.0, actualNm: 45.3, angleDeg: 162, status: 'PASS', timestamp: '06:38:40' },
          { toolId: 'TL-106', boltLocation: 'Front Left Door Upper Hinge', boltLocationZh: '左前门上铰链定位螺栓', targetNm: 32.0, actualNm: 31.9, angleDeg: 94, status: 'PASS', timestamp: '06:41:20' }
        ],
        visionInspections: [
          { id: 'VIS-01', area: 'Front Left Fender Gap', areaZh: '左前翼子板与前门缝隙', box: [22, 45, 14, 28], confidence: 0.992, label: 'Gap Nominal (3.6mm)', labelZh: '间隙正常 (3.6mm)', severity: 'OK' },
          { id: 'VIS-02', area: 'A-Pillar Windshield Bead', areaZh: 'A柱玻璃密封胶条连续性', box: [38, 20, 18, 30], confidence: 0.988, label: 'Continuous Seal Bead', labelZh: '胶条饱满连续', severity: 'OK' },
          { id: 'VIS-03', area: 'Roof Paint Specular Reflection', areaZh: '车顶镜面反射瑕疵扫描', box: [42, 10, 32, 25], confidence: 0.995, label: 'Zero Defect Clean', labelZh: '无尘无橘皮瑕疵', severity: 'OK' }
        ],
        startTime: '05:30:00',
        estimatedFinish: '07:15:00',
        stageHistory: [
          { stage: 'Press Shop', stageZh: '冲压成型', status: 'COMPLETED', time: '05:30:12' },
          { stage: 'Body Shop', stageZh: '焊装车身', status: 'COMPLETED', time: '05:52:45' },
          { stage: 'Paint Shop', stageZh: '涂装防腐', status: 'COMPLETED', time: '06:18:20' },
          { stage: 'General Assembly', stageZh: '总装装配', status: 'IN_PROGRESS', time: '06:22:00' },
          { stage: 'Quality Inspection', stageZh: '质检路试', status: 'PENDING', time: '--' },
          { stage: 'Finished Storage', stageZh: '成品下线', status: 'PENDING', time: '--' }
        ]
      },
      {
        vin: 'JCO-2026-000185',
        orderId: 'ORD-ME-4402',
        model: 'JAECOO 8',
        powertrain: 'ICE',
        batteryPackId: 'BAT-12V-AGM',
        colorName: 'Pearl White',
        colorNameZh: '珍珠白 (三涂层)',
        colorHex: '#f4f4f5',
        trim: 'Executive AWD 7-Seat',
        trimZh: '四驱行政版 7座',
        destination: 'Middle East / Dubai Hub',
        destinationZh: '中东 / 阿联酋迪拜保税港',
        currentStationId: 'ST-05',
        currentZone: 'general_assembly',
        progressPct: 42,
        status: 'IN_PRODUCTION',
        dimensionalInspection: [
          { feature: 'Front Left Door Gap', featureZh: '左前门前缝间隙', nominalMm: 3.5, measuredMm: 3.55, deviationMm: 0.05, toleranceMm: 0.5, status: 'PASS' },
          { feature: 'Engine Hood Flushness', featureZh: '发动机机盖平整面差', nominalMm: 0.0, measuredMm: 0.12, deviationMm: 0.12, toleranceMm: 0.4, status: 'PASS' }
        ],
        paintInspection: [
          { stage: '2K High-Gloss Clearcoat', stageZh: '双组份高光清漆', thicknessMicron: 46.5, nominalMicron: 45.0, glossGu: 95, orangePeelDoi: 94, defectsCount: 0, status: 'PASS' }
        ],
        traceability: [
          { id: 'TR-11', component: '2.0TGDI High-Power Engine', componentZh: '2.0TGDI 鲲鹏高功率发动机 (192kW)', partNumber: 'JCO-ENG-20TGDI-HP', supplier: 'ACTECO Powertrain', batchId: 'ENG-2609-88C', timestamp: '05:20:10', status: 'PASS' },
          { id: 'TR-12', component: '8-Speed Aisin AT Transmission', componentZh: '爱信原装 8速手自一体变速箱', partNumber: 'JCO-AT-8SP', supplier: 'Aisin Seiki', batchId: 'AT-2609-31', timestamp: '05:24:40', status: 'PASS' }
        ],
        torqueRecords: [
          { toolId: 'TL-104', boltLocation: 'Instrument Panel Crossmember LH', boltLocationZh: '仪表板横梁螺栓', targetNm: 42.0, actualNm: 42.1, angleDeg: 119, status: 'PASS', timestamp: '06:28:15' }
        ],
        visionInspections: [
          { id: 'VIS-11', area: 'Rear Tailgate Gap', areaZh: '后尾门缝隙', box: [65, 30, 20, 40], confidence: 0.991, label: 'Nominal', labelZh: '间隙合格', severity: 'OK' }
        ],
        startTime: '05:40:00',
        estimatedFinish: '07:25:00',
        stageHistory: [
          { stage: 'Press Shop', stageZh: '冲压成型', status: 'COMPLETED', time: '05:40:10' },
          { stage: 'Body Shop', stageZh: '焊装车身', status: 'COMPLETED', time: '06:02:15' },
          { stage: 'Paint Shop', stageZh: '涂装防腐', status: 'COMPLETED', time: '06:25:00' },
          { stage: 'General Assembly', stageZh: '总装装配', status: 'IN_PROGRESS', time: '06:28:00' },
          { stage: 'Quality Inspection', stageZh: '质检路试', status: 'PENDING', time: '--' },
          { stage: 'Finished Storage', stageZh: '成品下线', status: 'PENDING', time: '--' }
        ]
      },
      {
        vin: 'JCO-2026-000186',
        orderId: 'ORD-CN-1904',
        model: 'JAECOO 7',
        powertrain: 'BEV',
        batteryPackId: 'BAT-2026-90415',
        colorName: 'Moonlight Silver',
        colorNameZh: '月光银 (珠光金属漆)',
        colorHex: '#94a3b8',
        trim: 'Intelligent Max EV',
        trimZh: '纯电超智尊享版',
        destination: 'China / Shanghai Distribution',
        destinationZh: '中国 / 华东上海交付中心',
        currentStationId: 'ST-04',
        currentZone: 'general_assembly',
        progressPct: 33,
        status: 'IN_PRODUCTION',
        dimensionalInspection: [
          { feature: 'Front Left Door Gap', featureZh: '左前门前缝间隙', nominalMm: 3.5, measuredMm: 3.60, deviationMm: 0.10, toleranceMm: 0.5, status: 'PASS' }
        ],
        paintInspection: [
          { stage: 'Basecoat Silver', stageZh: '色漆层 (月光银)', thicknessMicron: 16.0, nominalMicron: 15.0, glossGu: 89, orangePeelDoi: 91, defectsCount: 0, status: 'PASS' }
        ],
        traceability: [
          { id: 'TR-21', component: '80kWh CTB Blade Battery Pack', componentZh: '80kWh 车身电池一体化刀片电池包', partNumber: 'JCO-BAT-BEV-80', supplier: 'JAECOO Power Systems (Wuhu)', batchId: 'BAT-2609-C08', timestamp: '05:50:30', status: 'PASS' }
        ],
        torqueRecords: [],
        visionInspections: [],
        startTime: '05:50:00',
        estimatedFinish: '07:35:00',
        stageHistory: [
          { stage: 'Press Shop', stageZh: '冲压成型', status: 'COMPLETED', time: '05:50:10' },
          { stage: 'Body Shop', stageZh: '焊装车身', status: 'COMPLETED', time: '06:12:00' },
          { stage: 'Paint Shop', stageZh: '涂装防腐', status: 'COMPLETED', time: '06:35:00' },
          { stage: 'General Assembly', stageZh: '总装装配', status: 'IN_PROGRESS', time: '06:38:00' },
          { stage: 'Quality Inspection', stageZh: '质检路试', status: 'PENDING', time: '--' },
          { stage: 'Finished Storage', stageZh: '成品下线', status: 'PENDING', time: '--' }
        ]
      }
    ];
    this.vehicles.set(initialVehicles);

    // 4. Battery Pack Twins (8 units in production & buffer)
    const initialBatteryPacks: BatteryPackTwin[] = [
      {
        packId: 'BAT-2026-90412',
        chemistry: 'NMC 811',
        capacityKwh: 34.0,
        cellConfig: '96S1P (96 Prismatic Cells)',
        nominalVoltageV: 355.2,
        measuredVoltageV: 355.8,
        currentA: 0.2,
        maxCellDeviationMv: 8.5,
        insulationResistanceMohm: 540,
        avgTempC: 24.6,
        maxTempC: 25.8,
        socPct: 62.5,
        sohPct: 99.8,
        weldIntegrityPct: 99.9,
        bmsFirmware: 'v3.8.2-JCO-PHEV',
        batchId: 'BAT-2609-B12',
        status: 'ASSEMBLED',
        cells: Array.from({ length: 96 }, (_, i) => ({
          id: i + 1,
          voltageV: Number((3.705 + (Math.sin(i) * 0.005)).toFixed(3)),
          tempC: Number((24.5 + (Math.cos(i) * 0.8)).toFixed(1)),
          status: 'NORMAL'
        }))
      },
      {
        packId: 'BAT-2026-90415',
        chemistry: 'LFP Blade',
        capacityKwh: 80.0,
        cellConfig: '128S1P (128 Blade Cells)',
        nominalVoltageV: 409.6,
        measuredVoltageV: 410.2,
        currentA: 0.1,
        maxCellDeviationMv: 6.2,
        insulationResistanceMohm: 620,
        avgTempC: 23.8,
        maxTempC: 24.9,
        socPct: 58.0,
        sohPct: 100.0,
        weldIntegrityPct: 100.0,
        bmsFirmware: 'v4.1.0-JCO-BEV',
        batchId: 'BAT-2609-C08',
        status: 'ASSEMBLED',
        cells: Array.from({ length: 96 }, (_, i) => ({
          id: i + 1,
          voltageV: Number((3.205 + (Math.sin(i * 0.5) * 0.004)).toFixed(3)),
          tempC: Number((23.6 + (Math.cos(i) * 0.6)).toFixed(1)),
          status: 'NORMAL'
        }))
      },
      {
        packId: 'BAT-2026-90418',
        chemistry: 'NMC 811',
        capacityKwh: 100.0,
        cellConfig: '108S2P (216 Cells)',
        nominalVoltageV: 399.6,
        measuredVoltageV: 400.1,
        currentA: 15.4,
        maxCellDeviationMv: 12.1,
        insulationResistanceMohm: 480,
        avgTempC: 27.2,
        maxTempC: 29.4,
        socPct: 70.0,
        sohPct: 99.6,
        weldIntegrityPct: 99.7,
        bmsFirmware: 'v4.2.1-JCO-AWD',
        batchId: 'BAT-2609-D01',
        status: 'TESTING',
        cells: Array.from({ length: 96 }, (_, i) => ({
          id: i + 1,
          voltageV: Number((3.71 + (Math.sin(i) * 0.008)).toFixed(3)),
          tempC: Number((27.0 + (Math.cos(i) * 1.2)).toFixed(1)),
          status: 'NORMAL'
        }))
      }
    ];
    this.batteryPacks.set(initialBatteryPacks);

    // 5. Powertrain Twins
    const initialPowertrains: PowertrainTwin[] = [
      {
        unitId: 'PT-2026-HYB-088',
        type: 'PHEV_SUPER_HYBRID',
        typeZh: '1.5TGDI + 3DHT 鲲鹏超能混动总成',
        torqueMaxNm: 545,
        testedTorqueNm: 544.8,
        testedPowerKw: 265,
        testedRpm: 5800,
        efficiencyPct: 97.4,
        inverterTempC: 48.2,
        vibrationRms: 1.1,
        testResult: 'PASS',
        components: [
          { name: '1.5TGDI Thermal Engine', nameZh: '44.5%热效率混动发动机', serial: 'ACT-15T-9921', status: 'OK' },
          { name: 'Dual Motor E-Drive (P1+P3)', nameZh: 'P1+P3 双电机定子转子总成', serial: 'JCO-ED-4410', status: 'OK' },
          { name: 'SiC Silicon Carbide Inverter', nameZh: '碳化硅高压电机控制器 (800V)', serial: 'SIC-INV-8832', status: 'OK' }
        ]
      },
      {
        unitId: 'PT-2026-ICE-104',
        type: 'ICE_2.0TGDI',
        typeZh: '2.0TGDI + 8AT 鲲鹏动力燃油总成',
        torqueMaxNm: 390,
        testedTorqueNm: 391.2,
        testedPowerKw: 192,
        testedRpm: 5500,
        efficiencyPct: 94.2,
        inverterTempC: 0,
        vibrationRms: 1.4,
        testResult: 'PASS',
        components: [
          { name: '2.0TGDI Engine Core', nameZh: '2.0TGDI 铸铝缸体缸盖总成', serial: 'ACT-20T-1048', status: 'OK' },
          { name: '8AT Hydraulic Gearbox', nameZh: '8速电控液力自动变速箱', serial: 'AISIN-8AT-094', status: 'OK' }
        ]
      },
      {
        unitId: 'PT-2026-BEV-201',
        type: 'BEV_DUAL_MOTOR',
        typeZh: '前后双电机智能四驱电驱动总成 (EDU)',
        torqueMaxNm: 680,
        testedTorqueNm: 682.4,
        testedPowerKw: 380,
        testedRpm: 18500,
        efficiencyPct: 98.2,
        inverterTempC: 52.0,
        vibrationRms: 0.8,
        testResult: 'RUNNING',
        components: [
          { name: 'Front Permanent Magnet Motor', nameZh: '前轴永磁同步扁线油冷电机 (180kW)', serial: 'JCO-PM-180', status: 'OK' },
          { name: 'Rear Induction Asynchronous Motor', nameZh: '后轴异步感应高速电机 (200kW)', serial: 'JCO-IM-200', status: 'OK' },
          { name: 'Integrated Planetary Reducer', nameZh: '一体化行星齿轮减速器 (9.8:1)', serial: 'RED-98-110', status: 'OK' }
        ]
      }
    ];
    this.powertrains.set(initialPowertrains);

    // 6. AGVs / AMRs (8 units with coordinates and routes)
    const initialAgvs: AGVUnit[] = [
      {
        id: 'AGV-01',
        model: 'Heavy-Duty 3T Omnidirectional AGV',
        x: 18,
        z: 8,
        targetX: 15,
        targetZ: 0,
        speedMps: 1.2,
        batteryPct: 94,
        payloadType: 'High-Voltage Battery Pack (34kWh)',
        payloadTypeZh: '动力电池包托盘 (34kWh)',
        status: 'MOVING',
        destinationName: 'General Assembly Station 09 (Marriage)',
        destinationNameZh: '总装 09工位 (底盘电池合装)',
        missionId: 'MSN-2026-8801',
        totalTripsToday: 48
      },
      {
        id: 'AGV-02',
        model: 'Heavy-Duty 3T Omnidirectional AGV',
        x: -25,
        z: -10,
        targetX: -10,
        targetZ: -18,
        speedMps: 1.0,
        batteryPct: 88,
        payloadType: 'Body-in-White Floor Assembly Stamping',
        payloadTypeZh: '下车身底板总成冲压分总成',
        status: 'MOVING',
        destinationName: 'Body Shop Framing Cell 03',
        destinationNameZh: '焊装车身合拼 03工位',
        missionId: 'MSN-2026-8802',
        totalTripsToday: 54
      },
      {
        id: 'AGV-03',
        model: 'AMR Smart Kitting Carrier (500kg)',
        x: 35,
        z: 15,
        targetX: -10,
        targetZ: 0,
        speedMps: 1.5,
        batteryPct: 76,
        payloadType: 'Cockpit Dashboard & Center Console Kitting',
        payloadTypeZh: '仪表板与中控台定制化配料料车 (JIS)',
        status: 'MOVING',
        destinationName: 'General Assembly Station 04 (Cockpit)',
        destinationNameZh: '总装 04工位 (仪表板分装)',
        missionId: 'MSN-2026-8803',
        totalTripsToday: 62
      },
      {
        id: 'AGV-04',
        model: 'AMR Smart Kitting Carrier (500kg)',
        x: 40,
        z: -10,
        targetX: 35,
        targetZ: -25,
        speedMps: 1.2,
        batteryPct: 92,
        payloadType: 'Prismatic Battery Cells Magazine (96 units)',
        payloadTypeZh: '方形铝壳电芯料盒 (96支/批)',
        status: 'LOADING',
        destinationName: 'Battery Module Assembly Station 01',
        destinationNameZh: '电池模组极耳焊接 01工位',
        missionId: 'MSN-2026-8804',
        totalTripsToday: 41
      },
      {
        id: 'AGV-05',
        model: 'Heavy-Duty 2T Forklift AMR',
        x: -40,
        z: 25,
        targetX: -40,
        targetZ: 30,
        speedMps: 0.0,
        batteryPct: 45,
        payloadType: 'Empty Stamping Stillage Rack',
        payloadTypeZh: '空载冲压金属料框回收',
        status: 'CHARGING',
        destinationName: 'High-Power Wireless Charging Dock #2',
        destinationNameZh: '2号高频无线快充站 (40kW)',
        missionId: 'MSN-2026-CHG2',
        totalTripsToday: 35
      },
      {
        id: 'AGV-06',
        model: 'AMR Smart Kitting Carrier (500kg)',
        x: 5,
        z: -5,
        targetX: 5,
        targetZ: 0,
        speedMps: 1.4,
        batteryPct: 82,
        payloadType: '19-inch Aluminum Alloy Wheel Rims & Michelin Tires',
        payloadTypeZh: '19吋熏黑双色铝合金轮毂与轮胎总成',
        status: 'MOVING',
        destinationName: 'General Assembly Station 07 (Wheels)',
        destinationNameZh: '总装 07工位 (四轮安装)',
        missionId: 'MSN-2026-8806',
        totalTripsToday: 58
      },
      {
        id: 'AGV-07',
        model: 'AMR Smart Kitting Carrier (500kg)',
        x: -5,
        z: 5,
        targetX: 0,
        targetZ: 0,
        speedMps: 1.1,
        batteryPct: 89,
        payloadType: 'Four Door Subassemblies & Wire Harnesses',
        payloadTypeZh: '四门分装总成 (内饰板/升降器)',
        status: 'UNLOADING',
        destinationName: 'General Assembly Station 06 (Doors)',
        destinationNameZh: '总装 06工位 (四门对接)',
        missionId: 'MSN-2026-8807',
        totalTripsToday: 51
      },
      {
        id: 'AGV-08',
        model: 'Heavy-Duty 3T Omnidirectional AGV',
        x: 20,
        z: -20,
        targetX: 15,
        targetZ: -10,
        speedMps: 0.8,
        batteryPct: 68,
        payloadType: '2.0TGDI Engine & 8AT Gearbox Skid',
        payloadTypeZh: '2.0TGDI 燃油动力总成托盘',
        status: 'AVAILABLE',
        destinationName: 'Powertrain Buffer Zone B',
        destinationNameZh: '动力总成缓存库区 B',
        missionId: 'MSN-2026-8808',
        totalTripsToday: 39
      }
    ];
    this.agvs.set(initialAgvs);

    // 7. Warehouse Racks
    const initialRacks: WarehouseRack[] = [
      { id: 'RK-A1', aisle: 'Aisle 01 (Stamping Sheet Coils)', capacity: 500, occupied: 435, category: 'Raw Materials', categoryZh: '热成型高强钢卷料', rfidScansPerHour: 142, shortageAlert: false, criticalItem: 'B-Pillar 2000MPa Ultra-High Tensile Coil', criticalItemZh: 'B柱专用 2000MPa 热成型钢卷', stockLevelPct: 87.0 },
      { id: 'RK-B2', aisle: 'Aisle 02 (Battery Modules & BMS)', capacity: 350, occupied: 298, category: 'Electrification', categoryZh: '电池电芯模组与BMS电控', rfidScansPerHour: 210, shortageAlert: false, criticalItem: 'NMC 811 34kWh Prismatic Module Batch', criticalItemZh: '34kWh 混动电芯模组批次', stockLevelPct: 85.1 },
      { id: 'RK-C3', aisle: 'Aisle 03 (Cockpit Electronics & Chips)', capacity: 800, occupied: 742, category: 'Smart Electronics', categoryZh: '座舱芯片与域控制器', rfidScansPerHour: 380, shortageAlert: false, criticalItem: 'Snapdragon 8155 Mainboard ECU', criticalItemZh: '高通8155座舱主板ECU', stockLevelPct: 92.8 },
      { id: 'RK-D4', aisle: 'Aisle 04 (Paint Resin & Solvents)', capacity: 200, occupied: 156, category: 'Chemicals', categoryZh: '水性色漆色浆与清漆固化剂', rfidScansPerHour: 88, shortageAlert: false, criticalItem: 'Obsidian Black Metallic Pigment Drum', criticalItemZh: '曜石黑金属纳米色浆桶 (200L)', stockLevelPct: 78.0 }
    ];
    this.warehouseRacks.set(initialRacks);

    // 8. Predictive Maintenance Machines
    const initialMachines: PredictiveMaintenanceMachine[] = [
      {
        machineId: 'MC-PRS-01',
        name: '2500T 伺服双臂重载多连杆冲压机',
        nameZh: '2500T 伺服双臂重载多连杆冲压机',
        zone: 'press_shop',
        zoneZh: '冲压车间',
        vibrationRmsMmS: 2.1,
        vibrationThresholdMmS: 4.5,
        tempC: 54.2,
        tempThresholdC: 75.0,
        currentA: 320,
        operatingHours: 8420,
        mtbfHours: 3200,
        rulDays: 145,
        healthScorePct: 94.2,
        status: 'NORMAL',
        recommendedAction: 'Routine oil lubrication check scheduled in 15 days',
        recommendedActionZh: '主减速箱润滑油品质正常，建议15天后常规例行巡检',
        failureRiskPct: 3.2
      },
      {
        machineId: 'MC-WLD-04',
        name: '中频逆变点焊电源控制器 (Cell 03)',
        nameZh: '中频逆变点焊电源控制器 (Cell 03)',
        zone: 'body_shop',
        zoneZh: '焊装车间',
        vibrationRmsMmS: 3.8,
        vibrationThresholdMmS: 4.0,
        tempC: 68.5,
        tempThresholdC: 70.0,
        currentA: 480,
        operatingHours: 6150,
        mtbfHours: 1800,
        rulDays: 18,
        healthScorePct: 78.5,
        status: 'ATTENTION',
        recommendedAction: 'Electrode tip dressing wear high, IGBT thermal rising',
        recommendedActionZh: '电极帽修磨频次超标，IGBT逆变模块结温接近70℃预警阈值',
        failureRiskPct: 22.4
      },
      {
        machineId: 'MC-PNT-02',
        name: '涂装烘烤炉 2号高温循环热风风机',
        nameZh: '涂装烘烤炉 2号高温循环热风风机',
        zone: 'paint_shop',
        zoneZh: '涂装车间',
        vibrationRmsMmS: 4.6,
        vibrationThresholdMmS: 4.5,
        tempC: 74.8,
        tempThresholdC: 75.0,
        currentA: 95,
        operatingHours: 9200,
        mtbfHours: 1200,
        rulDays: 7,
        healthScorePct: 64.0,
        status: 'MAINTENANCE_RECOMMENDED',
        recommendedAction: 'Bearing outer ring micro-pitting detected via FFT vibration harmonics',
        recommendedActionZh: 'FFT频谱检测到轴承外圈特征故障频率谐波，建议本周计划停机更换SKF深沟球轴承',
        failureRiskPct: 48.6
      },
      {
        machineId: 'MC-BAT-01',
        name: '电芯真空干燥注液氦质谱检漏仪',
        nameZh: '电芯真空干燥注液氦质谱检漏仪',
        zone: 'battery_plant',
        zoneZh: '电池车间',
        vibrationRmsMmS: 0.8,
        vibrationThresholdMmS: 2.0,
        tempC: 28.5,
        tempThresholdC: 45.0,
        currentA: 42,
        operatingHours: 2400,
        mtbfHours: 4500,
        rulDays: 280,
        healthScorePct: 98.5,
        status: 'NORMAL',
        recommendedAction: 'Vacuum seal ring integrity 100%, calibration active',
        recommendedActionZh: '高真空密封腔压降指标优异，分子泵运转平稳',
        failureRiskPct: 1.1
      }
    ];
    this.maintenanceMachines.set(initialMachines);

    // 9. IIoT Gateways
    const initialGateways: IIoTGateway[] = [
      { id: 'GW-01', name: 'Press PLC Industrial Gateway', protocol: 'Profinet', ip: '192.168.10.101', connectedNodes: 128, packetRateMsgS: 2450, latencyMs: 1.8, status: 'CONNECTED', zone: 'Press Shop', zoneZh: '冲压车间' },
      { id: 'GW-02', name: 'Body Shop Robot Edge Server', protocol: 'OPC-UA', ip: '192.168.20.102', connectedNodes: 340, packetRateMsgS: 8900, latencyMs: 2.1, status: 'CONNECTED', zone: 'Body Shop', zoneZh: '焊装车间' },
      { id: 'GW-03', name: 'Paint Booth Telemetry Broker', protocol: 'MQTT', ip: '192.168.30.103', connectedNodes: 215, packetRateMsgS: 4120, latencyMs: 3.4, status: 'CONNECTED', zone: 'Paint Shop', zoneZh: '涂装车间' },
      { id: 'GW-04', name: 'Battery Testing Data Concentrator', protocol: 'OPC-UA', ip: '192.168.40.104', connectedNodes: 480, packetRateMsgS: 12400, latencyMs: 1.5, status: 'CONNECTED', zone: 'Battery Plant', zoneZh: '电池车间' },
      { id: 'GW-05', name: 'General Assembly MES Line Gateway', protocol: 'Modbus-TCP', ip: '192.168.50.105', connectedNodes: 560, packetRateMsgS: 15800, latencyMs: 2.8, status: 'CONNECTED', zone: 'General Assembly', zoneZh: '总装车间' },
      { id: 'GW-06', name: 'Energy Microgrid Supervisory Node', protocol: 'MQTT', ip: '192.168.60.106', connectedNodes: 95, packetRateMsgS: 1850, latencyMs: 4.2, status: 'CONNECTED', zone: 'Energy Centre', zoneZh: '能源调度中心' }
    ];
    this.iiotGateways.set(initialGateways);

    // 10. Initial Events Log
    const initialEvents: FactoryEvent[] = [
      {
        id: 'EVT-01',
        timestamp: '06:40:15',
        type: 'QUALITY_PASS',
        title: 'Vehicle VIN 000184 Passed Body Gap Scan',
        titleZh: '车辆 000184 通过车身间隙平整度激光检测',
        details: 'All 42 coordinate points within ±0.3mm tolerance.',
        detailsZh: '全车42处门缝与漆面面差公差严格受控于 ±0.3mm 内。',
        severity: 'SUCCESS'
      },
      {
        id: 'EVT-02',
        timestamp: '06:38:50',
        type: 'BATTERY_TEST',
        title: 'Pack BAT-90412 EOL Insulation Test Complete',
        titleZh: '电池包 BAT-90412 终检绝缘耐压与气密性合格',
        details: 'Insulation: 540 MΩ, Cell max delta: 8.5 mV.',
        detailsZh: '5000V高压绝缘阻抗 540 MΩ，96串电芯最大压差仅 8.5 mV。',
        severity: 'SUCCESS'
      },
      {
        id: 'EVT-03',
        timestamp: '06:35:22',
        type: 'AGV_DISPATCH',
        title: 'AGV-01 Dispatched with 34kWh Pack to ST-09',
        titleZh: 'AGV-01 自动出库运送 34kWh 电池总成至总装 09工位',
        details: 'Mission MSN-2026-8801 in progress.',
        detailsZh: '执行任务 MSN-2026-8801，预计2分钟后抵达底盘合装工位。',
        severity: 'INFO'
      },
      {
        id: 'EVT-04',
        timestamp: '06:30:10',
        type: 'MAINTENANCE_ALERT',
        title: 'Paint Shop Fan MC-PNT-02 Bearing Vibration Warning',
        titleZh: '涂装烘烤炉 2号循环热风机轴承振动谐波偏高预警',
        details: 'Vibration RMS 4.6 mm/s exceeding 4.5 mm/s warning threshold.',
        detailsZh: '振动有效值 4.6 mm/s 略超预警阈值 4.5 mm/s，已自动派发CBM工单。',
        severity: 'WARN'
      }
    ];
    this.events.set(initialEvents);
  }

  private initHistory() {
    // Generate simulated timeline history starting from 06:00
    const history = [
      { timeStr: '06:00', oee: 89.2, fpy: 98.5, uph: 54, vehicles: 120 },
      { timeStr: '06:10', oee: 90.1, fpy: 98.8, uph: 56, vehicles: 125 },
      { timeStr: '06:20', oee: 88.5, fpy: 98.2, uph: 53, vehicles: 131 },
      { timeStr: '06:30', oee: 89.8, fpy: 98.6, uph: 55, vehicles: 136 },
      { timeStr: '06:40', oee: 87.8, fpy: 98.7, uph: 52, vehicles: 142 }
    ];
    this.historySnapshots.set(history);
  }

  // Simulation Loop Tick
  private startSimulationLoop() {
    if (this.timerHandle) clearInterval(this.timerHandle);

    this.timerHandle = setInterval(() => {
      if (!this.isPlaying()) return;

      const speed = this.speedMultiplier();
      const currentSec = this.simSeconds();
      const nextSec = currentSec + 1 * speed;
      this.simSeconds.set(nextSec);

      // Perform physics and telemetry updates every tick
      this.updateRobotsAndWelds();
      this.updateAgvMovement();
      this.updateEnergyAndSensors();

      // Periodically advance WIP vehicles and record snapshot
      if (Math.floor(nextSec / 60) > Math.floor(currentSec / 60)) {
        // Every simulation minute
        this.updateMinuteStep();
      }

      if (Math.floor(nextSec / 600) > Math.floor(currentSec / 600)) {
        // Every 10 simulation minutes, record snapshot
        this.recordHistorySnapshot();
      }
    }, 1000);
  }

  private updateRobotsAndWelds() {
    this.robots.update(rbs =>
      rbs.map(r => {
        if (r.state !== 'RUNNING') return r;
        // Oscillate joint angles slightly for visual kinematics
        const t = this.simSeconds() * 0.5;
        const newAngles = r.jointAngles.map((ang, idx) => {
          const delta = Math.sin(t + idx) * 0.8;
          return Number((ang + delta).toFixed(1));
        });

        // Weld completion progress if welding robot
        let welds = r.weldsCompleted;
        if (r.weldPointsCount > 0) {
          welds = (welds + 1) % (r.weldPointsCount + 1);
        }

        // Slight thermal oscillation
        const temp = Number((r.temperatureC + (Math.random() - 0.5) * 0.2).toFixed(1));

        return {
          ...r,
          jointAngles: newAngles,
          weldsCompleted: welds,
          temperatureC: Math.max(30, Math.min(80, temp))
        };
      })
    );
  }

  private updateAgvMovement() {
    this.agvs.update(agvs =>
      agvs.map(a => {
        if (a.status !== 'MOVING') return a;

        const dx = a.targetX - a.x;
        const dz = a.targetZ - a.z;
        const dist = Math.sqrt(dx * dx + dz * dz);

        if (dist < 0.5) {
          // Reached target waypoint, assign next waypoint
          const newTargetX = (Math.random() - 0.5) * 60;
          const newTargetZ = (Math.random() - 0.5) * 40;
          return {
            ...a,
            x: a.targetX,
            z: a.targetZ,
            targetX: Number(newTargetX.toFixed(1)),
            targetZ: Number(newTargetZ.toFixed(1)),
            batteryPct: Math.max(15, a.batteryPct - 0.05),
            totalTripsToday: a.totalTripsToday + 1
          };
        }

        const step = (a.speedMps * (this.speedMultiplier() > 10 ? 2 : 1)) * 0.05;
        const newX = a.x + (dx / dist) * Math.min(step, dist);
        const newZ = a.z + (dz / dist) * Math.min(step, dist);

        return {
          ...a,
          x: Number(newX.toFixed(2)),
          z: Number(newZ.toFixed(2)),
          batteryPct: Math.max(15, Number((a.batteryPct - 0.002).toFixed(2)))
        };
      })
    );
  }

  private updateEnergyAndSensors() {
    const t = this.simSeconds();
    const hour = (t / 3600) % 24;

    // Solar PV peaks during midday (10:00 - 16:00)
    let solarKw = 0;
    if (hour >= 6 && hour <= 18) {
      const sunFactor = Math.sin(((hour - 6) / 12) * Math.PI);
      solarKw = Math.round(3500 * sunFactor);
    }

    // Grid import depends on scenario (e.g. Peak Shaving)
    const isPeakShaving = this.activeScenario().id === 'POWER_PRICE_SPIKE';
    const essDischarge = isPeakShaving ? 3.5 : (hour >= 9 && hour <= 11 ? 2.0 : 0.5);
    const baseLoad = 15.2 + Math.sin(t * 0.01) * 0.6;
    const gridLoad = Math.max(8.0, Number((baseLoad - (solarKw / 1000) - essDischarge).toFixed(2)));

    this.energy.update(e => ({
      ...e,
      solarPvKw: solarKw,
      essDischargeMw: essDischarge,
      gridImportMw: gridLoad,
      totalFactoryLoadMw: Number(baseLoad.toFixed(2)),
      dailyConsumptionMwh: Number((e.dailyConsumptionMwh + (baseLoad / 3600) * this.speedMultiplier()).toFixed(2)),
      renewableSharePct: Number((((solarKw / 1000 + essDischarge) / baseLoad) * 100).toFixed(1))
    }));
  }

  private updateMinuteStep() {
    // Progress vehicles in line
    this.vehicles.update(veh =>
      veh.map(v => {
        let nextProg = v.progressPct + 1;
        if (nextProg > 100) {
          nextProg = 100;
        }
        return {
          ...v,
          progressPct: nextProg
        };
      })
    );
  }

  private recordHistorySnapshot() {
    const timeStr = this.simTimeFormatted().substring(0, 5);
    const oee = this.oeeMetrics().oee;
    const fpy = this.firstPassYieldPct();
    const uph = this.productionRateUph();
    const totalFinished = this.finishedVehiclesCount();

    this.historySnapshots.update(h => {
      const updated = [...h, { timeStr, oee, fpy, uph, vehicles: totalFinished }];
      if (updated.length > 20) updated.shift();
      return updated;
    });
  }

  // Actions & Controls
  togglePlay() {
    this.isPlaying.update(p => !p);
  }

  setSpeed(speed: number) {
    this.speedMultiplier.set(speed);
  }

  jumpToTime(hour: number, minute = 0) {
    this.simSeconds.set(hour * 3600 + minute * 60);
  }

  setScenario(scenarioId: string) {
    const sc = this.scenarios.find(s => s.id === scenarioId);
    if (!sc) return;
    this.activeScenario.set(sc);

    // Apply scenario side effects
    if (sc.id === 'ROBOT_FAILURE') {
      this.robots.update(rbs =>
        rbs.map(r => (r.id === 'RB-204' ? { ...r, state: 'FAULT', currentTaskZh: '电机伺服过热故障报警 (E-701)' } : r))
      );
      this.addEvent({
        type: 'ROBOT_FAULT',
        title: 'Robot RB-204 Servo Overheat Fault Injected',
        titleZh: '焊装机器人 RB-204 注入伺服电机过热故障 (E-701)',
        details: 'Cycle time stalled, Body Shop downstream buffer draining.',
        detailsZh: '工位节拍停滞，车身分装缓存区降至警戒水位。',
        severity: 'ERROR'
      });
    } else if (sc.id === 'PAINT_DOWNTIME') {
      this.addEvent({
        type: 'MAINTENANCE_ALERT',
        title: 'Paint Booth 02 Curing Heat Exchanger Delayed',
        titleZh: '涂装 2号烘烤区换热器气动阀卡滞',
        details: 'Curing cycle time extended from 60s to 78s.',
        detailsZh: '烘烤固化周期被迫延长至 78秒，前序电泳滑撬已积压 8台。',
        severity: 'WARN'
      });
    } else {
      // Restore normal robot states
      this.robots.update(rbs =>
        rbs.map(r => (r.state === 'FAULT' ? { ...r, state: 'RUNNING', currentTaskZh: '执行B柱热成型钢激光飞行焊' } : r))
      );
    }
  }

  setPerspective(perspective: ViewPerspective) {
    this.activePerspective.set(perspective);
  }

  selectObject(type: 'robot' | 'station' | 'vehicle' | 'agv' | 'machine' | 'rack', id: string) {
    this.selectedObjectId.set({ type, id });
  }

  clearSelection() {
    this.selectedObjectId.set(null);
  }

  addEvent(event: Omit<FactoryEvent, 'id' | 'timestamp'>) {
    const newEvent: FactoryEvent = {
      ...event,
      id: `EVT-${Date.now().toString().slice(-4)}`,
      timestamp: this.simTimeFormatted()
    };
    this.events.update(evts => [newEvent, ...evts.slice(0, 49)]);
  }

  // Update What-If parameters
  updateWhatIf(takt: number, bufferMul: number, speedMul: number, workers: number) {
    this.whatIfTakt.set(takt);
    this.whatIfBufferMultiplier.set(bufferMul);
    this.whatIfSpeedMultiplier.set(speedMul);
    this.whatIfWorkerCount.set(workers);
  }

  // Generate Shift Report Data
  generateShiftReport(): ShiftReport {
    const shift = this.currentShift();
    const metrics = this.oeeMetrics();
    const uph = this.productionRateUph();
    const planned = 480;
    const actual = Math.min(planned, Math.round(uph * 8 * (metrics.oee / 100)));
    const energyMwh = Number((actual * 0.28).toFixed(1));

    return {
      shiftId: `RPT-${shift.id}-${Date.now().toString().slice(-4)}`,
      date: '2026-10-03',
      shiftName: shift.nameEn,
      shiftNameZh: shift.name,
      planVolume: planned,
      actualVolume: actual,
      oee: {
        availability: metrics.availability,
        performance: metrics.performance,
        quality: metrics.quality,
        totalOee: metrics.oee
      },
      fpy: this.firstPassYieldPct(),
      downtimeMinutes: this.activeScenario().id === 'ROBOT_FAILURE' ? 24 : 6,
      energyUsedMwh: energyMwh,
      scrapRatePct: Number((100 - this.firstPassYieldPct()).toFixed(1)),
      topBottleneck: this.criticalBottleneckStation()?.name || 'Paint Curing Zone',
      topBottleneckZh: this.criticalBottleneckStation()?.nameZh || '涂装固化烘烤区',
      criticalAlarms: this.events().filter(e => e.severity === 'ERROR' || e.severity === 'WARN').map(e => e.titleZh).slice(0, 5),
      vehiclesProduced: actual,
      costPerVehicleYuan: this.energy().energyCostPerVehicleYuan
    };
  }
}
