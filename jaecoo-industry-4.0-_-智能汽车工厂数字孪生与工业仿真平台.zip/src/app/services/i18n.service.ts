import { Injectable, signal, computed } from '@angular/core';
import { Language } from '../models/factory.types';

@Injectable({
  providedIn: 'root'
})
export class I18nService {
  currentLang = signal<Language>('zh');

  private translations: Record<string, { zh: string; en: string }> = {
    // Brand & Header
    'brand.title': { zh: 'JAECOO 工业 4.0', en: 'JAECOO INDUSTRY 4.0' },
    'brand.subtitle': { zh: '智能汽车工厂数字孪生与工业仿真平台', en: 'Intelligent Automotive Factory Digital Twin & Simulator' },
    'brand.tagline': { zh: '智能制造 · 数字孪生 · 持续优化', en: 'Intelligent Manufacturing · Digital Twin · Continuous Optimisation' },
    'header.shift': { zh: '当前班次', en: 'Current Shift' },
    'header.simClock': { zh: '工厂仿真时钟', en: 'Factory Sim Clock' },
    'header.scenario': { zh: '运行场景', en: 'Scenario' },
    'header.perspective': { zh: '视角模式', en: 'Perspective' },
    'header.aiAssist': { zh: 'AI 专家诊断', en: 'AI Diagnostics' },
    'header.speed': { zh: '仿真速率', en: 'Sim Speed' },
    'header.play': { zh: '运行仿真', en: 'Play Sim' },
    'header.pause': { zh: '暂停', en: 'Pause' },

    // Nav items
    'nav.overview': { zh: '工厂总览', en: 'Factory Overview' },
    'nav.factory3d': { zh: '3D 孪生车间', en: '3D Factory Twin' },
    'nav.factory2d': { zh: '2D 图纸与流向', en: '2D Layout & Flows' },
    'nav.production': { zh: '总装产线平衡', en: 'Assembly Line Balancing' },
    'nav.vehicles': { zh: '车辆数字孪生', en: 'Vehicle Digital Twins' },
    'nav.robotics': { zh: '机器人工作站', en: 'Robotics Engineering' },
    'nav.bodyShop': { zh: '焊装与几何尺寸', en: 'Body Shop & Geometry' },
    'nav.paintShop': { zh: '涂装车间孪生', en: 'Paint Shop Twin' },
    'nav.battery': { zh: '动力电池制造', en: 'Battery Manufacturing' },
    'nav.powertrain': { zh: '动力总成测试', en: 'Powertrain Assembly' },
    'nav.logistics': { zh: '智慧物流与立库', en: 'Logistics & Warehouse' },
    'nav.quality': { zh: '机器视觉与质检', en: 'Quality & Vision AI' },
    'nav.maintenance': { zh: '预测性维护 CBM', en: 'Predictive Maintenance' },
    'nav.energy': { zh: '能源微电网与碳排', en: 'Energy Grid & Carbon' },
    'nav.iiot': { zh: '工业物联网 IIoT', en: 'Industrial IoT & Edge' },
    'nav.scenarios': { zh: '情景推演与对比', en: 'What-If Simulation' },
    'nav.reports': { zh: '班次数字化报告', en: 'Shift Reports & Export' },
    'nav.ai': { zh: '工业 AI 决策助手', en: 'Industrial AI Assistant' },

    // Perspectives
    'perspective.EXECUTIVE': { zh: '管理决策视角', en: 'Executive Mode' },
    'perspective.ENGINEERING': { zh: '工程诊断视角', en: 'Engineering Mode' },
    'perspective.OPERATOR': { zh: '工位操作视角', en: 'Operator Mode' },
    'perspective.MAINTENANCE': { zh: '设备维护视角', en: 'Maintenance Mode' },
    'perspective.LOGISTICS': { zh: '物流仓储视角', en: 'Logistics Mode' },

    // KPI Badges
    'kpi.vehiclesInProduction': { zh: '生产中车辆 (WIP)', en: 'Vehicles in Production' },
    'kpi.productionRate': { zh: '小时生产率 (UPH)', en: 'Production Rate (UPH)' },
    'kpi.lineUtilisation': { zh: '产线利用率', en: 'Line Utilisation' },
    'kpi.oee': { zh: '设备综合效率 (OEE)', en: 'Overall Equipment Effectiveness (OEE)' },
    'kpi.availability': { zh: '可用率 (Availability)', en: 'Availability' },
    'kpi.performance': { zh: '表现指数 (Performance)', en: 'Performance' },
    'kpi.qualityYield': { zh: '一次合格率 (FPY)', en: 'First Pass Yield (FPY)' },
    'kpi.downtime': { zh: '累计故障停机', en: 'Downtime Duration' },
    'kpi.energyTotal': { zh: '累计能耗', en: 'Total Energy' },
    'kpi.batteryPacks': { zh: '电池包下线数', en: 'Battery Output' },
    'kpi.robotUtil': { zh: '机器人平均负荷', en: 'Robot Fleet Load' },
    'kpi.taktTime': { zh: '产线节拍 (Takt)', en: 'Line Takt Time' },
    'kpi.targetTakt': { zh: '标准目标节拍', en: 'Target Takt Time' },
    'kpi.bottleneck': { zh: '关键瓶颈工序', en: 'Critical Bottleneck' },
    'kpi.costPerVehicle': { zh: '单车制造成本', en: 'Mfg Cost / Vehicle' },

    // General terms
    'common.status': { zh: '状态', en: 'Status' },
    'common.details': { zh: '详情', en: 'Details' },
    'common.nominal': { zh: '标称值', en: 'Nominal' },
    'common.measured': { zh: '实测值', en: 'Measured' },
    'common.deviation': { zh: '偏差值', en: 'Deviation' },
    'common.tolerance': { zh: '允许公差', en: 'Tolerance' },
    'common.pass': { zh: '合格', en: 'PASS' },
    'common.warn': { zh: '预警', en: 'WARN' },
    'common.fail': { zh: '超差/不合格', en: 'FAIL' },
    'common.exportPdf': { zh: '导出 PDF 报告', en: 'Export PDF' },
    'common.exportCsv': { zh: '导出 CSV 数据', en: 'Export CSV' },
    'common.exportJson': { zh: '导出 JSON 孪生数据', en: 'Export JSON' },
    'common.filter': { zh: '筛选过滤', en: 'Filter' },
    'common.search': { zh: '搜索 VIN / 编号...', en: 'Search VIN / ID...' },
    'common.reset': { zh: '重置仿真', en: 'Reset Simulation' },
    'common.apply': { zh: '应用参数', en: 'Apply Parameters' },
    'common.compare': { zh: '对比推演', en: 'Compare What-If' },
    'common.evidence': { zh: '推演诊断依据', en: 'Diagnostic Evidence' },
    'common.recommendation': { zh: '优化建议措施', en: 'Recommended Action' },

    // Robot states
    'robot.state.RUNNING': { zh: '运行中', en: 'RUNNING' },
    'robot.state.IDLE': { zh: '待机就绪', en: 'IDLE' },
    'robot.state.WAITING': { zh: '等待来料', en: 'WAITING' },
    'robot.state.TOOL_CHANGE': { zh: '更换末端工具', en: 'TOOL CHANGE' },
    'robot.state.FAULT': { zh: '报警故障', en: 'FAULT' },
    'robot.state.MAINTENANCE': { zh: '计划保养中', en: 'MAINTENANCE' },
    'robot.state.EMERGENCY_STOP': { zh: '急停触发', en: 'EMERGENCY STOP' },
    'robot.state.OFFLINE': { zh: '离线断开', en: 'OFFLINE' },

    // AGV states
    'agv.state.AVAILABLE': { zh: '空闲待命', en: 'AVAILABLE' },
    'agv.state.MOVING': { zh: '自主导航中', en: 'MOVING' },
    'agv.state.LOADING': { zh: '物料装载', en: 'LOADING' },
    'agv.state.UNLOADING': { zh: '卸料入位', en: 'UNLOADING' },
    'agv.state.CHARGING': { zh: '无线快充中', en: 'CHARGING' },
    'agv.state.FAULT': { zh: '避障停障/故障', en: 'FAULT' },

    // Maintenance states
    'cbm.NORMAL': { zh: '健康正常', en: 'Normal' },
    'cbm.ATTENTION': { zh: '劣化关注', en: 'Attention' },
    'cbm.MAINTENANCE_RECOMMENDED': { zh: '建议维护', en: 'Maintenance Recommended' },
    'cbm.CRITICAL': { zh: '紧急严重', en: 'Critical Alarm' },

    // Zones
    'zone.press_shop': { zh: '冲压车间 (Press Shop)', en: 'Press Shop' },
    'zone.body_shop': { zh: '焊装车间 (Body Shop)', en: 'Body Shop' },
    'zone.paint_shop': { zh: '涂装车间 (Paint Shop)', en: 'Paint Shop' },
    'zone.battery_plant': { zh: '电池车间 (Battery Plant)', en: 'Battery Plant' },
    'zone.powertrain': { zh: '动力总成 (Powertrain)', en: 'Powertrain' },
    'zone.general_assembly': { zh: '总装车间 (General Assembly)', en: 'General Assembly' },
    'zone.quality_inspection': { zh: '质检车间 (Quality Inspection)', en: 'Quality Inspection' },
    'zone.vehicle_test': { zh: '整车测试 (Vehicle Test)', en: 'Vehicle Test' },
    'zone.finished_storage': { zh: '成品车库 (Finished Storage)', en: 'Finished Storage' },
    'zone.smart_warehouse': { zh: '智能立库 (Smart Warehouse)', en: 'Smart Warehouse' },
    'zone.logistics_yard': { zh: '物流园区 (Logistics Yard)', en: 'Logistics Yard' },
    'zone.charging_area': { zh: '快充中心 (Charging Area)', en: 'Charging Area' },
    'zone.utilities': { zh: '辅助动力站 (Utilities)', en: 'Utilities' },
    'zone.energy_centre': { zh: '能源调度中心 (Energy Centre)', en: 'Energy Centre' },
    'zone.maintenance': { zh: '预测维护中心 (Maintenance)', en: 'Maintenance' },
    'zone.administration': { zh: '运营中心 (Administration)', en: 'Administration' },
  };

  setLanguage(lang: Language) {
    this.currentLang.set(lang);
  }

  toggleLanguage() {
    this.currentLang.update(l => (l === 'zh' ? 'en' : 'zh'));
  }

  t(key: string): string {
    const item = this.translations[key];
    if (!item) return key;
    return item[this.currentLang()];
  }

  isZh = computed(() => this.currentLang() === 'zh');
}
