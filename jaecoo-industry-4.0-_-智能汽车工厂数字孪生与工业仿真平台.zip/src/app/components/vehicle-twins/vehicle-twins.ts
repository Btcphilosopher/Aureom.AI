import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-vehicle-twins',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Title & Search Bar -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">directions_car</mat-icon>
            <span>{{ i18n.t('nav.vehicles') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? 'JAECOO 整车全生命周期数字孪生档案' : 'JAECOO Vehicle Digital Twin & Traceability' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '每台整车独立数字孪生：车身间隙公差、漆膜厚度、定扭拧紧曲线、全栈零部件追溯链' : 'Individual vehicle digital twins with gap tolerances, paint specs, torque logs, and component supply tree.' }}
          </p>
        </div>

        <!-- Vehicle Search Selector -->
        <div class="flex items-center gap-2">
          @for (veh of sim.vehicles(); track veh.vin) {
            <button
              (click)="selectedVin.set(veh.vin)"
              [class.bg-emerald-500]="selectedVin() === veh.vin"
              [class.text-zinc-950]="selectedVin() === veh.vin"
              [class.text-zinc-300]="selectedVin() !== veh.vin"
              class="px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-bold font-industrial-mono hover:bg-zinc-800 transition-all cursor-pointer">
              {{ veh.vin }} ({{ veh.model }})
            </button>
          }
        </div>
      </div>

      <!-- Active Selected Vehicle Digital Twin Cockpit -->
      @if (currentVehicle()) {
        <div class="space-y-6">
          <!-- 1. Vehicle Identity & Spec Summary Card -->
          <div class="bg-gradient-to-br from-zinc-900 via-zinc-950 to-zinc-900 p-6 rounded-2xl border border-zinc-800 shadow-xl">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
              <div class="flex items-center gap-4">
                <div
                  class="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg border border-zinc-700"
                  [style.background-color]="currentVehicle()!.colorHex">
                  <mat-icon class="text-2xl text-emerald-400">directions_car</mat-icon>
                </div>

                <div>
                  <div class="flex items-center gap-2 font-industrial-mono">
                    <span class="text-lg font-extrabold text-zinc-100">{{ currentVehicle()!.vin }}</span>
                    <span class="px-2 py-0.5 rounded text-[11px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                      {{ currentVehicle()!.powertrain }}
                    </span>
                  </div>
                  <div class="text-xs text-zinc-300 font-semibold mt-0.5">
                    {{ currentVehicle()!.model }} · {{ i18n.isZh() ? currentVehicle()!.trimZh : currentVehicle()!.trim }}
                  </div>
                  <div class="text-[11px] text-zinc-400 font-industrial-mono mt-0.5">
                    {{ i18n.isZh() ? '发运目的地: ' : 'Destination: ' }} {{ i18n.isZh() ? currentVehicle()!.destinationZh : currentVehicle()!.destination }}
                  </div>
                </div>
              </div>

              <!-- Production Progress & Order ID -->
              <div class="flex items-center gap-6 font-industrial-mono text-xs">
                <div>
                  <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '制造订单号' : 'Production Order' }}</div>
                  <div class="font-bold text-zinc-200">{{ currentVehicle()!.orderId }}</div>
                </div>
                <div>
                  <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '当前装配进度' : 'Assembly Progress' }}</div>
                  <div class="text-lg font-extrabold text-emerald-400">{{ currentVehicle()!.progressPct }}%</div>
                </div>
              </div>
            </div>

            <!-- 6-Stage Manufacturing Progression Timeline -->
            <div class="pt-5">
              <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono mb-3">
                {{ i18n.isZh() ? '车间制造工艺追溯流水线' : 'Manufacturing Stage Progression' }}
              </div>
              <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                @for (stage of currentVehicle()!.stageHistory; track stage.stage) {
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 text-center">
                    <div class="text-[10px] text-zinc-400 font-industrial-mono">{{ stage.time }}</div>
                    <div class="text-xs font-bold text-zinc-200 mt-0.5">{{ i18n.isZh() ? stage.stageZh : stage.stage }}</div>
                    <span
                      [class.bg-emerald-500/20]="stage.status === 'COMPLETED'"
                      [class.text-emerald-400]="stage.status === 'COMPLETED'"
                      [class.bg-blue-500/20]="stage.status === 'IN_PROGRESS'"
                      [class.text-blue-400]="stage.status === 'IN_PROGRESS'"
                      [class.bg-zinc-800]="stage.status === 'PENDING'"
                      [class.text-zinc-400]="stage.status === 'PENDING'"
                      class="inline-block mt-2 px-2 py-0.5 rounded text-[10px] font-industrial-mono font-bold">
                      {{ stage.status }}
                    </span>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- 2. Dimensional Gap Quality & Paint Shop Layer Audit -->
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Dimensional Gap Tolerances (Nominal vs Measured vs Deviation) -->
            <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-3">
              <div class="flex items-center justify-between">
                <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                  <mat-icon class="text-emerald-400 text-sm">straighten</mat-icon>
                  <span>{{ i18n.isZh() ? '车身四门两盖激光在线间隙与面差 (3D Gap Scan)' : '3D Dimensional Gap & Flushness Quality' }}</span>
                </h3>
                <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold font-industrial-mono">100% PASS</span>
              </div>

              <div class="overflow-x-auto">
                <table class="w-full text-left text-xs font-industrial-mono">
                  <thead class="bg-zinc-950 text-zinc-400 uppercase text-[10px] border-b border-zinc-800">
                    <tr>
                      <th class="p-2.5">{{ i18n.isZh() ? '测量特征位' : 'Feature' }}</th>
                      <th class="p-2.5">{{ i18n.isZh() ? '设计标称' : 'Nominal' }}</th>
                      <th class="p-2.5">{{ i18n.isZh() ? '实测值' : 'Measured' }}</th>
                      <th class="p-2.5">{{ i18n.isZh() ? '偏差 (Dev)' : 'Deviation' }}</th>
                      <th class="p-2.5 text-center">{{ i18n.isZh() ? '判定' : 'Status' }}</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-zinc-800/60 text-zinc-300">
                    @for (dp of currentVehicle()!.dimensionalInspection; track dp.feature) {
                      <tr class="hover:bg-zinc-900/50">
                        <td class="p-2.5 font-semibold text-zinc-200">{{ i18n.isZh() ? dp.featureZh : dp.feature }}</td>
                        <td class="p-2.5 text-zinc-400">{{ dp.nominalMm.toFixed(2) }} mm</td>
                        <td class="p-2.5 font-bold text-zinc-100">{{ dp.measuredMm.toFixed(2) }} mm</td>
                        <td
                          [class.text-emerald-400]="Math.abs(dp.deviationMm) <= dp.toleranceMm"
                          [class.text-red-400]="Math.abs(dp.deviationMm) > dp.toleranceMm"
                          class="p-2.5 font-bold">
                          {{ dp.deviationMm > 0 ? '+' : '' }}{{ dp.deviationMm.toFixed(2) }} mm
                        </td>
                        <td class="p-2.5 text-center">
                          <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">
                            {{ dp.status }}
                          </span>
                        </td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Paint Shop Quality Specs -->
            <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-3">
              <div class="flex items-center justify-between">
                <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                  <mat-icon class="text-blue-400 text-sm">format_paint</mat-icon>
                  <span>{{ i18n.isZh() ? '车身四涂层膜厚与漆面光泽度 (Paint Layer Twin)' : 'Paint Film Thickness & Optical Gloss Specs' }}</span>
                </h3>
                <span class="text-xs text-zinc-400 font-industrial-mono">{{ i18n.isZh() ? '曜石黑水性金属漆' : 'Obsidian Black Metallic' }}</span>
              </div>

              <div class="space-y-2.5">
                @for (paint of currentVehicle()!.paintInspection; track paint.stage) {
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 text-xs">
                    <div class="flex items-center justify-between font-industrial-mono mb-1">
                      <span class="font-bold text-zinc-200">{{ i18n.isZh() ? paint.stageZh : paint.stage }}</span>
                      <span class="text-emerald-400 font-bold">{{ paint.thicknessMicron }} µm / {{ paint.nominalMicron }} µm</span>
                    </div>
                    <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                      <div
                        class="bg-emerald-500 h-full rounded-full"
                        [style.width.%]="(paint.thicknessMicron / (paint.nominalMicron * 1.3)) * 100"></div>
                    </div>
                    <div class="flex items-center justify-between text-[11px] text-zinc-400 font-industrial-mono mt-1.5">
                      <span>光泽度 (Gloss): <strong class="text-zinc-200">{{ paint.glossGu }} GU</strong></span>
                      <span>鲜映性 (DOI): <strong class="text-zinc-200">{{ paint.orangePeelDoi }}</strong></span>
                      <span>瑕疵数: <strong class="text-emerald-400">{{ paint.defectsCount }}</strong></span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- 3. Component Traceability Chain (Vehicle -> Battery -> Engine -> Cockpit -> Supplier) -->
          <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                  <mat-icon class="text-emerald-400 text-sm">link</mat-icon>
                  <span>{{ i18n.isZh() ? '关键核心零部件追溯链 (Traceability Chain)' : 'Component Supply Traceability Tree' }}</span>
                </h3>
                <p class="text-xs text-zinc-400 mt-0.5">{{ i18n.isZh() ? '从供应商批次、总成序列号到装配工位100%全生命周期溯源' : 'End-to-end component traceability from supplier batch to assembly station.' }}</p>
              </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              @for (node of currentVehicle()!.traceability; track node.id) {
                <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-1.5">
                  <div class="flex items-center justify-between font-industrial-mono">
                    <span class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? node.componentZh : node.component }}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">{{ node.status }}</span>
                  </div>
                  <div class="text-[11px] text-zinc-400 font-industrial-mono">Part#: <strong class="text-zinc-300">{{ node.partNumber }}</strong></div>
                  <div class="text-[11px] text-zinc-400">供应商: <strong class="text-zinc-300">{{ node.supplier }}</strong></div>
                  <div class="text-[11px] text-zinc-400 font-industrial-mono">批次: <strong class="text-emerald-400">{{ node.batchId }}</strong> · {{ node.timestamp }}</div>
                </div>
              }
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class VehicleTwinsComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedVin = signal<string>('JCO-2026-000184');

  Math = Math;

  currentVehicle = () => {
    const v = this.sim.vehicles().find(x => x.vin === this.selectedVin());
    return v || this.sim.vehicles()[0];
  };
}
