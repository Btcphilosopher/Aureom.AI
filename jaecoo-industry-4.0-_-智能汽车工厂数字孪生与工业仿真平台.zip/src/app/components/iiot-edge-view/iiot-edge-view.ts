import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-iiot-edge-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">hub</mat-icon>
            <span>{{ i18n.t('nav.iiot') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '工业物联网 (IIoT) 与边缘计算网络架构' : 'Industrial IoT (IIoT) & Edge Computing Architecture' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '支持 OPC-UA, MQTT, Modbus-TCP 与 Profinet 协议的统一工业边缘数据网关矩阵' : 'Unified industrial edge computing matrix supporting OPC-UA, MQTT, Modbus-TCP and Profinet.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">边缘节点连接数</div>
            <div class="font-bold text-emerald-400">1,820 点位</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">消息吞吐率</div>
            <div class="font-bold text-zinc-200">45,470 msg/s</div>
          </div>
        </div>
      </div>

      <!-- Edge Hierarchy Diagram Card -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-3">
        <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '工业互联网六层数据链路 (Edge Architecture Stack)' : '6-Layer Industrial Data Pipeline Stack' }}
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center text-xs font-industrial-mono">
          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 01</div>
            <div class="font-bold text-zinc-200">传感器与执行器</div>
            <div class="text-[10px] text-zinc-400">Sensors & Actuators</div>
          </div>

          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 02</div>
            <div class="font-bold text-zinc-200">PLC与机器人控制</div>
            <div class="text-[10px] text-zinc-400">PLCs & Robots</div>
          </div>

          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 03</div>
            <div class="font-bold text-zinc-200">边缘计算网关</div>
            <div class="text-[10px] text-zinc-400">Edge Gateways</div>
          </div>

          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 04</div>
            <div class="font-bold text-zinc-200">工业消息总线</div>
            <div class="text-[10px] text-zinc-400">OPC-UA / MQTT</div>
          </div>

          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 05</div>
            <div class="font-bold text-zinc-200">数字孪生引擎</div>
            <div class="text-[10px] text-zinc-400">Digital Twin Core</div>
          </div>

          <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <div class="text-[10px] text-emerald-400">Layer 06</div>
            <div class="font-bold text-zinc-200">AI 决策分析</div>
            <div class="text-[10px] text-zinc-400">AI Analytics & MES</div>
          </div>
        </div>
      </div>

      <!-- Gateways Live Telemetry Table -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
          <mat-icon class="text-emerald-400 text-sm">router</mat-icon>
          <span>{{ i18n.isZh() ? '全厂边缘数据采集网关状态矩阵' : 'Edge Data Gateway Fleet Status' }}</span>
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (gw of sim.iiotGateways(); track gw.id) {
            <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2 text-xs font-industrial-mono">
              <div class="flex items-center justify-between">
                <span class="font-bold text-zinc-100">{{ gw.name }}</span>
                <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">{{ gw.protocol }}</span>
              </div>

              <div class="text-[11px] text-zinc-400">IP: {{ gw.ip }} · {{ i18n.isZh() ? gw.zoneZh : gw.zone }}</div>

              <div class="pt-2 border-t border-zinc-800 grid grid-cols-3 gap-2 text-center text-[10px]">
                <div class="p-1.5 rounded bg-zinc-900">
                  <span class="text-zinc-400">点位数</span>
                  <div class="font-bold text-zinc-200 mt-0.5">{{ gw.connectedNodes }}</div>
                </div>
                <div class="p-1.5 rounded bg-zinc-900">
                  <span class="text-zinc-400">速率</span>
                  <div class="font-bold text-zinc-200 mt-0.5">{{ gw.packetRateMsgS }} m/s</div>
                </div>
                <div class="p-1.5 rounded bg-zinc-900">
                  <span class="text-zinc-400">延迟</span>
                  <div class="font-bold text-emerald-400 mt-0.5">{{ gw.latencyMs }} ms</div>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class IIoTEdgeViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);
}
