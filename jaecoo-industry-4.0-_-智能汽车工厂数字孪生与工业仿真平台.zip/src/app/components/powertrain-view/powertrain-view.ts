import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { PowertrainTwin } from '../../models/factory.types';

@Component({
  selector: 'app-powertrain-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">settings_input_component</mat-icon>
            <span>{{ i18n.t('nav.powertrain') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '模块化动力总成与电驱动 (EDU) 数字化装配' : 'Modular Powertrain & Electric Drive Unit Assembly' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '支持燃油 (ICE)、插电混动 (PHEV) 与纯电双电机 (BEV) 柔性混线装配与台架动态测试' : 'Modular ICE, PHEV Super Hybrid, and BEV dual-motor electric drive flexible assembly line.' }}
          </p>
        </div>

        <div class="flex items-center gap-2">
          @for (pt of sim.powertrains(); track pt.unitId) {
            <button
              (click)="selectedUnit.set(pt)"
              [class.bg-emerald-500]="selectedUnit().unitId === pt.unitId"
              [class.text-zinc-950]="selectedUnit().unitId === pt.unitId"
              [class.text-zinc-300]="selectedUnit().unitId !== pt.unitId"
              class="px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-bold font-industrial-mono hover:bg-zinc-800 transition-all cursor-pointer">
              {{ pt.unitId }}
            </button>
          }
        </div>
      </div>

      <!-- Active Powertrain Twin Detail Card -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Dyno Test Specs (1 Col) -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between font-industrial-mono">
            <div>
              <span class="text-xs text-emerald-400 font-bold">{{ selectedUnit().unitId }}</span>
              <div class="text-base font-extrabold text-zinc-100">{{ selectedUnit().typeZh }}</div>
            </div>
            <span class="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-bold">
              {{ selectedUnit().testResult }}
            </span>
          </div>

          <div class="space-y-2.5 text-xs font-industrial-mono">
            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">实测峰值扭矩:</span>
              <strong class="text-emerald-400 text-base font-bold">{{ selectedUnit().testedTorqueNm }} / {{ selectedUnit().torqueMaxNm }} Nm</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">台架测试转速:</span>
              <strong class="text-zinc-200 text-sm font-bold">{{ selectedUnit().testedRpm }} RPM</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">电驱综合效率:</span>
              <strong class="text-emerald-400 text-sm font-bold">{{ selectedUnit().efficiencyPct }}%</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">逆变器结温 / 振动:</span>
              <strong class="text-zinc-200 text-sm font-bold">{{ selectedUnit().inverterTempC }}℃ / {{ selectedUnit().vibrationRms }} mm/s</strong>
            </div>
          </div>
        </div>

        <!-- Assembly Components Traceability (2 Cols) -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">memory</mat-icon>
            <span>{{ i18n.isZh() ? '动力总成核心模块序列号溯源' : 'Core Subassembly Component Serial Codes' }}</span>
          </h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            @for (comp of selectedUnit().components; track comp.serial) {
              <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-1.5">
                <div class="flex items-center justify-between font-industrial-mono">
                  <span class="font-bold text-zinc-200">{{ i18n.isZh() ? comp.nameZh : comp.name }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">{{ comp.status }}</span>
                </div>
                <div class="text-[11px] text-zinc-400 font-industrial-mono">
                  S/N: <strong class="text-emerald-400">{{ comp.serial }}</strong>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class PowertrainViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedUnit = signal<PowertrainTwin>(this.sim.powertrains()[0]);
}
