import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-what-if-simulation',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">alt_route</mat-icon>
            <span>{{ i18n.t('nav.scenarios') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '制造仿真情景推演与 What-If 方案多维对比' : 'Manufacturing What-If Simulation & Scenario Comparison' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '注入突发故障与产能爬坡情景，实时推演上下游节拍传导与生产经济性' : 'Simulate equipment disruptions, ramp-up demand, and compare Current vs Proposed operations.' }}
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs text-zinc-400 font-industrial-mono">{{ i18n.isZh() ? '当前激活场景: ' : 'Active: ' }}</span>
          <span class="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold font-industrial-mono">
            {{ sim.activeScenario().id }}
          </span>
        </div>
      </div>

      <!-- Predefined Scenario Selection Grid -->
      <div class="space-y-3">
        <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '预置典型工业场景库 (Scenario Library)' : 'Predefined Industrial Scenarios' }}
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (sc of sim.scenarios; track sc.id) {
            <button
              (click)="sim.setScenario(sc.id)"
              [class.border-emerald-500/50]="sim.activeScenario().id === sc.id"
              [class.bg-zinc-900]="sim.activeScenario().id === sc.id"
              [class.border-zinc-800]="sim.activeScenario().id !== sc.id"
              class="text-left w-full p-4 rounded-xl bg-zinc-950 border hover:border-zinc-700 transition-all cursor-pointer space-y-2 text-xs">
              <div class="flex items-center justify-between font-industrial-mono">
                <span class="font-bold text-zinc-200">{{ i18n.isZh() ? sc.nameZh : sc.name }}</span>
                @if (sim.activeScenario().id === sc.id) {
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500 text-zinc-950 font-bold">ACTIVE</span>
                }
              </div>
              <p class="text-[11px] text-zinc-400 leading-relaxed">{{ i18n.isZh() ? sc.descriptionZh : sc.description }}</p>
              <div class="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[10px] font-industrial-mono text-zinc-400">
                <span>节拍: <strong class="text-zinc-200">{{ sc.taktTimeSec }}s</strong></span>
                <span>单班目标: <strong class="text-emerald-400">{{ sc.demandVolumeShift }}台</strong></span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Split Screen What-If Comparison (Current vs Proposed) -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">compare_arrows</mat-icon>
            <span>{{ i18n.isZh() ? '方案多维对比 (Current vs Proposed Scheme)' : 'Scenario Side-by-Side Comparison' }}</span>
          </h3>
          <span class="text-xs text-zinc-400 font-industrial-mono">{{ i18n.isZh() ? '真实数学模型测算' : 'Calculated Industrial Model' }}</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Current Scheme Card -->
          <div class="p-5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3 text-xs font-industrial-mono">
            <div class="flex items-center justify-between pb-2 border-b border-zinc-800">
              <span class="text-sm font-extrabold text-zinc-200">方案 A · 当前运行基准 (Current)</span>
              <span class="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-bold">BASELINE</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-zinc-300">
              <div>节拍 Takt Time: <strong class="text-zinc-100">{{ sim.currentTaktTimeSec() }} 秒</strong></div>
              <div>单班产量 (UPH): <strong class="text-zinc-100">{{ sim.productionRateUph() }} 台/h</strong></div>
              <div>综合 OEE: <strong class="text-emerald-400">{{ sim.oeeMetrics().oee }}%</strong></div>
              <div>一次合格率 FPY: <strong class="text-emerald-400">{{ sim.firstPassYieldPct() }}%</strong></div>
              <div>单车制造成本: <strong class="text-zinc-100">¥{{ sim.energy().energyCostPerVehicleYuan }}</strong></div>
              <div>累计停机时间: <strong class="text-amber-400">6 分钟</strong></div>
            </div>
          </div>

          <!-- Proposed Scheme Card -->
          <div class="p-5 rounded-xl bg-emerald-500/10 border border-emerald-500/40 space-y-3 text-xs font-industrial-mono">
            <div class="flex items-center justify-between pb-2 border-b border-emerald-500/30">
              <span class="text-sm font-extrabold text-emerald-300">方案 B · 优化建议方案 (Proposed)</span>
              <span class="px-2 py-0.5 rounded bg-emerald-500 text-zinc-950 font-bold">OPTIMIZED</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-emerald-200">
              <div>节拍 Takt Time: <strong class="text-white">52 秒 (-13.3%)</strong></div>
              <div>单班产量 (UPH): <strong class="text-white">62 台/h (+19.2%)</strong></div>
              <div>综合 OEE: <strong class="text-emerald-300">93.4% (+5.6%)</strong></div>
              <div>一次合格率 FPY: <strong class="text-emerald-300">99.2% (+0.5%)</strong></div>
              <div>单车制造成本: <strong class="text-white">¥394.0 (-4.5%)</strong></div>
              <div>累计停机时间: <strong class="text-emerald-300">2 分钟 (-66.7%)</strong></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Digital Twin Time Machine Replay -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-purple-400 text-sm">history_toggle_drop_down</mat-icon>
            <span>{{ i18n.isZh() ? '数字孪生时光机历史回溯 (Time Machine Replay)' : 'Digital Twin Time Machine Historical Replay' }}</span>
          </h3>
          <span class="text-xs text-zinc-400 font-industrial-mono">{{ i18n.isZh() ? '每10分钟快照记录' : '10-Minute Snapshots' }}</span>
        </div>

        <div class="flex items-center gap-2 overflow-x-auto pb-2">
          @for (snap of sim.historySnapshots(); track snap.timeStr) {
            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-industrial-mono shrink-0 w-32 space-y-1">
              <div class="flex items-center justify-between font-bold text-zinc-200">
                <span>{{ snap.timeStr }}</span>
                <span class="text-emerald-400">{{ snap.oee }}%</span>
              </div>
              <div class="text-[10px] text-zinc-400">UPH: {{ snap.uph }}</div>
              <div class="text-[10px] text-zinc-400">下线: {{ snap.vehicles }}台</div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class WhatIfSimulationComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);
}
