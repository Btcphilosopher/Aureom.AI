import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject,
  signal
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { FactoryZoneId } from '../../models/factory.types';

@Component({
  selector: 'app-factory-3d',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[calc(100vh-4rem)] bg-zinc-950 overflow-hidden select-none flex flex-col">
      <!-- 3D WebGL Canvas Container -->
      <div #canvasContainer class="relative w-full flex-1 cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay Controls: Camera Presets & Layer Toggles -->
      <div class="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2.5 pointer-events-none z-10">
        <!-- Camera View Presets -->
        <div class="flex items-center gap-1 bg-zinc-950/85 backdrop-blur-md p-1 rounded-2xl border border-zinc-800 shadow-xl pointer-events-auto">
          @for (preset of cameraPresets; track preset.id) {
            <button
              (click)="setCameraPreset(preset.id)"
              [class.bg-emerald-500]="activeCameraPreset() === preset.id"
              [class.text-zinc-950]="activeCameraPreset() === preset.id"
              [class.text-zinc-300]="activeCameraPreset() !== preset.id"
              class="px-2.5 py-1.5 rounded-xl text-xs font-semibold hover:bg-zinc-800 hover:text-white transition-all cursor-pointer flex items-center gap-1">
              <mat-icon class="text-xs">{{ preset.icon }}</mat-icon>
              <span>{{ i18n.isZh() ? preset.nameZh : preset.nameEn }}</span>
            </button>
          }
        </div>

        <!-- Layer Visibility Toggles -->
        <div class="flex items-center gap-1.5 bg-zinc-950/85 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-zinc-800 shadow-xl pointer-events-auto text-xs">
          <span class="text-zinc-400 font-medium mr-1">{{ i18n.isZh() ? '图层:' : 'Layers:' }}</span>

          <button
            (click)="toggleLayer('robots')"
            [class.text-emerald-400]="layers.robots"
            [class.bg-emerald-500/10]="layers.robots"
            [class.border-emerald-500/30]="layers.robots"
            [class.text-zinc-500]="!layers.robots"
            class="px-2 py-1 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors flex items-center gap-1 cursor-pointer font-medium">
            <mat-icon class="text-xs">smart_toy</mat-icon>
            <span>{{ i18n.isZh() ? '机器人' : 'Robots' }}</span>
          </button>

          <button
            (click)="toggleLayer('agvs')"
            [class.text-emerald-400]="layers.agvs"
            [class.bg-emerald-500/10]="layers.agvs"
            [class.border-emerald-500/30]="layers.agvs"
            [class.text-zinc-500]="!layers.agvs"
            class="px-2 py-1 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors flex items-center gap-1 cursor-pointer font-medium">
            <mat-icon class="text-xs">local_shipping</mat-icon>
            <span>{{ i18n.isZh() ? 'AGV物流' : 'AGVs' }}</span>
          </button>

          <button
            (click)="toggleLayer('grid')"
            [class.text-emerald-400]="layers.grid"
            [class.bg-emerald-500/10]="layers.grid"
            [class.border-emerald-500/30]="layers.grid"
            [class.text-zinc-500]="!layers.grid"
            class="px-2 py-1 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors flex items-center gap-1 cursor-pointer font-medium">
            <mat-icon class="text-xs">bolt</mat-icon>
            <span>{{ i18n.isZh() ? '能源管网' : 'Energy' }}</span>
          </button>

          <button
            (click)="toggleLayer('labels')"
            [class.text-emerald-400]="layers.labels"
            [class.bg-emerald-500/10]="layers.labels"
            [class.border-emerald-500/30]="layers.labels"
            [class.text-zinc-500]="!layers.labels"
            class="px-2 py-1 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors flex items-center gap-1 cursor-pointer font-medium">
            <mat-icon class="text-xs">label</mat-icon>
            <span>{{ i18n.isZh() ? '车间标识' : 'Labels' }}</span>
          </button>
        </div>
      </div>

      <!-- Hover / Selection Tooltip HUD -->
      @if (hoveredInfo()) {
        <div class="absolute bottom-6 left-6 bg-zinc-950/90 backdrop-blur-md p-4 rounded-2xl border border-emerald-500/40 shadow-2xl z-20 max-w-sm pointer-events-none animate-fadeIn">
          <div class="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-1">
            <mat-icon class="text-base">{{ hoveredInfo()!.icon }}</mat-icon>
            <span>{{ hoveredInfo()!.title }}</span>
          </div>
          <p class="text-xs text-zinc-300 leading-relaxed">{{ hoveredInfo()!.description }}</p>
          <div class="mt-2.5 pt-2 border-t border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400 font-industrial-mono">
            <span>{{ i18n.isZh() ? '实时状态: ' : 'Status: ' }}<strong class="text-emerald-400">{{ hoveredInfo()!.status }}</strong></span>
            <span>{{ i18n.isZh() ? '点击进入数字孪生卡片' : 'Click to inspect digital twin' }}</span>
          </div>
        </div>
      }

      <!-- Bottom Quick Navigation Bar for Zones -->
      <div class="absolute bottom-4 right-4 flex items-center gap-1 bg-zinc-950/80 backdrop-blur-md p-1.5 rounded-2xl border border-zinc-800 z-10 text-xs">
        <span class="text-zinc-400 font-medium px-2">{{ i18n.isZh() ? '快速聚焦车间:' : 'Focus Zone:' }}</span>
        @for (zone of quickZones; track zone.id) {
          <button
            (click)="focusZone(zone.id)"
            class="px-2.5 py-1 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-emerald-400 transition-colors cursor-pointer font-medium">
            {{ i18n.isZh() ? zone.nameZh : zone.nameEn }}
          </button>
        }
      </div>
    </div>
  `
})
export class Factory3DComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  activeCameraPreset = signal<string>('ISO');
  hoveredInfo = signal<{ title: string; description: string; status: string; icon: string } | null>(null);

  layers = {
    robots: true,
    agvs: true,
    grid: true,
    labels: true
  };

  cameraPresets = [
    { id: 'ISO', icon: 'view_in_ar', nameZh: '鸟瞰全景', nameEn: 'Birds Eye' },
    { id: 'ASSEMBLY', icon: 'linear_scale', nameZh: '总装产线', nameEn: 'Assembly Line' },
    { id: 'BODY', icon: 'smart_toy', nameZh: '焊装车间', nameEn: 'Body Shop' },
    { id: 'PAINT', icon: 'format_paint', nameZh: '涂装车间', nameEn: 'Paint Shop' },
    { id: 'BATTERY', icon: 'battery_charging_full', nameZh: '电池工厂', nameEn: 'Battery Plant' },
    { id: 'WAREHOUSE', icon: 'warehouse', nameZh: '智能立库', nameEn: 'Warehouse' },
    { id: 'TOP', icon: 'layers', nameZh: '2D 俯视', nameEn: 'Top View' }
  ];

  quickZones: { id: FactoryZoneId; nameZh: string; nameEn: string }[] = [
    { id: 'press_shop', nameZh: '冲压', nameEn: 'Press' },
    { id: 'body_shop', nameZh: '焊装', nameEn: 'Body' },
    { id: 'paint_shop', nameZh: '涂装', nameEn: 'Paint' },
    { id: 'battery_plant', nameZh: '电池', nameEn: 'Battery' },
    { id: 'general_assembly', nameZh: '总装', nameEn: 'Assembly' },
    { id: 'smart_warehouse', nameZh: '立库', nameEn: 'Warehouse' }
  ];

  // Three.js internal objects
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId = 0;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  private robotMeshes: THREE.Group[] = [];
  private agvMeshes: THREE.Group[] = [];
  private vehicleMeshes: THREE.Group[] = [];
  private zoneLabelsGroup = new THREE.Group();
  private energyGridGroup = new THREE.Group();
  private interactiveObjects: THREE.Object3D[] = [];

  // Camera animation target
  private targetCamPos = new THREE.Vector3(75, 55, 75);
  private targetLookAt = new THREE.Vector3(0, 0, 0);
  private currentLookAt = new THREE.Vector3(0, 0, 0);

  // Mouse interaction state
  private isMouseDown = false;
  private mouseStartPos = { x: 0, y: 0 };
  private camAngleH = Math.PI / 4;
  private camAngleV = Math.PI / 5;
  private camDistance = 110;

  ngOnInit() {
    if (typeof window !== 'undefined') {
      this.initThree();
      this.setupEventListeners();
      this.animate();
    }
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || window.innerWidth - 256;
    const height = container.clientHeight || window.innerHeight - 64;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x09090b);
    this.scene.fog = new THREE.FogExp2(0x09090b, 0.005);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 500);
    this.camera.position.set(75, 55, 75);
    this.camera.lookAt(0, 0, 0);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 4. Lighting (Neutral daylight industrial scheme)
    const ambientLight = new THREE.AmbientLight(0xd4d4d8, 0.85);
    this.scene.add(ambientLight);

    const mainSun = new THREE.DirectionalLight(0xffffff, 1.4);
    mainSun.position.set(50, 90, 40);
    mainSun.castShadow = true;
    mainSun.shadow.mapSize.width = 2048;
    mainSun.shadow.mapSize.height = 2048;
    mainSun.shadow.camera.near = 10;
    mainSun.shadow.camera.far = 200;
    mainSun.shadow.camera.left = -90;
    mainSun.shadow.camera.right = 90;
    mainSun.shadow.camera.top = 90;
    mainSun.shadow.camera.bottom = -90;
    this.scene.add(mainSun);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.3);
    fillLight.position.set(-50, 40, -40);
    this.scene.add(fillLight);

    // 5. Build Factory Environment
    this.buildFactoryFloor();
    this.buildStructuralGantries();
    this.buildAssemblyLineTrack();
    this.buildShopZones();
    this.buildRobots();
    this.buildAgvs();
    this.buildWarehouseRacks();
    this.buildEnergyGrid();
    this.buildZoneBillboards();
  }

  private buildFactoryFloor() {
    // Concrete industrial floor with subtle grid
    const floorGeo = new THREE.PlaneGeometry(180, 140);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.8,
      metalness: 0.2
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // Grid helper overlay
    const grid = new THREE.GridHelper(180, 45, 0x27272a, 0x1f1f23);
    grid.position.y = 0.02;
    this.scene.add(grid);

    // Floor Track Lines (Yellow / White Safety Markings)
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xeab308, side: THREE.DoubleSide });
    const agvTrackGeo = new THREE.RingGeometry(22, 22.3, 32);
    const agvTrack = new THREE.Mesh(agvTrackGeo, lineMat);
    agvTrack.rotation.x = -Math.PI / 2;
    agvTrack.position.set(0, 0.03, 0);
    this.scene.add(agvTrack);
  }

  private buildStructuralGantries() {
    const trussMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.8, roughness: 0.4 });
    const colGeo = new THREE.BoxGeometry(1.2, 22, 1.2);

    // Perimeter structural columns
    const colPositions = [
      [-75, 11, -55], [-75, 11, 0], [-75, 11, 55],
      [75, 11, -55], [75, 11, 0], [75, 11, 55],
      [-25, 11, -55], [25, 11, -55],
      [-25, 11, 55], [25, 11, 55]
    ];

    colPositions.forEach(pos => {
      const col = new THREE.Mesh(colGeo, trussMat);
      col.position.set(pos[0], pos[1], pos[2]);
      col.castShadow = true;
      col.receiveShadow = true;
      this.scene.add(col);
    });

    // Overhead gantry crane beam
    const beamGeo = new THREE.BoxGeometry(150, 1.4, 2);
    const beam = new THREE.Mesh(beamGeo, trussMat);
    beam.position.set(0, 20, 0);
    this.scene.add(beam);
  }

  private buildAssemblyLineTrack() {
    const trackMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, metalness: 0.9, roughness: 0.3 });

    // Main Assembly Conveyor Belt
    const conveyorGeo = new THREE.BoxGeometry(60, 0.6, 6);
    const conveyor = new THREE.Mesh(conveyorGeo, trackMat);
    conveyor.position.set(0, 0.3, 0);
    conveyor.receiveShadow = true;
    this.scene.add(conveyor);

    // Conveyor support legs
    for (let x = -28; x <= 28; x += 7) {
      const legGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 8);
      const leg1 = new THREE.Mesh(legGeo, trackMat);
      leg1.position.set(x, 0.3, -2.8);
      this.scene.add(leg1);

      const leg2 = new THREE.Mesh(legGeo, trackMat);
      leg2.position.set(x, 0.3, 2.8);
      this.scene.add(leg2);
    }

    // Vehicle chassis models on conveyor
    for (let i = 0; i < 4; i++) {
      const vehGroup = this.createVehicleChassisMesh(i === 0 ? 0x18181b : (i === 1 ? 0xf4f4f5 : 0x0284c7));
      vehGroup.position.set(-20 + i * 14, 1.2, 0);
      this.scene.add(vehGroup);
      this.vehicleMeshes.push(vehGroup);
      this.interactiveObjects.push(vehGroup);
    }
  }

  private createVehicleChassisMesh(colorHex: number): THREE.Group {
    const group = new THREE.Group();
    group.name = 'VEHICLE_CHASSIS';

    // Main Body Cabin
    const bodyGeo = new THREE.BoxGeometry(7.2, 2.0, 3.2);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      metalness: 0.6,
      roughness: 0.2
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 1.0;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    // Roof & Greenhouse Cabin
    const roofGeo = new THREE.BoxGeometry(4.2, 1.4, 2.8);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      metalness: 0.9,
      roughness: 0.1,
      transparent: true,
      opacity: 0.85
    });
    const roof = new THREE.Mesh(roofGeo, glassMat);
    roof.position.set(-0.4, 2.4, 0);
    roof.castShadow = true;
    group.add(roof);

    // 4 Wheels
    const wheelGeo = new THREE.CylinderGeometry(0.8, 0.8, 0.5, 16);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
    const wheelPositions = [
      [2.2, 0.4, 1.7], [2.2, 0.4, -1.7],
      [-2.2, 0.4, 1.7], [-2.2, 0.4, -1.7]
    ];

    wheelPositions.forEach(pos => {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.rotation.x = Math.PI / 2;
      wheel.position.set(pos[0], pos[1], pos[2]);
      wheel.castShadow = true;
      group.add(wheel);
    });

    return group;
  }

  private buildShopZones() {
    // 1. Press Shop (Heavy 2500T Stamping Press)
    const pressGroup = new THREE.Group();
    const pressGeo = new THREE.BoxGeometry(10, 14, 10);
    const pressMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.8, roughness: 0.3 });
    const pressMesh = new THREE.Mesh(pressGeo, pressMat);
    pressMesh.position.set(-50, 7, -25);
    pressMesh.castShadow = true;
    pressGroup.add(pressMesh);

    // Stamping Die Crown
    const crownGeo = new THREE.BoxGeometry(8, 3, 8);
    const crownMat = new THREE.MeshStandardMaterial({ color: 0x059669, metalness: 0.5, roughness: 0.4 });
    const crown = new THREE.Mesh(crownGeo, crownMat);
    crown.position.set(-50, 12, -25);
    pressGroup.add(crown);
    this.scene.add(pressGroup);

    // 2. Paint Shop (Glass Enclosed Booth)
    const paintBoothGeo = new THREE.BoxGeometry(24, 8, 16);
    const boothMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.2,
      roughness: 0.1,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide
    });
    const paintBooth = new THREE.Mesh(paintBoothGeo, boothMat);
    paintBooth.position.set(-18, 4, 25);
    this.scene.add(paintBooth);

    // 3. Battery Plant (Cell assembly line table)
    const batTableGeo = new THREE.BoxGeometry(22, 1.2, 12);
    const batTableMat = new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.6, roughness: 0.4 });
    const batTable = new THREE.Mesh(batTableGeo, batTableMat);
    batTable.position.set(40, 0.6, -25);
    this.scene.add(batTable);
  }

  private buildRobots() {
    const simRobots = this.sim.robots();
    const baseMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.6, roughness: 0.3 }); // Industrial Robot Yellow/Orange
    const linkMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.2 });

    simRobots.forEach((r) => {
      const robotGroup = new THREE.Group();
      robotGroup.name = `ROBOT_${r.id}`;
      robotGroup.userData = { entityType: 'robot', id: r.id, data: r };

      // Base Pedestal
      const baseGeo = new THREE.CylinderGeometry(1.2, 1.4, 0.8, 16);
      const base = new THREE.Mesh(baseGeo, linkMat);
      base.position.y = 0.4;
      base.castShadow = true;
      robotGroup.add(base);

      // Shoulder Link (J1)
      const shoulderGeo = new THREE.BoxGeometry(1.4, 1.8, 1.4);
      const shoulder = new THREE.Mesh(shoulderGeo, baseMat);
      shoulder.position.y = 1.6;
      shoulder.castShadow = true;
      robotGroup.add(shoulder);

      // Upper Arm (J2)
      const arm1Geo = new THREE.BoxGeometry(0.8, 3.8, 0.8);
      const arm1 = new THREE.Mesh(arm1Geo, baseMat);
      arm1.position.set(0, 3.8, 0.6);
      arm1.rotation.x = -Math.PI / 6;
      arm1.castShadow = true;
      robotGroup.add(arm1);

      // Forearm (J3) & Tool Holder
      const arm2Geo = new THREE.BoxGeometry(0.6, 3.2, 0.6);
      const arm2 = new THREE.Mesh(arm2Geo, linkMat);
      arm2.position.set(0, 5.8, 1.4);
      arm2.rotation.x = Math.PI / 4;
      arm2.castShadow = true;
      robotGroup.add(arm2);

      // Weld Gun / Gripper End Effector
      const toolGeo = new THREE.ConeGeometry(0.3, 1.0, 8);
      const toolMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.5 });
      const tool = new THREE.Mesh(toolGeo, toolMat);
      tool.rotation.x = Math.PI;
      tool.position.set(0, 6.8, 2.2);
      robotGroup.add(tool);

      robotGroup.position.set(r.position[0], r.position[1], r.position[2]);
      this.scene.add(robotGroup);
      this.robotMeshes.push(robotGroup);
      this.interactiveObjects.push(robotGroup);
    });
  }

  private buildAgvs() {
    const simAgvs = this.sim.agvs();
    const agvMat = new THREE.MeshStandardMaterial({ color: 0x059669, metalness: 0.5, roughness: 0.3 });

    simAgvs.forEach(agv => {
      const agvGroup = new THREE.Group();
      agvGroup.name = `AGV_${agv.id}`;
      agvGroup.userData = { entityType: 'agv', id: agv.id, data: agv };

      // Chassis
      const chassisGeo = new THREE.BoxGeometry(2.8, 0.6, 1.8);
      const chassis = new THREE.Mesh(chassisGeo, agvMat);
      chassis.position.y = 0.4;
      chassis.castShadow = true;
      agvGroup.add(chassis);

      // Payload container on top
      const loadGeo = new THREE.BoxGeometry(2.2, 0.8, 1.4);
      const loadMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.5 });
      const load = new THREE.Mesh(loadGeo, loadMat);
      load.position.y = 1.0;
      load.castShadow = true;
      agvGroup.add(load);

      // Glowing LiDAR Scanner Head
      const lidarGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.3, 16);
      const lidarMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const lidar = new THREE.Mesh(lidarGeo, lidarMat);
      lidar.position.set(1.2, 0.85, 0);
      agvGroup.add(lidar);

      agvGroup.position.set(agv.x, 0, agv.z);
      this.scene.add(agvGroup);
      this.agvMeshes.push(agvGroup);
      this.interactiveObjects.push(agvGroup);
    });
  }

  private buildWarehouseRacks() {
    const rackMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.7, roughness: 0.4 });
    const boxMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.8 });

    // 4 High-Bay Racks in warehouse zone (x: 45 to 65, z: 15 to 45)
    for (let r = 0; r < 4; r++) {
      const rackGroup = new THREE.Group();
      const zPos = 15 + r * 8;

      // Vertical Uprights
      for (let x = 40; x <= 65; x += 5) {
        const upGeo = new THREE.BoxGeometry(0.3, 12, 0.3);
        const upMesh = new THREE.Mesh(upGeo, rackMat);
        upMesh.position.set(x, 6, zPos);
        upMesh.castShadow = true;
        rackGroup.add(upMesh);
      }

      // Horizontal Shelf Beams (3 tiers)
      for (let tier = 1; tier <= 3; tier++) {
        const beamGeo = new THREE.BoxGeometry(26, 0.2, 2.5);
        const beamMesh = new THREE.Mesh(beamGeo, rackMat);
        beamMesh.position.set(52.5, tier * 3.5, zPos);
        rackGroup.add(beamMesh);

        // Pallet Boxes on Shelves
        for (let bx = 42; bx <= 62; bx += 4) {
          const bGeo = new THREE.BoxGeometry(2.0, 1.8, 2.0);
          const bMesh = new THREE.Mesh(bGeo, boxMat);
          bMesh.position.set(bx, tier * 3.5 + 1.0, zPos);
          bMesh.castShadow = true;
          rackGroup.add(bMesh);
        }
      }

      rackGroup.userData = { entityType: 'rack', id: `RK-${r + 1}` };
      this.scene.add(rackGroup);
      this.interactiveObjects.push(rackGroup);
    }
  }

  private buildEnergyGrid() {
    // Glowing green power distribution lines
    const lineMat = new THREE.LineBasicMaterial({ color: 0x10b981, linewidth: 2 });
    const points = [
      new THREE.Vector3(-60, 0.1, -40),
      new THREE.Vector3(-60, 0.1, 0),
      new THREE.Vector3(0, 0.1, 0),
      new THREE.Vector3(60, 0.1, 0),
      new THREE.Vector3(60, 0.1, -40),
      new THREE.Vector3(60, 0.1, 40),
      new THREE.Vector3(-60, 0.1, 40)
    ];
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    const line = new THREE.Line(geo, lineMat);
    this.energyGridGroup.add(line);
    this.scene.add(this.energyGridGroup);
  }

  private buildZoneBillboards() {
    // 3D Text/Signpost Labels for Factory Zones
    const zones = [
      { text: 'PRESS SHOP / 冲压车间', pos: [-50, 15, -25] },
      { text: 'BODY SHOP / 焊装车间', pos: [-15, 12, -18] },
      { text: 'PAINT SHOP / 涂装车间', pos: [-18, 10, 25] },
      { text: 'BATTERY PLANT / 电池车间', pos: [40, 10, -25] },
      { text: 'GENERAL ASSEMBLY / 总装车间', pos: [0, 8, 0] },
      { text: 'SMART WAREHOUSE / 智能立库', pos: [52, 14, 25] }
    ];

    zones.forEach(z => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = 'rgba(24, 24, 27, 0.85)';
        ctx.roundRect(10, 10, 492, 108, 16);
        ctx.fill();
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 4;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 28px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(z.text, 256, 72);
      }

      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.set(z.pos[0], z.pos[1], z.pos[2]);
      sprite.scale.set(16, 4, 1);
      this.zoneLabelsGroup.add(sprite);
    });

    this.scene.add(this.zoneLabelsGroup);
  }

  private setupEventListeners() {
    const dom = this.renderer.domElement;

    dom.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.mouseStartPos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    dom.addEventListener('mousemove', (e) => {
      if (this.isMouseDown) {
        const deltaX = e.clientX - this.mouseStartPos.x;
        const deltaY = e.clientY - this.mouseStartPos.y;
        this.mouseStartPos = { x: e.clientX, y: e.clientY };

        this.camAngleH -= deltaX * 0.008;
        this.camAngleV = Math.max(0.1, Math.min(Math.PI / 2.2, this.camAngleV + deltaY * 0.008));
        this.updateCameraOrbit();
      }

      // Raycasting for Hover HUD
      const rect = dom.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.performHoverRaycast();
    });

    dom.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.camDistance = Math.max(25, Math.min(180, this.camDistance + e.deltaY * 0.08));
      this.updateCameraOrbit();
    }, { passive: false });

    dom.addEventListener('click', () => {
      this.performClickRaycast();
    });

    window.addEventListener('resize', () => {
      const container = this.containerRef.nativeElement;
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  private updateCameraOrbit() {
    this.targetCamPos.x = this.targetLookAt.x + this.camDistance * Math.sin(this.camAngleH) * Math.cos(this.camAngleV);
    this.targetCamPos.y = this.targetLookAt.y + this.camDistance * Math.sin(this.camAngleV);
    this.targetCamPos.z = this.targetLookAt.z + this.camDistance * Math.cos(this.camAngleH) * Math.cos(this.camAngleV);
  }

  private performHoverRaycast() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.interactiveObjects, true);

    if (intersects.length > 0) {
      let topObj: THREE.Object3D | null = intersects[0].object;
      while (topObj && !topObj.userData['entityType'] && topObj.parent !== this.scene) {
        topObj = topObj.parent;
      }

      if (topObj && topObj.userData['entityType']) {
        const u = topObj.userData;
        if (u['entityType'] === 'robot') {
          const r = this.sim.robots().find(x => x.id === u['id']);
          if (r) {
            this.hoveredInfo.set({
              title: this.i18n.isZh() ? r.nameZh : r.name,
              description: this.i18n.isZh() ? `${r.cellZh} | 当前任务: ${r.currentTaskZh}` : `${r.cell} | Task: ${r.currentTask}`,
              status: `${r.state} (${r.temperatureC}℃ | ${r.utilizationPct}%)`,
              icon: 'smart_toy'
            });
            return;
          }
        } else if (u['entityType'] === 'agv') {
          const a = this.sim.agvs().find(x => x.id === u['id']);
          if (a) {
            this.hoveredInfo.set({
              title: `${a.id} (${a.model})`,
              description: this.i18n.isZh() ? `运载: ${a.payloadTypeZh} -> 目的: ${a.destinationNameZh}` : `Payload: ${a.payloadType} -> Destination: ${a.destinationName}`,
              status: `${a.status} (电量: ${a.batteryPct}%)`,
              icon: 'local_shipping'
            });
            return;
          }
        }
      }
    }
    this.hoveredInfo.set(null);
  }

  private performClickRaycast() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.interactiveObjects, true);

    if (intersects.length > 0) {
      let topObj: THREE.Object3D | null = intersects[0].object;
      while (topObj && !topObj.userData['entityType'] && topObj.parent !== this.scene) {
        topObj = topObj.parent;
      }

      if (topObj && topObj.userData['entityType']) {
        const u = topObj.userData;
        this.sim.selectObject(u['entityType'], u['id']);
      }
    }
  }

  setCameraPreset(presetId: string) {
    this.activeCameraPreset.set(presetId);
    switch (presetId) {
      case 'ISO':
        this.camDistance = 110;
        this.camAngleH = Math.PI / 4;
        this.camAngleV = Math.PI / 5;
        this.targetLookAt.set(0, 0, 0);
        break;
      case 'ASSEMBLY':
        this.camDistance = 45;
        this.camAngleH = 0.2;
        this.camAngleV = 0.4;
        this.targetLookAt.set(0, 2, 0);
        break;
      case 'BODY':
        this.camDistance = 38;
        this.camAngleH = Math.PI / 3;
        this.camAngleV = 0.35;
        this.targetLookAt.set(-15, 2, -18);
        break;
      case 'PAINT':
        this.camDistance = 40;
        this.camAngleH = -Math.PI / 4;
        this.camAngleV = 0.3;
        this.targetLookAt.set(-18, 3, 25);
        break;
      case 'BATTERY':
        this.camDistance = 42;
        this.camAngleH = Math.PI / 6;
        this.camAngleV = 0.35;
        this.targetLookAt.set(40, 2, -25);
        break;
      case 'WAREHOUSE':
        this.camDistance = 50;
        this.camAngleH = Math.PI / 4;
        this.camAngleV = 0.4;
        this.targetLookAt.set(52, 5, 25);
        break;
      case 'TOP':
        this.camDistance = 130;
        this.camAngleH = 0;
        this.camAngleV = Math.PI / 2.05;
        this.targetLookAt.set(0, 0, 0);
        break;
    }
    this.updateCameraOrbit();
  }

  focusZone(zoneId: FactoryZoneId) {
    switch (zoneId) {
      case 'press_shop':
        this.targetLookAt.set(-50, 4, -25);
        this.camDistance = 40;
        break;
      case 'body_shop':
        this.targetLookAt.set(-15, 2, -18);
        this.camDistance = 38;
        break;
      case 'paint_shop':
        this.targetLookAt.set(-18, 3, 25);
        this.camDistance = 40;
        break;
      case 'battery_plant':
        this.targetLookAt.set(40, 2, -25);
        this.camDistance = 42;
        break;
      case 'general_assembly':
        this.targetLookAt.set(0, 2, 0);
        this.camDistance = 45;
        break;
      case 'smart_warehouse':
        this.targetLookAt.set(52, 5, 25);
        this.camDistance = 50;
        break;
    }
    this.updateCameraOrbit();
  }

  toggleLayer(layer: 'robots' | 'agvs' | 'grid' | 'labels') {
    this.layers[layer] = !this.layers[layer];
    if (layer === 'robots') {
      this.robotMeshes.forEach(m => (m.visible = this.layers.robots));
    } else if (layer === 'agvs') {
      this.agvMeshes.forEach(m => (m.visible = this.layers.agvs));
    } else if (layer === 'grid') {
      this.energyGridGroup.visible = this.layers.grid;
    } else if (layer === 'labels') {
      this.zoneLabelsGroup.visible = this.layers.labels;
    }
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    // Smooth camera interpolation
    this.camera.position.lerp(this.targetCamPos, 0.08);
    this.currentLookAt.lerp(this.targetLookAt, 0.08);
    this.camera.lookAt(this.currentLookAt);

    // Animate AGVs based on simulation state
    const agvs = this.sim.agvs();
    this.agvMeshes.forEach((mesh, idx) => {
      const data = agvs[idx];
      if (data) {
        mesh.position.x = data.x;
        mesh.position.z = data.z;
        mesh.rotation.y = Math.atan2(data.targetX - data.x, data.targetZ - data.z);
      }
    });

    // Animate Conveyor Vehicles smooth drift
    this.vehicleMeshes.forEach((vMesh) => {
      vMesh.position.x += 0.02 * (this.sim.isPlaying() ? this.sim.speedMultiplier() : 0);
      if (vMesh.position.x > 30) {
        vMesh.position.x = -26;
      }
    });

    this.renderer.render(this.scene, this.camera);
  };
}
