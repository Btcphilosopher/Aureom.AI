import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-overview-dashboard',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Top Title & Shift Status Banner -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-zinc-900/90 to-zinc-950 p-5 rounded-2xl border border-zinc-800 shadow-lg">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold tracking-wider uppercase mb-1">
            <mat-icon class="text-sm">analytics</mat-icon>
            <span>{{ i18n.t('nav.overview') }} · {{ i18n.isZh() ? '数字孪生实时中控' : 'Digital Twin Central Command' }}</span>
          </div>
          <h1 class="text-2xl font-extrabold text-zinc-100 tracking-tight">
            {{ i18n.isZh() ? 'JAECOO 智能整车制造数字化总览' : 'JAECOO Intelligent Manufacturing Operations Cockpit' }}
          </h1>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '全厂16大车间、12个总装工位、16台重载机器人与微电网实时在线仿真闭环' : 'Live closed-loop discrete simulation across 16 zones, 12 assembly stations, 16 robotics cells, and microgrid.' }}
          </p>
        </div>

        <!-- Quick Action Trigger Buttons -->
        <div class="flex items-center gap-2.5 shrink-0">
          <button
            (click)="navigateTab.emit('factory3d')"
            class="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm text-emerald-400">view_in_ar</mat-icon>
            <span>{{ i18n.t('nav.factory3d') }}</span>
          </button>

          <button
            (click)="navigateTab.emit('scenarios')"
            class="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm text-amber-400">alt_route</mat-icon>
            <span>{{ i18n.t('nav.scenarios') }}</span>
          </button>

          <button
            (click)="openAI.emit()"
            class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950/60 transition-all cursor-pointer flex items-center gap-1.5">
            <mat-icon class="text-sm">auto_awesome</mat-icon>
            <span>{{ i18n.t('header.aiAssist') }}</span>
          </button>
        </div>
      </div>

      <!-- Main High-Level Key Performance Indicators Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- 1. Vehicles in Production (WIP) -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-sm hover:border-zinc-700 transition-colors">
          <div class="flex items-center justify-between text-xs text-zinc-400 mb-2 font-medium">
            <span>{{ i18n.t('kpi.vehiclesInProduction') }}</span>
            <div class="p-1.5 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <mat-icon class="text-sm">directions_car</mat-icon>
            </div>
          </div>
          <div class="flex items-baseline gap-2">
            <span class="text-3xl font-extrabold text-zinc-100 font-industrial-mono">{{ sim.vehiclesInProductionCount() + sim.finishedVehiclesCount() }}</span>
            <span class="text-xs text-emerald-400 font-semibold font-industrial-mono">+12.4% / Shift</span>
          </div>
          <div class="mt-3 pt-2 border-t border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between">
            <span>{{ i18n.isZh() ? '总装在制品: ' : 'GA WIP: ' }}<strong class="text-zinc-200">{{ sim.vehiclesInProductionCount() }}</strong></span>
            <span>{{ i18n.isZh() ? '终检已下线: ' : 'Finished: ' }}<strong class="text-emerald-400">{{ sim.finishedVehiclesCount() }}</strong></span>
          </div>
        </div>

        <!-- 2. OEE Overall Equipment Effectiveness -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-sm hover:border-zinc-700 transition-colors">
          <div class="flex items-center justify-between text-xs text-zinc-400 mb-2 font-medium">
            <span>{{ i18n.t('kpi.oee') }}</span>
            <div class="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <mat-icon class="text-sm">speed</mat-icon>
            </div>
          </div>
          <div class="flex items-baseline gap-2">
            <span class="text-3xl font-extrabold text-emerald-400 font-industrial-mono">{{ sim.oeeMetrics().oee }}%</span>
            <span class="text-xs text-zinc-400 font-industrial-mono">{{ i18n.isZh() ? '基准: 85%' : 'Target: 85%' }}</span>
          </div>
          <div class="mt-3 pt-2 border-t border-zinc-800/80 text-[11px] text-zinc-400 grid grid-cols-3 gap-1 text-center font-industrial-mono">
            <div>A: <strong class="text-zinc-200">{{ sim.oeeMetrics().availability }}%</strong></div>
            <div>P: <strong class="text-zinc-200">{{ sim.oeeMetrics().performance }}%</strong></div>
            <div>Q: <strong class="text-zinc-200">{{ sim.oeeMetrics().quality }}%</strong></div>
          </div>
        </div>

        <!-- 3. Line Utilisation & Takt Rate -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-sm hover:border-zinc-700 transition-colors">
          <div class="flex items-center justify-between text-xs text-zinc-400 mb-2 font-medium">
            <span>{{ i18n.t('kpi.lineUtilisation') }}</span>
            <div class="p-1.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <mat-icon class="text-sm">tune</mat-icon>
            </div>
          </div>
          <div class="flex items-baseline gap-2">
            <span class="text-3xl font-extrabold text-zinc-100 font-industrial-mono">{{ sim.lineUtilisationPct() }}%</span>
            <span class="text-xs text-zinc-400 font-industrial-mono">{{ sim.productionRateUph() }} UPH</span>
          </div>
          <div class="mt-3 pt-2 border-t border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between font-industrial-mono">
            <span>{{ i18n.t('kpi.taktTime') }}: <strong class="text-zinc-200">{{ sim.currentTaktTimeSec() }}s</strong></span>
            <span>{{ i18n.t('kpi.qualityYield') }}: <strong class="text-emerald-400">{{ sim.firstPassYieldPct() }}%</strong></span>
          </div>
        </div>

        <!-- 4. Energy Load & Microgrid Telemetry -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-sm hover:border-zinc-700 transition-colors">
          <div class="flex items-center justify-between text-xs text-zinc-400 mb-2 font-medium">
            <span>{{ i18n.t('kpi.energyTotal') }}</span>
            <div class="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <mat-icon class="text-sm">bolt</mat-icon>
            </div>
          </div>
          <div class="flex items-baseline gap-2">
            <span class="text-3xl font-extrabold text-amber-400 font-industrial-mono">{{ sim.energy().totalFactoryLoadMw }} MW</span>
            <span class="text-xs text-emerald-400 font-industrial-mono">绿电: {{ sim.energy().renewableSharePct }}%</span>
          </div>
          <div class="mt-3 pt-2 border-t border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between font-industrial-mono">
            <span>{{ i18n.isZh() ? '单车电费: ' : 'Cost/Veh: ' }}<strong class="text-zinc-200">¥{{ sim.energy().energyCostPerVehicleYuan }}</strong></span>
            <span>{{ i18n.isZh() ? '单车碳排: ' : 'CO2/Veh: ' }}<strong class="text-zinc-200">{{ sim.energy().co2PerVehicleKg }}kg</strong></span>
          </div>
        </div>
      </div>

      <!-- Critical Bottleneck & Production Line Real-Time Balance Card -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Assembly Line Stations Bar Balance (2 Cols) -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm">
          <div class="flex items-center justify-between mb-4">
            <div>
              <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                <mat-icon class="text-emerald-400 text-sm">linear_scale</mat-icon>
                <span>{{ i18n.isZh() ? '总装12工位循环耗时与节拍对标 (Line Balancing)' : '12 Assembly Stations Cycle Time vs Takt' }}</span>
              </h3>
              <p class="text-xs text-zinc-400">{{ i18n.isZh() ? '标准设计节拍: 60秒/台 | 识别线体瓶颈工位' : 'Target Takt: 60s/veh | Real-time bottleneck engine' }}</p>
            </div>

            <!-- Bottleneck Badge -->
            <div class="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
              <mat-icon class="text-xs">report_problem</mat-icon>
              <span>{{ i18n.t('kpi.bottleneck') }}: {{ sim.criticalBottleneckStation()?.nameZh || '工位11 (软件标定)' }}</span>
            </div>
          </div>

          <!-- Stations Cycle Time Bars -->
          <div class="space-y-2.5">
            @for (station of sim.stations(); track station.id) {
              <div class="flex items-center gap-3 text-xs">
                <div class="w-28 text-zinc-400 truncate font-medium">
                  {{ station.number }}. {{ i18n.isZh() ? station.nameZh.substring(0, 8) : station.name.substring(0, 8) }}...
                </div>

                <div class="flex-1 bg-zinc-950 h-5 rounded-lg border border-zinc-800/80 relative overflow-hidden flex items-center">
                  <!-- Takt Target Line -->
                  <div
                    class="absolute top-0 bottom-0 w-0.5 bg-red-500/80 z-10"
                    [style.left.%]="(60 / 75) * 100"
                    title="Target Takt (60s)"></div>

                  <!-- Cycle Progress Bar -->
                  <div
                    [class.bg-emerald-500]="station.cycleTimeSec <= 60"
                    [class.bg-amber-500]="station.cycleTimeSec > 60"
                    class="h-full rounded-md transition-all duration-500 flex items-center justify-end pr-2 font-industrial-mono text-[10px] font-bold text-zinc-950"
                    [style.width.%]="(station.cycleTimeSec / 75) * 100">
                    {{ station.cycleTimeSec }}s
                  </div>
                </div>

                <!-- Station Buffer -->
                <div class="w-16 text-right font-industrial-mono text-zinc-400 text-[11px]">
                  WIP: <strong class="text-zinc-200">{{ station.currentBufferCount }}</strong>/{{ station.bufferCapacity }}
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right Side: Live Event Stream & Robot Fleet Health (1 Col) -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
                <mat-icon class="text-emerald-400 text-sm">history</mat-icon>
                <span>{{ i18n.isZh() ? '数字孪生实时事件总线' : 'Live Event Bus' }}</span>
              </h3>
              <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            </div>

            <div class="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              @for (evt of sim.events().slice(0, 5); track evt.id) {
                <div class="p-2.5 rounded-xl bg-zinc-950/60 border border-zinc-800/60 text-xs">
                  <div class="flex items-center justify-between text-zinc-400 font-industrial-mono text-[10px] mb-1">
                    <span class="font-bold text-zinc-300">{{ evt.timestamp }}</span>
                    <span
                      [class.text-emerald-400]="evt.severity === 'SUCCESS'"
                      [class.text-amber-400]="evt.severity === 'WARN'"
                      [class.text-red-400]="evt.severity === 'ERROR'"
                      [class.text-blue-400]="evt.severity === 'INFO'"
                      class="font-semibold">
                      {{ evt.severity }}
                    </span>
                  </div>
                  <div class="font-semibold text-zinc-200">
                    {{ i18n.isZh() ? evt.titleZh : evt.title }}
                  </div>
                  <div class="text-[11px] text-zinc-400 mt-0.5">
                    {{ i18n.isZh() ? evt.detailsZh : evt.details }}
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Quick Robot & AGV Fleet Telemetry Snapshot -->
          <div class="mt-4 pt-4 border-t border-zinc-800 grid grid-cols-2 gap-3 text-xs">
            <div class="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <div class="text-zinc-400">{{ i18n.isZh() ? '机器人健康度' : 'Robot Health' }}</div>
              <div class="text-lg font-extrabold text-emerald-400 font-industrial-mono mt-0.5">{{ sim.robotFleetHealthPct() }}%</div>
            </div>
            <div class="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <div class="text-zinc-400">{{ i18n.isZh() ? 'AGV在岗率' : 'Active AGVs' }}</div>
              <div class="text-lg font-extrabold text-blue-400 font-industrial-mono mt-0.5">8 / 8 台</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OverviewDashboardComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  navigateTab = output<string>();
  openAI = output<void>();
}
