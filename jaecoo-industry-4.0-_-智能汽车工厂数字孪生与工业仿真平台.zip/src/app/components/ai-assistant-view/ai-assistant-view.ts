import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { GeminiAIService } from '../../services/gemini-ai.service';

@Component({
  selector: 'app-ai-assistant-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-teal-950/80 via-zinc-900 to-zinc-950 p-5 rounded-2xl border border-teal-500/30 shadow-xl">
        <div>
          <div class="flex items-center gap-2 text-xs text-teal-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">auto_awesome</mat-icon>
            <span>{{ i18n.t('nav.ai') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? 'JAECOO 工业大模型数字孪生智能诊断决策助手' : 'JAECOO Industrial AI Digital Twin Diagnostic Assistant' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '基于 Gemini 3.8 全域工业数据流接地，实时推演工艺瓶颈根因并输出实证依据' : 'Grounded in real-time factory digital twin telemetry for root-cause bottleneck diagnostics.' }}
          </p>
        </div>

        <div class="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-300 text-xs font-industrial-mono font-bold">
          <span class="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
          <span>Gemini 3.8 Flash Industrial</span>
        </div>
      </div>

      <!-- Quick Recommended Industrial Engineering Prompt Chips -->
      <div class="space-y-2">
        <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '工艺工程师高频诊断指令 (Quick Diagnostic Chips)' : 'Engineering Quick Prompt Chips' }}
        </div>
        <div class="flex flex-wrap gap-2">
          @for (chip of promptChips; track chip.textZh) {
            <button
              (click)="askQuestion(i18n.isZh() ? chip.textZh : chip.textEn)"
              class="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80 text-xs font-medium cursor-pointer transition-all hover:border-emerald-500/50 flex items-center gap-2">
              <mat-icon class="text-xs text-teal-400">help_outline</mat-icon>
              <span>{{ i18n.isZh() ? chip.textZh : chip.textEn }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Query Input & Trigger Box -->
      <div class="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-md space-y-3">
        <div class="flex items-center gap-2 bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
          <input
            #queryInput
            type="text"
            [placeholder]="i18n.isZh() ? '输入制造工程问题 (例如: 当前产线瓶颈工序是什么？为什么 OEE 下降？)' : 'Ask an industrial engineering question...'"
            (keyup.enter)="askQuestion(queryInput.value)"
            class="flex-1 bg-transparent text-zinc-100 text-xs px-2 outline-none font-medium placeholder:text-zinc-400" />
          <button
            (click)="askQuestion(queryInput.value)"
            [disabled]="ai.isLoading()"
            class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold font-industrial-mono cursor-pointer transition-all flex items-center gap-1.5 shadow">
            @if (ai.isLoading()) {
              <mat-icon class="text-xs animate-spin">refresh</mat-icon>
              <span>{{ i18n.isZh() ? '分析中...' : 'Analyzing...' }}</span>
            } @else {
              <mat-icon class="text-xs">send</mat-icon>
              <span>{{ i18n.isZh() ? '执行诊断' : 'Run Diagnostics' }}</span>
            }
          </button>
        </div>
      </div>

      <!-- AI Diagnostic Output Result Card -->
      @if (ai.lastDiagnostic()) {
        <div class="bg-gradient-to-br from-zinc-900 via-zinc-950 to-zinc-900 p-6 rounded-2xl border border-teal-500/30 shadow-2xl space-y-5 text-xs">
          <!-- Title & Summary -->
          <div class="pb-4 border-b border-zinc-800 space-y-2">
            <div class="flex items-center justify-between">
              <h3 class="text-base font-extrabold text-teal-300 flex items-center gap-2">
                <mat-icon class="text-teal-400">verified</mat-icon>
                <span>{{ ai.lastDiagnostic()!.title }}</span>
              </h3>
              <span class="text-[11px] text-zinc-400 font-industrial-mono">Evidence-Based Root Cause</span>
            </div>
            <p class="text-zinc-200 text-xs leading-relaxed font-medium">
              {{ ai.lastDiagnostic()!.summary }}
            </p>
          </div>

          <!-- Evidence List (Critical Industrial Requirement) -->
          <div class="space-y-2.5">
            <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono flex items-center gap-1">
              <mat-icon class="text-xs text-emerald-400">fact_check</mat-icon>
              <span>{{ i18n.t('common.evidence') }}</span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
              @for (ev of ai.lastDiagnostic()!.evidence; track ev) {
                <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300 flex items-start gap-2">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0"></span>
                  <span class="leading-relaxed">{{ ev }}</span>
                </div>
              }
            </div>
          </div>

          <!-- Root Cause Mechanism -->
          <div class="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-1">
            <div class="text-[11px] font-bold text-amber-400 uppercase font-industrial-mono">工程根因机理 (Root Cause Mechanism)</div>
            <p class="text-zinc-300 text-xs leading-relaxed">{{ ai.lastDiagnostic()!.rootCause }}</p>
          </div>

          <!-- Recommendations & Expected Impact -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
              <div class="text-xs font-bold text-emerald-300 font-industrial-mono uppercase">{{ i18n.t('common.recommendation') }}</div>
              <ul class="space-y-1.5 text-[11px] text-zinc-200">
                @for (rec of ai.lastDiagnostic()!.recommendations; track rec) {
                  <li class="flex items-start gap-1.5">
                    <mat-icon class="text-emerald-400 text-xs mt-0.5 shrink-0">check_circle</mat-icon>
                    <span>{{ rec }}</span>
                  </li>
                }
              </ul>
            </div>

            <div class="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 space-y-2">
              <div class="text-xs font-bold text-teal-300 font-industrial-mono uppercase">预期优化效益 (Projected Impact)</div>
              <p class="text-[11px] text-zinc-200 leading-relaxed font-industrial-mono">
                {{ ai.lastDiagnostic()!.projectedImpact }}
              </p>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AIAssistantViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);
  ai = inject(GeminiAIService);

  promptChips = [
    { textZh: '当前总装生产线的瓶颈工位是什么？', textEn: 'Which station is currently the bottleneck?' },
    { textZh: '为什么 10:30 产量有所波动？请给出实证依据。', textEn: 'Why did production fluctuate? Show evidence.' },
    { textZh: '哪些机器人和机泵设备需要近期预防性维护？', textEn: 'Which machines require predictive maintenance?' },
    { textZh: '如果产线节拍从 60秒 压缩至 55秒，会产生哪些瓶颈？', textEn: 'What happens if takt time is reduced by 5 seconds?' }
  ];

  askQuestion(query: string) {
    if (!query || !query.trim()) return;

    const state = {
      scenario: this.sim.activeScenario().id,
      shift: this.sim.currentShift().name,
      vehiclesInProduction: this.sim.vehiclesInProductionCount(),
      oee: this.sim.oeeMetrics().oee,
      availability: this.sim.oeeMetrics().availability,
      performance: this.sim.oeeMetrics().performance,
      quality: this.sim.oeeMetrics().quality,
      fpy: this.sim.firstPassYieldPct(),
      taktTimeSec: this.sim.currentTaktTimeSec(),
      productionRateUph: this.sim.productionRateUph(),
      bottleneckStation: this.sim.criticalBottleneckStation()?.nameZh || '工位11 (软件刷写与ADAS标定 - 64秒)',
      energyLoadMw: this.sim.energy().totalFactoryLoadMw,
      solarKw: this.sim.energy().solarPvKw,
      renewableShare: this.sim.energy().renewableSharePct,
      robotHealth: this.sim.robotFleetHealthPct(),
      recentEvents: this.sim.events().slice(0, 4)
    };

    this.ai.runDiagnostic(query, this.i18n.currentLang(), state);
  }
}
