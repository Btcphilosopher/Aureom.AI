import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { RobotEntity } from '../../models/factory.types';

@Component({
  selector: 'app-robotics-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">smart_toy</mat-icon>
            <span>{{ i18n.t('nav.robotics') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '全厂重载工业机器人集群数字孪生' : 'Industrial Robotics Fleet Digital Twin' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '监控6轴关节运动学姿态、焊点数、伺服电机温度与在线振动健康度' : 'Monitor 6-axis kinematics, weld count, servo motor temperature, and vibration health.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '在线总数' : 'Total Fleet' }}</div>
            <div class="font-bold text-zinc-200">16 / 16 台</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '平均综合负荷' : 'Avg Utilization' }}</div>
            <div class="font-bold text-emerald-400">93.8%</div>
          </div>
        </div>
      </div>

      <!-- Robots Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (robot of sim.robots(); track robot.id) {
          <button
            (click)="selectedRobot.set(robot)"
            [class.border-emerald-500/50]="selectedRobot()?.id === robot.id"
            [class.bg-zinc-900]="selectedRobot()?.id === robot.id"
            [class.border-zinc-800]="selectedRobot()?.id !== robot.id"
            class="text-left w-full p-4 rounded-2xl bg-zinc-950 border hover:border-zinc-700 transition-all cursor-pointer space-y-3">
            <div class="flex items-center justify-between text-xs">
              <div class="flex items-center gap-2 font-industrial-mono">
                <span class="font-extrabold text-zinc-100">{{ robot.id }}</span>
                <span class="text-zinc-400 font-medium">{{ robot.manufacturer }} {{ robot.model }}</span>
              </div>
              <span
                [class.bg-emerald-500/20]="robot.state === 'RUNNING'"
                [class.text-emerald-400]="robot.state === 'RUNNING'"
                [class.bg-amber-500/20]="robot.state === 'WAITING' || robot.state === 'TOOL_CHANGE'"
                [class.text-amber-400]="robot.state === 'WAITING' || robot.state === 'TOOL_CHANGE'"
                [class.bg-red-500/20]="robot.state === 'FAULT' || robot.state === 'EMERGENCY_STOP'"
                [class.text-red-400]="robot.state === 'FAULT' || robot.state === 'EMERGENCY_STOP'"
                class="px-2 py-0.5 rounded text-[10px] font-bold font-industrial-mono">
                {{ i18n.t('robot.state.' + robot.state) }}
              </span>
            </div>

            <div>
              <div class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? robot.nameZh : robot.name }}</div>
              <div class="text-[11px] text-zinc-400 mt-0.5">{{ i18n.isZh() ? robot.cellZh : robot.cell }}</div>
            </div>

            <!-- 6 Joint Angles Preview -->
            <div class="bg-zinc-900/90 p-2 rounded-xl border border-zinc-800/80">
              <div class="text-[10px] font-bold text-zinc-400 uppercase font-industrial-mono mb-1">
                {{ i18n.isZh() ? '6轴关节角实时姿态 (J1-J6)' : '6-Axis Joint Kinematics' }}
              </div>
              <div class="grid grid-cols-6 gap-1 text-center font-industrial-mono text-[10px]">
                @for (angle of robot.jointAngles; track $index) {
                  <div class="bg-zinc-950 p-1 rounded border border-zinc-800/60">
                    <span class="text-zinc-400 text-[9px]">J{{ $index + 1 }}</span>
                    <div class="text-emerald-400 font-bold mt-0.5">{{ angle }}°</div>
                  </div>
                }
              </div>
            </div>

            <!-- Telemetry Gauges -->
            <div class="grid grid-cols-3 gap-2 text-center text-[11px] font-industrial-mono pt-1">
              <div class="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800/80">
                <span class="text-zinc-400 text-[10px]">温度</span>
                <div class="font-bold text-zinc-100 mt-0.5">{{ robot.temperatureC }}℃</div>
              </div>
              <div class="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800/80">
                <span class="text-zinc-400 text-[10px]">振动 RMS</span>
                <div class="font-bold text-zinc-100 mt-0.5">{{ robot.vibrationRms }} mm/s</div>
              </div>
              <div class="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800/80">
                <span class="text-zinc-400 text-[10px]">负载率</span>
                <div class="font-bold text-emerald-400 mt-0.5">{{ robot.utilizationPct }}%</div>
              </div>
            </div>

            @if (robot.weldPointsCount > 0) {
              <div class="text-[11px] text-zinc-400 font-industrial-mono flex items-center justify-between pt-2 border-t border-zinc-800/80">
                <span>焊点完成进度:</span>
                <strong class="text-emerald-400">{{ robot.weldsCompleted }} / {{ robot.weldPointsCount }} 点</strong>
              </div>
            }
          </button>
        }
      </div>
    </div>
  `
})
export class RoboticsViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedRobot = signal<RobotEntity | null>(null);
}
