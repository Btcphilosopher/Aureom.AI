import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { AssemblyStation } from '../../models/factory.types';

@Component({
  selector: 'app-production-balancing',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Title & Takt Time Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">linear_scale</mat-icon>
            <span>{{ i18n.t('nav.production') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '总装生产线工位平衡与节拍优化仿真' : 'General Assembly Line Balancing & Takt Optimization' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '自动计算瓶颈工序、工位利用率及在制品 (WIP) 动态安全缓冲容量' : 'Automated bottleneck calculation, station utilization, and WIP dynamic buffer simulation.' }}
          </p>
        </div>

        <!-- Takt Time Formula Metrics Card -->
        <div class="bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex items-center gap-5 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '单班净工时 / 目标产量' : 'Available Time / Demand' }}</div>
            <div class="text-xs text-zinc-300 font-bold">28,800s / 480台</div>
          </div>
          <div class="text-xl text-zinc-600">=</div>
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '设计节拍 (Takt Time)' : 'Design Takt Time' }}</div>
            <div class="text-lg font-extrabold text-emerald-400">{{ sim.currentTaktTimeSec() }} s/台</div>
          </div>
        </div>
      </div>

      <!-- Stations Balance Overview Chart & Bottleneck Alert -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <div class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">equalizer</mat-icon>
            <span>{{ i18n.isZh() ? '全线12个工位节拍平衡图 (Takt Balancing Chart)' : '12 Stations Cycle Time vs 60s Takt' }}</span>
          </div>

          <!-- Bottleneck Badge -->
          <div class="flex items-center gap-2 px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <mat-icon class="text-xs">warning</mat-icon>
            <span>{{ i18n.isZh() ? '当前瓶颈: ' : 'Critical Bottleneck: ' }} {{ sim.criticalBottleneckStation()?.nameZh || '工位11 (软件刷写)' }} ({{ sim.criticalBottleneckStation()?.cycleTimeSec }}s)</span>
          </div>
        </div>

        <!-- Bar Charts -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (station of sim.stations(); track station.id) {
            <button
              (click)="selectedStation.set(station)"
              [class.border-emerald-500/50]="selectedStation()?.id === station.id"
              [class.bg-zinc-900]="selectedStation()?.id === station.id"
              [class.border-zinc-800]="selectedStation()?.id !== station.id"
              class="text-left w-full p-3.5 rounded-xl bg-zinc-950 border hover:border-zinc-700 transition-all cursor-pointer">
              <div class="flex items-center justify-between text-xs mb-1.5">
                <span class="font-bold text-zinc-200 font-industrial-mono">ST-{{ station.number.toString().padStart(2, '0') }}</span>
                <span
                  [class.text-emerald-400]="station.cycleTimeSec <= 60"
                  [class.text-amber-400]="station.cycleTimeSec > 60"
                  class="font-extrabold font-industrial-mono text-sm">
                  {{ station.cycleTimeSec }}s
                </span>
              </div>

              <div class="text-xs text-zinc-300 truncate font-semibold">
                {{ i18n.isZh() ? station.nameZh : station.name }}
              </div>

              <!-- Bar Line -->
              <div class="w-full bg-zinc-900 h-2.5 rounded-full mt-2.5 overflow-hidden relative">
                <div
                  class="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
                  [style.left.%]="(60 / 75) * 100"></div>
                <div
                  [class.bg-emerald-500]="station.cycleTimeSec <= 60"
                  [class.bg-amber-500]="station.cycleTimeSec > 60"
                  class="h-full rounded-full transition-all duration-300"
                  [style.width.%]="(station.cycleTimeSec / 75) * 100"></div>
              </div>

              <div class="mt-2.5 pt-2 border-t border-zinc-900 flex items-center justify-between text-[11px] text-zinc-400 font-industrial-mono">
                <span>{{ i18n.isZh() ? '负荷率: ' : 'Load: ' }}<strong class="text-zinc-200">{{ station.utilizationPct }}%</strong></span>
                <span>WIP: <strong class="text-emerald-400">{{ station.currentBufferCount }}</strong>/{{ station.bufferCapacity }}</span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Selected Station Detailed SOP & Tooling Telemetry -->
      @if (selectedStation()) {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800">
          <!-- Station Work Instructions (SOP) -->
          <div class="lg:col-span-2 space-y-4">
            <div class="flex items-center justify-between">
              <div>
                <span class="text-xs text-emerald-400 font-bold font-industrial-mono">STATION {{ selectedStation()!.number }} DIGITAL TWIN</span>
                <h3 class="text-base font-extrabold text-zinc-100">
                  {{ i18n.isZh() ? selectedStation()!.nameZh : selectedStation()!.name }}
                </h3>
              </div>
              <div class="text-xs text-zinc-400 font-industrial-mono">
                {{ i18n.isZh() ? '责任工艺师: ' : 'Lead: ' }}<strong class="text-zinc-200">{{ selectedStation()!.operatorName }}</strong>
              </div>
            </div>

            <!-- Standard Work Steps -->
            <div class="space-y-2">
              <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono">{{ i18n.isZh() ? '标准工艺操作规程 (SOP)' : 'Standard Work Instructions' }}</div>
              @for (step of selectedStation()!.workInstructions; track step.step) {
                <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 flex items-start gap-3 text-xs">
                  <div class="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold font-industrial-mono text-xs shrink-0">
                    {{ step.step }}
                  </div>
                  <div class="flex-1">
                    <div class="font-bold text-zinc-200">{{ i18n.isZh() ? step.titleZh : step.title }}</div>
                    <div class="text-zinc-400 text-[11px] mt-0.5">{{ i18n.isZh() ? step.detailZh : step.detail }}</div>
                  </div>
                  <div class="font-industrial-mono text-emerald-400 font-semibold shrink-0">
                    {{ step.standardSec }}s
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Fastening Tool & Torque Audit Record -->
          <div class="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-3">
            <div class="text-xs font-bold text-zinc-300 font-industrial-mono uppercase">{{ i18n.isZh() ? '工位定扭工具与防错监测' : 'Station Tooling & Torque Log' }}</div>
            @for (tool of selectedStation()!.tools; track tool.id) {
              <div class="p-3 rounded-lg bg-zinc-900 border border-zinc-800 text-xs space-y-2">
                <div class="flex items-center justify-between font-industrial-mono">
                  <span class="font-bold text-zinc-200">{{ tool.nameZh }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">{{ tool.status }}</span>
                </div>

                @if (tool.targetTorqueNm) {
                  <div class="grid grid-cols-2 gap-2 text-[11px] font-industrial-mono text-zinc-400 pt-1 border-t border-zinc-800">
                    <div>目标扭矩: <strong class="text-zinc-200">{{ tool.targetTorqueNm }} Nm</strong></div>
                    <div>实测扭矩: <strong class="text-emerald-400">{{ tool.actualTorqueNm }} Nm</strong></div>
                    <div>转角监测: <strong class="text-zinc-200">{{ tool.angleDeg }}°</strong></div>
                    <div>校准有效期: <strong class="text-zinc-300">{{ tool.calibrationDate }}</strong></div>
                  </div>
                }
              </div>
            }

            <div class="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20 text-[11px] text-emerald-300">
              <mat-icon class="text-xs align-middle mr-1">verified</mat-icon>
              <span>{{ i18n.isZh() ? 'MES扭矩曲线100%实时绑定底盘VIN码' : '100% Torque Angle Curves Synced to VIN' }}</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class ProductionBalancingComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedStation = signal<AssemblyStation | null>(null);

  constructor() {
    // Select first station as default
    const first = this.sim.stations()[0];
    if (first) this.selectedStation.set(first);
  }
}
