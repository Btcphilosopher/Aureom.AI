import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { AGVUnit } from '../../models/factory.types';

@Component({
  selector: 'app-logistics-warehouse-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">local_shipping</mat-icon>
            <span>{{ i18n.t('nav.logistics') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '智慧厂内物流与 AS/RS 自动化立库数字孪生' : 'Smart Logistics & AS/RS Automated Warehouse' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '全厂8台重载全向 AGV/AMR 自主路径规划、高位货架库存与 RFID 智能物料流' : 'Fleet of 8 omnidirectional AGVs/AMRs, automated storage racks, and RFID JIT tracking.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">AGV车队在线率</div>
            <div class="font-bold text-emerald-400">100.0% (8/8)</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">物料准时交付率 (JIT)</div>
            <div class="font-bold text-zinc-200">99.8%</div>
          </div>
        </div>
      </div>

      <!-- High-Bay Automated Warehouse Racks Inventory -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-blue-400 text-sm">warehouse</mat-icon>
            <span>{{ i18n.isZh() ? 'AS/RS 自动化立体库 4大核心巷道库位监控' : 'AS/RS High-Bay Warehouse Aisle Storage' }}</span>
          </h3>
          <span class="text-xs text-emerald-400 font-industrial-mono font-bold">RFID Scans: 820/hr</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          @for (rack of sim.warehouseRacks(); track rack.id) {
            <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2.5 text-xs">
              <div class="flex items-center justify-between font-industrial-mono">
                <span class="font-bold text-zinc-200">{{ rack.id }}</span>
                <span class="text-emerald-400 font-bold">{{ rack.stockLevelPct }}% 满载</span>
              </div>

              <div class="text-xs font-semibold text-zinc-300">{{ i18n.isZh() ? rack.categoryZh : rack.category }}</div>
              <div class="text-[11px] text-zinc-400">{{ rack.aisle }}</div>

              <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full" [style.width.%]="rack.stockLevelPct"></div>
              </div>

              <div class="pt-2 border-t border-zinc-800 flex items-center justify-between text-[11px] font-industrial-mono text-zinc-400">
                <span>占用/总容量:</span>
                <strong class="text-zinc-200">{{ rack.occupied }} / {{ rack.capacity }} 托</strong>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- AGV Fleet Live Telemetry & Mission Dispatch -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">precision_manufacturing</mat-icon>
            <span>{{ i18n.isZh() ? 'AGV/AMR 自主导航小车实时集群' : 'AGV / AMR Autonomous Vehicle Fleet' }}</span>
          </h3>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          @for (agv of sim.agvs(); track agv.id) {
            <button
              (click)="selectedAgv.set(agv)"
              [class.border-emerald-500/50]="selectedAgv()?.id === agv.id"
              class="text-left w-full p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 transition-all cursor-pointer space-y-2.5 text-xs">
              <div class="flex items-center justify-between font-industrial-mono">
                <span class="font-extrabold text-zinc-100">{{ agv.id }}</span>
                <span
                  [class.text-emerald-400]="agv.batteryPct > 50"
                  [class.text-amber-400]="agv.batteryPct <= 50"
                  class="font-bold">
                  {{ agv.batteryPct }}%
                </span>
              </div>

              <div class="text-[11px] text-zinc-300 font-semibold truncate">
                {{ i18n.isZh() ? agv.payloadTypeZh : agv.payloadType }}
              </div>

              <div class="text-[10px] text-zinc-400 truncate">
                目标: <strong class="text-zinc-300">{{ i18n.isZh() ? agv.destinationNameZh : agv.destinationName }}</strong>
              </div>

              <div class="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] font-industrial-mono text-zinc-400">
                <span>坐标: ({{ agv.x }}, {{ agv.z }})</span>
                <span class="text-emerald-400 font-bold">{{ agv.status }}</span>
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `
})
export class LogisticsWarehouseViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedAgv = signal<AGVUnit | null>(null);
}
