import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-object-detail-modal',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (sim.selectedObjectId(); as sel) {
      <div class="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-zinc-900 border border-zinc-700 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-scaleUp">
          <!-- Header -->
          <div class="flex items-center justify-between pb-4 border-b border-zinc-800">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                <mat-icon>{{ getIcon(sel.type) }}</mat-icon>
              </div>
              <div>
                <span class="text-[10px] text-emerald-400 font-bold font-industrial-mono uppercase">
                  DIGITAL TWIN TELEMETRY · {{ sel.type }}
                </span>
                <h3 class="text-base font-extrabold text-zinc-100 font-industrial-mono">
                  {{ sel.id }}
                </h3>
              </div>
            </div>

            <button
              (click)="sim.clearSelection()"
              class="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer">
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <!-- Body Telemetry Data based on object type -->
          <div class="space-y-3 text-xs font-industrial-mono">
            @if (sel.type === 'robot') {
              @if (getRobotData(sel.id); as r) {
                <div class="grid grid-cols-2 gap-3 text-zinc-300">
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">名称 / 厂商</div>
                    <div class="font-bold text-zinc-100 mt-0.5">{{ i18n.isZh() ? r.nameZh : r.name }}</div>
                  </div>
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">状态 / 负荷率</div>
                    <div class="font-bold text-emerald-400 mt-0.5">{{ r.state }} ({{ r.utilizationPct }}%)</div>
                  </div>
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">电机温度 / 振动</div>
                    <div class="font-bold text-zinc-100 mt-0.5">{{ r.temperatureC }}℃ / {{ r.vibrationRms }} mm/s</div>
                  </div>
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">节拍耗时</div>
                    <div class="font-bold text-zinc-100 mt-0.5">{{ r.cycleTimeSec }}s / 标称 {{ r.targetCycleTimeSec }}s</div>
                  </div>
                </div>

                <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300">
                  <div class="text-zinc-400 text-[10px] mb-1">当前工位任务:</div>
                  {{ i18n.isZh() ? r.currentTaskZh : r.currentTask }}
                </div>
              }
            } @else if (sel.type === 'agv') {
              @if (getAgvData(sel.id); as a) {
                <div class="grid grid-cols-2 gap-3 text-zinc-300">
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">型号 / 状态</div>
                    <div class="font-bold text-zinc-100 mt-0.5">{{ a.id }} ({{ a.status }})</div>
                  </div>
                  <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div class="text-zinc-400 text-[10px]">电池电量 SOC</div>
                    <div class="font-bold text-emerald-400 mt-0.5">{{ a.batteryPct }}%</div>
                  </div>
                </div>

                <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300 space-y-1">
                  <div>装载物料: <strong class="text-zinc-100">{{ i18n.isZh() ? a.payloadTypeZh : a.payloadType }}</strong></div>
                  <div>配送目的: <strong class="text-emerald-400">{{ i18n.isZh() ? a.destinationNameZh : a.destinationName }}</strong></div>
                </div>
              }
            } @else {
              <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-400 text-center">
                {{ i18n.isZh() ? '设备数字孪生实时数据同步中...' : 'Digital twin telemetry live stream syncing...' }}
              </div>
            }
          </div>

          <!-- Footer -->
          <div class="pt-3 border-t border-zinc-800 flex justify-end">
            <button
              (click)="sim.clearSelection()"
              class="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold cursor-pointer transition-colors">
              {{ i18n.isZh() ? '关闭窗口' : 'Close' }}
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class ObjectDetailModalComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  getIcon(type: string): string {
    switch (type) {
      case 'robot': return 'smart_toy';
      case 'agv': return 'local_shipping';
      case 'station': return 'linear_scale';
      case 'vehicle': return 'directions_car';
      default: return 'precision_manufacturing';
    }
  }

  getRobotData(id: string) {
    return this.sim.robots().find(r => r.id === id);
  }

  getAgvData(id: string) {
    return this.sim.agvs().find(a => a.id === id);
  }
}
