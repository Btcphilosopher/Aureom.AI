import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-shift-reports-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">assessment</mat-icon>
            <span>{{ i18n.t('nav.reports') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '制造班次数字化总结报告与多格式导出' : 'Digital Shift Manufacturing Reports & Multi-Format Export' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '自动聚合产量、综合效率 (OEE)、一次合格率、故障停机、单车能耗与瓶颈工序' : 'Automated shift summary of production, OEE, yield, downtime, energy, and bottlenecks.' }}
          </p>
        </div>

        <!-- Export Buttons -->
        <div class="flex items-center gap-2">
          <button
            (click)="exportJson()"
            class="px-3.5 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-bold font-industrial-mono cursor-pointer transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm text-emerald-400">code</mat-icon>
            <span>{{ i18n.t('common.exportJson') }}</span>
          </button>

          <button
            (click)="exportCsv()"
            class="px-3.5 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-bold font-industrial-mono cursor-pointer transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm text-blue-400">table_view</mat-icon>
            <span>{{ i18n.t('common.exportCsv') }}</span>
          </button>

          <button
            (click)="printReport()"
            class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer flex items-center gap-1.5">
            <mat-icon class="text-sm">print</mat-icon>
            <span>{{ i18n.t('common.exportPdf') }}</span>
          </button>
        </div>
      </div>

      <!-- Active Generated Shift Report Document Sheet -->
      <div id="printable-report" class="bg-zinc-900/90 p-8 rounded-2xl border border-zinc-800 shadow-2xl space-y-6 text-xs">
        <!-- Document Title Header -->
        <div class="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div>
            <div class="text-xs text-emerald-400 font-industrial-mono font-bold">JAECOO AUTOMOTIVE MANUFACTURING REPORT</div>
            <h1 class="text-2xl font-extrabold text-zinc-100 mt-1">
              {{ i18n.isZh() ? '制造执行数字化班次运营总结报告' : 'Intelligent Manufacturing Shift Summary Report' }}
            </h1>
            <div class="text-xs text-zinc-400 font-industrial-mono mt-1">
              {{ report().shiftId }} · 日期: {{ report().date }} · 班次: {{ i18n.isZh() ? report().shiftNameZh : report().shiftName }}
            </div>
          </div>

          <div class="text-right font-industrial-mono">
            <div class="text-2xl font-black text-emerald-400">{{ report().oee.totalOee }}%</div>
            <div class="text-[10px] text-zinc-400 uppercase">Shift OEE Rating</div>
          </div>
        </div>

        <!-- 1. Executive Summary Table -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 font-industrial-mono">
          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800">
            <div class="text-zinc-400 text-[10px]">计划生产量 (Plan)</div>
            <div class="text-xl font-extrabold text-zinc-200 mt-1">{{ report().planVolume }} 台</div>
          </div>

          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800">
            <div class="text-zinc-400 text-[10px]">实际下线量 (Actual)</div>
            <div class="text-xl font-extrabold text-emerald-400 mt-1">{{ report().actualVolume }} 台</div>
          </div>

          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800">
            <div class="text-zinc-400 text-[10px]">一次合格率 (FPY)</div>
            <div class="text-xl font-extrabold text-emerald-400 mt-1">{{ report().fpy }}%</div>
          </div>

          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800">
            <div class="text-zinc-400 text-[10px]">故障停机时长</div>
            <div class="text-xl font-extrabold text-amber-400 mt-1">{{ report().downtimeMinutes }} 分钟</div>
          </div>
        </div>

        <!-- 2. OEE Component Breakdown -->
        <div class="p-5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3 font-industrial-mono">
          <div class="text-xs font-bold text-zinc-200">OEE 综合效率三要素测算:</div>
          <div class="grid grid-cols-3 gap-4 text-center">
            <div class="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
              <span class="text-zinc-400">可用率 Availability</span>
              <div class="text-lg font-bold text-zinc-100 mt-1">{{ report().oee.availability }}%</div>
            </div>
            <div class="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
              <span class="text-zinc-400">表现性能指数 Performance</span>
              <div class="text-lg font-bold text-zinc-100 mt-1">{{ report().oee.performance }}%</div>
            </div>
            <div class="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
              <span class="text-zinc-400">质量合格指数 Quality</span>
              <div class="text-lg font-bold text-zinc-100 mt-1">{{ report().oee.quality }}%</div>
            </div>
          </div>
        </div>

        <!-- 3. Critical Bottleneck & Alarms Log -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
            <div class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? '主要瓶颈工序与优化对策' : 'Primary Bottleneck & Countermeasure' }}</div>
            <div class="text-xs font-industrial-mono text-amber-400 font-bold">
              {{ i18n.isZh() ? report().topBottleneckZh : report().topBottleneck }}
            </div>
            <p class="text-zinc-400 text-[11px] leading-relaxed">
              {{ i18n.isZh() ? '刷写数据包体积增加导致工时超出 4秒。建议启动以太网双通道并行刷写协议。' : 'Flashing payload increase led to 4s takt overrun. Dual-channel protocol recommended.' }}
            </p>
          </div>

          <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2 font-industrial-mono">
            <div class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? '班次能源与制造单耗' : 'Shift Energy & Economics' }}</div>
            <div class="text-zinc-300 text-xs">
              累计耗电量: <strong class="text-zinc-100">{{ report().energyUsedMwh }} MWh</strong>
            </div>
            <div class="text-zinc-300 text-xs">
              单车制造成本分摊: <strong class="text-emerald-400">¥{{ report().costPerVehicleYuan }} / 台</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ShiftReportsViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  report = () => this.sim.generateShiftReport();

  exportJson() {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(this.report(), null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', `JAECOO_ShiftReport_${Date.now()}.json`);
    dlAnchor.click();
  }

  exportCsv() {
    const r = this.report();
    const csvContent = 'data:text/csv;charset=utf-8,' +
      'Metric,Value\n' +
      `ReportID,${r.shiftId}\n` +
      `Date,${r.date}\n` +
      `Shift,${r.shiftName}\n` +
      `PlannedVolume,${r.planVolume}\n` +
      `ActualVolume,${r.actualVolume}\n` +
      `OEE,${r.oee.totalOee}%\n` +
      `FPY,${r.fpy}%\n` +
      `DowntimeMinutes,${r.downtimeMinutes}\n` +
      `EnergyUsedMWh,${r.energyUsedMwh}\n` +
      `Bottleneck,${r.topBottleneck}\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JAECOO_ShiftReport_${Date.now()}.csv`);
    link.click();
  }

  printReport() {
    window.print();
  }
}
