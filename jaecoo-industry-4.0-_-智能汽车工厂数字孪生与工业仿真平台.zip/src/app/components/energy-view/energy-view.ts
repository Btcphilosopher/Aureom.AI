import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-energy-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">bolt</mat-icon>
            <span>{{ i18n.t('nav.energy') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '零碳工厂微电网与能源环境数字孪生' : 'Zero-Carbon Factory Microgrid & Energy Twin' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '分布式屋顶光伏、10MWh 储能电站削峰填谷、工业中水回用与单车制造碳足迹' : 'Distributed rooftop solar, 10MWh BESS storage, water recycling loop, and carbon footprint / vehicle.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">全厂综合负荷</div>
            <div class="font-bold text-amber-400">{{ sim.energy().totalFactoryLoadMw }} MW</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">绿电渗透率</div>
            <div class="font-bold text-emerald-400">{{ sim.energy().renewableSharePct }}%</div>
          </div>
        </div>
      </div>

      <!-- Main Energy Grid Cards Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-2">
          <div class="flex items-center justify-between text-xs text-zinc-400">
            <span>屋顶光伏发电</span>
            <mat-icon class="text-amber-400 text-sm">wb_sunny</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-amber-400 font-industrial-mono">{{ sim.energy().solarPvKw }} kW</div>
          <div class="text-[11px] text-zinc-400 font-industrial-mono">装机容量: 4,500 kWp</div>
        </div>

        <div class="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-2">
          <div class="flex items-center justify-between text-xs text-zinc-400">
            <span>储能电站放电 (BESS)</span>
            <mat-icon class="text-emerald-400 text-sm">battery_charging_full</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-emerald-400 font-industrial-mono">{{ sim.energy().essDischargeMw }} MW</div>
          <div class="text-[11px] text-zinc-400 font-industrial-mono">容量: 10.0 MWh 磷酸铁锂</div>
        </div>

        <div class="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-2">
          <div class="flex items-center justify-between text-xs text-zinc-400">
            <span>单车能耗成本</span>
            <mat-icon class="text-blue-400 text-sm">payments</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-zinc-100 font-industrial-mono">¥{{ sim.energy().energyCostPerVehicleYuan }}</div>
          <div class="text-[11px] text-zinc-400 font-industrial-mono">电价: ¥0.68 / kWh</div>
        </div>

        <div class="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-2">
          <div class="flex items-center justify-between text-xs text-zinc-400">
            <span>中水回用率</span>
            <mat-icon class="text-teal-400 text-sm">water_drop</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-teal-400 font-industrial-mono">{{ sim.energy().waterRecycledPct }}%</div>
          <div class="text-[11px] text-zinc-400 font-industrial-mono">单车用水: 0.85 m³/台</div>
        </div>
      </div>

      <!-- Factory Electrical Network Load Flow Breakdown -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
        <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
          <mat-icon class="text-emerald-400 text-sm">account_tree</mat-icon>
          <span>{{ i18n.isZh() ? '10kV / 380V 车间配电节点负荷流 (Single-Line Load Flow)' : 'Factory Power Distribution Load Flow' }}</span>
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs font-industrial-mono">
          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>冲压车间 (Press)</span>
              <span class="text-amber-400">3.8 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">2500T 伺服液压泵与拆垛机械手</div>
          </div>

          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>焊装车间 (Welding)</span>
              <span class="text-amber-400">4.2 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">中频逆变点焊机群与激光钎焊头</div>
          </div>

          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>涂装烘烤 (Paint Curing)</span>
              <span class="text-amber-400">3.9 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">热风循环风机与恒温恒湿空调机组</div>
          </div>

          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>总装与合装 (Assembly)</span>
              <span class="text-amber-400">2.1 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">输送线伺服驱动器与拧紧工具群</div>
          </div>

          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>动力电池产线 (Battery)</span>
              <span class="text-amber-400">1.6 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">充放电化成机与激光极耳焊机</div>
          </div>

          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
            <div class="flex items-center justify-between text-zinc-200 font-bold">
              <span>公用动力与空压站 (Utilities)</span>
              <span class="text-amber-400">1.8 MW</span>
            </div>
            <div class="text-[11px] text-zinc-400">7.2 bar 离心式无油空压机群</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);
}
