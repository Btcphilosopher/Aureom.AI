import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { BatteryPackTwin } from '../../models/factory.types';

@Component({
  selector: 'app-battery-plant-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">battery_charging_full</mat-icon>
            <span>{{ i18n.t('nav.battery') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '动力电池系统制造与 96串电芯数字孪生' : 'Battery Pack Manufacturing & 96-Cell Digital Twin' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '从电芯来料检验、极耳激光焊接、BMS集成到终检高压绝缘与热失控安全监测' : 'Cell inspection, laser busbar welding, BMS integration, high-voltage insulation, and thermal testing.' }}
          </p>
        </div>

        <!-- Battery Selector Buttons -->
        <div class="flex items-center gap-2">
          @for (pack of sim.batteryPacks(); track pack.packId) {
            <button
              (click)="selectedPack.set(pack)"
              [class.bg-emerald-500]="selectedPack().packId === pack.packId"
              [class.text-zinc-950]="selectedPack().packId === pack.packId"
              [class.text-zinc-300]="selectedPack().packId !== pack.packId"
              class="px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-bold font-industrial-mono hover:bg-zinc-800 transition-all cursor-pointer">
              {{ pack.packId }} ({{ pack.chemistry }})
            </button>
          }
        </div>
      </div>

      <!-- 8-Stage Battery Manufacturing Flow -->
      <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-3">
        <div class="text-xs font-bold text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '动力电池包 8大制造工序流向' : '8-Stage Battery Production Flow' }}
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          @for (stage of batteryStages; track stage.step) {
            <div class="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-center text-xs">
              <div class="text-[10px] text-emerald-400 font-industrial-mono font-bold">Step {{ stage.step }}</div>
              <div class="font-bold text-zinc-200 mt-0.5">{{ i18n.isZh() ? stage.nameZh : stage.nameEn }}</div>
              <span class="inline-block mt-1 px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/15 text-emerald-400 font-industrial-mono font-bold">
                PASS
              </span>
            </div>
          }
        </div>
      </div>

      <!-- Battery Pack Telemetry & 96-Cell Voltage Matrix -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Pack Level Telemetry Dials (1 Col) -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between font-industrial-mono">
            <div>
              <span class="text-xs text-emerald-400 font-bold">{{ selectedPack().packId }}</span>
              <div class="text-lg font-extrabold text-zinc-100">{{ selectedPack().capacityKwh }} kWh · {{ selectedPack().chemistry }}</div>
            </div>
            <span class="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-bold">
              {{ selectedPack().status }}
            </span>
          </div>

          <div class="space-y-2.5 text-xs font-industrial-mono">
            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">总包母线电压:</span>
              <strong class="text-emerald-400 text-base font-bold">{{ selectedPack().measuredVoltageV }} V</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">电芯最大压差 (ΔV):</span>
              <strong class="text-zinc-200 text-sm font-bold">{{ selectedPack().maxCellDeviationMv }} mV</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">高压绝缘阻抗:</span>
              <strong class="text-zinc-200 text-sm font-bold">{{ selectedPack().insulationResistanceMohm }} MΩ</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">平均温升 / 最高温:</span>
              <strong class="text-zinc-200 text-sm font-bold">{{ selectedPack().avgTempC }}℃ / {{ selectedPack().maxTempC }}℃</strong>
            </div>

            <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span class="text-zinc-400">荷电状态 SOC / 健康度 SOH:</span>
              <strong class="text-emerald-400 text-sm font-bold">{{ selectedPack().socPct }}% / {{ selectedPack().sohPct }}%</strong>
            </div>
          </div>
        </div>

        <!-- 96-Cell Voltage Matrix (2 Cols) -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm">grid_view</mat-icon>
                <span>{{ i18n.isZh() ? '96串电芯电压一致性矩阵 (96-Cell Matrix)' : '96-Cell Voltage Consistency Matrix' }}</span>
              </h3>
              <p class="text-xs text-zinc-400 mt-0.5">{{ i18n.isZh() ? '极差小于 15mV 为合格，实时监测热平衡' : 'Max voltage delta < 15mV nominal, thermal equilibrium active.' }}</p>
            </div>
            <span class="text-xs text-emerald-400 font-industrial-mono font-bold">ΔV = {{ selectedPack().maxCellDeviationMv }} mV</span>
          </div>

          <!-- 96 Cells Visual Grid -->
          <div class="grid grid-cols-8 sm:grid-cols-12 gap-1.5 max-h-80 overflow-y-auto pr-1">
            @for (cell of selectedPack().cells; track cell.id) {
              <div
                class="p-1.5 rounded bg-zinc-950 border border-zinc-800 hover:border-emerald-400 text-center font-industrial-mono transition-colors">
                <div class="text-[9px] text-zinc-400">#{{ cell.id }}</div>
                <div class="text-[11px] font-bold text-emerald-400">{{ cell.voltageV }}V</div>
                <div class="text-[9px] text-zinc-400">{{ cell.tempC }}℃</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class BatteryPlantViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  selectedPack = signal<BatteryPackTwin>(this.sim.batteryPacks()[0]);

  batteryStages = [
    { step: 1, nameZh: '电芯来料', nameEn: 'Cell Receiving' },
    { step: 2, nameZh: '电芯分选', nameEn: 'Cell Inspection' },
    { step: 3, nameZh: '模组焊接', nameEn: 'Module Assembly' },
    { step: 4, nameZh: 'Pack总装', nameEn: 'Pack Assembly' },
    { step: 5, nameZh: 'BMS集成', nameEn: 'BMS Integration' },
    { step: 6, nameZh: '电气测试', nameEn: 'Electrical Test' },
    { step: 7, nameZh: '热安全检', nameEn: 'Thermal Test' },
    { step: 8, nameZh: '终检下线', nameEn: 'EOL Sign-off' }
  ];
}
