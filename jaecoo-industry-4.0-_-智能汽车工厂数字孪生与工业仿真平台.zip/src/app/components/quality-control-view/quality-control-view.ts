import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-quality-control-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">center_focus_strong</mat-icon>
            <span>{{ i18n.t('nav.quality') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '工业机器视觉 (AI-CV) 缺陷检测与 SPC 统计过程控制' : 'Industrial Vision AI Quality & SPC Statistical Process Control' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '3D激光在线扫描间隙面差、漆面缺陷AI目标检测、X-bar & R 管理图及首检一次合格率 (FPY)' : '3D laser gap scan, AI defect bounding boxes, X-bar & R charts, and First-Pass-Yield.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">一次合格率 (FPY)</div>
            <div class="font-bold text-emerald-400 text-base">{{ sim.firstPassYieldPct() }}%</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">过程能力指数 CpK</div>
            <div class="font-bold text-zinc-200 text-base">1.67</div>
          </div>
        </div>
      </div>

      <!-- Main Vision AI Inspector & SPC Charts -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- 1. Simulated Computer Vision Panel (2 Cols) -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-sm">camera_alt</mat-icon>
              <span>{{ i18n.isZh() ? '在线高精工业相机实时视觉流 (Camera Feed: VIN 000184)' : 'Live High-Res Optical Camera Feed: VIN 000184' }}</span>
            </h3>
            <span class="text-xs text-emerald-400 font-industrial-mono font-bold">50 FPS / OpenCV AI Pipeline</span>
          </div>

          <!-- Camera Simulated Viewport with Bounding Boxes -->
          <div class="relative w-full h-72 rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden flex items-center justify-center p-4">
            <!-- Simulated Vehicle Outline SVG -->
            <svg class="w-full h-full opacity-60" viewBox="0 0 800 300">
              <path d="M 80 200 L 140 120 L 320 80 L 520 80 L 660 140 L 740 180 L 740 230 L 680 230 A 40 40 0 0 1 600 230 L 260 230 A 40 40 0 0 1 180 230 L 80 230 Z" fill="#18181b" stroke="#38bdf8" stroke-width="2.5"/>
              <circle cx="220" cy="230" r="32" fill="#09090b" stroke="#10b981" stroke-width="3"/>
              <circle cx="640" cy="230" r="32" fill="#09090b" stroke="#10b981" stroke-width="3"/>
              <!-- Door Lines -->
              <line x1="340" y1="90" x2="330" y2="230" stroke="#71717a" stroke-width="2" stroke-dasharray="4"/>
              <line x1="490" y1="90" x2="480" y2="230" stroke="#71717a" stroke-width="2" stroke-dasharray="4"/>
            </svg>

            <!-- Bounding Box 1: Door Gap -->
            <div class="absolute top-16 left-[40%] w-32 h-40 border-2 border-emerald-500 bg-emerald-500/10 rounded p-1.5 font-industrial-mono text-[10px]">
              <div class="text-emerald-400 font-bold">B-Pillar Door Gap: 3.52mm</div>
              <div class="text-zinc-300 text-[9px]">Conf: 99.4% [PASS]</div>
            </div>

            <!-- Bounding Box 2: Roof Laser Weld -->
            <div class="absolute top-6 left-[25%] w-48 h-16 border-2 border-emerald-500 bg-emerald-500/10 rounded p-1 font-industrial-mono text-[10px]">
              <div class="text-emerald-400 font-bold">Laser Weld Bead Continuous</div>
              <div class="text-zinc-300 text-[9px]">Conf: 99.8% [PASS]</div>
            </div>

            <!-- Bounding Box 3: Headlamp Flushness -->
            <div class="absolute top-28 left-[10%] w-24 h-24 border-2 border-emerald-500 bg-emerald-500/10 rounded p-1 font-industrial-mono text-[10px]">
              <div class="text-emerald-400 font-bold">Lamp Flush: 0.12mm</div>
              <div class="text-zinc-300 text-[9px]">Conf: 99.1% [PASS]</div>
            </div>
          </div>
        </div>

        <!-- 2. Defect Pareto & SPC Charts (1 Col) -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">insert_chart</mat-icon>
            <span>{{ i18n.isZh() ? '缺陷柏拉图分布 (Pareto Chart)' : 'Defect Pareto Distribution' }}</span>
          </h3>

          <div class="space-y-3 text-xs font-industrial-mono">
            @for (item of defectTypes; track item.label) {
              <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
                <div class="flex items-center justify-between text-zinc-300">
                  <span class="font-bold">{{ i18n.isZh() ? item.labelZh : item.label }}</span>
                  <span class="text-emerald-400 font-bold">{{ item.pct }}% ({{ item.count }}件)</span>
                </div>
                <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                  <div class="bg-emerald-500 h-full" [style.width.%]="item.pct"></div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class QualityControlViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  defectTypes = [
    { label: 'Dimensional Gap Variance', labelZh: '四门两盖间隙面差微量超差', pct: 45, count: 4 },
    { label: 'Paint Surface Dust Spec', labelZh: '漆面微尘橘皮返工', pct: 30, count: 3 },
    { label: 'Torque Fastening Angle Alert', labelZh: '螺栓定扭转角微偏预警', pct: 15, count: 1 },
    { label: 'Electronic Module Wakeup Lag', labelZh: '以太网域控唤醒偶发延迟', pct: 10, count: 1 }
  ];
}
