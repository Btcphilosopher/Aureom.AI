import { ChangeDetectionStrategy, Component, inject, input, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

export interface NavItem {
  id: string;
  icon: string;
  labelKey: string;
  badge?: string;
  badgeColor?: string;
}

@Component({
  selector: 'app-sidebar',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-64 bg-zinc-950/95 border-r border-zinc-800/80 flex flex-col h-[calc(100vh-4rem)] select-none shrink-0 overflow-hidden">
      <!-- Active Scenario Indicator Banner -->
      <div class="p-3 border-b border-zinc-800/80 bg-zinc-900/40">
        <div class="flex items-center justify-between text-xs text-zinc-400 mb-1">
          <span class="font-medium flex items-center gap-1">
            <mat-icon class="text-xs text-emerald-400">tune</mat-icon>
            {{ i18n.t('header.scenario') }}
          </span>
          <span class="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-industrial-mono">
            {{ sim.activeScenario().id }}
          </span>
        </div>
        <div class="text-xs font-semibold text-zinc-200 truncate">
          {{ i18n.isZh() ? sim.activeScenario().nameZh : sim.activeScenario().name }}
        </div>
      </div>

      <!-- Navigation List with smooth scroll -->
      <nav class="flex-1 overflow-y-auto py-2 px-2 space-y-1">
        <div class="px-3 py-1.5 text-[11px] font-bold tracking-wider text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '核心数字孪生系统' : 'CORE TWIN SYSTEMS' }}
        </div>

        @for (item of coreNavItems; track item.id) {
          <button
            (click)="selectTab.emit(item.id)"
            [class.bg-emerald-500/15]="activeTab() === item.id"
            [class.text-emerald-400]="activeTab() === item.id"
            [class.border-emerald-500/40]="activeTab() === item.id"
            [class.text-zinc-400]="activeTab() !== item.id"
            [class.border-transparent]="activeTab() !== item.id"
            [class.hover:bg-zinc-900]="activeTab() !== item.id"
            [class.hover:text-zinc-200]="activeTab() !== item.id"
            class="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium border transition-all cursor-pointer group">
            <div class="flex items-center gap-2.5 min-w-0">
              <mat-icon
                [class.text-emerald-400]="activeTab() === item.id"
                [class.text-zinc-400]="activeTab() !== item.id"
                [class.group-hover:text-zinc-200]="activeTab() !== item.id"
                class="text-lg transition-colors shrink-0">
                {{ item.icon }}
              </mat-icon>
              <span class="truncate font-semibold">{{ i18n.t(item.labelKey) }}</span>
            </div>

            @if (item.badge) {
              <span
                [class]="item.badgeColor || 'bg-zinc-800 text-zinc-300'"
                class="text-[10px] px-2 py-0.5 rounded-full font-industrial-mono font-bold shrink-0">
                {{ item.badge }}
              </span>
            }
          </button>
        }

        <div class="pt-3 px-3 py-1.5 text-[11px] font-bold tracking-wider text-zinc-400 uppercase font-industrial-mono">
          {{ i18n.isZh() ? '车间工艺与工程仿真' : 'PROCESS & ENGINEERING' }}
        </div>

        @for (item of processNavItems; track item.id) {
          <button
            (click)="selectTab.emit(item.id)"
            [class.bg-emerald-500/15]="activeTab() === item.id"
            [class.text-emerald-400]="activeTab() === item.id"
            [class.border-emerald-500/40]="activeTab() === item.id"
            [class.text-zinc-400]="activeTab() !== item.id"
            [class.border-transparent]="activeTab() !== item.id"
            [class.hover:bg-zinc-900]="activeTab() !== item.id"
            [class.hover:text-zinc-200]="activeTab() !== item.id"
            class="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium border transition-all cursor-pointer group">
            <div class="flex items-center gap-2.5 min-w-0">
              <mat-icon
                [class.text-emerald-400]="activeTab() === item.id"
                [class.text-zinc-400]="activeTab() !== item.id"
                [class.group-hover:text-zinc-200]="activeTab() !== item.id"
                class="text-lg transition-colors shrink-0">
                {{ item.icon }}
              </mat-icon>
              <span class="truncate font-semibold">{{ i18n.t(item.labelKey) }}</span>
            </div>

            @if (item.badge) {
              <span
                [class]="item.badgeColor || 'bg-zinc-800 text-zinc-300'"
                class="text-[10px] px-2 py-0.5 rounded-full font-industrial-mono font-bold shrink-0">
                {{ item.badge }}
              </span>
            }
          </button>
        }
      </nav>

      <!-- Bottom Status & Quick Telemetry -->
      <div class="p-3 border-t border-zinc-800/80 bg-zinc-900/30 text-xs">
        <div class="flex items-center justify-between text-zinc-400 mb-1.5 font-industrial-mono">
          <span>OEE: <strong class="text-emerald-400">{{ sim.oeeMetrics().oee }}%</strong></span>
          <span>UPH: <strong class="text-zinc-200">{{ sim.productionRateUph() }}</strong></span>
          <span>FPY: <strong class="text-emerald-400">{{ sim.firstPassYieldPct() }}%</strong></span>
        </div>
        <div class="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
          <div
            class="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
            [style.width.%]="sim.oeeMetrics().oee"></div>
        </div>
      </div>
    </aside>
  `
})
export class SidebarComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  activeTab = input.required<string>();
  selectTab = output<string>();

  coreNavItems: NavItem[] = [
    { id: 'overview', icon: 'dashboard', labelKey: 'nav.overview' },
    { id: 'factory3d', icon: 'view_in_ar', labelKey: 'nav.factory3d', badge: '3D WebGL', badgeColor: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' },
    { id: 'factory2d', icon: 'account_tree', labelKey: 'nav.factory2d' },
    { id: 'production', icon: 'linear_scale', labelKey: 'nav.production', badge: '12 Stations' },
    { id: 'vehicles', icon: 'directions_car', labelKey: 'nav.vehicles', badge: 'WIP: 3' },
    { id: 'scenarios', icon: 'alt_route', labelKey: 'nav.scenarios', badge: 'What-If' },
    { id: 'reports', icon: 'assessment', labelKey: 'nav.reports' },
    { id: 'ai', icon: 'auto_awesome', labelKey: 'nav.ai', badge: 'Gemini 3.8', badgeColor: 'bg-teal-500/20 text-teal-300 border border-teal-500/30' }
  ];

  processNavItems: NavItem[] = [
    { id: 'robotics', icon: 'smart_toy', labelKey: 'nav.robotics', badge: '16 Units' },
    { id: 'bodyShop', icon: 'polyline', labelKey: 'nav.bodyShop' },
    { id: 'paintShop', icon: 'format_paint', labelKey: 'nav.paintShop' },
    { id: 'battery', icon: 'battery_charging_full', labelKey: 'nav.battery', badge: '96 Cells' },
    { id: 'powertrain', icon: 'settings_input_component', labelKey: 'nav.powertrain' },
    { id: 'logistics', icon: 'local_shipping', labelKey: 'nav.logistics', badge: '8 AGVs' },
    { id: 'quality', icon: 'center_focus_strong', labelKey: 'nav.quality', badge: 'Vision AI' },
    { id: 'maintenance', icon: 'build', labelKey: 'nav.maintenance', badge: 'CBM' },
    { id: 'energy', icon: 'bolt', labelKey: 'nav.energy', badge: '15.6 MW' },
    { id: 'iiot', icon: 'hub', labelKey: 'nav.iiot' }
  ];
}
