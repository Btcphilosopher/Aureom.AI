import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-paint-shop-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">format_paint</mat-icon>
            <span>{{ i18n.t('nav.paintShop') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '涂装车间全自动喷涂与固化数字孪生' : 'Paint Shop Automation & Thermal Curing Twin' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '水性B1B2紧凑型喷涂工艺、3D静电旋杯雾化、温湿度恒温恒湿闭环与仿真色库' : 'Compact waterborne B1B2 process, electrostatic bells (70,000 rpm), and simulated color library.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">喷房温度 / 湿度</div>
            <div class="font-bold text-emerald-400">23.5℃ / 65.0% RH</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">综合涂层一次合格率</div>
            <div class="font-bold text-zinc-200">99.1%</div>
          </div>
        </div>
      </div>

      <!-- Main Paint Shop Panels -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- 1. Simulated Color Library (2 Cols) -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-sm">palette</mat-icon>
              <span>{{ i18n.isZh() ? '仿真车漆配色库 (Simulated Color Library)' : 'Simulated Paint Color Palette' }}</span>
            </h3>
            <span class="text-[11px] text-zinc-400 font-industrial-mono">SIMULATED COLOUR LIBRARY</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
            @for (color of colorLibrary; track color.name) {
              <button
                (click)="selectedColor.set(color)"
                [class.border-emerald-500/50]="selectedColor().name === color.name"
                [class.bg-zinc-900]="selectedColor().name === color.name"
                [class.border-zinc-800]="selectedColor().name !== color.name"
                class="text-left w-full p-4 rounded-xl bg-zinc-950 border hover:border-zinc-700 transition-all cursor-pointer space-y-3">
                <div
                  class="w-full h-16 rounded-lg shadow-inner border border-zinc-700/50 flex items-end p-2"
                  [style.background-color]="color.hex">
                  <span class="text-[10px] px-2 py-0.5 rounded bg-zinc-950/80 text-zinc-200 font-industrial-mono font-bold">
                    {{ color.hex }}
                  </span>
                </div>

                <div>
                  <div class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? color.nameZh : color.name }}</div>
                  <div class="text-[11px] text-zinc-400 mt-0.5">{{ color.type }}</div>
                </div>

                <div class="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[10px] font-industrial-mono text-zinc-400">
                  <span>膜厚: {{ color.nominalMicron }}µm</span>
                  <span>光泽度: {{ color.gloss }}GU</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- 2. Thermal Curing & Booth Telemetry (1 Col) -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">local_fire_department</mat-icon>
            <span>{{ i18n.isZh() ? '烘烤炉固化温度曲线' : 'Curing Oven Thermal Profile' }}</span>
          </h3>

          <div class="space-y-3 text-xs font-industrial-mono">
            <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
              <div class="flex items-center justify-between text-zinc-400">
                <span>升温预热区 (Zone 1)</span>
                <span class="text-emerald-400 font-bold">110℃ / 110℃</span>
              </div>
              <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full w-[70%]"></div>
              </div>
            </div>

            <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
              <div class="flex items-center justify-between text-zinc-400">
                <span>主固化保温区 (Zone 2 - 140℃)</span>
                <span class="text-amber-400 font-bold">142.5℃ / 140℃</span>
              </div>
              <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                <div class="bg-amber-500 h-full w-[95%]"></div>
              </div>
            </div>

            <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
              <div class="flex items-center justify-between text-zinc-400">
                <span>强冷出炉区 (Zone 3)</span>
                <span class="text-blue-400 font-bold">38.0℃ / 40℃</span>
              </div>
              <div class="w-full bg-zinc-900 h-2 rounded-full overflow-hidden">
                <div class="bg-blue-500 h-full w-[30%]"></div>
              </div>
            </div>
          </div>

          <div class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
            <mat-icon class="text-sm align-middle mr-1">thermostat</mat-icon>
            <span>{{ i18n.isZh() ? '热回收利用率 72.5%，废气 RTO 焚烧净化达标' : 'Heat recovery rate 72.5%, RTO VOC destruction 99.8%' }}</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PaintShopViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  colorLibrary = [
    { name: 'Obsidian Black', nameZh: '曜石黑', hex: '#18181b', type: 'Metallic Basecoat', nominalMicron: 115, gloss: 96 },
    { name: 'Pearl White', nameZh: '珍珠白', hex: '#f4f4f5', type: '3-Coat Pearl', nominalMicron: 125, gloss: 95 },
    { name: 'Moonlight Silver', nameZh: '月光银', hex: '#94a3b8', type: 'Liquid Metallic', nominalMicron: 112, gloss: 94 },
    { name: 'Deep Sea Blue', nameZh: '深海蓝', hex: '#0369a1', type: 'Chroma Metallic', nominalMicron: 118, gloss: 95 },
    { name: 'Forest Green', nameZh: '极光绿', hex: '#065f46', type: 'Mica Pearl', nominalMicron: 120, gloss: 93 },
    { name: 'Mineral Grey', nameZh: '矿物灰', hex: '#52525b', type: 'Satin Metallic', nominalMicron: 114, gloss: 94 }
  ];

  selectedColor = signal(this.colorLibrary[0]);
}
