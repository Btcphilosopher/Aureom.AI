import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-maintenance-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">build</mat-icon>
            <span>{{ i18n.t('nav.maintenance') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '设备状态监测与预测性维护 (CBM / PHM)' : 'Condition-Based Predictive Maintenance (CBM / PHM)' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '基于振动 FFT 频谱分析、轴承结温与电机电流特征，预测设备剩余使用寿命 (RUL)' : 'FFT vibration spectrum, bearing temperature, and Remaining Useful Life (RUL) prediction.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">全厂设备健康指数</div>
            <div class="font-bold text-emerald-400">96.5%</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">待处理维护工单</div>
            <div class="font-bold text-amber-400">1 项 (风机)</div>
          </div>
        </div>
      </div>

      <!-- Maintenance Strategy Comparison -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-2">
          <div class="font-bold text-zinc-300 font-industrial-mono">01. 事后事急维修 (Corrective)</div>
          <p class="text-zinc-400 text-[11px]">设备发生故障停机后抢修，平均停线损失 ¥120,000/小时。</p>
          <div class="text-red-400 font-bold font-industrial-mono text-[10px]">非计划停机高风险</div>
        </div>

        <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-2">
          <div class="font-bold text-zinc-300 font-industrial-mono">02. 周期定期预防 (Preventive)</div>
          <p class="text-zinc-400 text-[11px]">按固定运行工时（如每 5000小时）更换备件，存在过维修成本。</p>
          <div class="text-amber-400 font-bold font-industrial-mono text-[10px]">备件备库占用高</div>
        </div>

        <div class="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/40 text-xs space-y-2">
          <div class="font-bold text-emerald-300 font-industrial-mono">03. 智能预测性维护 (Predictive) [当前模式]</div>
          <p class="text-zinc-300 text-[11px]">实时监测振动与温度劣化趋势，精准在停工前 7-14天 安排维护。</p>
          <div class="text-emerald-400 font-bold font-industrial-mono text-[10px]">综合维护成本下降 34.5%</div>
        </div>
      </div>

      <!-- Critical Machines Health Matrix -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (machine of sim.maintenanceMachines(); track machine.machineId) {
          <div class="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-3 text-xs">
            <div class="flex items-center justify-between font-industrial-mono">
              <span class="font-bold text-zinc-100 text-sm">{{ machine.nameZh }}</span>
              <span
                [class.bg-emerald-500/20]="machine.status === 'NORMAL'"
                [class.text-emerald-400]="machine.status === 'NORMAL'"
                [class.bg-amber-500/20]="machine.status === 'ATTENTION' || machine.status === 'MAINTENANCE_RECOMMENDED'"
                [class.text-amber-400]="machine.status === 'ATTENTION' || machine.status === 'MAINTENANCE_RECOMMENDED'"
                [class.bg-red-500/20]="machine.status === 'CRITICAL'"
                [class.text-red-400]="machine.status === 'CRITICAL'"
                class="px-2.5 py-1 rounded-xl font-bold">
                {{ i18n.t('cbm.' + machine.status) }}
              </span>
            </div>

            <div class="text-zinc-400">{{ machine.zoneZh }} · 累计运行: {{ machine.operatingHours }} 小时</div>

            <!-- Health Score Bar -->
            <div class="space-y-1">
              <div class="flex items-center justify-between text-[11px] font-industrial-mono text-zinc-400">
                <span>健康指数:</span>
                <strong class="text-emerald-400">{{ machine.healthScorePct }}%</strong>
              </div>
              <div class="w-full bg-zinc-950 h-2 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full" [style.width.%]="machine.healthScorePct"></div>
              </div>
            </div>

            <!-- Sensor Telemetry -->
            <div class="grid grid-cols-3 gap-2 text-center text-[11px] font-industrial-mono pt-2 border-t border-zinc-800">
              <div class="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                <span class="text-zinc-400">振动 RMS</span>
                <div
                  [class.text-amber-400]="machine.vibrationRmsMmS > machine.vibrationThresholdMmS"
                  [class.text-zinc-100]="machine.vibrationRmsMmS <= machine.vibrationThresholdMmS"
                  class="font-bold mt-0.5">
                  {{ machine.vibrationRmsMmS }} mm/s
                </div>
              </div>
              <div class="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                <span class="text-zinc-400">结温</span>
                <div class="font-bold text-zinc-100 mt-0.5">{{ machine.tempC }}℃</div>
              </div>
              <div class="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                <span class="text-zinc-400">剩余寿命 RUL</span>
                <div class="font-bold text-emerald-400 mt-0.5">{{ machine.rulDays }} 天</div>
              </div>
            </div>

            <!-- Recommended Action -->
            <div class="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800 text-[11px] text-zinc-300">
              <span class="text-emerald-400 font-bold">CBM 建议: </span>
              {{ i18n.isZh() ? machine.recommendedActionZh : machine.recommendedAction }}
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class MaintenanceViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);
}
