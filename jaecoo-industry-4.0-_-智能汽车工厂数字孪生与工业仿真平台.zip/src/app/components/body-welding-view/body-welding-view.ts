import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';

@Component({
  selector: 'app-body-welding-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">polyline</mat-icon>
            <span>{{ i18n.t('nav.bodyShop') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '焊装车间白车身与几何尺寸工程' : 'Body Shop Body-in-White & Dimensional Geometry' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ i18n.isZh() ? '主车身合拼、2000MPa热成型钢激光飞行焊、在线结构胶涂布与关键尺寸闭环' : 'Main framing, 2000MPa laser brazing, adhesive application, and closed-loop dimensional inspection.' }}
          </p>
        </div>

        <div class="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-800 text-xs font-industrial-mono">
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '焊装自动化率' : 'Automation Rate' }}</div>
            <div class="font-bold text-emerald-400">100.0%</div>
          </div>
          <div class="h-6 w-px bg-zinc-800"></div>
          <div>
            <div class="text-zinc-400 text-[10px]">{{ i18n.isZh() ? '整车总焊点数' : 'Total Spot Welds' }}</div>
            <div class="font-bold text-zinc-200">4,280 点/台</div>
          </div>
        </div>
      </div>

      <!-- Main Body Shop Metrics & Geometry Dials -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Body Framing Processes List -->
        <div class="lg:col-span-2 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">view_in_ar</mat-icon>
            <span>{{ i18n.isZh() ? '焊装车间六大核心岛体工艺状态' : 'Core Body Shop Manufacturing Cells' }}</span>
          </h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            @for (cell of bodyCells; track cell.name) {
              <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-2">
                <div class="flex items-center justify-between font-industrial-mono">
                  <span class="font-bold text-zinc-200">{{ i18n.isZh() ? cell.nameZh : cell.name }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-bold">RUNNING</span>
                </div>
                <p class="text-[11px] text-zinc-400 leading-relaxed">{{ i18n.isZh() ? cell.descZh : cell.desc }}</p>
                <div class="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] font-industrial-mono text-zinc-400">
                  <span>{{ i18n.isZh() ? '机器人配置: ' : 'Robots: ' }}<strong class="text-zinc-200">{{ cell.robots }} 台</strong></span>
                  <span>{{ i18n.isZh() ? '节拍: ' : 'Takt: ' }}<strong class="text-emerald-400">{{ cell.takt }}s</strong></span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Dimensional Quality Inspection Nominal vs Deviation -->
        <div class="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-emerald-400 text-sm">straighten</mat-icon>
              <span>{{ i18n.isZh() ? '关键几何尺寸公差' : 'Dimensional Tolerance' }}</span>
            </h3>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold font-industrial-mono">CpK: 1.67</span>
          </div>

          <div class="space-y-3 font-industrial-mono text-xs">
            @for (dim of dimensions; track dim.feature) {
              <div class="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-zinc-200">{{ i18n.isZh() ? dim.featureZh : dim.feature }}</span>
                  <span class="text-emerald-400 font-bold">
                    {{ dim.deviation > 0 ? '+' : '' }}{{ dim.deviation.toFixed(2) }} mm
                  </span>
                </div>
                <div class="flex items-center justify-between text-[11px] text-zinc-400">
                  <span>标称: {{ dim.nominal }}mm</span>
                  <span>实测: <strong class="text-zinc-200">{{ dim.measured }}mm</strong></span>
                  <span>公差: ±{{ dim.tol }}mm</span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class BodyWeldingViewComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  bodyCells = [
    { name: 'Underbody Floor Framing', nameZh: '下车体总成主拼工作站', desc: 'Resistance spot welding front/rear longitudinal rails.', descZh: '高强钢前纵梁与后地板中频逆变点焊', robots: 6, takt: 56 },
    { name: 'Body Side Framing', nameZh: '左右侧围总成激光飞行焊', desc: 'B-pillar 2000MPa ultra-high-strength steel laser braze.', descZh: 'B柱与顶盖一体化激光飞行钎焊 (焊速 100mm/s)', robots: 4, takt: 58 },
    { name: 'Main Body Framing Jig (Open Gate)', nameZh: '总拼主夹具岛体 (Open Gate)', desc: 'Precise positioning framing jig with ±0.1mm repeatability.', descZh: '总拼刚性主夹具，定位重复精度 ±0.1mm', robots: 8, takt: 58 },
    { name: 'Closure Hemming & Sealing', nameZh: '四门两盖滚边涂胶岛', desc: 'Structural polyurethane acoustic damping glue beads.', descZh: '车顶阻尼胶与发动机机盖视觉滚边包边', robots: 4, takt: 52 }
  ];

  dimensions = [
    { feature: 'Front Left Door Gap', featureZh: '左前门门缝间隙', nominal: 3.5, measured: 3.62, deviation: 0.12, tol: 0.5 },
    { feature: 'Engine Hood Flushness', featureZh: '发动机盖平整度面差', nominal: 0.0, measured: 0.18, deviation: 0.18, tol: 0.4 },
    { feature: 'B-Pillar Diagonal Gauge', featureZh: 'B柱主对角线对中尺寸', nominal: 1420.0, measured: 1420.15, deviation: 0.15, tol: 0.8 },
    { feature: 'Tailgate Left Gap', featureZh: '后尾门左侧外缝', nominal: 4.0, measured: 4.12, deviation: 0.12, tol: 0.6 }
  ];
}
