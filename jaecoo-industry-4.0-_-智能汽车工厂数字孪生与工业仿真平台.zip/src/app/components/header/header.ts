import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { ViewPerspective } from '../../models/factory.types';

@Component({
  selector: 'app-header',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 bg-zinc-950/90 border-b border-zinc-800/80 px-4 flex items-center justify-between backdrop-blur-md sticky top-0 z-30 select-none">
      <!-- Left: Logo & Platform Identity -->
      <div class="flex items-center gap-3.5">
        <div class="h-10 w-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-950/50 border border-emerald-400/30">
          <mat-icon class="text-zinc-950 text-2xl font-bold">precision_manufacturing</mat-icon>
        </div>
        <div>
          <div class="flex items-center gap-2">
            <span class="font-extrabold tracking-wider text-base text-zinc-100 font-industrial-mono">JAECOO</span>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold tracking-wide">
              INDUSTRY 4.0
            </span>
          </div>
          <div class="text-xs text-zinc-400 flex items-center gap-1.5 font-medium">
            <span>{{ i18n.isZh() ? '智能汽车工厂数字孪生与工业仿真平台' : 'Automotive Digital Twin & Simulator' }}</span>
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
          </div>
        </div>
      </div>

      <!-- Center: Simulation Clock & Shift Controls -->
      <div class="hidden lg:flex items-center gap-3 bg-zinc-900/90 px-4 py-1.5 rounded-2xl border border-zinc-800 shadow-inner">
        <!-- Shift Badge -->
        <div class="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700/50">
          <mat-icon class="text-emerald-400 text-sm">schedule</mat-icon>
          <span class="font-medium">{{ i18n.isZh() ? sim.currentShift().name : sim.currentShift().nameEn }}</span>
        </div>

        <!-- Sim Time Display -->
        <div class="flex items-center gap-2">
          <div class="font-industrial-mono text-base font-bold text-emerald-400 tracking-widest bg-zinc-950 px-3 py-1 rounded-lg border border-emerald-500/20 shadow-sm">
            {{ sim.simTimeFormatted() }}
          </div>
        </div>

        <!-- Play/Pause Button -->
        <button
          (click)="sim.togglePlay()"
          [class.bg-emerald-600]="sim.isPlaying()"
          [class.bg-amber-600]="!sim.isPlaying()"
          class="p-1.5 rounded-lg text-white hover:opacity-90 transition-all flex items-center justify-center cursor-pointer shadow-md"
          [title]="sim.isPlaying() ? i18n.t('header.pause') : i18n.t('header.play')">
          <mat-icon class="text-base">{{ sim.isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
        </button>

        <!-- Speed Selectors -->
        <div class="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-xs font-industrial-mono">
          @for (spd of [1, 5, 10, 50, 100]; track spd) {
            <button
              (click)="sim.setSpeed(spd)"
              [class.bg-emerald-500]="sim.speedMultiplier() === spd"
              [class.text-zinc-950]="sim.speedMultiplier() === spd"
              [class.text-zinc-400]="sim.speedMultiplier() !== spd"
              class="px-2 py-0.5 rounded font-bold hover:text-white transition-colors cursor-pointer">
              {{ spd }}×
            </button>
          }
        </div>
      </div>

      <!-- Right: Perspective, Language, AI Assist & Alarms -->
      <div class="flex items-center gap-2.5">
        <!-- Active Alarms Counter Badge -->
        <div
          [class.border-amber-500/40]="sim.activeAlarmsCount() > 0"
          [class.bg-amber-500/10]="sim.activeAlarmsCount() > 0"
          [class.text-amber-400]="sim.activeAlarmsCount() > 0"
          [class.border-zinc-800]="sim.activeAlarmsCount() === 0"
          [class.text-zinc-500]="sim.activeAlarmsCount() === 0"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-industrial-mono font-semibold">
          <mat-icon class="text-sm">{{ sim.activeAlarmsCount() > 0 ? 'warning' : 'check_circle' }}</mat-icon>
          <span>{{ sim.activeAlarmsCount() }} {{ i18n.isZh() ? '告警' : 'Alarms' }}</span>
        </div>

        <!-- Perspective Selector -->
        <div class="hidden sm:flex items-center gap-1 bg-zinc-900 border border-zinc-800 p-1 rounded-xl text-xs">
          <button
            (click)="setPerspective('ENGINEERING')"
            [class.bg-zinc-800]="sim.activePerspective() === 'ENGINEERING'"
            [class.text-emerald-400]="sim.activePerspective() === 'ENGINEERING'"
            [class.text-zinc-400]="sim.activePerspective() !== 'ENGINEERING'"
            class="px-2.5 py-1 rounded-lg font-medium hover:text-zinc-200 transition-colors cursor-pointer flex items-center gap-1">
            <mat-icon class="text-xs">engineering</mat-icon>
            <span>{{ i18n.isZh() ? '工程' : 'Eng' }}</span>
          </button>
          <button
            (click)="setPerspective('EXECUTIVE')"
            [class.bg-zinc-800]="sim.activePerspective() === 'EXECUTIVE'"
            [class.text-emerald-400]="sim.activePerspective() === 'EXECUTIVE'"
            [class.text-zinc-400]="sim.activePerspective() !== 'EXECUTIVE'"
            class="px-2.5 py-1 rounded-lg font-medium hover:text-zinc-200 transition-colors cursor-pointer flex items-center gap-1">
            <mat-icon class="text-xs">dashboard</mat-icon>
            <span>{{ i18n.isZh() ? '管理' : 'Exec' }}</span>
          </button>
        </div>

        <!-- AI Assistant Quick Trigger Button -->
        <button
          (click)="openAI.emit()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600/30 to-teal-600/30 hover:from-emerald-600/50 hover:to-teal-600/50 text-emerald-300 border border-emerald-500/40 text-xs font-semibold cursor-pointer transition-all shadow-sm">
          <mat-icon class="text-sm">auto_awesome</mat-icon>
          <span class="hidden md:inline">{{ i18n.t('header.aiAssist') }}</span>
        </button>

        <!-- Bilingual Language Toggle (ZH / EN) -->
        <button
          (click)="i18n.toggleLanguage()"
          class="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700/60 text-xs font-bold font-industrial-mono cursor-pointer transition-colors">
          <mat-icon class="text-sm text-emerald-400">translate</mat-icon>
          <span>{{ i18n.isZh() ? '中文' : 'EN' }}</span>
        </button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  openAI = output<void>();

  setPerspective(perspective: ViewPerspective) {
    this.sim.setPerspective(perspective);
  }
}
