import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from '../../services/i18n.service';
import { FactorySimulationService } from '../../services/factory-simulation.service';
import { FactoryZoneId } from '../../models/factory.types';

type FlowMode = '2D_PLAN' | 'PRODUCTION_FLOW' | 'LOGISTICS_FLOW' | 'ENERGY_FLOW' | 'DATA_FLOW';

@Component({
  selector: 'app-factory-2d-flows',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto max-h-[calc(100vh-4rem)]">
      <!-- Header & Mode Selector -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/90 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div class="flex items-center gap-2 text-xs text-emerald-400 font-industrial-mono font-semibold uppercase mb-1">
            <mat-icon class="text-sm">account_tree</mat-icon>
            <span>{{ i18n.t('nav.factory2d') }}</span>
          </div>
          <h2 class="text-xl font-extrabold text-zinc-100">
            {{ i18n.isZh() ? '工厂二维工程图纸与全域流向拓扑' : '2D Factory CAD Layout & System Flow Maps' }}
          </h2>
        </div>

        <!-- Mode Buttons -->
        <div class="flex flex-wrap items-center gap-1.5 bg-zinc-950 p-1.5 rounded-xl border border-zinc-800 text-xs">
          @for (m of flowModes; track m.id) {
            <button
              (click)="activeMode.set(m.id)"
              [class.bg-emerald-500]="activeMode() === m.id"
              [class.text-zinc-950]="activeMode() === m.id"
              [class.text-zinc-400]="activeMode() !== m.id"
              class="px-3 py-1.5 rounded-lg font-bold hover:text-white transition-all cursor-pointer flex items-center gap-1">
              <mat-icon class="text-xs">{{ m.icon }}</mat-icon>
              <span>{{ i18n.isZh() ? m.nameZh : m.nameEn }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Interactive Flow Canvas Layout Card -->
      <div class="bg-zinc-900/80 p-6 rounded-2xl border border-zinc-800 shadow-xl relative min-h-[560px]">
        <!-- 1. 2D Factory CAD Plan & Zones -->
        @if (activeMode() === '2D_PLAN') {
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            @for (zone of factoryZones; track zone.id) {
              <button
                (click)="sim.selectObject('station', zone.id)"
                class="text-left w-full bg-zinc-950/80 p-4 rounded-xl border border-zinc-800 hover:border-emerald-500/50 hover:bg-zinc-900 transition-all cursor-pointer group">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[11px] font-industrial-mono text-zinc-400 font-bold">{{ zone.code }}</span>
                  <mat-icon class="text-emerald-400 text-base group-hover:scale-110 transition-transform">
                    {{ zone.icon }}
                  </mat-icon>
                </div>
                <h4 class="text-sm font-bold text-zinc-200 group-hover:text-emerald-300">
                  {{ i18n.isZh() ? zone.nameZh : zone.nameEn }}
                </h4>
                <p class="text-xs text-zinc-400 mt-1 leading-relaxed">
                  {{ i18n.isZh() ? zone.descZh : zone.descEn }}
                </p>
                <div class="mt-3 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[11px] text-zinc-400 font-industrial-mono">
                  <span>{{ i18n.isZh() ? '利用率: ' : 'Util: ' }}<strong class="text-zinc-200">{{ zone.util }}%</strong></span>
                  <span class="text-emerald-400 font-semibold">{{ zone.status }}</span>
                </div>
              </button>
            }
          </div>
        }

        <!-- 2. Production Process Flow Map -->
        @if (activeMode() === 'PRODUCTION_FLOW') {
          <div class="flex flex-col items-center py-6 space-y-6">
            <div class="text-xs text-zinc-400 max-w-xl text-center">
              {{ i18n.isZh() ? '汽车精益制造六大主工艺流向：冲压 -> 焊装 -> 涂装 -> 电池 -> 总装 -> 质检' : 'Automotive 6-Stage Core Manufacturing Flow: Press -> Body -> Paint -> Battery -> Assembly -> Inspection' }}
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3 w-full">
              @for (stg of productionFlowStages; track stg.step) {
                <div class="bg-zinc-950 p-4 rounded-xl border border-zinc-800 text-center relative flex flex-col items-center">
                  <div class="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-xs font-bold font-industrial-mono mb-2">
                    0{{ stg.step }}
                  </div>
                  <h4 class="text-xs font-bold text-zinc-200">{{ i18n.isZh() ? stg.nameZh : stg.nameEn }}</h4>
                  <div class="text-[11px] text-zinc-400 mt-1 font-industrial-mono">Takt: {{ stg.cycle }}s</div>
                  <div class="text-[10px] text-emerald-400 font-industrial-mono mt-0.5">FPY: {{ stg.yield }}%</div>
                </div>
              }
            </div>
          </div>
        }

        <!-- 3. Logistics AGV Flow Map -->
        @if (activeMode() === 'LOGISTICS_FLOW') {
          <div class="space-y-4">
            <div class="flex items-center justify-between text-xs text-zinc-400">
              <span>{{ i18n.isZh() ? '智能立库 (AS/RS) -> AGV / AMR JIT 配料路线实时监控' : 'AS/RS High-Bay Warehouse -> AGV / AMR JIT Part Delivery Network' }}</span>
              <span class="font-industrial-mono text-emerald-400 font-bold">8 AGVs Active / 100% On-Time</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              @for (agv of sim.agvs(); track agv.id) {
                <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between text-xs">
                  <div class="flex items-center gap-3">
                    <div class="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      <mat-icon class="text-sm">local_shipping</mat-icon>
                    </div>
                    <div>
                      <div class="font-bold text-zinc-200 font-industrial-mono">{{ agv.id }} · {{ agv.model }}</div>
                      <div class="text-zinc-400 text-[11px] mt-0.5">
                        {{ i18n.isZh() ? agv.payloadTypeZh : agv.payloadType }}
                      </div>
                    </div>
                  </div>

                  <div class="text-right font-industrial-mono">
                    <div class="text-emerald-400 font-bold">{{ agv.batteryPct }}% SOC</div>
                    <div class="text-[11px] text-zinc-400">{{ agv.status }}</div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- 4. Energy Microgrid Flow Map -->
        @if (activeMode() === 'ENERGY_FLOW') {
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="p-5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div class="flex items-center justify-between text-xs text-zinc-400">
                <span class="font-bold text-zinc-200">{{ i18n.isZh() ? '电网与光伏输入' : 'Power Generation' }}</span>
                <mat-icon class="text-amber-400 text-sm">wb_sunny</mat-icon>
              </div>
              <div class="text-2xl font-extrabold text-amber-400 font-industrial-mono">{{ sim.energy().solarPvKw }} kW</div>
              <div class="text-xs text-zinc-400">{{ i18n.isZh() ? '分布式厂房屋顶光伏发电实时功率' : 'Distributed rooftop solar generation output' }}</div>
            </div>

            <div class="p-5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div class="flex items-center justify-between text-xs text-zinc-400">
                <span class="font-bold text-zinc-200">{{ i18n.isZh() ? '10MWh 储能电站 BESS' : '10MWh Battery ESS' }}</span>
                <mat-icon class="text-emerald-400 text-sm">battery_charging_full</mat-icon>
              </div>
              <div class="text-2xl font-extrabold text-emerald-400 font-industrial-mono">{{ sim.energy().essDischargeMw }} MW</div>
              <div class="text-xs text-zinc-400">{{ i18n.isZh() ? '削峰填谷智能放电中，降低电费' : 'Peak shaving active, reducing grid demand costs' }}</div>
            </div>

            <div class="p-5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div class="flex items-center justify-between text-xs text-zinc-400">
                <span class="font-bold text-zinc-200">{{ i18n.isZh() ? '全厂总电气负荷' : 'Total Factory Load' }}</span>
                <mat-icon class="text-purple-400 text-sm">bolt</mat-icon>
              </div>
              <div class="text-2xl font-extrabold text-purple-400 font-industrial-mono">{{ sim.energy().totalFactoryLoadMw }} MW</div>
              <div class="text-xs text-zinc-400">{{ i18n.isZh() ? '冲压、焊装、涂装烘烤为三大主要负荷' : 'Press, Welding, and Paint Curing are top loads' }}</div>
            </div>
          </div>
        }

        <!-- 5. Industrial IoT Network Topology Map -->
        @if (activeMode() === 'DATA_FLOW') {
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            @for (gw of sim.iiotGateways(); track gw.id) {
              <div class="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="font-bold text-zinc-200 font-industrial-mono">{{ gw.name }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 font-industrial-mono">{{ gw.protocol }}</span>
                </div>
                <div class="text-[11px] text-zinc-400 font-industrial-mono">IP: {{ gw.ip }} | {{ i18n.isZh() ? gw.zoneZh : gw.zone }}</div>
                <div class="flex items-center justify-between text-xs text-zinc-400 font-industrial-mono pt-2 border-t border-zinc-800">
                  <span>{{ gw.packetRateMsgS }} msg/s</span>
                  <span class="text-emerald-400">{{ gw.latencyMs }}ms</span>
                </div>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `
})
export class Factory2DFlowsComponent {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  activeMode = signal<FlowMode>('2D_PLAN');

  flowModes: { id: FlowMode; nameZh: string; nameEn: string; icon: string }[] = [
    { id: '2D_PLAN', nameZh: '车间总图', nameEn: 'CAD Layout', icon: 'grid_view' },
    { id: 'PRODUCTION_FLOW', nameZh: '工艺流程', nameEn: 'Mfg Flow', icon: 'linear_scale' },
    { id: 'LOGISTICS_FLOW', nameZh: 'AGV物流', nameEn: 'Logistics', icon: 'local_shipping' },
    { id: 'ENERGY_FLOW', nameZh: '能源管网', nameEn: 'Energy Grid', icon: 'bolt' },
    { id: 'DATA_FLOW', nameZh: 'IIoT拓扑', nameEn: 'Data Flow', icon: 'hub' }
  ];

  factoryZones = [
    { id: 'press_shop' as FactoryZoneId, code: 'ZONE-01', icon: 'precision_manufacturing', nameZh: '冲压车间 (Press Shop)', nameEn: 'Press Shop', descZh: '2500T 伺服重载冲压线，全封闭高速自动化拆垛', descEn: '2500T servo tandem press line with automated destackers.', util: 92.4, status: 'RUNNING' },
    { id: 'body_shop' as FactoryZoneId, code: 'ZONE-02', icon: 'polyline', nameZh: '焊装车间 (Body Shop)', nameEn: 'Body Shop', descZh: '白车身全自动化激光飞行焊与电阻中频点焊', descEn: '100% automated laser braze welding and spot welding cells.', util: 96.2, status: 'RUNNING' },
    { id: 'paint_shop' as FactoryZoneId, code: 'ZONE-03', icon: 'format_paint', nameZh: '涂装车间 (Paint Shop)', nameEn: 'Paint Shop', descZh: '水性色漆静电高速旋杯喷涂与高温固化炉', descEn: 'Waterborne metallic basecoat electro-bell atomizers and curing oven.', util: 88.5, status: 'RUNNING' },
    { id: 'battery_plant' as FactoryZoneId, code: 'ZONE-04', icon: 'battery_charging_full', nameZh: '电池车间 (Battery Plant)', nameEn: 'Battery Plant', descZh: 'CTB 刀片电池与高能量三元锂包模块装配与终检', descEn: 'CTB blade & high-energy NMC battery pack assembly and EOL testing.', util: 94.0, status: 'RUNNING' },
    { id: 'general_assembly' as FactoryZoneId, code: 'ZONE-05', icon: 'linear_scale', nameZh: '总装车间 (General Assembly)', nameEn: 'General Assembly', descZh: '内饰、底盘动力电池一体化合装 (Marriage) 与四轮拧紧', descEn: 'Trim line, chassis battery marriage, glass robot, wheel fastening.', util: 95.1, status: 'RUNNING' },
    { id: 'quality_inspection' as FactoryZoneId, code: 'ZONE-06', icon: 'center_focus_strong', nameZh: '质检车间 (Quality Inspection)', nameEn: 'Quality Inspection', descZh: '3D 蓝光激光在线间隙平整度检测与底盘动态路试', descEn: '3D optical laser flushness/gap scanning and dynamometer road test.', util: 93.4, status: 'RUNNING' },
    { id: 'smart_warehouse' as FactoryZoneId, code: 'ZONE-07', icon: 'warehouse', nameZh: '智能立库 (Smart Warehouse)', nameEn: 'Smart Warehouse', descZh: 'AS/RS 自动化立体高位货架与 RFID 实时物料扫描', descEn: 'Automated storage/retrieval system with high-bay RFID tracking.', util: 86.8, status: 'RUNNING' },
    { id: 'energy_centre' as FactoryZoneId, code: 'ZONE-08', icon: 'bolt', nameZh: '能源调度中心 (Energy Centre)', nameEn: 'Energy Centre', descZh: '微电网协调控制、屋顶光伏发电与 10MWh 储能电站', descEn: 'Microgrid supervisory controller, solar PV & 10MWh BESS storage.', util: 98.0, status: 'RUNNING' }
  ];

  productionFlowStages = [
    { step: 1, nameZh: '冲压成型', nameEn: 'Press Shop', cycle: 15, yield: 99.4 },
    { step: 2, nameZh: '焊装车身', nameEn: 'Body Shop', cycle: 58, yield: 98.9 },
    { step: 3, nameZh: '涂装防腐', nameEn: 'Paint Shop', cycle: 60, yield: 99.1 },
    { step: 4, nameZh: '电池组装', nameEn: 'Battery Plant', cycle: 45, yield: 99.8 },
    { step: 5, nameZh: '总装集成', nameEn: 'General Assembly', cycle: 60, yield: 98.7 },
    { step: 6, nameZh: '整车终检', nameEn: 'Quality EOL', cycle: 55, yield: 99.9 }
  ];
}
