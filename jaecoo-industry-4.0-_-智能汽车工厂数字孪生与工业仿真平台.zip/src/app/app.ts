import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { HeaderComponent } from './components/header/header';
import { SidebarComponent } from './components/sidebar/sidebar';
import { Factory3DComponent } from './components/factory-3d/factory-3d';
import { OverviewDashboardComponent } from './components/overview-dashboard/overview-dashboard';
import { Factory2DFlowsComponent } from './components/factory-2d-flows/factory-2d-flows';
import { ProductionBalancingComponent } from './components/production-balancing/production-balancing';
import { VehicleTwinsComponent } from './components/vehicle-twins/vehicle-twins';
import { RoboticsViewComponent } from './components/robotics-view/robotics-view';
import { BodyWeldingViewComponent } from './components/body-welding-view/body-welding-view';
import { PaintShopViewComponent } from './components/paint-shop-view/paint-shop-view';
import { BatteryPlantViewComponent } from './components/battery-plant-view/battery-plant-view';
import { PowertrainViewComponent } from './components/powertrain-view/powertrain-view';
import { LogisticsWarehouseViewComponent } from './components/logistics-warehouse-view/logistics-warehouse-view';
import { QualityControlViewComponent } from './components/quality-control-view/quality-control-view';
import { MaintenanceViewComponent } from './components/maintenance-view/maintenance-view';
import { EnergyViewComponent } from './components/energy-view/energy-view';
import { IIoTEdgeViewComponent } from './components/iiot-edge-view/iiot-edge-view';
import { WhatIfSimulationComponent } from './components/what-if-simulation/what-if-simulation';
import { ShiftReportsViewComponent } from './components/shift-reports-view/shift-reports-view';
import { AIAssistantViewComponent } from './components/ai-assistant-view/ai-assistant-view';
import { ObjectDetailModalComponent } from './components/object-detail-modal/object-detail-modal';
import { I18nService } from './services/i18n.service';
import { FactorySimulationService } from './services/factory-simulation.service';

@Component({
  selector: 'app-root',
  imports: [
    HeaderComponent,
    SidebarComponent,
    Factory3DComponent,
    OverviewDashboardComponent,
    Factory2DFlowsComponent,
    ProductionBalancingComponent,
    VehicleTwinsComponent,
    RoboticsViewComponent,
    BodyWeldingViewComponent,
    PaintShopViewComponent,
    BatteryPlantViewComponent,
    PowertrainViewComponent,
    LogisticsWarehouseViewComponent,
    QualityControlViewComponent,
    MaintenanceViewComponent,
    EnergyViewComponent,
    IIoTEdgeViewComponent,
    WhatIfSimulationComponent,
    ShiftReportsViewComponent,
    AIAssistantViewComponent,
    ObjectDetailModalComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  i18n = inject(I18nService);
  sim = inject(FactorySimulationService);

  activeTab = signal<string>('overview');

  selectTab(tabId: string) {
    this.activeTab.set(tabId);
  }

  openAI() {
    this.activeTab.set('ai');
  }
}
