import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Server-Side Gemini Initialization
const ai = new GoogleGenAI({
  apiKey: process.env['GEMINI_API_KEY'],
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * AI Industrial Diagnostics API
 */
app.post('/api/ai/diagnose', async (req, res): Promise<void> => {
  try {
    const { query, lang = 'zh', factoryState } = req.body;

    const systemPrompt = `You are the Lead Industrial Systems Engineer & AI Diagnostic Engine for JAECOO INDUSTRY 4.0 Intelligent Automotive Manufacturing Platform.
Language target: ${lang === 'zh' ? 'Chinese (简体中文)' : 'English'}.
You analyze live factory digital twin state, root causes for bottlenecks, AGV logistics dispatch, predictive maintenance, quality deviations, and what-if simulation results.

CRITICAL INSTRUCTIONS:
- You must answer with strict industrial engineering professionalism (like a senior automotive manufacturing VP/Chief Process Engineer).
- Ground your answer strictly in the provided Factory Digital Twin telemetry facts.
- Include concrete evidence points (e.g. cycle time numbers, station IDs, temperature ℃, vibration mm/s, buffer counts).
- Never output generic fluff or unsupported guesses.

Respond ONLY with valid JSON in this exact structure:
{
  "title": "Short title of diagnosis",
  "summary": "Direct executive summary answer (2-3 sentences)",
  "evidence": [
    "Evidence point 1 with concrete metrics",
    "Evidence point 2 with concrete metrics",
    "Evidence point 3"
  ],
  "rootCause": "Clear technical root-cause mechanism",
  "recommendations": [
    "Actionable engineering countermeasure 1",
    "Actionable engineering countermeasure 2"
  ],
  "projectedImpact": "Quantified expected recovery (e.g. OEE +3.2%, Takt restored to 60s)"
}`;

    const userPrompt = `User question: "${query}"

Live Factory State Telemetry Grounding:
- Active Scenario: ${factoryState?.scenario || 'NORMAL_PRODUCTION'}
- Current Shift: ${factoryState?.shift || 'Shift 1 (06:00-14:00)'}
- Vehicles in Production (WIP): ${factoryState?.vehiclesInProduction || 142}
- Overall OEE: ${factoryState?.oee || 87.8}% (Availability: ${factoryState?.availability || 94.2}%, Performance: ${factoryState?.performance || 94.8}%, Quality: ${factoryState?.quality || 98.7}%)
- First Pass Yield (FPY): ${factoryState?.fpy || 98.7}%
- Current Takt Time: ${factoryState?.taktTimeSec || 60}s | Production Rate: ${factoryState?.productionRateUph || 52} UPH
- Critical Bottleneck: ${factoryState?.bottleneckStation || 'Station 11 (Software Flashing & ADAS Calibration - Cycle Time 64s)'}
- Key Alarms & Events: ${JSON.stringify(factoryState?.recentEvents || [])}
- Energy Load: ${factoryState?.energyLoadMw || 15.6} MW | Solar Generation: ${factoryState?.solarKw || 2850} kW | Renewable Share: ${factoryState?.renewableShare || 29.8}%
- Robot Fleet Health: ${factoryState?.robotHealth || 96.5}%
- Predictive Maintenance Alarms: ${JSON.stringify(factoryState?.maintenanceAlerts || [])}
`;

    if (!process.env['GEMINI_API_KEY']) {
      // Return high-fidelity fallback response when offline / key absent
      res.json({
        title: lang === 'zh' ? 'JAECOO 工业 4.0 智能仿真诊断 (模型离线模式)' : 'JAECOO Industry 4.0 Simulation Diagnostic',
        summary: lang === 'zh'
          ? `基于工厂数字孪生实时数据流，当前总装 11工位（软件刷写与ADAS标定，节拍 64秒）以及焊装 RB-204 机器人为主要制约点。产线整体 OEE 处于 ${factoryState?.oee || 87.8}%。`
          : `Based on live factory digital twin streams, Station 11 (Software Flash & ADAS Calibration at 64s cycle) and Body Robot RB-204 represent the critical bottleneck. Fleet OEE is currently ${factoryState?.oee || 87.8}%.`,
        evidence: lang === 'zh' ? [
          `总装 11工位（软件刷写）周期达 64秒，超出目标节拍 60秒 6.7%，下游缓冲区处于高水位 (3/3)`,
          `焊装车间 RB-204 伺服电机温度达 64.2℃，振动 RMS 3.4 mm/s，接近报警阈值`,
          `涂装 2号烘烤区固化时间略有滞后，排队滑撬占位率 85%`
        ] : [
          `Station 11 cycle time is 64s, exceeding 60s target by 6.7%, queue buffer full at 3/3`,
          `Body Shop RB-204 servo temperature at 64.2°C, vibration RMS 3.4 mm/s`,
          `Paint Booth 02 curing cycle slight delay, buffer occupancy 85%`
        ],
        rootCause: lang === 'zh'
          ? '智驾域控制器 OTA 刷写数据包吞吐量受千兆以太网交换机带宽排队抖动影响；同时焊接机器人第3轴减速机润滑油粘度下降导致机械阻力微增。'
          : 'High-speed ADAS domain controller flashing packet queuing jitter; accompanied by minor mechanical resistance in Robot RB-204 axis-3 reducer.',
        recommendations: lang === 'zh' ? [
          '启动以太网双通道并行刷写策略，将刷写时间压缩至 48秒以内',
          '利用 12:00 班间休息 15分钟，派发 CBM 预测维护工单更换 RB-204 轴承油脂',
          '微调 AGV-03 供料频次，确保仪表板预装料车准时化 (JIT) 齐套'
        ] : [
          'Enable dual-channel parallel ethernet flashing protocol to reduce cycle below 48s',
          'Dispatch CBM maintenance work order during 12:00 shift break to relubricate RB-204',
          'Adjust AGV-03 dispatch frequency for JIS cockpit parts delivery'
        ],
        projectedImpact: lang === 'zh'
          ? '优化后预计整线 OEE 恢复至 92.4%，单班增产 14 台整车，单车能耗下降 4.2%'
          : 'Projected OEE recovery to 92.4%, +14 finished vehicles per shift, energy -4.2% per vehicle.'
      });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.2,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('Gemini diagnostic error:', error);
    res.status(500).json({
      error: 'Diagnostic generation failed',
      details: message,
    });
  }
});

/**
 * Shift Report Export API
 */
app.post('/api/export/report', (req, res) => {
  const reportData = req.body;
  res.json({
    success: true,
    reportId: reportData.shiftId || `RPT-${Date.now()}`,
    exportedAt: new Date().toISOString(),
    format: 'json',
    data: reportData,
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

