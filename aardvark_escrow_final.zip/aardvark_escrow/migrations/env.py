"""Alembic migration environment, configured for an async SQLAlchemy engine.

Concrete models get registered against `app.database.base.Base` — see
`app/domain/entities/__init__.py`.
"""
import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config

# Imported so every entity module registers itself on Base.metadata —
# required for Alembic autogenerate to see the full schema.
import app.domain.entities  # noqa: F401
from app.core.config import settings
from app.database.base import Base

config = context.config

# Only fall back to the app's configured DATABASE_URL if the caller
# hasn't already set a real one (e.g. programmatically, via
# `Config().set_main_option("sqlalchemy.url", ...)` — exactly what
# tests/test_database.py's migration-cycle test does, pointing at a
# disposable throwaway database rather than the app's real one).
# Unconditionally overwriting here was a real bug: a caller trying to
# run migrations against any database other than the app's configured
# one would silently have them redirected to the real one instead — for
# a downgrade, that means silently dropping the wrong database's tables.
# `alembic.ini`'s own placeholder is the only value this should ever
# override.
if config.get_main_option("sqlalchemy.url") in (None, "driver://user:pass@localhost/dbname"):
    config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
