"""Notification delivery.

In-app notification *rows* have been created since Phase 7 — several
domain services call `app.domain.services.notification_helpers.notify`
alongside their other writes (escrow created/funded/released/refunded/
cancelled, disputes opened/resolved), and `GET /notifications` reads them
back. What's not built yet is actual external delivery: Phase 8 adds
Celery tasks here that pick up PENDING notifications, send them
(email/webhook), and update their status to SENT or FAILED.
"""
