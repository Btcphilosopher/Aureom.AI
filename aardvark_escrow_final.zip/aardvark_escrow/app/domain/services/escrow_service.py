"""Escrow service — creation, reading, and cancellation.

`fund`/`approve`/`release`/`refund` are deliberately NOT here. They move
money, and land in Phase 6's transaction engine, which combines
`EscrowStateMachine` (this phase) with `WalletService` (Phase 4) under a
single `UnitOfWork` locking a wallet and the escrow together. What's
here is the part of the lifecycle that touches no money and so needs no
financial locking: create, read, list, cancel.

Create and cancel each notify the other party (Phase 7's
`notification_helpers.notify`) so `GET /notifications` has real data to
return rather than being permanently empty.
"""
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import DomainError, NotFoundError
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import EscrowStatus, NotificationType
from app.domain.entities.escrow import Escrow, EscrowEvent
from app.domain.services.escrow_state_machine import EscrowStateMachine
from app.domain.services.notification_helpers import notify


class EscrowService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create_escrow(
        self,
        *,
        payer_id: UUID,
        payee_email: str,
        amount: Decimal,
        currency: str,
        description: str,
        terms: str | None = None,
        external_reference: str | None = None,
        expires_at: datetime | None = None,
    ) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            payee = await uow.users.get_by_email(payee_email.strip().lower())
            if payee is None:
                raise NotFoundError("No user found with that payee email")
            if payee.id == payer_id:
                raise DomainError("An escrow cannot have the same payer and payee")
            if not payee.is_active:
                raise DomainError("The specified payee's account is not active")

            escrow = Escrow(
                payer_id=payer_id,
                payee_id=payee.id,
                amount=amount,
                currency=currency,
                description=description,
                terms=terms,
                external_reference=external_reference,
                expires_at=expires_at,
                status=EscrowStatus.CREATED,
            )
            uow.escrows.add(escrow)
            await uow.session.flush()

            uow.session.add(
                EscrowEvent(
                    escrow_id=escrow.id,
                    from_status=None,
                    to_status=EscrowStatus.CREATED,
                    actor_id=payer_id,
                )
            )
            # Immediately advance to AWAITING_PAYMENT — see
            # EscrowStateMachine's module docstring for why creation and
            # this first transition happen together rather than needing
            # a separate "activate" endpoint the spec doesn't list.
            event = EscrowStateMachine.transition(
                escrow, EscrowStatus.AWAITING_PAYMENT, actor_id=payer_id
            )
            uow.session.add(event)

            uow.audit_log.add(
                AuditLog(
                    actor_id=payer_id,
                    action=AuditAction.ESCROW_CREATED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )
            notify(
                uow,
                payee.id,
                NotificationType.ESCROW_CREATED,
                title="New escrow awaiting payment",
                message=(
                    f"{escrow.description} — awaiting payment of "
                    f"{escrow.amount} {escrow.currency}"
                ),
                reference_type="escrow",
                reference_id=escrow.id,
            )

            await uow.commit()
            return escrow

    async def get_escrow(self, escrow_id: UUID, *, user_id: UUID) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_by_id(escrow_id)
            if escrow is None or user_id not in (escrow.payer_id, escrow.payee_id):
                # Same error either way: a party who isn't payer or payee
                # shouldn't be able to tell "doesn't exist" apart from
                # "exists but isn't yours" by the response they get.
                raise NotFoundError("Escrow not found")
            return escrow

    async def list_escrows(
        self, user_id: UUID, *, limit: int = 50, offset: int = 0
    ) -> list[Escrow]:
        async with UnitOfWork(self._session) as uow:
            return await uow.escrows.list_for_user(user_id, limit=limit, offset=offset)

    async def cancel_escrow(
        self, escrow_id: UUID, *, user_id: UUID, reason: str | None = None
    ) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_for_update(escrow_id)
            if escrow is None or user_id not in (escrow.payer_id, escrow.payee_id):
                raise NotFoundError("Escrow not found")

            event = EscrowStateMachine.transition(
                escrow, EscrowStatus.CANCELLED, actor_id=user_id, reason=reason
            )
            uow.session.add(event)
            uow.audit_log.add(
                AuditLog(
                    actor_id=user_id,
                    action=AuditAction.ESCROW_CANCELLED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            other_party_id = (
                escrow.payee_id if user_id == escrow.payer_id else escrow.payer_id
            )
            notify(
                uow,
                other_party_id,
                NotificationType.ESCROW_CANCELLED,
                title="Escrow cancelled",
                message=f"{escrow.description} was cancelled" + (f": {reason}" if reason else ""),
                reference_type="escrow",
                reference_id=escrow.id,
            )

            await uow.commit()
            return escrow

    async def list_expired_unfunded_escrow_ids(self, *, limit: int = 100) -> list[UUID]:
        """IDs of escrows past their funding deadline, still unfunded.

        Read-only helper for the Phase 8 expired-escrow detection worker
        — see `expire_escrow` for what happens to each one.
        """
        async with UnitOfWork(self._session) as uow:
            escrows = await uow.escrows.list_expired_unfunded(limit=limit)
            return [escrow.id for escrow in escrows]

    async def expire_escrow(self, escrow_id: UUID) -> Escrow:
        """System-triggered cancellation of an escrow whose funding
        deadline passed before it was funded.

        Unlike `cancel_escrow`, there's no calling user to authorize
        against — this is invoked by the expired-escrow detection worker
        (Phase 8), not an API endpoint, so `actor_id` is `None` on both
        the `EscrowEvent` and the `AuditLog` row it writes, same as any
        other system-initiated action.
        """
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_for_update(escrow_id)
            if escrow is None:
                raise NotFoundError("Escrow not found")  # pragma: no cover - defensive

            event = EscrowStateMachine.transition(
                escrow,
                EscrowStatus.CANCELLED,
                actor_id=None,
                reason="Escrow expired before funding",
            )
            uow.session.add(event)
            uow.audit_log.add(
                AuditLog(
                    actor_id=None,
                    action=AuditAction.ESCROW_CANCELLED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                    extra_data={"reason": "expired"},
                )
            )

            for party_id in (escrow.payer_id, escrow.payee_id):
                notify(
                    uow,
                    party_id,
                    NotificationType.ESCROW_CANCELLED,
                    title="Escrow expired",
                    message=(
                        f"{escrow.description} expired before being funded "
                        f"and was automatically cancelled"
                    ),
                    reference_type="escrow",
                    reference_id=escrow.id,
                )

            await uow.commit()
            return escrow
