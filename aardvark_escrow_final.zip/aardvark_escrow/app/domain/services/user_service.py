"""User profile service.

Handles `PATCH /users/me`: updating name, email, and/or password in one
call. Changing the email resets `is_verified` to `False` — there's no
email-sending/verification flow yet (that's Phase 8), so this just marks
the account as needing re-verification whenever that flow lands, rather
than silently treating a new, unconfirmed email address as verified.
"""
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import AuthenticationError, ConflictError, NotFoundError
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.user import User
from app.security.password import hash_password, verify_password


class UserService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def update_profile(
        self,
        user_id: UUID,
        *,
        full_name: str | None = None,
        email: str | None = None,
        current_password: str | None = None,
        new_password: str | None = None,
    ) -> User:
        async with UnitOfWork(self._session) as uow:
            user = await uow.users.get_by_id(user_id)
            if user is None:
                raise NotFoundError("User not found")  # pragma: no cover - defensive

            if full_name is not None:
                user.full_name = full_name.strip()

            if email is not None:
                normalized_email = email.strip().lower()
                if normalized_email != user.email:
                    existing = await uow.users.get_by_email(normalized_email)
                    if existing is not None and existing.id != user.id:
                        raise ConflictError("An account with this email already exists")
                    user.email = normalized_email
                    user.is_verified = False

            if new_password is not None:
                if current_password is None or not verify_password(
                    current_password, user.hashed_password
                ):
                    raise AuthenticationError("Current password is incorrect")
                user.hashed_password = hash_password(new_password)

            uow.audit_log.add(
                AuditLog(
                    actor_id=user.id,
                    action=AuditAction.USER_UPDATED,
                    resource_type="user",
                    resource_id=user.id,
                )
            )

            await uow.commit()
            return user
