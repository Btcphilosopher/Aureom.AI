"""Domain services.

Business logic that doesn't belong to a single entity lives here.
`AuthService` (Phase 3); `UserService` and `WalletService` (Phase 4);
`EscrowStateMachine` and `EscrowService` (Phase 5) for the non-financial
half of the escrow lifecycle; `EscrowTransactionEngine` (Phase 6) for
fund/approve/release/refund/split, the half that moves money;
`DisputeService` (Phase 7), which delegates its money-moving resolutions
to the transaction engine. `notification_helpers.notify` is a small
shared utility several of these call to write an in-app notification
alongside their other work. All of them depend only on repository
interfaces via `app.database.unit_of_work.UnitOfWork`, never on FastAPI
directly.
"""
