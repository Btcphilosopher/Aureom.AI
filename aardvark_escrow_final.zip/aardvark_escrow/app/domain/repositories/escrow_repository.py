"""Escrow persistence."""
from datetime import UTC, datetime
from typing import Protocol
from uuid import UUID

from sqlalchemy import or_, select
from sqlalchemy.orm import selectinload

from app.domain.entities.enums import EscrowStatus
from app.domain.entities.escrow import Escrow, EscrowTransaction
from app.domain.repositories.base import SQLAlchemyRepository

_UNFUNDED_STATUSES = (EscrowStatus.CREATED, EscrowStatus.AWAITING_PAYMENT)


class EscrowRepository(Protocol):
    async def get_by_id(self, escrow_id: UUID) -> Escrow | None: ...
    async def get_for_update(self, escrow_id: UUID) -> Escrow | None: ...
    async def list_for_user(
        self, user_id: UUID, limit: int = 50, offset: int = 0
    ) -> list[Escrow]: ...
    async def get_transaction_by_idempotency_key(
        self, idempotency_key: str
    ) -> EscrowTransaction | None: ...
    async def list_expired_unfunded(self, *, limit: int = 100) -> list[Escrow]: ...
    def add(self, escrow: Escrow) -> None: ...


class SQLAlchemyEscrowRepository(SQLAlchemyRepository[Escrow]):
    model = Escrow

    async def get_by_id(self, escrow_id: UUID) -> Escrow | None:
        result = await self._session.execute(
            select(Escrow)
            .where(Escrow.id == escrow_id)
            .options(selectinload(Escrow.transactions), selectinload(Escrow.events))
        )
        return result.scalar_one_or_none()

    async def get_for_update(self, escrow_id: UUID) -> Escrow | None:
        """Lock the escrow row for the duration of the current transaction.

        Held alongside one or two wallet locks (see
        `WalletRepository.get_for_update`) by `EscrowTransactionEngine`
        (Phase 6) whenever it moves money and advances escrow status in
        the same unit of work. `populate_existing=True` is required for
        the same reason it is there — see that method's docstring for the
        identity-map staleness bug it prevents.
        """
        result = await self._session.execute(
            select(Escrow)
            .where(Escrow.id == escrow_id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        return result.scalar_one_or_none()

    async def list_for_user(
        self, user_id: UUID, limit: int = 50, offset: int = 0
    ) -> list[Escrow]:
        """Escrows where the user is either the payer or the payee."""
        result = await self._session.execute(
            select(Escrow)
            .where(or_(Escrow.payer_id == user_id, Escrow.payee_id == user_id))
            .order_by(Escrow.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())

    async def get_transaction_by_idempotency_key(
        self, idempotency_key: str
    ) -> EscrowTransaction | None:
        """Look up a previously-processed fund/release/refund by its key.

        The single record-of-truth for "did this escrow operation already
        happen" — checked here rather than against either wallet's ledger,
        since one escrow operation (release) can touch two wallets' ledgers
        at once but only ever produces one `EscrowTransaction`.
        """
        result = await self._session.execute(
            select(EscrowTransaction).where(
                EscrowTransaction.idempotency_key == idempotency_key
            )
        )
        return result.scalar_one_or_none()

    async def list_expired_unfunded(self, *, limit: int = 100) -> list[Escrow]:
        """Escrows past their funding deadline, still in CREATED or
        AWAITING_PAYMENT. Feeds the Phase 8 expired-escrow detection
        worker — see `EscrowService.expire_escrow` for what happens next.
        """
        result = await self._session.execute(
            select(Escrow)
            .where(
                Escrow.expires_at.is_not(None),
                Escrow.expires_at < datetime.now(UTC),
                Escrow.status.in_(_UNFUNDED_STATUSES),
            )
            .limit(limit)
        )
        return list(result.scalars().all())
