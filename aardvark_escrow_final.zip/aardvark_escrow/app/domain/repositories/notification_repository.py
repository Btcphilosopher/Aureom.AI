"""Notification persistence."""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.enums import NotificationStatus
from app.domain.entities.notification import Notification
from app.domain.repositories.base import SQLAlchemyRepository


class NotificationRepository(Protocol):
    async def get_by_id(self, notification_id: UUID) -> Notification | None: ...
    async def list_for_user(
        self, user_id: UUID, limit: int = 50, offset: int = 0
    ) -> list[Notification]: ...
    async def list_pending(self, *, limit: int = 100) -> list[Notification]: ...
    def add(self, notification: Notification) -> None: ...


class SQLAlchemyNotificationRepository(SQLAlchemyRepository[Notification]):
    model = Notification

    async def list_for_user(
        self, user_id: UUID, limit: int = 50, offset: int = 0
    ) -> list[Notification]:
        result = await self._session.execute(
            select(Notification)
            .where(Notification.user_id == user_id)
            .order_by(Notification.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())

    async def list_pending(self, *, limit: int = 100) -> list[Notification]:
        """Notifications not yet delivered — feeds the Phase 8 delivery
        worker (`app.workers.tasks.notifications`).
        """
        result = await self._session.execute(
            select(Notification)
            .where(Notification.status == NotificationStatus.PENDING)
            .order_by(Notification.created_at)
            .limit(limit)
        )
        return list(result.scalars().all())
