"""AuditLog persistence.

Deliberately exposes no update or delete method at all — not "unused",
genuinely absent — so the immutability guarantee is enforced by the type
the service layer depends on, not just by convention.
"""
from datetime import datetime
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.audit import AuditLog
from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.domain.repositories.base import SQLAlchemyRepository


class AuditLogRepository(Protocol):
    async def list_by_resource(
        self, resource_type: str, resource_id: UUID, limit: int = 100
    ) -> list[AuditLog]: ...
    async def list_recent(self, limit: int = 100, offset: int = 0) -> list[AuditLog]: ...
    async def list_by_date_range(
        self, *, start: datetime | None = None, end: datetime | None = None, limit: int = 1000
    ) -> list[AuditLog]: ...
    async def list_admin_actions(
        self, *, start: datetime | None = None, end: datetime | None = None, limit: int = 1000
    ) -> list[AuditLog]: ...
    def add(self, audit_log: AuditLog) -> None: ...


class SQLAlchemyAuditLogRepository(SQLAlchemyRepository[AuditLog]):
    model = AuditLog

    async def list_by_resource(
        self, resource_type: str, resource_id: UUID, limit: int = 100
    ) -> list[AuditLog]:
        result = await self._session.execute(
            select(AuditLog)
            .where(
                AuditLog.resource_type == resource_type,
                AuditLog.resource_id == resource_id,
            )
            .order_by(AuditLog.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def list_recent(self, limit: int = 100, offset: int = 0) -> list[AuditLog]:
        result = await self._session.execute(
            select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).offset(offset)
        )
        return list(result.scalars().all())

    async def list_by_date_range(
        self, *, start: datetime | None = None, end: datetime | None = None, limit: int = 1000
    ) -> list[AuditLog]:
        """Feeds the Phase 9 audit export report."""
        query = select(AuditLog)
        if start is not None:
            query = query.where(AuditLog.created_at >= start)
        if end is not None:
            query = query.where(AuditLog.created_at <= end)
        query = query.order_by(AuditLog.created_at).limit(limit)

        result = await self._session.execute(query)
        return list(result.scalars().all())

    async def list_admin_actions(
        self, *, start: datetime | None = None, end: datetime | None = None, limit: int = 1000
    ) -> list[AuditLog]:
        """Actions taken by admin-role users specifically — feeds the
        Phase 9 operator activity report. Requires a join to `User`
        since `AuditLog` only stores `actor_id`, not the actor's role at
        the time (roles can change; this reports against *current* role,
        which is what "who are our operators, what have they been doing"
        actually wants to know).
        """
        query = (
            select(AuditLog)
            .join(User, User.id == AuditLog.actor_id)
            .where(User.role == UserRole.ADMIN)
        )
        if start is not None:
            query = query.where(AuditLog.created_at >= start)
        if end is not None:
            query = query.where(AuditLog.created_at <= end)
        query = query.order_by(AuditLog.created_at).limit(limit)

        result = await self._session.execute(query)
        return list(result.scalars().all())
