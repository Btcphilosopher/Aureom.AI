"""Enums shared across domain entities.

Kept in one module (rather than scattered per-entity) because several of
these are referenced from more than one entity file, and because seeing
the full vocabulary of statuses in one place makes the state machines
easier to reason about.
"""
import enum


class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"


class UserStatus(str, enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DELETED = "deleted"


class WalletTransactionType(str, enum.Enum):
    """Direction/purpose of a single wallet ledger entry.

    For DEPOSIT, WITHDRAWAL, and both sides of ESCROW_RELEASE, `amount`
    is a signed change to `Wallet.balance` (positive = credit, negative =
    debit) — summing these reconstructs `balance` (see the Phase 8
    reconciliation task, `app.workers.tasks.reconciliation`, which does
    exactly that).

    ESCROW_HOLD and ESCROW_REFUND are different: funding an escrow moves
    money into `held_balance`, not out of `balance` (an authorization-hold
    model — see `EscrowTransactionEngine`'s module docstring, Phase 6, for
    the full reasoning), so `balance` itself never changes for these two
    types. `amount` instead tracks the change to the user's *available*
    (spendable, non-held) position — negative for ESCROW_HOLD (funds
    become encumbered, `held_balance` goes up but availability goes
    down), positive for ESCROW_REFUND (the hold is released, availability
    goes back up). This is the inverse of the `held_balance` change
    itself, not the same as it — an earlier version of this docstring
    said "amount is the signed change to held_balance," which was
    backwards; fixed once this mattered for real, when the Phase 8
    reconciliation task needed a precise, correct description to
    reconstruct anything from. `held_balance` itself isn't reconstructed
    from this ledger at all: see that task's docstring for why, and what
    it checks against instead.

    The paying side of ESCROW_RELEASE (the payer's wallet, once the hold
    actually converts to a transfer) changes both `held_balance` and
    `balance` in the same operation — see `EscrowTransactionEngine.release`.
    """

    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    ESCROW_HOLD = "escrow_hold"
    ESCROW_RELEASE = "escrow_release"
    ESCROW_REFUND = "escrow_refund"
    FEE = "fee"
    ADJUSTMENT = "adjustment"


class EscrowStatus(str, enum.Enum):
    """The escrow lifecycle. See docs/architecture.md for the full diagram.

    EscrowStateMachine (Phase 5) is the only code path permitted to change
    this value on a persisted Escrow.
    """

    CREATED = "created"
    AWAITING_PAYMENT = "awaiting_payment"
    FUNDED = "funded"
    IN_PROGRESS = "in_progress"
    AWAITING_APPROVAL = "awaiting_approval"
    RELEASED = "released"
    DISPUTED = "disputed"
    REFUNDED = "refunded"
    CANCELLED = "cancelled"
    CLOSED = "closed"


class EscrowTransactionType(str, enum.Enum):
    DEPOSIT = "deposit"
    RELEASE = "release"
    REFUND = "refund"
    FEE = "fee"
    ADJUSTMENT = "adjustment"


class EscrowTransactionStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"


class DisputeStatus(str, enum.Enum):
    OPEN = "open"
    UNDER_REVIEW = "under_review"
    RESOLVED = "resolved"
    CLOSED = "closed"


class DisputeResolution(str, enum.Enum):
    RELEASE_TO_PAYEE = "release_to_payee"
    REFUND_TO_PAYER = "refund_to_payer"
    SPLIT = "split"


class NotificationType(str, enum.Enum):
    ESCROW_CREATED = "escrow_created"
    ESCROW_FUNDED = "escrow_funded"
    ESCROW_RELEASED = "escrow_released"
    ESCROW_REFUNDED = "escrow_refunded"
    ESCROW_CANCELLED = "escrow_cancelled"
    DISPUTE_OPENED = "dispute_opened"
    DISPUTE_RESOLVED = "dispute_resolved"
    SYSTEM = "system"


class NotificationStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    READ = "read"


class APIKeyStatus(str, enum.Enum):
    ACTIVE = "active"
    REVOKED = "revoked"
