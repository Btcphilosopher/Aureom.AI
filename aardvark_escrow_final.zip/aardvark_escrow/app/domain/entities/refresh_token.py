"""RefreshToken entity — backs the `sessions` concept in the DATABASE spec.

Only a hash of the refresh token is ever persisted, mirroring the API-key
approach: a stolen database dump should never yield usable credentials.
Logout / "log out everywhere" (Phase 3) works by setting `revoked_at`
rather than deleting the row, so a reused revoked token can be detected
and logged rather than silently failing.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import DateTime, ForeignKey, Index, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.domain.entities.user import User


class RefreshToken(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "refresh_tokens"
    __table_args__ = (Index("ix_refresh_tokens_user_id_revoked_at", "user_id", "revoked_at"),)

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    hashed_token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)

    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)

    expires_at: Mapped["datetime"] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped["datetime | None"] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="refresh_tokens")

    @property
    def is_revoked(self) -> bool:
        return self.revoked_at is not None

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<RefreshToken id={self.id} user_id={self.user_id} revoked={self.is_revoked}>"
