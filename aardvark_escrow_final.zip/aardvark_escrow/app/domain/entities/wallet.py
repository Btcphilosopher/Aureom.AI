"""Wallet and WalletTransaction entities.

`Wallet.balance` is a maintained cache — the append-only `WalletTransaction`
ledger is the source of truth. Every mutation to `balance` or `held_balance`
must happen in the same database transaction as the `WalletTransaction` row
that justifies it (enforced by WalletService in Phase 4, TransactionEngine
in Phase 6), never as a bare UPDATE.

`held_balance` tracks funds locked against an active escrow — money a user
owns but cannot withdraw because it's securing a pending deal. Available
balance for withdrawal purposes is always `balance - held_balance`.
"""
from decimal import Decimal
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import (
    CheckConstraint,
    Enum,
    ForeignKey,
    Index,
    Numeric,
    String,
    Text,
    Uuid,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin
from app.domain.entities.enums import WalletTransactionType

if TYPE_CHECKING:
    from app.domain.entities.user import User


class Wallet(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "wallets"
    __table_args__ = (
        CheckConstraint("balance >= 0", name="ck_wallets_balance_non_negative"),
        CheckConstraint("held_balance >= 0", name="ck_wallets_held_balance_non_negative"),
        CheckConstraint("held_balance <= balance", name="ck_wallets_held_balance_le_balance"),
    )

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), unique=True, nullable=False
    )
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    balance: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00")
    )
    held_balance: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00")
    )

    user: Mapped["User"] = relationship(back_populates="wallet")
    transactions: Mapped[list["WalletTransaction"]] = relationship(
        back_populates="wallet", order_by="WalletTransaction.created_at"
    )

    @property
    def available_balance(self) -> Decimal:
        """Funds free to withdraw or commit to a new escrow right now."""
        return self.balance - self.held_balance

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<Wallet id={self.id} user_id={self.user_id} balance={self.balance}>"


class WalletTransaction(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    """A single, immutable ledger entry against a wallet.

    `amount` is signed: positive for credits (deposit, escrow release
    received), negative for debits (withdrawal, escrow hold, fee).
    `balance_after` snapshots the wallet balance immediately after this
    entry was applied, so the ledger is auditable without replaying the
    full history.
    """

    __tablename__ = "wallet_transactions"
    __table_args__ = (
        Index("ix_wallet_transactions_wallet_id_created_at", "wallet_id", "created_at"),
    )

    wallet_id: Mapped[UUID] = mapped_column(
        ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False
    )
    type: Mapped[WalletTransactionType] = mapped_column(
        Enum(WalletTransactionType, name="wallet_transaction_type"), nullable=False
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)
    balance_after: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)

    reference_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    reference_id: Mapped[UUID | None] = mapped_column(Uuid, nullable=True)

    description: Mapped[str] = mapped_column(Text, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(
        String(255), unique=True, nullable=True
    )

    wallet: Mapped["Wallet"] = relationship(back_populates="transactions")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return (
            f"<WalletTransaction id={self.id} wallet_id={self.wallet_id} "
            f"type={self.type.value} amount={self.amount}>"
        )
