"""Aggregates all v1 API routers into a single mountable router."""
from fastapi import APIRouter

from app.api.v1.endpoints import (
    audit,
    auth,
    disputes,
    escrows,
    health,
    notifications,
    reports,
    users,
    wallet,
)

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(wallet.router)
api_router.include_router(escrows.router)
api_router.include_router(disputes.router)
api_router.include_router(audit.router)
api_router.include_router(notifications.router)
api_router.include_router(reports.router)
