"""User-facing endpoints."""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.user import User
from app.domain.services.user_service import UserService
from app.schemas.user import UpdateUserRequest, UserPublic
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserPublic)
async def get_me(current_user: User = Depends(get_current_user)) -> UserPublic:
    return UserPublic.model_validate(current_user)


@router.patch("/me", response_model=UserPublic)
async def update_me(
    body: UpdateUserRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserPublic:
    updated = await UserService(db).update_profile(
        current_user.id,
        full_name=body.full_name,
        email=body.email,
        current_password=body.current_password,
        new_password=body.new_password,
    )
    return UserPublic.model_validate(updated)
