"""Shared Pydantic field validators.

Factored out so `RegisterRequest.password` and `UpdateUserRequest.new_password`
enforce exactly the same rule rather than two copies drifting apart.
"""


def validate_password_strength(value: str) -> str:
    if value.isdigit() or value.isalpha():
        raise ValueError(
            "Password must contain a mix of letters, numbers, and/or symbols"
        )
    return value


def validate_optional_password_strength(value: str | None) -> str | None:
    """Same rule as `validate_password_strength`, but for an optional field
    (e.g. `UpdateUserRequest.new_password`, where `None` means "not changing
    the password" and should skip the strength check entirely).
    """
    if value is None:
        return value
    return validate_password_strength(value)
