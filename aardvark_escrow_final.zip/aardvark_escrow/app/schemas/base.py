"""Shared Pydantic schema base classes."""
from pydantic import BaseModel, ConfigDict


class ORMModel(BaseModel):
    """Base for response schemas built from ORM entities.

    `from_attributes=True` lets these be constructed directly from a
    SQLAlchemy model instance (`UserPublic.model_validate(user)`) instead
    of manually unpacking every field.
    """

    model_config = ConfigDict(from_attributes=True)
