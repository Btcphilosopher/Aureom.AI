"""Application factory and ASGI entrypoint.

`app` (the module-level FastAPI instance at the bottom of this file) is
what Uvicorn/Gunicorn point at: `app.main:app`.
"""
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.exceptions import (
    AardvarkError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    DomainError,
    NotFoundError,
    RateLimitExceededError,
)
from app.core.logging import configure_logging, get_logger
from app.middleware.request_context import RequestContextMiddleware
from app.middleware.security_headers import SecurityHeadersMiddleware

configure_logging()
logger = get_logger(__name__)

# Maps domain exception types to HTTP status codes. Checked in subclass
# order so e.g. InvalidStateTransitionError (a DomainError) still resolves
# to 422 without needing its own entry.
_ERROR_STATUS_MAP: dict[type[AardvarkError], int] = {
    NotFoundError: status.HTTP_404_NOT_FOUND,
    AuthenticationError: status.HTTP_401_UNAUTHORIZED,
    AuthorizationError: status.HTTP_403_FORBIDDEN,
    ConflictError: status.HTTP_409_CONFLICT,
    RateLimitExceededError: status.HTTP_429_TOO_MANY_REQUESTS,
    DomainError: status.HTTP_422_UNPROCESSABLE_ENTITY,
}


_OPENAPI_TAGS = [
    {
        "name": "auth",
        "description": "Register, log in, refresh, and log out. JWT access tokens "
        "(short-lived) plus opaque, rotating refresh tokens.",
    },
    {
        "name": "users",
        "description": "The authenticated caller's own profile.",
    },
    {
        "name": "wallet",
        "description": "Deposit, withdraw, and view balance. Wallets are provisioned "
        "lazily on first use.",
    },
    {
        "name": "escrows",
        "description": "Create, list, and read escrows, plus their full lifecycle: "
        "cancel, fund, approve, release, refund, and raise a dispute.",
    },
    {
        "name": "disputes",
        "description": "Submit evidence and, for admins, resolve a dispute "
        "(release the full amount, refund it, or split it between both parties).",
    },
    {
        "name": "audit",
        "description": "Admin-only: the platform's immutable audit trail.",
    },
    {
        "name": "notifications",
        "description": "The authenticated caller's own in-app notifications.",
    },
    {
        "name": "reports",
        "description": "Downloadable PDF/CSV reports — escrow history, wallet "
        "statements, audit exports, operator activity, and a platform-wide "
        "financial summary (the last three admin-only).",
    },
    {
        "name": "health",
        "description": "Liveness/readiness probes for orchestrators. No auth required.",
    },
]

_API_DESCRIPTION = """
A production-grade escrow platform: it holds funds between two or more
parties and releases, refunds, or arbitrates them according to strict,
auditable business rules.

Authenticate with either a bearer JWT (`Authorization: Bearer <token>`,
from `/auth/login` or `/auth/register`) or an API key
(`X-API-Key: <key>`) — both are accepted interchangeably by every
protected endpoint.

See `docs/architecture.md` in this repository for the escrow state
machine, financial integrity model, and security design this API is
built on.
"""


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info("application_startup", environment=settings.ENVIRONMENT)
    yield
    logger.info("application_shutdown")


def create_app() -> FastAPI:
    application = FastAPI(
        title=settings.PROJECT_NAME,
        description=_API_DESCRIPTION,
        version="1.0.0",
        openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
        docs_url=f"{settings.API_V1_PREFIX}/docs",
        redoc_url=f"{settings.API_V1_PREFIX}/redoc",
        openapi_tags=_OPENAPI_TAGS,
        lifespan=lifespan,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    application.add_middleware(RequestContextMiddleware)
    application.add_middleware(SecurityHeadersMiddleware)

    _register_exception_handlers(application)

    application.include_router(api_router, prefix=settings.API_V1_PREFIX)

    return application


def _register_exception_handlers(application: FastAPI) -> None:
    @application.exception_handler(AardvarkError)
    async def handle_aardvark_error(request: Request, exc: AardvarkError) -> JSONResponse:
        http_status = status.HTTP_400_BAD_REQUEST
        for exc_type, mapped_status in _ERROR_STATUS_MAP.items():
            if isinstance(exc, exc_type):
                http_status = mapped_status
                break

        logger.warning(
            "domain_error",
            error_type=type(exc).__name__,
            detail=str(exc),
            path=request.url.path,
        )
        return JSONResponse(
            status_code=http_status,
            content={"error": type(exc).__name__, "detail": str(exc)},
        )


app = create_app()
