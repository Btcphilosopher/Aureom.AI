"""Audit trail and reporting.

The audit *trail* itself (writing `AuditLog` rows) has been live since
Phase 3 — every domain service writes one alongside its other work via
`AuditLogRepository`. `GET /audit` (Phase 7) reads them back directly.

`service.py` (Phase 9) is the reporting layer on top: `ReportService`
gathers data (escrow history, wallet statements, audit exports, operator
activity, platform financial summaries) and hands it to `pdf.py`
(ReportLab) or `csv_export.py` (stdlib `csv`) for rendering. See
`app.api.v1.endpoints.reports` for the endpoints that expose these as
downloads.
"""
