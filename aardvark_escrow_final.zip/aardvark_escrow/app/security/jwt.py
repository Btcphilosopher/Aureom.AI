"""JWT access token issuance and verification.

Refresh tokens are deliberately NOT JWTs — see `app.security.refresh_tokens`
for the reasoning. Access tokens are short-lived (see
`settings.ACCESS_TOKEN_EXPIRE_MINUTES`), signed, and stateless: verifying
one never needs a database round trip. `get_current_user` in
`app.security.dependencies` still hits the database, but only to check
the *user's* current status (e.g. suspended after the token was issued) —
the token's own validity is checked entirely locally.
"""
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from uuid import UUID

import jwt

from app.core.config import settings
from app.core.exceptions import AuthenticationError
from app.domain.entities.enums import UserRole

_TOKEN_TYPE = "access"


@dataclass(frozen=True)
class AccessTokenPayload:
    user_id: UUID
    role: UserRole


def create_access_token(user_id: UUID, role: UserRole) -> str:
    now = datetime.now(UTC)
    payload = {
        "sub": str(user_id),
        "role": role.value,
        "type": _TOKEN_TYPE,
        "iat": now,
        "exp": now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_access_token(token: str) -> AccessTokenPayload:
    """Verify signature + expiry and return the decoded payload.

    Raises `AuthenticationError` — never a raw `jwt` exception — so
    callers elsewhere only need to know about this codebase's own
    exception hierarchy, not PyJWT's.
    """
    try:
        payload = jwt.decode(
            token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
        )
    except jwt.ExpiredSignatureError as exc:
        raise AuthenticationError("Access token has expired") from exc
    except jwt.InvalidTokenError as exc:
        raise AuthenticationError("Invalid access token") from exc

    if payload.get("type") != _TOKEN_TYPE:
        raise AuthenticationError("Invalid access token")

    try:
        user_id = UUID(payload["sub"])
        role = UserRole(payload["role"])
    except (KeyError, ValueError) as exc:
        raise AuthenticationError("Invalid access token") from exc

    return AccessTokenPayload(user_id=user_id, role=role)
