"""Password hashing.

Argon2id via Passlib — the OWASP-recommended default for new
applications, and specified explicitly in the project's security
requirements. Using `CryptContext` rather than calling an Argon2 library
directly means we can add a legacy scheme (e.g. bcrypt) later for
verifying old hashes during a migration, without touching any call site.
"""
from passlib.context import CryptContext

_pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    return _pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return _pwd_context.verify(plain_password, hashed_password)
