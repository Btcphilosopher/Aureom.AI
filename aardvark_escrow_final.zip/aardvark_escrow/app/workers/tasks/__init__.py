"""Celery task implementations.

Each module here follows the same shape: a plain `async def _impl(...)`
function holding the actual logic (directly testable with pytest-asyncio,
against a real database, the same as every other service in this
codebase), and a thin `@celery_app.task` wrapper that bridges into it via
`asyncio.run`. The wrapper is *not* called directly in tests — Celery
workers run tasks synchronously, and `asyncio.run` cannot be invoked from
inside an already-running event loop (which pytest-asyncio provides), so
tests exercise the `_impl` function instead.
"""
