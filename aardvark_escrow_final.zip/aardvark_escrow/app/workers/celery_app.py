"""Celery application configuration.

Task modules are listed in `include=` so a worker process discovers and
registers their `@celery_app.task`-decorated functions on startup. Each
one follows the sync-task/async-impl split described in
`app.workers.tasks`'s module docstring.

`beat_schedule` drives Celery Beat (the periodic-task scheduler) — run
alongside a worker via `celery -A app.workers.celery_app beat` in
production. Intervals are deliberately conservative for a first pass:
notification delivery runs often (users shouldn't wait long to be
notified), everything else runs on a daily or hourly cadence appropriate
to how time-sensitive it actually is.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "aardvark_escrow",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.workers.tasks.notifications",
        "app.workers.tasks.escrow_expiry",
        "app.workers.tasks.reconciliation",
        "app.workers.tasks.statistics",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    beat_schedule={
        "deliver-pending-notifications": {
            "task": "notifications.deliver_pending",
            "schedule": 60.0,  # every minute
        },
        "detect-expired-escrows": {
            "task": "escrows.detect_expired",
            "schedule": crontab(minute=0),  # hourly
        },
        "daily-wallet-reconciliation": {
            "task": "reconciliation.daily_wallet_reconciliation",
            "schedule": crontab(hour=2, minute=0),  # 02:00 UTC daily
        },
        "generate-platform-statistics": {
            "task": "statistics.generate_platform_statistics",
            "schedule": crontab(hour=1, minute=0),  # 01:00 UTC daily
        },
    },
)
