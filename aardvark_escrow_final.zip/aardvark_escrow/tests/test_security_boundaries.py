"""Consolidated security tests.

Many individual security properties already have dedicated tests
elsewhere in this suite (password hashing in test_security.py, rate
limiting in test_rate_limit.py, RBAC in test_rbac.py, API key handling
in test_api_key_auth.py). This file covers what didn't already have a
clear home: a systematic IDOR sweep across every resource type, sensitive
field non-leakage, mass-assignment protection, and SQL-injection
resistance — properties worth checking explicitly rather than trusting
"the ORM probably handles it."
"""
import uuid

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.api_key import APIKey
from app.domain.entities.refresh_token import RefreshToken
from app.domain.entities.user import User

pytestmark = [pytest.mark.security]

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> dict:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    body = response.json()
    return {"token": body["access_token"], "user_id": body["user"]["id"]}


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


# ------------------------------------------------------------------ IDOR


async def test_cannot_view_another_users_escrow(client: AsyncClient) -> None:
    owner = await _register(client, "sec-idor-owner1@example.com", "Owner")
    await _register(client, "sec-idor-payee1@example.com", "Payee")
    outsider = await _register(client, "sec-idor-out1@example.com", "Outsider")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(owner["token"]),
        json={
            "payee_email": "sec-idor-payee1@example.com",
            "amount": "10.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]

    response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(outsider["token"])
    )
    assert response.status_code == 404


async def test_cannot_cancel_another_users_escrow(client: AsyncClient) -> None:
    owner = await _register(client, "sec-idor-owner2@example.com", "Owner")
    await _register(client, "sec-idor-payee2@example.com", "Payee")
    outsider = await _register(client, "sec-idor-out2@example.com", "Outsider")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(owner["token"]),
        json={
            "payee_email": "sec-idor-payee2@example.com",
            "amount": "10.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(outsider["token"]), json={}
    )
    assert response.status_code == 404


async def test_cannot_fund_another_users_escrow(client: AsyncClient) -> None:
    owner = await _register(client, "sec-idor-owner3@example.com", "Owner")
    payee = await _register(client, "sec-idor-payee3@example.com", "Payee")
    outsider = await _register(client, "sec-idor-out3@example.com", "Outsider")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(outsider["token"]), json={"amount": "1000.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(owner["token"]),
        json={
            "payee_email": "sec-idor-payee3@example.com",
            "amount": "10.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]

    # A true outsider (not payer or payee) can't even see the escrow
    # exists — 404, not 403, so its existence isn't leaked either.
    outsider_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(outsider["token"]), json={}
    )
    assert outsider_response.status_code == 404

    # The payee IS a legitimate party — they can see the escrow — but
    # funding is the payer's action specifically, so this is a 403.
    payee_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payee["token"]), json={}
    )
    assert payee_response.status_code == 403


async def test_cannot_view_another_users_dispute_evidence_submission(
    client: AsyncClient,
) -> None:
    payer = await _register(client, "sec-idor-disp-payer@example.com", "Payer")
    await _register(client, "sec-idor-disp-payee@example.com", "Payee")
    outsider = await _register(client, "sec-idor-disp-out@example.com", "Outsider")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "100.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "sec-idor-disp-payee@example.com",
            "amount": "50.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    dispute_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": "x"},
    )
    dispute_id = dispute_response.json()["id"]

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/evidence",
        headers=_headers(outsider["token"]),
        json={"description": "not involved"},
    )
    assert response.status_code == 404


async def test_wallet_operations_always_scope_to_the_caller(client: AsyncClient) -> None:
    """There's no `/wallet/{id}` route at all — every wallet endpoint
    operates on "my own wallet," derived from the auth token, not from a
    client-supplied identifier. This test documents and locks in that
    design choice rather than testing an ID substitution that the API
    surface doesn't even expose.
    """
    user_a = await _register(client, "sec-idor-wallet-a@example.com", "A")
    user_b = await _register(client, "sec-idor-wallet-b@example.com", "B")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(user_a["token"]), json={"amount": "500.00"}
    )

    response = await client.get("/api/v1/wallet", headers=_headers(user_b["token"]))
    assert response.json()["balance"] == "0.00"


async def test_cannot_download_another_users_escrow_report(client: AsyncClient) -> None:
    owner = await _register(client, "sec-idor-report-owner@example.com", "Owner")
    await _register(client, "sec-idor-report-payee@example.com", "Payee")
    outsider = await _register(client, "sec-idor-report-out@example.com", "Outsider")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(owner["token"]),
        json={
            "payee_email": "sec-idor-report-payee@example.com",
            "amount": "10.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(outsider["token"])
    )
    assert response.status_code == 404


# --------------------------------------------------------- sensitive data


async def test_hashed_password_never_appears_in_any_response(client: AsyncClient) -> None:
    creds = await _register(client, "sec-leak-pw@example.com", "Leak Test")

    responses = [
        await client.get("/api/v1/users/me", headers=_headers(creds["token"])),
        await client.patch(
            "/api/v1/users/me", headers=_headers(creds["token"]), json={"full_name": "New Name"}
        ),
    ]
    for response in responses:
        assert "hashed_password" not in response.text
        assert PASSWORD not in response.text


async def test_refresh_token_hash_never_appears_in_response(client: AsyncClient) -> None:
    response = await client.post(
        "/api/v1/auth/register",
        json={
            "email": "sec-leak-rt@example.com",
            "password": PASSWORD,
            "full_name": "Leak Test",
        },
    )
    body = response.json()
    raw_refresh_token = body["refresh_token"]

    # The raw token is expected in the response (the client needs it) —
    # what must never appear is the *hash* stored server-side.
    assert "hashed_token" not in response.text
    assert raw_refresh_token != body["access_token"]


async def test_database_never_stores_the_plaintext_password(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "sec-plaintext@example.com",
            "password": PASSWORD,
            "full_name": "X",
        },
    )
    result = await db_session.execute(
        select(User).where(User.email == "sec-plaintext@example.com")
    )
    user = result.scalar_one()
    assert user.hashed_password != PASSWORD
    assert PASSWORD not in user.hashed_password


async def test_api_key_and_refresh_token_tables_store_hashes_not_plaintext(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    """Structural check on the persistence layer itself: even if some
    future endpoint bug leaked a full row, there's no raw secret sitting
    in the database to leak in the first place.
    """
    creds = await _register(client, "sec-hash-storage@example.com", "X")

    result = await db_session.execute(
        select(RefreshToken).where(
            RefreshToken.user_id == uuid.UUID(creds["user_id"])
        )
    )
    token_row = result.scalars().first()
    assert token_row is not None
    assert len(token_row.hashed_token) >= 32  # a hash, not a short raw value

    # No API keys exist yet for this user (none created), but confirm the
    # column itself is what it claims to be for anyone who does have one.
    api_key_columns = APIKey.__table__.columns
    assert "hashed_key" in api_key_columns
    assert "key_prefix" in api_key_columns


# ---------------------------------------------------------- mass assignment


async def test_cannot_set_own_role_via_profile_update(client: AsyncClient) -> None:
    creds = await _register(client, "sec-mass-role@example.com", "X")

    response = await client.patch(
        "/api/v1/users/me",
        headers=_headers(creds["token"]),
        json={"full_name": "Still Just A User", "role": "admin"},
    )
    # Pydantic ignores unknown fields by default rather than erroring —
    # what matters is that "role" had no effect either way.
    assert response.status_code in (200, 422)
    if response.status_code == 200:
        assert response.json()["role"] == "user"


async def test_cannot_set_own_verification_status_via_profile_update(
    client: AsyncClient,
) -> None:
    creds = await _register(client, "sec-mass-verified@example.com", "X")

    response = await client.patch(
        "/api/v1/users/me",
        headers=_headers(creds["token"]),
        json={"full_name": "X", "is_verified": True},
    )
    assert response.status_code in (200, 422)
    if response.status_code == 200:
        assert response.json()["is_verified"] is False


async def test_cannot_set_escrow_status_directly_on_creation(client: AsyncClient) -> None:
    payer = await _register(client, "sec-mass-escrow-payer@example.com", "Payer")
    await _register(client, "sec-mass-escrow-payee@example.com", "Payee")

    response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "sec-mass-escrow-payee@example.com",
            "amount": "10.00",
            "description": "x",
            "status": "released",  # not a real field on the request schema
        },
    )
    assert response.status_code == 201
    assert response.json()["status"] == "awaiting_payment"


# ---------------------------------------------------- injection resistance


async def test_sql_metacharacters_in_email_are_handled_safely(client: AsyncClient) -> None:
    malicious_email = "'; DROP TABLE users; --@example.com"
    response = await client.post(
        "/api/v1/auth/login", json={"email": malicious_email, "password": "whatever12345"}
    )
    # Either a validation error (invalid email shape) or a clean auth
    # failure — never a 500, and never actually executed as SQL.
    assert response.status_code in (401, 422)


async def test_sql_metacharacters_in_description_are_stored_verbatim(
    client: AsyncClient,
) -> None:
    payer = await _register(client, "sec-sqli-payer@example.com", "Payer")
    await _register(client, "sec-sqli-payee@example.com", "Payee")

    malicious_description = "'; DROP TABLE escrows; -- Robert'); DROP TABLE students;--"
    response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "sec-sqli-payee@example.com",
            "amount": "10.00",
            "description": malicious_description,
        },
    )
    assert response.status_code == 201
    # Parameterized queries treat this as inert text, not SQL — stored
    # and returned exactly as sent, and the escrows table still exists
    # (proven implicitly: the very next call succeeds at all).
    assert response.json()["description"] == malicious_description

    list_response = await client.get("/api/v1/escrows", headers=_headers(payer["token"]))
    assert list_response.status_code == 200
    assert len(list_response.json()) == 1


async def test_xss_payload_in_dispute_reason_is_stored_verbatim_not_executed(
    client: AsyncClient,
) -> None:
    """This is a JSON API, not server-rendered HTML, so there's no
    templating layer that could execute an injected script — but the
    same principle applies: untrusted input is data, stored and returned
    as-is, never interpreted.
    """
    payer = await _register(client, "sec-xss-payer@example.com", "Payer")
    await _register(client, "sec-xss-payee@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "50.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={"payee_email": "sec-xss-payee@example.com", "amount": "20.00", "description": "x"},
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )

    payload = "<script>alert('xss')</script>"
    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": payload},
    )
    assert response.status_code == 201
    assert response.json()["reason"] == payload
