"""Integration tests for GET /notifications and the services that write
to the Notification table as a side effect of their other work.
"""
import pytest
from httpx import AsyncClient

pytestmark = [pytest.mark.integration, pytest.mark.api]

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> str:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    return str(response.json()["access_token"])


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def test_notifications_requires_authentication(client: AsyncClient) -> None:
    response = await client.get("/api/v1/notifications")
    assert response.status_code == 401


async def test_notifications_starts_empty(client: AsyncClient) -> None:
    token = await _register(client, "no-notifications@example.com")
    response = await client.get("/api/v1/notifications", headers=_headers(token))
    assert response.status_code == 200
    assert response.json() == []


async def test_creating_an_escrow_notifies_the_payee(client: AsyncClient) -> None:
    payer_token = await _register(client, "notif-payer@example.com", "Payer")
    payee_token = await _register(client, "notif-payee@example.com", "Payee")

    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={
            "payee_email": "notif-payee@example.com",
            "amount": "100.00",
            "description": "Notification test escrow",
        },
    )

    response = await client.get("/api/v1/notifications", headers=_headers(payee_token))
    body = response.json()
    assert len(body) == 1
    assert body[0]["type"] == "escrow_created"
    assert body[0]["status"] == "pending"

    payer_response = await client.get("/api/v1/notifications", headers=_headers(payer_token))
    assert payer_response.json() == []  # only the payee is notified, not the payer


async def test_funding_an_escrow_notifies_the_payee(client: AsyncClient) -> None:
    payer_token = await _register(client, "notif-payer2@example.com", "Payer")
    payee_token = await _register(client, "notif-payee2@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer_token), json={"amount": "500.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={
            "payee_email": "notif-payee2@example.com",
            "amount": "200.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer_token), json={}
    )

    response = await client.get("/api/v1/notifications", headers=_headers(payee_token))
    types = [n["type"] for n in response.json()]
    assert "escrow_created" in types
    assert "escrow_funded" in types


async def test_cancelling_an_escrow_notifies_the_other_party(client: AsyncClient) -> None:
    payer_token = await _register(client, "notif-payer3@example.com", "Payer")
    payee_token = await _register(client, "notif-payee3@example.com", "Payee")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={
            "payee_email": "notif-payee3@example.com",
            "amount": "50.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel",
        headers=_headers(payer_token),
        json={"reason": "changed my mind"},
    )

    response = await client.get("/api/v1/notifications", headers=_headers(payee_token))
    types = [n["type"] for n in response.json()]
    assert "escrow_cancelled" in types


async def test_notifications_pagination(client: AsyncClient) -> None:
    payer_token = await _register(client, "notif-payer4@example.com", "Payer")
    payee_token = await _register(client, "notif-payee4@example.com", "Payee")

    for i in range(3):
        await client.post(
            "/api/v1/escrows",
            headers=_headers(payer_token),
            json={
                "payee_email": "notif-payee4@example.com",
                "amount": f"{10 + i}.00",
                "description": f"escrow {i}",
            },
        )

    response = await client.get(
        "/api/v1/notifications", headers=_headers(payee_token), params={"limit": 2}
    )
    assert len(response.json()) == 2
