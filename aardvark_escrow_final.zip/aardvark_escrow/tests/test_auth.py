"""Integration tests for the authentication flow.

These run against a real Postgres (see README: `docker compose up -d
postgres redis` first, with migrations applied) rather than a mock — an
auth system is fundamentally about persistence and crypto, so a test that
doesn't touch either would give false confidence.
"""
import pytest
from httpx import AsyncClient

pytestmark = [pytest.mark.integration, pytest.mark.api, pytest.mark.auth]

DEFAULT_EMAIL = "alice@example.com"
DEFAULT_PASSWORD = "correct-horse-42"
DEFAULT_NAME = "Alice Payer"


async def _register(
    client: AsyncClient,
    email: str = DEFAULT_EMAIL,
    password: str = DEFAULT_PASSWORD,
    full_name: str = DEFAULT_NAME,
):
    return await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "full_name": full_name},
    )


async def test_register_returns_tokens_and_user(client: AsyncClient) -> None:
    response = await _register(client)
    assert response.status_code == 201

    body = response.json()
    assert body["token_type"] == "bearer"
    assert body["expires_in"] > 0
    assert body["user"]["email"] == DEFAULT_EMAIL
    assert "hashed_password" not in body["user"]


async def test_register_rejects_duplicate_email(client: AsyncClient) -> None:
    await _register(client)
    response = await _register(client)
    assert response.status_code == 409


async def test_register_rejects_weak_password(client: AsyncClient) -> None:
    response = await _register(client, password="1234567890")
    assert response.status_code == 422


async def test_login_with_correct_credentials(client: AsyncClient) -> None:
    await _register(client)
    response = await client.post(
        "/api/v1/auth/login",
        json={"email": DEFAULT_EMAIL, "password": DEFAULT_PASSWORD},
    )
    assert response.status_code == 200
    assert "access_token" in response.json()


async def test_login_with_wrong_password_is_rejected(client: AsyncClient) -> None:
    await _register(client)
    response = await client.post(
        "/api/v1/auth/login",
        json={"email": DEFAULT_EMAIL, "password": "totally-wrong-password"},
    )
    assert response.status_code == 401


async def test_login_with_unknown_email_gives_same_error_as_wrong_password(
    client: AsyncClient,
) -> None:
    response = await client.post(
        "/api/v1/auth/login",
        json={"email": "nobody@example.com", "password": "whatever-12345"},
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Incorrect email or password"


async def test_protected_endpoint_requires_credentials(client: AsyncClient) -> None:
    response = await client.get("/api/v1/users/me")
    assert response.status_code == 401


async def test_protected_endpoint_rejects_garbage_token(client: AsyncClient) -> None:
    response = await client.get(
        "/api/v1/users/me", headers={"Authorization": "Bearer not-a-real-token"}
    )
    assert response.status_code == 401


async def test_protected_endpoint_returns_current_user(client: AsyncClient) -> None:
    register_response = await _register(client)
    access_token = register_response.json()["access_token"]

    response = await client.get(
        "/api/v1/users/me", headers={"Authorization": f"Bearer {access_token}"}
    )
    assert response.status_code == 200
    assert response.json()["email"] == DEFAULT_EMAIL


async def test_refresh_issues_a_new_working_access_token(client: AsyncClient) -> None:
    register_response = await _register(client)
    old_refresh_token = register_response.json()["refresh_token"]

    refresh_response = await client.post(
        "/api/v1/auth/refresh", json={"refresh_token": old_refresh_token}
    )
    assert refresh_response.status_code == 200
    new_tokens = refresh_response.json()
    assert new_tokens["refresh_token"] != old_refresh_token

    me_response = await client.get(
        "/api/v1/users/me",
        headers={"Authorization": f"Bearer {new_tokens['access_token']}"},
    )
    assert me_response.status_code == 200


async def test_refresh_token_rotation_rejects_reuse(client: AsyncClient) -> None:
    register_response = await _register(client)
    old_refresh_token = register_response.json()["refresh_token"]

    first_use = await client.post(
        "/api/v1/auth/refresh", json={"refresh_token": old_refresh_token}
    )
    assert first_use.status_code == 200

    reuse_attempt = await client.post(
        "/api/v1/auth/refresh", json={"refresh_token": old_refresh_token}
    )
    assert reuse_attempt.status_code == 401


async def test_refresh_rejects_garbage_token(client: AsyncClient) -> None:
    response = await client.post(
        "/api/v1/auth/refresh", json={"refresh_token": "not-a-real-refresh-token"}
    )
    assert response.status_code == 401


async def test_logout_revokes_refresh_token(client: AsyncClient) -> None:
    register_response = await _register(client)
    refresh_token = register_response.json()["refresh_token"]

    logout_response = await client.post(
        "/api/v1/auth/logout", json={"refresh_token": refresh_token}
    )
    assert logout_response.status_code == 204

    refresh_attempt = await client.post(
        "/api/v1/auth/refresh", json={"refresh_token": refresh_token}
    )
    assert refresh_attempt.status_code == 401


async def test_logout_is_idempotent(client: AsyncClient) -> None:
    register_response = await _register(client)
    refresh_token = register_response.json()["refresh_token"]

    first_logout = await client.post(
        "/api/v1/auth/logout", json={"refresh_token": refresh_token}
    )
    second_logout = await client.post(
        "/api/v1/auth/logout", json={"refresh_token": refresh_token}
    )
    assert first_logout.status_code == 204
    assert second_logout.status_code == 204
