"""Test data factories, using factory_boy + Faker.

These *build* (never persist) domain entities with realistic fake data —
plain `factory.Factory`, not `SQLAlchemyModelFactory`. factory_boy's
SQLAlchemy integration persists synchronously as part of building the
object, which doesn't compose with this project's async session; rather
than fight that, factories here only construct Python objects (exactly
what `User(...)`/`Escrow(...)` calls elsewhere in this suite already do
by hand). Tests remain responsible for `session.add(...)` +
`await session.commit()` themselves, same as everywhere else.

Not a retrofit: the 180+ tests written across Phases 3-9 already work
and already pass — rewriting them to use these factories would be
churn on working code for marginal benefit. These exist for Phase 10's
own new tests and as the foundation for tests going forward.
"""
from decimal import Decimal

import factory
from factory import LazyFunction
from faker import Faker as _Faker

from app.domain.entities.enums import EscrowStatus, UserRole
from app.domain.entities.escrow import Escrow
from app.domain.entities.user import User
from app.security.password import hash_password

_faker = _Faker()


class UserFactory(factory.Factory):
    class Meta:
        model = User

    email = factory.Sequence(lambda n: f"factory-user-{n}-{_faker.uuid4()}@example.com")
    full_name = factory.LazyFunction(_faker.name)
    hashed_password = LazyFunction(lambda: hash_password("correct-horse-42"))
    role = UserRole.USER


class AdminUserFactory(UserFactory):
    role = UserRole.ADMIN


class EscrowFactory(factory.Factory):
    class Meta:
        model = Escrow

    # payer_id / payee_id have no sensible default — a real Escrow always
    # belongs to two real, already-persisted users, so callers must
    # supply both explicitly: EscrowFactory(payer_id=..., payee_id=...).
    amount = factory.LazyFunction(lambda: Decimal(_faker.random_int(min=10, max=5000)))
    currency = "GBP"
    description = factory.LazyFunction(lambda: _faker.sentence(nb_words=6))
    status = EscrowStatus.CREATED
