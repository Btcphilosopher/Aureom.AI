"""Tests the Redis-backed rate limiter's actual counting logic directly.

The dependency is disabled under ENVIRONMENT=test (see
app/middleware/rate_limit.py) so the rest of the test suite isn't flaky
against real request volume — this test monkeypatches that gate off so
the underlying Redis increment/expire/reject logic still gets exercised
against a real Redis instance.
"""
import uuid

import pytest

from app.core.config import settings
from app.core.exceptions import RateLimitExceededError
from app.core.redis import get_redis
from app.middleware.rate_limit import rate_limit

pytestmark = [pytest.mark.integration, pytest.mark.security]

class _FakeClient:
    def __init__(self, host: str) -> None:
        self.host = host


class _FakeRequest:
    def __init__(self, host: str) -> None:
        self.client = _FakeClient(host)


@pytest.fixture(autouse=True)
def _enable_rate_limiting(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")


@pytest.fixture(autouse=True)
async def _cleanup_redis_keys():
    yield
    redis = get_redis()
    async for key in redis.scan_iter("ratelimit:test-*"):
        await redis.delete(key)


async def test_rate_limit_allows_requests_under_the_limit() -> None:
    bucket = f"test-{uuid.uuid4()}"
    check = rate_limit(bucket, limit=3, window_seconds=60)
    request = _FakeRequest(host="203.0.113.10")

    for _ in range(3):
        await check(request)  # should not raise


async def test_rate_limit_rejects_requests_over_the_limit() -> None:
    bucket = f"test-{uuid.uuid4()}"
    check = rate_limit(bucket, limit=2, window_seconds=60)
    request = _FakeRequest(host="203.0.113.11")

    await check(request)
    await check(request)
    with pytest.raises(RateLimitExceededError):
        await check(request)


async def test_rate_limit_is_isolated_per_client_ip() -> None:
    bucket = f"test-{uuid.uuid4()}"
    check = rate_limit(bucket, limit=1, window_seconds=60)

    await check(_FakeRequest(host="203.0.113.12"))
    # A different IP against the same bucket must not be blocked by the
    # first IP's usage.
    await check(_FakeRequest(host="203.0.113.13"))


async def test_rate_limit_disabled_under_test_environment() -> None:
    bucket = f"test-{uuid.uuid4()}"
    check = rate_limit(bucket, limit=1, window_seconds=60)
    request = _FakeRequest(host="203.0.113.14")

    settings.ENVIRONMENT = "test"
    try:
        for _ in range(5):
            await check(request)  # should never raise while gated off
    finally:
        settings.ENVIRONMENT = "development"
