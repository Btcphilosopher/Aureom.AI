"""Shared pytest fixtures.

Phase 10 expands this with factory-boy factories for every entity. For
now, `client` gives tests an ASGI test client, `db_session` gives direct
database access for setup/verification, and the autouse
`_clean_database` fixture truncates every table after each test so tests
never leak state into one another.

These fixtures talk to a real Postgres (see README) rather than mocking
the database — appropriate for a system whose entire value proposition is
transactional correctness.
"""
from collections.abc import AsyncGenerator

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

import app.domain.entities  # noqa: F401 - registers all models on Base.metadata
from app.database.base import Base
from app.database.session import AsyncSessionLocal
from app.main import app


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient, None]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        yield session


@pytest.fixture(autouse=True)
async def _clean_database() -> AsyncGenerator[None, None]:
    yield
    async with AsyncSessionLocal() as session:
        for table in reversed(Base.metadata.sorted_tables):
            await session.execute(table.delete())
        await session.commit()
