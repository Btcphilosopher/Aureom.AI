"""Database-layer tests: migrations and constraints.

These verify the persistence layer directly, independent of any service
logic sitting on top of it — the point is to catch a broken migration or
a loosened constraint even if every application-level test still passes
(the way Phase 2's `key_prefix` column-width bug and Phase 4's
`populate_existing` staleness bug were both first found by *manual*
verification against real Postgres, not by application tests; this file
makes that kind of check a permanent, automated part of the suite
instead of a one-off script).
"""
import uuid
from decimal import Decimal

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.domain.entities.enums import WalletTransactionType
from app.domain.entities.escrow import Escrow
from app.domain.entities.user import User
from app.domain.entities.wallet import Wallet, WalletTransaction

pytestmark = [pytest.mark.database]


# --------------------------------------------------------------- migrations


@pytest.mark.integration
def test_migration_upgrade_downgrade_upgrade_cycle() -> None:
    """Runs a full upgrade -> downgrade -> upgrade cycle against a
    throwaway database (never the shared test database other tests
    depend on), proving the migration is reversible and re-appliable —
    not just that `alembic upgrade head` works once from empty.

    Deliberately a *synchronous* test function, not `async def`: Alembic
    itself calls `asyncio.run(...)` internally (see `migrations/env.py`),
    which raises if it's invoked from inside an already-running event
    loop — exactly the loop pytest-asyncio provides to every `async def`
    test in this suite. Staying synchronous here (using the sync engine
    for admin operations) sidesteps that entirely, the same reasoning
    behind never calling a Celery task's sync wrapper directly in a test
    (`app.workers.tasks`'s module docstring).

    Needs CREATEDB on the configured Postgres role. Skips cleanly if
    that's not available rather than failing the whole suite over an
    environment permission difference — the manual verification in this
    project's history (Phase 2) remains the fallback record of this
    having been checked at least once by hand.
    """
    db_name = f"aardvark_migration_test_{uuid.uuid4().hex[:12]}"
    admin_engine = create_engine(
        settings.DATABASE_URL_SYNC.rsplit("/", 1)[0] + "/postgres",
        isolation_level="AUTOCOMMIT",
    )

    try:
        with admin_engine.connect() as conn:
            conn.execute(text(f'CREATE DATABASE "{db_name}"'))
    except Exception as exc:
        admin_engine.dispose()
        pytest.skip(f"Could not create a throwaway database for migration testing: {exc}")

    test_db_url_async = settings.DATABASE_URL.rsplit("/", 1)[0] + f"/{db_name}"
    test_db_url_sync = settings.DATABASE_URL_SYNC.rsplit("/", 1)[0] + f"/{db_name}"

    expected_tables = {
        "users", "wallets", "wallet_transactions", "escrows",
        "escrow_transactions", "escrow_events", "disputes", "evidence",
        "notifications", "audit_logs", "api_keys", "refresh_tokens",
        "alembic_version",
    }

    def _tables() -> set[str]:
        check_engine = create_engine(test_db_url_sync)
        try:
            with check_engine.connect() as conn:
                result = conn.execute(
                    text(
                        "SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = 'public'"
                    )
                )
                return {row[0] for row in result.fetchall()}
        finally:
            check_engine.dispose()

    try:
        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", test_db_url_async)

        command.upgrade(alembic_cfg, "head")
        assert expected_tables <= _tables()

        command.downgrade(alembic_cfg, "base")
        tables_after_downgrade = _tables()
        assert "users" not in tables_after_downgrade
        assert "escrows" not in tables_after_downgrade

        check_engine = create_engine(test_db_url_sync)
        try:
            with check_engine.connect() as conn:
                # Enum types must be cleaned up too, or the next CREATE
                # TYPE in a re-upgrade fails — see docs/architecture.md's
                # history for the bug this specifically guards against.
                result = conn.execute(
                    text("SELECT typname FROM pg_type WHERE typname = 'escrow_status'")
                )
                assert result.fetchone() is None
        finally:
            check_engine.dispose()

        # The real regression test: re-upgrading after a full downgrade
        # must succeed. This is exactly what broke before the enum-type
        # cleanup fix (CREATE TYPE failing on an already-existing type).
        command.upgrade(alembic_cfg, "head")
        assert expected_tables <= _tables()

    finally:
        with admin_engine.connect() as conn:
            conn.execute(
                text(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = :db_name AND pid <> pg_backend_pid()"
                ),
                {"db_name": db_name},
            )
            conn.execute(text(f'DROP DATABASE IF EXISTS "{db_name}"'))
        admin_engine.dispose()


# --------------------------------------------------------------- constraints
#
# These exercise the database's own CHECK/UNIQUE/FK constraints directly,
# bypassing the application-level validation that normally catches these
# cases first (Pydantic field validators, service-layer checks). The
# point is defense-in-depth: proving the *database* itself would still
# refuse bad data even if every layer above it had a bug, not re-testing
# the application logic that already has its own dedicated tests.


async def test_wallet_balance_cannot_go_negative(db_session: AsyncSession) -> None:
    user = User(email="db-test-1@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.flush()

    wallet = Wallet(user_id=user.id, balance=Decimal("-1.00"))
    db_session.add(wallet)
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_held_balance_cannot_exceed_balance(db_session: AsyncSession) -> None:
    user = User(email="db-test-2@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.flush()

    wallet = Wallet(user_id=user.id, balance=Decimal("10.00"), held_balance=Decimal("20.00"))
    db_session.add(wallet)
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_escrow_payer_cannot_equal_payee(db_session: AsyncSession) -> None:
    user = User(email="db-test-3@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.flush()

    escrow = Escrow(
        payer_id=user.id, payee_id=user.id, amount=Decimal("10.00"), description="x"
    )
    db_session.add(escrow)
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_escrow_amount_must_be_positive(db_session: AsyncSession) -> None:
    payer = User(email="db-test-4a@example.com", hashed_password="x", full_name="X")
    payee = User(email="db-test-4b@example.com", hashed_password="x", full_name="X")
    db_session.add_all([payer, payee])
    await db_session.flush()

    escrow = Escrow(
        payer_id=payer.id, payee_id=payee.id, amount=Decimal("0.00"), description="x"
    )
    db_session.add(escrow)
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_user_email_must_be_unique(db_session: AsyncSession) -> None:
    db_session.add(User(email="db-test-5@example.com", hashed_password="x", full_name="A"))
    await db_session.commit()

    db_session.add(User(email="db-test-5@example.com", hashed_password="x", full_name="B"))
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_only_one_wallet_per_user(db_session: AsyncSession) -> None:
    user = User(email="db-test-6@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.flush()

    db_session.add(Wallet(user_id=user.id))
    await db_session.commit()

    db_session.add(Wallet(user_id=user.id))
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_wallet_transaction_idempotency_key_must_be_unique(
    db_session: AsyncSession,
) -> None:
    user = User(email="db-test-7@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.flush()
    wallet = Wallet(user_id=user.id, balance=Decimal("100.00"))
    db_session.add(wallet)
    await db_session.flush()

    shared_key = "duplicate-key-test"
    db_session.add(
        WalletTransaction(
            wallet_id=wallet.id,
            type=WalletTransactionType.DEPOSIT,
            amount=Decimal("50.00"),
            balance_after=Decimal("150.00"),
            description="first",
            idempotency_key=shared_key,
        )
    )
    await db_session.commit()

    db_session.add(
        WalletTransaction(
            wallet_id=wallet.id,
            type=WalletTransactionType.DEPOSIT,
            amount=Decimal("50.00"),
            balance_after=Decimal("200.00"),
            description="second, same key",
            idempotency_key=shared_key,
        )
    )
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_wallet_cannot_reference_a_nonexistent_user(db_session: AsyncSession) -> None:
    db_session.add(Wallet(user_id=uuid.uuid4()))
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()


async def test_escrow_cannot_be_deleted_while_it_has_transaction_history(
    db_session: AsyncSession,
) -> None:
    """`escrow_transactions.escrow_id` is `ondelete=RESTRICT` — an escrow
    with ledger history can never be hard-deleted, protecting the audit
    trail from ever going missing underneath a transaction record.
    """
    from app.domain.entities.enums import EscrowTransactionType
    from app.domain.entities.escrow import EscrowTransaction

    payer = User(email="db-test-8a@example.com", hashed_password="x", full_name="X")
    payee = User(email="db-test-8b@example.com", hashed_password="x", full_name="X")
    db_session.add_all([payer, payee])
    await db_session.flush()

    escrow = Escrow(
        payer_id=payer.id, payee_id=payee.id, amount=Decimal("10.00"), description="x"
    )
    db_session.add(escrow)
    await db_session.flush()

    db_session.add(
        EscrowTransaction(
            escrow_id=escrow.id,
            type=EscrowTransactionType.DEPOSIT,
            amount=Decimal("10.00"),
        )
    )
    await db_session.commit()

    await db_session.delete(escrow)
    with pytest.raises(IntegrityError):
        await db_session.commit()
    await db_session.rollback()
