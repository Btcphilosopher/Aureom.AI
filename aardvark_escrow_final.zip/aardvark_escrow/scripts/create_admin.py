#!/usr/bin/env python3
"""Bootstrap an admin user.

There is deliberately no API endpoint that grants the ADMIN role — Phase
3's `UpdateUserRequest` schema doesn't even declare a `role` field, and
`tests/test_security_boundaries.py` locks that in as a security property,
not an oversight. Privilege escalation must never be self-service. This
script is the intended way to create the platform's first admin (and any
subsequent ones) — a deliberate, out-of-band action that requires shell
access to wherever the app is deployed, not a request any authenticated
user could make.

Usage:
    python scripts/create_admin.py existing-user@example.com
        Promotes an existing user to ADMIN.

    python scripts/create_admin.py new-admin@example.com --create --name "Jane Admin"
        Creates a brand new user with the ADMIN role directly. You will
        be prompted for a password (not accepted as a CLI argument, so
        it never ends up in shell history).

Run from the project root with the same .env the API itself uses:
    python scripts/create_admin.py admin@example.com --create --name "Admin"
"""
import argparse
import asyncio
import getpass
import sys
from pathlib import Path

# Running `python scripts/create_admin.py` puts scripts/ on sys.path, not
# the repo root — so `import app...` fails unless the repo root is added
# explicitly. Doing it here means the script works regardless of how
# it's invoked, without the caller needing to set PYTHONPATH themselves.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.core.config import settings
from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.domain.repositories.user_repository import SQLAlchemyUserRepository
from app.schemas.validators import validate_password_strength
from app.security.password import hash_password


async def _promote_existing(email: str) -> None:
    engine = create_async_engine(settings.DATABASE_URL)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async with session_factory() as session:
        users = SQLAlchemyUserRepository(session)
        user = await users.get_by_email(email)
        if user is None:
            print(f"No user found with email {email!r}.", file=sys.stderr)
            print("Use --create to make a brand new admin user instead.", file=sys.stderr)
            sys.exit(1)

        if user.role == UserRole.ADMIN:
            print(f"{email} is already an admin. Nothing to do.")
            return

        user.role = UserRole.ADMIN
        await session.commit()
        print(f"{email} promoted to ADMIN.")

    await engine.dispose()


async def _create_new(email: str, full_name: str, password: str) -> None:
    engine = create_async_engine(settings.DATABASE_URL)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async with session_factory() as session:
        users = SQLAlchemyUserRepository(session)
        existing = await users.get_by_email(email)
        if existing is not None:
            print(f"A user with email {email!r} already exists.", file=sys.stderr)
            print("Omit --create to promote that existing user instead.", file=sys.stderr)
            sys.exit(1)

        user = User(
            email=email.strip().lower(),
            hashed_password=hash_password(password),
            full_name=full_name,
            role=UserRole.ADMIN,
            is_verified=True,
        )
        users.add(user)
        await session.commit()
        print(f"Admin user created: {email}")

    await engine.dispose()


def _prompt_for_password() -> str:
    while True:
        password = getpass.getpass("Password for the new admin: ")
        try:
            validate_password_strength(password)
        except ValueError as exc:
            print(f"  {exc}", file=sys.stderr)
            continue
        if len(password) < 10:
            print("  Password must be at least 10 characters.", file=sys.stderr)
            continue
        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("  Passwords did not match — try again.", file=sys.stderr)
            continue
        return password


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("Usage:")[0])
    parser.add_argument("email", help="Email of the user to promote or create.")
    parser.add_argument(
        "--create",
        action="store_true",
        help="Create a brand new user with the ADMIN role, instead of promoting an existing one.",
    )
    parser.add_argument(
        "--name",
        default=None,
        help="Full name for the new user. Required with --create.",
    )
    args = parser.parse_args()

    if args.create:
        if not args.name:
            parser.error("--name is required when using --create")
        password = _prompt_for_password()
        asyncio.run(_create_new(args.email, args.name, password))
    else:
        asyncio.run(_promote_existing(args.email))


if __name__ == "__main__":
    main()
