#!/usr/bin/env bash
set -euo pipefail

echo "[entrypoint] waiting for postgres..."
until python -c "
import asyncio, sys
from sqlalchemy.ext.asyncio import create_async_engine
from app.core.config import settings

async def check():
    engine = create_async_engine(settings.DATABASE_URL)
    async with engine.connect():
        pass
    await engine.dispose()

try:
    asyncio.run(check())
except Exception as exc:
    print(f'not ready: {exc}', file=sys.stderr)
    sys.exit(1)
"; do
  sleep 1
done
echo "[entrypoint] postgres is ready"

echo "[entrypoint] running migrations..."
alembic upgrade head

echo "[entrypoint] starting: $*"
exec "$@"
