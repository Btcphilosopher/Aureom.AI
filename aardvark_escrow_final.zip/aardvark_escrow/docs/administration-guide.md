# Administration Guide

For platform operators/admins — day-to-day operation of an already-
deployed instance. For getting an instance running in the first place,
see [deployment-guide.md](deployment-guide.md).

## Creating your first admin

There is no self-serve way to become an admin — no request body,
anywhere in this API, ever accepts a `role` field. This is deliberate
(`tests/test_security_boundaries.py` locks it in as a security property,
not a gap), which means bootstrapping the first admin requires shell
access to the deployment:

```bash
# Promote an existing registered user:
python scripts/create_admin.py existing-user@example.com

# Or create a brand new admin user directly (prompts for a password
# interactively — never pass it as a CLI argument, which would leak it
# into shell history):
python scripts/create_admin.py new-admin@example.com --create --name "Jane Admin"
```

Both paths are idempotent-safe: promoting an already-admin user is a
no-op; `--create` against an existing email fails cleanly rather than
silently overwriting anything.

## What admins can do

| Action | Endpoint | Notes |
|---|---|---|
| List recent audit log entries | `GET /audit` | Paginated (`limit`/`offset`, max 500). |
| Export audit log as a file | `GET /reports/audit` | CSV (default) or PDF, optional `start_date`/`end_date`. |
| See what other admins have been doing | `GET /reports/operator-activity` | Filters to actions taken by admin-role users specifically — a join to `users.role`, checked at *current* role, not role-at-time-of-action. |
| Platform financial summary | `GET /reports/financial-summary` | User count, escrow counts by status, total released volume, total wallet balance across all users. PDF only. |
| Resolve a dispute | `POST /disputes/{id}/resolve` | Three outcomes — see below. |

Nothing else is admin-gated. Regular escrow/wallet/dispute operations
(create, fund, approve, cancel, raise a dispute, submit evidence) are
scoped to the escrow's payer/payee, same as any user — admins don't get
a back door into other users' day-to-day operations, only the oversight
actions above plus dispute resolution.

## Resolving a dispute

```
POST /disputes/{dispute_id}/resolve
{
  "resolution": "release_to_payee" | "refund_to_payer" | "split",
  "resolution_notes": "optional free text",
  "release_amount": "required only when resolution is 'split'"
}
```

- **`release_to_payee`** — the full escrowed amount moves to the payee.
- **`refund_to_payer`** — the hold is released; since funding never
  actually debits the payer's spendable balance (see
  [architecture.md's money model](architecture.md#dispute-resolution)),
  this is a same-instant, no-transfer operation.
- **`split`** — `release_amount` (strictly between 0 and the full escrow
  amount — use one of the other two resolutions for the full-amount
  cases) goes to the payee; the remainder simply stays with the payer.
  Both parties are notified with their respective amounts.

Before resolving, review the dispute's context. There is no dedicated
`GET /disputes/{id}` endpoint, and `GET /escrows/{id}`'s response schema
(`EscrowPublic`) does not include dispute details either.
`GET /reports/escrows/{id}` (the escrow history PDF) includes a Disputes
section with status, reason, resolution, and resolved-at timestamp for
every dispute on that escrow — but **not** the evidence submissions
themselves (description, file URL/hash from `POST /disputes/{id}/evidence`).
There is currently no endpoint or report that surfaces evidence content
at all; querying it directly (`SELECT * FROM evidence WHERE dispute_id = '<id>'`)
is the only way to review submitted evidence before resolving a dispute.
Worth treating as a gap to close before this matters for a real dispute
with meaningful evidence attached, not a permanent limitation.

A dispute can only be resolved once — `DisputeService.resolve_dispute`
rejects an already-resolved dispute with a 422, and the underlying escrow
transition is guarded by the state machine independently as a second
line of defence.

## Reading the financial summary report

`GET /reports/financial-summary` is intentionally a snapshot, not a
time-series — it reflects live query results at the moment of the
request, not a stored historical record. There is currently no persisted
history of past summaries; if you need trend data, this endpoint
computes what `app/workers/tasks/statistics.py`'s Celery task (Phase 8)
also computes and logs (structured, via `structlog`) once daily at 01:00
UTC — cross-reference your log aggregator for a historical view rather
than expecting the API itself to provide one.

## Wallet reconciliation

Runs automatically once daily (02:00 UTC, `reconciliation.daily_wallet_reconciliation`
in `app/workers/celery_app.py`'s Beat schedule). It does not need manual
triggering under normal operation, but if you suspect drift after an
incident (a failed deployment mid-transaction, manual database
intervention, etc.), you can run it on demand:

```bash
python -c "
import asyncio
from app.workers.tasks.reconciliation import _reconcile_wallets
print(asyncio.run(_reconcile_wallets()))
"
```

Any mismatch it finds is logged and written as a
`WALLET_RECONCILIATION_MISMATCH` audit log entry — see
[security-guide.md](security-guide.md#monitoring-the-audit-trail) for
what to do if one appears. The task never attempts to auto-correct a
mismatch; that's a deliberate design choice (see
`app/workers/tasks/reconciliation.py`'s module docstring) — a
reconciliation job's role is to surface a problem for a human to
investigate, not to guess at the fix.

## Revoking access

There's no dedicated "suspend user" or "revoke session" endpoint yet.
Until one exists, both are direct database operations — see
[security-guide.md](security-guide.md#authentication-model-operationally)
for the exact commands to force-expire a user's sessions or revoke a
leaked API key.
