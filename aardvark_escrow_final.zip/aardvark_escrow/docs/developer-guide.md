# Developer Guide

Practical, task-oriented notes for working in this codebase. For *why*
it's built this way, see [architecture.md](architecture.md); this
document is about *how* to actually get things done in it.

## Setup

```bash
git clone <repo> && cd aardvark_escrow
cp .env.example .env
docker compose up --build
```

Or without Docker — see the [README](../README.md#local-development-without-docker).
Either way, `docker compose up -d postgres redis` plus a working `.env`
is the minimum needed before running tests, since the suite runs against
real Postgres/Redis rather than mocks (see
[architecture.md's Testing section](architecture.md#testing) for why).

## Project layout, as a mental model

```
app/api/v1/endpoints/   HTTP layer — request parsing, response shaping. No business logic.
app/schemas/             Pydantic request/response models. API contract, separate from persistence.
app/domain/services/     Business logic. Depends on repository interfaces via UnitOfWork, never on FastAPI.
app/domain/entities/     SQLAlchemy models. The persistence contract.
app/domain/repositories/ Persistence interfaces (Protocol) + SQLAlchemy implementations.
app/security/            Auth primitives: JWT, password hashing, API keys, get_current_user/require_role.
app/workers/tasks/       Celery tasks — sync wrapper + async impl, see that package's docstring.
app/audit/               Report generation (PDF/CSV) on top of the audit trail.
```

Dependencies point inward only: `api` → `services` → `entities` /
`repositories`. A service never imports from `api`; an entity never
imports from `services`. If you find yourself wanting to import FastAPI
inside `app/domain/`, that's a sign the logic belongs in the API layer
instead.

## Adding a new endpoint

Concretely, adding `POST /widgets`:

1. **Entity** (if new) — `app/domain/entities/widget.py`, inheriting
   `UUIDPrimaryKeyMixin` + (`TimestampMixin` or `CreatedAtMixin` — mutable
   vs. append-only, see [er-diagram.md](er-diagram.md)). Register it in
   `app/domain/entities/__init__.py` so Alembic autogenerate sees it.
2. **Migration** — `alembic revision --autogenerate -m "add widgets table"`,
   then **read the generated file** before trusting it: check `downgrade()`
   actually drops any new Postgres ENUM types (autogenerate doesn't do
   this automatically — see the "async-ORM gotchas" note in
   [architecture.md](architecture.md#financial-integrity) for the bug
   this caught in Phase 4).
3. **Repository** — `app/domain/repositories/widget_repository.py`: a
   `Protocol` (the interface) + `SQLAlchemyWidgetRepository(SQLAlchemyRepository[Widget])`
   (the implementation). Only add methods beyond the base
   `get_by_id`/`add`/`delete` that you actually need — see
   `app/domain/repositories/base.py`.
4. **Register on `UnitOfWork`** — add `self.widgets = SQLAlchemyWidgetRepository(session)`
   in `app/database/unit_of_work.py`.
5. **Service** — `app/domain/services/widget_service.py`. Each method
   opens `async with UnitOfWork(self._session) as uow:`, does its work,
   calls `await uow.commit()` explicitly (there's no implicit commit —
   see `UnitOfWork`'s docstring for why). If the operation moves money or
   needs row-level locking, use `get_for_update` with
   `execution_options(populate_existing=True)` — **this is not optional
   decoration**, see the identity-map staleness bug documented in
   `WalletRepository.get_for_update`'s docstring.
6. **Schema** — `app/schemas/widget.py`: a `CreateWidgetRequest` and a
   `WidgetPublic(ORMModel)`. Never reuse the entity as the response model
   directly — the schema boundary is what keeps `hashed_password`-style
   fields from ever being one accidental field addition away from
   leaking.
7. **Endpoint** — `app/api/v1/endpoints/widgets.py`: parse the request,
   call the service, return the schema. Authorization checks belong in
   the *service* (so they apply no matter what calls it), not the
   endpoint — see how `EscrowService.get_escrow` encodes "payer, payee,
   or 404" once, and every caller (including the Phase 9 report
   endpoints) reuses it rather than re-deriving the rule.
8. **Wire the router** — add the import + `include_router` call in
   `app/api/v1/router.py`.
9. **Tests** — mark them (`pytestmark = [pytest.mark.integration, pytest.mark.api]`,
   see [architecture.md's Testing section](architecture.md#testing) for
   the full marker taxonomy), and actually hit the real database — this
   codebase's tests don't mock Postgres.

## Money-moving code, specifically

If your change touches a `Wallet.balance`/`held_balance`:

- **Validate state transitions before mutating balances**, not after —
  see `EscrowTransactionEngine`'s module docstring for the real bug this
  ordering fixed (refunding an already-released escrow tried to send
  `held_balance` negative before the illegal-transition check ever ran).
- **Lock rows you're about to mutate**, and if you're locking two wallets
  at once, lock them in a **fixed global order** (sorted by wallet ID,
  not by semantic role) to avoid deadlocking against a concurrent
  operation locking the same two wallets in the opposite order — see
  `EscrowTransactionEngine._lock_two_wallets_in_order`.
- **Write a concurrency test, not just a happy-path test.** The
  `populate_existing=True` staleness bug and the lock-ordering deadlock
  risk were both real bugs caught specifically by tests that fired
  genuinely concurrent requests — `asyncio.gather` in-process, and
  separately, real parallel `curl` processes via `xargs -P`. A sequential
  test of the same code would have passed either way.

## Style conventions actually enforced

- `ruff check app tests migrations main.py scripts` — zero tolerance,
  part of the definition of "done" for every phase.
- `mypy app --no-error-summary` — strict mode. Third-party libraries
  without stubs (Celery's `@task` decorator, `redis.asyncio.from_url`)
  get *scoped* overrides in `pyproject.toml`, never a blanket
  `# type: ignore` at the call site — see the comments next to those
  overrides for the reasoning.
- Docstrings explain **why**, not just what — a one-line summary plus,
  where a decision was non-obvious, the reasoning and (if applicable) the
  bug that reasoning was learned from. Skim any file in `app/domain/services/`
  for the pattern.
- `pyproject.toml`'s `[tool.coverage.report] fail_under = 90` is enforced
  by `pytest --cov=app` failing the run below that threshold. The suite
  currently sits around 96.5%; don't let a change drop it.

## Common pitfalls this codebase has already hit once

Worth knowing before you rediscover them:

1. **SQLAlchemy's identity map returns stale objects**, even under a
   `SELECT ... FOR UPDATE` that genuinely locked and waited, unless you
   pass `execution_options(populate_existing=True)`. See
   `WalletRepository.get_for_update`'s docstring.
2. **`onupdate=func.now()` columns get left expired** after a second
   flush within the same session (e.g. a state-machine transition
   following an initial insert), causing `MissingGreenlet` when a
   response schema later reads them. Fixed via `eager_defaults=True` on
   `TimestampMixin`/`CreatedAtMixin` — don't remove it.
3. **Alembic's autogenerated `downgrade()` doesn't drop Postgres ENUM
   types.** A downgrade-then-upgrade cycle will fail with "type already
   exists" unless the migration explicitly drops them. `tests/test_database.py`
   regression-tests this now; check it still passes after any migration change.
4. **A caller-configured Alembic URL can get silently overwritten.**
   `migrations/env.py` only falls back to `settings.DATABASE_URL` if the
   caller hasn't already set a real one — don't remove that guard, or a
   test/script pointing migrations at a different database will silently
   run against the real one instead.
5. **`asyncio.run()` cannot be called from a running event loop.** Celery
   tasks and Alembic's `env.py` both call it internally — never call a
   Celery task's sync wrapper, or `alembic.command.upgrade/downgrade`,
   from inside an `async def` test. Use the `_impl` async function
   directly, or make the test a plain sync `def` (see
   `tests/test_database.py`'s migration test for the latter pattern).
