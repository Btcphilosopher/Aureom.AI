# Security Guide

This is an operator-facing complement to
[architecture.md's Security Model](architecture.md#security-model), which
covers *how* the mechanisms are built. This document covers *running*
them: what to configure, what to watch, and what to do when something
goes wrong.

## Before you deploy

- **`JWT_SECRET_KEY` must be a real secret.** Generate one with
  `openssl rand -hex 32`. PyJWT itself will warn
  (`InsecureKeyLengthWarning`) if the key is under 32 bytes — treat that
  warning as a hard blocker, not a suggestion. Rotating this key
  invalidates every currently-issued access token immediately (they're
  self-contained JWTs — there's no server-side revocation list for
  access tokens by design, only for refresh tokens); plan a rotation for
  a maintenance window, not a live incident response.
- **Never set `ENVIRONMENT=test` outside the test suite.** It disables
  rate limiting entirely (`app/middleware/rate_limit.py`) — this exists
  so the test suite's rapid successive requests don't trip the limiter,
  not as a deployment mode.
- **Restrict `CORS_ORIGINS`** to your actual frontend origin(s). The
  default in `.env.example` is `localhost:3000` for local development
  only.

## Authentication model, operationally

- Access tokens are short-lived (15 min default) and stateless — nothing
  to revoke server-side if one leaks, beyond waiting for it to expire.
- Refresh tokens are opaque, hashed at rest, and **rotate on every use** —
  a refresh token can only ever be redeemed once. If a stolen refresh
  token is used by an attacker, the legitimate user's next refresh
  attempt will fail (the token they're holding was already invalidated
  by the attacker's use), which is itself a detectable signal: an
  unexpected refresh failure for an active user is worth investigating,
  not just retrying silently.
- To force a user out of every active session (e.g. suspected account
  compromise), revoke their refresh tokens directly —
  `RefreshTokenRepository` has no API-exposed "log out everywhere"
  endpoint yet, so this currently means an operator action:
  `UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = '<id>' AND revoked_at IS NULL;`
  Their existing access token remains valid until it naturally expires
  (at most 15 minutes) — full effect only completes once it does.
- API keys follow the same hash-at-rest pattern as refresh tokens
  (`app/security/api_keys.py`). There is currently no API-exposed
  create/list/revoke endpoint for them — see
  `app/security/api_keys.py`'s module docstring for why that was
  deferred, and revoke a compromised key directly:
  `UPDATE api_keys SET status = 'REVOKED', revoked_at = now() WHERE id = '<id>';`

## Monitoring the audit trail

Every security- and money-relevant action writes an immutable
`AuditLog` row (append-only — there is genuinely no update or delete
path anywhere in this codebase for that table, not just a convention).
Worth watching in production, either via `GET /audit` (admin-only) or
`GET /reports/audit`/`GET /reports/operator-activity` for bulk export:

- Repeated `user.login_failed` for the same actor/IP — credential
  stuffing or brute force (the rate limiter on `/auth/login`, 10/min,
  slows this but doesn't eliminate the value of watching for it).
- `wallet.reconciliation_mismatch` entries — written by the Phase 8
  daily reconciliation task whenever a wallet's `balance` or
  `held_balance` doesn't match what the ledger/live escrow state says it
  should. This should never fire in a healthy system; treat any
  occurrence as an incident, not noise (see
  `architecture.md`'s Background Workers section for exactly what it
  checks and why).
- `escrow.cancelled` entries with `extra_data.reason == "expired"` — the
  Phase 8 expiry-detection worker auto-cancelling unfunded escrows past
  their deadline. Expected in normal operation, but a sudden spike could
  indicate a payer-side integration issue worth investigating.
- `dispute.resolved` entries — every dispute resolution is admin-
  attributed (`resolved_by_id`); `GET /reports/operator-activity` filters
  specifically to admin-role actors for exactly this kind of oversight.

## Threat model notes

- **CSRF**: not implemented, deliberately. This API is Bearer-token
  authenticated (JWT in an `Authorization` header, or `X-API-Key`) —
  never a cookie a browser would attach automatically — so there's no
  ambient credential for a forged cross-site request to ride on. If you
  build a frontend that stores the access token in a cookie instead of
  application memory/localStorage, this assumption no longer holds and
  CSRF protection would need to be added.
- **SQL injection**: every query in this codebase goes through
  SQLAlchemy's parameterized query construction — there is no raw string
  interpolation into SQL anywhere in `app/`. `tests/test_security_boundaries.py`
  demonstrates this directly against several endpoints rather than just
  asserting it by architecture.
- **IDOR (insecure direct object reference)**: every resource-scoped
  endpoint checks the caller is a party to the resource (or an admin,
  where the resource type has an admin-relevant flow — disputes, mainly)
  before returning anything, including a 404 rather than a 403 for
  non-parties so a resource's mere existence isn't leaked. Swept
  systematically in `tests/test_security_boundaries.py` across escrows,
  disputes, wallets, and reports.
- **Mass assignment**: request schemas declare only the fields a client
  should be able to set — `UpdateUserRequest` has no `role` field at all,
  for instance, so there's no way to set it via that endpoint regardless
  of what a request body contains. This is enforced by the schema's
  *absence* of the field, not by filtering it out after the fact — a
  stronger guarantee, since a future field addition elsewhere can't
  accidentally reopen it.

## Dependency hygiene

`requirements.txt`/`requirements-dev.txt` pin minimum versions
(`>=`), not exact ones — appropriate for an actively-developed project,
but means a production deployment should pin exact versions (a lockfile
or `pip freeze` output) for reproducible builds, and should run a
vulnerability scan (`pip-audit` or equivalent) against those pinned
versions as part of CI, which isn't currently configured in this
repository.
