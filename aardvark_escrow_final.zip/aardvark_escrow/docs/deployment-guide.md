# Deployment Guide

## Services

`docker-compose.yml` defines five services:

| Service    | What it runs | Depends on |
|------------|---------------|------------|
| `postgres` | PostgreSQL 16 | — |
| `redis`    | Redis 7, used as both the rate-limiter store and the Celery broker/result backend | — |
| `api`      | `uvicorn app.main:app`, fronted by `scripts/entrypoint.sh` (waits for Postgres, then runs `alembic upgrade head` before starting) | postgres, redis |
| `worker`   | `celery -A app.workers.celery_app worker` — runs the four Phase 8 tasks | postgres, redis |
| `beat`     | `celery -A app.workers.celery_app beat` — triggers those tasks on their schedule | postgres, redis |

```bash
docker compose up --build
```

`api` and `worker` share the same image (`docker/api.Dockerfile` and
`docker/worker.Dockerfile` respectively); `beat` reuses the worker image
with its `command:` overridden. Only `api` runs migrations automatically
on startup — `worker` and `beat` assume the schema is already current,
so in a multi-instance deployment, exactly one process should own
running `alembic upgrade head` (typically as a release/init step ahead
of starting any of the three, rather than relying on `api`'s own
entrypoint racing against multiple replicas).

## Environment variables

Everything is centralized in `app/core/config.py`'s `Settings` class —
this table is a human-readable index of it, not a separate source of
truth. Copy `.env.example` and fill it in; nothing here has a
production-safe default baked into the image.

| Variable | Purpose | Notes |
|---|---|---|
| `ENVIRONMENT` | `development` \| `test` \| `production` | `test` disables rate limiting (see `app/middleware/rate_limit.py`) — **never set this in a real deployment**. `production` enables HSTS response headers. |
| `DATABASE_URL` | Async Postgres connection string | `postgresql+asyncpg://...` — used by the running application. |
| `DATABASE_URL_SYNC` | Sync Postgres connection string | `postgresql+psycopg2://...` — used by Alembic and `scripts/create_admin.py`. Same database, different driver. |
| `DATABASE_POOL_SIZE`, `DATABASE_MAX_OVERFLOW` | Connection pool sizing | Defaults (10/20) are conservative; size to your expected concurrent request volume. |
| `REDIS_URL` | Rate limiter + general Redis use | |
| `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND` | Celery's Redis DBs | Deliberately separate Redis *logical databases* (`/1`, `/2`) from the rate limiter's (`/0`) — see `.env.example`. |
| `JWT_SECRET_KEY` | Signs access tokens | **Generate with `openssl rand -hex 32`.** A short or default key triggers `InsecureKeyLengthWarning` from PyJWT — treat that warning as a deployment blocker, not noise. |
| `JWT_ALGORITHM` | `HS256` | |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Access token lifetime | Default 15. Short-lived by design — the refresh token, not this, is what should be long-lived. |
| `REFRESH_TOKEN_EXPIRE_DAYS` | Refresh token lifetime | Default 30. |
| `CORS_ORIGINS` | Allowed origins, JSON array | Restrict to your actual frontend origin(s) in production. |
| `RATE_LIMIT_PER_MINUTE` | General rate limit config | Per-endpoint limits (register: 5/min, login: 10/min, refresh: 20/min) are hardcoded at the call site in `app/api/v1/endpoints/auth.py`, not driven by this value — see `app/middleware/rate_limit.py`. |
| `IDEMPOTENCY_KEY_TTL_SECONDS` | Reserved | Not yet consumed by any code path — wallet/escrow idempotency currently relies on the database's own unique constraint, not a Redis TTL (see `architecture.md`'s Financial Integrity section). |
| `LOG_LEVEL` | stdlib logging level | Structured JSON logs in `production`, human-readable console output otherwise — see `app/core/logging.py`. |

## First deploy checklist

1. Generate a real `JWT_SECRET_KEY` (`openssl rand -hex 32`) — never reuse
   the `.env.example` placeholder or any value that's appeared in this
   repository's history.
2. Set `ENVIRONMENT=production`.
3. Set `CORS_ORIGINS` to your actual frontend origin(s), not `*` and not
   `localhost`.
4. Run migrations before traffic reaches the API:
   `alembic upgrade head` (or let `api`'s entrypoint do it on first boot,
   understanding the multi-replica caveat above).
5. Start `worker` and `beat` as long-running processes alongside `api` —
   without them, notifications never get delivered, expired escrows are
   never auto-cancelled, and reconciliation/statistics never run. The API
   itself will function without them; the platform's operational
   guarantees won't.
6. Create your first admin: `python scripts/create_admin.py <email> --create --name "..."`
   (see [administration-guide.md](administration-guide.md)) — there is no
   API path to do this, deliberately.
7. Confirm `GET /api/v1/health/ready` actually checks database
   connectivity (it does — see `app/api/v1/endpoints/health.py`) and wire
   your orchestrator's readiness probe to it, not `/health` (a plain
   liveness check that doesn't touch the database at all).
8. Point real email delivery at `app/workers/email.py`'s `EmailSender`
   protocol before relying on notification delivery — the shipped
   `LoggingEmailSender` only logs what *would* be sent (see
   `architecture.md`'s Background Workers section for why that's the
   honest default rather than a fake integration).

## Observability hooks already in place

- **Health checks**: `GET /health` (liveness), `GET /health/live`,
  `GET /health/ready` (readiness — verifies DB connectivity).
- **Structured logs**: every request carries a `request_id`
  (`app/middleware/request_context.py`); financial operations
  additionally carry `escrow_id`/`wallet_id` via `structlog` contextvars.
- **Prometheus / OpenTelemetry**: both are in `requirements.txt` (per the
  original tech stack) but not yet wired into `app/main.py` — instrumenting
  them is the natural next step if/when metrics or distributed tracing
  become a concrete operational need, rather than added speculatively
  ahead of one.

## Scaling notes

- `api` is stateless (JWTs are self-contained, refresh tokens and
  sessions live in Postgres) — safe to run multiple replicas behind a
  load balancer.
- `worker` can also run multiple replicas; Celery's own task
  acknowledgement (`task_acks_late=True`, `worker_prefetch_multiplier=1`
  in `app/workers/celery_app.py`) is already configured for safe
  at-least-once processing under concurrent workers.
- `beat` **must run as exactly one instance** — running two would fire
  every scheduled task twice. Celery Beat has no built-in leader
  election; if you need HA for the scheduler itself, look at
  `celery-beat-ha`/`redbeat` rather than just scaling the `beat` service
  in `docker-compose.yml`, which does not provide that on its own.
