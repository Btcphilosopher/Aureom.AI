# Entity-Relationship Diagram

Twelve tables, all created by the single Alembic migration at
`migrations/versions/43a05b493b88_initial_schema.py`. UUID primary keys
throughout (see `app/database/base.py`'s `UUIDPrimaryKeyMixin`) — never
auto-increment integers, which would leak sequence/volume information
across a public API.

```mermaid
erDiagram
    USERS ||--o| WALLETS : owns
    USERS ||--o{ REFRESH_TOKENS : has
    USERS ||--o{ API_KEYS : has
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ AUDIT_LOGS : "acts as (nullable)"
    USERS ||--o{ ESCROWS : "is payer of"
    USERS ||--o{ ESCROWS : "is payee of"
    USERS ||--o{ DISPUTES : raises
    USERS ||--o{ EVIDENCE : submits

    WALLETS ||--o{ WALLET_TRANSACTIONS : ledger

    ESCROWS ||--o{ ESCROW_EVENTS : "state history"
    ESCROWS ||--o{ ESCROW_TRANSACTIONS : "money movements"
    ESCROWS ||--o{ DISPUTES : "may have"

    DISPUTES ||--o{ EVIDENCE : "submissions"

    ESCROW_TRANSACTIONS }o--|| WALLET_TRANSACTIONS : "links to"

    USERS {
        uuid id PK
        string email UK
        string hashed_password
        string full_name
        enum role "user | admin"
        enum status "active | suspended | deleted"
        bool is_verified
        timestamptz created_at
        timestamptz updated_at
    }

    WALLETS {
        uuid id PK
        uuid user_id FK "UK — one wallet per user"
        string currency
        numeric balance "CHECK >= 0"
        numeric held_balance "CHECK >= 0, CHECK <= balance"
        timestamptz created_at
        timestamptz updated_at
    }

    WALLET_TRANSACTIONS {
        uuid id PK
        uuid wallet_id FK
        enum type "deposit|withdrawal|escrow_hold|escrow_release|escrow_refund|fee|adjustment"
        numeric amount "signed"
        numeric balance_after
        string reference_type
        uuid reference_id
        string description
        string idempotency_key UK
        timestamptz created_at "append-only, no updated_at"
    }

    ESCROWS {
        uuid id PK
        uuid payer_id FK
        uuid payee_id FK "CHECK payer_id != payee_id"
        enum status "10 states — see docs/architecture.md"
        numeric amount "CHECK > 0"
        numeric fee_amount "CHECK >= 0, reserved for future use"
        string currency
        text description
        text terms
        string external_reference
        timestamptz funded_at
        timestamptz released_at
        timestamptz refunded_at
        timestamptz cancelled_at
        timestamptz expires_at "optional funding deadline"
        timestamptz created_at
        timestamptz updated_at
    }

    ESCROW_TRANSACTIONS {
        uuid id PK
        uuid escrow_id FK
        enum type "deposit|release|refund|fee|adjustment"
        enum status "pending|completed|failed"
        numeric amount "CHECK > 0"
        uuid wallet_transaction_id FK "nullable"
        string idempotency_key UK
        timestamptz created_at "append-only"
    }

    ESCROW_EVENTS {
        uuid id PK
        uuid escrow_id FK
        enum from_status "nullable — null for the CREATED event"
        enum to_status
        uuid actor_id FK "nullable — null for system actions"
        text reason
        timestamptz created_at "append-only"
    }

    DISPUTES {
        uuid id PK
        uuid escrow_id FK
        uuid raised_by_id FK
        enum status "open|under_review|resolved|closed"
        text reason
        enum resolution "release_to_payee|refund_to_payer|split, nullable"
        text resolution_notes
        uuid resolved_by_id FK "nullable"
        timestamptz resolved_at
        timestamptz created_at
        timestamptz updated_at
    }

    EVIDENCE {
        uuid id PK
        uuid dispute_id FK
        uuid submitted_by_id FK
        text description
        string file_url
        string file_hash
        timestamptz created_at "append-only"
    }

    NOTIFICATIONS {
        uuid id PK
        uuid user_id FK
        enum type "escrow_*, dispute_*, system"
        enum status "pending|sent|failed|read"
        string title
        text message
        string reference_type
        uuid reference_id
        timestamptz read_at
        timestamptz created_at
        timestamptz updated_at
    }

    AUDIT_LOGS {
        uuid id PK
        uuid actor_id FK "nullable — null for system actions"
        string action "e.g. escrow.funded — see AuditAction"
        string resource_type
        uuid resource_id
        jsonb extra_data
        string ip_address
        string user_agent
        timestamptz created_at "append-only, immutable, never deleted"
    }

    API_KEYS {
        uuid id PK
        uuid user_id FK
        string name
        string key_prefix
        string hashed_key UK
        enum status "active|revoked"
        jsonb scopes
        timestamptz last_used_at
        timestamptz expires_at
        timestamptz revoked_at
        timestamptz created_at
        timestamptz updated_at
    }

    REFRESH_TOKENS {
        uuid id PK
        uuid user_id FK
        string hashed_token UK
        string user_agent
        string ip_address
        timestamptz expires_at
        timestamptz revoked_at
        timestamptz created_at
        timestamptz updated_at
    }
```

## Reading this alongside the code

- **Mixins, not per-table repetition** — `TimestampMixin`
  (`created_at`/`updated_at`) vs `CreatedAtMixin` (`created_at` only) are
  applied consistently: mutable entities (users, wallets, escrows,
  disputes, notifications, API keys, refresh tokens) get both columns;
  append-only ledger/event/audit tables (wallet transactions, escrow
  transactions, escrow events, evidence, audit logs) get only
  `created_at` — the absence of `updated_at` is deliberate, signalling
  "this row is never modified after insert," not an oversight. See
  `app/database/base.py`.
- **Two idempotency keys, two different reasons.** Both
  `wallet_transactions.idempotency_key` and
  `escrow_transactions.idempotency_key` are unique — the former guards
  `WalletService.deposit`/`withdraw` (Phase 4), the latter guards
  `EscrowTransactionEngine.fund`/`release`/`refund`/`split` (Phase 6/7).
  They're checked separately because a single escrow operation
  (`release`) can touch *two* wallets' ledgers at once but only ever
  produces *one* `EscrowTransaction` — see `docs/architecture.md`'s
  Financial Integrity section.
- **`escrows.payer_id`/`payee_id` both reference `users.id`**, which is
  why the diagram shows two separate USERS↔ESCROWS relationships rather
  than one — a user can appear on either side across different escrows,
  never both sides of the same one (enforced by a `CHECK` constraint,
  not just application logic).
- **CHECK constraints are load-bearing, not decorative.** `held_balance
  <= balance`, non-negative balances, `payer_id != payee_id`, positive
  amounts — all verified directly against live Postgres in
  `tests/test_database.py`, independent of whatever the application
  layer validates first.
- **The full legal `escrows.status` transition graph** — ten states,
  three deliberate widenings beyond the spec's minimal two-path diagram
  — is documented in `docs/architecture.md`'s Escrow State Machine
  section, not repeated here.
