# Studio Executive v2.0
### A Hollywood Management Simulation

---

## How to Run

**Requirements:** Python 3.11+ (no external packages needed)

```bash
python run.py
# OR
python -m studio_exec.main
```

---

## What's New in v2.0

- **Script Market** — Browse and buy 10 rotating scripts with variable quality and price. Negotiate prices down by up to 15%.
- **Talent Scouting** — Scouts find Emerging and B-List talent weekly. Sign them with a one-time fee before reports expire (8 weeks).
- **Studio Upgrades** — 10 purchasable facilities (Editing Suite, Soundstage, VFX House, Marketing Dept, etc.) that permanently buff your studio.
- **Revenue Projections** — Monte Carlo engine (200 simulations) gives you P10/P50/P90 revenue estimates and a risk rating before you commit.
- **Film Sequels** — Greenlight sequels to successful films (ROI > 120%) with quality and hype inheritance.
- **Film Cancellation** — Abandon films in development to cut losses.
- **Week Summary Dashboard** — Every advance shows a compact summary of pipeline events, releases, trends, and net cash.

---

## Systems Overview

### Film Production Pipeline
7 stages: Script → Development → Casting → Production → Post-Production → Marketing → Released

Each stage automatically consumes its budget fraction over time. Stage durations:
| Stage | Duration | Budget % |
|---|---|---|
| Script | 4 weeks | 5% |
| Development | 6 weeks | 8% |
| Casting | 3 weeks | 5% |
| Production | 12 weeks | 45% |
| Post-Production | 8 weeks | 22% |
| Marketing | 4 weeks | 15% |

Total pipeline: ~37 weeks from greenlight to release + 8 weeks theatrical run.

### Script Market
- 10 scripts in rotation, refreshed every 8 weeks
- Quality from grade F (35) to S (90+), price scales with quality
- Premium scripts (top 10%) appear rarely — worth watching for
- Prices decay ~3%/week unsold
- Negotiate any script down to 85% of asking

### Talent System
| Role | Effect |
|---|---|
| Writer | Script quality → critic score foundation (30%) |
| Director | Direction rating → critic score (35%) |
| Actor | Performance rating → critic score (25%), audience score |
| Chemistry | Compatible traits/genres → bonus up to +5 on scores |

Traits matter: `Professional` pairs well with everything. `Difficult` hurts chemistry. `Visionary` adds quality. `Scandal-Prone` triggers events.

### Scouting
- 1 scout by default (upgrade to 3 with Scout Network + upgrade)
- 30% chance per scout per week of finding talent
- Reports expire after 8 weeks — sign or lose them
- Tier probability: 60% Emerging, 30% B-List, 5% A-List

### Box Office Flow
1. Opening weekend (20% of projected total, ±12% surprise)
2. Weekly drop-off (~45%/week × word-of-mouth modifier)
3. 8 weeks of domestic box office
4. International revenue (0.8× – 1.8× domestic)
5. Streaming deal (5–30% of budget)

**Season multipliers:** Summer ×1.35 | Holiday ×1.25 | Awards ×1.15 | Regular ×1.0

### Studio Upgrades
| Upgrade | Cost | Effect |
|---|---|---|
| Premium Editing Suite | $3M | +4 quality per film |
| Large Soundstage | $5M | -10% cost overruns |
| In-House Marketing | $4M | +40% marketing effectiveness |
| Private Screening Room | $1.5M | +3 quality per film |
| Extended Scout Network | $2M | +1 scout slot |
| Expanded Studio Lot | $8M | +1 concurrent film slot |
| Studio Finance Dept | $2.5M | -2% loan interest |
| Awards Consultant | $1.2M | +5 prestige per award |
| In-House VFX Studio | $7M | +3 quality, -8% overruns |
| Partner Talent Agency | $3.5M | +5 hype per release |

### Revenue Projection Engine
Monte Carlo simulation (200 runs):
- Uses current talent, script quality, trends
- Accounts for genre popularity, season, competition
- Returns P10 (pessimistic), P50 (expected), P90 (optimistic) + risk rating

### Awards System
- Ceremony each Year at Week 5
- Eligible: released films with critic score ≥ 60
- 10 categories: Best Picture, Director, Actor, Actress, Supporting, Screenplay, VFX, Score, Cinematography, Audience Choice
- Winning: boosts box office 2-8%, lifts talent reputation/popularity, adds prestige and cash

---

## Strategy Guide

### Year 1
1. Browse the Script Market — look for an **A or B grade** script in a popular genre
2. Check Market Trends before buying — is the genre at 65+ popularity?
3. Set budget at $10M–$20M to stay solvent while your first film runs
4. Assign the cheapest Writer and Director with the right genre focus
5. Use revenue projections: if P50 < budget, reconsider the cast

### Year 2-3
- Reinvest box office profits into an upgrade (Editing Suite or Marketing Dept first)
- Start scouting for B-List talent to replace expensive A-list veterans
- Greenlight 2 films simultaneously on staggered timelines
- Aim for critics score 80+ to get award nominations

### Year 4+
- Max out the Studio Lot for 6 concurrent productions
- Build prestige awards run: Drama/Sci-Fi with visionary director + A-list cast
- Use sequels for proven franchise genres
- Loans are viable for blockbuster budgets if your Rep Bonus is >20%

---

## Save System
Saves stored in `~/.studio_exec_saves/` as JSON. Multiple named slots supported.
