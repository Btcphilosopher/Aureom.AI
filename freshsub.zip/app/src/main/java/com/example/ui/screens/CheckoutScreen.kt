package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StandardButton
import com.example.ui.theme.*
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

@Composable
fun CheckoutScreen(
    viewModel: FreshSubViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val cartItems = viewModel.cartItems.collectAsState()
    val totalPrice = viewModel.cartTotalPrice.collectAsState()
    val activeStore = viewModel.selectedLocation.collectAsState()
    val orderType = viewModel.orderType.collectAsState()

    var selectedPayment by remember { mutableStateOf("CREDIT_CARD") }
    val simulatedDeliveryFee = if (orderType.value == "DELIVERY") 2.99 else 0.00
    val simulatedTax = String.format("%.2f", totalPrice.value * 0.15).toDouble() // 15% VAT included

    val finalTotal = String.format("%.2f", totalPrice.value + simulatedDeliveryFee).toDouble()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(SoftCream)
    ) {
        // 1. Order Type Toggles
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "COLLECTION METHOD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val types = listOf(
                        Pair("PICKUP", "🏃 Pickup"),
                        Pair("DELIVERY", "🚗 Delivery"),
                        Pair("DINE-IN", "🍽️ Dine-in")
                    )
                    types.forEach { (type, label) ->
                        val isSelected = orderType.value == type
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) LightFreshGreen else SoftCream)
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) FreshGreen else BorderGray,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { viewModel.setOrderType(type) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) FreshGreen else DarkCharcoal
                            )
                        }
                    }
                }
            }
        }

        // 2. Location details Widget
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = FreshGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RESTAURANT ASSIGNED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = activeStore.value.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkCharcoal
                )
                Text(
                    text = activeStore.value.address + ", " + activeStore.value.city,
                    fontSize = 11.sp,
                    color = TextGray
                )
            }
        }

        // 3. Payment Methods Checklist
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SELECT PAYMENT METHOD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                val payments = listOf(
                    Pair("CREDIT_CARD", "💳 Credit or Debit Card"),
                    Pair("GOOGLE_PAY", "🤖 Google Pay"),
                    Pair("APPLE_PAY", "🍏 Apple Pay")
                )

                payments.forEach { (payId, label) ->
                    val isSelected = selectedPayment == payId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPayment = payId }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { selectedPayment = payId },
                            colors = RadioButtonDefaults.colors(selectedColor = FreshGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = label,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkCharcoal
                        )
                    }
                }
            }
        }

        // 4. Cart summary breakdown
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BILLING SUMMARY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                SummaryRow("Subtotal", "£${totalPrice.value}")
                if (simulatedDeliveryFee > 0) {
                    SummaryRow("Delivery Fee", "£${simulatedDeliveryFee}")
                }
                SummaryRow("Estimated VAT (Included)", "£${simulatedTax}")

                Divider(modifier = Modifier.padding(vertical = 12.dp), color = BorderGray)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL AMOUNT",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkCharcoal
                    )
                    Text(
                        text = "£${finalTotal}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = FreshGreen
                    )
                }

                // Points Earning notification
                Box(
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(LightFreshGreen)
                        .padding(10.dp)
                        .fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = FreshGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "You will earn +${(finalTotal * 10).toInt()} loyalty points on this order!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FreshGreen
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Checkout Trigger Action
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            StandardButton(
                text = "Place Order • £$finalTotal",
                onClick = { viewModel.placeOrder(selectedPayment) },
                isSecondary = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_place_order_btn")
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun SummaryRow(label: String, amount: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = TextGray)
        Text(text = amount, fontSize = 13.sp, color = DarkCharcoal, fontWeight = FontWeight.Bold)
    }
}
