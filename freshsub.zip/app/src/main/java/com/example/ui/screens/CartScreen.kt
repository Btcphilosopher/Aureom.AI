package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.CartItem
import com.example.ui.components.StandardButton
import com.example.ui.theme.*
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

@Composable
fun CartScreen(
    viewModel: FreshSubViewModel,
    modifier: Modifier = Modifier
) {
    val cartItems = viewModel.cartItems.collectAsState()
    val totalPrice = viewModel.cartTotalPrice.collectAsState()
    val totalCalories = viewModel.cartTotalCalories.collectAsState()
    val proposedDeal = viewModel.proposedDeal.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SoftCream)
    ) {
        if (cartItems.value.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .background(LightFreshGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = null,
                            tint = FreshGreen,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "YOUR BAG IS EMPTY",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = DarkCharcoal
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Customize your first sub, wrap, or salad exactly the way you like it!",
                        fontSize = 12.sp,
                        color = TextGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    StandardButton(
                        text = "EXPLORE MENU",
                        onClick = { viewModel.navigateTo(Screen.Menu) },
                        modifier = Modifier.testTag("cart_empty_explore_btn")
                    )
                }
            }
        } else {
            Column(modifier = Modifier.weight(1f)) {
                // 1. Proposed Deal Widget (Smart Recommendation Engine)
                proposedDeal.value?.let { deal ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FreshYellow),
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                            .border(2.dp, FreshGold, RoundedCornerShape(16.dp))
                            .testTag("proposed_deal_banner")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = DarkCharcoal)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "SMART COMBO FOUND!",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        color = DarkCharcoal,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(DarkCharcoal)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        "SAVE £${deal.saving}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FreshYellow
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Convert your standalone items into a customized Meal Deal bundle for extra savings!",
                                fontSize = 11.sp,
                                color = DarkCharcoal.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            StandardButton(
                                text = "APPLY BUNDLE DISCOUNT",
                                onClick = { viewModel.applyProposedDeal() },
                                isSecondary = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(36.dp)
                                    .testTag("apply_deal_btn")
                            )
                        }
                    }
                }

                // 2. Scrollable Bag Items
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(cartItems.value, key = { it.id }) { item ->
                        CartProductCard(
                            item = item,
                            onQuantityIncrease = { viewModel.updateCartItemQuantity(item, item.quantity + 1) },
                            onQuantityDecrease = { viewModel.updateCartItemQuantity(item, item.quantity - 1) },
                            onRemove = { viewModel.removeCartItem(item) }
                        )
                    }
                }

                // 3. Totals Box & Sticky Checkout Panel
                Surface(
                    tonalElevation = 6.dp,
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "BAG TOTAL (${cartItems.value.sumOf { it.quantity }} ITEMS)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextGray
                                )
                                Text(
                                    text = "£${totalPrice.value}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = DarkCharcoal
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "ESTIMATED NUTRITION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextGray
                                )
                                Text(
                                    text = "${totalCalories.value} kcal total",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FreshGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        StandardButton(
                            text = "PROCEED TO CHECKOUT",
                            onClick = { viewModel.navigateTo(Screen.Checkout) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_proceed_btn")
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CartProductCard(
    item: CartItem,
    onQuantityIncrease: () -> Unit,
    onQuantityDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cart_item_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkCharcoal
                    )
                    Text(
                        text = "Base: ${item.baseName} • Toasted: ${if (item.isToasted) "Yes" else "No"}",
                        fontSize = 11.sp,
                        color = TextGray
                    )
                }

                Text(
                    text = "£${String.format("%.2f", item.price * item.quantity)}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = FreshGreen
                )
            }

            // Ingredient detail breakdown
            val details = mutableListOf<String>()
            if (item.proteins.isNotEmpty()) details.add("Protein: ${item.proteins.joinToString(", ")}")
            if (item.cheeses.isNotEmpty()) details.add("Cheese: ${item.cheeses.joinToString(", ")}")
            if (item.vegetables.isNotEmpty()) details.add("Veggies: ${item.vegetables.joinToString(", ")}")
            if (item.sauces.isNotEmpty()) details.add("Sauces: ${item.sauces.joinToString(", ")}")
            if (item.extras.isNotEmpty()) details.add("Extras: ${item.extras.joinToString(", ")}")
            if (item.sideName != null) details.add("Meal Side: ${item.sideName}")
            if (item.drinkName != null) details.add("Meal Drink: ${item.drinkName}")

            if (details.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = details.joinToString(" | "),
                    fontSize = 10.sp,
                    color = TextGray,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BorderGray)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Remove Item Button (Large touch target)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onRemove() }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = ErrorRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "REMOVE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ErrorRed
                    )
                }

                // Quantity Multipliers
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(SoftCream)
                        .padding(horizontal = 4.dp)
                ) {
                    IconButton(
                        onClick = onQuantityDecrease,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("qty_decrease_${item.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease qty", tint = DarkCharcoal, modifier = Modifier.size(16.dp))
                    }
                    
                    Text(
                        text = item.quantity.toString(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkCharcoal,
                        modifier = Modifier.padding(horizontal = 10.dp),
                        textAlign = TextAlign.Center
                    )

                    IconButton(
                        onClick = onQuantityIncrease,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("qty_increase_${item.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increase qty", tint = DarkCharcoal, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
