package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.Order
import com.example.ui.components.StandardButton
import com.example.ui.theme.*
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

@Composable
fun TrackingScreen(
    viewModel: FreshSubViewModel,
    orderId: String,
    modifier: Modifier = Modifier
) {
    val activeOrderState = viewModel.activeTrackingOrder.collectAsState()
    val scrollState = rememberScrollState()

    val order = activeOrderState.value

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(SoftCream)
    ) {
        if (order == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "No active order found to track.", color = TextGray)
            }
        } else {
            // 1. Splash Header (Green background)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(vertical = 24.dp, horizontal = 20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (order.status == "READY" || order.status == "COLLECTED" || order.status == "DELIVERED") Icons.Default.CheckCircle else Icons.Default.Timer,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "ORDER STATUS: " + getReadableStatus(order.status),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "ID: ${order.id} • Assigned to ${order.restaurantName}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            // 2. Roadmap Progression Card (Vibrant step checklist)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "TRACKING YOUR FEAST",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    val steps = listOf(
                        Triple("ORDER_RECEIVED", "Order Confirmed", "We've received your ticket and are checking ingredients!"),
                        Triple("PREPARING", "Sub-Artisans At Work", "Pristinely arranging proteins, toasted cheeses & veggies!"),
                        Triple("READY", "Freshly Wrapped & Ready", "Wrapped hot in our signature foil at the pick-up counter!"),
                        Triple("DELIVERED_COLLECTED", "Handed Over & Complete", "Successfully collected! Grab a napkin and enjoy!")
                    )

                    steps.forEachIndexed { index, step ->
                        val isCompleted = isStepCompleted(order.status, step.first)
                        val isActive = isStepActive(order.status, step.first)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            // Step Visual Circle
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(
                                            color = if (isCompleted) FreshGreen else if (isActive) FreshYellow else BorderGray,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isCompleted) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    } else {
                                        Text(
                                            text = (index + 1).toString(),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isActive) DarkCharcoal else TextGray
                                        )
                                    }
                                }
                                if (index < steps.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .width(2.dp)
                                            .height(30.dp)
                                            .background(if (isCompleted) FreshGreen else BorderGray)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // Step texts
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = step.second,
                                    fontSize = 14.sp,
                                    fontWeight = if (isActive || isCompleted) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isActive || isCompleted) DarkCharcoal else TextGray
                                )
                                Text(
                                    text = step.third,
                                    fontSize = 11.sp,
                                    color = TextGray
                                )
                            }
                        }
                    }
                }
            }

            // 3. Receipt summary checklist
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ITEMS ORDERED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextGray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = order.itemsSummary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = DarkCharcoal
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BorderGray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Paid via Mobile", fontSize = 12.sp, color = TextGray)
                        Text("Total Paid: £${String.format("%.2f", order.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FreshGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 4. Back to Home action
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                StandardButton(
                    text = "BACK TO HOME",
                    onClick = { viewModel.navigateTo(Screen.Home) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tracking_back_home_btn")
                )
            }
            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

// status flow helpers
private fun isStepCompleted(current: String, stepId: String): Boolean {
    return when (stepId) {
        "ORDER_RECEIVED" -> current != "ORDER_RECEIVED"
        "PREPARING" -> current != "ORDER_RECEIVED" && current != "PREPARING"
        "READY" -> current == "COLLECTED" || current == "DELIVERED"
        "DELIVERED_COLLECTED" -> current == "COLLECTED" || current == "DELIVERED"
        else -> false
    }
}

private fun isStepActive(current: String, stepId: String): Boolean {
    return when (stepId) {
        "ORDER_RECEIVED" -> current == "ORDER_RECEIVED"
        "PREPARING" -> current == "PREPARING"
        "READY" -> current == "READY"
        "DELIVERED_COLLECTED" -> current == "COLLECTED" || current == "DELIVERED"
        else -> false
    }
}

private fun getReadableStatus(status: String): String {
    return when (status) {
        "ORDER_RECEIVED" -> "RECEIVED"
        "PREPARING" -> "PREPARING FOOD"
        "READY" -> "READY FOR PICKUP"
        "COLLECTED", "DELIVERED" -> "COMPLETED"
        else -> status
    }
}
