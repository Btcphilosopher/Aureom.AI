package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.MenuItem
import com.example.ui.components.NutritionBadge
import com.example.ui.components.StandardButton
import com.example.ui.theme.*
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

@Composable
fun MenuScreen(
    viewModel: FreshSubViewModel,
    modifier: Modifier = Modifier
) {
    val activeCategory = viewModel.selectedMenuCategory.collectAsState()
    val menuItems = viewModel.menuItemsForCategory.collectAsState()

    val categories = listOf(
        "SANDWICHES", "WRAPS", "SALADS", "BREAKFAST", "SIDES", "DRINKS", "COOKIES"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SoftCream)
    ) {
        // 1. Horizontal Scrollable Category Tabs
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(activeCategory.value).coerceAtLeast(0),
            containerColor = Color.White,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                val index = categories.indexOf(activeCategory.value).coerceAtLeast(0)
                if (index < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[index]),
                        color = MaterialTheme.colorScheme.primary,
                        height = 3.dp
                    )
                }
            },
            divider = { Divider(color = BorderGray) }
        ) {
            categories.forEach { cat ->
                val isSelected = activeCategory.value == cat
                Tab(
                    selected = isSelected,
                    onClick = { viewModel.setMenuCategory(cat) },
                    text = {
                        Text(
                            text = cat,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else TextGray
                        )
                    },
                    modifier = Modifier.testTag("menu_tab_$cat")
                )
            }
        }

        // 2. Menu Items Grid
        if (menuItems.value.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No items available in this category.",
                    fontSize = 14.sp,
                    color = TextGray
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(1), // 1-column layout for detailed card display
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(menuItems.value, key = { it.id }) { item ->
                    MenuProductCard(
                        item = item,
                        onCustomize = {
                            viewModel.initBuilder(item, item.category)
                            viewModel.navigateTo(Screen.Builder(item.id, item.category))
                        },
                        onAdd = { viewModel.addMenuItemToCartAsIs(item) }
                    )
                }
            }
        }
    }
}

@Composable
fun MenuProductCard(
    item: MenuItem,
    onCustomize: () -> Unit,
    onAdd: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row (Name + Calorie Badge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkCharcoal
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "From £${String.format("%.2f", item.basePrice)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = FreshGreen
                    )
                }
                
                NutritionBadge(calories = item.baseNutrition.calories)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = item.description,
                fontSize = 12.sp,
                color = TextGray,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = BorderGray)

            // Dynamic Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (item.isCustomizable) {
                    OutlinedButton(
                        onClick = onCustomize,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 40.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("customize_btn_${item.id}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("CUSTOMIZE", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = onAdd,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1.2f)
                        .heightIn(min = 40.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("add_as_is_btn_${item.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (item.isCustomizable) "ADD AS-IS" else "ADD TO BAG",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
