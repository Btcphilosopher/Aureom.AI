package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.MenuItem
import com.example.ui.components.NutritionBadge
import com.example.ui.components.StandardButton
import com.example.ui.theme.*
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

@Composable
fun HomeScreen(
    viewModel: FreshSubViewModel,
    modifier: Modifier = Modifier
) {
    val userName = viewModel.userName.collectAsState()
    val points = viewModel.userPoints.collectAsState()
    val selectedLoc = viewModel.selectedLocation.collectAsState()
    val scrollState = rememberScrollState()

    // Retrieve popular products from repo (e.g. BMT, Teriyaki, Meatball)
    val popularItems = viewModel.getBreads().take(3) // mock popular combinations using breads/menu
    val featuredSub = viewModel.getBreads().firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(SoftCream)
    ) {
        // 1. Hero Promo Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(bottom = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Welcome back, ${userName.value}!",
                    fontSize = 15.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Medium
                )
                
                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "WHAT ARE YOU\nHAVING TODAY?",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.secondary,
                    lineHeight = 36.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Core Call-to-Actions (Large Touch Targets)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StandardButton(
                        text = "Start Order",
                        onClick = { viewModel.navigateTo(Screen.Menu) },
                        isSecondary = true,
                        icon = Icons.Default.AddShoppingCart,
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("start_order_button")
                    )

                    Button(
                        onClick = { viewModel.navigateTo(Screen.LocationSelect) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkFreshGreen),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("find_store_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("STORES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // 2. Active Store Widget
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.LocationSelect) }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(LightFreshGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = FreshGreen)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Ordering from:",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = selectedLoc.value.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkCharcoal
                    )
                    Text(
                        text = "Prep: ${selectedLoc.value.prepTimeMinutes} mins • ${selectedLoc.value.openingHours}",
                        fontSize = 11.sp,
                        color = TextGray
                    )
                }
                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextGray)
            }
        }

        // 3. Loyalty Reward Teaser
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.Rewards) }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "FRESHSUB LOYALTY REWARDS",
                        fontSize = 11.sp,
                        color = FreshYellow,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "You have ${points.value} Points",
                        fontSize = 18.sp,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Earn 10 points per £1 spent. Redeem for free food!",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(FreshYellow, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = DarkCharcoal)
                }
            }
        }

        // 4. "Build Your Own" Banner Card with Generate Image check
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .clickable {
                    // Navigate to custom builder for oven roasted chicken sandwich
                    val chickenSub = viewModel.getMenuItems().firstOrNull { it.id == "sub_0_6" }
                    if (chickenSub != null) {
                        viewModel.initBuilder(chickenSub, "SANDWICHES")
                        viewModel.navigateTo(Screen.Builder(chickenSub.id, "SANDWICHES"))
                    }
                }
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(Color(0xFFE8F5E9)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.OutdoorGrill,
                            contentDescription = null,
                            tint = FreshGreen,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "BUILD YOUR OWN SANDWICH",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = FreshGreen
                        )
                        Text(
                            text = "Step-by-step: Bread, protein, toppings, and sauces.",
                            fontSize = 11.sp,
                            color = TextGray
                        )
                    }
                }
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Customized To Perfection",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkCharcoal
                        )
                        Text(
                            text = "Choose from over 30+ ingredients",
                            fontSize = 11.sp,
                            color = TextGray
                        )
                    }
                    Text(
                        text = "BUILD IT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = FreshGreen
                    )
                }
            }
        }

        // 5. Popular Categories/Selections (Sides and Extras)
        Text(
            text = "TODAY'S SPECIAL OFFERS",
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            color = DarkCharcoal,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
        )

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(viewModel.getDeals().take(4)) { deal ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .width(240.dp)
                        .clickable { viewModel.navigateTo(Screen.Menu) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(FreshYellow)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    deal.type.replace("_", " "),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkCharcoal
                                )
                            }
                            Text(
                                "SAVE £${deal.saving}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = FreshGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = deal.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkCharcoal
                        )

                        Text(
                            text = deal.description,
                            fontSize = 11.sp,
                            color = TextGray,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ONLY £${deal.dealPrice}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = FreshGreen
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = FreshGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
