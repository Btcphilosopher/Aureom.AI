package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.BuilderState
import com.example.ui.theme.*

@Composable
fun VisualBuilderPreview(
    state: BuilderState,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "LIVE RECIPE PREVIEW",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Box(
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (state.itemCategory) {
                    "SANDWICHES", "BREAKFAST" -> SandwichStack(state)
                    "WRAPS" -> WrapStack(state)
                    "SALADS" -> SaladStack(state)
                    else -> DefaultPlaceholderStack(state)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Dynamic Live Stats Summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = (state.selectedBread?.name ?: state.baseItem?.defaultBase ?: "Fresh Base").uppercase(),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                    Text(
                        text = "${state.selectedSize} Size • Toasted: ${if (state.isToasted) "Yes" else "No"}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "£${state.calculateTotalPrice()}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${state.calculateTotalNutrition().calories} kcal",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun SandwichStack(state: BuilderState) {
    val scale = animateFloatAsState(
        targetValue = if (state.selectedSize == "Footlong") 1.1f else 0.9f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val breadColor = when (state.selectedBread?.id) {
        "br_multigrain", "br_honey_oat" -> Color(0xFF8D6E63) // darker brown
        "br_herbs", "br_cheese_or" -> Color(0xFFD7CCC8) // cheese crust brown
        "br_flat" -> Color(0xFFFFF9C4) // flatbread yellow
        "br_jalapeno" -> Color(0xFFFFB74D) // orange-ish cheddar jalapeno
        else -> Color(0xFFF5DEB3) // wheat beige
    }

    Column(
        modifier = Modifier
            .scale(scale.value)
            .fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // LAYER 1: Top Bun
        Box(
            modifier = Modifier
                .width(160.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 6.dp, bottomEnd = 6.dp))
                .background(breadColor)
                .border(2.dp, breadColor.darken(0.1f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
        )

        // LAYER 2: Sauces (ZigZag Canvas)
        if (state.selectedSauces.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .width(150.dp)
                    .height(14.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val colors = state.selectedSauces.map { getSauceColor(it.id) }
                    colors.forEachIndexed { i, color ->
                        val yOffset = 5f + (i * 3f)
                        val points = (0..6).map { x ->
                            Offset(
                                x = (size.width / 6) * x,
                                y = yOffset + if (x % 2 == 0) 5f else -5f
                            )
                        }
                        for (idx in 0 until points.size - 1) {
                            drawLine(
                                color = color,
                                start = points[idx],
                                end = points[idx + 1],
                                strokeWidth = 4f
                            )
                        }
                    }
                }
            }
        }

        // LAYER 3: Vegetables
        if (state.selectedVegetables.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .width(140.dp)
                    .height(20.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                state.selectedVegetables.forEach { veg ->
                    val vegColor = getVegColor(veg.id)
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .padding(1.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(vegColor)
                    )
                }
            }
        }

        // LAYER 4: Cheese
        if (state.selectedCheeses.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .width(135.dp)
                    .height(14.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                state.selectedCheeses.forEach { _ ->
                    Box(
                        modifier = Modifier
                            .width(30.dp)
                            .height(12.dp)
                            .background(Color(0xFFFFD54F)) // Melted cheese gold
                            .clip(RoundedCornerShape(2.dp))
                    )
                }
            }
        }

        // LAYER 5: Proteins
        if (state.selectedProteins.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .width(140.dp)
                    .height(24.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                state.selectedProteins.forEach { prot ->
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(18.dp)
                            .padding(2.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF8D6E63)) // Protein brown
                            .border(1.dp, Color(0xFF5D4037), RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = prot.name.take(3).uppercase(),
                            fontSize = 7.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // LAYER 6: Bottom Bun
        Box(
            modifier = Modifier
                .width(160.dp)
                .height(22.dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                .background(breadColor)
                .border(2.dp, breadColor.darken(0.1f), RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
        )
    }
}

@Composable
fun WrapStack(state: BuilderState) {
    // Elegant Folded Wrap representation
    Box(
        modifier = Modifier
            .size(160.dp)
            .clip(RoundedCornerShape(80.dp))
            .background(Color(0xFFE6EE9C)) // Spinach tortilla green-yellow
            .border(4.dp, Color(0xFFC5E1A5), RoundedCornerShape(80.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = "FOLDED WRAP",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF558B2F)
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Nested ingredient list inside tortilla
            Row(horizontalArrangement = Arrangement.Center) {
                if (state.selectedProteins.isNotEmpty()) {
                    Box(modifier = Modifier.padding(2.dp).background(Color(0xFFD7CCC8), RoundedCornerShape(4.dp)).padding(4.dp)) {
                        Text(state.selectedProteins.first().name.take(12), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (state.selectedCheeses.isNotEmpty()) {
                    Box(modifier = Modifier.padding(2.dp).background(Color(0xFFFFF59D), RoundedCornerShape(4.dp)).padding(4.dp)) {
                        Text("Melted Cheese", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (state.selectedVegetables.isNotEmpty()) {
                Text(
                    text = "${state.selectedVegetables.size} Fresh Veggies Selected",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
            if (state.selectedSauces.isNotEmpty()) {
                Text(
                    text = "+ ${state.selectedSauces.first().name}",
                    fontSize = 9.sp,
                    color = Color(0xFFE65100),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun SaladStack(state: BuilderState) {
    // Beautiful salad bowl layout
    Box(
        modifier = Modifier
            .width(170.dp)
            .height(130.dp)
            .clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp, topStart = 10.dp, topEnd = 10.dp))
            .background(Color(0xFF37474F)) // Deep dark charcoal bowl
            .border(3.dp, Color(0xFF263238), RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp, topStart = 10.dp, topEnd = 10.dp)),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier.padding(top = 10.dp, start = 8.dp, end = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Leafy Salad base (Greens)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF4CAF50)) // Fresh Salad green
            ) {
                Text("FRESH SALAD BASE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Stacked options in bowl
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                if (state.selectedProteins.isNotEmpty()) {
                    Box(modifier = Modifier.background(Color(0xFF8D6E63), RoundedCornerShape(4.dp)).padding(4.dp)) {
                        Text(state.selectedProteins.first().name.take(8), fontSize = 8.sp, color = Color.White)
                    }
                }
                if (state.selectedVegetables.isNotEmpty()) {
                    Box(modifier = Modifier.background(Color(0xFF81C784), RoundedCornerShape(4.dp)).padding(4.dp)) {
                        Text("+${state.selectedVegetables.size} Garden Veg", fontSize = 8.sp, color = Color.Black)
                    }
                }
            }
        }
    }
}

@Composable
fun DefaultPlaceholderStack(state: BuilderState) {
    Box(
        modifier = Modifier
            .size(120.dp)
            .clip(RoundedCornerShape(60.dp))
            .background(LightFreshGreen),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = state.baseItem?.name?.take(3)?.uppercase() ?: "SUB",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// Helpers
fun getSauceColor(id: String): Color {
    return when (id) {
        "sc_mayo", "sc_l_mayo", "sc_ranch", "sc_caesar" -> Color(0xFFFFFDE7) // Cream creamy white
        "sc_mustard" -> Color(0xFFFFD54F) // Yellow mustard
        "sc_h_mustard" -> Color(0xFFFFA000) // Dark yellow amber
        "sc_bbq" -> Color(0xFF3E2723) // Brown BBQ
        "sc_sriracha", "sc_buffalo" -> Color(0xFFD84315) // Red sriracha chilli
        "sc_sweet_o", "sc_sweet_ch" -> Color(0xFFFFCC80) // Translucent honey gold
        "sc_pesto" -> Color(0xFF558B2F) // Pesto green
        else -> Color(0xFFFFE082)
    }
}

fun getVegColor(id: String): Color {
    return when (id) {
        "vg_lettuce", "vg_spinach", "vg_cilantro" -> Color(0xFF4CAF50) // Lettuce light green
        "vg_tomato" -> Color(0xFFE53935) // Tomato red
        "vg_cucumber" -> Color(0xFF81C784) // Cucumber light green
        "vg_onion" -> Color(0xFFBA68C8) // Onion red/purple
        "vg_peppers", "vg_jalapenos" -> Color(0xFF2E7D32) // Peppers deep green
        "vg_olives" -> Color(0xFF212121) // Olives black
        "vg_sweetcorn" -> Color(0xFFFFD54F) // Corn gold
        else -> Color(0xFFAED581)
    }
}

fun Color.darken(factor: Float): Color {
    return Color(
        red = (this.red * (1f - factor)).coerceIn(0f, 1f),
        green = (this.green * (1f - factor)).coerceIn(0f, 1f),
        blue = (this.blue * (1f - factor)).coerceIn(0f, 1f),
        alpha = this.alpha
    )
}
