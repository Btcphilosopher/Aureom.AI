package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = FreshGreen,
    secondary = FreshYellow,
    tertiary = FreshGold,
    background = DarkCharcoal,
    surface = SurfaceDark,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = DarkCharcoal,
    onTertiary = DarkCharcoal,
    onBackground = SoftCream,
    onSurface = SoftCream,
    error = ErrorRed
  )

private val LightColorScheme =
  lightColorScheme(
    primary = FreshGreen,
    secondary = FreshYellow,
    tertiary = FreshGold,
    background = SoftCream,
    surface = androidx.compose.ui.graphics.Color.White,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = DarkCharcoal,
    onTertiary = DarkCharcoal,
    onBackground = DarkCharcoal,
    onSurface = DarkCharcoal,
    error = ErrorRed
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Branded Subway-style app prefers brand identity colors over generic wallpaper tint
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
