package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FreshGreen = Color(0xFF008938)
val DarkFreshGreen = Color(0xFF005E26)
val LightFreshGreen = Color(0xFFEDF7EE)
val FreshYellow = Color(0xFFFFC600)
val FreshGold = Color(0xFFE5B200)
val LightGold = Color(0xFFFFFDE7)
val DarkCharcoal = Color(0xFF262626)
val SurfaceDark = Color(0xFF333333)
val SoftCream = Color(0xFFF9F9F7)
val BorderGray = Color(0xFFEBEBE9)
val TextGray = Color(0xFF7A7A7A)
val ErrorRed = Color(0xFFD32F2F)

