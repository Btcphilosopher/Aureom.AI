package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.IngredientOption
import com.example.models.MenuItem
import com.example.ui.components.StandardButton
import com.example.ui.components.VisualBuilderPreview
import com.example.ui.theme.*
import com.example.viewmodel.BuilderState
import com.example.viewmodel.FreshSubViewModel

@Composable
fun BuilderScreen(
    viewModel: FreshSubViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.builderState.collectAsState()
    var currentStep by remember { mutableStateOf(1) }

    // Total steps configuration based on food category
    val totalSteps = if (state.itemCategory == "SANDWICHES" || state.itemCategory == "BREAKFAST") 9 else 7

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SoftCream)
    ) {
        // 1. Fixed Top Layer: Live Visual Stack Preview
        VisualBuilderPreview(state = state, modifier = Modifier.weight(0.9f))

        // 2. Step Title & Progression Bar
        Surface(
            tonalElevation = 2.dp,
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getStepTitle(currentStep, state.itemCategory),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Step $currentStep of $totalSteps",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextGray
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = currentStep.toFloat() / totalSteps.toFloat(),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = BorderGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }

        // 3. Wizard Choice Selection Body (Scrollable lists)
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            when (getStepType(currentStep, state.itemCategory)) {
                "BREAD" -> BreadSelector(viewModel, state)
                "SIZE" -> SizeSelector(viewModel, state)
                "PROTEIN" -> ProteinSelector(viewModel, state)
                "CHEESE" -> CheeseSelector(viewModel, state)
                "TOASTING" -> ToastingSelector(viewModel, state)
                "VEGETABLES" -> VegetableSelector(viewModel, state)
                "SAUCES" -> SauceSelector(viewModel, state)
                "EXTRAS" -> ExtrasSelector(viewModel, state)
                "MEAL" -> MealSelector(viewModel, state)
                else -> Text("Loading Step options...", modifier = Modifier.align(Alignment.Center))
            }
        }

        // 4. Fixed Bottom: Next / Prev Navigation
        Surface(
            tonalElevation = 6.dp,
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { currentStep-- },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("builder_prev_btn")
                    ) {
                        Text("BACK", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }

                if (currentStep < totalSteps) {
                    StandardButton(
                        text = "NEXT STEP",
                        onClick = { currentStep++ },
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("builder_next_btn")
                    )
                } else {
                    StandardButton(
                        text = "ADD TO BAG",
                        onClick = { viewModel.addBuiltItemToCart() },
                        isSecondary = true,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("builder_add_to_cart_btn")
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// STEP SELECTORS WORKFLOWS
// -------------------------------------------------------------

@Composable
fun BreadSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getBreads()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { bread ->
            val isSelected = state.selectedBread?.id == bread.id
            SelectionRow(
                name = bread.name,
                description = "Calories: ${bread.nutrition.calories} kcal • Fibre: 2g",
                price = if (bread.price > 0) "+ £${String.format("%.2f", bread.price)}" else "FREE",
                isSelected = isSelected,
                onClick = { viewModel.updateBread(bread) },
                tag = "bread_opt_${bread.id}"
            )
        }
    }
}

@Composable
fun SizeSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val sizes = listOf(
        Triple("6 Inch", "Perfect for a single fresh snack or light meal.", "Standard Price"),
        Triple("Footlong", "Massive size. Great to share or double up your hunger.", "Add ~70% Base Price")
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(sizes) { size ->
            val isSelected = state.selectedSize == size.first
            SelectionRow(
                name = size.first,
                description = size.second,
                price = size.third,
                isSelected = isSelected,
                onClick = { viewModel.updateSize(size.first) },
                tag = "size_opt_${size.first.replace(" ", "_")}"
            )
        }
    }
}

@Composable
fun ProteinSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getProteins()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { protein ->
            val isSelected = state.selectedProteins.any { it.id == protein.id }
            SelectionRow(
                name = protein.name,
                description = "Calories: ${protein.nutrition.calories} kcal • Protein: ${protein.nutrition.protein}g",
                price = "+ £${String.format("%.2f", protein.price)}",
                isSelected = isSelected,
                onClick = { viewModel.toggleProtein(protein) },
                tag = "protein_opt_${protein.id}"
            )
        }
    }
}

@Composable
fun CheeseSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getCheeses()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { cheese ->
            val isSelected = state.selectedCheeses.any { it.id == cheese.id }
            SelectionRow(
                name = cheese.name,
                description = "Calories: ${cheese.nutrition.calories} kcal • Sodium: ${cheese.nutrition.sodium}mg",
                price = if (cheese.price > 0) "+ £${String.format("%.2f", cheese.price)}" else "FREE",
                isSelected = isSelected,
                onClick = { viewModel.toggleCheese(cheese) },
                tag = "cheese_opt_${cheese.id}"
            )
        }
    }
}

@Composable
fun ToastingSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val options = listOf(
        Pair(true, "TOASTED (Melted cheese, warm toasted bun)"),
        Pair(false, "DO NOT TOAST (Served cool and crisp)")
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        options.forEach { opt ->
            val isSelected = state.isToasted == opt.first
            SelectionRow(
                name = if (opt.first) "TOASTED" else "NO TOAST",
                description = opt.second,
                price = "FREE",
                isSelected = isSelected,
                onClick = { viewModel.updateToasting(opt.first) },
                tag = "toast_opt_${opt.first}"
            )
        }
    }
}

@Composable
fun VegetableSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getVegetables()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { veg ->
            val isSelected = state.selectedVegetables.any { it.id == veg.id }
            SelectionRow(
                name = veg.name,
                description = "Fresh crisp garden toppings • ${veg.nutrition.calories} kcal",
                price = "FREE",
                isSelected = isSelected,
                onClick = { viewModel.toggleVegetable(veg) },
                tag = "veg_opt_${veg.id}"
            )
        }
    }
}

@Composable
fun SauceSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getSauces()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { sauce ->
            val isSelected = state.selectedSauces.any { it.id == sauce.id }
            SelectionRow(
                name = sauce.name,
                description = "Subway-style premium squirt • ${sauce.nutrition.calories} kcal",
                price = "FREE",
                isSelected = isSelected,
                onClick = { viewModel.toggleSauce(sauce) },
                tag = "sauce_opt_${sauce.id}"
            )
        }
    }
}

@Composable
fun ExtrasSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val items = viewModel.getExtras()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { extra ->
            val isSelected = state.selectedExtras.any { it.id == extra.id }
            SelectionRow(
                name = extra.name,
                description = "Gourmet loaded upgrade • +${extra.nutrition.calories} kcal",
                price = "+ £${String.format("%.2f", extra.price)}",
                isSelected = isSelected,
                onClick = { viewModel.toggleExtra(extra) },
                tag = "extra_opt_${extra.id}"
            )
        }
    }
}

@Composable
fun MealSelector(viewModel: FreshSubViewModel, state: BuilderState) {
    val sides = viewModel.getMenuItems().filter { it.category == "SIDES" }
    val drinks = viewModel.getMenuItems().filter { it.category == "DRINKS" }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (state.includeMealUpgrade) LightFreshGreen else Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setMealUpgrade(!state.includeMealUpgrade) }
                    .border(
                        width = if (state.includeMealUpgrade) 1.5.dp else 0.dp,
                        color = if (state.includeMealUpgrade) FreshGreen else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = state.includeMealUpgrade,
                        onCheckedChange = { viewModel.setMealUpgrade(it) },
                        colors = CheckboxDefaults.colors(checkedColor = FreshGreen)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("UPGRADE TO MEAL COMBO", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DarkCharcoal)
                        Text("Add any Side + Drink and save £0.99 off bundle price!", fontSize = 11.sp, color = TextGray)
                    }
                }
            }
        }

        if (state.includeMealUpgrade) {
            item {
                Text("CHOOSE A SIDE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextGray, modifier = Modifier.padding(top = 8.dp))
            }

            items(sides) { side ->
                val isSelected = state.selectedSide?.id == side.id
                SelectionRow(
                    name = side.name,
                    description = side.description,
                    price = "Included in Meal",
                    isSelected = isSelected,
                    onClick = { viewModel.updateSide(side) },
                    tag = "meal_side_${side.id}"
                )
            }

            item {
                Text("CHOOSE A DRINK", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextGray, modifier = Modifier.padding(top = 8.dp))
            }

            items(drinks) { drink ->
                val isSelected = state.selectedDrink?.id == drink.id
                SelectionRow(
                    name = drink.name,
                    description = drink.description,
                    price = "Included in Meal",
                    isSelected = isSelected,
                    onClick = { viewModel.updateDrink(drink) },
                    tag = "meal_drink_${drink.id}"
                )
            }
        }
    }
}

// -------------------------------------------------------------
// REUSABLE SELECTION COMPONENT CARD
// -------------------------------------------------------------

@Composable
fun SelectionRow(
    name: String,
    description: String,
    price: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) LightFreshGreen else Color.White
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) FreshGreen else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .testTag(tag),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                RadioButton(
                    selected = isSelected,
                    onClick = onClick,
                    colors = RadioButtonDefaults.colors(selectedColor = FreshGreen)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkCharcoal
                    )
                    Text(
                        text = description,
                        fontSize = 11.sp,
                        color = TextGray
                    )
                }
            }

            Text(
                text = price,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = FreshGreen
            )
        }
    }
}

// -------------------------------------------------------------
// WIZARD CONFIGURATION MAPS
// -------------------------------------------------------------

fun getStepType(step: Int, category: String): String {
    val sandwichSteps = listOf("", "BREAD", "SIZE", "PROTEIN", "CHEESE", "TOASTING", "VEGETABLES", "SAUCES", "EXTRAS", "MEAL")
    val standardSteps = listOf("", "PROTEIN", "CHEESE", "VEGETABLES", "SAUCES", "EXTRAS", "MEAL") // base is defined automatically for wraps/salads

    return if (category == "SANDWICHES" || category == "BREAKFAST") {
        sandwichSteps.getOrNull(step) ?: ""
    } else {
        standardSteps.getOrNull(step) ?: ""
    }
}

fun getStepTitle(step: Int, category: String): String {
    return when (getStepType(step, category)) {
        "BREAD" -> "STEP 1 — CHOOSE YOUR BREAD"
        "SIZE" -> "STEP 2 — CHOOSE YOUR SIZE"
        "PROTEIN" -> "STEP 3 — LOAD YOUR PROTEIN"
        "CHEESE" -> "STEP 4 — SELECT YOUR CHEESE"
        "TOASTING" -> "STEP 5 — CHOOSE TOASTING OPTION"
        "VEGETABLES" -> "STEP 6 — SELECT FRESH VEGETABLES"
        "SAUCES" -> "STEP 7 — CHOOSE FRESH SAUCES"
        "EXTRAS" -> "STEP 8 — CHOOSE OPTIONAL EXTRAS"
        "MEAL" -> "STEP 9 — MAKE IT A MEAL DEAL COMBO"
        else -> "CUSTOMIZE RECIPE"
    }
}
