package com.example.database

import android.content.Context
import androidx.room.*
import com.example.models.CartItem
import com.example.models.Order
import kotlinx.coroutines.flow.Flow

// 1. Thread-safe String List TypeConverter
class RoomTypeConverters {
    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list == null) return ""
        return list.joinToString("||")
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrEmpty()) return emptyList()
        return data.split("||").filter { it.isNotEmpty() }
    }
}

// 2. DAO for Cart Management
@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItem)

    @Update
    suspend fun updateCartItem(item: CartItem)

    @Delete
    suspend fun deleteCartItem(item: CartItem)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItemById(id: Long)
}

// 3. DAO for Order Tracking & History
@Dao
interface OrderDao {
    @Query("SELECT * FROM past_orders ORDER BY dateLong DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Query("UPDATE past_orders SET status = :status WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)

    @Query("SELECT * FROM past_orders WHERE id = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): Order?
}

// 4. AppDatabase Definition
@Database(entities = [CartItem::class, Order::class], version = 1, exportSchema = false)
@TypeConverters(RoomTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "freshsub_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
