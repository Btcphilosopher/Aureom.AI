package com.example.repository

import com.example.database.CartDao
import com.example.database.OrderDao
import com.example.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class FreshSubRepository(
    private val cartDao: CartDao,
    private val orderDao: OrderDao
) {
    // 1. Local Database - Cart Operations
    val cartItems: Flow<List<CartItem>> = cartDao.getCartItems()

    suspend fun addToCart(item: CartItem) {
        cartDao.insertCartItem(item)
    }

    suspend fun updateCartItem(item: CartItem) {
        cartDao.updateCartItem(item)
    }

    suspend fun removeFromCart(item: CartItem) {
        cartDao.deleteCartItem(item)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }

    // 2. Local Database - Order Operations
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()

    suspend fun placeOrder(order: Order) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrderStatus(orderId: String, status: String) {
        orderDao.updateOrderStatus(orderId, status)
    }

    suspend fun getOrderById(orderId: String): Order? {
        return orderDao.getOrderById(orderId)
    }

    // 3. Static/Mock Menu, Ingredients & Deals (From DemoData)
    fun getMenuItems(): List<MenuItem> = DemoData.menuItems
    fun getBreads(): List<IngredientOption> = DemoData.breads
    fun getProteins(): List<IngredientOption> = DemoData.proteins
    fun getCheeses(): List<IngredientOption> = DemoData.cheeses
    fun getVegetables(): List<IngredientOption> = DemoData.vegetables
    fun getSauces(): List<IngredientOption> = DemoData.sauces
    fun getExtras(): List<IngredientOption> = DemoData.extras
    fun getRestaurants(): List<Restaurant> = DemoData.restaurants
    fun getDeals(): List<Deal> = DemoData.deals

    fun getRewards(): List<Reward> {
        return listOf(
            Reward("rew_cookie", "Free Signature Cookie", 100, "Redeem for any freshly baked single cookie.", true),
            Reward("rew_drink", "Free Regular Drink", 150, "Redeem for any medium soft drink or iced tea.", true),
            Reward("rew_side", "Free Crispy Side", 200, "Redeem for warm toasted hashbrowns or chips.", true),
            Reward("rew_sub_6", "Free 6-Inch Sub", 500, "Redeem for any classic 6-inch sandwich customization.", true),
            Reward("rew_meal", "Free Premium Meal Combo", 800, "Redeem for a full meal deal including sub, side, and drink.", true),
            Reward("rew_sub_12", "Free Footlong Sub", 1000, "Redeem for any massive customized Footlong sandwich.", true)
        )
    }
}
