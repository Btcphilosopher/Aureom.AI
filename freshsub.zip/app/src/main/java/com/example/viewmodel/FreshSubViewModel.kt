package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.models.*
import com.example.repository.FreshSubRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object LocationSelect : Screen()
    object Menu : Screen()
    data class Builder(val menuItemId: String, val category: String) : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    data class Tracking(val orderId: String) : Screen()
    object Rewards : Screen()
    object Account : Screen()
}

data class BuilderState(
    val itemCategory: String = "SANDWICHES", // "SANDWICHES", "WRAPS", "SALADS", "BREAKFAST"
    val baseItem: MenuItem? = null,
    val selectedBread: IngredientOption? = null,
    val selectedSize: String = "6 Inch", // "6 Inch", "Footlong", "N/A"
    val selectedProteins: List<IngredientOption> = emptyList(),
    val selectedCheeses: List<IngredientOption> = emptyList(),
    val isToasted: Boolean = false,
    val selectedVegetables: List<IngredientOption> = emptyList(),
    val selectedSauces: List<IngredientOption> = emptyList(),
    val selectedExtras: List<IngredientOption> = emptyList(),
    // Meal upgrade addition
    val includeMealUpgrade: Boolean = false,
    val selectedSide: MenuItem? = null,
    val selectedDrink: MenuItem? = null,
    val drinkSize: String = "Medium"
) {
    fun calculateTotalPrice(): Double {
        val base = baseItem?.basePrice ?: 0.0
        val sizeMultiplier = if (selectedSize == "Footlong") 1.7 else 1.0
        val baseAdjusted = if (itemCategory == "SANDWICHES" || itemCategory == "BREAKFAST") {
            // basePrice is defined for 6" or breakfast, scale up if Footlong
            if (selectedSize == "Footlong") (baseItem?.basePrice ?: 0.0) * 1.7 else base
        } else base

        val breadPrice = selectedBread?.price ?: 0.0
        val proteinPrice = selectedProteins.sumOf { it.price }
        val cheesePrice = selectedCheeses.sumOf { it.price }
        val vegPrice = selectedVegetables.sumOf { it.price }
        val saucePrice = selectedSauces.sumOf { it.price }
        val extraPrice = selectedExtras.sumOf { it.price }

        var total = baseAdjusted + breadPrice + proteinPrice + cheesePrice + vegPrice + saucePrice + extraPrice

        if (includeMealUpgrade) {
            val sidePrice = selectedSide?.basePrice ?: 1.20
            val drinkPrice = selectedDrink?.basePrice ?: 1.50
            total += (sidePrice + drinkPrice) - 0.99 // Save 99p on bundle
        }

        return String.format("%.2f", total).toDouble()
    }

    fun calculateTotalNutrition(): Nutrition {
        var nut = baseItem?.baseNutrition ?: Nutrition.ZERO
        
        // Scale base nutrition if Footlong
        if ((itemCategory == "SANDWICHES" || itemCategory == "BREAKFAST") && selectedSize == "Footlong") {
            nut = nut * 2
        }

        selectedBread?.let { nut += it.nutrition }
        selectedProteins.forEach { nut += it.nutrition }
        selectedCheeses.forEach { nut += it.nutrition }
        selectedVegetables.forEach { nut += it.nutrition }
        selectedSauces.forEach { nut += it.nutrition }
        selectedExtras.forEach { nut += it.nutrition }

        if (includeMealUpgrade) {
            selectedSide?.let { nut += it.baseNutrition }
            selectedDrink?.let { nut += it.baseNutrition }
        }

        return nut
    }

    private fun <T> emptyStringList(): List<T> = emptyList()
}

class FreshSubViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FreshSubRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = FreshSubRepository(db.cartDao(), db.orderDao())
    }

    // --- Navigation & Flow ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        backStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeAt(backStack.size - 1)
            return true
        }
        return false
    }

    // --- Order Type ---
    private val _orderType = MutableStateFlow("PICKUP") // "PICKUP", "DELIVERY", "DINE-IN"
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    fun setOrderType(type: String) {
        _orderType.value = type
    }

    // --- User Rewards & Account ---
    private val _userPoints = MutableStateFlow(420) // Demo loyalty balance
    val userPoints: StateFlow<Int> = _userPoints.asStateFlow()

    private val _userName = MutableStateFlow("David Miller")
    val userName: StateFlow<String> = _userName.asStateFlow()

    // --- Locations ---
    private val _selectedLocation = MutableStateFlow<Restaurant>(repository.getRestaurants().first())
    val selectedLocation: StateFlow<Restaurant> = _selectedLocation.asStateFlow()

    private val _restaurantSearchQuery = MutableStateFlow("")
    val restaurantSearchQuery: StateFlow<String> = _restaurantSearchQuery.asStateFlow()

    fun updateSearchQuery(q: String) {
        _restaurantSearchQuery.value = q
    }

    val filteredRestaurants: StateFlow<List<Restaurant>> = _restaurantSearchQuery
        .map { query ->
            val list = repository.getRestaurants()
            if (query.isEmpty()) list
            else list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.city.contains(query, ignoreCase = true) ||
                it.postcode.contains(query, ignoreCase = true)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.getRestaurants())

    fun selectLocation(restaurant: Restaurant) {
        _selectedLocation.value = restaurant
        navigateTo(Screen.Menu)
    }

    // --- Menu Selection ---
    private val _selectedMenuCategory = MutableStateFlow("SANDWICHES")
    val selectedMenuCategory: StateFlow<String> = _selectedMenuCategory.asStateFlow()

    fun setMenuCategory(cat: String) {
        _selectedMenuCategory.value = cat
    }

    val menuItemsForCategory: StateFlow<List<MenuItem>> = _selectedMenuCategory
        .map { cat ->
            repository.getMenuItems().filter { it.category == cat }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Customizable Builder State ---
    private val _builderState = MutableStateFlow(BuilderState())
    val builderState: StateFlow<BuilderState> = _builderState.asStateFlow()

    fun initBuilder(menuItem: MenuItem, category: String) {
        val defaultBread = repository.getBreads().firstOrNull()
        val defaultSize = menuItem.defaultSize ?: "6 Inch"

        _builderState.value = BuilderState(
            itemCategory = category,
            baseItem = menuItem,
            selectedBread = if (category == "SANDWICHES" || category == "BREAKFAST") defaultBread else null,
            selectedSize = defaultSize,
            selectedProteins = repository.getProteins().filter { menuItem.defaultProteins.contains(it.name) },
            selectedCheeses = repository.getCheeses().filter { menuItem.defaultCheeses.contains(it.name) },
            isToasted = menuItem.defaultToasted,
            selectedVegetables = repository.getVegetables().filter { menuItem.defaultVegetables.contains(it.name) },
            selectedSauces = repository.getSauces().filter { menuItem.defaultSauces.contains(it.name) },
            selectedExtras = emptyList(),
            includeMealUpgrade = false
        )
    }

    fun updateBread(bread: IngredientOption) {
        _builderState.update { it.copy(selectedBread = bread) }
    }

    fun updateSize(size: String) {
        _builderState.update { it.copy(selectedSize = size) }
    }

    fun toggleProtein(protein: IngredientOption) {
        _builderState.update { state ->
            val list = state.selectedProteins.toMutableList()
            if (list.any { it.id == protein.id }) list.removeAll { it.id == protein.id }
            else list.add(protein)
            state.copy(selectedProteins = list)
        }
    }

    fun toggleCheese(cheese: IngredientOption) {
        _builderState.update { state ->
            val list = state.selectedCheeses.toMutableList()
            if (list.any { it.id == cheese.id }) list.removeAll { it.id == cheese.id }
            else list.add(cheese)
            state.copy(selectedCheeses = list)
        }
    }

    fun updateToasting(toast: Boolean) {
        _builderState.update { it.copy(isToasted = toast) }
    }

    fun toggleVegetable(veg: IngredientOption) {
        _builderState.update { state ->
            val list = state.selectedVegetables.toMutableList()
            if (list.any { it.id == veg.id }) list.removeAll { it.id == veg.id }
            else list.add(veg)
            state.copy(selectedVegetables = list)
        }
    }

    fun toggleSauce(sauce: IngredientOption) {
        _builderState.update { state ->
            val list = state.selectedSauces.toMutableList()
            if (list.any { it.id == sauce.id }) list.removeAll { it.id == sauce.id }
            else list.add(sauce)
            state.copy(selectedSauces = list)
        }
    }

    fun toggleExtra(extra: IngredientOption) {
        _builderState.update { state ->
            val list = state.selectedExtras.toMutableList()
            if (list.any { it.id == extra.id }) list.removeAll { it.id == extra.id }
            else list.add(extra)
            state.copy(selectedExtras = list)
        }
    }

    fun setMealUpgrade(upgrade: Boolean) {
        val side = if (upgrade) repository.getMenuItems().firstOrNull { it.category == "SIDES" } else null
        val drink = if (upgrade) repository.getMenuItems().firstOrNull { it.category == "DRINKS" } else null
        _builderState.update {
            it.copy(
                includeMealUpgrade = upgrade,
                selectedSide = side,
                selectedDrink = drink
            )
        }
    }

    fun updateSide(side: MenuItem) {
        _builderState.update { it.copy(selectedSide = side) }
    }

    fun updateDrink(drink: MenuItem) {
        _builderState.update { it.copy(selectedDrink = drink) }
    }

    fun updateDrinkSize(size: String) {
        _builderState.update { it.copy(drinkSize = size) }
    }

    // --- Cart Management (Reactive flow) ---
    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotalPrice: StateFlow<Double> = cartItems
        .map { list ->
            val sum = list.sumOf { it.price * it.quantity }
            String.format("%.2f", sum).toDouble()
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartTotalCalories: StateFlow<Int> = cartItems
        .map { list -> list.sumOf { it.calories * it.quantity } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addBuiltItemToCart() {
        val state = _builderState.value
        val name = when (state.itemCategory) {
            "WRAPS" -> state.baseItem?.name ?: "Fresh Custom Wrap"
            "SALADS" -> state.baseItem?.name ?: "Fresh Custom Salad Bowl"
            else -> "${state.selectedSize} ${state.baseItem?.name ?: "Fresh Sub"}"
        }

        viewModelScope.launch {
            repository.addToCart(
                CartItem(
                    itemType = state.itemCategory.removeSuffix("S"), // e.g. "SANDWICH", "WRAP", "SALAD"
                    name = name,
                    baseName = state.selectedBread?.name ?: state.baseItem?.defaultBase ?: "N/A",
                    size = state.selectedSize,
                    proteins = state.selectedProteins.map { it.name },
                    cheeses = state.selectedCheeses.map { it.name },
                    vegetables = state.selectedVegetables.map { it.name },
                    sauces = state.selectedSauces.map { it.name },
                    extras = state.selectedExtras.map { it.name },
                    isToasted = state.isToasted,
                    sideName = if (state.includeMealUpgrade) state.selectedSide?.name else null,
                    drinkName = if (state.includeMealUpgrade) "${state.drinkSize} ${state.selectedDrink?.name}" else null,
                    drinkSize = if (state.includeMealUpgrade) state.drinkSize else null,
                    price = state.calculateTotalPrice(),
                    calories = state.calculateTotalNutrition().calories,
                    quantity = 1
                )
            )
            navigateTo(Screen.Cart)
        }
    }

    fun addMenuItemToCartAsIs(menuItem: MenuItem) {
        viewModelScope.launch {
            repository.addToCart(
                CartItem(
                    itemType = menuItem.category.removeSuffix("S"),
                    name = menuItem.name,
                    baseName = menuItem.defaultBase ?: "N/A",
                    size = menuItem.defaultSize ?: "N/A",
                    proteins = menuItem.defaultProteins,
                    cheeses = menuItem.defaultCheeses,
                    vegetables = menuItem.defaultVegetables,
                    sauces = menuItem.defaultSauces,
                    extras = menuItem.defaultExtras,
                    isToasted = menuItem.defaultToasted,
                    price = menuItem.basePrice,
                    calories = menuItem.baseNutrition.calories,
                    quantity = 1
                )
            )
            navigateTo(Screen.Cart)
        }
    }

    fun removeCartItem(item: CartItem) {
        viewModelScope.launch {
            repository.removeFromCart(item)
        }
    }

    fun updateCartItemQuantity(item: CartItem, newQty: Int) {
        if (newQty <= 0) {
            removeCartItem(item)
        } else {
            viewModelScope.launch {
                repository.updateCartItem(item.copy(quantity = newQty))
            }
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    // --- Smart Deal Engine ---
    // Scans cart and identifies if custom Meal Deal combinations are present
    // Let's implement active proposal if any item is not a deal yet
    val proposedDeal: StateFlow<Deal?> = cartItems
        .map { list ->
            // Check if cart contains sub + side + drink that is not already a combo meal
            val hasSub = list.any { (it.itemType == "SANDWICH" || it.itemType == "WRAP" || it.itemType == "SALAD") && it.sideName == null }
            val hasSide = list.any { it.itemType == "SIDE" }
            val hasDrink = list.any { it.itemType == "DRINK" }
            
            if (hasSub && hasSide && hasDrink) {
                repository.getDeals().firstOrNull { it.id == "deal_1" }
            } else null
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun applyProposedDeal() {
        val deal = proposedDeal.value ?: return
        viewModelScope.launch {
            val items = cartItems.value.toMutableList()
            val subIndex = items.indexOfFirst { (it.itemType == "SANDWICH" || it.itemType == "WRAP" || it.itemType == "SALAD") && it.sideName == null }
            val sideIndex = items.indexOfFirst { it.itemType == "SIDE" }
            val drinkIndex = items.indexOfFirst { it.itemType == "DRINK" }

            if (subIndex != -1 && sideIndex != -1 && drinkIndex != -1) {
                val sub = items[subIndex]
                val side = items[sideIndex]
                val drink = items[drinkIndex]

                // Remove side and drink, bundle them into sub
                repository.removeFromCart(side)
                repository.removeFromCart(drink)
                
                // Upgrade sub with side, drink, and applied deal price
                val bundlePrice = String.format("%.2f", sub.price + side.price + drink.price - deal.saving).toDouble()
                repository.updateCartItem(
                    sub.copy(
                        sideName = side.name,
                        drinkName = drink.name,
                        price = bundlePrice,
                        calories = sub.calories + side.calories + drink.calories,
                        appliedDealId = deal.id
                    )
                )
            }
        }
    }

    // --- Past Orders ---
    val orderHistory: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Real-time Order Tracking State ---
    private val _activeTrackingOrder = MutableStateFlow<Order?>(null)
    val activeTrackingOrder: StateFlow<Order?> = _activeTrackingOrder.asStateFlow()

    fun placeOrder(paymentMethod: String) {
        val total = cartTotalPrice.value
        val items = cartItems.value
        if (items.isEmpty()) return

        // 1. Availability validation check
        val containsUnavailable = items.any { it.name.contains("seasonal", ignoreCase = true) }
        if (containsUnavailable) {
            // Unavailable item check simulation
            return
        }

        val summary = items.joinToString(", ") { "${it.quantity}x ${it.name}" }
        val orderId = "FS-" + (100000..999999).random().toString()
        val loc = selectedLocation.value

        val newOrder = Order(
            id = orderId,
            dateLong = System.currentTimeMillis(),
            itemsSummary = summary,
            totalAmount = total,
            status = "ORDER_RECEIVED",
            orderType = _orderType.value,
            restaurantId = loc.id,
            restaurantName = loc.name
        )

        viewModelScope.launch {
            // Earn loyalty points: 10 points per £1 spent
            val pointsEarned = (total * 10).toInt()
            _userPoints.update { it + pointsEarned }

            repository.placeOrder(newOrder)
            repository.clearCart()
            _activeTrackingOrder.value = newOrder
            navigateTo(Screen.Tracking(orderId))

            // Start order lifecycle simulation in background coroutine!
            simulateOrderStatusUpdates(orderId)
        }
    }

    private fun simulateOrderStatusUpdates(orderId: String) {
        viewModelScope.launch {
            // ORDER_RECEIVED (0 - 4 seconds)
            delay(4000)
            updateTrackingStatus(orderId, "PREPARING")

            // PREPARING (4 - 8 seconds)
            delay(5000)
            updateTrackingStatus(orderId, "READY")

            // READY (8 - 12 seconds)
            delay(5000)
            val finalStatus = if (_orderType.value == "DELIVERY") "DELIVERED" else "COLLECTED"
            updateTrackingStatus(orderId, finalStatus)
        }
    }

    private suspend fun updateTrackingStatus(orderId: String, status: String) {
        repository.updateOrderStatus(orderId, status)
        val currentActive = _activeTrackingOrder.value
        if (currentActive != null && currentActive.id == orderId) {
            _activeTrackingOrder.value = currentActive.copy(status = status)
        }
    }

    // --- Redeem Rewards ---
    fun redeemReward(reward: Reward) {
        val current = _userPoints.value
        if (current >= reward.pointsCost) {
            _userPoints.value = current - reward.pointsCost
            viewModelScope.launch {
                // Add the rewarded item to cart with a price of £0.00!
                val cat = when (reward.id) {
                    "rew_cookie" -> "COOKIES"
                    "rew_drink" -> "DRINKS"
                    "rew_side" -> "SIDES"
                    else -> "SANDWICHES"
                }
                val menuItem = repository.getMenuItems().firstOrNull { it.category == cat }
                menuItem?.let {
                    repository.addToCart(
                        CartItem(
                            itemType = cat.removeSuffix("S"),
                            name = "[REWARD] " + it.name,
                            baseName = it.defaultBase ?: "N/A",
                            size = it.defaultSize ?: "N/A",
                            price = 0.00,
                            calories = it.baseNutrition.calories,
                            quantity = 1,
                            appliedDealId = "REWARD"
                        )
                    )
                }
                navigateTo(Screen.Cart)
            }
        }
    }

    fun reorder(order: Order) {
        viewModelScope.launch {
            val menu = repository.getMenuItems()
            val parts = order.itemsSummary.split(",")
            parts.forEach { part ->
                val trimmed = part.trim()
                val match = menu.firstOrNull { trimmed.contains(it.name, ignoreCase = true) }
                if (match != null) {
                    repository.addToCart(
                        CartItem(
                            itemType = match.category.removeSuffix("S"),
                            name = match.name,
                            baseName = match.defaultBase ?: "N/A",
                            size = match.defaultSize ?: "N/A",
                            proteins = match.defaultProteins,
                            cheeses = match.defaultCheeses,
                            vegetables = match.defaultVegetables,
                            sauces = match.defaultSauces,
                            extras = match.defaultExtras,
                            isToasted = match.defaultToasted,
                            price = match.basePrice,
                            calories = match.baseNutrition.calories,
                            quantity = 1
                        )
                    )
                }
            }
            navigateTo(Screen.Cart)
        }
    }

    // List of Ingredients helper methods
    fun getMenuItems() = repository.getMenuItems()
    fun getDeals() = repository.getDeals()
    fun getBreads() = repository.getBreads()
    fun getProteins() = repository.getProteins()
    fun getCheeses() = repository.getCheeses()
    fun getVegetables() = repository.getVegetables()
    fun getSauces() = repository.getSauces()
    fun getExtras() = repository.getExtras()
    fun getRewards() = repository.getRewards()
}
