package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import com.example.ui.components.FreshSubBottomNav
import com.example.ui.components.FreshSubHeader
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.FreshSubViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize our ViewModel with constructor injection inside Compose
                val viewModel: FreshSubViewModel = androidx.lifecycle.viewmodel.compose.viewModel()

                val currentScreen = viewModel.currentScreen.collectAsState()
                val selectedLoc = viewModel.selectedLocation.collectAsState()
                val cartItems = viewModel.cartItems.collectAsState()
                
                // Track total quantity of items in shopping bag
                val cartItemCount = cartItems.value.sumOf { it.quantity }

                // Determine active navigation bottom tab based on current screen
                val activeTab = when (currentScreen.value) {
                    is Screen.Home -> "home"
                    is Screen.LocationSelect -> "location"
                    is Screen.Menu -> "menu"
                    is Screen.Rewards -> "rewards"
                    is Screen.Cart -> "cart"
                    else -> ""
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        // Global top action bar
                        FreshSubHeader(
                            title = when (currentScreen.value) {
                                is Screen.Home -> "FreshSub"
                                is Screen.LocationSelect -> "Store Locator"
                                is Screen.Menu -> "Our Menu"
                                is Screen.Builder -> "Custom Sub"
                                is Screen.Cart -> "Your Bag"
                                is Screen.Checkout -> "Checkout"
                                is Screen.Tracking -> "Order Tracker"
                                is Screen.Rewards -> "Loyalty Rewards"
                                is Screen.Account -> "My Profile"
                            },
                            subtitle = if (currentScreen.value is Screen.Home || currentScreen.value is Screen.Menu) {
                                selectedLoc.value.name
                            } else null,
                            onBackClick = if (currentScreen.value != Screen.Home) {
                                { viewModel.navigateBack() }
                            } else null,
                            onCartClick = if (currentScreen.value != Screen.Cart && currentScreen.value != Screen.Checkout) {
                                { viewModel.navigateTo(Screen.Cart) }
                            } else null,
                            cartItemCount = cartItemCount,
                            onAccountClick = if (currentScreen.value != Screen.Account) {
                                { viewModel.navigateTo(Screen.Account) }
                            } else null
                        )
                    },
                    bottomBar = {
                        // Render bottom navigation bar on primary main tab destinations
                        if (currentScreen.value is Screen.Home || 
                            currentScreen.value is Screen.LocationSelect || 
                            currentScreen.value is Screen.Menu || 
                            currentScreen.value is Screen.Rewards || 
                            currentScreen.value is Screen.Cart
                        ) {
                            FreshSubBottomNav(
                                activeTab = activeTab,
                                onTabSelected = { tabId ->
                                    val target = when (tabId) {
                                        "home" -> Screen.Home
                                        "location" -> Screen.LocationSelect
                                        "menu" -> Screen.Menu
                                        "rewards" -> Screen.Rewards
                                        "cart" -> Screen.Cart
                                        else -> Screen.Home
                                    }
                                    if (currentScreen.value != target) {
                                        viewModel.navigateTo(target)
                                    }
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    // Main Screen Router
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (val screen = currentScreen.value) {
                            is Screen.Home -> {
                                HomeScreen(viewModel = viewModel)
                            }
                            is Screen.LocationSelect -> {
                                LocationScreen(viewModel = viewModel)
                            }
                            is Screen.Menu -> {
                                MenuScreen(viewModel = viewModel)
                            }
                            is Screen.Builder -> {
                                BuilderScreen(viewModel = viewModel)
                            }
                            is Screen.Cart -> {
                                CartScreen(viewModel = viewModel)
                            }
                            is Screen.Checkout -> {
                                CheckoutScreen(viewModel = viewModel)
                            }
                            is Screen.Tracking -> {
                                TrackingScreen(
                                    viewModel = viewModel,
                                    orderId = screen.orderId
                                )
                            }
                            is Screen.Rewards -> {
                                RewardsScreen(viewModel = viewModel)
                            }
                            is Screen.Account -> {
                                AccountScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
