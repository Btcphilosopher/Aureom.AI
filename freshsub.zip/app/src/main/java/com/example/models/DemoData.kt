package com.example.models

object DemoData {

    // 15+ Bread Options
    val breads = listOf(
        IngredientOption("br_white", "Italian White", "BREAD", 0.0, Nutrition(160, 5, 32, 2, 280)),
        IngredientOption("br_multigrain", "Hearty Multigrain", "BREAD", 0.0, Nutrition(180, 7, 34, 2, 310)),
        IngredientOption("br_herbs", "Italian Herbs & Cheese", "BREAD", 0.40, Nutrition(220, 8, 35, 5, 420)),
        IngredientOption("br_honey_oat", "Honey Oat", "BREAD", 0.30, Nutrition(190, 6, 38, 3, 300)),
        IngredientOption("br_flat", "Artisanal Flatbread", "BREAD", 0.0, Nutrition(150, 4, 29, 2, 290)),
        IngredientOption("br_gluten_free", "Gluten-Free Bread", "BREAD", 1.00, Nutrition(160, 2, 30, 4, 260), isPremium = true),
        IngredientOption("br_jalapeno", "Jalapeno Cheddar", "BREAD", 0.40, Nutrition(230, 9, 34, 6, 450)),
        IngredientOption("br_sourdough", "Sourdough", "BREAD", 0.20, Nutrition(170, 5, 33, 1, 310)),
        IngredientOption("br_rye", "Marbled Rye", "BREAD", 0.20, Nutrition(160, 6, 32, 2, 340)),
        IngredientOption("br_brioche", "Brioche Sub Bun", "BREAD", 0.50, Nutrition(210, 6, 30, 7, 320)),
        IngredientOption("br_ciabatta", "Artisan Ciabatta", "BREAD", 0.40, Nutrition(180, 5, 35, 2, 350)),
        IngredientOption("br_sesame", "Toasted Sesame", "BREAD", 0.10, Nutrition(170, 5, 33, 3, 290)),
        IngredientOption("br_garlic", "Garlic Butter Crust", "BREAD", 0.30, Nutrition(200, 6, 32, 5, 380)),
        IngredientOption("br_cheese_or", "Cheese & Oregano", "BREAD", 0.30, Nutrition(210, 7, 34, 5, 400)),
        IngredientOption("br_spinach_f", "Spinach Herb Crust", "BREAD", 0.20, Nutrition(170, 5, 32, 2, 300)),
        IngredientOption("br_parm", "Parmesan Oregano", "BREAD", 0.30, Nutrition(210, 7, 33, 5, 390))
    )

    // Proteins (12+)
    val proteins = listOf(
        IngredientOption("pr_chicken", "Oven Roasted Chicken", "PROTEIN", 1.50, Nutrition(120, 23, 1, 2, 480)),
        IngredientOption("pr_teriyaki", "Chicken Teriyaki Strips", "PROTEIN", 1.80, Nutrition(160, 21, 10, 3, 620)),
        IngredientOption("pr_turkey", "Sliced Turkey Breast", "PROTEIN", 1.30, Nutrition(80, 15, 2, 1, 450)),
        IngredientOption("pr_beef", "Sliced Roast Beef", "PROTEIN", 2.00, Nutrition(110, 19, 1, 3, 390)),
        IngredientOption("pr_ham", "Black Forest Ham", "PROTEIN", 1.20, Nutrition(90, 14, 2, 2, 580)),
        IngredientOption("pr_steak", "Shaved Steak Strips", "PROTEIN", 2.20, Nutrition(150, 22, 2, 6, 520)),
        IngredientOption("pr_tuna", "Tuna Mayonnaise", "PROTEIN", 1.50, Nutrition(250, 16, 1, 20, 380)),
        IngredientOption("pr_salami", "Genoa Salami", "PROTEIN", 1.00, Nutrition(110, 6, 1, 9, 430)),
        IngredientOption("pr_pepperoni", "Spicy Pepperoni", "PROTEIN", 1.00, Nutrition(120, 5, 1, 11, 490)),
        IngredientOption("pr_veggie_p", "Signature Veggie Patty", "PROTEIN", 1.20, Nutrition(160, 12, 18, 5, 350)),
        IngredientOption("pr_meatball", "Italian Marinara Meatballs", "PROTEIN", 1.80, Nutrition(240, 14, 12, 14, 690)),
        IngredientOption("pr_plant_t", "Plant-Based Tikka Strips", "PROTEIN", 1.80, Nutrition(140, 18, 6, 4, 410))
    )

    // Cheeses (8+)
    val cheeses = listOf(
        IngredientOption("ch_cheddar", "Mature Cheddar", "CHEESE", 0.0, Nutrition(60, 4, 0, 5, 120)),
        IngredientOption("ch_american", "Processed American Slices", "CHEESE", 0.0, Nutrition(50, 3, 1, 4, 230)),
        IngredientOption("ch_mozzarella", "Fresh Shredded Mozzarella", "CHEESE", 0.30, Nutrition(70, 5, 1, 5, 110)),
        IngredientOption("ch_pepperjack", "Spicy Pepperjack", "CHEESE", 0.20, Nutrition(60, 4, 0, 5, 130)),
        IngredientOption("ch_provolone", "Sharp Provolone", "CHEESE", 0.20, Nutrition(60, 4, 0, 5, 140)),
        IngredientOption("ch_swiss", "Creamy Swiss", "CHEESE", 0.20, Nutrition(60, 5, 0, 5, 80)),
        IngredientOption("ch_feta", "Crumbled Greek Feta", "CHEESE", 0.40, Nutrition(50, 3, 1, 4, 190)),
        IngredientOption("ch_vegan", "Plant-Based Mozzarella Style", "CHEESE", 0.50, Nutrition(60, 0, 5, 4, 150))
    )

    // Vegetables (15+ Options)
    val vegetables = listOf(
        IngredientOption("vg_lettuce", "Crisp Iceberg Lettuce", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 5)),
        IngredientOption("vg_spinach", "Baby Spinach Leaves", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 10)),
        IngredientOption("vg_tomato", "Vine-Ripened Tomato Slices", "VEGETABLE", 0.0, Nutrition(10, 0, 2, 0, 5)),
        IngredientOption("vg_cucumber", "Fresh Sliced Cucumber", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 2)),
        IngredientOption("vg_onion", "Red Onions", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 2)),
        IngredientOption("vg_peppers", "Mixed Bell Peppers", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 2)),
        IngredientOption("vg_pickles", "Tangy Dill Pickles", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 110)),
        IngredientOption("vg_olives", "Black Sliced Olives", "VEGETABLE", 0.0, Nutrition(15, 0, 1, 1, 60)),
        IngredientOption("vg_jalapenos", "Spicy Jalapeños", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 90)),
        IngredientOption("vg_sweetcorn", "Golden Sweetcorn", "VEGETABLE", 0.0, Nutrition(20, 1, 4, 0, 10)),
        IngredientOption("vg_crisp_o", "Crispy Fried Onions", "VEGETABLE", 0.30, Nutrition(45, 1, 5, 3, 50)),
        IngredientOption("vg_beetroot", "Shredded Beetroot", "VEGETABLE", 0.0, Nutrition(10, 0, 2, 0, 15)),
        IngredientOption("vg_carrots", "Julienne Carrots", "VEGETABLE", 0.0, Nutrition(10, 0, 2, 0, 15)),
        IngredientOption("vg_cabbage", "Red Cabbage Slaw", "VEGETABLE", 0.0, Nutrition(15, 0, 3, 0, 10)),
        IngredientOption("vg_cilantro", "Fresh Cilantro Leaves", "VEGETABLE", 0.0, Nutrition(2, 0, 0, 0, 1)),
        IngredientOption("vg_banana_p", "Mild Banana Peppers", "VEGETABLE", 0.0, Nutrition(5, 0, 1, 0, 85))
    )

    // Sauces (20+ Options)
    val sauces = listOf(
        IngredientOption("sc_mayo", "Real Mayonnaise", "SAUCE", 0.0, Nutrition(100, 0, 1, 11, 70)),
        IngredientOption("sc_l_mayo", "Light Mayonnaise", "SAUCE", 0.0, Nutrition(50, 0, 2, 5, 90)),
        IngredientOption("sc_mustard", "Yellow Mustard", "SAUCE", 0.0, Nutrition(10, 0, 1, 1, 120)),
        IngredientOption("sc_h_mustard", "Honey Mustard", "SAUCE", 0.0, Nutrition(40, 0, 6, 2, 110)),
        IngredientOption("sc_bbq", "Smoky Hickory BBQ", "SAUCE", 0.0, Nutrition(50, 0, 12, 0, 150)),
        IngredientOption("sc_southwest", "Chipotle Southwest", "SAUCE", 0.0, Nutrition(90, 1, 2, 9, 140)),
        IngredientOption("sc_ranch", "Creamy Buttermilk Ranch", "SAUCE", 0.0, Nutrition(80, 0, 1, 8, 160)),
        IngredientOption("sc_sriracha", "Spicy Sriracha Chilli", "SAUCE", 0.0, Nutrition(35, 0, 7, 1, 220)),
        IngredientOption("sc_sweet_o", "Sweet Onion Teriyaki", "SAUCE", 0.0, Nutrition(40, 0, 9, 0, 100)),
        IngredientOption("sc_caesar", "Creamy Garlic Caesar", "SAUCE", 0.0, Nutrition(90, 1, 1, 9, 180)),
        IngredientOption("sc_marinara", "Zesty Herb Marinara", "SAUCE", 0.0, Nutrition(30, 1, 5, 1, 120)),
        IngredientOption("sc_garlic_ao", "Roasted Garlic Aioli", "SAUCE", 0.0, Nutrition(90, 0, 2, 9, 110)),
        IngredientOption("sc_blue", "Chunky Blue Cheese", "SAUCE", 0.10, Nutrition(100, 1, 2, 10, 210)),
        IngredientOption("sc_thousand", "Classic Thousand Island", "SAUCE", 0.0, Nutrition(80, 0, 4, 7, 130)),
        IngredientOption("sc_sweet_ch", "Sweet Thai Chilli", "SAUCE", 0.0, Nutrition(60, 0, 15, 0, 140)),
        IngredientOption("sc_vinegar", "Red Wine Vinegar", "SAUCE", 0.0, Nutrition(2, 0, 0, 0, 0)),
        IngredientOption("sc_oil", "Extra Virgin Olive Oil", "SAUCE", 0.0, Nutrition(120, 0, 0, 14, 0)),
        IngredientOption("sc_pesto", "Basil Pesto Drizzle", "SAUCE", 0.20, Nutrition(90, 1, 1, 9, 150)),
        IngredientOption("sc_buffalo", "Tangy Buffalo Sauce", "SAUCE", 0.0, Nutrition(15, 0, 1, 1, 380)),
        IngredientOption("sc_herb_d", "Garlic & Herb Vinaigrette", "SAUCE", 0.0, Nutrition(60, 0, 2, 6, 120)),
        IngredientOption("sc_tzatziki", "Cool Cucumber Tzatziki", "SAUCE", 0.10, Nutrition(30, 1, 2, 2, 95))
    )

    // Extras
    val extras = listOf(
        IngredientOption("ex_double_m", "Double Protein", "EXTRA", 2.50, Nutrition(120, 15, 2, 4, 350)),
        IngredientOption("ex_cheese", "Extra Cheese Slice", "EXTRA", 0.60, Nutrition(60, 4, 0, 5, 120)),
        IngredientOption("ex_bacon", "Smoked Bacon Strips (2)", "EXTRA", 1.20, Nutrition(80, 6, 0, 7, 240)),
        IngredientOption("ex_guac", "Crushed Avocado Guacamole", "EXTRA", 1.50, Nutrition(70, 1, 3, 6, 105)),
        IngredientOption("ex_pepperoni", "Pepperoni Topping (4)", "EXTRA", 0.80, Nutrition(90, 4, 0, 8, 310)),
        IngredientOption("ex_hash", "Crispy Hashbrowns (2)", "EXTRA", 1.00, Nutrition(140, 2, 16, 8, 290))
    )

    // 20+ Fictional Restaurants
    val restaurants = listOf(
        Restaurant("rest_1", "FreshSub - Downtown Square", "128 Main Street, City Centre", 0.4, true, "7:00 AM - 10:00 PM", prepTimeMinutes = 8, city = "London", postcode = "EC1A 1BB", isFavourite = true),
        Restaurant("rest_2", "FreshSub - Central Terminal", "Platform 4, Grand Central Station", 0.8, true, "6:00 AM - 11:00 PM", prepTimeMinutes = 5, city = "London", postcode = "W1D 1AA"),
        Restaurant("rest_3", "FreshSub - Financial District", "45 Canary Wharf Plaza", 1.2, true, "7:30 AM - 8:00 PM", prepTimeMinutes = 10, city = "London", postcode = "E14 5AB"),
        Restaurant("rest_4", "FreshSub - University Campus", "Student Union Building, Block B", 2.1, false, "8:00 AM - 6:00 PM", prepTimeMinutes = 12, city = "London", postcode = "WC1E 7HU"),
        Restaurant("rest_5", "FreshSub - West End Boulevard", "92 Shaftesbury Avenue", 1.5, true, "10:00 AM - Midnight", prepTimeMinutes = 7, city = "London", postcode = "W1D 5AY"),
        Restaurant("rest_6", "FreshSub - Greenwich Reach", "8 Cutty Sark Gardens", 4.3, true, "9:00 AM - 9:00 PM", prepTimeMinutes = 9, city = "London", postcode = "SE10 9HT"),
        Restaurant("rest_7", "FreshSub - Tech Hub Shoreditch", "16 Great Eastern St", 1.7, true, "8:00 AM - 10:00 PM", prepTimeMinutes = 8, city = "London", postcode = "EC2A 3EH"),
        Restaurant("rest_8", "FreshSub - Kensington High", "214 Kensington High St", 3.2, true, "8:00 AM - 9:30 PM", prepTimeMinutes = 10, city = "London", postcode = "W8 7RG"),
        Restaurant("rest_9", "FreshSub - Islington Village", "64 Upper Street", 2.9, true, "9:00 AM - 10:00 PM", prepTimeMinutes = 8, city = "London", postcode = "N1 0NY"),
        Restaurant("rest_10", "FreshSub - Camden Lock", "Locks Market, Unit 12", 3.5, true, "10:00 AM - 8:00 PM", prepTimeMinutes = 11, city = "London", postcode = "NW1 8AF"),
        Restaurant("rest_11", "FreshSub - Piccadilly Hub", "22 Regent Street", 1.1, true, "Open 24 Hours", prepTimeMinutes = 6, city = "London", postcode = "SW1Y 4PH"),
        Restaurant("rest_12", "FreshSub - Soho Lounge", "14 Wardour Street", 1.3, true, "9:00 AM - 11:00 PM", prepTimeMinutes = 7, city = "London", postcode = "W1D 6QF"),
        Restaurant("rest_13", "FreshSub - Westminster Central", "3 Parliament Square", 1.8, true, "7:00 AM - 9:00 PM", prepTimeMinutes = 9, city = "London", postcode = "SW1A 0AA"),
        Restaurant("rest_14", "FreshSub - Chelsea Boulevard", "155 King's Road", 3.7, true, "8:00 AM - 10:00 PM", prepTimeMinutes = 10, city = "London", postcode = "SW3 5TX"),
        Restaurant("rest_15", "FreshSub - Paddington Canal", "2 Basin Approach", 2.8, true, "7:00 AM - 9:30 PM", prepTimeMinutes = 7, city = "London", postcode = "W2 1AF"),
        Restaurant("rest_16", "FreshSub - King's Cross Galleria", "Euston Road Concourse", 2.2, true, "5:30 AM - 11:00 PM", prepTimeMinutes = 5, city = "London", postcode = "N1C 4AL"),
        Restaurant("rest_17", "FreshSub - Battersea Gardens", "Power Station, Circus West", 3.1, true, "9:00 AM - 10:00 PM", prepTimeMinutes = 9, city = "London", postcode = "SW11 8AL"),
        Restaurant("rest_18", "FreshSub - Heathrow Express", "Terminal 5 Departures", 14.5, true, "4:00 AM - 10:00 PM", prepTimeMinutes = 4, city = "London", postcode = "TW6 2GA"),
        Restaurant("rest_19", "FreshSub - Stratford Gate", "Westfield Avenue, Lower Level", 5.8, true, "9:00 AM - 10:30 PM", prepTimeMinutes = 8, city = "London", postcode = "E20 1EH"),
        Restaurant("rest_20", "FreshSub - Brixton Arches", "400 Coldharbour Lane", 4.9, true, "10:00 AM - 11:00 PM", prepTimeMinutes = 9, city = "London", postcode = "SW9 8LF")
    )

    // 30+ Programmatic Deals
    val deals = listOf(
        Deal("deal_1", "Fresh Meal Upgrade", "Add any side and drink to your sub for a special combo price, saving you up to £2.50!", 11.20, 8.99, 2.21, "Exp. 31/12/2026", "MEAL_DEAL"),
        Deal("deal_2", "Double Sub Footlong Feast", "Two Footlong Subs (Chicken/Turkey/BMT) for a perfect share meal.", 19.80, 15.99, 3.81, "Exp. 31/12/2026", "FAMILY_DEAL"),
        Deal("deal_3", "QSR Lunch Rush", "Any 6-inch Sub plus a cookie and small drink between 11 AM and 2 PM.", 8.50, 6.49, 2.01, "Exp. 31/10/2026", "LUNCH_DEAL"),
        Deal("deal_4", "App Exclusive - Free Double Meat", "Unlocks double protein on any Footlong Sub ordered via app.", 11.50, 8.99, 2.51, "Exp. Next Sunday", "APP_EXCLUSIVE"),
        Deal("deal_5", "Midweek Cookie Bundle", "Four freshly baked cookies of your choice for a sweet discount.", 5.20, 3.99, 1.21, "Exp. Wednesday Only", "APP_EXCLUSIVE"),
        Deal("deal_6", "Ultimate Wrap & Drink Combo", "Any wrap plus a regular drink for a light, delicious bite.", 8.40, 6.99, 1.41, "Exp. 30/11/2026", "MEAL_DEAL"),
        Deal("deal_7", "Vegan Sub Saver", "Get our signature Plant-Based Tikka Sub at a special promotional rate.", 7.50, 5.99, 1.51, "Exp. 31/12/2026", "APP_EXCLUSIVE"),
        Deal("deal_8", "Family Feast Bundle", "Two Footlongs, two 6-inch kids subs, four cookies, and four drinks.", 38.00, 29.99, 8.01, "Exp. 31/12/2026", "FAMILY_DEAL"),
        Deal("deal_9", "Breakfast Sub Combo", "Any breakfast sub (egg, bacon, cheese) and a hot coffee.", 6.20, 4.49, 1.71, "Exp. Daily 11 AM", "LUNCH_DEAL"),
        Deal("deal_10", "Salad Bowl Combo", "Any fresh customization salad bowl plus bottled spring water.", 9.00, 7.49, 1.51, "Exp. 30/11/2026", "MEAL_DEAL")
    ) + List(20) { index ->
        // Generate remaining 20 deals programmatically to hit 30+ deal options
        val idNum = index + 11
        val isOdd = index % 2 == 0
        val dealType = if (isOdd) "APP_EXCLUSIVE" else "LUNCH_DEAL"
        val saving = 1.0 + (index * 0.15)
        val orig = 7.50 + (index * 0.5)
        val dp = orig - saving
        Deal(
            id = "deal_$idNum",
            title = "Promo Voucher #$index",
            description = "Special limited-time promotional discount on selected gourmet selections.",
            originalPrice = String.format("%.2f", orig).toDouble(),
            dealPrice = String.format("%.2f", dp).toDouble(),
            saving = String.format("%.2f", saving).toDouble(),
            expiryDate = "Exp. 30 days",
            type = dealType
        )
    }

    // 100+ Menu Items across various Subway-inspired categories
    val menuItems: List<MenuItem> by lazy {
        val list = mutableListOf<MenuItem>()

        // 1. SANDWICHES (30+ items)
        val sandwichBases = listOf(
            Triple("Classic Oven Roasted Chicken", "Our signature chicken breast, roasted to juicy perfection.", 5.80),
            Triple("Fresh Teriyaki Chicken", "Tender chicken strips glazed in sticky, savory teriyaki glaze.", 6.20),
            Triple("The Italian B.M.T. Legend", "Classic pepperoni, salami, and smoked black forest ham.", 5.90),
            Triple("Spicy Southwest Steak", "Shaved tender steak with cheese and chipotle kick.", 6.50),
            Triple("Smoked Ham Classic", "Rich black forest ham piled high on freshly baked bread.", 5.20),
            Triple("The Turkey & Ham Club", "Premium sliced turkey breast and smoked ham with bacon.", 6.10),
            Triple("Gourmet Sliced Turkey", "Lean, premium sliced turkey breast - simple and fresh.", 5.50),
            Triple("Classic Creamy Tuna Mayo", "Flaked tuna chunks blended with smooth real mayonnaise.", 5.60),
            Triple("Signature Meatball Marinara", "Juicy meatballs simmered in a rich, zesty Italian tomato sauce.", 5.80),
            Triple("Ultimate Veggie Delight", "A crisp, colorful rainbow of fresh garden vegetables.", 4.50),
            Triple("The Garden Veggie Patty", "Hearty veggie patty seasoned with fine herbs and spices.", 5.40),
            Triple("Vegan Tikka Supreme", "Plant-based soy tikka strips with delicious mild spice.", 6.00),
            Triple("Bacon, Lettuce & Tomato", "Smoked bacon strips, crisp lettuce, and fresh tomatoes.", 5.30),
            Triple("Steak & Mature Cheddar", "Shaved steak slices smothered in creamy melted cheddar.", 6.60),
            Triple("The Spicy Pepperoni Melt", "Double loaded spicy pepperoni with melted mozzarella.", 5.40)
        )

        // Generate 30 sandwiches using bases + generated variations
        sandwichBases.forEachIndexed { i, base ->
            list.add(
                MenuItem(
                    id = "sub_${i}_6",
                    name = base.first + " (6\")",
                    description = base.second,
                    category = "SANDWICHES",
                    basePrice = base.third,
                    baseNutrition = Nutrition(280 + (i * 15), 18 + (i % 5), 40, 6 + (i % 3), 550 + (i * 20)),
                    defaultBase = "Italian White",
                    defaultSize = "6 Inch",
                    defaultProteins = if (base.first.contains("Chicken")) listOf("Oven Roasted Chicken") else emptyList(),
                    isCustomizable = true
                )
            )
            list.add(
                MenuItem(
                    id = "sub_${i}_12",
                    name = base.first + " (Footlong)",
                    description = base.second + " Double the size, double the fresh toppings.",
                    category = "SANDWICHES",
                    basePrice = base.third * 1.7,
                    baseNutrition = Nutrition(560 + (i * 30), 36 + (i % 5) * 2, 80, 12 + (i % 3) * 2, 1100 + (i * 40)),
                    defaultBase = "Hearty Multigrain",
                    defaultSize = "Footlong",
                    isCustomizable = true
                )
            )
        }

        // 2. WRAPS (15+ items)
        val wrapBases = listOf(
            Triple("Chicken Caesar Wrap", "Roasted chicken with crisp lettuce, parmesan, and Caesar dressing.", 6.40),
            Triple("Southwest Steak Wrap", "Steak strips, mixed peppers, onions, cheese, and Southwest sauce.", 6.80),
            Triple("Turkey Bacon Avocado Wrap", "Sliced turkey, smoked bacon, fresh guacamole, and ranch.", 6.90),
            Triple("Spicy Falafel Wrap", "Crisp falafel, spinach, cucumbers, tomatoes, and cool tzatziki.", 5.90),
            Triple("Tuna Cucumber Crunch Wrap", "Tuna mayo, cucumber slices, crisp lettuce, and light vinaigrette.", 6.10),
            Triple("BBQ Plant Tikka Wrap", "Plant-based tikka, crispy fried onions, sweet BBQ sauce, and spinach.", 6.50),
            Triple("Classic Ham & Cheese Wrap", "Black forest ham, mature cheddar, tomatoes, and mayonnaise.", 5.80)
        )

        wrapBases.forEachIndexed { i, base ->
            list.add(
                MenuItem(
                    id = "wrap_${i}_std",
                    name = base.first,
                    description = base.second,
                    category = "WRAPS",
                    basePrice = base.third,
                    baseNutrition = Nutrition(350 + (i * 10), 22 + (i % 4), 38, 9 + (i % 3), 620 + (i * 15)),
                    defaultBase = "Spinach Wrap",
                    isCustomizable = true
                )
            )
            // Wrap variations
            list.add(
                MenuItem(
                    id = "wrap_${i}_spicy",
                    name = "Spicy " + base.first,
                    description = base.second + " Infused with jalapeños and extra sriracha sauce.",
                    category = "WRAPS",
                    basePrice = base.third + 0.30,
                    baseNutrition = Nutrition(360 + (i * 10), 22 + (i % 4), 39, 9 + (i % 3), 750 + (i * 15)),
                    defaultBase = "Tomato Basil Wrap",
                    isCustomizable = true
                )
            )
        }

        // 3. SALADS (15+ items)
        val saladBases = listOf(
            Triple("Gourmet Chicken Salad Bowl", "Juicy roasted chicken breast on a rich bed of garden salad.", 6.99),
            Triple("Italian B.M.T. Antipasto Salad", "Pepperoni, salami, ham, cheese, olives, and herb vinaigrette.", 7.20),
            Triple("Teriyaki Glazed Chicken Salad", "Chicken teriyaki, cucumbers, red onions, sweetcorn, and sesame.", 7.40),
            Triple("Shaved Steak & Cheese Bowl", "Steak strips, melted cheddar, bell peppers, tomatoes, and garlic aioli.", 7.80),
            Triple("Mediterranean Falafel Salad", "Warm falafel, feta cheese, black olives, vine tomatoes, and tzatziki.", 6.80),
            Triple("Rainbow Veggie Delight Bowl", "A generous combination of all our fresh garden vegetables.", 5.50),
            Triple("Zesty Tuna Mayo Salad", "Tuna mayonnaise, celery crunch, sweetcorn, lettuce, and tomatoes.", 6.60)
        )

        saladBases.forEachIndexed { i, base ->
            list.add(
                MenuItem(
                    id = "salad_${i}_std",
                    name = base.first,
                    description = base.second,
                    category = "SALADS",
                    basePrice = base.third,
                    baseNutrition = Nutrition(120 + (i * 15), 15 + (i % 4), 12, 4 + (i % 3), 320 + (i * 20)),
                    defaultBase = "Lettuce Salad Base",
                    isCustomizable = true
                )
            )
            list.add(
                MenuItem(
                    id = "salad_${i}_double",
                    name = "Double " + base.first,
                    description = base.second + " Loaded with double portions of premium protein.",
                    category = "SALADS",
                    basePrice = base.third + 1.99,
                    baseNutrition = Nutrition(240 + (i * 15), 30 + (i % 4), 14, 8 + (i % 3), 540 + (i * 20)),
                    defaultBase = "Spinach Salad Base",
                    isCustomizable = true
                )
            )
        }

        // 4. BREAKFAST (10+ items)
        val bfastBases = listOf(
            Triple("Egg & Cheese Breakfast Sub", "Fluffy scrambled egg patties and melted cheddar.", 3.80),
            Triple("Bacon, Egg & Cheese Sub", "Crispy smoked bacon strips, scrambled eggs, and cheese.", 4.20),
            Triple("Sausage, Egg & Cheese Sub", "Hearty breakfast pork sausage patties, scrambled eggs, and cheese.", 4.40),
            Triple("The Mega Breakfast Melt", "Sausage, bacon, ham, scrambled eggs, double cheddar, toasted.", 4.99),
            Triple("Veggie Egg White & Cheese Sub", "Fluffy egg whites, baby spinach, tomatoes, and Swiss cheese.", 3.99)
        )
        bfastBases.forEachIndexed { i, base ->
            list.add(
                MenuItem(
                    id = "bfast_${i}_6",
                    name = base.first + " (6\")",
                    description = base.second + " A perfect energetic start to your morning.",
                    category = "BREAKFAST",
                    basePrice = base.third,
                    baseNutrition = Nutrition(310 + (i * 15), 16, 35, 10, 680),
                    defaultBase = "Italian White",
                    defaultSize = "6 Inch",
                    isCustomizable = true
                )
            )
            list.add(
                MenuItem(
                    id = "bfast_${i}_flat",
                    name = base.first + " on Flatbread",
                    description = base.second + " Served toasted on soft, warm artisanal flatbread.",
                    category = "BREAKFAST",
                    basePrice = base.third + 0.20,
                    baseNutrition = Nutrition(290 + (i * 15), 14, 32, 9, 640),
                    defaultBase = "Artisanal Flatbread",
                    isCustomizable = true
                )
            )
        }

        // 5. SIDES (10+ items)
        val sides = listOf(
            Triple("Crinkle Cut Potato Chips (Salted)", "Crisp, premium quality lightly salted potato crisps.", 1.20),
            Triple("Chipotle Southwest BBQ Chips", "Bold, smoky chipotle seasoned potato chips.", 1.20),
            Triple("Sour Cream & Chive Baked Chips", "Rich sour cream flavor with subtle chive accents.", 1.25),
            Triple("Warm Toasted Hash Browns (4)", "Four golden, crispy hash browns with a side dip.", 1.50),
            Triple("Fresh Apple Slices Pack", "Crisp, sweet, organic fresh apple slices.", 1.40),
            Triple("Creamy Red Onion Coleslaw", "Freshly shredded cabbage and carrot in creamy mayo.", 1.80),
            Triple("Warm Garlic Dough Bites (3)", "Three toasted dough bites brushed with rich garlic butter.", 1.99),
            Triple("Mozzarella Cheesy Dough Twists", "Two braided dough twists loaded with baked mozzarella.", 2.49),
            Triple("Crisp Side Salad", "A mini portion of lettuce, cucumbers, and tomatoes.", 1.50),
            Triple("Creamy Avocado Dip", "Fresh mashed guacamole dip pot.", 1.20)
        )
        sides.forEachIndexed { i, side ->
            list.add(
                MenuItem(
                    id = "side_${i}",
                    name = side.first,
                    description = side.second,
                    category = "SIDES",
                    basePrice = side.third,
                    baseNutrition = Nutrition(120 + (i * 20), 2, 15 + (i * 2), 4 + (i % 3), 150 + (indexMultiplier(i) * 30)),
                    isCustomizable = false
                )
            )
        }

        // 6. COOKIES & DESSERTS (10+ items)
        val cookies = listOf(
            Triple("Chocolate Chip Cookie", "Our legendary freshly baked cookie loaded with milk chocolate chips.", 0.99),
            Triple("Double Chocolate Chunk Cookie", "A rich cocoa cookie loaded with dark chocolate chunks.", 0.99),
            Triple("Raspberry Cheesecake Cookie", "Sweet, tangy raspberry pieces with white chocolate chunks.", 0.99),
            Triple("Oatmeal Raisin Cookie", "Classic chewy oats combined with sweet plump raisins.", 0.99),
            Triple("White Chip Macadamia Cookie", "Crunchy macadamia nuts paired with creamy white chips.", 1.10),
            Triple("Double Cookie Pack", "Choose any two of our freshly baked signature cookies.", 1.80),
            Triple("Sweet Trio Cookie Bundle", "Any three cookies of your choice for a delightful sweet treat.", 2.50),
            Triple("Rainbow Candy Sugar Cookie", "Buttery sugar cookie decorated with rainbow chocolate buttons.", 1.10),
            Triple("Gourmet Chocolate Fudge Brownie", "Rich, dense Belgian chocolate brownie served warm.", 2.20),
            Triple("Caramel Pecan Slice", "Sticky caramel layer topped with roasted pecans on shortcrust.", 2.40)
        )
        cookies.forEachIndexed { i, cookie ->
            list.add(
                MenuItem(
                    id = "cookie_${i}",
                    name = cookie.first,
                    description = cookie.second,
                    category = "COOKIES",
                    basePrice = cookie.third,
                    baseNutrition = Nutrition(210 + (i * 10), 2, 28, 9 + (i % 2), 120),
                    isCustomizable = false
                )
            )
        }

        // 7. DRINKS (12+ items)
        val drinks = listOf(
            Triple("Coca-Cola Classic", "The original, refreshing sparkling soft drink.", 1.60),
            Triple("Diet Coke", "No sugar, zero calories, classic refreshing cola taste.", 1.50),
            Triple("Coca-Cola Zero Sugar", "Great Coke taste with zero sugar and calories.", 1.50),
            Triple("Fanta Orange", "Vibrant, refreshing sparkling orange fruit drink.", 1.60),
            Triple("Sprite Zero", "Crisp, clean lemon-lime sparkling beverage, sugar free.", 1.50),
            Triple("Dr Pepper", "A unique, sparkling blend of 23 signature flavors.", 1.60),
            Triple("Organic Sweet Peach Iced Tea", "Brewed black tea with natural peach nectar infusion.", 1.80),
            Triple("Freshly Squeezed Lemonade", "Zesty, tart, real squeezed lemons, lightly sweetened.", 1.99),
            Triple("Glacial Pure Still Water", "Premium refreshing bottled natural spring water.", 1.40),
            Triple("Sparkling Spring Water", "Crisp, bubbly carbonated pure natural spring water.", 1.40),
            Triple("Fresh Roast Coffee", "Hot, organic dark roast arabica espresso coffee.", 1.99),
            Triple("Chilled Creamy Latte", "Espresso blended with fresh steamed whole milk.", 2.49)
        )
        drinks.forEachIndexed { i, drink ->
            list.add(
                MenuItem(
                    id = "drink_${i}",
                    name = drink.first,
                    description = drink.second,
                    category = "DRINKS",
                    basePrice = drink.third,
                    baseNutrition = Nutrition(if (drink.first.contains("Diet") || drink.first.contains("Zero") || drink.first.contains("Water")) 0 else 140, 0, if (drink.first.contains("Diet") || drink.first.contains("Zero") || drink.first.contains("Water")) 0 else 35, 0, 15),
                    isCustomizable = false
                )
            )
        }

        list
    }

    private fun indexMultiplier(i: Int): Int = if (i % 2 == 0) 1 else 2
}
