package com.example.models

import androidx.room.Entity
import androidx.room.PrimaryKey

data class Nutrition(
    val calories: Int,
    val protein: Int, // in grams
    val carbs: Int,   // in grams
    val fat: Int,     // in grams
    val sodium: Int   // in milligrams
) {
    operator fun plus(other: Nutrition): Nutrition {
        return Nutrition(
            calories = this.calories + other.calories,
            protein = this.protein + other.protein,
            carbs = this.carbs + other.carbs,
            fat = this.fat + other.fat,
            sodium = this.sodium + other.sodium
        )
    }

    operator fun times(factor: Int): Nutrition {
        return Nutrition(
            calories = this.calories * factor,
            protein = this.protein * factor,
            carbs = this.carbs * factor,
            fat = this.fat * factor,
            sodium = this.sodium * factor
        )
    }

    companion object {
        val ZERO = Nutrition(0, 0, 0, 0, 0)
    }
}

data class IngredientOption(
    val id: String,
    val name: String,
    val category: String, // "BREAD", "WRAP", "SALAD_BASE", "PROTEIN", "CHEESE", "VEGETABLE", "SAUCE", "EXTRA"
    val price: Double,
    val nutrition: Nutrition,
    val isPremium: Boolean = false,
    val availability: String = "AVAILABLE" // "AVAILABLE", "LIMITED", "UNAVAILABLE"
)

data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // "SANDWICHES", "WRAPS", "SALADS", "BREAKFAST", "SIDES", "DRINKS", "COOKIES", "DESSERTS"
    val basePrice: Double,
    val baseNutrition: Nutrition,
    val defaultBase: String? = null, // e.g. "White"
    val defaultSize: String? = null, // e.g. "6 Inch"
    val defaultProteins: List<String> = emptyList(),
    val defaultCheeses: List<String> = emptyList(),
    val defaultVegetables: List<String> = emptyList(),
    val defaultSauces: List<String> = emptyList(),
    val defaultExtras: List<String> = emptyList(),
    val defaultToasted: Boolean = false,
    val isCustomizable: Boolean = true,
    val availability: String = "AVAILABLE"
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemType: String, // "SANDWICH", "WRAP", "SALAD", "SIDE", "DRINK", "MEAL"
    val name: String,
    val baseName: String, // bread / wrap / salad base
    val size: String, // "6 Inch", "Footlong", "Medium", "Large", "N/A"
    val proteins: List<String> = emptyList(),
    val cheeses: List<String> = emptyList(),
    val vegetables: List<String> = emptyList(),
    val sauces: List<String> = emptyList(),
    val extras: List<String> = emptyList(),
    val isToasted: Boolean = false,
    val sideName: String? = null,
    val drinkName: String? = null,
    val drinkSize: String? = null,
    val price: Double,
    val calories: Int,
    val quantity: Int = 1,
    val appliedDealId: String? = null
)

@Entity(tableName = "past_orders")
data class Order(
    @PrimaryKey val id: String,
    val dateLong: Long,
    val itemsSummary: String,
    val totalAmount: Double,
    val status: String, // "ORDER_RECEIVED", "PREPARING", "READY", "COLLECTED", "DELIVERED"
    val orderType: String, // "PICKUP", "DELIVERY", "DINE-IN"
    val restaurantId: String,
    val restaurantName: String
)

data class Restaurant(
    val id: String,
    val name: String,
    val address: String,
    val distance: Double, // in miles
    val isOpen: Boolean,
    val openingHours: String,
    val allowsPickup: Boolean = true,
    val allowsDelivery: Boolean = true,
    val prepTimeMinutes: Int,
    val city: String,
    val postcode: String,
    val isFavourite: Boolean = false
)

data class Deal(
    val id: String,
    val title: String,
    val description: String,
    val originalPrice: Double,
    val dealPrice: Double,
    val saving: Double,
    val expiryDate: String,
    val type: String, // "MEAL_DEAL", "FAMILY_DEAL", "LUNCH_DEAL", "APP_EXCLUSIVE"
    val isApplicable: (List<CartItem>) -> Boolean = { false }
)

data class Reward(
    val id: String,
    val title: String,
    val pointsCost: Int,
    val description: String,
    val isAvailable: Boolean
)
