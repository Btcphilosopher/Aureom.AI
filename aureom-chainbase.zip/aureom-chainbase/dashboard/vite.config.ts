/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The gateway serves dist/ at "/" (SPA fallback) and the app calls /api/v1 on the same origin.
// In development the dev server proxies /api to the gateway (or `npm run mock`, port 8083).
const target = process.env.VITE_PROXY_TARGET ?? 'http://127.0.0.1:8083';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target, changeOrigin: true } },
  },
  preview: { proxy: { '/api': { target, changeOrigin: true } } },
  build: {
    outDir: 'dist',
    sourcemap: false,
    chunkSizeWarningLimit: 400,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          query: ['@tanstack/react-query'],
        },
      },
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    css: false,
    include: ['src/**/*.test.{ts,tsx}'],
  },
});
