/* Click-through checks of the interactive flows against a running gateway (mock or real):
 * theme toggle, search, finality verification, proof lookup + time travel, projection verify + rebuild (with confirm dialog),
 * keyboard navigation. Exits non-zero on the first failed assertion or any console error.
 *   BASE_URL=http://127.0.0.1:8083 node scripts/interactions.cjs */
const { createRequire } = require('module');
const path = require('path');
const cp = require('child_process');
let chromium;
try { ({ chromium } = require('playwright')); } catch { ({ chromium } = createRequire(path.join(cp.execSync('npm root -g').toString().trim(), 'noop.js'))('playwright')); }
const assert = require('assert');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8083';
const OUT = path.resolve(process.env.OUT || path.join(__dirname, '..', 'screenshots', 'work'));
const api = (p) => fetch(BASE + '/api/v1' + p).then((r) => r.json());

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, colorScheme: 'light' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  const step = (s) => console.log('·', s);

  step('theme toggle switches data-theme and persists');
  await page.goto(BASE + '/');
  await page.waitForSelector('.page');
  const before = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await page.getByRole('button', { name: /Switch to dark theme/ }).click();
  assert.strictEqual(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'dark');
  assert.notStrictEqual(await page.evaluate(() => getComputedStyle(document.body).backgroundColor), before);
  await page.reload();
  await page.waitForSelector('.page');
  assert.strictEqual(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'dark');
  await page.getByRole('button', { name: /Switch to light theme/ }).click();

  step('sidebar has exactly the eleven sections, keyboard reachable');
  const labels = await page.locator('nav[aria-label="Sections"] a').allInnerTexts();
  assert.deepStrictEqual(labels.map((s) => s.trim()), ['Overview', 'Network', 'Products', 'Inventory', 'Sales', 'Suppliers', 'Prices', 'Loyalty', 'Migration', 'Explorer', 'Administration']);

  step('footer strip shows chain height / indexed height / lag on every page');
  for (const p of ['/', '/network', '/products', '/inventory', '/sales', '/suppliers', '/prices', '/loyalty', '/migration', '/explorer', '/administration']) {
    await page.goto(BASE + p);
    await page.waitForSelector('.page');
    await page.waitForFunction(() => /\d/.test(document.querySelector('[data-testid="foot-head"]')?.textContent || ''));
    const t = await page.locator('footer.statusbar').innerText();
    assert.match(t, /Chain height\s+\d+/);
    assert.match(t, /Indexed height\s+\d+/);
    assert.match(t, /Lag\s+\d+ blocks?/);
    assert.ok(await page.locator('header.topbar').getByText(/HEALTHY|DEGRADED|HALTED/).first().isVisible());
  }

  step('explorer: finality verification of a block');
  const blocks = await api('/explorer/blocks?limit=5');
  const h = blocks[3].height;
  await page.goto(BASE + '/explorer/block/' + h);
  await page.getByRole('button', { name: new RegExp('Verify finality of block ' + h) }).click();
  await page.getByText(/Finality verified|NOT verified/).first().waitFor({ timeout: 20000 });
  assert.ok(await page.getByText('Finality verified').first().isVisible());
  await page.screenshot({ path: path.join(OUT, 'interaction-finality.png') });

  step('explorer: search by block height, then open the result');
  await page.goto(BASE + '/explorer');
  await page.getByLabel(/Search by transaction id/).fill(String(h));
  await page.getByRole('button', { name: 'Search' }).click();
  await page.getByRole('link', { name: 'Block ' + h }).click();
  await page.waitForURL(new RegExp('/explorer/block/' + h));

  step('explorer: record proof, step-by-step explanation and the caveat; time travel');
  const sales = (await api('/q/sales?limit=1')).items;
  const key = 'sale/' + sales[0].id;
  await page.goto(BASE + '/explorer/record?key=' + encodeURIComponent(key));
  await page.getByText('Merkle proof valid').waitFor({ timeout: 20000 });
  await page.getByText('Step by step').waitFor();
  await page.getByText('A proof only establishes inclusion of that key/value in a committed state root, not business correctness or completeness of a search.').waitFor();
  await page.getByRole('button', { name: /Earlier block/ }).click();
  await page.waitForURL(/height=\d+/);
  await page.getByText(/State as it was committed at height/).waitFor();
  await page.getByRole('tab', { name: 'Audit history' }).click();
  await page.getByText(/^Version 1$/).first().waitFor();

  step('administration: verify projection');
  await page.goto(BASE + '/administration?tab=projection');
  await page.getByRole('button', { name: 'Verify projection' }).click();
  await page.getByText(/Digest matches the chain|Digest MISMATCH/).waitFor({ timeout: 30000 });
  assert.ok(await page.getByText('Digest matches the chain').isVisible());

  step('administration: rebuild needs confirmation; cancel does nothing, confirm starts a rebuild');
  await page.getByRole('button', { name: 'Rebuild projection' }).click();
  await page.getByRole('alertdialog', { name: 'Rebuild the query projection?' }).waitFor();
  await page.getByRole('button', { name: 'Cancel' }).click();
  assert.strictEqual(await page.getByRole('alertdialog').count(), 0);
  await page.getByRole('button', { name: 'Rebuild projection' }).click();
  await page.getByRole('button', { name: 'Rebuild projection' }).last().click();
  await page.getByText(/Rebuild started/).waitFor({ timeout: 10000 });
  await page.screenshot({ path: path.join(OUT, 'interaction-rebuild.png') });
  // wait for the projection to catch up again
  await page.waitForFunction(() => /OK/.test(document.querySelector('.kpi .chip')?.textContent || '') , null, { timeout: 90000 }).catch(() => {});

  step('products: keyboard opens the detail drawer, Escape closes it');
  await page.goto(BASE + '/products');
  await page.waitForSelector('table.dt tbody tr.clickable');
  await page.locator('table.dt tbody tr.clickable').first().focus();
  await page.keyboard.press('Enter');
  await page.getByRole('dialog').waitFor();
  await page.keyboard.press('Escape');
  assert.strictEqual(await page.getByRole('dialog').count(), 0);

  await browser.close();
  const real = errors.filter((e) => !/Failed to load resource/.test(e));
  if (real.length) { console.error('console errors:', real); process.exit(1); }
  console.log('all interaction checks passed');
})().catch((e) => { console.error(e); process.exit(1); });
