/* Screenshot every page of the console in light and dark, against a running gateway (mock or real).
 *   BASE_URL=http://127.0.0.1:8083 SCALE=1 OUT=screenshots/work node scripts/screenshots.cjs [filter... | =exact-name...]
 *   EXTRA="name=/path?query,..." adds pages; SCENARIOS=0 skips the degraded/halted/lag/down states (mock only)
 * Uses the globally installed Playwright + the pre-installed Chromium (no `playwright install`).
 * Exits non-zero if any page logged a console error / page error / failed API call. */
const { createRequire } = require('module');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');

let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  const root = cp.execSync('npm root -g').toString().trim();
  ({ chromium } = createRequire(path.join(root, 'noop.js'))('playwright'));
}

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8083';
const OUT = path.resolve(process.env.OUT || path.join(__dirname, '..', 'screenshots', 'work'));
const SCALE = Number(process.env.SCALE || 1);
const THEMES = (process.env.THEMES || 'light,dark').split(',');
const WIDTH = Number(process.env.WIDTH || 1440);
const HEIGHT = Number(process.env.HEIGHT || 900);
const FULL = process.env.FULL !== '0';
const filters = process.argv.slice(2);

async function api(p) {
  const r = await fetch(BASE + '/api/v1' + p);
  return r.json();
}

async function settle(page) {
  try {
    await page.waitForFunction(() => !document.querySelector('.skeleton') && !document.querySelector('.spinner'), null, { timeout: 8000 });
  } catch {
    /* continue: screenshot whatever is there */
  }
  await page.waitForTimeout(450);
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  // pick interesting records from the API
  const returns = (await api('/q/returns?limit=50')).items || [];
  const sales = (await api('/q/sales?limit=500')).items || [];
  const rich = sales.find((s) => s.lines.some((l) => (l.pricing_steps || []).length >= 2)) || sales.find((s) => s.lines.some((l) => (l.pricing_steps || []).length >= 1)) || sales[0];
  const refunded = returns.find((r) => r.status === 'RECEIVED') || returns[0];
  const instructed = sales.find((s) => s.payment_status === 'INSTRUCTED') || sales[1] || sales[0];
  const accts = (await api('/q/loyalty/accounts?limit=50')).items || [];
  const exc = (await api('/q/exceptions?kind=LOYALTY_SHORTFALL&limit=5')).items || [];
  const shortfallAcct = exc[0] ? (await api('/q/loyalty/accounts?limit=50')).items.find((a) => exc[0].detail.includes(a.id)) : undefined;
  const recent = (await api('/explorer/blocks?limit=60')) || [];
  const txs = (await api('/q/transactions?limit=100')).items || [];
  const rejHeight = (txs.find((t) => t.status === 'REJECTED') || {}).height;
  const busy = (rejHeight && { height: rejHeight }) || recent[5];
  const rejectedTx = txs.find((t) => t.status === 'REJECTED') || txs[0];
  const okTx = txs.find((t) => t.status === 'OK' && t.type === 'CompleteSale') || txs.find((t) => t.status === 'OK') || txs[0];
  const reports = await api('/migration/reports');
  const trialFail = reports.find((r) => r.decision === 'REJECT') || reports[0] || { id: 'none' };
  const finalRep = reports.find((r) => !r.trial) || reports[reports.length - 1] || { id: 'none' };

  const PAGES = [
    ['overview', '/'],
    ['network', '/network'],
    ['products', '/products'],
    ['product-drawer', '/products?id=P-1019'],
    ['product-drawer-imported', '/products?id=P-1002'],
    ['inventory-balances', '/inventory'],
    ['inventory-lowstock', '/inventory?low=1'],
    ['inventory-drawer', '/inventory?row=' + encodeURIComponent('SKU-1019-1M@STORE-N-01')],
    ['inventory-movements', '/inventory?tab=movements'],
    ['inventory-reservations', '/inventory?tab=reservations'],
    ['inventory-transfers', '/inventory?tab=transfers'],
    ['inventory-adjustments', '/inventory?tab=adjustments'],
    ['inventory-exceptions', '/inventory?tab=exceptions'],
    ['sales', '/sales'],
    ['sales-returns', '/sales?tab=returns'],
    ['sales-refunds', '/sales?tab=refunds'],
    ['sale-detail', '/sales/' + encodeURIComponent(rich.id)],
    ['sale-detail-refund', '/sales/' + encodeURIComponent(refunded ? refunded.sale_id : rich.id)],
    ['sale-detail-instructed', '/sales/' + encodeURIComponent(instructed.id)],
    ['suppliers', '/suppliers'],
    ['suppliers-orders', '/suppliers?tab=orders'],
    ['suppliers-po-drawer', '/suppliers?tab=orders&po=PO-2026-0104'],
    ['suppliers-receipts', '/suppliers?tab=receipts'],
    ['suppliers-outstanding', '/suppliers?tab=outstanding'],
    ['prices', '/prices'],
    ['prices-history', '/prices?tab=history'],
    ['prices-promos', '/prices?tab=promos'],
    ['loyalty', '/loyalty'],
    ['loyalty-ledger', '/loyalty/' + encodeURIComponent((shortfallAcct || accts[3] || accts[0]).id)],
    ['migration', '/migration'],
    ['migration-report-trial-fail', '/migration/reports/' + encodeURIComponent(trialFail.id)],
    ['migration-report-final', '/migration/reports/' + encodeURIComponent(finalRep.id)],
    ['explorer', '/explorer'],
    ['explorer-block', '/explorer/block/' + busy.height],
    ['explorer-tx', '/explorer/tx/' + encodeURIComponent(okTx.tx_id || okTx.id)],
    ['explorer-tx-rejected', '/explorer/tx/' + encodeURIComponent(rejectedTx.tx_id || rejectedTx.id)],
    ['explorer-record', '/explorer/record?key=' + encodeURIComponent('sale/' + rich.id)],
    ['explorer-record-history', '/explorer/record?rtab=history&key=' + encodeURIComponent('product/P-1019')],
    ['explorer-record-absent', '/explorer/record?key=' + encodeURIComponent('sale/S-DOES-NOT-EXIST')],
    ['admin-governance', '/administration'],
    ['admin-members', '/administration?tab=members'],
    ['admin-identities', '/administration?tab=identities'],
    ['admin-grants', '/administration?tab=grants'],
    ['admin-projection', '/administration?tab=projection'],
    ['admin-params', '/administration?tab=params'],
  ]
    .concat((process.env.EXTRA || '').split(',').filter(Boolean).map((s) => [s.split('=')[0], s.slice(s.indexOf('=') + 1)]))
    .filter(([name]) => filters.length === 0 || filters.some((f) => (f.startsWith('=') ? name === f.slice(1) : name.includes(f))));

  const browser = await chromium.launch();
  let problems = 0;
  for (const theme of THEMES) {
    const ctx = await browser.newContext({ viewport: { width: WIDTH, height: HEIGHT }, deviceScaleFactor: SCALE, colorScheme: theme });
    const page = await ctx.newPage();
    let current = '';
    const report = (kind, text) => {
      problems++;
      console.log(`  [${theme}] ${current}: ${kind}: ${text}`);
    };
    page.on('console', (m) => {
      if (m.type() === 'error') report('console.error', m.text());
    });
    page.on('pageerror', (e) => report('pageerror', String(e)));
    page.on('response', (r) => {
      const u = r.url();
      if (u.includes('/api/') && r.status() >= 400 && !(r.status() === 404 && /does-not-exist|DOES-NOT/i.test(u))) report('http ' + r.status(), u.replace(BASE, ''));
    });
    page.on('requestfailed', (r) => {
      if (!/ERR_ABORTED/.test(r.failure()?.errorText || '')) report('requestfailed', r.url().replace(BASE, ''));
    });
    for (const [name, url] of PAGES) {
      current = name;
      await page.goto(BASE + url, { waitUntil: 'domcontentloaded' });
      await page.waitForSelector('.page', { timeout: 10000 }).catch(() => report('missing', '.page'));
      await settle(page);
      const file = path.join(OUT, `${name}.${theme}.png`);
      if (FULL && !/drawer/.test(name)) {
        // the app scrolls inside .content, so grow the viewport to fit the whole page
        const need = await page.evaluate(() => {
          const c = document.querySelector('.content');
          return c ? c.scrollHeight + (window.innerHeight - c.clientHeight) : window.innerHeight;
        });
        await page.setViewportSize({ width: WIDTH, height: Math.min(Math.max(HEIGHT, need), 5000) });
        await page.waitForTimeout(250);
      }
      if (/drawer/.test(name)) await page.setViewportSize({ width: WIDTH, height: 1500 });
      if (/drawer/.test(name)) await page.waitForTimeout(150);
      await page.screenshot({ path: file });
      await page.setViewportSize({ width: WIDTH, height: HEIGHT });
      console.log(`ok ${theme} ${name}`);
    }
    await ctx.close();
  }
  await browser.close();
  // failure / degraded states (mock only)
  const ctrl = await fetch(BASE + '/__mock/scenario').then((r) => r.ok).catch(() => false);
  if (ctrl && (filters.length === 0 || filters.includes('scenarios')) && process.env.SCENARIOS !== '0') {
    const b2 = await chromium.launch();
    const SC = [['degraded', ['/network', '/']], ['halted', ['/network', '/']], ['lag', ['/']], ['lagbad', ['/', '/administration?tab=projection']], ['rebuilding', ['/administration?tab=projection']], ['empty', ['/products']], ['down', ['/']]];
    for (const [sc, urls] of SC) {
      await fetch(BASE + '/__mock/scenario', { method: 'POST', body: JSON.stringify({ name: sc }) });
      const ctx = await b2.newContext({ viewport: { width: WIDTH, height: HEIGHT }, deviceScaleFactor: SCALE, colorScheme: 'light' });
      const page = await ctx.newPage();
      for (const u of urls) {
        await page.goto(BASE + u, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('.page, .banner', { timeout: 10000 }).catch(() => {});
        await page.waitForTimeout(sc === 'down' ? 6000 : 1800);
        const name = `state-${sc}-${u.replace(/[^a-z]+/gi, '_').replace(/^_|_$/g, '') || 'overview'}`;
        await page.setViewportSize({ width: WIDTH, height: 1000 });
        await page.screenshot({ path: path.join(OUT, `${name}.light.png`) });
        await page.setViewportSize({ width: WIDTH, height: HEIGHT });
        console.log('ok scenario', sc, u);
      }
      await ctx.close();
    }
    await fetch(BASE + '/__mock/scenario', { method: 'POST', body: JSON.stringify({ name: 'normal' }) });
    await b2.close();
  }
  console.log(problems ? `\n${problems} problem(s) logged` : '\nno console errors / failed API calls');
  process.exit(problems ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(2);
});
