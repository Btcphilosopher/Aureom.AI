import { render } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router-dom';
import { vi } from 'vitest';
import type { ReactElement } from 'react';
import { ChainStatusProvider } from '../api/chainStatus';

export type FetchMap = Record<string, unknown | ((url: URL) => unknown)>;

/** Stub fetch: longest matching path prefix wins; unknown paths 404 like the gateway. */
export function stubFetch(map: FetchMap) {
  const f = vi.fn(async (input: RequestInfo | URL) => {
    const url = new URL(String(input), 'http://localhost');
    const path = url.pathname.replace(/^\/api\/v1/, '');
    const key = Object.keys(map)
      .filter((k) => path === k || path.startsWith(k + '/') || path.startsWith(k))
      .sort((a, b) => b.length - a.length)[0];
    if (!key) return new Response(JSON.stringify({ error: 'unknown API endpoint', code: 'NOT_FOUND' }), { status: 404 });
    const v = map[key];
    const body = typeof v === 'function' ? (v as (u: URL) => unknown)(url) : v;
    return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
  });
  vi.stubGlobal('fetch', f);
  return f;
}

export function renderWithProviders(ui: ReactElement, opts: { route?: string; withStatus?: boolean } = {}) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } } });
  const tree = (
    <QueryClientProvider client={qc}>
      <MemoryRouter initialEntries={[opts.route ?? '/']}>{opts.withStatus === false ? ui : <ChainStatusProvider pollMs={60_000}>{ui}</ChainStatusProvider>}</MemoryRouter>
    </QueryClientProvider>
  );
  return render(tree);
}

export const META = { indexed_height: 120, chain_head: 121, lag_blocks: 1, projection_state: 'OK' };

export const NETWORK = {
  network_id: 'aureom-retail-demo-1',
  app_version: 1,
  chain: { latest_height: 121, latest_block_time: '2026-11-12T20:00:00Z', latest_app_hash: 'AB'.repeat(32) },
  bft: { validators: 4, voting_power_total: 40, f: 1, quorum_power_required: 27, online_power: 40, online_validators: 4, status: 'HEALTHY', explanation: 'All validators are online.' },
  validators: ['val-hq', 'val-dist', 'val-north', 'val-south'].map((name, i) => ({
    name, org: `org-${name.slice(4)}`, role: i === 0 ? 'HEADQUARTERS' : 'REGIONAL', node_id: 'n'.repeat(40), reachable: true, height: 121, catching_up: false, peers: 3, latency_ms: 3,
    voting_power: 10, agrees_with_majority: true, last_signed_height: 121,
  })),
  mempool: { unconfirmed_txs: 0 },
};

export const PROJECTION = { state: 'OK', indexed_height: 120, chain_head: 121, lag_blocks: 1 };
