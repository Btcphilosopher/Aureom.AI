import { humanize, type Tone } from './format';

export interface StatusMeta {
  tone: Tone;
  label: string;
}

type Kind = 'payment' | 'fulfilment' | 'sale' | 'refund' | 'po' | 'transfer' | 'return' | 'generic' | 'key' | 'severity' | 'check';

const GENERIC: Record<string, Tone> = {
  OK: 'ok', ACTIVE: 'ok', APPROVED: 'ok', CONFIRMED: 'ok', PASS: 'ok', ACCEPT: 'ok', FINALISED: 'ok', FINALISED_OK: 'ok',
  RECEIVED: 'ok', COMPLETED: 'ok', FULFILLED: 'ok', EXECUTED: 'ok', RESOLVED: 'ok', HEALTHY: 'ok', CLOSED: 'ok', INDEXED: 'ok',
  PENDING: 'warn', INSTRUCTED: 'warn', PARTIALLY_PAID: 'warn', PARTIALLY_RECEIVED: 'warn', PARTIALLY_RETURNED: 'warn', IN_TRANSIT: 'warn',
  REQUESTED: 'warn', WARN: 'warn', DEGRADED: 'warn', SCHEDULED: 'info', ROTATED: 'warn', OPEN: 'warn', REBUILDING: 'warn',
  RECEIVED_WITH_DISCREPANCY: 'warn', OVERPAID: 'warn', MEDIUM: 'warn', WARNING: 'warn', SUSPENDED: 'warn',
  FAIL: 'bad', FAILED: 'bad', REJECTED: 'bad', REVOKED: 'bad', HALTED: 'bad', CANCELLED: 'bad', REJECT: 'bad', REMOVED: 'bad',
  HIGH: 'bad', CRITICAL: 'bad', FINALISED_REJECTED: 'bad', UNREACHABLE: 'bad', EMPTY: 'warn',
  DRAFT: 'neutral', DISCONTINUED: 'neutral', RELEASED: 'neutral', ENDED: 'neutral', EXPIRED: 'neutral', NOT_STARTED: 'neutral',
  CONSUMED: 'neutral', UNKNOWN: 'neutral', SUCCEEDED: 'ok', SUCCESS: 'ok', DECLINED: 'bad', LOW: 'info', INFO: 'info', REVERSED: 'neutral',
};

const LABELS: Record<Kind, Record<string, string>> = {
  payment: {
    INSTRUCTED: 'Payment instructed', PARTIALLY_PAID: 'Partially paid', CONFIRMED: 'Paid', FAILED: 'Payment failed', OVERPAID: 'Overpaid',
  },
  fulfilment: { FULFILLED: 'Fulfilled', PARTIALLY_RETURNED: 'Partly returned', RETURNED: 'Returned' },
  sale: { COMPLETED: 'Completed' },
  refund: { INSTRUCTED: 'Refund instructed', CONFIRMED: 'Refund confirmed', FAILED: 'Refund failed' },
  po: { DRAFT: 'Awaiting approval', APPROVED: 'Approved', PARTIALLY_RECEIVED: 'Partly received', RECEIVED: 'Received', CANCELLED: 'Cancelled' },
  transfer: { IN_TRANSIT: 'In transit', RECEIVED: 'Received', RECEIVED_WITH_DISCREPANCY: 'Received, discrepancy' },
  return: { REQUESTED: 'Requested', APPROVED: 'Approved', REJECTED: 'Rejected', PARTIALLY_RECEIVED: 'Partly received', RECEIVED: 'Received' },
  generic: { OK: 'OK' },
  key: {},
  severity: {},
  check: {},
};

const OVERRIDE_TONE: Partial<Record<Kind, Record<string, Tone>>> = {
  fulfilment: { RETURNED: 'info', PARTIALLY_RETURNED: 'info' },
  po: { DRAFT: 'warn' },
  refund: { INSTRUCTED: 'warn', CONFIRMED: 'ok' },
  transfer: { RECEIVED: 'ok' },
};

export function statusMeta(value: string | undefined | null, kind: Kind = 'generic'): StatusMeta {
  if (!value) return { tone: 'neutral', label: '–' };
  const tone = OVERRIDE_TONE[kind]?.[value] ?? GENERIC[value] ?? 'neutral';
  const label = LABELS[kind]?.[value] ?? humanize(value);
  return { tone, label };
}

export type { Kind as StatusKind };

/** Result-code families from docs/TRANSACTIONS.md, for plain-English display. */
export function codeFamily(code: number | undefined): string {
  if (code === undefined) return '';
  if (code === 0) return 'Success';
  if (code < 100) return 'Structure / limits';
  if (code < 200) return 'Cryptographic validity';
  if (code < 210) return 'Identity';
  if (code < 300) return 'Replay protection';
  if (code < 400) return 'Authorisation';
  if (code < 500) return 'Business validation';
  return 'Internal';
}

/** Does this code leave no trace in state (stages 1-3)? Stage 4+ are recorded as REJECTED in a block. */
export function codeRecordedOnChain(code: number): boolean {
  return code >= 210 || code === 0;
}

export const BUCKET_LABEL: Record<string, string> = {
  available: 'available',
  reserved: 'reserved',
  quarantined: 'quarantined',
  damaged: 'damaged',
};
