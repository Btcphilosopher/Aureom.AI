import { describe, expect, it } from 'vitest';
import { codeFamily, codeRecordedOnChain, statusMeta } from './status';

describe('statusMeta uses business language per domain', () => {
  it('keeps payment, fulfilment and refund statuses distinct', () => {
    expect(statusMeta('CONFIRMED', 'payment')).toEqual({ tone: 'ok', label: 'Paid' });
    expect(statusMeta('INSTRUCTED', 'payment')).toEqual({ tone: 'warn', label: 'Payment instructed' });
    expect(statusMeta('FAILED', 'payment')).toEqual({ tone: 'bad', label: 'Payment failed' });
    expect(statusMeta('PARTIALLY_RETURNED', 'fulfilment').label).toBe('Partly returned');
    expect(statusMeta('INSTRUCTED', 'refund').label).toBe('Refund instructed');
    expect(statusMeta('CONFIRMED', 'refund').label).toBe('Refund confirmed');
  });
  it('maps purchase order and transfer states', () => {
    expect(statusMeta('DRAFT', 'po').label).toBe('Awaiting approval');
    expect(statusMeta('IN_TRANSIT', 'transfer').label).toBe('In transit');
    expect(statusMeta('RECEIVED_WITH_DISCREPANCY', 'transfer').tone).toBe('warn');
  });
  it('maps generic outcomes', () => {
    expect(statusMeta('PASS').tone).toBe('ok');
    expect(statusMeta('WARN').tone).toBe('warn');
    expect(statusMeta('FAIL').tone).toBe('bad');
    expect(statusMeta('REVOKED').tone).toBe('bad');
    expect(statusMeta('ROTATED').tone).toBe('warn');
    expect(statusMeta('OK').label).toBe('OK');
    expect(statusMeta(undefined).label).toBe('–');
    expect(statusMeta('SOMETHING_NEW').tone).toBe('neutral');
  });
});

describe('result codes', () => {
  it('describes the code families from docs/TRANSACTIONS.md', () => {
    expect(codeFamily(0)).toBe('Success');
    expect(codeFamily(6)).toBe('Structure / limits');
    expect(codeFamily(101)).toBe('Cryptographic validity');
    expect(codeFamily(202)).toBe('Identity');
    expect(codeFamily(211)).toBe('Replay protection');
    expect(codeFamily(303)).toBe('Authorisation');
    expect(codeFamily(404)).toBe('Business validation');
  });
  it('knows which rejections are recorded in a block', () => {
    expect(codeRecordedOnChain(101)).toBe(false);
    expect(codeRecordedOnChain(203)).toBe(false);
    expect(codeRecordedOnChain(210)).toBe(true);
    expect(codeRecordedOnChain(404)).toBe(true);
  });
});
