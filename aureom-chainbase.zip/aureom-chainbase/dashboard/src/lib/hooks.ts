import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';

/** One URL search param as state, so tabs / filters / drawers are deep-linkable. */
export function useParam(key: string, def = ''): [string, (v: string | null) => void] {
  const [sp, setSp] = useSearchParams();
  const value = sp.get(key) ?? def;
  const set = useCallback(
    (v: string | null) => {
      setSp(
        (prev) => {
          const n = new URLSearchParams(prev);
          if (v === null || v === '' || v === def) n.delete(key);
          else n.set(key, v);
          return n;
        },
        { replace: true },
      );
    },
    [key, def, setSp],
  );
  return [value, set];
}

export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export type ThemeChoice = 'light' | 'dark';

function effectiveTheme(): ThemeChoice {
  const attr = document.documentElement.getAttribute('data-theme');
  if (attr === 'light' || attr === 'dark') return attr;
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

/** Theme follows prefers-color-scheme until the user toggles; the choice is then remembered. */
export function useTheme(): [ThemeChoice, () => void] {
  const [theme, setTheme] = useState<ThemeChoice>(() => effectiveTheme());
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-color-scheme: dark)');
    if (!mq) return;
    const on = () => setTheme(effectiveTheme());
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  const toggle = useCallback(() => {
    const next: ThemeChoice = effectiveTheme() === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try {
      localStorage.setItem('aureom-theme', next);
    } catch {
      /* storage blocked */
    }
    setTheme(next);
  }, []);
  return [theme, toggle];
}
