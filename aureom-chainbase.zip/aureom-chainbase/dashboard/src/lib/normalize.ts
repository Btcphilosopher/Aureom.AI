import type { Governance, GovEvent, Identity, ProjectionMeta, RoleGrant, QStats } from '../api/types';

/** Flatten nested objects with "_" so {sales:{today:3}} also answers to sales_today. */
export function flatten(o: unknown, prefix = '', out: Record<string, unknown> = {}): Record<string, unknown> {
  if (!o || typeof o !== 'object') return out;
  for (const [k, v] of Object.entries(o as Record<string, unknown>)) {
    const key = prefix ? `${prefix}_${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key, out);
    else out[key] = v;
  }
  return out;
}

export function statNum(flat: Record<string, unknown>, ...names: string[]): number | undefined {
  for (const n of names) {
    const v = flat[n];
    if (typeof v === 'number' && !Number.isNaN(v)) return v;
  }
  return undefined;
}

export interface StatsView {
  flat: Record<string, unknown>;
  products?: number;
  skus?: number;
  locations?: number;
  salesToday?: number;
  sales24h?: number;
  net24h?: number;
  salesTotal?: number;
  openExceptions?: number;
  rejected24h?: number;
  txTotal?: number;
  activeReservations?: number;
  loyaltyPoints?: number;
}

/** /q/stats shape is loosely specified ("headline counters"), so accept several spellings. */
export function normalizeStats(res: unknown): StatsView {
  const body = (res && typeof res === 'object' ? ((res as { item?: unknown; stats?: unknown }).item ?? (res as { stats?: unknown }).stats ?? res) : {}) as QStats;
  const f = flatten(body);
  delete f['meta_indexed_height'];
  return {
    flat: f,
    products: statNum(f, 'products', 'product_count', 'products_total'),
    skus: statNum(f, 'skus', 'sku_count', 'skus_total'),
    locations: statNum(f, 'locations', 'location_count', 'locations_total'),
    salesToday: statNum(f, 'sales_today', 'today_sales', 'sales_count_today'),
    sales24h: statNum(f, 'sales_24h', 'sales_last_24h'),
    net24h: statNum(f, 'sales_net_minor_24h', 'net_minor_24h'),
    salesTotal: statNum(f, 'sales_total', 'total_sales', 'sales', 'sales_count'),
    openExceptions: statNum(f, 'open_exceptions', 'exceptions_open', 'exceptions'),
    rejected24h: statNum(f, 'transactions_rejected_24h', 'rejected_tx_24h', 'rejected_24h', 'rejected_tx', 'rejected_txs_24h', 'rejected_transactions_24h', 'rejected_tx_last_24h'),
    txTotal: statNum(f, 'tx_total', 'txs_total', 'transactions_total', 'tx_count', 'transactions'),
    activeReservations: statNum(f, 'active_reservations', 'reservations_active', 'reservations'),
    loyaltyPoints: statNum(f, 'loyalty_points_outstanding', 'loyalty_points', 'points_outstanding'),
  };
}

export function identityGrants(i: Identity): RoleGrant[] {
  const g = i.grants;
  if (Array.isArray(g)) return g;
  if (g && typeof g === 'object' && Array.isArray((g as { grants?: RoleGrant[] }).grants)) return (g as { grants: RoleGrant[] }).grants;
  return [];
}

export function normalizeGovernance(res: unknown): Governance & { meta?: ProjectionMeta } {
  const r = (res && typeof res === 'object' ? ((res as { item?: unknown }).item ?? res) : {}) as Partial<Governance>;
  const meta = (res as { meta?: ProjectionMeta } | undefined)?.meta;
  const upg = r.upgrades;
  return {
    meta,
    members: Array.isArray(r.members) ? r.members : [],
    proposals: Array.isArray(r.proposals) ? r.proposals : [],
    upgrades: Array.isArray(upg) ? upg : upg && typeof upg === 'object' ? Object.values(upg as object) : [],
    params: r.params && typeof r.params === 'object' ? r.params : {},
    events: Array.isArray(r.events) ? r.events : [],
  };
}

export function eventTime(e: GovEvent): number {
  const n = (e.block_time_ms ?? e.time_ms ?? 0) as number;
  return typeof n === 'number' ? n : 0;
}

export function tupleKey(...parts: (string | number | undefined)[]): string {
  return parts.map((p) => String(p ?? '')).join('|');
}

export function sumBy<T>(rows: T[], f: (r: T) => number): number {
  return rows.reduce((a, r) => a + f(r), 0);
}

export function groupBy<T>(rows: T[], f: (r: T) => string): Record<string, T[]> {
  const out: Record<string, T[]> = {};
  for (const r of rows) (out[f(r)] ??= []).push(r);
  return out;
}

export function txIdOf(t: { id?: string; tx_id?: string }): string {
  return t.id ?? t.tx_id ?? '';
}
