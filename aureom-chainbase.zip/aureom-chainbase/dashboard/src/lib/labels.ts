import { humanize } from './format';

/** Pseudo-locations used by the movement ledger, in business words. */
export function locLabel(code: string | undefined, names?: (id: string) => string | undefined): string {
  if (!code) return '–';
  if (code === 'EXT:SUPPLIER') return 'Supplier (external)';
  if (code === 'EXT:CUSTOMER') return 'Customer (external)';
  if (code === 'EXT:ADJUST') return 'Stock adjustment';
  if (code === 'EXT:MIGRATION') return 'Migration opening balance';
  if (code.startsWith('TRANSIT:')) return `In transit (${code.slice(8)})`;
  const n = names?.(code);
  return n ? `${code} · ${n}` : code;
}

export function bucketLabel(b: string | undefined): string {
  switch (b) {
    case 'available': return 'available';
    case 'reserved': return 'reserved for orders';
    case 'quarantined': return 'quarantined';
    case 'damaged': return 'damaged';
    case 'in_transit': return 'in transit';
    default: return b ? humanize(b).toLowerCase() : '';
  }
}

export function reasonLabel(r: string | undefined): string {
  if (!r) return '–';
  return humanize(r);
}

export function promoSummary(p: { type: string; bp?: number; off_minor?: number; buy_n?: number; bundle_minor?: number; currency?: string }, money: (m: number, c?: string) => string, bp: (n: number) => string): string {
  switch (p.type) {
    case 'PERCENT_OFF': return `${bp(p.bp ?? 0)} off`;
    case 'AMOUNT_OFF_PER_UNIT': return `${money(p.off_minor ?? 0, p.currency)} off each`;
    case 'MULTIBUY_FIXED_PRICE': return `Buy ${p.buy_n ?? '?'} for ${money(p.bundle_minor ?? 0, p.currency)}`;
    default: return humanize(p.type);
  }
}

/** Explorer: record kind -> state key prefix (docs/API.md "State key reference"). */
export const KIND_PREFIX: Record<string, string> = {
  product: 'product/', sku: 'sku/', location: 'loc/', supplier: 'supplier/', po: 'po/', receipt: 'receipt/',
  reservation: 'resv/', sale: 'sale/', return: 'return/', refund: 'refund/', price: 'price/', promotion: 'promo/',
  loyalty: 'loy/', 'loyalty-entry': 'loye/', adjustment: 'adjust/', transfer: 'xfer/', exception: 'exc/',
  identity: 'iam/id/', grants: 'iam/grants/', tx: 'tx/', member: 'gov/member/', proposal: 'gov/prop/',
};

/** Permission catalogue (docs/TRANSACTIONS.md). */
export const ROLE_CATALOGUE: { role: string; permissions: string[]; privileged?: boolean }[] = [
  { role: 'auditor', permissions: [] },
  { role: 'buyer', permissions: ['po.create', 'supplier.write'] },
  { role: 'catalog-manager', permissions: ['catalog.write'] },
  { role: 'finance-controller', permissions: ['reverse.entry', 'exception.resolve', 'return.approve'], privileged: true },
  { role: 'hq-admin', permissions: ['iam.grant', 'iam.admin', 'location.write', 'supplier.write', 'gov.propose', 'exception.resolve'], privileged: true },
  { role: 'loyalty-operator', permissions: ['loyalty.credit', 'loyalty.expire', 'loyalty.redeem'] },
  { role: 'migration-operator', permissions: ['import.batch', 'migration.control'], privileged: true },
  { role: 'org-admin', permissions: ['gov.propose', 'gov.approve'], privileged: true },
  { role: 'payment-adapter', permissions: ['payment.record', 'refund.record'] },
  { role: 'pricing-manager', permissions: ['price.publish', 'promo.manage'] },
  { role: 'purchasing-approver', permissions: ['po.approve'] },
  { role: 'store-cashier', permissions: ['stock.reserve', 'stock.release', 'sale.complete', 'return.request', 'loyalty.redeem'] },
  { role: 'store-manager', permissions: ['goods.receive', 'transfer.dispatch', 'stock.reserve', 'stock.release', 'sale.complete', 'return.request', 'loyalty.redeem', 'return.approve', 'return.receive', 'stock.adjust.propose', 'stock.adjust.approve', 'transfer.receive', 'reverse.entry', 'exception.resolve', 'loyalty.credit'] },
  { role: 'terminal', permissions: ['stock.reserve', 'stock.release', 'sale.complete', 'loyalty.redeem'] },
  { role: 'warehouse-manager', permissions: ['goods.receive', 'transfer.dispatch', 'transfer.receive', 'stock.adjust.propose', 'stock.adjust.approve', 'stock.reserve', 'stock.release', 'reverse.entry', 'exception.resolve'] },
  { role: 'warehouse-operator', permissions: ['goods.receive', 'transfer.dispatch', 'transfer.receive', 'stock.adjust.propose', 'stock.reserve', 'stock.release'] },
];

export const PARAM_INFO: Record<string, { label: string; kind: 'bytes' | 'ms' | 'minor' | 'blocks' | 'count' | 'units'; help: string }> = {
  max_tx_bytes: { label: 'Maximum transaction size', kind: 'bytes', help: 'Largest ordinary transaction the network accepts.' },
  max_import_tx_bytes: { label: 'Maximum import transaction size', kind: 'bytes', help: 'Larger limit for bulk migration batches.' },
  max_lines: { label: 'Maximum lines per transaction', kind: 'count', help: 'Sale, purchase order or receipt lines in one transaction.' },
  max_import_records: { label: 'Maximum records per import batch', kind: 'count', help: 'Records in one bulk import transaction.' },
  max_future_skew_ms: { label: 'Allowed clock skew into the future', kind: 'ms', help: 'How far ahead a terminal’s claimed time may be.' },
  max_backdate_ms: { label: 'Maximum back-dating', kind: 'ms', help: 'How far in the past a terminal may claim an effective time (offline sales).' },
  min_gov_delay_blocks: { label: 'Minimum governance delay', kind: 'blocks', help: 'Blocks between a governance proposal and its activation.' },
  min_upgrade_delay_blocks: { label: 'Minimum upgrade delay', kind: 'blocks', help: 'Blocks of notice before a state machine upgrade activates.' },
  min_validators: { label: 'Minimum validators', kind: 'count', help: 'Validator count may not drop below this.' },
  po_local_limit_minor: { label: 'Purchase order local approval limit', kind: 'minor', help: 'Above this value a global-scope approver is required.' },
  adjust_small_units: { label: 'Small stock adjustment threshold', kind: 'units', help: 'Adjustments larger than this need global-scope approval.' },
  return_local_limit_minor: { label: 'Return local approval limit', kind: 'minor', help: 'Refund value a store can approve itself.' },
  return_window_ms: { label: 'Return window', kind: 'ms', help: 'How long after a sale a return may be requested.' },
  reservation_max_ttl_ms: { label: 'Maximum reservation hold', kind: 'ms', help: 'Longest a stock reservation may be held.' },
  allowance_max_ttl_ms: { label: 'Maximum offline allowance', kind: 'ms', help: 'Longest a pre-allocated offline stock allowance may last.' },
  loyalty_point_value_minor: { label: 'Loyalty point value', kind: 'minor', help: 'Value of one point in minor units of the sale currency.' },
};

/** Loyalty rule codes, e.g. EARN_1_PER_GBP -> "Earn 1 per £1". */
export function ruleLabel(r: string | undefined): string {
  if (!r) return '–';
  if (/[a-z]/.test(r)) return r; // free-form rule text from the state machine (e.g. "Earn.v1.per unit=1"): show verbatim
  return humanize(r).replace(/\bgbp\b/i, '£1');
}
