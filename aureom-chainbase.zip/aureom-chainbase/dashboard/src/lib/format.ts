// Formatting helpers. Money is integer minor units; quantities are integers in the
// unit's smallest step (EA/PK whole units, KG grams, L millilitres, M millimetres).

const CCY_EXP: Record<string, number> = { GBP: 2, USD: 2, EUR: 2, JPY: 0 };
const CCY_SYMBOL: Record<string, string> = { GBP: '£', USD: '$', EUR: '€', JPY: '¥' };

export function currencyExponent(ccy: string): number {
  return CCY_EXP[ccy] ?? 2;
}

function groupThousands(digits: string): string {
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/** Integer minor units -> "£1,234.50". Exact (no floating point). */
export function formatMoney(minor: number | null | undefined, ccy = 'GBP', opts: { plus?: boolean } = {}): string {
  if (minor === null || minor === undefined || Number.isNaN(minor)) return '–';
  const exp = currencyExponent(ccy);
  const neg = minor < 0;
  const abs = Math.abs(Math.trunc(minor));
  const s = String(abs).padStart(exp + 1, '0');
  const major = groupThousands(exp === 0 ? s : s.slice(0, s.length - exp));
  const frac = exp === 0 ? '' : '.' + s.slice(s.length - exp);
  const sym = CCY_SYMBOL[ccy] ?? ccy + ' ';
  const sign = neg ? '−' : opts.plus && abs > 0 ? '+' : '';
  return `${sign}${sym}${major}${frac}`;
}

/** Percent from basis points: 1500 -> "15%", 1250 -> "12.5%". */
export function formatBp(bp: number): string {
  const p = bp / 100;
  return `${Number.isInteger(p) ? p : p.toFixed(2).replace(/0+$/, '')}%`;
}

export function formatInt(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return '–';
  const neg = n < 0;
  return (neg ? '−' : '') + groupThousands(String(Math.abs(Math.trunc(n))));
}

const UNIT_SCALE: Record<string, number> = { EA: 0, PK: 0, KG: 3, L: 3, M: 3 };
const UNIT_LABEL: Record<string, string> = { EA: '', PK: 'pk', KG: 'kg', L: 'L', M: 'm' };

export function unitLabel(unit: string | undefined): string {
  if (!unit) return '';
  return UNIT_LABEL[unit] ?? unit.toLowerCase();
}

/** Quantity in the unit's smallest step -> display string, e.g. (1250,'KG') -> "1.25 kg". */
export function formatQty(v: number | null | undefined, unit = 'EA', opts: { unit?: boolean; plus?: boolean } = {}): string {
  if (v === null || v === undefined || Number.isNaN(v)) return '–';
  const scale = UNIT_SCALE[unit] ?? 0;
  const neg = v < 0;
  const abs = Math.abs(Math.trunc(v));
  let body: string;
  if (scale === 0) {
    body = groupThousands(String(abs));
  } else {
    const s = String(abs).padStart(scale + 1, '0');
    const whole = groupThousands(s.slice(0, s.length - scale));
    const frac = s.slice(s.length - scale).replace(/0+$/, '');
    body = frac ? `${whole}.${frac}` : whole;
  }
  const label = opts.unit === false ? '' : unitLabel(unit);
  const sign = neg ? '−' : opts.plus && abs > 0 ? '+' : '';
  return `${sign}${body}${label ? ' ' + label : ''}`;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const p2 = (n: number) => String(n).padStart(2, '0');

export function formatDate(ms: number | null | undefined, utc = false): string {
  if (!ms) return '–';
  const d = new Date(ms);
  const day = utc ? d.getUTCDate() : d.getDate();
  const mon = utc ? d.getUTCMonth() : d.getMonth();
  const yr = utc ? d.getUTCFullYear() : d.getFullYear();
  return `${day} ${MONTHS[mon]} ${yr}`;
}

/** "12 Nov 2026, 14:32:05" in the viewer's local zone (or UTC). */
export function formatTime(ms: number | null | undefined, opts: { seconds?: boolean; utc?: boolean } = {}): string {
  if (!ms) return '–';
  const d = new Date(ms);
  const utc = !!opts.utc;
  const h = utc ? d.getUTCHours() : d.getHours();
  const m = utc ? d.getUTCMinutes() : d.getMinutes();
  const s = utc ? d.getUTCSeconds() : d.getSeconds();
  const t = `${p2(h)}:${p2(m)}${opts.seconds === false ? '' : ':' + p2(s)}`;
  return `${formatDate(ms, utc)}, ${t}`;
}

export function formatISO(ms: number | null | undefined): string {
  if (!ms) return '–';
  return new Date(ms).toISOString();
}

export function parseTimeString(s: string | undefined | null): number {
  if (!s) return 0;
  const t = Date.parse(s);
  return Number.isNaN(t) ? 0 : t;
}

/** Relative time: "just now", "12 s ago", "4 min ago", "3 h ago", "2 d ago". */
export function timeAgo(ms: number | null | undefined, now = Date.now()): string {
  if (!ms) return '–';
  const diff = Math.round((now - ms) / 1000);
  if (diff < 0) {
    const f = -diff;
    if (f < 60) return `in ${f} s`;
    if (f < 3600) return `in ${Math.round(f / 60)} min`;
    if (f < 86400) return `in ${Math.round(f / 3600)} h`;
    return `in ${Math.round(f / 86400)} d`;
  }
  if (diff < 5) return 'just now';
  if (diff < 60) return `${diff} s ago`;
  if (diff < 3600) return `${Math.round(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.round(diff / 3600)} h ago`;
  return `${Math.round(diff / 86400)} d ago`;
}

/** Milliseconds -> "420 ms" / "1.18 s". */
export function formatDuration(ms: number | null | undefined): string {
  if (ms === null || ms === undefined || Number.isNaN(ms)) return '–';
  if (ms < 1000) return `${Math.round(ms)} ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(ms < 10_000 ? 2 : 1)} s`;
  const m = Math.floor(ms / 60_000);
  const s = Math.round((ms % 60_000) / 1000);
  return `${m} min ${s} s`;
}

export function shortHash(h: string | undefined | null, n = 8): string {
  if (!h) return '–';
  if (h.length <= n * 2 + 1) return h;
  return `${h.slice(0, n)}…${h.slice(-4)}`;
}

/** SCREAMING_SNAKE -> "Screaming snake". */
export function humanize(code: string | undefined | null): string {
  if (!code) return '–';
  const s = code
    .replace(/[_-]+/g, ' ')
    .toLowerCase()
    .replace(/\b(sku|skus|fk|po|id|gbp|api|uk|erp|ean|iam|ok)\b/g, (m) => m.toUpperCase());
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** PascalCase tx type -> "Complete sale". */
export function txTypeLabel(t: string | undefined | null): string {
  if (!t) return '–';
  const s = t.replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export type Tone = 'ok' | 'warn' | 'bad' | 'info' | 'neutral' | 'accent';

/** Projection lag thresholds: <=2 blocks fine, 3..10 amber, >10 red. */
export function lagTone(lag: number | null | undefined): Tone {
  if (lag === null || lag === undefined) return 'neutral';
  if (lag <= 2) return 'ok';
  if (lag <= 10) return 'warn';
  return 'bad';
}

export function healthTone(status: string | undefined): Tone {
  switch (status) {
    case 'HEALTHY':
      return 'ok';
    case 'DEGRADED':
      return 'warn';
    case 'HALTED':
      return 'bad';
    default:
      return 'neutral';
  }
}

/** BFT arithmetic for the quorum explainer. Tolerates f = floor((n-1)/3); quorum is > 2/3 of voting power. */
export function bftMath(powers: number[]) {
  const n = powers.length;
  const total = powers.reduce((a, b) => a + b, 0);
  const f = n > 0 ? Math.floor((n - 1) / 3) : 0;
  const quorum = Math.floor((total * 2) / 3) + 1;
  return { n, total, f, quorum, haltBelow: quorum };
}

export function pct(part: number, whole: number): string {
  if (!whole) return '0%';
  return `${Math.round((part / whole) * 100)}%`;
}

export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}

/** Epoch ms for local midnight of a yyyy-mm-dd string (start of day) or end of day. */
export function dateInputToMs(v: string, endOfDay = false): number | undefined {
  if (!v) return undefined;
  const [y, m, d] = v.split('-').map(Number);
  if (!y || !m || !d) return undefined;
  const dt = endOfDay ? new Date(y, m - 1, d, 23, 59, 59, 999) : new Date(y, m - 1, d, 0, 0, 0, 0);
  return dt.getTime();
}

export function msToDateInput(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
}

/** Shallow field diff of two JSON objects, used for the audit-history timeline. */
export function shallowDiff(prev: unknown, next: unknown): { key: string; before: unknown; after: unknown }[] {
  const a = (prev && typeof prev === 'object' ? prev : {}) as Record<string, unknown>;
  const b = (next && typeof next === 'object' ? next : {}) as Record<string, unknown>;
  const keys = Array.from(new Set([...Object.keys(a), ...Object.keys(b)]));
  const out: { key: string; before: unknown; after: unknown }[] = [];
  for (const k of keys) {
    if (['version', 'updated_height', 'updated_tx'].includes(k)) continue;
    if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) out.push({ key: k, before: a[k], after: b[k] });
  }
  return out;
}

export function compactJSON(v: unknown, max = 80): string {
  let s: string;
  try {
    s = typeof v === 'string' ? v : JSON.stringify(v);
  } catch {
    s = String(v);
  }
  if (s === undefined) return '–';
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

/** Value of a quantity at a per-whole-unit price: unit_minor * v / 10^scale (rounded half away from zero; display only). */
export function lineValue(unitMinor: number, v: number, unit = 'EA'): number {
  const scale = UNIT_SCALE[unit] ?? 0;
  return Math.round((unitMinor * v) / Math.pow(10, scale));
}

/** Compact table timestamp: "12 Nov, 20:52" within the current year, with the year otherwise. */
export function formatTimeShort(ms: number | null | undefined, now = Date.now()): string {
  if (!ms) return '–';
  const full = formatTime(ms, { seconds: false });
  return new Date(ms).getFullYear() === new Date(now).getFullYear() ? full.replace(/ \d{4},/, ',') : full;
}
