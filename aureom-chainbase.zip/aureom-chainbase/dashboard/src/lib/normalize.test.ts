import { describe, expect, it } from 'vitest';
import { flatten, groupBy, identityGrants, normalizeGovernance, normalizeStats, statNum, sumBy, txIdOf } from './normalize';
import type { Identity } from '../api/types';

describe('normalizeStats', () => {
  it('reads the real gateway key names from item', () => {
    const s = normalizeStats({ meta: {}, item: { products: 24, skus: 33, locations: 4, sales_total: 94, sales_24h: 36, sales_net_minor_24h: 150000, open_exceptions: 7, transactions_total: 252, transactions_rejected_24h: 18, active_reservations: 5, loyalty_points_outstanding: 5207 } });
    expect(s).toMatchObject({ products: 24, skus: 33, salesTotal: 94, sales24h: 36, net24h: 150000, openExceptions: 7, txTotal: 252, rejected24h: 18, activeReservations: 5, loyaltyPoints: 5207 });
  });
  it('accepts the documented / nested spellings', () => {
    const s = normalizeStats({ sales: { today: 3 }, rejected_tx_24h: 2, tx_total: 10 });
    expect(s.salesToday).toBe(3);
    expect(s.rejected24h).toBe(2);
    expect(s.txTotal).toBe(10);
  });
  it('is safe on garbage', () => {
    expect(normalizeStats(undefined).products).toBeUndefined();
    expect(normalizeStats('x').txTotal).toBeUndefined();
  });
  it('flatten + statNum', () => {
    const f = flatten({ a: { b: 1 }, c: [1, 2] });
    expect(statNum(f, 'a_b')).toBe(1);
    expect(statNum(f, 'nope', 'a_b')).toBe(1);
    expect(statNum(f, 'c')).toBeUndefined();
  });
});

describe('identityGrants', () => {
  const base = { id: 'x', org: 'o', kind: 'HUMAN', keys: [], status: 'ACTIVE' } as Identity;
  it('accepts an array or the {grants:[...]} record', () => {
    const g = { role: 'buyer', scope: '*', granted_height: 1, granted_by: 'genesis' };
    expect(identityGrants({ ...base, grants: [g] })).toHaveLength(1);
    expect(identityGrants({ ...base, grants: { grants: [g, g] } })).toHaveLength(2);
    expect(identityGrants(base)).toEqual([]);
  });
});

describe('normalizeGovernance', () => {
  it('unwraps the item wrapper and keeps defaults for missing sections', () => {
    const g = normalizeGovernance({ meta: { indexed_height: 5, chain_head: 5, lag_blocks: 0 }, item: { members: [{ id: 'val-hq' }], proposals: [], params: { max_lines: 100 } } });
    expect(g.members).toHaveLength(1);
    expect(g.upgrades).toEqual([]);
    expect(g.events).toEqual([]);
    expect(g.params.max_lines).toBe(100);
    expect(g.meta?.indexed_height).toBe(5);
  });
  it('accepts an upgrade map', () => {
    const g = normalizeGovernance({ upgrades: { '2': { version: 2 } } });
    expect(g.upgrades).toHaveLength(1);
  });
});

describe('small helpers', () => {
  it('groups, sums and reads tx ids', () => {
    expect(Object.keys(groupBy([1, 2, 3], (n) => (n % 2 ? 'odd' : 'even')))).toEqual(['odd', 'even']);
    expect(sumBy([{ a: 1 }, { a: 2 }], (r) => r.a)).toBe(3);
    expect(txIdOf({ tx_id: 'T' })).toBe('T');
    expect(txIdOf({ id: 'I' })).toBe('I');
  });
});
