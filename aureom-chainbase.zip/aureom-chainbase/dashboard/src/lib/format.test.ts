import { describe, expect, it } from 'vitest';
import {
  bftMath, clamp, compactJSON, dateInputToMs, formatBp, formatDate, formatDuration, formatInt, formatISO, formatMoney, formatQty, formatTime,
  healthTone, humanize, lagTone, lineValue, msToDateInput, parseTimeString, pct, shallowDiff, shortHash, timeAgo, txTypeLabel, unitLabel,
} from './format';

describe('formatMoney (integer minor units, no floating point)', () => {
  it('formats GBP pence', () => {
    expect(formatMoney(0)).toBe('£0.00');
    expect(formatMoney(5)).toBe('£0.05');
    expect(formatMoney(129)).toBe('£1.29');
    expect(formatMoney(123456789)).toBe('£1,234,567.89');
  });
  it('handles negatives and explicit plus', () => {
    expect(formatMoney(-250)).toBe('−£2.50');
    expect(formatMoney(250, 'GBP', { plus: true })).toBe('+£2.50');
    expect(formatMoney(0, 'GBP', { plus: true })).toBe('£0.00');
  });
  it('uses the currency exponent (JPY has none) and symbols', () => {
    expect(formatMoney(1500, 'JPY')).toBe('¥1,500');
    expect(formatMoney(1999, 'USD')).toBe('$19.99');
    expect(formatMoney(1999, 'EUR')).toBe('€19.99');
  });
  it('is exact at the 10^12 minor-unit ceiling', () => {
    expect(formatMoney(1_000_000_000_000)).toBe('£10,000,000,000.00');
    expect(formatMoney(999_999_999_999)).toBe('£9,999,999,999.99');
  });
  it('renders missing values as a dash', () => {
    expect(formatMoney(undefined)).toBe('–');
    expect(formatMoney(null)).toBe('–');
  });
});

describe('formatQty (quantity in the unit’s smallest step)', () => {
  it('shows whole units as integers', () => {
    expect(formatQty(12, 'EA')).toBe('12');
    expect(formatQty(12, 'PK')).toBe('12 pk');
    expect(formatQty(1234, 'EA', { unit: false })).toBe('1,234');
  });
  it('converts grams, millilitres and millimetres', () => {
    expect(formatQty(1250, 'KG')).toBe('1.25 kg');
    expect(formatQty(500, 'KG')).toBe('0.5 kg');
    expect(formatQty(3000, 'KG')).toBe('3 kg');
    expect(formatQty(1500, 'L')).toBe('1.5 L');
    expect(formatQty(2500, 'M')).toBe('2.5 m');
    expect(formatQty(5, 'KG')).toBe('0.005 kg');
    expect(formatQty(1234567, 'KG')).toBe('1,234.567 kg');
  });
  it('signs deltas', () => {
    expect(formatQty(-5500, 'KG', { unit: false })).toBe('−5.5');
    expect(formatQty(4, 'EA', { plus: true })).toBe('+4');
  });
  it('defaults unknown units to the raw unit label', () => {
    expect(unitLabel('BOX')).toBe('box');
    expect(formatQty(3, 'BOX')).toBe('3 box');
    expect(formatQty(undefined)).toBe('–');
  });
});

describe('percentages, integers, line values', () => {
  it('formats basis points', () => {
    expect(formatBp(1500)).toBe('15%');
    expect(formatBp(1250)).toBe('12.5%');
    expect(formatBp(1)).toBe('0.01%');
  });
  it('groups integers', () => {
    expect(formatInt(1234567)).toBe('1,234,567');
    expect(formatInt(-42)).toBe('−42');
  });
  it('computes line value from a per-whole-unit price', () => {
    expect(lineValue(109, 1500, 'KG')).toBe(164); // 1.5 kg at 1.09/kg = 1.635 -> 1.64 (rounded)
    expect(lineValue(299, 3, 'PK')).toBe(897);
  });
  it('pct and clamp', () => {
    expect(pct(27, 40)).toBe('68%');
    expect(pct(1, 0)).toBe('0%');
    expect(clamp(5, 0, 3)).toBe(3);
  });
});

describe('time formatting', () => {
  const ms = Date.UTC(2026, 10, 12, 14, 32, 5);
  it('formats UTC dates and times', () => {
    expect(formatDate(ms, true)).toBe('12 Nov 2026');
    expect(formatTime(ms, { utc: true })).toBe('12 Nov 2026, 14:32:05');
    expect(formatTime(ms, { utc: true, seconds: false })).toBe('12 Nov 2026, 14:32');
    expect(formatISO(ms)).toBe('2026-11-12T14:32:05.000Z');
    expect(formatTime(0)).toBe('–');
  });
  it('gives relative times', () => {
    expect(timeAgo(ms, ms + 2000)).toBe('just now');
    expect(timeAgo(ms, ms + 12_000)).toBe('12 s ago');
    expect(timeAgo(ms, ms + 4 * 60_000)).toBe('4 min ago');
    expect(timeAgo(ms, ms + 3 * 3_600_000)).toBe('3 h ago');
    expect(timeAgo(ms, ms + 2 * 86_400_000)).toBe('2 d ago');
    expect(timeAgo(ms + 90_000, ms)).toBe('in 2 min');
  });
  it('formats durations', () => {
    expect(formatDuration(420)).toBe('420 ms');
    expect(formatDuration(1180)).toBe('1.18 s');
    expect(formatDuration(12_500)).toBe('12.5 s');
    expect(formatDuration(125_000)).toBe('2 min 5 s');
    expect(formatDuration(undefined)).toBe('–');
  });
  it('parses gateway timestamps, including nanosecond RFC3339', () => {
    expect(parseTimeString('2026-11-12T14:32:05.118Z')).toBe(Date.UTC(2026, 10, 12, 14, 32, 5, 118));
    expect(parseTimeString('2026-11-12T14:32:05.118123456Z')).toBe(Date.UTC(2026, 10, 12, 14, 32, 5, 118));
    expect(parseTimeString('nonsense')).toBe(0);
    expect(parseTimeString(undefined)).toBe(0);
  });
  it('round-trips date inputs through local day boundaries', () => {
    const start = dateInputToMs('2026-11-12')!;
    const end = dateInputToMs('2026-11-12', true)!;
    expect(end - start).toBe(86_400_000 - 1);
    expect(msToDateInput(start)).toBe('2026-11-12');
    expect(dateInputToMs('')).toBeUndefined();
  });
});

describe('labels and tones', () => {
  it('humanizes codes, keeping acronyms', () => {
    expect(humanize('PARTIALLY_RECEIVED')).toBe('Partially received');
    expect(humanize('DUPLICATE_SKU')).toBe('Duplicate SKU');
    expect(humanize('ORPHAN_FK')).toBe('Orphan FK');
    expect(humanize(undefined)).toBe('–');
  });
  it('turns transaction types into words', () => {
    expect(txTypeLabel('CompleteSale')).toBe('Complete sale');
    expect(txTypeLabel('ApproveGovernance')).toBe('Approve governance');
  });
  it('lag thresholds: <=2 ok, 3..10 amber, >10 red', () => {
    expect(lagTone(0)).toBe('ok');
    expect(lagTone(2)).toBe('ok');
    expect(lagTone(3)).toBe('warn');
    expect(lagTone(10)).toBe('warn');
    expect(lagTone(11)).toBe('bad');
    expect(lagTone(null)).toBe('neutral');
  });
  it('health tones', () => {
    expect(healthTone('HEALTHY')).toBe('ok');
    expect(healthTone('DEGRADED')).toBe('warn');
    expect(healthTone('HALTED')).toBe('bad');
    expect(healthTone('???')).toBe('neutral');
  });
  it('shortens hashes', () => {
    expect(shortHash('ABCDEF0123456789ABCDEF0123456789', 8)).toBe('ABCDEF01…6789');
    expect(shortHash('ABC')).toBe('ABC');
    expect(shortHash(undefined)).toBe('–');
  });
  it('compacts JSON', () => {
    expect(compactJSON({ a: 1 })).toBe('{"a":1}');
    expect(compactJSON('x'.repeat(100), 10)).toBe('xxxxxxxxx…');
  });
});

describe('BFT arithmetic (n=4 validators, 10 power each)', () => {
  it('tolerates f=1 and needs more than two thirds', () => {
    const m = bftMath([10, 10, 10, 10]);
    expect(m).toMatchObject({ n: 4, total: 40, f: 1, quorum: 27 });
  });
  it('scales with n', () => {
    expect(bftMath([1, 1, 1, 1, 1, 1, 1]).f).toBe(2);
    expect(bftMath([5, 5, 5]).quorum).toBe(11);
    expect(bftMath([]).f).toBe(0);
  });
});

describe('shallowDiff (audit-history changes)', () => {
  it('reports changed, added and removed fields but ignores version bookkeeping', () => {
    const d = shallowDiff({ a: 1, b: 'x', version: 1, updated_height: 3 }, { a: 2, c: true, version: 2, updated_height: 9 });
    expect(d.map((x) => x.key).sort()).toEqual(['a', 'b', 'c']);
    expect(d.find((x) => x.key === 'a')).toMatchObject({ before: 1, after: 2 });
  });
  it('handles non-objects', () => {
    expect(shallowDiff(undefined, { a: 1 })).toHaveLength(1);
    expect(shallowDiff(null, null)).toHaveLength(0);
  });
});
