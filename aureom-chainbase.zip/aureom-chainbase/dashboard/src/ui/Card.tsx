import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import type { Tone } from '../lib/format';

export function PageHeader({ title, subtitle, actions, crumbs }: { title: ReactNode; subtitle?: ReactNode; actions?: ReactNode; crumbs?: ReactNode }) {
  return (
    <header className="page-header">
      <div>
        {crumbs && <div className="crumbs">{crumbs}</div>}
        <h1 className="page-title">{title}</h1>
        {subtitle && <div className="page-sub">{subtitle}</div>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

export function Card({ title, sub, actions, children, flush, foot, className = '', id }: { title?: ReactNode; sub?: ReactNode; actions?: ReactNode; children: ReactNode; flush?: boolean; foot?: ReactNode; className?: string; id?: string }) {
  return (
    <section className={`card ${className}`} id={id} aria-label={typeof title === 'string' ? title : undefined}>
      {(title || actions) && (
        <div className="card-head">
          <div style={{ minWidth: 0 }}>
            <h2 className="card-title">{title}</h2>
            {sub && <div className="card-sub">{sub}</div>}
          </div>
          {actions && <div className="row" style={{ marginLeft: 'auto' }}>{actions}</div>}
        </div>
      )}
      <div className={`card-body${flush ? ' flush' : ''}`}>{children}</div>
      {foot && <div className="card-foot">{foot}</div>}
    </section>
  );
}

export function Kpi({ label, value, note, tone, to }: { label: string; value: ReactNode; note?: ReactNode; tone?: Tone; to?: string }) {
  const cls = `kpi${to ? ' link' : ''}${tone && tone !== 'neutral' ? ` tone-${tone}` : ''}`;
  const inner = (
    <>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
      {note && <div className="kpi-note">{note}</div>}
    </>
  );
  return to ? (
    <Link to={to} className={cls}>
      {inner}
    </Link>
  ) : (
    <div className={cls}>{inner}</div>
  );
}

export function KV({ items, cols2 }: { items: [ReactNode, ReactNode][]; cols2?: boolean }) {
  return (
    <dl className={`kv${cols2 ? ' cols-2' : ''}`}>
      {items.map(([k, v], i) => (
        <div key={i} style={{ display: 'contents' }}>
          <dt>{k}</dt>
          <dd>{v ?? '–'}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Section({ title, children, right }: { title: ReactNode; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="section">
      <h3>
        {title}
        {right}
      </h3>
      {children}
    </section>
  );
}

export function Callout({ tone = 'neutral', children, icon }: { tone?: 'info' | 'warn' | 'bad' | 'ok' | 'neutral'; children: ReactNode; icon?: ReactNode }) {
  return (
    <div className={`callout ${tone === 'neutral' ? '' : tone}`} role={tone === 'bad' ? 'alert' : undefined}>
      {icon}
      <div style={{ minWidth: 0 }}>{children}</div>
    </div>
  );
}
