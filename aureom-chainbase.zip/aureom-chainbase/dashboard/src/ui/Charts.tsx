import { useEffect, useRef, useState, type ReactNode } from 'react';

function useWidth<T extends HTMLElement>(initial = 520): [React.RefObject<T>, number] {
  const ref = useRef<T>(null);
  const [w, setW] = useState(initial);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const set = () => setW(Math.max(160, Math.floor(el.getBoundingClientRect().width)));
    set();
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(set);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w];
}

/** "Nice" axis ticks from 0..max. */
export function niceTicks(max: number, count = 4): number[] {
  if (max <= 0) return [0, 1];
  const raw = max / count;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
  const ticks: number[] = [];
  for (let v = 0; v <= max + step * 0.999; v += step) ticks.push(Math.round(v * 1e6) / 1e6);
  return ticks;
}

/** Bar with only the data end (top) rounded, anchored at the baseline. */
function barPath(x: number, y: number, w: number, h: number, r = 3): string {
  const rr = Math.min(r, w / 2, h);
  return `M${x},${y + h} V${y + rr} Q${x},${y} ${x + rr},${y} H${x + w - rr} Q${x + w},${y} ${x + w},${y + rr} V${y + h} Z`;
}

export interface BarDatum {
  label: string;
  value: number;
  tip: ReactNode;
}

/** Single-series vertical bar chart (sales by day/location/channel). */
export function BarChart({ data, height = 190, format, ariaLabel, seriesName }: { data: BarDatum[]; height?: number; format: (v: number) => string; ariaLabel: string; seriesName: string }) {
  const [ref, width] = useWidth<HTMLDivElement>();
  const [hover, setHover] = useState<number | null>(null);
  const padL = 52, padR = 8, padT = 10, padB = 26;
  const w = width, h = height;
  const innerW = w - padL - padR, innerH = h - padT - padB;
  const max = Math.max(1, ...data.map((d) => d.value));
  const ticks = niceTicks(max);
  const top = ticks[ticks.length - 1] || 1;
  const slot = data.length ? innerW / data.length : innerW;
  const bw = Math.max(4, Math.min(34, slot - 4));
  const every = Math.max(1, Math.ceil(data.length / Math.max(1, Math.floor(innerW / 58))));
  const y = (v: number) => padT + innerH - (v / top) * innerH;
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <svg className="chart" width={w} height={h} role="img" aria-label={ariaLabel} onMouseLeave={() => setHover(null)}>
        {ticks.map((t) => (
          <g key={t}>
            <line className="grid-line" x1={padL} x2={w - padR} y1={y(t)} y2={y(t)} />
            <text x={padL - 6} y={y(t) + 3.5} textAnchor="end">{format(t)}</text>
          </g>
        ))}
        <line className="axis-line" x1={padL} x2={w - padR} y1={padT + innerH} y2={padT + innerH} />
        {data.map((d, i) => {
          const x = padL + i * slot + (slot - bw) / 2;
          const bh = Math.max(d.value > 0 ? 1 : 0, (d.value / top) * innerH);
          return (
            <g key={d.label + i}>
              <rect x={padL + i * slot} y={padT} width={slot} height={innerH} fill="transparent" onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} />
              {bh > 0 && (
                <path className="bar" d={barPath(x, padT + innerH - bh, bw, bh)} fill="var(--series-1)" tabIndex={0} onFocus={() => setHover(i)} onBlur={() => setHover(null)} onMouseEnter={() => setHover(i)} aria-label={`${d.label}: ${format(d.value)}`} />
              )}
              {i % every === 0 && (
                <text x={x + bw / 2} y={h - 8} textAnchor="middle">{d.label}</text>
              )}
            </g>
          );
        })}
      </svg>
      {hover !== null && data[hover] && (
        <div className="chart-tip" style={{ left: Math.min(Math.max(padL + hover * slot + slot / 2 - 60, 4), Math.max(4, w - 150)), top: 0 }}>
          <b>{data[hover].label}</b>
          <div className="muted">{seriesName}: {format(data[hover].value)}</div>
          <div>{data[hover].tip}</div>
        </div>
      )}
      <table className="sr-only">
        <caption>{ariaLabel}</caption>
        <thead><tr><th>Bucket</th><th>{seriesName}</th></tr></thead>
        <tbody>{data.map((d) => <tr key={d.label}><td>{d.label}</td><td>{format(d.value)}</td></tr>)}</tbody>
      </table>
    </div>
  );
}

export interface GroupDatum {
  label: string;
  values: { series: string; value: number }[];
}

/** Grouped bars for two series (e.g. admission vs finality at p50/p95/p99) with direct value labels. */
export function GroupedBars({ groups, series, height = 170, format, ariaLabel }: { groups: GroupDatum[]; series: { name: string; color: string }[]; height?: number; format: (v: number) => string; ariaLabel: string }) {
  const [ref, width] = useWidth<HTMLDivElement>(360);
  const padL = 8, padR = 8, padT = 18, padB = 24;
  const w = width, h = height;
  const innerW = w - padL - padR, innerH = h - padT - padB;
  const max = Math.max(1, ...groups.flatMap((g) => g.values.map((v) => v.value)));
  const slot = innerW / Math.max(1, groups.length);
  const bw = Math.min(40, (slot - 16) / series.length - 2);
  return (
    <div ref={ref}>
      <svg className="chart" width={w} height={h} role="img" aria-label={ariaLabel}>
        <line className="axis-line" x1={padL} x2={w - padR} y1={padT + innerH} y2={padT + innerH} />
        {groups.map((g, gi) => {
          const gw = series.length * (bw + 2) - 2;
          const gx = padL + gi * slot + (slot - gw) / 2;
          return (
            <g key={g.label}>
              {g.values.map((v, si) => {
                const bh = Math.max(v.value > 0 ? 2 : 0, (v.value / max) * innerH);
                const x = gx + si * (bw + 2);
                return (
                  <g key={v.series}>
                    <path className="bar" d={barPath(x, padT + innerH - bh, bw, bh)} fill={series[si].color} aria-label={`${g.label} ${v.series}: ${format(v.value)}`}>
                      <title>{`${g.label} ${v.series}: ${format(v.value)}`}</title>
                    </path>
                    <text x={x + bw / 2} y={padT + innerH - bh - 4} textAnchor="middle" style={{ fill: 'var(--text-2)', fontWeight: 600 }}>{format(v.value)}</text>
                  </g>
                );
              })}
              <text x={padL + gi * slot + slot / 2} y={h - 8} textAnchor="middle">{g.label}</text>
            </g>
          );
        })}
      </svg>
      <div className="chart-legend">
        {series.map((s) => (
          <span key={s.name}><i style={{ background: s.color }} />{s.name}</span>
        ))}
      </div>
    </div>
  );
}

/** Small trend line (2px stroke, end marker) for recent values. */
export function Sparkline({ values, height = 44, ariaLabel, color = 'var(--series-1)' }: { values: number[]; height?: number; ariaLabel: string; color?: string }) {
  const [ref, width] = useWidth<HTMLDivElement>(260);
  if (values.length < 2) return <div ref={ref} className="muted">Not enough data</div>;
  const pad = 4;
  const max = Math.max(...values), min = Math.min(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => [pad + (i / (values.length - 1)) * (width - pad * 2), pad + (1 - (v - min) / span) * (height - pad * 2)] as const);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const last = pts[pts.length - 1];
  return (
    <div ref={ref}>
      <svg className="sparkline chart" width={width} height={height} role="img" aria-label={ariaLabel}>
        <path d={d} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
        <circle cx={last[0]} cy={last[1]} r={4} fill={color} stroke="var(--surface)" strokeWidth={2} />
      </svg>
    </div>
  );
}
