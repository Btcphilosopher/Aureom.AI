import type { ReactNode } from 'react';
import type { UseQueryResult } from '@tanstack/react-query';
import type { ApiError } from '../api/client';

export function LoadingBlock({ rows = 5, label = 'Loading…' }: { rows?: number; label?: string }) {
  return (
    <div className="card-body" role="status" aria-live="polite" aria-label={label}>
      <div className="stack-sm">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="skeleton" style={{ width: `${92 - ((i * 13) % 40)}%`, height: 14 }} />
        ))}
      </div>
      <span className="sr-only">{label}</span>
    </div>
  );
}

export function EmptyState({ title = 'Nothing to show', children }: { title?: string; children?: ReactNode }) {
  return (
    <div className="state" role="status">
      <div className="state-title">{title}</div>
      {children && <div>{children}</div>}
    </div>
  );
}

export function ErrorState({ error, onRetry, title = 'Could not load this data' }: { error: unknown; onRetry?: () => void; title?: string }) {
  const e = error as ApiError | undefined;
  return (
    <div className="state error" role="alert">
      <div className="state-title">{title}</div>
      <div style={{ marginBottom: 8 }}>
        {e?.unreachable ? 'The gateway cannot be reached.' : e?.message ?? 'Unexpected error.'}
        {e?.status ? <span className="muted"> (HTTP {e.status}{e.code ? ` · ${e.code}` : ''})</span> : null}
      </div>
      {onRetry && (
        <button type="button" className="btn sm" onClick={onRetry}>
          Retry
        </button>
      )}
    </div>
  );
}

/**
 * Renders loading / error / empty / content for a query. `isEmpty` decides the empty state
 * from the loaded data. Children are only rendered when there is data and it is not empty.
 */
export function QueryBoundary<T>({
  q, isEmpty, emptyTitle, emptyText, rows, children,
}: { q: UseQueryResult<T, ApiError>; isEmpty?: (d: T) => boolean; emptyTitle?: string; emptyText?: ReactNode; rows?: number; children: (data: T) => ReactNode }) {
  if (q.isPending) return <LoadingBlock rows={rows} />;
  if (q.isError && !q.data) return <ErrorState error={q.error} onRetry={() => void q.refetch()} />;
  const d = q.data as T;
  if (isEmpty?.(d)) return <EmptyState title={emptyTitle}>{emptyText}</EmptyState>;
  return <>{children(d)}</>;
}
