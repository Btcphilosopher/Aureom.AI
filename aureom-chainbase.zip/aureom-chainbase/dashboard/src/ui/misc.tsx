import { useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { IconCheck, IconCopy, IconExternal } from './icons';

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="btn ghost sm icon"
      aria-label={`${label}: ${text.length > 40 ? text.slice(0, 40) + '…' : text}`}
      title={label}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1200);
        } catch {
          /* clipboard unavailable (insecure context): ignore */
        }
      }}
    >
      {done ? <IconCheck /> : <IconCopy />}
    </button>
  );
}

export function Json({ value, max = 360 }: { value: unknown; max?: number }) {
  let text: string;
  try {
    text = JSON.stringify(value, null, 2) ?? 'null';
  } catch {
    text = String(value);
  }
  return (
    <pre className="json" style={{ maxHeight: max }} tabIndex={0} aria-label="JSON document">
      {text}
    </pre>
  );
}

export function Hash({ value, copy = true }: { value?: string; copy?: boolean }) {
  if (!value) return <span className="muted">–</span>;
  return (
    <span className="row" style={{ gap: 2 }}>
      <span className="hash" title={value}>{value}</span>
      {copy && <CopyButton text={value} label="Copy hash" />}
    </span>
  );
}

/** Link to the Explorer record view for a state key (e.g. sale/S-1). */
export function ChainLink({ stateKey, children }: { stateKey: string; children?: ReactNode }) {
  return (
    <Link to={`/explorer/record?key=${encodeURIComponent(stateKey)}`} className="row nowrap" style={{ gap: 4, display: 'inline-flex' }}>
      {children ?? 'View on chain'} <IconExternal width={12} height={12} />
    </Link>
  );
}

export function TxLink({ id }: { id?: string }) {
  if (!id) return <span className="muted">–</span>;
  return (
    <Link to={`/explorer/tx/${encodeURIComponent(id)}`} className="mono" title="Open in Explorer">
      {id}
    </Link>
  );
}

export function KeyValueTags({ data }: { data?: Record<string, string> }) {
  const e = Object.entries(data ?? {});
  if (e.length === 0) return <span className="muted">None</span>;
  return (
    <div className="tag-list">
      {e.map(([k, v]) => (
        <span className="tag" key={k}>
          {k}: {v}
        </span>
      ))}
    </div>
  );
}
