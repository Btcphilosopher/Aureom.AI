const STAGES = [
  { id: 'SOURCE', desc: 'Legacy system is the system of record' },
  { id: 'FROZEN', desc: 'Legacy system frozen read-only; data being finalised' },
  { id: 'CHAIN', desc: 'Ledger is the system of record' },
] as const;

/** SOURCE -> FROZEN -> CHAIN indicator: which system is authoritative right now. */
export function StageIndicator({ current }: { current?: string }) {
  const idx = STAGES.findIndex((s) => s.id === current);
  return (
    <ol className="stages" aria-label={`Authoritative system: ${current ?? 'unknown'}`} style={{ listStyle: 'none', margin: 0, padding: 0 }}>
      {STAGES.map((s, i) => (
        <li key={s.id} className={`stage${i === idx ? ' current' : ''}${idx > i ? ' done' : ''}`} aria-current={i === idx ? 'step' : undefined}>
          <div className="stage-name">{s.id}{i === idx && <span className="sr-only"> (current)</span>}</div>
          <div className="stage-desc">{s.desc}</div>
        </li>
      ))}
    </ol>
  );
}
