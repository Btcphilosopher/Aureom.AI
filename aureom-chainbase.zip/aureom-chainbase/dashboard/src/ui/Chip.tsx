import type { ReactNode } from 'react';
import type { Tone } from '../lib/format';
import { statusMeta, type StatusKind } from '../lib/status';

export function Chip({ tone = 'neutral', children, dot, lg, title, square }: { tone?: Tone; children: ReactNode; dot?: boolean; lg?: boolean; title?: string; square?: boolean }) {
  return (
    <span className={`chip ${tone}${lg ? ' lg' : ''}${square ? ' square' : ''}`} title={title}>
      {dot && <span className="dot" aria-hidden />}
      {children}
    </span>
  );
}

/** Status chip with business-language labels per domain (payment, fulfilment, refund ...). */
export function StatusChip({ value, kind = 'generic', dot = true, lg, title }: { value: string | undefined | null; kind?: StatusKind; dot?: boolean; lg?: boolean; title?: string }) {
  const m = statusMeta(value, kind);
  return (
    <Chip tone={m.tone} dot={dot} lg={lg} title={title ?? (value ?? undefined)}>
      {m.label}
    </Chip>
  );
}

export function ProvenanceChip({ origin }: { origin?: string }) {
  if (!origin) return <span className="muted">–</span>;
  const imported = origin.startsWith('IMPORTED');
  return (
    <Chip tone={imported ? 'accent' : 'info'} square title={imported ? 'Imported from a legacy system: the legacy system’s assertion, not witnessed on this ledger' : 'Created natively on this ledger'}>
      {imported ? 'Imported' : 'Native'}
    </Chip>
  );
}
