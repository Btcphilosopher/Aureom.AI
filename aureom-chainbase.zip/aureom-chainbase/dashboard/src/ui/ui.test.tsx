import { describe, expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Chip, ProvenanceChip, StatusChip } from './Chip';
import { DataTable, type Column } from './DataTable';
import { Tabs } from './Tabs';
import { Staleness } from './Meta';
import { BarChart, GroupedBars, niceTicks } from './Charts';
import { ConfirmDialog, Drawer } from './Drawer';
import { ErrorState, QueryBoundary } from './States';
import { Tip } from './Tip';
import { StageIndicator } from './Stages';
import { ApiError } from '../api/client';

describe('chips', () => {
  it('renders tone classes and business labels', () => {
    render(<><Chip tone="ok">Fine</Chip><StatusChip kind="payment" value="CONFIRMED" /><StatusChip kind="refund" value="INSTRUCTED" /></>);
    expect(screen.getByText('Fine')).toHaveClass('chip', 'ok');
    expect(screen.getByText('Paid')).toHaveClass('ok');
    expect(screen.getByText('Refund instructed')).toHaveClass('warn');
  });
  it('distinguishes native from imported provenance', () => {
    render(<><ProvenanceChip origin="NATIVE" /><ProvenanceChip origin="IMPORTED" /></>);
    expect(screen.getByText('Native')).toHaveClass('info');
    expect(screen.getByText('Imported')).toHaveClass('accent');
  });
});

interface Row { id: string; name: string; qty: number }
const rows: Row[] = Array.from({ length: 30 }, (_, i) => ({ id: `R${String(i).padStart(2, '0')}`, name: i % 2 ? `Beta ${i}` : `Alpha ${i}`, qty: (i * 7) % 11 }));
const cols: Column<Row>[] = [
  { key: 'id', header: 'ID', sortValue: (r) => r.id, render: (r) => r.id },
  { key: 'name', header: 'Name', sortValue: (r) => r.name, render: (r) => r.name },
  { key: 'qty', header: 'Qty', align: 'right', sortValue: (r) => r.qty, render: (r) => r.qty },
];

describe('DataTable', () => {
  it('paginates, sorts and filters', async () => {
    const user = userEvent.setup();
    render(<DataTable caption="Rows" rows={rows} rowKey={(r) => r.id} columns={cols} pageSize={10} quickFilter={(r, q) => r.name.toLowerCase().includes(q)} />);
    expect(screen.getAllByRole('row')).toHaveLength(11); // header + 10
    expect(screen.getByText('1–10 of 30')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Next page' }));
    expect(screen.getByText('11–20 of 30')).toBeInTheDocument();

    // sort by Qty descending (asc, then desc)
    const qtyHeader = screen.getByRole('columnheader', { name: /Qty/ });
    expect(qtyHeader).toHaveAttribute('aria-sort', 'none');
    await user.click(within(qtyHeader).getByRole('button'));
    expect(qtyHeader).toHaveAttribute('aria-sort', 'ascending');
    await user.click(within(qtyHeader).getByRole('button'));
    expect(qtyHeader).toHaveAttribute('aria-sort', 'descending');
    const firstQty = within(screen.getAllByRole('row')[1]).getAllByRole('cell')[2];
    expect(firstQty).toHaveTextContent('10');

    // quick filter
    await user.type(screen.getByRole('searchbox'), 'alpha');
    expect(screen.getByText(/of 15/)).toBeInTheDocument();
  });
  it('shows an empty message and is keyboard operable', async () => {
    const onRow = vi.fn();
    const { rerender } = render(<DataTable caption="Rows" rows={rows.slice(0, 2)} rowKey={(r) => r.id} columns={cols} onRowClick={onRow} />);
    const first = screen.getAllByRole('row')[1];
    first.focus();
    await userEvent.keyboard('{Enter}');
    expect(onRow).toHaveBeenCalledWith(rows[0]);
    rerender(<DataTable caption="Rows" rows={[]} rowKey={(r) => r.id} columns={cols} emptyText="Nothing here" />);
    expect(screen.getByText('Nothing here')).toBeInTheDocument();
  });
  it('notes when the server has more rows than were loaded', () => {
    render(<DataTable caption="Rows" rows={rows.slice(0, 5)} rowKey={(r) => r.id} columns={cols} total={120} />);
    expect(screen.getByText(/120 match on the server/)).toBeInTheDocument();
  });
});

describe('Tabs', () => {
  it('supports arrow-key navigation', async () => {
    const onChange = vi.fn();
    render(<Tabs label="Views" value="a" onChange={onChange} items={[{ id: 'a', label: 'A' }, { id: 'b', label: 'B', count: 3 }]} />);
    const a = screen.getByRole('tab', { name: 'A' });
    a.focus();
    await userEvent.keyboard('{ArrowRight}');
    expect(onChange).toHaveBeenCalledWith('b');
    expect(screen.getByRole('tab', { name: /B/ })).toHaveAttribute('aria-selected', 'false');
    expect(a).toHaveAttribute('aria-selected', 'true');
  });
});

describe('Staleness', () => {
  it('is discreet when up to date and flags lag', () => {
    const { rerender } = render(<Staleness meta={{ indexed_height: 100, chain_head: 100, lag_blocks: 0 }} />);
    expect(screen.getByText(/as of block 100 · up to date/)).not.toHaveClass('warn');
    rerender(<Staleness meta={{ indexed_height: 100, chain_head: 106, lag_blocks: 6 }} />);
    expect(screen.getByText(/6 behind chain/)).toHaveClass('warn');
    rerender(<Staleness meta={{ indexed_height: 100, chain_head: 130, lag_blocks: 30 }} />);
    expect(screen.getByText(/30 behind chain/)).toHaveClass('bad');
  });
  it('renders nothing without meta', () => {
    const { container } = render(<Staleness meta={undefined} />);
    expect(container).toBeEmptyDOMElement();
  });
});

describe('charts', () => {
  it('computes tidy axis ticks', () => {
    expect(niceTicks(0)).toEqual([0, 1]);
    const t = niceTicks(1370);
    expect(t[0]).toBe(0);
    expect(t[t.length - 1]).toBeGreaterThanOrEqual(1370);
    expect(t).toEqual([0, 500, 1000, 1500]);
  });
  it('renders a bar chart with an accessible table fallback', () => {
    render(<BarChart ariaLabel="Net sales by day" seriesName="Net sales" format={(v) => `£${v / 100}`} data={[{ label: '10 Nov', value: 1000, tip: 'a' }, { label: '11 Nov', value: 2500, tip: 'b' }]} />);
    expect(screen.getByRole('img', { name: 'Net sales by day' })).toBeInTheDocument();
    expect(screen.getByRole('table', { hidden: true })).toBeInTheDocument();
    expect(screen.getAllByText('£25', { exact: false }).length).toBeGreaterThan(0);
  });
  it('renders grouped bars with a legend', () => {
    render(<GroupedBars ariaLabel="Latency" format={(v) => `${v} ms`} series={[{ name: 'Submission', color: 'red' }, { name: 'Finalisation', color: 'blue' }]} groups={[{ label: 'p50', values: [{ series: 'Submission', value: 6 }, { series: 'Finalisation', value: 1180 }] }]} />);
    expect(screen.getByText('Submission')).toBeInTheDocument();
    expect(screen.getByText('1180 ms')).toBeInTheDocument();
  });
});

describe('overlays', () => {
  it('Drawer closes on Escape and labels itself', async () => {
    const onClose = vi.fn();
    render(<Drawer title="Product P-1" onClose={onClose}><button>inside</button></Drawer>);
    expect(screen.getByRole('dialog', { name: 'Product P-1' })).toBeInTheDocument();
    await userEvent.keyboard('{Escape}');
    expect(onClose).toHaveBeenCalled();
  });
  it('ConfirmDialog requires an explicit confirm', async () => {
    const onConfirm = vi.fn();
    const onCancel = vi.fn();
    render(<ConfirmDialog title="Rebuild?" confirmLabel="Rebuild now" danger onConfirm={onConfirm} onCancel={onCancel}>This drops the index.</ConfirmDialog>);
    expect(screen.getByRole('alertdialog', { name: 'Rebuild?' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(onCancel).toHaveBeenCalled();
    expect(onConfirm).not.toHaveBeenCalled();
    await userEvent.click(screen.getByRole('button', { name: 'Rebuild now' }));
    expect(onConfirm).toHaveBeenCalled();
  });
});

describe('states and help', () => {
  it('ErrorState distinguishes an unreachable gateway and offers retry', async () => {
    const retry = vi.fn();
    render(<ErrorState error={new ApiError('x', 0, 'UNREACHABLE', true)} onRetry={retry} />);
    expect(screen.getByRole('alert')).toHaveTextContent('gateway cannot be reached');
    await userEvent.click(screen.getByRole('button', { name: 'Retry' }));
    expect(retry).toHaveBeenCalled();
  });
  it('QueryBoundary shows loading, error and empty states', () => {
    const base = { refetch: vi.fn(), data: undefined, error: null, isPending: true, isError: false };
    const { rerender } = render(<QueryBoundary q={base as never}>{() => <div>content</div>}</QueryBoundary>);
    expect(screen.getByRole('status')).toBeInTheDocument();
    rerender(<QueryBoundary q={{ ...base, isPending: false, isError: true, error: new ApiError('boom', 500) } as never}>{() => <div>content</div>}</QueryBoundary>);
    expect(screen.getByRole('alert')).toHaveTextContent('boom');
    rerender(<QueryBoundary q={{ ...base, isPending: false, data: { items: [] } } as never} isEmpty={(d: { items: unknown[] }) => d.items.length === 0} emptyTitle="No rows">{() => <div>content</div>}</QueryBoundary>);
    expect(screen.getByText('No rows')).toBeInTheDocument();
    rerender(<QueryBoundary q={{ ...base, isPending: false, data: { items: [1] } } as never} isEmpty={(d: { items: unknown[] }) => d.items.length === 0}>{() => <div>content</div>}</QueryBoundary>);
    expect(screen.getByText('content')).toBeInTheDocument();
  });
  it('Tip shows on focus and hides on Escape', async () => {
    render(<Tip>Explains the thing</Tip>);
    await userEvent.tab();
    expect(screen.getByRole('button', { name: 'More information' })).toHaveFocus();
    expect(screen.getByRole('tooltip')).toHaveTextContent('Explains the thing');
    await userEvent.keyboard('{Escape}');
    expect(screen.queryByRole('tooltip')).toBeNull();
  });
  it('StageIndicator marks the current authoritative system', () => {
    render(<StageIndicator current="FROZEN" />);
    expect(screen.getByRole('list', { name: /Authoritative system: FROZEN/ })).toBeInTheDocument();
    expect(screen.getByText('FROZEN').closest('li')).toHaveClass('current');
    expect(screen.getByText('SOURCE').closest('li')).toHaveClass('done');
  });
});
