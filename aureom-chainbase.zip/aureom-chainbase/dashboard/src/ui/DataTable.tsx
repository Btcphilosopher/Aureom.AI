import { useEffect, useMemo, useState, type KeyboardEvent, type ReactNode } from 'react';
import { Tip } from './Tip';
import { IconChevronL, IconChevronR } from './icons';

export interface Column<T> {
  key: string;
  header: ReactNode;
  /** Small "?" explanation shown next to the header. */
  tip?: ReactNode;
  render: (row: T) => ReactNode;
  /** Provide to make the column sortable. */
  sortValue?: (row: T) => string | number | null | undefined;
  align?: 'right';
  mono?: boolean;
  wrap?: boolean;
  width?: string | number;
}

export interface SortState {
  key: string;
  dir: 'asc' | 'desc';
}

export interface DataTableProps<T> {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  caption: string;
  onRowClick?: (row: T) => void;
  selectedKey?: string | null;
  initialSort?: SortState;
  pageSize?: number;
  /** Adds a local text filter box that filters the already loaded rows. */
  quickFilter?: (row: T, q: string) => boolean;
  filterPlaceholder?: string;
  emptyText?: ReactNode;
  /** Server-side total, when more rows exist than were loaded. */
  total?: number;
  footerLeft?: ReactNode;
  rowClass?: (row: T) => string | undefined;
  compact?: boolean;
  toolbar?: ReactNode;
}

const cmp = (a: string | number | null | undefined, b: string | number | null | undefined) => {
  const an = a === null || a === undefined;
  const bn = b === null || b === undefined;
  if (an && bn) return 0;
  if (an) return 1;
  if (bn) return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
};

export function DataTable<T>({
  columns, rows, rowKey, caption, onRowClick, selectedKey, initialSort, pageSize = 25, quickFilter, filterPlaceholder = 'Filter loaded rows…', emptyText, total, footerLeft, rowClass, compact, toolbar,
}: DataTableProps<T>) {
  const [sort, setSort] = useState<SortState | undefined>(initialSort);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(pageSize);
  const [filter, setFilter] = useState('');

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    return q && quickFilter ? rows.filter((r) => quickFilter(r, q)) : rows;
  }, [rows, filter, quickFilter]);

  const sorted = useMemo(() => {
    if (!sort) return filtered;
    const col = columns.find((c) => c.key === sort.key);
    if (!col?.sortValue) return filtered;
    const sv = col.sortValue;
    const m = sort.dir === 'asc' ? 1 : -1;
    return [...filtered].sort((a, b) => m * cmp(sv(a), sv(b)));
  }, [filtered, sort, columns]);

  const pages = Math.max(1, Math.ceil(sorted.length / size));
  useEffect(() => {
    if (page > pages - 1) setPage(0);
  }, [pages, page]);
  useEffect(() => setPage(0), [rows]);
  const slice = sorted.slice(page * size, page * size + size);

  const toggle = (key: string) => {
    setPage(0);
    setSort((s) => (!s || s.key !== key ? { key, dir: 'asc' } : s.dir === 'asc' ? { key, dir: 'desc' } : undefined));
  };

  const onKey = (e: KeyboardEvent, row: T) => {
    if (!onRowClick) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onRowClick(row);
    }
  };

  const from = sorted.length === 0 ? 0 : page * size + 1;
  const to = Math.min(sorted.length, page * size + size);

  return (
    <div>
      {(quickFilter || toolbar) && (
        <div className="toolbar" style={{ alignItems: 'center' }}>
          {quickFilter && (
            <input className="input" style={{ width: 240 }} type="search" aria-label={`${caption}: ${filterPlaceholder}`} placeholder={filterPlaceholder} value={filter} onChange={(e) => setFilter(e.target.value)} />
          )}
          {toolbar}
        </div>
      )}
      <div className="table-wrap">
        <table className={`dt${compact ? ' compact' : ''}`}>
          <caption className="sr-only">{caption}</caption>
          <thead>
            <tr>
              {columns.map((c) => {
                const active = sort?.key === c.key;
                return (
                  <th
                    key={c.key}
                    scope="col"
                    className={c.align === 'right' ? 'num' : undefined}
                    style={c.width ? { width: c.width } : undefined}
                    aria-sort={active ? (sort!.dir === 'asc' ? 'ascending' : 'descending') : c.sortValue ? 'none' : undefined}
                  >
                    <span className="row" style={{ gap: 4, justifyContent: c.align === 'right' ? 'flex-end' : undefined }}>
                      {c.sortValue ? (
                        <button type="button" className="sort" onClick={() => toggle(c.key)}>
                          {c.header}
                          <span className="sort-ind" aria-hidden>{active ? (sort!.dir === 'asc' ? '▲' : '▼') : '↕'}</span>
                        </button>
                      ) : (
                        c.header
                      )}
                      {c.tip && <Tip label={`About ${typeof c.header === 'string' ? c.header : 'this column'}`}>{c.tip}</Tip>}
                    </span>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {slice.map((row) => {
              const k = rowKey(row);
              return (
                <tr
                  key={k}
                  className={`${onRowClick ? 'clickable' : ''}${selectedKey === k ? ' selected' : ''} ${rowClass?.(row) ?? ''}`}
                  tabIndex={onRowClick ? 0 : undefined}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  onKeyDown={onRowClick ? (e) => onKey(e, row) : undefined}
                  aria-selected={selectedKey === k ? true : undefined}
                >
                  {columns.map((c) => (
                    <td key={c.key} className={`${c.align === 'right' ? 'num' : ''}${c.mono ? ' mono' : ''}${c.wrap ? ' wrap' : ''}`}>
                      {c.render(row)}
                    </td>
                  ))}
                </tr>
              );
            })}
            {slice.length === 0 && (
              <tr>
                <td colSpan={columns.length}>
                  <div className="state">{emptyText ?? (filter ? 'No rows match the filter.' : 'No rows.')}</div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="table-foot">
        <span>
          {sorted.length === 0 ? '0 rows' : `${from}–${to} of ${sorted.length}`}
          {total !== undefined && total > rows.length && <> · {total} match on the server (first {rows.length} loaded)</>}
          {filter && <> · filtered from {rows.length}</>}
        </span>
        {footerLeft}
        <span className="pager">
          <label className="row" style={{ gap: 4 }}>
            <span className="muted">Rows</span>
            <select className="select" style={{ height: 24, fontSize: 12 }} value={size} onChange={(e) => { setSize(Number(e.target.value)); setPage(0); }} aria-label="Rows per page">
              {Array.from(new Set([10, 25, 50, 100, pageSize])).sort((a, b) => a - b).map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </label>
          <button type="button" className="btn sm icon" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} aria-label="Previous page"><IconChevronL /></button>
          <span style={{ minWidth: 64, textAlign: 'center' }}>Page {page + 1} / {pages}</span>
          <button type="button" className="btn sm icon" onClick={() => setPage((p) => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1} aria-label="Next page"><IconChevronR /></button>
        </span>
      </div>
    </div>
  );
}
