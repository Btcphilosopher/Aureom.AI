import type { ProjectionMeta } from '../api/types';
import { lagTone } from '../lib/format';

/** Discreet staleness note for projection-backed data: "as of block 142 · lag 0". */
export function Staleness({ meta, fetchedAt }: { meta?: ProjectionMeta; fetchedAt?: number }) {
  if (!meta) return null;
  const tone = lagTone(meta.lag_blocks);
  const cls = tone === 'bad' ? 'bad' : tone === 'warn' ? 'warn' : '';
  const stateNote = meta.projection_state && meta.projection_state !== 'OK' ? ` · projection ${meta.projection_state.toLowerCase()}` : '';
  return (
    <span className={`meta-note ${cls}`} title="Projection data is derived from finalised blocks. It can trail the chain head by a few blocks.">
      as of block {meta.indexed_height}
      {meta.lag_blocks > 0 ? ` · ${meta.lag_blocks} behind chain` : ' · up to date'}
      {stateNote}
      {fetchedAt ? ` · fetched ${new Date(fetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}` : ''}
    </span>
  );
}
