import { useId, useState, type ReactNode } from 'react';

/** Accessible "?" help tooltip, shown on hover and keyboard focus. */
export function Tip({ children, label = 'More information', align = 'left' }: { children: ReactNode; label?: string; align?: 'left' | 'right' }) {
  const id = useId();
  const [open, setOpen] = useState(false);
  return (
    <span className="tip" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <button
        type="button"
        className="tip-btn"
        aria-label={label}
        aria-describedby={open ? id : undefined}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
      >
        ?
      </button>
      {open && (
        <span role="tooltip" id={id} className={`tip-pop${align === 'right' ? ' right' : ''}`}>
          {children}
        </span>
      )}
    </span>
  );
}
