import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useChainStatus } from '../api/chainStatus';
import { Chip } from '../ui/Chip';
import { healthTone, formatInt, lagTone, timeAgo } from '../lib/format';
import { useNow, useTheme } from '../lib/hooks';
import {
  IconAdmin, IconAlert, IconExplorer, IconInfo, IconInventory, IconLoyalty, IconMenu, IconMigration, IconMoon, IconNetwork,
  IconOverview, IconPrices, IconProducts, IconSales, IconSuppliers, IconSun,
} from '../ui/icons';

export const NAV = [
  { to: '/', label: 'Overview', icon: IconOverview, end: true },
  { to: '/network', label: 'Network', icon: IconNetwork },
  { to: '/products', label: 'Products', icon: IconProducts },
  { to: '/inventory', label: 'Inventory', icon: IconInventory },
  { to: '/sales', label: 'Sales', icon: IconSales },
  { to: '/suppliers', label: 'Suppliers', icon: IconSuppliers },
  { to: '/prices', label: 'Prices', icon: IconPrices },
  { to: '/loyalty', label: 'Loyalty', icon: IconLoyalty },
  { to: '/migration', label: 'Migration', icon: IconMigration },
  { to: '/explorer', label: 'Explorer', icon: IconExplorer },
  { to: '/administration', label: 'Administration', icon: IconAdmin },
] as const;

function BrandMark() {
  return (
    <svg className="brand-mark" viewBox="0 0 32 32" aria-hidden>
      <rect width="32" height="32" rx="7" fill="#1b2f4d" />
      <path d="M8 22 16 8l8 14h-4.2L16 15.2 12.2 22z" fill="#6da7ec" />
      <rect x="9" y="24" width="14" height="2" rx="1" fill="#6da7ec" />
    </svg>
  );
}

function sectionName(pathname: string): string {
  const seg = pathname.split('/')[1];
  const n = NAV.find((x) => (x.to === '/' ? seg === '' : x.to === '/' + seg));
  return n?.label ?? 'Console';
}

export function LagChip({ lag, state }: { lag: number | null; state?: string }) {
  if (state === 'REBUILDING') return <Chip tone="warn" dot>Rebuilding</Chip>;
  if (state === 'EMPTY') return <Chip tone="warn" dot>Not indexed</Chip>;
  if (lag === null) return <Chip tone="neutral">–</Chip>;
  return (
    <Chip tone={lagTone(lag)} dot title="Blocks the query projection is behind the finalised chain head. Amber above 2, red above 10.">
      {lag} {lag === 1 ? 'block' : 'blocks'}
    </Chip>
  );
}

export function HealthChip() {
  const s = useChainStatus();
  const tone = s.health === 'UNREACHABLE' ? 'bad' : healthTone(s.health);
  return (
    <Chip tone={tone} dot lg title="Network health from the validators’ consensus status">
      {s.health === 'UNKNOWN' ? 'CONNECTING' : s.health}
    </Chip>
  );
}

function TopBar({ onMenu }: { onMenu: () => void }) {
  const s = useChainStatus();
  const loc = useLocation();
  const [theme, toggle] = useTheme();
  return (
    <header className="topbar">
      <button type="button" className="btn ghost icon menu-btn" onClick={onMenu} aria-label="Open navigation menu">
        <IconMenu />
      </button>
      <div className="topbar-title">
        AUREOM CHAINBASE <span aria-hidden>/</span> <b>{sectionName(loc.pathname)}</b>
      </div>
      <div className="topbar-metrics" role="group" aria-label="Chain status">
        <div className="metric hide-sm" title="Latest finalised block height">
          <span className="metric-label">Finalised height</span>
          <span className="metric-value" data-testid="top-head">{s.head === null ? '–' : formatInt(s.head)}</span>
        </div>
        <div className="metric hide-sm" title="Highest block the query projection has processed">
          <span className="metric-label">Indexed height</span>
          <span className="metric-value" data-testid="top-indexed">{s.indexed === null ? '–' : formatInt(s.indexed)}</span>
        </div>
        <div className="metric" title="Projection lag">
          <span className="metric-label">Lag</span>
          <span className="metric-value"><LagChip lag={s.lag} state={s.projectionState} /></span>
        </div>
        <span className="topbar-sep" aria-hidden />
        <HealthChip />
        <button type="button" className="btn ghost icon" onClick={toggle} aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'} title="Toggle light / dark theme">
          {theme === 'dark' ? <IconSun /> : <IconMoon />}
        </button>
      </div>
    </header>
  );
}

function StatusBar() {
  const s = useChainStatus();
  const now = useNow(1000);
  const tone = s.health === 'UNREACHABLE' ? 'bad' : healthTone(s.health);
  return (
    <footer className="statusbar" role="contentinfo" aria-label="Chain height, indexed height and lag">
      <span className="sb-item">
        <span className={`dot ${tone === 'neutral' ? '' : tone}${s.reachable ? '' : ' pulse'}`} aria-hidden />
        {s.reachable ? 'Gateway connected' : 'Gateway unreachable'}
      </span>
      <span className="sb-item">Chain height <b data-testid="foot-head">{s.head === null ? '–' : formatInt(s.head)}</b></span>
      <span className="sb-item">Indexed height <b data-testid="foot-indexed">{s.indexed === null ? '–' : formatInt(s.indexed)}</b></span>
      <span className="sb-item">Lag <b data-testid="foot-lag" className={lagTone(s.lag) === 'bad' ? 'lag-bad' : undefined} style={{ color: lagTone(s.lag) === 'bad' ? 'var(--bad-fg)' : lagTone(s.lag) === 'warn' ? 'var(--warn-fg)' : undefined }}>{s.lag === null ? '–' : `${s.lag} ${s.lag === 1 ? 'block' : 'blocks'}`}</b></span>
      <span className="sb-item hide-sm">Network <b>{s.networkId || '–'}</b>{s.appVersion !== null && <> · state machine v{s.appVersion}</>}</span>
      <span className="spacer" />
      <span className="sb-item hide-sm">{s.updatedAt ? `Updated ${timeAgo(s.updatedAt, now)}` : 'Waiting for gateway…'}</span>
    </footer>
  );
}

function Banners() {
  const s = useChainStatus();
  if (!s.reachable) {
    return (
      <div className="banner bad" role="alert">
        <IconAlert />
        <div>
          <b>Gateway unreachable.</b> The console cannot read chain or projection data right now{s.updatedAt ? '; figures shown are the last known values' : ''}. Retrying automatically every few seconds.
          {s.error && <span className="muted" style={{ color: 'inherit', opacity: 0.8 }}> ({s.error})</span>}
        </div>
      </div>
    );
  }
  const out = [];
  if (s.health === 'HALTED') {
    out.push(
      <div className="banner bad" role="alert" key="halt">
        <IconAlert />
        <div><b>Network halted.</b> Fewer validators than the voting quorum are online, so no transaction can be finalised. The chain does not fork and committed data stays intact; it resumes when enough validators return. Open <NavLink to="/network" style={{ color: 'inherit', textDecoration: 'underline' }}>Network</NavLink> for details.</div>
      </div>,
    );
  } else if (s.health === 'DEGRADED') {
    out.push(
      <div className="banner warn" key="deg">
        <IconAlert />
        <div><b>Network degraded.</b> A validator is offline or unhealthy. Transactions still finalise, but the network has no remaining fault tolerance. See <NavLink to="/network" style={{ color: 'inherit', textDecoration: 'underline' }}>Network</NavLink>.</div>
      </div>,
    );
  }
  if (s.projectionState === 'REBUILDING') {
    out.push(
      <div className="banner warn" key="rebuild">
        <IconInfo />
        <div><b>Query projection is rebuilding</b> from block 1 ({formatInt(s.indexed ?? 0)} of {formatInt(s.head ?? 0)} replayed). Lists on this console show partial data until it catches up. Chain data is not affected.</div>
      </div>,
    );
  } else if (s.lag !== null && s.lag > 10) {
    out.push(
      <div className="banner warn" key="lag">
        <IconInfo />
        <div><b>Query data is {s.lag} blocks behind the chain.</b> Tables on this console may not show the most recent activity yet.</div>
      </div>,
    );
  }
  return <>{out}</>;
}

export function Shell() {
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  useEffect(() => {
    const t = sectionName(loc.pathname);
    document.title = `${t} · AUREOM CHAINBASE`;
  }, [loc.pathname]);
  const s = useChainStatus();
  return (
    <div className="app">
      <a href="#main" className="skip-link">Skip to content</a>
      {open && <div className="overlay" style={{ zIndex: 65 }} onClick={() => setOpen(false)} aria-hidden />}
      <aside className={`sidebar${open ? ' open' : ''}`} aria-label="Primary">
        <div className="brand">
          <BrandMark />
          <div className="brand-text">
            <div className="brand-name">AUREOM</div>
            <div className="brand-sub">CHAINBASE · Operations</div>
          </div>
        </div>
        <nav className="nav" aria-label="Sections">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={'end' in n ? n.end : false} className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`} title={n.label}>
              <n.icon />
              <span>{n.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div><strong>Read-only console</strong></div>
          <div>{s.networkId || 'Connecting…'}</div>
        </div>
      </aside>
      <div className="main">
        <TopBar onMenu={() => setOpen(true)} />
        <Banners />
        <main className="content" id="main" tabIndex={-1}>
          <Outlet />
        </main>
        <StatusBar />
      </div>
    </div>
  );
}
