import { Link } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems, metaOf } from '../api/client';
import type { MigrationBatch, MigrationState, ReportListRow } from '../api/types';
import { formatInt, formatTime, humanize, parseTimeString, shortHash } from '../lib/format';
import { Callout, Card, KV, PageHeader } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable } from '../ui/DataTable';
import { Hash, TxLink } from '../ui/misc';
import { StageIndicator } from '../ui/Stages';
import { ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconInfo } from '../ui/icons';

export const IMPORT_STATEMENT = 'Imported history is the legacy system’s assertion. Reconciliation shows the import matches the source snapshot; it does not prove the legacy data was correct.';

export function RunKindChip({ trial, lg }: { trial: boolean; lg?: boolean }) {
  return <Chip tone={trial ? 'warn' : 'info'} square lg={lg} title={trial ? 'Rehearsal run: does not change which system is authoritative' : 'Production run'}>{trial ? 'TRIAL' : 'PRODUCTION'}</Chip>;
}

interface MigRoot { state?: MigrationState; batches?: MigrationBatch[]; item?: { state?: MigrationState; batches?: MigrationBatch[] } & Partial<MigrationState> }

const WINDOW_TEXT: Record<string, string> = {
  NOT_STARTED: 'The import window has not been opened. The legacy system remains authoritative.',
  OPEN: 'The import window is open: authorised migration batches may be loaded. The legacy system should be frozen for the final run.',
  CLOSED: 'The import window is closed. No further imports are accepted; the ledger is the system of record.',
};

export default function Migration() {
  const q = useApi<MigRoot>('/q/migration');
  const rep = useApi<ReportListRow[] | { items: ReportListRow[] }>('/migration/reports');
  const state = q.data?.state ?? q.data?.item?.state ?? (q.data?.item as MigrationState | undefined);
  const batches = (q.data?.batches ?? q.data?.item?.batches ?? []) as MigrationBatch[];
  const reports = asItems<ReportListRow>(rep.data).sort((a, b) => parseTimeString(b.generated_at) - parseTimeString(a.generated_at));
  const latestProd = reports.find((r) => !r.trial);
  const authoritative = state?.status === 'CLOSED' ? 'CHAIN' : state?.status === 'OPEN' ? 'FROZEN' : 'SOURCE';
  const matched = state?.reconciliation_report_hash ? reports.find((r) => r.sha256 === state.reconciliation_report_hash) : undefined;

  const counters = state ? Array.from(new Set([...Object.keys(state.chain_counters ?? {}), ...Object.keys(state.attested_totals ?? {})])).sort() : [];

  return (
    <div className="page">
      <PageHeader title="Migration" subtitle="Cut-over from the legacy retail system: on-chain import window, batches and reconciliation reports." />
      <div className="mb"><Callout tone="info" icon={<IconInfo />}><span><b>{IMPORT_STATEMENT}</b> Records created by an import are labelled <Chip tone="accent" square>Imported</Chip> everywhere and keep their source id, batch and mapping version.</span></Callout></div>

      <Card title="Authoritative system" sub="Which system is the system of record right now" className="mb">
        <StageIndicator current={authoritative} />
        <p className="muted" style={{ marginTop: 8 }}>Derived from the on-chain window state{latestProd ? ` and the latest production report (${latestProd.id}, ${latestProd.decision})` : ''}. Trial runs never change the authoritative system.</p>
      </Card>

      <div className="grid cols-2 mb">
        <Card title="On-chain migration state" sub="Read from the ledger (mig/state)" foot={<Staleness meta={metaOf(q.data)} />}>
          {q.isPending ? <LoadingBlock rows={6} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : !state ? <div className="state">No migration state recorded.</div> : (
            <div className="stack-sm">
              <div className="row wrap"><span className="muted">Import window</span> <StatusChip value={state.status} lg /> <span className="muted">{WINDOW_TEXT[state.status]}</span></div>
              <KV items={[
                ['Source system', state.source_system || '–'],
                ['Opened at height', state.opened_height ? <Link to={`/explorer/block/${state.opened_height}`}>{formatInt(state.opened_height)}</Link> : '–'],
                ['Closed at height', state.closed_height ? <Link to={`/explorer/block/${state.closed_height}`}>{formatInt(state.closed_height)}</Link> : '–'],
                ['Batches imported', formatInt(state.batches)],
                ['Records imported', formatInt(state.records)],
                ['Source freeze marker', <span className="mono">{state.source_freeze_marker || '–'}</span>],
                ['Opening manifest hash', <Hash value={state.open_manifest_hash} />],
                ['Reconciliation report hash', <Hash value={state.reconciliation_report_hash} />],
                ['Matches stored report', matched ? <span className="row" style={{ gap: 6 }}><Chip tone="ok" dot>Match</Chip><Link to={`/migration/reports/${encodeURIComponent(matched.id)}`} className="mono">{matched.id}</Link></span> : state.reconciliation_report_hash ? <Chip tone="warn" dot>No stored report has this hash</Chip> : <span className="muted">Window not closed</span>],
              ]} />
            </div>
          )}
        </Card>
        <Card title="Chain counters vs attested source totals" sub="Counts on the ledger compared with totals the migration operator attested at close" flush>
          {!state ? <div className="state">–</div> : counters.length === 0 ? <div className="state">No counters yet.</div> : (
            <div className="table-wrap"><table className="dt compact">
              <caption className="sr-only">Chain counters versus attested totals</caption>
              <thead><tr><th>Entity</th><th className="num">On the ledger</th><th className="num">Attested by source</th><th className="num">Difference</th><th>Result</th></tr></thead>
              <tbody>{counters.map((k) => {
                const c = state.chain_counters?.[k];
                const a = state.attested_totals?.[k];
                const d = c !== undefined && a !== undefined ? c - a : undefined;
                return (<tr key={k}><td>{humanize(k)}</td><td className="num">{c === undefined ? '–' : formatInt(c)}</td><td className="num">{a === undefined ? '–' : formatInt(a)}</td><td className="num" style={{ color: d ? 'var(--bad-fg)' : undefined }}>{d === undefined ? '–' : formatInt(d)}</td><td>{d === undefined ? <span className="muted">not attested</span> : d === 0 ? <Chip tone="ok" dot>Match</Chip> : <Chip tone="bad" dot>Differs</Chip>}</td></tr>);
              })}</tbody>
            </table></div>
          )}
        </Card>
      </div>

      <Card title="Reconciliation reports" sub="Produced by the migration tool; stored by the gateway. The closing report’s hash is recorded on the ledger." flush className="mb">
        {rep.isPending ? <LoadingBlock rows={4} /> : rep.isError && !rep.data ? <ErrorState error={rep.error} onRetry={() => void rep.refetch()} /> : reports.length === 0 ? <div className="state"><div className="state-title">No reports yet</div>Run the migration tool and post its report to the gateway.</div> : (
          <DataTable<ReportListRow> caption="Reconciliation reports" rows={reports} rowKey={(r) => r.id} pageSize={10} initialSort={{ key: 'gen', dir: 'desc' }}
            columns={[
              { key: 'id', header: 'Report', mono: true, sortValue: (r) => r.id, render: (r) => <Link to={`/migration/reports/${encodeURIComponent(r.id)}`}>{r.id}</Link> },
              { key: 'phase', header: 'Phase', sortValue: (r) => r.phase, render: (r) => humanize(r.phase) },
              { key: 'kind', header: 'Run type', sortValue: (r) => Number(r.trial), render: (r) => <RunKindChip trial={r.trial} /> },
              { key: 'gen', header: 'Generated', sortValue: (r) => parseTimeString(r.generated_at), render: (r) => formatTime(parseTimeString(r.generated_at), { seconds: false }) },
              { key: 'dec', header: 'Decision', sortValue: (r) => r.decision, render: (r) => <StatusChip value={r.decision} /> },
              { key: 'sha', header: 'SHA-256', mono: true, render: (r) => <span title={r.sha256}>{shortHash(r.sha256, 10)}</span> },
              { key: 'chain', header: 'On ledger', render: (r) => (state?.reconciliation_report_hash === r.sha256 ? <Chip tone="ok" dot>Hash recorded at close</Chip> : <span className="muted">–</span>) },
            ]}
          />
        )}
      </Card>

      <Card title="Import batches" sub="Signed bulk-import transactions finalised on the ledger" flush foot={<Staleness meta={metaOf(q.data)} />}>
        <QueryBoundary q={q} isEmpty={() => batches.length === 0} emptyTitle="No batches" emptyText="No import batches have been recorded.">
          {() => (
            <DataTable<MigrationBatch> caption="Import batches" rows={batches} rowKey={(b, ) => String(b.id ?? b.batch_id ?? b.tx_id ?? Math.random())} pageSize={10}
              columns={[
                { key: 'id', header: 'Batch', mono: true, sortValue: (b) => String(b.id ?? b.batch_id), render: (b) => String(b.id ?? b.batch_id ?? '–') },
                { key: 'ent', header: 'Entity', sortValue: (b) => b.entity, render: (b) => (b.entity ? humanize(String(b.entity)) : '–') },
                { key: 'seq', header: 'Seq', align: 'right', sortValue: (b) => Number(b.seq ?? 0), render: (b) => String(b.seq ?? '–') },
                { key: 'rec', header: 'Records', align: 'right', sortValue: (b) => Number(b.records ?? 0), render: (b) => (b.records !== undefined ? formatInt(Number(b.records)) : '–') },
                { key: 'tx', header: 'Transaction', render: (b) => <TxLink id={b.tx_id as string | undefined} /> },
                { key: 'st', header: 'Result', render: (b) => (b.status ? <StatusChip value={String(b.status)} /> : '–') },
              ]}
            />
          )}
        </QueryBoundary>
      </Card>
    </div>
  );
}
