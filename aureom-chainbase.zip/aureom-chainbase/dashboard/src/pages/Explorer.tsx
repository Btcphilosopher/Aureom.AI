import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, NavLink, Route, Routes, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems } from '../api/client';
import type { BlockDetail as BlockDetailT, BlockSummary, ChainRecord, ExplorerTx, ProofResponse, SearchHit, VerifyFinality } from '../api/types';
import { useChainStatus } from '../api/chainStatus';
import { formatInt, formatISO, formatTime, humanize, parseTimeString, shallowDiff, shortHash, compactJSON, pct } from '../lib/format';
import { KIND_PREFIX } from '../lib/labels';
import { codeFamily, codeRecordedOnChain } from '../lib/status';
import { Callout, Card, KV, PageHeader, Section } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Hash, Json, TxLink } from '../ui/misc';
import { Tabs, TabPanel } from '../ui/Tabs';
import { EmptyState, ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { IconCheck, IconInfo, IconRefresh } from '../ui/icons';
import { useParam } from '../lib/hooks';

export const PROOF_CAVEAT = 'A proof only establishes inclusion of that key/value in a committed state root, not business correctness or completeness of a search.';

// ---------- search ----------

export function hitTarget(h: SearchHit): { to: string; label: string; kind: string } {
  const kind = String(h.kind ?? h.type ?? '').toLowerCase();
  const ref = h.ref !== undefined ? String(h.ref) : undefined;
  const key = (h.key as string | undefined) ?? (kind.includes('record') ? ((h.id as string | undefined) ?? ref) : undefined);
  if (key) return { to: `/explorer/record?key=${encodeURIComponent(key)}`, label: key, kind: 'Record' };
  const tx = (h.tx_id as string | undefined) ?? (h.hash as string | undefined) ?? (kind.includes('tx') ? ((h.id as string | undefined) ?? ref) : undefined);
  if (tx) return { to: `/explorer/tx/${encodeURIComponent(tx)}`, label: tx, kind: 'Transaction' };
  const height = h.height ?? (kind.includes('block') ? ref : undefined);
  if (height !== undefined) return { to: `/explorer/block/${height}`, label: `Block ${height}`, kind: 'Block' };
  return { to: '/explorer', label: JSON.stringify(h), kind: 'Match' };
}

function SearchBox() {
  const [text, setText] = useState('');
  const [submitted, setSubmitted] = useState('');
  const q = useApi<unknown>('/explorer/search', { q: submitted }, { enabled: submitted.length > 0 });
  const hits = (() => {
    const d = q.data as { results?: SearchHit[]; matches?: SearchHit[]; hits?: SearchHit[] } | SearchHit[] | undefined;
    if (!d) return [];
    if (Array.isArray(d)) return d;
    return d.results ?? d.matches ?? d.hits ?? asItems<SearchHit>(d);
  })();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(text.trim());
  };
  return (
    <div className="mb">
      <form onSubmit={submit} role="search" aria-label="Explorer search" className="row">
        <input className="input big-search mono" type="search" aria-label="Search by transaction id or hash, block height or record key" placeholder="Search a transaction id / hash, block height or record key (e.g. sale/S-100)…" value={text} onChange={(e) => setText(e.target.value)} />
        <button type="submit" className="btn primary" style={{ height: 36 }}>Search</button>
      </form>
      {submitted && (
        <Card className="mt" title={`Results for “${submitted}”`} flush>
          {q.isPending ? <LoadingBlock rows={2} /> : q.isError ? <ErrorState error={q.error} onRetry={() => void q.refetch()} title="Search failed" /> : hits.length === 0 ? <EmptyState title="No matches" /> : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {hits.map((h, i) => {
                const t = hitTarget(h);
                return (
                  <li key={i} style={{ padding: '8px 14px', borderBottom: i < hits.length - 1 ? '1px solid var(--border)' : 0 }} className="row">
                    <Chip tone="info" square>{t.kind}</Chip>
                    <Link to={t.to} className="mono trunc">{t.label}</Link>
                    {(h.summary || h.label) && <span className="muted trunc">{String(h.summary ?? h.label)}</span>}
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      )}
    </div>
  );
}

function ExplorerNav() {
  const { pathname } = useLocation();
  return (
    <div className="tabs" role="navigation" aria-label="Explorer sections">
      {[
        { to: '/explorer', label: 'Blocks', end: true },
        { to: '/explorer/tx', label: 'Transactions' },
        { to: '/explorer/record', label: 'Records and proofs' },
      ].map((n) => (
        <NavLink key={n.to} to={n.to} end={n.end} className="tab" style={({ isActive }) => ((n.to === '/explorer' ? isActive || pathname.startsWith('/explorer/block') : isActive) ? { color: 'var(--accent)', borderBottomColor: 'var(--accent)' } : undefined)}>{n.label}</NavLink>
      ))}
    </div>
  );
}

// ---------- blocks ----------

function BlocksHome() {
  const [before, setBefore] = useState<number | undefined>(undefined);
  const [stack, setStack] = useState<(number | undefined)[]>([]);
  const q = useApi<BlockSummary[] | { items: BlockSummary[] }>('/explorer/blocks', { limit: 20, before }, { poll: before === undefined ? 3000 : undefined, keep: true });
  const rows = asItems<BlockSummary>(q.data);
  const nav = useNavigate();
  const cols: Column<BlockSummary>[] = [
    { key: 'h', header: 'Height', align: 'right', render: (b) => <Link to={`/explorer/block/${b.height}`}>{formatInt(b.height)}</Link> },
    { key: 't', header: 'Time', render: (b) => formatTime(parseTimeString(b.time)) },
    { key: 'tx', header: 'Transactions', align: 'right', render: (b) => b.num_txs },
    { key: 'rj', header: 'Rejected', align: 'right', render: (b) => (b.num_rejected ? <Chip tone="bad">{b.num_rejected}</Chip> : <span className="muted">0</span>) },
    { key: 'p', header: 'Proposer', render: (b) => b.proposer },
    { key: 'hash', header: 'Block hash', mono: true, render: (b) => <span title={b.hash}>{shortHash(b.hash, 12)}</span> },
    { key: 'ah', header: 'App hash', mono: true, render: (b) => <span title={b.app_hash}>{shortHash(b.app_hash, 10)}</span> },
    { key: 'sz', header: 'Size', align: 'right', render: (b) => `${(b.size_bytes / 1024).toFixed(1)} KB` },
  ];
  return (
    <Card title="Blocks" sub={before === undefined ? 'Latest finalised blocks (refreshes every few seconds)' : `Blocks below height ${formatInt(before)}`} flush
      actions={<>
        <button type="button" className="btn sm" disabled={stack.length === 0} onClick={() => { const s = [...stack]; const b = s.pop(); setStack(s); setBefore(b); }}>Newer</button>
        <button type="button" className="btn sm" disabled={rows.length === 0} onClick={() => { setStack([...stack, before]); setBefore(rows[rows.length - 1].height); }}>Older</button>
      </>}>
      <QueryBoundary q={q} isEmpty={() => rows.length === 0} emptyTitle="No blocks">
        {() => <DataTable<BlockSummary> caption="Blocks" rows={rows} rowKey={(b) => String(b.height)} columns={cols} pageSize={20} onRowClick={(b) => nav(`/explorer/block/${b.height}`)} />}
      </QueryBoundary>
    </Card>
  );
}

function PowerBar({ signed, total }: { signed: number; total: number }) {
  const quorumPct = (2 / 3) * 100;
  const ok = signed * 3 > total * 2;
  return (
    <div>
      <div style={{ position: 'relative', height: 14, background: 'var(--surface-3)', borderRadius: 4, overflow: 'visible', margin: '8px 0 4px' }} role="img" aria-label={`${signed} of ${total} voting power signed; more than two thirds is required`}>
        <div style={{ width: `${total ? (signed / total) * 100 : 0}%`, height: '100%', background: ok ? 'var(--ok-solid)' : 'var(--bad-solid)', borderRadius: 4 }} />
        <div style={{ position: 'absolute', left: `${quorumPct}%`, top: -4, bottom: -4, borderLeft: '2px dashed var(--text)' }} title="Two-thirds threshold" />
      </div>
      <div className="muted" style={{ fontSize: 11.5 }}>{signed} of {total} voting power signed ({pct(signed, total)}). More than ⅔ (dashed line) is required for finality.</div>
    </div>
  );
}

function FinalityPanel({ height }: { height: number }) {
  const [run, setRun] = useState(false);
  const q = useApi<VerifyFinality>('/explorer/verify-finality', { height }, { enabled: run, staleTime: 60_000 });
  useEffect(() => setRun(false), [height]);
  return (
    <Card title="Finality verification" sub="Independent check that this block is final">
      <p className="text-2">A block is <b>final</b> when validators holding more than two thirds of the voting power have signed it. The gateway re-verifies those signatures with a light client that trusts only the genesis validator set, rather than trusting any single node.</p>
      {!run ? (
        <button type="button" className="btn primary" onClick={() => setRun(true)}><IconCheck /> Verify finality of block {formatInt(height)}</button>
      ) : q.isPending ? <div className="row"><span className="spinner" /> Verifying with the light client…</div> : q.isError ? <ErrorState error={q.error} onRetry={() => void q.refetch()} title="Verification failed to run" /> : q.data && (
        <div className="stack-sm">
          <div className="row"><Chip tone={q.data.verified ? 'ok' : 'bad'} dot lg>{q.data.verified ? 'Finality verified' : 'NOT verified'}</Chip><span className="muted">{q.data.method}</span></div>
          <PowerBar signed={q.data.signed_power} total={q.data.total_power} />
          <KV items={[
            ...(q.data.trusted_height !== undefined ? ([['Trusted height', formatInt(q.data.trusted_height)]] as [string, ReactNode][]) : []),
            ['Signed power', `${q.data.signed_power} of ${q.data.total_power}`],
            ['Quorum required', `more than ⅔ → ${q.data.quorum_required}`],
            ['Validators that signed', <div className="pill-list">{(q.data.validators_signed ?? []).map((v) => <Chip key={v} tone="ok" square>{v}</Chip>)}</div>],
            ['Block hash', <Hash value={q.data.block_hash} />],
            ['App hash carried in this header', <Hash value={q.data.header_app_hash ?? q.data.app_hash_next_header} />],
          ]} />
          {q.data.note && <p className="muted" style={{ margin: 0 }}>{q.data.note}</p>}
          {q.data.error && <Callout tone="bad">{q.data.error}</Callout>}
        </div>
      )}
    </Card>
  );
}

function BlockDetail() {
  const { height = '' } = useParams();
  const h = Number(height);
  const q = useApi<BlockDetailT>(`/explorer/block/${encodeURIComponent(height)}`, undefined, { staleTime: 30_000 });
  const b = q.data;
  const chain = useChainStatus();
  const sigs = b?.commit?.signatures ?? [];
  const known = new Set(['height', 'time', 'hash', 'app_hash', 'state_app_hash_after_block', 'proposer', 'num_txs', 'num_rejected', 'size_bytes', 'txs', 'commit']);
  const extra = b ? Object.entries(b).filter(([k, v]) => !known.has(k) && (typeof v === 'string' || typeof v === 'number')) : [];
  const txsIn = b?.txs ?? [];
  const nRejected = b?.num_rejected ?? txsIn.filter((t) => t.code !== undefined && t.code !== 0).length;
  const sizeBytes = b?.size_bytes ?? txsIn.reduce((a, t) => a + (t.size ?? 0), 0);
  const stateHash = b?.state_app_hash_after_block ?? b?.app_hash;
  return (
    <div className="stack">
      <div className="row">
        <Link to={`/explorer/block/${h - 1}`} className={`btn sm${h <= 1 ? ' disabled' : ''}`} aria-disabled={h <= 1} onClick={(e) => h <= 1 && e.preventDefault()}>← Block {h - 1}</Link>
        <Link to={`/explorer/block/${h + 1}`} className="btn sm" style={chain.head !== null && h >= chain.head ? { pointerEvents: 'none', opacity: 0.5 } : undefined}>Block {h + 1} →</Link>
      </div>
      {q.isPending && <Card><LoadingBlock rows={8} /></Card>}
      {q.isError && !q.data && <Card><ErrorState error={q.error} onRetry={() => void q.refetch()} title={(q.error as { status?: number })?.status === 404 ? `Block ${height} does not exist (yet)` : undefined} /></Card>}
      {b && (
        <>
          <Card title={`Block ${formatInt(b.height)}`} actions={b.commit && <Chip tone={b.commit.finality_verified ? 'ok' : 'warn'} dot>{b.commit.finality_verified ? 'Finality verified' : 'Finality not yet verified'}</Chip>}>
            <KV items={[
              ['Block time', <span>{formatTime(parseTimeString(b.time))} <span className="muted">({formatISO(parseTimeString(b.time))})</span></span>],
              ['Block hash', <Hash value={b.hash} />],
              ['App hash (state after this block)', <Hash value={stateHash} />],
              ['Proposer', b.proposer ?? '–'],
              ['Transactions', `${b.num_txs ?? txsIn.length} (${nRejected} rejected)`],
              ...(sizeBytes ? ([['Size', `${(sizeBytes / 1024).toFixed(2)} KB`]] as [string, ReactNode][]) : []),
              ...extra.map(([k, v]) => [humanize(k), <span className="mono">{String(v)}</span>] as [string, ReactNode]),
            ]} />
          </Card>
          <Card title={`Transactions (${txsIn.length})`} flush>
            {txsIn.length === 0 ? <EmptyState title="Empty block" >No transactions were included in this block.</EmptyState> : (
              <DataTable<NonNullable<BlockDetailT['txs']>[number]> caption="Transactions in this block" rows={txsIn} rowKey={(t) => t.hash} pageSize={25}
                rowClass={(t) => (t.code !== undefined && t.code !== 0 ? 'row-bad' : undefined)}
                columns={[
                  { key: 'i', header: '#', align: 'right', render: (t) => t.index ?? txsIn.indexOf(t) },
                  { key: 'id', header: 'Transaction', mono: true, render: (t) => (t.tx_id ? <TxLink id={t.tx_id} /> : <Link to={`/explorer/tx/${t.hash}`} className="mono">{shortHash(t.hash, 10)}</Link>) },
                  { key: 'type', header: 'Type', render: (t) => t.type ?? (t.decode_error ? <span className="muted">undecodable</span> : '–') },
                  { key: 'sg', header: 'Signer', mono: true, render: (t) => t.signer ?? '–' },
                  { key: 'res', header: 'Result', render: (t) => (t.code === undefined ? <span className="muted">–</span> : t.code === 0 ? <Chip tone="ok" dot>OK</Chip> : <Chip tone="bad" dot>{t.code_name}</Chip>) },
                  { key: 'log', header: 'Log', wrap: true, render: (t) => t.log || <span className="muted">–</span> },
                  { key: 'hash', header: 'Hash', mono: true, render: (t) => <span title={t.hash}>{shortHash(t.hash, 8)}</span> },
                ]}
              />
            )}
          </Card>
          {b.commit && (
            <Card title="Commit signatures" sub={`Round ${b.commit.round}: which validators signed this block`} flush>
              <div className="card-body" style={{ paddingBottom: 6 }}><PowerBar signed={b.commit.signed_power} total={b.commit.total_power} /></div>
              <div className="table-wrap"><table className="dt compact">
                <caption className="sr-only">Commit signatures</caption>
                <thead><tr><th>Validator</th><th>Validator address</th><th>Signed</th><th className="num">Voting power</th></tr></thead>
                <tbody>{sigs.map((s) => (
                  <tr key={s.validator}><td><b>{s.validator_name}</b></td><td className="mono" title={s.validator}>{shortHash(s.validator, 8)}</td><td><Chip tone={s.signed ? 'ok' : 'bad'} dot>{s.signed ? 'Signed' : 'Did not sign'}</Chip></td><td className="num">{s.power}</td></tr>
                ))}</tbody>
              </table></div>
            </Card>
          )}
          <FinalityPanel height={b.height} />
        </>
      )}
    </div>
  );
}

// ---------- transactions ----------

function pick<T = unknown>(o: Record<string, unknown> | undefined, ...keys: string[]): T | undefined {
  if (!o) return undefined;
  for (const k of keys) if (o[k] !== undefined && o[k] !== null) return o[k] as T;
  return undefined;
}

function TxLookup() {
  const nav = useNavigate();
  const [id, setId] = useState('');
  return (
    <Card title="Look up a transaction" sub="By transaction id or transaction hash">
      <form className="row" onSubmit={(e) => { e.preventDefault(); if (id.trim()) nav(`/explorer/tx/${encodeURIComponent(id.trim())}`); }}>
        <input className="input mono" style={{ flex: 1 }} aria-label="Transaction id or hash" placeholder="tx id or hash" value={id} onChange={(e) => setId(e.target.value)} />
        <button className="btn primary" type="submit">Look up</button>
      </form>
    </Card>
  );
}

function TxDetail() {
  const { id = '' } = useParams();
  const q = useApi<ExplorerTx>(`/explorer/tx/${encodeURIComponent(id)}`, { include_proof: 1 }, { staleTime: 30_000 });
  const t = q.data;
  const r = t as Record<string, unknown> | undefined;
  const body = pick<Record<string, unknown>>(r, 'body', 'decoded', 'tx', 'decoded_body');
  const sig = pick<Record<string, unknown>>(r, 'signature', 'signature_check', 'sig_check');
  const result = pick<Record<string, unknown>>(r, 'result', 'tx_result');
  const inclTop = pick<{ height: number; index: number }>(r, 'inclusion');
  const incl = inclTop ?? (typeof r?.height === 'number' ? { height: r.height as number, index: Number(r.index ?? 0) } : undefined);
  const txRecord = pick<Record<string, unknown>>(r, 'record');
  const proof = pick<Record<string, unknown>>(r, 'inclusion_proof', 'merkle_proof', 'proof');
  const changedRaw = pick<unknown[]>(r, 'records_changed', 'changed_records', 'changes', 'changed') ?? [];
  const changed = changedRaw.length === 0 && Array.isArray(txRecord?.keys) ? (txRecord!.keys as unknown[]) : changedRaw;
  const code = Number(result?.code ?? r?.code ?? 0);
  const codeName = String(result?.code_name ?? r?.code_name ?? (code === 0 ? 'OK' : 'REJECTED'));
  const log = String(result?.log || txRecord?.reason || r?.log || r?.reason || '');
  const sigOk = sig ? (sig.valid ?? sig.ok ?? sig.verified) : undefined;
  const bodyObj = body as Record<string, unknown> | undefined;
  return (
    <div className="stack">
      {q.isPending && <Card><LoadingBlock rows={8} /></Card>}
      {q.isError && !q.data && <Card><ErrorState error={q.error} onRetry={() => void q.refetch()} title={(q.error as { status?: number })?.status === 404 ? 'Transaction not found' : undefined} /></Card>}
      {t && (
        <>
          <Card title={<span className="row wrap">Transaction <span className="mono">{String(t.tx_id ?? bodyObj?.tx_id ?? txRecord?.id ?? id)}</span> <Chip tone={code === 0 ? 'ok' : 'bad'} dot lg>{code === 0 ? 'Accepted' : `Rejected: ${codeName}`}</Chip></span>}>
            <KV items={[
              ['Type', String(t.type ?? bodyObj?.type ?? txRecord?.type ?? '–')],
              ['Signer', <span className="mono">{String(t.signer ?? bodyObj?.signer ?? txRecord?.signer ?? '–')}</span>],
              ['Transaction hash', <Hash value={t.hash as string | undefined} />],
              ['Included in block', incl ? <span><Link to={`/explorer/block/${incl.height}`}>{formatInt(incl.height)}</Link> at position {incl.index}</span> : '–'],
              ['Result code', <span><b>{code}</b> {codeName} <span className="muted">· {codeFamily(code)}</span></span>],
              ['Log / reason', log || '–'],
              ['Client time claim', bodyObj?.client_time_ms ? <span>{formatTime(Number(bodyObj.client_time_ms))} <span className="muted">(the signer’s claim; never trusted as proof of when it happened)</span></span> : '–'],
            ]} />
            {code !== 0 && <div className="mt"><Callout tone={codeRecordedOnChain(code) ? 'warn' : 'bad'}>{codeRecordedOnChain(code) ? 'This transaction was ordered into a block but refused by the business rules (all-or-nothing): it changed no data apart from being recorded as REJECTED.' : 'Transactions that fail structural, signature or identity checks leave no trace in state.'}</Callout></div>}
          </Card>
          <div className="grid cols-2">
            <Card title="Signature check" sub="ed25519 over network id and the exact body bytes">
              {sig ? (
                <div className="stack-sm">
                  <Chip tone={sigOk === false ? 'bad' : 'ok'} dot lg>{sigOk === false ? 'Signature INVALID' : 'Signature valid'}</Chip>
                  <KV items={Object.entries(sig).filter(([k]) => !['valid', 'ok', 'verified'].includes(k)).map(([k, v]) => [humanize(k), <span className="mono" style={{ overflowWrap: 'anywhere' }}>{compactJSON(v, 120)}</span>] as [string, ReactNode])} />
                </div>
              ) : <span className="muted">Not provided by the gateway.</span>}
            </Card>
            <Card title="Inclusion proof" sub="Merkle proof that this transaction is in the block’s data hash">
              {proof ? (
                <div className="stack-sm">
                  {(proof.valid ?? proof.verified) !== undefined && <Chip tone={(proof.valid ?? proof.verified) ? 'ok' : 'bad'} dot lg>{(proof.valid ?? proof.verified) ? 'Inclusion proof valid' : 'Inclusion proof INVALID'}</Chip>}
                  <Json value={proof} max={180} />
                </div>
              ) : <span className="muted">No inclusion proof returned.</span>}
            </Card>
          </div>
          <Card title="Decoded transaction body" sub="Exactly what the signer signed">
            {body ? <Json value={body} /> : <span className="muted">Body not available.</span>}
          </Card>
          <Card title={`Records changed (${changed.length})`} flush>
            {changed.length === 0 ? <div className="state">No records were changed{code !== 0 ? ' (rejected transaction)' : ''}.</div> : (
              <ul style={{ margin: 0, padding: '8px 14px', listStyle: 'none' }}>
                {changed.map((c, i) => { const key = typeof c === 'string' ? c : String((c as { key?: string }).key ?? JSON.stringify(c)); const op = typeof c === 'object' && c ? (c as { op?: string }).op : undefined; return (<li key={i} style={{ padding: '3px 0' }} className="row">{op && <Chip tone={op === 'delete' ? 'bad' : 'info'} square>{op}</Chip>}<Link className="mono" to={`/explorer/record?key=${encodeURIComponent(key)}`}>{key}</Link></li>); })}
              </ul>
            )}
          </Card>
        </>
      )}
    </div>
  );
}

// ---------- records & proofs ----------

interface HistRow { height: number; tx_id: string; tx_type: string; signer: string; block_time_ms: number; version: number; value: unknown; deleted?: boolean }

function History({ stateKey, onPickHeight }: { stateKey: string; onPickHeight: (h: number) => void }) {
  const q = useApi<unknown>('/q/history', { key: stateKey });
  const rows = asItems<HistRow>(q.data).sort((a, b) => a.height - b.height || a.version - b.version);
  return (
    <Card title="Audit history" sub={`Every version of ${stateKey}, oldest first. Derived from finalised blocks (query projection).`}>
      {q.isPending ? <LoadingBlock rows={4} /> : q.isError ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : rows.length === 0 ? <EmptyState title="No history" >No versions are recorded for this key.</EmptyState> : (
        <ul className="timeline">
          {rows.map((v, i) => {
            const diffs = i > 0 ? shallowDiff(rows[i - 1].value, v.value) : [];
            return (
              <li key={`${v.height}-${v.version}`} className={v.deleted ? 'bad' : undefined}>
                <div className="tl-head">
                  <b>Version {v.version}</b>
                  <Chip tone="info" square>{humanize(String(v.tx_type).replace(/([a-z])([A-Z])/g, '$1_$2'))}</Chip>
                  <span className="tl-time">{formatTime(v.block_time_ms)} · by <span className="mono">{v.signer}</span> · block <Link to={`/explorer/block/${v.height}`}>{v.height}</Link></span>
                  <TxLink id={v.tx_id} />
                  <button type="button" className="btn sm ghost" onClick={() => onPickHeight(v.height)}>View state at block {v.height}</button>
                </div>
                {v.deleted && <Chip tone="bad">Deleted</Chip>}
                {i === 0 ? <div className="muted">Created</div> : diffs.length === 0 ? <div className="muted">No field changes</div> : (
                  <div className="diff">{diffs.slice(0, 12).map((d) => <div className="diff-row" key={d.key}><div className="k">{d.key}</div><div className="b">{compactJSON(d.before, 70)}</div><div className="a">{compactJSON(d.after, 70)}</div></div>)}</div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

const DEFAULT_STEPS = [
  'The gateway asked a validator for this key at the chosen height and requested a Merkle (ICS23) proof from its state tree.',
  'The proof was checked locally: starting from the key and value, the hashes along the proof path must reproduce the state root (the application hash).',
  'The application hash was compared with the one in the next block header. That header was verified by the light client: it is signed by more than two thirds of the voting power, starting from the trusted genesis validator set.',
  'Conclusion: this key held exactly this value in the committed state at that height.',
];

function RecordView() {
  const [sp, setSp] = useSearchParams();
  const key = sp.get('key') ?? '';
  const height = sp.get('height') ?? '';
  const [tab, setTab] = useParam('rtab', sp.get('history') ? 'history' : 'proof');
  const chain = useChainStatus();
  const [keyIn, setKeyIn] = useState(key);
  const [heightIn, setHeightIn] = useState(height);
  const [kind, setKind] = useState('sale');
  const [idIn, setIdIn] = useState('');
  useEffect(() => { setKeyIn(key); setHeightIn(height); }, [key, height]);

  const pq = useApi<ChainRecord | ProofResponse>('/explorer/proof', { key, height: height || undefined }, { enabled: key.length > 0, staleTime: 30_000 });
  // the gateway wraps the record: {record, explanation}; the documented shape is the record itself
  const wrapped = pq.data as ProofResponse | undefined;
  const q = { ...pq, data: (wrapped?.record ?? (pq.data as ChainRecord | undefined)) as ChainRecord | undefined };
  const apiSteps = wrapped?.explanation ?? (pq.data as ChainRecord | undefined)?.explanation;
  const apply = (e?: FormEvent) => {
    e?.preventDefault();
    const n = new URLSearchParams(sp);
    if (keyIn.trim()) n.set('key', keyIn.trim()); else n.delete('key');
    if (heightIn.trim()) n.set('height', heightIn.trim()); else n.delete('height');
    n.delete('history');
    setSp(n);
  };
  const setHeight = (h: string) => { const n = new URLSearchParams(sp); if (h) n.set('height', h); else n.delete('height'); setSp(n); };
  const d = q.data;
  const steps = (apiSteps && apiSteps.length ? apiSteps : DEFAULT_STEPS).map((s) => s.replace(/^\s*\d+\.\s*/, ''));
  const v = d?.verification;
  const headerPending = !!d && !v?.header_verified && !!d.proof && chain.head !== null && d.proof.app_hash_height >= chain.head - 1 && v?.proof_valid !== false;

  return (
    <div className="stack">
      <Card title="Look up a record" sub="Read a business record straight from committed chain state, optionally as it was at an earlier block, with a verifiable proof">
        <form onSubmit={apply} className="stack-sm">
          <div className="row wrap" style={{ alignItems: 'flex-end' }}>
            <div className="field" style={{ flex: '1 1 320px' }}>
              <label htmlFor="rec-key">State key</label>
              <input id="rec-key" className="input mono" placeholder="e.g. sale/S-100, product/P-1001, bal/SKU-MILK/STORE-N-01" value={keyIn} onChange={(e) => setKeyIn(e.target.value)} />
            </div>
            <div className="field" style={{ width: 190 }}>
              <label htmlFor="rec-height">State at height</label>
              <div className="row" style={{ gap: 4 }}>
                <input id="rec-height" className="input mono" style={{ width: 100 }} inputMode="numeric" value={heightIn} onChange={(e) => setHeightIn(e.target.value.replace(/[^0-9]/g, ''))} placeholder="latest" title="Leave blank for the latest committed state" />
                <button type="button" className="btn sm" onClick={() => { setHeightIn(''); setHeight(''); }}>Latest</button>
              </div>
            </div>
            <button type="submit" className="btn primary">Look up</button>
          </div>
          <div className="row wrap">
            <span className="muted">Or build a key:</span>
            <select className="select" aria-label="Record type" value={kind} onChange={(e) => setKind(e.target.value)}>{Object.keys(KIND_PREFIX).map((k) => <option key={k} value={k}>{humanize(k)}</option>)}</select>
            <input className="input mono" aria-label="Record id" placeholder="id" style={{ width: 180 }} value={idIn} onChange={(e) => setIdIn(e.target.value)} />
            <button type="button" className="btn sm" disabled={!idIn} onClick={() => { setKeyIn(KIND_PREFIX[kind] + idIn); }}>Use</button>
          </div>
        </form>
      </Card>

      {!key ? <Card><EmptyState title="Enter a state key">Business records live under keys such as <span className="mono">sale/S-100</span>. Use the search box above or the builder to find one.</EmptyState></Card> : (
        <>
          <Tabs label="Record views" value={tab} onChange={setTab} items={[{ id: 'proof', label: 'Value and proof' }, { id: 'history', label: 'Audit history' }]} />
          <TabPanel id="proof" active={tab === 'proof'}>
            {q.isPending && <Card><LoadingBlock rows={6} /></Card>}
            {q.isError && !q.data && <Card><ErrorState error={q.error} onRetry={() => void q.refetch()} /></Card>}
            {d && (
              <div className="stack">
                <Card title={<span className="row wrap"><span className="mono">{d.key}</span> <Chip tone={d.found ? 'ok' : 'warn'} dot>{d.found ? 'Found' : 'Not found'}</Chip></span>} sub={height ? `State as it was committed at height ${formatInt(Number(height))}` : `Latest committed state (height ${formatInt(d.height)})`}
                  actions={<>
                    <button type="button" className="btn sm" disabled={!d.height || d.height <= 1} onClick={() => setHeight(String((height ? Number(height) : d.height) - 1))}>← Earlier block</button>
                    <button type="button" className="btn sm" disabled={!height || (chain.head !== null && Number(height) >= chain.head)} onClick={() => setHeight(String(Number(height) + 1))}>Later block →</button>
                  </>}>
                  {d.found ? <Json value={d.value} max={420} /> : <Callout tone="warn" icon={<IconInfo />}><span>No record exists under this key{height ? ` at height ${height}` : ''}. With a proof, absence is itself provable: a <b>non-membership proof</b> shows the key is not in the committed state.</span></Callout>}
                </Card>
                <Card title="Proof verification" sub="Can this value be trusted to be what the validators committed?">
                  {!d.proof ? <span className="muted">No proof was returned for this lookup.</span> : (
                    <div className="stack">
                      <div className="row wrap">
                        <Chip tone={v?.proof_valid ? 'ok' : 'bad'} dot lg>{v?.proof_valid ? 'Merkle proof valid' : 'Proof NOT valid'}</Chip>
                        {v?.header_verified ? <Chip tone="ok" dot lg>Header verified by light client</Chip> : headerPending ? <Chip tone="warn" dot lg title="The root is carried in the header of the next block, which has not been produced yet. Re-check in a moment.">Header pending: next block not yet committed</Chip> : <Chip tone="bad" dot lg>Header NOT verified</Chip>}
                        {headerPending && <button type="button" className="btn sm" onClick={() => void q.refetch()}>Re-check</button>}
                        <Chip tone="neutral" lg>{d.found ? 'Membership proof' : 'Non-membership proof'}</Chip>
                      </div>
                      <KV items={[
                        ['Proof type', <span className="mono">{d.proof.type}</span>],
                        ['State root (app hash)', <Hash value={d.proof.app_hash} />],
                        ['Root taken from header at height', <Link to={`/explorer/block/${d.proof.app_hash_height}`}>{formatInt(d.proof.app_hash_height)}</Link>],
                        ['Proof size', `${Math.round((d.proof.proof_b64?.length ?? 0) * 0.75)} bytes`],
                      ]} />
                      <Section title="Step by step">
                        <ol className="stack-sm" style={{ margin: 0, paddingLeft: 20 }}>{steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
                      </Section>
                      <Callout tone="warn" icon={<IconInfo />}><span><b>What a proof does not tell you.</b> {PROOF_CAVEAT}</span></Callout>
                      {v?.statement && <p className="muted" style={{ margin: 0 }}>Gateway statement: {v.statement}</p>}
                    </div>
                  )}
                </Card>
              </div>
            )}
          </TabPanel>
          <TabPanel id="history" active={tab === 'history'}><History stateKey={key} onPickHeight={(h) => { setHeight(String(h)); setTab('proof'); }} /></TabPanel>
        </>
      )}
    </div>
  );
}

function TxHome() {
  return (
    <div className="stack">
      <TxLookup />
      <RecentTxList />
    </div>
  );
}

function RecentTxList() {
  const q = useApi<unknown>('/q/transactions', { limit: 30 });
  const rows = asItems<{ id?: string; tx_id?: string; type: string; signer: string; status: string; code_name: string; height: number; block_time_ms: number }>(q.data);
  return (
    <Card title="Recent transactions" flush>
      <QueryBoundary q={q} isEmpty={() => rows.length === 0} emptyTitle="No transactions yet">
        {() => (
          <DataTable caption="Recent transactions" rows={rows} rowKey={(t) => String(t.id ?? t.tx_id)} pageSize={15}
            columns={[
              { key: 'id', header: 'Transaction', mono: true, render: (t) => <TxLink id={String(t.id ?? t.tx_id)} /> },
              { key: 'type', header: 'Type', render: (t) => t.type },
              { key: 'sg', header: 'Signer', mono: true, render: (t) => t.signer },
              { key: 'st', header: 'Result', render: (t) => (t.status === 'OK' ? <StatusChip value="OK" /> : <Chip tone="bad" dot>{t.code_name}</Chip>) },
              { key: 'h', header: 'Block', align: 'right', render: (t) => <Link to={`/explorer/block/${t.height}`}>{formatInt(t.height)}</Link> },
              { key: 'time', header: 'Recorded', render: (t) => formatTime(t.block_time_ms) },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

export default function Explorer() {
  const chain = useChainStatus();
  return (
    <div className="page">
      <PageHeader
        title="Explorer"
        subtitle="Blockchain diagnostics: blocks, transactions, commit signatures, finality, and verifiable records. Search by transaction, block height or record key."
        actions={<button type="button" className="btn" onClick={chain.refresh}><IconRefresh /> Refresh</button>}
      />
      <SearchBox />
      <ExplorerNav />
      <Routes>
        <Route index element={<BlocksHome />} />
        <Route path="block/:height" element={<BlockDetail />} />
        <Route path="tx" element={<TxHome />} />
        <Route path="tx/:id" element={<TxDetail />} />
        <Route path="record" element={<RecordView />} />
      </Routes>
    </div>
  );
}
