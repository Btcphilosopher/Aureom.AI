import { Link, useParams } from 'react-router-dom';
import { useApi } from '../api/hooks';
import type { MigrationReport as Report, ReportCheck, ReportException, ReportBatch, UnsupportedField } from '../api/types';
import { formatInt, formatTime, humanize, parseTimeString } from '../lib/format';
import { Callout, Card, Kpi, KV, PageHeader } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable } from '../ui/DataTable';
import { Hash, TxLink } from '../ui/misc';
import { StageIndicator } from '../ui/Stages';
import { ErrorState, LoadingBlock } from '../ui/States';
import { IconInfo } from '../ui/icons';
import { IMPORT_STATEMENT, RunKindChip } from './Migration';

const num = (v: unknown) => (typeof v === 'number' ? formatInt(v) : v === null || v === undefined ? '–' : String(v));

const DISPOSITION_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'info'> = { FIXED: 'ok', PRESERVED_AS_EXTRAS: 'info', EXCLUDED: 'warn', MANUAL: 'bad' };
const DISPOSITION_TEXT: Record<string, string> = {
  FIXED: 'Corrected during import',
  PRESERVED_AS_EXTRAS: 'Kept verbatim in source_extras',
  EXCLUDED: 'Left out of the import',
  MANUAL: 'Needs manual follow-up',
};

export default function MigrationReport() {
  const { id = '' } = useParams();
  const q = useApi<Report>(id === 'latest' ? '/migration/reports/latest' : `/migration/reports/${encodeURIComponent(id)}`);
  const r = q.data;
  const checks = r?.checks ?? [];
  const pass = checks.filter((c) => c.status === 'PASS').length;
  const warn = checks.filter((c) => c.status === 'WARN').length;
  const fail = checks.filter((c) => c.status === 'FAIL').length;

  return (
    <div className="page">
      <PageHeader
        crumbs={<><Link to="/migration">Migration</Link> / reports / <span className="mono">{id}</span></>}
        title={<span className="row wrap" style={{ gap: 10 }}>Reconciliation report {r && <RunKindChip trial={r.trial} lg />} {r && <StatusChip value={r.decision} lg />}</span>}
        subtitle={r ? <span><span className="mono">{r.id}</span> · phase <b>{humanize(r.phase)}</b> · generated {formatTime(parseTimeString(r.generated_at))}</span> : undefined}
      />
      {q.isPending && <Card><LoadingBlock rows={8} /></Card>}
      {q.isError && !q.data && <Card><ErrorState error={q.error} onRetry={() => void q.refetch()} title={(q.error as { status?: number })?.status === 404 ? 'Report not found' : undefined} /></Card>}
      {r && (
        <div className="stack">
          {r.trial ? (
            <Callout tone="warn" icon={<IconInfo />}><span><b>TRIAL RUN.</b> This is a rehearsal against a copy of the data. It tests the mapping and reconciliation and <b>does not change which system is authoritative</b>. A trial decision is not a cut-over approval.</span></Callout>
          ) : (
            <Callout tone="info" icon={<IconInfo />}><span><b>PRODUCTION RUN.</b> This report belongs to the real cut-over. Its SHA-256 is recorded on the ledger when the import window is closed.</span></Callout>
          )}
          <Callout tone="neutral" icon={<IconInfo />}><span>{IMPORT_STATEMENT}</span></Callout>

          <Card title="Authoritative system at the time of this report">
            <StageIndicator current={r.authoritative_system} />
          </Card>

          <div className="grid kpis">
            <Kpi label="Decision" value={<StatusChip value={r.decision} lg />} note={r.decision === 'REJECT' ? 'Do not proceed' : 'Reconciled'} tone={r.decision === 'ACCEPT' ? 'ok' : 'bad'} />
            <Kpi label="Checks passed" value={`${pass} / ${checks.length}`} tone={pass === checks.length ? 'ok' : undefined} />
            <Kpi label="Warnings" value={warn} tone={warn ? 'warn' : undefined} />
            <Kpi label="Failures" value={fail} tone={fail ? 'bad' : 'ok'} />
            <Kpi label="Exceptions" value={(r.exceptions ?? []).length} note="With dispositions" />
            <Kpi label="Unsupported fields" value={(r.unsupported_fields ?? []).length} note="Preserved or dropped" />
          </div>

          <div className="grid cols-2">
            <Card title="Source and mapping">
              <KV items={[
                ['Source system', r.source_system], ['Mapping version', <span className="mono">{r.mapping_version}</span>],
                ['Snapshot', <span className="mono">{r.snapshot_id}</span>], ['Snapshot SHA-256', <Hash value={r.snapshot_sha256} />],
                ['Network', r.network_id],
              ]} />
            </Card>
            <Card title="Notes from the operator">{r.notes ? <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{r.notes}</p> : <span className="muted">No notes.</span>}</Card>
          </div>

          <Card title="Checks" sub="Source system figures compared with what is on the ledger" flush>
            <DataTable<ReportCheck> caption="Reconciliation checks" rows={checks} rowKey={(c) => c.name} pageSize={50} initialSort={undefined}
              rowClass={(c) => (c.status === 'FAIL' ? 'row-bad' : undefined)}
              columns={[
                { key: 'name', header: 'Check', sortValue: (c) => c.name, render: (c) => <b>{c.name}</b> },
                { key: 'st', header: 'Result', sortValue: (c) => ({ FAIL: 0, WARN: 1, PASS: 2 } as Record<string, number>)[c.status] ?? 3, render: (c) => <StatusChip value={c.status} /> },
                { key: 'src', header: 'Source', align: 'right', render: (c) => num(c.source) },
                { key: 'chain', header: 'Ledger', align: 'right', render: (c) => num(c.chain) },
                { key: 'delta', header: 'Difference', align: 'right', tip: 'Ledger minus source. Zero means they agree.', sortValue: (c) => (typeof c.delta === 'number' ? Math.abs(c.delta) : 0), render: (c) => <b style={{ color: c.delta ? (c.status === 'FAIL' ? 'var(--bad-fg)' : 'var(--warn-fg)') : undefined }}>{typeof c.delta === 'number' && c.delta > 0 ? '+' : ''}{num(c.delta)}</b> },
                { key: 'det', header: 'Detail', wrap: true, render: (c) => c.detail || <span className="muted">–</span> },
              ]}
            />
          </Card>

          <Card title="Exceptions and dispositions" sub="Source records that could not be imported cleanly, and what was done with each" flush>
            {(r.exceptions ?? []).length === 0 ? <div className="state">No exceptions.</div> : (
              <DataTable<ReportException> caption="Migration exceptions" rows={r.exceptions} rowKey={(e) => `${e.kind}|${e.source_ref}`} pageSize={25} quickFilter={(e, t) => `${e.kind} ${e.source_ref} ${e.detail}`.toLowerCase().includes(t)}
                columns={[
                  { key: 'kind', header: 'Kind', sortValue: (e) => e.kind, render: (e) => humanize(e.kind) },
                  { key: 'ref', header: 'Source record', mono: true, render: (e) => e.source_ref },
                  { key: 'detail', header: 'Detail', wrap: true, render: (e) => e.detail },
                  { key: 'disp', header: 'Disposition', sortValue: (e) => e.disposition, render: (e) => <span className="row" style={{ gap: 6 }}><Chip tone={DISPOSITION_TONE[e.disposition] ?? 'neutral'} dot>{humanize(e.disposition)}</Chip><span className="muted">{DISPOSITION_TEXT[e.disposition] ?? ''}</span></span> },
                ]}
              />
            )}
          </Card>

          <Card title="Unsupported source fields" sub="Columns in the legacy system that the ledger schema has no field for" flush>
            {(r.unsupported_fields ?? []).length === 0 ? <div className="state">None.</div> : (
              <DataTable<UnsupportedField> caption="Unsupported fields" rows={r.unsupported_fields} rowKey={(u) => `${u.table}.${u.column}`} pageSize={25}
                columns={[
                  { key: 't', header: 'Source table', mono: true, render: (u) => u.table },
                  { key: 'c', header: 'Column', mono: true, render: (u) => u.column },
                  { key: 'rows', header: 'Rows affected', align: 'right', sortValue: (u) => u.rows, render: (u) => formatInt(u.rows) },
                  { key: 'tr', header: 'Treatment', render: (u) => <Chip tone={u.treatment.startsWith('preserved') ? 'info' : 'warn'} dot>{u.treatment}</Chip> },
                ]}
              />
            )}
          </Card>

          <Card title="Import batches" sub="Bulk-import transactions and where they were finalised" flush>
            {(r.batches ?? []).length === 0 ? <div className="state">No batches.</div> : (
              <DataTable<ReportBatch> caption="Import batches in this report" rows={r.batches} rowKey={(b) => b.batch_id} pageSize={25}
                columns={[
                  { key: 'b', header: 'Batch', mono: true, sortValue: (b) => b.batch_id, render: (b) => b.batch_id },
                  { key: 'e', header: 'Entity', render: (b) => humanize(b.entity) },
                  { key: 's', header: 'Seq', align: 'right', render: (b) => b.seq },
                  { key: 'r', header: 'Records', align: 'right', sortValue: (b) => b.records, render: (b) => formatInt(b.records) },
                  { key: 'tx', header: 'Transaction', render: (b) => <TxLink id={b.tx_id} /> },
                  { key: 'st', header: 'Result', render: (b) => <StatusChip value={b.status} /> },
                ]}
              />
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
