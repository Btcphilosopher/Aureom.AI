import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useApi } from '../api/hooks';
import { asItems, asTotal, metaOf } from '../api/client';
import type { ListResponse, Refund, Return, Sale, SalesSummaryRow } from '../api/types';
import { useLocations } from '../api/refdata';
import { dateInputToMs, formatDate, formatInt, formatMoney, formatTime, formatTimeShort, humanize, msToDateInput } from '../lib/format';
import { useDebounced, useParam } from '../lib/hooks';
import { sumBy } from '../lib/normalize';
import { Callout, Card, Kpi, PageHeader } from '../ui/Card';
import { Chip, ProvenanceChip, StatusChip } from '../ui/Chip';
import { BarChart } from '../ui/Charts';
import { DataTable, type Column } from '../ui/DataTable';
import { TabPanel, Tabs } from '../ui/Tabs';
import { Tip } from '../ui/Tip';
import { ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconInfo, IconRefresh } from '../ui/icons';

export const EFFECTIVE_TIP = (
  <>
    <b>Effective time</b> is when the sale happened according to the till (business time, supplied by the terminal within the network’s back-dating limit).
    <br /><br />
    <b>Recorded in block at</b> is when the validators agreed the transaction was included in a block. It cannot be back-dated.
    <br /><br />
    They differ for offline tills that upload later, queued transactions and imported history.
  </>
);

type Group = 'day' | 'location' | 'channel';

function SalesSummary({ from, to, location, loc }: { from?: number; to?: number; location: string; loc: ReturnType<typeof useLocations> }) {
  const [group, setGroup] = useState<Group>('day');
  const q = useApi<ListResponse<SalesSummaryRow>>('/q/sales/summary', { from, to, group, location }, { keep: true });
  const rows = asItems<SalesSummaryRow>(q.data);
  const sorted = useMemo(() => [...rows].sort((a, b) => a.bucket.localeCompare(b.bucket)), [rows]);
  const ccy = 'GBP';
  const label = (b: string) => {
    if (group === 'day') {
      const [y, m, d] = b.split('-').map(Number);
      return y ? formatDate(Date.UTC(y, m - 1, d), true).replace(/ \d{4}$/, '') : b;
    }
    return b;
  };
  return (
    <Card
      title="Sales summary"
      sub="Net sales by effective time"
      actions={
        <div className="seg" role="group" aria-label="Group summary by">
          {(['day', 'location', 'channel'] as Group[]).map((g) => (
            <button key={g} type="button" aria-pressed={group === g} onClick={() => setGroup(g)}>{humanize(g)}</button>
          ))}
        </div>
      }
      foot={<Staleness meta={metaOf(q.data)} />}
    >
      {q.isPending ? <LoadingBlock rows={5} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : sorted.length === 0 ? (
        <div className="state">No sales in this period.</div>
      ) : (
        <div className="grid cols-21">
          <BarChart
            ariaLabel={`Net sales by ${group}`}
            seriesName="Net sales"
            format={(v) => formatMoney(v, ccy).replace(/\.00$/, '')}
            data={sorted.map((r) => ({
              label: group === 'location' ? (loc.nameOf(r.bucket)?.split(' ')[0] ?? r.bucket) : label(r.bucket),
              value: r.net_minor,
              tip: (<span>{r.sales} sale{r.sales === 1 ? '' : 's'} · gross {formatMoney(r.gross_minor, ccy)} · discounts {formatMoney(r.discount_minor, ccy)}{r.refunded_minor ? ` · refunded ${formatMoney(r.refunded_minor, ccy)}` : ''}</span>),
            }))}
          />
          <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', alignContent: 'start' }}>
            <Kpi label="Sales" value={formatInt(sumBy(sorted, (r) => r.sales))} />
            <Kpi label="Net sales" value={formatMoney(sumBy(sorted, (r) => r.net_minor), ccy)} />
            <Kpi label="Discounts" value={formatMoney(sumBy(sorted, (r) => r.discount_minor), ccy)} />
            <Kpi label="Refunded" value={formatMoney(sumBy(sorted, (r) => r.refunded_minor), ccy)} note="confirmed" />
          </div>
        </div>
      )}
    </Card>
  );
}

function SalesTable({ params, nav }: { params: Record<string, string | number | undefined>; nav: (id: string) => void }) {
  const q = useApi<ListResponse<Sale>>('/q/sales', { ...params, limit: 500 }, { keep: true });
  const rows = asItems<Sale>(q.data);
  const cols: Column<Sale>[] = [
    { key: 'id', header: 'Sale', mono: true, sortValue: (s) => s.id, render: (s) => <Link to={`/sales/${encodeURIComponent(s.id)}`}>{s.id}</Link> },
    { key: 'eff', header: 'Effective time', tip: EFFECTIVE_TIP, sortValue: (s) => s.effective_at_ms, render: (s) => <span title={formatTime(s.effective_at_ms)}>{formatTimeShort(s.effective_at_ms)}</span> },
    { key: 'rec', header: 'Recorded in block at', tip: EFFECTIVE_TIP, sortValue: (s) => s.block_time_ms, render: (s) => <span className="muted" title={formatTime(s.block_time_ms)}>{formatTimeShort(s.block_time_ms)}</span> },
    { key: 'loc', header: 'Location', sortValue: (s) => s.loc, render: (s) => <span title={`Channel: ${humanize(s.channel)}`}>{s.loc}</span> },
    { key: 'cust', header: 'Customer', mono: true, render: (s) => s.customer_id || <span className="muted">walk-in</span> },
    { key: 'net', header: 'Net total', align: 'right', sortValue: (s) => s.net_minor, render: (s) => <b>{formatMoney(s.net_minor, s.currency)}</b> },
    { key: 'sale', header: 'Sale', render: (s) => <StatusChip kind="sale" value={s.sale_status} dot={false} /> },
    { key: 'pay', header: 'Payment', sortValue: (s) => s.payment_status, render: (s) => <StatusChip kind="payment" value={s.payment_status} /> },
    { key: 'ful', header: 'Fulfilment', sortValue: (s) => s.fulfilment_status, render: (s) => <StatusChip kind="fulfilment" value={s.fulfilment_status} /> },
    { key: 'ref', header: 'Refunded', align: 'right', tip: 'Confirmed = the payment provider has confirmed the money moved. Instructed = we asked the provider to refund but have no confirmation yet.', render: (s) => (s.refund_instructed_minor || s.refund_confirmed_minor ? <span>{formatMoney(s.refund_confirmed_minor, s.currency)}{s.refund_instructed_minor > s.refund_confirmed_minor && <span className="muted"> (+{formatMoney(s.refund_instructed_minor - s.refund_confirmed_minor, s.currency)} pending)</span>}</span> : <span className="muted">–</span>) },
    { key: 'prov', header: 'Origin', render: (s) => <ProvenanceChip origin={s.provenance?.origin} /> },
  ];
  return (
    <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No sales found" emptyText="No sales match this period and filters.">
      {() => <DataTable<Sale> compact caption="Sales" rows={rows} rowKey={(s) => s.id} columns={cols} pageSize={25} total={asTotal(q.data)} initialSort={{ key: 'eff', dir: 'desc' }} onRowClick={(s) => nav(s.id)} footerLeft={<Staleness meta={metaOf(q.data)} />} />}
    </QueryBoundary>
  );
}

function ReturnsTable() {
  const [status, setStatus] = useParam('rtstatus');
  const q = useApi<ListResponse<Return>>('/q/returns', { status, limit: 500 }, { keep: true });
  const rows = asItems<Return>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="rt-st">Status</label>
          <select id="rt-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Any status</option>
            {['REQUESTED', 'APPROVED', 'REJECTED', 'PARTIALLY_RECEIVED', 'RECEIVED'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}
          </select></div>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No returns" emptyText="No customer returns match.">
        {() => (
          <DataTable<Return> caption="Returns" rows={rows} rowKey={(r) => r.id} pageSize={25}
            columns={[
              { key: 'id', header: 'Return', mono: true, sortValue: (r) => r.id, render: (r) => r.id },
              { key: 'sale', header: 'Sale', mono: true, render: (r) => <Link to={`/sales/${encodeURIComponent(r.sale_id)}`}>{r.sale_id}</Link> },
              { key: 'loc', header: 'Location', render: (r) => r.loc },
              { key: 'lines', header: 'Items', wrap: true, render: (r) => r.lines.map((l) => `line ${l.line_no}: ${l.qty_v} (${humanize(l.reason).toLowerCase()})`).join('; ') },
              { key: 'refund', header: 'Refund value', align: 'right', sortValue: (r) => sumBy(r.lines, (l) => l.refund_minor), render: (r) => formatMoney(sumBy(r.lines, (l) => l.refund_minor)) },
              { key: 'st', header: 'Status', sortValue: (r) => r.status, render: (r) => <StatusChip kind="return" value={r.status} /> },
              { key: 'by', header: 'Requested by', render: (r) => <span className="mono">{r.requested_by}</span> },
              { key: 'dec', header: 'Decided by', render: (r) => (r.decided_by ? <span className="mono">{r.decided_by}</span> : <span className="muted">–</span>) },
              { key: 'ov', header: 'Override', wrap: true, render: (r) => r.override_reason ?? '–' },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function RefundsTable() {
  const [status, setStatus] = useParam('rfstatus');
  const q = useApi<ListResponse<Refund>>('/q/refunds', { status, limit: 500 }, { keep: true });
  const rows = asItems<Refund>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="rf-st">Status</label>
          <select id="rf-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Any status</option><option value="INSTRUCTED">Refund instructed</option><option value="CONFIRMED">Refund confirmed</option><option value="FAILED">Refund failed</option>
          </select></div>
        <span className="muted" style={{ alignSelf: 'center' }}><b>Instructed</b>: we asked the payment provider to refund. <b>Confirmed</b>: the provider confirmed the money moved.</span>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No refunds" emptyText="No refunds match.">
        {() => (
          <DataTable<Refund> caption="Refunds" rows={rows} rowKey={(r) => r.id} pageSize={25}
            columns={[
              { key: 'id', header: 'Refund', mono: true, sortValue: (r) => r.id, render: (r) => r.id },
              { key: 'sale', header: 'Sale', mono: true, render: (r) => <Link to={`/sales/${encodeURIComponent(r.sale_id)}`}>{r.sale_id}</Link> },
              { key: 'ret', header: 'Return', mono: true, render: (r) => r.return_id },
              { key: 'amt', header: 'Amount', align: 'right', sortValue: (r) => r.amount_minor, render: (r) => <b>{formatMoney(r.amount_minor, r.currency)}</b> },
              { key: 'st', header: 'Status', sortValue: (r) => r.status, render: (r) => <StatusChip kind="refund" value={r.status} /> },
              { key: 'prov', header: 'Provider', render: (r) => r.provider ?? <span className="muted">not yet</span> },
              { key: 'ref', header: 'Provider reference', mono: true, render: (r) => r.provider_ref ?? '–' },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

export default function Sales() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const loc = useLocations();
  const [tab, setTab] = useParam('tab', 'sales');
  const [from, setFrom] = useParam('from');
  const [to, setTo] = useParam('to');
  const [location, setLocation] = useParam('location');
  const [pay, setPay] = useParam('payment');
  const [cust, setCust] = useState('');
  const dCust = useDebounced(cust);
  const fromMs = dateInputToMs(from);
  const toMs = dateInputToMs(to, true);

  const preset = (days: number | null) => {
    if (days === null) { setFrom(null); setTo(null); return; }
    const end = Date.now();
    const start = days === 0 ? end : end - days * 86_400_000;
    setFrom(msToDateInput(start));
    setTo(msToDateInput(end));
  };
  const active = !from && !to ? 'all' : to === msToDateInput(Date.now()) ? (from === msToDateInput(Date.now()) ? '0' : from === msToDateInput(Date.now() - 7 * 86_400_000) ? '7' : from === msToDateInput(Date.now() - 30 * 86_400_000) ? '30' : '') : '';
  const params = { from: fromMs, to: toMs, location, payment_status: pay, customer: dCust || undefined };

  return (
    <div className="page">
      <PageHeader title="Sales" subtitle="Sales by effective time with payment and fulfilment tracked as separate statuses." actions={<button type="button" className="btn" onClick={() => void qc.invalidateQueries({ queryKey: ['api'] })}><IconRefresh /> Refresh</button>} />
      <Card flush className="mb">
        <div className="toolbar">
          <div className="field">
            <label htmlFor="s-from">Effective from <Tip label="About effective time">{EFFECTIVE_TIP}</Tip></label>
            <input id="s-from" className="input" type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="s-to">Effective to</label>
            <input id="s-to" className="input" type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="field">
            <span className="field-label">Period</span>
            <div className="seg" role="group" aria-label="Period presets">
              <button type="button" aria-pressed={active === '0'} onClick={() => preset(0)}>Today</button>
              <button type="button" aria-pressed={active === '7'} onClick={() => preset(7)}>7 days</button>
              <button type="button" aria-pressed={active === '30'} onClick={() => preset(30)}>30 days</button>
              <button type="button" aria-pressed={active === 'all'} onClick={() => preset(null)}>All time</button>
            </div>
          </div>
          <div className="field">
            <label htmlFor="s-loc">Location</label>
            <select id="s-loc" className="select" value={location} onChange={(e) => setLocation(e.target.value)}>
              <option value="">All locations</option>
              {loc.locations.map((l) => <option key={l.id} value={l.id}>{l.id} · {l.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="s-pay">Payment</label>
            <select id="s-pay" className="select" value={pay} onChange={(e) => setPay(e.target.value)}>
              <option value="">Any payment status</option>
              <option value="INSTRUCTED">Payment instructed</option><option value="PARTIALLY_PAID">Partially paid</option><option value="CONFIRMED">Paid</option><option value="FAILED">Payment failed</option><option value="OVERPAID">Overpaid</option>
            </select>
          </div>
          <div className="field" style={{ width: 170 }}>
            <label htmlFor="s-cust">Customer</label>
            <input id="s-cust" className="input mono" type="search" placeholder="CUST-000123" value={cust} onChange={(e) => setCust(e.target.value)} />
          </div>
        </div>
        <div className="card-body" style={{ paddingTop: 10, paddingBottom: 10 }}>
          <div className="row" style={{ alignItems: 'flex-start' }}>
            <IconInfo width={15} height={15} style={{ marginTop: 2, color: 'var(--info-fg)', flex: 'none' }} />
            <span className="muted">The period filters on <b>effective time</b>, when the sale happened at the till. The separate column <b>Recorded in block at</b> shows when the network committed it; the two can differ for offline tills and imported history.</span>
          </div>
        </div>
      </Card>

      <div className="mb"><SalesSummary from={fromMs} to={toMs} location={location} loc={loc} /></div>

      <Tabs label="Sales views" value={tab} onChange={setTab} items={[{ id: 'sales', label: 'Sales' }, { id: 'returns', label: 'Returns' }, { id: 'refunds', label: 'Refunds' }]} />
      <TabPanel id="sales" active={tab === 'sales'}><Card flush><SalesTable params={params} nav={(id) => nav(`/sales/${encodeURIComponent(id)}`)} /></Card></TabPanel>
      <TabPanel id="returns" active={tab === 'returns'}><ReturnsTable /></TabPanel>
      <TabPanel id="refunds" active={tab === 'refunds'}><RefundsTable /></TabPanel>
      <div className="mt"><Callout tone="neutral"><span>Imported sales are history asserted by the legacy system. They are labelled <Chip tone="accent" square>Imported</Chip> and were not witnessed by this ledger.</span></Callout></div>
    </div>
  );
}
