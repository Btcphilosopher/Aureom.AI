import { describe, expect, it } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import { Route, Routes } from 'react-router-dom';
import { META, NETWORK, PROJECTION, renderWithProviders, stubFetch } from '../test/utils';
import { Shell } from '../layout/Shell';
import Overview from './Overview';
import Network, { QuorumExplainer, spareValidators, avgBlockInterval } from './Network';
import SaleDetail from './SaleDetail';
import MigrationReport from './MigrationReport';
import { buildBook, promoState } from './Prices';
import { hitTarget, PROOF_CAVEAT } from './Explorer';
import type { NetworkInfo, PriceRecord, Promotion } from '../api/types';

const net = NETWORK as unknown as NetworkInfo;

describe('chain status strip (every page)', () => {
  it('shows finalised height, indexed height, lag and health in the top bar and footer', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION, '/q/stats': { meta: META, item: {} }, '/q/transactions': { meta: META, items: [], total: 0 }, '/q/inventory/exceptions': { meta: META, items: [], total: 0 }, '/q/exceptions': { meta: META, items: [], total: 0 }, '/metrics/latency': { count: 0, admission_ms: {}, finality_ms: {}, recent: [] }, '/q/migration': { meta: META, item: { state: { status: 'CLOSED' } } }, '/migration/reports': [] });
    renderWithProviders(<Routes><Route element={<Shell />}><Route index element={<div>page body</div>} /></Route></Routes>);
    await waitFor(() => expect(screen.getByTestId('top-head')).toHaveTextContent('121'));
    expect(screen.getByTestId('top-indexed')).toHaveTextContent('120');
    expect(screen.getByTestId('foot-head')).toHaveTextContent('121');
    expect(screen.getByTestId('foot-lag')).toHaveTextContent('1 block');
    expect(screen.getAllByText('HEALTHY').length).toBeGreaterThan(0);
    // exactly the eleven required sections
    const nav = screen.getByRole('navigation', { name: 'Sections' });
    expect(within(nav).getAllByRole('link').map((a) => a.textContent)).toEqual(['Overview', 'Network', 'Products', 'Inventory', 'Sales', 'Suppliers', 'Prices', 'Loyalty', 'Migration', 'Explorer', 'Administration']);
  });
  it('shows a banner and an UNREACHABLE chip when the gateway cannot be reached', async () => {
    const { vi } = await import('vitest');
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    renderWithProviders(<Routes><Route element={<Shell />}><Route index element={<div />} /></Route></Routes>);
    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('Gateway unreachable'));
    expect(screen.getAllByText('UNREACHABLE').length).toBeGreaterThan(0);
    vi.unstubAllGlobals();
  });
  it('turns the lag amber and red past the thresholds, and flags a halted network', async () => {
    stubFetch({ '/network': { ...NETWORK, bft: { ...NETWORK.bft, status: 'HALTED', online_power: 20, online_validators: 2 } }, '/projection/status': { ...PROJECTION, lag_blocks: 14, indexed_height: 107 } });
    renderWithProviders(<Routes><Route element={<Shell />}><Route index element={<div />} /></Route></Routes>);
    await waitFor(() => expect(screen.getByText('Network halted.')).toBeInTheDocument());
    expect(screen.getByText('Query data is 14 blocks behind the chain.')).toBeInTheDocument();
    expect(screen.getAllByText('HALTED').length).toBeGreaterThan(0);
  });
});

describe('Network quorum explainer', () => {
  it('states n, f, quorum and the halt-not-fork semantics', () => {
    renderWithProviders(<QuorumExplainer net={net} />, { withStatus: false });
    expect(screen.getByText(/Tolerated faults/)).toBeInTheDocument();
    expect(screen.getByText('27')).toBeInTheDocument();
    expect(screen.getByText(/Up to 1 validator may fail or even be malicious/)).toBeInTheDocument();
    expect(screen.getByText(/If 2 or more validators are down/)).toBeInTheDocument();
    expect(screen.getByText(/It halts, it does not fork/)).toBeInTheDocument();
  });
  it('computes how many validators can still fail', () => {
    const vs = net.validators;
    expect(spareValidators(vs, 27)).toBe(1);
    expect(spareValidators(vs.map((v, i) => ({ ...v, reachable: i < 3 })), 27)).toBe(0);
    expect(spareValidators(vs.map((v, i) => ({ ...v, reachable: i < 2 })), 27)).toBe(-1);
  });
  it('derives the block interval from timestamps', () => {
    expect(avgBlockInterval([{ time: '2026-11-12T20:00:00Z' }, { time: '2026-11-12T20:00:02Z' }, { time: '2026-11-12T20:00:03Z' }])).toBe(1500);
    expect(avgBlockInterval([{ time: '2026-11-12T20:00:00Z' }])).toBeUndefined();
  });
  it('renders the Network page from /network', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION, '/explorer/blocks': [{ height: 121, time: '2026-11-12T20:00:00Z', hash: 'A'.repeat(64), app_hash: 'B'.repeat(64), proposer: 'val-hq', num_txs: 2, num_rejected: 1, size_bytes: 2048 }], '/q/governance': { meta: META, item: { upgrades: [{ version: 2, activation_height: 500, status: 'SCHEDULED' }] } } });
    renderWithProviders(<Network />);
    await waitFor(() => expect(screen.getByRole('heading', { name: 'Validators' })).toBeInTheDocument());
    expect(screen.getAllByText('val-south').length).toBeGreaterThan(0);
    const validators = screen.getByRole('region', { name: 'Validators' });
    expect(within(validators).getByText('val-south')).toBeInTheDocument();
    await waitFor(() => expect(screen.getByText('Scheduled')).toBeInTheDocument());
  });
});

describe('Overview', () => {
  it('renders KPI tiles, rejected transactions with reason + code name + signer, and latency', async () => {
    stubFetch({
      '/network': NETWORK, '/projection/status': PROJECTION,
      '/q/stats': { meta: META, item: { products: 24, skus: 33, locations: 4, sales_total: 94, sales_24h: 36, sales_net_minor_24h: 123456, open_exceptions: 7, transactions_total: 252, transactions_rejected_24h: 18, active_reservations: 5, loyalty_points_outstanding: 5207 } },
      '/q/transactions': (u: URL) => (u.searchParams.get('status') === 'REJECTED'
        ? { meta: META, total: 1, items: [{ tx_id: 'tx_rej_1', type: 'CompleteSale', signer: 'term-n01-2', status: 'REJECTED', code: 404, code_name: 'INSUFFICIENT', reason: 'insufficient available stock for SKU-X', height: 5, block_time_ms: Date.now() - 5000 }] }
        : { meta: META, total: 1, items: [{ tx_id: 'tx_ok_1', type: 'PublishPrice', signer: 'pricing-mgr', status: 'OK', code: 0, code_name: 'OK', height: 4, block_time_ms: Date.now() - 9000 }] }),
      '/q/inventory/exceptions': { meta: META, items: [{ kind: 'TRANSFER_DISCREPANCY', severity: 'HIGH', ref: 'XFER-1', detail: 'short by 2' }], total: 1 },
      '/q/exceptions': { meta: META, items: [], total: 0 },
      '/metrics/latency': { count: 10, admission_ms: { p50: 6, p95: 14, p99: 31, max: 58 }, finality_ms: { p50: 1180, p95: 1960, p99: 2410, max: 3120 }, recent: [{ tx_id: 'a', type: 'X', admission_ms: 5, finality_ms: 1000, code: 0, at: '2026-11-12T20:00:00Z' }, { tx_id: 'b', type: 'X', admission_ms: 6, finality_ms: 1200, code: 0, at: '2026-11-12T20:00:01Z' }] },
      '/q/migration': { meta: META, item: { state: { status: 'CLOSED', source_system: 'legacy-retail-erp' } } },
      '/migration/reports': [{ id: 'rpt-final', phase: 'final', trial: false, generated_at: '2026-11-12T20:00:00Z', decision: 'ACCEPT', sha256: 'abc' }],
    });
    renderWithProviders(<Overview />);
    await waitFor(() => expect(screen.getByText('252')).toBeInTheDocument());
    expect(screen.getByText('5,207')).toBeInTheDocument();
    const rejected = screen.getByRole('region', { name: 'Rejected transactions' });
    await waitFor(() => expect(within(rejected).getByText('INSUFFICIENT')).toBeInTheDocument());
    expect(within(rejected).getByText('insufficient available stock for SKU-X')).toBeInTheDocument();
    expect(within(rejected).getByText('term-n01-2')).toBeInTheDocument();
    await waitFor(() => expect(screen.getByText('rpt-final')).toBeInTheDocument());
    expect(screen.getByText('PRODUCTION')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: /Latency percentiles/ })).toBeInTheDocument();
    expect(screen.getByText('Transfer discrepancy')).toBeInTheDocument();
  });
  it('shows an error state per panel instead of crashing when queries fail', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION });
    renderWithProviders(<Overview />);
    await waitFor(() => expect(screen.getAllByRole('alert').length).toBeGreaterThan(0));
  });
});

const SALE = {
  id: 'S-1', loc: 'STORE-N-01', channel: 'IN_STORE', customer_id: 'CUST-000101', currency: 'GBP', effective_at_ms: 1_700_000_000_000, block_time_ms: 1_700_000_090_000, rules_version: 1,
  sale_status: 'COMPLETED', payment_status: 'INSTRUCTED', fulfilment_status: 'PARTIALLY_RETURNED', payment_method: 'CARD', gross_minor: 1000, discount_minor: 150, net_minor: 850, paid_minor: 0, refund_instructed_minor: 300, refund_confirmed_minor: 100,
  provenance: { origin: 'NATIVE' },
  lines: [{ line_no: 1, sku: 'SKU-A', qty: { v: 2, unit: 'EA' }, price_id: 'PR-1', price_version: 1, unit_minor: 500, gross_minor: 1000, discount_minor: 150, net_minor: 850, returned_v: 0, returning_v: 0, refund_committed_minor: 0,
    pricing_steps: [{ promo_id: 'PROMO-1', promo_version: 1, type: 'PERCENT_OFF', before_minor: 1000, discount_minor: 150, after_minor: 850, explain: '15% of £10.00 = £1.50' }] }],
  returns: [], refunds: [{ id: 'RFD-1', sale_id: 'S-1', return_id: 'RET-1', amount_minor: 300, currency: 'GBP', status: 'INSTRUCTED' }, { id: 'RFD-2', sale_id: 'S-1', return_id: 'RET-1', amount_minor: 100, currency: 'GBP', status: 'CONFIRMED' }],
  loyalty_entries: [],
};

describe('Sale detail', () => {
  it('shows three separate statuses, pricing steps, effective vs recorded time and refund instructed vs confirmed', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION, '/q/sales/S-1': { meta: META, item: SALE }, '/q/skus': { meta: META, items: [{ id: 'SKU-A', product_id: 'P-1', unit: 'EA' }], total: 1 }, '/q/products': { meta: META, items: [], total: 0 } });
    renderWithProviders(<Routes><Route path="/sales/:id" element={<SaleDetail />} /></Routes>, { route: '/sales/S-1' });
    await waitFor(() => expect(screen.getByText('Payment instructed')).toBeInTheDocument());
    expect(screen.getByText('Completed')).toBeInTheDocument();
    expect(screen.getByText('Partly returned')).toBeInTheDocument();
    expect(screen.getByText('15% of £10.00 = £1.50')).toBeInTheDocument();
    expect(screen.getByText('Recorded in block at')).toBeInTheDocument();
    expect(screen.getByText('Refund instructed', { selector: '.kpi-label' })).toBeInTheDocument();
    expect(screen.getByText('Refund confirmed', { selector: '.kpi-label' })).toBeInTheDocument();
    expect(screen.getAllByText('Refund instructed').length).toBeGreaterThan(1); // KPI label + status chip
    expect(screen.getAllByText('Refund confirmed').length).toBeGreaterThan(1);
    expect(screen.getByRole('link', { name: /View on chain/ })).toHaveAttribute('href', '/explorer/record?key=sale%2FS-1');
  });
  it('reports a missing sale', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION });
    renderWithProviders(<Routes><Route path="/sales/:id" element={<SaleDetail />} /></Routes>, { route: '/sales/NOPE' });
    await waitFor(() => expect(screen.getByText('Sale not found')).toBeInTheDocument());
  });
});

const REPORT = {
  id: 'rpt-1', phase: 'trial', trial: true, generated_at: '2026-11-12T20:00:00Z', authoritative_system: 'SOURCE', mapping_version: 'map-v1', source_system: 'legacy', decision: 'REJECT', notes: 'fix stock',
  checks: [{ name: 'product count', source: 15, chain: 15, delta: 0, status: 'PASS' }, { name: 'stock on hand', source: 100, chain: 88, delta: -12, status: 'FAIL', detail: 'negative stock clamped' }, { name: 'barcodes', source: 2, chain: 0, delta: -2, status: 'WARN' }],
  exceptions: [{ kind: 'DUPLICATE_SKU', source_ref: 'items:1', detail: 'dup', disposition: 'EXCLUDED' }], unsupported_fields: [{ table: 'items', column: 'tax', rows: 3, treatment: 'preserved in source_extras' }], batches: [],
};

describe('Migration report', () => {
  it('labels trial vs production, renders checks with deltas and the legacy-assertion statement', async () => {
    stubFetch({ '/network': NETWORK, '/projection/status': PROJECTION, '/migration/reports/rpt-1': REPORT });
    renderWithProviders(<Routes><Route path="/migration/reports/:id" element={<MigrationReport />} /></Routes>, { route: '/migration/reports/rpt-1' });
    await waitFor(() => expect(screen.getByText('TRIAL RUN.')).toBeInTheDocument());
    expect(screen.getAllByText('TRIAL').length).toBeGreaterThan(0);
    expect(screen.getByText(/Imported history is the legacy system’s assertion/)).toBeInTheDocument();
    const fail = screen.getByText('stock on hand').closest('tr')!;
    expect(within(fail).getByText('Fail')).toBeInTheDocument();
    expect(within(fail).getByText('−12')).toBeInTheDocument();
    expect(screen.getByText('Excluded')).toBeInTheDocument();
    expect(screen.getByRole('list', { name: /Authoritative system: SOURCE/ })).toBeInTheDocument();
  });
});

describe('Prices and promotions helpers', () => {
  const now = 1_000_000;
  const mk = (over: Partial<PriceRecord>): PriceRecord => ({ id: 'P', sku: 'S', loc: '*', currency: 'GBP', unit_minor: 100, effective_from_ms: 0, effective_to_ms: 0, seq: 1, ...over });
  it('builds the price book with current, previous and scheduled prices', () => {
    const book = buildBook([mk({ id: 'a', seq: 1, unit_minor: 100, effective_from_ms: 100, effective_to_ms: 500 }), mk({ id: 'b', seq: 2, unit_minor: 120, effective_from_ms: 500 }), mk({ id: 'c', seq: 3, unit_minor: 90, effective_from_ms: now + 5000 })], now);
    expect(book).toHaveLength(1);
    expect(book[0].current?.id).toBe('b');
    expect(book[0].previous?.id).toBe('a');
    expect(book[0].upcoming?.id).toBe('c');
    expect(book[0].history).toHaveLength(3);
  });
  it('classifies promotion windows', () => {
    const p = { status: 'ACTIVE', from_ms: 100, to_ms: 0 } as Promotion;
    expect(promoState(p, 200).label).toBe('Running');
    expect(promoState({ ...p, from_ms: 500 }, 200).label).toBe('Scheduled');
    expect(promoState({ ...p, to_ms: 150 }, 200).label).toBe('Expired');
    expect(promoState({ ...p, status: 'ENDED' }, 200).label).toBe('Ended');
  });
});

describe('Explorer helpers', () => {
  it('maps search hits from both the real ({type, ref}) and documented shapes', () => {
    expect(hitTarget({ type: 'block', ref: 12 } as never).to).toBe('/explorer/block/12');
    expect(hitTarget({ type: 'record', ref: 'sale/S-1' } as never).to).toBe('/explorer/record?key=sale%2FS-1');
    expect(hitTarget({ type: 'tx', ref: 'tx_abc' } as never).to).toBe('/explorer/tx/tx_abc');
    expect(hitTarget({ kind: 'record', key: 'po/PO-1' }).kind).toBe('Record');
    expect(hitTarget({ kind: 'block', height: 3 }).label).toBe('Block 3');
  });
  it('keeps the exact proof caveat', () => {
    expect(PROOF_CAVEAT).toBe('A proof only establishes inclusion of that key/value in a committed state root, not business correctness or completeness of a search.');
  });
});
