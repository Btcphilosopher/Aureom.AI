import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems, asTotal, metaOf } from '../api/client';
import type { ExceptionRec, ListResponse, LoyaltyAccount, LoyaltyEntry } from '../api/types';
import { formatInt, formatMoney, formatTime } from '../lib/format';
import { useDebounced } from '../lib/hooks';
import { ruleLabel } from '../lib/labels';
import { Callout, Card, KV, PageHeader } from '../ui/Card';
import { Chip, ProvenanceChip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { ChainLink } from '../ui/misc';
import { ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';

function findArray<T>(root: unknown, keys: string[]): T[] {
  const r = root as Record<string, unknown> | undefined;
  const item = r?.item as Record<string, unknown> | undefined;
  for (const k of keys) {
    if (Array.isArray(r?.[k])) return r![k] as T[];
    if (Array.isArray(item?.[k])) return item![k] as T[];
  }
  return [];
}

const TYPE_TONE: Record<string, 'ok' | 'info' | 'warn' | 'bad' | 'accent'> = { EARN: 'ok', REDEEM: 'info', EXPIRE: 'warn', REVERSE: 'bad', OPENING: 'accent' };

function Ledger({ id }: { id: string }) {
  const q = useApi<unknown>(`/q/loyalty/accounts/${encodeURIComponent(id)}`);
  const [hl, setHl] = useState<string | null>(null);
  const root = q.data as { item?: LoyaltyAccount } | undefined;
  const account = (root?.item ?? root) as LoyaltyAccount | undefined;
  const entries = useMemo(() => findArray<LoyaltyEntry>(q.data, ['entries', 'ledger', 'items']), [q.data]);

  const rows = useMemo(() => {
    const sorted = [...entries].sort((a, b) => (a.created_height ?? 0) - (b.created_height ?? 0) || a.effective_at_ms - b.effective_at_ms);
    let bal = 0;
    const reversedBy = new Map<string, LoyaltyEntry[]>();
    for (const e of sorted) if (e.reverses) reversedBy.set(e.reverses, [...(reversedBy.get(e.reverses) ?? []), e]);
    return sorted.map((e) => { bal += e.points; return { e, balance: bal, reversedBy: reversedBy.get(e.id) ?? [] }; }).reverse();
  }, [entries]);

  const cols: Column<(typeof rows)[number]>[] = [
    { key: 'when', header: 'Effective', sortValue: (r) => r.e.effective_at_ms, render: (r) => formatTime(r.e.effective_at_ms, { seconds: false }) },
    { key: 'id', header: 'Entry', mono: true, render: (r) => r.e.id },
    { key: 'type', header: 'Type', sortValue: (r) => r.e.type, render: (r) => <Chip tone={TYPE_TONE[r.e.type] ?? 'neutral'} square>{r.e.type}</Chip> },
    { key: 'pts', header: 'Points', align: 'right', sortValue: (r) => r.e.points, render: (r) => <b style={{ color: r.e.points < 0 ? 'var(--bad-fg)' : 'var(--ok-fg)' }}>{r.e.points > 0 ? '+' : ''}{formatInt(r.e.points)}</b> },
    { key: 'bal', header: 'Balance after', align: 'right', render: (r) => formatInt(r.balance) },
    { key: 'val', header: 'Value', align: 'right', render: (r) => (r.e.value_minor ? formatMoney(r.e.value_minor) : <span className="muted">–</span>) },
    { key: 'src', header: 'Linked to', wrap: true, render: (r) => (
      <div className="stack-sm" style={{ gap: 2 }}>
        {r.e.sale_id && <span>Sale <Link to={`/sales/${encodeURIComponent(r.e.sale_id)}`} className="mono">{r.e.sale_id}</Link></span>}
        {r.e.refund_id && <span>Refund <span className="mono">{r.e.refund_id}</span></span>}
        {r.e.reverses && <span>Reverses <button type="button" className="link-btn mono" onClick={() => setHl(r.e.reverses!)}>{r.e.reverses}</button></span>}
        {r.reversedBy.map((x) => <span key={x.id}>Reversed by <button type="button" className="link-btn mono" onClick={() => setHl(x.id)}>{x.id}</button> <span className="muted">({formatInt(Math.abs(x.points))} pts)</span></span>)}
        {!r.e.sale_id && !r.e.refund_id && !r.e.reverses && r.reversedBy.length === 0 && <span className="muted">–</span>}
      </div>) },
    { key: 'flag', header: 'Flags', render: (r) => (r.e.shortfall_points ? <Chip tone="warn" dot title="The customer no longer held enough points to fully reverse this entry. The shortfall could not be taken back.">Shortfall {formatInt(r.e.shortfall_points)} pts</Chip> : r.reversedBy.length ? <Chip tone="neutral">Reversed</Chip> : <span className="muted">–</span>) },
    { key: 'rule', header: 'Rule', render: (r) => ruleLabel(r.e.rule) },
    { key: 'orig', header: 'Origin', render: (r) => <ProvenanceChip origin={r.e.provenance?.origin} /> },
  ];

  return (
    <Card title={<span>Points ledger <span className="mono muted">{id}</span></span>} sub="Every change to the balance is an entry; reversals point back to the entry they undo" flush actions={<ChainLink stateKey={`loy/${id}`}>Account on chain</ChainLink>} foot={<Staleness meta={metaOf(q.data)} />}>
      {q.isPending ? <LoadingBlock rows={6} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} title={(q.error as { status?: number })?.status === 404 ? 'Account not found' : undefined} /> : (
        <>
          {account && (
            <div className="card-body" style={{ borderBottom: '1px solid var(--border)' }}>
              <div className="grid cols-3">
                <KV items={[['Points balance', <b>{formatInt(account.points)}</b>], ['Lifetime earned', formatInt(account.lifetime_earned)]]} />
                <KV items={[['Entries', formatInt(typeof account.entries === 'number' ? account.entries : entries.length)], ['Status', <StatusChip value={account.status} />]]} />
                <KV items={[['Origin', <ProvenanceChip origin={account.provenance?.origin} />]]} />
              </div>
            </div>
          )}
          {rows.length === 0 ? <div className="state">No ledger entries.</div> : (
            <DataTable<(typeof rows)[number]> caption="Loyalty entries ledger" rows={rows} rowKey={(r) => r.e.id} columns={cols} pageSize={25} selectedKey={hl} onRowClick={(r) => setHl(r.e.id)} rowClass={(r) => (r.e.shortfall_points ? 'row-bad' : undefined)} initialSort={undefined} />
          )}
        </>
      )}
    </Card>
  );
}

export default function Loyalty() {
  const { id } = useParams();
  const nav = useNavigate();
  const [qs, setQs] = useState('');
  const dq = useDebounced(qs, 250);
  const q = useApi<ListResponse<LoyaltyAccount>>('/q/loyalty/accounts', { q: dq, limit: 500 }, { keep: true });
  const rows = asItems<LoyaltyAccount>(q.data);
  const shortfalls = useApi<ListResponse<ExceptionRec>>('/q/exceptions', { kind: 'LOYALTY_SHORTFALL', status: 'OPEN', limit: 20 });
  const sf = asItems<ExceptionRec>(shortfalls.data);
  return (
    <div className="page">
      <PageHeader title="Loyalty" subtitle="Customer points accounts and the entry ledger behind each balance." />
      {sf.length > 0 && (
        <div className="mb"><Callout tone="warn"><span><b>{sf.length} loyalty shortfall{sf.length === 1 ? '' : 's'} open.</b> A reversal could not remove all points because the customer had already spent them. {sf.slice(0, 3).map((e) => <span key={e.id} className="mono"> {e.ref}</span>)}{sf.length > 3 ? ' …' : ''}</span></Callout></div>
      )}
      <Card flush className="mb" foot={<Staleness meta={metaOf(q.data)} />}>
        <div className="toolbar">
          <div className="field" style={{ width: 260 }}><label htmlFor="loy-q">Search accounts</label><input id="loy-q" className="input mono" type="search" placeholder="CUST-000123" value={qs} onChange={(e) => setQs(e.target.value)} /></div>
        </div>
        <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No loyalty accounts" emptyText="No accounts match your search.">
          {() => (
            <DataTable<LoyaltyAccount> caption="Loyalty accounts" rows={rows} rowKey={(a) => a.id} pageSize={10} total={asTotal(q.data)} selectedKey={id ?? null} onRowClick={(a) => nav(`/loyalty/${encodeURIComponent(a.id)}`)} initialSort={{ key: 'pts', dir: 'desc' }}
              columns={[
                { key: 'id', header: 'Account', mono: true, sortValue: (a) => a.id, render: (a) => a.id },
                { key: 'pts', header: 'Points balance', align: 'right', sortValue: (a) => a.points, render: (a) => <b>{formatInt(a.points)}</b> },
                { key: 'life', header: 'Lifetime earned', align: 'right', sortValue: (a) => a.lifetime_earned, render: (a) => formatInt(a.lifetime_earned) },
                { key: 'ent', header: 'Ledger entries', align: 'right', sortValue: (a) => (typeof a.entries === 'number' ? a.entries : 0), render: (a) => (typeof a.entries === 'number' ? a.entries : '–') },
                { key: 'st', header: 'Status', render: (a) => <StatusChip value={a.status} /> },
                { key: 'pv', header: 'Origin', render: (a) => <ProvenanceChip origin={a.provenance?.origin} /> },
              ]}
            />
          )}
        </QueryBoundary>
      </Card>
      {id ? <Ledger id={id} /> : <Card><div className="state"><div className="state-title">Select an account</div>Choose a row above to see its points ledger, including reversals and shortfalls.</div></Card>}
    </div>
  );
}
