import { Link } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems, asTotal, metaOf } from '../api/client';
import type { GoodsReceipt, ListResponse, PurchaseOrder, Supplier } from '../api/types';
import { useLocations, useSkus, useSuppliers } from '../api/refdata';
import { formatMoney, formatTime, humanize, lineValue } from '../lib/format';
import { useParam } from '../lib/hooks';
import { Callout, Card, KV, PageHeader, Section } from '../ui/Card';
import { Chip, ProvenanceChip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Drawer } from '../ui/Drawer';
import { TabPanel, Tabs } from '../ui/Tabs';
import { ChainLink, TxLink } from '../ui/misc';
import { QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';

type Units = ReturnType<typeof useSkus>;

function SupplierList({ onPick }: { onPick: (id: string) => void }) {
  const q = useApi<ListResponse<Supplier>>('/q/suppliers', { limit: 500 });
  const rows = asItems<Supplier>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No suppliers">
        {() => (
          <DataTable<Supplier> caption="Suppliers" rows={rows} rowKey={(s) => s.id} pageSize={25} quickFilter={(s, t) => `${s.id} ${s.name}`.toLowerCase().includes(t)}
            onRowClick={(s) => onPick(s.id)}
            columns={[
              { key: 'id', header: 'Supplier ID', mono: true, sortValue: (s) => s.id, render: (s) => s.id },
              { key: 'name', header: 'Name', sortValue: (s) => s.name, render: (s) => <b>{s.name}</b> },
              { key: 'terms', header: 'Payment terms', render: (s) => s.terms || '–' },
              { key: 'st', header: 'Status', sortValue: (s) => s.status, render: (s) => <StatusChip value={s.status} /> },
              { key: 'pv', header: 'Origin', render: (s) => <ProvenanceChip origin={s.provenance?.origin} /> },
              { key: 'po', header: '', render: () => <span className="muted">View purchase orders →</span> },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function ApprovalCell({ po }: { po: PurchaseOrder }) {
  if (po.status === 'CANCELLED') return <span className="muted">n/a</span>;
  if (!po.approved_by) return <Chip tone="warn" dot>Awaiting approval</Chip>;
  const sod = po.approved_by !== po.created_by;
  return <span className="row" style={{ gap: 6 }}><Chip tone={sod ? 'ok' : 'bad'} dot>{sod ? 'Approved' : 'Self-approved'}</Chip><span className="mono muted">{po.approved_by}</span></span>;
}

function PoDrawer({ po, sup, locs, units, onClose }: { po: PurchaseOrder; sup: ReturnType<typeof useSuppliers>; locs: ReturnType<typeof useLocations>; units: Units; onClose: () => void }) {
  const rq = useApi<ListResponse<GoodsReceipt>>('/q/receipts', { limit: 100 });
  const receipts = asItems<GoodsReceipt>(rq.data).filter((r) => r.po_id === po.id);
  return (
    <Drawer title={<span>Purchase order <span className="mono">{po.id}</span></span>} subtitle={<span className="row wrap"><StatusChip kind="po" value={po.status} /><span>{sup.nameOf(po.supplier_id) ?? po.supplier_id}</span></span>} onClose={onClose} actions={<ChainLink stateKey={`po/${po.id}`} />}>
      <Section title="Order">
        <KV items={[
          ['Supplier', `${sup.nameOf(po.supplier_id) ?? ''} (${po.supplier_id})`],
          ['Deliver to', `${po.location_id}${locs.nameOf(po.location_id) ? ' · ' + locs.nameOf(po.location_id) : ''}`],
          ['Ordered', formatTime(po.ordered_at_ms)],
          ['Total', <b>{formatMoney(po.total_minor, po.currency)}</b>],
          ['Created by', <span className="mono">{po.created_by}</span>],
          ['Approved by', po.approved_by ? <span className="mono">{po.approved_by}</span> : <Chip tone="warn">Awaiting approval</Chip>],
          ['Origin', <ProvenanceChip origin={po.provenance?.origin} />],
          ['Last change', po.updated_tx ? <TxLink id={po.updated_tx} /> : '–'],
        ]} />
        <div className="mt"><Callout tone="info">Separation of duties: the person who creates an order cannot be the one who approves it, and orders above the local limit need an approver with wider scope.</Callout></div>
      </Section>
      <Section title="Lines">
        <div className="card"><table className="dt compact">
          <caption className="sr-only">Purchase order lines</caption>
          <thead><tr><th>SKU</th><th className="num">Ordered</th><th className="num">Received</th><th className="num">Outstanding</th><th className="num">Unit cost</th><th className="num">Line value</th></tr></thead>
          <tbody>{po.lines.map((l) => (
            <tr key={l.line_no}>
              <td><span className="mono">{l.sku}</span><div className="muted">{units.nameOf(l.sku)}</div></td>
              <td className="num">{units.qty(l.qty.v, l.sku, { unit: false })} <span className="muted">{l.qty.unit}</span></td>
              <td className="num">{units.qty(l.received_v, l.sku, { unit: false })}</td>
              <td className="num"><b style={{ color: l.qty.v - l.received_v > 0 ? 'var(--warn-fg)' : undefined }}>{units.qty(Math.max(0, l.qty.v - l.received_v), l.sku, { unit: false })}</b></td>
              <td className="num">{formatMoney(l.unit_cost_minor, po.currency)}</td>
              <td className="num">{formatMoney(lineValue(l.unit_cost_minor, l.qty.v, l.qty.unit), po.currency)}</td>
            </tr>
          ))}</tbody>
        </table></div>
      </Section>
      <Section title="Goods receipts">
        {receipts.length === 0 ? <span className="muted">Nothing received yet.</span> : (
          <div className="card"><table className="dt compact"><caption className="sr-only">Receipts</caption><thead><tr><th>Receipt</th><th>Received</th><th>By</th><th>Lines</th></tr></thead>
            <tbody>{receipts.map((r) => <tr key={r.id}><td className="mono">{r.id}</td><td>{formatTime(r.effective_at_ms, { seconds: false })}</td><td className="mono">{r.received_by}</td><td>{r.lines.map((l) => `${l.sku} ×${units.qty(l.qty.v, l.sku, { unit: false })}`).join(', ')}</td></tr>)}</tbody></table></div>
        )}
      </Section>
    </Drawer>
  );
}

function PurchaseOrders({ sup, locs, units, supplier, setSupplier }: { sup: ReturnType<typeof useSuppliers>; locs: ReturnType<typeof useLocations>; units: Units; supplier: string; setSupplier: (s: string | null) => void }) {
  const [status, setStatus] = useParam('postatus');
  const [sel, setSel] = useParam('po');
  const q = useApi<ListResponse<PurchaseOrder>>('/q/purchase-orders', { status, supplier, limit: 500 }, { keep: true });
  const rows = asItems<PurchaseOrder>(q.data);
  const open = rows.find((p) => p.id === sel);
  const cols: Column<PurchaseOrder>[] = [
    { key: 'id', header: 'Purchase order', mono: true, sortValue: (p) => p.id, render: (p) => p.id },
    { key: 'sup', header: 'Supplier', sortValue: (p) => sup.nameOf(p.supplier_id) ?? p.supplier_id, render: (p) => sup.nameOf(p.supplier_id) ?? p.supplier_id },
    { key: 'loc', header: 'Deliver to', render: (p) => p.location_id },
    { key: 'st', header: 'Status', sortValue: (p) => p.status, render: (p) => <StatusChip kind="po" value={p.status} /> },
    { key: 'tot', header: 'Total', align: 'right', sortValue: (p) => p.total_minor, render: (p) => <b>{formatMoney(p.total_minor, p.currency)}</b> },
    { key: 'ln', header: 'Lines', align: 'right', render: (p) => p.lines.length },
    { key: 'cb', header: 'Created by', render: (p) => <span className="mono">{p.created_by}</span> },
    { key: 'ab', header: 'Approval', tip: 'Orders must be approved by someone other than the creator before goods can be received.', render: (p) => <ApprovalCell po={p} /> },
    { key: 'oa', header: 'Ordered', sortValue: (p) => p.ordered_at_ms, render: (p) => formatTime(p.ordered_at_ms, { seconds: false }) },
    { key: 'rc', header: 'Receipts', align: 'right', render: (p) => p.receipts?.length ?? 0 },
  ];
  return (
    <>
      <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
        <div className="toolbar">
          <div className="field"><label htmlFor="po-st">Status</label>
            <select id="po-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">Any status</option>
              {['DRAFT', 'APPROVED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED'].map((s) => <option key={s} value={s}>{s === 'DRAFT' ? 'Awaiting approval' : humanize(s)}</option>)}
            </select></div>
          <div className="field"><label htmlFor="po-sup">Supplier</label>
            <select id="po-sup" className="select" value={supplier} onChange={(e) => setSupplier(e.target.value)}>
              <option value="">All suppliers</option>{sup.suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select></div>
        </div>
        <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No purchase orders" emptyText="No orders match these filters.">
          {() => <DataTable<PurchaseOrder> caption="Purchase orders" rows={rows} rowKey={(p) => p.id} columns={cols} pageSize={25} total={asTotal(q.data)} initialSort={{ key: 'oa', dir: 'desc' }} onRowClick={(p) => setSel(p.id)} selectedKey={sel || null} />}
        </QueryBoundary>
      </Card>
      {open && <PoDrawer po={open} sup={sup} locs={locs} units={units} onClose={() => setSel(null)} />}
    </>
  );
}

function Receipts({ sup, units }: { sup: ReturnType<typeof useSuppliers>; units: Units }) {
  const q = useApi<ListResponse<GoodsReceipt>>('/q/receipts', { limit: 500 });
  const rows = asItems<GoodsReceipt>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No goods receipts">
        {() => (
          <DataTable<GoodsReceipt> caption="Goods receipts" rows={rows} rowKey={(r) => r.id} pageSize={25} initialSort={{ key: 'eff', dir: 'desc' }}
            columns={[
              { key: 'id', header: 'Receipt', mono: true, sortValue: (r) => r.id, render: (r) => r.id },
              { key: 'po', header: 'Purchase order', mono: true, render: (r) => r.po_id ?? '–' },
              { key: 'sup', header: 'Supplier', render: (r) => sup.nameOf(r.supplier_id) ?? r.supplier_id ?? '–' },
              { key: 'loc', header: 'Received at', render: (r) => r.location_id },
              { key: 'lines', header: 'Items', wrap: true, render: (r) => r.lines.map((l) => <div key={l.sku + (l.po_line ?? '')}><span className="mono">{l.sku}</span> × {units.qty(l.qty.v, l.sku)}</div>) },
              { key: 'eff', header: 'Received (effective)', sortValue: (r) => r.effective_at_ms, render: (r) => formatTime(r.effective_at_ms, { seconds: false }) },
              { key: 'by', header: 'Received by', render: (r) => <span className="mono">{r.received_by}</span> },
              { key: 'rev', header: 'Reversed', render: (r) => (r.reversed ? <Chip tone="bad" square>Reversed</Chip> : <span className="muted">No</span>) },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

interface OutRow { key: string; po: PurchaseOrder; sku: string; ordered: number; received: number; outstanding: number; value: number; unit: string }

function Outstanding({ sup, units }: { sup: ReturnType<typeof useSuppliers>; units: Units }) {
  const q = useApi<ListResponse<PurchaseOrder>>('/q/purchase-orders', { limit: 500 });
  const rows: OutRow[] = asItems<PurchaseOrder>(q.data)
    .filter((p) => p.status === 'APPROVED' || p.status === 'PARTIALLY_RECEIVED')
    .flatMap((p) => p.lines.filter((l) => l.qty.v - l.received_v > 0).map((l) => ({ key: `${p.id}/${l.line_no}`, po: p, sku: l.sku, ordered: l.qty.v, received: l.received_v, outstanding: l.qty.v - l.received_v, value: lineValue(l.unit_cost_minor, l.qty.v - l.received_v, l.qty.unit), unit: l.qty.unit })));
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="card-body" style={{ paddingBottom: 0 }}><Callout tone="info">Approved purchase orders where the supplier has not yet delivered everything that was ordered.</Callout></div>
      <QueryBoundary q={q} isEmpty={() => rows.length === 0} emptyTitle="Nothing outstanding" emptyText="All approved orders have been fully received.">
        {() => (
          <DataTable<OutRow> caption="Outstanding quantities" rows={rows} rowKey={(r) => r.key} pageSize={25} initialSort={{ key: 'val', dir: 'desc' }}
            columns={[
              { key: 'po', header: 'Purchase order', mono: true, sortValue: (r) => r.po.id, render: (r) => r.po.id },
              { key: 'sup', header: 'Supplier', render: (r) => sup.nameOf(r.po.supplier_id) ?? r.po.supplier_id },
              { key: 'sku', header: 'SKU', mono: true, sortValue: (r) => r.sku, render: (r) => r.sku },
              { key: 'name', header: 'Product', render: (r) => units.nameOf(r.sku) ?? '–' },
              { key: 'dest', header: 'Deliver to', render: (r) => r.po.location_id },
              { key: 'ord', header: 'Ordered', align: 'right', render: (r) => units.qty(r.ordered, r.sku, { unit: false }) },
              { key: 'rec', header: 'Received', align: 'right', render: (r) => units.qty(r.received, r.sku, { unit: false }) },
              { key: 'out', header: 'Outstanding', align: 'right', sortValue: (r) => r.outstanding, render: (r) => <b>{units.qty(r.outstanding, r.sku)}</b> },
              { key: 'val', header: 'Outstanding value', align: 'right', sortValue: (r) => r.value, render: (r) => formatMoney(r.value, r.po.currency) },
              { key: 'st', header: 'Status', render: (r) => <StatusChip kind="po" value={r.po.status} /> },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

export default function Suppliers() {
  const [tab, setTab] = useParam('tab', 'suppliers');
  const [supplier, setSupplier] = useParam('supplier');
  const sup = useSuppliers();
  const locs = useLocations();
  const units = useSkus();
  const pending = useApi<ListResponse<PurchaseOrder>>('/q/purchase-orders', { status: 'DRAFT', limit: 1 });
  return (
    <div className="page">
      <PageHeader title="Suppliers" subtitle="Suppliers, purchase orders and what is still to be delivered." />
      <Tabs label="Supplier views" value={tab} onChange={setTab} items={[
        { id: 'suppliers', label: 'Suppliers' },
        { id: 'orders', label: 'Purchase orders', count: pending.data ? asTotal(pending.data) || undefined : undefined, countTone: 'warn' },
        { id: 'receipts', label: 'Goods receipts' },
        { id: 'outstanding', label: 'Outstanding quantities' },
      ]} />
      <TabPanel id="suppliers" active={tab === 'suppliers'}><SupplierList onPick={(id) => { setSupplier(id); setTab('orders'); }} /></TabPanel>
      <TabPanel id="orders" active={tab === 'orders'}><PurchaseOrders sup={sup} locs={locs} units={units} supplier={supplier} setSupplier={setSupplier} /></TabPanel>
      <TabPanel id="receipts" active={tab === 'receipts'}><Receipts sup={sup} units={units} /></TabPanel>
      <TabPanel id="outstanding" active={tab === 'outstanding'}><Outstanding sup={sup} units={units} /></TabPanel>
      <p className="muted mt">Related: <Link to="/inventory?tab=transfers">stock transfers</Link>, <Link to="/inventory">stock balances</Link>.</p>
    </div>
  );
}
