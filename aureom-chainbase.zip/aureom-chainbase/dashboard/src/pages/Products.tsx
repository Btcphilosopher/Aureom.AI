import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItem, asItems, asTotal, metaOf } from '../api/client';
import type { ListResponse, Product, Provenance, Sku } from '../api/types';
import { formatMoney, formatTime, shallowDiff, humanize, compactJSON } from '../lib/format';
import { useDebounced, useParam } from '../lib/hooks';
import { Callout, Card, KV, PageHeader, Section } from '../ui/Card';
import { Chip, ProvenanceChip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Drawer } from '../ui/Drawer';
import { ChainLink, KeyValueTags, TxLink } from '../ui/misc';
import { ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconRefresh } from '../ui/icons';

function skuObjects(p: Product): Sku[] {
  if (Array.isArray(p.sku_details) && p.sku_details.length) return p.sku_details;
  return (p.skus ?? []).filter((s): s is Sku => typeof s === 'object' && s !== null);
}
function skuCount(p: Product): number {
  return Math.max((p.skus ?? []).length, p.sku_details?.length ?? 0);
}

function ProvenanceBlock({ prov }: { prov?: Provenance }) {
  if (!prov) return <span className="muted">No provenance recorded.</span>;
  const imported = prov.origin?.startsWith('IMPORTED');
  return (
    <div className="stack-sm">
      <div className="row"><ProvenanceChip origin={prov.origin} /> <span className="muted">{imported ? 'Imported from a legacy system. This is that system’s assertion; the ledger records that it was imported, not that it was true.' : 'Created and signed on this ledger by an authorised identity.'}</span></div>
      {imported && (
        <KV items={[
          ['Source system', prov.source_system],
          ['Source id', <span className="mono">{prov.source_id}</span>],
          ['Import batch', <span className="mono">{prov.batch_id}</span>],
          ['Mapping version', <span className="mono">{prov.mapping_version}</span>],
          ['Snapshot', <span className="mono">{prov.snapshot_id}</span>],
        ]} />
      )}
    </div>
  );
}

interface VersionRow {
  version?: number;
  height?: number;
  tx_id?: string;
  tx_type?: string;
  signer?: string;
  block_time_ms?: number;
  value?: unknown;
  deleted?: boolean;
  [k: string]: unknown;
}

function ProductDrawer({ id, onClose }: { id: string; onClose: () => void }) {
  const q = useApi<unknown>(`/q/products/${encodeURIComponent(id)}`);
  const root = (q.data ?? {}) as { item?: Record<string, unknown>; price_history?: unknown[]; versions?: unknown[] };
  const item = (asItem<Product & { price_history?: unknown[]; versions?: unknown[] }>(q.data) ?? undefined) as (Product & { price_history?: unknown[]; versions?: unknown[] }) | undefined;
  const priceHist = ((item?.price_history ?? root.price_history ?? []) as Record<string, unknown>[]).slice();
  const versions = ((item?.versions ?? root.versions ?? []) as VersionRow[]).slice();
  const embedded = item ? skuObjects(item) : [];
  const needSkus = !!item && embedded.length === 0 && (item.skus ?? []).length > 0;
  const skusQ = useApi<ListResponse<Sku>>('/q/skus', { product: id, limit: 100 }, { enabled: needSkus });
  const skus = embedded.length ? embedded : asItems<Sku>(skusQ.data);

  const extras = useMemo(() => {
    const out: { scope: string; key: string; value: string }[] = [];
    for (const [k, v] of Object.entries(item?.source_extras ?? {})) out.push({ scope: `Product ${id}`, key: k, value: v });
    for (const s of skus) for (const [k, v] of Object.entries(s.source_extras ?? {})) out.push({ scope: `SKU ${s.id}`, key: k, value: v });
    return out;
  }, [item, skus, id]);

  return (
    <Drawer
      title={item?.name ?? id}
      subtitle={item ? <span className="row wrap"><span className="mono">{item.id}</span><StatusChip value={item.status} /><ProvenanceChip origin={item.provenance?.origin} /></span> : undefined}
      onClose={onClose}
      actions={<ChainLink stateKey={`product/${id}`}>View on chain</ChainLink>}
    >
      {q.isPending && <LoadingBlock rows={8} />}
      {q.isError && <ErrorState error={q.error} onRetry={() => void q.refetch()} />}
      {item && (
        <>
          <Section title="Details">
            <KV items={[
              ['Brand', item.brand], ['Category', item.category], ['Status', <StatusChip value={item.status} />],
              ['Attributes', <KeyValueTags data={item.attributes} />],
              ['Current version', item.version !== undefined ? `v${item.version}` : '–'],
              ['Last updated', item.updated_tx ? <TxLink id={item.updated_tx} /> : '–'],
            ]} />
          </Section>
          <Section title="Origin of this record"><ProvenanceBlock prov={item.provenance} /></Section>
          <Section title={`SKUs (${skuCount(item)})`}>
            {needSkus && skusQ.isPending ? <LoadingBlock rows={3} /> : (
              <div className="card"><DataTable<Sku>
                caption="SKUs of this product"
                rows={skus}
                rowKey={(s) => s.id}
                pageSize={10}
                columns={[
                  { key: 'id', header: 'SKU', mono: true, sortValue: (s) => s.id, render: (s) => s.id },
                  { key: 'bc', header: 'Barcode', mono: true, render: (s) => s.barcode || '–' },
                  { key: 'unit', header: 'Unit', render: (s) => s.unit },
                  { key: 'attr', header: 'Variant', wrap: true, render: (s) => <KeyValueTags data={s.attributes} /> },
                  { key: 'scarce', header: 'Scarce', tip: 'Scarce SKUs need a pre-allocated allowance for offline sales.', render: (s) => (s.scarce ? <Chip tone="warn">Scarce</Chip> : <span className="muted">No</span>) },
                  { key: 'st', header: 'Status', render: (s) => <StatusChip value={s.status} /> },
                  { key: 'pv', header: 'Origin', render: (s) => <ProvenanceChip origin={s.provenance?.origin} /> },
                ]}
              /></div>
            )}
          </Section>
          <Section title="Price history">
            {priceHist.length === 0 ? <span className="muted">No prices published for this product yet.</span> : (
              <div className="card"><DataTable<Record<string, unknown>>
                caption="Price history"
                rows={priceHist}
                rowKey={(r) => String(r.id ?? r.seq ?? JSON.stringify(r))}
                pageSize={10}
                initialSort={{ key: 'from', dir: 'desc' }}
                columns={[
                  { key: 'sku', header: 'SKU', mono: true, render: (r) => String(r.sku ?? '–') },
                  { key: 'loc', header: 'Location', render: (r) => (r.loc === '*' || !r.loc ? 'All locations' : String(r.loc)) },
                  { key: 'unit', header: 'Unit price', align: 'right', sortValue: (r) => Number(r.unit_minor ?? 0), render: (r) => formatMoney(Number(r.unit_minor ?? 0), String(r.currency ?? 'GBP')) },
                  { key: 'from', header: 'Effective from', sortValue: (r) => Number(r.effective_from_ms ?? r.from_ms ?? 0), render: (r) => formatTime(Number(r.effective_from_ms ?? r.from_ms ?? 0), { seconds: false }) },
                  { key: 'to', header: 'Until', render: (r) => { const t = Number(r.effective_to_ms ?? r.to_ms ?? 0); return t ? formatTime(t, { seconds: false }) : <span className="muted">open-ended</span>; } },
                ]}
              /></div>
            )}
          </Section>
          <Section title="Version history">
            {versions.length === 0 ? <span className="muted">Only the original version exists.</span> : (
              <ul className="timeline">
                {versions.map((v, i, arr) => {
                  const cur = (v.value ?? v) as Record<string, unknown>;
                  const prev = i > 0 ? ((arr[i - 1].value ?? arr[i - 1]) as Record<string, unknown>) : undefined;
                  const diffs = prev ? shallowDiff(prev, cur).filter((d) => !['updated_height', 'updated_tx', 'version'].includes(d.key)) : [];
                  return (
                    <li key={i}>
                      <div className="tl-head">
                        <b>Version {String(v.version ?? cur.version ?? i + 1)}</b>
                        {v.tx_type && <Chip tone="info" square>{humanize(String(v.tx_type).replace(/([a-z])([A-Z])/g, '$1_$2'))}</Chip>}
                        <span className="tl-time">{v.block_time_ms ? formatTime(v.block_time_ms) : ''}{v.signer ? ` · ${v.signer}` : ''}</span>
                        {v.tx_id && <TxLink id={v.tx_id} />}
                      </div>
                      {i === 0 ? <div className="muted">Created</div> : diffs.length === 0 ? <div className="muted">No field changes</div> : (
                        <div className="diff">
                          {diffs.map((d) => (
                            <div className="diff-row" key={d.key}><div className="k">{d.key}</div><div className="b">{compactJSON(d.before, 60)}</div><div className="a">{compactJSON(d.after, 60)}</div></div>
                          ))}
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </Section>
          <Section title="Preserved source fields">
            <p className="muted">Fields from the legacy system that the ledger schema has no column for. They are kept verbatim so nothing is lost in migration.</p>
            {extras.length === 0 ? <span className="muted">None: every source field was mapped.</span> : (
              <div className="card"><table className="dt compact">
                <caption className="sr-only">Preserved source fields</caption>
                <thead><tr><th>Belongs to</th><th>Source field</th><th>Value</th></tr></thead>
                <tbody>{extras.map((e, i) => (<tr key={i}><td>{e.scope}</td><td className="mono">{e.key}</td><td style={{ whiteSpace: 'normal' }}>{e.value}</td></tr>))}</tbody>
              </table></div>
            )}
          </Section>
        </>
      )}
    </Drawer>
  );
}

export default function Products() {
  const [qs, setQs] = useState('');
  const [category, setCategory] = useParam('category');
  const [status, setStatus] = useParam('status');
  const [sel, setSel] = useParam('id');
  const dq = useDebounced(qs, 250);

  const all = useApi<ListResponse<Product>>('/q/products', { limit: 500 });
  const categories = useMemo(() => Array.from(new Set(asItems<Product>(all.data).map((p) => p.category).filter(Boolean) as string[])).sort(), [all.data]);

  const q = useApi<ListResponse<Product>>('/q/products', { q: dq, category, status, limit: 500 }, { keep: true });
  const rows = asItems<Product>(q.data);

  const cols: Column<Product>[] = [
    { key: 'id', header: 'Product ID', mono: true, sortValue: (p) => p.id, render: (p) => p.id },
    { key: 'name', header: 'Name', sortValue: (p) => p.name, render: (p) => <b>{p.name}</b> },
    { key: 'brand', header: 'Brand', sortValue: (p) => p.brand, render: (p) => p.brand || '–' },
    { key: 'cat', header: 'Category', sortValue: (p) => p.category, render: (p) => p.category || '–' },
    { key: 'skus', header: 'SKUs', align: 'right', sortValue: (p) => skuCount(p), render: (p) => skuCount(p) },
    { key: 'status', header: 'Status', sortValue: (p) => p.status, render: (p) => <StatusChip value={p.status} /> },
    { key: 'prov', header: 'Origin', tip: 'Native: created on this ledger. Imported: loaded from the legacy system during migration.', sortValue: (p) => p.provenance?.origin, render: (p) => <ProvenanceChip origin={p.provenance?.origin} /> },
    { key: 'ver', header: 'Version', align: 'right', sortValue: (p) => p.version, render: (p) => (p.version !== undefined ? `v${p.version}` : '–') },
  ];

  return (
    <div className="page">
      <PageHeader
        title="Products"
        subtitle="Product catalogue with SKUs, price history and where each record came from."
        actions={<button type="button" className="btn" onClick={() => void q.refetch()}><IconRefresh /> Refresh</button>}
      />
      <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
        <div className="toolbar">
          <div className="field" style={{ flex: '1 1 260px', maxWidth: 360 }}>
            <label htmlFor="prod-q">Search</label>
            <input id="prod-q" className="input" type="search" placeholder="Name, brand, SKU or barcode" value={qs} onChange={(e) => setQs(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="prod-cat">Category</label>
            <select id="prod-cat" className="select" value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="">All categories</option>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="prod-status">Status</label>
            <select id="prod-status" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">Any status</option>
              <option value="ACTIVE">Active</option>
              <option value="DISCONTINUED">Discontinued</option>
            </select>
          </div>
          {(qs || category || status) && <button type="button" className="btn ghost" onClick={() => { setQs(''); setCategory(''); setStatus(''); }}>Clear filters</button>}
        </div>
        <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No products match" emptyText="Try clearing a filter or searching by SKU or barcode.">
          {() => (
            <DataTable<Product>
              caption="Products"
              rows={rows}
              rowKey={(p) => p.id}
              columns={cols}
              pageSize={25}
              total={asTotal(q.data)}
              selectedKey={sel || null}
              onRowClick={(p) => setSel(p.id)}
              initialSort={{ key: 'id', dir: 'asc' }}
            />
          )}
        </QueryBoundary>
      </Card>
      <div className="mt"><Callout tone="info"><span>Prices on this screen are listed per whole unit. For stock levels see <Link to="/inventory">Inventory</Link>; for the full price book see <Link to="/prices">Prices</Link>.</span></Callout></div>
      {sel && <ProductDrawer id={sel} onClose={() => setSel(null)} />}
    </div>
  );
}

