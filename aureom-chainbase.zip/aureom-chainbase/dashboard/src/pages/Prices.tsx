import { useMemo, useState } from 'react';
import { useApi } from '../api/hooks';
import { asItems, metaOf } from '../api/client';
import type { ListResponse, PriceRecord, Promotion } from '../api/types';
import { useLocations, useSkus } from '../api/refdata';
import { formatBp, formatMoney, formatTime, humanize } from '../lib/format';
import { promoSummary } from '../lib/labels';
import { useParam } from '../lib/hooks';
import { groupBy } from '../lib/normalize';
import { Callout, Card, PageHeader, Section } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Drawer } from '../ui/Drawer';
import { TabPanel, Tabs } from '../ui/Tabs';
import { ChainLink, TxLink } from '../ui/misc';
import { QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';

interface BookRow {
  key: string;
  sku: string;
  loc: string;
  current?: PriceRecord;
  previous?: PriceRecord;
  upcoming?: PriceRecord;
  history: PriceRecord[];
}

const priceActive = (p: PriceRecord, now: number) => p.effective_from_ms <= now && (!p.effective_to_ms || p.effective_to_ms > now);

export function buildBook(prices: PriceRecord[], now = Date.now()): BookRow[] {
  const groups = groupBy(prices, (p) => `${p.sku}@${p.loc}`);
  return Object.entries(groups).map(([key, list]) => {
    const history = [...list].sort((a, b) => b.seq - a.seq || b.effective_from_ms - a.effective_from_ms);
    const active = history.filter((p) => priceActive(p, now));
    const current = active.sort((a, b) => b.seq - a.seq)[0];
    const upcoming = history.filter((p) => p.effective_from_ms > now).sort((a, b) => a.effective_from_ms - b.effective_from_ms)[0];
    const previous = history.filter((p) => p !== current && p.effective_from_ms <= now).sort((a, b) => b.effective_from_ms - a.effective_from_ms)[0];
    return { key, sku: list[0].sku, loc: list[0].loc, current, previous, upcoming, history };
  });
}

const locName = (loc: string) => (loc === '*' ? 'All locations' : loc);

function PriceHistoryDrawer({ row, units, onClose }: { row: BookRow; units: ReturnType<typeof useSkus>; onClose: () => void }) {
  return (
    <Drawer title={units.nameOf(row.sku) ?? row.sku} subtitle={<span className="mono">{row.sku} · {locName(row.loc)}</span>} onClose={onClose} actions={<ChainLink stateKey={`pbook/${row.sku}/${row.loc}`} />}>
      <Section title="Publication history">
        <p className="muted">Each publication adds a new price with its own effective window. Prices are never edited in place; the latest publication active at the time of sale applies.</p>
        <div className="card"><table className="dt compact">
          <caption className="sr-only">Price publications</caption>
          <thead><tr><th className="num">#</th><th className="num">Unit price</th><th>Effective from</th><th>Until</th><th>Published</th></tr></thead>
          <tbody>{row.history.map((p) => (
            <tr key={p.id} className={p === row.current ? 'selected' : undefined}>
              <td className="num">{p.seq}</td><td className="num"><b>{formatMoney(p.unit_minor, p.currency)}</b></td>
              <td>{formatTime(p.effective_from_ms, { seconds: false })}</td>
              <td>{p.effective_to_ms ? formatTime(p.effective_to_ms, { seconds: false }) : <span className="muted">open-ended</span>}</td>
              <td>{p === row.current ? <Chip tone="ok" dot>Current</Chip> : p.effective_from_ms > Date.now() ? <Chip tone="info" dot>Scheduled</Chip> : <span className="muted">Superseded</span>} {p.created_tx && <TxLink id={p.created_tx} />}</td>
            </tr>
          ))}</tbody>
        </table></div>
      </Section>
    </Drawer>
  );
}

function PriceBook({ prices, units, locs }: { prices: PriceRecord[]; units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [skuQ, setSkuQ] = useState('');
  const [loc, setLoc] = useParam('ploc');
  const [sel, setSel] = useParam('book');
  const book = useMemo(() => buildBook(prices).filter((r) => (!loc || r.loc === loc || r.loc === '*') && (!skuQ || `${r.sku} ${units.nameOf(r.sku) ?? ''}`.toLowerCase().includes(skuQ.toLowerCase()))), [prices, loc, skuQ, units]);
  const open = book.find((r) => r.key === sel);
  const cols: Column<BookRow>[] = [
    { key: 'sku', header: 'SKU', mono: true, sortValue: (r) => r.sku, render: (r) => r.sku },
    { key: 'name', header: 'Product', sortValue: (r) => units.nameOf(r.sku), render: (r) => units.nameOf(r.sku) ?? '–' },
    { key: 'loc', header: 'Applies to', sortValue: (r) => r.loc, render: (r) => (r.loc === '*' ? <Chip tone="neutral" square>All locations</Chip> : <span title={locs.nameOf(r.loc)}>{r.loc}</span>) },
    { key: 'cur', header: 'Current price', align: 'right', sortValue: (r) => r.current?.unit_minor, render: (r) => (r.current ? <b>{formatMoney(r.current.unit_minor, r.current.currency)}<span className="muted"> / {units.unitOf(r.sku) === 'EA' ? 'each' : units.unitOf(r.sku).toLowerCase()}</span></b> : <Chip tone="warn">No active price</Chip>) },
    { key: 'since', header: 'Effective since', render: (r) => (r.current ? formatTime(r.current.effective_from_ms, { seconds: false }) : '–') },
    { key: 'prev', header: 'Previous', align: 'right', render: (r) => (r.previous ? <span className="muted">{formatMoney(r.previous.unit_minor, r.previous.currency)}{r.current && r.previous.unit_minor !== r.current.unit_minor && <span style={{ color: r.current.unit_minor > r.previous.unit_minor ? 'var(--bad-fg)' : 'var(--ok-fg)' }}> {r.current.unit_minor > r.previous.unit_minor ? '▲' : '▼'}</span>}</span> : '–') },
    { key: 'next', header: 'Scheduled change', render: (r) => (r.upcoming ? <span>{formatMoney(r.upcoming.unit_minor, r.upcoming.currency)} <span className="muted">from {formatTime(r.upcoming.effective_from_ms, { seconds: false })}</span></span> : <span className="muted">–</span>) },
    { key: 'n', header: 'Publications', align: 'right', sortValue: (r) => r.history.length, render: (r) => r.history.length },
  ];
  return (
    <>
      <Card flush>
        <div className="toolbar">
          <div className="field" style={{ width: 240 }}><label htmlFor="pb-sku">SKU or product</label><input id="pb-sku" className="input" type="search" value={skuQ} onChange={(e) => setSkuQ(e.target.value)} placeholder="Search…" /></div>
          <div className="field"><label htmlFor="pb-loc">Location</label>
            <select id="pb-loc" className="select" value={loc} onChange={(e) => setLoc(e.target.value)}><option value="">All locations</option>{locs.locations.map((l) => <option key={l.id} value={l.id}>{l.id} · {l.name}</option>)}</select></div>
        </div>
        {book.length === 0 ? <div className="state">No prices match.</div> : <DataTable<BookRow> caption="Price book" rows={book} rowKey={(r) => r.key} columns={cols} pageSize={25} initialSort={{ key: 'sku', dir: 'asc' }} onRowClick={(r) => setSel(r.key)} selectedKey={sel || null} />}
      </Card>
      <div className="mt"><Callout tone="info">A price with location “All locations” applies everywhere unless a location-specific price is published for that SKU. Prices are per whole unit (for example per kg).</Callout></div>
      {open && <PriceHistoryDrawer row={open} units={units} onClose={() => setSel(null)} />}
    </>
  );
}

function History({ prices, units }: { prices: PriceRecord[]; units: ReturnType<typeof useSkus> }) {
  return (
    <Card flush>
      <DataTable<PriceRecord> caption="Price publication history" rows={prices} rowKey={(p) => p.id} pageSize={25} initialSort={{ key: 'seq', dir: 'desc' }}
        quickFilter={(p, t) => `${p.sku} ${p.loc} ${p.id}`.toLowerCase().includes(t)}
        columns={[
          { key: 'seq', header: 'Seq', align: 'right', sortValue: (p) => p.seq, render: (p) => p.seq },
          { key: 'id', header: 'Price entry', mono: true, render: (p) => p.id },
          { key: 'sku', header: 'SKU', mono: true, sortValue: (p) => p.sku, render: (p) => <span title={units.nameOf(p.sku)}>{p.sku}</span> },
          { key: 'loc', header: 'Location', sortValue: (p) => p.loc, render: (p) => locName(p.loc) },
          { key: 'u', header: 'Unit price', align: 'right', sortValue: (p) => p.unit_minor, render: (p) => <b>{formatMoney(p.unit_minor, p.currency)}</b> },
          { key: 'f', header: 'Effective from', sortValue: (p) => p.effective_from_ms, render: (p) => formatTime(p.effective_from_ms, { seconds: false }) },
          { key: 't', header: 'Until', render: (p) => (p.effective_to_ms ? formatTime(p.effective_to_ms, { seconds: false }) : <span className="muted">open-ended</span>) },
          { key: 'tx', header: 'Published by transaction', render: (p) => <TxLink id={p.created_tx} /> },
          { key: 'v', header: 'Version', align: 'right', render: (p) => (p.version !== undefined ? `v${p.version}` : '–') },
        ]}
      />
    </Card>
  );
}

export function promoState(p: Promotion, now = Date.now()): { label: string; tone: 'ok' | 'info' | 'neutral' | 'warn' } {
  if (p.status === 'ENDED') return { label: 'Ended', tone: 'neutral' };
  if (p.from_ms > now) return { label: 'Scheduled', tone: 'info' };
  if (p.to_ms && p.to_ms < now) return { label: 'Expired', tone: 'neutral' };
  return { label: 'Running', tone: 'ok' };
}

function Promotions({ locs }: { locs: ReturnType<typeof useLocations> }) {
  const [status, setStatus] = useParam('pstatus');
  const q = useApi<ListResponse<Promotion>>('/q/promotions', { status, limit: 500 }, { keep: true });
  const rows = asItems<Promotion>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="pr-st">Status</label>
          <select id="pr-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Any status</option><option value="ACTIVE">Active</option><option value="ENDED">Ended</option></select></div>
        <span className="muted" style={{ alignSelf: 'center' }}>Promotions are evaluated in priority order (lower number first). Non-stackable promotions stop later ones applying to the same item.</span>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No promotions" emptyText="No promotions match.">
        {() => (
          <DataTable<Promotion> caption="Promotions" rows={rows} rowKey={(p) => p.id} pageSize={25} initialSort={{ key: 'prio', dir: 'asc' }}
            columns={[
              { key: 'name', header: 'Promotion', sortValue: (p) => p.name, render: (p) => <div><b>{p.name}</b><div className="muted mono">{p.id}</div></div> },
              { key: 'offer', header: 'Offer', render: (p) => <div>{promoSummary(p, formatMoney, formatBp)}<div className="muted">{humanize(p.type)}</div></div> },
              { key: 'prio', header: 'Priority', align: 'right', sortValue: (p) => p.priority, render: (p) => p.priority },
              { key: 'stack', header: 'Stackable', render: (p) => (p.stackable ? <Chip tone="ok" square>Stackable</Chip> : <Chip tone="neutral" square>Exclusive</Chip>) },
              { key: 'loy', header: 'Audience', render: (p) => (p.loyalty_only ? <Chip tone="accent" square>Loyalty members</Chip> : 'Everyone') },
              { key: 'win', header: 'Active window', sortValue: (p) => p.from_ms, render: (p) => <span>{formatTime(p.from_ms, { seconds: false })}<br /><span className="muted">to {p.to_ms ? formatTime(p.to_ms, { seconds: false }) : 'no end date'}</span></span> },
              { key: 'scope', header: 'Applies to', render: (p) => <span title={p.skus.join(', ')}>{p.skus.length} SKU{p.skus.length === 1 ? '' : 's'}<br /><span className="muted" title={p.locs.join(', ')}>{p.locs.includes('*') ? 'all locations' : p.locs.length === 1 ? (locs.nameOf(p.locs[0]) ?? p.locs[0]) : `${p.locs.length} locations`}</span></span> },
              { key: 'st', header: 'Status', sortValue: (p) => p.status, render: (p) => { const s = promoState(p); return <span className="row" style={{ gap: 6 }}><StatusChip value={p.status} />{s.label !== (p.status === 'ENDED' ? 'Ended' : 'Running') && <Chip tone={s.tone}>{s.label}</Chip>}</span>; } },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

export default function Prices() {
  const [tab, setTab] = useParam('tab', 'book');
  const units = useSkus();
  const locs = useLocations();
  const q = useApi<ListResponse<PriceRecord>>('/q/prices', { limit: 500 });
  const prices = asItems<PriceRecord>(q.data);
  return (
    <div className="page">
      <PageHeader title="Prices" subtitle="Price book per SKU and location, how prices were published over time, and promotions." />
      <Tabs label="Pricing views" value={tab} onChange={setTab} items={[{ id: 'book', label: 'Price book' }, { id: 'history', label: 'Publication history' }, { id: 'promos', label: 'Promotions' }]} />
      {tab !== 'promos' && (
        <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No prices published" emptyText="No prices have been published yet.">
          {() => (
            <>
              <TabPanel id="book" active={tab === 'book'}><PriceBook prices={prices} units={units} locs={locs} /></TabPanel>
              <TabPanel id="history" active={tab === 'history'}><History prices={prices} units={units} /></TabPanel>
              <div className="mt"><Staleness meta={metaOf(q.data)} /></div>
            </>
          )}
        </QueryBoundary>
      )}
      <TabPanel id="promos" active={tab === 'promos'}><Promotions locs={locs} /></TabPanel>
    </div>
  );
}
