import { Link, useNavigate } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { metaOf } from '../api/client';
import type { BlockSummary, NetworkInfo, ValidatorInfo } from '../api/types';
import { useChainStatus } from '../api/chainStatus';
import { normalizeGovernance } from '../lib/normalize';
import { bftMath, formatDuration, formatInt, formatTime, healthTone, parseTimeString, shortHash, timeAgo } from '../lib/format';
import { Callout, Card, Kpi, PageHeader } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Hash } from '../ui/misc';
import { ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconInfo, IconRefresh } from '../ui/icons';
import { LagChip } from '../layout/Shell';

/** How many validators can still fail while the online power stays >= quorum. */
export function spareValidators(validators: Pick<ValidatorInfo, 'voting_power' | 'reachable'>[], quorum: number): number {
  const online = validators.filter((v) => v.reachable).map((v) => v.voting_power).sort((a, b) => b - a);
  let power = online.reduce((a, b) => a + b, 0);
  if (power < quorum) return -1;
  let k = 0;
  for (const p of online) {
    if (power - p >= quorum) {
      power -= p;
      k++;
    } else break;
  }
  return k;
}

export function QuorumExplainer({ net }: { net: NetworkInfo }) {
  const vals = net.validators ?? [];
  const m = bftMath(vals.map((v) => v.voting_power));
  const total = net.bft.voting_power_total || m.total;
  const quorum = net.bft.quorum_power_required || m.quorum;
  const f = net.bft.f ?? m.f;
  const online = net.bft.online_power;
  const n = net.bft.validators || m.n;
  const spare = spareValidators(vals, quorum);
  const sorted = [...vals].sort((a, b) => Number(b.reachable) - Number(a.reachable));
  const status = net.bft.status;
  return (
    <Card title="How the network agrees (BFT quorum)" sub="Byzantine fault tolerant consensus: why one bad validator cannot corrupt the record">
      <div className="grid cols-12" style={{ alignItems: 'start' }}>
        <dl className="kv" style={{ gridTemplateColumns: 'minmax(120px,170px) minmax(0,1fr)' }}>
          <dt>Validators (n)</dt><dd><b>{n}</b>, run by independent organisations</dd>
          <dt>Total voting power</dt><dd><b>{total}</b></dd>
          <dt>Tolerated faults (f)</dt><dd><b>{f}</b> <span className="muted">= ⌊(n − 1) / 3⌋</span></dd>
          <dt>Quorum required</dt><dd><b>{quorum}</b> <span className="muted">more than ⅔ of {total}</span></dd>
          <dt>Online power</dt><dd><b>{online}</b> of {total} ({net.bft.online_validators}/{n} validators)</dd>
          <dt>Spare validators</dt><dd>{spare < 0 ? <Chip tone="bad" dot>Below quorum: chain halted</Chip> : <span><b>{spare}</b> <span className="muted">can fail before the chain halts</span></span>}</dd>
          <dt>Status</dt><dd><Chip tone={healthTone(status)} dot>{status}</Chip></dd>
        </dl>
        <div>
          <div className="field-label">Voting power online vs quorum</div>
          <div className="powerbar" role="img" aria-label={`Online voting power ${online} of ${total}; quorum requires ${quorum}`}>
            {sorted.map((v) => (
              <div key={v.name} className={`seg-v ${v.reachable ? 'on' : 'off'}`} style={{ flex: v.voting_power }} title={`${v.name}: ${v.voting_power} power, ${v.reachable ? 'online' : 'offline'}`}>
                {v.name}
              </div>
            ))}
            <div className="quorum-mark" style={{ left: `${(quorum / total) * 100}%` }}><span>quorum {quorum}</span></div>
          </div>
          <div className="muted" style={{ fontSize: 11.5 }}>Each block needs signatures from validators holding at least the quorum marker’s worth of power.</div>
        </div>
      </div>
      <div className="divider" />
      <div className="grid cols-3">
        <Callout tone="ok" icon={<IconInfo />}>
          <strong>What is tolerated.</strong> Up to {f} validator{f === 1 ? '' : 's'} may fail or even be malicious (send conflicting or invalid messages). The remaining validators still finalise blocks correctly.
        </Callout>
        <Callout tone="warn" icon={<IconInfo />}>
          <strong>What stops the chain.</strong> If {f + 1} or more validators are down, fewer than {quorum} power remains and the chain halts: no transaction finalises until enough validators return.
        </Callout>
        <Callout tone="info" icon={<IconInfo />}>
          <strong>It halts, it does not fork.</strong> Without a quorum nothing new can be committed, so there is never a second, conflicting history. Committed data stays valid and readable.
        </Callout>
      </div>
      {net.bft.explanation && <p className="muted" style={{ marginTop: 10 }}>Gateway assessment: {net.bft.explanation}</p>}
    </Card>
  );
}

function ValidatorsTable({ net }: { net: NetworkInfo }) {
  const head = net.chain.latest_height;
  const cols: Column<ValidatorInfo>[] = [
    { key: 'name', header: 'Validator', sortValue: (v) => v.name, render: (v) => (<div><b>{v.name}</b><div className="muted">{v.org}</div></div>) },
    { key: 'role', header: 'Role', sortValue: (v) => v.role, render: (v) => <Chip tone="info" square>{v.role}</Chip> },
    { key: 'reach', header: 'Reachable', sortValue: (v) => Number(v.reachable), render: (v) => <Chip tone={v.reachable ? 'ok' : 'bad'} dot>{v.reachable ? 'Online' : 'Offline'}</Chip> },
    { key: 'height', header: 'Height', align: 'right', sortValue: (v) => v.height, render: (v) => (v.reachable ? formatInt(v.height) : <span className="muted">–</span>) },
    { key: 'catch', header: 'Catching up', render: (v) => (v.reachable ? <Chip tone={v.catching_up ? 'warn' : 'neutral'}>{v.catching_up ? 'Yes' : 'No'}</Chip> : <span className="muted">–</span>) },
    { key: 'peers', header: 'Peers', align: 'right', sortValue: (v) => v.peers, render: (v) => (v.reachable ? v.peers : '–') },
    { key: 'lat', header: 'Latency', align: 'right', sortValue: (v) => v.latency_ms, render: (v) => (v.reachable ? formatDuration(v.latency_ms) : '–') },
    { key: 'power', header: 'Voting power', align: 'right', sortValue: (v) => v.voting_power, render: (v) => v.voting_power },
    { key: 'signed', header: 'Last signed', align: 'right', tip: 'Latest block this validator signed. A validator that stops signing falls behind the chain head.', sortValue: (v) => v.last_signed_height, render: (v) => (!v.last_signed_height ? <span className="muted" title="This validator is not among the signatures of the latest commit (a commit needs only more than two thirds)">not in latest commit</span> : <span>{formatInt(v.last_signed_height)}{head - v.last_signed_height > 2 && <span className="muted"> (−{head - v.last_signed_height})</span>}</span>) },
    { key: 'agree', header: 'Agrees with majority', tip: 'Whether this validator’s application state hash matches what most validators report at the same height. A mismatch would indicate divergent state.', render: (v) => (v.reachable ? <Chip tone={v.agrees_with_majority ? 'ok' : 'bad'} dot>{v.agrees_with_majority ? 'Agrees' : 'Diverges'}</Chip> : <span className="muted">–</span>) },
    { key: 'node', header: 'Node ID', mono: true, render: (v) => <span title={v.node_id}>{shortHash(v.node_id, 6)}</span> },
  ];
  return (
    <Card title="Validators" sub="Four independent organisations each operate one validator node" flush foot={<span className="meta-note">queried {net.queried_at ? timeAgo(parseTimeString(net.queried_at)) : '–'} · chain head {formatInt(head)}</span>}>
      <DataTable caption="Validators" rows={net.validators ?? []} rowKey={(v) => v.name} columns={cols} pageSize={10} />
    </Card>
  );
}

type BlocksQ = ReturnType<typeof useApi<BlockSummary[] | { items: BlockSummary[] }>>;

/** Average seconds between consecutive blocks, from block timestamps (the network view carries no interval). */
export function avgBlockInterval(blocks: Pick<BlockSummary, 'time'>[]): number | undefined {
  const ts = blocks.map((b) => parseTimeString(b.time)).filter((t) => t > 0).sort((a, b) => a - b);
  if (ts.length < 2) return undefined;
  return (ts[ts.length - 1] - ts[0]) / (ts.length - 1);
}

function RecentBlocks({ q, rows }: { q: BlocksQ; rows: BlockSummary[] }) {
  const nav = useNavigate();
  return (
    <Card title="Recent blocks" sub="Newest first; click a row to open it in the Explorer" flush actions={<Link to="/explorer">All blocks</Link>}>
      <QueryBoundary q={q} isEmpty={() => rows.length === 0} emptyTitle="No blocks yet">
        {() => (
          <DataTable<BlockSummary>
            caption="Recent blocks"
            rows={rows}
            rowKey={(b) => String(b.height)}
            pageSize={12}
            columns={[
              { key: 'h', header: 'Height', align: 'right', sortValue: (b) => b.height, render: (b) => <Link to={`/explorer/block/${b.height}`}>{formatInt(b.height)}</Link> },
              { key: 't', header: 'Time', render: (b) => <span title={b.time}>{formatTime(parseTimeString(b.time))}</span> },
              { key: 'tx', header: 'Txs', align: 'right', render: (b) => b.num_txs },
              { key: 'rej', header: 'Rejected', align: 'right', render: (b) => (b.num_rejected ? <Chip tone="bad">{b.num_rejected}</Chip> : <span className="muted">0</span>) },
              { key: 'p', header: 'Proposer', render: (b) => b.proposer },
              { key: 'hash', header: 'Block hash', mono: true, render: (b) => <span title={b.hash}>{shortHash(b.hash, 10)}</span> },
              { key: 'ah', header: 'App hash', mono: true, render: (b) => <span title={b.app_hash}>{shortHash(b.app_hash, 8)}</span> },
              { key: 'sz', header: 'Size', align: 'right', render: (b) => `${(b.size_bytes / 1024).toFixed(1)} KB` },
            ]}
            onRowClick={(b) => nav(`/explorer/block/${b.height}`)}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function UpgradeCard({ head, version }: { head: number | null; version: number | null }) {
  const q = useApi<unknown>('/q/governance', undefined, { poll: 10_000 });
  const g = normalizeGovernance(q.data);
  const sorted = [...g.upgrades].sort((a, b) => a.version - b.version);
  return (
    <Card title="State machine version and upgrades" sub="The business rules the validators execute" flush foot={<Staleness meta={g.meta ?? metaOf(q.data)} />}>
      <div className="card-body" style={{ paddingBottom: 10 }}>
        <div className="row"><span className="muted">Active version</span> <Chip tone="ok" dot lg>v{version ?? '–'}</Chip></div>
        <p className="muted" style={{ margin: '8px 0 0' }}>Upgrades are scheduled through governance and activate at a fixed block height on every validator at once.</p>
      </div>
      {q.isPending ? <LoadingBlock rows={2} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : sorted.length === 0 ? (
        <div className="state">No upgrades recorded.</div>
      ) : (
        <div className="table-wrap">
          <table className="dt compact">
            <caption className="sr-only">Scheduled upgrades</caption>
            <thead><tr><th>Version</th><th>Status</th><th className="num">At height</th><th className="num">Blocks to go</th></tr></thead>
            <tbody>
              {sorted.map((u) => (
                <tr key={u.version}>
                  <td><b>v{u.version}</b></td>
                  <td><StatusChip value={u.status} /></td>
                  <td className="num">{formatInt(u.activation_height)}</td>
                  <td className="num">{head !== null && u.activation_height > head ? formatInt(u.activation_height - head) : <span className="muted">–</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

export default function Network() {
  const s = useChainStatus();
  const net = s.network;
  const blocksQ = useApi<BlockSummary[] | { items: BlockSummary[] }>('/explorer/blocks', { limit: 12 }, { poll: 3000 });
  const blockRows = Array.isArray(blocksQ.data) ? blocksQ.data : blocksQ.data?.items ?? [];
  const interval = net?.chain.block_interval_ms_avg ?? avgBlockInterval(blockRows);
  return (
    <div className="page">
      <PageHeader
        title="Network"
        subtitle="Consensus health, validators and finality. This is the only place (besides the Explorer) where blockchain diagnostics are shown."
        actions={<button type="button" className="btn" onClick={s.refresh}><IconRefresh /> Refresh</button>}
      />
      {!net ? (
        <Card>{s.reachable && !s.error ? <LoadingBlock rows={6} label="Loading network status…" /> : <ErrorState error={{ message: s.error ?? 'No data', unreachable: !s.reachable }} onRetry={s.refresh} title="Network status unavailable" />}</Card>
      ) : (
        <>
          <div className="grid kpis mb">
            <Kpi label="Network health" value={<Chip tone={healthTone(net.bft.status)} dot lg>{net.bft.status}</Chip>} note={`${net.bft.online_validators} of ${net.bft.validators} validators online`} />
            <Kpi label="Finalised height" value={formatInt(net.chain.latest_height)} note={`block time ${formatTime(parseTimeString(net.chain.latest_block_time))}`} />
            <Kpi label="Block interval (avg)" value={interval === undefined ? '–' : formatDuration(interval)} note="Time between finalised blocks" />
            <Kpi label="Mempool" value={formatInt(net.mempool?.unconfirmed_txs ?? 0)} note="Transactions waiting for a block" tone={(net.mempool?.unconfirmed_txs ?? 0) > 50 ? 'warn' : undefined} />
            <Kpi label="Query index lag" value={<LagChip lag={s.lag} state={s.projectionState} />} note={`indexed ${formatInt(s.indexed ?? 0)} of ${formatInt(s.head ?? 0)}`} />
            <Kpi label="State machine" value={`v${net.app_version}`} note={net.network_id} />
          </div>
          <div className="mb"><QuorumExplainer net={net} /></div>
          <div className="mb"><ValidatorsTable net={net} /></div>
          <div className="grid cols-21 mb">
            <RecentBlocks q={blocksQ} rows={blockRows} />
            <div className="stack">
              <UpgradeCard head={s.head} version={s.appVersion} />
              <Card title="Latest application state hash" sub="Fingerprint of all business data at the chain head">
                <Hash value={net.chain.latest_app_hash} />
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
