import { Link } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems, asTotal, metaOf } from '../api/client';
import type { InventoryException, ExceptionRec, LatencyMetrics, ListResponse, MigrationState, ReportListRow, TxRow } from '../api/types';
import { useChainStatus } from '../api/chainStatus';
import { normalizeStats, txIdOf } from '../lib/normalize';
import { formatDuration, formatInt, formatMoney, formatTime, humanize, parseTimeString, timeAgo, txTypeLabel } from '../lib/format';
import { Card, Kpi, PageHeader } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import type { Column } from '../ui/DataTable';
import { EmptyState, ErrorState, LoadingBlock, QueryBoundary } from '../ui/States';
import { GroupedBars, Sparkline } from '../ui/Charts';
import { Staleness } from '../ui/Meta';
import { Tip } from '../ui/Tip';
import { IconRefresh } from '../ui/icons';

const POLL = 5000;

function RecentTx() {
  const q = useApi<ListResponse<TxRow>>('/q/transactions', { status: 'OK', limit: 10 }, { poll: POLL });
  const cols: Column<TxRow>[] = [
    { key: 'time', header: 'Recorded', render: (t) => <span title={formatTime(t.block_time_ms)}>{timeAgo(t.block_time_ms)}</span> },
    { key: 'type', header: 'Transaction', render: (t) => txTypeLabel(t.type) },
    { key: 'signer', header: 'Signed by', render: (t) => <span className="mono">{t.signer}</span> },
    { key: 'result', header: 'Result', render: (t) => <StatusChip value={t.status} /> },
    { key: 'id', header: 'Reference', render: (t) => <Link className="mono" to={`/explorer/tx/${encodeURIComponent(txIdOf(t))}`}>{txIdOf(t)}</Link> },
  ];
  return (
    <Card title="Recent finalised transactions" sub="Latest business activity recorded on the ledger" flush foot={<Staleness meta={metaOf(q.data)} />}>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No finalised transactions yet">
        {(d) => (
          <div className="table-wrap">
            <table className="dt compact">
              <caption className="sr-only">Recent finalised transactions</caption>
              <thead><tr>{cols.map((c) => <th key={c.key}>{c.header}</th>)}</tr></thead>
              <tbody>
                {asItems<TxRow>(d).map((t) => (
                  <tr key={txIdOf(t)}>{cols.map((c) => <td key={c.key} className={c.mono ? 'mono' : undefined}>{c.render(t)}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </QueryBoundary>
    </Card>
  );
}

function RejectedTx() {
  const q = useApi<ListResponse<TxRow>>('/q/transactions', { status: 'REJECTED', limit: 8 }, { poll: POLL });
  return (
    <Card
      title="Rejected transactions"
      sub="Ordered by the network but refused by the business rules. No data changed."
      flush
      actions={<Link to="/explorer" className="muted">Investigate in Explorer</Link>}
      foot={<Staleness meta={metaOf(q.data)} />}
    >
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No rejected transactions" emptyText="Every recorded transaction was accepted.">
        {(d) => (
          <div className="table-wrap">
            <table className="dt compact">
              <caption className="sr-only">Rejected transactions</caption>
              <thead><tr><th>Recorded</th><th>Reason</th><th>Code name</th><th>Signed by</th></tr></thead>
              <tbody>
                {asItems<TxRow>(d).map((t) => (
                  <tr key={txIdOf(t)} className="row-bad">
                    <td className="nowrap" title={formatTime(t.block_time_ms)}>{timeAgo(t.block_time_ms)}</td>
                    <td className="wrap" style={{ whiteSpace: 'normal', minWidth: 180 }}>
                      <div>{txTypeLabel(t.type)}</div>
                      <div className="muted">{t.reason || '–'}</div>
                    </td>
                    <td className="nowrap"><Chip tone="bad" square title={`Result code ${t.code}`}>{t.code_name}</Chip></td>
                    <td className="mono">{t.signer}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </QueryBoundary>
    </Card>
  );
}

function Latency() {
  const q = useApi<LatencyMetrics>('/metrics/latency', undefined, { poll: POLL });
  return (
    <Card
      title="Submission and finalisation latency"
      sub="Transactions submitted through this gateway"
      actions={<Tip label="About latency" align="right">Submission = time until a validator accepted the transaction into its waiting queue (not yet final). Finalisation = time until the transaction was included in a block that more than two-thirds of voting power signed. Percentiles: p50 is the typical case, p95/p99 the slow tail.</Tip>}
    >
      <QueryBoundary q={q} isEmpty={(d) => !d || !d.count} emptyTitle="No latency samples yet" emptyText="Submit a transaction through the gateway to populate this panel.">
        {(d) => {
          const recent = [...(d.recent ?? [])].sort((a, b) => (typeof a.at === 'number' ? a.at : parseTimeString(String(a.at))) - (typeof b.at === 'number' ? b.at : parseTimeString(String(b.at))));
          return (
            <div className="grid cols-2">
              <div>
                <GroupedBars
                  ariaLabel="Latency percentiles: submission versus finalisation"
                  format={(v) => formatDuration(v)}
                  series={[{ name: 'Submission', color: 'var(--series-1)' }, { name: 'Finalisation', color: 'var(--series-2)' }]}
                  groups={(['p50', 'p95', 'p99'] as const).map((p) => ({
                    label: p,
                    values: [{ series: 'Submission', value: d.admission_ms?.[p] ?? 0 }, { series: 'Finalisation', value: d.finality_ms?.[p] ?? 0 }],
                  }))}
                />
              </div>
              <div className="stack-sm">
                <div className="field-label">Finalisation, most recent {recent.length} transactions</div>
                <Sparkline values={recent.map((r) => r.finality_ms)} ariaLabel="Finalisation latency of recent transactions" color="var(--series-2)" />
                <div className="row wrap" style={{ gap: 16 }}>
                  <div><div className="muted">Samples</div><b>{formatInt(d.count)}</b></div>
                  <div><div className="muted">Slowest submission</div><b>{formatDuration(d.admission_ms?.max)}</b></div>
                  <div><div className="muted">Slowest finalisation</div><b>{formatDuration(d.finality_ms?.max)}</b></div>
                </div>
              </div>
            </div>
          );
        }}
      </QueryBoundary>
    </Card>
  );
}

function Exceptions() {
  const inv = useApi<ListResponse<InventoryException>>('/q/inventory/exceptions', { limit: 6 }, { poll: POLL });
  const exc = useApi<ListResponse<ExceptionRec>>('/q/exceptions', { status: 'OPEN', limit: 6 }, { poll: POLL });
  const invItems = asItems<InventoryException>(inv.data);
  const excItems = asItems<ExceptionRec>(exc.data).filter((e) => !invItems.some((i) => i.ref === e.ref));
  return (
    <Card title="Open exceptions" sub="Items that need a person to look at them" flush foot={<Staleness meta={metaOf(exc.data) ?? metaOf(inv.data)} />}>
      {(inv.isPending || exc.isPending) && <LoadingBlock rows={4} />}
      {inv.isError && !inv.data && <ErrorState error={inv.error} onRetry={() => void inv.refetch()} title="Inventory exceptions unavailable" />}
      {exc.isError && !exc.data && <ErrorState error={exc.error} onRetry={() => void exc.refetch()} title="Business exceptions unavailable" />}
      {inv.data && exc.data && invItems.length + excItems.length === 0 && <EmptyState title="No open exceptions" />}
      {inv.data && exc.data && invItems.length + excItems.length > 0 && (
        <div className="table-wrap">
          <table className="dt compact">
            <caption className="sr-only">Open exceptions</caption>
            <thead><tr><th>Area</th><th>Type</th><th>Reference</th><th>Detail</th></tr></thead>
            <tbody>
              {invItems.map((e, i) => (
                <tr key={`i${i}`}>
                  <td><Link to="/inventory?tab=exceptions">Inventory</Link></td>
                  <td><div className="row" style={{ gap: 6 }}><StatusChip value={e.severity} dot={false} /> {humanize(e.kind)}</div></td>
                  <td className="mono">{e.ref}</td>
                  <td style={{ whiteSpace: 'normal' }}>{e.detail}</td>
                </tr>
              ))}
              {excItems.map((e) => (
                <tr key={e.id}>
                  <td>Operations</td>
                  <td>{humanize(e.kind)}</td>
                  <td className="mono">{e.ref}</td>
                  <td style={{ whiteSpace: 'normal' }}>{e.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

function MigrationCard() {
  const st = useApi<{ meta?: unknown; state?: MigrationState; item?: { state?: MigrationState } } & Partial<MigrationState>>('/q/migration', undefined, { poll: POLL * 3 });
  const rep = useApi<ReportListRow[] | { items?: ReportListRow[] }>('/migration/reports', undefined, { poll: POLL * 3 });
  const state = st.data?.state ?? st.data?.item?.state ?? (st.data as MigrationState | undefined);
  const reports = asItems<ReportListRow>(rep.data).sort((a, b) => parseTimeString(b.generated_at) - parseTimeString(a.generated_at));
  const latest = reports[0];
  return (
    <Card title="Migration" sub="Legacy system cut-over" actions={<Link to="/migration">Open</Link>}>
      {st.isPending ? <LoadingBlock rows={3} /> : st.isError && !st.data ? <ErrorState error={st.error} onRetry={() => void st.refetch()} /> : (
        <div className="stack-sm">
          <div className="row wrap">
            <span className="muted">Import window</span>
            <StatusChip value={state?.status} lg />
            {state?.source_system && <span className="muted">from {state.source_system}</span>}
          </div>
          {latest ? (
            <div className="row wrap">
              <span className="muted">Latest report</span>
              <Link to={`/migration/reports/${encodeURIComponent(latest.id)}`} className="mono">{latest.id}</Link>
              <Chip tone={latest.trial ? 'warn' : 'info'} square>{latest.trial ? 'TRIAL' : 'PRODUCTION'}</Chip>
              <StatusChip value={latest.decision} />
            </div>
          ) : rep.isError ? <span className="muted">Reports unavailable</span> : <span className="muted">No reconciliation reports yet.</span>}
        </div>
      )}
    </Card>
  );
}

export default function Overview() {
  const chain = useChainStatus();
  const stats = useApi<unknown>('/q/stats', undefined, { poll: POLL });
  const s = normalizeStats(stats.data);
  const val = (n: number | undefined) => (stats.isPending ? '…' : n === undefined ? '–' : formatInt(n));
  const net = chain.network;
  const rejectedList = useApi<ListResponse<TxRow>>('/q/transactions', { status: 'REJECTED', limit: 1 }, { poll: POLL });
  const rejected = s.rejected24h ?? (rejectedList.data ? asTotal(rejectedList.data) : undefined);
  return (
    <div className="page">
      <PageHeader
        title="Overview"
        subtitle="Operational snapshot of the retail group: activity, exceptions and system health."
        actions={<button type="button" className="btn" onClick={() => { void stats.refetch(); chain.refresh(); }}><IconRefresh /> Refresh</button>}
      />
      {stats.isError && !stats.data && <div className="mb"><Card><ErrorState error={stats.error} onRetry={() => void stats.refetch()} title="Headline figures unavailable" /></Card></div>}
      <div className="grid kpis k4 mb">
        <Kpi label="Network" value={<Chip tone={chain.health === 'HEALTHY' ? 'ok' : chain.health === 'DEGRADED' ? 'warn' : chain.health === 'UNKNOWN' ? 'neutral' : 'bad'} dot lg>{chain.health === 'UNKNOWN' ? 'CONNECTING' : chain.health}</Chip>} note={net ? `${net.bft.online_validators} of ${net.bft.validators} validators online` : '–'} to="/network" />
        <Kpi label={s.salesToday !== undefined ? 'Sales today' : 'Sales (24 h)'} value={val(s.salesToday ?? s.sales24h)} note={s.net24h !== undefined && s.salesToday === undefined ? `${formatMoney(s.net24h)} net · ${formatInt(s.salesTotal ?? 0)} in total` : s.salesTotal !== undefined ? `${formatInt(s.salesTotal)} in total` : undefined} to="/sales" />
        <Kpi label="Open exceptions" value={val(s.openExceptions)} tone={s.openExceptions ? 'warn' : 'ok'} note="Need follow-up" to="/inventory?tab=exceptions" />
        <Kpi label="Rejected (24 h)" value={stats.isPending && rejected === undefined ? '…' : rejected === undefined ? '–' : formatInt(rejected)} tone={rejected ? 'bad' : 'ok'} note="Refused by business rules" />
        <Kpi label="Transactions" value={val(s.txTotal)} note="Recorded in total" />
        <Kpi label="Products" value={val(s.products)} note={[s.skus !== undefined ? `${formatInt(s.skus)} SKUs` : '', s.locations !== undefined ? `${formatInt(s.locations)} locations` : ''].filter(Boolean).join(' · ') || undefined} to="/products" />
        <Kpi label="Active reservations" value={val(s.activeReservations)} note="Stock held for orders" to="/inventory?tab=reservations" />
        <Kpi label="Loyalty points" value={val(s.loyaltyPoints)} note="Outstanding balance" to="/loyalty" />
      </div>
      <div className="grid cols-2 mb">
        <RecentTx />
        <RejectedTx />
      </div>
      <div className="grid cols-21 mb">
        <Latency />
        <div className="stack">
          <MigrationCard />
        </div>
      </div>
      <Exceptions />
    </div>
  );
}

