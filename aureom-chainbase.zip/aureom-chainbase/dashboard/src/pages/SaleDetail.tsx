import { Link, useParams } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItem, metaOf } from '../api/client';
import type { LoyaltyEntry, PaymentEvent, Refund, Return, Sale, SaleLine } from '../api/types';
import { useSkus } from '../api/refdata';
import { formatMoney, formatTime, humanize, timeAgo, formatInt } from '../lib/format';
import { sumBy } from '../lib/normalize';
import { ruleLabel } from '../lib/labels';
import { Callout, Card, Kpi, KV, PageHeader, Section } from '../ui/Card';
import { Chip, ProvenanceChip, StatusChip } from '../ui/Chip';
import { ChainLink, KeyValueTags, TxLink } from '../ui/misc';
import { ErrorState, LoadingBlock } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { Tip } from '../ui/Tip';
import { EFFECTIVE_TIP } from './Sales';
import { IconInfo } from '../ui/icons';

type SaleDetailRes = Sale & { returns?: Return[]; refunds?: Refund[]; loyalty_entries?: LoyaltyEntry[]; loyalty?: LoyaltyEntry[]; payment_events?: PaymentEvent[] };

function PricingExplanation({ line, ccy, units }: { line: SaleLine; ccy: string; units: ReturnType<typeof useSkus> }) {
  const qtyText = units.qty(line.qty.v, line.sku);
  const steps = line.pricing_steps ?? [];
  return (
    <div className="stack-sm">
      <div className="field-label">How this line was priced</div>
      <ol style={{ margin: 0, paddingLeft: 18 }} className="stack-sm">
        <li>
          <b>Price used</b>: price entry <span className="mono">{line.price_id}</span> version {line.price_version}, <b>{formatMoney(line.unit_minor, ccy)}</b> per whole unit.
        </li>
        <li>
          <b>List value</b>: {formatMoney(line.unit_minor, ccy)} × {qtyText} = <b>{formatMoney(line.gross_minor, ccy)}</b> <span className="muted">(rounded half-to-even at the penny)</span>.
        </li>
        {steps.length === 0 && <li><b>Promotions</b>: none applied.</li>}
      </ol>
      {steps.length > 0 && (
        <div className="card">
          <div className="table-wrap">
            <table className="dt compact">
              <caption className="sr-only">Promotion steps for line {line.line_no}</caption>
              <thead><tr><th>Step</th><th>Promotion</th><th>Type</th><th className="num">Price before</th><th className="num">Discount</th><th className="num">Price after</th><th>Explanation</th></tr></thead>
              <tbody>
                {steps.map((st, i) => (
                  <tr key={i}>
                    <td>{i + 1}</td>
                    <td className="mono">{st.promo_id} <span className="muted">v{st.promo_version}</span></td>
                    <td>{humanize(st.type)}</td>
                    <td className="num">{formatMoney(st.before_minor, ccy)}</td>
                    <td className="num" style={{ color: 'var(--ok-fg)' }}>−{formatMoney(st.discount_minor, ccy).replace('−', '')}</td>
                    <td className="num">{formatMoney(st.after_minor, ccy)}</td>
                    <td style={{ whiteSpace: 'normal', minWidth: 220 }}>{st.explain}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <div>
        <b>Line total</b>: {formatMoney(line.gross_minor, ccy)} − {formatMoney(line.discount_minor, ccy)} discount = <b>{formatMoney(line.net_minor, ccy)}</b>
        {line.returned_v > 0 && <span className="muted"> · {units.qty(line.returned_v, line.sku)} returned</span>}
        {line.returning_v > 0 && <span className="muted"> · {units.qty(line.returning_v, line.sku)} on its way back</span>}
      </div>
    </div>
  );
}

export default function SaleDetail() {
  const { id = '' } = useParams();
  const q = useApi<unknown>(`/q/sales/${encodeURIComponent(id)}`);
  const units = useSkus();
  const item = asItem<SaleDetailRes>(q.data);
  const root = (q.data ?? {}) as Partial<SaleDetailRes>;
  const sale: SaleDetailRes | undefined = item && item.id ? item : undefined;
  const ccy = sale?.currency ?? 'GBP';
  const returns = (sale?.returns ?? root.returns ?? []) as Return[];
  const refunds = (sale?.refunds ?? root.refunds ?? []) as Refund[];
  const loyalty = (sale?.loyalty_entries ?? root.loyalty_entries ?? sale?.loyalty ?? root.loyalty ?? []) as LoyaltyEntry[];
  const events = (sale?.payment_events ?? root.payment_events ?? []) as PaymentEvent[];

  return (
    <div className="page">
      <PageHeader
        crumbs={<><Link to="/sales">Sales</Link> / <span className="mono">{id}</span></>}
        title={<span className="row wrap" style={{ gap: 10 }}>Sale <span className="mono">{id}</span> {sale && <ProvenanceChip origin={sale.provenance?.origin} />}</span>}
        subtitle={sale ? <span className="row wrap" style={{ gap: 14 }}>
          <span className="row" style={{ gap: 6 }}>Sale <StatusChip kind="sale" value={sale.sale_status} lg /></span>
          <span className="row" style={{ gap: 6 }}>Payment <StatusChip kind="payment" value={sale.payment_status} lg /></span>
          <span className="row" style={{ gap: 6 }}>Fulfilment <StatusChip kind="fulfilment" value={sale.fulfilment_status} lg /></span>
        </span> : undefined}
        actions={sale ? <ChainLink stateKey={`sale/${id}`}>View on chain</ChainLink> : undefined}
      />
      {q.isPending && <Card><LoadingBlock rows={8} /></Card>}
      {q.isError && !q.data && <Card><ErrorState error={q.error} onRetry={() => void q.refetch()} title={(q.error as { status?: number })?.status === 404 ? 'Sale not found' : undefined} /></Card>}
      {sale && (
        <div className="stack">
          <div className="grid kpis">
            <Kpi label="Gross" value={formatMoney(sale.gross_minor, ccy)} note="List value of lines" />
            <Kpi label="Discounts" value={formatMoney(sale.discount_minor, ccy)} />
            <Kpi label="Net total" value={formatMoney(sale.net_minor, ccy)} note="What the customer owes" />
            <Kpi label="Paid" value={formatMoney(sale.paid_minor, ccy)} tone={sale.paid_minor === sale.net_minor ? 'ok' : sale.paid_minor > sale.net_minor ? 'warn' : sale.payment_status === 'FAILED' ? 'bad' : 'warn'} note={sale.paid_minor === sale.net_minor ? 'Matches the total' : `${formatMoney(sale.paid_minor - sale.net_minor, ccy, { plus: true })} vs total`} />
            <Kpi label="Refund instructed" value={formatMoney(sale.refund_instructed_minor, ccy)} note="Asked the provider to pay back" />
            <Kpi label="Refund confirmed" value={formatMoney(sale.refund_confirmed_minor, ccy)} note="Provider confirmed" tone={sale.refund_confirmed_minor < sale.refund_instructed_minor ? 'warn' : undefined} />
          </div>

          <div className="grid cols-2">
            <Card title="When and where">
              <KV items={[
                [<span className="row" style={{ gap: 4 }}>Effective time <Tip label="About effective time">{EFFECTIVE_TIP}</Tip></span>, <b>{formatTime(sale.effective_at_ms)}</b>],
                ['Recorded in block at', <span>{formatTime(sale.block_time_ms)} <span className="muted">({timeAgo(sale.block_time_ms)})</span></span>],
                ['Location', sale.loc], ['Channel', humanize(sale.channel)], ['Terminal', sale.terminal_id ?? '–'],
                ['Customer', sale.customer_id ? <Link to={`/loyalty/${encodeURIComponent(sale.customer_id)}`} className="mono">{sale.customer_id}</Link> : 'Walk-in'],
                ['Payment method', humanize(sale.payment_method)],
                ['Pricing rules version', `v${sale.rules_version}`],
                ['Recorded by', sale.created_tx ? <TxLink id={sale.created_tx} /> : '–'],
              ]} />
            </Card>
            <Card title="Record details">
              <KV items={[
                ['Origin', <ProvenanceChip origin={sale.provenance?.origin} />],
                ...(sale.provenance?.origin === 'IMPORTED' ? ([
                  ['Source system', sale.provenance.source_system], ['Source id', <span className="mono">{sale.provenance.source_id}</span>], ['Import batch', <span className="mono">{sale.provenance.batch_id}</span>], ['Mapping version', sale.provenance.mapping_version],
                ] as [string, React.ReactNode][]) : []),
                ['Record version', sale.version !== undefined ? `v${sale.version}` : '–'],
                ['Preserved source fields', <KeyValueTags data={sale.source_extras} />],
              ]} />
              {sale.provenance?.origin === 'IMPORTED' && (
                <div className="mt"><Callout tone="neutral" icon={<IconInfo />}><span>This sale was imported. It is the legacy system’s assertion of what happened; the ledger records that it was imported, not that it was true.</span></Callout></div>
              )}
            </Card>
          </div>

          <Card title={`Items and pricing (${sale.lines.length})`} sub="Exact price inputs and every promotion step applied">
            <div className="stack">
              {sale.lines.map((l) => (
                <div key={l.line_no} className="card" style={{ boxShadow: 'none' }}>
                  <div className="card-head">
                    <div>
                      <div className="card-title"><span className="muted">Line {l.line_no}</span> · {units.nameOf(l.sku) ?? l.sku} <span className="mono muted">{l.sku}</span></div>
                      <div className="card-sub">{units.qty(l.qty.v, l.sku)} × {formatMoney(l.unit_minor, ccy)}</div>
                    </div>
                    <div style={{ marginLeft: 'auto', textAlign: 'right' }}><div className="muted">Line total</div><b>{formatMoney(l.net_minor, ccy)}</b></div>
                  </div>
                  <div className="card-body"><PricingExplanation line={l} ccy={ccy} units={units} /></div>
                </div>
              ))}
            </div>
            <div className="divider" />
            <div className="row" style={{ justifyContent: 'flex-end', gap: 24 }}>
              <span>Gross <b>{formatMoney(sale.gross_minor, ccy)}</b></span><span>Discount <b>−{formatMoney(sale.discount_minor, ccy).replace('−', '')}</b></span><span>Net <b>{formatMoney(sale.net_minor, ccy)}</b></span>
            </div>
          </Card>

          <Card title="Payment" sub="Events reported by the payment provider; the sale is only “Paid” once they add up to the total" flush>
            {events.length === 0 ? <div className="state">No payment events recorded yet. Payment is {humanize(sale.payment_status).toLowerCase()}.</div> : (
              <div className="table-wrap"><table className="dt compact">
                <caption className="sr-only">Payment events</caption>
                <thead><tr><th>Provider</th><th>Event</th><th>Reference</th><th>Result</th><th className="num">Amount</th><th>Transaction</th></tr></thead>
                <tbody>{events.map((e) => (
                  <tr key={e.event_id}>
                    <td>{e.provider}</td><td className="mono">{e.event_id}</td><td className="mono">{e.provider_ref}</td>
                    <td><StatusChip value={e.result?.toUpperCase()} kind="payment" /></td>
                    <td className="num">{formatMoney(e.amount_minor, ccy)}</td><td><TxLink id={e.tx_id} /></td>
                  </tr>
                ))}</tbody>
                <tfoot><tr><td colSpan={4} style={{ padding: '6px 12px' }} className="muted">Total confirmed</td><td className="num" style={{ padding: '6px 12px' }}><b>{formatMoney(sale.paid_minor, ccy)}</b></td><td /></tr></tfoot>
              </table></div>
            )}
          </Card>

          <div className="grid cols-2">
            <Card title="Returns" flush>
              {returns.length === 0 ? <div className="state">No returns against this sale.</div> : (
                <div className="table-wrap"><table className="dt compact">
                  <caption className="sr-only">Returns for this sale</caption>
                  <thead><tr><th>Return</th><th>Status</th><th>Items</th><th>Requested / decided by</th></tr></thead>
                  <tbody>{returns.map((r) => (
                    <tr key={r.id}>
                      <td className="mono">{r.id}</td><td><StatusChip kind="return" value={r.status} /></td>
                      <td style={{ whiteSpace: 'normal' }}>{r.lines.map((l) => <div key={l.line_no}>line {l.line_no}: {l.qty_v} requested, {l.received_v} received{l.inspection ? ` (${humanize(l.inspection).toLowerCase()})` : ''} · {formatMoney(l.refund_minor, ccy)}</div>)}</td>
                      <td className="mono">{r.requested_by}{r.decided_by ? ` / ${r.decided_by}` : ''}</td>
                    </tr>
                  ))}</tbody>
                </table></div>
              )}
            </Card>
            <Card title="Refunds" sub="Instructed is not the same as confirmed" flush>
              {refunds.length === 0 ? <div className="state">No refunds for this sale.</div> : (
                <div className="table-wrap"><table className="dt compact">
                  <caption className="sr-only">Refunds for this sale</caption>
                  <thead><tr><th>Refund</th><th>Return</th><th className="num">Amount</th><th>Status</th></tr></thead>
                  <tbody>{refunds.map((r) => (
                    <tr key={r.id}>
                      <td className="mono">{r.id}</td><td className="mono">{r.return_id}</td><td className="num">{formatMoney(r.amount_minor, r.currency)}</td>
                      <td title={r.provider_ref ? `Provider reference ${r.provider_ref}` : undefined}><StatusChip kind="refund" value={r.status} /></td>
                    </tr>
                  ))}</tbody>
                  <tfoot><tr><td colSpan={2} className="muted" style={{ padding: '6px 12px' }}>Instructed {formatMoney(sumBy(refunds, (r) => r.amount_minor), ccy)}</td><td colSpan={2} className="muted" style={{ padding: '6px 12px' }}>Confirmed {formatMoney(sumBy(refunds.filter((r) => r.status === 'CONFIRMED'), (r) => r.amount_minor), ccy)}</td></tr></tfoot>
                </table></div>
              )}
            </Card>
          </div>

          <Card title="Loyalty entries" sub="Points earned or reversed because of this sale" flush>
            {loyalty.length === 0 ? <div className="state">{sale.customer_id ? 'No loyalty entries for this sale.' : 'Walk-in customer: no loyalty account.'}</div> : (
              <div className="table-wrap"><table className="dt compact">
                <caption className="sr-only">Loyalty entries for this sale</caption>
                <thead><tr><th>Entry</th><th>Type</th><th>Account</th><th className="num">Points</th><th>Rule</th><th>Links</th></tr></thead>
                <tbody>{loyalty.map((e) => (
                  <tr key={e.id}>
                    <td className="mono">{e.id}</td><td><Chip tone={e.type === 'EARN' ? 'ok' : e.type === 'REVERSE' ? 'bad' : 'info'} square>{e.type}</Chip></td>
                    <td><Link to={`/loyalty/${encodeURIComponent(e.account)}`} className="mono">{e.account}</Link></td>
                    <td className="num" style={{ color: e.points < 0 ? 'var(--bad-fg)' : 'var(--ok-fg)' }}>{formatInt(e.points)}</td>
                    <td>{ruleLabel(e.rule)}</td>
                    <td>{e.reverses ? <span>reverses <span className="mono">{e.reverses}</span></span> : '–'}{e.shortfall_points ? <> <Chip tone="warn" square>shortfall {e.shortfall_points}</Chip></> : null}</td>
                  </tr>
                ))}</tbody>
              </table></div>
            )}
          </Card>
          <Section title="Verification"><div className="row wrap"><ChainLink stateKey={`sale/${id}`}>View this sale on chain</ChainLink><Link to={`/explorer/record?key=${encodeURIComponent('sale/' + id)}&history=1`}>Audit history of this record</Link><Staleness meta={metaOf(q.data)} /></div></Section>
        </div>
      )}
    </div>
  );
}
