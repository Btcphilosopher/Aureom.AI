import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useApi } from '../api/hooks';
import { apiGet, apiPost, asItems, type ApiError } from '../api/client';
import type { GovEvent, Identity, Member, ProjectionStatus, ProjectionVerify, Proposal } from '../api/types';
import { useChainStatus } from '../api/chainStatus';
import { eventTime, identityGrants, normalizeGovernance } from '../lib/normalize';
import { formatDuration, formatInt, formatMoney, formatTime, humanize, parseTimeString, shortHash, timeAgo, compactJSON, txTypeLabel } from '../lib/format';
import { PARAM_INFO, ROLE_CATALOGUE } from '../lib/labels';
import { useParam } from '../lib/hooks';
import { Callout, Card, Kpi, KV, PageHeader, Section } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable } from '../ui/DataTable';
import { ConfirmDialog, Drawer } from '../ui/Drawer';
import { Hash, Json } from '../ui/misc';
import { TabPanel, Tabs } from '../ui/Tabs';
import { ErrorState, LoadingBlock } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconLock } from '../ui/icons';
import { LagChip } from '../layout/Shell';

function useGovernance() {
  const q = useApi<unknown>('/q/governance');
  return { q, g: normalizeGovernance(q.data) };
}

function ReadOnlyNotice() {
  return (
    <div className="mb"><Callout tone="info" icon={<IconLock />}>
      <span><b>Read-only console. Signing happens in the SDK / signing service; this console cannot change business state.</b> No private keys are held, requested or stored in this browser, and nothing here can submit a business transaction. The only actions available (verify and rebuild the query projection) affect the disposable index, never the chain.</span>
    </Callout></div>
  );
}

// ---------- governance ----------

function ProposalDrawer({ p, orgs, onClose }: { p: Proposal; orgs: string[]; onClose: () => void }) {
  return (
    <Drawer title={<span>Proposal <span className="mono">{p.id}</span></span>} subtitle={<span className="row"><StatusChip value={p.status} /> {humanize(p.kind)}</span>} onClose={onClose}>
      <Section title="Approvals">
        <div className="pill-list">{orgs.map((o) => <Chip key={o} tone={p.approvals?.includes(o) ? 'ok' : 'neutral'} dot>{o}{p.approvals?.includes(o) ? ' approved' : ' pending'}</Chip>)}</div>
      </Section>
      <Section title="Schedule">
        <KV items={[['Proposed by', <span className="mono">{p.proposer}</span>], ['Activation height', formatInt(p.activation_height)], ['Approved at height', p.approved_height ? formatInt(p.approved_height) : '–'], ['Executed at height', p.executed_height ? formatInt(p.executed_height) : '–'], ['Result', p.result || '–']]} />
      </Section>
      <Section title="Payload"><Json value={p.payload} max={300} /></Section>
    </Drawer>
  );
}

function Governance() {
  const { q, g } = useGovernance();
  const chain = useChainStatus();
  const [sel, setSel] = useState<string | null>(null);
  const orgs = Array.from(new Set(g.members.filter((m) => m.status !== 'REMOVED' && m.kind === 'VALIDATOR').map((m) => m.org)));
  const open = g.proposals.find((p) => p.id === sel);
  const head = chain.head ?? 0;
  return (
    <div className="stack">
      <div className="grid cols-3">
        <Kpi label="Active state machine" value={`v${chain.appVersion ?? '–'}`} note="Business rules every validator runs" />
        <Kpi label="Open proposals" value={g.proposals.filter((p) => p.status === 'PENDING' || p.status === 'APPROVED').length} note="Pending or approved, not yet executed" tone={g.proposals.some((p) => p.status === 'PENDING') ? 'warn' : undefined} />
        <Kpi label="Scheduled upgrades" value={g.upgrades.filter((u) => u.status === 'SCHEDULED').length} note={g.upgrades.find((u) => u.status === 'SCHEDULED') ? `v${g.upgrades.find((u) => u.status === 'SCHEDULED')!.version} at height ${formatInt(g.upgrades.find((u) => u.status === 'SCHEDULED')!.activation_height)}` : 'None scheduled'} />
      </div>
      <Card title="Governance proposals" sub="Changes to membership, roles, parameters and the state machine need approval from several organisations" flush foot={<Staleness meta={g.meta} />}>
        {q.isPending ? <LoadingBlock rows={4} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : (
          <DataTable<Proposal> caption="Governance proposals" rows={g.proposals} rowKey={(p) => p.id} pageSize={10} onRowClick={(p) => setSel(p.id)} selectedKey={sel} initialSort={{ key: 'id', dir: 'desc' }} emptyText="No governance proposals."
            columns={[
              { key: 'id', header: 'Proposal', mono: true, sortValue: (p) => p.id, render: (p) => p.id },
              { key: 'kind', header: 'Kind', sortValue: (p) => p.kind, render: (p) => humanize(p.kind) },
              { key: 'by', header: 'Proposed by', render: (p) => <span className="mono">{p.proposer}</span> },
              { key: 'ap', header: 'Approvals', render: (p) => <span className="row" style={{ gap: 4 }}><b>{p.approvals?.length ?? 0}/{orgs.length || '?'}</b><span className="pill-list">{(p.approvals ?? []).map((o) => <Chip key={o} tone="ok" square>{o.replace('org-', '')}</Chip>)}</span></span> },
              { key: 'act', header: 'Activation height', align: 'right', sortValue: (p) => p.activation_height, render: (p) => <span>{formatInt(p.activation_height)}{head > 0 && p.activation_height > head && <span className="muted"> (in {formatInt(p.activation_height - head)} blocks)</span>}</span> },
              { key: 'st', header: 'Status', sortValue: (p) => p.status, render: (p) => <StatusChip value={p.status} /> },
              { key: 'res', header: 'Result', wrap: true, render: (p) => p.result || <span className="muted">–</span> },
            ]}
          />
        )}
      </Card>
      <Card title="State machine versions and scheduled upgrades" sub="An upgrade activates at a fixed block height on every validator simultaneously" flush>
        <DataTable caption="Upgrades" rows={g.upgrades} rowKey={(u) => String(u.version)} pageSize={10} emptyText="No upgrades recorded." initialSort={{ key: 'v', dir: 'desc' }}
          columns={[
            { key: 'v', header: 'Version', sortValue: (u) => u.version, render: (u) => <b>v{u.version}</b> },
            { key: 'st', header: 'Status', render: (u) => <StatusChip value={u.status} /> },
            { key: 'h', header: 'Activation height', align: 'right', sortValue: (u) => u.activation_height, render: (u) => formatInt(u.activation_height) },
            { key: 'to', header: 'Blocks until activation', align: 'right', render: (u) => (u.activation_height > head ? formatInt(u.activation_height - head) : <span className="muted">activated</span>) },
            { key: 'p', header: 'Proposal', mono: true, render: (u) => u.proposal ?? '–' },
          ]}
        />
      </Card>
      {open && <ProposalDrawer p={open} orgs={orgs} onClose={() => setSel(null)} />}
    </div>
  );
}

// ---------- members ----------

function Members() {
  const { q, g } = useGovernance();
  const chain = useChainStatus();
  const live = new Map((chain.network?.validators ?? []).map((v) => [v.name, v]));
  return (
    <div className="stack">
      <Card title="Validator membership" sub="The organisations that operate validators, each with one vote weighted by voting power" flush foot={<Staleness meta={g.meta} />}>
        {q.isPending ? <LoadingBlock rows={4} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : (
          <DataTable<Member> caption="Validator membership" rows={g.members} rowKey={(m) => m.id} pageSize={10} emptyText="No members."
            columns={[
              { key: 'id', header: 'Member', sortValue: (m) => m.id, render: (m) => <b>{m.id}</b> },
              { key: 'org', header: 'Organisation', render: (m) => m.org },
              { key: 'kind', header: 'Kind', render: (m) => <Chip tone={m.kind === 'VALIDATOR' ? 'info' : 'neutral'} square>{m.kind}</Chip> },
              { key: 'role', header: 'Role', render: (m) => humanize(m.role) },
              { key: 'pow', header: 'Voting power', align: 'right', sortValue: (m) => m.power, render: (m) => m.power },
              { key: 'st', header: 'Membership', render: (m) => <StatusChip value={m.status} /> },
              { key: 'live', header: 'Node now', render: (m) => { const v = live.get(m.id); return v ? <Chip tone={v.reachable ? 'ok' : 'bad'} dot>{v.reachable ? 'Online' : 'Offline'}</Chip> : <span className="muted">–</span>; } },
              { key: 'add', header: 'Added at height', align: 'right', render: (m) => formatInt(m.added_height) },
              { key: 'key', header: 'Consensus key', mono: true, render: (m) => <span title={m.consensus_pubkey_b64}>{shortHash(m.consensus_pubkey_b64, 8)}</span> },
            ]}
          />
        )}
      </Card>
      <Card title="Node allow-list" sub="Only nodes whose id appears here may take part in the network. Adding or removing one is a governance decision." flush>
        <DataTable<Member> caption="Node allow-list" rows={g.members.filter((m) => m.status !== 'REMOVED')} rowKey={(m) => m.id} pageSize={10} emptyText="No nodes allow-listed."
          columns={[
            { key: 'node', header: 'Node id', mono: true, render: (m) => <Hash value={m.node_id} /> },
            { key: 'm', header: 'Member', render: (m) => m.id },
            { key: 'org', header: 'Organisation', render: (m) => m.org },
            { key: 'k', header: 'Allowed as', render: (m) => (m.kind === 'VALIDATOR' ? 'Validator (votes)' : 'Observer (reads only)') },
          ]}
        />
      </Card>
    </div>
  );
}

// ---------- identities ----------

function IdentityDrawer({ id, onClose }: { id: Identity; onClose: () => void }) {
  const grants = identityGrants(id);
  return (
    <Drawer title={<span className="mono">{id.id}</span>} subtitle={<span className="row"><StatusChip value={id.status} /> {humanize(id.kind)} · {id.org}</span>} onClose={onClose}>
      <Section title="Keys">
        <div className="card"><table className="dt compact">
          <caption className="sr-only">Keys</caption>
          <thead><tr><th>Key</th><th>Status</th><th>Public key</th><th className="num">From height</th><th className="num">To height</th></tr></thead>
          <tbody>{id.keys.map((k) => (
            <tr key={k.key_id}><td className="mono">{k.key_id}</td><td><StatusChip value={k.status} /></td><td className="mono" title={k.pub_b64}>{shortHash(k.pub_b64, 8)}</td><td className="num">{formatInt(k.from_height)}</td><td className="num">{k.to_height ? formatInt(k.to_height) : <span className="muted">current</span>}</td></tr>
          ))}</tbody>
        </table></div>
      </Section>
      <Section title="Role grants">
        {grants.length === 0 ? <span className="muted">No roles granted.</span> : (
          <div className="card"><table className="dt compact"><caption className="sr-only">Role grants</caption><thead><tr><th>Role</th><th>Scope</th><th>Granted by</th><th className="num">At height</th></tr></thead>
            <tbody>{grants.map((g, i) => <tr key={i}><td>{g.role}</td><td className="mono">{g.scope}</td><td className="mono">{g.granted_by}</td><td className="num">{formatInt(g.granted_height)}</td></tr>)}</tbody></table></div>
        )}
      </Section>
      {id.bound_location && <KV items={[['Bound to location', id.bound_location]]} />}
    </Drawer>
  );
}

function Identities() {
  const q = useApi<unknown>('/q/identities', { limit: 500 });
  const gov = useGovernance();
  const rows = asItems<Identity>(q.data);
  const [sel, setSel] = useState<string | null>(null);
  const open = rows.find((i) => i.id === sel);
  const timeline = useMemo(() => {
    const ev: { h: number; t: number; title: string; sub: string; tone: 'ok' | 'warn' | 'bad' | 'info' }[] = [];
    for (const e of gov.g.events as GovEvent[]) {
      const kind = String(e.kind ?? e.type ?? e.tx_type ?? 'EVENT');
      const text = `${e.summary ?? ''} ${kind} ${e.detail ?? ''}`;
      const what = e.key ? (e.key.startsWith('iam/grants/') ? 'Role grant' : e.key.startsWith('iam/id/') ? 'Identity / keys' : e.key.startsWith('gov/member/') ? 'Membership' : e.key.startsWith('gov/prop/') ? 'Governance proposal' : e.key.startsWith('gov/upgrade/') ? 'Upgrade' : '') : '';
      const title = what ? `${what}${e.tx_type ? ' · ' + txTypeLabel(e.tx_type) : ''}` : e.tx_type ? txTypeLabel(e.tx_type) : humanize(kind);
      ev.push({ h: Number(e.height ?? 0), t: eventTime(e), title, sub: `${e.summary ?? `${e.subject ?? ''}${e.detail ? ' · ' + e.detail : ''}`}${e.signer ? ` (by ${e.signer})` : ''}`.trim(), tone: /REVOK|REMOV/i.test(text) ? 'bad' : /ROTAT/i.test(text) ? 'warn' : /ADD|REGISTER|GRANT/i.test(text) ? 'ok' : 'info' });
    }
    if (ev.length === 0) {
      for (const i of rows) for (const k of i.keys) if (k.status !== 'ACTIVE' || k.from_height > 1) ev.push({ h: k.status === 'ACTIVE' ? k.from_height : k.to_height, t: 0, title: k.status === 'ACTIVE' ? 'Key activated' : k.status === 'ROTATED' ? 'Key rotated out' : 'Key revoked', sub: `${i.id} · ${k.key_id}`, tone: k.status === 'REVOKED' ? 'bad' : k.status === 'ROTATED' ? 'warn' : 'ok' });
    }
    return ev.sort((a, b) => b.h - a.h);
  }, [gov.g.events, rows]);
  const revoked = rows.flatMap((i) => i.keys).filter((k) => k.status === 'REVOKED').length;
  const rotated = rows.flatMap((i) => i.keys).filter((k) => k.status === 'ROTATED').length;
  return (
    <div className="stack">
      <div className="grid cols-3">
        <Kpi label="Identities" value={rows.length} note="People, services and terminals" />
        <Kpi label="Keys rotated" value={rotated} note="Replaced by a newer key" />
        <Kpi label="Keys revoked" value={revoked} tone={revoked ? 'warn' : undefined} note="No longer accepted for signing" />
      </div>
      <div className="grid cols-21">
        <Card title="Identities and keys" sub="Who may sign transactions. Click a row for its keys and roles." flush>
          {q.isPending ? <LoadingBlock rows={6} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : (
            <DataTable<Identity> caption="Identities" rows={rows} rowKey={(i) => i.id} pageSize={15} onRowClick={(i) => setSel(i.id)} selectedKey={sel} quickFilter={(i, t) => `${i.id} ${i.org} ${i.kind}`.toLowerCase().includes(t)} emptyText="No identities."
              columns={[
                { key: 'id', header: 'Identity', mono: true, sortValue: (i) => i.id, render: (i) => i.id },
                { key: 'org', header: 'Organisation', sortValue: (i) => i.org, render: (i) => i.org },
                { key: 'kind', header: 'Kind', render: (i) => humanize(i.kind) },
                { key: 'loc', header: 'Bound to', render: (i) => i.bound_location ?? '–' },
                { key: 'keys', header: 'Keys', render: (i) => <span className="pill-list">{i.keys.map((k) => <StatusChip key={k.key_id} value={k.status} dot={false} title={`${k.key_id}: ${k.status}`} />)}</span> },
                { key: 'st', header: 'Status', render: (i) => <StatusChip value={i.status} /> },
              ]}
            />
          )}
        </Card>
        <Card title="Key and membership changes" sub="Newest first">
          {timeline.length === 0 ? <span className="muted">No key or membership changes recorded.</span> : (
            <ul className="timeline" style={{ maxHeight: 520, overflowY: 'auto' }}>
              {timeline.map((e, i) => (
                <li key={i} className={e.tone === 'info' ? undefined : e.tone}>
                  <div className="tl-head"><b>{e.title}</b>{e.h > 0 && <span className="tl-time">height {formatInt(e.h)}{e.t ? ` · ${formatTime(e.t)}` : ''}</span>}</div>
                  <div className="muted">{e.sub}</div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      {open && <IdentityDrawer id={open} onClose={() => setSel(null)} />}
    </div>
  );
}

function Grants() {
  const q = useApi<unknown>('/q/identities', { limit: 500 });
  const rows = asItems<Identity>(q.data);
  const flat = rows.flatMap((i) => identityGrants(i).map((g) => ({ ...g, identity: i.id, org: i.org })));
  const [role, setRole] = useState('');
  const shown = role ? flat.filter((g) => g.role === role) : flat;
  return (
    <div className="stack">
      <Card title="Role grants" sub="What each identity is allowed to do, and where (scope: everywhere, one location or one region)" flush>
        <div className="toolbar"><div className="field"><label htmlFor="g-role">Role</label><select id="g-role" className="select" value={role} onChange={(e) => setRole(e.target.value)}><option value="">All roles</option>{ROLE_CATALOGUE.map((r) => <option key={r.role} value={r.role}>{r.role}</option>)}</select></div></div>
        {q.isPending ? <LoadingBlock rows={6} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : (
          <DataTable caption="Role grants" rows={shown} rowKey={(g) => `${g.identity}|${g.role}|${g.scope}`} pageSize={15} emptyText="No role grants."
            columns={[
              { key: 'id', header: 'Identity', mono: true, sortValue: (g) => g.identity, render: (g) => g.identity },
              { key: 'org', header: 'Organisation', render: (g) => g.org },
              { key: 'role', header: 'Role', sortValue: (g) => g.role, render: (g) => <span className="row" style={{ gap: 6 }}>{g.role}{ROLE_CATALOGUE.find((r) => r.role === g.role)?.privileged && <Chip tone="warn" square title="Privileged: can only be granted by multi-organisation governance">privileged</Chip>}</span> },
              { key: 'scope', header: 'Scope', sortValue: (g) => g.scope, render: (g) => <span className="mono">{g.scope === '*' ? '* (everywhere)' : g.scope}</span> },
              { key: 'by', header: 'Granted by', mono: true, render: (g) => g.granted_by },
              { key: 'h', header: 'At height', align: 'right', sortValue: (g) => g.granted_height, render: (g) => formatInt(g.granted_height) },
            ]}
          />
        )}
      </Card>
      <Card title="Permission catalogue" sub="What each role can do. Privileged roles can only be granted or revoked by multi-organisation governance (or at genesis)." flush>
        <div className="table-wrap"><table className="dt compact">
          <caption className="sr-only">Role permission catalogue</caption>
          <thead><tr><th>Role</th><th>Permissions</th></tr></thead>
          <tbody>{ROLE_CATALOGUE.map((r) => (
            <tr key={r.role}><td><b>{r.role}</b> {r.privileged && <Chip tone="warn" square>privileged</Chip>}</td><td style={{ whiteSpace: 'normal' }}>{r.permissions.length ? <div className="tag-list">{r.permissions.map((p) => <span className="tag" key={p}>{p}</span>)}</div> : <span className="muted">read-only</span>}</td></tr>
          ))}</tbody>
        </table></div>
      </Card>
    </div>
  );
}

// ---------- projection ----------

function Projection() {
  const qc = useQueryClient();
  const chain = useChainStatus();
  const st = useApi<ProjectionStatus>('/projection/status', undefined, { poll: 1500 });
  const s = st.data ?? chain.projection;
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ tone: 'ok' | 'bad'; text: string } | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [vr, setVr] = useState<ProjectionVerify | null>(null);
  const [verr, setVerr] = useState<string | null>(null);

  const rebuild = async () => {
    setBusy(true);
    try {
      await apiPost('/projection/rebuild');
      setMsg({ tone: 'ok', text: 'Rebuild started. The projection is being re-created from block 1; progress is shown below.' });
      setVr(null);
      void qc.invalidateQueries({ queryKey: ['api', '/projection/status'] });
    } catch (e) {
      setMsg({ tone: 'bad', text: `Could not start rebuild: ${(e as ApiError).message}` });
    } finally {
      setBusy(false);
      setConfirm(false);
    }
  };
  const verify = async () => {
    setVerifying(true); setVerr(null); setVr(null);
    try { setVr(await apiGet<ProjectionVerify>('/projection/verify', { proofs: 20 })); }
    catch (e) { setVerr((e as ApiError).message); }
    finally { setVerifying(false); }
  };
  const rebuilding = s?.state === 'REBUILDING';
  const lastIdx = parseTimeString(s?.last_block_time ?? s?.last_indexed_block_time);
  const rbStart = parseTimeString(s?.rebuild?.started_at);
  useEffect(() => { if (rebuilding) setVr(null); }, [rebuilding]);
  const progress = s && s.chain_head ? Math.min(100, Math.round((s.indexed_height / s.chain_head) * 100)) : 0;
  return (
    <div className="stack">
      <Card title="Query projection" sub="A disposable SQLite index built only from finalised blocks. It powers every list on this console." actions={<span className="row"><button type="button" className="btn" disabled={verifying || rebuilding} onClick={() => void verify()}>{verifying && <span className="spinner" />} Verify projection</button><button type="button" className="btn danger" disabled={busy || rebuilding} onClick={() => setConfirm(true)}>Rebuild projection</button></span>}>
        {!s ? <LoadingBlock rows={4} /> : (
          <div className="stack">
            <div className="grid kpis">
              <Kpi label="State" value={<StatusChip value={s.state} lg />} note={rebuilding ? 'Replaying blocks…' : s.state === 'OK' ? 'Serving queries' : undefined} />
              <Kpi label="Indexed height" value={formatInt(s.indexed_height)} note={`chain head ${formatInt(s.chain_head)}`} />
              <Kpi label="Lag" value={<LagChip lag={s.lag_blocks} state={s.state} />} note={s.lag_seconds !== undefined ? `${s.lag_seconds.toFixed(1)} s behind` : undefined} />
              <Kpi label="Entries indexed" value={s.entries !== undefined ? formatInt(s.entries) : '–'} note="State records in the index" />
            </div>
            {rebuilding && <div><div className="progress" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Rebuild progress"><i style={{ width: `${progress}%` }} /></div><div className="muted" style={{ marginTop: 4 }}>{progress}% · block {formatInt(s.indexed_height)} of {formatInt(s.chain_head)}</div></div>}
            <KV items={[
              ['Projection digest', <Hash value={s.digest} />],
              ['Last block indexed', lastIdx > 0 ? `${formatTime(lastIdx)} (${timeAgo(lastIdx)})` : '–'],
              ['Last rebuild', rbStart > 0 ? <span>started {formatTime(rbStart)}{s.rebuild?.finished_at ? `, finished ${formatTime(parseTimeString(s.rebuild.finished_at))}` : ', in progress'}{s.rebuild?.blocks_replayed ? ` · ${formatInt(s.rebuild.blocks_replayed)} blocks replayed` : ''}{s.rebuild?.finished_at && s.rebuild.duration_ms ? ` in ${formatDuration(s.rebuild.duration_ms)}` : ''}</span> : <span className="muted">never rebuilt in this process</span>],
            ]} />
            {msg && <Callout tone={msg.tone}>{msg.text}</Callout>}
          </div>
        )}
      </Card>
      <Card title="Verify projection" sub="Compares the index with the chain: digest match plus random record proofs">
        {verifying ? <div className="row"><span className="spinner" /> Comparing digests and checking proofs…</div> : verr ? <Callout tone="bad">{verr}</Callout> : vr ? (
          <div className="stack-sm">
            <div className="row wrap">
              <Chip tone={vr.match ? 'ok' : 'bad'} dot lg>{vr.match ? 'Digest matches the chain' : 'Digest MISMATCH'}</Chip>
              {vr.proofs_checked !== undefined && <Chip tone={vr.proofs_valid === vr.proofs_checked ? 'ok' : 'bad'} dot lg>{vr.proofs_valid ?? 0} of {vr.proofs_checked} proofs valid</Chip>}
            </div>
            <KV items={[
              ['At height', formatInt(vr.height)],
              ['Entries (projection / chain)', `${formatInt(vr.projection_entries ?? vr.entries)} / ${vr.chain_entries !== undefined ? formatInt(vr.chain_entries) : '–'}`],
              ['Projection digest', <Hash value={vr.projection_digest} />], ['Chain digest', <Hash value={vr.chain_digest} />],
              ...(vr.proof_failures?.length ? ([['Proof failures', <span className="mono">{vr.proof_failures.join(', ')}</span>]] as [string, React.ReactNode][]) : []),
            ]} />
            {vr.statement && <p className="muted" style={{ margin: 0 }}>{vr.statement}</p>}
            {!vr.match && <Callout tone="bad">The index disagrees with the chain. Rebuild the projection; chain data is not affected.</Callout>}
          </div>
        ) : <span className="muted">Not run yet. Press “Verify projection”. This is read-only.</span>}
      </Card>
      {confirm && (
        <ConfirmDialog title="Rebuild the query projection?" confirmLabel="Rebuild projection" danger busy={busy} onConfirm={() => void rebuild()} onCancel={() => setConfirm(false)}>
          <p>This deletes the gateway’s query database and replays every finalised block from height 1. Lists and reports on this console will be empty or partial until it catches up.</p>
          <p style={{ marginBottom: 0 }}><b>Chain data and business records are not affected.</b></p>
        </ConfirmDialog>
      )}
    </div>
  );
}

// ---------- parameters ----------

function fmtParam(kind: string, v: number): string {
  switch (kind) {
    case 'bytes': return v >= 1024 * 1024 ? `${(v / 1024 / 1024).toFixed(2)} MiB` : `${(v / 1024).toFixed(0)} KiB`;
    case 'ms': return v >= 3_600_000 ? (v % 86_400_000 === 0 ? `${v / 86_400_000} days` : `${(v / 3_600_000).toFixed(1)} hours`) : formatDuration(v);
    case 'minor': return formatMoney(v, 'GBP');
    case 'blocks': return `${formatInt(v)} blocks`;
    default: return formatInt(v);
  }
}

function Parameters() {
  const { q, g } = useGovernance();
  const entries = Object.entries(g.params);
  return (
    <Card title="Parameters and limits" sub="On-chain governance parameters. Changing one requires a governance proposal." flush foot={<Staleness meta={g.meta} />}>
      {q.isPending ? <LoadingBlock rows={8} /> : q.isError && !q.data ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : entries.length === 0 ? <div className="state">No parameters returned.</div> : (
        <div className="table-wrap"><table className="dt compact">
          <caption className="sr-only">Governance parameters</caption>
          <thead><tr><th>Parameter</th><th className="num">Value</th><th>Meaning</th><th>Key</th></tr></thead>
          <tbody>{entries.map(([k, v]) => {
            const info = PARAM_INFO[k];
            return (<tr key={k}><td><b>{info?.label ?? humanize(k)}</b></td><td className="num"><b>{typeof v === 'number' ? fmtParam(info?.kind ?? 'count', v) : compactJSON(v)}</b></td><td style={{ whiteSpace: 'normal' }}>{info?.help ?? ''}</td><td className="mono muted">{k}</td></tr>);
          })}</tbody>
        </table></div>
      )}
    </Card>
  );
}

export default function Administration() {
  const [tab, setTab] = useParam('tab', 'governance');
  return (
    <div className="page">
      <PageHeader title="Administration" subtitle="Network membership, governance, identities and keys, roles, and the query projection. Everything here is read-only." />
      <ReadOnlyNotice />
      <Tabs label="Administration views" value={tab} onChange={setTab} items={[
        { id: 'governance', label: 'Governance and upgrades' },
        { id: 'members', label: 'Validators and nodes' },
        { id: 'identities', label: 'Identities and keys' },
        { id: 'grants', label: 'Role grants' },
        { id: 'projection', label: 'Projection' },
        { id: 'params', label: 'Parameters' },
      ]} />
      <TabPanel id="governance" active={tab === 'governance'}><Governance /></TabPanel>
      <TabPanel id="members" active={tab === 'members'}><Members /></TabPanel>
      <TabPanel id="identities" active={tab === 'identities'}><Identities /></TabPanel>
      <TabPanel id="grants" active={tab === 'grants'}><Grants /></TabPanel>
      <TabPanel id="projection" active={tab === 'projection'}><Projection /></TabPanel>
      <TabPanel id="params" active={tab === 'params'}><Parameters /></TabPanel>
      <p className="muted mt">For consensus health and validators in real time see <Link to="/network">Network</Link>.</p>
    </div>
  );
}
