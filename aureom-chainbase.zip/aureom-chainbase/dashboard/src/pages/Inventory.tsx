import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../api/hooks';
import { asItems, asTotal, metaOf } from '../api/client';
import type { Adjustment, InventoryException, InventoryRow, ListResponse, Movement, Reservation, Transfer } from '../api/types';
import { useLocations, useSkus } from '../api/refdata';
import { formatTime, humanize } from '../lib/format';
import { bucketLabel, locLabel, reasonLabel } from '../lib/labels';
import { useDebounced, useParam } from '../lib/hooks';
import { Callout, Card, KV, PageHeader, Section } from '../ui/Card';
import { Chip, StatusChip } from '../ui/Chip';
import { DataTable, type Column } from '../ui/DataTable';
import { Drawer } from '../ui/Drawer';
import { TabPanel, Tabs } from '../ui/Tabs';
import { ChainLink, TxLink } from '../ui/misc';
import { QueryBoundary } from '../ui/States';
import { Staleness } from '../ui/Meta';
import { IconRefresh } from '../ui/icons';

const DEFS = {
  onHand: 'Physically at the location: available + reserved + quarantined + damaged. Excludes stock in transit.',
  reserved: 'Held for orders or terminals that have reserved it but not yet completed the sale. Not available to sell.',
  available: 'On hand that is free to sell: not reserved, quarantined or damaged.',
  transit: 'Stock dispatched between locations and not yet received. “In” is arriving here; “out” has left here.',
  quarantined: 'Set aside (for example for inspection). Counted on hand but not sellable.',
  damaged: 'Written down as damaged. Counted on hand until adjusted, not sellable.',
};

function Qty({ v, sku, units, bad }: { v: number | undefined; sku: string; units: ReturnType<typeof useSkus>; bad?: boolean }) {
  if (!v) return <span className="muted">0</span>;
  return <span style={bad ? { color: 'var(--bad-fg)' } : undefined}>{units.qty(v, sku, { unit: false })}</span>;
}

function BucketBar({ row }: { row: InventoryRow }) {
  const parts = [
    { k: 'Available to sell', v: row.available, c: 'var(--ok-solid)' },
    { k: 'Reserved for orders', v: row.reserved, c: 'var(--series-1)' },
    { k: 'Quarantined', v: row.quarantined, c: 'var(--warn-solid)' },
    { k: 'Damaged', v: row.damaged, c: 'var(--bad-solid)' },
  ];
  const total = parts.reduce((a, p) => a + p.v, 0) || 1;
  return (
    <div>
      <div className="row" style={{ gap: 2, height: 14 }} role="img" aria-label="Stock on hand split by status">
        {parts.filter((p) => p.v > 0).map((p) => (
          <div key={p.k} title={`${p.k}: ${p.v}`} style={{ flex: p.v / total, background: p.c, height: '100%', borderRadius: 3, minWidth: 3 }} />
        ))}
      </div>
      <div className="chart-legend">
        {parts.map((p) => <span key={p.k}><i style={{ background: p.c }} />{p.k}</span>)}
      </div>
    </div>
  );
}

function MovementsTable({ params, units, locs, compact, pageSize = 15 }: { params: Record<string, string | number | undefined>; units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations>; compact?: boolean; pageSize?: number }) {
  const q = useApi<ListResponse<Movement>>('/q/movements', { ...params, limit: 500 }, { keep: true });
  const rows = asItems<Movement>(q.data);
  const cols: Column<Movement>[] = [
    { key: 'seq', header: 'Seq', align: 'right', sortValue: (m) => m.seq, render: (m) => m.seq },
    { key: 'eff', header: 'Effective', tip: 'When the movement took place according to the signer. The ledger records its own inclusion time separately.', sortValue: (m) => m.effective_at_ms, render: (m) => formatTime(m.effective_at_ms, { seconds: false }) },
    ...(compact ? [] : [{ key: 'sku', header: 'SKU', mono: true, sortValue: (m: Movement) => m.sku, render: (m: Movement) => m.sku } as Column<Movement>]),
    { key: 'from', header: 'From', wrap: true, render: (m) => <span>{locLabel(m.from_loc, compact ? undefined : locs.nameOf)} <span className="muted">· {bucketLabel(m.from_bucket)}</span></span> },
    { key: 'to', header: 'To', wrap: true, render: (m) => <span>{locLabel(m.to_loc, compact ? undefined : locs.nameOf)} <span className="muted">· {bucketLabel(m.to_bucket)}</span></span> },
    { key: 'qty', header: 'Quantity', align: 'right', sortValue: (m) => m.qty, render: (m) => units.qty(m.qty, m.sku) },
    { key: 'reason', header: 'Reason', sortValue: (m) => m.reason, render: (m) => reasonLabel(m.reason) },
    { key: 'ref', header: 'Reference', mono: true, render: (m) => (compact ? <span title={`${m.ref_type}:${m.ref_id}`}>{m.ref_id}</span> : `${m.ref_type}:${m.ref_id}`) },
    ...(compact ? [] : [{ key: 'origin', header: 'Origin', render: (m: Movement) => (m.origin === 'NATIVE' ? <Chip tone="info" square>Native</Chip> : <Chip tone="accent" square title="Opening balance imported from the legacy system">Imported opening</Chip>) } as Column<Movement>]),
    ...(compact ? [] : [{ key: 'tx', header: 'Transaction', render: (m: Movement) => <TxLink id={m.tx_id} /> } as Column<Movement>]),
  ];
  return (
    <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No movements" emptyText="No stock movements match these filters.">
      {() => <DataTable<Movement> caption="Stock movement ledger" rows={rows} rowKey={(m) => `${m.sku}-${m.seq}`} columns={cols} pageSize={pageSize} initialSort={{ key: 'seq', dir: 'desc' }} compact={compact} total={asTotal(q.data)} footerLeft={<Staleness meta={metaOf(q.data)} />} />}
    </QueryBoundary>
  );
}

function BalanceDrawer({ row, units, locs, onClose }: { row: InventoryRow; units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations>; onClose: () => void }) {
  const name = row.product_name ?? units.nameOf(row.sku);
  return (
    <Drawer title={name ?? row.sku} subtitle={<span className="mono">{row.sku} · {locLabel(row.loc, locs.nameOf)}</span>} onClose={onClose} actions={<ChainLink stateKey={`bal/${row.sku}/${row.loc}`} />}>
      <Section title="Stock position">
        <BucketBar row={row} />
        <div className="mt">
          <KV items={[
            ['On hand', <b>{units.qty(row.on_hand, row.sku)}</b>],
            ['Available to sell', units.qty(row.available, row.sku)],
            ['Reserved for orders', units.qty(row.reserved, row.sku)],
            ['Quarantined', units.qty(row.quarantined, row.sku)],
            ['Damaged', units.qty(row.damaged, row.sku)],
            ['In transit (arriving)', units.qty(row.in_transit_in ?? 0, row.sku)],
            ['In transit (leaving)', units.qty(row.in_transit_out ?? 0, row.sku)],
          ]} />
        </div>
      </Section>
      <Section title="Movement ledger for this SKU at this location">
        <p className="muted">Every change to these numbers is a recorded movement; the balance is the sum of the ledger.</p>
        <div className="card"><MovementsTable params={{ sku: row.sku, location: row.loc }} units={units} locs={locs} compact pageSize={10} /></div>
      </Section>
    </Drawer>
  );
}

function Balances({ units, locs }: { units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [skuQ, setSkuQ] = useState('');
  const dSku = useDebounced(skuQ);
  const [loc, setLoc] = useParam('location');
  const [low, setLow] = useParam('low');
  const [threshold, setThreshold] = useState('20');
  const [selKey, setSelKey] = useParam('row');
  const q = useApi<ListResponse<InventoryRow>>('/q/inventory', { sku: dSku, location: loc, low_stock: low ? Number(threshold) || 0 : undefined, limit: 500 }, { keep: true });
  const rows = asItems<InventoryRow>(q.data);
  const sel = rows.find((r) => `${r.sku}@${r.loc}` === selKey);

  const cols: Column<InventoryRow>[] = [
    { key: 'sku', header: 'SKU', mono: true, sortValue: (r) => r.sku, render: (r) => <span>{r.sku} <span className="muted" title="Quantities are shown in this unit">{r.unit ?? units.unitOf(r.sku)}</span></span> },
    { key: 'name', header: 'Product', sortValue: (r) => r.product_name ?? units.nameOf(r.sku), render: (r) => r.product_name ?? units.nameOf(r.sku) ?? '–' },
    { key: 'loc', header: 'Location', sortValue: (r) => r.loc, render: (r) => <span title={locs.nameOf(r.loc)}>{r.loc}</span> },
    { key: 'oh', header: 'On hand', align: 'right', tip: DEFS.onHand, sortValue: (r) => r.on_hand, render: (r) => <b><Qty v={r.on_hand} sku={r.sku} units={units} /></b> },
    { key: 'res', header: 'Reserved for orders', align: 'right', tip: DEFS.reserved, sortValue: (r) => r.reserved, render: (r) => <Qty v={r.reserved} sku={r.sku} units={units} /> },
    { key: 'av', header: 'Available to sell', align: 'right', tip: DEFS.available, sortValue: (r) => r.available, render: (r) => <b style={{ color: r.available <= 0 ? 'var(--bad-fg)' : undefined }}><Qty v={r.available} sku={r.sku} units={units} /></b> },
    { key: 'tr', header: 'In transit (in / out)', align: 'right', tip: DEFS.transit, sortValue: (r) => (r.in_transit_in ?? 0) + (r.in_transit_out ?? 0), render: (r) => ((r.in_transit_in ?? 0) + (r.in_transit_out ?? 0) === 0 ? <span className="muted">0</span> : <span>{units.qty(r.in_transit_in ?? 0, r.sku, { unit: false })} / {units.qty(r.in_transit_out ?? 0, r.sku, { unit: false })}</span>) },
    { key: 'qu', header: 'Quarantined', align: 'right', tip: DEFS.quarantined, sortValue: (r) => r.quarantined, render: (r) => <Qty v={r.quarantined} sku={r.sku} units={units} /> },
    { key: 'dm', header: 'Damaged', align: 'right', tip: DEFS.damaged, sortValue: (r) => r.damaged, render: (r) => <Qty v={r.damaged} sku={r.sku} units={units} bad /> },
  ];
  return (
    <>
      <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
        <div className="toolbar">
          <div className="field" style={{ width: 220 }}>
            <label htmlFor="inv-sku">SKU</label>
            <input id="inv-sku" className="input" type="search" placeholder="e.g. SKU-MILK" value={skuQ} onChange={(e) => setSkuQ(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="inv-loc">Location</label>
            <select id="inv-loc" className="select" value={loc} onChange={(e) => setLoc(e.target.value)}>
              <option value="">All locations</option>
              {locs.locations.map((l) => <option key={l.id} value={l.id}>{l.id} · {l.name}</option>)}
            </select>
          </div>
          <label className="check"><input type="checkbox" checked={!!low} onChange={(e) => setLow(e.target.checked ? '1' : null)} /> Low stock only</label>
          {low && (
            <div className="field" style={{ width: 120 }}>
              <label htmlFor="inv-th" title="Available to sell at or below this quantity, in the SKU’s smallest unit (pieces, grams, millilitres)">Available ≤</label>
              <input id="inv-th" className="input" inputMode="numeric" value={threshold} onChange={(e) => setThreshold(e.target.value.replace(/[^0-9]/g, ''))} />
            </div>
          )}
        </div>
        <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No balances" emptyText="No stock balances match these filters.">
          {() => <DataTable<InventoryRow> caption="Stock balances by SKU and location" rows={rows} rowKey={(r) => `${r.sku}@${r.loc}`} columns={cols} pageSize={25} total={asTotal(q.data)} initialSort={{ key: 'sku', dir: 'asc' }} onRowClick={(r) => setSelKey(`${r.sku}@${r.loc}`)} selectedKey={selKey || null} />}
        </QueryBoundary>
      </Card>
      {sel && <BalanceDrawer row={sel} units={units} locs={locs} onClose={() => setSelKey(null)} />}
    </>
  );
}

function Movements({ units, locs }: { units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [sku, setSku] = useState('');
  const [ref, setRef] = useState('');
  const [reason, setReason] = useParam('reason');
  const [loc, setLoc] = useParam('mloc');
  const dSku = useDebounced(sku), dRef = useDebounced(ref);
  return (
    <Card flush>
      <div className="toolbar">
        <div className="field" style={{ width: 200 }}><label htmlFor="mv-sku">SKU</label><input id="mv-sku" className="input" type="search" value={sku} onChange={(e) => setSku(e.target.value)} placeholder="Exact SKU id" /></div>
        <div className="field"><label htmlFor="mv-loc">Location</label>
          <select id="mv-loc" className="select" value={loc} onChange={(e) => setLoc(e.target.value)}><option value="">All locations</option>{locs.locations.map((l) => <option key={l.id} value={l.id}>{l.id}</option>)}</select></div>
        <div className="field"><label htmlFor="mv-reason">Reason</label>
          <select id="mv-reason" className="select" value={reason} onChange={(e) => setReason(e.target.value)}>
            <option value="">Any reason</option>
            {['RECEIPT', 'SALE', 'RETURN', 'RESERVE', 'RELEASE', 'TRANSFER_DISPATCH', 'TRANSFER_RECEIVE', 'ADJUSTMENT', 'OPENING_BALANCE'].map((r) => <option key={r} value={r}>{reasonLabel(r)}</option>)}
          </select></div>
        <div className="field" style={{ width: 200 }}><label htmlFor="mv-ref">Reference id</label><input id="mv-ref" className="input mono" value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Sale, PO, transfer id…" /></div>
      </div>
      <MovementsTable params={{ sku: dSku || undefined, location: loc || undefined, reason: reason || undefined, ref_id: dRef || undefined }} units={units} locs={locs} />
    </Card>
  );
}

function Reservations({ units, locs }: { units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [status, setStatus] = useParam('rstatus', 'ACTIVE');
  const q = useApi<ListResponse<Reservation>>('/q/reservations', { status: status === 'ALL' ? undefined : status, limit: 500 }, { keep: true });
  const rows = asItems<Reservation>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="rs-st">Status</label>
          <select id="rs-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="ACTIVE">Open (active)</option><option value="ALL">All</option><option value="CONSUMED">Used by a sale</option><option value="RELEASED">Released</option><option value="EXPIRED">Expired</option>
          </select></div>
        <span className="muted" style={{ alignSelf: 'center' }}>Stock held back for an order or terminal. It leaves “available to sell” until the sale completes or the hold ends.</span>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No reservations" emptyText="There are no reservations with this status.">
        {() => (
          <DataTable<Reservation> caption="Reservations" rows={rows} rowKey={(r) => r.id} pageSize={25} total={asTotal(q.data)}
            initialSort={{ key: 'exp', dir: 'asc' }}
            columns={[
              { key: 'id', header: 'Reservation', mono: true, sortValue: (r) => r.id, render: (r) => r.id },
              { key: 'sku', header: 'SKU', mono: true, sortValue: (r) => r.sku, render: (r) => r.sku },
              { key: 'loc', header: 'Location', render: (r) => <span title={locs.nameOf(r.loc)}>{r.loc}</span> },
              { key: 'qty', header: 'Quantity held', align: 'right', sortValue: (r) => r.qty, render: (r) => units.qty(r.qty, r.sku) },
              { key: 'used', header: 'Used', align: 'right', render: (r) => (r.consumed_v ? units.qty(r.consumed_v, r.sku, { unit: false }) : <span className="muted">0</span>) },
              { key: 'holder', header: 'Held by', render: (r) => <span className="mono">{r.holder}</span> },
              { key: 'term', header: 'Terminal', render: (r) => r.terminal_id ?? '–' },
              { key: 'type', header: 'Type', render: (r) => (r.allowance ? <Chip tone="accent" square title="Pre-allocated stock allowance for offline sales of scarce items">Offline allowance</Chip> : <span className="muted">Standard</span>) },
              { key: 'st', header: 'Status', sortValue: (r) => r.status, render: (r) => <StatusChip value={r.status} /> },
              { key: 'exp', header: 'Hold expires', sortValue: (r) => r.expires_at_ms, render: (r) => formatTime(r.expires_at_ms, { seconds: false }) },
              { key: 'sale', header: 'Sale', render: (r) => (r.sale_id ? <Link to={`/sales/${encodeURIComponent(r.sale_id)}`} className="mono">{r.sale_id}</Link> : '–') },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function Transfers({ units, locs }: { units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [status, setStatus] = useParam('tstatus');
  const q = useApi<ListResponse<Transfer>>('/q/transfers', { status, limit: 500 }, { keep: true });
  const rows = asItems<Transfer>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="tf-st">Status</label>
          <select id="tf-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All transfers</option><option value="IN_TRANSIT">In transit (dispatched)</option><option value="RECEIVED">Received</option><option value="RECEIVED_WITH_DISCREPANCY">Received with discrepancy</option>
          </select></div>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No transfers" emptyText="No stock transfers match.">
        {() => (
          <DataTable<Transfer> caption="Stock transfers" rows={rows} rowKey={(t) => t.id} pageSize={25}
            columns={[
              { key: 'id', header: 'Transfer', mono: true, sortValue: (t) => t.id, render: (t) => t.id },
              { key: 'route', header: 'Route', wrap: true, render: (t) => <span>{locLabel(t.from, locs.nameOf)} → {locLabel(t.to, locs.nameOf)}</span> },
              { key: 'lines', header: 'Lines (dispatched / received / damaged)', wrap: true, render: (t) => (
                <div className="stack-sm" style={{ gap: 2 }}>
                  {t.lines.map((l) => {
                    const off = t.status !== 'IN_TRANSIT' && l.sent_v !== l.received_v + l.damaged_v;
                    return (
                      <div key={l.sku} className="row" style={{ gap: 6 }}>
                        <span className="mono">{l.sku}</span>
                        <span>{units.qty(l.sent_v, l.sku, { unit: false })} / {t.status === 'IN_TRANSIT' ? '–' : units.qty(l.received_v, l.sku, { unit: false })} / {l.damaged_v ? <b style={{ color: 'var(--bad-fg)' }}>{units.qty(l.damaged_v, l.sku, { unit: false })}</b> : 0} <span className="muted">{units.unitOf(l.sku)}</span></span>
                        {off && <Chip tone="bad" square>short {units.qty(l.sent_v - l.received_v - l.damaged_v, l.sku, { unit: false })}</Chip>}
                      </div>
                    );
                  })}
                </div>
              ) },
              { key: 'st', header: 'Status', sortValue: (t) => t.status, render: (t) => <StatusChip kind="transfer" value={t.status} /> },
              { key: 'ver', header: 'Version', align: 'right', render: (t) => (t.version !== undefined ? `v${t.version}` : '–') },
              { key: 'chain', header: '', render: (t) => <ChainLink stateKey={`xfer/${t.id}`}>On chain</ChainLink> },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function Adjustments({ units, locs }: { units: ReturnType<typeof useSkus>; locs: ReturnType<typeof useLocations> }) {
  const [status, setStatus] = useParam('astatus', 'PENDING');
  const q = useApi<ListResponse<Adjustment>>('/q/adjustments', { status: status === 'ALL' ? undefined : status, limit: 500 }, { keep: true });
  const rows = asItems<Adjustment>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="toolbar">
        <div className="field"><label htmlFor="adj-st">Status</label>
          <select id="adj-st" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="PENDING">Awaiting approval</option><option value="ALL">All</option><option value="APPROVED">Approved</option><option value="REJECTED">Rejected</option><option value="REVERSED">Reversed</option>
          </select></div>
        <span className="muted" style={{ alignSelf: 'center' }}>Stock corrections proposed after a count. Larger corrections need approval from a manager with wider scope before the balance changes.</span>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="Nothing awaiting approval" emptyText="There are no stock adjustments with this status.">
        {() => (
          <DataTable<Adjustment> caption="Stock adjustments" rows={rows} rowKey={(a) => a.id} pageSize={25}
            columns={[
              { key: 'id', header: 'Adjustment', mono: true, sortValue: (a) => a.id, render: (a) => a.id },
              { key: 'sku', header: 'SKU', mono: true, sortValue: (a) => a.sku, render: (a) => a.sku },
              { key: 'loc', header: 'Location', render: (a) => <span title={locs.nameOf(a.loc)}>{a.loc}</span> },
              { key: 'b', header: 'Stock type', render: (a) => bucketLabel(a.bucket) },
              { key: 'sys', header: 'System count', align: 'right', render: (a) => units.qty(a.system_qty, a.sku, { unit: false }) },
              { key: 'cnt', header: 'Counted', align: 'right', render: (a) => units.qty(a.counted_qty, a.sku, { unit: false }) },
              { key: 'd', header: 'Difference', align: 'right', sortValue: (a) => a.delta, render: (a) => <b style={{ color: a.delta < 0 ? 'var(--bad-fg)' : 'var(--ok-fg)' }}>{units.qty(a.delta, a.sku, { unit: false, plus: true })}</b> },
              { key: 'r', header: 'Reason', wrap: true, render: (a) => <div>{humanize(a.reason)}<div className="muted mono">{a.evidence_ref}</div></div> },
              { key: 'p', header: 'Proposed by', render: (a) => <span className="mono">{a.proposer}</span> },
              { key: 'dec', header: 'Decided by', render: (a) => (a.decider ? <span className="mono">{a.decider}</span> : <span className="muted">awaiting</span>) },
              { key: 'st', header: 'Status', sortValue: (a) => a.status, render: (a) => <StatusChip value={a.status} /> },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

function Exceptions({ locs }: { locs: ReturnType<typeof useLocations> }) {
  const q = useApi<ListResponse<InventoryException>>('/q/inventory/exceptions', { limit: 500 });
  const rows = asItems<InventoryException>(q.data);
  return (
    <Card flush foot={<Staleness meta={metaOf(q.data)} />}>
      <div className="card-body" style={{ paddingBottom: 0 }}>
        <Callout tone="info">Open exceptions, transfer discrepancies, stock stuck in transit and reservations about to expire. Each needs a person to confirm or correct.</Callout>
      </div>
      <QueryBoundary q={q} isEmpty={(d) => asItems(d).length === 0} emptyTitle="No inventory exceptions" emptyText="Everything reconciles.">
        {() => (
          <DataTable<InventoryException> caption="Inventory exceptions" rows={rows} rowKey={(e) => `${e.kind}|${e.ref}|${e.sku ?? ''}`} pageSize={25}
            initialSort={{ key: 'sev', dir: 'asc' }}
            columns={[
              { key: 'sev', header: 'Severity', sortValue: (e) => ({ HIGH: 0, CRITICAL: 0, MEDIUM: 1, WARNING: 1, LOW: 2, INFO: 2 } as Record<string, number>)[e.severity?.toUpperCase()] ?? 3, render: (e) => <StatusChip value={e.severity?.toUpperCase()} /> },
              { key: 'kind', header: 'Type', sortValue: (e) => e.kind, render: (e) => humanize(e.kind) },
              { key: 'ref', header: 'Reference', mono: true, render: (e) => e.ref },
              { key: 'detail', header: 'Detail', wrap: true, render: (e) => e.detail },
              { key: 'loc', header: 'Location', render: (e) => (e.location ? <span title={locs.nameOf(e.location)}>{e.location}</span> : '–') },
              { key: 'sku', header: 'SKU', mono: true, render: (e) => e.sku ?? '–' },
            ]}
          />
        )}
      </QueryBoundary>
    </Card>
  );
}

export default function Inventory() {
  const [tab, setTab] = useParam('tab', 'balances');
  const units = useSkus();
  const locs = useLocations();
  const excCount = useApi<ListResponse<InventoryException>>('/q/inventory/exceptions', { limit: 1 });
  const adjCount = useApi<ListResponse<Adjustment>>('/q/adjustments', { status: 'PENDING', limit: 1 });
  const resCount = useApi<ListResponse<Reservation>>('/q/reservations', { status: 'ACTIVE', limit: 1 });
  const n = (q: { data?: unknown }) => (q.data ? asTotal(q.data) : undefined);
  return (
    <div className="page">
      <PageHeader
        title="Inventory"
        subtitle="Stock on hand, reserved for orders, available to sell, in transit and quarantined or damaged, by SKU and location."
        actions={<button type="button" className="btn" onClick={() => { void excCount.refetch(); void adjCount.refetch(); void resCount.refetch(); }}><IconRefresh /> Refresh counts</button>}
      />
      <Tabs
        label="Inventory views"
        value={tab}
        onChange={setTab}
        items={[
          { id: 'balances', label: 'Stock balances' },
          { id: 'movements', label: 'Movement ledger' },
          { id: 'reservations', label: 'Reservations', count: n(resCount) },
          { id: 'transfers', label: 'Transfers' },
          { id: 'adjustments', label: 'Adjustments', count: n(adjCount), countTone: n(adjCount) ? 'warn' : undefined },
          { id: 'exceptions', label: 'Exceptions', count: n(excCount), countTone: n(excCount) ? 'bad' : undefined },
        ]}
      />
      <TabPanel id="balances" active={tab === 'balances'}><Balances units={units} locs={locs} /></TabPanel>
      <TabPanel id="movements" active={tab === 'movements'}><Movements units={units} locs={locs} /></TabPanel>
      <TabPanel id="reservations" active={tab === 'reservations'}><Reservations units={units} locs={locs} /></TabPanel>
      <TabPanel id="transfers" active={tab === 'transfers'}><Transfers units={units} locs={locs} /></TabPanel>
      <TabPanel id="adjustments" active={tab === 'adjustments'}><Adjustments units={units} locs={locs} /></TabPanel>
      <TabPanel id="exceptions" active={tab === 'exceptions'}><Exceptions locs={locs} /></TabPanel>
    </div>
  );
}
