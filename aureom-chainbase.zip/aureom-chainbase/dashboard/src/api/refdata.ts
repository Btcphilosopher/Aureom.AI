import { useMemo } from 'react';
import { useApi } from './hooks';
import { asItems } from './client';
import type { ListResponse, Location, Product, Sku, Supplier } from './types';
import { formatQty } from '../lib/format';

/** Reference data used to render units, names and location labels across screens. */
export function useSkus() {
  const q = useApi<ListResponse<Sku>>('/q/skus', { limit: 500 }, { staleTime: 60_000 });
  const products = useApi<ListResponse<Product>>('/q/products', { limit: 500 }, { staleTime: 60_000 });
  return useMemo(() => {
    const unit = new Map<string, string>();
    const name = new Map<string, string>();
    const prodName = new Map<string, string>();
    for (const p of asItems<Product>(products.data)) {
      prodName.set(p.id, p.name);
      for (const s of (p.sku_details ?? p.skus ?? []) as (string | Sku)[]) if (typeof s === 'object') { unit.set(s.id, s.unit); name.set(s.id, p.name); }
    }
    for (const s of asItems<Sku>(q.data)) {
      unit.set(s.id, s.unit);
      if (!name.has(s.id) && prodName.has(s.product_id)) name.set(s.id, prodName.get(s.product_id)!);
    }
    return {
      skus: asItems<Sku>(q.data),
      unitOf: (sku: string) => unit.get(sku) ?? 'EA',
      nameOf: (sku: string) => name.get(sku),
      qty: (v: number | undefined, sku: string, opts?: { unit?: boolean; plus?: boolean }) => formatQty(v, unit.get(sku) ?? 'EA', opts),
      loading: q.isPending,
    };
  }, [q.data, products.data, q.isPending]);
}

export function useLocations() {
  const q = useApi<ListResponse<Location>>('/q/locations', { limit: 200 }, { staleTime: 60_000 });
  return useMemo(() => {
    const items = asItems<Location>(q.data);
    const names = new Map(items.map((l) => [l.id, l.name]));
    return { locations: items, nameOf: (id: string) => names.get(id), loading: q.isPending };
  }, [q.data, q.isPending]);
}

export function useSuppliers() {
  const q = useApi<ListResponse<Supplier>>('/q/suppliers', { limit: 200 }, { staleTime: 60_000 });
  return useMemo(() => {
    const items = asItems<Supplier>(q.data);
    const names = new Map(items.map((s) => [s.id, s.name]));
    return { suppliers: items, nameOf: (id: string | undefined) => (id ? names.get(id) : undefined), loading: q.isPending };
  }, [q.data, q.isPending]);
}
