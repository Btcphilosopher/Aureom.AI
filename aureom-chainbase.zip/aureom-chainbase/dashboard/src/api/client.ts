// Thin fetch wrapper for the gateway REST API. The console is read-only: the only
// non-GET calls are the projection maintenance endpoints (rebuild).

export const API_BASE: string = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') ?? '/api/v1';

export class ApiError extends Error {
  status: number;
  code: string;
  /** true when no HTTP response was received at all (gateway down / network error). */
  unreachable: boolean;
  constructor(message: string, status: number, code = '', unreachable = false) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.unreachable = unreachable;
  }
}

export type Params = Record<string, string | number | boolean | undefined | null>;

export function buildUrl(path: string, params?: Params): string {
  const base = API_BASE + (path.startsWith('/') ? path : '/' + path);
  if (!params) return base;
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '' || v === false) continue;
    qs.set(k, v === true ? '1' : String(v));
  }
  const s = qs.toString();
  return s ? `${base}?${s}` : base;
}

async function parse<T>(res: Response): Promise<T> {
  const text = await res.text();
  let body: unknown = undefined;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      if (res.ok) throw new ApiError('Gateway returned a non-JSON response (is the API base URL correct?)', res.status, 'BAD_RESPONSE');
    }
  }
  if (!res.ok) {
    const b = (body ?? {}) as { error?: string; code?: string };
    throw new ApiError(b.error ?? `HTTP ${res.status} ${res.statusText}`, res.status, b.code ?? '');
  }
  return body as T;
}

export async function apiGet<T>(path: string, params?: Params, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await fetch(buildUrl(path, params), { headers: { Accept: 'application/json' }, signal });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e;
    throw new ApiError('Gateway unreachable: ' + ((e as Error).message || 'network error'), 0, 'UNREACHABLE', true);
  }
  return parse<T>(res);
}

export async function apiPost<T>(path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(buildUrl(path), {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (e) {
    throw new ApiError('Gateway unreachable: ' + ((e as Error).message || 'network error'), 0, 'UNREACHABLE', true);
  }
  return parse<T>(res);
}

// ---- response normalisers (the gateway wraps lists/items; be tolerant of bare arrays) ----

import type { ListResponse, ProjectionMeta } from './types';

export function asItems<T>(res: unknown): T[] {
  if (Array.isArray(res)) return res as T[];
  const r = res as { items?: T[] } | undefined;
  return Array.isArray(r?.items) ? (r!.items as T[]) : [];
}

export function asTotal(res: unknown): number {
  if (Array.isArray(res)) return res.length;
  const r = res as ListResponse<unknown> | undefined;
  return typeof r?.total === 'number' ? r.total : asItems(res).length;
}

export function asItem<T>(res: unknown): T | undefined {
  if (!res || typeof res !== 'object') return undefined;
  const r = res as { item?: T };
  return (r.item ?? (res as T)) as T;
}

export function metaOf(res: unknown): ProjectionMeta | undefined {
  if (!res || typeof res !== 'object') return undefined;
  return (res as { meta?: ProjectionMeta }).meta;
}
