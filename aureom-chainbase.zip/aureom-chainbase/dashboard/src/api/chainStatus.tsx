import { createContext, useContext, useMemo, type ReactNode } from 'react';
import { useApi } from './hooks';
import type { NetworkInfo, ProjectionStatus } from './types';
import { parseTimeString } from '../lib/format';

export interface ChainStatus {
  reachable: boolean;
  /** Finalised block height as seen by the gateway. */
  head: number | null;
  indexed: number | null;
  lag: number | null;
  health: 'HEALTHY' | 'DEGRADED' | 'HALTED' | 'UNKNOWN' | 'UNREACHABLE';
  projectionState: string;
  networkId: string;
  appVersion: number | null;
  blockTimeMs: number;
  network?: NetworkInfo;
  projection?: ProjectionStatus;
  updatedAt: number;
  error?: string;
  refresh: () => void;
}

const Ctx = createContext<ChainStatus | null>(null);

/** Polls /network and /projection/status so every page can show chain height, indexed height and lag. */
export function ChainStatusProvider({ children, pollMs = 3000 }: { children: ReactNode; pollMs?: number }) {
  const net = useApi<NetworkInfo>('/network', undefined, { poll: pollMs });
  const proj = useApi<ProjectionStatus>('/projection/status', undefined, { poll: pollMs });

  const value = useMemo<ChainStatus>(() => {
    const network = net.data;
    const projection = proj.data;
    const netDown = net.isError && net.error?.unreachable;
    const projDown = proj.isError && proj.error?.unreachable;
    const reachable = !(netDown && projDown) && !(netDown && !proj.data);
    const head = network?.chain?.latest_height ?? projection?.chain_head ?? null;
    const indexed = projection?.indexed_height ?? null;
    const lag = projection ? projection.lag_blocks : head !== null && indexed !== null ? Math.max(0, head - indexed) : null;
    let health: ChainStatus['health'] = 'UNKNOWN';
    if (!reachable) health = 'UNREACHABLE';
    else if (network?.bft?.status) health = network.bft.status as ChainStatus['health'];
    const updatedAt = Math.max(net.dataUpdatedAt || 0, proj.dataUpdatedAt || 0);
    return {
      reachable,
      head,
      indexed,
      lag,
      health,
      projectionState: projection?.state ?? 'UNKNOWN',
      networkId: network?.network_id ?? '',
      appVersion: network?.app_version ?? null,
      blockTimeMs: network ? parseTimeString(network.chain?.latest_block_time) : 0,
      network,
      projection,
      updatedAt,
      error: net.error?.message ?? proj.error?.message,
      refresh: () => {
        void net.refetch();
        void proj.refetch();
      },
    };
  }, [net.data, net.isError, net.error, net.dataUpdatedAt, net.refetch, proj.data, proj.isError, proj.error, proj.dataUpdatedAt, proj.refetch]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useChainStatus(): ChainStatus {
  const c = useContext(Ctx);
  if (!c) throw new Error('useChainStatus must be used inside <ChainStatusProvider>');
  return c;
}
