import { useRef } from 'react';
import { keepPreviousData, useQuery, type UseQueryResult } from '@tanstack/react-query';
import { apiGet, ApiError, type Params } from './client';

export interface QueryOpts {
  enabled?: boolean;
  /** Poll interval in ms (Network / Overview only). */
  poll?: number;
  /** Keep the previous result visible while a new filter combination loads. */
  keep?: boolean;
  staleTime?: number;
}

/**
 * Generic GET hook. The query key is the (path, params) pair, so filters are cacheable.
 * A query that has failed and has no data keeps reporting its error while it is polled again,
 * so a polling screen shows a stable error state (not a flickering skeleton) when the gateway is down.
 */
export function useApi<T = unknown>(path: string, params?: Params, opts: QueryOpts = {}): UseQueryResult<T, ApiError> {
  const q = useQuery<T, ApiError>({
    queryKey: ['api', path, params ?? {}],
    queryFn: ({ signal }) => apiGet<T>(path, params, signal),
    enabled: opts.enabled ?? true,
    refetchInterval: opts.poll,
    placeholderData: opts.keep ? keepPreviousData : undefined,
    staleTime: opts.staleTime ?? (opts.poll ? 0 : 15_000),
  });
  const lastError = useRef<ApiError | null>(null);
  if (q.data !== undefined) lastError.current = null;
  else if (q.error) lastError.current = q.error;
  if (q.data === undefined && q.isPending && lastError.current && (opts.enabled ?? true)) {
    return { ...q, isPending: false, isLoading: false, isError: true, status: 'error', error: lastError.current } as unknown as UseQueryResult<T, ApiError>;
  }
  return q;
}
