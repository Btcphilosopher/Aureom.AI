import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiError, apiGet, apiPost, asItem, asItems, asTotal, buildUrl, metaOf } from './client';

afterEach(() => vi.unstubAllGlobals());

const jsonRes = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

describe('buildUrl', () => {
  it('prefixes /api/v1 and drops empty params', () => {
    expect(buildUrl('/q/products', { q: 'milk', category: '', status: undefined, limit: 50, low: false })).toBe('/api/v1/q/products?q=milk&limit=50');
    expect(buildUrl('network')).toBe('/api/v1/network');
    expect(buildUrl('/x', { prove: true })).toBe('/api/v1/x?prove=1');
    expect(buildUrl('/x', { n: 0 })).toBe('/api/v1/x?n=0');
  });
});

describe('response normalisers', () => {
  it('reads items from wrapped and bare lists', () => {
    expect(asItems<number>({ items: [1, 2], total: 9 })).toEqual([1, 2]);
    expect(asItems<number>([1, 2, 3])).toEqual([1, 2, 3]);
    expect(asItems(undefined)).toEqual([]);
    expect(asTotal({ items: [1], total: 9 })).toBe(9);
    expect(asTotal([1, 2])).toBe(2);
  });
  it('reads item and meta', () => {
    expect(asItem<{ a: number }>({ item: { a: 1 } })).toEqual({ a: 1 });
    expect(asItem<{ a: number }>({ a: 2 })).toEqual({ a: 2 });
    expect(metaOf({ meta: { lag_blocks: 3 } })).toEqual({ lag_blocks: 3 });
  });
});

describe('apiGet / apiPost', () => {
  it('returns parsed JSON', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonRes({ ok: 1 })));
    await expect(apiGet('/network')).resolves.toEqual({ ok: 1 });
  });
  it('turns gateway errors into ApiError with the code', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonRes({ error: 'sale not found', code: 'NOT_FOUND' }, 404)));
    const err = await apiGet('/q/sales/x').catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err).toMatchObject({ status: 404, code: 'NOT_FOUND', message: 'sale not found', unreachable: false });
  });
  it('flags an unreachable gateway', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    const err = (await apiGet('/network').catch((e) => e)) as ApiError;
    expect(err.unreachable).toBe(true);
    expect(err.status).toBe(0);
  });
  it('rejects a non-JSON 200 (wrong base URL / SPA fallback)', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('<html></html>', { status: 200 })));
    await expect(apiGet('/network')).rejects.toMatchObject({ code: 'BAD_RESPONSE' });
  });
  it('posts with a JSON body', async () => {
    const f = vi.fn().mockResolvedValue(jsonRes({ started: true }));
    vi.stubGlobal('fetch', f);
    await apiPost('/projection/rebuild');
    expect(f.mock.calls[0][0]).toBe('/api/v1/projection/rebuild');
    expect(f.mock.calls[0][1].method).toBe('POST');
  });
});
