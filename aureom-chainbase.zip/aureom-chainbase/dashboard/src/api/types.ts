// Types for the gateway REST contract (docs/API.md) and the on-chain record shapes
// (chain/internal/core/types.go). Fields the gateway may omit are optional so the UI
// degrades gracefully rather than crashing on a missing key.

export interface ProjectionMeta {
  indexed_height: number;
  chain_head: number;
  lag_blocks: number;
  projection_state?: 'OK' | 'REBUILDING' | 'EMPTY' | string;
}

export interface ListResponse<T> {
  meta?: ProjectionMeta;
  items: T[];
  total?: number;
}
export interface ItemResponse<T> {
  meta?: ProjectionMeta;
  item: T;
}

export interface RecordMeta {
  version: number;
  schema_version: number;
  created_height: number;
  updated_height: number;
  created_tx: string;
  updated_tx: string;
}

export interface Provenance {
  origin: 'NATIVE' | 'IMPORTED' | string;
  source_system?: string;
  source_id?: string;
  batch_id?: string;
  mapping_version?: string;
  snapshot_id?: string;
}

export type Extras = Record<string, string>;

export interface Product extends Partial<RecordMeta> {
  id: string;
  name: string;
  brand?: string;
  category?: string;
  status: string;
  attributes?: Record<string, string>;
  source_extras?: Extras;
  skus: string[] | Sku[];
  /** The gateway embeds the full SKU records here (skus stays a list of ids). */
  sku_details?: Sku[];
  provenance?: Provenance;
}

export interface Sku extends Partial<RecordMeta> {
  id: string;
  product_id: string;
  barcode?: string;
  unit: string;
  scarce: boolean;
  status: string;
  attributes?: Record<string, string>;
  source_extras?: Extras;
  provenance?: Provenance;
}

export interface Location extends Partial<RecordMeta> {
  id: string;
  name: string;
  kind: string;
  region: string;
  currency: string;
  status: string;
  source_extras?: Extras;
  provenance?: Provenance;
}

export interface Supplier extends Partial<RecordMeta> {
  id: string;
  name: string;
  status: string;
  terms?: string;
  region?: string;
  source_extras?: Extras;
  provenance?: Provenance;
}

export interface Qty {
  v: number;
  unit: string;
}

export interface POLine {
  line_no: number;
  sku: string;
  qty: Qty;
  unit_cost_minor: number;
  received_v: number;
}

export interface PurchaseOrder extends Partial<RecordMeta> {
  id: string;
  supplier_id: string;
  location_id: string;
  currency: string;
  lines: POLine[];
  total_minor: number;
  status: string;
  created_by: string;
  approved_by?: string;
  ordered_at_ms: number;
  receipts?: string[];
  provenance?: Provenance;
}

export interface GoodsReceipt extends Partial<RecordMeta> {
  id: string;
  po_id?: string;
  supplier_id?: string;
  location_id: string;
  lines: { sku: string; qty: Qty; po_line?: number }[];
  effective_at_ms: number;
  received_by: string;
  reversed: boolean;
}

export interface InventoryRow {
  sku: string;
  loc: string;
  product_name?: string;
  available: number;
  reserved: number;
  quarantined: number;
  damaged: number;
  on_hand: number;
  in_transit_in?: number;
  in_transit_out?: number;
  version?: number;
  unit?: string;
  product_id?: string;
  location_name?: string;
}

export interface InventoryException {
  kind: string;
  severity: string;
  ref: string;
  detail: string;
  location?: string;
  sku?: string;
}

export interface Movement {
  seq: number;
  sku: string;
  from_loc: string;
  from_bucket: string;
  to_loc: string;
  to_bucket: string;
  qty: number;
  reason: string;
  ref_type: string;
  ref_id: string;
  tx_id: string;
  height: number;
  effective_at_ms: number;
  origin: string;
}

export interface Reservation extends Partial<RecordMeta> {
  id: string;
  sku: string;
  loc: string;
  qty: number;
  unit: string;
  status: string;
  allowance: boolean;
  holder: string;
  terminal_id?: string;
  expires_at_ms: number;
  sale_id?: string;
  consumed_v: number;
}

export interface PricingStep {
  promo_id: string;
  promo_version: number;
  type: string;
  before_minor: number;
  discount_minor: number;
  after_minor: number;
  explain: string;
}

export interface SaleLine {
  line_no: number;
  sku: string;
  qty: Qty;
  reservation_id?: string;
  price_id: string;
  price_version: number;
  unit_minor: number;
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  pricing_steps: PricingStep[];
  returned_v: number;
  returning_v: number;
  refund_committed_minor: number;
}

export interface PaymentEvent {
  provider: string;
  event_id: string;
  provider_ref: string;
  result: string;
  amount_minor: number;
  tx_id: string;
  height: number;
}

export interface Sale extends Partial<RecordMeta> {
  id: string;
  loc: string;
  channel: string;
  terminal_id?: string;
  customer_id?: string;
  currency: string;
  lines: SaleLine[];
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  effective_at_ms: number;
  block_time_ms: number;
  rules_version: number;
  sale_status: string;
  payment_status: string;
  fulfilment_status: string;
  payment_method: string;
  paid_minor: number;
  refund_instructed_minor: number;
  refund_confirmed_minor: number;
  payment_events?: PaymentEvent[];
  loyalty_entry?: string;
  provenance?: Provenance;
  source_extras?: Extras;
}

export interface SalesSummaryRow {
  bucket: string;
  sales: number;
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  paid_minor: number;
  refunded_minor: number;
}

export interface ReturnLine {
  line_no: number;
  qty_v: number;
  reason: string;
  received_v: number;
  inspection?: string;
  refund_minor: number;
}
export interface Return extends Partial<RecordMeta> {
  id: string;
  sale_id: string;
  loc: string;
  lines: ReturnLine[];
  status: string;
  requested_by: string;
  decided_by?: string;
  override_reason?: string;
  refunds?: string[];
}
export interface Refund extends Partial<RecordMeta> {
  id: string;
  sale_id: string;
  return_id: string;
  amount_minor: number;
  currency: string;
  status: string;
  provider?: string;
  provider_ref?: string;
}

export interface PriceRecord extends Partial<RecordMeta> {
  id: string;
  sku: string;
  loc: string;
  currency: string;
  unit_minor: number;
  effective_from_ms: number;
  effective_to_ms: number;
  seq: number;
}

export interface Promotion extends Partial<RecordMeta> {
  id: string;
  name: string;
  type: string;
  bp?: number;
  off_minor?: number;
  buy_n?: number;
  bundle_minor?: number;
  skus: string[];
  locs: string[];
  from_ms: number;
  to_ms: number;
  priority: number;
  stackable: boolean;
  loyalty_only: boolean;
  status: string;
  currency: string;
}

export interface LoyaltyAccount extends Partial<RecordMeta> {
  id: string;
  points: number;
  lifetime_earned: number;
  /** Entry count in lists; the account detail replaces it with the entries array. */
  entries: number | LoyaltyEntry[];
  status: string;
  provenance?: Provenance;
}
export interface LoyaltyEntry extends Partial<RecordMeta> {
  id: string;
  account: string;
  type: 'EARN' | 'REDEEM' | 'EXPIRE' | 'REVERSE' | 'OPENING' | string;
  points: number;
  sale_id?: string;
  refund_id?: string;
  reverses?: string;
  reversed_points: number;
  shortfall_points?: number;
  value_minor?: number;
  effective_at_ms: number;
  rule: string;
  provenance?: Provenance;
}

export interface Adjustment extends Partial<RecordMeta> {
  id: string;
  sku: string;
  loc: string;
  bucket: string;
  balance_version_at_count: number;
  system_qty: number;
  counted_qty: number;
  delta: number;
  reason: string;
  evidence_ref: string;
  status: string;
  proposer: string;
  decider?: string;
}

export interface TransferLine {
  sku: string;
  sent_v: number;
  received_v: number;
  damaged_v: number;
  unit: string;
}
export interface Transfer extends Partial<RecordMeta> {
  id: string;
  from: string;
  to: string;
  lines: TransferLine[];
  status: string;
}

export interface ExceptionRec extends Partial<RecordMeta> {
  id: string;
  kind: string;
  ref: string;
  detail: string;
  status: string;
  resolution?: string;
  resolved_by?: string;
}

export interface KeyRec {
  key_id: string;
  pub_b64: string;
  status: 'ACTIVE' | 'REVOKED' | 'ROTATED' | string;
  from_height: number;
  to_height: number;
}
export interface RoleGrant {
  role: string;
  scope: string;
  granted_height: number;
  granted_by: string;
}
export interface Identity extends Partial<RecordMeta> {
  id: string;
  org: string;
  kind: string;
  keys: KeyRec[];
  status: string;
  bound_location?: string;
  grants?: RoleGrant[] | { identity?: string; grants: RoleGrant[] };
}

export interface TxRow {
  id?: string;
  tx_id?: string;
  type: string;
  signer: string;
  status: 'OK' | 'REJECTED' | string;
  code: number;
  code_name: string;
  reason?: string;
  height: number;
  index?: number;
  block_time_ms: number;
  client_time_ms?: number;
  idempotency_ref?: string;
}

export interface Member {
  id: string;
  org: string;
  kind: string;
  role: string;
  consensus_pubkey_b64?: string;
  node_id: string;
  power: number;
  status: string;
  added_height: number;
  removed_height?: number;
  history?: string[];
}

export interface Proposal extends Partial<RecordMeta> {
  id: string;
  kind: string;
  payload?: unknown;
  proposer: string;
  activation_height: number;
  status: string;
  approvals: string[];
  approved_height: number;
  executed_height: number;
  result?: string;
}

export interface Upgrade {
  version: number;
  activation_height: number;
  proposal?: string;
  status: string;
}

export interface Params {
  max_tx_bytes: number;
  max_import_tx_bytes: number;
  max_lines: number;
  max_import_records: number;
  max_future_skew_ms: number;
  max_backdate_ms: number;
  min_gov_delay_blocks: number;
  min_upgrade_delay_blocks: number;
  min_validators: number;
  po_local_limit_minor: number;
  adjust_small_units: number;
  return_local_limit_minor: number;
  return_window_ms: number;
  reservation_max_ttl_ms: number;
  allowance_max_ttl_ms: number;
  loyalty_point_value_minor: number;
  [k: string]: number;
}

export interface GovEvent {
  height?: number;
  block_time_ms?: number;
  tx_id?: string;
  tx_type?: string;
  signer?: string;
  /** State key the event changed, e.g. iam/id/cashier-s01 or gov/member/val-hq. */
  key?: string;
  summary?: string;
  kind?: string;
  type?: string;
  subject?: string;
  detail?: string;
  [k: string]: unknown;
}

export interface Governance {
  meta?: ProjectionMeta;
  members: Member[];
  proposals: Proposal[];
  upgrades: Upgrade[];
  params: Partial<Params>;
  events: GovEvent[];
}

export interface MigrationState extends Partial<RecordMeta> {
  status: 'NOT_STARTED' | 'OPEN' | 'CLOSED' | string;
  source_system: string;
  opened_height: number;
  closed_height: number;
  batches: number;
  records: number;
  open_manifest_hash?: string;
  reconciliation_report_hash?: string;
  chain_counters: Record<string, number>;
  attested_totals?: Record<string, number>;
  source_freeze_marker?: string;
}
export interface MigrationBatch {
  id?: string;
  batch_id?: string;
  entity?: string;
  seq?: number;
  records?: number;
  tx_id?: string;
  height?: number;
  status?: string;
  [k: string]: unknown;
}

export interface QStats {
  products?: number;
  skus?: number;
  locations?: number;
  sales_today?: number;
  sales_total?: number;
  open_exceptions?: number;
  rejected_tx_24h?: number;
  tx_total?: number;
  active_reservations?: number;
  loyalty_points_outstanding?: number;
  [k: string]: unknown;
}

// ---- Network / explorer ----

export interface ValidatorInfo {
  name: string;
  org: string;
  role: string;
  node_id?: string;
  rpc_url?: string;
  reachable: boolean;
  height: number;
  catching_up: boolean;
  peers: number;
  latency_ms: number;
  voting_power: number;
  consensus_pubkey?: string;
  app_hash?: string;
  agrees_with_majority: boolean;
  last_signed_height: number;
}

export interface NetworkInfo {
  network_id: string;
  app_version: number;
  chain: { latest_height: number; latest_block_time: string; latest_app_hash: string; block_interval_ms_avg?: number };
  bft: {
    validators: number;
    voting_power_total: number;
    f: number;
    quorum_power_required: number;
    online_power: number;
    online_validators: number;
    status: 'HEALTHY' | 'DEGRADED' | 'HALTED' | string;
    explanation?: string;
    tolerance?: string;
  };
  validators: ValidatorInfo[];
  members?: Member[];
  mempool?: { unconfirmed_txs: number };
  queried_at?: string;
}

export interface BlockSummary {
  height: number;
  time: string;
  hash: string;
  app_hash: string;
  proposer: string;
  num_txs: number;
  num_rejected: number;
  size_bytes: number;
}

export interface BlockTx {
  index?: number;
  tx_id?: string;
  type?: string;
  signer?: string;
  /** Absent when the gateway could not fetch block results. */
  code?: number;
  code_name?: string;
  log?: string;
  hash: string;
  size?: number;
  decode_error?: string;
}

export interface CommitSignature {
  validator: string;
  validator_name: string;
  signed: boolean;
  power: number;
}

export interface BlockDetail extends Partial<BlockSummary> {
  height: number;
  time: string;
  hash: string;
  /** Present in real gateway output instead of app_hash / num_txs / size_bytes. */
  header_app_hash?: string;
  state_app_hash_after_block?: string;
  proposer_address?: string;
  txs: BlockTx[];
  commit?: {
    round: number;
    signatures: CommitSignature[];
    signed_power: number;
    total_power: number;
    finality_verified: boolean;
  };
  [k: string]: unknown;
}

export interface VerifyFinality {
  height: number;
  verified: boolean;
  method: string;
  trusted_height?: number;
  signed_power: number;
  total_power: number;
  quorum_required: number;
  validators_signed?: string[];
  app_hash_next_header?: string;
  block_hash?: string;
  header_app_hash?: string;
  note?: string;
  error?: string;
}

export interface ProofInfo {
  type: string;
  proof_b64: string;
  app_hash_height: number;
  app_hash: string;
}

export interface ProofResponse {
  record?: ChainRecord;
  explanation?: string[];
}

export interface ChainRecord {
  key: string;
  found: boolean;
  value?: unknown;
  height: number;
  proof?: ProofInfo;
  verification?: { proof_valid: boolean; header_verified: boolean; statement: string };
  explanation?: string[];
}

export interface ExplorerTx {
  tx_id?: string;
  hash?: string;
  type?: string;
  signer?: string;
  body?: unknown;
  decoded?: unknown;
  signature?: { valid?: boolean; ok?: boolean; algorithm?: string; pub?: string; key_id?: string; detail?: string; [k: string]: unknown };
  signature_check?: { valid?: boolean; ok?: boolean; [k: string]: unknown };
  result?: { code: number; code_name?: string; log?: string; status?: string; [k: string]: unknown };
  inclusion?: { height: number; index: number };
  inclusion_proof?: { valid?: boolean; verified?: boolean; [k: string]: unknown };
  changed_records?: string[];
  records_changed?: string[];
  [k: string]: unknown;
}

export interface SearchHit {
  kind: string;
  id?: string;
  key?: string;
  height?: number;
  label?: string;
  summary?: string;
  [k: string]: unknown;
}

export interface ProjectionStatus {
  state: 'OK' | 'REBUILDING' | 'EMPTY' | string;
  indexed_height: number;
  chain_head: number;
  lag_blocks: number;
  lag_seconds?: number;
  entries?: number;
  digest?: string;
  last_block_time?: string;
  last_indexed_block_time?: string;
  digest_height?: number;
  storage?: string;
  rebuild?: { started_at?: string; finished_at?: string | null; blocks_replayed?: number; duration_ms?: number } | null;
}

export interface ProjectionVerify {
  height: number;
  projection_digest: string;
  chain_digest: string;
  match: boolean;
  entries?: number;
  projection_entries?: number;
  chain_entries?: number;
  proofs_checked?: number;
  proofs_valid?: number;
  proof_failures?: string[];
  statement?: string;
}

export interface LatencyStats {
  p50: number;
  p95: number;
  p99: number;
  max: number;
}
export interface LatencyRecent {
  tx_id: string;
  type: string;
  admission_ms: number;
  finality_ms: number;
  code: number;
  at: string | number;
}
export interface LatencyMetrics {
  count: number;
  admission_ms: LatencyStats;
  finality_ms: LatencyStats;
  recent: LatencyRecent[];
  rejected_recent?: {
    tx_id: string;
    type?: string;
    signer?: string;
    code?: number;
    code_name?: string;
    reason?: string;
    stage?: string;
    at?: string | number;
  }[];
}

// ---- Migration report (off-chain) ----

export interface ReportCheck {
  name: string;
  source: number | string | null;
  chain: number | string | null;
  delta: number | string | null;
  status: 'PASS' | 'FAIL' | 'WARN' | string;
  detail?: string;
}
export interface ReportException {
  kind: string;
  source_ref: string;
  detail: string;
  disposition: string;
}
export interface UnsupportedField {
  table: string;
  column: string;
  rows: number;
  treatment: string;
}
export interface ReportBatch {
  batch_id: string;
  entity: string;
  seq: number;
  records: number;
  tx_id: string;
  height: number;
  status: string;
}
export interface MigrationReport {
  id: string;
  phase: 'trial' | 'master' | 'opening' | 'final' | string;
  trial: boolean;
  network_id?: string;
  generated_at: string;
  snapshot_id?: string;
  snapshot_sha256?: string;
  mapping_version?: string;
  source_system?: string;
  authoritative_system?: 'SOURCE' | 'FROZEN' | 'CHAIN' | string;
  checks: ReportCheck[];
  exceptions: ReportException[];
  unsupported_fields: UnsupportedField[];
  batches: ReportBatch[];
  decision: 'ACCEPT' | 'REJECT' | string;
  notes?: string;
}
export interface ReportListRow {
  id: string;
  phase: string;
  trial: boolean;
  generated_at: string;
  decision: string;
  sha256: string;
}
