import { lazy, Suspense } from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import { Shell } from './layout/Shell';
import { LoadingBlock } from './ui/States';

const Overview = lazy(() => import('./pages/Overview'));
const Network = lazy(() => import('./pages/Network'));
const Products = lazy(() => import('./pages/Products'));
const Inventory = lazy(() => import('./pages/Inventory'));
const Sales = lazy(() => import('./pages/Sales'));
const SaleDetail = lazy(() => import('./pages/SaleDetail'));
const Suppliers = lazy(() => import('./pages/Suppliers'));
const Prices = lazy(() => import('./pages/Prices'));
const Loyalty = lazy(() => import('./pages/Loyalty'));
const Migration = lazy(() => import('./pages/Migration'));
const MigrationReport = lazy(() => import('./pages/MigrationReport'));
const Explorer = lazy(() => import('./pages/Explorer'));
const Administration = lazy(() => import('./pages/Administration'));

function NotFound() {
  return (
    <div className="page">
      <div className="card"><div className="state"><div className="state-title">Page not found</div><Link to="/">Back to Overview</Link></div></div>
    </div>
  );
}

export function App() {
  return (
    <Suspense fallback={<div className="page"><div className="card"><LoadingBlock rows={6} label="Loading page…" /></div></div>}>
      <Routes>
        <Route element={<Shell />}>
          <Route index element={<Overview />} />
          <Route path="network" element={<Network />} />
          <Route path="products" element={<Products />} />
          <Route path="inventory" element={<Inventory />} />
          <Route path="sales" element={<Sales />} />
          <Route path="sales/:id" element={<SaleDetail />} />
          <Route path="suppliers" element={<Suppliers />} />
          <Route path="prices" element={<Prices />} />
          <Route path="loyalty" element={<Loyalty />} />
          <Route path="loyalty/:id" element={<Loyalty />} />
          <Route path="migration" element={<Migration />} />
          <Route path="migration/reports/:id" element={<MigrationReport />} />
          <Route path="explorer/*" element={<Explorer />} />
          <Route path="administration" element={<Administration />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Suspense>
  );
}
