// Mock AUREOM CHAINBASE gateway: plain node http, no framework. Implements the endpoints of
// docs/API.md that the dashboard uses, with rich synthetic data (see data.ts).
//   npm run mock           -> http://127.0.0.1:8083  (also serves ../dist with SPA fallback if built)
//   POST /__mock/scenario  {"name":"normal|degraded|halted|lag|lagbad|rebuilding|empty|down"}
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BLOCK_MS, NETWORK_ID, buildDataset, sha256, type Rec, type Tx } from './data';

const PORT = Number(process.env.PORT ?? 8083);
const HOST = process.env.HOST ?? '127.0.0.1';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.resolve(HERE, '..', 'dist');

const D = buildDataset();
let scenario = 'normal';
let haltedAt = 0;
let timeBase = D.bootTime;
let rebuild: { start: number; durationMs: number; blocks: number } | null = null;
let lastRebuild: { started_at: string; finished_at?: string; blocks_replayed: number; duration_ms: number } | null = null;

// ---------------- chain clock ----------------
const liveHead = (t = Date.now()) => D.H0 + Math.max(0, Math.floor((t - timeBase) / BLOCK_MS));
const head = () => (scenario === 'halted' && haltedAt ? haltedAt : liveHead());
const blockTime = (h: number) => (h <= D.H0 ? D.blockTime(h) : timeBase + (h - D.H0) * BLOCK_MS);

function setScenario(name: string) {
  const prev = scenario;
  if (name === 'halted' && prev !== 'halted') haltedAt = liveHead();
  if (prev === 'halted' && name !== 'halted') timeBase = Date.now() - (haltedAt - D.H0) * BLOCK_MS;
  scenario = name;
  if (name === 'rebuilding') rebuild = null;
}

// ---------------- derived chain data ----------------
const okPrefix: number[] = [0];
for (let h = 1; h <= D.H0; h++) okPrefix[h] = okPrefix[h - 1] + (D.txsByHeight.get(h) ?? []).filter((t) => t.code === 0).length;
const appHashAt = (h: number) => sha256(`app|${okPrefix[Math.min(h, D.H0)] ?? 0}|${D.H0 > 0 ? 'x' : ''}`);
const blockHash = (h: number) => sha256(`block|${h}`);
const VALS = D.members;
const valAddr = (id: string) => sha256('addr' + id).slice(0, 40);
const proposerOf = (h: number) => VALS[h % VALS.length].id;
const missed = (h: number, valId: string) => (valId === 'val-south' && (h === 77 || h === 78 || (scenario === 'degraded' && h > head() - 40))) || (valId === 'val-north' && scenario === 'halted' && h > haltedAt - 20);

function blockSummary(h: number) {
  const txs = D.txsByHeight.get(h) ?? [];
  return { height: h, time: new Date(blockTime(h)).toISOString(), hash: blockHash(h), app_hash: appHashAt(h), proposer: proposerOf(h), num_txs: txs.length, num_rejected: txs.filter((t) => t.code !== 0).length, size_bytes: 420 + txs.reduce((a, t) => a + JSON.stringify(t.body).length, 0) };
}

function blockDetail(h: number) {
  const txs = D.txsByHeight.get(h) ?? [];
  const sigs = VALS.map((v) => ({ validator: valAddr(v.id), validator_name: v.id, signed: !missed(h, v.id), power: v.power }));
  const signedPower = sigs.filter((s) => s.signed).reduce((a, s) => a + s.power, 0);
  // same field set as the real gateway (/explorer/block): no num_txs / size_bytes / app_hash on this endpoint
  return {
    height: h, time: new Date(blockTime(h)).toISOString(), hash: blockHash(h), chain_id: NETWORK_ID,
    proposer: proposerOf(h), proposer_address: valAddr(proposerOf(h)),
    header_app_hash: appHashAt(h - 1), state_app_hash_after_block: appHashAt(h),
    validators_hash: sha256('vals'), data_hash: sha256('data' + h), app_version: 1,
    txs: txs.map((t, i) => ({ index: i, hash: t.hash, size: JSON.stringify(t.body).length, tx_id: t.tx_id, type: t.type, signer: t.signer, code: t.code, code_name: t.code_name, log: t.reason })),
    commit: { round: 0, signatures: sigs, signed_power: signedPower, total_power: 40, finality_verified: h < head() && signedPower * 3 > 40 * 2 },
  };
}

function validatorStatus() {
  const h = head();
  return VALS.map((v, i) => {
    const down = (scenario === 'degraded' && v.id === 'val-south') || (scenario === 'halted' && (v.id === 'val-south' || v.id === 'val-north'));
    return {
      name: v.id, org: v.org, role: v.role, node_id: v.node_id, rpc_url: `http://127.0.0.1:${29601 + i * 10}`, reachable: !down, height: down ? Math.max(1, h - (scenario === 'halted' ? 22 : 31)) : h, catching_up: false,
      peers: down ? 0 : 3 - (scenario === 'halted' ? 1 : 0), latency_ms: down ? 0 : 2 + i * 2 + (h % 3), voting_power: v.power, consensus_pubkey: v.consensus_pubkey_b64, app_hash: down ? appHashAt(Math.max(1, h - 30)) : appHashAt(h), agrees_with_majority: true, last_signed_height: down ? Math.max(1, h - 32) : h - (i === 3 ? 1 : 0),
    };
  });
}

function networkBody() {
  const vs = validatorStatus();
  const online = vs.filter((v) => v.reachable);
  const onlinePower = online.reduce((a, v) => a + v.voting_power, 0);
  const status = onlinePower >= 27 ? (online.length === vs.length ? 'HEALTHY' : 'DEGRADED') : 'HALTED';
  const explanation = status === 'HEALTHY' ? 'All 4 validators are online and agree on the latest state. Up to 1 validator can fail without stopping the chain.' : status === 'DEGRADED' ? `${vs.length - online.length} validator offline. Online voting power ${onlinePower} of 40 is still above the quorum of 27, so blocks continue to finalise, but no further failure can be tolerated.` : `Only ${onlinePower} of 40 voting power online; quorum (27) is not reachable. The chain is halted: no new block can be finalised until validators return. Nothing forks.`;
  return {
    network_id: NETWORK_ID, app_version: 1,
    chain: { latest_height: head(), latest_block_time: new Date(blockTime(head())).toISOString(), latest_app_hash: appHashAt(head()) },
    bft: { validators: 4, voting_power_total: 40, f: 1, quorum_power_required: 27, online_power: onlinePower, online_validators: online.length, status, explanation, tolerance: 'n=4 validators tolerate f=1 Byzantine/failed (n >= 3f+1). Finality needs > 2/3 of voting power.' },
    validators: vs, members: D.members, mempool: { unconfirmed_txs: scenario === 'halted' ? 14 : head() % 4 === 0 ? 2 : 0 }, queried_at: new Date().toISOString(),
  };
}

// ---------------- projection ----------------
function projection() {
  const h = head();
  let state = 'OK';
  let indexed = h - (Math.floor(Date.now() / 3000) % 4 === 0 ? 1 : 0);
  if (scenario === 'lag') indexed = h - 7;
  if (scenario === 'lagbad') indexed = h - 18;
  if (scenario === 'rebuilding') { state = 'REBUILDING'; indexed = Math.floor(h * 0.45); }
  if (scenario === 'empty') { state = 'EMPTY'; indexed = 0; }
  if (rebuild) {
    const p = Math.min(1, (Date.now() - rebuild.start) / rebuild.durationMs);
    if (p < 1) { state = 'REBUILDING'; indexed = Math.floor(h * p); } else { lastRebuild = { started_at: new Date(rebuild.start).toISOString(), finished_at: new Date(rebuild.start + rebuild.durationMs).toISOString(), blocks_replayed: rebuild.blocks, duration_ms: rebuild.durationMs }; rebuild = null; }
  }
  indexed = Math.max(0, Math.min(indexed, h));
  return { state, indexed_height: indexed, chain_head: h, lag_blocks: h - indexed, projection_state: state };
}
const meta = () => { const p = projection(); return { indexed_height: p.indexed_height, chain_head: p.chain_head, lag_blocks: p.lag_blocks, projection_state: p.state }; };
const empty = () => projection().state === 'EMPTY';
const digestAt = (h: number) => sha256(`digest|${D.state.size}|${okPrefix[Math.min(h, D.H0)] ?? 0}`);

// ---------------- helpers ----------------
type Q = URLSearchParams;
function paged<T>(q: Q, rows: T[]) {
  const limit = Math.min(500, Math.max(1, Number(q.get('limit') ?? 50)));
  const offset = Math.max(0, Number(q.get('offset') ?? 0));
  const src = empty() ? [] : rows;
  return { meta: meta(), items: src.slice(offset, offset + limit), total: src.length };
}
const has = (s: unknown, t: string) => String(s ?? '').toLowerCase().includes(t.toLowerCase());
const eq = (v: string | null, x: unknown) => !v || String(x) === v;
const num = (v: string | null) => (v === null || v === '' ? undefined : Number(v));

function recordAt(key: string, h?: number): { found: boolean; value?: Rec; height: number } {
  const cur = head();
  const at = Math.min(h ?? cur, cur);
  const hist = D.history.get(key);
  if (hist && hist.length) {
    const vs = hist.filter((v) => v.height <= at).sort((a, b) => a.version - b.version);
    const v = vs[vs.length - 1];
    if (!v || v.deleted) return { found: false, height: at };
    return { found: true, value: v.value, height: at };
  }
  const rec = D.state.get(key);
  if (!rec) return { found: false, height: at };
  if (typeof rec.created_height === 'number' && rec.created_height > at) return { found: false, height: at };
  return { found: true, value: rec, height: at };
}

function chainRecord(key: string, h: number | undefined, prove: boolean) {
  const r = recordAt(key, h);
  const body: Rec = { key, found: r.found, height: r.height };
  if (r.found) body.value = r.value;
  if (prove) {
    body.proof = { type: 'ics23:iavl', proof_b64: Buffer.from(sha256(`proof|${key}|${r.height}|${r.found}`) + sha256(key).slice(0, 24)).toString('base64'), app_hash_height: r.height + 1, app_hash: appHashAt(r.height) };
    body.verification = { proof_valid: true, header_verified: r.height < head(), statement: 'key/value is committed in the state whose root is in a +2/3-signed header; this alone does not establish business correctness or search completeness' };
    if (!r.found) body.verification.statement = 'key is provably absent from the committed state (non-membership proof); this alone does not establish business correctness or search completeness';
  }
  return body;
}

function explanation(key: string, found: boolean, h: number): string[] {
  return [
    `Asked validator val-hq for "${key}" at height ${h} with ABCI query prove=true.`,
    found ? 'Received the value and an ICS23 existence proof from the IAVL state tree.' : 'The key is absent, so the validator returned an ICS23 non-membership proof (the neighbouring keys prove nothing lies between them).',
    `Recomputed the Merkle root from the ${found ? 'key, value and' : 'neighbouring keys and'} proof path: root ${appHashAt(h).slice(0, 16)}…`,
    `Compared it with the app_hash carried in the header of block ${h + 1}. That header was verified by the light client (signed by more than ⅔ of voting power, rooted in the genesis validator set).`,
    found ? 'Result: this key held exactly this value in the committed state at that height.' : 'Result: this key did not exist in the committed state at that height.',
  ];
}

// ---------------- sales helpers ----------------
const dayKey = (ms: number) => new Date(ms).toISOString().slice(0, 10);
const startOfToday = () => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); return d.getTime(); };

function salesFiltered(q: Q) {
  const from = num(q.get('from'));
  const to = num(q.get('to'));
  return D.sales.filter((s) => (from === undefined || s.effective_at_ms >= from) && (to === undefined || s.effective_at_ms <= to) && eq(q.get('location'), s.loc) && eq(q.get('payment_status'), s.payment_status) && eq(q.get('customer'), s.customer_id));
}

function inventoryExceptions() {
  const out: Rec[] = [];
  for (const e of D.exceptions.filter((x) => x.status === 'OPEN' && x.kind === 'TRANSFER_DISCREPANCY')) {
    const x = D.transfers.find((t) => `xfer/${t.id}` === e.ref)!;
    out.push({ kind: 'TRANSFER_DISCREPANCY', severity: 'HIGH', ref: e.ref, detail: e.detail, location: x?.to, sku: x?.lines[0]?.sku });
  }
  for (const t of D.transfers.filter((x) => x.status === 'IN_TRANSIT')) out.push({ kind: 'STUCK_IN_TRANSIT', severity: 'MEDIUM', ref: `xfer/${t.id}`, detail: `Dispatched from ${t.from} and not received at ${t.to} after more than 2 hours`, location: t.to, sku: t.lines[0].sku });
  for (const r of D.reservations.filter((x) => x.status === 'ACTIVE' && x.expires_at_ms < Date.now() + 5 * 60_000)) out.push({ kind: 'RESERVATION_EXPIRING', severity: 'LOW', ref: `resv/${r.id}`, detail: `Reservation of ${r.qty} held by ${r.holder} expires in under 5 minutes`, location: r.loc, sku: r.sku });
  for (const b of D.balances.filter((x) => x.available <= 0 && x.reserved > 0)) out.push({ kind: 'RESERVED_BEYOND_AVAILABLE', severity: 'HIGH', ref: `bal/${b.sku}/${b.loc}`, detail: 'All stock is reserved; nothing left available to sell', location: b.loc, sku: b.sku });
  for (const a of D.adjustments.filter((x) => x.status === 'PENDING' && Math.abs(x.delta) > 10)) out.push({ kind: 'ADJUSTMENT_AWAITING_APPROVAL', severity: 'MEDIUM', ref: `adjust/${a.id}`, detail: `Stock correction of ${a.delta} proposed by ${a.proposer} is awaiting a manager with wider scope`, location: a.loc, sku: a.sku });
  return out;
}

function stats() {
  const today = startOfToday();
  const last24 = Date.now() - 86_400_000;
  const sales24 = D.sales.filter((s) => s.effective_at_ms >= last24);
  return {
    products: D.products.length, skus: D.skus.length, locations: D.locations.length, suppliers: D.suppliers.length,
    sales_total: D.sales.length, sales_native: D.sales.filter((s) => s.provenance.origin === 'NATIVE').length,
    open_exceptions: D.exceptions.filter((e) => e.status === 'OPEN').length,
    transactions_total: D.txs.length, transactions_rejected: D.txs.filter((t) => t.code !== 0).length, transactions_rejected_24h: D.txs.filter((t) => t.code !== 0).length,
    active_reservations: D.reservations.filter((r) => r.status === 'ACTIVE').length,
    loyalty_points_outstanding: D.loyaltyAccounts.reduce((a, l) => a + l.points, 0),
    units_on_hand: D.balances.reduce((a, b) => a + b.on_hand, 0),
    sales_net_minor_24h: sales24.reduce((a, s) => a + s.net_minor, 0), refunded_minor_24h: sales24.reduce((a, s) => a + s.refund_confirmed_minor, 0), sales_24h: sales24.length,
    _today: today,
  };
}

// ---------------- routing ----------------
type Handler = (q: Q, params: string[], req: http.IncomingMessage) => unknown | Promise<unknown>;
const routes: { method: string; re: RegExp; h: Handler }[] = [];
const route = (method: string, pattern: string, h: Handler) => {
  const re = new RegExp('^' + pattern.replace(/:[a-z_]+\*/g, '(.+)').replace(/:[a-z_]+/g, '([^/]+)') + '$');
  routes.push({ method, re, h });
};
class HttpError extends Error { constructor(public status: number, msg: string, public code = '') { super(msg); } }
const notFound = (what: string) => new HttpError(404, `${what} not found`, 'NOT_FOUND');
const dec = decodeURIComponent;

route('GET', '/api/v1/health', () => ({ status: 'ok', network_id: NETWORK_ID, mock: true }));
route('GET', '/api/v1/network', () => networkBody());
route('GET', '/api/v1/chain/info', () => ({ height: head(), app_hash: appHashAt(head()), app_version: 1, chain_id: NETWORK_ID, max_supported_version: 2 }));
route('GET', '/api/v1/chain/record', (q) => chainRecord(q.get('key') ?? '', num(q.get('height')), q.get('prove') === '1'));
route('GET', '/api/v1/chain/records/:kind/:id', (q, p) => {
  const prefix: Record<string, string> = { product: 'product/', sku: 'sku/', location: 'loc/', supplier: 'supplier/', po: 'po/', receipt: 'receipt/', reservation: 'resv/', sale: 'sale/', return: 'return/', refund: 'refund/', price: 'price/', promotion: 'promo/', loyalty: 'loy/', 'loyalty-entry': 'loye/', adjustment: 'adjust/', transfer: 'xfer/', exception: 'exc/', identity: 'iam/id/', grants: 'iam/grants/', tx: 'tx/', member: 'gov/member/', proposal: 'gov/prop/' };
  if (!prefix[p[0]]) throw new HttpError(400, `unknown kind ${p[0]}`, 'BAD_REQUEST');
  return chainRecord(prefix[p[0]] + dec(p[1]), num(q.get('height')), q.get('prove') === '1');
});
route('GET', '/api/v1/chain/scan', (q) => {
  const prefix = q.get('prefix') ?? '';
  const after = q.get('after') ?? '';
  const limit = Math.min(500, Number(q.get('limit') ?? 200));
  const keys = Array.from(D.state.keys()).filter((k) => k.startsWith(prefix) && k > after).sort();
  const page = keys.slice(0, limit);
  return { height: head(), items: page.map((k) => ({ key: k, value: D.state.get(k) })), next_after: keys.length > limit ? page[page.length - 1] : '' };
});
route('GET', '/api/v1/chain/inventory', (q) => D.balances.filter((b) => eq(q.get('sku'), b.sku) && eq(q.get('location'), b.loc)).map((b) => ({ sku: b.sku, loc: b.loc, available: b.available, reserved: b.reserved, quarantined: b.quarantined, damaged: b.damaged, on_hand: b.on_hand, in_transit_out: b.in_transit_out, version: b.version })));
route('GET', '/api/v1/chain/digest', (q) => { const h = Math.min(num(q.get('height')) ?? head(), head()); return { height: h, app_hash: appHashAt(h), digest: digestAt(h), entries: D.state.size }; });
route('GET', '/api/v1/chain/migration', () => D.state.get('mig/state'));

// explorer
route('GET', '/api/v1/explorer/blocks', (q) => {
  const limit = Math.min(100, Number(q.get('limit') ?? 20));
  const before = num(q.get('before')) ?? head() + 1;
  const out = [];
  for (let h = Math.min(before - 1, head()); h >= 1 && out.length < limit; h--) out.push(blockSummary(h));
  return out;
});
route('GET', '/api/v1/explorer/block/:height', (_q, p) => {
  const h = Number(p[0]);
  if (!Number.isInteger(h) || h < 1 || h > head()) throw notFound(`block ${p[0]}`);
  return blockDetail(h);
});
const findTx = (id: string): Tx | undefined => D.txById.get(id) ?? D.txByHash.get(id.toLowerCase());
route('GET', '/api/v1/explorer/tx/:id', (q, p) => {
  const t = findTx(dec(p[0]));
  if (!t) throw notFound('transaction');
  const txsInBlock = D.txsByHeight.get(t.height) ?? [];
  // same shape as the real gateway: {record, hash, height, index, result, body, signature_check, records_changed, inclusion_proof}
  const out: Rec = {
    record: D.txRecords.find((r) => r.id === t.tx_id), hash: t.hash, height: t.height, index: t.index,
    result: { code: t.code, code_name: t.code_name, log: t.reason, data: null },
    body: t.body,
    signature_check: { valid: t.code !== 101, public_key: Buffer.from(sha256(t.signer + t.key_id)).toString('base64').slice(0, 44), note: 'cryptographic validity only; authorisation is a separate on-chain check' },
    records_changed: t.code === 0 ? t.keys.map((k) => ({ op: 'write', key: k })) : [],
  };
  if (q.get('include_proof') === '1') out.inclusion_proof = { root_hash: sha256('data' + t.height), total: txsInBlock.length, index: t.index, note: 'Merkle proof that the tx is in the block whose header data_hash equals root_hash' };
  return out;
});
route('GET', '/api/v1/explorer/verify-finality', (q) => {
  const h = num(q.get('height')) ?? 0;
  if (h < 1 || h > head()) throw notFound(`block ${h}`);
  const sigs = blockDetail(h).commit.signatures;
  const signed = sigs.filter((s) => s.signed);
  const power = signed.reduce((a, s) => a + s.power, 0);
  const ok = h < head() && power * 3 > 40 * 2;
  return { height: h, method: 'CometBFT light client (skipping verification), trust root = genesis validator set hash; witnesses = the other validators', verified: ok, signed_power: power, total_power: 40, quorum_required: 27, validators_signed: signed.map((s) => s.validator_name).sort(), block_hash: blockHash(h), header_app_hash: appHashAt(h - 1), note: 'header_app_hash at height H commits the state produced by block H-1; a Merkle proof for state at height H-1 verifies against it.', ...(h >= head() ? { error: 'block is the chain head: the next header (which carries the app hash) does not exist yet' } : {}) };
});
route('GET', '/api/v1/explorer/proof', (q) => {
  const key = q.get('key') ?? '';
  const h = num(q.get('height'));
  const rec = chainRecord(key, h, true);
  return { record: rec, explanation: explanation(key, rec.found, rec.height).map((s, i) => `${i + 1}. ${s}`) };
});
route('GET', '/api/v1/explorer/search', (q) => {
  const s = (q.get('q') ?? '').trim();
  const out: Rec[] = [];
  if (!s) return { query: s, results: [] };
  // real gateway: {type: block|record|tx, ref}
  if (/^\d+$/.test(s) && Number(s) >= 1 && Number(s) <= head()) out.push({ type: 'block', ref: Number(s) });
  const t = findTx(s);
  if (t) out.push({ type: 'tx', ref: t.tx_id });
  for (const x of D.txs) if (out.length < 12 && x.tx_id !== t?.tx_id && x.tx_id.toLowerCase().includes(s.toLowerCase())) out.push({ type: 'tx', ref: x.tx_id });
  for (const k of D.state.keys()) if (out.length < 24 && (k === s || k.endsWith('/' + s) || (s.length > 3 && k.toLowerCase().includes(s.toLowerCase())))) out.push({ type: 'record', ref: k });
  return { query: s, results: out };
});

// projection
route('GET', '/api/v1/projection/status', () => {
  const p = projection();
  return { state: p.state, indexed_height: p.indexed_height, chain_head: p.chain_head, lag_blocks: p.lag_blocks, lag_seconds: p.lag_blocks * 1.2, entries: p.state === 'EMPTY' ? 0 : Math.floor(D.state.size * (p.indexed_height / Math.max(1, p.chain_head))), digest: digestAt(p.indexed_height), last_indexed_block_time: new Date(blockTime(p.indexed_height || 1)).toISOString(), digest_height: p.indexed_height, storage: 'SQLite (disposable; rebuildable from the chain)', rebuild: rebuild ? { started_at: new Date(rebuild.start).toISOString(), finished_at: null, blocks_replayed: Math.floor(p.indexed_height), duration_ms: 0 } : lastRebuild ?? { started_at: '0001-01-01T00:00:00Z', finished_at: null, blocks_replayed: 0, duration_ms: 0 } };
});
route('POST', '/api/v1/projection/rebuild', () => {
  rebuild = { start: Date.now(), durationMs: 7000, blocks: head() };
  return { started: true, message: 'projection dropped; re-ingesting from height 1' };
});
route('GET', '/api/v1/projection/verify', (q) => {
  const p = projection();
  if (p.state === 'REBUILDING') throw new HttpError(409, 'projection is rebuilding', 'CONFLICT');
  const n = Number(q.get('proofs') ?? 20);
  const bad = scenario === 'lagbad';
  return { height: p.indexed_height, projection_digest: digestAt(p.indexed_height), chain_digest: bad ? digestAt(p.indexed_height + 1) : digestAt(p.indexed_height), projection_entries: D.state.size, chain_entries: bad ? D.state.size + 1 : D.state.size, match: !bad, statement: 'digest = SHA-256 over every (key,value) of the state in key order: equality means the projection mirrors the committed state exactly (completeness + correctness); the chain digest is computed by a validator from the committed IAVL tree at that height', proofs_checked: n, proofs_valid: bad ? n - 1 : n, proof_failures: bad ? ['sale/S-2026-1004'] : [] };
});

// metrics + tx status
route('GET', '/api/v1/metrics/latency', () => ({ ...D.latency, indexed_ms: { p50: 1260, p95: 2050, p99: 2500, max: 3200 }, note: 'measured for transactions submitted through this gateway (client-observed: includes block interval quantisation)' }));
route('GET', '/api/v1/tx/:id/status', (_q, p) => {
  const t = findTx(dec(p[0]));
  if (!t) return { tx_id: dec(p[0]), status: 'UNKNOWN' };
  return { tx_id: t.tx_id, status: t.code === 0 ? 'FINALISED_OK' : 'FINALISED_REJECTED', height: t.height, index: t.index, code: t.code, code_name: t.code_name, reason: t.reason, block_time_ms: blockTime(t.height), signer: t.signer, type: t.type, indexed: true };
});

// ---- projection queries ----
route('GET', '/api/v1/q/products', (q) => {
  const text = (q.get('q') ?? '').trim();
  const rows = D.products.filter((p) => eq(q.get('category'), p.category) && eq(q.get('status'), p.status)).filter((p) => {
    if (!text) return true;
    const ss = p.skus.map((id: string) => D.skus.find((s) => s.id === id)!);
    return has(p.name, text) || has(p.brand, text) || has(p.id, text) || ss.some((s: Rec) => has(s.id, text) || has(s.barcode, text));
  }).map((p) => ({ ...p, sku_details: p.skus.map((id: string) => D.skus.find((s) => s.id === id)) }));
  return paged(q, rows);
});
route('GET', '/api/v1/q/products/:id', (_q, p) => {
  const prod = D.products.find((x) => x.id === dec(p[0]));
  if (!prod) throw notFound(`product ${dec(p[0])}`);
  const hist = D.history.get(`product/${prod.id}`) ?? [];
  return { meta: meta(), item: { ...prod, sku_details: prod.skus.map((id: string) => D.skus.find((s) => s.id === id)), price_history: D.prices.filter((x) => prod.skus.includes(x.sku)).sort((a, b) => b.seq - a.seq), versions: hist.map((v) => ({ ...v, block_time_ms: blockTime(v.height) })) } };
});
route('GET', '/api/v1/q/skus', (q) => paged(q, D.skus.filter((s) => eq(q.get('product'), s.product_id) && (!q.get('scarce') || String(s.scarce) === (q.get('scarce') === '1' ? 'true' : q.get('scarce'))) && (!q.get('q') || has(s.id, q.get('q')!) || has(s.barcode, q.get('q')!)))));
route('GET', '/api/v1/q/locations', (q) => paged(q, D.locations.filter((l) => eq(q.get('kind'), l.kind) && eq(q.get('region'), l.region))));
route('GET', '/api/v1/q/suppliers', (q) => paged(q, D.suppliers.filter((s) => eq(q.get('region'), s.region ?? ''))));
route('GET', '/api/v1/q/inventory/exceptions', (q) => paged(q, inventoryExceptions()));
route('GET', '/api/v1/q/inventory', (q) => {
  const low = num(q.get('low_stock'));
  const rows = D.balances.filter((b) => eq(q.get('sku'), b.sku) && eq(q.get('location'), b.loc) && (low === undefined || b.available <= low));
  return paged(q, rows.map((b) => ({ ...b, product_id: D.skus.find((s) => s.id === b.sku)?.product_id, unit: D.skus.find((s) => s.id === b.sku)?.unit, location_name: D.locations.find((l) => l.id === b.loc)?.name })));
});
route('GET', '/api/v1/q/movements', (q) => {
  const rows = D.movements.filter((m) => eq(q.get('sku'), m.sku) && (!q.get('location') || m.from_loc === q.get('location') || m.to_loc === q.get('location')) && eq(q.get('reason'), m.reason) && eq(q.get('ref_id'), m.ref_id)).sort((a, b) => b.height - a.height || b.seq - a.seq);
  return paged(q, rows);
});
route('GET', '/api/v1/q/purchase-orders', (q) => paged(q, D.pos.filter((p) => eq(q.get('status'), p.status) && eq(q.get('supplier'), p.supplier_id) && eq(q.get('location'), p.location_id) && (!q.get('sku') || p.lines.some((l: Rec) => l.sku === q.get('sku')))).sort((a, b) => b.ordered_at_ms - a.ordered_at_ms)));
route('GET', '/api/v1/q/receipts', (q) => paged(q, D.receipts.filter((r) => eq(q.get('supplier'), r.supplier_id) && eq(q.get('location'), r.location_id) && eq(q.get('status'), r.reversed ? 'REVERSED' : 'POSTED'))));
route('GET', '/api/v1/q/transfers', (q) => paged(q, D.transfers.filter((t) => eq(q.get('status'), t.status) && (!q.get('location') || t.from === q.get('location') || t.to === q.get('location')))));
route('GET', '/api/v1/q/adjustments', (q) => paged(q, D.adjustments.filter((a) => eq(q.get('status'), a.status) && eq(q.get('location'), a.loc) && eq(q.get('sku'), a.sku))));
route('GET', '/api/v1/q/reservations', (q) => paged(q, D.reservations.filter((r) => eq(q.get('status'), r.status) && eq(q.get('location'), r.loc) && eq(q.get('sku'), r.sku))));
route('GET', '/api/v1/q/sales/summary', (q) => {
  const group = q.get('group') ?? 'day';
  const m = new Map<string, Rec>();
  for (const s of salesFiltered(q)) {
    const b = group === 'location' ? s.loc : group === 'channel' ? s.channel : dayKey(s.effective_at_ms);
    const r = m.get(b) ?? { bucket: b, sales: 0, gross_minor: 0, discount_minor: 0, net_minor: 0, paid_minor: 0, refunded_minor: 0 };
    r.sales++; r.gross_minor += s.gross_minor; r.discount_minor += s.discount_minor; r.net_minor += s.net_minor; r.paid_minor += s.paid_minor; r.refunded_minor += s.refund_confirmed_minor; r.refund_instructed_minor = (r.refund_instructed_minor ?? 0) + s.refund_instructed_minor;
    m.set(b, r);
  }
  return paged(q, Array.from(m.values()).sort((a, b) => a.bucket.localeCompare(b.bucket)));
});
route('GET', '/api/v1/q/sales/:id', (_q, p) => {
  const s = D.sales.find((x) => x.id === dec(p[0]));
  if (!s) throw notFound(`sale ${dec(p[0])}`);
  return { meta: meta(), item: { ...s, returns: D.returns.filter((r) => r.sale_id === s.id), refunds: D.refunds.filter((r) => r.sale_id === s.id), loyalty_entries: D.loyaltyEntries.filter((e) => e.sale_id === s.id), movements: D.movements.filter((m) => m.ref_id === s.id) } };
});
route('GET', '/api/v1/q/sales', (q) => paged(q, salesFiltered(q).sort((a, b) => b.effective_at_ms - a.effective_at_ms)));
route('GET', '/api/v1/q/returns', (q) => paged(q, D.returns.filter((r) => eq(q.get('status'), r.status) && eq(q.get('sale'), r.sale_id))));
route('GET', '/api/v1/q/refunds', (q) => paged(q, D.refunds.filter((r) => eq(q.get('status'), r.status) && eq(q.get('sale'), r.sale_id))));
route('GET', '/api/v1/q/prices', (q) => paged(q, D.prices.filter((p) => eq(q.get('sku'), p.sku) && eq(q.get('location'), p.loc)).sort((a, b) => b.seq - a.seq)));
route('GET', '/api/v1/q/promotions', (q) => paged(q, D.promos.filter((p) => eq(q.get('status'), p.status))));
route('GET', '/api/v1/q/loyalty/accounts/:id', (_q, p) => {
  const a = D.loyaltyAccounts.find((x) => x.id === dec(p[0]));
  if (!a) throw notFound(`loyalty account ${dec(p[0])}`);
  return { meta: meta(), item: { ...a, entries: D.loyaltyEntries.filter((e) => e.account === a.id) } };
});
route('GET', '/api/v1/q/loyalty/accounts', (q) => paged(q, D.loyaltyAccounts.filter((a) => !q.get('q') || has(a.id, q.get('q')!))));
route('GET', '/api/v1/q/exceptions', (q) => paged(q, D.exceptions.filter((e) => eq(q.get('status'), e.status) && eq(q.get('kind'), e.kind))));
route('GET', '/api/v1/q/transactions', (q) => {
  const from = num(q.get('from_height'));
  const rows = D.txRecords.filter((t) => eq(q.get('type'), t.type) && eq(q.get('signer'), t.signer) && eq(q.get('status'), t.status) && eq(q.get('code'), t.code) && (from === undefined || t.height >= from)).sort((a, b) => b.height - a.height || b.index - a.index).map(({ id, index, ...t }) => ({ height: t.height, index_in_block: index, tx_id: id, type: t.type, signer: t.signer, status: t.status, code: t.code, code_name: t.code_name, reason: t.reason, hash: D.txById.get(id)?.hash, block_time_ms: blockTime(t.height), client_time_ms: t.client_time_ms, authenticated: true }));
  return paged(q, rows);
});
route('GET', '/api/v1/q/history', (q) => {
  const key = q.get('key') ?? `${({ product: 'product', sale: 'sale', po: 'po', loyalty: 'loy' } as Record<string, string>)[q.get('kind') ?? ''] ?? q.get('kind')}/${q.get('id')}`;
  let hist = D.history.get(key);
  if (!hist) {
    const rec = D.state.get(key);
    if (rec) {
      const tx = D.txById.get(rec.created_tx);
      hist = [{ height: rec.created_height ?? 1, tx_id: rec.created_tx ?? 'genesis', tx_type: tx?.type ?? 'Genesis', signer: tx?.signer ?? 'genesis', version: rec.version ?? 1, value: rec }];
    }
  }
  const items = (hist ?? []).map((v) => ({ ...v, block_time_ms: blockTime(v.height), deleted: !!v.deleted })).sort((a, b) => a.height - b.height || a.version - b.version);
  return paged(q, items);
});
route('GET', '/api/v1/q/identities', (q) => paged(q, D.identities));
route('GET', '/api/v1/q/governance', () => ({ meta: meta(), item: { members: D.members, proposals: D.proposals, upgrades: D.upgrades, params: D.params, app_version: '{"version":1}', events: D.govEvents } }));
route('GET', '/api/v1/q/migration', () => ({ meta: meta(), item: { state: D.migState, batches: D.migBatches } }));
route('GET', '/api/v1/q/stats', () => { const { _today, ...rest } = stats(); void _today; return { meta: meta(), item: rest }; });

// migration reports
route('GET', '/api/v1/migration/reports/latest', () => D.reports[D.reports.length - 1]);
route('GET', '/api/v1/migration/reports/:id', (_q, p) => {
  const r = D.reports.find((x) => x.id === dec(p[0]));
  if (!r) throw notFound(`report ${dec(p[0])}`);
  const { sha256: _s, ...rest } = r;
  void _s;
  return rest;
});
route('GET', '/api/v1/migration/reports', () => D.reports.map((r) => ({ id: r.id, phase: r.phase, trial: r.trial, generated_at: r.generated_at, decision: r.decision, sha256: r.sha256 })));

// ---------------- server ----------------
const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon', '.map': 'application/json', '.woff2': 'font/woff2' };

function send(res: http.ServerResponse, status: number, body: unknown) {
  const s = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' });
  res.end(s);
}

function serveStatic(req: http.IncomingMessage, res: http.ServerResponse, pathname: string) {
  if (!fs.existsSync(path.join(DIST, 'index.html'))) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<h1>AUREOM CHAINBASE mock gateway</h1><p>API at /api/v1. Dashboard not built (run <code>npm run build</code> or use the Vite dev server on :5173).</p>');
    return;
  }
  const safe = path.normalize(decodeURIComponent(pathname)).replace(/^(\.\.[/\\])+/, '');
  let file = path.join(DIST, safe);
  if (!file.startsWith(DIST) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html');
  const ext = path.extname(file);
  res.writeHead(200, { 'Content-Type': MIME[ext] ?? 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600' });
  fs.createReadStream(file).pipe(res);
  void req;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  const pathname = url.pathname.replace(/\/+$/, '') || '/';
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' }); res.end(); return; }

  if (pathname === '/__mock/scenario') {
    if (req.method === 'POST') {
      let raw = '';
      for await (const c of req) raw += c;
      try { const b = JSON.parse(raw || '{}'); setScenario(String(b.name ?? 'normal')); } catch { /* ignore */ }
    }
    return send(res, 200, { scenario, head: head() });
  }
  if (!pathname.startsWith('/api/')) return serveStatic(req, res, pathname);
  if (scenario === 'down') { req.socket.destroy(); return; }

  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.re.exec(pathname);
    if (!m) continue;
    try {
      const out = await r.h(url.searchParams, m.slice(1), req);
      return send(res, 200, out);
    } catch (e) {
      const he = e instanceof HttpError ? e : new HttpError(500, (e as Error).message, 'INTERNAL');
      if (!(e instanceof HttpError)) console.error(e);
      return send(res, he.status, { error: he.message, code: he.code || 'ERROR' });
    }
  }
  return send(res, 404, { error: 'unknown API endpoint', code: 'NOT_FOUND' });
});

server.listen(PORT, HOST, () => {
  console.log(`mock gateway on http://${HOST}:${PORT}  (head ${head()}, ${D.txs.length} txs, ${D.sales.length} sales, ${D.state.size} state keys)`);
});
process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
