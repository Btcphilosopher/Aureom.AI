// Synthetic dataset for the mock gateway. ALL DATA IS FICTIONAL. Record shapes follow
// chain/internal/core/types.go; money is integer minor units (GBP), quantities are in the
// SKU unit's smallest step (EA/PK whole units, KG grams, L millilitres, M millimetres).
import { createHash } from 'node:crypto';

export type Rec = Record<string, any>;

export const NETWORK_ID = 'aureom-retail-demo-1';
export const BLOCK_MS = 1200;
const DAY = 86_400_000;
const HOUR = 3_600_000;

export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex').toUpperCase();
const sha1 = (s: string) => createHash('sha1').update(s).digest('hex').toUpperCase();
const b64 = (s: string) => Buffer.from(createHash('sha256').update(s).digest()).toString('base64');

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const UNIT_SCALE: Record<string, number> = { EA: 0, PK: 0, KG: 3, L: 3, M: 3 };

function halfEven(num: number, den: number): number {
  const q = Math.floor(num / den);
  const r = num - q * den;
  const twice = r * 2;
  if (twice > den || (twice === den && q % 2 === 1)) return q + 1;
  return q;
}
const lineAmount = (unitMinor: number, v: number, unit: string) => halfEven(unitMinor * v, Math.pow(10, UNIT_SCALE[unit] ?? 0));
const money = (m: number) => `£${(m / 100).toFixed(2)}`;

export interface Tx {
  tx_id: string;
  hash: string;
  type: string;
  signer: string;
  key_id: string;
  height: number;
  index: number;
  code: number;
  code_name: string;
  reason: string;
  client_time_ms: number;
  idempotency_ref: string;
  body: Rec;
  keys: string[];
}

export interface Version {
  height: number;
  tx_id: string;
  tx_type: string;
  signer: string;
  version: number;
  value: Rec;
  deleted?: boolean;
}

const CODE_NAMES: Record<number, string> = {
  0: 'OK', 1: 'MALFORMED', 2: 'TOO_LARGE', 3: 'WRONG_NETWORK', 4: 'UNKNOWN_TYPE', 5: 'UNSUPPORTED_SCHEMA', 6: 'INVALID_FIELD',
  101: 'BAD_SIGNATURE', 201: 'UNKNOWN_SIGNER', 202: 'KEY_INACTIVE', 203: 'EXPIRED', 210: 'REPLAY', 211: 'DUPLICATE_IDEMPOTENCY',
  301: 'UNAUTHORIZED', 302: 'SCOPE_VIOLATION', 303: 'POLICY_VIOLATION', 401: 'NOT_FOUND', 402: 'ALREADY_EXISTS', 403: 'VERSION_CONFLICT',
  404: 'INSUFFICIENT', 405: 'INVALID_STATE', 406: 'LIMIT_EXCEEDED', 407: 'INVALID_ARGUMENT', 408: 'MIGRATION_WINDOW',
};

export function buildDataset(now = Date.now()) {
  const rnd = mulberry32(20261112);
  const ri = (lo: number, hi: number) => lo + Math.floor(rnd() * (hi - lo + 1));
  const pick = <T,>(a: T[]): T => a[Math.floor(rnd() * a.length)];

  // ---------------- timeline ----------------
  let cursor = 1;
  const txs: Tx[] = [];
  const perHeight = new Map<number, number>();
  let txn = 0;
  // block times are assigned after the head is known: blockTime(h) = bootTime - (H0 - h) * BLOCK_MS
  const heightTimes: { tx: Tx }[] = [];

  function emit(type: string, signer: string, payload: Rec, o: { keys?: string[]; code?: number; reason?: string; stay?: boolean; idem?: string; clientAhead?: number } = {}): Tx {
    if (!o.stay) cursor += rnd() < 0.5 ? 1 : 0;
    if (cursor < 1) cursor = 1;
    txn++;
    const id = `tx_${String(txn).padStart(5, '0')}_${sha256(type + txn).slice(0, 6).toLowerCase()}`;
    const index = perHeight.get(cursor) ?? 0;
    perHeight.set(cursor, index + 1);
    const code = o.code ?? 0;
    const tx: Tx = {
      tx_id: id, hash: '', type, signer, key_id: signer === 'term-n01-2' && cursor > 58 ? 'k2' : signer === 'cashier-s01' && cursor > 97 ? 'k2' : 'k1',
      height: cursor, index, code, code_name: CODE_NAMES[code] ?? `CODE_${code}`, reason: o.reason ?? '', client_time_ms: 0,
      idempotency_ref: o.idem ?? `${type.toLowerCase()}-${txn}`, body: {}, keys: o.keys ?? [],
    };
    txs.push(tx);
    heightTimes.push({ tx });
    // body is finalised after times are known
    tx.body = { tx_id: id, network_id: NETWORK_ID, type, schema_version: 1, signer, key_id: tx.key_id, idempotency_ref: tx.idempotency_ref, client_time_ms: 0, payload };
    return tx;
  }

  // ---------------- locations / identities / params ----------------
  const LOCS = [
    { id: 'WH-DIST-01', name: 'Distribution Centre Midlands', kind: 'WAREHOUSE', region: 'central' },
    { id: 'STORE-N-01', name: 'Northgate Superstore', kind: 'STORE', region: 'north' },
    { id: 'STORE-N-02', name: 'Harbour Street Express', kind: 'STORE', region: 'north' },
    { id: 'STORE-S-01', name: 'Southcoast Superstore', kind: 'STORE', region: 'south' },
  ];
  const STORES = LOCS.filter((l) => l.kind === 'STORE').map((l) => l.id);
  const meta = (created: number, updated: number, ctx: string, utx: string, version = 1) => ({ version, schema_version: 1, created_height: created, updated_height: updated, created_tx: ctx, updated_tx: utx });
  const NATIVE = { origin: 'NATIVE' };

  const locations: Rec[] = LOCS.map((l) => ({ ...l, currency: 'GBP', status: 'ACTIVE', provenance: NATIVE, ...meta(1, 1, 'genesis', 'genesis') }));

  // ---------------- migration timeline (heights 3..16) ----------------
  cursor = 2;
  const SRC = 'legacy-retail-erp';
  const SNAP = 'snap-20261029-a';
  const MAPV = 'map-v1';
  const mkProv = (sid: string, batch: string) => ({ origin: 'IMPORTED', source_system: SRC, source_id: sid, batch_id: batch, mapping_version: MAPV, snapshot_id: SNAP });
  const migOpen = emit('MigrationControl', 'migration-op', { action: 'OPEN', source_system: SRC, manifest_hash: sha256('manifest-1') }, { keys: ['mig/state'] });
  const batchTx: Record<string, Tx> = {};
  const batchDefs: [string, string, number][] = [['products', 'product', 15], ['suppliers', 'supplier', 4], ['prices', 'price', 41], ['opening-balances', 'balance', 104], ['sales-history', 'sale', 56], ['loyalty', 'loyalty', 8]];
  batchDefs.forEach(([name, entity, n], i) => {
    batchTx[name] = emit('ImportBatch', 'migration-op', { batch_id: `mig-b-${name}-001`, entity, mapping_version: MAPV, snapshot_id: SNAP, source_system: SRC, seq: i + 1, records: `[${n} records]` }, { keys: [`mig/batch/mig-b-${name}-001`] });
    if (i === 2 || i === 4) cursor += 1;
  });
  const batchProv = (name: string, sid: string) => mkProv(sid, `mig-b-${name}-001`);

  // ---------------- products & SKUs ----------------
  interface PDef { id: string; name: string; brand: string; cat: string; imported: boolean; skus: { s: string; attrs: Record<string, string>; unit: string; price: number; scarce?: boolean }[]; extras?: Record<string, string>; status?: string }
  const PRODS: PDef[] = [
    { id: 'P-1001', name: 'Organic Whole Milk', brand: 'Meadowfield', cat: 'Dairy & Eggs', imported: true, skus: [{ s: '1L', attrs: { size: '1 L' }, unit: 'EA', price: 129 }, { s: '2L', attrs: { size: '2 L' }, unit: 'EA', price: 215 }], extras: { legacy_tax_code: 'T0', legacy_cost_centre: 'CC-410' } },
    { id: 'P-1002', name: 'Free Range Eggs', brand: 'Hillcrest Farm', cat: 'Dairy & Eggs', imported: true, skus: [{ s: '6PK', attrs: { count: '6' }, unit: 'PK', price: 235 }, { s: '12PK', attrs: { count: '12' }, unit: 'PK', price: 420 }], extras: { legacy_tax_code: 'T0', supplier_notes: 'Weekly delivery, cold chain required' } },
    { id: 'P-1003', name: 'Mature Cheddar', brand: 'Meadowfield', cat: 'Dairy & Eggs', imported: true, skus: [{ s: '350G', attrs: { weight: '350 g' }, unit: 'EA', price: 389 }] },
    { id: 'P-1004', name: 'Arabica Coffee Beans', brand: 'Corvino Roasters', cat: 'Beverages', imported: true, skus: [{ s: '250G', attrs: { weight: '250 g', roast: 'medium' }, unit: 'EA', price: 549 }, { s: '1KG', attrs: { weight: '1 kg', roast: 'medium' }, unit: 'EA', price: 1799 }], extras: { legacy_tax_code: 'T20', legacy_barcode_alt: '5012345678900' } },
    { id: 'P-1005', name: 'Sparkling Water 6 x 500 ml', brand: 'Brookside', cat: 'Beverages', imported: true, skus: [{ s: '6X500', attrs: { size: '6 x 500 ml' }, unit: 'PK', price: 299 }] },
    { id: 'P-1006', name: 'Orange Juice (not from concentrate)', brand: 'Sunvale', cat: 'Beverages', imported: true, skus: [{ s: '1L', attrs: { size: '1 L' }, unit: 'EA', price: 249 }] },
    { id: 'P-1007', name: 'Basmati Rice', brand: 'Saffron Gate', cat: 'Grocery', imported: true, skus: [{ s: '1KG', attrs: { weight: '1 kg' }, unit: 'EA', price: 249 }, { s: '5KG', attrs: { weight: '5 kg' }, unit: 'EA', price: 949 }] },
    { id: 'P-1008', name: 'Penne Pasta', brand: 'Rossi', cat: 'Grocery', imported: true, skus: [{ s: '500G', attrs: { weight: '500 g' }, unit: 'EA', price: 119 }] },
    { id: 'P-1009', name: 'Extra Virgin Olive Oil', brand: 'Oliva Verde', cat: 'Grocery', imported: true, skus: [{ s: '500ML', attrs: { size: '500 ml' }, unit: 'EA', price: 799 }, { s: 'LOOSE', attrs: { sold: 'loose, per litre' }, unit: 'L', price: 1299 }] },
    { id: 'P-1010', name: 'Bananas (loose)', brand: 'Fresh Counter', cat: 'Fresh Produce', imported: true, skus: [{ s: 'KG', attrs: { sold: 'loose, per kg' }, unit: 'KG', price: 109 }] },
    { id: 'P-1011', name: 'Cox Apples (loose)', brand: 'Fresh Counter', cat: 'Fresh Produce', imported: true, skus: [{ s: 'KG', attrs: { sold: 'loose, per kg' }, unit: 'KG', price: 189 }] },
    { id: 'P-1012', name: 'Baby Spinach', brand: 'Fresh Counter', cat: 'Fresh Produce', imported: true, skus: [{ s: '200G', attrs: { weight: '200 g' }, unit: 'EA', price: 150 }], extras: { legacy_shelf_life_days: '5' } },
    { id: 'P-1013', name: 'Laundry Detergent', brand: 'CleanWave', cat: 'Household', imported: true, skus: [{ s: '1.5L', attrs: { size: '1.5 L' }, unit: 'EA', price: 899 }, { s: '3L', attrs: { size: '3 L' }, unit: 'EA', price: 1599 }] },
    { id: 'P-1014', name: 'Dishwasher Tablets', brand: 'CleanWave', cat: 'Household', imported: true, skus: [{ s: '40PK', attrs: { count: '40' }, unit: 'PK', price: 749 }] },
    { id: 'P-1015', name: 'Kitchen Roll', brand: 'SoftTouch', cat: 'Household', imported: true, skus: [{ s: '4PK', attrs: { rolls: '4' }, unit: 'PK', price: 549 }] },
    { id: 'P-1016', name: 'Nourishing Shampoo', brand: 'Lumina', cat: 'Health & Beauty', imported: false, skus: [{ s: '400ML', attrs: { size: '400 ml' }, unit: 'EA', price: 349 }] },
    { id: 'P-1017', name: 'Whitening Toothpaste', brand: 'Dentra', cat: 'Health & Beauty', imported: false, skus: [{ s: '75ML', attrs: { size: '75 ml' }, unit: 'EA', price: 199 }] },
    { id: 'P-1018', name: 'Vitamin D3 (90 capsules)', brand: 'VitaCore', cat: 'Health & Beauty', imported: false, skus: [{ s: '90CAP', attrs: { count: '90' }, unit: 'EA', price: 649 }] },
    { id: 'P-1019', name: 'USB-C Charging Cable', brand: 'Voltix', cat: 'Electronics', imported: false, skus: [{ s: '1M', attrs: { length: '1 m' }, unit: 'EA', price: 799 }, { s: '2M', attrs: { length: '2 m' }, unit: 'EA', price: 999 }] },
    { id: 'P-1020', name: 'Wireless Earbuds', brand: 'Sonora', cat: 'Electronics', imported: false, skus: [{ s: 'BLK', attrs: { colour: 'black' }, unit: 'EA', price: 5999, scarce: true }, { s: 'WHT', attrs: { colour: 'white' }, unit: 'EA', price: 5999, scarce: true }] },
    { id: 'P-1021', name: 'LED Bulb 4-pack', brand: 'Lumenix', cat: 'Home & Garden', imported: false, skus: [{ s: 'E27', attrs: { fitting: 'E27 screw' }, unit: 'PK', price: 899 }, { s: 'B22', attrs: { fitting: 'B22 bayonet' }, unit: 'PK', price: 899 }] },
    { id: 'P-1022', name: 'Garden Hose (by the metre)', brand: 'GreenFlow', cat: 'Home & Garden', imported: false, skus: [{ s: 'METRE', attrs: { sold: 'cut to length, per metre' }, unit: 'M', price: 189 }] },
    { id: 'P-1023', name: 'Peat-free Compost 40 L', brand: 'GreenFlow', cat: 'Home & Garden', imported: false, skus: [{ s: '40L', attrs: { size: '40 L' }, unit: 'EA', price: 749 }] },
    { id: 'P-1024', name: 'Cola Classic Retro', brand: 'Brookside', cat: 'Beverages', imported: false, status: 'DISCONTINUED', skus: [{ s: '330ML', attrs: { size: '330 ml can' }, unit: 'EA', price: 99 }] },
  ];

  const history = new Map<string, Version[]>();
  const state = new Map<string, Rec>();
  const putState = (key: string, value: Rec) => state.set(key, value);
  const addVersion = (key: string, v: Version) => { const l = history.get(key) ?? []; l.push(v); history.set(key, l); };

  const products: Rec[] = [];
  const skus: Rec[] = [];
  const skuById = new Map<string, Rec>();
  const importedSkuIds = new Set<string>();

  // native CreateProduct txs follow the migration; imported use batch tx
  const nativeCreate: Record<string, Tx> = {};
  const prodTxPlaceholder = (p: PDef): Tx => {
    if (p.imported) return batchTx['products'];
    // creating native products happens after window close (set later); placeholder replaced below
    return undefined as unknown as Tx;
  };
  void prodTxPlaceholder;

  // close the migration window (reconciliation report hash filled in later)
  cursor += 1;
  const migClose = emit('MigrationControl', 'migration-op', { action: 'CLOSE', report_hash: '', totals: { products: 15, skus: 26, suppliers: 4, prices: 41, opening_balances: 104, sales: 56, loyalty_accounts: 8 }, source_freeze_marker: 'freeze-20261029T2200Z' }, { keys: ['mig/state'] });

  // native product creation (catalog manager) after the window
  for (const p of PRODS.filter((x) => !x.imported)) {
    nativeCreate[p.id] = emit('CreateProduct', 'catalog-mgr', { product_id: p.id, name: p.name, brand: p.brand, category: p.cat, variants: p.skus.map((s) => ({ sku_id: `SKU-${p.id.slice(2)}-${s.s}`, unit: s.unit, scarce: !!s.scarce })) }, { keys: [`product/${p.id}`, ...p.skus.map((s) => `sku/SKU-${p.id.slice(2)}-${s.s}`)] });
  }

  let srcCounter = 3000;
  for (const p of PRODS) {
    const ctx = p.imported ? batchTx['products'] : nativeCreate[p.id];
    const prov = p.imported ? batchProv('products', `ERP-ITM-${++srcCounter}`) : NATIVE;
    const skuIds: string[] = [];
    for (const s of p.skus) {
      const id = `SKU-${p.id.slice(2)}-${s.s}`;
      skuIds.push(id);
      const sku: Rec = { id, product_id: p.id, barcode: `50${p.id.slice(2)}${String(skuIds.length).padStart(2, '0')}${String(ri(100000, 999999))}`.slice(0, 13), unit: s.unit, scarce: !!s.scarce, status: p.status ?? 'ACTIVE', attributes: s.attrs, provenance: p.imported ? batchProv('products', `ERP-SKU-${++srcCounter}`) : NATIVE, ...meta(ctx.height, ctx.height, ctx.tx_id, ctx.tx_id) };
      if (p.imported && p.extras && skuIds.length === 1 && rnd() < 0.7) sku.source_extras = { legacy_sku_class: 'A' };
      skus.push(sku);
      skuById.set(id, sku);
      if (p.imported) importedSkuIds.add(id);
      putState(`sku/${id}`, sku);
    }
    const prod: Rec = { id: p.id, name: p.name, brand: p.brand, category: p.cat, status: p.status ?? 'ACTIVE', attributes: { range: p.cat === 'Electronics' ? 'tech' : 'everyday' }, skus: skuIds, provenance: prov, ...meta(ctx.height, ctx.height, ctx.tx_id, ctx.tx_id) };
    if (p.extras) prod.source_extras = p.extras;
    products.push(prod);
    putState(`product/${p.id}`, prod);
    addVersion(`product/${p.id}`, { height: ctx.height, tx_id: ctx.tx_id, tx_type: ctx.type, signer: ctx.signer, version: 1, value: JSON.parse(JSON.stringify(prod)) });
  }

  // product updates: versions
  const updProd = (id: string, patch: Rec, note: Rec) => {
    const prod = products.find((x) => x.id === id)!;
    const t = emit('UpdateProduct', 'catalog-mgr', { product_id: id, ...note }, { keys: [`product/${id}`] });
    Object.assign(prod, patch, { version: prod.version + 1, updated_height: t.height, updated_tx: t.tx_id });
    addVersion(`product/${id}`, { height: t.height, tx_id: t.tx_id, tx_type: t.type, signer: t.signer, version: prod.version, value: JSON.parse(JSON.stringify(prod)) });
  };
  updProd('P-1002', { category: 'Dairy & Eggs', brand: 'Hillcrest Farm Ltd' }, { brand: 'Hillcrest Farm Ltd' });
  updProd('P-1019', { name: 'USB-C Charging Cable (braided)' }, { name: 'USB-C Charging Cable (braided)' });
  updProd('P-1019', { attributes: { range: 'tech', warranty: '2 years' } }, { attributes: { range: 'tech', warranty: '2 years' } });
  updProd('P-1020', { attributes: { range: 'tech', warranty: '1 year' } }, { attributes: { range: 'tech', warranty: '1 year' } });
  {
    const prod = products.find((x) => x.id === 'P-1024')!;
    prod.status = 'ACTIVE';
    const prev = JSON.parse(JSON.stringify(prod));
    const t = emit('UpdateProduct', 'catalog-mgr', { product_id: 'P-1024', status: 'DISCONTINUED' }, { keys: ['product/P-1024'] });
    prod.status = 'DISCONTINUED'; prod.version += 1; prod.updated_height = t.height; prod.updated_tx = t.tx_id;
    history.get('product/P-1024')![0].value = prev;
    addVersion('product/P-1024', { height: t.height, tx_id: t.tx_id, tx_type: t.type, signer: t.signer, version: prod.version, value: JSON.parse(JSON.stringify(prod)) });
  }

  // ---------------- suppliers ----------------
  const SUPS: [string, string, string, boolean][] = [
    ['SUP-001', 'Meadowfield Dairies Ltd', 'Net 30', true], ['SUP-002', 'Corvino Roasters Ltd', 'Net 30', true], ['SUP-003', 'Saffron Gate Foods', 'Net 45', true], ['SUP-004', 'CleanWave Household', 'Net 30', true],
    ['SUP-005', 'Voltix Electronics UK', 'Net 14', false], ['SUP-006', 'GreenFlow Garden Supplies', 'Net 30', false],
  ];
  const suppliers: Rec[] = SUPS.map(([id, name, terms, imp]) => {
    let ctx = batchTx['suppliers'];
    if (!imp) ctx = emit('CreateSupplier', 'buyer-hq', { supplier_id: id, name, terms }, { keys: [`supplier/${id}`] });
    const s: Rec = { id, name, status: 'ACTIVE', terms, provenance: imp ? batchProv('suppliers', `ERP-SUP-${++srcCounter}`) : NATIVE, ...meta(ctx.height, ctx.height, ctx.tx_id, ctx.tx_id) };
    putState(`supplier/${id}`, s);
    return s;
  });

  // ---------------- prices ----------------
  const prices: Rec[] = [];
  let pseq = 0;
  const skuBase = new Map<string, number>();
  for (const p of PRODS) for (const s of p.skus) skuBase.set(`SKU-${p.id.slice(2)}-${s.s}`, s.price);
  const addPrice = (sku: string, loc: string, unit: number, from: number, to: number, ctx: Tx) => {
    pseq++;
    const rec: Rec = { id: `PR-${String(pseq).padStart(4, '0')}`, sku, loc, currency: 'GBP', unit_minor: unit, effective_from_ms: from, effective_to_ms: to, seq: pseq, ...meta(ctx.height, ctx.height, ctx.tx_id, ctx.tx_id) };
    prices.push(rec);
    putState(`price/${rec.id}`, rec);
    return rec;
  };
  const priceStart = now - 20 * DAY;
  const priceChange: Record<string, [number, number]> = { 'SKU-1004-250G': [5, 579], 'SKU-1007-5KG': [6, 899], 'SKU-1013-1.5L': [4, 929], 'SKU-1019-1M': [3, 749], 'SKU-1001-1L': [2, 135], 'SKU-1009-500ML': [9, 829] };
  const priceTxNative = (sku: string, loc: string, unit: number, from: number, to = 0) => {
    const t = emit('PublishPrice', 'pricing-mgr', { price_id: `PR-${String(pseq + 1).padStart(4, '0')}`, sku, location_id: loc, unit_minor: unit, currency: 'GBP', effective_from_ms: from, effective_to_ms: to }, { keys: [`price/PR-${String(pseq + 1).padStart(4, '0')}`, `pbook/${sku}/${loc}`] });
    return addPrice(sku, loc, unit, from, to, t);
  };
  for (const [sku, base] of skuBase) {
    const imported = importedSkuIds.has(sku);
    const ch = priceChange[sku];
    const first = imported ? addPrice(sku, '*', base, priceStart, ch ? now - ch[0] * DAY : 0, batchTx['prices']) : priceTxNative(sku, '*', base, priceStart, ch ? now - ch[0] * DAY : 0);
    void first;
    if (ch) priceTxNative(sku, '*', ch[1], now - ch[0] * DAY, 0);
    if (rnd() < 0.18) priceTxNative(sku, 'STORE-S-01', Math.max(50, Math.round(base * 0.96)), now - 10 * DAY, 0);
  }
  priceTxNative('SKU-1020-BLK', '*', 5499, now + 12 * DAY, 0); // scheduled price drop (Black Friday)

  // ---------------- promotions ----------------
  const promos: Rec[] = [];
  const promoTx = (def: Rec) => {
    const t = emit('ActivatePromotion', 'pricing-mgr', { promo_id: def.id, name: def.name, type: def.type, skus: def.skus, locations: def.locs, effective_from_ms: def.from_ms, effective_to_ms: def.to_ms, priority: def.priority, stackable: def.stackable, loyalty_only: def.loyalty_only }, { keys: [`promo/${def.id}`] });
    const rec: Rec = { ...def, currency: 'GBP', ...meta(t.height, t.height, t.tx_id, t.tx_id) };
    promos.push(rec);
    putState(`promo/${rec.id}`, rec);
    return rec;
  };
  promoTx({ id: 'PROMO-001', name: 'Dairy Week: 15% off', type: 'PERCENT_OFF', bp: 1500, skus: ['SKU-1001-1L', 'SKU-1001-2L', 'SKU-1003-350G'], locs: ['*'], from_ms: now - 22 * DAY, to_ms: now + 5 * DAY, priority: 10, stackable: false, loyalty_only: false, status: 'ACTIVE' });
  promoTx({ id: 'PROMO-002', name: 'Coffee: 50p off', type: 'AMOUNT_OFF_PER_UNIT', off_minor: 50, skus: ['SKU-1004-250G'], locs: ['*'], from_ms: now - 22 * DAY, to_ms: 0, priority: 20, stackable: true, loyalty_only: false, status: 'ACTIVE' });
  promoTx({ id: 'PROMO-003', name: 'Sparkling water: 3 for £7.00', type: 'MULTIBUY_FIXED_PRICE', buy_n: 3, bundle_minor: 700, skus: ['SKU-1005-6X500'], locs: ['STORE-N-01', 'STORE-N-02', 'STORE-S-01'], from_ms: now - 22 * DAY, to_ms: 0, priority: 15, stackable: false, loyalty_only: false, status: 'ACTIVE' });
  promoTx({ id: 'PROMO-004', name: 'Members: 10% off fresh produce', type: 'PERCENT_OFF', bp: 1000, skus: ['SKU-1010-KG', 'SKU-1011-KG', 'SKU-1012-200G'], locs: ['*'], from_ms: now - 22 * DAY, to_ms: 0, priority: 30, stackable: true, loyalty_only: true, status: 'ACTIVE' });
  promoTx({ id: 'PROMO-005', name: 'Autumn detergent: £2 off', type: 'AMOUNT_OFF_PER_UNIT', off_minor: 200, skus: ['SKU-1013-1.5L', 'SKU-1013-3L'], locs: ['*'], from_ms: now - 22 * DAY, to_ms: now - 3 * DAY, priority: 25, stackable: true, loyalty_only: false, status: 'ENDED' });
  promoTx({ id: 'PROMO-006', name: 'Black Friday electronics: 20% off', type: 'PERCENT_OFF', bp: 2000, skus: ['SKU-1019-1M', 'SKU-1019-2M', 'SKU-1020-BLK', 'SKU-1020-WHT'], locs: ['*'], from_ms: now + 12 * DAY, to_ms: now + 15 * DAY, priority: 5, stackable: false, loyalty_only: false, status: 'ACTIVE' });

  const priceAt = (sku: string, loc: string, t: number): Rec | undefined => {
    const act = (l: string) => prices.filter((p) => p.sku === sku && p.loc === l && p.effective_from_ms <= t && (!p.effective_to_ms || p.effective_to_ms > t)).sort((a, b) => b.seq - a.seq)[0];
    return act(loc) ?? act('*');
  };

  interface Line { line_no: number; sku: string; qty: { v: number; unit: string }; reservation_id?: string; price_id: string; price_version: number; unit_minor: number; gross_minor: number; discount_minor: number; net_minor: number; pricing_steps: Rec[]; returned_v: number; returning_v: number; refund_committed_minor: number }

  function priceLine(no: number, sku: string, v: number, loc: string, t: number, loyalty: boolean): Line | undefined {
    const sk = skuById.get(sku)!;
    const pr = priceAt(sku, loc, t);
    if (!pr) return undefined;
    const gross = lineAmount(pr.unit_minor, v, sk.unit);
    let cur = gross;
    const steps: Rec[] = [];
    const eligible = promos.filter((p) => p.skus.includes(sku) && (p.locs.includes('*') || p.locs.includes(loc)) && p.from_ms <= t && (!p.to_ms || p.to_ms > t) && (!p.loyalty_only || loyalty)).sort((a, b) => a.priority - b.priority);
    for (const p of eligible) {
      let disc = 0;
      let why = '';
      if (p.type === 'PERCENT_OFF') {
        disc = halfEven(cur * p.bp, 10000);
        why = `${p.bp / 100}% of ${money(cur)} = ${money(disc)}`;
      } else if (p.type === 'AMOUNT_OFF_PER_UNIT') {
        disc = Math.min(cur, lineAmount(p.off_minor, v, sk.unit));
        why = `${money(p.off_minor)} off per unit × ${sk.unit === 'EA' || sk.unit === 'PK' ? v : (v / 1000).toFixed(3)} = ${money(disc)}`;
      } else if (p.type === 'MULTIBUY_FIXED_PRICE') {
        const groups = Math.floor(v / p.buy_n);
        if (groups < 1) continue;
        disc = groups * (p.buy_n * pr.unit_minor - p.bundle_minor);
        if (disc <= 0) continue;
        why = `${groups} group${groups > 1 ? 's' : ''} of ${p.buy_n} at ${money(p.bundle_minor)} instead of ${money(p.buy_n * pr.unit_minor)}`;
      }
      if (disc <= 0) continue;
      steps.push({ promo_id: p.id, promo_version: p.version, type: p.type, before_minor: cur, discount_minor: disc, after_minor: cur - disc, explain: `${p.name}: ${why}. ${p.stackable ? 'Stackable, later promotions may also apply.' : 'Not stackable: later promotions are skipped for this line.'}` });
      cur -= disc;
      if (!p.stackable) break;
    }
    return { line_no: no, sku, qty: { v, unit: sk.unit }, price_id: pr.id, price_version: pr.version, unit_minor: pr.unit_minor, gross_minor: gross, discount_minor: gross - cur, net_minor: cur, pricing_steps: steps, returned_v: 0, returning_v: 0, refund_committed_minor: 0 };
  }

  const randQty = (unit: string) => (unit === 'EA' ? ri(1, 4) : unit === 'PK' ? ri(1, 3) : unit === 'KG' ? ri(3, 22) * 100 : unit === 'L' ? ri(5, 20) * 100 : ri(10, 60) * 100);

  // ---------------- stock plan (ledger first, balances derived) ----------------
  const movements: Rec[] = [];
  const seqBySku = new Map<string, number>();
  const outflow = new Map<string, number>();
  const mv = (sku: string, fromLoc: string, fromB: string, toLoc: string, toB: string, qty: number, reason: string, refType: string, refId: string, t: Tx, eff: number, origin = 'NATIVE') => {
    const seq = (seqBySku.get(sku) ?? 0) + 1;
    seqBySku.set(sku, seq);
    movements.push({ seq, sku, from_loc: fromLoc, from_bucket: fromB, to_loc: toLoc, to_bucket: toB, qty, reason, ref_type: refType, ref_id: refId, tx_id: t.tx_id, height: t.height, effective_at_ms: eff, origin });
  };

  // ---------------- customers ----------------
  const custIds = Array.from({ length: 14 }, (_, i) => `CUST-${String(101 + i * 7).padStart(6, '0')}`);
  const importedCust = new Set(custIds.slice(0, 8));

  // ---------------- sales ----------------
  const sales: Rec[] = [];
  const loyaltyEntries: Rec[] = [];
  const reservations: Rec[] = [];
  let saleSeq = 0;
  const skuList = Array.from(skuById.keys()).filter((id) => skuById.get(id)!.status === 'ACTIVE');
  const stockableForSale = skuList.filter((id) => id !== 'SKU-1020-BLK' && id !== 'SKU-1020-WHT');

  function buildLines(loc: string, t: number, loyalty: boolean, forced?: [string, number][]): Line[] {
    const lines: Line[] = [];
    const chosen: [string, number][] = forced ?? Array.from({ length: ri(1, 4) }, () => { const s = pick(stockableForSale); return [s, randQty(skuById.get(s)!.unit)] as [string, number]; });
    const seen = new Set<string>();
    for (const [s, v] of chosen) {
      if (seen.has(s)) continue;
      seen.add(s);
      const l = priceLine(lines.length + 1, s, v, loc, t, loyalty);
      if (l) lines.push(l);
    }
    return lines;
  }

  function finishSale(sale: Rec) {
    sale.gross_minor = sale.lines.reduce((a: number, l: Line) => a + l.gross_minor, 0);
    sale.discount_minor = sale.lines.reduce((a: number, l: Line) => a + l.discount_minor, 0);
    sale.net_minor = sale.lines.reduce((a: number, l: Line) => a + l.net_minor, 0);
  }

  // imported sale history: days 3..16 ago, via batch tx
  const nImported = 56;
  for (let i = 0; i < nImported; i++) {
    const daysAgo = 3 + Math.floor((i / nImported) * 13.9);
    const eff = now - daysAgo * DAY - ri(0, 11) * HOUR;
    const loc = pick(STORES);
    const cust = rnd() < 0.5 ? pick(custIds.slice(0, 8)) : undefined;
    const lines = buildLines(loc, eff, !!cust);
    if (!lines.length) continue;
    saleSeq++;
    const id = `S-IMP-${String(10000 + saleSeq)}`;
    const bt = batchTx['sales-history'];
    const sale: Rec = { id, loc, channel: pick(['IN_STORE', 'IN_STORE', 'IN_STORE', 'CLICK_AND_COLLECT']), customer_id: cust, currency: 'GBP', lines, effective_at_ms: eff, block_time_ms: 0, rules_version: 1, sale_status: 'COMPLETED', payment_status: 'CONFIRMED', fulfilment_status: 'FULFILLED', payment_method: pick(['CARD', 'CARD', 'CASH', 'CONTACTLESS']), refund_instructed_minor: 0, refund_confirmed_minor: 0, provenance: batchProv('sales-history', `ERP-INV-${88000 + i * 13}`), ...meta(bt.height, bt.height, bt.tx_id, bt.tx_id) };
    finishSale(sale);
    sale.paid_minor = sale.net_minor;
    sale.payment_events = [{ provider: 'legacy-pos', event_id: `EV-${id}-1`, provider_ref: `LEG-${88000 + i * 13}`, result: 'SUCCEEDED', amount_minor: sale.net_minor, tx_id: bt.tx_id, height: bt.height }];
    if (i % 9 === 4) sale.source_extras = { legacy_till_operator: `OP-${ri(10, 40)}`, legacy_receipt_no: `R${ri(100000, 999999)}` };
    sale._import = true;
    sales.push(sale);
  }

  // native sales: some tied to a cashier path
  const SALE_SIGNERS: Record<string, string[]> = { 'STORE-N-01': ['term-n01-1', 'term-n01-2', 'cashier-n01'], 'STORE-N-02': ['cashier-n01'], 'STORE-S-01': ['cashier-s01', 'manager-s01'], 'WH-DIST-01': ['manager-n01'] };

  // governance of scenario items: mark which native sales get special treatments
  const nNative = 38;
  const special: Record<number, string> = { 3: 'instructed', 9: 'partial', 14: 'failed', 21: 'overpaid', 26: 'instructed', 30: 'offline', 6: 'return-full', 11: 'return-partial', 17: 'return-pending', 24: 'return-reject', 33: 'return-failedrefund', 36: 'return-requested' };
  const nativeSaleInfo: { sale: Rec; tx: Tx; kind?: string }[] = [];

  // ---------------- purchase orders & receipts (native) before sales ----------------
  const pos: Rec[] = [];
  const receipts: Rec[] = [];
  const poPlan: { id: string; sup: string; loc: string; lines: [string, number, number][]; status: string; creator: string; approver?: string }[] = [
    { id: 'PO-2026-0101', sup: 'SUP-001', loc: 'WH-DIST-01', lines: [['SKU-1001-1L', 600, 78], ['SKU-1001-2L', 300, 130], ['SKU-1003-350G', 200, 241]], status: 'RECEIVED', creator: 'buyer-hq', approver: 'po-approver-hq' },
    { id: 'PO-2026-0102', sup: 'SUP-002', loc: 'WH-DIST-01', lines: [['SKU-1004-250G', 400, 352], ['SKU-1004-1KG', 100, 1180]], status: 'PARTIALLY_RECEIVED', creator: 'buyer-hq', approver: 'po-approver-hq' },
    { id: 'PO-2026-0103', sup: 'SUP-003', loc: 'WH-DIST-01', lines: [['SKU-1007-1KG', 500, 140], ['SKU-1007-5KG', 120, 560]], status: 'APPROVED', creator: 'buyer-hq', approver: 'po-approver-dist' },
    { id: 'PO-2026-0104', sup: 'SUP-004', loc: 'WH-DIST-01', lines: [['SKU-1013-1.5L', 250, 540], ['SKU-1013-3L', 150, 980], ['SKU-1014-40PK', 300, 450]], status: 'PARTIALLY_RECEIVED', creator: 'buyer-hq', approver: 'po-approver-hq' },
    { id: 'PO-2026-0105', sup: 'SUP-005', loc: 'WH-DIST-01', lines: [['SKU-1019-1M', 400, 380], ['SKU-1019-2M', 300, 520], ['SKU-1020-BLK', 60, 3400], ['SKU-1020-WHT', 60, 3400]], status: 'DRAFT', creator: 'buyer-hq' },
    { id: 'PO-2026-0106', sup: 'SUP-006', loc: 'WH-DIST-01', lines: [['SKU-1022-METRE', 200000, 90], ['SKU-1023-40L', 180, 410], ['SKU-1021-E27', 150, 480]], status: 'APPROVED', creator: 'buyer-hq', approver: 'po-approver-dist' },
    { id: 'PO-2026-0107', sup: 'SUP-001', loc: 'STORE-N-01', lines: [['SKU-1002-6PK', 120, 118], ['SKU-1002-12PK', 60, 210]], status: 'RECEIVED', creator: 'buyer-hq', approver: 'po-approver-hq' },
    { id: 'PO-2026-0108', sup: 'SUP-002', loc: 'WH-DIST-01', lines: [['SKU-1004-250G', 150, 352]], status: 'CANCELLED', creator: 'buyer-hq', approver: 'po-approver-hq' },
    { id: 'PO-2026-0109', sup: 'SUP-003', loc: 'WH-DIST-01', lines: [['SKU-1008-500G', 800, 60], ['SKU-1009-500ML', 200, 430]], status: 'DRAFT', creator: 'buyer-hq' },
    { id: 'PO-2026-0110', sup: 'SUP-001', loc: 'WH-DIST-01', lines: [['SKU-1006-1L', 300, 128], ['SKU-1003-350G', 100, 241]], status: 'RECEIVED', creator: 'buyer-hq', approver: 'po-approver-dist' },
  ];
  for (const plan of poPlan) {
    const cr = emit('CreatePurchaseOrder', plan.creator, { po_id: plan.id, supplier_id: plan.sup, location_id: plan.loc, currency: 'GBP', ordered_at_ms: 0, lines: plan.lines.map(([sku, q, c]) => ({ sku, qty: { v: q, unit: skuById.get(sku)!.unit }, unit_cost_minor: c })) }, { keys: [`po/${plan.id}`] });
    const lines = plan.lines.map(([sku, q, c], i) => ({ line_no: i + 1, sku, qty: { v: q, unit: skuById.get(sku)!.unit }, unit_cost_minor: c, received_v: 0 }));
    const total = lines.reduce((a, l) => a + lineAmount(l.unit_cost_minor, l.qty.v, l.qty.unit), 0);
    const po: Rec = { id: plan.id, supplier_id: plan.sup, location_id: plan.loc, currency: 'GBP', lines, total_minor: total, status: 'DRAFT', created_by: plan.creator, ordered_at_ms: 0, receipts: [], provenance: NATIVE, ...meta(cr.height, cr.height, cr.tx_id, cr.tx_id) };
    putState(`po/${po.id}`, po);
    addVersion(`po/${po.id}`, { height: cr.height, tx_id: cr.tx_id, tx_type: cr.type, signer: cr.signer, version: 1, value: JSON.parse(JSON.stringify(po)) });
    const bump = (t: Tx) => { po.version += 1; po.updated_height = t.height; po.updated_tx = t.tx_id; addVersion(`po/${po.id}`, { height: t.height, tx_id: t.tx_id, tx_type: t.type, signer: t.signer, version: po.version, value: JSON.parse(JSON.stringify(po)) }); };
    if (plan.approver) { const ap = emit('ApprovePurchaseOrder', plan.approver, { po_id: plan.id }, { keys: [`po/${plan.id}`] }); po.approved_by = plan.approver; po.status = 'APPROVED'; bump(ap); }
    if (plan.status === 'CANCELLED') po.status = 'CANCELLED';
    const recvFrac = plan.status === 'RECEIVED' ? 1 : plan.status === 'PARTIALLY_RECEIVED' ? 0.55 : 0;
    po._recv = recvFrac;
    po._cr = cr;
    pos.push(po);
    po._bump = bump;
  }
  // expected-version conflict + separation-of-duties rejection for realism
  const po5 = pos.find((p) => p.id === 'PO-2026-0105')!;
  emit('ApprovePurchaseOrder', 'buyer-hq', { po_id: po5.id }, { keys: ['tx/self'], code: 303, reason: `separation of duties: ${po5.id} was created by buyer-hq, who cannot approve it` });
  emit('CreatePurchaseOrder', 'buyer-hq', { po_id: po5.id }, { code: 402, reason: `purchase order ${po5.id} already exists` });

  // receipts + opening/receipt movements; stock planning
  const receiptPlan: Rec[] = [];
  for (const po of pos) {
    if (!po._recv) continue;
    const ap = history.get(`po/${po.id}`)!;
    void ap;
    const rid = `GR-${po.id.slice(-4)}`;
    const rtx = emit('ReceiveGoods', po.location_id === 'WH-DIST-01' ? 'wh-operator-dist' : 'manager-n01', { receipt_id: rid, po_id: po.id, supplier_id: po.supplier_id, location_id: po.location_id, lines: po.lines.map((l: Rec) => ({ po_line: l.line_no, sku: l.sku, qty: { v: Math.floor(l.qty.v * po._recv), unit: l.qty.unit } })), effective_at_ms: 0 }, { keys: [`receipt/${rid}`, `po/${po.id}`] });
    for (const l of po.lines) l.received_v = Math.floor(l.qty.v * po._recv);
    po.status = po._recv === 1 ? 'RECEIVED' : 'PARTIALLY_RECEIVED';
    po.receipts = [rid];
    po._bump(rtx);
    const rc: Rec = { id: rid, po_id: po.id, supplier_id: po.supplier_id, location_id: po.location_id, lines: po.lines.map((l: Rec) => ({ sku: l.sku, qty: { v: l.received_v, unit: l.qty.unit }, po_line: l.line_no })), effective_at_ms: 0, received_by: rtx.signer, reversed: false, ...meta(rtx.height, rtx.height, rtx.tx_id, rtx.tx_id) };
    receipts.push(rc);
    putState(`receipt/${rid}`, rc);
    receiptPlan.push({ rc, tx: rtx });
  }
  // an extra receipt that was reversed
  {
    const rtx = emit('ReceiveGoods', 'wh-operator-dist', { receipt_id: 'GR-0099', supplier_id: 'SUP-005', location_id: 'WH-DIST-01' }, { keys: ['receipt/GR-0099'] });
    const rc: Rec = { id: 'GR-0099', supplier_id: 'SUP-005', location_id: 'WH-DIST-01', lines: [{ sku: 'SKU-1019-1M', qty: { v: 40, unit: 'EA' } }], effective_at_ms: 0, received_by: 'wh-operator-dist', reversed: true, ...meta(rtx.height, rtx.height + 1, rtx.tx_id, rtx.tx_id, 2) };
    receipts.push(rc); putState('receipt/GR-0099', rc);
    receiptPlan.push({ rc, tx: rtx });
  }

  // ---------------- native sales ----------------
  const returns: Rec[] = [];
  const refunds: Rec[] = [];
  let loyaltySeq = 0;
  const loyaltyTotals = new Map<string, { points: number; earned: number; entries: number }>();
  const addLoyalty = (e: Rec, t: Tx | undefined) => {
    loyaltySeq++;
    const rec: Rec = { id: e.id ?? `LOYE-${String(loyaltySeq).padStart(5, '0')}`, account: e.account, type: e.type, points: e.points, sale_id: e.sale_id, refund_id: e.refund_id, reverses: e.reverses, reversed_points: e.reversed_points ?? 0, shortfall_points: e.shortfall_points, value_minor: e.value_minor, effective_at_ms: e.effective_at_ms, rule: e.rule, provenance: e.provenance ?? NATIVE, ...meta(t?.height ?? 1, t?.height ?? 1, t?.tx_id ?? 'genesis', t?.tx_id ?? 'genesis') };
    loyaltyEntries.push(rec);
    putState(`loye/${rec.id}`, rec);
    const a = loyaltyTotals.get(e.account) ?? { points: 0, earned: 0, entries: 0 };
    a.points += e.points; a.entries += 1; if (e.points > 0 && (e.type === 'EARN' || e.type === 'OPENING')) a.earned += e.points;
    loyaltyTotals.set(e.account, a);
    return rec;
  };

  // opening loyalty (imported)
  {
    const bt = batchTx['loyalty'];
    custIds.slice(0, 8).forEach((c, i) => addLoyalty({ account: c, type: 'OPENING', points: 200 + i * 130, effective_at_ms: now - 15 * DAY, rule: 'OPENING_BALANCE', provenance: batchProv('loyalty', `ERP-LOY-${5000 + i}`) }, bt));
  }

  for (let i = 0; i < nNative; i++) {
    const kind = special[i];
    const loc = i % 7 === 0 ? 'STORE-S-01' : i % 5 === 0 ? 'STORE-N-02' : i % 3 === 0 ? 'STORE-S-01' : 'STORE-N-01';
    const signer = pick(SALE_SIGNERS[loc]);
    const cust = rnd() < 0.55 ? pick(custIds) : undefined;
    // temporary effective time for pricing = approx now (fixed after block time is known)
    const approxEff = now - ri(1, 20) * 1000;
    const forced: [string, number][] | undefined = kind === 'return-full' ? [['SKU-1017-75ML', 2], ['SKU-1016-400ML', 1]] : kind === 'offline' ? [['SKU-1020-BLK', 1], ['SKU-1019-1M', 1]] : undefined;
    const lines = buildLines(loc, approxEff, !!cust, forced);
    if (!lines.length) continue;
    saleSeq++;
    const id = `S-2026-${String(1000 + i + 1)}`;
    const t = emit('CompleteSale', signer, { sale_id: id, location_id: loc, channel: 'IN_STORE', currency: 'GBP', customer_id: cust, payment_method: pick(['CARD', 'CONTACTLESS', 'CARD']), lines: lines.map((l) => ({ sku: l.sku, qty: l.qty })), effective_at_ms: 0 }, { keys: [`sale/${id}`], idem: `sale-${id}` });
    const offlineDelay = kind === 'offline' ? ri(22, 40) * HOUR : rnd() < 0.12 ? ri(2, 30) * HOUR : ri(1, 25) * 1000;
    const sale: Rec = { id, loc, channel: kind === 'offline' ? 'IN_STORE' : pick(['IN_STORE', 'IN_STORE', 'IN_STORE', 'CLICK_AND_COLLECT']), terminal_id: signer.startsWith('term') ? signer : undefined, customer_id: cust, currency: 'GBP', lines, effective_at_ms: 0, block_time_ms: 0, rules_version: 1, sale_status: 'COMPLETED', payment_status: 'INSTRUCTED', fulfilment_status: 'FULFILLED', payment_method: t.body.payload.payment_method, paid_minor: 0, refund_instructed_minor: 0, refund_confirmed_minor: 0, payment_events: [], provenance: NATIVE, ...meta(t.height, t.height, t.tx_id, t.tx_id) };
    sale._delay = offlineDelay;
    sale._tx = t;
    sale._kind = kind;
    finishSale(sale);
    sales.push(sale);
    nativeSaleInfo.push({ sale, tx: t, kind });
    // payment events
    if (kind !== 'instructed') {
      const amt = kind === 'partial' ? Math.round(sale.net_minor * 0.6) : kind === 'overpaid' ? sale.net_minor + 150 : sale.net_minor;
      const res = kind === 'failed' ? 'FAILED' : 'SUCCEEDED';
      const pt = emit('RecordPaymentResult', 'payment-adapter-1', { event_id: `EV-${id}-1`, sale_id: id, provider: 'cardnet', provider_ref: `CN-${ri(100000, 999999)}`, result: res, amount_minor: amt, currency: 'GBP' }, { keys: [`sale/${id}`] });
      sale.payment_events.push({ provider: 'cardnet', event_id: `EV-${id}-1`, provider_ref: pt.body.payload.provider_ref, result: res, amount_minor: amt, tx_id: pt.tx_id, height: pt.height });
      if (res === 'SUCCEEDED') sale.paid_minor = amt;
      sale.payment_status = kind === 'failed' ? 'FAILED' : kind === 'partial' ? 'PARTIALLY_PAID' : kind === 'overpaid' ? 'OVERPAID' : 'CONFIRMED';
      sale.version += 1; sale.updated_height = pt.height; sale.updated_tx = pt.tx_id;
      sale._payTx = pt;
    }
    // loyalty earn
    if (cust && sale.payment_status === 'CONFIRMED') {
      const lt = emit('CreditLoyalty', 'loyalty-op', { entry_id: `LOYE-S${id.slice(-4)}`, customer_id: cust, sale_id: id }, { keys: [`loy/${cust}`] });
      const pts = Math.floor(sale.net_minor / 100);
      const e = addLoyalty({ id: `LOYE-S${id.slice(-4)}`, account: cust, type: 'EARN', points: pts, sale_id: id, value_minor: pts, effective_at_ms: 0, rule: 'EARN_1_PER_GBP' }, lt);
      e._sale = sale;
      sale.loyalty_entry = e.id;
    }
  }

  // a couple of rejected sales / attempts
  emit('CompleteSale', 'cashier-n01', { sale_id: 'S-2026-REJ1', location_id: 'STORE-N-01', lines: [{ sku: 'SKU-1019-1M', qty: { v: 25, unit: 'EA' } }] }, { keys: ['tx/rej'], code: 404, reason: 'insufficient available stock for SKU-1019-1M at STORE-N-01: available 7, requested 25' });
  emit('ReserveStock', 'cashier-s01', { reservation_id: 'RSV-REJ-2', location_id: 'STORE-N-01', sku: 'SKU-1001-1L', qty: { v: 4, unit: 'EA' } }, { code: 302, reason: 'scope loc:STORE-S-01 does not cover location STORE-N-01' });
  emit('PublishPrice', 'catalog-mgr', { price_id: 'PR-REJ', sku: 'SKU-1017-75ML', unit_minor: 99 }, { code: 301, reason: 'catalog-mgr lacks permission price.publish' });
  emit('UpdateProduct', 'catalog-mgr', { product_id: 'P-1019', name: 'USB-C Cable' }, { code: 403, reason: 'expected_version 2 but record is at version 3' });

  // ---------------- returns & refunds ----------------
  const retPlan = nativeSaleInfo.filter((x) => x.kind?.startsWith('return'));
  let rseq = 0;
  for (const { sale, kind } of retPlan) {
    rseq++;
    const rid = `RET-${String(100 + rseq)}`;
    const ln = sale.lines[0];
    const qty = kind === 'return-partial' ? Math.max(1, Math.floor(ln.qty.v / 2)) : ln.qty.v;
    const lineRefund = Math.round((ln.net_minor * qty) / ln.qty.v);
    const status = kind === 'return-full' ? 'RECEIVED' : kind === 'return-partial' ? 'PARTIALLY_RECEIVED' : kind === 'return-pending' ? 'APPROVED' : kind === 'return-reject' ? 'REJECTED' : kind === 'return-failedrefund' ? 'RECEIVED' : 'REQUESTED';
    const rq = emit('RequestReturn', sale.loc === 'STORE-S-01' ? 'manager-s01' : 'cashier-n01', { return_id: rid, sale_id: sale.id, lines: [{ line_no: 1, qty_v: qty, reason: pick(['DAMAGED', 'CHANGED_MIND', 'FAULTY']) }] }, { keys: [`return/${rid}`, `sale/${sale.id}`] });
    const ret: Rec = { id: rid, sale_id: sale.id, loc: sale.loc, lines: [{ line_no: 1, qty_v: qty, reason: rq.body.payload.lines[0].reason, received_v: 0, refund_minor: lineRefund }], status: 'REQUESTED', requested_by: rq.signer, refunds: [], ...meta(rq.height, rq.height, rq.tx_id, rq.tx_id) };
    putState(`return/${rid}`, ret);
    addVersion(`return/${rid}`, { height: rq.height, tx_id: rq.tx_id, tx_type: rq.type, signer: rq.signer, version: 1, value: JSON.parse(JSON.stringify(ret)) });
    const step = (t: Tx) => { ret.version += 1; ret.updated_height = t.height; ret.updated_tx = t.tx_id; addVersion(`return/${rid}`, { height: t.height, tx_id: t.tx_id, tx_type: t.type, signer: t.signer, version: ret.version, value: JSON.parse(JSON.stringify(ret)) }); };
    if (status !== 'REQUESTED') {
      const dec = status === 'REJECTED' ? 'REJECT' : 'APPROVE';
      const at = emit('ApproveReturn', 'manager-n01', { return_id: rid, decision: dec }, { keys: [`return/${rid}`] });
      ret.status = status === 'REJECTED' ? 'REJECTED' : 'APPROVED'; ret.decided_by = 'manager-n01';
      if (rid === 'RET-102') ret.override_reason = 'Customer goodwill, approved by store manager';
      step(at);
      if (status !== 'APPROVED' && status !== 'REJECTED') {
        const rr = emit('ReceiveReturnedGoods', 'manager-n01', { return_id: rid, lines: [{ line_no: 1, qty_v: kind === 'return-partial' ? Math.max(1, qty - 1) : qty, inspection: 'RESELLABLE' }] }, { keys: [`return/${rid}`] });
        ret.lines[0].received_v = kind === 'return-partial' ? Math.max(1, qty - 1) : qty;
        ret.lines[0].inspection = 'RESELLABLE';
        ret.status = status; step(rr);
        ret._recvTx = rr;
        // refund
        const fid = `RFD-${String(rseq).padStart(4, '0')}`;
        const instr = lineRefund;
        const failed = kind === 'return-failedrefund';
        const confirmed = kind === 'return-full' || kind === 'return-partial' ? true : false;
        const ft = emit('RecordRefundResult', 'payment-adapter-1', { refund_id: fid, event_id: `EV-${fid}`, provider: 'cardnet', provider_ref: `CNR-${ri(100000, 999999)}`, amount_minor: instr, result: failed ? 'FAILED' : 'SUCCEEDED' }, { keys: [`refund/${fid}`, `sale/${sale.id}`] });
        const rf: Rec = { id: fid, sale_id: sale.id, return_id: rid, amount_minor: instr, currency: 'GBP', status: failed ? 'FAILED' : confirmed ? 'CONFIRMED' : 'INSTRUCTED', provider: 'cardnet', provider_ref: ft.body.payload.provider_ref, ...meta(ft.height, ft.height, ft.tx_id, ft.tx_id) };
        refunds.push(rf); putState(`refund/${fid}`, rf);
        ret.refunds = [fid];
        sale.refund_instructed_minor += instr;
        if (rf.status === 'CONFIRMED') sale.refund_confirmed_minor += instr;
        ln.returned_v = ret.lines[0].received_v; ln.refund_committed_minor = instr;
        sale.fulfilment_status = qty >= ln.qty.v && sale.lines.length === 1 ? 'RETURNED' : 'PARTIALLY_RETURNED';
        sale.version += 1; sale.updated_height = ft.height; sale.updated_tx = ft.tx_id;
        ret._refundTx = ft;
      } else if (status === 'APPROVED') {
        ln.returning_v = qty;
        // refund instructed only
        const fid = `RFD-${String(rseq).padStart(4, '0')}`;
        const ft = emit('RecordRefundResult', 'payment-adapter-1', { refund_id: fid, provider: 'cardnet', provider_ref: `CNR-${ri(100000, 999999)}`, amount_minor: lineRefund, result: 'PENDING' }, { keys: [`refund/${fid}`] });
        const rf: Rec = { id: fid, sale_id: sale.id, return_id: rid, amount_minor: lineRefund, currency: 'GBP', status: 'INSTRUCTED', provider: 'cardnet', ...meta(ft.height, ft.height, ft.tx_id, ft.tx_id) };
        refunds.push(rf); putState(`refund/${fid}`, rf); ret.refunds = [fid];
        sale.refund_instructed_minor += lineRefund;
      }
    }
    returns.push(ret);
  }
  emit('RequestReturn', 'cashier-n01', { return_id: 'RET-REJ', sale_id: 'S-IMP-10003' }, { code: 406, reason: 'return window of 30 days exceeded for sale S-IMP-10003 (override_reason required)' });
  emit('ApproveReturn', 'manager-n01', { return_id: 'RET-101', decision: 'APPROVE' }, { code: 405, reason: 'return RET-101 is in status RECEIVED; expected REQUESTED' });

  // loyalty reversals for returned sales (+ shortfall case)
  const earnBySale = new Map(loyaltyEntries.filter((e) => e.type === 'EARN').map((e) => [e.sale_id, e]));
  for (const ret of returns) {
    const sale = sales.find((s) => s.id === ret.sale_id)!;
    const earn = earnBySale.get(sale.id);
    if (!earn || ret.status === 'REJECTED' || ret.status === 'REQUESTED') continue;
    const rf = refunds.find((r) => r.return_id === ret.id);
    const t = emit('ReverseBusinessEntry', 'finance-ctrl', { reversal_id: `REV-${ret.id}`, target_type: 'LOYALTY_ENTRY', target_id: earn.id, refund_id: rf?.id, reason: 'refund of purchased items', points: Math.floor(earn.points * 0.6) }, { keys: [`loye/${earn.id}`] });
    const acct = loyaltyTotals.get(earn.account)!;
    const want = Math.max(1, Math.floor(earn.points * 0.6));
    const short = ret.id === 'RET-105' ? want : 0;
    addLoyalty({ account: earn.account, type: 'REVERSE', points: -(want - short), sale_id: sale.id, refund_id: rf?.id, reverses: earn.id, reversed_points: want - short, shortfall_points: short || undefined, value_minor: want, effective_at_ms: 0, rule: 'REVERSE_ON_REFUND' }, t);
    earn.reversed_points = want - short;
    void acct;
  }
  // redemptions and expiries
  for (const c of custIds.slice(2, 5)) {
    const lt = emit('RedeemLoyalty', 'cashier-n01', { entry_id: `LOYE-R${c.slice(-3)}`, customer_id: c, points: 150, location_id: 'STORE-N-01', redemption_ref: `rdm-${c}` }, { keys: [`loy/${c}`] });
    addLoyalty({ id: `LOYE-R${c.slice(-3)}`, account: c, type: 'REDEEM', points: -150, value_minor: 150, effective_at_ms: 0, rule: 'REDEEM_AT_TILL' }, lt);
  }
  {
    const lt = emit('ExpireLoyalty', 'loyalty-op', { entry_id: 'LOYE-X001', customer_id: custIds[0], points: 80, reason: '12 month inactivity' }, { keys: [`loy/${custIds[0]}`] });
    addLoyalty({ id: 'LOYE-X001', account: custIds[0], type: 'EXPIRE', points: -80, effective_at_ms: 0, rule: 'EXPIRE_INACTIVE' }, lt);
  }

  // ---------------- stock transfers & adjustments & reservations ----------------
  const transfers: Rec[] = [];
  const transferPlan: [string, string, string, [string, number, number, number][], string][] = [
    ['XFER-0001', 'WH-DIST-01', 'STORE-N-01', [['SKU-1001-1L', 120, 120, 0], ['SKU-1002-6PK', 60, 60, 0]], 'RECEIVED'],
    ['XFER-0002', 'WH-DIST-01', 'STORE-S-01', [['SKU-1013-1.5L', 40, 38, 2], ['SKU-1014-40PK', 30, 30, 0]], 'RECEIVED_WITH_DISCREPANCY'],
    ['XFER-0003', 'WH-DIST-01', 'STORE-N-02', [['SKU-1004-250G', 80, 80, 0]], 'RECEIVED'],
    ['XFER-0004', 'WH-DIST-01', 'STORE-N-01', [['SKU-1019-1M', 50, 0, 0], ['SKU-1019-2M', 40, 0, 0]], 'IN_TRANSIT'],
    ['XFER-0005', 'WH-DIST-01', 'STORE-S-01', [['SKU-1007-1KG', 100, 0, 0]], 'IN_TRANSIT'],
    ['XFER-0006', 'STORE-N-01', 'STORE-N-02', [['SKU-1005-6X500', 24, 21, 0]], 'RECEIVED_WITH_DISCREPANCY'],
  ];
  const xferTx: Record<string, { d: Tx; r?: Tx }> = {};
  for (const [id, from, to, lines, st] of transferPlan) {
    const dt = emit('TransferStock', 'wh-manager-dist', { transfer_id: id, op: 'DISPATCH', from_location: from, to_location: to, lines: lines.map(([sku, sent]) => ({ sku, qty: { v: sent, unit: skuById.get(sku)!.unit } })) }, { keys: [`xfer/${id}`] });
    let rt: Tx | undefined;
    if (st !== 'IN_TRANSIT') rt = emit('TransferStock', to.startsWith('STORE-S') ? 'manager-s01' : 'manager-n01', { transfer_id: id, op: 'RECEIVE', lines: lines.map(([sku, , rec, dmg]) => ({ sku, qty: { v: rec, unit: skuById.get(sku)!.unit }, damaged_v: dmg })) }, { keys: [`xfer/${id}`] });
    xferTx[id] = { d: dt, r: rt };
    const rec: Rec = { id, from, to, lines: lines.map(([sku, sent, rec2, dmg]) => ({ sku, sent_v: sent, received_v: rec2, damaged_v: dmg, unit: skuById.get(sku)!.unit })), status: st, ...meta(dt.height, (rt ?? dt).height, dt.tx_id, (rt ?? dt).tx_id, rt ? 2 : 1) };
    transfers.push(rec); putState(`xfer/${id}`, rec);
    addVersion(`xfer/${id}`, { height: dt.height, tx_id: dt.tx_id, tx_type: dt.type, signer: dt.signer, version: 1, value: { ...JSON.parse(JSON.stringify(rec)), status: 'IN_TRANSIT', version: 1 } });
    if (rt) addVersion(`xfer/${id}`, { height: rt.height, tx_id: rt.tx_id, tx_type: rt.type, signer: rt.signer, version: 2, value: JSON.parse(JSON.stringify(rec)) });
  }
  emit('TransferStock', 'wh-operator-dist', { transfer_id: 'XFER-0007', op: 'DISPATCH' }, { code: 404, reason: 'insufficient available stock for SKU-1020-BLK at WH-DIST-01: available 0, requested 20' });

  const adjustments: Rec[] = [];
  const adjPlan: [string, string, string, string, number, number, string, string][] = [
    ['ADJ-0001', 'SKU-1001-1L', 'STORE-N-01', 'available', 118, 112, 'COUNT_VARIANCE', 'APPROVED'],
    ['ADJ-0002', 'SKU-1017-75ML', 'STORE-S-01', 'damaged', 3, 9, 'DAMAGED_IN_STORE', 'PENDING'],
    ['ADJ-0003', 'SKU-1010-KG', 'STORE-N-01', 'available', 42000, 36500, 'SPOILAGE', 'PENDING'],
    ['ADJ-0004', 'SKU-1019-1M', 'WH-DIST-01', 'available', 320, 290, 'COUNT_VARIANCE', 'PENDING'],
    ['ADJ-0005', 'SKU-1008-500G', 'STORE-N-02', 'available', 60, 64, 'FOUND_STOCK', 'REJECTED'],
    ['ADJ-0006', 'SKU-1015-4PK', 'STORE-N-01', 'quarantined', 0, 6, 'QUALITY_HOLD', 'APPROVED'],
  ];
  for (const [id, sku, loc, bucket, sys, cnt, reason, st] of adjPlan) {
    const pt = emit('AdjustStock', loc.startsWith('WH') ? 'wh-operator-dist' : 'manager-n01', { adjustment_id: id, op: 'PROPOSE', location_id: loc, sku, bucket, counted_v: cnt, reason, evidence_ref: `evidence/${id.toLowerCase()}.jpg` }, { keys: [`adjust/${id}`] });
    let dt: Tx | undefined;
    if (st !== 'PENDING') dt = emit('AdjustStock', loc.startsWith('WH') ? 'wh-manager-dist' : 'manager-n01', { adjustment_id: id, op: st === 'APPROVED' ? 'APPROVE' : 'REJECT' }, { keys: [`adjust/${id}`] });
    const rec: Rec = { id, sku, loc, bucket, balance_version_at_count: 3, system_qty: sys, counted_qty: cnt, delta: cnt - sys, reason, evidence_ref: `evidence/${id.toLowerCase()}.jpg`, status: st, proposer: pt.signer, decider: dt?.signer, ...meta(pt.height, (dt ?? pt).height, pt.tx_id, (dt ?? pt).tx_id, dt ? 2 : 1) };
    adjustments.push(rec); putState(`adjust/${id}`, rec);
    addVersion(`adjust/${id}`, { height: pt.height, tx_id: pt.tx_id, tx_type: pt.type, signer: pt.signer, version: 1, value: { ...JSON.parse(JSON.stringify(rec)), status: 'PENDING', decider: undefined, version: 1 } });
    if (dt) addVersion(`adjust/${id}`, { height: dt.height, tx_id: dt.tx_id, tx_type: dt.type, signer: dt.signer, version: 2, value: JSON.parse(JSON.stringify(rec)) });
  }
  emit('AdjustStock', 'wh-operator-dist', { adjustment_id: 'ADJ-0099', op: 'PROPOSE', counted_v: -4 }, { code: 407, reason: 'counted quantity cannot be negative' });

  // ---------------- stock ledger from plan ----------------
  // outflows
  const key = (sku: string, loc: string) => `${sku}|${loc}`;
  for (const s of sales) for (const l of s.lines) outflow.set(key(l.sku, s.loc), (outflow.get(key(l.sku, s.loc)) ?? 0) + l.qty.v);
  for (const x of transfers) for (const l of x.lines) outflow.set(key(l.sku, x.from), (outflow.get(key(l.sku, x.from)) ?? 0) + l.sent_v);
  for (const a of adjustments.filter((x) => x.status === 'APPROVED' && x.delta < 0)) outflow.set(key(a.sku, a.loc), (outflow.get(key(a.sku, a.loc)) ?? 0) - a.delta);

  // opening / receipts
  const lowPick = new Set(['SKU-1019-1M@STORE-N-01', 'SKU-1017-75ML@STORE-S-01', 'SKU-1012-200G@STORE-N-02', 'SKU-1001-2L@STORE-S-01', 'SKU-1004-1KG@STORE-N-01', 'SKU-1006-1L@STORE-N-02', 'SKU-1023-40L@STORE-S-01', 'SKU-1010-KG@STORE-S-01']);
  const zeroPick = new Set(['SKU-1020-BLK@STORE-N-02', 'SKU-1024-330ML@STORE-S-01', 'SKU-1020-WHT@STORE-S-01']);
  const reservedPlan: Record<string, number> = { 'SKU-1001-1L@STORE-N-01': 6, 'SKU-1019-1M@STORE-N-01': 3, 'SKU-1020-BLK@STORE-N-01': 2, 'SKU-1004-250G@STORE-S-01': 4, 'SKU-1017-75ML@STORE-S-01': 2 };
  const quarPlan: Record<string, number> = { 'SKU-1015-4PK@STORE-N-01': 6, 'SKU-1002-12PK@STORE-S-01': 8, 'SKU-1003-350G@STORE-N-02': 4 };
  const dmgPlan: Record<string, number> = { 'SKU-1013-1.5L@STORE-S-01': 2, 'SKU-1005-6X500@STORE-N-02': 3, 'SKU-1017-75ML@STORE-S-01': 3 };
  const openingByKey = new Map<string, { qty: number; tx: Tx; imported: boolean }>();
  const balKeys: [string, string][] = [];
  for (const sku of skuById.keys()) for (const l of LOCS) balKeys.push([sku, l.id]);
  for (const [sku, loc] of balKeys) {
    const k = key(sku, loc);
    const unit = skuById.get(sku)!.unit;
    const scale = unit === 'EA' || unit === 'PK' ? 1 : unit === 'M' ? 100 : 100;
    const isWh = loc === 'WH-DIST-01';
    const dormant = skuById.get(sku)!.status === 'DISCONTINUED' && !isWh;
    let target: number;
    const tag = `${sku}@${loc}`;
    if (zeroPick.has(tag)) target = 0;
    else if (lowPick.has(tag)) target = unit === 'EA' || unit === 'PK' ? ri(3, 9) : ri(8, 24) * 100;
    else if (isWh) target = unit === 'EA' || unit === 'PK' ? ri(150, 640) : unit === 'M' ? ri(80, 200) * 1000 : ri(60, 180) * 1000;
    else target = unit === 'EA' || unit === 'PK' ? ri(24, 140) : unit === 'M' ? ri(20, 60) * 1000 : ri(20, 60) * 1000;
    if (dormant) target = 0;
    void scale;
    const extra = (reservedPlan[tag] ?? 0) + (quarPlan[tag] ?? 0) + (dmgPlan[tag] ?? 0);
    const out = outflow.get(k) ?? 0;
    // received-in transfers
    const inbound = transfers.filter((x) => x.to === loc).reduce((a, x) => a + x.lines.filter((l: Rec) => l.sku === sku).reduce((b: number, l: Rec) => b + l.received_v, 0), 0);
    const dmgIn = transfers.filter((x) => x.to === loc).reduce((a, x) => a + x.lines.filter((l: Rec) => l.sku === sku).reduce((b: number, l: Rec) => b + l.damaged_v, 0), 0);
    const opening = Math.max(0, target + out + extra + dmgIn - inbound);
    if (opening <= 0 && out === 0 && extra === 0) continue;
    const imported = importedSkuIds.has(sku);
    let tx = imported ? batchTx['opening-balances'] : (receiptPlan.find((r) => r.rc.lines.some((l: Rec) => l.sku === sku) && r.rc.location_id === loc)?.tx ?? (isWh ? nativeCreate['P-' + sku.slice(4, 8)] : undefined)) ?? nativeCreate['P-' + sku.slice(4, 8)] ?? batchTx['opening-balances'];
    if (!imported && !tx) tx = batchTx['opening-balances'];
    openingByKey.set(k, { qty: opening, tx: tx!, imported });
    if (opening > 0) mv(sku, imported ? 'EXT:MIGRATION' : 'EXT:SUPPLIER', 'available', loc, 'available', opening, imported ? 'OPENING_BALANCE' : 'RECEIPT', imported ? 'migration' : 'receipt', imported ? 'mig-b-opening-balances-001' : 'GR-opening', tx!, now - 19 * DAY, imported ? 'IMPORTED_OPENING' : 'NATIVE');
  }
  // sales movements
  for (const s of sales) {
    const t = s._tx as Tx | undefined;
    const bt = batchTx['sales-history'];
    for (const l of s.lines) mv(l.sku, s.loc, 'available', 'EXT:CUSTOMER', 'available', l.qty.v, 'SALE', 'sale', s.id, t ?? bt, s.effective_at_ms || now - 5 * DAY, 'NATIVE');
  }
  // transfers
  for (const x of transfers) {
    const { d, r } = xferTx[x.id];
    for (const l of x.lines) {
      mv(l.sku, x.from, 'available', `TRANSIT:${x.id}`, 'available', l.sent_v, 'TRANSFER_DISPATCH', 'transfer', x.id, d, now - 2 * HOUR);
      if (r) {
        if (l.received_v > 0) mv(l.sku, `TRANSIT:${x.id}`, 'available', x.to, 'available', l.received_v, 'TRANSFER_RECEIVE', 'transfer', x.id, r, now - HOUR);
        if (l.damaged_v > 0) mv(l.sku, `TRANSIT:${x.id}`, 'available', x.to, 'damaged', l.damaged_v, 'TRANSFER_RECEIVE', 'transfer', x.id, r, now - HOUR);
      }
    }
  }
  // approved adjustments
  for (const a of adjustments.filter((x) => x.status === 'APPROVED')) {
    const t = txs.find((tx) => tx.tx_id === a.updated_tx)!;
    if (a.delta < 0) mv(a.sku, a.loc, a.bucket, 'EXT:ADJUST', a.bucket, -a.delta, 'ADJUSTMENT', 'adjustment', a.id, t, now - HOUR);
    else mv(a.sku, 'EXT:ADJUST', a.bucket, a.loc, a.bucket, a.delta, 'ADJUSTMENT', 'adjustment', a.id, t, now - HOUR);
  }
  // returns received
  for (const r of returns) {
    if (!r._recvTx) continue;
    const l = r.lines[0];
    const sale = sales.find((s) => s.id === r.sale_id)!;
    mv(sale.lines[0].sku, 'EXT:CUSTOMER', 'available', sale.loc, 'available', l.received_v, 'RETURN', 'return', r.id, r._recvTx, now - 30 * 60_000);
  }
  // reserved / quarantined / damaged
  const nowTx = txs[txs.length - 1];
  for (const [tag, q] of Object.entries(reservedPlan)) { const [sku, loc] = tag.split('@'); mv(sku, loc, 'available', loc, 'reserved', q, 'RESERVE', 'reservation', `RSV-${tag.length}${q}`, nowTx, now - 5 * 60_000); }
  for (const [tag, q] of Object.entries(quarPlan)) { const [sku, loc] = tag.split('@'); mv(sku, loc, 'available', loc, 'quarantined', q, 'QUARANTINE', 'adjustment', 'QH-' + q, nowTx, now - 3 * HOUR); }
  for (const [tag, q] of Object.entries(dmgPlan)) { const [sku, loc] = tag.split('@'); mv(sku, loc, 'available', loc, 'damaged', q, 'ADJUSTMENT', 'adjustment', 'DMG-' + q, nowTx, now - 2 * HOUR); }

  // reservations records
  let rsvSeq = 0;
  const rsvDefs: [string, string, number, string, string, number][] = [
    ['SKU-1001-1L', 'STORE-N-01', 6, 'ACTIVE', 'term-n01-1', 20 * 60_000], ['SKU-1019-1M', 'STORE-N-01', 3, 'ACTIVE', 'term-n01-2', 4 * 60_000],
    ['SKU-1020-BLK', 'STORE-N-01', 2, 'ACTIVE', 'term-n01-1', 6 * 3600_000 * 24], ['SKU-1004-250G', 'STORE-S-01', 4, 'ACTIVE', 'cashier-s01', 90_000], ['SKU-1017-75ML', 'STORE-S-01', 2, 'ACTIVE', 'cashier-s01', 25 * 60_000],
    ['SKU-1005-6X500', 'STORE-N-01', 3, 'CONSUMED', 'term-n01-1', -60_000], ['SKU-1002-6PK', 'STORE-N-01', 2, 'RELEASED', 'term-n01-2', -3600_000], ['SKU-1010-KG', 'STORE-N-01', 1500, 'EXPIRED', 'term-n01-1', -7200_000],
  ];
  for (const [sku, loc, qty, st, holder, ttl] of rsvDefs) {
    rsvSeq++;
    const t = emit('ReserveStock', holder, { reservation_id: `RSV-${String(rsvSeq).padStart(4, '0')}`, location_id: loc, sku, qty: { v: qty, unit: skuById.get(sku)!.unit }, terminal_id: holder.startsWith('term') ? holder : undefined, ttl_ms: 1800000 }, { keys: [`resv/RSV-${String(rsvSeq).padStart(4, '0')}`] });
    const rec: Rec = { id: `RSV-${String(rsvSeq).padStart(4, '0')}`, sku, loc, qty, unit: skuById.get(sku)!.unit, status: st, allowance: sku === 'SKU-1020-BLK', holder, terminal_id: holder.startsWith('term') ? holder : undefined, expires_at_ms: now + ttl, consumed_v: st === 'CONSUMED' ? qty : 0, ...meta(t.height, t.height, t.tx_id, t.tx_id) };
    if (st === 'CONSUMED') rec.sale_id = sales.find((s) => s.id.startsWith('S-2026'))?.id;
    reservations.push(rec); putState(`resv/${rec.id}`, rec);
  }

  // balances from ledger
  const bal = new Map<string, Rec>();
  const getBal = (sku: string, loc: string) => {
    const k = key(sku, loc);
    let b = bal.get(k);
    if (!b) { b = { sku, loc, available: 0, reserved: 0, quarantined: 0, damaged: 0, last_movement_seq: 0, ...meta(1, 1, 'genesis', 'genesis') }; bal.set(k, b); }
    return b;
  };
  for (const m of [...movements].sort((a, b) => a.height - b.height || a.seq - b.seq)) {
    if (!m.from_loc.startsWith('EXT:') && !m.from_loc.startsWith('TRANSIT:')) { const b = getBal(m.sku, m.from_loc); b[m.from_bucket] -= m.qty; b.last_movement_seq = m.seq; b.updated_height = m.height; b.updated_tx = m.tx_id; b.version++; }
    if (!m.to_loc.startsWith('EXT:') && !m.to_loc.startsWith('TRANSIT:')) { const b = getBal(m.sku, m.to_loc); b[m.to_bucket] += m.qty; b.last_movement_seq = m.seq; b.updated_height = m.height; b.updated_tx = m.tx_id; b.version++; }
  }
  const balances: Rec[] = [];
  for (const b of bal.values()) {
    const inIn = transfers.filter((x) => x.status === 'IN_TRANSIT' && x.to === b.loc).reduce((a, x) => a + x.lines.filter((l: Rec) => l.sku === b.sku).reduce((c: number, l: Rec) => c + l.sent_v, 0), 0);
    const inOut = transfers.filter((x) => x.status === 'IN_TRANSIT' && x.from === b.loc).reduce((a, x) => a + x.lines.filter((l: Rec) => l.sku === b.sku).reduce((c: number, l: Rec) => c + l.sent_v, 0), 0);
    b.on_hand = b.available + b.reserved + b.quarantined + b.damaged;
    b.product_name = products.find((p) => p.id === skuById.get(b.sku)!.product_id)!.name;
    b.in_transit_in = inIn; b.in_transit_out = inOut;
    balances.push(b);
    putState(`bal/${b.sku}/${b.loc}`, b);
  }
  balances.sort((a, b) => a.sku.localeCompare(b.sku) || a.loc.localeCompare(b.loc));
  for (const m of movements) putState(`mov/${m.sku}/${String(m.seq).padStart(12, '0')}`, m);

  // ---------------- exceptions ----------------
  const exceptions: Rec[] = [];
  const addExc = (kind: string, ref: string, detail: string, status: string, ctx: Tx, resolution?: string) => {
    const id = `EXC-${String(exceptions.length + 1).padStart(4, '0')}`;
    const rec: Rec = { id, kind, ref, detail, status, resolution, resolved_by: resolution ? 'finance-ctrl' : undefined, ...meta(ctx.height, ctx.height, ctx.tx_id, ctx.tx_id) };
    exceptions.push(rec); putState(`exc/${id}`, rec);
    return rec;
  };
  const byKind = (k: string) => nativeSaleInfo.find((x) => x.kind === k)!;
  { const x = byKind('partial'); addExc('PAYMENT_AMOUNT_MISMATCH', `sale/${x.sale.id}`, `Provider confirmed ${money(x.sale.paid_minor)} but the sale total is ${money(x.sale.net_minor)}; ${money(x.sale.net_minor - x.sale.paid_minor)} outstanding`, 'OPEN', x.sale._payTx); }
  { const x = byKind('overpaid'); addExc('PAYMENT_OVERPAID', `sale/${x.sale.id}`, `Provider confirmed ${money(x.sale.paid_minor)} for a sale of ${money(x.sale.net_minor)}; ${money(x.sale.paid_minor - x.sale.net_minor)} to refund`, 'OPEN', x.sale._payTx); }
  { const x = byKind('failed'); addExc('PAYMENT_FAILED', `sale/${x.sale.id}`, 'Card payment declined by provider; goods were handed over', 'OPEN', x.sale._payTx); }
  { const r = returns.find((x) => x.id === 'RET-105'); const rf = refunds.find((x) => x.return_id === r?.id); if (rf) addExc('REFUND_FAILED', `refund/${rf.id}`, `Provider could not return ${money(rf.amount_minor)} to the original card`, 'OPEN', txs.find((t) => t.tx_id === rf.created_tx)!); }
  { const sf = loyaltyEntries.find((e) => e.shortfall_points); if (sf) addExc('LOYALTY_SHORTFALL', `loye/${sf.id}`, `Reversal needed ${sf.reversed_points + sf.shortfall_points} points but customer ${sf.account} only held ${sf.reversed_points}; ${sf.shortfall_points} points could not be taken back`, 'OPEN', txs.find((t) => t.tx_id === sf.created_tx)!); }
  { const x = transfers.find((t) => t.status === 'RECEIVED_WITH_DISCREPANCY')!; addExc('TRANSFER_DISCREPANCY', `xfer/${x.id}`, `Dispatched ${x.lines[0].sent_v}, received ${x.lines[0].received_v} plus ${x.lines[0].damaged_v} damaged`, 'OPEN', txs.find((t) => t.tx_id === x.updated_tx)!); }
  { const x = transfers.filter((t) => t.status === 'RECEIVED_WITH_DISCREPANCY')[1]; addExc('TRANSFER_DISCREPANCY', `xfer/${x.id}`, `Dispatched ${x.lines[0].sent_v}, received ${x.lines[0].received_v}: 3 units unaccounted for`, 'RESOLVED', txs.find((t) => t.tx_id === x.updated_tx)!, 'Written off as lost in transit; supplier claim raised'); }
  { const x = byKind('instructed'); addExc('PAYMENT_AMOUNT_MISMATCH', `sale/${x.sale.id}`, 'Provider reported amount differing by 1p (rounding); accepted', 'RESOLVED', x.tx, 'Rounding difference accepted by finance'); }
  // exception resolution tx
  emit('ResolveException', 'finance-ctrl', { exception_id: exceptions[exceptions.length - 1].id, resolution: 'Rounding difference accepted by finance' }, { keys: [`exc/${exceptions[exceptions.length - 1].id}`] });
  emit('ResolveException', 'manager-s01', { exception_id: 'EXC-0001', resolution: 'n/a' }, { code: 302, reason: 'scope loc:STORE-S-01 does not cover the exception location' });

  // ---------------- loyalty accounts ----------------
  const loyaltyAccounts: Rec[] = custIds.map((c, i) => {
    const t = loyaltyTotals.get(c) ?? { points: 0, earned: 0, entries: 0 };
    const first = loyaltyEntries.find((e) => e.account === c);
    const a: Rec = { id: c, points: Math.max(0, t.points), lifetime_earned: t.earned, entries: t.entries, status: 'ACTIVE', provenance: importedCust.has(c) ? batchProv('loyalty', `ERP-LOY-${5000 + i}`) : NATIVE, ...meta(first?.created_height ?? 20, first?.created_height ?? 20, first?.created_tx ?? 'genesis', first?.created_tx ?? 'genesis') };
    putState(`loy/${c}`, a);
    return a;
  });

  // ---------------- sale times, history, state ----------------
  // governance & keys (emit before computing head)
  const propTx = (id: string, kind: string, by: string, payload: Rec, approvals: string[], status: string, delta: number, result?: string) => {
    const pt = emit('ProposeGovernance', by, { proposal_id: id, kind, payload, activation_height: 0 }, { keys: [`gov/prop/${id}`] });
    let last = pt;
    for (const o of approvals) last = emit('ApproveGovernance', o.replace('org-', '') + '-org-admin', { proposal_id: id }, { keys: [`gov/prop/${id}`] });
    return { pt, last, id, kind, by, payload, approvals, status, delta, result };
  };
  const props = [
    propTx('PROP-0001', 'GRANT_ROLE', 'hq-org-admin', { identity_id: 'finance-ctrl', role: 'finance-controller', scope: '*' }, ['org-hq', 'org-dist', 'org-north'], 'EXECUTED', 12, 'role granted'),
    propTx('PROP-0002', 'SET_PARAMS', 'hq-org-admin', { return_local_limit_minor: 75000 }, ['org-hq', 'org-dist', 'org-south'], 'APPROVED', 400),
    propTx('PROP-0003', 'UPGRADE', 'hq-org-admin', { version: 2, notes: 'Loyalty rounding rules and multibuy stacking fix' }, ['org-hq', 'org-dist'], 'PENDING', 2000),
    propTx('PROP-0004', 'ADD_MEMBER', 'north-org-admin', { id: 'obs-audit', org: 'org-audit', kind: 'OBSERVER', node_id: sha1('obs-audit-node') }, ['org-north'], 'PENDING', 1600),
  ];
  const kr = emit('RotateKey', 'term-n01-2', { identity_id: 'term-n01-2', new_key_id: 'k2', new_pub_b64: b64('term-n01-2/k2'), reason: 'scheduled rotation' }, { keys: ['iam/id/term-n01-2'] });
  const kv = emit('RevokeKey', 'hq-iam-admin', { identity_id: 'cashier-s01', key_id: 'k1', reason: 'device reported lost' }, { keys: ['iam/id/cashier-s01'] });
  const kv2 = emit('RevokeKey', 'hq-iam-admin', { identity_id: 'po-approver-dist', key_id: 'k1', reason: 'employee left; account suspended' }, { keys: ['iam/id/po-approver-dist'] });
  // replay / sig rejections in the tx log
  emit('CompleteSale', 'term-n01-1', { sale_id: 'S-2026-1004' }, { code: 210, reason: 'tx_id already seen (REPLAY)' });
  emit('CompleteSale', 'term-n01-1', { sale_id: 'S-2026-1005' }, { code: 211, reason: 'idempotency_ref sale-S-2026-1005 already executed by tx ' + (nativeSaleInfo[4]?.tx.tx_id ?? '') });
  emit('ImportBatch', 'migration-op', { batch_id: 'mig-b-late-001', entity: 'product' }, { code: 408, reason: 'import window is CLOSED; imports are no longer accepted' });
  emit('CompleteSale', 'term-n01-2', { sale_id: 'S-2026-1006' }, { code: 404, reason: 'insufficient available stock for SKU-1020-WHT at STORE-N-01: available 0, requested 1' });
  emit('RequestReturn', 'cashier-s01', { return_id: 'RET-REJ2', sale_id: 'S-2026-1013' }, { code: 302, reason: 'scope loc:STORE-S-01 does not cover location STORE-N-01' });
  emit('PublishPrice', 'pricing-mgr', { price_id: 'PR-REJ2', sku: 'SKU-1017-75ML', unit_minor: 0 }, { code: 407, reason: 'unit_minor must be greater than zero' });
  emit('ApproveReturn', 'cashier-n01', { return_id: 'RET-104', decision: 'APPROVE' }, { code: 301, reason: 'cashier-n01 lacks permission return.approve' });

  // ---------------- head & block times ----------------
  const H0 = Math.max(cursor + 3, 143);
  const bootTime = now;
  const blockTime = (h: number) => bootTime - (H0 - h) * BLOCK_MS;
  for (const t of txs) {
    t.client_time_ms = blockTime(t.height) - ri(200, 1400);
    t.body.client_time_ms = t.client_time_ms;
  }
  for (const t of txs) {
    t.hash = sha256(JSON.stringify(t.body) + t.tx_id);
  }
  // fix idempotency (bodies reference tx)
  const migCloseReport = { id: 'rpt-20261030-final' };
  void migCloseReport;

  // sale times
  for (const s of sales) {
    if (s._import) {
      const bt = batchTx['sales-history'];
      s.block_time_ms = blockTime(bt.height);
      for (const e of s.payment_events ?? []) void e;
      continue;
    }
    const t = s._tx as Tx;
    s.block_time_ms = blockTime(t.height);
    s.effective_at_ms = s.block_time_ms - Math.round(s._delay);
  }
  // apply price check for backdated sales? (effective time may predate a price publication: keep as is, pricing is by price id)
  for (const e of loyaltyEntries) {
    if (e.effective_at_ms) continue;
    const sale = e.sale_id ? sales.find((s) => s.id === e.sale_id) : undefined;
    e.effective_at_ms = sale ? sale.effective_at_ms + 30_000 : blockTime(e.created_height);
  }
  for (const m of movements) {
    if (m.reason === 'SALE') { const s = sales.find((x) => x.id === m.ref_id); if (s) m.effective_at_ms = s.effective_at_ms; }
  }
  for (const po of pos) { po.ordered_at_ms = blockTime(po.created_height) - 2 * DAY; }
  for (const rc of receipts) { rc.effective_at_ms = blockTime(rc.created_height) - 20 * 60_000; }
  for (const r of reservations) { r.expires_at_ms = r.expires_at_ms; }
  for (const m of movements) if (m.reason === 'RECEIPT') m.effective_at_ms = blockTime(m.height);

  // finalise sales (state + history)
  for (const s of sales) {
    const keyS = `sale/${s.id}`;
    // return line stats are already on lines
    const clean = JSON.parse(JSON.stringify(s, (k, v) => (k.startsWith('_') ? undefined : v)));
    Object.keys(s).filter((k) => k.startsWith('_')).forEach((k) => delete s[k]);
    putState(keyS, s);
    if (s.provenance.origin === 'NATIVE') {
      const t1 = txs.find((t) => t.tx_id === s.created_tx)!;
      const first = JSON.parse(JSON.stringify(clean));
      first.payment_status = 'INSTRUCTED'; first.paid_minor = 0; first.payment_events = []; first.version = 1; first.fulfilment_status = 'FULFILLED'; first.refund_instructed_minor = 0; first.refund_confirmed_minor = 0; first.block_time_ms = s.block_time_ms; first.effective_at_ms = s.effective_at_ms;
      addVersion(keyS, { height: t1.height, tx_id: t1.tx_id, tx_type: t1.type, signer: t1.signer, version: 1, value: first });
      if (s.version > 1) addVersion(keyS, { height: s.updated_height, tx_id: s.updated_tx, tx_type: txs.find((t) => t.tx_id === s.updated_tx)?.type ?? 'RecordPaymentResult', signer: txs.find((t) => t.tx_id === s.updated_tx)?.signer ?? 'payment-adapter-1', version: s.version, value: JSON.parse(JSON.stringify(s)) });
    } else {
      addVersion(keyS, { height: s.created_height, tx_id: s.created_tx, tx_type: 'ImportBatch', signer: 'migration-op', version: 1, value: JSON.parse(JSON.stringify(s)) });
    }
    for (const l of s.lines) l.pricing_steps = l.pricing_steps ?? [];
  }
  for (const e of loyaltyEntries) { delete e._sale; }
  // loyalty account history
  for (const a of loyaltyAccounts) {
    const es = loyaltyEntries.filter((e) => e.account === a.id).sort((x, y) => x.created_height - y.created_height);
    let pts = 0, earned = 0, n = 0;
    es.forEach((e, i) => {
      pts += e.points; n++; if (e.points > 0) earned += e.points;
      const t = txs.find((tx) => tx.tx_id === e.created_tx);
      addVersion(`loy/${a.id}`, { height: e.created_height, tx_id: e.created_tx, tx_type: t?.type ?? 'ImportBatch', signer: t?.signer ?? 'migration-op', version: i + 1, value: { ...JSON.parse(JSON.stringify(a)), points: Math.max(0, pts), lifetime_earned: earned, entries: n, version: i + 1 } });
    });
    a.version = es.length || 1;
  }

  // ---------------- tx records in state ----------------
  const txRecords: Rec[] = txs.map((t) => ({ id: t.tx_id, type: t.type, signer: t.signer, status: t.code === 0 ? 'OK' : 'REJECTED', code: t.code, code_name: t.code_name, reason: t.reason, height: t.height, index: t.index, block_time_ms: blockTime(t.height), client_time_ms: t.client_time_ms, idempotency_ref: t.idempotency_ref }));
  for (const r of txRecords) putState(`tx/${r.id}`, r);

  // ---------------- identities ----------------
  const ROSTER: [string, string, string, string, [string, string][]][] = [
    ['hq-org-admin', 'org-hq', 'HUMAN', '', [['org-admin', '*'], ['hq-admin', '*']]], ['dist-org-admin', 'org-dist', 'HUMAN', '', [['org-admin', '*']]], ['north-org-admin', 'org-north', 'HUMAN', '', [['org-admin', '*']]], ['south-org-admin', 'org-south', 'HUMAN', '', [['org-admin', '*']]],
    ['hq-iam-admin', 'org-hq', 'HUMAN', '', [['hq-admin', '*']]], ['catalog-mgr', 'org-hq', 'HUMAN', '', [['catalog-manager', '*']]], ['buyer-hq', 'org-hq', 'HUMAN', '', [['buyer', '*']]], ['po-approver-hq', 'org-hq', 'HUMAN', '', [['purchasing-approver', '*']]],
    ['po-approver-dist', 'org-dist', 'HUMAN', '', [['purchasing-approver', 'loc:WH-DIST-01']]], ['wh-operator-dist', 'org-dist', 'HUMAN', '', [['warehouse-operator', 'loc:WH-DIST-01']]], ['wh-manager-dist', 'org-dist', 'HUMAN', '', [['warehouse-manager', 'loc:WH-DIST-01']]],
    ['cashier-n01', 'org-north', 'HUMAN', '', [['store-cashier', 'loc:STORE-N-01']]], ['manager-n01', 'org-north', 'HUMAN', '', [['store-manager', 'loc:STORE-N-01']]], ['cashier-s01', 'org-south', 'HUMAN', '', [['store-cashier', 'loc:STORE-S-01']]], ['manager-s01', 'org-south', 'HUMAN', '', [['store-manager', 'loc:STORE-S-01']]],
    ['term-n01-1', 'org-north', 'TERMINAL', 'STORE-N-01', [['terminal', 'loc:STORE-N-01']]], ['term-n01-2', 'org-north', 'TERMINAL', 'STORE-N-01', [['terminal', 'loc:STORE-N-01']]], ['pricing-mgr', 'org-hq', 'HUMAN', '', [['pricing-manager', '*']]], ['loyalty-op', 'org-hq', 'HUMAN', '', [['loyalty-operator', '*']]],
    ['payment-adapter-1', 'org-hq', 'SERVICE', '', [['payment-adapter', '*']]], ['finance-ctrl', 'org-hq', 'HUMAN', '', [['finance-controller', '*']]], ['migration-op', 'org-hq', 'HUMAN', '', [['migration-operator', '*']]], ['auditor-1', 'org-hq', 'HUMAN', '', [['auditor', '*']]],
  ];
  const identities: Rec[] = ROSTER.map(([id, org, kind, bound, roles]) => {
    const keys: Rec[] = [{ key_id: 'k1', pub_b64: b64(id + '/k1'), status: 'ACTIVE', from_height: 1, to_height: 0 }];
    let status = 'ACTIVE';
    let updatedTx = 'genesis', updatedH = 1, ver = 1;
    if (id === 'term-n01-2') { keys[0].status = 'ROTATED'; keys[0].to_height = kr.height; keys.push({ key_id: 'k2', pub_b64: b64(id + '/k2'), status: 'ACTIVE', from_height: kr.height, to_height: 0 }); updatedTx = kr.tx_id; updatedH = kr.height; ver = 2; }
    if (id === 'cashier-s01') { keys[0].status = 'REVOKED'; keys[0].to_height = kv.height; keys.push({ key_id: 'k2', pub_b64: b64(id + '/k2'), status: 'ACTIVE', from_height: kv.height, to_height: 0 }); updatedTx = kv.tx_id; updatedH = kv.height; ver = 2; }
    if (id === 'po-approver-dist') { keys[0].status = 'REVOKED'; keys[0].to_height = kv2.height; status = 'SUSPENDED'; updatedTx = kv2.tx_id; updatedH = kv2.height; ver = 2; }
    const grants = roles.map(([role, scope]) => ({ role, scope, granted_height: id === 'finance-ctrl' ? props[0].last.height + 1 : 1, granted_by: id === 'finance-ctrl' ? 'PROP-0001' : 'genesis' }));
    const rec: Rec = { id, org, kind, keys, status, bound_location: bound || undefined, grants, ...meta(1, updatedH, 'genesis', updatedTx, ver) };
    putState(`iam/id/${id}`, { ...rec, grants: undefined });
    putState(`iam/grants/${id}`, { identity: id, grants, ...meta(1, 1, 'genesis', 'genesis') });
    return rec;
  });

  // ---------------- governance ----------------
  const VALS = [
    { id: 'val-hq', org: 'org-hq', role: 'HEADQUARTERS' }, { id: 'val-dist', org: 'org-dist', role: 'DISTRIBUTION' },
    { id: 'val-north', org: 'org-north', role: 'REGIONAL' }, { id: 'val-south', org: 'org-south', role: 'REGIONAL' },
  ];
  const members: Rec[] = VALS.map((v, i) => ({ id: v.id, org: v.org, kind: 'VALIDATOR', role: v.role, consensus_pubkey_b64: b64('consensus/' + v.id), node_id: sha1('node' + i).toLowerCase(), power: 10, status: 'ACTIVE', added_height: 1 }));
  members.forEach((m) => putState(`gov/member/${m.id}`, m));
  const proposals: Rec[] = props.map((p) => ({ id: p.id, kind: p.kind, payload: p.payload, proposer: p.by, activation_height: p.status === 'EXECUTED' ? p.last.height + 3 : H0 + p.delta, status: p.status, approvals: p.approvals, approved_height: p.status === 'PENDING' ? 0 : p.last.height, executed_height: p.status === 'EXECUTED' ? p.last.height + 3 : 0, result: p.result, ...meta(p.pt.height, p.last.height, p.pt.tx_id, p.last.tx_id, 1 + p.approvals.length) }));
  proposals.forEach((p) => putState(`gov/prop/${p.id}`, p));
  const upgrades: Rec[] = [{ version: 1, activation_height: 1, proposal: 'genesis', status: 'ACTIVE' }, { version: 2, activation_height: H0 + 2000, proposal: 'PROP-0003', status: 'SCHEDULED' }];
  upgrades.forEach((u) => putState(`gov/upgrade/${u.version}`, u));
  const params = { max_tx_bytes: 32768, max_import_tx_bytes: 921600, max_lines: 100, max_import_records: 400, max_future_skew_ms: 300000, max_backdate_ms: 259200000, min_gov_delay_blocks: 3, min_upgrade_delay_blocks: 10, min_validators: 4, po_local_limit_minor: 2000000, adjust_small_units: 10, return_local_limit_minor: 50000, return_window_ms: 2592000000, reservation_max_ttl_ms: 1800000, allowance_max_ttl_ms: 604800000, loyalty_point_value_minor: 1 };
  putState('gov/params', params);
  putState('meta/appver', { version: 1 });
  const ev = (height: number, tx: Tx | undefined, key: string, summary: string) => ({ height, tx_id: tx?.tx_id ?? 'genesis', tx_type: tx?.type ?? 'GENESIS', signer: tx?.signer ?? '', block_time_ms: blockTime(height), key, summary });
  const govEvents: Rec[] = [
    ...members.map((m) => ev(1, undefined, `gov/member/${m.id}`, `member ${m.id} (${m.kind}) status ${m.status} power ${m.power}`)),
    ev(props[0].last.height + 1, props[0].last, 'iam/grants/finance-ctrl', 'role grants of finance-ctrl changed (1 grants)'),
    ev(kr.height, kr, 'iam/id/term-n01-2', 'identity term-n01-2 keys [k1:ROTATED, k2:ACTIVE]'),
    ev(kv.height, kv, 'iam/id/cashier-s01', 'identity cashier-s01 keys [k1:REVOKED, k2:ACTIVE]'),
    ev(kv2.height, kv2, 'iam/id/po-approver-dist', 'identity po-approver-dist keys [k1:REVOKED]'),
    ...props.map((p) => ev(p.last.height, p.last, `gov/prop/${p.id}`, `proposal ${p.id} ${p.kind} -> ${p.status} (activation height ${p.status === 'EXECUTED' ? p.last.height + 3 : H0 + p.delta})`)),
    ev(props[2].last.height, props[2].last, 'gov/upgrade/2', `state machine v2 SCHEDULED at height ${H0 + 2000}`),
  ].sort((a, b) => b.height - a.height);

  // ---------------- migration ----------------
  const reports: Rec[] = [];
  const cnt = {
    products: products.filter((x) => x.provenance.origin === 'IMPORTED').length,
    skus: importedSkuIds.size,
    suppliers: suppliers.filter((x) => x.provenance.origin === 'IMPORTED').length,
    prices: prices.filter((x) => x.created_tx === batchTx['prices'].tx_id).length,
    opening_balances: Array.from(openingByKey.values()).filter((o) => o.imported && o.qty > 0).length,
    sales: sales.filter((x) => x.provenance.origin === 'IMPORTED').length,
    loyalty_accounts: 8,
  };
  migClose.body.payload.totals = { ...cnt };
  batchDefs[0][2] = cnt.products + cnt.skus; batchDefs[1][2] = cnt.suppliers; batchDefs[2][2] = cnt.prices; batchDefs[3][2] = cnt.opening_balances; batchDefs[4][2] = cnt.sales; batchDefs[5][2] = cnt.loyalty_accounts;
  const stockUnits = Array.from(openingByKey.values()).filter((o) => o.imported).reduce((a, o) => a + o.qty, 0);
  const stockValue = stockUnits * 137;
  const salesNetImported = sales.filter((x) => x.provenance.origin === 'IMPORTED').reduce((a, x) => a + x.net_minor, 0);
  const openingPoints = loyaltyEntries.filter((e) => e.type === 'OPENING').reduce((a, e) => a + e.points, 0);
  const mkCheck = (name: string, source: number, chain: number, status = 'PASS', detail = '') => ({ name, source, chain, delta: chain - source, status, detail });
  const baseChecks = (bad: boolean) => [
    mkCheck('product count', cnt.products, cnt.products), mkCheck('sku count', cnt.skus, cnt.skus), mkCheck('supplier count', cnt.suppliers, cnt.suppliers), mkCheck('price rows', cnt.prices, cnt.prices),
    mkCheck('sales history rows', cnt.sales, cnt.sales), mkCheck('sales net total (minor units)', salesNetImported, salesNetImported),
    mkCheck('loyalty accounts', cnt.loyalty_accounts, cnt.loyalty_accounts), mkCheck('loyalty points outstanding', openingPoints, openingPoints),
    bad ? mkCheck('stock on hand (total units)', stockUnits, stockUnits - 12, 'FAIL', '12 units across 3 SKUs: negative opening stock in the source was clamped to 0 by the importer') : mkCheck('stock on hand (total units)', stockUnits, stockUnits),
    mkCheck('stock value at cost (minor units)', stockValue, stockValue),
    mkCheck('open purchase orders', 0, 0, 'PASS', 'POs are created natively after cut-over'),
    mkCheck('duplicate barcodes', 2, 0, 'WARN', '2 duplicate barcodes in source; duplicates excluded, see exceptions'),
  ];
  const exBase = [
    { kind: 'DUPLICATE_SKU', source_ref: 'items:ERP-ITM-3011', detail: 'barcode 5000000001234 already used by ERP-ITM-3004', disposition: 'EXCLUDED' },
    { kind: 'ORPHAN_FK', source_ref: 'sales:88391', detail: 'sale line references deleted item ERP-ITM-2990', disposition: 'EXCLUDED' },
    { kind: 'UNSUPPORTED_FIELD', source_ref: 'items:ERP-ITM-3002', detail: 'legacy_tax_code has no ledger field', disposition: 'PRESERVED_AS_EXTRAS' },
    { kind: 'UNSUPPORTED_FIELD', source_ref: 'items:ERP-ITM-3008', detail: 'supplier_notes has no ledger field', disposition: 'PRESERVED_AS_EXTRAS' },
    { kind: 'NEGATIVE_STOCK', source_ref: 'stock:ERP-ITM-3007@STORE-N-02', detail: 'quantity -4 recorded in source', disposition: 'FIXED' },
  ];
  const unsupported = [
    { table: 'items', column: 'legacy_tax_code', rows: 15, treatment: 'preserved in source_extras' },
    { table: 'items', column: 'supplier_notes', rows: 3, treatment: 'preserved in source_extras' },
    { table: 'sales', column: 'legacy_till_operator', rows: 7, treatment: 'preserved in source_extras' },
    { table: 'items', column: 'internal_margin_bp', rows: 15, treatment: 'dropped with approval' },
  ];
  const batchesFor = () => batchDefs.map(([name, entity, n], i) => ({ batch_id: `mig-b-${name}-001`, entity, seq: i + 1, records: n, tx_id: batchTx[name].tx_id, height: batchTx[name].height, status: 'FINALISED' }));
  reports.push({ id: 'rpt-20261022-trial-1', phase: 'trial', trial: true, network_id: NETWORK_ID, generated_at: new Date(now - 6 * DAY).toISOString(), snapshot_id: 'snap-20261022-a', snapshot_sha256: sha256('snap-20261022-a').toLowerCase(), mapping_version: 'map-v0', source_system: SRC, authoritative_system: 'SOURCE', checks: baseChecks(true), exceptions: [...exBase, { kind: 'NEGATIVE_STOCK', source_ref: 'stock:ERP-ITM-3012@STORE-S-01', detail: 'quantity -5 recorded in source', disposition: 'MANUAL' }, { kind: 'NEGATIVE_STOCK', source_ref: 'stock:ERP-ITM-3009@WH-DIST-01', detail: 'quantity -3 recorded in source', disposition: 'MANUAL' }], unsupported_fields: unsupported.slice(0, 3), batches: batchesFor().slice(0, 4).map((b) => ({ ...b, status: 'FINALISED' })), decision: 'REJECT', notes: 'Trial 1 against a throw-away chain. Negative source stock must be corrected in the legacy system before the next trial; mapping v0 did not preserve till operator.' });
  reports.push({ id: 'rpt-20261025-trial-2', phase: 'trial', trial: true, network_id: NETWORK_ID, generated_at: new Date(now - 3 * DAY).toISOString(), snapshot_id: 'snap-20261025-a', snapshot_sha256: sha256('snap-20261025-a').toLowerCase(), mapping_version: MAPV, source_system: SRC, authoritative_system: 'SOURCE', checks: baseChecks(false).map((c) => (c.status === 'WARN' ? c : c)), exceptions: exBase.slice(0, 4), unsupported_fields: unsupported, batches: batchesFor(), decision: 'ACCEPT', notes: 'Trial 2 passed all numeric checks. One warning for duplicate barcodes was accepted. Ready for the opening run.' });
  reports.push({ id: 'rpt-20261029-opening', phase: 'opening', trial: false, network_id: NETWORK_ID, generated_at: new Date(blockTime(migOpen.height) - 90_000).toISOString(), snapshot_id: SNAP, snapshot_sha256: sha256(SNAP).toLowerCase(), mapping_version: MAPV, source_system: SRC, authoritative_system: 'FROZEN', checks: baseChecks(false), exceptions: exBase.slice(0, 4), unsupported_fields: unsupported, batches: batchesFor().slice(0, 3), decision: 'ACCEPT', notes: 'Opening manifest approved. Legacy ERP frozen read-only at freeze-20261029T2200Z.' });
  reports.push({ id: 'rpt-20261029-final', phase: 'final', trial: false, network_id: NETWORK_ID, generated_at: new Date(blockTime(migClose.height) - 20_000).toISOString(), snapshot_id: SNAP, snapshot_sha256: sha256(SNAP).toLowerCase(), mapping_version: MAPV, source_system: SRC, authoritative_system: 'CHAIN', checks: baseChecks(false).map((c) => (c.name === 'duplicate barcodes' ? { ...c, detail: '2 duplicate barcodes in source; excluded and listed in exceptions' } : c)), exceptions: exBase.slice(0, 4), unsupported_fields: unsupported, batches: batchesFor(), decision: 'ACCEPT', notes: 'Final reconciliation. Chain counters equal the totals attested at CLOSE. The ledger is now the system of record; the legacy ERP stays read-only for reference.' });
  const reportRows: Rec[] = reports.map((r) => ({ ...r, sha256: sha256(JSON.stringify(r)).toLowerCase() }));
  const finalRep = reportRows[reportRows.length - 1];
  migClose.body.payload.report_hash = finalRep.sha256;
  const migState: Rec = { status: 'CLOSED', source_system: SRC, opened_height: migOpen.height, closed_height: migClose.height, batches: 6, records: Object.values(cnt).reduce((a, b) => a + b, 0), open_manifest_hash: sha256('manifest-1').toLowerCase(), reconciliation_report_hash: finalRep.sha256, chain_counters: { ...cnt }, attested_totals: { ...cnt }, source_freeze_marker: 'freeze-20261029T2200Z', ...meta(migOpen.height, migClose.height, migOpen.tx_id, migClose.tx_id, 8) };
  putState('mig/state', migState);
  const migBatches = batchesFor().map((b) => ({ ...b, id: b.batch_id }));
  for (const b of migBatches) putState(`mig/batch/${b.batch_id}`, b);

  // ---------------- latency metrics ----------------
  const recent = Array.from({ length: 40 }, (_, i) => {
    const t = txs.filter((x) => x.code === 0)[txs.filter((x) => x.code === 0).length - 1 - i];
    return { tx_id: t.tx_id, type: t.type, admission_ms: ri(3, 14), finality_ms: 900 + ri(0, 900) + (i % 7 === 0 ? 600 : 0), code: 0, at: blockTime(t.height) };
  });
  const rejectedRecent = [
    ...txs.filter((t) => t.code !== 0).slice(-6).map((t) => ({ tx_id: t.tx_id, type: t.type, signer: t.signer, code: t.code, code_name: t.code_name, reason: t.reason, stage: 'FINALISED', at: blockTime(t.height) })),
    { tx_id: 'tx_adm_0001', type: 'CompleteSale', signer: 'term-n01-2', code: 101, code_name: 'BAD_SIGNATURE', reason: 'signature does not verify against key k1', stage: 'ADMISSION', at: now - 40_000 },
    { tx_id: 'tx_adm_0002', type: 'CreateProduct', signer: 'catalog-mgr', code: 6, code_name: 'INVALID_FIELD', reason: 'unknown currency "GBX"', stage: 'ADMISSION', at: now - 95_000 },
  ];
  const latency = { count: 214, admission_ms: { p50: 6, p95: 14, p99: 31, max: 58 }, finality_ms: { p50: 1180, p95: 1960, p99: 2410, max: 3120 }, recent, rejected_recent: rejectedRecent };

  // heights -> txs
  const txsByHeight = new Map<number, Tx[]>();
  for (const t of txs) { const l = txsByHeight.get(t.height) ?? []; l.push(t); txsByHeight.set(t.height, l); }
  const txById = new Map(txs.map((t) => [t.tx_id, t]));
  const txByHash = new Map(txs.map((t) => [t.hash.toLowerCase(), t]));

  // clean helper: tx metadata attached to sales etc. is in state already
  return {
    now, H0, bootTime, blockTime, txs, txById, txByHash, txsByHeight, txRecords, history, state,
    products, skus, locations, suppliers, pos, receipts, balances, movements, reservations, sales, returns, refunds, prices, promos,
    loyaltyAccounts, loyaltyEntries, adjustments, transfers, exceptions, identities, members, proposals, upgrades, params, govEvents,
    migState, migBatches, reports: reportRows, latency, customers: custIds,
  };
}

export type Dataset = ReturnType<typeof buildDataset>;
