# AUREOM CHAINBASE

A **blockchain-native retail database** for a fictional retail group: business state lives on a BFT-replicated chain (CometBFT v0.38.25 + a deterministic Go state machine), mutations are signed
transactions, history is queryable at any finalised height, and a conventional retail database can be migrated into it with reconciliation and a controlled cutover.
Everything uses **synthetic data**. No tokens, mining, staking or fees.

> **Read this first — what is real and what is not.** A *functioning multi-validator network* is delivered: 4 independent `chaind` processes with real
> CometBFT consensus (n=4, f=1), tested under crashes, partitions and quorum loss. In this package all four run on **one machine under one operator**,
> so it demonstrates fault tolerance and the mechanics of independent administration — **not** independent trust (see `docs/TRUST_MODEL.md`).
> The *single-node prototype* (`core.Sim`, used by unit tests and the engine benchmark) is the same state machine without consensus.
> The Docker Compose files were written but could not be executed in the build sandbox (no Docker daemon).
> `docs/GUARANTEES.md` lists exactly what is implemented, what was tested and what remains a deployment limitation.

## Quick start
```bash
make build                         # Go >= 1.26 (go.mod pins `go 1.26.0`; with GOTOOLCHAIN=auto an older Go downloads it) → bin/{chaind,chainctl,gateway,bench}
make test                          # unit + app tests (state machine, determinism, restart, proofs)
(cd chain && go test -tags integration -timeout 20m ./internal/itest)   # multi-process network tests
scripts/localnet.sh start          # 4-validator network (HQ, Distribution, Regional North/South)
scripts/localnet.sh gateway start  # API + disposable projection + dashboard → http://127.0.0.1:8080
scripts/demo.sh                    # the 13-step demonstration (see docs/DEMO.md)
scripts/demo-governance.sh         # membership, key rotation, upgrade activation, old-binary halt
```
Requirements: Go 1.26+, Node 22+, Python 3.11+ (migration tool), `curl`. Docker is optional (`deploy/`).

## What is where
| Path | Contents |
|---|---|
| `chain/` | Go: state machine (`internal/core`), ABCI app (`internal/app`), gateway + projection (`internal/gateway`), verification tools, network generator, integration tests, `cmd/{chaind,chainctl,gateway,bench}` |
| `sdk/` | TypeScript SDK (signing, key stores, proofs), POS **offline terminal simulator**, provider-independent **integration adapters**, demo steps, examples |
| `migration/` | Python migration + reconciliation tool, synthetic legacy SQLite database, mapping spec, trial/cutover procedure |
| `dashboard/` | React operations dashboard (Overview, Network, Products, Inventory, Sales, Suppliers, Prices, Loyalty, Migration, Explorer, Administration) |
| `deploy/` | Dockerfile, docker-compose.yml, entrypoint |
| `scripts/` | `localnet.sh`, `demo.sh`, `demo-governance.sh`, `gen-docs.sh` |
| `docs/` | ARCHITECTURE, CONSENSUS, TRUST_MODEL, GOVERNANCE, PRIVACY, OPERATIONS, TRANSACTIONS (generated), API, SDK, MIGRATION, DASHBOARD, BENCHMARK, DEMO, GUARANTEES |

## Documents
* **Architecture & definition of "pure blockchain database":** `docs/ARCHITECTURE.md`
* **Consensus choice, failure model, finality, quorum arithmetic:** `docs/CONSENSUS.md`
* **Trust model, who can read data, what a chain does not prove:** `docs/TRUST_MODEL.md`, `docs/PRIVACY.md`
* **Chain schemas & transaction definitions:** `docs/TRANSACTIONS.md` (generated from the Go types), record shapes in `chain/internal/core/types.go`
* **Governance / membership / upgrades:** `docs/GOVERNANCE.md`
* **API & SDK:** `docs/API.md`, `docs/SDK.md` · **Migration:** `docs/MIGRATION.md` · **Dashboard:** `docs/DASHBOARD.md`
* **Deployment & recovery:** `docs/OPERATIONS.md` · **Benchmarks:** `docs/BENCHMARK.md` · **Guarantees & limitations:** `docs/GUARANTEES.md`
