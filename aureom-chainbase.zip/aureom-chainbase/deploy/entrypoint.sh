#!/bin/sh
# Roles: init (generate the permissioned testnet into /net), validator <name>, gateway
set -eu
NET=${NET_DIR:-/net}
case "${1:-}" in
  init)
    if [ -f "$NET/network.json" ]; then echo "network already initialised"; exit 0; fi
    chainctl testnet --out "$NET" --network-id "${NETWORK_ID:-aureom-retail-demo-1}" --block-time "${BLOCK_TIME:-1s}" --docker true
    ;;
  validator)
    # each validator runs from its OWN home: in a real deployment each organisation holds only its own
    # directory; the shared /net volume exists only so the single-host demo can be generated in one step.
    exec chaind start --home "$NET/nodes/$2" --log-level "${LOG_LEVEL:-main:info,state:info,*:error}"
    ;;
  gateway)
    # the compose network.json uses container hostnames for RPC
    exec gateway --network "$NET/network.json" --listen 0.0.0.0:8080 --projection /data/projection.sqlite --static /opt/dashboard
    ;;
  *) exec "$@";;
esac
