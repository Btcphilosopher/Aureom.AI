// Node-side helper used by the demo steps, examples and CLIs: loads identity keys from the key
// directory written by `chainctl testnet` and gives each identity a TxBuilder.

import { Client, TxBuilder, TxRejectedError, Signer, outcomeOf, type BuildOptions, type SignedTx, type SubmitResponse, type TxOutcome, type TxPayloadMap, type TxType, type WaitMode } from "../src/index.js";
import { RawKeyFileStore } from "../src/node.js";
import { resolveEnv, type Env } from "./env.js";

export interface SendOptions extends BuildOptions {
  wait?: WaitMode;
  timeoutMs?: number;
  /** Return rejected outcomes instead of throwing TxRejectedError. */
  allowReject?: boolean;
}

export interface SendResult<T extends TxType> {
  tx: SignedTx<T>;
  response: SubmitResponse;
  outcome: TxOutcome;
}

export class Runtime {
  readonly builders = new Map<string, TxBuilder>();
  constructor(
    readonly env: Env,
    readonly client: Client,
    readonly keys: RawKeyFileStore,
  ) {}

  async builder(identity: string): Promise<TxBuilder> {
    let b = this.builders.get(identity);
    if (!b) {
      b = new TxBuilder({ networkId: this.env.networkId, signer: await Signer.forIdentity(this.keys, identity) });
      this.builders.set(identity, b);
    }
    return b;
  }

  /** Sign as `identity`, submit, and by default wait for finality. Throws TxRejectedError unless allowReject. */
  async send<T extends TxType>(identity: string, type: T, payload: TxPayloadMap[T], opts: SendOptions = {}): Promise<SendResult<T>> {
    const { wait, timeoutMs, allowReject, ...build } = opts;
    const tx = await (await this.builder(identity)).build(type, payload, build);
    return this.submitSigned(tx, { wait: wait ?? "final", ...(timeoutMs !== undefined ? { timeoutMs } : {}), ...(allowReject !== undefined ? { allowReject } : {}) });
  }

  async submitSigned<T extends TxType>(tx: SignedTx<T>, o: { wait?: WaitMode; timeoutMs?: number; allowReject?: boolean } = {}): Promise<SendResult<T>> {
    const response = await this.client.submit(tx, { wait: o.wait ?? "final", ...(o.timeoutMs !== undefined ? { timeoutMs: o.timeoutMs } : {}) });
    const outcome = outcomeOf(response);
    if (!o.allowReject) {
      if (outcome.status === "ADMISSION_REJECTED") throw new TxRejectedError(tx.txId, "admission", outcome.code, outcome.codeName, outcome.log);
      if (outcome.status === "FINALISED_REJECTED") throw new TxRejectedError(tx.txId, "finalised", outcome.code, outcome.codeName, outcome.log);
    }
    return { tx, response, outcome };
  }
}

export async function connect(opts: { identities?: string[]; gatewayUrl?: string; runDir?: string; keysDir?: string; networkId?: string } = {}): Promise<Runtime> {
  const env = resolveEnv({
    ...(opts.gatewayUrl ? { gatewayUrl: opts.gatewayUrl } : {}),
    ...(opts.runDir ? { runDir: opts.runDir } : {}),
    ...(opts.keysDir ? { keysDir: opts.keysDir } : {}),
    ...(opts.networkId ? { networkId: opts.networkId } : {}),
  });
  const keys = await RawKeyFileStore.open(env.keysDir, opts.identities ? { identities: opts.identities } : {});
  const client = new Client({ baseUrl: env.gatewayUrl });
  return new Runtime(env, client, keys);
}
