#!/usr/bin/env -S npx tsx
// Key tooling.   npm run keys -- <command>
//   generate <identity> [--key-id k1] [--dir DIR]      create a key file (mode 0600) and print the RegisterIdentity payload
//   vault-import <vault.json> [--dir DIR]              encrypt every plaintext key file of DIR into an encrypted vault
//   vault-list <vault.json>                            list the keys in a vault (needs the passphrase)
// The vault passphrase is read from $KEYSTORE_PASSPHRASE (or the file named by $KEYSTORE_PASSPHRASE_FILE).
import { readFileSync } from "node:fs";
import { parseArgs } from "node:util";
import { bytesToBase64, hexToBytes } from "../src/index.js";
import { EncryptedFileKeyStore, RawKeyFileStore, readRawKeyFiles } from "../src/node.js";
import { resolveEnv } from "./env.js";

const { values, positionals } = parseArgs({ allowPositionals: true, options: { "key-id": { type: "string" }, dir: { type: "string" }, "run-dir": { type: "string" } } });
const [cmd, arg] = positionals;
const env = resolveEnv({ ...(values["run-dir"] ? { runDir: values["run-dir"] } : {}), ...(values.dir ? { keysDir: values.dir } : {}) });

function passphrase(): string {
  const f = process.env["KEYSTORE_PASSPHRASE_FILE"];
  const p = f ? readFileSync(f, "utf8").trim() : process.env["KEYSTORE_PASSPHRASE"];
  if (!p) {
    console.error("set KEYSTORE_PASSPHRASE (or KEYSTORE_PASSPHRASE_FILE)");
    process.exit(2);
  }
  return p;
}

switch (cmd) {
  case "generate": {
    if (!arg) break;
    const store = await RawKeyFileStore.open(env.keysDir, { identities: [] });
    const keyId = values["key-id"] ?? "k1";
    const k = await store.generate(arg, keyId);
    console.log(`created ${env.keysDir}/${arg}.${keyId}.json (mode 600)`);
    console.log("RegisterIdentity payload (submit with hq-iam-admin):");
    console.log(JSON.stringify({ identity_id: arg, org: "org-north", kind: "HUMAN", key_id: keyId, pub_b64: bytesToBase64(k.publicKey) }));
    process.exit(0);
    break;
  }
  case "vault-import": {
    if (!arg) break;
    let vault: EncryptedFileKeyStore;
    try {
      vault = await EncryptedFileKeyStore.open(arg, passphrase());
    } catch {
      vault = await EncryptedFileKeyStore.create(arg, passphrase());
    }
    let n = 0;
    for (const kf of await readRawKeyFiles(env.keysDir)) {
      await vault.addSeed(kf.identity, kf.key_id, hexToBytes(kf.seed_hex));
      n++;
    }
    console.log(`imported ${n} key(s) into ${arg}. Now delete the plaintext files in ${env.keysDir}.`);
    process.exit(0);
    break;
  }
  case "vault-list": {
    if (!arg) break;
    const v = await EncryptedFileKeyStore.open(arg, passphrase());
    for (const k of await v.list()) console.log(`${k.ref}  ${bytesToBase64(k.publicKey)}`);
    process.exit(0);
    break;
  }
}
console.error("usage: npm run keys -- generate <identity> [--key-id k1] | vault-import <vault.json> | vault-list <vault.json>");
process.exit(2);
