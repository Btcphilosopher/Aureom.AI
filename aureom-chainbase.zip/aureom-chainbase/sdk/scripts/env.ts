// Shared environment resolution for the CLIs (terminal, demo, send, examples). Node only.
//
//   RUN_DIR      run directory of the local network (same variable as scripts/localnet.sh). Default: <repo>/run
//   GATEWAY_URL  gateway base URL. Default: http://127.0.0.1:8080
//   KEYS_DIR     identity key files. Default: $RUN_DIR/net/keys
//   NETWORK_ID   chain id. Default: read from $RUN_DIR/net/network.json, else aureom-retail-demo-1

import { existsSync, readFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const sdkRoot = fileURLToPath(new URL("..", import.meta.url));

export interface Env {
  sdkRoot: string;
  runDir: string;
  keysDir: string;
  gatewayUrl: string;
  networkId: string;
}

export function resolveEnv(overrides: Partial<{ runDir: string; keysDir: string; gatewayUrl: string; networkId: string }> = {}): Env {
  const runDir = resolve(overrides.runDir ?? process.env["RUN_DIR"] ?? join(sdkRoot, "..", "run"));
  const keysDir = resolve(overrides.keysDir ?? process.env["KEYS_DIR"] ?? join(runDir, "net", "keys"));
  const gatewayUrl = overrides.gatewayUrl ?? process.env["GATEWAY_URL"] ?? "http://127.0.0.1:8080";
  let networkId = overrides.networkId ?? process.env["NETWORK_ID"];
  if (!networkId) {
    const f = join(runDir, "net", "network.json");
    if (existsSync(f)) {
      try {
        networkId = (JSON.parse(readFileSync(f, "utf8")) as { network_id?: string }).network_id;
      } catch {
        /* fall through to the default */
      }
    }
  }
  return { sdkRoot, runDir, keysDir, gatewayUrl, networkId: networkId ?? "aureom-retail-demo-1" };
}
