#!/usr/bin/env -S npx tsx
// Seed the minimum catalogue the demo needs when the Python migration has NOT been run:
//   SUP-009, product PRD-KETTLE / sku KETTLE-RED (scarce), chain-wide price 39.99 GBP, 2 units at STORE-N-01
//   and the open approved purchase order PO-2001 with 1 unit outstanding (mirrors migration/source/*.demo.json).
// Idempotent: anything that already exists (e.g. because the migration ran) is skipped.
//   RUN_DIR=... GATEWAY_URL=... npm run seed
import { TxRejectedError } from "../src/index.js";
import { connect, type Runtime } from "./runtime.js";

const rt = await connect({ identities: ["buyer-hq", "po-approver-hq", "catalog-mgr", "pricing-mgr", "manager-n01"] });

async function exists(key: string): Promise<boolean> {
  return (await rt.client.getRecord(key)).found;
}

async function step(label: string, key: string | undefined, run: (rt: Runtime) => Promise<unknown>): Promise<void> {
  if (key && (await exists(key))) return void console.log(`skip  ${label} (${key} exists)`);
  try {
    await run(rt);
    console.log(`ok    ${label}`);
  } catch (e) {
    if (e instanceof TxRejectedError) return void console.log(`FAIL  ${label}: ${e.resultName} ${e.message}`);
    throw e;
  }
}

const now = Date.now();
await step("supplier SUP-009", "supplier/SUP-009", (r) => r.send("buyer-hq", "CreateSupplier", { supplier_id: "SUP-009", name: "Brightway Appliances", terms: "NET30" }));
await step("product PRD-KETTLE / KETTLE-RED (scarce)", "product/PRD-KETTLE", (r) =>
  r.send("catalog-mgr", "CreateProduct", { product_id: "PRD-KETTLE", name: "Aureom Barista Kettle", brand: "Aureom", category: "kitchen", variants: [{ sku_id: "KETTLE-RED", unit: "EA", barcode: "5012345678900", scarce: true, attributes: { colour: "Red" } }] }),
);
await step("price 39.99 GBP (all locations)", "price/PR-KETTLE-RED-1", (r) =>
  r.send("pricing-mgr", "PublishPrice", { price_id: "PR-KETTLE-RED-1", sku: "KETTLE-RED", location_id: "*", currency: "GBP", unit_minor: 3999, effective_from_ms: now - 24 * 3600_000 }),
);
await step("purchase order PO-2001 (3 x KETTLE-RED to STORE-N-01)", "po/PO-2001", (r) =>
  r.send("buyer-hq", "CreatePurchaseOrder", { po_id: "PO-2001", supplier_id: "SUP-009", location_id: "STORE-N-01", currency: "GBP", ordered_at_ms: now - 3600_000, lines: [{ sku: "KETTLE-RED", qty: { v: 3, unit: "EA" }, unit_cost_minor: 1800 }] }),
);
const po = await rt.client.getRecord<{ status: string }>("po/PO-2001");
if (po.found && po.value?.status === "DRAFT") await step("approve PO-2001", undefined, (r) => r.send("po-approver-hq", "ApprovePurchaseOrder", { po_id: "PO-2001" }));
const po2 = await rt.client.getRecord<{ status: string; receipts?: string[] }>("po/PO-2001");
if (po2.found && po2.value?.status === "APPROVED" && !(po2.value.receipts?.length)) {
  await step("opening stock: receive 2 of 3 against PO-2001", "receipt/RCPT-SEED-1", (r) =>
    r.send("manager-n01", "ReceiveGoods", { receipt_id: "RCPT-SEED-1", location_id: "STORE-N-01", po_id: "PO-2001", effective_at_ms: Date.now(), lines: [{ sku: "KETTLE-RED", qty: { v: 2, unit: "EA" }, po_line: 1 }] }),
  );
}
const inv = await rt.client.inventory({ sku: "KETTLE-RED", location: "STORE-N-01" });
console.log("KETTLE-RED at STORE-N-01:", JSON.stringify(inv.balances[0]));
