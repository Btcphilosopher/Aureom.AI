#!/usr/bin/env -S npx tsx
// Sign and submit one transaction as a demo identity.
//   npm run send -- --signer manager-n01 --type AdjustStock --payload '{"op":"PROPOSE",...}' [--wait none|final|indexed] [--idem REF]
import { parseArgs } from "node:util";
import { TxRejectedError, isTxType, type TxPayloadMap, type TxType, type WaitMode } from "../src/index.js";
import { connect } from "./runtime.js";

const { values } = parseArgs({
  options: {
    signer: { type: "string" },
    type: { type: "string" },
    payload: { type: "string" },
    wait: { type: "string" },
    idem: { type: "string" },
    "run-dir": { type: "string" },
    gateway: { type: "string" },
  },
});
if (!values.signer || !values.type || !values.payload) {
  console.error("usage: npm run send -- --signer <identity> --type <TxType> --payload '<json>' [--wait none|final|indexed] [--idem ref]");
  process.exit(2);
}
if (!isTxType(values.type)) {
  console.error(`unknown tx type ${values.type}`);
  process.exit(2);
}
const rt = await connect({ identities: [values.signer], ...(values["run-dir"] ? { runDir: values["run-dir"] } : {}), ...(values.gateway ? { gatewayUrl: values.gateway } : {}) });
const type = values.type as TxType;
try {
  const r = await rt.send(values.signer, type, JSON.parse(values.payload) as TxPayloadMap[TxType], {
    wait: (values.wait ?? "final") as WaitMode,
    ...(values.idem ? { idempotencyRef: values.idem } : {}),
  });
  console.log(JSON.stringify({ tx_id: r.tx.txId, outcome: r.outcome }, null, 2));
} catch (e) {
  if (e instanceof TxRejectedError) {
    console.error(`${e.stage} rejected: ${e.resultName} (${e.resultCode}) ${e.message}`);
    process.exit(3);
  }
  throw e;
}
