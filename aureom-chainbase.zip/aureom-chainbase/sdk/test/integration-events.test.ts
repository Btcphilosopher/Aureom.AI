import { describe, expect, it } from "vitest";
import { ChainEventSource, MemoryCheckpointStore, eventNameFor, type ChainEvent, type ChainReader, type ListResponse, type TransactionRow, type TxDetail } from "../src/index.js";

interface FakeTx {
  tx_id: string;
  type: string;
  height: number;
  index: number;
  signer?: string;
  status?: "OK" | "REJECTED";
  payload?: Record<string, unknown>;
  result?: Record<string, unknown>;
}

/** A fake gateway projection: newest-first, paged, with a switchable REBUILDING state. */
class FakeReader implements ChainReader {
  txs: FakeTx[] = [];
  indexedHeight = 0;
  state = "OK";
  calls = 0;
  records = new Map<string, unknown>();
  add(...t: FakeTx[]): void {
    this.txs.push(...t);
    this.indexedHeight = Math.max(this.indexedHeight, ...t.map((x) => x.height));
  }
  async transactions(q: { status: "OK"; type?: string; from_height: number; limit: number; offset: number }): Promise<ListResponse<TransactionRow>> {
    this.calls++;
    const rows = this.txs
      .filter((t) => (t.status ?? "OK") === q.status && (!q.type || t.type === q.type) && t.height >= q.from_height)
      .sort((a, b) => b.height - a.height || b.index - a.index);
    const items = rows.slice(q.offset, q.offset + q.limit).map((t) => ({ tx_id: t.tx_id, type: t.type, signer: t.signer ?? "x", status: "OK" as const, code: 0, code_name: "OK", height: t.height, index_in_block: t.index, block_time_ms: t.height * 1000, client_time_ms: 0 }));
    return { meta: { indexed_height: this.indexedHeight, chain_head: this.indexedHeight, lag_blocks: 0, projection_state: this.state }, items, total: rows.length };
  }
  async txDetail(txId: string): Promise<TxDetail> {
    const t = this.txs.find((x) => x.tx_id === txId)!;
    return { payload: t.payload ?? {}, result: t.result ?? {}, recordsChanged: [`k/${txId}`] };
  }
  async getRecord(key: string) {
    const v = this.records.get(key);
    return { key, found: v !== undefined, ...(v !== undefined ? { value: v } : {}), height: this.indexedHeight };
  }
}

const sale = (n: number, h: number, i = 0): FakeTx => ({ tx_id: `tx-sale-${n}`, type: "CompleteSale", height: h, index: i, payload: { sale_id: `S-${n}` }, result: { sale_id: `S-${n}`, net_minor: 100 * n } });

describe("ChainEventSource (outbound events)", () => {
  it("event names map from transaction types and results", () => {
    expect(eventNameFor("CompleteSale", {}, {})).toBe("sale.completed");
    expect(eventNameFor("ReceiveReturnedGoods", { refund_id: "RF-1" }, {})).toBe("refund.instructed");
    expect(eventNameFor("ReceiveReturnedGoods", {}, {})).toBe("return.received");
    expect(eventNameFor("TransferStock", {}, { op: "DISPATCH" })).toBe("transfer.dispatch");
    expect(eventNameFor("AdjustStock", {}, { op: "PROPOSE" })).toBe("adjustment.propose");
    expect(eventNameFor("CreateSupplier", {}, {})).toBe("tx.CreateSupplier");
  });

  it("starts from 'now' by default: history is not replayed, new finalised transactions are delivered once, in chain order", async () => {
    const reader = new FakeReader();
    reader.add(sale(1, 10));
    const src = new ChainEventSource({ reader });
    const got: ChainEvent[] = [];
    src.on("sale.completed", (e) => void got.push(e));
    expect(await src.poll()).toHaveLength(0);
    reader.add(sale(3, 12, 1), sale(2, 12, 0), sale(4, 13));
    const first = await src.poll();
    expect(first.map((e) => e.txId)).toEqual(["tx-sale-2", "tx-sale-3", "tx-sale-4"]); // ascending (height, index)
    expect(first[0]).toMatchObject({ name: "sale.completed", txType: "CompleteSale", height: 12, index: 0, payload: { sale_id: "S-2" }, result: { net_minor: 200 }, recordsChanged: ["k/tx-sale-2"] });
    expect(await src.poll()).toHaveLength(0); // nothing new: no duplicates
    expect(got).toHaveLength(3);
  });

  it("can start from the beginning, pages through large histories, and only asks for subscribed types", async () => {
    const reader = new FakeReader();
    for (let n = 1; n <= 7; n++) reader.add(sale(n, n));
    reader.add({ tx_id: "tx-other", type: "CreateSupplier", height: 8, index: 0 });
    const src = new ChainEventSource({ reader, startFrom: "beginning", pageSize: 3 });
    const got: string[] = [];
    src.on("sale.completed", (e) => void got.push(e.txId));
    await src.poll();
    expect(got).toEqual(Array.from({ length: 7 }, (_, i) => `tx-sale-${i + 1}`)); // CreateSupplier never fetched/delivered
  });

  it("refund.instructed carries the refund record; unsubscribed names are not delivered", async () => {
    const reader = new FakeReader();
    reader.records.set("refund/RF-RET-1-001", { id: "RF-RET-1-001", sale_id: "S-1", amount_minor: 3999, status: "INSTRUCTED" });
    const src = new ChainEventSource({ reader, startFrom: "beginning" });
    const refunds: ChainEvent[] = [];
    src.on("refund.instructed", (e) => void refunds.push(e));
    reader.add({ tx_id: "tx-rcv", type: "ReceiveReturnedGoods", height: 5, index: 0, result: { return_id: "RET-1", refund_id: "RF-RET-1-001", refund_instructed_minor: 3999 } }, { tx_id: "tx-rcv2", type: "ReceiveReturnedGoods", height: 6, index: 0, result: { return_id: "RET-2", status: "REJECTED" } });
    await src.poll();
    expect(refunds).toHaveLength(1);
    expect(refunds[0]?.details).toEqual({ refund: { id: "RF-RET-1-001", sale_id: "S-1", amount_minor: 3999, status: "INSTRUCTED" } });
  });

  it("a failing handler does not advance the checkpoint: the event is redelivered (at-least-once)", async () => {
    const reader = new FakeReader();
    const cp = new MemoryCheckpointStore();
    const src = new ChainEventSource({ reader, checkpoint: cp, startFrom: "beginning" });
    let fail = true;
    const seen: string[] = [];
    src.on("*", (e) => {
      if (e.txId === "tx-sale-2" && fail) throw new Error("downstream down");
      seen.push(e.txId);
    });
    reader.add(sale(1, 1), sale(2, 2), sale(3, 3));
    await expect(src.poll()).rejects.toThrow("downstream down");
    expect(seen).toEqual(["tx-sale-1"]);
    expect(await cp.load()).toEqual({ height: 1, index: 0 });
    fail = false;
    await src.poll();
    expect(seen).toEqual(["tx-sale-1", "tx-sale-2", "tx-sale-3"]);
  });

  it("resumes from a persisted checkpoint across instances", async () => {
    const reader = new FakeReader();
    const cp = new MemoryCheckpointStore();
    reader.add(sale(1, 1), sale(2, 2));
    const a = new ChainEventSource({ reader, checkpoint: cp, startFrom: "beginning" });
    a.on("*", () => undefined);
    await a.poll();
    reader.add(sale(3, 3));
    const b = new ChainEventSource({ reader, checkpoint: cp });
    const got: string[] = [];
    b.on("*", (e) => void got.push(e.txId));
    await b.poll();
    expect(got).toEqual(["tx-sale-3"]);
  });

  it("emits nothing while the projection is REBUILDING and resumes afterwards without loss or duplicates", async () => {
    const reader = new FakeReader();
    const src = new ChainEventSource({ reader, startFrom: "beginning" });
    const got: string[] = [];
    src.on("*", (e) => void got.push(e.txId));
    reader.add(sale(1, 1));
    await src.poll();
    reader.state = "REBUILDING";
    reader.add(sale(2, 2));
    expect(await src.poll()).toEqual([]);
    reader.state = "OK";
    await src.poll();
    expect(got).toEqual(["tx-sale-1", "tx-sale-2"]);
  });

  it("unsubscribe stops delivery; run() polls until aborted and reports errors without dying", async () => {
    const reader = new FakeReader();
    const errors: unknown[] = [];
    let ticks = 0;
    const ctl = new AbortController();
    const src = new ChainEventSource({
      reader,
      startFrom: "beginning",
      onError: (e) => void errors.push(e),
      sleep: async () => {
        if (++ticks >= 3) ctl.abort();
      },
    });
    const got: string[] = [];
    const off = src.on("*", (e) => void got.push(e.txId));
    reader.add(sale(1, 1));
    await src.run({ signal: ctl.signal });
    expect(got).toEqual(["tx-sale-1"]);
    off();
    reader.add(sale(2, 2));
    expect(await src.poll()).toEqual([]);
    expect(errors).toEqual([]);
  });
});
