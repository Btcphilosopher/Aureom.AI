import { mkdtemp, readFile, rm, writeFile, chmod, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  DEFAULT_KDF,
  EncryptedFileKeyStore,
  ExternalSignerKeyStore,
  KeyStoreError,
  MemoryKeyStore,
  RawKeyFileStore,
  Signer,
  TxBuilder,
  UnconfiguredExternalSigner,
  buildRevokeKeyTx,
  buildRotateKeyTx,
  base64ToBytes,
  bytesToBase64,
  bytesToHex,
  hexToBytes,
  keyRef,
  rotateKey,
  verifyEnvelope,
  verifySignature,
  type ExternalSignerBackend,
} from "../src/node.js";
import { ed25519 } from "@noble/curves/ed25519.js";

const FAST = { N: 1 << 12, r: 8, p: 1 };
let dir: string;
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "aureom-ks-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

const msg = new TextEncoder().encode("message to sign");

describe("MemoryKeyStore", () => {
  it("generates, lists, signs and verifies", async () => {
    const s = new MemoryKeyStore();
    const info = await s.generate("term-n01-1", "k1");
    expect(info.ref).toBe(keyRef("term-n01-1", "k1"));
    expect((await s.list()).map((k) => k.ref)).toEqual(["term-n01-1#k1"]);
    const sig = await s.sign(info.ref, msg);
    expect(sig.length).toBe(64);
    expect(verifySignature(await s.publicKey(info.ref), msg, sig)).toBe(true);
    expect(verifySignature(await s.publicKey(info.ref), new Uint8Array(1), sig)).toBe(false);
  });
  it("rejects duplicates and unknown refs, and wipes", async () => {
    const s = new MemoryKeyStore();
    await s.generate("a", "k1");
    await expect(s.generate("a", "k1")).rejects.toMatchObject({ code: "KEY_EXISTS" });
    await expect(s.sign("nope#k1", msg)).rejects.toMatchObject({ code: "KEY_NOT_FOUND" });
    s.wipe();
    expect(await s.list()).toEqual([]);
  });
  it("does not leak mutable internals", async () => {
    const s = new MemoryKeyStore();
    const info = await s.generate("a", "k1");
    const pub = await s.publicKey(info.ref);
    pub.fill(0);
    const sig = await s.sign(info.ref, msg);
    expect(verifySignature(info.publicKey, msg, sig)).toBe(true);
  });
  it("Signer.forIdentity picks the latest key unless told otherwise", async () => {
    const s = new MemoryKeyStore();
    await s.generate("a", "k1");
    await s.generate("a", "k2");
    expect((await Signer.forIdentity(s, "a")).keyId).toBe("k2");
    expect((await Signer.forIdentity(s, "a", "k1")).keyId).toBe("k1");
    await expect(Signer.forIdentity(s, "zzz")).rejects.toMatchObject({ code: "KEY_NOT_FOUND" });
  });
});

describe("RawKeyFileStore (Go tool key files)", () => {
  async function writeGoKeyFile(identity: string, mode = 0o600) {
    const seed = ed25519.utils.randomSecretKey();
    const pub = ed25519.getPublicKey(seed);
    const path = join(dir, `${identity}.json`);
    await writeFile(path, JSON.stringify({ identity, key_id: "k1", seed_hex: bytesToHex(seed), pub_b64: bytesToBase64(pub) }, null, 2), { mode });
    await chmod(path, mode);
    return { seed, pub };
  }

  it("loads {identity,key_id,seed_hex,pub_b64} files and signs", async () => {
    const a = await writeGoKeyFile("term-n01-1");
    await writeGoKeyFile("term-n01-2");
    await writeFile(join(dir, "notes.json"), "{}");
    const s = await RawKeyFileStore.open(dir);
    expect((await s.list()).map((k) => k.ref).sort()).toEqual(["term-n01-1#k1", "term-n01-2#k1"]);
    const sig = await s.sign("term-n01-1#k1", msg);
    expect(verifySignature(a.pub, msg, sig)).toBe(true);
    expect(s.insecureFiles).toEqual([]);
  });

  it("can load only the identities it needs (least privilege)", async () => {
    await writeGoKeyFile("term-n01-1");
    await writeGoKeyFile("manager-n01");
    const s = await RawKeyFileStore.open(dir, { identities: ["term-n01-1"] });
    expect((await s.list()).map((k) => k.identity)).toEqual(["term-n01-1"]);
    await expect(RawKeyFileStore.open(dir, { identities: ["nobody"] })).rejects.toMatchObject({ code: "KEY_NOT_FOUND" });
  });

  it("reports (or refuses) group/other-readable key files", async () => {
    await writeGoKeyFile("loose", 0o644);
    const s = await RawKeyFileStore.open(dir);
    expect(s.insecureFiles.length).toBe(1);
    await expect(RawKeyFileStore.open(dir, { strictPermissions: true })).rejects.toBeInstanceOf(KeyStoreError);
  });

  it("detects a pub_b64 that does not match the seed", async () => {
    const seed = ed25519.utils.randomSecretKey();
    await writeFile(join(dir, "x.json"), JSON.stringify({ identity: "x", key_id: "k1", seed_hex: bytesToHex(seed), pub_b64: bytesToBase64(new Uint8Array(32)) }), { mode: 0o600 });
    await expect(RawKeyFileStore.open(dir)).rejects.toMatchObject({ code: "CORRUPT_KEYSTORE" });
  });

  it("persists rotated keys as <identity>.<key_id>.json (mode 0600) and removes them on rollback", async () => {
    await writeGoKeyFile("term-n01-1");
    const s = await RawKeyFileStore.open(dir);
    const k2 = await s.generate("term-n01-1", "k2");
    expect((await readdir(dir)).sort()).toContain("term-n01-1.k2.json");
    const again = await RawKeyFileStore.open(dir);
    expect((await again.list()).map((k) => k.ref)).toContain("term-n01-1#k2");
    expect(bytesToHex((await again.publicKey("term-n01-1#k2")))).toBe(bytesToHex(k2.publicKey));
    await s.remove(k2.ref);
    expect(await readdir(dir)).not.toContain("term-n01-1.k2.json");
  });
});

describe("EncryptedFileKeyStore (scrypt + AES-256-GCM)", () => {
  const pass = "correct horse battery staple";

  it("round-trips: create, add keys, reopen with the passphrase, same public keys and signatures verify", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const a = await s.generate("term-n01-1", "k1");
    const seed = ed25519.utils.randomSecretKey();
    const b = await s.addSeed("manager-n01", "k1", seed);

    const reopened = await EncryptedFileKeyStore.open(path, pass);
    const list = await reopened.list();
    expect(list.map((k) => k.ref).sort()).toEqual(["manager-n01#k1", "term-n01-1#k1"]);
    expect(bytesToHex(await reopened.publicKey(a.ref))).toBe(bytesToHex(a.publicKey));
    // deterministic Ed25519: a signature from the reopened store equals one made directly from the seed
    expect(bytesToHex(await reopened.sign(b.ref, msg))).toBe(bytesToHex(ed25519.sign(msg, seed)));
    expect(verifySignature(a.publicKey, msg, await reopened.sign(a.ref, msg))).toBe(true);
  });

  it("works with the default (OWASP-grade) scrypt cost", async () => {
    const path = join(dir, "vault-default.json");
    const s = await EncryptedFileKeyStore.create(path, pass);
    await s.generate("x", "k1");
    const file = JSON.parse(await readFile(path, "utf8")) as { kdf: { N: number; r: number; p: number } };
    expect(file.kdf).toMatchObject({ N: DEFAULT_KDF.N, r: DEFAULT_KDF.r, p: DEFAULT_KDF.p });
    const re = await EncryptedFileKeyStore.open(path, pass);
    expect((await re.list()).length).toBe(1);
  });

  it("fails with BAD_PASSPHRASE on a wrong passphrase", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    await s.generate("term-n01-1", "k1");
    await expect(EncryptedFileKeyStore.open(path, "wrong passphrase!!")).rejects.toMatchObject({ code: "BAD_PASSPHRASE" });
    await expect(EncryptedFileKeyStore.open(path, "")).rejects.toMatchObject({ code: "BAD_PASSPHRASE" });
  });

  it("never writes seeds to disk in the clear", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const seed = ed25519.utils.randomSecretKey();
    await s.addSeed("a", "k1", seed);
    const text = await readFile(path, "utf8");
    expect(text).not.toContain(bytesToHex(seed));
    expect(text).not.toContain(bytesToBase64(seed));
    expect(text).not.toContain(pass);
  });

  it("detects tampering with ciphertext, public key list and KDF parameters", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const k = await s.generate("a", "k1");
    interface Vault {
      ciphertext_b64: string;
      cipher: { iv_b64: string; tag_b64: string };
      keys: { identity: string; pub_b64: string }[];
      kdf: { N: number };
    }
    const original = JSON.parse(await readFile(path, "utf8")) as Vault;

    const flip = (b64: string) => {
      const b = base64ToBytes(b64);
      b[0] = b[0]! ^ 1;
      return bytesToBase64(b);
    };
    const variants: Record<string, (f: Vault) => void> = {
      ciphertext: (f) => void (f.ciphertext_b64 = flip(f.ciphertext_b64)),
      tag: (f) => void (f.cipher.tag_b64 = flip(f.cipher.tag_b64)),
      iv: (f) => void (f.cipher.iv_b64 = flip(f.cipher.iv_b64)),
      swappedPublicKey: (f) => void (f.keys[0]!.pub_b64 = bytesToBase64(ed25519.getPublicKey(ed25519.utils.randomSecretKey()))),
      renamedIdentity: (f) => void (f.keys[0]!.identity = "mallory"),
      weakenedKdf: (f) => void (f.kdf.N = 1 << 4),
    };
    for (const [name, mutate] of Object.entries(variants)) {
      const f = structuredClone(original);
      mutate(f);
      const p = join(dir, `tampered-${name}.json`);
      await writeFile(p, JSON.stringify(f));
      await expect(EncryptedFileKeyStore.open(p, pass), name).rejects.toBeInstanceOf(KeyStoreError);
    }
    expect(k.ref).toBe("a#k1");
  });

  it("refuses absurd scrypt costs from an untrusted file (DoS guard)", async () => {
    const path = join(dir, "vault.json");
    await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const f = JSON.parse(await readFile(path, "utf8")) as { kdf: { N: number } };
    f.kdf.N = 1 << 30;
    await writeFile(path, JSON.stringify(f));
    await expect(EncryptedFileKeyStore.open(path, pass)).rejects.toMatchObject({ code: "CORRUPT_KEYSTORE" });
  });

  it("uses a fresh salt and IV on every save", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const a = JSON.parse(await readFile(path, "utf8")) as { kdf: { salt_b64: string }; cipher: { iv_b64: string } };
    await s.generate("a", "k1");
    const b = JSON.parse(await readFile(path, "utf8")) as { kdf: { salt_b64: string }; cipher: { iv_b64: string } };
    expect(b.kdf.salt_b64).not.toBe(a.kdf.salt_b64);
    expect(b.cipher.iv_b64).not.toBe(a.cipher.iv_b64);
  });

  it("changePassphrase re-encrypts: old passphrase stops working", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    await s.generate("a", "k1");
    await s.changePassphrase("a brand new passphrase");
    await expect(EncryptedFileKeyStore.open(path, pass)).rejects.toMatchObject({ code: "BAD_PASSPHRASE" });
    expect((await (await EncryptedFileKeyStore.open(path, "a brand new passphrase")).list()).length).toBe(1);
  });

  it("lock() wipes memory and blocks signing", async () => {
    const path = join(dir, "vault.json");
    const s = await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const k = await s.generate("a", "k1");
    s.lock();
    await expect(s.sign(k.ref, msg)).rejects.toMatchObject({ code: "LOCKED" });
    expect(await s.list()).toEqual([]);
  });

  it("enforces a minimum passphrase length and never overwrites an existing vault on create", async () => {
    const path = join(dir, "vault.json");
    await expect(EncryptedFileKeyStore.create(path, "short", { kdf: FAST })).rejects.toMatchObject({ code: "BAD_PASSPHRASE" });
    await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    await expect(EncryptedFileKeyStore.create(path, pass, { kdf: FAST })).rejects.toMatchObject({ code: "KEY_EXISTS" });
  });

  it("writes the vault with owner-only permissions", async () => {
    const path = join(dir, "vault.json");
    await EncryptedFileKeyStore.create(path, pass, { kdf: FAST });
    const { mode } = await (await import("node:fs/promises")).stat(path);
    expect(mode & 0o077).toBe(0);
  });
});

describe("ExternalSignerKeyStore (HSM/KMS adapter)", () => {
  // A fake device: the private key lives only inside this closure; the adapter never sees it.
  function fakeDevice(opts: { wrongKey?: boolean; shortSig?: boolean } = {}): ExternalSignerBackend {
    const secret = ed25519.utils.randomSecretKey();
    const other = ed25519.utils.randomSecretKey();
    const pub = ed25519.getPublicKey(secret);
    return {
      async listKeys() {
        return [{ handle: "hsm://slot1/term-n01-1", identity: "term-n01-1", keyId: "k1", publicKey: pub }];
      },
      async signRaw(_handle, message) {
        if (opts.shortSig) return new Uint8Array(10);
        return ed25519.sign(message, opts.wrongKey ? other : secret);
      },
    };
  }

  it("signs through the device and works as a TxBuilder signer", async () => {
    const store = new ExternalSignerKeyStore(fakeDevice());
    const signer = await Signer.forIdentity(store, "term-n01-1");
    const tx = await new TxBuilder({ networkId: "net-1", signer }).build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
    expect(verifyEnvelope(tx.envelope, "net-1").ok).toBe(true);
  });

  it("verifies device signatures and fails loudly on a misconfigured device", async () => {
    await expect(new ExternalSignerKeyStore(fakeDevice({ wrongKey: true })).sign("term-n01-1#k1", msg)).rejects.toMatchObject({ code: "SIGNER_ERROR" });
    await expect(new ExternalSignerKeyStore(fakeDevice({ shortSig: true })).sign("term-n01-1#k1", msg)).rejects.toMatchObject({ code: "SIGNER_ERROR" });
  });

  it("the unconfigured stub refuses to sign and explains why", async () => {
    const store = new ExternalSignerKeyStore(new UnconfiguredExternalSigner());
    expect(await store.list()).toEqual([]);
    await expect(new UnconfiguredExternalSigner().signRaw("x", msg)).rejects.toThrow(/never leave the device/);
  });
});

describe("key rotation and revocation helpers", () => {
  it("rotateKey generates a new key and builds a RotateKey tx signed by the OLD key", async () => {
    const store = new MemoryKeyStore();
    await store.generate("term-n01-1", "k1");
    const builder = new TxBuilder({ networkId: "net-1", signer: await Signer.forIdentity(store, "term-n01-1") });
    const r = await rotateKey({ builder, store, newKeyId: "k2", reason: "scheduled rotation" });

    expect(r.tx.type).toBe("RotateKey");
    expect(r.tx.keyId).toBe("k1");
    expect(r.tx.body.payload).toEqual({ identity_id: "term-n01-1", new_key_id: "k2", new_pub_b64: bytesToBase64(r.newKey.publicKey), reason: "scheduled rotation" });
    const check = verifyEnvelope(r.tx.envelope, "net-1");
    expect(check.ok).toBe(true);
    expect(bytesToHex(base64ToBytes(r.tx.envelope.pub))).toBe(bytesToHex((await store.publicKey("term-n01-1#k1"))));

    // the new builder signs with k2
    const next = await r.builder.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
    expect(next.keyId).toBe("k2");
    expect(next.envelope.pub).toBe(bytesToBase64(r.newKey.publicKey));
  });

  it("buildRotateKeyTx / buildRevokeKeyTx validate input", async () => {
    const store = new MemoryKeyStore();
    await store.generate("manager-n01", "k1");
    const builder = new TxBuilder({ networkId: "net-1", signer: await Signer.forIdentity(store, "manager-n01") });
    await expect(buildRotateKeyTx(builder, { newKeyId: "k2", newPublicKey: new Uint8Array(5), reason: "x" })).rejects.toThrow(/32 bytes/);
    await expect(buildRotateKeyTx(builder, { newKeyId: "k2", newPublicKey: new Uint8Array(32), reason: "" })).rejects.toThrow(/reason/);
    const rev = await buildRevokeKeyTx(builder, { keyId: "k1", reason: "laptop stolen" });
    expect(rev.body.payload).toEqual({ identity_id: "manager-n01", key_id: "k1", reason: "laptop stolen" });
    // an iam.admin revoking someone else's key
    const admin = await buildRevokeKeyTx(builder, { identityId: "term-n01-2", keyId: "k1", reason: "compromised" });
    expect(admin.body.payload).toMatchObject({ identity_id: "term-n01-2" });
  });

  it("a failed rotation can be rolled back by removing the unused key", async () => {
    const store = new MemoryKeyStore();
    await store.generate("a", "k1");
    const builder = new TxBuilder({ networkId: "net-1", signer: await Signer.forIdentity(store, "a") });
    const r = await rotateKey({ builder, store, newKeyId: "k2", reason: "r" });
    await store.remove(r.newKey.ref);
    expect((await store.list()).map((k) => k.ref)).toEqual(["a#k1"]);
  });
});

it("hex helpers round-trip", () => {
  expect(bytesToHex(hexToBytes("00ff10"))).toBe("00ff10");
});
