import { mkdtemp, readFile, rm, readdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { FileCheckpointStore, FileDeadLetterStore, JsonlReconciliationSink, type DeadLetter, type ReconciliationException } from "../src/node.js";
import { FileStateStore, newState } from "../terminal/state.js";

let dir: string;
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "aureom-files-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

describe("terminal FileStateStore", () => {
  it("round-trips, creates parent directories, and returns undefined when absent", async () => {
    const store = new FileStateStore(join(dir, "nested", "term.json"));
    expect(await store.load()).toBeUndefined();
    const s = newState({ terminal_id: "term-n01-1", location_id: "STORE-N-01", network_id: "net-1", now: 1 });
    s.counters.queue = 7;
    await store.save(s);
    expect((await store.load())?.counters.queue).toBe(7);
  });
  it("never leaves a temp file behind and replaces the previous content atomically", async () => {
    const store = new FileStateStore(join(dir, "term.json"));
    const s = newState({ terminal_id: "t", location_id: "L", network_id: "n", now: 1 });
    for (let i = 0; i < 5; i++) {
      s.counters.queue = i;
      await store.save(s);
    }
    expect(await readdir(dir)).toEqual(["term.json"]);
    expect(JSON.parse(await readFile(join(dir, "term.json"), "utf8")).counters.queue).toBe(4);
  });
  it("refuses a state file of an unknown version", async () => {
    await writeFile(join(dir, "x.json"), JSON.stringify({ version: 99 }));
    await expect(new FileStateStore(join(dir, "x.json")).load()).rejects.toThrow(/version/);
  });
});

describe("integration file stores", () => {
  const dl = (id: string): DeadLetter => ({ id, adapter: "a", eventId: "e", receivedAtMs: 1, failedAtMs: 2, failure: { stage: "business", code: "X", reason: "r", attempts: 1, transient: false }, event: { rawBody: "{}" }, applied: [], replays: 0 });

  it("FileDeadLetterStore add/get/list/update/remove, one JSON file per entry, unsafe ids refused", async () => {
    const s = new FileDeadLetterStore(join(dir, "dlq"));
    expect(await s.list()).toEqual([]);
    await s.add(dl("DLQ-1"));
    await s.add(dl("DLQ-2"));
    expect((await s.list()).map((d) => d.id)).toEqual(["DLQ-1", "DLQ-2"]);
    await s.update({ ...dl("DLQ-1"), replays: 3 });
    expect((await s.get("DLQ-1"))?.replays).toBe(3);
    await s.remove("DLQ-1");
    expect(await s.get("DLQ-1")).toBeUndefined();
    await expect(s.add(dl("../escape"))).rejects.toThrow(/unsafe/);
  });

  it("JsonlReconciliationSink appends one JSON object per line", async () => {
    const sink = new JsonlReconciliationSink(join(dir, "recon", "exceptions.jsonl"));
    const e = (id: string): ReconciliationException => ({ id, adapter: "a", eventId: "e", subject: "s", severity: "HIGH", kind: "UNAPPLIED_EVENT", detail: "d", suggestedAction: "x", createdAtMs: 1 });
    await sink.report(e("R1"));
    await sink.report(e("R2"));
    const lines = (await readFile(join(dir, "recon", "exceptions.jsonl"), "utf8")).trim().split("\n");
    expect(lines.map((l) => (JSON.parse(l) as ReconciliationException).id)).toEqual(["R1", "R2"]);
  });

  it("FileCheckpointStore persists the cursor", async () => {
    const c = new FileCheckpointStore(join(dir, "cp.json"));
    expect(await c.load()).toBeUndefined();
    await c.save({ height: 12, index: 3 });
    expect(await new FileCheckpointStore(join(dir, "cp.json")).load()).toEqual({ height: 12, index: 3 });
  });
});
