import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  MemoryKeyStore,
  Signer,
  TxBuilder,
  SIG_DOMAIN,
  assertWireSafe,
  base64ToBytes,
  bytesToBase64,
  bytesToHex,
  encodeBody,
  hexToBytes,
  parseEnvelope,
  preimage,
  signBody,
  txHashOf,
  utf8,
  verifyEnvelope,
  type TxBody,
  type TxType,
} from "../src/index.js";

interface SignVec {
  name: string;
  network_id: string;
  seed_hex: string;
  pub_b64: string;
  tx_id: string;
  type: TxType;
  signer: string;
  key_id: string;
  idempotency_ref: string;
  expected_version?: number;
  client_time_ms: number;
  valid_until_height?: number;
  payload_text: string;
  body_b64: string;
  preimage_hex: string;
  sig_b64: string;
  envelope: string;
  tx_hash: string;
}
const golden = JSON.parse(readFileSync(new URL("./golden.json", import.meta.url), "utf8")) as { sign: SignVec[] };

async function signerFor(v: SignVec): Promise<Signer> {
  const store = new MemoryKeyStore();
  await store.addSeed(v.signer, v.key_id, hexToBytes(v.seed_hex));
  return Signer.forIdentity(store, v.signer, v.key_id);
}

function bodyOf(v: SignVec): TxBody {
  // The golden payload text is canonical JS JSON, so parse -> stringify is the identity.
  expect(JSON.stringify(JSON.parse(v.payload_text))).toBe(v.payload_text);
  const b: TxBody = {
    tx_id: v.tx_id,
    network_id: v.network_id,
    type: v.type,
    schema_version: 1,
    signer: v.signer,
    key_id: v.key_id,
    idempotency_ref: v.idempotency_ref,
    client_time_ms: v.client_time_ms,
    payload: JSON.parse(v.payload_text) as never,
  };
  if (v.expected_version !== undefined) b.expected_version = v.expected_version;
  if (v.valid_until_height) b.valid_until_height = v.valid_until_height;
  return b;
}

describe("signing: byte-compatibility with the Go reference signer (core.SignTx)", () => {
  it("has golden vectors", () => {
    expect(golden.sign.length).toBeGreaterThanOrEqual(4);
  });

  for (const v of golden.sign) {
    describe(v.name, () => {
      it("produces byte-identical body, preimage, signature, envelope and tx hash", async () => {
        const signer = await signerFor(v);
        expect(signer.publicKeyB64).toBe(v.pub_b64);
        const body = bodyOf(v);
        expect(bytesToBase64(encodeBody(body))).toBe(v.body_b64);
        expect(bytesToHex(preimage(v.network_id, base64ToBytes(v.body_b64)))).toBe(v.preimage_hex);
        const tx = await signBody(signer, body);
        expect(tx.envelope.sig).toBe(v.sig_b64);
        expect(tx.envelope.body).toBe(v.body_b64);
        expect(tx.json).toBe(v.envelope);
        expect(tx.txHash).toBe(v.tx_hash);
        expect(txHashOf(utf8(v.envelope))).toBe(v.tx_hash);
      });

      it("verifies the Go-signed envelope locally (stage 2: cryptographic validity)", () => {
        const r = verifyEnvelope(v.envelope, v.network_id);
        expect(r.ok).toBe(true);
        expect(r.body?.tx_id).toBe(v.tx_id);
      });

      it("rejects the Go-signed envelope under another network id (cross-network replay protection)", () => {
        expect(verifyEnvelope(v.envelope, "some-other-network").ok).toBe(false);
      });
    });
  }

  it("preimage layout is domain 0x00 network 0x00 body", () => {
    const p = preimage("net-1", utf8("{}"));
    expect(Array.from(p)).toEqual([...Array.from(utf8(SIG_DOMAIN)), 0, ...Array.from(utf8("net-1")), 0, ...Array.from(utf8("{}"))]);
  });

  it("detects a tampered body or signature", () => {
    const v = golden.sign[0]!;
    const env = parseEnvelope(v.envelope);
    const body = base64ToBytes(env.body);
    body[10] = body[10]! ^ 1;
    expect(verifyEnvelope({ ...env, body: bytesToBase64(body) }, v.network_id).ok).toBe(false);
    const sig = base64ToBytes(env.sig);
    sig[0] = sig[0]! ^ 1;
    expect(verifyEnvelope({ ...env, sig: bytesToBase64(sig) }, v.network_id).ok).toBe(false);
  });
});

describe("TxBuilder", () => {
  async function builder(now = () => 1_790_000_000_000) {
    const store = new MemoryKeyStore();
    await store.generate("term-n01-1", "k1");
    return new TxBuilder({ networkId: "net-test-1", signer: await Signer.forIdentity(store, "term-n01-1"), now });
  }

  it("fills tx_id, idempotency_ref, schema_version, network_id, client_time_ms and signs", async () => {
    const b = await builder();
    const tx = await b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
    expect(tx.body.tx_id).toMatch(/^[A-Za-z0-9_-]{8,64}$/);
    expect(tx.body.idempotency_ref).toBe(`idem-${tx.body.tx_id}`);
    expect(tx.body.schema_version).toBe(1);
    expect(tx.body.network_id).toBe("net-test-1");
    expect(tx.body.client_time_ms).toBe(1_790_000_000_000);
    expect(tx.body.signer).toBe("term-n01-1");
    expect(tx.body.key_id).toBe("k1");
    expect(verifyEnvelope(tx.envelope, "net-test-1").ok).toBe(true);
  });

  it("generates unique tx ids", async () => {
    const b = await builder();
    const ids = new Set<string>();
    for (let i = 0; i < 200; i++) ids.add((await b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" })).txId);
    expect(ids.size).toBe(200);
  });

  it("carries expected_version (including 0) and valid_until_height", async () => {
    const b = await builder();
    const tx = await b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" }, { expectedVersion: 0, validUntilHeight: 500, idempotencyRef: "release:RES-1" });
    const parsed = JSON.parse(new TextDecoder().decode(tx.bodyBytes)) as Record<string, unknown>;
    expect(parsed["expected_version"]).toBe(0);
    expect(parsed["valid_until_height"]).toBe(500);
    expect(parsed["idempotency_ref"]).toBe("release:RES-1");
    // field order matches Go's struct order
    expect(Object.keys(parsed)).toEqual(["tx_id", "network_id", "type", "schema_version", "signer", "key_id", "idempotency_ref", "expected_version", "client_time_ms", "valid_until_height", "payload"]);
  });

  it("omits expected_version and valid_until_height when unset", async () => {
    const b = await builder();
    const tx = await b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
    const parsed = JSON.parse(new TextDecoder().decode(tx.bodyBytes)) as Record<string, unknown>;
    expect("expected_version" in parsed).toBe(false);
    expect("valid_until_height" in parsed).toBe(false);
  });

  it("rejects malformed ids and non-integer numbers before signing", async () => {
    const b = await builder();
    await expect(b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" }, { txId: "short" })).rejects.toThrow(/tx_id/);
    await expect(b.build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" }, { idempotencyRef: "-bad" })).rejects.toThrow(/idempotency_ref/);
    await expect(b.build("ReserveStock", { reservation_id: "R-1", location_id: "L", sku: "S", qty: { v: 1.5, unit: "EA" }, ttl_ms: 1000 })).rejects.toThrow(/safe integer/);
    expect(() => assertWireSafe({ a: [NaN] })).toThrow();
    expect(() => assertWireSafe({ a: 2 ** 60 })).toThrow();
  });

  it("refuses to sign a body that names a different signer than the key", async () => {
    const b = await builder();
    const body = b.body("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
    await expect(signBody(b.signer, { ...body, signer: "someone-else" })).rejects.toThrow(/signer/);
  });
});
