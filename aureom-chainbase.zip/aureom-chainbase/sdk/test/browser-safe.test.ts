import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

// The signing / client path (everything reachable from src/index.ts) must run in a browser:
// no node: imports, no Buffer, no process, no require().
const root = resolve(dirname(fileURLToPath(import.meta.url)), "../src");

function reachable(entry: string): string[] {
  const seen = new Set<string>();
  const walk = (file: string) => {
    if (seen.has(file)) return;
    seen.add(file);
    const text = readFileSync(file, "utf8");
    for (const m of text.matchAll(/from\s+"(\.[^"]+)\.js"/g)) walk(resolve(dirname(file), `${m[1]}.ts`));
  };
  walk(entry);
  return [...seen];
}

describe("browser-safe core", () => {
  const files = reachable(resolve(root, "index.ts"));

  it("covers the whole core (sanity)", () => {
    const names = files.map((f) => f.slice(root.length + 1));
    for (const expected of ["tx.ts", "client.ts", "proof.ts", "keystore.ts", "integration/runner.ts", "integration/events.ts"]) expect(names).toContain(expected);
    expect(names).not.toContain("keystore-rawfile.ts");
    expect(names).not.toContain("keystore-encrypted.ts");
  });

  it("uses no node: modules, Buffer, process, require or __dirname", () => {
    for (const f of files) {
      const code = readFileSync(f, "utf8").replace(/\/\/.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "");
      expect(code, f).not.toMatch(/from\s+"node:/);
      expect(code, f).not.toMatch(/\bBuffer\b/);
      expect(code, f).not.toMatch(/\bprocess\./);
      expect(code, f).not.toMatch(/\brequire\(/);
      expect(code, f).not.toMatch(/__dirname|__filename/);
    }
  });

  it("node-only code lives only in the node entry point", () => {
    const node = reachable(resolve(root, "node.ts")).map((f) => f.slice(root.length + 1));
    expect(node).toEqual(expect.arrayContaining(["keystore-rawfile.ts", "keystore-encrypted.ts", "integration/stores-file.ts"]));
  });
});
