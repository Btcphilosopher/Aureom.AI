import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  Client,
  GatewayError,
  MemoryKeyStore,
  NetworkError,
  Signer,
  TimeoutError,
  TxBuilder,
  TxRejectedError,
  bytesToBase64,
  outcomeOf,
  utf8,
  type SubmitResponse,
} from "../src/index.js";

interface Call {
  method: string;
  url: URL;
  body: unknown;
}
type Responder = (c: Call, n: number) => { status?: number; json?: unknown; text?: string; headers?: Record<string, string> } | Error;

function mockFetch(responder: Responder): { fetch: typeof fetch; calls: Call[] } {
  const calls: Call[] = [];
  const f = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const call: Call = { method: init?.method ?? "GET", url: new URL(String(input)), body: init?.body ? JSON.parse(String(init.body)) : undefined };
    calls.push(call);
    const r = responder(call, calls.length);
    if (r instanceof Error) throw r;
    const text = r.text ?? JSON.stringify(r.json ?? {});
    return new Response(text, { status: r.status ?? 200, headers: { "content-type": "application/json", ...(r.headers ?? {}) } });
  }) as typeof fetch;
  return { fetch: f, calls };
}

async function signedTx() {
  const store = new MemoryKeyStore();
  await store.generate("term-n01-1", "k1");
  return new TxBuilder({ networkId: "net-1", signer: await Signer.forIdentity(store, "term-n01-1") }).build("ReleaseReservation", { reservation_id: "RES-1", reason: "CANCELLED" });
}

const ok = (over: Partial<SubmitResponse> = {}): SubmitResponse => ({ tx_hash: "AB", tx_id: "tx", type: "ReleaseReservation", signer: "term-n01-1", admission: { code: 0, name: "OK", log: "" }, ...over });

describe("Client.submit", () => {
  it("POSTs {tx: envelope object, wait, timeout_ms} to /api/v1/tx/submit (default wait: final)", async () => {
    const { fetch, calls } = mockFetch(() => ({ json: ok({ finalised: { height: 7, index: 0, code: 0, code_name: "OK", log: "", data: { a: 1 } } }) }));
    const tx = await signedTx();
    const c = new Client({ baseUrl: "http://gw.test:8080/", fetch });
    const r = await c.submit(tx);
    expect(calls[0]?.method).toBe("POST");
    expect(calls[0]?.url.pathname).toBe("/api/v1/tx/submit");
    expect(calls[0]?.body).toEqual({ tx: tx.envelope, wait: "final", timeout_ms: 15000 });
    expect(r.finalised?.height).toBe(7);
    await c.submit(tx, { wait: "indexed", timeoutMs: 5000 });
    expect(calls[1]?.body).toMatchObject({ wait: "indexed", timeout_ms: 5000 });
  });

  it("accepts an envelope or its JSON string", async () => {
    const { fetch, calls } = mockFetch(() => ({ json: ok() }));
    const tx = await signedTx();
    const c = new Client({ fetch });
    await c.submit(tx.envelope, { wait: "none" });
    await c.submit(tx.json, { wait: "none" });
    expect((calls[0]?.body as { tx: unknown }).tx).toEqual(tx.envelope);
    expect((calls[1]?.body as { tx: unknown }).tx).toBe(tx.json);
  });

  it("outcomeOf separates admission rejection, admitted-not-final, finalised OK and finalised-but-rejected", () => {
    expect(outcomeOf(ok({ admission: { code: 202, name: "KEY_INACTIVE", log: "k1 revoked" } }))).toEqual({ status: "ADMISSION_REJECTED", code: 202, codeName: "KEY_INACTIVE", log: "k1 revoked" });
    expect(outcomeOf(ok()).status).toBe("ADMITTED_NOT_FINAL");
    expect(outcomeOf(ok({ finalised: null as never })).status).toBe("ADMITTED_NOT_FINAL"); // the gateway sends null on timeout
    expect(outcomeOf(ok({ finalised: { height: 3, index: 1, code: 0, code_name: "OK", log: "" }, indexed: true }))).toMatchObject({ status: "FINALISED_OK", height: 3, indexed: true });
    expect(outcomeOf(ok({ finalised: { height: 3, index: 1, code: 404, code_name: "INSUFFICIENT", log: "have 0" } }))).toEqual({ status: "FINALISED_REJECTED", height: 3, index: 1, code: 404, codeName: "INSUFFICIENT", log: "have 0" });
  });

  it("submitAndWait throws TxRejectedError for admission and finalised rejections, TimeoutError when not final", async () => {
    const tx = await signedTx();
    const mk = (r: SubmitResponse) => new Client({ fetch: mockFetch(() => ({ json: r })).fetch });
    await expect(mk(ok({ admission: { code: 101, name: "BAD_SIGNATURE", log: "x" } })).submitAndWait(tx)).rejects.toMatchObject({ stage: "admission", resultName: "BAD_SIGNATURE" });
    await expect(mk(ok({ finalised: { height: 1, index: 0, code: 404, code_name: "INSUFFICIENT", log: "" } })).submitAndWait(tx)).rejects.toBeInstanceOf(TxRejectedError);
    await expect(mk(ok()).submitAndWait(tx)).rejects.toBeInstanceOf(TimeoutError);
    const good = await mk(ok({ finalised: { height: 1, index: 0, code: 0, code_name: "OK", log: "" } })).submitAndWait(tx);
    expect(good.finalised.height).toBe(1);
  });

  it("retries HTTP 429 honouring Retry-After, then gives a GatewayError when exhausted", async () => {
    let n = 0;
    const { fetch, calls } = mockFetch(() => (++n < 3 ? { status: 429, json: { error: "rate limit exceeded", code: "Too Many Requests" }, headers: { "retry-after": "0" } } : { json: ok() }));
    const c = new Client({ fetch, maxRetries429: 5 });
    await c.submit(await signedTx(), { wait: "none" });
    expect(calls).toHaveLength(3);
    const always = mockFetch(() => ({ status: 429, json: { error: "rate limit exceeded" }, headers: { "retry-after": "0" } }));
    await expect(new Client({ fetch: always.fetch, maxRetries429: 2 }).submit(await signedTx(), { wait: "none" })).rejects.toMatchObject({ status: 429 });
    expect(always.calls).toHaveLength(3);
  });

  it("maps gateway errors and unreachable gateways to typed errors", async () => {
    const tx = await signedTx();
    const e500 = new Client({ fetch: mockFetch(() => ({ status: 502, json: { error: "no validator reachable", code: "Bad Gateway" } })).fetch });
    await expect(e500.submit(tx)).rejects.toBeInstanceOf(GatewayError);
    await expect(e500.network()).rejects.toMatchObject({ status: 502, gatewayCode: "Bad Gateway" });
    const down = new Client({ fetch: mockFetch(() => new TypeError("fetch failed")).fetch });
    await expect(down.network()).rejects.toBeInstanceOf(NetworkError);
  });

  it("reports a re-sent identical transaction (mempool cache) as a duplicate and looks up the original result", async () => {
    const tx = await signedTx();
    const { fetch } = mockFetch((c) => {
      if (c.url.pathname === "/api/v1/tx/submit") return { status: 502, json: { error: "no validator reachable: ... tx already exists in cache" } };
      return { json: { tx_id: tx.txId, status: "FINALISED_OK", height: 42, index: 3, code: 0, code_name: "OK" } };
    });
    const r = await new Client({ fetch }).submit(tx, { wait: "final" });
    expect(r.duplicate).toBe(true);
    expect(r.tx_id).toBe(tx.txId);
    expect(r.finalised).toMatchObject({ height: 42, index: 3, code: 0 });
    const none = await new Client({ fetch }).submit(tx, { wait: "none" });
    expect(none.duplicate).toBe(true);
    expect(none.finalised).toBeUndefined();
  });
});

describe("Client reads", () => {
  it("getRecord / getRecordByKind / scan / inventory build the documented URLs", async () => {
    const { fetch, calls } = mockFetch((c) => {
      if (c.url.pathname === "/api/v1/chain/inventory") return { json: { height: 9, balances: [{ sku: "A", loc: "STORE-N-01", available: 1, reserved: 0, quarantined: 0, damaged: 0, on_hand: 1, version: 2 }], in_transit: [] } };
      if (c.url.pathname === "/api/v1/chain/scan") return { json: { height: 9, items: [], next_after: "" } };
      return { json: { key: "sale/S-1", found: false, height: 9 } };
    });
    const c = new Client({ fetch });
    await c.getRecord("sale/S-1", { height: 5, prove: true });
    expect(calls[0]?.url.search).toBe("?key=sale%2FS-1&height=5&prove=1");
    await c.getRecordByKind("sale", "S 1");
    expect(calls[1]?.url.pathname).toBe("/api/v1/chain/records/sale/S%201");
    await c.scan("sale/", { after: "sale/S-1", limit: 10 });
    expect(calls[2]?.url.search).toBe("?prefix=sale%2F&after=sale%2FS-1&limit=10");
    const inv = await c.inventory({ sku: "A", location: "STORE-N-01" });
    expect(inv.balances).toHaveLength(1);
    expect(inv.in_transit).toHaveLength(0);
  });

  it("inventory also accepts the bare-array shape of docs/API.md and splits TRANSIT rows", async () => {
    const row = (loc: string) => ({ sku: "A", loc, available: 1, reserved: 0, quarantined: 0, damaged: 0, on_hand: 1, version: 1 });
    const c = new Client({ fetch: mockFetch(() => ({ json: [row("STORE-N-01"), row("TRANSIT:X-1")] })).fetch });
    const inv = await c.inventory();
    expect(inv.balances.map((b) => b.loc)).toEqual(["STORE-N-01"]);
    expect(inv.in_transit.map((b) => b.loc)).toEqual(["TRANSIT:X-1"]);
  });

  it("scanAll pages with next_after and pins the first page's height", async () => {
    const pages: Record<string, unknown> = {
      "": { height: 20, items: [{ key: "a/1", value: 1 }, { key: "a/2", value: 2 }], next_after: "a/2" },
      "a/2": { height: 20, items: [{ key: "a/3", value: 3 }], next_after: "" },
    };
    const { fetch, calls } = mockFetch((c) => ({ json: pages[c.url.searchParams.get("after") ?? ""] }));
    const got: string[] = [];
    for await (const it of new Client({ fetch }).scanAll("a/", { pageSize: 2 })) got.push(it.key);
    expect(got).toEqual(["a/1", "a/2", "a/3"]);
    expect(calls[1]?.url.searchParams.get("height")).toBe("20");
  });

  it("projection queries pass filters and read-after-write parameters", async () => {
    const { fetch, calls } = mockFetch(() => ({ json: { meta: { indexed_height: 10, chain_head: 10, lag_blocks: 0, projection_state: "OK" }, items: [], total: 0 } }));
    const c = new Client({ fetch });
    await c.q.sales({ customer: "CUST-DEMO01", location: "STORE-N-01", min_height: 10, wait_ms: 3000, limit: 5 });
    expect(calls[0]?.url.pathname).toBe("/api/v1/q/sales");
    expect(Object.fromEntries(calls[0]!.url.searchParams)).toEqual({ customer: "CUST-DEMO01", location: "STORE-N-01", min_height: "10", wait_ms: "3000", limit: "5" });
    await c.q.history({ kind: "sale", id: "S-1" });
    expect(calls[1]?.url.search).toBe("?kind=sale&id=S-1");
    expect(() => c.q.history({})).toThrow(/key, or kind and id/);
  });
});

describe("read-after-write against a lagging / rebuilding projection", () => {
  const status = (state: string, indexed: number, head = 100) => ({ state, indexed_height: indexed, chain_head: head, lag_blocks: head - indexed });

  it("waitIndexed polls until the projection has indexed the height", async () => {
    const seq = [status("OK", 98), status("OK", 99), status("OK", 100)];
    const { fetch } = mockFetch((c, n) => (c.url.pathname === "/api/v1/projection/status" ? { json: seq[Math.min(n - 1, 2)] } : { json: {} }));
    const r = await new Client({ fetch }).waitIndexed(100, { intervalMs: 1 });
    expect(r.status.indexed_height).toBe(100);
    expect(r.sawRebuild).toBe(false);
  });

  it("waitIndexed rides out a rebuild (state REBUILDING, indexed height restarting from 0) and reports it", async () => {
    const seq = [status("OK", 98), status("REBUILDING", 0), status("REBUILDING", 40), status("REBUILDING", 99), status("OK", 100)];
    let i = 0;
    const { fetch } = mockFetch(() => ({ json: seq[Math.min(i++, seq.length - 1)] }));
    const r = await new Client({ fetch }).waitIndexed(100, { intervalMs: 1 });
    expect(r.status.state).toBe("OK");
    expect(r.sawRebuild).toBe(true);
  });

  it("waitIndexed times out with a diagnostic when the projection never catches up", async () => {
    const { fetch } = mockFetch(() => ({ json: status("EMPTY", 0) }));
    await expect(new Client({ fetch }).waitIndexed(100, { intervalMs: 1, timeoutMs: 30 })).rejects.toThrow(/did not reach height 100.*EMPTY/);
  });

  it("readAfterWrite re-reads if a rebuild starts between the wait and the read", async () => {
    let reads = 0;
    const { fetch } = mockFetch((c) => {
      if (c.url.pathname === "/api/v1/projection/status") return { json: status("OK", 100) };
      reads++;
      return { json: { meta: { indexed_height: reads === 1 ? 0 : 100, chain_head: 100, lag_blocks: 0, projection_state: reads === 1 ? "REBUILDING" : "OK" }, item: { id: "S-1" } } };
    });
    const c = new Client({ fetch });
    const r = await c.readAfterWrite(100, () => c.q.sale("S-1"), { intervalMs: 1 });
    expect(reads).toBe(2);
    expect(r.meta.projection_state).toBe("OK");
  });
});

describe("getVerifiedRecord (proof verification inside the client)", () => {
  interface PV {
    name: string;
    kind: string;
    key: string;
    value?: string;
    proof_b64: string;
    app_hash: string;
    height: number;
  }
  const golden = JSON.parse(readFileSync(new URL("./golden.json", import.meta.url), "utf8")) as { proofs: PV[] };
  const p = golden.proofs.find((x) => x.name === "location")!;
  const gateway = (over: Record<string, unknown> = {}, finality: Record<string, unknown> | undefined = undefined) =>
    mockFetch((c) => {
      if (c.url.pathname === "/api/v1/chain/record") {
        return { json: { key: p.key, found: true, value: JSON.parse(p.value!), height: p.height, proof: { type: "ics23:iavl", proof_b64: p.proof_b64, app_hash: p.app_hash.toUpperCase(), app_hash_height: p.height + 1 }, verification: { proof_valid: true, header_verified: true }, ...over } };
      }
      if (c.url.pathname === "/api/v1/explorer/verify-finality") return { json: finality ?? { height: p.height + 1, verified: true, header_app_hash: p.app_hash.toUpperCase() } };
      return { status: 404, json: { error: "x" } };
    });

  it("verifies locally against the proof's app hash (the gateway sends it upper-case) and asks for prove=1", async () => {
    const g = gateway();
    const v = await new Client({ fetch: g.fetch }).getVerifiedRecord(p.key);
    expect(g.calls[0]?.url.searchParams.get("prove")).toBe("1");
    expect(v.verdict.valid, v.verdict.reason).toBe(true);
  });

  it("cross-checks the header with the gateway's light-client report (header_app_hash of header height+1)", async () => {
    const g = gateway();
    const v = await new Client({ fetch: g.fetch }).getVerifiedRecord(p.key, { crossCheckFinality: true });
    expect(v.finalityAgrees).toBe(true);
    expect(g.calls[1]?.url.searchParams.get("height")).toBe(String(p.height + 1));
    const bad = await new Client({ fetch: gateway({}, { height: p.height + 1, verified: true, header_app_hash: "00".repeat(32) }).fetch }).getVerifiedRecord(p.key, { crossCheckFinality: true });
    expect(bad.finalityAgrees).toBe(false);
  });

  it("does not trust a lying gateway: a tampered value is INVALID even though the gateway says proof_valid", async () => {
    const tampered = { ...JSON.parse(p.value!), name: "Hacked Store" };
    const v = await new Client({ fetch: gateway({ value: tampered }).fetch }).getVerifiedRecord(p.key);
    expect(v.verdict.valid).toBe(false);
    expect(v.record.verification?.proof_valid).toBe(true);
  });

  it("uses value_b64 when the gateway provides exact bytes, and an independently supplied root when the gateway has none", async () => {
    const exact = await new Client({ fetch: gateway({ value_b64: bytesToBase64(utf8(p.value!)) }).fetch }).getVerifiedRecord(p.key);
    expect(exact.verdict.valueEncoding).toBe("value_b64");
    // gateway could not verify the header: app_hash is empty
    const noRoot = gateway({ proof: { type: "ics23:iavl", proof_b64: p.proof_b64, app_hash: "", app_hash_height: p.height + 1 } });
    const refused = await new Client({ fetch: noRoot.fetch }).getVerifiedRecord(p.key);
    expect(refused.verdict.valid).toBe(false);
    const pinned = await new Client({ fetch: noRoot.fetch }).getVerifiedRecord(p.key, { expectedAppHash: p.app_hash });
    expect(pinned.verdict).toMatchObject({ valid: true, rootPinned: true });
  });
});
