import { describe, expect, it, beforeEach } from "vitest";
import {
  AdapterRunner,
  EcommerceOrderAdapter,
  ErpPurchaseOrderAdapter,
  HmacSha256Verifier,
  MemoryKeyStore,
  RE_ID,
  RE_IDEM,
  SimulatedPaymentProvider,
  WarehouseAdapter,
  constantTimeEqual,
  idempotencyRefFor,
  signWebhook,
  simPayDelivery,
  toChainId,
  verifyEnvelope,
  type AdapterRunner as Runner,
  type EcomOrderEvent,
  type ErpEvent,
  type RunnerLog,
  type SimPayWebhook,
  type WebhookInbound,
  type WmsEvent,
} from "../src/index.js";
import { MockSubmitter } from "./helpers/mock-submitter.js";

const NET = "net-test-1";
const SECRET = "simpay-test-secret-0123456789";
const NOW = 1_794_500_000_000;

async function keysFor(...ids: string[]): Promise<MemoryKeyStore> {
  const s = new MemoryKeyStore();
  for (const id of ids) await s.generate(id, "k1");
  return s;
}

const paymentEvent = (over: Partial<SimPayWebhook> = {}, data: Partial<SimPayWebhook["data"]> = {}): SimPayWebhook => ({
  id: "evt_0001",
  type: "payment.succeeded",
  created: Math.floor(NOW / 1000),
  data: { sale_id: "SALE-1", reference: "ch_123", amount: 3999, currency: "GBP", ...data },
  ...over,
});

describe("HMAC webhook verification", () => {
  const v = new HmacSha256Verifier({ secrets: [SECRET] });
  const body = JSON.stringify(paymentEvent());
  const signed = (t = NOW, secret = SECRET, b = body): WebhookInbound => ({ rawBody: b, headers: signWebhook(secret, b, t) });

  it("accepts a correctly signed, fresh webhook", () => {
    expect(v.verify(signed(), NOW)).toEqual({ ok: true });
    expect(v.verify(signed(NOW - 4 * 60_000), NOW).ok).toBe(true); // inside the 5 minute tolerance
  });
  it("rejects a bad signature (wrong secret) and a tampered body", () => {
    const r = v.verify(signed(NOW, "another-secret-0123456789"), NOW);
    expect(r).toMatchObject({ ok: false, code: "BAD_SIGNATURE" });
    const tampered = { ...signed(), rawBody: body.replace("3999", "1") };
    expect(v.verify(tampered, NOW)).toMatchObject({ ok: false, code: "BAD_SIGNATURE" });
  });
  it("rejects a replayed old timestamp (and a far-future one) even with a valid signature", () => {
    const old = v.verify(signed(NOW - 10 * 60_000), NOW);
    expect(old).toMatchObject({ ok: false, code: "TIMESTAMP_OUT_OF_TOLERANCE" });
    expect(v.verify(signed(NOW + 10 * 60_000), NOW)).toMatchObject({ ok: false, code: "TIMESTAMP_OUT_OF_TOLERANCE" });
    // an attacker cannot fix the timestamp: it is part of the signed material
    const forged: WebhookInbound = { rawBody: body, headers: { "x-signature": signed(NOW - 10 * 60_000).headers["x-signature"]!.replace(/t=\d+/, `t=${Math.floor(NOW / 1000)}`) } };
    expect(v.verify(forged, NOW)).toMatchObject({ ok: false, code: "BAD_SIGNATURE" });
  });
  it("rejects missing or malformed signature headers; header names are case-insensitive", () => {
    expect(v.verify({ rawBody: body, headers: {} }, NOW)).toMatchObject({ ok: false, code: "MISSING_SIGNATURE" });
    expect(v.verify({ rawBody: body, headers: { "x-signature": "garbage" } }, NOW)).toMatchObject({ ok: false, code: "MALFORMED_SIGNATURE" });
    expect(v.verify({ rawBody: body, headers: { "x-signature": "t=abc,v1=00" } }, NOW)).toMatchObject({ ok: false, code: "MALFORMED_SIGNATURE" });
    const s = signed();
    expect(v.verify({ rawBody: body, headers: { "X-SIGNATURE": s.headers["x-signature"]! } }, NOW).ok).toBe(true);
  });
  it("supports secret rotation (any listed secret verifies) and refuses weak secrets", () => {
    const rot = new HmacSha256Verifier({ secrets: ["old-secret-0123456789", SECRET] });
    expect(rot.verify(signed(NOW, "old-secret-0123456789"), NOW).ok).toBe(true);
    expect(rot.verify(signed(NOW, SECRET), NOW).ok).toBe(true);
    expect(() => new HmacSha256Verifier({ secrets: ["short"] })).toThrow(/16 characters/);
  });
  it("constantTimeEqual compares content and length", () => {
    expect(constantTimeEqual(Uint8Array.of(1, 2, 3), Uint8Array.of(1, 2, 3))).toBe(true);
    expect(constantTimeEqual(Uint8Array.of(1, 2, 3), Uint8Array.of(1, 2, 4))).toBe(false);
    expect(constantTimeEqual(Uint8Array.of(1, 2), Uint8Array.of(1, 2, 3))).toBe(false);
  });
});

describe("idempotency refs and id mapping", () => {
  it("are valid chain identifiers, stable, and collision-safe", () => {
    expect(idempotencyRefFor("pay", "SIMPAY", "evt_0001")).toBe("pay:SIMPAY:evt_0001");
    const weird = idempotencyRefFor("pay", "SIMPAY", "evt/with spaces & symbols");
    expect(RE_IDEM.test(weird)).toBe(true);
    expect(idempotencyRefFor("pay", "SIMPAY", "evt/with spaces & symbols")).toBe(weird); // stable
    expect(idempotencyRefFor("pay", "SIMPAY", "evt/with spaces & symbols")).not.toBe(idempotencyRefFor("pay", "SIMPAY", "evt-with-spaces-&-symbols")); // distinct inputs stay distinct
    const long = idempotencyRefFor("pay", "SIMPAY", "x".repeat(300));
    expect(long.length).toBeLessThanOrEqual(96);
    expect(RE_IDEM.test(long)).toBe(true);
    expect(idempotencyRefFor("pay", "SIMPAY", "x".repeat(300) + "a")).not.toBe(long);
    expect(RE_IDEM.test(idempotencyRefFor("-", "-", "-"))).toBe(true);
  });
  it("toChainId sanitises external numbers", () => {
    expect(toChainId("PO-", "4500123")).toBe("PO-4500123");
    const id = toChainId("PO-", "4500/12 345");
    expect(RE_ID.test(id)).toBe(true);
    expect(toChainId("PO-", "4500/12 345")).toBe(id);
    expect(RE_ID.test(toChainId("X-", "y".repeat(200)))).toBe(true);
  });
});

describe("PaymentProviderAdapter + AdapterRunner (SIMPAY)", () => {
  let chain: MockSubmitter;
  let runner: Runner<WebhookInbound>;
  let logs: RunnerLog[];
  let sleeps: number[];
  const provider = () => new SimulatedPaymentProvider({ secrets: [SECRET] });
  const deliver = (e: SimPayWebhook = paymentEvent(), t = NOW) => simPayDelivery(SECRET, e, t);

  async function makeRunner(over: Partial<ConstructorParameters<typeof AdapterRunner<WebhookInbound>>[0]> = {}) {
    return new AdapterRunner<WebhookInbound>({
      adapter: provider(),
      keys: await keysFor("payment-adapter-1"),
      networkId: NET,
      gateway: chain,
      now: () => NOW,
      sleep: async (ms) => void sleeps.push(ms),
      random: () => 0.5, // no jitter: deterministic delays
      newId: () => "fixed",
      log: (e) => logs.push(e),
      ...over,
    });
  }
  beforeEach(async () => {
    chain = new MockSubmitter(NET);
    logs = [];
    sleeps = [];
    runner = await makeRunner();
  });

  it("maps payment.succeeded to a signed RecordPaymentResult from the service identity, idempotency_ref from the provider event id", async () => {
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.seen).toHaveLength(1);
    const s = chain.seen[0]!;
    expect(s.type).toBe("RecordPaymentResult");
    expect(s.signer).toBe("payment-adapter-1");
    expect(s.idem).toBe("pay:SIMPAY:evt_0001");
    expect(s.payload).toEqual({ sale_id: "SALE-1", provider: "SIMPAY", event_id: "evt_0001", provider_ref: "ch_123", result: "CONFIRMED", amount_minor: 3999, currency: "GBP" });
    expect(r.applied[0]?.duplicate).toBe(false);
  });

  it("maps failed payments and refund events (RecordRefundResult)", async () => {
    await runner.handle(deliver(paymentEvent({ id: "evt_f", type: "payment.failed" }, { amount: 0 })));
    await runner.handle(deliver(paymentEvent({ id: "evt_r", type: "refund.succeeded" }, { sale_id: undefined, refund_id: "RF-RET-1-001", reference: "rf_9", amount: 3999 })));
    await runner.handle(deliver(paymentEvent({ id: "evt_rf", type: "refund.failed" }, { sale_id: undefined, refund_id: "RF-RET-1-001", reference: "rf_10", amount: 3999 })));
    expect(chain.seen.map((s) => `${s.type}:${String(s.payload["result"])}`)).toEqual(["RecordPaymentResult:FAILED", "RecordRefundResult:CONFIRMED", "RecordRefundResult:FAILED"]);
    expect(chain.seen[1]?.payload).toEqual({ refund_id: "RF-RET-1-001", provider: "SIMPAY", event_id: "evt_r", provider_ref: "rf_9", result: "CONFIRMED", amount_minor: 3999 });
    expect(chain.seen[1]?.idem).toBe("refund:SIMPAY:evt_r");
  });

  it("a DUPLICATE callback (provider retry) is applied once: the second delivery is reported DUPLICATE, nothing new executes", async () => {
    const first = await runner.handle(deliver());
    const second = await runner.handle(deliver(paymentEvent(), NOW + 30_000)); // redelivery: same event id, fresh signature timestamp
    expect(first.status).toBe("APPLIED");
    expect(second.status).toBe("DUPLICATE");
    expect(second.applied[0]?.duplicate).toBe(true);
    expect(chain.seen.filter((s) => s.code === 0)).toHaveLength(1);
    // and the chain-level dedupe by provider+event_id is also honoured (a result flagged deduplicated)
    const other = new MockSubmitter(NET);
    const r2 = await (await makeRunner({ gateway: other })).handle(deliver());
    // same event id under a DIFFERENT idempotency ref (e.g. a re-keyed adapter): chain answers deduplicated:true
    const rekeyed = new SimulatedPaymentProvider({ secrets: [SECRET] });
    const orig = rekeyed.translate.bind(rekeyed);
    rekeyed.translate = (i) => orig(i).map((q, n) => ({ ...q, idempotencyRef: `${q.idempotencyRef}-v${n}-rekey` }));
    const r3 = await (await makeRunner({ gateway: other, adapter: rekeyed })).handle(deliver());
    expect(r2.status).toBe("APPLIED");
    expect(r3.status).toBe("DUPLICATE");
    expect(r3.applied[0]?.data).toMatchObject({ deduplicated: true });
  });

  it("rejects a bad signature: nothing is submitted, an UNAUTHENTIC_EVENT exception is raised, no dead letter is stored", async () => {
    const bad = { ...deliver(), headers: signWebhook("not-the-secret-0123456789", deliver().rawBody, NOW) };
    const r = await runner.handle(bad);
    expect(r.status).toBe("REJECTED_UNAUTHENTIC");
    expect(r.failure?.code).toBe("BAD_SIGNATURE");
    expect(chain.calls).toBe(0);
    expect(r.exception).toMatchObject({ kind: "UNAUTHENTIC_EVENT" });
    expect(await runner.deadLetters.list()).toHaveLength(0); // never persist (or replay) unauthenticated payloads
  });

  it("rejects a replayed OLD webhook (valid signature, stale timestamp)", async () => {
    const captured = deliver(paymentEvent(), NOW - 20 * 60_000);
    const r = await runner.handle(captured);
    expect(r.status).toBe("REJECTED_UNAUTHENTIC");
    expect(r.failure?.code).toBe("TIMESTAMP_OUT_OF_TOLERANCE");
    expect(chain.calls).toBe(0);
  });

  it("retries a TRANSIENT submit failure with exponential backoff, re-sending the SAME signed tx", async () => {
    chain.script("RecordPaymentResult", { kind: "network" }, { kind: "network" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.calls).toBe(3);
    expect(chain.seen).toHaveLength(1); // executed exactly once
    expect(r.applied[0]?.attempts).toBe(3);
    expect(sleeps).toEqual([200, 400]);
    expect(logs.filter((l) => l.type === "retry")).toHaveLength(2);
    const retried = logs.filter((l): l is Extract<RunnerLog, { type: "retry" }> => l.type === "retry");
    expect(new Set(retried.map((l) => l.txId)).size).toBe(1); // same tx id on every attempt
  });

  it("a LOST response (executed, answer lost) is resolved by asking the chain, not by re-executing", async () => {
    chain.script("RecordPaymentResult", { kind: "lost-response" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.calls).toBe(1);
    expect(chain.statusCalls).toHaveLength(1);
    expect(chain.seen).toHaveLength(1);
  });

  it("admitted-but-not-final is resolved through tx status", async () => {
    chain.script("RecordPaymentResult", { kind: "admitted-only" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.calls).toBe(1);
  });

  it("gives up after the retry budget: DEAD_LETTERED (transient) with a reconciliation exception; replay succeeds once the network is back", async () => {
    chain.scriptAny(...Array.from({ length: 5 }, () => ({ kind: "network" as const })));
    const r = await runner.handle(deliver());
    expect(r.status).toBe("DEAD_LETTERED");
    expect(r.failure).toMatchObject({ stage: "submission", code: "TRANSIENT_EXHAUSTED", transient: true, attempts: 5 });
    expect(chain.calls).toBe(5);
    expect(sleeps).toEqual([200, 400, 800, 1600]);
    expect(r.deadLetter?.event).toMatchObject({ rawBody: expect.stringContaining("evt_0001") });
    expect(r.exception).toMatchObject({ kind: "UNAPPLIED_EVENT", severity: "MEDIUM", deadLetterId: r.deadLetter?.id });
    expect(r.exception?.suggestedAction).toMatch(/Money may have moved/);
    expect(await runner.deadLetters.list()).toHaveLength(1);

    // the dead letter was authenticated at intake: replay does not re-check the (now stale) timestamp
    const replay = await runner.replayDeadLetter(r.deadLetter!.id);
    expect(replay.status).toBe("APPLIED");
    expect(await runner.deadLetters.list()).toHaveLength(0);
    expect(chain.seen).toHaveLength(1);
  });

  it("a PERMANENT business failure is dead-lettered immediately (no retries) and stays queued across a failed replay", async () => {
    chain.script("RecordPaymentResult", { kind: "reject", code: 405, log: "sale payment is FAILED" }, { kind: "reject", code: 405, log: "sale payment is FAILED" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("DEAD_LETTERED");
    expect(r.failure).toMatchObject({ stage: "business", code: "INVALID_STATE", transient: false, attempts: 1 });
    expect(sleeps).toEqual([]);
    expect(chain.calls).toBe(1);
    expect(r.exception?.detail).toContain("INVALID_STATE");

    const again = await runner.replayDeadLetter(r.deadLetter!.id);
    expect(again.status).toBe("DEAD_LETTERED");
    const stored = await runner.deadLetters.get(r.deadLetter!.id);
    expect(stored?.replays).toBe(1);
    expect(await runner.deadLetters.list()).toHaveLength(1); // updated in place, not duplicated
  });

  it("OUT-OF-ORDER callback: NOT_FOUND is retried with a FRESH tx id but the SAME idempotency_ref, then succeeds", async () => {
    chain.script("RecordPaymentResult", { kind: "reject", code: 401, log: "sale SALE-1 not found" }, { kind: "reject", code: 401, log: "sale SALE-1 not found" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.seen).toHaveLength(3);
    expect(new Set(chain.seen.map((s) => s.txId)).size).toBe(3); // a rejected tx id is burned on chain
    expect(new Set(chain.seen.map((s) => s.idem)).size).toBe(1);
    expect(chain.seen.map((s) => s.code)).toEqual([401, 401, 0]);
    expect(logs.filter((l) => l.type === "business_retry")).toHaveLength(2);
  });

  it("OUT-OF-ORDER callback refused at ADMISSION (the authorisation stage looks the sale up) is retried the same way", async () => {
    chain.script("RecordPaymentResult", { kind: "admit-reject", code: 401, log: "sale SALE-1 not found" }, { kind: "admit-reject", code: 401, log: "sale SALE-1 not found" });
    const r = await runner.handle(deliver());
    expect(r.status).toBe("APPLIED");
    expect(chain.calls).toBe(3);
    expect(chain.seen).toHaveLength(1); // only the third attempt reached ordering
    expect(logs.filter((l) => l.type === "business_retry")).toHaveLength(2);
    // other admission rejections stay permanent
    chain.script("RecordPaymentResult", { kind: "admit-reject", code: 202, log: "key k1 is not an active key" });
    const dead = await runner.handle(deliver(paymentEvent({ id: "evt_k" })));
    expect(dead.status).toBe("DEAD_LETTERED");
    expect(dead.failure).toMatchObject({ stage: "submission", code: "KEY_INACTIVE", transient: false });
  });

  it("OUT-OF-ORDER that never resolves ends in the dead letter queue with finance guidance", async () => {
    chain.scriptAny(...Array.from({ length: 4 }, () => ({ kind: "reject" as const, code: 401, log: "sale SALE-1 not found" })));
    const r = await runner.handle(deliver());
    expect(r.status).toBe("DEAD_LETTERED");
    expect(r.failure).toMatchObject({ stage: "business", code: "NOT_FOUND", attempts: 4 });
    expect(r.exception?.suggestedAction).toMatch(/no record of payment for sale SALE-1/);
  });

  it("dead-letters events the adapter cannot translate (unsupported type, zero-amount confirmation) without touching the chain", async () => {
    const odd = await runner.handle(deliver(paymentEvent({ id: "evt_x", type: "dispute.created" as SimPayWebhook["type"] })));
    expect(odd.status).toBe("DEAD_LETTERED");
    expect(odd.failure).toMatchObject({ stage: "translation", code: "UNSUPPORTED_EVENT" });
    const zero = await runner.handle(deliver(paymentEvent({ id: "evt_z" }, { amount: 0 })));
    expect(zero.failure).toMatchObject({ stage: "translation", code: "BAD_AMOUNT" });
    const noSale = await runner.handle(deliver(paymentEvent({ id: "evt_n" }, { sale_id: undefined })));
    expect(noSale.failure).toMatchObject({ stage: "translation", code: "MISSING_SALE" });
    expect(chain.calls).toBe(0);
  });

  it("fails permanently (no retry loop) when the service identity has no key in the store", async () => {
    const r = await (await makeRunner({ keys: await keysFor("someone-else") })).handle(deliver());
    expect(r.status).toBe("DEAD_LETTERED");
    expect(r.failure).toMatchObject({ stage: "submission", code: "KEY_NOT_FOUND", transient: false });
    expect(chain.calls).toBe(0);
  });

  it("signs with the service key: the submitted envelope verifies and names payment-adapter-1", async () => {
    let captured: string | undefined;
    const spy: MockSubmitter = chain;
    const orig = spy.submit.bind(spy);
    spy.submit = async (tx, o) => {
      captured = tx.json;
      return orig(tx, o);
    };
    await runner.handle(deliver());
    const chk = verifyEnvelope(captured!, NET);
    expect(chk.ok).toBe(true);
    expect(chk.body?.signer).toBe("payment-adapter-1");
    expect(chk.body?.idempotency_ref).toBe("pay:SIMPAY:evt_0001");
  });
});

describe("example adapters share the same shape", () => {
  it("ERP: an approved PO release becomes CreatePurchaseOrder + ApprovePurchaseOrder from two DIFFERENT identities", async () => {
    const chain = new MockSubmitter(NET);
    const runner = new AdapterRunner<ErpEvent>({ adapter: new ErpPurchaseOrderAdapter({ allowedSources: ["legacy-retail-erp"] }), keys: await keysFor("buyer-hq", "po-approver-hq", "manager-n01"), networkId: NET, gateway: chain, now: () => NOW });
    const ev: ErpEvent = { kind: "PO_RELEASED", event_id: "OUTBOX-77", source_system: "legacy-retail-erp", po_number: "4500/12 345", supplier_id: "SUP-009", location_id: "STORE-N-01", currency: "GBP", ordered_at_ms: NOW, erp_status: "APPROVED", lines: [{ sku: "KETTLE-RED", qty_v: 3, unit: "EA", unit_cost_minor: 1800 }] };
    const r = await runner.handle(ev);
    expect(r.status).toBe("APPLIED");
    expect(chain.seen.map((s) => `${s.type}@${s.signer}`)).toEqual(["CreatePurchaseOrder@buyer-hq", "ApprovePurchaseOrder@po-approver-hq"]);
    const poId = (chain.seen[0]!.payload["po_id"] as string);
    expect(RE_ID.test(poId)).toBe(true);
    expect(chain.seen[1]!.payload).toEqual({ po_id: poId });
    expect(chain.seen[0]!.idem).not.toBe(chain.seen[1]!.idem);
    // redelivery of the same outbox message: both requests are duplicates
    expect((await runner.handle(ev)).status).toBe("DUPLICATE");
    expect(chain.seen).toHaveLength(2);
  });

  it("ERP: a DRAFT PO is only created; receipts map to ReceiveGoods; unknown sources are rejected; buyer must differ from approver", async () => {
    const chain = new MockSubmitter(NET);
    const runner = new AdapterRunner<ErpEvent>({ adapter: new ErpPurchaseOrderAdapter({ allowedSources: ["erp-1"] }), keys: await keysFor("buyer-hq", "po-approver-hq", "manager-n01"), networkId: NET, gateway: chain, now: () => NOW });
    await runner.handle({ kind: "PO_RELEASED", event_id: "E1", source_system: "erp-1", po_number: "1", supplier_id: "S", location_id: "L", currency: "GBP", ordered_at_ms: NOW, erp_status: "DRAFT", lines: [{ sku: "A", qty_v: 1, unit: "EA", unit_cost_minor: 5 }] });
    await runner.handle({ kind: "GOODS_RECEIPT_POSTED", event_id: "E2", source_system: "erp-1", po_number: "1", location_id: "L", effective_at_ms: NOW, lines: [{ sku: "A", qty_v: 1, unit: "EA", po_line: 1 }] });
    expect(chain.seen.map((s) => s.type)).toEqual(["CreatePurchaseOrder", "ReceiveGoods"]);
    const bad = await runner.handle({ kind: "GOODS_RECEIPT_POSTED", event_id: "E3", source_system: "evil", po_number: "1", location_id: "L", effective_at_ms: NOW, lines: [] });
    expect(bad.status).toBe("REJECTED_UNAUTHENTIC");
    expect(() => new ErpPurchaseOrderAdapter({ buyerIdentity: "x", approverIdentity: "x" })).toThrow(/differ/);
  });

  it("WMS: receive / dispatch / transfer-receive scans and a cycle count (PROPOSE only, never APPROVE)", async () => {
    const chain = new MockSubmitter(NET);
    const runner = new AdapterRunner<WmsEvent & { device_id?: string }>({ adapter: new WarehouseAdapter({ allowedDevices: ["scanner-7"] }), keys: await keysFor("wh-operator-dist"), networkId: NET, gateway: chain, now: () => NOW });
    const d = { device_id: "scanner-7" };
    await runner.handle({ ...d, kind: "RECEIVE_SCAN", event_id: "S1", location_id: "WH-DIST-01", po_number: "2001", effective_at_ms: NOW, lines: [{ sku: "A", qty_v: 4, unit: "EA", po_line: 1 }] });
    await runner.handle({ ...d, kind: "DISPATCH_SCAN", event_id: "S2", transfer_no: "T9", from_location: "WH-DIST-01", to_location: "STORE-N-01", lines: [{ sku: "A", qty_v: 4, unit: "EA" }] });
    await runner.handle({ ...d, kind: "TRANSFER_RECEIVE_SCAN", event_id: "S3", transfer_no: "T9", lines: [{ sku: "A", qty_v: 4, unit: "EA", damaged_v: 1 }] });
    await runner.handle({ ...d, kind: "CYCLE_COUNT", event_id: "S4", location_id: "WH-DIST-01", sku: "A", bucket: "available", counted_v: 3, reason: "cycle count", evidence_ref: "count-sheet-17" });
    expect(chain.seen.map((s) => s.type)).toEqual(["ReceiveGoods", "TransferStock", "TransferStock", "AdjustStock"]);
    expect(chain.seen[1]!.payload).toMatchObject({ op: "DISPATCH", from_location: "WH-DIST-01", to_location: "STORE-N-01" });
    expect(chain.seen[2]!.payload).toMatchObject({ op: "RECEIVE", lines: [{ sku: "A", qty: { v: 4, unit: "EA" }, damaged_v: 1 }] });
    expect(chain.seen[3]!.payload).toMatchObject({ op: "PROPOSE", counted_v: 3, evidence_ref: "count-sheet-17" });
    expect(chain.seen.every((s) => s.signer === "wh-operator-dist")).toBe(true);
    const rogue = await runner.handle({ device_id: "scanner-X", kind: "CYCLE_COUNT", event_id: "S5", location_id: "WH-DIST-01", sku: "A", bucket: "available", counted_v: 0, reason: "x" });
    expect(rogue.status).toBe("REJECTED_UNAUTHENTIC");
    const noSource = await runner.handle({ ...d, kind: "RECEIVE_SCAN", event_id: "S6", location_id: "L", effective_at_ms: NOW, lines: [] });
    expect(noSource.failure).toMatchObject({ stage: "translation", code: "NO_SOURCE" });
  });

  describe("E-commerce", () => {
    const order = (over: Partial<EcomOrderEvent> = {}): EcomOrderEvent => ({
      kind: "ORDER_PLACED",
      event_id: "WEB-EVT-1",
      order_id: "10001",
      location_id: "STORE-N-01",
      currency: "GBP",
      placed_at_ms: NOW,
      payment_method: "ONLINE_CARD",
      customer_id: "CUST-DEMO01",
      lines: [{ sku: "A", qty_v: 1, unit: "EA" }, { sku: "B", qty_v: 2, unit: "EA" }],
      ...over,
    });
    it("reserves each line then completes the sale on channel ECOM", async () => {
      const chain = new MockSubmitter(NET);
      const runner = new AdapterRunner<EcomOrderEvent>({ adapter: new EcommerceOrderAdapter({ serviceIdentity: "cashier-n01" }), keys: await keysFor("cashier-n01"), networkId: NET, gateway: chain, now: () => NOW });
      const r = await runner.handle(order());
      expect(r.status).toBe("APPLIED");
      expect(chain.seen.map((s) => s.type)).toEqual(["ReserveStock", "ReserveStock", "CompleteSale"]);
      const sale = chain.seen[2]!.payload as { channel: string; sale_id: string; lines: { reservation_id: string }[]; customer_id: string };
      expect(sale.channel).toBe("ECOM");
      expect(sale.customer_id).toBe("CUST-DEMO01");
      expect(sale.lines.map((l) => l.reservation_id)).toEqual(chain.seen.slice(0, 2).map((s) => s.payload["reservation_id"]));
      expect((await runner.handle(order())).status).toBe("DUPLICATE"); // webhook redelivery
      expect(chain.seen).toHaveLength(3);
    });
    it("a permanent failure part-way compensates (releases the reservations taken) and raises a HIGH PARTIAL_APPLICATION exception", async () => {
      const chain = new MockSubmitter(NET);
      chain.script("ReserveStock", { kind: "ok" }, { kind: "reject", code: 404, log: "insufficient available at STORE-N-01 for B" });
      const runner = new AdapterRunner<EcomOrderEvent>({ adapter: new EcommerceOrderAdapter({ serviceIdentity: "cashier-n01" }), keys: await keysFor("cashier-n01"), networkId: NET, gateway: chain, now: () => NOW });
      const r = await runner.handle(order());
      expect(r.status).toBe("DEAD_LETTERED");
      expect(r.failure).toMatchObject({ stage: "business", code: "INSUFFICIENT" });
      expect(chain.seen.map((s) => `${s.type}:${s.code}`)).toEqual(["ReserveStock:0", "ReserveStock:404", "ReleaseReservation:0"]);
      expect(chain.seen[2]!.payload).toEqual({ reservation_id: chain.seen[0]!.payload["reservation_id"], reason: "CANCELLED" });
      expect(r.exception).toMatchObject({ kind: "PARTIAL_APPLICATION", severity: "HIGH" });
      expect(r.exception?.suggestedAction).toMatch(/stock was not available/);
      expect(r.deadLetter?.applied.map((a) => a.type)).toEqual(["ReserveStock"]);
    });
  });
});
