import { beforeEach, describe, expect, it } from "vitest";
import { MemoryKeyStore, NetworkError, Signer, verifyEnvelope } from "../src/index.js";
import { OFFLINE_BANNER, UNFINALISED_LABEL, formatEscalation, formatExceptions, formatQueue, formatReceipt, formatStatus, formatSync } from "../terminal/format.js";
import { MemoryStateStore } from "../terminal/state.js";
import { OfflineError, PolicyRefusal, SaleFailed, Terminal } from "../terminal/terminal.js";
import { MockChain } from "./helpers/mock-chain.js";

const NET = "net-test-1";

interface Rig {
  chain: MockChain;
  term: Terminal;
  store: MemoryStateStore;
  signer: Signer;
  clock: { t: number };
  reopen: () => Promise<Terminal>;
}

async function rig(skuOverrides?: Partial<Parameters<typeof makeChain>[0]>): Promise<Rig> {
  const chain = makeChain(skuOverrides ?? {});
  const keys = new MemoryKeyStore();
  await keys.generate("term-n01-1", "k1");
  const signer = await Signer.forIdentity(keys, "term-n01-1");
  const store = new MemoryStateStore();
  const clock = { t: chain.timeMs + 5_000 };
  let n = 0;
  const open = () =>
    Terminal.open({
      store,
      gateway: chain,
      signer,
      networkId: NET,
      locationId: "STORE-N-01",
      now: () => clock.t,
      newId: (p) => `${p}-${String(++n).padStart(4, "0")}`,
      sleep: async () => {
        clock.t += 1000;
      },
    });
  const term = await open();
  return { chain, term, store, signer, clock, reopen: open };
}

function makeChain(_o: object): MockChain {
  return new MockChain({
    networkId: NET,
    skus: [
      { id: "KETTLE-RED", unit: "EA", scarce: true, price_minor: 2500, available: 10, name: "Red kettle" },
      { id: "MUG-BLUE", unit: "EA", scarce: false, price_minor: 400, available: 5, name: "Blue mug" },
      { id: "TOWEL", unit: "EA", scarce: false, price_minor: 900, available: 1, name: "Bath towel" },
    ],
  });
}

/** Warm the SKU cache while online (a terminal can only sell offline what it has seen). */
async function prime(r: Rig, ...skus: string[]) {
  await r.term.refresh(skus);
}

describe("terminal: offline selling, queue and labelling", () => {
  let r: Rig;
  beforeEach(async () => {
    r = await rig();
    await prime(r, "KETTLE-RED", "MUG-BLUE", "TOWEL");
  });

  it("makes NO network call while offline (sell, status, queue, exceptions, receipt)", async () => {
    await r.term.goOffline();
    const before = r.chain.calls.length;
    const res = await r.term.sell([{ sku: "MUG-BLUE", qty: 2 }], { customerId: "CUST-DEMO01" });
    r.term.status();
    r.term.listExceptions();
    formatQueue(r.term.state.queue);
    formatReceipt(r.term.state, res);
    expect(r.chain.calls.length).toBe(before);
  });

  it("refuses network operations while offline without touching the gateway", async () => {
    await r.term.goOffline();
    const before = r.chain.calls.length;
    await expect(r.term.sync()).rejects.toBeInstanceOf(OfflineError);
    await expect(r.term.requestAllowance("KETTLE-RED", 2)).rejects.toBeInstanceOf(OfflineError);
    await expect(r.term.refresh()).rejects.toBeInstanceOf(OfflineError);
    expect(r.chain.calls.length).toBe(before);
  });

  it("an offline sale is signed locally, queued UNFINALISED and labelled everywhere", async () => {
    await r.term.goOffline();
    const res = await r.term.sell([{ sku: "MUG-BLUE", qty: 2 }], { customerId: "CUST-DEMO01", paymentMethod: "CARD" });
    expect(res.mode).toBe("OFFLINE");
    expect(res.sale.status).toBe("UNFINALISED");
    // non-scarce, no allowance: pre-signed ReserveStock followed by a CompleteSale referencing it
    expect(res.queue.map((q) => q.tx_type)).toEqual(["ReserveStock", "CompleteSale"]);
    expect(res.queue.every((q) => q.status === "UNFINALISED")).toBe(true);
    expect(res.sale.lines[0]?.backing).toBe("PRESIGNED_RESERVATION");

    // every queued request is a real, verifiable signed envelope from the terminal key
    for (const q of res.queue) {
      const chk = verifyEnvelope(q.envelope, NET);
      expect(chk.ok).toBe(true);
      expect(chk.body?.signer).toBe("term-n01-1");
      expect(q.status).toBe("UNFINALISED");
    }
    const reserve = res.queue[0]!;
    const saleItem = res.queue[1]!;
    const resBody = verifyEnvelope(reserve.envelope, NET).body!.payload as unknown as { reservation_id: string; terminal_id: string; allowance?: boolean };
    const saleBody = verifyEnvelope(saleItem.envelope, NET).body!.payload as unknown as { lines: { reservation_id: string }[]; terminal_id: string; customer_id: string };
    expect(saleBody.lines[0]?.reservation_id).toBe(resBody.reservation_id);
    expect(resBody.terminal_id).toBe("term-n01-1");
    expect(resBody.allowance).toBeUndefined();
    expect(saleBody.customer_id).toBe("CUST-DEMO01");
    expect(saleItem.depends_on).toEqual([reserve.id]);
    // replay window bounded by valid_until_height computed from the last known height
    const vu = verifyEnvelope(reserve.envelope, NET).body!.valid_until_height;
    expect(vu).toBeGreaterThan(r.chain.height);

    const text = formatReceipt(r.term.state, res).join("\n");
    expect(text).toContain(OFFLINE_BANNER);
    expect(text).toContain("OFFLINE – NOT FINALISED");
    expect(text).toContain(UNFINALISED_LABEL);
    expect(text).toContain("NOT stock-protected");
    expect(formatStatus(r.term.status()).join("\n")).toContain(OFFLINE_BANNER);
    expect(formatQueue(r.term.state.queue).join("\n")).toContain("UNFINALISED / NOT CONFIRMED");
    // nothing reached the chain
    expect(r.chain.submitted.length).toBe(0);
    expect(r.chain.available("MUG-BLUE")).toBe(5);
  });

  it("the queue is durable: a new Terminal over the same state sees it", async () => {
    await r.term.goOffline();
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    const again = await r.reopen();
    expect(again.state.mode).toBe("OFFLINE");
    expect(again.state.queue.filter((q) => q.status === "UNFINALISED").length).toBe(2);
  });

  it("refuses an unknown SKU offline (never seen online)", async () => {
    await r.term.goOffline();
    await expect(r.term.sell([{ sku: "NEVER-SEEN", qty: 1 }])).rejects.toThrow(/offline cache/);
  });

  it("validates quantities, duplicates and customer references before signing anything", async () => {
    await r.term.goOffline();
    await expect(r.term.sell([{ sku: "MUG-BLUE", qty: 0 }])).rejects.toBeInstanceOf(PolicyRefusal);
    await expect(r.term.sell([{ sku: "MUG-BLUE", qty: 1 }, { sku: "MUG-BLUE", qty: 1 }])).rejects.toThrow(/twice/);
    await expect(r.term.sell([{ sku: "MUG-BLUE", qty: 1 }], { customerId: "alice@example.com" })).rejects.toThrow(/CUST-xxxx/);
    expect(r.term.state.queue.length).toBe(0);
  });
});

describe("terminal: scarce SKUs require a pre-allocated allowance offline", () => {
  let r: Rig;
  beforeEach(async () => {
    r = await rig();
    await prime(r, "KETTLE-RED", "MUG-BLUE");
  });

  it("refuses a scarce SKU offline without an allowance, and queues nothing", async () => {
    await r.term.goOffline();
    await expect(r.term.sell([{ sku: "KETTLE-RED", qty: 1 }])).rejects.toThrow(/online finality required for scarce items/);
    expect(r.term.state.queue.length).toBe(0);
    expect(Object.keys(r.term.state.sales).length).toBe(0);
  });

  it("an all-or-nothing refusal: a mixed basket with one unbacked scarce line signs nothing", async () => {
    await r.term.goOffline();
    await expect(r.term.sell([{ sku: "MUG-BLUE", qty: 1 }, { sku: "KETTLE-RED", qty: 1 }])).rejects.toBeInstanceOf(PolicyRefusal);
    expect(r.term.state.queue.length).toBe(0);
  });

  it("allowance is ReserveStock{allowance:true, terminal_id} with the chain's maximum ttl, finalised online", async () => {
    const a = await r.term.requestAllowance("KETTLE-RED", 5);
    const sub = r.chain.submitted.find((s) => s.type === "ReserveStock")!;
    expect(sub.payload["allowance"]).toBe(true);
    expect(sub.payload["terminal_id"]).toBe("term-n01-1");
    expect(sub.payload["ttl_ms"]).toBe(r.chain.params.allowance_max_ttl_ms);
    expect(sub.code).toBe(0);
    expect(a.granted_v).toBe(5);
    expect(a.chain_remaining_v).toBe(5);
    expect(r.chain.available("KETTLE-RED")).toBe(5); // pre-allocated: no longer sellable by others
  });

  it("refuses an allowance ttl above the chain limit before sending anything", async () => {
    const before = r.chain.submitted.length;
    await expect(r.term.requestAllowance("KETTLE-RED", 1, { ttlMs: r.chain.params.allowance_max_ttl_ms + 1 })).rejects.toThrow(/chain limit/);
    expect(r.chain.submitted.length).toBe(before);
  });

  it("sells against the allowance offline (no ReserveStock queued), tracks remaining units locally, refuses beyond", async () => {
    const a = await r.term.requestAllowance("KETTLE-RED", 3);
    await r.term.goOffline();

    const s1 = await r.term.sell([{ sku: "KETTLE-RED", qty: 2 }]);
    expect(s1.queue.map((q) => q.tx_type)).toEqual(["CompleteSale"]);
    expect(s1.sale.lines[0]).toMatchObject({ backing: "ALLOWANCE", reservation_id: a.reservation_id, allowance_id: a.reservation_id });
    const saleBody = verifyEnvelope(s1.queue[0]!.envelope, NET).body!.payload as unknown as { lines: { reservation_id: string; qty: { v: number } }[] };
    expect(saleBody.lines[0]).toMatchObject({ reservation_id: a.reservation_id, qty: { v: 2 } });
    expect(r.term.state.allowances[a.reservation_id]).toMatchObject({ chain_remaining_v: 3, pending_v: 2 });
    expect(formatReceipt(r.term.state, s1).join("\n")).toContain(`allowance ${a.reservation_id}`);

    // 1 unit left locally: 1 is fine, 2 is refused
    await expect(r.term.sell([{ sku: "KETTLE-RED", qty: 2 }])).rejects.toThrow(/online finality required for scarce items.*1 usable/);
    const s2 = await r.term.sell([{ sku: "KETTLE-RED", qty: 1 }]);
    expect(s2.queue.length).toBe(1);
    expect(r.term.state.allowances[a.reservation_id]?.pending_v).toBe(3);
    await expect(r.term.sell([{ sku: "KETTLE-RED", qty: 1 }])).rejects.toBeInstanceOf(PolicyRefusal);
  });

  it("refuses to sell against an allowance that is expired or expiring on the terminal clock", async () => {
    const a = await r.term.requestAllowance("KETTLE-RED", 3);
    await r.term.goOffline();
    r.clock.t = a.expires_at_ms - 60_000; // inside the 15 minute safety margin
    await expect(r.term.sell([{ sku: "KETTLE-RED", qty: 1 }])).rejects.toThrow(/online finality required/);
    expect(formatStatus(r.term.status()).join("\n")).toMatch(/WARNING.*expires/);
  });

  it("offline sale against an allowance syncs as ACCEPTED and updates the chain-side tracking", async () => {
    const a = await r.term.requestAllowance("KETTLE-RED", 3);
    await r.term.goOffline();
    await r.term.sell([{ sku: "KETTLE-RED", qty: 2 }]);
    await r.term.goOnline({ sync: false });
    const rep = await r.term.sync();
    expect(rep.accepted).toBe(1);
    expect(rep.rejected).toBe(0);
    expect(r.term.state.allowances[a.reservation_id]).toMatchObject({ chain_remaining_v: 1, pending_v: 0 });
    expect(r.chain.resv.get(a.reservation_id)).toMatchObject({ qty: 1, consumed_v: 2, status: "ACTIVE" }); // partial consumption
  });

  it("releasing an allowance returns the units (online only)", async () => {
    const a = await r.term.requestAllowance("KETTLE-RED", 4);
    await r.term.releaseAllowance(a.reservation_id);
    expect(r.chain.available("KETTLE-RED")).toBe(10);
    expect(r.term.state.allowances[a.reservation_id]?.status).toBe("RELEASED");
  });
});

describe("terminal: sync splits ACCEPTED vs REJECTED and keeps exceptions", () => {
  let r: Rig;
  beforeEach(async () => {
    r = await rig();
    await prime(r, "KETTLE-RED", "MUG-BLUE", "TOWEL");
    await r.term.goOffline();
  });

  it("accepts a good sale and rejects an oversold one (dependent sale marked REJECTED: dependency failed)", async () => {
    await r.term.sell([{ sku: "MUG-BLUE", qty: 2 }], { customerId: "CUST-DEMO01" }); // stock is fine
    await r.term.sell([{ sku: "TOWEL", qty: 1 }]); // the last towel...
    r.chain.setAvailable("TOWEL", 0); // ...is sold elsewhere while we are disconnected

    const out = await r.term.goOnline();
    const rep = out.sync!;
    expect(rep.accepted).toBe(2); // mug reserve + mug sale
    expect(rep.rejected).toBe(2); // towel reserve (INSUFFICIENT) + towel sale (dependency)
    const byType = (t: string, name: string) => rep.rows.find((x) => x.tx_type === t && x.status === "REJECTED" && x.code_name === name);
    expect(byType("ReserveStock", "INSUFFICIENT")).toBeTruthy();
    expect(byType("CompleteSale", "DEPENDENCY_FAILED")).toBeTruthy();
    expect(rep.stillUnfinalised).toBe(0);

    // the dependent sale was never submitted to the chain
    expect(r.chain.submitted.filter((s) => s.type === "CompleteSale").length).toBe(1);

    const accepted = r.term.state.queue.filter((q) => q.status === "ACCEPTED").map((q) => q.tx_type).sort();
    expect(accepted).toEqual(["CompleteSale", "ReserveStock"]);
    const sales = Object.values(r.term.state.sales);
    expect(sales.map((s) => s.status).sort()).toEqual(["FINALISED", "REJECTED"]);
    expect(sales.find((s) => s.status === "FINALISED")?.net_minor).toBe(800);

    // exception recorded with code names and reasons
    expect(rep.newExceptions.length).toBe(1);
    const exc = r.term.listExceptions()[0]!;
    expect(exc.status).toBe("OPEN");
    expect(exc.reasons.map((x) => x.code_name).sort()).toEqual(["DEPENDENCY_FAILED", "INSUFFICIENT"]);

    const printed = formatSync(rep).join("\n");
    expect(printed).toContain("ACCEPTED");
    expect(printed).toContain("REJECTED");
    expect(printed).toContain("INSUFFICIENT");
    expect(printed).toContain("DEPENDENCY_FAILED");
    expect(printed).toContain("NEW EXCEPTION");
    expect(formatExceptions(r.term.listExceptions()).join("\n")).toContain("INSUFFICIENT");
  });

  it("submits the queue in order, one sale at a time", async () => {
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    await r.term.goOnline();
    expect(r.chain.submitted.map((s) => s.type)).toEqual(["ReserveStock", "CompleteSale", "ReserveStock", "CompleteSale"]);
  });

  it("an interrupted sync leaves the rest UNFINALISED and the next sync resumes without double-booking", async () => {
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    await r.term.goOnline({ sync: false });
    r.chain.failSubmitsAfter = 2; // first sale goes through, then the connection dies
    const rep = await r.term.sync();
    expect(rep.interrupted).toMatch(/connection loss/);
    expect(rep.accepted).toBe(2);
    expect(rep.stillUnfinalised).toBe(2);
    expect(formatSync(rep).join("\n")).toContain("SYNC INTERRUPTED");
    expect(r.term.state.queue.filter((q) => q.status === "UNFINALISED").length).toBe(2);

    r.chain.failSubmitsAfter = undefined;
    const rep2 = await r.term.sync();
    expect(rep2.accepted).toBe(2);
    expect(rep2.stillUnfinalised).toBe(0);
    expect(r.chain.available("MUG-BLUE")).toBe(5 - 2 + 0); // two reserves consumed by two sales
    expect(r.chain.sales.size).toBe(2);
  });

  it("a lost response is reconciled with tx status instead of being resubmitted blindly", async () => {
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    await r.term.goOnline({ sync: false });
    r.chain.loseNextResponse = true; // the reserve executes on chain but we never see the answer
    const rep = await r.term.sync();
    expect(rep.interrupted).toBeDefined();
    expect(rep.stillUnfinalised).toBe(2);
    const rep2 = await r.term.sync();
    expect(rep2.accepted).toBe(2);
    expect(rep2.rows.find((x) => x.tx_type === "ReserveStock")?.reason).toMatch(/finalised earlier/);
    expect(r.chain.submitted.filter((s) => s.type === "ReserveStock").length).toBe(1); // never executed twice
  });

  it("a request past its valid_until_height is REJECTED at admission (EXPIRED), not silently dropped", async () => {
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    // age the chain past valid_until_height: EXPIRED (203) at admission
    r.chain.height = 10_000_000;
    const out = await r.term.goOnline();
    expect(out.sync!.rejected).toBeGreaterThanOrEqual(1);
    expect(out.sync!.rows.some((x) => x.code_name === "EXPIRED")).toBe(true);
  });
});

describe("terminal: exceptions workflow (retry / cancel / escalate)", () => {
  let r: Rig;
  async function oversold(): Promise<string> {
    await r.term.goOffline();
    await r.term.sell([{ sku: "TOWEL", qty: 1 }]);
    r.chain.setAvailable("TOWEL", 0);
    await r.term.goOnline();
    return r.term.listExceptions()[0]!.id;
  }
  beforeEach(async () => {
    r = await rig();
    await prime(r, "TOWEL", "MUG-BLUE");
  });

  it("retry re-signs with NEW tx ids and a NEW reservation id, keeps the sale id, and resolves when stock exists", async () => {
    const id = await oversold();
    const exc = r.term.listExceptions()[0]!;
    const sale = r.term.state.sales[exc.sale_ref]!;
    const oldReservation = sale.lines[0]!.reservation_id;
    const oldTxIds = r.term.state.queue.map((q) => q.tx_id);

    // still no stock: retry fails, exception stays OPEN, the failure is logged
    const bad = await r.term.resolve(id, "retry");
    expect(bad.ok).toBe(false);
    expect(bad.message).toMatch(/INSUFFICIENT/);
    expect(r.term.listExceptions()[0]?.retry_log.length).toBe(1);

    r.chain.setAvailable("TOWEL", 2); // a manager's adjustment (or a delivery) fixed the stock
    const ok = await r.term.resolve(id, "retry");
    expect(ok.ok).toBe(true);
    expect(ok.txIds.every((t) => !oldTxIds.includes(t))).toBe(true);
    const finalSale = r.term.state.sales[exc.sale_ref]!;
    expect(finalSale.status).toBe("FINALISED");
    expect(finalSale.sale_id).toBe(exc.sale_ref); // same sale id: the chain cannot record it twice
    expect(finalSale.lines[0]!.reservation_id).not.toBe(oldReservation);
    expect(r.chain.sales.has(exc.sale_ref)).toBe(true);
    expect(r.term.listExceptions().length).toBe(0);
    expect(r.term.state.exceptions[0]?.status).toBe("RESOLVED_RETRIED");
  });

  it("retry needs the network: refused offline without any network call", async () => {
    const id = await oversold();
    await r.term.goOffline();
    const before = r.chain.calls.length;
    await expect(r.term.resolve(id, "retry")).rejects.toBeInstanceOf(OfflineError);
    expect(r.chain.calls.length).toBe(before);
  });

  it("cancel needs a reason, voids locally, releases reservations the chain accepted, and warns about goods", async () => {
    await r.term.goOffline();
    // two lines: mug reserve will be accepted, towel reserve rejected -> the mug reservation is orphaned on chain
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }, { sku: "TOWEL", qty: 1 }]);
    r.chain.setAvailable("TOWEL", 0);
    await r.term.goOnline();
    const exc = r.term.listExceptions()[0]!;
    expect(exc.orphan_reservations.length).toBe(1);
    expect(r.chain.available("MUG-BLUE")).toBe(4); // orphan still holds one mug

    await expect(r.term.resolve(exc.id, "cancel")).rejects.toThrow(/--reason/);
    const res = await r.term.resolve(exc.id, "cancel", { reason: "customer returned the goods at the till" });
    expect(res.ok).toBe(true);
    expect(res.exception.status).toBe("CANCELLED");
    expect(res.exception.resolution?.note).toBe("customer returned the goods at the till");
    expect(res.notes.join(" ")).toMatch(/goods already left the store/i);
    expect(res.notes.join(" ")).toMatch(/AdjustStock PROPOSE/);
    expect(r.chain.available("MUG-BLUE")).toBe(5); // orphan released
    expect(r.term.state.sales[exc.sale_ref]?.status).toBe("CANCELLED");
    expect(r.term.listExceptions().length).toBe(0);
    await expect(r.term.resolve(exc.id, "cancel", { reason: "again" })).rejects.toThrow(/already CANCELLED/);
  });

  it("cancel while OFFLINE signs the release and queues it (no network call)", async () => {
    await r.term.goOffline();
    await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }, { sku: "TOWEL", qty: 1 }]);
    r.chain.setAvailable("TOWEL", 0);
    await r.term.goOnline();
    const exc = r.term.listExceptions()[0]!;
    await r.term.goOffline();
    const before = r.chain.calls.length;
    const res = await r.term.resolve(exc.id, "cancel", { reason: "voided by supervisor" });
    expect(r.chain.calls.length).toBe(before);
    expect(res.notes.join(" ")).toMatch(/queued as Q-\d+ \(UNFINALISED/);
    const release = r.term.state.queue.find((q) => q.kind === "RELEASE")!;
    expect(release.status).toBe("UNFINALISED");
    await r.term.goOnline();
    expect(r.chain.available("MUG-BLUE")).toBe(5);
  });

  it("escalate writes a record with the manager procedure (AdjustStock PROPOSE then APPROVE by a different signer, then retry)", async () => {
    const id = await oversold();
    const res = await r.term.resolve(id, "escalate", { reason: "store manager informed" });
    const esc = res.escalation!;
    expect(esc.id).toBe("ESC-0001");
    expect(r.term.state.escalations.length).toBe(1);
    expect(res.exception.status).toBe("ESCALATED");
    const steps = esc.suggested_actions.map((a) => `${a.tx_type ?? ""}:${(a.payload_template as { op?: string } | undefined)?.op ?? ""}`);
    expect(steps).toContain("AdjustStock:PROPOSE");
    expect(steps).toContain("AdjustStock:APPROVE");
    const proposeIdx = steps.indexOf("AdjustStock:PROPOSE");
    const approveIdx = steps.indexOf("AdjustStock:APPROVE");
    expect(approveIdx).toBeGreaterThan(proposeIdx);
    expect(esc.suggested_actions[approveIdx]?.actor).toMatch(/DIFFERENT/);
    expect(esc.suggested_actions.some((a) => /retry/.test(a.action))).toBe(true);
    expect(esc.goods_may_have_left_store).toBe(true);
    expect(esc.problem).toMatch(/Oversell/);
    const text = formatEscalation(esc).join("\n");
    expect(text).toContain("AdjustStock");
    expect(text).toContain("DIFFERENT");
    // an escalated exception can still be retried afterwards
    r.chain.setAvailable("TOWEL", 1);
    expect((await r.term.resolve(id, "retry")).ok).toBe(true);
  });
});

describe("terminal: online selling", () => {
  let r: Rig;
  beforeEach(async () => {
    r = await rig();
  });

  it("online sell = Reserve + CompleteSale with finality; receipt says FINALISED", async () => {
    const res = await r.term.sell([{ sku: "MUG-BLUE", qty: 2 }, { sku: "KETTLE-RED", qty: 1 }], { customerId: "CUST-DEMO01" });
    expect(res.mode).toBe("ONLINE");
    expect(res.sale.status).toBe("FINALISED");
    expect(res.finalised?.data["net_minor"]).toBe(800 + 2500);
    expect(r.chain.submitted.map((s) => s.type)).toEqual(["ReserveStock", "ReserveStock", "CompleteSale"]);
    const text = formatReceipt(r.term.state, res).join("\n");
    expect(text).toContain("FINALISED at height");
    expect(text).not.toContain(OFFLINE_BANNER);
    expect(r.term.state.queue.length).toBe(0);
  });

  it("insufficient stock online: the sale is refused and accepted reservations are released", async () => {
    await expect(r.term.sell([{ sku: "MUG-BLUE", qty: 1 }, { sku: "TOWEL", qty: 5 }])).rejects.toBeInstanceOf(SaleFailed);
    expect(r.chain.available("MUG-BLUE")).toBe(5); // the mug reservation that DID succeed was released
    expect(r.chain.sales.size).toBe(0);
  });

  it("connection lost while completing the sale: the signed request is kept as UNFINALISED, never lost", async () => {
    r.chain.failSubmitsAfter = 1; // reserve succeeds; the CompleteSale submit fails
    const res = await r.term.sell([{ sku: "MUG-BLUE", qty: 1 }]);
    expect(res.outcomeUnknown).toBe(true);
    expect(res.sale.status).toBe("UNFINALISED");
    expect(res.queue[0]?.tx_type).toBe("CompleteSale");
    expect(formatReceipt(r.term.state, res).join("\n")).toContain("OUTCOME UNKNOWN");
    r.chain.failSubmitsAfter = undefined;
    const rep = await r.term.sync();
    expect(rep.accepted).toBe(1);
    expect(r.term.state.sales[res.sale.sale_id]?.status).toBe("FINALISED");
  });

  it("go-online with an unreachable gateway keeps the terminal OFFLINE", async () => {
    await r.term.goOffline();
    r.chain.network = async () => {
      throw new NetworkError("down");
    };
    await expect(r.term.goOnline()).rejects.toThrow(/stays OFFLINE/);
    expect(r.term.state.mode).toBe("OFFLINE");
  });

  it("refuses a state file that belongs to another terminal or network", async () => {
    const keys = new MemoryKeyStore();
    await keys.generate("term-n01-2", "k1");
    const other = await Signer.forIdentity(keys, "term-n01-2");
    await expect(Terminal.open({ store: r.store, gateway: r.chain, signer: other })).rejects.toThrow(/belongs to terminal/);
    await expect(Terminal.open({ store: r.store, gateway: r.chain, signer: r.signer, networkId: "other-net" })).rejects.toThrow(/network/);
  });
});
