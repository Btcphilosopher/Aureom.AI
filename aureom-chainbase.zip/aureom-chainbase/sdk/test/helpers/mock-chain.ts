// A tiny in-memory stand-in for the gateway + state machine, faithful for the handful of
// transaction types the terminal uses (ReserveStock / CompleteSale / ReleaseReservation).
// It enforces the same rules as chain/internal/core (see h_stock.go, h_sales.go): total order,
// all-or-nothing, reservation expiry by BLOCK time, allowance partial consumption, replay and
// idempotency rejection, valid_until_height, signature verification.

import {
  NetworkError,
  verifyEnvelope,
  type ChainRecordOptions,
  type ChainRecordResponse,
  type Envelope,
  type NetworkInfo,
  type SignedTx,
  type SubmitOptions,
  type SubmitResponse,
  type TxGateway,
  type TxStatus,
  codeName,
  parseEnvelope,
} from "../../src/index.js";

interface Resv {
  id: string;
  sku: string;
  loc: string;
  qty: number;
  unit: string;
  status: "ACTIVE" | "RELEASED" | "CONSUMED" | "EXPIRED";
  allowance: boolean;
  holder: string;
  terminal_id?: string;
  expires_at_ms: number;
  consumed_v: number;
}

export interface MockSku {
  id: string;
  unit: string;
  scarce: boolean;
  price_minor: number;
  available: number;
  name?: string;
}

export interface MockChainOptions {
  networkId?: string;
  startMs?: number;
  skus: MockSku[];
  /** identity id -> bound location */
  terminals?: Record<string, string>;
}

export class MockChain implements TxGateway {
  readonly networkId: string;
  height = 100;
  timeMs: number;
  /** every gateway method call, in order (to prove an OFFLINE terminal makes none) */
  calls: string[] = [];
  /** fail the next N submits with a NetworkError (simulating a connection loss mid-sync) */
  failSubmitsAfter: number | undefined;
  /** swallow the response of the next submit AFTER executing it (answer lost on the wire) */
  loseNextResponse = false;
  readonly stock = new Map<string, number>();
  readonly skus = new Map<string, MockSku>();
  readonly resv = new Map<string, Resv>();
  readonly sales = new Map<string, { id: string; net: number; lines: unknown[] }>();
  readonly txs = new Map<string, TxStatus>();
  readonly idem = new Set<string>();
  readonly submitted: { type: string; txId: string; code: number; payload: Record<string, unknown> }[] = [];
  readonly params = { reservation_max_ttl_ms: 1_800_000, allowance_max_ttl_ms: 7 * 24 * 3600_000, max_backdate_ms: 3 * 24 * 3600_000, max_future_skew_ms: 300_000 };
  readonly pubByIdentity = new Map<string, string>();
  private readonly terminals: Record<string, string>;

  constructor(opts: MockChainOptions) {
    this.networkId = opts.networkId ?? "net-test-1";
    this.timeMs = opts.startMs ?? 1_790_000_000_000;
    this.terminals = opts.terminals ?? { "term-n01-1": "STORE-N-01", "term-n01-2": "STORE-N-01" };
    for (const s of opts.skus) {
      this.skus.set(s.id, s);
      this.stock.set(s.id, s.available);
    }
  }

  private call(name: string): void {
    this.calls.push(name);
  }

  available(sku: string): number {
    return this.stock.get(sku) ?? 0;
  }
  setAvailable(sku: string, n: number): void {
    this.stock.set(sku, n);
  }

  async network(): Promise<NetworkInfo> {
    this.call("network");
    return {
      network_id: this.networkId,
      app_version: 1,
      chain: { latest_height: this.height, latest_block_time: new Date(this.timeMs).toISOString(), latest_app_hash: "00", block_interval_ms_avg: 1000 },
      bft: { validators: 4, voting_power_total: 40, f: 1, quorum_power_required: 27, online_power: 40, online_validators: 4, status: "HEALTHY" },
      validators: [],
      members: [],
      mempool: { unconfirmed_txs: 0 },
      queried_at: "",
    };
  }

  async getRecord<T = unknown>(key: string, _opts?: ChainRecordOptions): Promise<ChainRecordResponse<T>> {
    this.call(`getRecord:${key}`);
    const mk = (value: unknown | undefined): ChainRecordResponse<T> => ({ key, found: value !== undefined, ...(value !== undefined ? { value: value as T } : {}), height: this.height });
    const [kind, id] = [key.slice(0, key.indexOf("/")), key.slice(key.indexOf("/") + 1)];
    if (kind === "sku") {
      const s = this.skus.get(id);
      return mk(s && { id: s.id, product_id: `P-${s.id}`, unit: s.unit, scarce: s.scarce, status: "ACTIVE" });
    }
    if (kind === "product") {
      const sku = id.replace(/^P-/, "");
      const s = this.skus.get(sku);
      return mk(s && { id, name: s.name ?? `Product ${sku}`, status: "ACTIVE", skus: [sku] });
    }
    if (key === "gov/params") return mk(this.params);
    if (kind === "iam") return mk({ id: id.replace("id/", ""), bound_location: this.terminals[id.replace("id/", "")], keys: [], kind: "TERMINAL" });
    if (kind === "resv") {
      const r = this.resv.get(id);
      return mk(r && { ...r, loc: r.loc, qty: r.qty });
    }
    return mk(undefined);
  }

  async txStatus(txId: string): Promise<TxStatus> {
    this.call(`txStatus:${txId}`);
    return this.txs.get(txId) ?? { tx_id: txId, status: "UNKNOWN" };
  }

  async submit(tx: SignedTx | Envelope | string, _opts?: SubmitOptions): Promise<SubmitResponse> {
    this.call("submit");
    if (this.failSubmitsAfter !== undefined) {
      if (this.failSubmitsAfter <= 0) throw new NetworkError("simulated connection loss");
      this.failSubmitsAfter -= 1;
    }
    const env = typeof tx === "string" ? parseEnvelope(tx) : "envelope" in tx ? tx.envelope : tx;
    const resp = this.process(env);
    if (this.loseNextResponse) {
      this.loseNextResponse = false;
      throw new NetworkError("simulated: response lost after the chain executed the tx");
    }
    return resp;
  }

  // ---- state machine ---------------------------------------------------------------------

  private process(env: Envelope): SubmitResponse {
    const chk = verifyEnvelope(env, this.networkId);
    const body = chk.body;
    const reject = (code: number, log: string): SubmitResponse => ({
      tx_hash: "",
      tx_id: body?.tx_id ?? "",
      type: body?.type ?? "",
      signer: body?.signer ?? "",
      admission: { code, name: codeName(code), log },
    });
    if (!chk.ok || !body) return reject(chk.reason?.includes("network") ? 3 : 101, chk.reason ?? "bad envelope");
    if (!(body.signer in this.terminals) && !body.signer.startsWith("manager")) return reject(201, "unknown signer");
    if (body.valid_until_height !== undefined && this.height + 1 > body.valid_until_height) return reject(203, "valid_until_height passed");
    if (this.txs.has(body.tx_id)) return reject(210, "tx_id already processed");
    if (this.idem.has(`${body.signer}/${body.idempotency_ref}`)) return reject(211, "idempotency_ref already executed");

    this.height += 1;
    this.timeMs += 1000;
    const payload = body.payload as unknown as Record<string, unknown>;
    let code = 0;
    let log = "";
    let data: Record<string, unknown> = {};
    const err = (c: number, l: string) => {
      code = c;
      log = l;
    };
    switch (body.type) {
      case "ReserveStock": {
        const sku = this.skus.get(payload["sku"] as string);
        const qty = (payload["qty"] as { v: number; unit: string }).v;
        const rid = payload["reservation_id"] as string;
        const allowance = payload["allowance"] === true;
        const max = allowance ? this.params.allowance_max_ttl_ms : this.params.reservation_max_ttl_ms;
        if (this.resv.has(rid)) err(402, "reservation id exists");
        else if (!sku) err(401, "sku not found");
        else if ((payload["ttl_ms"] as number) > max) err(406, `ttl_ms exceeds ${max}`);
        else if (this.available(sku.id) < qty) err(404, `insufficient available at ${payload["location_id"]} for ${sku.id}: have ${this.available(sku.id)} need ${qty}`);
        else {
          this.stock.set(sku.id, this.available(sku.id) - qty);
          const r: Resv = { id: rid, sku: sku.id, loc: payload["location_id"] as string, qty, unit: sku.unit, status: "ACTIVE", allowance, holder: body.signer, expires_at_ms: this.timeMs + (payload["ttl_ms"] as number), consumed_v: 0 };
          if (typeof payload["terminal_id"] === "string") r.terminal_id = payload["terminal_id"];
          this.resv.set(rid, r);
          data = { reservation_id: rid, expires_at_ms: r.expires_at_ms };
        }
        break;
      }
      case "ReleaseReservation": {
        const r = this.resv.get(payload["reservation_id"] as string);
        if (!r) err(401, "reservation not found");
        else if (r.status !== "ACTIVE") err(405, `reservation is ${r.status}`);
        else {
          this.stock.set(r.sku, this.available(r.sku) + r.qty);
          r.status = "RELEASED";
          r.qty = 0;
          data = { reservation_id: r.id, status: "RELEASED" };
        }
        break;
      }
      case "CompleteSale": {
        const lines = payload["lines"] as { sku: string; qty: { v: number }; reservation_id: string }[];
        const saleId = payload["sale_id"] as string;
        let net = 0;
        const staged: { r: Resv; qty: number }[] = [];
        if (this.sales.has(saleId)) err(402, `sale ${saleId} exists (duplicate sale prevented)`);
        const eff = payload["effective_at_ms"] as number;
        if (code === 0 && eff < this.timeMs - this.params.max_backdate_ms) err(407, "effective_at_ms older than max backdate window");
        for (const l of lines) {
          if (code !== 0) break;
          const r = this.resv.get(l.reservation_id);
          if (!r) err(401, `reservation ${l.reservation_id} not found`);
          else if (r.status !== "ACTIVE") err(405, `reservation ${r.id} is ${r.status}`);
          else if (r.sku !== l.sku) err(407, `reservation ${r.id} is for ${r.sku}`);
          else if (this.timeMs >= r.expires_at_ms) err(405, `reservation ${r.id} expired`);
          else if (r.terminal_id && r.terminal_id !== payload["terminal_id"]) err(303, `reservation ${r.id} is bound to terminal ${r.terminal_id}`);
          else if (r.allowance && l.qty.v > r.qty) err(404, `allowance ${r.id} has ${r.qty} left, sale needs ${l.qty.v}`);
          else if (!r.allowance && l.qty.v !== r.qty) err(407, `sale quantity ${l.qty.v} must equal reservation quantity ${r.qty}`);
          else {
            staged.push({ r, qty: l.qty.v });
            net += (this.skus.get(l.sku)?.price_minor ?? 0) * l.qty.v;
          }
        }
        if (code === 0) {
          for (const s of staged) {
            s.r.qty -= s.qty;
            s.r.consumed_v += s.qty;
            if (s.r.qty === 0) s.r.status = "CONSUMED";
          }
          this.sales.set(saleId, { id: saleId, net, lines });
          data = { sale_id: saleId, net_minor: net, gross_minor: net, discount_minor: 0 };
        }
        break;
      }
      default:
        err(4, `mock chain does not implement ${body.type}`);
    }
    if (code === 0) this.idem.add(`${body.signer}/${body.idempotency_ref}`); // the chain records idempotency only after SUCCESS
    const status: TxStatus = { tx_id: body.tx_id, status: code === 0 ? "FINALISED_OK" : "FINALISED_REJECTED", height: this.height, index: 0, code, code_name: codeName(code), reason: log, signer: body.signer, type: body.type };
    this.txs.set(body.tx_id, status);
    this.submitted.push({ type: body.type, txId: body.tx_id, code, payload });
    return {
      tx_hash: "",
      tx_id: body.tx_id,
      type: body.type,
      signer: body.signer,
      admission: { code: 0, name: "OK", log: "" },
      finalised: { height: this.height, index: 0, code, code_name: codeName(code), log, data },
      indexed: false,
    };
  }
}
