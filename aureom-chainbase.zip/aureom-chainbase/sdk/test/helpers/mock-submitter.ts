// A scriptable stand-in for the gateway as seen by AdapterRunner: it verifies envelope signatures,
// enforces tx-id replay / idempotency_ref semantics like the chain, dedupes payment events by
// provider+event_id, and lets a test script transient failures, lost responses and business rejections.

import {
  NetworkError,
  codeName,
  verifyEnvelope,
  type SignedTx,
  type SubmitOptions,
  type SubmitResponse,
  type TxStatus,
} from "../../src/index.js";
import type { TxSubmitter } from "../../src/integration/index.js";

export type Script =
  | { kind: "network" } // submit throws NetworkError BEFORE reaching the chain
  | { kind: "lost-response" } // chain executes, then the answer is lost (throws NetworkError)
  | { kind: "reject"; code: number; log?: string } // chain orders the tx but rejects it
  | { kind: "admit-reject"; code: number; log?: string } // refused at admission (CheckTx): never ordered, no trace on chain
  | { kind: "admitted-only" } // admitted, no finalised in the response (timeout), status resolves later
  | { kind: "ok" }; // behave normally (used to position a later scripted failure)

export interface Seen {
  type: string;
  txId: string;
  signer: string;
  idem: string;
  payload: Record<string, unknown>;
  code: number;
}

export class MockSubmitter implements TxSubmitter {
  readonly networkId: string;
  height = 500;
  /** every submit call that reached the chain, in order */
  readonly seen: Seen[] = [];
  /** raw call count (including calls that failed before reaching the chain) */
  calls = 0;
  readonly statusCalls: string[] = [];
  private readonly txs = new Map<string, TxStatus>();
  private readonly idem = new Set<string>();
  private readonly events = new Set<string>();
  private readonly scripts = new Map<string, Script[]>();
  private readonly allScripts: Script[] = [];

  constructor(networkId = "net-test-1") {
    this.networkId = networkId;
  }

  /** Script the next behaviours for a tx type ("*" = any). Consumed one per submit call. */
  script(type: string, ...s: Script[]): void {
    this.scripts.set(type, [...(this.scripts.get(type) ?? []), ...s]);
  }
  scriptAny(...s: Script[]): void {
    this.allScripts.push(...s);
  }
  private nextScript(type: string): Script | undefined {
    const q = this.scripts.get(type);
    return (q && q.shift()) ?? this.allScripts.shift();
  }

  async txStatus(txId: string): Promise<TxStatus> {
    this.statusCalls.push(txId);
    return this.txs.get(txId) ?? { tx_id: txId, status: "UNKNOWN" };
  }

  async submit(tx: SignedTx, _opts?: SubmitOptions): Promise<SubmitResponse> {
    this.calls++;
    const sc = this.nextScript(tx.type);
    if (sc?.kind === "network") throw new NetworkError("simulated: gateway unreachable");
    if (sc?.kind === "admit-reject") return { tx_hash: tx.txHash, tx_id: tx.txId, type: tx.type, signer: tx.signer, admission: { code: sc.code, name: codeName(sc.code), log: sc.log ?? "scripted admission rejection" } };
    const chk = verifyEnvelope(tx.envelope, this.networkId);
    const base = { tx_hash: tx.txHash, tx_id: tx.txId, type: tx.type, signer: tx.signer };
    if (!chk.ok) return { ...base, admission: { code: 101, name: "BAD_SIGNATURE", log: chk.reason ?? "" } };
    if (this.txs.has(tx.txId)) return { ...base, admission: { code: 210, name: "REPLAY", log: "tx_id already processed" } };
    if (this.idem.has(`${tx.signer}/${tx.idempotencyRef}`)) return { ...base, admission: { code: 211, name: "DUPLICATE_IDEMPOTENCY", log: "idempotency_ref already executed" } };
    const payload = tx.body.payload as unknown as Record<string, unknown>;
    this.height++;
    let code = 0;
    let log = "";
    let data: Record<string, unknown> = { ok: true };
    if (sc?.kind === "reject") {
      code = sc.code;
      log = sc.log ?? `scripted rejection ${codeName(sc.code)}`;
      data = {};
    } else if ((tx.type === "RecordPaymentResult" || tx.type === "RecordRefundResult") && typeof payload["event_id"] === "string") {
      const key = `${tx.type}/${String(payload["provider"])}/${String(payload["event_id"])}`;
      if (this.events.has(key)) data = { deduplicated: true };
      else this.events.add(key);
    }
    if (code === 0) this.idem.add(`${tx.signer}/${tx.idempotencyRef}`);
    this.seen.push({ type: tx.type, txId: tx.txId, signer: tx.signer, idem: tx.idempotencyRef, payload, code });
    this.txs.set(tx.txId, { tx_id: tx.txId, status: code === 0 ? "FINALISED_OK" : "FINALISED_REJECTED", height: this.height, index: 0, code, code_name: codeName(code), reason: log });
    if (sc?.kind === "lost-response") throw new NetworkError("simulated: answer lost after execution");
    const resp: SubmitResponse = { ...base, admission: { code: 0, name: "OK", log: "" } };
    if (sc?.kind === "admitted-only") return resp;
    resp.finalised = { height: this.height, index: 0, code, code_name: codeName(code), log, data };
    return resp;
  }
}
