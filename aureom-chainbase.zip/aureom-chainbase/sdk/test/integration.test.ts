// LIVE integration tests against a running network + gateway. Skipped unless GATEWAY_URL is set.
//
//   RUN_DIR=$PWD/../run GATEWAY_URL=http://127.0.0.1:8080 npm run test:integration
//
// Needs the identity keys of the demo roster (RUN_DIR/net/keys or KEYS_DIR). Every test creates its own
// fresh SKU, so the suite can be re-run against the same network.
import { describe, expect, it } from "vitest";
import {
  AdapterRunner,
  ChainEventSource,
  SimulatedPaymentProvider,
  outcomeOf,
  readerFromClient,
  simPayDelivery,
  type ChainEvent,
  type Sale,
  type WebhookInbound,
} from "../src/index.js";
import { connect } from "../scripts/runtime.js";
import { freshSku } from "../examples/_fixture.js";
import { MemoryStateStore } from "../terminal/state.js";
import { Terminal } from "../terminal/terminal.js";
import { Signer } from "../src/index.js";

const live = process.env["GATEWAY_URL"] !== undefined;
const IDS = ["catalog-mgr", "pricing-mgr", "buyer-hq", "manager-n01", "cashier-n01", "term-n01-1", "term-n01-2", "payment-adapter-1"];

describe.skipIf(!live)("live gateway", { timeout: 90_000 }, () => {
  it("network, chain info and projection status answer", async () => {
    const rt = await connect({ identities: [] });
    const n = await rt.client.network();
    expect(n.network_id).toBe(rt.env.networkId);
    expect(n.bft.status).toBe("HEALTHY");
    const info = await rt.client.chainInfo();
    expect(info.height).toBeGreaterThan(0);
    expect((await rt.client.projectionStatus()).state).toBeDefined();
  });

  it("submit with wait=indexed gives read-after-write; the record verifies against an ICS23 proof and the light-client header", async () => {
    const rt = await connect({ identities: IDS });
    const id = Date.now().toString(36).toUpperCase();
    const r = await rt.send("catalog-mgr", "CreateProduct", { product_id: `P-IT-${id}`, name: `IT ${id}`, variants: [{ sku_id: `IT-${id}`, unit: "EA" }] }, { wait: "indexed" });
    expect(r.outcome.status).toBe("FINALISED_OK");
    const h = r.outcome.status === "FINALISED_OK" ? r.outcome.height : 0;
    const p = await rt.client.q.product(`P-IT-${id}`, { min_height: h, wait_ms: 5000 });
    expect(p.item.name).toBe(`IT ${id}`);
    const v = await rt.client.getVerifiedRecord(`product/P-IT-${id}`, { crossCheckFinality: true });
    expect(v.verdict.valid, v.verdict.reason).toBe(true);
    expect(v.finalityAgrees).toBe(true);
    const absent = await rt.client.getVerifiedRecord(`product/NOPE-${id}`);
    expect(absent.record.found).toBe(false);
    expect(absent.verdict).toMatchObject({ valid: true, kind: "non-membership" });
  });

  it("duplicates: a re-sent identical tx is a duplicate; a new tx reusing the idempotency_ref is refused at admission", async () => {
    const rt = await connect({ identities: IDS });
    const { sku } = await freshSku(rt, "ITD", 2);
    const b = await rt.builder("cashier-n01");
    const tx = await b.build("ReserveStock", { reservation_id: `RES-${sku}`, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 60_000 }, { idempotencyRef: `it:${sku}` });
    expect(outcomeOf((await rt.client.submit(tx)))).toMatchObject({ status: "FINALISED_OK" });
    const again = await rt.client.submit(tx);
    expect(again.duplicate).toBe(true);
    const reuse = await b.build("ReserveStock", { reservation_id: `RES2-${sku}`, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 60_000 }, { idempotencyRef: `it:${sku}` });
    expect(outcomeOf(await rt.client.submit(reuse))).toMatchObject({ status: "ADMISSION_REJECTED", codeName: "DUPLICATE_IDEMPOTENCY" });
  });

  it("two terminals race for the last unit: exactly one wins, the other is INSUFFICIENT", async () => {
    const rt = await connect({ identities: IDS });
    const { sku } = await freshSku(rt, "ITR", 1);
    const mk = async (t: string) => (await rt.builder(t)).build("ReserveStock", { reservation_id: `RES-${sku}-${t.slice(-1)}`, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 60_000, terminal_id: t });
    const [a, b] = await Promise.all([mk("term-n01-1"), mk("term-n01-2")]);
    const res = await Promise.all([a, b].map((tx) => rt.submitSigned(tx, { allowReject: true })));
    const statuses = res.map((r) => r.outcome.status).sort();
    expect(statuses).toEqual(["FINALISED_OK", "FINALISED_REJECTED"]);
    const loser = res.find((r) => r.outcome.status === "FINALISED_REJECTED")!.outcome;
    expect(loser).toMatchObject({ codeName: "INSUFFICIENT" });
  });

  it("offline terminal: scarce refused, allowance and non-scarce sales queue UNFINALISED, sync splits ACCEPTED / REJECTED", async () => {
    const rt = await connect({ identities: IDS });
    const ok = await freshSku(rt, "ITT", 5, 400);
    const last = await freshSku(rt, "ITL", 1, 900);
    const scarceId = Date.now().toString(36).toUpperCase();
    await rt.send("catalog-mgr", "CreateProduct", { product_id: `P-ITS-${scarceId}`, name: "scarce", variants: [{ sku_id: `ITS-${scarceId}`, unit: "EA", scarce: true }] });
    await rt.send("pricing-mgr", "PublishPrice", { price_id: `PR-ITS-${scarceId}`, sku: `ITS-${scarceId}`, location_id: "*", currency: "GBP", unit_minor: 5000, effective_from_ms: Date.now() - 3600_000 });
    await rt.send("manager-n01", "ReceiveGoods", { receipt_id: `RCPT-ITS-${scarceId}`, location_id: "STORE-N-01", supplier_id: `SUP-${ok.sku}`, effective_at_ms: Date.now(), lines: [{ sku: `ITS-${scarceId}`, qty: { v: 3, unit: "EA" } }] });

    const term = await Terminal.open({ store: new MemoryStateStore(), gateway: rt.client, signer: await Signer.forIdentity(rt.keys, "term-n01-1"), networkId: rt.env.networkId, locationId: "STORE-N-01" });
    await term.refresh([ok.sku, last.sku, `ITS-${scarceId}`]);
    await term.requestAllowance(`ITS-${scarceId}`, 2);
    await term.goOffline();
    await expect(term.sell([{ sku: `ITS-${scarceId}`, qty: 3 }])).rejects.toThrow(/online finality required for scarce items/);
    const s1 = await term.sell([{ sku: `ITS-${scarceId}`, qty: 1 }, { sku: ok.sku, qty: 2 }], { customerId: "CUST-DEMO01" });
    const s2 = await term.sell([{ sku: last.sku, qty: 1 }]);
    expect(s1.sale.status).toBe("UNFINALISED");
    // the last unit of `last.sku` is sold elsewhere while we are offline
    const other = await rt.send("cashier-n01", "ReserveStock", { reservation_id: `RES-OTHER-${last.suffix}`, location_id: "STORE-N-01", sku: last.sku, qty: { v: 1, unit: "EA" }, ttl_ms: 600_000 });
    expect(other.outcome.status).toBe("FINALISED_OK");
    const { sync } = await term.goOnline();
    expect(sync?.accepted).toBe(2);
    expect(sync?.rejected).toBe(2);
    expect(term.state.sales[s1.sale.sale_id]?.status).toBe("FINALISED");
    expect(term.state.sales[s2.sale.sale_id]?.status).toBe("REJECTED");
    expect(term.listExceptions()).toHaveLength(1);
    const chainSale = await rt.client.getRecord<Sale>(`sale/${s1.sale.sale_id}`);
    expect(chainSale.value?.lines).toHaveLength(2);
  });

  it("payment adapter: forged and stale callbacks are refused, the genuine one confirms payment, the duplicate is harmless; ChainEventSource reports the sale", async () => {
    const rt = await connect({ identities: IDS });
    const { sku, suffix } = await freshSku(rt, "ITP", 1, 1250);
    const src = new ChainEventSource({ reader: readerFromClient(rt.client), startFrom: "now" });
    const events: ChainEvent[] = [];
    src.on("sale.completed", (e) => void events.push(e));
    await src.poll();

    const resId = `RES-ITP-${suffix}`;
    const saleId = `SALE-ITP-${suffix}`;
    await rt.send("cashier-n01", "ReserveStock", { reservation_id: resId, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 300_000 });
    const sale = await rt.send("cashier-n01", "CompleteSale", { sale_id: saleId, location_id: "STORE-N-01", channel: "STORE", effective_at_ms: Date.now(), currency: "GBP", payment_method: "CARD", lines: [{ sku, qty: { v: 1, unit: "EA" }, reservation_id: resId }] }, { wait: "indexed" });
    const net = sale.outcome.status === "FINALISED_OK" ? Number(sale.outcome.data["net_minor"]) : -1;
    expect(net).toBe(1250);

    const SECRET = "integration-test-secret-0123456789";
    const runner = new AdapterRunner<WebhookInbound>({ adapter: new SimulatedPaymentProvider({ secrets: [SECRET] }), keys: rt.keys, networkId: rt.env.networkId, gateway: rt.client });
    const ev = { id: `evt_${suffix}`, type: "payment.succeeded" as const, created: Math.floor(Date.now() / 1000), data: { sale_id: saleId, reference: `ch_${suffix}`, amount: net, currency: "GBP" } };
    expect((await runner.handle(simPayDelivery("wrong-secret-0123456789", ev, Date.now()))).status).toBe("REJECTED_UNAUTHENTIC");
    expect((await runner.handle(simPayDelivery(SECRET, ev, Date.now() - 3600_000))).status).toBe("REJECTED_UNAUTHENTIC");
    expect(((await rt.client.getRecord<Sale>(`sale/${saleId}`)).value)?.payment_status).toBe("INSTRUCTED");
    expect((await runner.handle(simPayDelivery(SECRET, ev, Date.now()))).status).toBe("APPLIED");
    expect((await runner.handle(simPayDelivery(SECRET, ev, Date.now()))).status).toBe("DUPLICATE");
    const final = (await rt.client.getRecord<Sale>(`sale/${saleId}`)).value;
    expect(final?.payment_status).toBe("CONFIRMED");
    expect(final?.paid_minor).toBe(1250);
    expect(final?.payment_events).toHaveLength(1);

    await rt.client.waitIndexed(sale.outcome.status === "FINALISED_OK" ? sale.outcome.height : 0);
    await src.poll();
    expect(events.map((e) => e.payload["sale_id"])).toContain(saleId);
  });
});
