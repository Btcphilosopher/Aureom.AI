// Shared context for the demo step library: gateway runtime, persisted ids, narration helpers.

import { promises as fs } from "node:fs";
import { dirname, join } from "node:path";
import { outcomeOf, type TxOutcome, type TxStatus } from "../src/index.js";
import type { Runtime, SendResult } from "../scripts/runtime.js";
import type { TxType } from "../src/index.js";

export interface TxLogEntry {
  step: string;
  label: string;
  tx_id: string;
  type: string;
  signer: string;
  status: string;
  height?: number;
  index?: number;
  code?: number;
  code_name?: string;
  at: string;
}

/** Everything later steps need, persisted in $RUN_DIR/demo-state.json. */
export interface DemoState {
  version: 1;
  run_id: string;
  network_id: string;
  created_at: string;
  sku: string;
  location: string;
  customer_id: string;
  ids: {
    po_id?: string;
    po_line?: number;
    receipt_id?: string;
    unit?: string;
    bulk_reservation_id?: string;
    bulk_qty?: number;
    race_reservations?: { terminal: string; reservation_id: string; tx_id: string }[];
    winner?: { terminal: string; reservation_id: string; tx_id: string };
    loser?: { terminal: string; reservation_id: string; tx_id: string };
    sale_id?: string;
    sale_net_minor?: number;
    payment_event_id?: string;
    payment_ref?: string;
    loyalty_entry_id?: string;
    loyalty_points?: number;
    return_id?: string;
    refund_id?: string;
    refund_minor?: number;
    refund_event_id?: string;
    reversal_id?: string;
  };
  heights: Record<string, number>;
  txs: TxLogEntry[];
  completed: string[];
}

export function newRunId(): string {
  return Date.now().toString(36).slice(-5).toUpperCase() + Math.floor(Math.random() * 36 ** 2).toString(36).toUpperCase().padStart(2, "0");
}

export class DemoContext {
  state: DemoState;
  constructor(
    readonly rt: Runtime,
    readonly statePath: string,
    state: DemoState,
    readonly out: (line: string) => void = (l) => console.log(l),
  ) {
    this.state = state;
  }

  static defaultStatePath(runDir: string): string {
    return join(runDir, "demo-state.json");
  }

  static async open(rt: Runtime, opts: { statePath?: string; out?: (l: string) => void } = {}): Promise<DemoContext> {
    const path = opts.statePath ?? process.env["DEMO_STATE"] ?? DemoContext.defaultStatePath(rt.env.runDir);
    let state: DemoState;
    try {
      state = JSON.parse(await fs.readFile(path, "utf8")) as DemoState;
    } catch {
      state = {
        version: 1,
        run_id: newRunId(),
        network_id: rt.env.networkId,
        created_at: new Date().toISOString(),
        sku: "KETTLE-RED",
        location: "STORE-N-01",
        customer_id: "CUST-DEMO01",
        ids: {},
        heights: {},
        txs: [],
        completed: [],
      };
    }
    return new DemoContext(rt, path, state, opts.out);
  }

  async save(): Promise<void> {
    await fs.mkdir(dirname(this.statePath), { recursive: true });
    await fs.writeFile(this.statePath, JSON.stringify(this.state, null, 2));
  }

  say(line = ""): void {
    this.out(line);
  }
  heading(step: string, title: string): void {
    this.out("");
    this.out("=".repeat(78));
    this.out(`${step.toUpperCase()}  ${title}`);
    this.out("=".repeat(78));
  }
  /** Plain-language explanation of what is about to happen / what it means. */
  explain(...lines: string[]): void {
    for (const l of lines) this.out(`  ${l}`);
  }

  need<K extends keyof DemoState["ids"]>(key: K, fromStep: string): NonNullable<DemoState["ids"][K]> {
    const v = this.state.ids[key];
    if (v === undefined) throw new Error(`state has no ${String(key)}: run ${fromStep} first (state file ${this.statePath})`);
    return v as NonNullable<DemoState["ids"][K]>;
  }

  /** Log a transaction (printed and persisted). */
  logTx(step: string, label: string, r: SendResult<TxType>): void {
    const o = r.outcome;
    const e: TxLogEntry = { step, label, tx_id: r.tx.txId, type: r.tx.type, signer: r.tx.signer, status: o.status, at: new Date().toISOString() };
    if (o.status === "FINALISED_OK" || o.status === "FINALISED_REJECTED") {
      e.height = o.height;
      e.index = o.index;
      e.code = o.status === "FINALISED_OK" ? 0 : o.code;
      e.code_name = o.status === "FINALISED_OK" ? "OK" : o.codeName;
    } else if (o.status === "ADMISSION_REJECTED") {
      e.code = o.code;
      e.code_name = o.codeName;
    }
    this.state.txs.push(e);
    this.out(`  - ${label}`);
    this.out(`      ${r.tx.type} signed by ${r.tx.signer} (key ${r.tx.keyId})   tx_id ${r.tx.txId}`);
    this.out(`      ${describe(o)}`);
    if (o.status === "FINALISED_OK" && Object.keys(o.data).length > 0) this.out(`      result data: ${JSON.stringify(o.data)}`);
    if (o.status === "FINALISED_OK") this.state.heights[`${step}:${label}`] = o.height;
  }

  logStatus(step: string, label: string, signer: string, type: string, s: TxStatus): void {
    this.state.txs.push({
      step,
      label,
      tx_id: s.tx_id,
      type,
      signer,
      status: s.status,
      ...(s.height !== undefined ? { height: s.height } : {}),
      ...(s.index !== undefined ? { index: s.index } : {}),
      ...(s.code !== undefined ? { code: s.code } : {}),
      ...(s.code_name !== undefined ? { code_name: s.code_name } : {}),
      at: new Date().toISOString(),
    });
  }
}

export function describe(o: TxOutcome): string {
  switch (o.status) {
    case "FINALISED_OK":
      return `FINALISED OK at height ${o.height} (block index ${o.index}), result code 0 OK${o.indexed ? ", indexed in the projection" : ""}`;
    case "FINALISED_REJECTED":
      return `ORDERED at height ${o.height} but REJECTED: ${o.codeName} (code ${o.code}) - ${o.log}. No state change.`;
    case "ADMISSION_REJECTED":
      return `REJECTED at admission (never ordered): ${o.codeName} (code ${o.code}) - ${o.log}`;
    case "ADMITTED_NOT_FINAL":
      return "admitted to the mempool; finality not yet observed";
  }
}

export { outcomeOf };
