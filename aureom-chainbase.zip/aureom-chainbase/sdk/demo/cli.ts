#!/usr/bin/env -S npx tsx
// Demo step library CLI.   npm run demo -- <step> [--run-dir DIR] [--gateway URL] [--state FILE]
import { parseArgs } from "node:util";
import { promises as fs } from "node:fs";
import { TxRejectedError } from "../src/index.js";
import { connect } from "../scripts/runtime.js";
import { DemoContext } from "./context.js";
import { STEPS, runStep } from "./steps.js";

const IDENTITIES = ["manager-n01", "cashier-n01", "term-n01-1", "term-n01-2", "payment-adapter-1", "loyalty-op", "finance-ctrl"];
const USAGE = `AUREOM CHAINBASE demo steps 2-10 (against a running network + gateway)

usage: npm run demo -- <step|all|status|reset> [--run-dir DIR] [--gateway URL] [--state FILE]

steps:  ${Object.keys(STEPS).join("\n        ")}
other:  all      run step2 .. step10 in order
        status   show the persisted ids and the transaction log
        reset    forget the persisted ids (chain state is NOT touched; the next run uses fresh ids)

environment: RUN_DIR (default <repo>/run), GATEWAY_URL (default http://127.0.0.1:8080), DEMO_STATE
state file: $RUN_DIR/demo-state.json
`;

const { values, positionals } = parseArgs({ allowPositionals: true, options: { "run-dir": { type: "string" }, gateway: { type: "string" }, state: { type: "string" }, help: { type: "boolean", short: "h" } } });
const cmd = positionals[0];
if (!cmd || values.help) {
  console.log(USAGE);
  process.exit(cmd ? 0 : 2);
}

const rt = await connect({ identities: IDENTITIES, ...(values["run-dir"] ? { runDir: values["run-dir"] } : {}), ...(values.gateway ? { gatewayUrl: values.gateway } : {}) });
const statePath = values.state ?? process.env["DEMO_STATE"] ?? DemoContext.defaultStatePath(rt.env.runDir);

try {
  if (cmd === "reset") {
    await fs.rm(statePath, { force: true });
    console.log(`removed ${statePath}`);
  } else {
    const ctx = await DemoContext.open(rt, { statePath });
    if (cmd === "status") {
      console.log(JSON.stringify({ run_id: ctx.state.run_id, completed: ctx.state.completed, ids: ctx.state.ids }, null, 2));
      for (const t of ctx.state.txs) console.log(`${t.step.padEnd(7)} ${t.type.padEnd(22)} ${t.signer.padEnd(18)} ${String(t.status).padEnd(20)} h=${t.height ?? "-"} ${t.code_name ?? ""} ${t.tx_id}`);
    } else {
      const names = cmd === "all" ? Object.keys(STEPS) : [cmd];
      for (const n of names) await runStep(ctx, n);
    }
  }
} catch (e) {
  if (e instanceof TxRejectedError) process.exit(3);
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
}
