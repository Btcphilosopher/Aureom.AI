// Demo steps 2-10 of the complete demonstration, against a running network + gateway.
// (Step 1 and steps 11-13 are done by other tools.) Each step narrates in plain language, prints
// tx ids / finalised heights / result codes, and persists the ids later steps need.

import { Client, TxRejectedError, outcomeOf, type PurchaseOrder, type Sale, type TxPayloadMap } from "../src/index.js";
import { DemoContext, describe } from "./context.js";

export interface StepResult {
  step: string;
  ok: boolean;
}

const SIGNERS = {
  receiver: "manager-n01",
  cashier: "cashier-n01",
  manager: "manager-n01",
  terminals: ["term-n01-1", "term-n01-2"] as const,
  payment: "payment-adapter-1",
  loyalty: "loyalty-op",
  reverser: "finance-ctrl",
};

const money = (minor: number | undefined, ccy = "GBP") => (minor === undefined ? "-" : `${ccy} ${(minor / 100).toFixed(2)} (${minor} minor units)`);

async function nextBlock(client: Client, timeoutMs = 3000): Promise<number> {
  const start = (await client.chainInfo()).height;
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    await new Promise((r) => setTimeout(r, 25));
    const h = (await client.chainInfo()).height;
    if (h > start || Date.now() > deadline) return h;
  }
}

async function balances(client: Client, sku: string, loc: string): Promise<string> {
  const inv = await client.inventory({ sku, location: loc });
  const b = inv.balances.find((x) => x.loc === loc);
  return b ? `available ${b.available}, reserved ${b.reserved}, quarantined ${b.quarantined}, damaged ${b.damaged}, on hand ${b.on_hand}` : "no balance row";
}

async function availableOf(client: Client, sku: string, loc: string): Promise<number> {
  const inv = await client.inventory({ sku, location: loc });
  return inv.balances.find((x) => x.loc === loc)?.available ?? 0;
}

async function readSale(client: Client, saleId: string, minHeight?: number): Promise<{ sale: Sale; via: string }> {
  if (minHeight !== undefined) {
    try {
      const r = await client.readAfterWrite(minHeight, () => client.q.sale(saleId, { min_height: minHeight, wait_ms: 3000 }), { timeoutMs: 10_000 });
      return { sale: r.item, via: `projection (indexed_height ${r.meta.indexed_height}, chain head ${r.meta.chain_head})` };
    } catch {
      /* fall back to the authoritative record below */
    }
  }
  const rec = await client.getRecord<Sale>(`sale/${saleId}`);
  if (!rec.found || !rec.value) throw new Error(`sale ${saleId} not found on chain`);
  return { sale: rec.value, via: `authoritative chain state at height ${rec.height}` };
}

function printPricing(ctx: DemoContext, sale: Sale): void {
  ctx.say("  Line pricing explanation (computed deterministically by the state machine from the price book and promotions in force at the sale's effective time):");
  for (const l of sale.lines) {
    ctx.say(`    line ${l.line_no}: ${l.qty.v} ${l.qty.unit} x ${l.sku}`);
    ctx.say(`      price book entry ${l.price_id} (version ${l.price_version}): unit price ${money(l.unit_minor)} -> gross ${money(l.gross_minor)}`);
    if (l.pricing_steps.length === 0) ctx.say("      no promotion applied");
    for (const s of l.pricing_steps) ctx.say(`      promotion ${s.promo_id} v${s.promo_version} (${s.type}): ${s.before_minor} - ${s.discount_minor} = ${s.after_minor}   \"${s.explain}\"`);
    ctx.say(`      line net ${money(l.net_minor)}`);
  }
  ctx.say(`  Sale totals: gross ${money(sale.gross_minor)}, discount ${money(sale.discount_minor)}, NET ${money(sale.net_minor)}`);
}

async function done(ctx: DemoContext, step: string, next: string | undefined): Promise<StepResult> {
  if (!ctx.state.completed.includes(step)) ctx.state.completed.push(step);
  await ctx.save();
  ctx.say("");
  ctx.say(next ? `  done. Next: npm run demo -- ${next}` : "  done.");
  return { step, ok: true };
}

// ---------------------------------------------------------------------------------------------
// Step 2: goods receipt against the migrated purchase order
// ---------------------------------------------------------------------------------------------

async function findOpenPo(client: Client, sku: string, preferred: string): Promise<{ po: PurchaseOrder; via: string }> {
  const open = (po: PurchaseOrder) => (po.status === "APPROVED" || po.status === "PARTIALLY_RECEIVED") && po.lines.some((l) => l.sku === sku && l.qty.v - l.received_v > 0);
  try {
    const found: PurchaseOrder[] = [];
    for (const status of ["APPROVED", "PARTIALLY_RECEIVED"]) {
      // note: the gateway's purchase-orders endpoint filters status/supplier/location only, so the SKU test is done here
      const page = await client.q.purchaseOrders({ status, limit: 500 });
      found.push(...page.items.filter(open));
    }
    found.sort((a, b) => Number(b.id === preferred) - Number(a.id === preferred) || a.ordered_at_ms - b.ordered_at_ms);
    const first = found[0];
    if (first) return { po: first, via: "query projection (disposable, may lag the chain)" };
  } catch {
    /* projection unavailable: read the authoritative record directly */
  }
  const rec = await client.getRecord<PurchaseOrder>(`po/${preferred}`);
  if (rec.found && rec.value && open(rec.value)) return { po: rec.value, via: `authoritative chain state at height ${rec.height}` };
  throw new Error(`no open approved purchase order with outstanding ${sku} found (looked for ${preferred})`);
}

export async function step2Receive(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  const { sku, location } = ctx.state;
  ctx.heading("step 2", `Goods receipt: one more ${sku} arrives at ${location}`);
  ctx.explain(
    "A purchase order for the scarce kettle was migrated from the legacy ERP and is approved. The store manager receives one unit against it.",
    "Receiving goods is the ONLY way stock enters a store: it posts a ledger movement EXT:SUPPLIER -> store (available).",
  );
  const { po, via } = await findOpenPo(client, sku, "PO-2001");
  const line = po.lines.find((l) => l.sku === sku && l.qty.v - l.received_v > 0);
  if (!line) throw new Error("PO has no outstanding line");
  ctx.say(`  Found open PO ${po.id} (${po.status}, supplier ${po.supplier_id}, delivers to ${po.location_id}) via ${via}`);
  ctx.say(`  Line ${line.line_no}: ${line.qty.v} ${line.qty.unit} ${sku}, received so far ${line.received_v}, outstanding ${line.qty.v - line.received_v}`);
  if (po.location_id !== location) throw new Error(`PO ${po.id} delivers to ${po.location_id}, not ${location}`);
  ctx.say(`  Stock at ${location} BEFORE: ${await balances(client, sku, location)}`);

  const receiptId = `RCPT-DEMO-${ctx.state.run_id}`;
  const r = await ctx.rt.send(SIGNERS.receiver, "ReceiveGoods", { receipt_id: receiptId, location_id: location, po_id: po.id, effective_at_ms: Date.now(), lines: [{ sku, qty: { v: 1, unit: line.qty.unit }, po_line: line.line_no }] }, { wait: "indexed" });
  ctx.logTx("step2", "receive 1 unit against the purchase order", r);
  if (r.outcome.status !== "FINALISED_OK") throw new Error("receipt not finalised");
  ctx.say(`  Stock at ${location} AFTER (authoritative chain state): ${await balances(client, sku, location)}`);
  const proj = await client.readAfterWrite(r.outcome.height, () => client.q.inventory({ sku, location, min_height: r.outcome.status === "FINALISED_OK" ? r.outcome.height : 0, wait_ms: 3000 }));
  const row = proj.items[0];
  ctx.say(`  Same read from the query projection (read-after-write at height ${r.outcome.height}, indexed ${proj.meta.indexed_height}): available ${row?.available ?? "?"}`);

  Object.assign(ctx.state.ids, { po_id: po.id, po_line: line.line_no, receipt_id: receiptId, unit: line.qty.unit });
  ctx.state.heights["step2"] = r.outcome.height;
  await ctx.save();
  return done(ctx, "step2", "step3-compete");
}

// ---------------------------------------------------------------------------------------------
// Step 3: two terminals compete for the last unit
// ---------------------------------------------------------------------------------------------

export async function step3Compete(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  const { sku, location } = ctx.state;
  const unit = ctx.state.ids.unit ?? "EA";
  ctx.heading("step 3", `Two terminals race for the LAST ${sku} at ${location}`);
  ctx.explain(
    "First a cashier reserves every unit but one in an ordinary online reservation (stock moves available -> reserved).",
    "Then two terminals try to reserve the last unit at the same moment. There is no lock and no 'first click wins' guess:",
    "the validators agree ONE total order of transactions, and the state machine runs them one after the other.",
    "The first reservation moves the last unit; the second finds none available and is rejected - whatever the network timing.",
  );
  const avail = await availableOf(client, sku, location);
  ctx.say(`  Stock before the race: ${await balances(client, sku, location)}`);
  if (avail < 1) throw new Error(`no ${sku} available at ${location}; run step2-receive first`);
  const bulk = avail - 1;
  if (bulk > 0) {
    const ttl = Math.min(20 * 60_000, 25 * 60_000);
    const resId = `RES-DEMO-BULK-${ctx.state.run_id}`;
    const r = await ctx.rt.send(SIGNERS.cashier, "ReserveStock", { reservation_id: resId, location_id: location, sku, qty: { v: bulk, unit }, ttl_ms: ttl });
    ctx.logTx("step3", `cashier reserves ${bulk} of ${avail} units (all but one)`, r);
    ctx.state.ids.bulk_reservation_id = resId;
    ctx.state.ids.bulk_qty = bulk;
  } else {
    ctx.say("  Exactly one unit is available: nothing to pre-reserve.");
  }
  ctx.say(`  Stock now: ${await balances(client, sku, location)}`);

  // sign both competing requests first, then release them together right after a new block starts
  const entries = await Promise.all(
    SIGNERS.terminals.map(async (terminal) => {
      const resId = `RES-DEMO-${terminal.replace("term-n01-", "T")}-${ctx.state.run_id}`;
      const b = await ctx.rt.builder(terminal);
      const tx = await b.build("ReserveStock", { reservation_id: resId, location_id: location, sku, qty: { v: 1, unit }, ttl_ms: 20 * 60_000, terminal_id: terminal });
      return { terminal, resId, tx };
    }),
  );
  ctx.say(`  Both requests are signed locally by their own terminal keys (${entries.map((e) => e.terminal).join(", ")}); submitting them concurrently...`);
  const h = await nextBlock(client);
  ctx.say(`  (released right after block ${h} was committed, so both can be picked up for the next block)`);
  const results = await Promise.all(entries.map((e) => ctx.rt.submitSigned(e.tx, { wait: "final", allowReject: true })));
  results.forEach((r, i) => ctx.logTx("step3", `${entries[i]?.terminal} reserves the last unit`, r));
  const heights = results.map((r) => (r.outcome.status === "FINALISED_OK" || r.outcome.status === "FINALISED_REJECTED" ? r.outcome.height : undefined));
  if (heights[0] !== undefined && heights[0] === heights[1]) ctx.say(`  Both were ordered in the SAME block (height ${heights[0]}).`);
  else ctx.say(`  They landed in blocks ${heights.join(" and ")} (the ordering rule is the same either way).`);

  ctx.state.ids.race_reservations = entries.map((e) => ({ terminal: e.terminal, reservation_id: e.resId, tx_id: e.tx.txId }));
  await ctx.save();
  return done(ctx, "step3", "step4-outcome");
}

// ---------------------------------------------------------------------------------------------
// Step 4: who won, from chain records
// ---------------------------------------------------------------------------------------------

export async function step4Outcome(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  const { sku, location } = ctx.state;
  ctx.heading("step 4", "Outcome of the race, read back from chain records");
  ctx.explain("Everything below is read from authoritative chain state (tx/<id> and resv/<id> records), not from the submitting side.");
  const race = ctx.need("race_reservations", "step3-compete");
  const rows: { terminal: string; reservation_id: string; tx_id: string; status: string; code_name: string; height: number; index: number; reason: string; resv: string }[] = [];
  for (const e of race) {
    const t = await client.getRecord<{ status: string; code_name: string; height: number; index: number; reason?: string }>(`tx/${e.tx_id}`);
    const rv = await client.getRecord<{ status: string; qty: number }>(`resv/${e.reservation_id}`);
    if (!t.found || !t.value) throw new Error(`tx ${e.tx_id} is not on chain yet`);
    rows.push({ ...e, status: t.value.status, code_name: t.value.code_name, height: t.value.height, index: t.value.index, reason: t.value.reason ?? "", resv: rv.found ? `${rv.value?.status} qty ${rv.value?.qty}` : "no reservation record (nothing changed)" });
  }
  for (const r of rows) {
    const verdict = r.status === "OK" ? "FINALISED  (WINNER)" : "REJECTED   (LOSER) ";
    ctx.say(`  ${verdict} ${r.terminal}: reservation ${r.reservation_id}`);
    ctx.say(`      tx ${r.tx_id}  height ${r.height}, index ${r.index} in block   result ${r.code_name}`);
    ctx.say(`      reservation record: ${r.resv}${r.reason ? `   reason: ${r.reason}` : ""}`);
  }
  const winner = rows.find((r) => r.status === "OK");
  const loser = rows.find((r) => r.status !== "OK");
  if (!winner) throw new Error("neither reservation succeeded (the stock was taken before the race): reset the demo state and run step2-receive again");
  ctx.state.ids.winner = { terminal: winner.terminal, reservation_id: winner.reservation_id, tx_id: winner.tx_id };
  if (loser) ctx.state.ids.loser = { terminal: loser.terminal, reservation_id: loser.reservation_id, tx_id: loser.tx_id };
  ctx.say("");
  if (rows.length === 2 && rows[0]!.height === rows[1]!.height) {
    ctx.say(`  Same block ${winner.height}: the winner had index ${winner.index}, the loser ${loser?.index}. Order within the block is part of the agreed block, so every validator reached the same result.`);
  }
  if (loser) ctx.say(`  Why the loser failed: ${loser.code_name} - a rejected transaction is still recorded (tx/${loser.tx_id} = REJECTED with the reason) but changes no stock.`);
  ctx.say(`  Stock now: ${await balances(client, sku, location)}`);

  // proof for the winning reservation: independently checkable evidence
  try {
    const v = await client.getVerifiedRecord(`resv/${winner.reservation_id}`);
    ctx.say(`  Merkle proof check (ICS23) of the winning reservation record, verified locally by this SDK: ${v.verdict.valid ? "VALID" : "INVALID"}`);
    ctx.say(`      ${v.verdict.statement}`);
    ctx.say("      (a proof shows the record is committed in that state root; it does not by itself show the business was right)");
  } catch (e) {
    ctx.say(`  (proof check skipped: ${e instanceof Error ? e.message : String(e)})`);
  }
  await ctx.save();
  return done(ctx, "step4", "step5-sale");
}

// ---------------------------------------------------------------------------------------------
// Step 5: complete the sale with the winning reservation
// ---------------------------------------------------------------------------------------------

export async function step5Sale(ctx: DemoContext): Promise<StepResult> {
  const { sku, location, customer_id } = ctx.state;
  const unit = ctx.state.ids.unit ?? "EA";
  ctx.heading("step 5", `The winning terminal completes the sale to ${customer_id}`);
  const w = ctx.need("winner", "step4-outcome");
  ctx.explain(
    `${w.terminal} turns its reservation into a sale. The terminal sends only WHAT was sold (sku, quantity, reservation) - never a price.`,
    "The state machine prices the line itself and records every step, so two validators can never disagree about a total.",
  );
  const saleId = `SALE-DEMO-${ctx.state.run_id}`;
  const payload: TxPayloadMap["CompleteSale"] = {
    sale_id: saleId,
    location_id: location,
    channel: "STORE",
    terminal_id: w.terminal,
    customer_id,
    effective_at_ms: Date.now(),
    currency: "GBP",
    payment_method: "CARD",
    lines: [{ sku, qty: { v: 1, unit }, reservation_id: w.reservation_id }],
  };
  const r = await ctx.rt.send(w.terminal, "CompleteSale", payload, { wait: "indexed" });
  ctx.logTx("step5", `complete sale ${saleId} with reservation ${w.reservation_id}`, r);
  if (r.outcome.status !== "FINALISED_OK") throw new Error("sale not finalised");
  const { sale, via } = await readSale(ctx.rt.client, saleId, r.outcome.height);
  ctx.say(`  Sale record read from ${via}:`);
  printPricing(ctx, sale);
  ctx.say(`  Payment status: ${sale.payment_status} (the sale INSTRUCTS payment; only the payment adapter can confirm it)`);
  ctx.say(`  Reservation ${w.reservation_id} is now consumed; stock now: ${await balances(ctx.rt.client, sku, location)}`);
  ctx.state.ids.sale_id = saleId;
  ctx.state.ids.sale_net_minor = sale.net_minor;
  ctx.state.heights["step5"] = r.outcome.height;
  await ctx.save();
  return done(ctx, "step5", "step6-payment");
}

// ---------------------------------------------------------------------------------------------
// Step 6: payment confirmation (+ duplicate callback)
// ---------------------------------------------------------------------------------------------

export async function step6Payment(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  ctx.heading("step 6", "Payment confirmed by the payment adapter, and a duplicate callback");
  const saleId = ctx.need("sale_id", "step5-sale");
  const net = ctx.need("sale_net_minor", "step5-sale");
  ctx.explain(
    "The sale only INSTRUCTED payment. The payment provider (SIMPAY) calls our adapter service back; the adapter - a registered SERVICE identity,",
    "not a human and not the terminal - records the confirmed result on chain. Providers retry callbacks, so each callback carries a unique event id.",
  );
  const eventId = `SIMPAY-EVT-${ctx.state.run_id}-1`;
  const providerRef = `SIMPAY-CHG-${ctx.state.run_id}`;
  const payload: TxPayloadMap["RecordPaymentResult"] = { sale_id: saleId, provider: "SIMPAY", event_id: eventId, provider_ref: providerRef, result: "CONFIRMED", amount_minor: net, currency: "GBP" };
  const r = await ctx.rt.send(SIGNERS.payment, "RecordPaymentResult", payload, { wait: "indexed" });
  ctx.logTx("step6", "payment CONFIRMED by SIMPAY", r);
  if (r.outcome.status !== "FINALISED_OK") throw new Error("payment not finalised");
  const before = await client.getRecord<Sale>(`sale/${saleId}`);
  ctx.say(`  Sale now: payment_status ${before.value?.payment_status}, paid ${money(before.value?.paid_minor)}, ${before.value?.payment_events?.length ?? 0} payment event(s)`);

  ctx.say("");
  ctx.say("  Duplicate callback #1: the provider re-delivers the SAME callback (same event id) and the adapter forwards it as a NEW transaction (new tx id).");
  const dup = await ctx.rt.send(SIGNERS.payment, "RecordPaymentResult", payload, { wait: "final" });
  ctx.logTx("step6", "duplicate SIMPAY callback (same event id, new tx)", dup);
  const dedup = dup.outcome.status === "FINALISED_OK" && dup.outcome.data["deduplicated"] === true;
  const after = await client.getRecord<Sale>(`sale/${saleId}`);
  ctx.say(`  -> ${dedup ? "DEDUPLICATED: accepted as a no-op (result data says deduplicated:true), no state change." : "NOT deduplicated (unexpected)."}`);
  ctx.say(`     Sale still shows paid ${money(after.value?.paid_minor)} and ${after.value?.payment_events?.length ?? 0} payment event(s) - the customer was NOT charged twice on the ledger.`);

  ctx.say("");
  ctx.say("  Duplicate #2: the exact same signed transaction is submitted again (a network retry).");
  const replay = await ctx.rt.submitSigned(r.tx, { wait: "final", allowReject: true });
  if (replay.response.duplicate) ctx.say("      the network already holds this exact transaction (\"tx already exists in cache\"): it was NOT executed again.");
  else ctx.say(`      ${describe(outcomeOf(replay.response))}`);
  ctx.say("      (transaction ids are single-use: a replay is stopped before execution - by the mempool cache, or later by REPLAY (210) at admission)");
  ctx.state.ids.payment_event_id = eventId;
  ctx.state.ids.payment_ref = providerRef;
  await ctx.save();
  return done(ctx, "step6", "step7-loyalty");
}

// ---------------------------------------------------------------------------------------------
// Step 7: loyalty points
// ---------------------------------------------------------------------------------------------

export async function step7Loyalty(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  ctx.heading("step 7", "Loyalty points credited (only on CONFIRMED payment)");
  const saleId = ctx.need("sale_id", "step5-sale");
  ctx.explain(
    "Points are credited by the loyalty operator, once per sale, and only after payment is confirmed (an instruction is not money).",
    "The rule is versioned inside the state machine: points = whole currency units of the net total x the points-per-unit of the active rules version.",
  );
  const entryId = `LOYE-DEMO-${ctx.state.run_id}`;
  const r = await ctx.rt.send(SIGNERS.loyalty, "CreditLoyalty", { entry_id: entryId, customer_id: ctx.state.customer_id, sale_id: saleId }, { wait: "indexed" });
  ctx.logTx("step7", `credit loyalty points for sale ${saleId}`, r);
  if (r.outcome.status !== "FINALISED_OK") throw new Error("credit not finalised");
  const acct = await client.readAfterWrite(r.outcome.height, () => client.q.loyaltyAccount(ctx.state.customer_id, { min_height: r.outcome.status === "FINALISED_OK" ? r.outcome.height : 0, wait_ms: 3000 }));
  ctx.say(`  Account ${ctx.state.customer_id} (from the projection at height ${acct.meta.indexed_height}): ${acct.item.points} points, lifetime earned ${acct.item.lifetime_earned}`);
  ctx.state.ids.loyalty_entry_id = entryId;
  ctx.state.ids.loyalty_points = Number(r.outcome.data["points"] ?? 0);
  await ctx.save();
  return done(ctx, "step7", "step8-return");
}

// ---------------------------------------------------------------------------------------------
// Step 8: return
// ---------------------------------------------------------------------------------------------

export async function step8Return(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  const { sku, location } = ctx.state;
  ctx.heading("step 8", "The customer returns the kettle: request, approval, inspection");
  const saleId = ctx.need("sale_id", "step5-sale");
  ctx.explain(
    "Three different people/roles are involved - on purpose. The cashier REQUESTS, the manager APPROVES (separation of duties: nobody approves their own request),",
    "and the manager records the physical inspection. Only the inspection moves stock (RESELLABLE -> back to available) and instructs the refund.",
  );
  const returnId = `RET-DEMO-${ctx.state.run_id}`;
  const req = await ctx.rt.send(SIGNERS.cashier, "RequestReturn", { return_id: returnId, sale_id: saleId, lines: [{ line_no: 1, qty_v: 1, reason: "changed mind" }] });
  ctx.logTx("step8", "cashier requests the return", req);
  const apr = await ctx.rt.send(SIGNERS.manager, "ApproveReturn", { return_id: returnId, decision: "APPROVE" });
  ctx.logTx("step8", "manager approves the return", apr);
  ctx.say(`  Stock before inspection: ${await balances(client, sku, location)}`);
  const rec = await ctx.rt.send(SIGNERS.manager, "ReceiveReturnedGoods", { return_id: returnId, lines: [{ line_no: 1, qty_v: 1, inspection: "RESELLABLE" }] }, { wait: "indexed" });
  ctx.logTx("step8", "manager inspects: RESELLABLE", rec);
  if (rec.outcome.status !== "FINALISED_OK") throw new Error("inspection not finalised");
  const refundId = String(rec.outcome.data["refund_id"] ?? "");
  const refundMinor = Number(rec.outcome.data["refund_instructed_minor"] ?? 0);
  ctx.say(`  Refund INSTRUCTED: ${refundId} for ${money(refundMinor)} (pro-rata of the line net, half-even rounding; the chain does not move money)`);
  ctx.say(`  Stock after inspection: ${await balances(client, sku, location)}`);
  ctx.state.ids.return_id = returnId;
  ctx.state.ids.refund_id = refundId;
  ctx.state.ids.refund_minor = refundMinor;
  await ctx.save();
  return done(ctx, "step8", "step9-refund");
}

// ---------------------------------------------------------------------------------------------
// Step 9: refund confirmed
// ---------------------------------------------------------------------------------------------

export async function step9Refund(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  ctx.heading("step 9", "Refund confirmed by the payment adapter");
  const refundId = ctx.need("refund_id", "step8-return");
  const amount = ctx.need("refund_minor", "step8-return");
  const saleId = ctx.need("sale_id", "step5-sale");
  ctx.explain("The chain recorded the refund INSTRUCTION. Only when the provider reports the money actually went back does the adapter record CONFIRMED.");
  const eventId = `SIMPAY-RFD-${ctx.state.run_id}-1`;
  const r = await ctx.rt.send(SIGNERS.payment, "RecordRefundResult", { refund_id: refundId, provider: "SIMPAY", event_id: eventId, provider_ref: `SIMPAY-RFD-REF-${ctx.state.run_id}`, result: "CONFIRMED", amount_minor: amount }, { wait: "indexed" });
  ctx.logTx("step9", `refund ${refundId} CONFIRMED by SIMPAY`, r);
  const sale = await client.getRecord<Sale>(`sale/${saleId}`);
  ctx.say(`  Sale ${saleId}: paid ${money(sale.value?.paid_minor)}, refund instructed ${money(sale.value?.refund_instructed_minor)}, refund confirmed ${money(sale.value?.refund_confirmed_minor)}, fulfilment ${sale.value?.fulfilment_status}`);
  ctx.state.ids.refund_event_id = eventId;
  await ctx.save();
  return done(ctx, "step9", "step10-loyalty-reverse");
}

// ---------------------------------------------------------------------------------------------
// Step 10: reverse the loyalty points
// ---------------------------------------------------------------------------------------------

export async function step10LoyaltyReverse(ctx: DemoContext): Promise<StepResult> {
  const { client } = ctx.rt;
  ctx.heading("step 10", "Loyalty points reversed because the money was refunded");
  const entryId = ctx.need("loyalty_entry_id", "step7-loyalty");
  const refundId = ctx.need("refund_id", "step8-return");
  ctx.explain(
    "Nothing is ever edited in place: the original EARN entry stays, and a linked REVERSE entry is added. Because the points are proportional to the money refunded,",
    "the chain derives the amount from the CONFIRMED refund (a refund that is only instructed would be refused).",
  );
  const reversalId = `REV-DEMO-${ctx.state.run_id}`;
  const r = await ctx.rt.send(SIGNERS.reverser, "ReverseBusinessEntry", { reversal_id: reversalId, target_type: "LOYALTY_ENTRY", target_id: entryId, reason: "goods returned and refunded", refund_id: refundId }, { wait: "indexed" });
  ctx.logTx("step10", `reverse loyalty entry ${entryId}`, r);
  if (r.outcome.status !== "FINALISED_OK") throw new Error("reversal not finalised");
  const acct = await client.readAfterWrite(r.outcome.height, () => client.q.loyaltyAccount(ctx.state.customer_id, { min_height: r.outcome.status === "FINALISED_OK" ? r.outcome.height : 0, wait_ms: 3000 }));
  ctx.say(`  Account ${ctx.state.customer_id} now: ${acct.item.points} points (lifetime earned ${acct.item.lifetime_earned}); points reversed ${r.outcome.data["points_reversed"] ?? "?"}`);
  const hist = await client.q.history({ key: `loye/${entryId}`, min_height: r.outcome.height, wait_ms: 3000 }).catch(() => undefined);
  if (hist) ctx.say(`  Audit history of loyalty entry ${entryId}: ${hist.items.length} version(s) (the original EARN is still there; reversed_points was incremented)`);
  ctx.state.ids.reversal_id = reversalId;
  await ctx.save();
  return done(ctx, "step10", undefined);
}

export const STEPS: Record<string, (ctx: DemoContext) => Promise<StepResult>> = {
  "step2-receive": step2Receive,
  "step3-compete": step3Compete,
  "step4-outcome": step4Outcome,
  "step5-sale": step5Sale,
  "step6-payment": step6Payment,
  "step7-loyalty": step7Loyalty,
  "step8-return": step8Return,
  "step9-refund": step9Refund,
  "step10-loyalty-reverse": step10LoyaltyReverse,
};

export async function runStep(ctx: DemoContext, name: string): Promise<StepResult> {
  const fn = STEPS[name];
  if (!fn) throw new Error(`unknown step ${name}; known: ${Object.keys(STEPS).join(", ")}`);
  try {
    return await fn(ctx);
  } catch (e) {
    await ctx.save();
    if (e instanceof TxRejectedError) {
      ctx.say("");
      ctx.say(`  STEP FAILED: ${e.stage} rejection ${e.resultName} (${e.resultCode}) for tx ${e.txId}: ${e.message}`);
    }
    throw e;
  }
}
