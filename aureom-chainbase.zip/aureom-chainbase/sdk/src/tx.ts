// Transaction envelope, signing preimage, signing and building. Byte-compatible with the Go
// reference signer core.SignTx (chain/internal/core/tx.go):
//
//   envelope = {"v":1,"body":"<base64 body bytes>","sig":"<base64 ed25519>","pub":"<base64 pubkey>"}
//   preimage = "AUREOM-CHAINBASE/TX/v1" 0x00 <network_id> 0x00 <body bytes>
//
// The validators verify the signature over the exact body bytes carried in the envelope, so no
// cross-language JSON canonicalisation is needed; we merely emit the same field order as Go.

import { sha256 } from "@noble/hashes/sha2.js";
import { ed25519 } from "@noble/curves/ed25519.js";
import { base64ToBytes, bytesToBase64, bytesToHex, concatBytes, fromUtf8, utf8 } from "./encoding.js";
import { ValidationError } from "./errors.js";
import { assertIdempotencyRef, assertTxId, newTxId } from "./ids.js";
import type { Signer } from "./keystore.js";
import type { TxPayloadMap, TxType } from "./payloads.js";

export const SIG_DOMAIN = "AUREOM-CHAINBASE/TX/v1";
export const SCHEMA_VERSION = 1;
export const DEFAULT_NETWORK_ID = "aureom-retail-demo-1";

export interface Envelope {
  v: 1;
  /** base64 of the exact body bytes that were signed. */
  body: string;
  /** base64 Ed25519 signature over the preimage. */
  sig: string;
  /** base64 Ed25519 public key that made the signature. */
  pub: string;
}

export interface TxBody<T extends TxType = TxType> {
  tx_id: string;
  network_id: string;
  type: T;
  schema_version: number;
  signer: string;
  key_id: string;
  idempotency_ref: string;
  expected_version?: number;
  client_time_ms: number;
  valid_until_height?: number;
  payload: TxPayloadMap[T];
}

export interface SignedTx<T extends TxType = TxType> {
  type: T;
  txId: string;
  signer: string;
  keyId: string;
  idempotencyRef: string;
  body: TxBody<T>;
  /** The exact bytes that were signed (the `body` of the envelope, decoded). */
  bodyBytes: Uint8Array;
  envelope: Envelope;
  /** Envelope JSON as a string (what is POSTed / broadcast). */
  json: string;
  /** Envelope JSON as UTF-8 bytes (what validators receive; hashed for the CometBFT tx hash). */
  bytes: Uint8Array;
  /** Upper-case hex SHA-256 of `bytes` = CometBFT tx hash. */
  txHash: string;
}

/** Signature preimage: domain 0x00 network_id 0x00 body. */
export function preimage(networkId: string, bodyBytes: Uint8Array): Uint8Array {
  return concatBytes(utf8(SIG_DOMAIN), Uint8Array.of(0), utf8(networkId), Uint8Array.of(0), bodyBytes);
}

/** Reject payloads that JSON would silently corrupt (NaN -> null) or that the chain cannot decode (non-integers). */
export function assertWireSafe(value: unknown, path = "payload"): void {
  if (value === null || typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) throw new ValidationError(`${path}: ${value} is not a safe integer (all numeric fields are integers in minor units / smallest quantity steps)`);
    return;
  }
  if (value === undefined) return; // dropped by JSON.stringify, like Go's omitempty/zero value
  if (Array.isArray(value)) {
    value.forEach((v, i) => assertWireSafe(v, `${path}[${i}]`));
    return;
  }
  if (typeof value === "object") {
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) assertWireSafe(v, `${path}.${k}`);
    return;
  }
  throw new ValidationError(`${path}: unsupported value of type ${typeof value}`);
}

function assertInt(name: string, n: number): number {
  if (!Number.isSafeInteger(n) || n < 0) throw new ValidationError(`${name} must be a non-negative safe integer`);
  return n;
}

/** Serialise a body with the same field order as Go's core.Body (omitempty on the two optional fields). */
export function encodeBody(b: TxBody): Uint8Array {
  assertTxId(b.tx_id);
  assertIdempotencyRef(b.idempotency_ref);
  assertInt("client_time_ms", b.client_time_ms);
  assertWireSafe(b.payload);
  const o: Record<string, unknown> = {
    tx_id: b.tx_id,
    network_id: b.network_id,
    type: b.type,
    schema_version: b.schema_version,
    signer: b.signer,
    key_id: b.key_id,
    idempotency_ref: b.idempotency_ref,
  };
  if (b.expected_version !== undefined) o["expected_version"] = assertInt("expected_version", b.expected_version);
  o["client_time_ms"] = b.client_time_ms;
  // Go: `valid_until_height,omitempty` on an int64 — zero is omitted.
  if (b.valid_until_height !== undefined && b.valid_until_height !== 0) o["valid_until_height"] = assertInt("valid_until_height", b.valid_until_height);
  o["payload"] = b.payload;
  return utf8(JSON.stringify(o));
}

/** Sign a fully-specified body (network_id and schema_version already set). */
export async function signBody<T extends TxType>(signer: Signer, body: TxBody<T>): Promise<SignedTx<T>> {
  if (body.signer !== signer.identity || body.key_id !== signer.keyId) {
    throw new ValidationError(`body is for ${body.signer}#${body.key_id} but the signer is ${signer.identity}#${signer.keyId}`);
  }
  const bodyBytes = encodeBody(body);
  const sig = await signer.sign(preimage(body.network_id, bodyBytes));
  const envelope: Envelope = { v: 1, body: bytesToBase64(bodyBytes), sig: bytesToBase64(sig), pub: signer.publicKeyB64 };
  const json = JSON.stringify(envelope);
  const bytes = utf8(json);
  return {
    type: body.type,
    txId: body.tx_id,
    signer: body.signer,
    keyId: body.key_id,
    idempotencyRef: body.idempotency_ref,
    body,
    bodyBytes,
    envelope,
    json,
    bytes,
    txHash: bytesToHex(sha256(bytes)).toUpperCase(),
  };
}

export interface BuildOptions {
  /** Default: a fresh unique id. */
  txId?: string;
  /** Business-level dedupe key, unique per signer. Default: derived from the tx id. */
  idempotencyRef?: string;
  /** Optimistic-concurrency pin on the record the transaction primarily changes. */
  expectedVersion?: number;
  /** Reject the tx after this block height (bounds replay windows for queued/offline requests). */
  validUntilHeight?: number;
  /** The signer's claim of local time (never trusted by the chain). Default: now. */
  clientTimeMs?: number;
}

export interface TxBuilderOptions {
  networkId: string;
  signer: Signer;
  /** Clock source (ms since epoch); injectable for tests and simulated clocks. */
  now?: () => number;
}

/** Creates and signs transactions for one signer on one network. */
export class TxBuilder {
  readonly networkId: string;
  readonly signer: Signer;
  private readonly now: () => number;

  constructor(opts: TxBuilderOptions) {
    this.networkId = opts.networkId;
    this.signer = opts.signer;
    this.now = opts.now ?? Date.now;
  }

  /** Build the body (unsigned) — useful for review or for external signing flows. */
  body<T extends TxType>(type: T, payload: TxPayloadMap[T], opts: BuildOptions = {}): TxBody<T> {
    const txId = opts.txId ?? newTxId(this.now());
    const body: TxBody<T> = {
      tx_id: txId,
      network_id: this.networkId,
      type,
      schema_version: SCHEMA_VERSION,
      signer: this.signer.identity,
      key_id: this.signer.keyId,
      idempotency_ref: opts.idempotencyRef ?? `idem-${txId}`,
      client_time_ms: opts.clientTimeMs ?? this.now(),
      payload,
    };
    if (opts.expectedVersion !== undefined) body.expected_version = opts.expectedVersion;
    if (opts.validUntilHeight !== undefined) body.valid_until_height = opts.validUntilHeight;
    return body;
  }

  /** Build and sign. */
  async build<T extends TxType>(type: T, payload: TxPayloadMap[T], opts: BuildOptions = {}): Promise<SignedTx<T>> {
    return signBody(this.signer, this.body(type, payload, opts));
  }

  /** A builder for the same network with a different signer (e.g. after key rotation). */
  withSigner(signer: Signer): TxBuilder {
    return new TxBuilder({ networkId: this.networkId, signer, now: this.now });
  }
}

/** One-shot functional form of TxBuilder.build. */
export function buildTx<T extends TxType>(
  signer: Signer,
  networkId: string,
  type: T,
  payload: TxPayloadMap[T],
  opts: BuildOptions = {},
): Promise<SignedTx<T>> {
  return new TxBuilder({ networkId, signer }).build(type, payload, opts);
}

// ---- Decoding / local verification ---------------------------------------------------------

export function parseEnvelope(input: string | Uint8Array | Envelope): Envelope {
  let o: unknown = input;
  if (typeof input === "string") o = JSON.parse(input);
  else if (input instanceof Uint8Array) o = JSON.parse(fromUtf8(input));
  const e = o as Partial<Envelope> | null;
  if (!e || e.v !== 1 || typeof e.body !== "string" || typeof e.sig !== "string" || typeof e.pub !== "string") {
    throw new ValidationError("not a v1 transaction envelope");
  }
  return { v: 1, body: e.body, sig: e.sig, pub: e.pub };
}

export interface EnvelopeCheck {
  ok: boolean;
  reason?: string;
  body?: TxBody;
  bodyBytes?: Uint8Array;
}

/** Locally verify the signature of an envelope (what validators do in stage 2) and decode its body. */
export function verifyEnvelope(input: string | Uint8Array | Envelope, networkId: string): EnvelopeCheck {
  let env: Envelope;
  try {
    env = parseEnvelope(input);
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : String(e) };
  }
  let bodyBytes: Uint8Array, sig: Uint8Array, pub: Uint8Array;
  try {
    bodyBytes = base64ToBytes(env.body);
    sig = base64ToBytes(env.sig);
    pub = base64ToBytes(env.pub);
  } catch (e) {
    return { ok: false, reason: `bad base64: ${e instanceof Error ? e.message : String(e)}` };
  }
  if (sig.length !== 64 || pub.length !== 32) return { ok: false, reason: "bad signature or key length" };
  let body: TxBody;
  try {
    body = JSON.parse(fromUtf8(bodyBytes)) as TxBody;
  } catch {
    return { ok: false, reason: "body is not JSON" };
  }
  if (body.network_id !== networkId) return { ok: false, reason: `network_id ${body.network_id} != ${networkId}`, body, bodyBytes };
  let good = false;
  try {
    good = ed25519.verify(sig, preimage(networkId, bodyBytes), pub);
  } catch {
    good = false;
  }
  return good ? { ok: true, body, bodyBytes } : { ok: false, reason: "signature does not verify", body, bodyBytes };
}

/** CometBFT transaction hash (upper-case hex SHA-256 of the envelope bytes). */
export function txHashOf(envelopeBytes: Uint8Array): string {
  return bytesToHex(sha256(envelopeBytes)).toUpperCase();
}
