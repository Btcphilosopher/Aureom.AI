// Record shapes as stored on chain (mirrors chain/internal/core/types.go; JSON field names).
// Every versioned record carries the Meta fields.

import type { Qty, GovParams } from "./payloads.js";

export interface Meta {
  version: number;
  schema_version: number;
  created_height: number;
  updated_height: number;
  created_tx: string;
  updated_tx: string;
}

export interface Provenance {
  origin: "NATIVE" | "IMPORTED";
  source_system?: string;
  source_id?: string;
  batch_id?: string;
  mapping_version?: string;
  snapshot_id?: string;
}

export interface Product extends Meta {
  id: string;
  name: string;
  brand?: string;
  category?: string;
  status: "ACTIVE" | "DISCONTINUED";
  attributes?: Record<string, string>;
  source_extras?: Record<string, string>;
  skus: string[];
  provenance: Provenance;
}

export interface Sku extends Meta {
  id: string;
  product_id: string;
  barcode?: string;
  unit: string;
  scarce: boolean;
  status: "ACTIVE" | "DISCONTINUED";
  attributes?: Record<string, string>;
  source_extras?: Record<string, string>;
  provenance: Provenance;
}

export interface Location extends Meta {
  id: string;
  name: string;
  kind: "STORE" | "WAREHOUSE";
  region: string;
  currency: string;
  status: string;
  provenance: Provenance;
}

export interface Supplier extends Meta {
  id: string;
  name: string;
  status: string;
  terms?: string;
  provenance: Provenance;
}

export interface PurchaseOrderLine {
  line_no: number;
  sku: string;
  qty: Qty;
  unit_cost_minor: number;
  received_v: number;
}

export interface PurchaseOrder extends Meta {
  id: string;
  supplier_id: string;
  location_id: string;
  currency: string;
  lines: PurchaseOrderLine[];
  total_minor: number;
  status: "DRAFT" | "APPROVED" | "PARTIALLY_RECEIVED" | "RECEIVED" | "CANCELLED";
  created_by: string;
  approved_by?: string;
  ordered_at_ms: number;
  receipts?: string[];
  provenance: Provenance;
}

export interface Balance extends Meta {
  sku: string;
  loc: string;
  available: number;
  reserved: number;
  quarantined: number;
  damaged: number;
  last_movement_seq: number;
}

/** Balance row as returned by the gateway's inventory endpoints (adds the derived on_hand). */
export interface BalanceRow {
  sku: string;
  loc: string;
  available: number;
  reserved: number;
  quarantined: number;
  damaged: number;
  on_hand: number;
  version: number;
}

export type ReservationStatus = "ACTIVE" | "RELEASED" | "CONSUMED" | "EXPIRED";

export interface Reservation extends Meta {
  id: string;
  sku: string;
  loc: string;
  /** Remaining reserved quantity (an allowance shrinks as it is consumed). */
  qty: number;
  unit: string;
  status: ReservationStatus;
  allowance: boolean;
  holder: string;
  terminal_id?: string;
  expires_at_ms: number;
  sale_id?: string;
  consumed_v: number;
}

export interface PricingStep {
  promo_id: string;
  promo_version: number;
  type: string;
  before_minor: number;
  discount_minor: number;
  after_minor: number;
  explain: string;
}

export interface SaleLine {
  line_no: number;
  sku: string;
  qty: Qty;
  reservation_id?: string;
  price_id: string;
  price_version: number;
  unit_minor: number;
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  pricing_steps: PricingStep[];
  returned_v: number;
  returning_v: number;
  refund_committed_minor: number;
}

export interface PaymentEvent {
  provider: string;
  event_id: string;
  provider_ref: string;
  result: string;
  amount_minor: number;
  tx_id: string;
  height: number;
}

export interface Sale extends Meta {
  id: string;
  loc: string;
  channel: string;
  terminal_id?: string;
  customer_id?: string;
  currency: string;
  lines: SaleLine[];
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  effective_at_ms: number;
  block_time_ms: number;
  rules_version: number;
  sale_status: string;
  payment_status: "INSTRUCTED" | "PARTIALLY_PAID" | "CONFIRMED" | "FAILED" | "OVERPAID";
  fulfilment_status: "FULFILLED" | "PARTIALLY_RETURNED" | "RETURNED";
  payment_method: string;
  paid_minor: number;
  refund_instructed_minor: number;
  refund_confirmed_minor: number;
  payment_events?: PaymentEvent[];
  loyalty_entry?: string;
  provenance: Provenance;
}

export interface ReturnLine {
  line_no: number;
  qty_v: number;
  reason: string;
  received_v: number;
  inspection?: string;
  refund_minor: number;
}

export interface Return extends Meta {
  id: string;
  sale_id: string;
  loc: string;
  lines: ReturnLine[];
  status: "REQUESTED" | "APPROVED" | "REJECTED" | "PARTIALLY_RECEIVED" | "RECEIVED";
  requested_by: string;
  decided_by?: string;
  override_reason?: string;
  refunds?: string[];
}

export interface Refund extends Meta {
  id: string;
  sale_id: string;
  return_id: string;
  amount_minor: number;
  currency: string;
  status: "INSTRUCTED" | "CONFIRMED" | "FAILED" | "DISPUTED";
  provider?: string;
  provider_ref?: string;
}

export interface LoyaltyAccount extends Meta {
  id: string;
  points: number;
  lifetime_earned: number;
  entries: number;
  status: string;
}

export interface LoyaltyEntry extends Meta {
  id: string;
  account: string;
  type: "EARN" | "REDEEM" | "EXPIRE" | "REVERSE" | "OPENING";
  points: number;
  sale_id?: string;
  refund_id?: string;
  reverses?: string;
  reversed_points: number;
  shortfall_points?: number;
  value_minor?: number;
  effective_at_ms: number;
  rule: string;
}

export interface Adjustment extends Meta {
  id: string;
  sku: string;
  loc: string;
  bucket: string;
  balance_version_at_count: number;
  system_qty: number;
  counted_qty: number;
  delta: number;
  reason: string;
  evidence_ref: string;
  status: "PENDING" | "APPROVED" | "REJECTED" | "REVERSED";
  proposer: string;
  decider?: string;
}

export interface ChainException extends Meta {
  id: string;
  kind: string;
  ref: string;
  detail: string;
  status: "OPEN" | "RESOLVED";
  resolution?: string;
  resolved_by?: string;
}

export interface KeyRecord {
  key_id: string;
  pub_b64: string;
  status: "ACTIVE" | "REVOKED" | "ROTATED";
  from_height: number;
  to_height: number;
}

export interface Identity extends Meta {
  id: string;
  org: string;
  kind: "HUMAN" | "SERVICE" | "TERMINAL";
  keys: KeyRecord[];
  status: "ACTIVE" | "SUSPENDED";
  bound_location?: string;
}

export interface TxRecord {
  id: string;
  type: string;
  signer: string;
  status: "OK" | "REJECTED";
  code: number;
  code_name: string;
  reason?: string;
  height: number;
  index: number;
  block_time_ms: number;
  client_time_ms: number;
  idempotency_ref: string;
}

/** On-chain parameter record `gov/params`. */
export type ChainParams = GovParams;
