// Gateway client (docs/API.md). Browser-safe: uses only fetch / AbortController.

import type {
  BlockSummary,
  ChainInfo,
  Digest,
  FinalityReport,
  HistoryRow,
  InventoryExceptionRow,
  InventoryResult,
  InventoryRow,
  ItemResponse,
  ListResponse,
  NetworkInfo,
  ProductView,
  ProjectionStatus,
  ProjectionVerify,
  QueryOptions,
  SaleDetail,
  SalesSummaryRow,
  ScanOptions,
  ScanResponse,
  SubmitResponse,
  TransactionRow,
  TxOutcome,
  TxStatus,
  WaitMode,
  ChainRecordOptions,
} from "./api-types.js";
import { codeName } from "./codes.js";
import { base64ToBytes, fromUtf8 } from "./encoding.js";
import { GatewayError, TimeoutError, TxRejectedError, ValidationError } from "./errors.js";
import { Http, sleep, type HttpOptions, type JsonObject, type Query } from "./http.js";
import { verifyRecordResponse, type ChainRecordResponse, type ProofVerdict } from "./proof.js";
import type { Envelope, SignedTx } from "./tx.js";
import type { Reservation, Sale, Sku, Product, Location, Supplier, PurchaseOrder, Return, Refund, LoyaltyAccount, ChainException } from "./records.js";

export const DEFAULT_GATEWAY_URL = "http://127.0.0.1:8080";

/** Record kinds understood by GET /api/v1/chain/records/{kind}/{id}. */
export const RECORD_KINDS = [
  "product", "sku", "location", "supplier", "po", "receipt", "reservation", "sale", "return", "refund", "price",
  "promotion", "loyalty", "loyalty-entry", "adjustment", "transfer", "exception", "identity", "grants", "tx", "member", "proposal",
] as const;
export type RecordKind = (typeof RECORD_KINDS)[number];

/** Typed record bodies for the kinds the SDK knows a shape for. */
export interface RecordKindMap {
  product: Product;
  sku: Sku;
  location: Location;
  supplier: Supplier;
  po: PurchaseOrder;
  reservation: Reservation;
  sale: Sale;
  return: Return;
  refund: Refund;
  loyalty: LoyaltyAccount;
  exception: ChainException;
}

export interface SubmitOptions {
  /** none = return after mempool admission; final = after the block is committed; indexed = also projection-readable. */
  wait?: WaitMode;
  /** Server-side wait budget. Default 15000. */
  timeoutMs?: number;
}

export interface ClientOptions extends Partial<HttpOptions> {
  /** Gateway base URL. Default http://127.0.0.1:8080. */
  baseUrl?: string;
}

/** What a gateway-style submit endpoint must offer; the terminal simulator depends only on this. */
export interface TxGateway {
  submit(tx: SignedTx | Envelope | string, opts?: SubmitOptions): Promise<SubmitResponse>;
  txStatus(txId: string): Promise<TxStatus>;
  getRecord<T = unknown>(key: string, opts?: ChainRecordOptions): Promise<ChainRecordResponse<T>>;
  network(): Promise<NetworkInfo>;
}

/** Collapse a submit response into one of four outcomes. */
export function outcomeOf(r: SubmitResponse): TxOutcome {
  if (r.admission.code !== 0) return { status: "ADMISSION_REJECTED", code: r.admission.code, codeName: r.admission.name || codeName(r.admission.code), log: r.admission.log };
  const f = r.finalised;
  if (!f) return { status: "ADMITTED_NOT_FINAL", admitted: true };
  if (f.code === 0) return { status: "FINALISED_OK", height: f.height, index: f.index, data: f.data ?? {}, indexed: r.indexed === true };
  return { status: "FINALISED_REJECTED", height: f.height, index: f.index, code: f.code, codeName: f.code_name || codeName(f.code), log: f.log };
}

function metaOf(tx: SignedTx | Envelope | string): { txId: string; type: string; signer: string; txHash?: string } {
  if (typeof tx === "object" && "txId" in tx) return { txId: tx.txId, type: tx.type, signer: tx.signer, txHash: tx.txHash };
  try {
    const env = typeof tx === "string" ? (JSON.parse(tx) as Envelope) : tx;
    const b = JSON.parse(fromUtf8(base64ToBytes(env.body))) as { tx_id?: string; type?: string; signer?: string };
    return { txId: b.tx_id ?? "", type: b.type ?? "", signer: b.signer ?? "" };
  } catch {
    return { txId: "", type: "", signer: "" };
  }
}

function toEnvelope(tx: SignedTx | Envelope | string): Envelope | string {
  if (typeof tx === "string") return tx;
  if ("envelope" in tx) return tx.envelope;
  return tx;
}

export class ProjectionQueries {
  constructor(private readonly http: Http) {}

  private list<T>(path: string, q?: Query): Promise<ListResponse<T>> {
    return this.http.get<ListResponse<T>>(`/api/v1/q${path}`, q);
  }
  private item<T>(path: string, q?: Query): Promise<ItemResponse<T>> {
    return this.http.get<ItemResponse<T>>(`/api/v1/q${path}`, q);
  }

  products(f: { q?: string; category?: string; status?: string } & QueryOptions = {}) {
    return this.list<ProductView>("/products", f);
  }
  product(id: string, o: QueryOptions = {}) {
    return this.item<ProductView & { price_history?: JsonObject[]; versions?: JsonObject[] }>(`/products/${encodeURIComponent(id)}`, o);
  }
  skus(f: { product?: string; q?: string; scarce?: boolean } & QueryOptions = {}) {
    return this.list<Sku>("/skus", f);
  }
  locations(f: { kind?: string; region?: string } & QueryOptions = {}) {
    return this.list<Location>("/locations", f);
  }
  suppliers(f: { kind?: string; region?: string } & QueryOptions = {}) {
    return this.list<Supplier>("/suppliers", f);
  }
  inventory(f: { sku?: string; location?: string; low_stock?: number } & QueryOptions = {}) {
    return this.list<InventoryRow>("/inventory", f);
  }
  inventoryExceptions(o: QueryOptions = {}) {
    return this.list<InventoryExceptionRow>("/inventory/exceptions", o);
  }
  movements(f: { sku?: string; location?: string; reason?: string; ref_id?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/movements", f);
  }
  purchaseOrders(f: { status?: string; supplier?: string; location?: string; sku?: string } & QueryOptions = {}) {
    return this.list<PurchaseOrder>("/purchase-orders", f);
  }
  receipts(f: { status?: string; supplier?: string; location?: string; sku?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/receipts", f);
  }
  transfers(f: { status?: string; location?: string; sku?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/transfers", f);
  }
  adjustments(f: { status?: string; location?: string; sku?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/adjustments", f);
  }
  reservations(f: { status?: string; location?: string; sku?: string } & QueryOptions = {}) {
    return this.list<Reservation>("/reservations", f);
  }
  /** `from`/`to` are epoch ms of the sale's EFFECTIVE time (a terminal claim), not block time. */
  sales(f: { from?: number; to?: number; location?: string; payment_status?: string; customer?: string } & QueryOptions = {}) {
    return this.list<Sale>("/sales", f);
  }
  sale(id: string, o: QueryOptions = {}) {
    return this.item<SaleDetail>(`/sales/${encodeURIComponent(id)}`, o);
  }
  salesSummary(f: { from?: number; to?: number; group?: "day" | "location" | "channel" } & QueryOptions = {}) {
    return this.list<SalesSummaryRow>("/sales/summary", f);
  }
  returns(f: { status?: string; sale?: string } & QueryOptions = {}) {
    return this.list<Return>("/returns", f);
  }
  refunds(f: { status?: string; sale?: string } & QueryOptions = {}) {
    return this.list<Refund>("/refunds", f);
  }
  prices(f: { sku?: string; location?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/prices", f);
  }
  promotions(f: { status?: string } & QueryOptions = {}) {
    return this.list<JsonObject>("/promotions", f);
  }
  loyaltyAccounts(f: { q?: string } & QueryOptions = {}) {
    return this.list<LoyaltyAccount>("/loyalty/accounts", f);
  }
  loyaltyAccount(id: string, o: QueryOptions = {}) {
    return this.item<LoyaltyAccount & { entries_list?: JsonObject[]; entries_detail?: JsonObject[] }>(`/loyalty/accounts/${encodeURIComponent(id)}`, o);
  }
  exceptions(f: { status?: string; kind?: string } & QueryOptions = {}) {
    return this.list<ChainException>("/exceptions", f);
  }
  transactions(f: { type?: string; signer?: string; status?: "OK" | "REJECTED"; code?: number; from_height?: number } & QueryOptions = {}) {
    return this.list<TransactionRow>("/transactions", f);
  }
  /** Audit history of a record: pass `key` (exact state key) or `kind` + `id`. */
  history(f: { key?: string; kind?: string; id?: string } & QueryOptions) {
    if (!f.key && !(f.kind && f.id)) throw new ValidationError("history needs key, or kind and id");
    return this.list<HistoryRow>("/history", f);
  }
  identities(o: QueryOptions = {}) {
    return this.list<JsonObject>("/identities", o);
  }
  governance(o: QueryOptions = {}) {
    return this.http.get<{ meta: ListResponse<unknown>["meta"] } & JsonObject>("/api/v1/q/governance", o as Query);
  }
  migration(o: QueryOptions = {}) {
    return this.http.get<{ meta: ListResponse<unknown>["meta"] } & JsonObject>("/api/v1/q/migration", o as Query);
  }
  stats(o: QueryOptions = {}) {
    return this.http.get<{ meta: ListResponse<unknown>["meta"] } & JsonObject>("/api/v1/q/stats", o as Query);
  }
}

export class ExplorerApi {
  constructor(private readonly http: Http) {}
  blocks(f: { limit?: number; before?: number } = {}) {
    return this.http.get<BlockSummary[]>("/api/v1/explorer/blocks", f);
  }
  block(height: number) {
    return this.http.get<JsonObject>(`/api/v1/explorer/block/${height}`);
  }
  tx(idOrHash: string, f: { include_proof?: boolean } = {}) {
    return this.http.get<JsonObject>(`/api/v1/explorer/tx/${encodeURIComponent(idOrHash)}`, { include_proof: f.include_proof ? 1 : undefined });
  }
  /** Light-client check of a block's commit (gateway-asserted; see docs/API.md). */
  verifyFinality(height: number) {
    return this.http.get<FinalityReport>("/api/v1/explorer/verify-finality", { height });
  }
  proof(key: string, height?: number) {
    return this.http.get<JsonObject>("/api/v1/explorer/proof", { key, height });
  }
  search(q: string) {
    return this.http.get<JsonObject>("/api/v1/explorer/search", { q });
  }
}

export interface WaitIndexedOptions {
  timeoutMs?: number;
  intervalMs?: number;
}
export interface IndexedWait {
  status: ProjectionStatus;
  waitedMs: number;
  /** True if the projection was observed rebuilding / going backwards while waiting. */
  sawRebuild: boolean;
}

export interface VerifiedRecord<T> {
  record: ChainRecordResponse<T>;
  verdict: ProofVerdict;
  /** Set when crossCheckFinality was requested. */
  finality?: FinalityReport;
  /** True only if the gateway's own light-client report for the proof's header agrees with the proof's app hash. */
  finalityAgrees?: boolean;
}

export class Client implements TxGateway {
  readonly http: Http;
  readonly q: ProjectionQueries;
  readonly explorer: ExplorerApi;

  constructor(opts: ClientOptions = {}) {
    this.http = new Http({ ...opts, baseUrl: opts.baseUrl ?? DEFAULT_GATEWAY_URL });
    this.q = new ProjectionQueries(this.http);
    this.explorer = new ExplorerApi(this.http);
  }

  get baseUrl(): string {
    return this.http.baseUrl;
  }

  // ---- Submission ------------------------------------------------------------------------

  /**
   * POST /api/v1/tx/submit. `wait: "none"` returns after mempool admission (NOT finality);
   * `"final"` after the block is committed; `"indexed"` additionally after the projection has it.
   * A committed transaction may still carry code != 0 (ordered but rejected, no state change).
   * Use outcomeOf() / submitAndWait() to interpret the response.
   */
  async submit(tx: SignedTx | Envelope | string, opts: SubmitOptions = {}): Promise<SubmitResponse> {
    const wait = opts.wait ?? "final";
    const timeoutMs = opts.timeoutMs ?? 15_000;
    try {
      // HTTP deadline must outlast the server-side wait.
      return await this.http.post<SubmitResponse>("/api/v1/tx/submit", { tx: toEnvelope(tx), wait, timeout_ms: timeoutMs }, { timeoutMs: timeoutMs + 10_000 });
    } catch (e) {
      // Re-sending identical bytes: the validators' mempool cache refuses them (HTTP 502 from the gateway).
      // That is not a failure of the transaction - it is already known. Report it as a duplicate.
      if (e instanceof GatewayError && e.status === 502 && /already exists in cache/i.test(e.message)) return this.duplicateResponse(tx, wait, timeoutMs);
      throw e;
    }
  }

  private async duplicateResponse(tx: SignedTx | Envelope | string, wait: WaitMode, timeoutMs: number): Promise<SubmitResponse> {
    const meta = metaOf(tx);
    const resp: SubmitResponse = {
      tx_hash: meta.txHash ?? "",
      tx_id: meta.txId,
      type: meta.type,
      signer: meta.signer,
      admission: { code: 0, name: "OK", log: "duplicate: the network already holds this exact transaction (mempool cache); not executed again" },
      duplicate: true,
    };
    if (wait !== "none" && meta.txId) {
      try {
        const st = await this.waitForTx(meta.txId, { timeoutMs });
        resp.finalised = { height: st.height ?? 0, index: st.index ?? 0, code: st.code ?? 0, code_name: st.code_name ?? codeName(st.code ?? 0), log: st.reason ?? "" };
      } catch (e) {
        if (!(e instanceof TimeoutError)) throw e;
      }
    }
    return resp;
  }

  /** Submit, wait, and throw TxRejectedError unless the tx finalised with code 0. Returns the finalised result. */
  async submitAndWait<T extends SubmitResponse>(tx: SignedTx | Envelope | string, opts: SubmitOptions = {}): Promise<T & { finalised: NonNullable<SubmitResponse["finalised"]> }> {
    const r = (await this.submit(tx, { wait: "final", ...opts })) as T;
    const o = outcomeOf(r);
    if (o.status === "ADMISSION_REJECTED") throw new TxRejectedError(r.tx_id, "admission", o.code, o.codeName, o.log);
    if (o.status === "FINALISED_REJECTED") throw new TxRejectedError(r.tx_id, "finalised", o.code, o.codeName, o.log);
    if (o.status !== "FINALISED_OK") throw new TimeoutError(`tx ${r.tx_id} was admitted but not finalised within the wait budget`);
    return r as T & { finalised: NonNullable<SubmitResponse["finalised"]> };
  }

  txStatus(txId: string): Promise<TxStatus> {
    return this.http.get<TxStatus>(`/api/v1/tx/${encodeURIComponent(txId)}/status`);
  }

  /** Poll txStatus until the tx is finalised (or the deadline passes). */
  async waitForTx(txId: string, opts: { timeoutMs?: number; intervalMs?: number } = {}): Promise<TxStatus> {
    const deadline = Date.now() + (opts.timeoutMs ?? 20_000);
    for (;;) {
      const s = await this.txStatus(txId);
      if (s.status === "FINALISED_OK" || s.status === "FINALISED_REJECTED") return s;
      if (Date.now() >= deadline) throw new TimeoutError(`tx ${txId} is still ${s.status} after ${opts.timeoutMs ?? 20_000} ms`);
      await sleep(opts.intervalMs ?? 250);
    }
  }

  latencyMetrics(): Promise<JsonObject> {
    return this.http.get<JsonObject>("/api/v1/metrics/latency");
  }

  // ---- Network & chain --------------------------------------------------------------------

  network(): Promise<NetworkInfo> {
    return this.http.get<NetworkInfo>("/api/v1/network");
  }
  chainInfo(): Promise<ChainInfo> {
    return this.http.get<ChainInfo>("/api/v1/chain/info");
  }

  // ---- Authoritative reads -----------------------------------------------------------------

  /** GET /chain/record: one state record from committed state (optionally pinned to `height`, optionally with a proof). */
  getRecord<T = unknown>(key: string, opts: ChainRecordOptions = {}): Promise<ChainRecordResponse<T>> {
    return this.http.get<ChainRecordResponse<T>>("/api/v1/chain/record", { key, height: opts.height, prove: opts.prove ? 1 : undefined });
  }

  /** GET /chain/records/{kind}/{id} (typed for kinds with a known record shape). */
  getRecordByKind<K extends keyof RecordKindMap>(kind: K, id: string, opts?: ChainRecordOptions): Promise<ChainRecordResponse<RecordKindMap[K]>>;
  getRecordByKind(kind: RecordKind, id: string, opts?: ChainRecordOptions): Promise<ChainRecordResponse<unknown>>;
  getRecordByKind(kind: RecordKind, id: string, opts: ChainRecordOptions = {}): Promise<ChainRecordResponse<unknown>> {
    return this.http.get<ChainRecordResponse<unknown>>(`/api/v1/chain/records/${kind}/${encodeURIComponent(id)}`, { height: opts.height, prove: opts.prove ? 1 : undefined });
  }

  /** GET /chain/scan: one page of keys with a prefix (authoritative, paginated, NO proofs). */
  scan<T = unknown>(prefix: string, opts: ScanOptions = {}): Promise<ScanResponse<T>> {
    return this.http.get<ScanResponse<T>>("/api/v1/chain/scan", { prefix, after: opts.after, limit: opts.limit, height: opts.height });
  }

  /** Iterate every record under a prefix (pins the height of the first page so the walk is consistent). */
  async *scanAll<T = unknown>(prefix: string, opts: { pageSize?: number; height?: number } = {}): AsyncGenerator<{ key: string; value: T }, void, undefined> {
    let after: string | undefined;
    let height = opts.height;
    for (;;) {
      const page: ScanResponse<T> = await this.scan<T>(prefix, { ...(after !== undefined ? { after } : {}), limit: opts.pageSize ?? 200, ...(height !== undefined ? { height } : {}) });
      height = page.height;
      for (const it of page.items) yield it;
      if (!page.next_after || page.items.length === 0) return;
      after = page.next_after;
    }
  }

  /** GET /chain/inventory: authoritative balances. Accepts both an array and an {items,in_transit} object. */
  async inventory(f: { sku?: string; location?: string; height?: number } = {}): Promise<InventoryResult> {
    const raw = await this.http.get<unknown>("/api/v1/chain/inventory", f);
    return normaliseInventory(raw);
  }

  digest(height?: number): Promise<Digest> {
    return this.http.get<Digest>("/api/v1/chain/digest", { height });
  }
  chainMigration(): Promise<JsonObject> {
    return this.http.get<JsonObject>("/api/v1/chain/migration");
  }

  /**
   * Read a record with an ICS23 proof and verify it locally against the app hash in the response.
   * See src/proof.ts for exactly what a valid verdict does and does not establish.
   *
   * @param expectedAppHash pin the root to a value obtained independently of this gateway
   * @param crossCheckFinality also ask the gateway's light client for the finality report of the
   *   header that carries the proof's app hash and compare (still gateway-asserted, but catches
   *   inconsistent responses)
   */
  async getVerifiedRecord<T = unknown>(
    key: string,
    opts: { height?: number; expectedAppHash?: string; crossCheckFinality?: boolean } = {},
  ): Promise<VerifiedRecord<T>> {
    const record = await this.getRecord<T>(key, { ...(opts.height !== undefined ? { height: opts.height } : {}), prove: true });
    const verdict = verifyRecordResponse(key, record as ChainRecordResponse, opts.expectedAppHash !== undefined ? { expectedAppHash: opts.expectedAppHash } : {});
    const out: VerifiedRecord<T> = { record, verdict };
    if (opts.crossCheckFinality && record.proof) {
      // The header that carries the root of the state at height H is header H+1 (proof.app_hash_height).
      const hdr = record.proof.app_hash_height ?? record.height + 1;
      const fin = await this.explorer.verifyFinality(hdr);
      out.finality = fin;
      const reported = (fin.header_app_hash ?? "").toLowerCase();
      out.finalityAgrees = fin.verified === true && reported !== "" && reported === record.proof.app_hash.toLowerCase();
    }
    return out;
  }

  // ---- Projection admin & read-after-write -------------------------------------------------

  projectionStatus(): Promise<ProjectionStatus> {
    return this.http.get<ProjectionStatus>("/api/v1/projection/status");
  }
  /** Drop and rebuild the disposable projection from finalised blocks (returns immediately; poll status). */
  rebuildProjection(): Promise<JsonObject> {
    return this.http.post<JsonObject>("/api/v1/projection/rebuild", {});
  }
  verifyProjection(proofs?: number): Promise<ProjectionVerify> {
    return this.http.get<ProjectionVerify>("/api/v1/projection/verify", { proofs });
  }

  /**
   * Block until the projection has indexed `height` (state OK). Handles a projection that is
   * rebuilding (indexed_height restarts from 0): keeps waiting and reports `sawRebuild`.
   */
  async waitIndexed(height: number, opts: WaitIndexedOptions = {}): Promise<IndexedWait> {
    const started = Date.now();
    const deadline = started + (opts.timeoutMs ?? 30_000);
    const interval = opts.intervalMs ?? 150;
    let sawRebuild = false;
    let lastIndexed = -1;
    let last: ProjectionStatus | undefined;
    for (;;) {
      last = await this.projectionStatus();
      if (last.state !== "OK" || last.indexed_height < lastIndexed) sawRebuild = true;
      lastIndexed = Math.max(lastIndexed, last.indexed_height);
      if (last.state === "OK" && last.indexed_height >= height) return { status: last, waitedMs: Date.now() - started, sawRebuild };
      if (Date.now() >= deadline) {
        throw new TimeoutError(`projection did not reach height ${height} within ${opts.timeoutMs ?? 30_000} ms (state ${last.state}, indexed ${last.indexed_height}, chain head ${last.chain_head})`);
      }
      await sleep(interval);
    }
  }

  /**
   * Read-after-write helper: wait until the projection covers `height`, run `read`, and re-run it
   * if the response's own meta says it was served by a stale/rebuilding projection (a rebuild can
   * start between the wait and the read). Returns the read result.
   */
  async readAfterWrite<R extends { meta: { indexed_height: number; projection_state?: string } }>(
    height: number,
    read: () => Promise<R>,
    opts: WaitIndexedOptions & { attempts?: number } = {},
  ): Promise<R> {
    const attempts = opts.attempts ?? 5;
    let last: R | undefined;
    for (let i = 0; i < attempts; i++) {
      await this.waitIndexed(height, opts);
      last = await read();
      const m = last.meta;
      if (m.indexed_height >= height && (m.projection_state === undefined || m.projection_state === "OK")) return last;
    }
    throw new TimeoutError(`projection stayed behind height ${height} after ${attempts} attempts (last meta: ${JSON.stringify(last?.meta)})`);
  }
}

function normaliseInventory(raw: unknown): InventoryResult {
  type B = InventoryResult["balances"][number];
  const asRows = (v: unknown): B[] => (Array.isArray(v) ? (v as B[]) : []);
  const split = (rows: B[]) => ({
    balances: rows.filter((r) => !String(r.loc).startsWith("TRANSIT:")),
    in_transit: rows.filter((r) => String(r.loc).startsWith("TRANSIT:")),
  });
  if (Array.isArray(raw)) return { ...split(asRows(raw)), raw };
  if (raw && typeof raw === "object") {
    const o = raw as Record<string, unknown>;
    const main = asRows(o["balances"] ?? o["items"] ?? o["inventory"]);
    const transit = asRows(o["in_transit"]);
    const s = split(main);
    return { balances: s.balances, in_transit: [...s.in_transit, ...transit], raw };
  }
  return { balances: [], in_transit: [], raw };
}
