// PaymentProviderAdapter: authenticated provider webhooks -> RecordPaymentResult / RecordRefundResult.
//
// KEY RULES
//  * The chain records an INSTRUCTION to take / return money (sale payment_status INSTRUCTED, refund
//    status INSTRUCTED). That is NOT money movement. Only a result reported by this authenticated
//    adapter (CONFIRMED / FAILED) tells the chain what really happened at the provider.
//  * The adapter holds a SERVICE identity (default payment-adapter-1, role payment-adapter) - never a
//    human's or a terminal's key.
//  * Providers redeliver callbacks and deliver them out of order:
//      - duplicates: idempotency_ref = pay:<provider>:<event id>, and the chain also dedupes by
//        provider + event_id (the second is accepted as a no-op with data.deduplicated = true);
//      - out of order (a result arrives before the sale/refund it refers to is on chain): the chain
//        answers NOT_FOUND; the runner retries with backoff and a fresh tx id, then dead-letters;
//      - amount disagreements are recorded by the chain as reconciliation exceptions
//        (PAYMENT_AMOUNT_MISMATCH, PAYMENT_OVERPAID, REFUND_AMOUNT_MISMATCH, ...), never silently fixed.

import type { Currency } from "../payloads.js";
import { ValidationError } from "../errors.js";
import { type WebhookInbound, type WebhookVerifier } from "./hmac.js";
import { AdapterRejection, request, type AdapterContext, type FailureInfo, type IntegrationAdapter, type TxRequest, type VerifyResult } from "./types.js";
import { idempotencyRefFor } from "./util.js";

export type PaymentEventKind = "PAYMENT_CONFIRMED" | "PAYMENT_FAILED" | "REFUND_CONFIRMED" | "REFUND_FAILED";

/** Provider-neutral form of a callback, produced by the provider-specific parseWebhook(). */
export interface NormalisedPaymentEvent {
  kind: PaymentEventKind;
  /** Short provider code stored on chain (<= 64 chars, chain id rules), e.g. "SIMPAY". */
  provider: string;
  /** Provider's unique event / callback id. Duplicates share it. */
  eventId: string;
  /** Provider's reference for the charge / refund (shown in audit trails). */
  providerRef: string;
  /** Minor units. */
  amountMinor: number;
  currency: Currency;
  /** PAYMENT_*: the chain sale id the payment was instructed for. */
  saleId?: string;
  /** REFUND_*: the chain refund id (instructed by ReceiveReturnedGoods). */
  refundId?: string;
}

export interface PaymentAdapterOptions {
  /** Service identity (in the runner's KeyStore). Default "payment-adapter-1". */
  serviceIdentity?: string;
  verifier: WebhookVerifier;
}

export abstract class PaymentProviderAdapter implements IntegrationAdapter<WebhookInbound> {
  abstract readonly name: string;
  protected readonly serviceIdentity: string;
  protected readonly verifier: WebhookVerifier;

  constructor(opts: PaymentAdapterOptions) {
    this.serviceIdentity = opts.serviceIdentity ?? "payment-adapter-1";
    this.verifier = opts.verifier;
  }

  /** Provider-specific: turn the (already authenticated) raw body into a normalised event. Throw AdapterRejection if unusable. */
  abstract parseWebhook(rawBody: string): NormalisedPaymentEvent;

  verify(inbound: WebhookInbound, ctx: AdapterContext): VerifyResult {
    return this.verifier.verify(inbound, ctx.now);
  }

  eventId(inbound: WebhookInbound): string {
    return this.parseWebhook(inbound.rawBody).eventId;
  }

  /** Out-of-order delivery: the sale / refund may not be on chain yet (NOT_FOUND = 401). */
  retryableBusinessCodes(): number[] {
    return [401];
  }

  translate(inbound: WebhookInbound): TxRequest[] {
    const e = this.parseWebhook(inbound.rawBody);
    if (!Number.isSafeInteger(e.amountMinor) || e.amountMinor < 0) throw new AdapterRejection("BAD_AMOUNT", `amount ${e.amountMinor} is not a non-negative integer of minor units`);
    if (e.kind === "PAYMENT_CONFIRMED" || e.kind === "PAYMENT_FAILED") {
      if (!e.saleId) throw new AdapterRejection("MISSING_SALE", "payment event carries no sale id");
      if (e.kind === "PAYMENT_CONFIRMED" && e.amountMinor === 0) throw new AdapterRejection("BAD_AMOUNT", "a CONFIRMED payment must have a positive amount");
      return [
        request(
          this.serviceIdentity,
          "RecordPaymentResult",
          { sale_id: e.saleId, provider: e.provider, event_id: e.eventId, provider_ref: e.providerRef, result: e.kind === "PAYMENT_CONFIRMED" ? "CONFIRMED" : "FAILED", amount_minor: e.amountMinor, currency: e.currency },
          idempotencyRefFor("pay", e.provider, e.eventId),
          `${e.kind} for sale ${e.saleId}`,
        ),
      ];
    }
    if (!e.refundId) throw new AdapterRejection("MISSING_REFUND", "refund event carries no refund id");
    return [
      request(
        this.serviceIdentity,
        "RecordRefundResult",
        { refund_id: e.refundId, provider: e.provider, event_id: e.eventId, provider_ref: e.providerRef, result: e.kind === "REFUND_CONFIRMED" ? "CONFIRMED" : "FAILED", amount_minor: e.amountMinor },
        idempotencyRefFor("refund", e.provider, e.eventId),
        `${e.kind} for refund ${e.refundId}`,
      ),
    ];
  }

  suggestAction(inbound: WebhookInbound, f: FailureInfo): string {
    let subject = "the payment";
    try {
      const e = this.parseWebhook(inbound.rawBody);
      subject = e.kind.startsWith("REFUND") ? `refund ${e.refundId}` : `payment for sale ${e.saleId}`;
    } catch {
      /* keep the generic subject */
    }
    if (f.code === "NOT_FOUND") return `The chain has no record of ${subject}. If the sale/refund id is wrong, the provider reference needs manual matching in finance reconciliation. If the sale was created late, replay the dead letter. Money may have MOVED at the provider although the chain does not know it yet.`;
    return `Money may have moved at the provider but the chain could not record it (${f.code}). Reconcile ${subject} with the provider's settlement report; replay the dead letter once the cause is fixed.`;
  }
}

export function assertCurrency(c: string): Currency {
  if (c === "GBP" || c === "USD" || c === "EUR" || c === "JPY") return c;
  throw new ValidationError(`unsupported currency ${c}`);
}
