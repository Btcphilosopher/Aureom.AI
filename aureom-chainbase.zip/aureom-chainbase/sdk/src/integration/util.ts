import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, utf8 } from "../encoding.js";
import { RE_ID, RE_IDEM } from "../ids.js";

function squash(s: string): string {
  return s.replace(/[^A-Za-z0-9._:-]/g, "_");
}

/**
 * Stable idempotency_ref from an external event id: `<role>:<provider>:<eventId>`.
 * Characters the chain does not accept are replaced; if the result would exceed the 96 character limit
 * it is shortened and a hash of the ORIGINAL parts is appended, so distinct events never collide.
 */
export function idempotencyRefFor(...parts: string[]): string {
  const lossless = parts.every((p) => squash(p) === p);
  const joined = parts.map(squash).join(":");
  const candidate = /^[A-Za-z0-9]/.test(joined) ? joined : `x${joined}`;
  if (lossless && candidate === joined && candidate.length <= 96 && RE_IDEM.test(candidate)) return candidate;
  // lossy squashing or too long: keep a readable prefix and bind the ORIGINAL parts with a hash
  const h = bytesToHex(sha256(utf8(parts.join("\u0000")))).slice(0, 12);
  return `${candidate.slice(0, 80)}:${h}`;
}

/** Map an external identifier to a valid chain business id (<= 64 chars, RE_ID), with a prefix. */
export function toChainId(prefix: string, external: string): string {
  const clean = squash(external);
  const id = `${prefix}${clean}`;
  if (id.length <= 64 && RE_ID.test(id) && clean === external) return id;
  const h = bytesToHex(sha256(utf8(external))).slice(0, 10);
  return `${prefix}${clean.slice(0, 64 - prefix.length - 11)}-${h}`;
}
