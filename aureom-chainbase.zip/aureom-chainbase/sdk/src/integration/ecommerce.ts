// E-commerce adapter (example): web-shop orders -> ReserveStock (per line) + CompleteSale (channel ECOM).
//
// Reservations are taken first (stock moves available -> reserved, so two orders cannot take the same
// last unit); the sale is only completed if every line reserved. If a later request fails permanently,
// compensate() releases the reservations that were taken, so a rejected order never strands stock.
// Payment is NOT part of this adapter: the sale only INSTRUCTS payment; the payment adapter confirms it.

import type { Currency } from "../payloads.js";
import { AdapterRejection, request, type AppliedRequest, type IntegrationAdapter, type TxRequest, type VerifyResult } from "./types.js";
import { idempotencyRefFor, toChainId } from "./util.js";

export interface EcomOrderEvent {
  kind: "ORDER_PLACED";
  event_id: string;
  order_id: string;
  /** Fulfilment location (store or warehouse). */
  location_id: string;
  currency: Currency;
  placed_at_ms: number;
  payment_method: string;
  /** Synthetic / pseudonymous reference only (CUST-xxxx / PSN-xxxx), never an email or name. */
  customer_id?: string;
  lines: { sku: string; qty_v: number; unit: string }[];
}

export interface EcomAdapterOptions {
  /** Service identity holding stock.reserve + sale.complete at the fulfilment location. */
  serviceIdentity: string;
  /** Reservation lifetime; must be within the chain's reservation_max_ttl_ms (default 30 min). Default 20 min. */
  reservationTtlMs?: number;
}

export class EcommerceOrderAdapter implements IntegrationAdapter<EcomOrderEvent> {
  readonly name = "ecommerce:orders";
  private readonly identity: string;
  private readonly ttl: number;

  constructor(opts: EcomAdapterOptions) {
    this.identity = opts.serviceIdentity;
    this.ttl = opts.reservationTtlMs ?? 20 * 60_000;
  }

  verify(e: EcomOrderEvent): VerifyResult {
    if (!e?.event_id || !e.order_id) return { ok: false, code: "BAD_EVENT", reason: "missing event_id / order_id" };
    return { ok: true };
  }

  eventId(e: EcomOrderEvent): string {
    return e.event_id;
  }

  translate(e: EcomOrderEvent): TxRequest[] {
    if (e.lines.length === 0) throw new AdapterRejection("NO_LINES", "order has no lines");
    const reserves = e.lines.map((l, i) => {
      // derived from the EVENT id (not the order id): a compensated order can be re-submitted as a new event without ALREADY_EXISTS
      const reservationId = toChainId("ECO-", `${e.event_id}-${i + 1}`);
      return { l, reservationId, req: request(this.identity, "ReserveStock", { reservation_id: reservationId, location_id: e.location_id, sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, ttl_ms: this.ttl }, idempotencyRefFor("ecom-reserve", e.event_id, String(i + 1)), `reserve ${l.qty_v} x ${l.sku}`) };
    });
    const sale = request(
      this.identity,
      "CompleteSale",
      {
        sale_id: toChainId("ECO-", e.order_id),
        location_id: e.location_id,
        channel: "ECOM",
        ...(e.customer_id ? { customer_id: e.customer_id } : {}),
        effective_at_ms: e.placed_at_ms,
        currency: e.currency,
        payment_method: e.payment_method,
        lines: reserves.map((r) => ({ sku: r.l.sku, qty: { v: r.l.qty_v, unit: r.l.unit }, reservation_id: r.reservationId })),
      },
      idempotencyRefFor("ecom-sale", e.event_id),
      `complete sale for order ${e.order_id}`,
    );
    return [...reserves.map((r) => r.req), sale];
  }

  compensate(_e: EcomOrderEvent, applied: AppliedRequest[]): TxRequest[] {
    return applied
      .filter((a) => a.request.type === "ReserveStock" && !a.duplicate)
      .map((a) => {
        const id = (a.request.payload as { reservation_id: string }).reservation_id;
        return request(this.identity, "ReleaseReservation", { reservation_id: id, reason: "CANCELLED" }, idempotencyRefFor("ecom-release", id), `release ${id}`);
      });
  }

  suggestAction(e: EcomOrderEvent, f: { code: string }): string {
    return f.code === "INSUFFICIENT"
      ? `Order ${e.order_id}: stock was not available at ${e.location_id}. Reservations taken for other lines were released. Tell the customer / back-order, or fulfil from another location and replay with a different location_id.`
      : `Order ${e.order_id} could not be recorded (${f.code}). Check the order data (SKU, unit, location) and replay the dead letter.`;
  }
}
