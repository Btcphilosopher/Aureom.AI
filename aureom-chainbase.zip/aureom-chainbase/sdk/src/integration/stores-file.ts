// NODE ONLY: durable file-backed stores for the integration layer.

import { promises as fs } from "node:fs";
import { dirname, join } from "node:path";
import type { CheckpointStore, Cursor } from "./stores.js";
import type { DeadLetter, DeadLetterStore, ReconciliationException, ReconciliationSink } from "./types.js";

async function writeAtomic(path: string, data: string): Promise<void> {
  await fs.mkdir(dirname(path), { recursive: true });
  const tmp = `${path}.tmp-${process.pid}`;
  const fh = await fs.open(tmp, "w", 0o600);
  try {
    await fh.writeFile(data);
    await fh.sync();
  } finally {
    await fh.close();
  }
  await fs.rename(tmp, path);
}

/** One JSON file per dead letter: <dir>/<id>.json. */
export class FileDeadLetterStore implements DeadLetterStore {
  constructor(readonly dir: string) {}
  private file(id: string): string {
    if (!/^[A-Za-z0-9._-]+$/.test(id)) throw new Error("unsafe dead letter id");
    return join(this.dir, `${id}.json`);
  }
  async add(dl: DeadLetter): Promise<void> {
    await writeAtomic(this.file(dl.id), JSON.stringify(dl, null, 2));
  }
  update(dl: DeadLetter): Promise<void> {
    return this.add(dl);
  }
  async get(id: string): Promise<DeadLetter | undefined> {
    try {
      return JSON.parse(await fs.readFile(this.file(id), "utf8")) as DeadLetter;
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return undefined;
      throw e;
    }
  }
  async list(): Promise<DeadLetter[]> {
    let names: string[];
    try {
      names = await fs.readdir(this.dir);
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw e;
    }
    const out: DeadLetter[] = [];
    for (const n of names.filter((x) => x.endsWith(".json")).sort()) out.push(JSON.parse(await fs.readFile(join(this.dir, n), "utf8")) as DeadLetter);
    return out;
  }
  async remove(id: string): Promise<void> {
    await fs.rm(this.file(id), { force: true });
  }
}

/** Append-only JSON Lines file of reconciliation exceptions (feed it to finance / ops tooling). */
export class JsonlReconciliationSink implements ReconciliationSink {
  constructor(readonly path: string) {}
  async report(e: ReconciliationException): Promise<void> {
    await fs.mkdir(dirname(this.path), { recursive: true });
    await fs.appendFile(this.path, `${JSON.stringify(e)}\n`, { mode: 0o600 });
  }
}

export class FileCheckpointStore implements CheckpointStore {
  constructor(readonly path: string) {}
  async load(): Promise<Cursor | undefined> {
    try {
      return JSON.parse(await fs.readFile(this.path, "utf8")) as Cursor;
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return undefined;
      throw e;
    }
  }
  async save(c: Cursor): Promise<void> {
    await writeAtomic(this.path, JSON.stringify(c));
  }
}
