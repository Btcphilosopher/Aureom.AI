import type { DeadLetter, DeadLetterStore, ReconciliationException, ReconciliationSink } from "./types.js";

export class MemoryDeadLetterStore implements DeadLetterStore {
  private readonly m = new Map<string, DeadLetter>();
  async add(dl: DeadLetter): Promise<void> {
    this.m.set(dl.id, structuredClone(dl));
  }
  async list(): Promise<DeadLetter[]> {
    return [...this.m.values()].map((d) => structuredClone(d));
  }
  async get(id: string): Promise<DeadLetter | undefined> {
    const d = this.m.get(id);
    return d ? structuredClone(d) : undefined;
  }
  async update(dl: DeadLetter): Promise<void> {
    this.m.set(dl.id, structuredClone(dl));
  }
  async remove(id: string): Promise<void> {
    this.m.delete(id);
  }
}

export class MemoryReconciliationSink implements ReconciliationSink {
  readonly items: ReconciliationException[] = [];
  async report(e: ReconciliationException): Promise<void> {
    this.items.push(structuredClone(e));
  }
}

/** Position of a ChainEventSource in the finalised transaction log. */
export interface Cursor {
  height: number;
  index: number;
}
export interface CheckpointStore {
  load(): Promise<Cursor | undefined>;
  save(c: Cursor): Promise<void>;
}
export class MemoryCheckpointStore implements CheckpointStore {
  private c: Cursor | undefined;
  async load(): Promise<Cursor | undefined> {
    return this.c ? { ...this.c } : undefined;
  }
  async save(c: Cursor): Promise<void> {
    this.c = { ...c };
  }
}
