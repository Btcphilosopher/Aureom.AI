// ERP adapter (example): ERP purchase-order documents -> CreatePurchaseOrder / ApprovePurchaseOrder / ReceiveGoods.
//
// Same shape as every adapter: verify -> translate -> signed requests with idempotency refs derived from
// the ERP's document/event ids. Separation of duties is preserved ON CHAIN: the PO creator and approver
// must be different identities, so the adapter holds two service identities.

import type { Currency } from "../payloads.js";
import { AdapterRejection, request, type IntegrationAdapter, type TxRequest, type VerifyResult } from "./types.js";
import { idempotencyRefFor, toChainId } from "./util.js";

export interface ErpPoLine {
  sku: string;
  qty_v: number;
  unit: string;
  unit_cost_minor: number;
}

export type ErpEvent =
  | {
      kind: "PO_RELEASED";
      /** ERP's unique id for this event (e.g. the outbox message id). */
      event_id: string;
      source_system: string;
      po_number: string;
      supplier_id: string;
      location_id: string;
      currency: Currency;
      ordered_at_ms: number;
      lines: ErpPoLine[];
      /** The ERP's own approval state; the adapter only submits ApprovePurchaseOrder if the ERP approved it. */
      erp_status: "DRAFT" | "APPROVED";
    }
  | {
      kind: "GOODS_RECEIPT_POSTED";
      event_id: string;
      source_system: string;
      po_number: string;
      location_id: string;
      effective_at_ms: number;
      lines: { sku: string; qty_v: number; unit: string; po_line: number }[];
    };

export interface ErpAdapterOptions {
  /** Identity holding po.create (default buyer-hq). */
  buyerIdentity?: string;
  /** Identity holding po.approve; MUST differ from the buyer (default po-approver-hq). */
  approverIdentity?: string;
  /** Identity holding goods.receive for the receiving location (default manager-n01). */
  receiverIdentity?: string;
  /** Source systems allowed to post (a deployment would also authenticate the transport: mTLS / HMAC). */
  allowedSources?: string[];
}

export class ErpPurchaseOrderAdapter implements IntegrationAdapter<ErpEvent> {
  readonly name = "erp:purchase-orders";
  private readonly buyer: string;
  private readonly approver: string;
  private readonly receiver: string;
  private readonly sources: Set<string> | undefined;

  constructor(opts: ErpAdapterOptions = {}) {
    this.buyer = opts.buyerIdentity ?? "buyer-hq";
    this.approver = opts.approverIdentity ?? "po-approver-hq";
    this.receiver = opts.receiverIdentity ?? "manager-n01";
    if (this.buyer === this.approver) throw new Error("buyer and approver identities must differ (the chain enforces maker-checker)");
    this.sources = opts.allowedSources ? new Set(opts.allowedSources) : undefined;
  }

  verify(e: ErpEvent): VerifyResult {
    if (!e || typeof e.event_id !== "string" || !e.event_id) return { ok: false, code: "BAD_EVENT", reason: "missing event_id" };
    if (this.sources && !this.sources.has(e.source_system)) return { ok: false, code: "UNKNOWN_SOURCE", reason: `source system ${String(e.source_system)} is not allowed` };
    return { ok: true };
  }

  eventId(e: ErpEvent): string {
    return e.event_id;
  }

  retryableBusinessCodes(): number[] {
    return [401]; // e.g. a receipt that races ahead of the PO it refers to
  }

  translate(e: ErpEvent): TxRequest[] {
    const poId = toChainId("PO-", e.po_number);
    if (e.kind === "PO_RELEASED") {
      if (e.lines.length === 0) throw new AdapterRejection("NO_LINES", "purchase order has no lines");
      const reqs: TxRequest[] = [
        request(
          this.buyer,
          "CreatePurchaseOrder",
          { po_id: poId, supplier_id: e.supplier_id, location_id: e.location_id, currency: e.currency, ordered_at_ms: e.ordered_at_ms, lines: e.lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, unit_cost_minor: l.unit_cost_minor })) },
          idempotencyRefFor("erp-po-create", e.source_system, e.event_id),
          `create ${poId}`,
        ),
      ];
      if (e.erp_status === "APPROVED") reqs.push(request(this.approver, "ApprovePurchaseOrder", { po_id: poId }, idempotencyRefFor("erp-po-approve", e.source_system, e.event_id), `approve ${poId}`));
      return reqs;
    }
    if (e.lines.length === 0) throw new AdapterRejection("NO_LINES", "goods receipt has no lines");
    return [
      request(
        this.receiver,
        "ReceiveGoods",
        { receipt_id: toChainId("RCPT-", `${e.source_system}-${e.event_id}`), location_id: e.location_id, po_id: poId, effective_at_ms: e.effective_at_ms, lines: e.lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, po_line: l.po_line })) },
        idempotencyRefFor("erp-receipt", e.source_system, e.event_id),
        `receive against ${poId}`,
      ),
    ];
  }

  suggestAction(e: ErpEvent): string {
    return `Check ERP document ${e.kind === "PO_RELEASED" ? e.po_number : `receipt for ${e.po_number}`} against chain record po/${toChainId("PO-", e.po_number)}; fix master data (supplier, SKU, location, unit) in the ERP or on chain, then replay the dead letter.`;
  }
}
