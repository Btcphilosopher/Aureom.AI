// Provider-independent integration layer: shared types.
//
// ARCHITECTURE RULES (see docs/SDK.md, "Integration layer")
//  * Adapters live OUTSIDE consensus. The chain never calls an external API.
//  * An adapter (1) AUTHENTICATES an inbound event, (2) TRANSLATES it into one or more
//    transaction requests, (3) SIGNS them with a service identity from a KeyStore, and
//    (4) SUBMITS them with an idempotency_ref derived from the external system's unique event id.
//  * A recorded payment / refund INSTRUCTION is not a money movement. Only an authenticated adapter
//    result (RecordPaymentResult / RecordRefundResult) confirms that money actually moved.

import type { TxPayloadMap, TxType } from "../payloads.js";

/** One transaction the adapter wants on chain. */
export interface TxRequest<T extends TxType = TxType> {
  /** Service identity that signs (must be present in the runner's KeyStore). */
  signer: string;
  type: T;
  payload: TxPayloadMap[T];
  /**
   * Stable business dedupe key. Derive it from the EXTERNAL event id (and the request's role within the
   * event), never from a clock or counter: a re-delivery then yields the same ref and the chain rejects
   * the second execution with DUPLICATE_IDEMPOTENCY. See idempotencyRefFor().
   */
  idempotencyRef: string;
  /** Short human label used in logs / dead letters. */
  label?: string;
  expectedVersion?: number;
}

/** Request builder with type inference for the payload. */
export function request<T extends TxType>(signer: string, type: T, payload: TxPayloadMap[T], idempotencyRef: string, label?: string): TxRequest<T> {
  return { signer, type, payload, idempotencyRef, ...(label ? { label } : {}) };
}

export type VerifyResult = { ok: true } | { ok: false; code: string; reason: string };

export interface AdapterContext {
  /** Current time (ms), injectable for tests. */
  now: number;
}

/**
 * The shape every adapter has. `TEvent` is whatever arrives from the outside world: a raw webhook
 * (body + headers) for providers that sign callbacks, or a parsed document for pull-based systems.
 */
export interface IntegrationAdapter<TEvent> {
  readonly name: string;
  /** Authenticate (and validate) the inbound event. A failure is NEVER submitted and never retried. */
  verify(event: TEvent, ctx: AdapterContext): VerifyResult | Promise<VerifyResult>;
  /** The external system's unique id for this event (stable across redeliveries). */
  eventId(event: TEvent): string;
  /** Translate into ordered transaction requests. Throw AdapterRejection for events that make no sense. */
  translate(event: TEvent, ctx: AdapterContext): TxRequest[] | Promise<TxRequest[]>;
  /**
   * Business rejection codes (see codes.ts) worth retrying with a FRESH tx id, e.g. NOT_FOUND for an
   * out-of-order callback that arrived before the record it refers to. Default: none.
   */
  retryableBusinessCodes?(): number[];
  /** Requests that undo already-applied requests when a later request of the same event fails permanently. */
  compensate?(event: TEvent, applied: AppliedRequest[]): TxRequest[];
  /** What a human should do about a dead-lettered event (goes into the reconciliation exception). */
  suggestAction?(event: TEvent, failure: FailureInfo): string;
}

/** Thrown by translate()/parse code when an (authentic) event cannot be mapped to a transaction. */
export class AdapterRejection extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "AdapterRejection";
    this.code = code;
  }
}

export interface AppliedRequest {
  request: TxRequest;
  txId: string;
  height: number;
  /** True if the chain reported the request as a duplicate of something it already applied. */
  duplicate: boolean;
  data?: Record<string, unknown>;
  attempts: number;
}

export interface FailureInfo {
  stage: "authentication" | "translation" | "submission" | "business";
  code: string;
  codeName?: string;
  reason: string;
  /** Request that failed (submission/business). */
  request?: TxRequest;
  txId?: string;
  attempts: number;
  /** True if retrying later could succeed (transient exhaustion), false for definitive rejections. */
  transient: boolean;
}

export interface DeadLetter<TEvent = unknown> {
  id: string;
  adapter: string;
  eventId: string;
  receivedAtMs: number;
  failedAtMs: number;
  failure: FailureInfo;
  /** The inbound event exactly as received (JSON-serialisable). It was authenticated BEFORE it was dead-lettered. */
  event: TEvent;
  /** Requests that had already been applied when the failure happened. */
  applied: { type: string; txId: string; height: number; idempotencyRef: string }[];
  /** Replay count (operator driven). */
  replays: number;
}

export interface ReconciliationException {
  id: string;
  adapter: string;
  eventId: string;
  /** What the event was about, e.g. "sale SALE-1" / "refund RF-1". */
  subject: string;
  severity: "HIGH" | "MEDIUM" | "LOW";
  kind: "UNAPPLIED_EVENT" | "UNAUTHENTIC_EVENT" | "PARTIAL_APPLICATION";
  detail: string;
  suggestedAction: string;
  createdAtMs: number;
  deadLetterId?: string;
}

/** Durable storage for events that could not be applied. */
export interface DeadLetterStore {
  add(dl: DeadLetter): Promise<void>;
  list(): Promise<DeadLetter[]>;
  get(id: string): Promise<DeadLetter | undefined>;
  update(dl: DeadLetter): Promise<void>;
  remove(id: string): Promise<void>;
}

/** Sink for reconciliation exceptions (feed it to finance/ops tooling, a ticket system, a JSONL file ...). */
export interface ReconciliationSink {
  report(e: ReconciliationException): Promise<void>;
}

export interface RetryPolicy {
  /** Attempts per request for transient failures (network, timeout, 5xx, not-yet-final). */
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  /** 0..1 random spread applied to every delay. */
  jitter: number;
  /** Fresh-tx-id attempts for retryable business rejections (out-of-order callbacks). */
  maxBusinessAttempts: number;
}

export const DEFAULT_RETRY: RetryPolicy = { maxAttempts: 5, baseDelayMs: 200, maxDelayMs: 10_000, jitter: 0.2, maxBusinessAttempts: 4 };
