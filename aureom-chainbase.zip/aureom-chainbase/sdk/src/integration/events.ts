// Outbound side: ChainEventSource tails FINALISED transactions through the gateway so external systems
// can react ("sale completed", "refund instructed", ...).
//
// THE CHAIN NEVER CALLS EXTERNAL APIs. This is a pull model: an external worker subscribes, performs
// the real-world action (charge the card, send the refund, ship the parcel) and then reports the
// RESULT back as an authenticated transaction (see PaymentProviderAdapter). An event is a statement
// that something was finalised on chain, not that anything happened in the outside world.
//
// Source of truth for ordering: the projection's transaction log (/api/v1/q/transactions), enriched
// per transaction with the decoded payload and result from /api/v1/explorer/tx/{id}. The projection is
// disposable: while it is REBUILDING the source simply waits (no events are emitted from a partial
// index) and resumes from its checkpoint afterwards. Delivery is AT LEAST ONCE (a checkpoint is saved
// after each event's handlers succeed); handlers must be idempotent - use event.txId.

import type { ListResponse, TransactionRow } from "../api-types.js";
import type { Client } from "../client.js";
import { sleep as realSleep } from "../http.js";
import type { JsonObject } from "../http.js";
import type { ChainRecordResponse } from "../proof.js";
import { MemoryCheckpointStore, type CheckpointStore, type Cursor } from "./stores.js";

export interface ChainEvent {
  /** Domain name, e.g. "sale.completed". Unmapped transaction types are "tx.<Type>". */
  name: string;
  txType: string;
  txId: string;
  height: number;
  index: number;
  blockTimeMs: number;
  signer: string;
  /** Decoded transaction payload. */
  payload: Record<string, unknown>;
  /** Result data returned by the state machine for this transaction. */
  result: Record<string, unknown>;
  /** State keys the transaction wrote. */
  recordsChanged: string[];
  /** Extra context fetched for some events (e.g. the refund record for refund.instructed). */
  details?: Record<string, unknown>;
}

export interface TxDetail {
  payload: Record<string, unknown>;
  result: Record<string, unknown>;
  recordsChanged: string[];
}

/** What the source needs from the gateway (mockable). */
export interface ChainReader {
  transactions(q: { status: "OK"; type?: string; from_height: number; limit: number; offset: number }): Promise<ListResponse<TransactionRow>>;
  txDetail(txId: string): Promise<TxDetail>;
  getRecord(key: string): Promise<ChainRecordResponse>;
}

export function readerFromClient(c: Client): ChainReader {
  return {
    transactions: (q) => c.q.transactions({ ...q }),
    txDetail: async (txId) => {
      const d = (await c.explorer.tx(txId)) as JsonObject & { body?: { payload?: unknown }; result?: { data?: unknown }; records_changed?: { key?: string }[] };
      const obj = (v: unknown): Record<string, unknown> => (v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
      return { payload: obj(d.body?.payload), result: obj(d.result?.data), recordsChanged: (d.records_changed ?? []).map((r) => r.key ?? "").filter(Boolean) };
    },
    getRecord: (key) => c.getRecord(key),
  };
}

const NAMES: Record<string, string> = {
  CompleteSale: "sale.completed",
  RecordPaymentResult: "payment.recorded",
  RecordRefundResult: "refund.recorded",
  RequestReturn: "return.requested",
  ApproveReturn: "return.approved",
  CreatePurchaseOrder: "purchase_order.created",
  ApprovePurchaseOrder: "purchase_order.approved",
  ReceiveGoods: "goods.received",
  ReserveStock: "stock.reserved",
  ReleaseReservation: "stock.released",
  CreditLoyalty: "loyalty.credited",
  RedeemLoyalty: "loyalty.redeemed",
  ReverseBusinessEntry: "entry.reversed",
};

export function eventNameFor(txType: string, result: Record<string, unknown>, payload: Record<string, unknown>): string {
  if (txType === "ReceiveReturnedGoods") return typeof result["refund_id"] === "string" && result["refund_id"] ? "refund.instructed" : "return.received";
  if (txType === "TransferStock") return `transfer.${String(payload["op"] ?? "").toLowerCase() || "update"}`;
  if (txType === "AdjustStock") return `adjustment.${String(payload["op"] ?? "").toLowerCase() || "update"}`;
  return NAMES[txType] ?? `tx.${txType}`;
}

/** Transaction types that can produce the given event name (so a subscriber queries only what it needs). */
function typesFor(name: string): string[] | undefined {
  if (name === "*") return undefined;
  if (name === "refund.instructed" || name === "return.received") return ["ReceiveReturnedGoods"];
  if (name.startsWith("transfer.")) return ["TransferStock"];
  if (name.startsWith("adjustment.")) return ["AdjustStock"];
  if (name.startsWith("tx.")) return [name.slice(3)];
  const hit = Object.entries(NAMES).find(([, n]) => n === name);
  return hit ? [hit[0]] : [];
}

export type ChainEventHandler = (e: ChainEvent) => void | Promise<void>;

export interface ChainEventSourceOptions {
  reader: ChainReader;
  checkpoint?: CheckpointStore;
  /** Where to start when there is no checkpoint: "now" (default), "beginning", or a block height. */
  startFrom?: "now" | "beginning" | number;
  pageSize?: number;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  onError?: (e: unknown) => void;
}

interface Sub {
  name: string;
  handler: ChainEventHandler;
}

export class ChainEventSource {
  private readonly o: ChainEventSourceOptions;
  private readonly checkpoint: CheckpointStore;
  private readonly subs: Sub[] = [];
  private readonly sleep: (ms: number) => Promise<void>;

  constructor(opts: ChainEventSourceOptions) {
    this.o = opts;
    this.checkpoint = opts.checkpoint ?? new MemoryCheckpointStore();
    this.sleep = opts.sleep ?? realSleep;
  }

  /** Subscribe to one event name ("sale.completed", "refund.instructed", ...) or "*". Returns an unsubscribe function. */
  on(name: string, handler: ChainEventHandler): () => void {
    const s = { name, handler };
    this.subs.push(s);
    return () => {
      const i = this.subs.indexOf(s);
      if (i >= 0) this.subs.splice(i, 1);
    };
  }

  private wantedTypes(): (string | undefined)[] {
    const all = new Set<string | undefined>();
    for (const s of this.subs) {
      const t = typesFor(s.name);
      if (t === undefined) return [undefined]; // wildcard: everything
      for (const x of t) all.add(x);
    }
    return [...all];
  }

  private async cursor(): Promise<Cursor> {
    const saved = await this.checkpoint.load();
    if (saved) return saved;
    const from = this.o.startFrom ?? "now";
    let c: Cursor;
    if (from === "beginning") c = { height: 0, index: -1 };
    else if (typeof from === "number") c = { height: Math.max(0, from - 1), index: Number.MAX_SAFE_INTEGER };
    else {
      const head = await this.o.reader.transactions({ status: "OK", from_height: 0, limit: 1, offset: 0 });
      c = { height: head.meta.indexed_height, index: Number.MAX_SAFE_INTEGER };
    }
    await this.checkpoint.save(c);
    return c;
  }

  /**
   * One polling step: fetch finalised transactions after the checkpoint, deliver them in chain order,
   * advance the checkpoint after each. Returns the events delivered. A handler error stops the step
   * (the failed event is redelivered next time) and is rethrown after the checkpoint is saved.
   */
  async poll(): Promise<ChainEvent[]> {
    if (this.subs.length === 0) return [];
    let cursor = await this.cursor();
    const after = (h: number, i: number) => h > cursor.height || (h === cursor.height && i > cursor.index);
    const rows = new Map<string, TransactionRow & { index_in_block: number }>();
    let indexedHeight = 0;
    for (const type of this.wantedTypes()) {
      const pageSize = this.o.pageSize ?? 200;
      for (let offset = 0; ; offset += pageSize) {
        const page = await this.o.reader.transactions({ status: "OK", ...(type ? { type } : {}), from_height: cursor.height, limit: pageSize, offset });
        if (page.meta.projection_state !== "OK") return []; // rebuilding: never emit from a partial index
        indexedHeight = Math.max(indexedHeight, page.meta.indexed_height);
        for (const r of page.items as (TransactionRow & { index_in_block?: number })[]) {
          const idx = r.index_in_block ?? 0;
          const id = r.tx_id ?? r.id ?? "";
          if (id && after(r.height, idx)) rows.set(id, { ...r, index_in_block: idx });
        }
        if (page.items.length < pageSize || offset + pageSize >= page.total) break;
      }
    }
    const ordered = [...rows.values()].filter((r) => r.height <= indexedHeight).sort((a, b) => a.height - b.height || a.index_in_block - b.index_in_block);
    const delivered: ChainEvent[] = [];
    for (const r of ordered) {
      const txId = (r.tx_id ?? r.id) as string;
      const d = await this.o.reader.txDetail(txId);
      const name = eventNameFor(r.type, d.result, d.payload);
      const ev: ChainEvent = { name, txType: r.type, txId, height: r.height, index: r.index_in_block, blockTimeMs: r.block_time_ms, signer: r.signer, payload: d.payload, result: d.result, recordsChanged: d.recordsChanged };
      if (name === "refund.instructed" && typeof d.result["refund_id"] === "string") {
        const rf = await this.o.reader.getRecord(`refund/${d.result["refund_id"]}`);
        if (rf.found && rf.value && typeof rf.value === "object") ev.details = { refund: rf.value as Record<string, unknown> };
      }
      const targets = this.subs.filter((s) => s.name === "*" || s.name === name);
      try {
        for (const s of targets) await s.handler(ev);
      } catch (e) {
        this.o.onError?.(e);
        throw e;
      }
      cursor = { height: r.height, index: r.index_in_block };
      await this.checkpoint.save(cursor);
      delivered.push(ev);
    }
    return delivered;
  }

  /** Poll until the signal aborts. Errors (gateway down, handler failure) are reported via onError and retried. */
  async run(opts: { intervalMs?: number; signal?: AbortSignal } = {}): Promise<void> {
    const interval = opts.intervalMs ?? 1000;
    while (!opts.signal?.aborted) {
      try {
        await this.poll();
      } catch (e) {
        this.o.onError?.(e);
      }
      await this.sleep(interval);
    }
  }
}
