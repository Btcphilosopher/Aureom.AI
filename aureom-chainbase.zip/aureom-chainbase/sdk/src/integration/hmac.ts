// Webhook authentication: HMAC-SHA256 over `<timestamp>.<raw body>` with a replay window and a
// constant-time comparison. Provider-specific schemes plug in through WebhookVerifier.

import { hmac } from "@noble/hashes/hmac.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes, utf8 } from "../encoding.js";
import type { VerifyResult } from "./types.js";

/** What an HTTP edge hands to an adapter: the RAW body (the signature covers exact bytes) and the headers. */
export interface WebhookInbound {
  rawBody: string;
  /** Header names are matched case-insensitively. */
  headers: Record<string, string>;
}

/** Provider-specific verification (Stripe-like, Adyen-like, mTLS, JWT ...). Pluggable into PaymentProviderAdapter. */
export interface WebhookVerifier {
  verify(inbound: WebhookInbound, nowMs: number): VerifyResult;
}

/** Constant-time equality for two byte strings of the same length (length itself is not secret). */
export function constantTimeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i]! ^ b[i]!;
  return d === 0;
}

export function hmacSha256Hex(secret: string, message: string): string {
  return bytesToHex(hmac(sha256, utf8(secret), utf8(message)));
}

export interface HmacVerifierOptions {
  /** Shared secret(s). Several secrets allow rotation: a signature matching ANY of them is accepted. */
  secrets: string[];
  /** Header carrying `t=<unix seconds>,v1=<hex>[,v1=<hex>...]`. Default "x-signature". */
  header?: string;
  /** Maximum clock difference in either direction. Default 5 minutes. */
  toleranceMs?: number;
}

/**
 * Scheme: header `X-Signature: t=<unix seconds>,v1=<hex(HMAC-SHA256(secret, "<t>.<rawBody>"))>`.
 * Rejects: missing/malformed header, timestamps outside the tolerance (REPLAY of an old capture or a
 * far-future stamp), and any signature that does not match. The comparison is constant-time.
 */
export class HmacSha256Verifier implements WebhookVerifier {
  private readonly secrets: string[];
  private readonly header: string;
  private readonly toleranceMs: number;

  constructor(opts: HmacVerifierOptions) {
    if (opts.secrets.length === 0 || opts.secrets.some((s) => s.length < 16)) throw new Error("HMAC secrets must be at least 16 characters; generate them randomly");
    this.secrets = opts.secrets;
    this.header = (opts.header ?? "x-signature").toLowerCase();
    this.toleranceMs = opts.toleranceMs ?? 5 * 60_000;
  }

  verify(inbound: WebhookInbound, nowMs: number): VerifyResult {
    const headers = Object.fromEntries(Object.entries(inbound.headers).map(([k, v]) => [k.toLowerCase(), v]));
    const raw = headers[this.header];
    if (!raw) return { ok: false, code: "MISSING_SIGNATURE", reason: `no ${this.header} header` };
    let t: number | undefined;
    const candidates: Uint8Array[] = [];
    for (const part of raw.split(",")) {
      const [k, v] = [part.slice(0, part.indexOf("=")).trim(), part.slice(part.indexOf("=") + 1).trim()];
      if (k === "t" && /^\d{1,12}$/.test(v)) t = Number(v);
      else if (k === "v1" && /^[0-9a-fA-F]{64}$/.test(v)) candidates.push(hexToBytes(v));
    }
    if (t === undefined || candidates.length === 0) return { ok: false, code: "MALFORMED_SIGNATURE", reason: "expected t=<unix seconds>,v1=<64 hex>" };
    if (Math.abs(nowMs - t * 1000) > this.toleranceMs) {
      return { ok: false, code: "TIMESTAMP_OUT_OF_TOLERANCE", reason: `timestamp ${t} is ${Math.round(Math.abs(nowMs - t * 1000) / 1000)}s away from now (tolerance ${Math.round(this.toleranceMs / 1000)}s): possible replay` };
    }
    const signed = `${t}.${inbound.rawBody}`;
    let match = false;
    for (const secret of this.secrets) {
      const expected = hmac(sha256, utf8(secret), utf8(signed));
      for (const c of candidates) if (constantTimeEqual(expected, c)) match = true; // no early exit: constant work
    }
    return match ? { ok: true } : { ok: false, code: "BAD_SIGNATURE", reason: "signature does not match" };
  }
}

/** Produce the header an HMAC-signing sender would attach (used by simulators and tests). */
export function signWebhook(secret: string, rawBody: string, nowMs: number): { "x-signature": string } {
  const t = Math.floor(nowMs / 1000);
  return { "x-signature": `t=${t},v1=${hmacSha256Hex(secret, `${t}.${rawBody}`)}` };
}
