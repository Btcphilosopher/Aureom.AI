// AdapterRunner: verify -> translate -> sign -> submit (retry/backoff) -> dead letter + reconciliation.
//
// Retry model (and why it is safe):
//  * Transient failures (network error, timeout, HTTP 5xx/429, admitted-but-not-final): the SAME signed
//    transaction is re-sent after a backoff, but only after asking the chain whether the first attempt
//    already finalised (an answer lost on the wire must not become a second execution). Even if it did
//    run twice, the idempotency_ref (derived from the external event id) makes the chain reject the second.
//  * Retryable BUSINESS rejections (for example NOT_FOUND because a callback arrived before the record it
//    refers to; the chain reports it at admission or, if the record vanished in between, after ordering): the
//    request is re-signed with a FRESH tx id (a finalised rejection burns the old id). The idempotency_ref stays the same - the chain allows reuse after a rejection.
//  * Everything else is permanent: the event is dead-lettered and a reconciliation exception is emitted.

import { codeName } from "../codes.js";
import { GatewayError, KeyStoreError, NetworkError, TimeoutError } from "../errors.js";
import { newBusinessId } from "../ids.js";
import { Signer, type KeyStore } from "../keystore.js";
import { outcomeOf, type SubmitOptions } from "../client.js";
import type { SubmitResponse, TxOutcome, TxStatus } from "../api-types.js";
import { sleep as realSleep } from "../http.js";
import { TxBuilder, type SignedTx } from "../tx.js";
import { MemoryDeadLetterStore, MemoryReconciliationSink } from "./stores.js";
import {
  AdapterRejection,
  DEFAULT_RETRY,
  type AppliedRequest,
  type DeadLetter,
  type DeadLetterStore,
  type FailureInfo,
  type IntegrationAdapter,
  type ReconciliationException,
  type ReconciliationSink,
  type RetryPolicy,
  type TxRequest,
  type VerifyResult,
} from "./types.js";

/** The slice of Client the runner needs (mockable). */
export interface TxSubmitter {
  submit(tx: SignedTx, opts?: SubmitOptions): Promise<SubmitResponse>;
  txStatus(txId: string): Promise<TxStatus>;
}

export type HandleStatus = "APPLIED" | "DUPLICATE" | "REJECTED_UNAUTHENTIC" | "DEAD_LETTERED";

export interface HandleResult {
  status: HandleStatus;
  adapter: string;
  eventId?: string;
  applied: AppliedRequest[];
  failure?: FailureInfo;
  deadLetter?: DeadLetter;
  exception?: ReconciliationException;
}

export type RunnerLog =
  | { type: "unauthentic"; adapter: string; code: string; reason: string }
  | { type: "retry"; adapter: string; eventId: string; txId: string; attempt: number; delayMs: number; reason: string }
  | { type: "business_retry"; adapter: string; eventId: string; codeName: string; attempt: number; delayMs: number }
  | { type: "applied"; adapter: string; eventId: string; requests: number; duplicate: boolean }
  | { type: "dead_letter"; adapter: string; eventId: string; id: string; failure: FailureInfo };

export interface RunnerOptions<TEvent> {
  adapter: IntegrationAdapter<TEvent>;
  /** Holds the service identity keys (never the private key in the adapter). */
  keys: KeyStore;
  networkId: string;
  gateway: TxSubmitter;
  deadLetters?: DeadLetterStore;
  reconciliation?: ReconciliationSink;
  retry?: Partial<RetryPolicy>;
  /** Server-side finality wait per submit. Default 15000. */
  submitTimeoutMs?: number;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  newId?: () => string;
  log?: (e: RunnerLog) => void;
}

class TransientExhausted extends Error {
  constructor(
    readonly attempts: number,
    readonly last: string,
    readonly txId: string,
  ) {
    super(`gave up after ${attempts} attempts: ${last}`);
  }
}
class RequestFailure extends Error {
  constructor(readonly info: FailureInfo) {
    super(info.reason);
  }
}

function isTransient(e: unknown): boolean {
  return e instanceof NetworkError || e instanceof TimeoutError || (e instanceof GatewayError && (e.status >= 500 || e.status === 429));
}

export class AdapterRunner<TEvent> {
  readonly deadLetters: DeadLetterStore;
  readonly reconciliation: ReconciliationSink;
  private readonly o: RunnerOptions<TEvent>;
  private readonly retry: RetryPolicy;
  private readonly builders = new Map<string, TxBuilder>();
  private readonly now: () => number;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly random: () => number;
  private seq = 0;

  constructor(opts: RunnerOptions<TEvent>) {
    this.o = opts;
    this.retry = { ...DEFAULT_RETRY, ...opts.retry };
    this.deadLetters = opts.deadLetters ?? new MemoryDeadLetterStore();
    this.reconciliation = opts.reconciliation ?? new MemoryReconciliationSink();
    this.now = opts.now ?? Date.now;
    this.sleep = opts.sleep ?? realSleep;
    this.random = opts.random ?? Math.random;
  }

  private newId(prefix: string): string {
    return this.o.newId ? `${prefix}-${this.o.newId()}` : newBusinessId(prefix, this.now());
  }

  private async builder(identity: string): Promise<TxBuilder> {
    let b = this.builders.get(identity);
    if (!b) {
      const signer = await Signer.forIdentity(this.o.keys, identity);
      b = new TxBuilder({ networkId: this.o.networkId, signer, now: this.now });
      this.builders.set(identity, b);
    }
    return b;
  }

  private delay(attempt: number): number {
    const base = Math.min(this.retry.maxDelayMs, this.retry.baseDelayMs * 2 ** (attempt - 1));
    return Math.max(0, Math.round(base * (1 + this.retry.jitter * (this.random() * 2 - 1))));
  }

  /**
   * Process one inbound event end to end. Never throws for event-level problems: the result says what
   * happened. `skipVerify` is for replaying a dead letter that was already authenticated on first intake.
   */
  async handle(event: TEvent, opts: { skipVerify?: boolean; replayOf?: string } = {}): Promise<HandleResult> {
    const a = this.o.adapter;
    const receivedAtMs = this.now();
    const ctx = { now: receivedAtMs };

    if (!opts.skipVerify) {
      let v: VerifyResult;
      try {
        v = await a.verify(event, ctx);
      } catch (e) {
        v = { ok: false as const, code: "VERIFY_ERROR", reason: e instanceof Error ? e.message : String(e) };
      }
      if (!v.ok) {
        this.o.log?.({ type: "unauthentic", adapter: a.name, code: v.code, reason: v.reason });
        const exception = await this.raise({ adapter: a.name, eventId: "unknown", subject: "unauthenticated inbound event", severity: "MEDIUM", kind: "UNAUTHENTIC_EVENT", detail: `${v.code}: ${v.reason}`, suggestedAction: "Nothing was applied. If the sender is legitimate, check its signing secret / clock; otherwise treat as an attempted forgery or replay." });
        return { status: "REJECTED_UNAUTHENTIC", adapter: a.name, applied: [], failure: { stage: "authentication", code: v.code, reason: v.reason, attempts: 0, transient: false }, exception };
      }
    }

    let eventId = "unknown";
    let requests: TxRequest[];
    try {
      eventId = a.eventId(event);
      requests = await a.translate(event, ctx);
    } catch (e) {
      const failure: FailureInfo = { stage: "translation", code: e instanceof AdapterRejection ? e.code : "TRANSLATION_ERROR", reason: e instanceof Error ? e.message : String(e), attempts: 0, transient: false };
      return this.fail(event, eventId, receivedAtMs, failure, [], opts.replayOf);
    }

    const applied: AppliedRequest[] = [];
    for (const req of requests) {
      try {
        applied.push(await this.apply(req, eventId));
      } catch (e) {
        let failure: FailureInfo;
        if (e instanceof RequestFailure) failure = e.info;
        else if (e instanceof TransientExhausted) failure = { stage: "submission", code: "TRANSIENT_EXHAUSTED", reason: e.message, request: req, txId: e.txId, attempts: e.attempts, transient: true };
        else throw e;
        if (a.compensate && applied.length > 0) {
          for (const c of a.compensate(event, applied)) {
            try {
              await this.apply(c, eventId);
            } catch {
              /* best effort: the reconciliation exception tells a human what remains */
            }
          }
        }
        return this.fail(event, eventId, receivedAtMs, failure, applied, opts.replayOf);
      }
    }
    const allDup = applied.length > 0 && applied.every((x) => x.duplicate);
    this.o.log?.({ type: "applied", adapter: a.name, eventId, requests: applied.length, duplicate: allDup });
    if (opts.replayOf) await this.deadLetters.remove(opts.replayOf);
    return { status: allDup ? "DUPLICATE" : "APPLIED", adapter: a.name, eventId, applied };
  }

  /** Re-run a dead letter (an operator decided the cause is fixed). It is removed on success, updated on failure. */
  async replayDeadLetter(id: string): Promise<HandleResult> {
    const dl = await this.deadLetters.get(id);
    if (!dl) throw new Error(`no dead letter ${id}`);
    return this.handle(dl.event as TEvent, { skipVerify: true, replayOf: id });
  }

  // ---- one request -------------------------------------------------------------------------

  private async apply(req: TxRequest, eventId: string): Promise<AppliedRequest> {
    let builder: TxBuilder;
    try {
      builder = await this.builder(req.signer);
    } catch (e) {
      if (e instanceof KeyStoreError) throw new RequestFailure({ stage: "submission", code: e.code, reason: `no signing key for service identity ${req.signer}: ${e.message}`, request: req, attempts: 0, transient: false });
      throw e;
    }
    const retryable = new Set(this.o.adapter.retryableBusinessCodes?.() ?? []);
    let totalAttempts = 0;
    for (let businessAttempt = 1; ; businessAttempt++) {
      const tx = await builder.build(req.type, req.payload, { idempotencyRef: req.idempotencyRef, ...(req.expectedVersion !== undefined ? { expectedVersion: req.expectedVersion } : {}) });
      const sub = await this.submitTransient(tx, eventId);
      totalAttempts += sub.attempts;
      const o = sub.outcome;
      if (o.status === "FINALISED_OK") {
        return { request: req, txId: tx.txId, height: o.height, duplicate: o.data["deduplicated"] === true, data: o.data, attempts: totalAttempts };
      }
      if (o.status === "ADMISSION_REJECTED") {
        if (o.code === 211) return { request: req, txId: tx.txId, height: 0, duplicate: true, attempts: totalAttempts }; // idempotency_ref already executed: applied earlier
        // The authorisation stage looks records up (for example the sale a payment refers to), so an
        // out-of-order callback is refused at ADMISSION with NOT_FOUND - not only after ordering.
        if (retryable.has(o.code) && businessAttempt < this.retry.maxBusinessAttempts) {
          const d = this.delay(businessAttempt);
          this.o.log?.({ type: "business_retry", adapter: this.o.adapter.name, eventId, codeName: o.codeName, attempt: businessAttempt, delayMs: d });
          await this.sleep(d);
          continue;
        }
        throw new RequestFailure({ stage: "submission", code: o.codeName, codeName: o.codeName, reason: o.log, request: req, txId: tx.txId, attempts: totalAttempts, transient: false });
      }
      if (o.status === "FINALISED_REJECTED") {
        if (retryable.has(o.code) && businessAttempt < this.retry.maxBusinessAttempts) {
          const d = this.delay(businessAttempt);
          this.o.log?.({ type: "business_retry", adapter: this.o.adapter.name, eventId, codeName: o.codeName, attempt: businessAttempt, delayMs: d });
          await this.sleep(d);
          continue; // fresh tx id on the next loop, same idempotency_ref
        }
        throw new RequestFailure({ stage: "business", code: o.codeName, codeName: o.codeName, reason: o.log, request: req, txId: tx.txId, attempts: totalAttempts, transient: false });
      }
      throw new TransientExhausted(totalAttempts, "admitted but never observed final", tx.txId);
    }
  }

  /** Submit the SAME signed tx until it is final or attempts run out. */
  private async submitTransient(tx: SignedTx, eventId: string): Promise<{ outcome: TxOutcome; attempts: number }> {
    let last = "";
    for (let attempt = 1; attempt <= this.retry.maxAttempts; attempt++) {
      try {
        const resp = await this.o.gateway.submit(tx, { wait: "final", timeoutMs: this.o.submitTimeoutMs ?? 15_000 });
        const o = outcomeOf(resp);
        if (o.status !== "ADMITTED_NOT_FINAL") return { outcome: o, attempts: attempt };
        const resolved = await this.statusOutcome(tx.txId);
        if (resolved) return { outcome: resolved, attempts: attempt };
        last = "admitted, not yet final";
      } catch (e) {
        if (!isTransient(e)) {
          throw new RequestFailure({ stage: "submission", code: e instanceof GatewayError ? `HTTP_${e.status}` : "SUBMIT_ERROR", reason: e instanceof Error ? e.message : String(e), txId: tx.txId, attempts: attempt, transient: false });
        }
        last = e instanceof Error ? e.message : String(e);
        // the answer may have been lost AFTER execution: the chain is the source of truth
        const resolved = await this.statusOutcome(tx.txId).catch(() => undefined);
        if (resolved) return { outcome: resolved, attempts: attempt };
      }
      if (attempt < this.retry.maxAttempts) {
        const d = this.delay(attempt);
        this.o.log?.({ type: "retry", adapter: this.o.adapter.name, eventId, txId: tx.txId, attempt, delayMs: d, reason: last });
        await this.sleep(d);
      }
    }
    throw new TransientExhausted(this.retry.maxAttempts, last, tx.txId);
  }

  private async statusOutcome(txId: string): Promise<TxOutcome | undefined> {
    const st = await this.o.gateway.txStatus(txId);
    if (st.status === "FINALISED_OK") return { status: "FINALISED_OK", height: st.height ?? 0, index: st.index ?? 0, data: {}, indexed: st.indexed === true };
    if (st.status === "FINALISED_REJECTED") return { status: "FINALISED_REJECTED", height: st.height ?? 0, index: st.index ?? 0, code: st.code ?? 0, codeName: st.code_name ?? codeName(st.code ?? 0), log: st.reason ?? "" };
    return undefined;
  }

  // ---- failure handling --------------------------------------------------------------------

  private async raise(e: Omit<ReconciliationException, "id" | "createdAtMs">): Promise<ReconciliationException> {
    const full: ReconciliationException = { ...e, id: this.newId("RECON"), createdAtMs: this.now() };
    await this.reconciliation.report(full);
    return full;
  }

  private async fail(event: TEvent, eventId: string, receivedAtMs: number, failure: FailureInfo, applied: AppliedRequest[], replayOf: string | undefined): Promise<HandleResult> {
    const a = this.o.adapter;
    const summary = applied.map((x) => ({ type: x.request.type, txId: x.txId, height: x.height, idempotencyRef: x.request.idempotencyRef }));
    let dl: DeadLetter;
    const existing = replayOf ? await this.deadLetters.get(replayOf) : undefined;
    if (existing) {
      dl = { ...existing, failedAtMs: this.now(), failure, applied: summary, replays: existing.replays + 1 };
      await this.deadLetters.update(dl);
    } else {
      dl = { id: this.newId("DLQ"), adapter: a.name, eventId, receivedAtMs, failedAtMs: this.now(), failure, event: structuredClone(event), applied: summary, replays: 0 };
      await this.deadLetters.add(dl);
    }
    this.o.log?.({ type: "dead_letter", adapter: a.name, eventId, id: dl.id, failure });
    const partial = applied.length > 0;
    const exception = await this.raise({
      adapter: a.name,
      eventId,
      subject: failure.request ? `${failure.request.type}${failure.request.label ? ` (${failure.request.label})` : ""}` : "event",
      severity: partial ? "HIGH" : "MEDIUM",
      kind: partial ? "PARTIAL_APPLICATION" : "UNAPPLIED_EVENT",
      detail: `${failure.stage}/${failure.code}: ${failure.reason}${partial ? ` - ${applied.length} request(s) already applied: ${summary.map((s) => s.type).join(", ")}` : ""}`,
      suggestedAction: a.suggestAction?.(event, failure) ?? defaultAction(failure, partial),
      deadLetterId: dl.id,
    });
    return { status: "DEAD_LETTERED", adapter: a.name, eventId, applied, failure, deadLetter: dl, exception };
  }
}

function defaultAction(f: FailureInfo, partial: boolean): string {
  if (f.transient) return "The gateway/network was unavailable for the whole retry budget. Check connectivity, then replay the dead letter (runner.replayDeadLetter).";
  if (partial) return "Part of the event is already on chain. Review the applied requests, fix the cause of the rejection and replay the dead letter; idempotency refs make the already-applied requests safe to repeat.";
  return `The chain rejected the request (${f.code}). Fix the cause (missing record, wrong amount, missing permission ...) and replay the dead letter, or resolve it manually and remove it.`;
}
