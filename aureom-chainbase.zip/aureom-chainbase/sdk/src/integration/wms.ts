// Warehouse-management-system adapter (example): scan events -> ReceiveGoods / TransferStock / AdjustStock PROPOSE.
//
// The adapter only PROPOSES stock adjustments from cycle counts. Approval is a separate, different
// human (maker-checker enforced on chain), so a scanner can never change the ledger on its own say-so.

import { AdapterRejection, request, type IntegrationAdapter, type TxRequest, type VerifyResult } from "./types.js";
import { idempotencyRefFor, toChainId } from "./util.js";

export type WmsEvent =
  | { kind: "RECEIVE_SCAN"; event_id: string; location_id: string; po_number?: string; supplier_id?: string; effective_at_ms: number; lines: { sku: string; qty_v: number; unit: string; po_line?: number }[] }
  | { kind: "DISPATCH_SCAN"; event_id: string; transfer_no: string; from_location: string; to_location: string; lines: { sku: string; qty_v: number; unit: string }[] }
  | { kind: "TRANSFER_RECEIVE_SCAN"; event_id: string; transfer_no: string; lines: { sku: string; qty_v: number; unit: string; damaged_v?: number }[] }
  | { kind: "CYCLE_COUNT"; event_id: string; location_id: string; sku: string; bucket: "available" | "quarantined" | "damaged"; counted_v: number; reason: string; evidence_ref?: string };

export interface WmsAdapterOptions {
  /** Warehouse operator identity (goods.receive, transfer.*, stock.adjust.propose). Default wh-operator-dist. */
  serviceIdentity?: string;
  /** Scanner / device ids that may post (transport authentication is a deployment concern). */
  allowedDevices?: string[];
}

export class WarehouseAdapter implements IntegrationAdapter<WmsEvent & { device_id?: string }> {
  readonly name = "wms:scan-events";
  private readonly identity: string;
  private readonly devices: Set<string> | undefined;

  constructor(opts: WmsAdapterOptions = {}) {
    this.identity = opts.serviceIdentity ?? "wh-operator-dist";
    this.devices = opts.allowedDevices ? new Set(opts.allowedDevices) : undefined;
  }

  verify(e: WmsEvent & { device_id?: string }): VerifyResult {
    if (!e?.event_id) return { ok: false, code: "BAD_EVENT", reason: "missing event_id" };
    if (this.devices && !(e.device_id && this.devices.has(e.device_id))) return { ok: false, code: "UNKNOWN_DEVICE", reason: `device ${String(e.device_id)} is not registered` };
    return { ok: true };
  }

  eventId(e: WmsEvent): string {
    return e.event_id;
  }

  retryableBusinessCodes(): number[] {
    return [401]; // a transfer receive scanned before the dispatch scan reached the chain
  }

  translate(e: WmsEvent): TxRequest[] {
    switch (e.kind) {
      case "RECEIVE_SCAN":
        if (!e.po_number && !e.supplier_id) throw new AdapterRejection("NO_SOURCE", "a receipt needs a purchase order or a supplier");
        return [
          request(
            this.identity,
            "ReceiveGoods",
            {
              receipt_id: toChainId("RCPT-", e.event_id),
              location_id: e.location_id,
              ...(e.po_number ? { po_id: toChainId("PO-", e.po_number) } : { supplier_id: e.supplier_id as string }),
              effective_at_ms: e.effective_at_ms,
              lines: e.lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, ...(l.po_line !== undefined ? { po_line: l.po_line } : {}) })),
            },
            idempotencyRefFor("wms-receive", e.event_id),
            `receive at ${e.location_id}`,
          ),
        ];
      case "DISPATCH_SCAN":
        return [
          request(
            this.identity,
            "TransferStock",
            { op: "DISPATCH", transfer_id: toChainId("XFER-", e.transfer_no), from_location: e.from_location, to_location: e.to_location, lines: e.lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit } })) },
            idempotencyRefFor("wms-dispatch", e.event_id),
            `dispatch ${e.transfer_no}`,
          ),
        ];
      case "TRANSFER_RECEIVE_SCAN":
        return [
          request(
            this.identity,
            "TransferStock",
            { op: "RECEIVE", transfer_id: toChainId("XFER-", e.transfer_no), lines: e.lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, ...(l.damaged_v ? { damaged_v: l.damaged_v } : {}) })) },
            idempotencyRefFor("wms-xfer-receive", e.event_id),
            `receive transfer ${e.transfer_no}`,
          ),
        ];
      case "CYCLE_COUNT":
        return [
          request(
            this.identity,
            "AdjustStock",
            { op: "PROPOSE", adjustment_id: toChainId("ADJ-", e.event_id), location_id: e.location_id, sku: e.sku, bucket: e.bucket, counted_v: e.counted_v, reason: e.reason, ...(e.evidence_ref ? { evidence_ref: e.evidence_ref } : {}) },
            idempotencyRefFor("wms-count", e.event_id),
            `count ${e.sku} at ${e.location_id}`,
          ),
        ];
    }
  }

  suggestAction(e: WmsEvent): string {
    return `Check ${e.kind} ${e.event_id} against chain state (stock balance / transfer record); re-scan if the device posted wrong data, then replay the dead letter.`;
  }
}
