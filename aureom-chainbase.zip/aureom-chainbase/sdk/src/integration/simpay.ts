// SimulatedPaymentProvider: the SIMPAY provider used by the demo. It shows the shape any real provider
// adapter (card acquirer, PSP, bank) follows: (1) a verifier for the provider's signature scheme,
// (2) parseWebhook() mapping the provider's JSON to NormalisedPaymentEvent.

import { signWebhook, HmacSha256Verifier, type WebhookInbound, type WebhookVerifier } from "./hmac.js";
import { assertCurrency, PaymentProviderAdapter, type NormalisedPaymentEvent, type PaymentAdapterOptions } from "./payment.js";
import { AdapterRejection } from "./types.js";

/** The JSON body SIMPAY posts to our webhook. */
export interface SimPayWebhook {
  id: string;
  type: "payment.succeeded" | "payment.failed" | "refund.succeeded" | "refund.failed";
  /** Unix seconds. */
  created: number;
  data: {
    /** Our sale id (payments) - the merchant reference we passed when instructing the charge. */
    sale_id?: string;
    /** Our refund id (refunds). */
    refund_id?: string;
    /** SIMPAY's charge / refund reference. */
    reference: string;
    /** Minor units. */
    amount: number;
    currency: string;
  };
}

export interface SimulatedPaymentProviderOptions extends Partial<PaymentAdapterOptions> {
  /** Webhook signing secret(s) shared with SIMPAY. Ignored if a custom verifier is given. */
  secrets?: string[];
  toleranceMs?: number;
}

export class SimulatedPaymentProvider extends PaymentProviderAdapter {
  readonly name = "payments:SIMPAY";
  static readonly PROVIDER = "SIMPAY";

  constructor(opts: SimulatedPaymentProviderOptions = {}) {
    super({ verifier: SimulatedPaymentProvider.verifierFor(opts), ...(opts.serviceIdentity ? { serviceIdentity: opts.serviceIdentity } : {}) });
  }

  private static verifierFor(opts: SimulatedPaymentProviderOptions): WebhookVerifier {
    return opts.verifier ?? new HmacSha256Verifier({ secrets: opts.secrets ?? ["simpay-demo-secret-change-me"], ...(opts.toleranceMs !== undefined ? { toleranceMs: opts.toleranceMs } : {}) });
  }

  parseWebhook(rawBody: string): NormalisedPaymentEvent {
    let w: SimPayWebhook;
    try {
      w = JSON.parse(rawBody) as SimPayWebhook;
    } catch {
      throw new AdapterRejection("BAD_JSON", "webhook body is not JSON");
    }
    if (!w || typeof w.id !== "string" || !w.data || typeof w.data.reference !== "string" || typeof w.data.amount !== "number") throw new AdapterRejection("BAD_SHAPE", "unexpected SIMPAY webhook shape");
    const kind = ({ "payment.succeeded": "PAYMENT_CONFIRMED", "payment.failed": "PAYMENT_FAILED", "refund.succeeded": "REFUND_CONFIRMED", "refund.failed": "REFUND_FAILED" } as const)[w.type];
    if (!kind) throw new AdapterRejection("UNSUPPORTED_EVENT", `SIMPAY event type ${String(w.type)} is not handled`);
    let currency;
    try {
      currency = assertCurrency(w.data.currency);
    } catch {
      throw new AdapterRejection("BAD_CURRENCY", `unsupported currency ${w.data.currency}`);
    }
    return {
      kind,
      provider: SimulatedPaymentProvider.PROVIDER,
      eventId: w.id,
      providerRef: w.data.reference,
      amountMinor: w.data.amount,
      currency,
      ...(w.data.sale_id ? { saleId: w.data.sale_id } : {}),
      ...(w.data.refund_id ? { refundId: w.data.refund_id } : {}),
    };
  }
}

/** The provider's side of the wire (for demos and tests): build and sign a webhook delivery. */
export function simPayDelivery(secret: string, event: SimPayWebhook, nowMs: number = event.created * 1000): WebhookInbound {
  const rawBody = JSON.stringify(event);
  return { rawBody, headers: { "content-type": "application/json", ...signWebhook(secret, rawBody, nowMs) } };
}
