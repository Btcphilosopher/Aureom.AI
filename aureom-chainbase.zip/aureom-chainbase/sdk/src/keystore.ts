// Signing-key storage interfaces (browser-safe). File-backed stores live in the Node-only entry
// point (src/node.ts): RawKeyFileStore and EncryptedFileKeyStore.
//
// Design rule: callers ask the store to SIGN; they never ask for the private key. That keeps the
// door open for hardware modules / cloud KMS where the key cannot leave the device
// (see ExternalSignerKeyStore).

import { ed25519 } from "@noble/curves/ed25519.js";
import { bytesEqual, bytesToBase64, wipe } from "./encoding.js";
import { KeyStoreError } from "./errors.js";

/** Store-local reference to one key: `<identity>#<key_id>` (key_id is the on-chain key id, e.g. "k1"). */
export type KeyRef = string;

export function keyRef(identity: string, keyId: string): KeyRef {
  return `${identity}#${keyId}`;
}

export interface KeyInfo {
  ref: KeyRef;
  /** On-chain identity id (the `signer` of transactions), e.g. "term-n01-1". */
  identity: string;
  /** On-chain key id (the `key_id` of transactions), e.g. "k1". */
  keyId: string;
  /** Raw 32-byte Ed25519 public key. */
  publicKey: Uint8Array;
}

export interface KeyStore {
  /** Public descriptions of every key the store holds (never secret material). */
  list(): Promise<KeyInfo[]>;
  publicKey(ref: KeyRef): Promise<Uint8Array>;
  /** Raw Ed25519 signature (64 bytes) over `message`. */
  sign(ref: KeyRef, message: Uint8Array): Promise<Uint8Array>;
}

/** A store that can mint new keys (needed for key rotation). */
export interface KeyGeneratingStore extends KeyStore {
  generate(identity: string, keyId: string): Promise<KeyInfo>;
  /** Forget a key (e.g. a rotation that was rejected on chain). Optional. */
  remove?(ref: KeyRef): Promise<void>;
}

/** Binds a key reference to the (identity, key_id) pair that goes into every transaction. */
export class Signer {
  readonly store: KeyStore;
  readonly ref: KeyRef;
  readonly identity: string;
  readonly keyId: string;
  readonly publicKey: Uint8Array;

  constructor(store: KeyStore, info: KeyInfo) {
    this.store = store;
    this.ref = info.ref;
    this.identity = info.identity;
    this.keyId = info.keyId;
    this.publicKey = info.publicKey;
  }

  get publicKeyB64(): string {
    return bytesToBase64(this.publicKey);
  }

  sign(message: Uint8Array): Promise<Uint8Array> {
    return this.store.sign(this.ref, message);
  }

  /** Signer for an exact key reference. */
  static async fromRef(store: KeyStore, ref: KeyRef): Promise<Signer> {
    const info = (await store.list()).find((k) => k.ref === ref);
    if (!info) throw new KeyStoreError("KEY_NOT_FOUND", `no key ${ref} in store`);
    return new Signer(store, info);
  }

  /** Signer for an identity: its key `keyId`, or (default) the most recently added one. */
  static async forIdentity(store: KeyStore, identity: string, keyId?: string): Promise<Signer> {
    const keys = (await store.list()).filter((k) => k.identity === identity && (keyId === undefined || k.keyId === keyId));
    const info = keys[keys.length - 1];
    if (!info) throw new KeyStoreError("KEY_NOT_FOUND", `no key for identity ${identity}${keyId ? `#${keyId}` : ""} in store`);
    return new Signer(store, info);
  }
}

/** Derive the public key for a 32-byte Ed25519 seed. */
export function publicKeyFromSeed(seed: Uint8Array): Uint8Array {
  if (seed.length !== 32) throw new KeyStoreError("INVALID_KEY", "Ed25519 seed must be 32 bytes");
  return ed25519.getPublicKey(seed);
}

/** Verify an Ed25519 signature. */
export function verifySignature(publicKey: Uint8Array, message: Uint8Array, signature: Uint8Array): boolean {
  try {
    return ed25519.verify(signature, message, publicKey);
  } catch {
    return false;
  }
}

/**
 * Seeds held in process memory. For tests, short-lived tooling and as the in-memory cache behind
 * the file stores. Not durable. `wipe()` zeroes the seeds on a best-effort basis (JS gives no
 * hard guarantee about copies made by the runtime).
 */
export class MemoryKeyStore implements KeyGeneratingStore {
  protected readonly keys = new Map<KeyRef, { info: KeyInfo; seed: Uint8Array }>();

  /** Add an existing key from its 32-byte seed. Throws if the ref is taken. */
  async addSeed(identity: string, keyId: string, seed: Uint8Array): Promise<KeyInfo> {
    const ref = keyRef(identity, keyId);
    if (this.keys.has(ref)) throw new KeyStoreError("KEY_EXISTS", `key ${ref} already exists`);
    const own = Uint8Array.from(seed);
    const info: KeyInfo = { ref, identity, keyId, publicKey: publicKeyFromSeed(own) };
    this.keys.set(ref, { info, seed: own });
    return info;
  }

  async generate(identity: string, keyId: string): Promise<KeyInfo> {
    return this.addSeed(identity, keyId, ed25519.utils.randomSecretKey());
  }

  async remove(ref: KeyRef): Promise<void> {
    const k = this.keys.get(ref);
    if (k) wipe(k.seed);
    this.keys.delete(ref);
  }

  async list(): Promise<KeyInfo[]> {
    return [...this.keys.values()].map((k) => ({ ...k.info, publicKey: Uint8Array.from(k.info.publicKey) }));
  }

  async publicKey(ref: KeyRef): Promise<Uint8Array> {
    return Uint8Array.from(this.must(ref).info.publicKey);
  }

  async sign(ref: KeyRef, message: Uint8Array): Promise<Uint8Array> {
    return ed25519.sign(message, this.must(ref).seed);
  }

  /** Zero every seed and forget all keys. */
  wipe(): void {
    for (const k of this.keys.values()) wipe(k.seed);
    this.keys.clear();
  }

  protected must(ref: KeyRef): { info: KeyInfo; seed: Uint8Array } {
    const k = this.keys.get(ref);
    if (!k) throw new KeyStoreError("KEY_NOT_FOUND", `no key ${ref} in store`);
    return k;
  }
}

// ---- External signers (HSM / KMS / secure element) ------------------------------------------

export interface ExternalKeyDescriptor {
  /** Opaque handle understood by the backend (PKCS#11 label, KMS key ARN, YubiHSM object id ...). */
  handle: string;
  identity: string;
  keyId: string;
  publicKey: Uint8Array;
}

/**
 * Implement this for a hardware security module or a cloud KMS that supports Ed25519.
 *
 * The private key must be generated INSIDE the device and be non-exportable. The backend only
 * ever receives the message to sign (the transaction signature preimage) and returns the 64-byte
 * signature. Nothing in the SDK needs, requests or logs the private key.
 */
export interface ExternalSignerBackend {
  /** Enumerate the keys the device exposes. Public material only. */
  listKeys(): Promise<ExternalKeyDescriptor[]>;
  /** Produce a raw Ed25519 (pure, RFC 8032) signature over `message` with the key behind `handle`. */
  signRaw(handle: string, message: Uint8Array): Promise<Uint8Array>;
}

export interface ExternalSignerOptions {
  /** Verify each returned signature against the advertised public key (default true). */
  verifySignatures?: boolean;
}

/**
 * Adapter that turns an ExternalSignerBackend into a KeyStore. It adds one safety net: the
 * signature coming back from the device is verified against the advertised public key before it
 * is returned, so a misconfigured device (wrong key, wrong algorithm, Ed25519ph instead of pure
 * Ed25519) fails loudly on the client instead of producing a BAD_SIGNATURE rejection on chain.
 */
export class ExternalSignerKeyStore implements KeyStore {
  private readonly backend: ExternalSignerBackend;
  private readonly verify: boolean;
  private cache: Map<KeyRef, ExternalKeyDescriptor> | undefined;

  constructor(backend: ExternalSignerBackend, options: ExternalSignerOptions = {}) {
    this.backend = backend;
    this.verify = options.verifySignatures ?? true;
  }

  private async load(): Promise<Map<KeyRef, ExternalKeyDescriptor>> {
    if (!this.cache) {
      const m = new Map<KeyRef, ExternalKeyDescriptor>();
      for (const d of await this.backend.listKeys()) m.set(keyRef(d.identity, d.keyId), d);
      this.cache = m;
    }
    return this.cache;
  }

  /** Re-enumerate the device (after provisioning a new key). */
  refresh(): void {
    this.cache = undefined;
  }

  async list(): Promise<KeyInfo[]> {
    return [...(await this.load()).values()].map((d) => ({
      ref: keyRef(d.identity, d.keyId),
      identity: d.identity,
      keyId: d.keyId,
      publicKey: Uint8Array.from(d.publicKey),
    }));
  }

  async publicKey(ref: KeyRef): Promise<Uint8Array> {
    return Uint8Array.from(await this.descriptor(ref).then((d) => d.publicKey));
  }

  async sign(ref: KeyRef, message: Uint8Array): Promise<Uint8Array> {
    const d = await this.descriptor(ref);
    let sig: Uint8Array;
    try {
      sig = await this.backend.signRaw(d.handle, message);
    } catch (e) {
      throw new KeyStoreError("SIGNER_ERROR", `external signer failed for ${ref}: ${e instanceof Error ? e.message : String(e)}`, e);
    }
    if (sig.length !== 64) throw new KeyStoreError("SIGNER_ERROR", `external signer returned ${sig.length} bytes, expected a 64-byte Ed25519 signature`);
    if (this.verify && !verifySignature(d.publicKey, message, sig)) {
      throw new KeyStoreError("SIGNER_ERROR", `signature from external signer does not verify under the advertised public key of ${ref}`);
    }
    return sig;
  }

  private async descriptor(ref: KeyRef): Promise<ExternalKeyDescriptor> {
    const d = (await this.load()).get(ref);
    if (!d) throw new KeyStoreError("KEY_NOT_FOUND", `no external key ${ref}`);
    return d;
  }
}

/**
 * Placeholder backend that documents the integration point. It refuses every call. Replace it
 * with a real implementation (PKCS#11, AWS KMS ECC_NIST_EDWARDS25519, GCP KMS, YubiHSM 2, ...).
 */
export class UnconfiguredExternalSigner implements ExternalSignerBackend {
  async listKeys(): Promise<ExternalKeyDescriptor[]> {
    return [];
  }
  async signRaw(handle: string, _message: Uint8Array): Promise<Uint8Array> {
    throw new KeyStoreError(
      "UNSUPPORTED",
      `no external signer configured (asked to sign with ${handle}). Implement ExternalSignerBackend for your HSM/KMS; the private key must never leave the device.`,
    );
  }
}

/** Constant-time comparison helper for public keys. */
export function samePublicKey(a: Uint8Array, b: Uint8Array): boolean {
  return bytesEqual(a, b);
}
