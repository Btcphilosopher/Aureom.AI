// NODE ONLY. Reads the plaintext key files written by the Go tooling (`chainctl testnet` ->
// <run>/net/keys/<identity>.json = {"identity","key_id","seed_hex","pub_b64"}).
//
// These files hold the Ed25519 SEED IN THE CLEAR. They exist for the local demo network. Use
// EncryptedFileKeyStore (or an HSM/KMS via ExternalSignerKeyStore) for anything else.

import { promises as fs } from "node:fs";
import { join } from "node:path";
import { base64ToBytes, bytesToBase64, bytesToHex, bytesEqual, hexToBytes } from "./encoding.js";
import { KeyStoreError } from "./errors.js";
import { MemoryKeyStore, keyRef, type KeyInfo, type KeyRef } from "./keystore.js";

export interface RawKeyFile {
  identity: string;
  key_id: string;
  seed_hex: string;
  pub_b64: string;
}

export interface RawKeyFileStoreOptions {
  /** Load only these identities (least privilege: a terminal needs only its own key). Default: every *.json in the directory. */
  identities?: string[];
  /** Throw if a key file is readable by group/other (POSIX). Default false: only reported in `insecureFiles`. */
  strictPermissions?: boolean;
}

export class RawKeyFileStore extends MemoryKeyStore {
  readonly dir: string;
  /** Files that were group/other accessible when loaded. */
  readonly insecureFiles: string[] = [];

  private constructor(dir: string) {
    super();
    this.dir = dir;
  }

  static async open(dir: string, opts: RawKeyFileStoreOptions = {}): Promise<RawKeyFileStore> {
    const store = new RawKeyFileStore(dir);
    let names: string[];
    try {
      names = await fs.readdir(dir);
    } catch (e) {
      throw new KeyStoreError("KEY_NOT_FOUND", `cannot read key directory ${dir}: ${e instanceof Error ? e.message : String(e)}`, e);
    }
    const wanted = opts.identities ? new Set(opts.identities) : undefined;
    for (const name of names.filter((n) => n.endsWith(".json")).sort()) {
      const path = join(dir, name);
      let kf: RawKeyFile;
      try {
        kf = JSON.parse(await fs.readFile(path, "utf8")) as RawKeyFile;
      } catch {
        continue; // not a key file
      }
      if (typeof kf.identity !== "string" || typeof kf.key_id !== "string" || typeof kf.seed_hex !== "string") continue;
      if (wanted && !wanted.has(kf.identity)) continue;
      const st = await fs.stat(path);
      if (process.platform !== "win32" && (st.mode & 0o077) !== 0) {
        if (opts.strictPermissions) throw new KeyStoreError("CORRUPT_KEYSTORE", `${path} is accessible by group/other (mode ${(st.mode & 0o777).toString(8)}); chmod 600`);
        store.insecureFiles.push(path);
      }
      const seed = hexToBytes(kf.seed_hex);
      const info = await MemoryKeyStore.prototype.addSeed.call(store, kf.identity, kf.key_id, seed);
      if (typeof kf.pub_b64 === "string" && !bytesEqual(base64ToBytes(kf.pub_b64), info.publicKey)) {
        await store.remove(info.ref);
        throw new KeyStoreError("CORRUPT_KEYSTORE", `${path}: pub_b64 does not match the seed`);
      }
    }
    if (wanted) {
      for (const id of wanted) {
        if (!(await store.list()).some((k) => k.identity === id)) throw new KeyStoreError("KEY_NOT_FOUND", `no key file for identity ${id} in ${dir}`);
      }
    }
    return store;
  }

  /** Generate a key and persist it as <identity>.<keyId>.json (mode 0600). Used for key rotation. */
  override async generate(identity: string, keyId: string): Promise<KeyInfo> {
    const info = await super.generate(identity, keyId);
    const seed = this.must(info.ref).seed;
    const file: RawKeyFile = { identity, key_id: keyId, seed_hex: bytesToHex(seed), pub_b64: bytesToBase64(info.publicKey) };
    try {
      await fs.writeFile(join(this.dir, `${identity}.${keyId}.json`), JSON.stringify(file, null, 2), { mode: 0o600, flag: "wx" });
    } catch (e) {
      await super.remove(info.ref);
      throw new KeyStoreError("KEY_EXISTS", `cannot write key file: ${e instanceof Error ? e.message : String(e)}`, e);
    }
    return info;
  }

  override async remove(ref: KeyRef): Promise<void> {
    const k = this.keys.get(ref);
    await super.remove(ref);
    if (k) await fs.rm(join(this.dir, `${k.info.identity}.${k.info.keyId}.json`), { force: true });
  }
}

/** Read the plaintext key files of a directory (used to migrate them into an encrypted vault). */
export async function readRawKeyFiles(dir: string): Promise<RawKeyFile[]> {
  const out: RawKeyFile[] = [];
  for (const name of (await fs.readdir(dir)).filter((n) => n.endsWith(".json")).sort()) {
    try {
      const kf = JSON.parse(await fs.readFile(join(dir, name), "utf8")) as RawKeyFile;
      if (typeof kf.identity === "string" && typeof kf.key_id === "string" && typeof kf.seed_hex === "string") out.push(kf);
    } catch {
      /* not a key file */
    }
  }
  return out;
}

export { keyRef };
