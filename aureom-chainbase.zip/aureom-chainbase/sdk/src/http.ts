// Minimal fetch wrapper (browser + Node >= 18): timeouts, JSON, gateway error mapping,
// automatic retry of HTTP 429 (the gateway rate limiter rejects BEFORE processing, so a retry is safe).

import { GatewayError, NetworkError, TimeoutError } from "./errors.js";

export type JsonValue = string | number | boolean | null | JsonValue[] | { [k: string]: JsonValue };
export type JsonObject = { [k: string]: JsonValue };

/** Query parameters: any plain object whose values are string | number | boolean | undefined | null. */
export type Query = object;

export interface HttpOptions {
  baseUrl: string;
  fetch?: typeof fetch;
  /** Default per-request timeout. */
  timeoutMs?: number;
  /** Extra headers on every request (e.g. an API token for a protected gateway). */
  headers?: Record<string, string>;
  /** How many times to retry a 429 (honouring Retry-After). Default 5. */
  maxRetries429?: number;
}

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  timeoutMs?: number;
  signal?: AbortSignal;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export class Http {
  readonly baseUrl: string;
  private readonly f: typeof fetch;
  private readonly timeoutMs: number;
  private readonly headers: Record<string, string>;
  private readonly maxRetries429: number;

  constructor(opts: HttpOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/+$/, "");
    this.f = opts.fetch ?? ((input, init) => globalThis.fetch(input, init));
    this.timeoutMs = opts.timeoutMs ?? 20_000;
    this.headers = opts.headers ?? {};
    this.maxRetries429 = opts.maxRetries429 ?? 5;
  }

  url(path: string, query?: Query): string {
    const u = new URL(this.baseUrl + path);
    if (query) {
      for (const [k, v] of Object.entries(query as Record<string, unknown>)) {
        if (v === undefined || v === null || v === "") continue;
        if (typeof v !== "string" && typeof v !== "number" && typeof v !== "boolean") throw new TypeError(`query parameter ${k} must be a string, number or boolean`);
        u.searchParams.set(k, String(v));
      }
    }
    return u.toString();
  }

  async request<T>(method: "GET" | "POST", path: string, opts: RequestOptions = {}): Promise<T> {
    const url = this.url(path, opts.query);
    for (let attempt = 0; ; attempt++) {
      const ctl = new AbortController();
      const timeoutMs = opts.timeoutMs ?? this.timeoutMs;
      const timer = setTimeout(() => ctl.abort(), timeoutMs);
      const onAbort = () => ctl.abort();
      opts.signal?.addEventListener("abort", onAbort);
      let res: Response;
      try {
        const init: RequestInit = { method, headers: { accept: "application/json", ...(opts.body !== undefined ? { "content-type": "application/json" } : {}), ...this.headers }, signal: ctl.signal };
        if (opts.body !== undefined) init.body = JSON.stringify(opts.body);
        res = await this.f(url, init);
      } catch (e) {
        if (ctl.signal.aborted && !opts.signal?.aborted) throw new TimeoutError(`${method} ${path}: no response within ${timeoutMs} ms`);
        throw new NetworkError(`${method} ${url}: ${e instanceof Error ? e.message : String(e)}`, e);
      } finally {
        clearTimeout(timer);
        opts.signal?.removeEventListener("abort", onAbort);
      }
      const text = await res.text();
      let parsed: unknown;
      if (text.length > 0) {
        try {
          parsed = JSON.parse(text);
        } catch {
          if (res.ok) throw new GatewayError(res.status, `non-JSON response: ${text.slice(0, 120)}`);
        }
      }
      if (res.ok) return parsed as T;
      const err = (parsed ?? {}) as { error?: unknown; code?: unknown };
      const retryAfter = Number(res.headers.get("retry-after"));
      const retryAfterMs = Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : undefined;
      if (res.status === 429 && attempt < this.maxRetries429) {
        await sleep(Math.min(retryAfterMs ?? 250 * (attempt + 1), 5_000));
        continue;
      }
      const msg = typeof err.error === "string" ? err.error : text.slice(0, 200) || res.statusText;
      throw new GatewayError(res.status, msg, typeof err.code === "string" ? err.code : undefined, retryAfterMs);
    }
  }

  get<T>(path: string, query?: Query, o: Omit<RequestOptions, "query" | "body"> = {}): Promise<T> {
    return this.request<T>("GET", path, { ...o, ...(query ? { query } : {}) });
  }
  post<T>(path: string, body: unknown, o: Omit<RequestOptions, "body"> = {}): Promise<T> {
    return this.request<T>("POST", path, { ...o, body });
  }
}

export { sleep };
