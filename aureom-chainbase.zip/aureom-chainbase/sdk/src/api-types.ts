// Response shapes of the gateway REST API (docs/API.md).

import type { JsonObject } from "./http.js";
import type { BalanceRow, Sale, Reservation, Sku, Product } from "./records.js";

export type WaitMode = "none" | "final" | "indexed";

export interface Admission {
  code: number;
  name: string;
  log: string;
}

export interface Finalised {
  height: number;
  index: number;
  code: number;
  code_name: string;
  log: string;
  /** Result data returned by the state machine for this transaction. */
  data?: Record<string, unknown>;
}

export interface SubmitResponse {
  tx_hash: string;
  tx_id: string;
  type: string;
  signer: string;
  admission: Admission;
  finalised?: Finalised;
  indexed?: boolean;
  latency_ms?: { admission?: number; finality?: number; indexed?: number };
  /**
   * Set by the SDK (not the gateway) when the network already held these exact transaction bytes
   * (CometBFT mempool cache: "tx already exists in cache"). The transaction was NOT executed again;
   * `finalised`, when present, is the original execution result looked up by tx id.
   */
  duplicate?: boolean;
}

export type TxLifecycle = "UNKNOWN" | "PENDING" | "FINALISED_OK" | "FINALISED_REJECTED";

export interface TxStatus {
  tx_id: string;
  status: TxLifecycle;
  height?: number;
  index?: number;
  code?: number;
  code_name?: string;
  reason?: string;
  block_time_ms?: number;
  signer?: string;
  type?: string;
  indexed?: boolean;
}

/** Normalised view of what happened to a submitted transaction. */
export type TxOutcome =
  | { status: "ADMISSION_REJECTED"; code: number; codeName: string; log: string }
  | { status: "ADMITTED_NOT_FINAL"; admitted: true }
  | { status: "FINALISED_OK"; height: number; index: number; data: Record<string, unknown>; indexed: boolean }
  | { status: "FINALISED_REJECTED"; height: number; index: number; code: number; codeName: string; log: string };

export interface ProjectionMeta {
  indexed_height: number;
  chain_head: number;
  lag_blocks: number;
  projection_state: "OK" | "REBUILDING" | "EMPTY" | string;
}

export interface ListResponse<T> {
  meta: ProjectionMeta;
  items: T[];
  total: number;
}
export interface ItemResponse<T> {
  meta: ProjectionMeta;
  item: T;
}

export interface ProjectionStatus {
  state: "OK" | "REBUILDING" | "EMPTY" | string;
  indexed_height: number;
  chain_head: number;
  lag_blocks: number;
  lag_seconds?: number;
  entries?: number;
  digest?: string;
  last_block_time?: string;
  rebuild?: { started_at?: string; finished_at?: string; blocks_replayed?: number; duration_ms?: number };
}

export interface ProjectionVerify {
  height: number;
  projection_digest: string;
  chain_digest: string;
  match: boolean;
  entries: number;
  proofs_checked: number;
  proofs_valid: number;
}

export interface QueryOptions {
  limit?: number;
  offset?: number;
  /** Read-after-write: block until the projection has indexed this height ... */
  min_height?: number;
  /** ... for at most this many ms. */
  wait_ms?: number;
}

export interface NetworkInfo {
  network_id: string;
  app_version: number;
  chain: { latest_height: number; latest_block_time: string; latest_app_hash: string; block_interval_ms_avg: number };
  bft: {
    validators: number;
    voting_power_total: number;
    f: number;
    quorum_power_required: number;
    online_power: number;
    online_validators: number;
    status: "HEALTHY" | "DEGRADED" | "HALTED" | string;
    explanation?: string;
  };
  validators: {
    name: string;
    org: string;
    role: string;
    node_id: string;
    rpc_url: string;
    reachable: boolean;
    height: number;
    catching_up: boolean;
    peers: number;
    latency_ms: number;
    voting_power: number;
    consensus_pubkey: string;
    app_hash: string;
    agrees_with_majority: boolean;
    last_signed_height: number;
  }[];
  members: JsonObject[];
  mempool: { unconfirmed_txs: number };
  queried_at: string;
}

export interface ChainInfo {
  height: number;
  app_hash: string;
  app_version: number;
  chain_id: string;
  max_supported_version: number;
}

export interface ChainRecordOptions {
  /** Read the state as of this committed height. */
  height?: number;
  /** Ask for an ICS23 proof. */
  prove?: boolean;
}

export interface ScanOptions {
  after?: string;
  limit?: number;
  height?: number;
}
export interface ScanResponse<T = unknown> {
  height: number;
  items: { key: string; value: T }[];
  next_after?: string | null;
}

export interface InventoryResult {
  balances: BalanceRow[];
  in_transit: BalanceRow[];
  /** Raw payload as returned by the gateway. */
  raw: unknown;
}

export interface Digest {
  height: number;
  app_hash: string;
  digest: string;
  entries: number;
}

export interface FinalityReport {
  height: number;
  verified: boolean;
  method?: string;
  trusted_height?: number;
  signed_power?: number;
  total_power?: number;
  quorum_required?: number;
  validators_signed?: string[];
  /** Upper-case hex app hash carried by the header at `height` (commits the state produced by block height-1). */
  header_app_hash?: string;
  /** docs/API.md names this field `app_hash_next_header`; the gateway implementation uses `header_app_hash`. Both are read. */
  app_hash_next_header?: string;
  block_hash?: string;
  error?: string;
}

/** Projection row types (only fields with a stable contract are named; extras stay accessible). */
export interface InventoryRow {
  sku: string;
  loc: string;
  product_name?: string;
  available: number;
  reserved: number;
  quarantined: number;
  damaged: number;
  on_hand: number;
  in_transit_in?: number;
  in_transit_out?: number;
  version: number;
}
export interface ProductView extends Product {
  /** The gateway embeds each product's SKU records here. */
  sku_details?: Sku[];
  [extra: string]: unknown;
}
export interface InventoryExceptionRow {
  kind: string;
  severity: string;
  ref: string;
  detail: string;
  location?: string;
  sku?: string;
}
export interface SalesSummaryRow {
  bucket: string;
  sales: number;
  gross_minor: number;
  discount_minor: number;
  net_minor: number;
  paid_minor: number;
  refunded_minor: number;
}
export interface TransactionRow {
  tx_id?: string;
  id?: string;
  type: string;
  signer: string;
  status: "OK" | "REJECTED";
  code: number;
  code_name: string;
  reason?: string;
  height: number;
  /** Position within the block (the gateway names it index_in_block). */
  index_in_block?: number;
  hash?: string;
  block_time_ms: number;
  client_time_ms: number;
}
export interface HistoryRow {
  height: number;
  tx_id: string;
  tx_type: string;
  signer: string;
  block_time_ms: number;
  version: number;
  value: unknown;
  deleted: boolean;
}
export interface SaleDetail extends Sale {
  returns?: JsonObject[];
  refunds?: JsonObject[];
  loyalty_entries?: JsonObject[];
  payment_events_detail?: JsonObject[];
  [extra: string]: unknown;
}
export type ReservationRow = Reservation;

export interface BlockSummary {
  height: number;
  time: string;
  hash: string;
  app_hash: string;
  proposer: string;
  num_txs: number;
  num_rejected: number;
  size_bytes: number;
}
