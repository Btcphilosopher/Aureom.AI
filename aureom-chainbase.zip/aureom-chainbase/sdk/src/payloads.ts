// Payload types for ALL 33 transaction types. Mirrors docs/TRANSACTIONS.md (generated from the
// Go payload structs) and the validators in chain/internal/core/h_*.go.
//
// Optionality: a field is optional here when the Go validator accepts its zero value (omitted
// field == "" / 0 / false). The chain is always the authority; unknown fields are rejected.

/** Quantity with explicit unit. `v` is an integer in the unit's smallest step (EA/PK whole; KG grams; L ml; M mm). */
export interface Qty {
  v: number;
  unit: string;
}

export type Channel = "STORE" | "ECOM";
export type Currency = "GBP" | "USD" | "EUR" | "JPY";
export type StockBucket = "available" | "quarantined" | "damaged";

// ---- Catalogue, locations, suppliers --------------------------------------------------------

export interface Variant {
  sku_id: string;
  unit: string;
  barcode?: string;
  /** Scarce SKUs may only be sold offline against a pre-allocated allowance. */
  scarce?: boolean;
  attributes?: Record<string, string>;
}
export interface CreateProductPayload {
  product_id: string;
  name: string;
  brand?: string;
  category?: string;
  attributes?: Record<string, string>;
  variants: Variant[];
}
export interface SkuUpdate {
  sku_id: string;
  status?: "ACTIVE" | "DISCONTINUED";
  scarce?: boolean;
  barcode?: string;
  attributes?: Record<string, string>;
}
export interface UpdateProductPayload {
  product_id: string;
  name?: string;
  brand?: string;
  category?: string;
  status?: "ACTIVE" | "DISCONTINUED";
  attributes?: Record<string, string>;
  sku_updates?: SkuUpdate[];
}
export interface CreateLocationPayload {
  location_id: string;
  name: string;
  kind: "STORE" | "WAREHOUSE";
  region: string;
  currency: Currency;
}
export interface CreateSupplierPayload {
  supplier_id: string;
  name: string;
  terms?: string;
}

// ---- Purchasing & receiving -----------------------------------------------------------------

export interface PurchaseOrderLineInput {
  sku: string;
  qty: Qty;
  unit_cost_minor: number;
}
export interface CreatePurchaseOrderPayload {
  po_id: string;
  supplier_id: string;
  location_id: string;
  currency: Currency;
  ordered_at_ms: number;
  lines: PurchaseOrderLineInput[];
}
export interface ApprovePurchaseOrderPayload {
  po_id: string;
}
export interface ReceiptLineInput {
  sku: string;
  qty: Qty;
  /** 1-based PO line number; required when po_id is set. */
  po_line?: number;
}
export interface ReceiveGoodsPayload {
  receipt_id: string;
  location_id: string;
  /** Receive against a PO (must be APPROVED / PARTIALLY_RECEIVED and deliver to location_id). */
  po_id?: string;
  /** Required when there is no po_id. */
  supplier_id?: string;
  effective_at_ms: number;
  lines: ReceiptLineInput[];
}

// ---- Inventory ------------------------------------------------------------------------------

export interface ReserveStockPayload {
  reservation_id: string;
  location_id: string;
  sku: string;
  qty: Qty;
  /** Must be > 0; capped by reservation_max_ttl_ms (normal) or allowance_max_ttl_ms (allowance). */
  ttl_ms: number;
  /** If set, only that terminal may complete a sale against the reservation. */
  terminal_id?: string;
  /** Pre-allocated offline allowance: may be consumed partially by several sales. */
  allowance?: boolean;
}
export interface ReleaseReservationPayload {
  reservation_id: string;
  reason: "CANCELLED" | "EXPIRED";
}

export interface TransferLineInput {
  sku: string;
  qty: Qty;
  /** RECEIVE only: of the received qty, how many arrived damaged. */
  damaged_v?: number;
}
export interface TransferDispatchPayload {
  op: "DISPATCH";
  transfer_id: string;
  from_location: string;
  to_location: string;
  lines: TransferLineInput[];
}
export interface TransferReceivePayload {
  op: "RECEIVE";
  transfer_id: string;
  lines: TransferLineInput[];
}
export type TransferStockPayload = TransferDispatchPayload | TransferReceivePayload;

export interface AdjustProposePayload {
  op: "PROPOSE";
  adjustment_id: string;
  location_id: string;
  sku: string;
  bucket: StockBucket;
  /** The physically counted quantity (not the delta). */
  counted_v: number;
  reason: string;
  evidence_ref?: string;
}
export interface AdjustDecidePayload {
  op: "APPROVE" | "REJECT";
  adjustment_id: string;
  reason?: string;
}
export type AdjustStockPayload = AdjustProposePayload | AdjustDecidePayload;

// ---- Sales, payments, returns ---------------------------------------------------------------

export interface SaleLineInput {
  sku: string;
  qty: Qty;
  reservation_id: string;
}
export interface CompleteSalePayload {
  sale_id: string;
  location_id: string;
  channel: Channel;
  terminal_id?: string;
  /** Synthetic / pseudonymous reference only: CUST-xxxx or PSN-xxxx. */
  customer_id?: string;
  effective_at_ms: number;
  currency: Currency;
  /** 0/omitted = do not check; otherwise the sale is rejected if the computed total differs. */
  expected_total_minor?: number;
  payment_method: string;
  lines: SaleLineInput[];
}
export interface RecordPaymentResultPayload {
  sale_id: string;
  provider: string;
  /** Provider's unique event/callback id; duplicates are deduplicated. */
  event_id: string;
  provider_ref: string;
  result: "CONFIRMED" | "FAILED";
  amount_minor: number;
  currency: Currency;
}
export interface ReturnLineInput {
  line_no: number;
  qty_v: number;
  reason: string;
}
export interface RequestReturnPayload {
  return_id: string;
  sale_id: string;
  /** Required (and needs a global-scope approver) when outside the return window. */
  override_reason?: string;
  lines: ReturnLineInput[];
}
export interface ApproveReturnPayload {
  return_id: string;
  decision: "APPROVE" | "REJECT";
}
export type Inspection = "RESELLABLE" | "DAMAGED" | "QUARANTINE" | "REJECTED";
export interface InspectionLineInput {
  line_no: number;
  qty_v: number;
  inspection: Inspection;
}
export interface ReceiveReturnedGoodsPayload {
  return_id: string;
  lines: InspectionLineInput[];
}
export interface RecordRefundResultPayload {
  refund_id: string;
  provider: string;
  event_id: string;
  provider_ref: string;
  result: "CONFIRMED" | "FAILED";
  amount_minor: number;
}

// ---- Pricing & promotions -------------------------------------------------------------------

export interface PublishPricePayload {
  price_id: string;
  sku: string;
  /** Location id, or "*" for a chain-wide price (needs a global-scope grant). */
  location_id: string;
  currency: Currency;
  /** Price per WHOLE unit of the SKU's unit. */
  unit_minor: number;
  effective_from_ms: number;
  /** 0/omitted = open ended. */
  effective_to_ms?: number;
}
export type PromotionType = "PERCENT_OFF" | "AMOUNT_OFF_PER_UNIT" | "MULTIBUY_FIXED_PRICE";
export interface ActivatePromotionPayload {
  promo_id: string;
  name: string;
  type: PromotionType;
  status: "ACTIVE" | "ENDED";
  currency: Currency;
  skus: string[];
  /** Location ids, or ["*"]. */
  locations: string[];
  effective_from_ms: number;
  effective_to_ms?: number;
  priority?: number;
  stackable?: boolean;
  loyalty_only?: boolean;
  /** PERCENT_OFF: basis points 1..10000. */
  bp?: number;
  /** AMOUNT_OFF_PER_UNIT. */
  off_minor?: number;
  /** MULTIBUY_FIXED_PRICE. */
  buy_n?: number;
  bundle_minor?: number;
}

// ---- Loyalty --------------------------------------------------------------------------------

export interface CreditLoyaltyPayload {
  entry_id: string;
  customer_id: string;
  sale_id: string;
}
export interface RedeemLoyaltyPayload {
  entry_id: string;
  customer_id: string;
  location_id: string;
  points: number;
  /** Unique per redemption: a second use is rejected. */
  redemption_ref: string;
  sale_id?: string;
  effective_at_ms: number;
}
export interface ExpireLoyaltyPayload {
  entry_id: string;
  customer_id: string;
  points: number;
  reason: string;
}

// ---- Corrections & exceptions ---------------------------------------------------------------

export interface ReverseBusinessEntryPayload {
  reversal_id: string;
  target_type: "LOYALTY_ENTRY" | "STOCK_ADJUSTMENT" | "GOODS_RECEIPT";
  target_id: string;
  reason: string;
  /** LOYALTY_ENTRY: explicit points to reverse; omit/0 to derive from refund_id. */
  points?: number;
  /** LOYALTY_ENTRY: a CONFIRMED refund that triggers a proportional reversal. */
  refund_id?: string;
}
export interface ResolveExceptionPayload {
  exception_id: string;
  location_id?: string;
  resolution: string;
}

// ---- Identity & access ----------------------------------------------------------------------

export interface RegisterIdentityPayload {
  identity_id: string;
  org: string;
  kind: "HUMAN" | "SERVICE" | "TERMINAL";
  key_id: string;
  pub_b64: string;
  bound_location?: string;
}
export interface GrantRolePayload {
  identity_id: string;
  role: string;
  /** "*", "loc:<id>" or "region:<name>". */
  scope: string;
}
export type RevokeRolePayload = GrantRolePayload;
export interface RotateKeyPayload {
  identity_id: string;
  new_key_id: string;
  new_pub_b64: string;
  reason: string;
}
export interface RevokeKeyPayload {
  identity_id: string;
  key_id: string;
  reason: string;
}

// ---- Governance -----------------------------------------------------------------------------

export interface GovMemberPayload {
  member_id: string;
  org: string;
  role: string;
  pubkey_b64: string;
  node_id: string;
  power: number;
}
export interface GovMemberIdPayload {
  member_id: string;
}
export interface GovRotateValidatorPayload {
  member_id: string;
  new_pubkey_b64: string;
  new_node_id: string;
}
export interface GovPrivilegedRolePayload {
  identity_id: string;
  role: string;
  scope: string;
}
export interface GovParams {
  max_tx_bytes: number;
  max_import_tx_bytes: number;
  max_lines: number;
  max_import_records: number;
  max_future_skew_ms: number;
  max_backdate_ms: number;
  min_gov_delay_blocks: number;
  min_upgrade_delay_blocks: number;
  min_validators: number;
  po_local_limit_minor: number;
  adjust_small_units: number;
  return_local_limit_minor: number;
  return_window_ms: number;
  reservation_max_ttl_ms: number;
  allowance_max_ttl_ms: number;
  loyalty_point_value_minor: number;
}
export interface GovSetParamsPayload {
  params: GovParams;
}
export interface GovUpgradePayload {
  version: number;
}
export type ProposeGovernancePayload =
  | { proposal_id: string; kind: "ADD_VALIDATOR" | "ADD_OBSERVER"; payload: GovMemberPayload; activation_height?: number }
  | { proposal_id: string; kind: "REMOVE_VALIDATOR" | "REMOVE_OBSERVER"; payload: GovMemberIdPayload; activation_height?: number }
  | { proposal_id: string; kind: "ROTATE_VALIDATOR_KEY"; payload: GovRotateValidatorPayload; activation_height?: number }
  | { proposal_id: string; kind: "GRANT_PRIVILEGED_ROLE" | "REVOKE_PRIVILEGED_ROLE"; payload: GovPrivilegedRolePayload; activation_height?: number }
  | { proposal_id: string; kind: "SET_PARAMS"; payload: GovSetParamsPayload; activation_height?: number }
  | { proposal_id: string; kind: "SCHEDULE_UPGRADE"; payload: GovUpgradePayload; activation_height: number };
export interface ApproveGovernancePayload {
  proposal_id: string;
}

// ---- Migration ------------------------------------------------------------------------------

export interface ImportBatchPayload {
  batch_id: string;
  source_system: string;
  snapshot_id: string;
  mapping_version: string;
  entity:
    | "LOCATION"
    | "SUPPLIER"
    | "PRODUCT"
    | "PRICE"
    | "OPENING_BALANCE"
    | "OPEN_PO"
    | "LOYALTY_OPENING"
    | "HISTORICAL_SALE";
  seq: number;
  records: Record<string, unknown>[];
}
export interface MigrationControlPayload {
  action: "OPEN" | "CLOSE";
  source_system: string;
  manifest_hash?: string;
  report_hash?: string;
  source_freeze_marker?: string;
  totals?: Record<string, number>;
}

// ---- Type map -------------------------------------------------------------------------------

export interface TxPayloadMap {
  ActivatePromotion: ActivatePromotionPayload;
  AdjustStock: AdjustStockPayload;
  ApproveGovernance: ApproveGovernancePayload;
  ApprovePurchaseOrder: ApprovePurchaseOrderPayload;
  ApproveReturn: ApproveReturnPayload;
  CompleteSale: CompleteSalePayload;
  CreateLocation: CreateLocationPayload;
  CreateProduct: CreateProductPayload;
  CreatePurchaseOrder: CreatePurchaseOrderPayload;
  CreateSupplier: CreateSupplierPayload;
  CreditLoyalty: CreditLoyaltyPayload;
  ExpireLoyalty: ExpireLoyaltyPayload;
  GrantRole: GrantRolePayload;
  ImportBatch: ImportBatchPayload;
  MigrationControl: MigrationControlPayload;
  ProposeGovernance: ProposeGovernancePayload;
  PublishPrice: PublishPricePayload;
  ReceiveGoods: ReceiveGoodsPayload;
  ReceiveReturnedGoods: ReceiveReturnedGoodsPayload;
  RecordPaymentResult: RecordPaymentResultPayload;
  RecordRefundResult: RecordRefundResultPayload;
  RedeemLoyalty: RedeemLoyaltyPayload;
  RegisterIdentity: RegisterIdentityPayload;
  ReleaseReservation: ReleaseReservationPayload;
  RequestReturn: RequestReturnPayload;
  ReserveStock: ReserveStockPayload;
  ResolveException: ResolveExceptionPayload;
  ReverseBusinessEntry: ReverseBusinessEntryPayload;
  RevokeKey: RevokeKeyPayload;
  RevokeRole: RevokeRolePayload;
  RotateKey: RotateKeyPayload;
  TransferStock: TransferStockPayload;
  UpdateProduct: UpdateProductPayload;
}

export type TxType = keyof TxPayloadMap;

/** Permission each type requires ("(handler)" = checked inside the handler, depends on `op` / identity). */
export const TX_PERMISSIONS = {
  ActivatePromotion: "promo.manage",
  AdjustStock: "(handler)",
  ApproveGovernance: "gov.approve",
  ApprovePurchaseOrder: "po.approve",
  ApproveReturn: "return.approve",
  CompleteSale: "sale.complete",
  CreateLocation: "location.write",
  CreateProduct: "catalog.write",
  CreatePurchaseOrder: "po.create",
  CreateSupplier: "supplier.write",
  CreditLoyalty: "loyalty.credit",
  ExpireLoyalty: "loyalty.expire",
  GrantRole: "iam.grant",
  ImportBatch: "import.batch",
  MigrationControl: "migration.control",
  ProposeGovernance: "gov.propose",
  PublishPrice: "price.publish",
  ReceiveGoods: "goods.receive",
  ReceiveReturnedGoods: "return.receive",
  RecordPaymentResult: "payment.record",
  RecordRefundResult: "refund.record",
  RedeemLoyalty: "loyalty.redeem",
  RegisterIdentity: "iam.admin",
  ReleaseReservation: "stock.release",
  RequestReturn: "return.request",
  ReserveStock: "stock.reserve",
  ResolveException: "exception.resolve",
  ReverseBusinessEntry: "reverse.entry",
  RevokeKey: "(handler)",
  RevokeRole: "iam.grant",
  RotateKey: "(handler)",
  TransferStock: "(handler)",
  UpdateProduct: "catalog.write",
} as const satisfies Record<TxType, string>;

/** All 33 transaction types (derived from the permission table, so it cannot drift from TxPayloadMap). */
export const TX_TYPES = Object.keys(TX_PERMISSIONS) as TxType[];

export function isTxType(s: string): s is TxType {
  return Object.prototype.hasOwnProperty.call(TX_PERMISSIONS, s);
}

// ---- Result `data` shapes returned by the state machine (finalised.data) --------------------

export interface TxResultMap {
  ReserveStock: { reservation_id: string; expires_at_ms: number };
  ReleaseReservation: { reservation_id: string; status: string };
  CompleteSale: { sale_id: string; net_minor: number; gross_minor: number; discount_minor: number };
  RecordPaymentResult: { sale_id: string; payment_status?: string; paid_minor?: number; deduplicated?: boolean };
  RequestReturn: { return_id: string; status: string };
  ApproveReturn: { return_id: string; status: string; estimated_refund_minor: number };
  ReceiveReturnedGoods: { return_id: string; status: string; refund_instructed_minor: number; refund_id?: string };
  RecordRefundResult: { refund_id: string; status?: string; deduplicated?: boolean };
  CreditLoyalty: { entry_id: string; points: number; balance: number };
  RedeemLoyalty: { entry_id: string; balance: number; value_minor: number };
  ReverseBusinessEntry: { reversal_id: string; target: string; points_reversed?: number; balance?: number };
  ReceiveGoods: { receipt_id: string; lines: string };
  CreateProduct: { product_id: string; skus: string[]; version: number };
  CreatePurchaseOrder: { po_id: string; total_minor: number; version: number };
  ApprovePurchaseOrder: { po_id: string; status: string; version: number };
  PublishPrice: { price_id: string; book_version: number };
  AdjustStock: { adjustment_id: string; delta?: number; status: string };
  TransferStock: { transfer_id: string; status: string };
  RotateKey: { identity_id: string; active_key: string };
  RevokeKey: { identity_id: string; revoked_key: string };
}
