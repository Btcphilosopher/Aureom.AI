// Client-side ICS23 proof verification for state records served by the gateway.
//
// WHAT A VERIFIED PROOF ESTABLISHES
//   "The key K holds exactly the bytes V (membership) / holds no value (non-membership) in the
//    application state whose Merkle root is R."
//   Nothing more. In particular it does NOT establish:
//     * that the record is business-correct (the chain stores what the state machine accepted,
//       and migrated records are assertions by the legacy system);
//     * that a LIST, SCAN or SEARCH result is complete (a proof covers one key; absence of a
//       proof for other keys proves nothing about them);
//     * that R is the root of a finalised block. Trust in R comes from header verification: the
//       app hash of height H+1's header is signed by +2/3 of the validator set, which the gateway
//       (light client) or `chainctl verify-finality` checks. This module can pin R to a value you
//       obtained independently (`expectedAppHash`) but cannot, by itself, tell you R is final.

import { ics23, iavlSpec, verifyMembership, verifyNonMembership } from "@confio/ics23";
import { base64ToBytes, bytesToHex, fromUtf8, hexToBytes, utf8 } from "./encoding.js";
import { ProofError } from "./errors.js";

export const PROOF_TYPE_IAVL = "ics23:iavl";
/** Upper bound on an encoded proof we are willing to decode (IAVL proofs are a few KB). */
export const MAX_PROOF_BYTES = 64 * 1024;

export interface ProofEnvelope {
  type: string;
  proof_b64: string;
  /** Height of the block header that carries `app_hash` (= state height + 1). */
  app_hash_height?: number;
  /** Hex Merkle root of the application state the proof is against. */
  app_hash: string;
}

export type ValueEncoding = "value_b64" | "reencoded" | "reencoded-html-escaped" | "none";

export interface ProofVerdict {
  /** True iff the proof is a valid ICS23/IAVL proof against `root` for the claimed (non-)membership. */
  valid: boolean;
  kind: "membership" | "non-membership";
  key: string;
  /** Hex root the proof was checked against. */
  root: string;
  /** Height of the header that carries the root, if reported. */
  appHashHeight?: number;
  /** How the committed value bytes were obtained (membership only). */
  valueEncoding: ValueEncoding;
  /** Whether `root` was matched against an independently supplied expectedAppHash. */
  rootPinned: boolean;
  /** Why the verdict is `valid: false`. */
  reason?: string;
  /** Plain-language statement of what a valid verdict means. */
  statement: string;
  /** What it does NOT mean. */
  caveats: string[];
}

export const PROOF_CAVEATS: readonly string[] = [
  "Establishes only that this key/value (or its absence) is committed in the state with this Merkle root.",
  "Does not establish business correctness of the record, nor completeness of any list or search result.",
  "Root trust comes from header verification (+2/3 validator signatures over the header carrying this app hash), done by the gateway light client or `chainctl verify-finality`; it is not established by the proof itself.",
];

export interface VerifyProofInput {
  /** The state key you ASKED for (never take the key from the response being verified). */
  key: string;
  found: boolean;
  proof: ProofEnvelope;
  /** Parsed record as returned by the gateway (membership). */
  value?: unknown;
  /** Exact committed bytes, base64 (membership). Preferred over re-encoding `value` when available. */
  valueB64?: string;
  /** Root obtained independently of the gateway (e.g. via your own light client). Hex. */
  expectedAppHash?: string;
}

function jsonUnicodeEscapes(s: string, html: boolean): string {
  let out = s.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  if (html) out = out.replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026");
  return out;
}

function sameJson(a: unknown, b: unknown): boolean {
  return JSON.stringify(sortKeys(a)) === JSON.stringify(sortKeys(b));
}
function sortKeys(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(sortKeys);
  if (v && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v as object).sort()) o[k] = sortKeys((v as Record<string, unknown>)[k]);
    return o;
  }
  return v;
}

function verdict(base: Pick<ProofVerdict, "kind" | "key" | "root" | "valueEncoding" | "rootPinned"> & { appHashHeight?: number }, valid: boolean, reason?: string): ProofVerdict {
  const subject = base.kind === "membership" ? `key ${JSON.stringify(base.key)} holds exactly this value` : `key ${JSON.stringify(base.key)} is absent`;
  const v: ProofVerdict = {
    ...base,
    valid,
    statement: valid
      ? `VERIFIED: ${subject} in the state with Merkle root ${base.root}${base.appHashHeight ? ` (carried by the header of block ${base.appHashHeight})` : ""}.`
      : `NOT VERIFIED: the proof does not show that ${subject} under root ${base.root}.`,
    caveats: [...PROOF_CAVEATS],
  };
  if (reason !== undefined) v.reason = reason;
  return v;
}

/** Verify one ICS23/IAVL proof. Never throws for a bad proof - it returns `valid: false` with a reason. */
export function verifyProof(input: VerifyProofInput): ProofVerdict {
  const { key, found, proof } = input;
  const kind: ProofVerdict["kind"] = found ? "membership" : "non-membership";
  const rootHex = (proof.app_hash ?? "").toLowerCase();
  const base = { kind, key, root: rootHex, valueEncoding: "none" as ValueEncoding, rootPinned: false, ...(proof.app_hash_height !== undefined ? { appHashHeight: proof.app_hash_height } : {}) };

  if (proof.type !== PROOF_TYPE_IAVL) return verdict(base, false, `unsupported proof type ${JSON.stringify(proof.type)} (expected ${PROOF_TYPE_IAVL})`);
  // The gateway leaves app_hash empty when it could not verify the header (e.g. its light client is not
  // ready yet). A caller that holds an independently obtained root can still verify against that root.
  if (rootHex === "" && input.expectedAppHash !== undefined) {
    base.root = input.expectedAppHash.toLowerCase();
    base.rootPinned = true;
  } else if (rootHex === "") {
    return verdict(base, false, "the gateway returned no app_hash (it could not verify the header); supply expectedAppHash obtained independently to verify anyway");
  } else if (input.expectedAppHash !== undefined) {
    if (input.expectedAppHash.toLowerCase() !== rootHex) {
      return verdict(base, false, `app_hash ${rootHex} differs from the independently supplied expectedAppHash ${input.expectedAppHash.toLowerCase()}`);
    }
    base.rootPinned = true;
  }
  let root: Uint8Array;
  try {
    root = hexToBytes(base.root);
  } catch {
    return verdict(base, false, "app_hash is not valid hex");
  }
  if (root.length !== 32) return verdict(base, false, `app_hash must be 32 bytes, got ${root.length}`);

  let bytes: Uint8Array;
  try {
    bytes = base64ToBytes(proof.proof_b64);
  } catch {
    return verdict(base, false, "proof_b64 is not valid base64");
  }
  if (bytes.length === 0 || bytes.length > MAX_PROOF_BYTES) return verdict(base, false, `proof size ${bytes.length} outside 1..${MAX_PROOF_BYTES} bytes`);

  let cp: ics23.ICommitmentProof;
  try {
    cp = ics23.CommitmentProof.decode(bytes);
  } catch (e) {
    return verdict(base, false, `proof does not decode as an ICS23 CommitmentProof: ${e instanceof Error ? e.message : String(e)}`);
  }
  const keyBytes = utf8(key);

  if (!found) {
    let ok = false;
    try {
      ok = verifyNonMembership(cp, iavlSpec, root, keyBytes);
    } catch (e) {
      return verdict(base, false, `verification error: ${e instanceof Error ? e.message : String(e)}`);
    }
    return verdict(base, ok, ok ? undefined : "no valid non-membership proof for this key under this root");
  }

  // Membership: candidates for the committed value bytes.
  const candidates: { bytes: Uint8Array; enc: ValueEncoding }[] = [];
  if (input.valueB64 !== undefined) {
    let exact: Uint8Array;
    try {
      exact = base64ToBytes(input.valueB64);
    } catch {
      return verdict(base, false, "value_b64 is not valid base64");
    }
    if (input.value !== undefined) {
      let parsed: unknown;
      try {
        parsed = JSON.parse(fromUtf8(exact));
      } catch {
        return verdict(base, false, "value_b64 is not JSON although the gateway also returned a parsed value");
      }
      if (!sameJson(parsed, input.value)) return verdict(base, false, "the returned value differs from the bytes value_b64 that the proof covers");
    }
    candidates.push({ bytes: exact, enc: "value_b64" });
  } else if (input.value !== undefined) {
    const plain = jsonUnicodeEscapes(JSON.stringify(input.value), false);
    candidates.push({ bytes: utf8(plain), enc: "reencoded" });
    const html = jsonUnicodeEscapes(JSON.stringify(input.value), true);
    if (html !== plain) candidates.push({ bytes: utf8(html), enc: "reencoded-html-escaped" });
  } else {
    return verdict(base, false, "membership proof requires the record value");
  }
  for (const c of candidates) {
    let ok = false;
    try {
      ok = verifyMembership(cp, iavlSpec, root, keyBytes, c.bytes);
    } catch (e) {
      return verdict(base, false, `verification error: ${e instanceof Error ? e.message : String(e)}`);
    }
    if (ok) return verdict({ ...base, valueEncoding: c.enc }, true);
  }
  return verdict(base, false, "no valid membership proof for this key and value under this root");
}

/** Shape of GET /api/v1/chain/record (see docs/API.md). */
export interface ChainRecordResponse<T = unknown> {
  key: string;
  found: boolean;
  value?: T;
  /** Optional exact stored bytes (base64). The SDK uses it when present; see docs/SDK.md. */
  value_b64?: string;
  height: number;
  proof?: ProofEnvelope;
  verification?: {
    proof_valid?: boolean;
    header_verified?: boolean;
    statement?: string;
  };
}

/** Verify a /chain/record?prove=1 response against the key that was requested. */
export function verifyRecordResponse(requestedKey: string, resp: ChainRecordResponse, opts: { expectedAppHash?: string } = {}): ProofVerdict {
  if (resp.key !== undefined && resp.key !== requestedKey) {
    throw new ProofError(`response is for key ${JSON.stringify(resp.key)} but ${JSON.stringify(requestedKey)} was requested`);
  }
  if (!resp.proof) throw new ProofError("response carries no proof (was prove=1 sent?)");
  const input: VerifyProofInput = { key: requestedKey, found: resp.found, proof: resp.proof };
  if (resp.value !== undefined) input.value = resp.value;
  if (resp.value_b64 !== undefined) input.valueB64 = resp.value_b64;
  if (opts.expectedAppHash !== undefined) input.expectedAppHash = opts.expectedAppHash;
  const v = verifyProof(input);
  // The proof is bound to the state at `height`; its header is block height+1.
  if (v.valid && resp.proof.app_hash_height !== undefined && resp.height !== undefined && resp.proof.app_hash_height !== resp.height + 1) {
    return { ...v, valid: false, statement: v.statement.replace("VERIFIED", "NOT VERIFIED"), reason: `app_hash_height ${resp.proof.app_hash_height} is not state height ${resp.height} + 1` };
  }
  return v;
}

/** Hex of a root, for display. */
export function rootHex(root: Uint8Array): string {
  return bytesToHex(root);
}
