// Key rotation and revocation helpers (RotateKey / RevokeKey transactions).
//
// Chain semantics (chain/internal/core/h_admin.go):
//  * RotateKey signed by the identity itself retires the key that signed it (status ROTATED) and
//    activates the new one. An iam.admin may rotate on behalf of an identity (lost-key recovery);
//    that retires every ACTIVE key of the identity.
//  * RevokeKey marks one ACTIVE key REVOKED (identity itself or an iam.admin).
//  * After either finalises, transactions signed by the retired key are rejected with
//    KEY_INACTIVE (202) at admission - including anything still queued/pre-signed offline.
//    Re-sign queued requests with the new key.

import { bytesToBase64 } from "./encoding.js";
import { ValidationError } from "./errors.js";
import { assertId } from "./ids.js";
import { Signer, type KeyGeneratingStore, type KeyInfo } from "./keystore.js";
import type { BuildOptions, SignedTx, TxBuilder } from "./tx.js";

export interface RotateKeyInput {
  /** Identity whose key is rotated (default: the builder's own identity = self-rotation). */
  identityId?: string;
  newKeyId: string;
  /** Public key of the new key. */
  newPublicKey: Uint8Array;
  reason: string;
}

/** Build a RotateKey transaction signed by the builder's current key. */
export async function buildRotateKeyTx(builder: TxBuilder, input: RotateKeyInput, opts: BuildOptions = {}): Promise<SignedTx<"RotateKey">> {
  assertId("new_key_id", input.newKeyId);
  if (input.newPublicKey.length !== 32) throw new ValidationError("new public key must be 32 bytes");
  if (!input.reason) throw new ValidationError("a reason is required");
  return builder.build(
    "RotateKey",
    {
      identity_id: input.identityId ?? builder.signer.identity,
      new_key_id: input.newKeyId,
      new_pub_b64: bytesToBase64(input.newPublicKey),
      reason: input.reason,
    },
    opts,
  );
}

export interface RevokeKeyInput {
  identityId?: string;
  keyId: string;
  reason: string;
}

/** Build a RevokeKey transaction. A key can revoke ITSELF (compromise response) or an iam.admin can revoke it. */
export async function buildRevokeKeyTx(builder: TxBuilder, input: RevokeKeyInput, opts: BuildOptions = {}): Promise<SignedTx<"RevokeKey">> {
  assertId("key_id", input.keyId);
  if (!input.reason) throw new ValidationError("a reason is required");
  return builder.build("RevokeKey", { identity_id: input.identityId ?? builder.signer.identity, key_id: input.keyId, reason: input.reason }, opts);
}

export interface RotationResult {
  /** The signed RotateKey transaction (signed by the OLD key). Submit it and wait for finality. */
  tx: SignedTx<"RotateKey">;
  /** The new key, already present in the store. */
  newKey: KeyInfo;
  /** Signer for the new key — switch to it only AFTER the RotateKey tx is finalised OK. */
  newSigner: Signer;
}

/**
 * Self-rotation: generate a fresh key in `store` and build the RotateKey tx that registers it.
 *
 * Safe sequence:
 *   1. const r = await rotateKey({ builder, store, newKeyId: "k2", reason: "scheduled rotation" })
 *   2. await client.submit(r.tx, { wait: "final" })   // old key signs this one last transaction
 *   3. on code 0: use r.builder (or builder.withSigner(r.newSigner)) from now on
 *      on rejection: await store.remove?.(r.newKey.ref) to discard the unused key
 */
export async function rotateKey(args: {
  builder: TxBuilder;
  store: KeyGeneratingStore;
  newKeyId: string;
  reason: string;
}): Promise<RotationResult & { builder: TxBuilder }> {
  const { builder, store, newKeyId, reason } = args;
  const identity = builder.signer.identity;
  const newKey = await store.generate(identity, newKeyId);
  try {
    const tx = await buildRotateKeyTx(builder, { newKeyId, newPublicKey: newKey.publicKey, reason });
    const newSigner = new Signer(store, newKey);
    return { tx, newKey, newSigner, builder: builder.withSigner(newSigner) };
  } catch (e) {
    await store.remove?.(newKey.ref);
    throw e;
  }
}
