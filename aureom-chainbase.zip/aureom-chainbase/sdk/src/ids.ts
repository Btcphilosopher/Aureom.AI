// Identifier rules enforced by the validators (chain/internal/core/tx.go) plus generators.

import { bytesToHex, randomBytes } from "./encoding.js";
import { ValidationError } from "./errors.js";

/** tx_id: unique per network. */
export const RE_TX_ID = /^[A-Za-z0-9_-]{8,64}$/;
/** Business identifiers (reservation_id, sale_id, sku, location ...). */
export const RE_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;
/** idempotency_ref. */
export const RE_IDEM = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$/;
/** Synthetic / pseudonymous customer reference only. */
export const RE_CUSTOMER = /^(CUST|PSN)-[A-Za-z0-9]{4,40}$/;

export function assertTxId(s: string): string {
  if (!RE_TX_ID.test(s)) throw new ValidationError(`tx_id ${JSON.stringify(s)} must match ${RE_TX_ID}`);
  return s;
}
export function assertId(what: string, s: string): string {
  if (!RE_ID.test(s)) throw new ValidationError(`${what} ${JSON.stringify(s)} must match ${RE_ID}`);
  return s;
}
export function assertIdempotencyRef(s: string): string {
  if (!RE_IDEM.test(s)) throw new ValidationError(`idempotency_ref ${JSON.stringify(s)} must match ${RE_IDEM}`);
  return s;
}

/** Unique, roughly time-ordered tx id: tx-<base36 ms>-<12 hex random> (<= 30 chars). */
export function newTxId(nowMs: number = Date.now()): string {
  return `tx-${nowMs.toString(36)}-${bytesToHex(randomBytes(6))}`;
}

/** Business id with a caller prefix, e.g. newBusinessId("RES") -> RES-lq3k9x2a-5f1c9e. Always satisfies RE_ID. */
export function newBusinessId(prefix: string, nowMs: number = Date.now()): string {
  const id = `${prefix}-${nowMs.toString(36)}-${bytesToHex(randomBytes(3))}`;
  return assertId("generated id", id);
}
