// Error types. All SDK errors extend SdkError and carry a stable `code` string.

export class SdkError extends Error {
  readonly code: string;
  constructor(code: string, message: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = new.target.name;
    this.code = code;
  }
}

/** The gateway answered with HTTP >= 400 (body is {"error": "...", "code": "..."}). */
export class GatewayError extends SdkError {
  readonly status: number;
  readonly gatewayCode: string | undefined;
  readonly retryAfterMs: number | undefined;
  constructor(status: number, message: string, gatewayCode?: string, retryAfterMs?: number) {
    super("GATEWAY_ERROR", `gateway ${status}${gatewayCode ? ` ${gatewayCode}` : ""}: ${message}`);
    this.status = status;
    this.gatewayCode = gatewayCode;
    this.retryAfterMs = retryAfterMs;
  }
}

/** The gateway could not be reached at all (DNS, refused, reset, timeout before any HTTP response). */
export class NetworkError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super("NETWORK_ERROR", message, { cause });
  }
}

/** A client-side timeout (waiting for finality / indexing / a request deadline). */
export class TimeoutError extends SdkError {
  constructor(message: string) {
    super("TIMEOUT", message);
  }
}

/** A transaction was rejected (at admission or after being ordered into a block). */
export class TxRejectedError extends SdkError {
  readonly txId: string;
  readonly resultCode: number;
  readonly resultName: string;
  readonly stage: "admission" | "finalised";
  constructor(txId: string, stage: "admission" | "finalised", resultCode: number, resultName: string, log: string) {
    super("TX_REJECTED", `tx ${txId} rejected at ${stage}: ${resultName}${log ? ` (${log})` : ""}`);
    this.txId = txId;
    this.stage = stage;
    this.resultCode = resultCode;
    this.resultName = resultName;
  }
}

export class KeyStoreError extends SdkError {
  constructor(code: "KEY_NOT_FOUND" | "BAD_PASSPHRASE" | "CORRUPT_KEYSTORE" | "LOCKED" | "KEY_EXISTS" | "UNSUPPORTED" | "SIGNER_ERROR" | "INVALID_KEY", message: string, cause?: unknown) {
    super(code, message, { cause });
  }
}

export class ProofError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super("PROOF_ERROR", message, { cause });
  }
}

export class ValidationError extends SdkError {
  constructor(message: string) {
    super("VALIDATION", message);
  }
}
