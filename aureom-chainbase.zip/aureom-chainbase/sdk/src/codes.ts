// Transaction result codes (mirrors docs/TRANSACTIONS.md and chain/internal/core/errors.go).

export const RESULT_CODES = {
  OK: 0,
  MALFORMED: 1,
  TOO_LARGE: 2,
  WRONG_NETWORK: 3,
  UNKNOWN_TYPE: 4,
  UNSUPPORTED_SCHEMA: 5,
  INVALID_FIELD: 6,
  BAD_SIGNATURE: 101,
  UNKNOWN_SIGNER: 201,
  KEY_INACTIVE: 202,
  EXPIRED: 203,
  REPLAY: 210,
  DUPLICATE_IDEMPOTENCY: 211,
  UNAUTHORIZED: 301,
  SCOPE_VIOLATION: 302,
  POLICY_VIOLATION: 303,
  NOT_FOUND: 401,
  ALREADY_EXISTS: 402,
  VERSION_CONFLICT: 403,
  INSUFFICIENT: 404,
  INVALID_STATE: 405,
  LIMIT_EXCEEDED: 406,
  INVALID_ARGUMENT: 407,
  MIGRATION_WINDOW: 408,
  INTERNAL: 500,
} as const;

export type ResultCodeName = keyof typeof RESULT_CODES;

const BY_NUMBER = new Map<number, ResultCodeName>(
  (Object.entries(RESULT_CODES) as [ResultCodeName, number][]).map(([name, n]) => [n, name]),
);

/** Name for a numeric result code; unknown codes render as CODE_<n> (same as the Go side). */
export function codeName(code: number): string {
  return BY_NUMBER.get(code) ?? `CODE_${code}`;
}

/**
 * Codes that mean "this request was rejected before it could change state" at the stage of
 * structure / signature / identity / replay. Transactions failing here leave no trace on chain.
 */
export function isPreStateRejection(code: number): boolean {
  return code !== 0 && code < 300;
}
