// NODE ONLY. Passphrase-encrypted key vault: scrypt (KDF) + AES-256-GCM (authenticated encryption).
//
// File format (JSON, mode 0600):
//   { "format": "aureom-keystore/v1",
//     "kdf":    { "name": "scrypt", "N": 131072, "r": 8, "p": 1, "salt_b64": "..." },
//     "cipher": { "name": "aes-256-gcm", "iv_b64": "...", "tag_b64": "..." },
//     "keys":   [ { "identity": "...", "key_id": "...", "pub_b64": "..." } ],     // public, plaintext
//     "ciphertext_b64": "..." }                                                   // {"seeds": {ref: hex}}
//
// * The key-encryption key is scrypt(NFKC(passphrase), salt) -> 32 bytes. N=2^17, r=8, p=1 is the
//   OWASP-recommended minimum cost (about 128 MiB of memory, ~0.3 s on a laptop).
// * A fresh random salt and IV are generated on EVERY save (GCM must never reuse an IV under one key).
// * The plaintext header (format, kdf params, IV, public key list) is bound as additional authenticated
//   data, so tampering with the cost parameters or swapping a public key fails authentication.
// * A wrong passphrase and a corrupted file are indistinguishable by design: both fail the GCM tag.
// * Seeds live in process memory only while the store is unlocked. lock() wipes them.

import { randomBytes as nodeRandomBytes, scrypt, createCipheriv, createDecipheriv, type ScryptOptions } from "node:crypto";
import { promises as fs } from "node:fs";
import { dirname } from "node:path";
import { base64ToBytes, bytesToBase64, bytesToHex, bytesEqual, fromUtf8, hexToBytes, utf8, wipe } from "./encoding.js";
import { KeyStoreError } from "./errors.js";
import { MemoryKeyStore, keyRef, publicKeyFromSeed, type KeyInfo, type KeyRef } from "./keystore.js";

export const KEYSTORE_FORMAT = "aureom-keystore/v1";
const MAX_SCRYPT_N = 1 << 20; // refuse absurd cost parameters from an untrusted file

export interface KdfParams {
  N: number;
  r: number;
  p: number;
}
export const DEFAULT_KDF: KdfParams = { N: 1 << 17, r: 8, p: 1 };

interface VaultFile {
  format: string;
  kdf: { name: "scrypt"; N: number; r: number; p: number; salt_b64: string };
  cipher: { name: "aes-256-gcm"; iv_b64: string; tag_b64: string };
  keys: { identity: string; key_id: string; pub_b64: string }[];
  ciphertext_b64: string;
}

function derive(passphrase: string, salt: Uint8Array, kdf: KdfParams): Promise<Uint8Array> {
  if (!Number.isInteger(kdf.N) || kdf.N < 2 || (kdf.N & (kdf.N - 1)) !== 0 || kdf.N > MAX_SCRYPT_N || kdf.r < 1 || kdf.r > 32 || kdf.p < 1 || kdf.p > 16) {
    return Promise.reject(new KeyStoreError("CORRUPT_KEYSTORE", "unsupported scrypt parameters"));
  }
  const opts: ScryptOptions = { N: kdf.N, r: kdf.r, p: kdf.p, maxmem: 256 * 1024 * 1024 };
  return new Promise((resolve, reject) => {
    scrypt(passphrase.normalize("NFKC"), salt, 32, opts, (err, key) => (err ? reject(new KeyStoreError("CORRUPT_KEYSTORE", `scrypt failed: ${err.message}`, err)) : resolve(new Uint8Array(key))));
  });
}

/** Header bytes bound as AAD. Field order is fixed so encrypt and decrypt agree. */
function aad(f: Pick<VaultFile, "format" | "kdf" | "keys"> & { iv_b64: string }): Uint8Array {
  return utf8(JSON.stringify({ format: f.format, kdf: f.kdf, iv_b64: f.iv_b64, keys: f.keys }));
}

export interface EncryptedStoreOptions {
  kdf?: KdfParams;
  /** Minimum passphrase length (default 8; use a long passphrase or a generated one). */
  minPassphraseLength?: number;
}

export class EncryptedFileKeyStore extends MemoryKeyStore {
  readonly path: string;
  private passphrase: string | undefined;
  private kdf: KdfParams;
  private locked = false;
  private readonly minLen: number;

  private constructor(path: string, passphrase: string, kdf: KdfParams, minLen: number) {
    super();
    this.path = path;
    this.passphrase = passphrase;
    this.kdf = kdf;
    this.minLen = minLen;
  }

  /** Create a new, empty vault file. Fails if the file already exists. */
  static async create(path: string, passphrase: string, opts: EncryptedStoreOptions = {}): Promise<EncryptedFileKeyStore> {
    const minLen = opts.minPassphraseLength ?? 8;
    if (passphrase.length < minLen) throw new KeyStoreError("BAD_PASSPHRASE", `passphrase must be at least ${minLen} characters`);
    try {
      await fs.access(path);
      throw new KeyStoreError("KEY_EXISTS", `${path} already exists`);
    } catch (e) {
      if (e instanceof KeyStoreError) throw e;
    }
    const s = new EncryptedFileKeyStore(path, passphrase, opts.kdf ?? DEFAULT_KDF, minLen);
    await s.save(true);
    return s;
  }

  /** Decrypt and open an existing vault. Throws KeyStoreError("BAD_PASSPHRASE") if the passphrase is wrong. */
  static async open(path: string, passphrase: string, opts: EncryptedStoreOptions = {}): Promise<EncryptedFileKeyStore> {
    let f: VaultFile;
    try {
      f = JSON.parse(await fs.readFile(path, "utf8")) as VaultFile;
    } catch (e) {
      throw new KeyStoreError("CORRUPT_KEYSTORE", `cannot read keystore ${path}: ${e instanceof Error ? e.message : String(e)}`, e);
    }
    if (f.format !== KEYSTORE_FORMAT || f.kdf?.name !== "scrypt" || f.cipher?.name !== "aes-256-gcm") throw new KeyStoreError("CORRUPT_KEYSTORE", "unrecognised keystore format");
    const kdf: KdfParams = { N: f.kdf.N, r: f.kdf.r, p: f.kdf.p };
    const kek = await derive(passphrase, base64ToBytes(f.kdf.salt_b64), kdf);
    let plain: Uint8Array;
    try {
      const d = createDecipheriv("aes-256-gcm", kek, base64ToBytes(f.cipher.iv_b64));
      d.setAAD(aad({ format: f.format, kdf: f.kdf, iv_b64: f.cipher.iv_b64, keys: f.keys }));
      d.setAuthTag(base64ToBytes(f.cipher.tag_b64));
      plain = new Uint8Array(Buffer.concat([d.update(base64ToBytes(f.ciphertext_b64)), d.final()]));
    } catch {
      throw new KeyStoreError("BAD_PASSPHRASE", "wrong passphrase, or the keystore file has been modified");
    } finally {
      wipe(kek);
    }
    const store = new EncryptedFileKeyStore(path, passphrase, kdf, opts.minPassphraseLength ?? 8);
    let seeds: Record<string, string>;
    try {
      seeds = (JSON.parse(fromUtf8(plain)) as { seeds: Record<string, string> }).seeds;
    } catch (e) {
      throw new KeyStoreError("CORRUPT_KEYSTORE", "decrypted payload is not valid", e);
    } finally {
      wipe(plain);
    }
    for (const k of f.keys) {
      const ref = keyRef(k.identity, k.key_id);
      const hex = seeds[ref];
      if (hex === undefined) throw new KeyStoreError("CORRUPT_KEYSTORE", `no secret for ${ref}`);
      const seed = hexToBytes(hex);
      const info = await MemoryKeyStore.prototype.addSeed.call(store, k.identity, k.key_id, seed);
      wipe(seed);
      if (!bytesEqual(info.publicKey, base64ToBytes(k.pub_b64))) throw new KeyStoreError("CORRUPT_KEYSTORE", `public key of ${ref} does not match its secret`);
    }
    return store;
  }

  override async addSeed(identity: string, keyId: string, seed: Uint8Array): Promise<KeyInfo> {
    this.assertOpen();
    const info = await super.addSeed(identity, keyId, seed);
    await this.save();
    return info;
  }

  override async generate(identity: string, keyId: string): Promise<KeyInfo> {
    this.assertOpen();
    const info = await super.generate(identity, keyId);
    await this.save();
    return info;
  }

  override async remove(ref: KeyRef): Promise<void> {
    await super.remove(ref);
    if (!this.locked) await this.save();
  }

  override async sign(ref: KeyRef, message: Uint8Array): Promise<Uint8Array> {
    this.assertOpen();
    return super.sign(ref, message);
  }

  /** Re-encrypt under a new passphrase (new salt and IV). */
  async changePassphrase(newPassphrase: string): Promise<void> {
    this.assertOpen();
    if (newPassphrase.length < this.minLen) throw new KeyStoreError("BAD_PASSPHRASE", `passphrase must be at least ${this.minLen} characters`);
    this.passphrase = newPassphrase;
    await this.save();
  }

  /** Wipe all decrypted seeds from memory. The store must be re-opened to sign again. */
  lock(): void {
    this.wipe();
    this.passphrase = undefined;
    this.locked = true;
  }

  /** Re-encrypt and atomically replace the vault file. */
  async save(createNew = false): Promise<void> {
    this.assertOpen();
    const pass = this.passphrase as string;
    const salt = new Uint8Array(nodeRandomBytes(16));
    const iv = new Uint8Array(nodeRandomBytes(12));
    const kek = await derive(pass, salt, this.kdf);
    const infos = [...this.keys.values()].map((k) => k.info).sort((a, b) => (a.ref < b.ref ? -1 : 1));
    const seeds: Record<string, string> = {};
    for (const i of infos) seeds[i.ref] = bytesToHex(this.must(i.ref).seed);
    const header = {
      format: KEYSTORE_FORMAT,
      kdf: { name: "scrypt" as const, N: this.kdf.N, r: this.kdf.r, p: this.kdf.p, salt_b64: bytesToBase64(salt) },
      iv_b64: bytesToBase64(iv),
      keys: infos.map((i) => ({ identity: i.identity, key_id: i.keyId, pub_b64: bytesToBase64(i.publicKey) })),
    };
    const c = createCipheriv("aes-256-gcm", kek, iv);
    c.setAAD(aad(header));
    const plain = utf8(JSON.stringify({ seeds }));
    const ct = Buffer.concat([c.update(plain), c.final()]);
    const tag = c.getAuthTag();
    wipe(plain);
    wipe(kek);
    const file: VaultFile = {
      format: header.format,
      kdf: header.kdf,
      cipher: { name: "aes-256-gcm", iv_b64: header.iv_b64, tag_b64: bytesToBase64(new Uint8Array(tag)) },
      keys: header.keys,
      ciphertext_b64: bytesToBase64(new Uint8Array(ct)),
    };
    const tmp = `${this.path}.tmp-${process.pid}-${bytesToHex(new Uint8Array(nodeRandomBytes(4)))}`;
    await fs.mkdir(dirname(this.path), { recursive: true });
    const fh = await fs.open(tmp, "wx", 0o600);
    try {
      await fh.writeFile(JSON.stringify(file, null, 2));
      await fh.sync();
    } finally {
      await fh.close();
    }
    if (createNew) {
      try {
        await fs.link(tmp, this.path); // fails if the destination exists: never clobber an existing vault on create
      } catch (e) {
        await fs.rm(tmp, { force: true });
        throw new KeyStoreError("KEY_EXISTS", `${this.path} already exists`, e);
      }
      await fs.rm(tmp, { force: true });
    } else {
      await fs.rename(tmp, this.path);
    }
  }

  private assertOpen(): void {
    if (this.locked) throw new KeyStoreError("LOCKED", "keystore is locked; open it again with the passphrase");
  }
}

/** Convenience: import a seed into a vault, verifying the public key. */
export async function importSeed(store: EncryptedFileKeyStore, identity: string, keyId: string, seed: Uint8Array, expectedPub?: Uint8Array): Promise<KeyInfo> {
  if (expectedPub && !bytesEqual(publicKeyFromSeed(seed), expectedPub)) throw new KeyStoreError("INVALID_KEY", "seed does not match the expected public key");
  return store.addSeed(identity, keyId, seed);
}
