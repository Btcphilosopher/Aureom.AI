// Suggested manager actions for an exception that the terminal cannot resolve by itself.
// These are SUGGESTIONS written into an escalation record; nothing here signs or submits anything.

import type { ExceptionItem, SaleRecord, SuggestedAction } from "./state.js";

export interface EscalationPlan {
  problem: string;
  goodsMayHaveLeftStore: boolean;
  actions: SuggestedAction[];
  note: string;
}

function primaryCode(exc: ExceptionItem): string {
  return exc.reasons.find((r) => r.tx_type === "ReserveStock")?.code_name ?? exc.reasons[0]?.code_name ?? "UNKNOWN";
}

export function planEscalation(exc: ExceptionItem, sale: SaleRecord | undefined, terminalId: string): EscalationPlan {
  const code = primaryCode(exc);
  const first = sale?.lines[0];
  const loc = sale?.location_id ?? "<location>";
  const sku = first?.sku ?? "<sku>";
  const adjId = `ADJ-${exc.id}`;
  const offline = sale?.mode === "OFFLINE";
  const goodsLeft = offline === true;

  if (code === "INSUFFICIENT") {
    return {
      problem: `Oversell: the chain had no available ${sku} at ${loc} when the offline sale ${exc.sale_ref} reached it (another sale or reservation took the stock while ${terminalId} was disconnected). The goods have already been handed to the customer.`,
      goodsMayHaveLeftStore: goodsLeft,
      actions: [
        { step: 1, actor: "store manager", action: `Physically count ${sku} at ${loc} (shelf and back room) and decide which sale the physical stock belongs to. Do not touch the chain until the count is done.` },
        {
          step: 2,
          actor: "store manager A (e.g. manager-n01)",
          action: "If the offline sale is to be recorded, propose a stock adjustment so the chain has the units the offline sale needs: counted_v = current chain available + units sold offline. Put the exception id in evidence_ref.",
          tx_type: "AdjustStock",
          payload_template: { op: "PROPOSE", adjustment_id: adjId, location_id: loc, sku, bucket: "available", counted_v: "<chain available + qty sold>", reason: `oversell reconciliation for ${exc.sale_ref}`, evidence_ref: exc.id },
          note: "Check the current chain balance first (gateway /api/v1/chain/inventory).",
        },
        {
          step: 3,
          actor: "a DIFFERENT approver (separation of duties)",
          action: "Approve the adjustment. The proposer cannot approve their own adjustment. An adjustment larger than the local limit (adjust_small_units, default 10) needs a global-scope approver.",
          tx_type: "AdjustStock",
          payload_template: { op: "APPROVE", adjustment_id: adjId },
          note: "The demo roster has one store manager per store: register a second approver (RegisterIdentity + GrantRole store-manager loc:<store>) or use a warehouse/HQ approver with the right scope.",
        },
        { step: 4, actor: "terminal operator", action: `Re-submit the sale online: resolve ${exc.id} retry (new tx ids and a new reservation id; the sale id is kept so the chain cannot record it twice).` },
        { step: 5, actor: "store manager", action: "The other customer whose sale consumed the same unit must be handled commercially (cancel / refund through the normal RequestReturn -> ApproveReturn -> RecordRefundResult flow). The chain cannot decide which customer keeps the goods." },
      ],
      note: "If the offline sale should NOT be recorded (goods came back), use `resolve <id> cancel --reason ...` instead and correct stock only if the count differs from the chain.",
    };
  }

  if (code === "INVALID_STATE" || code === "EXPIRED" || code === "NOT_FOUND") {
    return {
      problem: `The offline sale ${exc.sale_ref} was refused with ${code} (${exc.reasons[0]?.reason ?? ""}). Typical causes: the allowance/reservation expired before sync, or the signing key was rotated/revoked while the request was queued.`,
      goodsMayHaveLeftStore: goodsLeft,
      actions: [
        { step: 1, actor: "terminal operator", action: `Go online and try: resolve ${exc.id} retry (re-signs with the current key, takes fresh reservations).` },
        { step: 2, actor: "store manager", action: "If the retry is refused for lack of stock, follow the oversell procedure: count stock, AdjustStock PROPOSE, a different approver APPROVE, then retry." },
      ],
      note: "A KEY_INACTIVE rejection means the terminal key was rotated or revoked: provision the new key on the terminal first.",
    };
  }

  return {
    problem: `The sale ${exc.sale_ref} was rejected with ${code} (${exc.reasons[0]?.reason ?? ""}) and needs a human decision.`,
    goodsMayHaveLeftStore: goodsLeft,
    actions: [
      { step: 1, actor: "store manager", action: `Read the rejection reason, check the sale and stock on the dashboard (record key sale/${exc.sale_ref}, tx ids in this escalation).` },
      { step: 2, actor: "store manager", action: `Fix the cause (for example publish a missing price, correct a SKU status), then run: resolve ${exc.id} retry. If the sale cannot be recorded, run: resolve ${exc.id} cancel --reason "...".` },
    ],
    note: "Rejected requests make no state change on the chain; the rejection itself is recorded as tx/<tx_id> with status REJECTED.",
  };
}
