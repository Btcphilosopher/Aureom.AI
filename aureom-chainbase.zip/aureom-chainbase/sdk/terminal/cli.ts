#!/usr/bin/env -S npx tsx
// Offline POS terminal simulator.   npm run terminal -- [options] <command> [args]

import { join } from "node:path";
import { parseArgs } from "node:util";
import { Client, SdkError, Signer } from "../src/index.js";
import { RawKeyFileStore } from "../src/node.js";
import { resolveEnv } from "../scripts/env.js";
import { FileStateStore } from "./state.js";
import { OfflineError, PolicyRefusal, SaleFailed, Terminal, type ResolveAction } from "./terminal.js";
import { fmtTime, formatEscalation, formatExceptions, formatQueue, formatReceipt, formatResolve, formatStatus, formatSync, OFFLINE_BANNER, table, UNFINALISED_LABEL } from "./format.js";

const USAGE = `AUREOM CHAINBASE offline POS terminal simulator (synthetic data only)

usage: npm run terminal -- [options] <command> [args]

commands
  status [--live]                    local view: mode, allowances, queue, exceptions (never touches the network)
  go-offline                         simulated outage: no network call is attempted until go-online
  go-online [--no-sync]              leave the outage, then sync the queue (unless --no-sync)
  refresh [sku...]                   (online) refresh SKU cache, chain params, allowance balances
  allowance <sku> <qty> [--ttl-hours N]
                                     (online) pre-allocate stock for offline selling (ReserveStock allowance:true)
  release-allowance <reservation_id> (online) give unused allowance units back
  sell <sku>:<qty>... [--customer CUST-xxxx] [--payment CARD] [--use-allowance]
                                     online: Reserve + CompleteSale with finality; OFFLINE: sign locally and queue
  queue                              list queued requests
  sync                               (online) submit the queue in order, print ACCEPTED / REJECTED
  exceptions [--all]                 rejected sales that need a decision
  resolve <exception-id> retry|cancel|escalate [--reason "..."]
  receipt <sale_id>                  reprint a stored receipt

options
  --terminal <id>     terminal identity (default term-n01-1; also term-n01-2)
  --state <file>      state file (default $RUN_DIR/terminals/<terminal>.json)
  --keys <dir>        identity key files (default $RUN_DIR/net/keys)
  --gateway <url>     gateway (default $GATEWAY_URL or http://127.0.0.1:8080)
  --network-id <id>   chain id used when signing offline (default: from $RUN_DIR/net/network.json)
  --location <id>     bound location (default STORE-N-01; refreshed from the chain identity when online)
  --run-dir <dir>     run directory (default $RUN_DIR or <repo>/run)
`;

function print(lines: string[]): void {
  console.log(lines.join("\n"));
}

async function main(argv: string[]): Promise<number> {
  const { values, positionals } = parseArgs({
    args: argv,
    allowPositionals: true,
    options: {
      terminal: { type: "string" },
      state: { type: "string" },
      keys: { type: "string" },
      gateway: { type: "string" },
      "network-id": { type: "string" },
      location: { type: "string" },
      "run-dir": { type: "string" },
      customer: { type: "string" },
      payment: { type: "string" },
      reason: { type: "string" },
      "ttl-hours": { type: "string" },
      "use-allowance": { type: "boolean" },
      "no-sync": { type: "boolean" },
      live: { type: "boolean" },
      all: { type: "boolean" },
      help: { type: "boolean", short: "h" },
    },
  });
  const [command, ...args] = positionals;
  if (values.help || !command) {
    console.log(USAGE);
    return command ? 0 : 2;
  }

  const env = resolveEnv({
    ...(values["run-dir"] ? { runDir: values["run-dir"] } : {}),
    ...(values.keys ? { keysDir: values.keys } : {}),
    ...(values.gateway ? { gatewayUrl: values.gateway } : {}),
    ...(values["network-id"] ? { networkId: values["network-id"] } : {}),
  });
  const terminalId = values.terminal ?? "term-n01-1";
  const keys = await RawKeyFileStore.open(env.keysDir, { identities: [terminalId] });
  const signer = await Signer.forIdentity(keys, terminalId);
  const client = new Client({ baseUrl: env.gatewayUrl });
  const store = new FileStateStore(values.state ?? join(env.runDir, "terminals", `${terminalId}.json`));
  const term = await Terminal.open({ store, gateway: client, signer, networkId: env.networkId, ...(values.location ? { locationId: values.location } : {}) });

  switch (command) {
    case "status": {
      print(formatStatus(term.status()));
      if (values.live && term.state.mode === "ONLINE") {
        const n = await client.network();
        console.log(`Live          network ${n.network_id}, height ${n.chain.latest_height}, BFT ${n.bft.status}, ${n.bft.online_validators}/${n.bft.validators} validators`);
      }
      return 0;
    }
    case "go-offline": {
      await term.goOffline();
      print([...bannerLines(), "Simulated outage started. No network call will be attempted until `go-online`.", "Selling continues: requests are signed locally and queued as UNFINALISED / NOT CONFIRMED."]);
      return 0;
    }
    case "go-online": {
      const r = await term.goOnline({ sync: !values["no-sync"] });
      console.log(`terminal is ONLINE (gateway ${env.gatewayUrl})`);
      if (r.sync) print(formatSync(r.sync));
      else if (term.status().unfinalised.length > 0) console.log(`${term.status().unfinalised.length} request(s) still ${UNFINALISED_LABEL}; run \`sync\`.`);
      return 0;
    }
    case "refresh": {
      const r = await term.refresh(args.length > 0 ? args : undefined);
      console.log(`refreshed ${r.skus.length} SKU(s); location ${r.location_id}; chain height ${r.height ?? "?"}`);
      if (r.allowances.length > 0) print(table(["allowance", "sku", "chain remaining", "status"], r.allowances.map((a) => [a.reservation_id, a.sku, String(a.chain_remaining_v), a.status])));
      return 0;
    }
    case "allowance": {
      const [sku, qty] = args;
      if (!sku || !qty) return usage("allowance <sku> <qty>");
      const hours = values["ttl-hours"] ? Number(values["ttl-hours"]) : undefined;
      const a = await term.requestAllowance(sku, Number(qty), hours !== undefined ? { ttlMs: Math.round(hours * 3600_000) } : {});
      print([
        `ALLOWANCE GRANTED (finalised at height ${a.height ?? "?"})`,
        `  reservation ${a.reservation_id}: ${a.granted_v} ${a.unit} of ${a.sku} at ${a.location_id}`,
        `  stock is now RESERVED for this terminal until ${fmtTime(a.expires_at_ms)}; other terminals can no longer sell these units`,
        `  usable offline by this terminal only (partial consumption allowed); sync before it expires`,
      ]);
      return 0;
    }
    case "release-allowance": {
      const [id] = args;
      if (!id) return usage("release-allowance <reservation_id>");
      const a = await term.releaseAllowance(id);
      console.log(`allowance ${a.reservation_id} released; unused units are available to other terminals again`);
      return 0;
    }
    case "sell": {
      if (args.length === 0) return usage("sell <sku>:<qty>...");
      const lines = args.map((a) => {
        const m = /^([^:\s]+):(\d+)$/.exec(a);
        if (!m) throw new PolicyRefusal(`bad line ${JSON.stringify(a)}; expected <sku>:<qty> with an integer quantity`);
        return { sku: m[1] as string, qty: Number(m[2]) };
      });
      const r = await term.sell(lines, { ...(values.customer ? { customerId: values.customer } : {}), ...(values.payment ? { paymentMethod: values.payment } : {}), ...(values["use-allowance"] ? { useAllowance: true } : {}) });
      print(formatReceipt(term.state, r));
      return 0;
    }
    case "queue":
      print(formatQueue(term.state.queue));
      return 0;
    case "sync": {
      const r = await term.sync();
      print(formatSync(r));
      return r.interrupted ? 1 : 0;
    }
    case "exceptions":
      print(formatExceptions(term.listExceptions({ all: values.all === true })));
      return 0;
    case "resolve": {
      const [id, action] = args;
      if (!id || (action !== "retry" && action !== "cancel" && action !== "escalate")) return usage("resolve <exception-id> retry|cancel|escalate [--reason \"...\"]");
      const r = await term.resolve(id, action as ResolveAction, values.reason ? { reason: values.reason } : {});
      print(formatResolve(r));
      return r.ok ? 0 : 1;
    }
    case "receipt": {
      const [id] = args;
      const sale = id ? term.state.sales[id] : undefined;
      if (!sale) return usage("receipt <sale_id> (known sales: " + Object.keys(term.state.sales).join(", ") + ")");
      print(formatReceipt(term.state, { mode: sale.mode, sale, queue: term.state.queue.filter((q) => sale.queue_ids.includes(q.id)), notes: [] }));
      return 0;
    }
    case "escalation": {
      const [id] = args;
      const e = term.state.escalations.find((x) => x.id === id);
      if (!e) return usage("escalation <ESC-id>");
      print(formatEscalation(e));
      return 0;
    }
    default:
      return usage(`unknown command ${command}`);
  }
}

function bannerLines(): string[] {
  return ["=".repeat(72), `  ${OFFLINE_BANNER}`, "=".repeat(72)];
}

function usage(msg: string): number {
  console.error(`usage error: ${msg}\n`);
  console.error(USAGE);
  return 2;
}

main(process.argv.slice(2)).then(
  (code) => process.exit(code),
  (e: unknown) => {
    if (e instanceof OfflineError) {
      console.error(`REFUSED (offline): ${e.message}`);
      process.exit(3);
    }
    if (e instanceof PolicyRefusal) {
      console.error(`REFUSED (policy): ${e.message}`);
      process.exit(3);
    }
    if (e instanceof SaleFailed) {
      console.error(`NOT COMPLETED: ${e.message}`);
      process.exit(3);
    }
    if (e instanceof SdkError) {
      console.error(`${e.code}: ${e.message}`);
      process.exit(1);
    }
    console.error(e);
    process.exit(1);
  },
);
