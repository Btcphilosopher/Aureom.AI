// Durable state of the simulated POS terminal (one JSON file per terminal).

import { promises as fs } from "node:fs";
import { dirname } from "node:path";
import type { Envelope } from "../src/index.js";

export type Mode = "ONLINE" | "OFFLINE";
export type QueueStatus = "UNFINALISED" | "ACCEPTED" | "REJECTED" | "CANCELLED";
export type QueueKind = "RESERVE" | "SALE" | "RELEASE";
export type SaleStatus = "UNFINALISED" | "FINALISED" | "REJECTED" | "CANCELLED";
export type LineBacking = "ALLOWANCE" | "PRESIGNED_RESERVATION" | "ONLINE_RESERVATION";

export interface SkuCache {
  sku: string;
  unit: string;
  scarce: boolean;
  status: string;
  product_id?: string;
  product_name?: string;
  cached_at_ms: number;
}

export interface AllowanceRec {
  reservation_id: string;
  sku: string;
  unit: string;
  location_id: string;
  granted_v: number;
  /** Units the chain still holds in the allowance as of the last contact (shrinks as sales are FINALISED). */
  chain_remaining_v: number;
  /** Units sold offline against this allowance whose CompleteSale is still UNFINALISED. */
  pending_v: number;
  /** Chain block time at which the allowance stops being usable. */
  expires_at_ms: number;
  created_at_ms: number;
  tx_id: string;
  height?: number;
  status: "ACTIVE" | "RELEASED" | "CONSUMED" | "EXPIRED";
}

export interface ItemResult {
  stage: "admission" | "finalised" | "dependency" | "local";
  code: number;
  code_name: string;
  reason: string;
  height?: number;
  data?: Record<string, unknown>;
  at_ms: number;
}

export interface QueueItem {
  id: string;
  sale_ref: string;
  kind: QueueKind;
  tx_type: "ReserveStock" | "CompleteSale" | "ReleaseReservation";
  tx_id: string;
  idempotency_ref: string;
  /** The fully signed request, exactly as it will be submitted. */
  envelope: Envelope;
  signed_by: string;
  summary: string;
  /** RESERVE: reservation created; RELEASE: reservation released. */
  reservation_id?: string;
  depends_on: string[];
  queued_at_ms: number;
  status: QueueStatus;
  attempts: number;
  submitted_at_ms?: number;
  result?: ItemResult;
}

export interface SaleLineRec {
  sku: string;
  qty_v: number;
  unit: string;
  scarce: boolean;
  backing: LineBacking;
  reservation_id: string;
  /** For ALLOWANCE lines: the allowance that backs it (== reservation_id). */
  allowance_id?: string;
}

export interface SaleRecord {
  sale_id: string;
  mode: Mode;
  status: SaleStatus;
  created_at_ms: number;
  effective_at_ms: number;
  location_id: string;
  customer_id?: string;
  payment_method: string;
  lines: SaleLineRec[];
  /** Queue items of this sale (offline) in submission order. */
  queue_ids: string[];
  /** Direct (online) transactions. */
  tx_ids: string[];
  finalised_height?: number;
  net_minor?: number;
  gross_minor?: number;
  discount_minor?: number;
  /** Attempts to re-submit this sale after an exception (online). */
  retries: number;
}

export type ExceptionStatus = "OPEN" | "ESCALATED" | "RESOLVED_RETRIED" | "CANCELLED";

export interface ExceptionReason {
  queue_id?: string;
  tx_type: string;
  tx_id?: string;
  code: number;
  code_name: string;
  reason: string;
  stage: string;
}

export interface ExceptionItem {
  id: string;
  sale_ref: string;
  created_at_ms: number;
  status: ExceptionStatus;
  reasons: ExceptionReason[];
  /** Reservations the chain accepted for this sale that were never consumed (they hold stock until released). */
  orphan_reservations: string[];
  resolution?: { action: "retry" | "cancel" | "escalate"; at_ms: number; note?: string; escalation_id?: string; tx_ids?: string[] };
  /** Outcome of failed retry attempts, newest last. */
  retry_log: { at_ms: number; code_name: string; reason: string }[];
}

export interface SuggestedAction {
  step: number;
  actor: string;
  action: string;
  tx_type?: string;
  payload_template?: Record<string, unknown>;
  note?: string;
}

export interface EscalationRecord {
  id: string;
  exception_id: string;
  sale_ref: string;
  created_at_ms: number;
  terminal_id: string;
  location_id: string;
  problem: string;
  goods_may_have_left_store: boolean;
  lines: { sku: string; qty_v: number; unit: string; scarce: boolean; backing: LineBacking }[];
  reasons: ExceptionReason[];
  suggested_actions: SuggestedAction[];
  note?: string;
}

export interface TerminalState {
  version: 1;
  terminal_id: string;
  location_id: string;
  network_id: string;
  mode: Mode;
  mode_changed_at_ms: number;
  last_online_ms?: number;
  last_known_height?: number;
  block_interval_ms?: number;
  chain_params?: { reservation_max_ttl_ms: number; allowance_max_ttl_ms: number; max_backdate_ms: number; max_future_skew_ms: number };
  skus: Record<string, SkuCache>;
  allowances: Record<string, AllowanceRec>;
  sales: Record<string, SaleRecord>;
  queue: QueueItem[];
  exceptions: ExceptionItem[];
  escalations: EscalationRecord[];
  counters: { queue: number; exception: number; escalation: number };
}

export function newState(init: { terminal_id: string; location_id: string; network_id: string; now: number }): TerminalState {
  return {
    version: 1,
    terminal_id: init.terminal_id,
    location_id: init.location_id,
    network_id: init.network_id,
    mode: "ONLINE",
    mode_changed_at_ms: init.now,
    skus: {},
    allowances: {},
    sales: {},
    queue: [],
    exceptions: [],
    escalations: [],
    counters: { queue: 0, exception: 0, escalation: 0 },
  };
}

export interface StateStore {
  /** Returns undefined if no state exists yet. */
  load(): Promise<TerminalState | undefined>;
  /** Durable write: when this resolves the data is on disk (for FileStateStore). */
  save(state: TerminalState): Promise<void>;
}

export class MemoryStateStore implements StateStore {
  private data: string | undefined;
  saves = 0;
  constructor(initial?: TerminalState) {
    if (initial) this.data = JSON.stringify(initial);
  }
  async load(): Promise<TerminalState | undefined> {
    return this.data === undefined ? undefined : (JSON.parse(this.data) as TerminalState);
  }
  async save(state: TerminalState): Promise<void> {
    this.saves++;
    this.data = JSON.stringify(state);
  }
}

/** Atomic, fsync'd JSON file: write temp -> fsync -> rename, so a crash never leaves a half-written queue. */
export class FileStateStore implements StateStore {
  constructor(readonly path: string) {}
  async load(): Promise<TerminalState | undefined> {
    try {
      const s = JSON.parse(await fs.readFile(this.path, "utf8")) as TerminalState;
      if (s.version !== 1) throw new Error(`unsupported terminal state version ${String(s.version)}`);
      return s;
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return undefined;
      throw e;
    }
  }
  async save(state: TerminalState): Promise<void> {
    await fs.mkdir(dirname(this.path), { recursive: true });
    const tmp = `${this.path}.tmp-${process.pid}`;
    const fh = await fs.open(tmp, "w", 0o600);
    try {
      await fh.writeFile(JSON.stringify(state, null, 2));
      await fh.sync();
    } finally {
      await fh.close();
    }
    await fs.rename(tmp, this.path);
  }
}
