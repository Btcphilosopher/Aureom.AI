// Plain-text rendering for the terminal CLI. Pure functions (return lines) so they can be tested.

import type { EscalationRecord, ExceptionItem, QueueItem, SaleRecord, TerminalState } from "./state.js";
import type { ResolveResult, SellResult, StatusReport, SyncReport } from "./terminal.js";

export const OFFLINE_BANNER = "OFFLINE – NOT FINALISED";
export const UNFINALISED_LABEL = "UNFINALISED / NOT CONFIRMED";
const RULE = "=".repeat(72);
const THIN = "-".repeat(72);

export function fmtTime(ms: number | undefined): string {
  return ms === undefined ? "-" : new Date(ms).toISOString().replace("T", " ").replace(/\.\d+Z$/, "Z");
}

export function table(headers: string[], rows: string[][]): string[] {
  const widths = headers.map((h, i) => Math.max(h.length, ...rows.map((r) => (r[i] ?? "").length)));
  const line = (cells: string[]) => cells.map((c, i) => c.padEnd(widths[i] ?? 0)).join("  ").trimEnd();
  return [line(headers), widths.map((w) => "-".repeat(w)).join("  "), ...rows.map(line)];
}

function boxed(title: string[]): string[] {
  return [RULE, ...title.map((t) => `  ${t}`), RULE];
}

function lineText(l: SaleRecord["lines"][number], skuName?: string): string {
  const name = skuName ? ` (${skuName})` : "";
  const backing =
    l.backing === "ALLOWANCE"
      ? `allowance ${l.reservation_id}`
      : l.backing === "PRESIGNED_RESERVATION"
        ? `pre-signed reservation ${l.reservation_id} [NOT stock-protected]`
        : `reservation ${l.reservation_id}`;
  return `${String(l.qty_v).padStart(6)} ${l.unit}  ${l.sku}${name}${l.scarce ? "  [scarce]" : ""}\n          backed by ${backing}`;
}

export function formatReceipt(state: TerminalState, r: SellResult): string[] {
  const s = r.sale;
  const out: string[] = [];
  const height = r.finalised?.height ?? s.finalised_height;
  if (s.status === "FINALISED") {
    out.push(...boxed([`${s.mode === "OFFLINE" ? "OFFLINE SALE \u2013 NOW " : "ONLINE \u2013 "}FINALISED at height ${height ?? "?"}`, "Confirmed by the chain (CometBFT finality)."]));
  } else if (s.status === "REJECTED") {
    out.push(...boxed(["REJECTED by the chain \u2013 NOT A VALID SALE", "No state change was made on the chain. See `exceptions`."]));
  } else if (s.status === "CANCELLED") {
    out.push(...boxed(["CANCELLED locally \u2013 NOT RECORDED ON THE CHAIN"]));
  } else if (s.mode === "OFFLINE" && !r.outcomeUnknown) {
    out.push(...boxed([OFFLINE_BANNER, UNFINALISED_LABEL, "This sale is signed but NOT confirmed by the chain. It is not final until `sync` succeeds."]));
  } else {
    out.push(...boxed([`ONLINE \u2013 OUTCOME UNKNOWN`, UNFINALISED_LABEL, "Connection lost while completing the sale. Kept in the queue; checked against the chain at the next sync."]));
  }
  out.push(` Terminal   ${state.terminal_id} @ ${s.location_id}`);
  out.push(` Sale       ${s.sale_id}`);
  out.push(` Time       ${fmtTime(s.created_at_ms)} (terminal clock; the chain stores it only as a claim)`);
  out.push(` Customer   ${s.customer_id ?? "-"}        Payment: ${s.payment_method}${s.status === "UNFINALISED" && s.mode === "OFFLINE" ? " (not authorised while offline)" : ""}`);
  out.push(THIN);
  for (const l of s.lines) out.push(lineText(l, state.skus[l.sku]?.product_name));
  out.push(THIN);
  if (s.net_minor !== undefined) {
    out.push(` Gross ${s.gross_minor ?? "?"}  Discount ${s.discount_minor ?? "?"}  NET ${s.net_minor}  (minor units, computed by the chain)`);
  } else {
    out.push(" Total      determined by the chain at finalisation (price book and promotions at the sale's effective time)");
  }
  for (const n of r.notes) out.push(` ! ${n}`);
  if (r.queue.length > 0) {
    out.push(` Queue      ${r.queue.map((q) => `${q.id} ${q.tx_type} ${q.status === "UNFINALISED" ? UNFINALISED_LABEL : q.status}`).join(", ")}`);
  }
  out.push(RULE);
  return out;
}

export function formatStatus(rep: StatusReport): string[] {
  const s = rep.state;
  const out: string[] = [];
  if (s.mode === "OFFLINE" || rep.unfinalised.length > 0) {
    out.push(...boxed([s.mode === "OFFLINE" ? OFFLINE_BANNER : `ONLINE – ${rep.unfinalised.length} request(s) ${UNFINALISED_LABEL}`, s.mode === "OFFLINE" ? "Simulated outage: no network call is attempted." : "Run `sync` to submit them."]));
  }
  out.push(`Terminal      ${s.terminal_id} @ ${s.location_id}   network ${s.network_id}`);
  out.push(`Mode          ${s.mode}${s.mode === "OFFLINE" ? " (simulated outage)" : ""} since ${fmtTime(s.mode_changed_at_ms)}`);
  out.push(`Chain height  ${s.last_known_height ?? "unknown"} (last contact ${fmtTime(s.last_online_ms)})`);
  out.push(`SKU cache     ${Object.keys(s.skus).length} SKU(s)${Object.values(s.skus).some((k) => k.scarce) ? `, scarce: ${Object.values(s.skus).filter((k) => k.scarce).map((k) => k.sku).join(", ")}` : ""}`);
  const al = Object.values(s.allowances).filter((a) => a.status === "ACTIVE");
  out.push(`Allowances    ${al.length === 0 ? "none" : `${al.length} active`}`);
  if (al.length > 0) {
    out.push(...table(["  reservation", "sku", "granted", "chain left", "pending*", "usable", "expires"], al.map((a) => [`  ${a.reservation_id}`, a.sku, String(a.granted_v), String(a.chain_remaining_v), String(a.pending_v), String(a.chain_remaining_v - a.pending_v), fmtTime(a.expires_at_ms)])));
    out.push("  * pending = sold offline, UNFINALISED / NOT CONFIRMED");
  }
  const counts = (st: QueueItem["status"]) => s.queue.filter((q) => q.status === st).length;
  out.push(`Queue         ${counts("UNFINALISED")} UNFINALISED, ${counts("ACCEPTED")} accepted, ${counts("REJECTED")} rejected, ${counts("CANCELLED")} cancelled`);
  out.push(`Exceptions    ${rep.openExceptions.length} open`);
  for (const w of rep.warnings) out.push(`WARNING       ${w}`);
  return out;
}

export function formatQueue(items: QueueItem[]): string[] {
  if (items.length === 0) return ["queue is empty"];
  return table(
    ["id", "sale", "type", "status", "tx_id", "summary"],
    items.map((q) => [q.id, q.sale_ref, q.tx_type, q.status === "UNFINALISED" ? `${q.status} / NOT CONFIRMED` : q.status + (q.result ? ` ${q.result.code_name}` : ""), q.tx_id, q.summary]),
  );
}

export function formatSync(rep: SyncReport): string[] {
  const out: string[] = [];
  if (rep.rows.length === 0 && !rep.interrupted) return ["nothing to sync: the queue has no UNFINALISED requests"];
  out.push("SYNC RESULT (each request submitted with wait=final, in queue order)");
  out.push(
    ...table(
      ["queue", "type", "result", "code", "height", "reason"],
      rep.rows.map((r) => [r.queue_id, r.tx_type, r.status === "UNFINALISED" ? `UNFINALISED / NOT CONFIRMED` : r.status, r.code_name, r.height === undefined ? "-" : String(r.height), r.reason]),
    ),
  );
  out.push(`ACCEPTED ${rep.accepted}   REJECTED ${rep.rejected}   still UNFINALISED ${rep.stillUnfinalised}`);
  if (rep.interrupted) out.push(`SYNC INTERRUPTED: ${rep.interrupted}. Remaining requests stay UNFINALISED / NOT CONFIRMED.`);
  for (const e of rep.newExceptions) out.push(`NEW EXCEPTION ${e.id} for sale ${e.sale_ref}: ${e.reasons.map((r) => `${r.tx_type} ${r.code_name}`).join("; ")}`);
  if (rep.newExceptions.length > 0) out.push("Run `exceptions` to review and `resolve <id> retry|cancel|escalate`.");
  return out;
}

export function formatExceptions(list: ExceptionItem[]): string[] {
  if (list.length === 0) return ["no open exceptions"];
  const out = table(
    ["id", "sale", "status", "created", "reason"],
    list.map((e) => [e.id, e.sale_ref, e.status, fmtTime(e.created_at_ms), e.reasons.map((r) => `${r.tx_type}:${r.code_name}${r.reason ? ` (${r.reason})` : ""}`).join("; ")]),
  );
  for (const e of list) if (e.orphan_reservations.length > 0) out.push(`  ${e.id}: reservations still holding stock on chain: ${e.orphan_reservations.join(", ")}`);
  return out;
}

export function formatEscalation(r: EscalationRecord): string[] {
  const out = boxed([`ESCALATION ${r.id} for exception ${r.exception_id}`, `terminal ${r.terminal_id} @ ${r.location_id}   sale ${r.sale_ref}`]);
  out.push(`Problem: ${r.problem}`);
  if (r.goods_may_have_left_store) out.push("NOTE: this was an OFFLINE sale - the goods may already have left the store.");
  out.push("Lines:");
  for (const l of r.lines) out.push(`  ${l.qty_v} ${l.unit} ${l.sku}${l.scarce ? " [scarce]" : ""} (${l.backing})`);
  out.push("Rejections:");
  for (const x of r.reasons) out.push(`  ${x.tx_type} ${x.tx_id ?? ""} -> ${x.code_name}${x.reason ? `: ${x.reason}` : ""}`);
  out.push("Suggested manager actions:");
  for (const a of r.suggested_actions) {
    out.push(`  ${a.step}. [${a.actor}] ${a.action}`);
    if (a.tx_type) out.push(`       ${a.tx_type} ${JSON.stringify(a.payload_template)}`);
    if (a.note) out.push(`       note: ${a.note}`);
  }
  if (r.note) out.push(`Note: ${r.note}`);
  return out;
}

export function formatResolve(r: ResolveResult): string[] {
  const out = [r.ok ? `OK: ${r.message}` : `NOT RESOLVED: ${r.message}`];
  for (const n of r.notes) out.push(`  ${n}`);
  if (r.escalation) out.push("", ...formatEscalation(r.escalation));
  return out;
}
