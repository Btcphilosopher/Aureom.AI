// Offline-capable POS terminal simulator (logic only; no console I/O — see cli.ts / format.ts).
//
// Inventory policy while OFFLINE (documented in docs/SDK.md):
//   (a) SCARCE SKUs may only be sold against a pre-allocated ALLOWANCE reservation held by this
//       terminal, with enough units remaining as tracked locally. Otherwise: refuse.
//   (b) NON-SCARCE SKUs may be sold without an allowance: the terminal pre-signs a ReserveStock
//       (new reservation id) followed by a CompleteSale that references it. If the chain later
//       rejects the ReserveStock (no stock) the dependent sale is REJECTED -> exception. That is
//       oversell RISK accepted by policy; the chain cannot prevent overselling across
//       disconnected stores.
//   Everything signed offline is UNFINALISED / NOT CONFIRMED until the chain finalises it.

import {
  GatewayError,
  NetworkError,
  SdkError,
  TimeoutError,
  TxBuilder,
  RE_CUSTOMER,
  codeName,
  newBusinessId,
  outcomeOf,
  sleep as realSleep,
  type BuildOptions,
  type ChainParams,
  type Identity,
  type Product,
  type Reservation,
  type SignedTx,
  type Signer,
  type Sku,
  type SubmitResponse,
  type TxGateway,
  type TxOutcome,
  type TxPayloadMap,
  type TxType,
} from "../src/index.js";
import { planEscalation } from "./escalation.js";
import type {
  AllowanceRec,
  EscalationRecord,
  ExceptionItem,
  ItemResult,
  LineBacking,
  Mode,
  QueueItem,
  SaleLineRec,
  SaleRecord,
  SkuCache,
  StateStore,
  TerminalState,
} from "./state.js";
import { newState } from "./state.js";

// ---- Errors --------------------------------------------------------------------------------

export class PolicyRefusal extends SdkError {
  constructor(message: string) {
    super("POLICY_REFUSED", message);
  }
}

export class OfflineError extends SdkError {
  constructor(op: string) {
    super("OFFLINE", `${op} needs the network, but this terminal is OFFLINE (simulated outage). Run go-online first. No network call was attempted.`);
  }
}

export class SaleFailed extends SdkError {
  constructor(message: string, readonly details: { codeName: string; reason: string; txType: string }) {
    super("SALE_FAILED", message);
  }
}

// ---- Configuration -------------------------------------------------------------------------

export interface TerminalConfig {
  /** TTL of ordinary reservations (online and pre-signed offline). Chain limit: reservation_max_ttl_ms (30 min). */
  reserveTtlMs: number;
  /** Do not sell against an allowance that expires within this margin of the terminal's clock. */
  allowanceSafetyMarginMs: number;
  /** Horizon used to compute valid_until_height of requests signed offline (chain backdate window is 3 days). */
  offlineWindowMs: number;
  /** Server-side finality wait per submitted request. */
  submitTimeoutMs: number;
  /** How long sync waits for an admitted-but-not-yet-final tx before leaving it UNFINALISED. */
  finalityPollMs: number;
}

export const DEFAULT_CONFIG: TerminalConfig = {
  reserveTtlMs: 10 * 60_000,
  allowanceSafetyMarginMs: 15 * 60_000,
  offlineWindowMs: 3 * 24 * 3600_000,
  submitTimeoutMs: 20_000,
  finalityPollMs: 15_000,
};

const DEFAULT_ALLOWANCE_MAX_TTL_MS = 7 * 24 * 3600_000;
const DEFAULT_RESERVATION_MAX_TTL_MS = 30 * 60_000;
const DEFAULT_MAX_BACKDATE_MS = 3 * 24 * 3600_000;
const SKU_CACHE_MAX_AGE_MS = 24 * 3600_000;

export interface TerminalOptions {
  store: StateStore;
  gateway: TxGateway;
  signer: Signer;
  /** Used only when no state file exists yet. */
  networkId?: string;
  locationId?: string;
  config?: Partial<TerminalConfig>;
  now?: () => number;
  /** id generator (injectable for tests). */
  newId?: (prefix: string) => string;
  sleep?: (ms: number) => Promise<void>;
}

// ---- Result types --------------------------------------------------------------------------

export interface SellLineInput {
  sku: string;
  qty: number;
}
export interface SellOptions {
  customerId?: string;
  paymentMethod?: string;
  /** Online only: back lines with a local allowance instead of taking a fresh reservation. */
  useAllowance?: boolean;
}
export interface SellResult {
  mode: Mode;
  sale: SaleRecord;
  queue: QueueItem[];
  /** Online: the CompleteSale result. */
  finalised?: { height: number; data: Record<string, unknown> };
  /** Online sale whose outcome could not be determined (connection lost); queued for reconciliation. */
  outcomeUnknown?: boolean;
  /** Offline lines grouped by policy decision (for the receipt). */
  notes: string[];
}

export interface SyncRow {
  queue_id: string;
  sale_ref: string;
  tx_type: string;
  tx_id: string;
  status: "ACCEPTED" | "REJECTED" | "UNFINALISED";
  code_name: string;
  height?: number;
  reason: string;
}
export interface SyncReport {
  rows: SyncRow[];
  accepted: number;
  rejected: number;
  stillUnfinalised: number;
  newExceptions: ExceptionItem[];
  /** Set when the gateway became unreachable mid-sync (remaining items stay UNFINALISED). */
  interrupted?: string;
}

export interface StatusReport {
  state: TerminalState;
  unfinalised: QueueItem[];
  openExceptions: ExceptionItem[];
  warnings: string[];
}

export interface RefreshReport {
  skus: string[];
  allowances: { reservation_id: string; sku: string; chain_remaining_v: number; status: string }[];
  location_id: string;
  height?: number;
}

export type ResolveAction = "retry" | "cancel" | "escalate";
export interface ResolveResult {
  exception: ExceptionItem;
  action: ResolveAction;
  ok: boolean;
  message: string;
  notes: string[];
  escalation?: EscalationRecord;
  txIds: string[];
}

function isTransient(e: unknown): boolean {
  return e instanceof NetworkError || e instanceof TimeoutError || (e instanceof GatewayError && e.status >= 500);
}

export class Terminal {
  private constructor(
    private readonly s: TerminalState,
    private readonly o: Required<Pick<TerminalOptions, "store" | "gateway" | "signer">> & { now: () => number; newId: (p: string) => string; sleep: (ms: number) => Promise<void>; cfg: TerminalConfig },
  ) {}

  static async open(opts: TerminalOptions): Promise<Terminal> {
    const now = opts.now ?? Date.now;
    let state = await opts.store.load();
    if (!state) {
      state = newState({
        terminal_id: opts.signer.identity,
        location_id: opts.locationId ?? "STORE-N-01",
        network_id: opts.networkId ?? "aureom-retail-demo-1",
        now: now(),
      });
      await opts.store.save(state);
    } else {
      if (state.terminal_id !== opts.signer.identity) {
        throw new PolicyRefusal(`state file belongs to terminal ${state.terminal_id}, but the signing identity is ${opts.signer.identity}`);
      }
      if (opts.networkId && opts.networkId !== state.network_id) {
        throw new PolicyRefusal(`state file is for network ${state.network_id}, not ${opts.networkId}`);
      }
    }
    return new Terminal(state, {
      store: opts.store,
      gateway: opts.gateway,
      signer: opts.signer,
      now,
      newId: opts.newId ?? ((p) => newBusinessId(p, now())),
      sleep: opts.sleep ?? realSleep,
      cfg: { ...DEFAULT_CONFIG, ...opts.config },
    });
  }

  // ---- Small helpers -----------------------------------------------------------------------

  get state(): Readonly<TerminalState> {
    return this.s;
  }
  private now(): number {
    return this.o.now();
  }
  private async persist(): Promise<void> {
    await this.o.store.save(this.s);
  }
  /** The ONLY way to reach the gateway: refuses (without any network call) when the terminal is OFFLINE. */
  private net(op: string): TxGateway {
    if (this.s.mode === "OFFLINE") throw new OfflineError(op);
    return this.o.gateway;
  }
  private builder(): TxBuilder {
    return new TxBuilder({ networkId: this.s.network_id, signer: this.o.signer, now: this.o.now });
  }
  private qid(): string {
    this.s.counters.queue += 1;
    return `Q-${String(this.s.counters.queue).padStart(4, "0")}`;
  }
  private maxBackdateMs(): number {
    return this.s.chain_params?.max_backdate_ms ?? DEFAULT_MAX_BACKDATE_MS;
  }
  private reserveTtlMs(): number {
    return Math.min(this.o.cfg.reserveTtlMs, this.s.chain_params?.reservation_max_ttl_ms ?? DEFAULT_RESERVATION_MAX_TTL_MS);
  }
  /** valid_until_height for requests signed without network access (bounds the replay window). */
  private offlineValidUntil(): number | undefined {
    const h = this.s.last_known_height;
    if (h === undefined) return undefined;
    const interval = Math.max(this.s.block_interval_ms ?? 1000, 100);
    return h + Math.ceil(Math.min(this.o.cfg.offlineWindowMs, this.maxBackdateMs()) / interval);
  }
  private noteChain(height: number | undefined, intervalMs?: number): void {
    if (height !== undefined && (this.s.last_known_height === undefined || height > this.s.last_known_height)) this.s.last_known_height = height;
    if (intervalMs && intervalMs > 0) this.s.block_interval_ms = intervalMs;
    this.s.last_online_ms = this.now();
  }

  // ---- Mode switch -------------------------------------------------------------------------

  async goOffline(): Promise<void> {
    this.s.mode = "OFFLINE";
    this.s.mode_changed_at_ms = this.now();
    await this.persist();
  }

  /** Flip to ONLINE after checking the gateway answers; optionally sync the queue. */
  async goOnline(opts: { sync?: boolean } = {}): Promise<{ sync?: SyncReport }> {
    const previous = this.s.mode;
    this.s.mode = "ONLINE";
    try {
      const n = await this.o.gateway.network();
      if (n.network_id && n.network_id !== this.s.network_id) {
        this.s.mode = previous;
        throw new PolicyRefusal(`gateway is network ${n.network_id}, this terminal is provisioned for ${this.s.network_id}`);
      }
      this.noteChain(n.chain?.latest_height, n.chain?.block_interval_ms_avg);
    } catch (e) {
      this.s.mode = previous;
      await this.persist();
      if (e instanceof PolicyRefusal) throw e;
      throw new NetworkError(`gateway unreachable, terminal stays ${previous}: ${e instanceof Error ? e.message : String(e)}`, e);
    }
    this.s.mode_changed_at_ms = this.now();
    await this.persist();
    const wantSync = opts.sync ?? true;
    if (wantSync && this.s.queue.some((q) => q.status === "UNFINALISED")) return { sync: await this.sync() };
    return {};
  }

  // ---- Status ------------------------------------------------------------------------------

  status(): StatusReport {
    const unfinalised = this.s.queue.filter((q) => q.status === "UNFINALISED");
    const openExceptions = this.s.exceptions.filter((e) => e.status === "OPEN" || e.status === "ESCALATED");
    const warnings: string[] = [];
    const t = this.now();
    for (const a of Object.values(this.s.allowances)) {
      if (a.status !== "ACTIVE") continue;
      if (a.expires_at_ms <= t) warnings.push(`allowance ${a.reservation_id} (${a.sku}) has EXPIRED by the terminal clock`);
      else if (a.expires_at_ms - t < this.o.cfg.allowanceSafetyMarginMs) warnings.push(`allowance ${a.reservation_id} (${a.sku}) expires in under ${Math.round(this.o.cfg.allowanceSafetyMarginMs / 60000)} min: offline sales against it are refused`);
    }
    const oldest = unfinalised.reduce<number | undefined>((m, q) => (m === undefined || q.queued_at_ms < m ? q.queued_at_ms : m), undefined);
    if (oldest !== undefined && t - oldest > 0.8 * this.maxBackdateMs()) {
      warnings.push(`oldest UNFINALISED request is ${Math.round((t - oldest) / 3600_000)} h old; the chain rejects sales whose effective time is older than ${Math.round(this.maxBackdateMs() / 3600_000)} h before the block that includes them`);
    }
    if (this.s.mode === "OFFLINE" && this.s.last_known_height === undefined) warnings.push("no chain height known: requests signed now carry no valid_until_height");
    return { state: this.s, unfinalised, openExceptions, warnings };
  }

  // ---- Cache refresh (online) --------------------------------------------------------------

  private async fetchSku(gw: TxGateway, skuId: string): Promise<SkuCache> {
    const r = await gw.getRecord<Sku>(`sku/${skuId}`);
    if (!r.found || !r.value) throw new PolicyRefusal(`SKU ${skuId} does not exist on the chain`);
    this.noteChain(r.height);
    const cache: SkuCache = { sku: skuId, unit: r.value.unit, scarce: r.value.scarce === true, status: r.value.status, product_id: r.value.product_id, cached_at_ms: this.now() };
    try {
      const p = await gw.getRecord<Product>(`product/${r.value.product_id}`);
      if (p.found && p.value) cache.product_name = p.value.name;
    } catch (e) {
      if (!isTransient(e)) throw e; // a missing product name is cosmetic
    }
    this.s.skus[skuId] = cache;
    return cache;
  }

  private async ensureSkuOnline(skuId: string): Promise<SkuCache> {
    const c = this.s.skus[skuId];
    if (c && this.now() - c.cached_at_ms < SKU_CACHE_MAX_AGE_MS) return c;
    return this.fetchSku(this.net("sku lookup"), skuId);
  }

  /** Refresh SKU metadata (default: every cached SKU and every allowance SKU), chain params, bound location and allowance balances. */
  async refresh(skus?: string[]): Promise<RefreshReport> {
    const gw = this.net("refresh");
    const ids = new Set<string>(skus ?? [...Object.keys(this.s.skus), ...Object.values(this.s.allowances).map((a) => a.sku)]);
    for (const id of ids) await this.fetchSku(gw, id);
    try {
      const p = await gw.getRecord<ChainParams>("gov/params");
      if (p.found && p.value) {
        this.s.chain_params = {
          reservation_max_ttl_ms: p.value.reservation_max_ttl_ms,
          allowance_max_ttl_ms: p.value.allowance_max_ttl_ms,
          max_backdate_ms: p.value.max_backdate_ms,
          max_future_skew_ms: p.value.max_future_skew_ms,
        };
      }
      const idr = await gw.getRecord<Identity>(`iam/id/${this.s.terminal_id}`);
      if (idr.found && idr.value?.bound_location) this.s.location_id = idr.value.bound_location;
    } catch (e) {
      if (!isTransient(e)) throw e;
    }
    const report: RefreshReport["allowances"] = [];
    for (const a of Object.values(this.s.allowances)) {
      if (a.status !== "ACTIVE") continue;
      const r = await gw.getRecord<Reservation>(`resv/${a.reservation_id}`);
      if (r.found && r.value) {
        a.chain_remaining_v = r.value.qty;
        a.status = r.value.status;
        a.expires_at_ms = r.value.expires_at_ms;
      }
      report.push({ reservation_id: a.reservation_id, sku: a.sku, chain_remaining_v: a.chain_remaining_v, status: a.status });
    }
    const n = await gw.network();
    this.noteChain(n.chain?.latest_height, n.chain?.block_interval_ms_avg);
    await this.persist();
    return { skus: [...ids], allowances: report, location_id: this.s.location_id, ...(this.s.last_known_height !== undefined ? { height: this.s.last_known_height } : {}) };
  }

  // ---- Allowances (online only) ------------------------------------------------------------

  /** Pre-allocate stock for offline selling: ReserveStock{allowance:true, terminal_id, ttl up to the chain limit}. */
  async requestAllowance(skuId: string, qty: number, opts: { ttlMs?: number } = {}): Promise<AllowanceRec> {
    const gw = this.net("allowance");
    if (!Number.isSafeInteger(qty) || qty <= 0) throw new PolicyRefusal("allowance quantity must be a positive integer (in the SKU unit's smallest step)");
    const sku = await this.ensureSkuOnline(skuId);
    if (sku.status !== "ACTIVE") throw new PolicyRefusal(`SKU ${skuId} is ${sku.status}`);
    try {
      const p = await gw.getRecord<ChainParams>("gov/params");
      if (p.found && p.value) {
        this.s.chain_params = {
          reservation_max_ttl_ms: p.value.reservation_max_ttl_ms,
          allowance_max_ttl_ms: p.value.allowance_max_ttl_ms,
          max_backdate_ms: p.value.max_backdate_ms,
          max_future_skew_ms: p.value.max_future_skew_ms,
        };
      }
    } catch (e) {
      if (!isTransient(e)) throw e;
    }
    const maxTtl = this.s.chain_params?.allowance_max_ttl_ms ?? DEFAULT_ALLOWANCE_MAX_TTL_MS;
    const ttl = opts.ttlMs ?? maxTtl;
    if (ttl <= 0 || ttl > maxTtl) throw new PolicyRefusal(`allowance ttl ${ttl} ms exceeds the chain limit of ${maxTtl} ms`);
    const reservationId = this.o.newId("ALW");
    const tx = await this.builder().build(
      "ReserveStock",
      { reservation_id: reservationId, location_id: this.s.location_id, sku: skuId, qty: { v: qty, unit: sku.unit }, ttl_ms: ttl, terminal_id: this.s.terminal_id, allowance: true },
      { idempotencyRef: `resv:${reservationId}` },
    );
    const resp = await gw.submit(tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs });
    const out = outcomeOf(resp);
    if (out.status === "FINALISED_OK") {
      const expires = Number(out.data["expires_at_ms"] ?? this.now() + ttl);
      const rec: AllowanceRec = {
        reservation_id: reservationId,
        sku: skuId,
        unit: sku.unit,
        location_id: this.s.location_id,
        granted_v: qty,
        chain_remaining_v: qty,
        pending_v: 0,
        expires_at_ms: expires,
        created_at_ms: this.now(),
        tx_id: tx.txId,
        height: out.height,
        status: "ACTIVE",
      };
      this.s.allowances[reservationId] = rec;
      this.noteChain(out.height);
      await this.persist();
      return rec;
    }
    await this.persist();
    throw new SaleFailed(`allowance for ${skuId} was not granted: ${describeOutcome(out)}`, { ...failureOf(out), txType: "ReserveStock" });
  }

  /** Give unused allowance units back (ReleaseReservation CANCELLED). Online only. */
  async releaseAllowance(reservationId: string): Promise<AllowanceRec> {
    const gw = this.net("release allowance");
    const a = this.s.allowances[reservationId];
    if (!a) throw new PolicyRefusal(`no local allowance ${reservationId}`);
    if (a.pending_v > 0) throw new PolicyRefusal(`allowance ${reservationId} still has ${a.pending_v} unit(s) sold offline and UNFINALISED; sync first`);
    const tx = await this.builder().build("ReleaseReservation", { reservation_id: reservationId, reason: "CANCELLED" }, { idempotencyRef: `release:${reservationId}` });
    const out = outcomeOf(await gw.submit(tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs }));
    if (out.status !== "FINALISED_OK") throw new SaleFailed(`release failed: ${describeOutcome(out)}`, { ...failureOf(out), txType: "ReleaseReservation" });
    a.status = "RELEASED";
    a.chain_remaining_v = 0;
    await this.persist();
    return a;
  }

  // ---- Selling -----------------------------------------------------------------------------

  private newSaleId(): string {
    return this.o.newId("TS");
  }

  private validateLines(lines: SellLineInput[]): void {
    if (lines.length === 0) throw new PolicyRefusal("a sale needs at least one line");
    const seen = new Set<string>();
    for (const l of lines) {
      if (!Number.isSafeInteger(l.qty) || l.qty <= 0) throw new PolicyRefusal(`quantity for ${l.sku} must be a positive integer`);
      if (seen.has(l.sku)) throw new PolicyRefusal(`SKU ${l.sku} appears twice; combine the quantities`);
      seen.add(l.sku);
    }
  }

  /** Allowance usable offline for `qty` units of `sku`, by the terminal's clock and local tracking. */
  private usableAllowance(sku: string, qty: number, claimed: Map<string, number>): AllowanceRec | undefined {
    const t = this.now();
    return Object.values(this.s.allowances)
      .filter((a) => a.sku === sku && a.status === "ACTIVE" && a.expires_at_ms - this.o.cfg.allowanceSafetyMarginMs > t)
      .filter((a) => a.chain_remaining_v - a.pending_v - (claimed.get(a.reservation_id) ?? 0) >= qty)
      .sort((x, y) => x.expires_at_ms - y.expires_at_ms)[0];
  }

  private allowanceSummary(sku: string): string {
    const t = this.now();
    const list = Object.values(this.s.allowances).filter((a) => a.sku === sku && a.status === "ACTIVE");
    if (list.length === 0) return "no allowance held";
    return list.map((a) => `${a.reservation_id}: ${a.chain_remaining_v - a.pending_v} usable${a.expires_at_ms - this.o.cfg.allowanceSafetyMarginMs <= t ? " (expired/expiring)" : ""}`).join("; ");
  }

  async sell(lines: SellLineInput[], opts: SellOptions = {}): Promise<SellResult> {
    this.validateLines(lines);
    if (opts.customerId !== undefined && !RE_CUSTOMER.test(opts.customerId)) throw new PolicyRefusal("customer must be a synthetic/pseudonymous reference: CUST-xxxx or PSN-xxxx");
    const pm = opts.paymentMethod ?? "CARD";
    if (!/^[\x20-\x7e]{1,30}$/.test(pm)) throw new PolicyRefusal("payment method must be 1-30 printable ASCII characters");
    return this.s.mode === "OFFLINE" ? this.sellOffline(lines, opts) : this.sellOnline(lines, opts);
  }

  // OFFLINE: build + sign locally, append to the durable queue. NO network access.
  private async sellOffline(lines: SellLineInput[], opts: SellOptions): Promise<SellResult> {
    const notes: string[] = [];
    // 1) policy decision for every line BEFORE signing anything (all-or-nothing)
    type Plan = { line: SellLineInput; meta: SkuCache; allowance?: AllowanceRec };
    const plans: Plan[] = [];
    const claimed = new Map<string, number>();
    for (const l of lines) {
      const meta = this.s.skus[l.sku];
      if (!meta) {
        throw new PolicyRefusal(`SKU ${l.sku} is not in this terminal's offline cache (it has never been seen online), so its scarcity and unit are unknown. Online finality required: go online and run \`refresh ${l.sku}\`.`);
      }
      if (meta.status !== "ACTIVE") throw new PolicyRefusal(`SKU ${l.sku} is ${meta.status} in the offline cache`);
      const allowance = this.usableAllowance(l.sku, l.qty, claimed);
      if (meta.scarce && !allowance) {
        throw new PolicyRefusal(
          `online finality required for scarce items: ${l.sku} is scarce and this terminal holds no usable pre-allocated allowance with ${l.qty} unit(s) remaining (${this.allowanceSummary(l.sku)}). ` +
            `Go online and run \`allowance ${l.sku} <qty>\` before the outage.`,
        );
      }
      if (allowance) claimed.set(allowance.reservation_id, (claimed.get(allowance.reservation_id) ?? 0) + l.qty);
      plans.push({ line: l, meta, ...(allowance ? { allowance } : {}) });
    }

    // 2) sign everything locally
    const b = this.builder();
    const t = this.now();
    const validUntil = this.offlineValidUntil();
    const bo = (idem: string): BuildOptions => ({ idempotencyRef: idem, ...(validUntil !== undefined ? { validUntilHeight: validUntil } : {}) });
    const saleId = this.newSaleId();
    const queueItems: QueueItem[] = [];
    const saleLines: SaleLineRec[] = [];
    const reserveQueueIds: string[] = [];
    for (const p of plans) {
      if (p.allowance) {
        saleLines.push({ sku: p.line.sku, qty_v: p.line.qty, unit: p.meta.unit, scarce: p.meta.scarce, backing: "ALLOWANCE", reservation_id: p.allowance.reservation_id, allowance_id: p.allowance.reservation_id });
        notes.push(`${p.line.sku}: backed by allowance ${p.allowance.reservation_id} (stock already reserved on chain for this terminal)`);
        continue;
      }
      const resId = this.o.newId("RSV");
      const tx = await b.build(
        "ReserveStock",
        { reservation_id: resId, location_id: this.s.location_id, sku: p.line.sku, qty: { v: p.line.qty, unit: p.meta.unit }, ttl_ms: this.reserveTtlMs(), terminal_id: this.s.terminal_id },
        bo(`resv:${resId}`),
      );
      const qi = this.queueItemFor(tx, saleId, "RESERVE", `reserve ${p.line.qty} x ${p.line.sku} (${resId})`, t, [], resId);
      reserveQueueIds.push(qi.id);
      queueItems.push(qi);
      saleLines.push({ sku: p.line.sku, qty_v: p.line.qty, unit: p.meta.unit, scarce: p.meta.scarce, backing: "PRESIGNED_RESERVATION", reservation_id: resId });
      notes.push(`${p.line.sku}: NOT stock-protected - pre-signed reservation ${resId} may be rejected at sync (oversell risk accepted by policy)`);
    }
    const saleTx = await b.build("CompleteSale", this.salePayload(saleId, saleLines, t, opts), bo(`sale:${saleId}`));
    queueItems.push(this.queueItemFor(saleTx, saleId, "SALE", `complete sale ${saleId}`, t, reserveQueueIds));

    // 3) commit to the durable queue + local allowance tracking in ONE write
    for (const qi of queueItems) this.s.queue.push(qi);
    for (const sl of saleLines) if (sl.backing === "ALLOWANCE") (this.s.allowances[sl.reservation_id] as AllowanceRec).pending_v += sl.qty_v;
    const sale: SaleRecord = {
      sale_id: saleId,
      mode: "OFFLINE",
      status: "UNFINALISED",
      created_at_ms: t,
      effective_at_ms: t,
      location_id: this.s.location_id,
      ...(opts.customerId ? { customer_id: opts.customerId } : {}),
      payment_method: opts.paymentMethod ?? "CARD",
      lines: saleLines,
      queue_ids: queueItems.map((q) => q.id),
      tx_ids: [],
      retries: 0,
    };
    this.s.sales[saleId] = sale;
    await this.persist();
    return { mode: "OFFLINE", sale, queue: queueItems, notes };
  }

  private salePayload(saleId: string, lines: SaleLineRec[], effectiveAtMs: number, opts: SellOptions): TxPayloadMap["CompleteSale"] {
    return {
      sale_id: saleId,
      location_id: this.s.location_id,
      channel: "STORE",
      terminal_id: this.s.terminal_id,
      ...(opts.customerId ? { customer_id: opts.customerId } : {}),
      effective_at_ms: effectiveAtMs,
      currency: "GBP",
      payment_method: opts.paymentMethod ?? "CARD",
      lines: lines.map((l) => ({ sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, reservation_id: l.reservation_id })),
    };
  }

  private queueItemFor(tx: SignedTx<TxType>, saleRef: string, kind: QueueItem["kind"], summary: string, at: number, dependsOn: string[], reservationId?: string): QueueItem {
    return {
      id: this.qid(),
      sale_ref: saleRef,
      kind,
      tx_type: tx.type as QueueItem["tx_type"],
      tx_id: tx.txId,
      idempotency_ref: tx.idempotencyRef,
      envelope: tx.envelope,
      signed_by: `${tx.signer}#${tx.keyId}`,
      summary,
      ...(reservationId ? { reservation_id: reservationId } : {}),
      depends_on: dependsOn,
      queued_at_ms: at,
      status: "UNFINALISED",
      attempts: 0,
    };
  }

  // ONLINE: Reserve (+CompleteSale) with finality.
  private async sellOnline(lines: SellLineInput[], opts: SellOptions): Promise<SellResult> {
    const gw = this.net("online sale");
    const b = this.builder();
    const metas = new Map<string, SkuCache>();
    for (const l of lines) metas.set(l.sku, await this.ensureSkuOnline(l.sku));
    const saleId = this.newSaleId();
    const t = this.now();
    const saleLines: SaleLineRec[] = [];
    const reserveTxs: { tx: SignedTx<"ReserveStock">; resId: string; line: SaleLineRec }[] = [];
    const claimed = new Map<string, number>();
    for (const l of lines) {
      const meta = metas.get(l.sku) as SkuCache;
      const allowance = opts.useAllowance ? this.usableAllowance(l.sku, l.qty, claimed) : undefined;
      if (allowance) {
        claimed.set(allowance.reservation_id, (claimed.get(allowance.reservation_id) ?? 0) + l.qty);
        saleLines.push({ sku: l.sku, qty_v: l.qty, unit: meta.unit, scarce: meta.scarce, backing: "ALLOWANCE", reservation_id: allowance.reservation_id, allowance_id: allowance.reservation_id });
        continue;
      }
      const resId = this.o.newId("RSV");
      const tx = await b.build(
        "ReserveStock",
        { reservation_id: resId, location_id: this.s.location_id, sku: l.sku, qty: { v: l.qty, unit: meta.unit }, ttl_ms: this.reserveTtlMs(), terminal_id: this.s.terminal_id },
        { idempotencyRef: `resv:${resId}` },
      );
      const line: SaleLineRec = { sku: l.sku, qty_v: l.qty, unit: meta.unit, scarce: meta.scarce, backing: "ONLINE_RESERVATION", reservation_id: resId };
      saleLines.push(line);
      reserveTxs.push({ tx, resId, line });
    }
    const sale: SaleRecord = {
      sale_id: saleId,
      mode: "ONLINE",
      status: "UNFINALISED",
      created_at_ms: t,
      effective_at_ms: t,
      location_id: this.s.location_id,
      ...(opts.customerId ? { customer_id: opts.customerId } : {}),
      payment_method: opts.paymentMethod ?? "CARD",
      lines: saleLines,
      queue_ids: [],
      tx_ids: reserveTxs.map((r) => r.tx.txId),
      retries: 0,
    };
    // reservations in parallel (they compete fairly in the chain's total order)
    const outs = await Promise.all(reserveTxs.map((r) => gw.submit(r.tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs }).then(outcomeOf)));
    const failed = outs.map((o, i) => ({ o, r: reserveTxs[i] as (typeof reserveTxs)[number] })).filter((x) => x.o.status !== "FINALISED_OK");
    if (failed.length > 0) {
      const accepted = reserveTxs.filter((_, i) => (outs[i] as TxOutcome).status === "FINALISED_OK");
      await this.releaseBestEffort(accepted.map((a) => a.resId));
      sale.status = "REJECTED";
      this.s.sales[saleId] = sale;
      await this.persist();
      const f = failed[0] as (typeof failed)[number];
      throw new SaleFailed(`sale not completed: ${f.r.line.sku}: ${describeOutcome(f.o)}`, { ...failureOf(f.o), txType: "ReserveStock" });
    }
    const saleTx = await b.build("CompleteSale", this.salePayload(saleId, saleLines, t, opts), { idempotencyRef: `sale:${saleId}` });
    sale.tx_ids.push(saleTx.txId);
    let resp: SubmitResponse;
    try {
      resp = await gw.submit(saleTx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs });
    } catch (e) {
      if (!isTransient(e)) throw e;
      // The request is signed and may have been ordered: keep it, never lose it, reconcile at sync.
      const qi = this.queueItemFor(saleTx, saleId, "SALE", `complete sale ${saleId} (outcome unknown after connection loss)`, t, []);
      qi.attempts = 1;
      qi.submitted_at_ms = this.now();
      this.s.queue.push(qi);
      sale.queue_ids.push(qi.id);
      this.s.sales[saleId] = sale;
      await this.persist();
      return { mode: "ONLINE", sale, queue: [qi], outcomeUnknown: true, notes: ["connection lost while completing the sale: OUTCOME UNKNOWN, kept in the queue as UNFINALISED and checked against the chain at the next sync"] };
    }
    const out = outcomeOf(resp);
    if (out.status === "FINALISED_OK") {
      sale.status = "FINALISED";
      sale.finalised_height = out.height;
      sale.net_minor = Number(out.data["net_minor"] ?? 0);
      sale.gross_minor = Number(out.data["gross_minor"] ?? 0);
      sale.discount_minor = Number(out.data["discount_minor"] ?? 0);
      for (const sl of saleLines) {
        if (sl.backing === "ALLOWANCE") (this.s.allowances[sl.reservation_id] as AllowanceRec).chain_remaining_v -= sl.qty_v;
      }
      this.s.sales[saleId] = sale;
      this.noteChain(out.height);
      await this.persist();
      return { mode: "ONLINE", sale, queue: [], finalised: { height: out.height, data: out.data }, notes: [] };
    }
    if (out.status === "ADMITTED_NOT_FINAL") {
      const qi = this.queueItemFor(saleTx, saleId, "SALE", `complete sale ${saleId} (admitted, finality not yet seen)`, t, []);
      qi.attempts = 1;
      qi.submitted_at_ms = this.now();
      this.s.queue.push(qi);
      sale.queue_ids.push(qi.id);
      this.s.sales[saleId] = sale;
      await this.persist();
      return { mode: "ONLINE", sale, queue: [qi], outcomeUnknown: true, notes: ["the sale was admitted but finality was not observed within the wait budget: UNFINALISED, checked at next sync"] };
    }
    await this.releaseBestEffort(reserveTxs.map((r) => r.resId));
    sale.status = "REJECTED";
    this.s.sales[saleId] = sale;
    await this.persist();
    throw new SaleFailed(`sale rejected: ${describeOutcome(out)}`, { ...failureOf(out), txType: "CompleteSale" });
  }

  private async releaseBestEffort(reservationIds: string[]): Promise<void> {
    if (reservationIds.length === 0 || this.s.mode === "OFFLINE") return;
    const b = this.builder();
    await Promise.all(
      reservationIds.map(async (id) => {
        try {
          const tx = await b.build("ReleaseReservation", { reservation_id: id, reason: "CANCELLED" }, { idempotencyRef: `release:${id}` });
          await this.o.gateway.submit(tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs });
        } catch {
          // best effort: an unreleased reservation simply expires and is swept by its TTL
        }
      }),
    );
  }

  // ---- Sync --------------------------------------------------------------------------------

  /** Submit the UNFINALISED queue in order with wait=final; classify every request ACCEPTED or REJECTED. */
  async sync(): Promise<SyncReport> {
    const gw = this.net("sync");
    const rows: SyncRow[] = [];
    let interrupted: string | undefined;
    try {
      const n = await gw.network();
      this.noteChain(n.chain?.latest_height, n.chain?.block_interval_ms_avg);
    } catch (e) {
      throw new NetworkError(`sync aborted, gateway unreachable (queue untouched): ${e instanceof Error ? e.message : String(e)}`, e);
    }
    const pendingSales: string[] = [];
    for (const q of this.s.queue) if (q.status === "UNFINALISED" && !pendingSales.includes(q.sale_ref)) pendingSales.push(q.sale_ref);

    try {
      for (const saleRef of pendingSales) {
        const items = this.s.queue.filter((q) => q.sale_ref === saleRef && q.status === "UNFINALISED");
        // reservations of one sale go out concurrently; the dependent sale/release after them
        const reserves = items.filter((q) => q.kind === "RESERVE");
        await Promise.all(reserves.map((q) => this.processItem(q, rows)));
        for (const q of items.filter((i) => i.kind !== "RESERVE")) await this.processItem(q, rows);
      }
    } catch (e) {
      if (!isTransient(e)) throw e;
      interrupted = e instanceof Error ? e.message : String(e);
    }
    const created = this.reconcileSalesAndExceptions(pendingSales);
    await this.persist();
    return {
      rows: rows.sort((a, b) => a.queue_id.localeCompare(b.queue_id)),
      accepted: rows.filter((r) => r.status === "ACCEPTED").length,
      rejected: rows.filter((r) => r.status === "REJECTED").length,
      stillUnfinalised: this.s.queue.filter((q) => q.status === "UNFINALISED").length,
      newExceptions: created,
      ...(interrupted ? { interrupted } : {}),
    };
  }

  private rowFor(q: QueueItem, status: SyncRow["status"], r?: ItemResult): SyncRow {
    return { queue_id: q.id, sale_ref: q.sale_ref, tx_type: q.tx_type, tx_id: q.tx_id, status, code_name: r?.code_name ?? "-", ...(r?.height !== undefined ? { height: r.height } : {}), reason: r?.reason ?? "" };
  }

  private settle(q: QueueItem, status: "ACCEPTED" | "REJECTED", r: ItemResult, rows: SyncRow[]): void {
    q.status = status;
    q.result = r;
    rows.push(this.rowFor(q, status, r));
  }

  private async processItem(q: QueueItem, rows: SyncRow[]): Promise<void> {
    const gw = this.o.gateway;
    const now = this.now();
    // 1) dependency check: a sale whose reservation was rejected is never submitted
    for (const depId of q.depends_on) {
      const dep = this.s.queue.find((x) => x.id === depId);
      if (dep && (dep.status === "REJECTED" || dep.status === "CANCELLED")) {
        this.settle(q, "REJECTED", { stage: "dependency", code: 0, code_name: "DEPENDENCY_FAILED", reason: `${dep.tx_type} ${dep.reservation_id ?? dep.tx_id} was ${dep.status}: ${dep.result?.code_name ?? ""} ${dep.result?.reason ?? ""}`.trim(), at_ms: now }, rows);
        return;
      }
    }
    // 2) an earlier attempt may have been ordered although we never saw the answer: ask the chain first
    if (q.attempts > 0) {
      const st = await gw.txStatus(q.tx_id);
      if (st.status === "FINALISED_OK") return void this.settle(q, "ACCEPTED", { stage: "finalised", code: 0, code_name: "OK", reason: "finalised earlier (confirmed by tx status)", ...(st.height !== undefined ? { height: st.height } : {}), at_ms: now }, rows);
      if (st.status === "FINALISED_REJECTED") return void this.settle(q, "REJECTED", { stage: "finalised", code: st.code ?? 0, code_name: st.code_name ?? codeName(st.code ?? 0), reason: st.reason ?? "", ...(st.height !== undefined ? { height: st.height } : {}), at_ms: now }, rows);
    }
    // 3) submit
    q.attempts += 1;
    q.submitted_at_ms = now;
    const resp = await gw.submit(q.envelope, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs });
    let out = outcomeOf(resp);
    if (out.status === "ADMITTED_NOT_FINAL") out = await this.pollFinality(q.tx_id, out);
    const at = this.now();
    switch (out.status) {
      case "FINALISED_OK":
        this.settle(q, "ACCEPTED", { stage: "finalised", code: 0, code_name: "OK", reason: "", height: out.height, data: out.data, at_ms: at }, rows);
        this.noteChain(out.height);
        return;
      case "FINALISED_REJECTED":
        this.settle(q, "REJECTED", { stage: "finalised", code: out.code, code_name: out.codeName, reason: out.log, height: out.height, at_ms: at }, rows);
        return;
      case "ADMISSION_REJECTED": {
        // REPLAY / DUPLICATE_IDEMPOTENCY: our earlier attempt (answer lost) already succeeded or failed on chain.
        if (out.code === 210 || out.code === 211) {
          const st = await gw.txStatus(q.tx_id);
          if (st.status === "FINALISED_OK") return void this.settle(q, "ACCEPTED", { stage: "finalised", code: 0, code_name: "OK", reason: "already finalised (duplicate submission detected)", ...(st.height !== undefined ? { height: st.height } : {}), at_ms: at }, rows);
        }
        this.settle(q, "REJECTED", { stage: "admission", code: out.code, code_name: out.codeName, reason: out.log, at_ms: at }, rows);
        return;
      }
      case "ADMITTED_NOT_FINAL":
        rows.push(this.rowFor(q, "UNFINALISED"));
        return;
    }
  }

  private async pollFinality(txId: string, fallback: TxOutcome): Promise<TxOutcome> {
    const deadline = this.now() + this.o.cfg.finalityPollMs;
    for (;;) {
      const st = await this.o.gateway.txStatus(txId);
      if (st.status === "FINALISED_OK") return { status: "FINALISED_OK", height: st.height ?? 0, index: st.index ?? 0, data: {}, indexed: st.indexed === true };
      if (st.status === "FINALISED_REJECTED") return { status: "FINALISED_REJECTED", height: st.height ?? 0, index: st.index ?? 0, code: st.code ?? 0, codeName: st.code_name ?? codeName(st.code ?? 0), log: st.reason ?? "" };
      if (this.now() >= deadline) return fallback;
      await this.o.sleep(250);
    }
  }

  /** After a sync pass: update sale records, allowance counters and open exceptions. */
  private reconcileSalesAndExceptions(saleRefs: string[]): ExceptionItem[] {
    const created: ExceptionItem[] = [];
    for (const ref of saleRefs) {
      const sale = this.s.sales[ref];
      const items = this.s.queue.filter((q) => q.sale_ref === ref);
      const saleItem = items.find((q) => q.kind === "SALE");
      // only a sale that is still UNFINALISED can change status here (cancelled / retried sales are left alone)
      if (!sale || !saleItem || sale.status !== "UNFINALISED") continue;
      if (saleItem.status === "ACCEPTED") {
        sale.status = "FINALISED";
        if (saleItem.result?.height !== undefined) sale.finalised_height = saleItem.result.height;
        const d = saleItem.result?.data ?? {};
        if (d["net_minor"] !== undefined) {
          sale.net_minor = Number(d["net_minor"]);
          sale.gross_minor = Number(d["gross_minor"] ?? 0);
          sale.discount_minor = Number(d["discount_minor"] ?? 0);
        }
        for (const l of sale.lines) {
          const a = l.backing === "ALLOWANCE" ? this.s.allowances[l.reservation_id] : undefined;
          if (a) {
            a.pending_v = Math.max(0, a.pending_v - l.qty_v);
            a.chain_remaining_v = Math.max(0, a.chain_remaining_v - l.qty_v);
          }
        }
      } else if (saleItem.status === "REJECTED") {
        sale.status = "REJECTED";
        for (const l of sale.lines) {
          const a = l.backing === "ALLOWANCE" ? this.s.allowances[l.reservation_id] : undefined;
          if (a) a.pending_v = Math.max(0, a.pending_v - l.qty_v); // the units are still held by the chain allowance
        }
        const reasons = items
          .filter((q) => q.status === "REJECTED")
          .map((q) => ({ queue_id: q.id, tx_type: q.tx_type, tx_id: q.tx_id, code: q.result?.code ?? 0, code_name: q.result?.code_name ?? "", reason: q.result?.reason ?? "", stage: q.result?.stage ?? "" }));
        const orphans = items.filter((q) => q.kind === "RESERVE" && q.status === "ACCEPTED" && q.reservation_id).map((q) => q.reservation_id as string);
        this.s.counters.exception += 1;
        const exc: ExceptionItem = {
          id: `EXC-T-${String(this.s.counters.exception).padStart(4, "0")}`,
          sale_ref: ref,
          created_at_ms: this.now(),
          status: "OPEN",
          reasons,
          orphan_reservations: orphans,
          retry_log: [],
        };
        this.s.exceptions.push(exc);
        created.push(exc);
      }
    }
    return created;
  }

  // ---- Exceptions --------------------------------------------------------------------------

  listExceptions(opts: { all?: boolean } = {}): ExceptionItem[] {
    return this.s.exceptions.filter((e) => opts.all || e.status === "OPEN" || e.status === "ESCALATED");
  }

  private mustException(id: string): ExceptionItem {
    const e = this.s.exceptions.find((x) => x.id === id);
    if (!e) throw new PolicyRefusal(`no exception ${id}`);
    if (e.status === "RESOLVED_RETRIED" || e.status === "CANCELLED") throw new PolicyRefusal(`exception ${id} is already ${e.status}`);
    return e;
  }

  async resolve(id: string, action: ResolveAction, opts: { reason?: string } = {}): Promise<ResolveResult> {
    const exc = this.mustException(id);
    if (action === "retry") return this.resolveRetry(exc);
    if (action === "cancel") return this.resolveCancel(exc, opts.reason);
    return this.resolveEscalate(exc, opts.reason);
  }

  private async resolveRetry(exc: ExceptionItem): Promise<ResolveResult> {
    const gw = this.net("resolve retry");
    const sale = this.s.sales[exc.sale_ref];
    if (!sale) throw new PolicyRefusal(`sale record ${exc.sale_ref} is missing from the state file`);
    const b = this.builder();
    const txIds: string[] = [];
    const notes: string[] = [];
    // free stock still held by reservations of the failed attempt
    await this.releaseBestEffort(exc.orphan_reservations);
    exc.orphan_reservations = [];
    sale.retries += 1;
    const lines: SaleLineRec[] = [];
    const reserveTxs: { tx: SignedTx<"ReserveStock">; resId: string }[] = [];
    for (const l of sale.lines) {
      const resId = this.o.newId("RSV");
      const tx = await b.build(
        "ReserveStock",
        { reservation_id: resId, location_id: sale.location_id, sku: l.sku, qty: { v: l.qty_v, unit: l.unit }, ttl_ms: this.reserveTtlMs(), terminal_id: this.s.terminal_id },
        { idempotencyRef: `resv:${resId}` },
      );
      reserveTxs.push({ tx, resId });
      txIds.push(tx.txId);
      lines.push({ sku: l.sku, qty_v: l.qty_v, unit: l.unit, scarce: l.scarce, backing: "ONLINE_RESERVATION", reservation_id: resId });
    }
    const outs = await Promise.all(reserveTxs.map((r) => gw.submit(r.tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs }).then(outcomeOf)));
    const bad = outs.findIndex((o) => o.status !== "FINALISED_OK");
    if (bad >= 0) {
      await this.releaseBestEffort(reserveTxs.filter((_, i) => (outs[i] as TxOutcome).status === "FINALISED_OK").map((r) => r.resId));
      const o = outs[bad] as TxOutcome;
      const f = failureOf(o);
      exc.retry_log.push({ at_ms: this.now(), code_name: f.codeName, reason: f.reason });
      await this.persist();
      return { exception: exc, action: "retry", ok: false, txIds, notes, message: `RETRY FAILED at ReserveStock for ${sale.lines[bad]?.sku}: ${describeOutcome(o)}. The exception stays OPEN; use \`resolve ${exc.id} escalate\` for the manager procedure.` };
    }
    const saleTx = await b.build("CompleteSale", { ...this.salePayload(sale.sale_id, lines, sale.effective_at_ms, { ...(sale.customer_id ? { customerId: sale.customer_id } : {}), paymentMethod: sale.payment_method }) }, { idempotencyRef: `sale:${sale.sale_id}:r${sale.retries}` });
    txIds.push(saleTx.txId);
    const out = outcomeOf(await gw.submit(saleTx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs }));
    if (out.status === "FINALISED_OK") {
      sale.lines = lines;
      sale.status = "FINALISED";
      sale.finalised_height = out.height;
      sale.net_minor = Number(out.data["net_minor"] ?? 0);
      sale.gross_minor = Number(out.data["gross_minor"] ?? 0);
      sale.discount_minor = Number(out.data["discount_minor"] ?? 0);
      sale.tx_ids.push(...txIds);
      exc.status = "RESOLVED_RETRIED";
      exc.resolution = { action: "retry", at_ms: this.now(), tx_ids: txIds };
      this.noteChain(out.height);
      await this.persist();
      return { exception: exc, action: "retry", ok: true, txIds, notes, message: `RETRY SUCCEEDED: sale ${sale.sale_id} is now FINALISED at height ${out.height} (net ${out.data["net_minor"] ?? "?"} minor units).` };
    }
    await this.releaseBestEffort(reserveTxs.map((r) => r.resId));
    const f = failureOf(out);
    exc.retry_log.push({ at_ms: this.now(), code_name: f.codeName, reason: f.reason });
    await this.persist();
    const hint = f.codeName === "INVALID_ARGUMENT" ? " If the reason mentions the effective time or backdate window, the sale is too old to record: escalate." : "";
    return { exception: exc, action: "retry", ok: false, txIds, notes, message: `RETRY FAILED at CompleteSale: ${describeOutcome(out)}.${hint}` };
  }

  private async resolveCancel(exc: ExceptionItem, reason: string | undefined): Promise<ResolveResult> {
    if (!reason || reason.trim().length < 3) throw new PolicyRefusal("cancel needs --reason \"...\" (kept in the audit trail)");
    const sale = this.s.sales[exc.sale_ref];
    const txIds: string[] = [];
    const notes: string[] = [];
    // units of an allowance go back to the allowance pool (the chain never consumed them)
    for (const q of this.s.queue.filter((x) => x.sale_ref === exc.sale_ref && x.status === "UNFINALISED")) {
      q.status = "CANCELLED";
      q.result = { stage: "local", code: 0, code_name: "CANCELLED", reason, at_ms: this.now() };
    }
    if (sale) sale.status = "CANCELLED";
    // reservations the chain accepted for this sale hold stock until released
    if (exc.orphan_reservations.length > 0) {
      const b = this.builder();
      for (const id of exc.orphan_reservations) {
        const tx = await b.build("ReleaseReservation", { reservation_id: id, reason: "CANCELLED" }, { idempotencyRef: `release:${id}`, ...(this.s.mode === "OFFLINE" && this.offlineValidUntil() !== undefined ? { validUntilHeight: this.offlineValidUntil() as number } : {}) });
        if (this.s.mode === "ONLINE") {
          try {
            await this.o.gateway.submit(tx, { wait: "final", timeoutMs: this.o.cfg.submitTimeoutMs });
            txIds.push(tx.txId);
            notes.push(`released reservation ${id} on the chain`);
            continue;
          } catch (e) {
            if (!isTransient(e)) throw e;
          }
        }
        const qi = this.queueItemFor(tx, exc.sale_ref, "RELEASE", `release orphan reservation ${id}`, this.now(), [], id);
        this.s.queue.push(qi);
        notes.push(`release of reservation ${id} signed and queued as ${qi.id} (UNFINALISED until the next sync)`);
      }
      exc.orphan_reservations = [];
    }
    exc.status = "CANCELLED";
    exc.resolution = { action: "cancel", at_ms: this.now(), note: reason, tx_ids: txIds };
    await this.persist();
    notes.push("The sale was NOT recorded on the chain. If goods already left the store, a manager must correct stock: AdjustStock PROPOSE (count) by one manager, APPROVE by a different signer (see docs/SDK.md, offline exception procedure).");
    return { exception: exc, action: "cancel", ok: true, txIds, notes, message: `exception ${exc.id} CANCELLED locally: ${reason}` };
  }

  private async resolveEscalate(exc: ExceptionItem, note: string | undefined): Promise<ResolveResult> {
    const sale = this.s.sales[exc.sale_ref];
    const plan = planEscalation(exc, sale, this.s.terminal_id);
    this.s.counters.escalation += 1;
    const rec: EscalationRecord = {
      id: `ESC-${String(this.s.counters.escalation).padStart(4, "0")}`,
      exception_id: exc.id,
      sale_ref: exc.sale_ref,
      created_at_ms: this.now(),
      terminal_id: this.s.terminal_id,
      location_id: this.s.location_id,
      problem: plan.problem,
      goods_may_have_left_store: plan.goodsMayHaveLeftStore,
      lines: (sale?.lines ?? []).map((l) => ({ sku: l.sku, qty_v: l.qty_v, unit: l.unit, scarce: l.scarce, backing: l.backing as LineBacking })),
      reasons: exc.reasons,
      suggested_actions: plan.actions,
      note: [plan.note, note].filter(Boolean).join(" "),
    };
    this.s.escalations.push(rec);
    exc.status = "ESCALATED";
    exc.resolution = { action: "escalate", at_ms: this.now(), escalation_id: rec.id, ...(note ? { note } : {}) };
    await this.persist();
    return { exception: exc, action: "escalate", ok: true, txIds: [], notes: [], escalation: rec, message: `exception ${exc.id} ESCALATED as ${rec.id}` };
  }
}

// ---- Outcome description helpers -----------------------------------------------------------

export function failureOf(o: TxOutcome): { codeName: string; reason: string } {
  switch (o.status) {
    case "ADMISSION_REJECTED":
      return { codeName: o.codeName, reason: o.log };
    case "FINALISED_REJECTED":
      return { codeName: o.codeName, reason: o.log };
    case "ADMITTED_NOT_FINAL":
      return { codeName: "NOT_FINAL", reason: "admitted but not finalised within the wait budget" };
    case "FINALISED_OK":
      return { codeName: "OK", reason: "" };
  }
}

export function describeOutcome(o: TxOutcome): string {
  const f = failureOf(o);
  return `${f.codeName}${f.reason ? ` - ${f.reason}` : ""}`;
}
