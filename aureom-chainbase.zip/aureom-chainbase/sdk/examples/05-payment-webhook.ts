// Example 5: the integration layer. A (simulated) payment provider calls our webhook; the adapter
// authenticates it, translates it into a signed RecordPaymentResult and submits it idempotently.
//   npm run example -- 05-payment-webhook
//
// The chain only INSTRUCTED the payment when the sale completed. Only this authenticated adapter
// result confirms that money moved.
import { AdapterRunner, SimulatedPaymentProvider, signWebhook, simPayDelivery, type Sale, type SimPayWebhook, type WebhookInbound } from "../src/index.js";
import { connect } from "../scripts/runtime.js";
import { freshSku } from "./_fixture.js";

const SECRET = "simpay-demo-secret-change-me-0001";
const rt = await connect({ identities: ["cashier-n01", "payment-adapter-1", "catalog-mgr", "pricing-mgr", "buyer-hq", "manager-n01"] });
const { sku, suffix: id } = await freshSku(rt, "EX5", 1, 1250);

// A sale awaiting payment (reserve + complete as the cashier).
const resId = `RES-EX5-${id}`;
const saleId = `SALE-EX5-${id}`;
await rt.send("cashier-n01", "ReserveStock", { reservation_id: resId, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 300_000 });
const s = await rt.send("cashier-n01", "CompleteSale", { sale_id: saleId, location_id: "STORE-N-01", channel: "STORE", effective_at_ms: Date.now(), currency: "GBP", payment_method: "CARD", lines: [{ sku, qty: { v: 1, unit: "EA" }, reservation_id: resId }] });
const net = s.outcome.status === "FINALISED_OK" ? Number(s.outcome.data["net_minor"]) : 0;
const saleNow = async () => (await rt.client.getRecord<Sale>(`sale/${saleId}`)).value;
console.log(`sale ${saleId}: net ${net}, payment_status ${(await saleNow())?.payment_status} (an INSTRUCTION, not money)`);

const adapter = new SimulatedPaymentProvider({ secrets: [SECRET] });
const runner = new AdapterRunner<WebhookInbound>({ adapter, keys: rt.keys, networkId: rt.env.networkId, gateway: rt.client, log: (e) => console.log("  [runner]", e.type, "attempt" in e ? e.attempt : "") });
const event: SimPayWebhook = { id: `evt_${id}`, type: "payment.succeeded", created: Math.floor(Date.now() / 1000), data: { sale_id: saleId, reference: `ch_${id}`, amount: net, currency: "GBP" } };

const show = (label: string, r: Awaited<ReturnType<typeof runner.handle>>) => console.log(`${label}: ${r.status}${r.failure ? ` (${r.failure.stage}/${r.failure.code}: ${r.failure.reason})` : ""}${r.applied[0] ? ` tx ${r.applied[0].txId} duplicate=${r.applied[0].duplicate}` : ""}`);

show("1. forged callback (wrong secret)", await runner.handle({ rawBody: JSON.stringify(event), headers: signWebhook("attacker-secret-0123456789", JSON.stringify(event), Date.now()) }));
show("2. replay of an old capture (20 min old)", await runner.handle(simPayDelivery(SECRET, event, Date.now() - 20 * 60_000)));
console.log(`   sale still ${(await saleNow())?.payment_status}: nothing was applied`);
show("3. genuine callback", await runner.handle(simPayDelivery(SECRET, event, Date.now())));
console.log(`   sale now ${(await saleNow())?.payment_status}, paid ${(await saleNow())?.paid_minor}`);
show("4. provider redelivers the same callback", await runner.handle(simPayDelivery(SECRET, event, Date.now())));
console.log(`   paid still ${(await saleNow())?.paid_minor}; payment events ${(await saleNow())?.payment_events?.length}`);

const orphan: SimPayWebhook = { ...event, id: `evt_${id}_orphan`, data: { ...event.data, sale_id: `SALE-NOT-ON-CHAIN-${id}` } };
const fast = new AdapterRunner<WebhookInbound>({ adapter, keys: rt.keys, networkId: rt.env.networkId, gateway: rt.client, retry: { baseDelayMs: 50, maxBusinessAttempts: 2 } });
const r5 = await fast.handle(simPayDelivery(SECRET, orphan, Date.now()));
show("5. callback for a sale the chain does not know", r5);
console.log("   reconciliation exception:", JSON.stringify(r5.exception, null, 2));
console.log(`   dead letters waiting for an operator: ${(await fast.deadLetters.list()).length}`);
