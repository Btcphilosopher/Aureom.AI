// Example 2: two terminals race for the LAST unit in one block. The chain picks the winner by
// executing transactions in one agreed order; the loser is ordered but REJECTED (INSUFFICIENT).
//   npm run example -- 02-reservation-race
import { connect } from "../scripts/runtime.js";
import { freshSku } from "./_fixture.js";

const rt = await connect({ identities: ["catalog-mgr", "buyer-hq", "manager-n01", "term-n01-1", "term-n01-2"] });
const { sku } = await freshSku(rt, "EX2", 1);
console.log(`fixture: 1 x ${sku} at STORE-N-01`);

// Sign both requests first, then release them together right after a block was committed.
const terminals = ["term-n01-1", "term-n01-2"] as const;
const signed = await Promise.all(
  terminals.map(async (t) => (await rt.builder(t)).build("ReserveStock", { reservation_id: `RES-${sku}-${t.slice(-1)}`, location_id: "STORE-N-01", sku, qty: { v: 1, unit: "EA" }, ttl_ms: 120_000, terminal_id: t })),
);
const start = (await rt.client.chainInfo()).height;
while ((await rt.client.chainInfo()).height === start) await new Promise((r) => setTimeout(r, 20));
const results = await Promise.all(signed.map((tx) => rt.submitSigned(tx, { wait: "final", allowReject: true })));

for (const [i, r] of results.entries()) {
  const o = r.outcome;
  if (o.status === "FINALISED_OK") console.log(`${terminals[i]}: WON   height ${o.height} index ${o.index}  reservation ${(o.data["reservation_id"] as string)}`);
  else if (o.status === "FINALISED_REJECTED") console.log(`${terminals[i]}: LOST  height ${o.height} index ${o.index}  ${o.codeName}: ${o.log}`);
  else console.log(`${terminals[i]}: ${o.status}`);
}
const heights = results.map((r) => (r.outcome.status === "FINALISED_OK" || r.outcome.status === "FINALISED_REJECTED" ? r.outcome.height : -1));
console.log(heights[0] === heights[1] ? `both ordered in the same block (${heights[0]})` : `blocks ${heights.join(" / ")}`);
const inv = await rt.client.inventory({ sku, location: "STORE-N-01" });
console.log("authoritative balance:", JSON.stringify(inv.balances[0]));
// tidy up: release the winner's reservation
for (const r of results) if (r.outcome.status === "FINALISED_OK") await rt.send(r.tx.signer, "ReleaseReservation", { reservation_id: String(r.outcome.data["reservation_id"]), reason: "CANCELLED" });
