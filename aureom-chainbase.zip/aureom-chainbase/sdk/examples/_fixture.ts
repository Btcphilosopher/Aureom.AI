// Fixture helper for the examples: a brand-new SKU with a price and N units at STORE-N-01, so every
// example is self-contained and can be re-run. (Uses catalog-mgr, buyer-hq, pricing-mgr, manager-n01.)
import type { Runtime } from "../scripts/runtime.js";

export async function freshSku(rt: Runtime, tag: string, units: number, priceMinor?: number): Promise<{ sku: string; suffix: string }> {
  const suffix = Date.now().toString(36).toUpperCase();
  const sku = `${tag}-${suffix}`;
  await rt.send("catalog-mgr", "CreateProduct", { product_id: `P-${sku}`, name: `Example product ${sku}`, variants: [{ sku_id: sku, unit: "EA" }] });
  if (priceMinor !== undefined) await rt.send("pricing-mgr", "PublishPrice", { price_id: `PR-${sku}`, sku, location_id: "*", currency: "GBP", unit_minor: priceMinor, effective_from_ms: Date.now() - 3600_000 });
  await rt.send("buyer-hq", "CreateSupplier", { supplier_id: `SUP-${sku}`, name: "Example supplier" });
  await rt.send("manager-n01", "ReceiveGoods", { receipt_id: `RCPT-${sku}`, location_id: "STORE-N-01", supplier_id: `SUP-${sku}`, effective_at_ms: Date.now(), lines: [{ sku, qty: { v: units, unit: "EA" } }] });
  return { sku, suffix };
}
