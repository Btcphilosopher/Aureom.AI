// Example 4: rebuild-aware read-after-write.
//   npm run example -- 04-read-after-write
//
// The query projection is DISPOSABLE and may lag (or be rebuilding). Rules:
//   1. After a write, wait for finality (wait:"final") - that is the authoritative fact.
//   2. To read it back from the projection, use wait:"indexed" or waitIndexed(height) / readAfterWrite().
//   3. Facts that matter (balances before a decision) can always be read from authoritative chain state.
import { connect } from "../scripts/runtime.js";

const rt = await connect({ identities: ["catalog-mgr"] });
const { client } = rt;
const id = Date.now().toString(36).toUpperCase();
const productId = `P-EX4-${id}`;

const w = await rt.send("catalog-mgr", "CreateProduct", { product_id: productId, name: `Read-after-write ${id}`, variants: [{ sku_id: `EX4-${id}`, unit: "EA" }] }, { wait: "final" });
const h = w.outcome.status === "FINALISED_OK" ? w.outcome.height : 0;
console.log(`written and FINAL at height ${h}`);

const status0 = await client.projectionStatus();
console.log(`projection: state ${status0.state}, indexed ${status0.indexed_height}, chain head ${status0.chain_head} (lag ${status0.lag_blocks})`);

// A plain read might miss the new product if the projection lags; readAfterWrite never does.
const viaProjection = await client.readAfterWrite(h, () => client.q.product(productId, { min_height: h, wait_ms: 3000 }));
console.log(`projection read OK (indexed ${viaProjection.meta.indexed_height}): ${viaProjection.item.name}`);
const authoritative = await client.getRecord(`product/${productId}`);
console.log(`authoritative read: found=${authoritative.found} at state height ${authoritative.height}`);

// Rebuild the projection from scratch while we keep working: reads stay correct, because waitIndexed
// waits for state OK and a height >= ours, and reports that it saw the rebuild.
console.log("dropping and rebuilding the projection from finalised blocks ...");
await client.rebuildProjection();
const t0 = Date.now();
const w2 = await rt.send("catalog-mgr", "CreateProduct", { product_id: `${productId}-B`, name: `During rebuild ${id}`, variants: [{ sku_id: `EX4B-${id}`, unit: "EA" }] }, { wait: "final" });
const h2 = w2.outcome.status === "FINALISED_OK" ? w2.outcome.height : 0;
const waited = await client.waitIndexed(h2, { timeoutMs: 60_000 });
console.log(`waitIndexed(${h2}) returned after ${Date.now() - t0} ms; sawRebuild=${waited.sawRebuild}; projection state ${waited.status.state}, indexed ${waited.status.indexed_height}`);
const again = await client.readAfterWrite(h2, () => client.q.product(`${productId}-B`));
console.log(`read after rebuild: ${again.item.name}`);
const v = await client.verifyProjection(10);
console.log(`projection digest matches chain digest: ${v.match} (${v.proofs_valid}/${v.proofs_checked} spot-checked proofs valid)`);
