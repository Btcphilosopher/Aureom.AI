// Example 3: read a record WITH an ICS23 proof and verify it locally.
//   npm run example -- 03-read-with-proof [state-key]
//
// A verified proof says: "this key holds exactly this value in the state with this Merkle root".
// It does NOT say the record is business-correct, nor that a list/search is complete, nor (by
// itself) that the root is final - that trust comes from header verification (the +2/3 validator
// signatures over the header that carries the root), done by the gateway light client.
import { verifyRecordResponse, type ChainRecordResponse } from "../src/index.js";
import { connect } from "../scripts/runtime.js";

const rt = await connect({ identities: [] });
const key = process.argv[3] ?? "sku/KETTLE-RED";
const { client } = rt;

const present = await client.getVerifiedRecord(key, { crossCheckFinality: true });
console.log(`record ${key}: found=${present.record.found} at state height ${present.record.height}`);
console.log("  verdict:", present.verdict.valid ? "VALID" : `INVALID (${present.verdict.reason})`);
console.log("  ", present.verdict.statement);
console.log(`   value encoding used for the check: ${present.verdict.valueEncoding}`);
console.log(`   gateway light client agrees on the header's app hash: ${present.finalityAgrees}`);
console.log("   NOT established:", present.verdict.caveats[1]);

// Pin the root to a value obtained independently (here: ask a second time via the chain digest endpoint).
const digest = await client.digest(present.record.height);
const pinned = await client.getVerifiedRecord(key, { height: present.record.height, expectedAppHash: digest.app_hash });
console.log(`pinned to independently supplied app hash ${digest.app_hash.slice(0, 16)}...: ${pinned.verdict.valid ? "VALID" : "INVALID"} (rootPinned=${pinned.verdict.rootPinned})`);

// Tamper: change one field of the returned value and verify again - the proof no longer matches.
if (present.record.found && present.record.value && typeof present.record.value === "object") {
  const forged: ChainRecordResponse = { ...present.record, value: { ...(present.record.value as object), status: "FORGED" } };
  delete forged.value_b64;
  const v = verifyRecordResponse(key, forged);
  console.log(`tampered copy: ${v.valid ? "VALID (unexpected!)" : "REJECTED"} - ${v.reason ?? ""}`);
}

// Absence is provable too (non-membership), but only for that exact key.
const absent = await client.getVerifiedRecord("sale/DOES-NOT-EXIST-0001");
console.log(`absent key: found=${absent.record.found}, ${absent.verdict.kind} proof ${absent.verdict.valid ? "VALID" : "INVALID"}`);
