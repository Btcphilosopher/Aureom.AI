// Example 1: build, sign and submit a transaction; read the outcome and the result code.
//   npm run example -- 01-submit-tx
import { outcomeOf, codeName } from "../src/index.js";
import { connect } from "../scripts/runtime.js";

const rt = await connect({ identities: ["cashier-n01"] });
const builder = await rt.builder("cashier-n01");
const id = Date.now().toString(36).toUpperCase();

// 1) Build + sign locally. Nothing has been sent yet.
const tx = await builder.build("ReserveStock", { reservation_id: `EX1-${id}`, location_id: "STORE-N-01", sku: "KETTLE-RED", qty: { v: 1, unit: "EA" }, ttl_ms: 60_000 });
console.log("signed", tx.type, "as", `${tx.signer}#${tx.keyId}`);
console.log("  tx_id           ", tx.txId);
console.log("  idempotency_ref ", tx.idempotencyRef);
console.log("  envelope bytes  ", tx.bytes.length, "(tx hash", tx.txHash.slice(0, 16) + "...)");

// 2) Submit and wait for FINALITY (wait: "final"). "none" would return after mempool admission only.
const resp = await rt.client.submit(tx, { wait: "final" });
const o = outcomeOf(resp);
console.log("admission:", resp.admission.name, "| outcome:", o.status);
if (o.status === "FINALISED_OK") {
  console.log(`  finalised at height ${o.height}; result data`, o.data);
  // 3) Give the stock back (a second, independent transaction).
  const rel = await rt.send("cashier-n01", "ReleaseReservation", { reservation_id: `EX1-${id}`, reason: "CANCELLED" });
  console.log("released:", rel.outcome.status);
} else if (o.status === "FINALISED_REJECTED") {
  // Ordered but rejected: recorded on chain as tx/<id> = REJECTED, no state change.
  console.log(`  rejected: ${o.codeName} (${o.code}) ${o.log}`);
} else if (o.status === "ADMISSION_REJECTED") {
  console.log(`  rejected at admission: ${codeName(o.code)} ${o.log}`);
}
