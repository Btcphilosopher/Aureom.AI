#!/usr/bin/env -S npx tsx
// npm run example -- <name> [args]
import { readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";

const dir = fileURLToPath(new URL(".", import.meta.url));
const names = readdirSync(dir).filter((f) => /^\d\d-.*\.ts$/.test(f)).map((f) => f.replace(/\.ts$/, ""));
const want = process.argv[2];
if (!want || !names.includes(want)) {
  console.error(`usage: npm run example -- <name>\nexamples: ${names.join(", ")}`);
  process.exit(want ? 1 : 2);
}
await import(`./${want}.ts`);
