// Package netgen generates a permissioned local/Docker testnet: validator homes, genesis,
// authenticated node keys, persistent-peer wiring and synthetic demo identity keys.
package netgen

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	cmtcfg "github.com/cometbft/cometbft/config"
	cmtjson "github.com/cometbft/cometbft/libs/json"
	cmtos "github.com/cometbft/cometbft/libs/os"
	"github.com/cometbft/cometbft/p2p"
	"github.com/cometbft/cometbft/privval"
	cmttypes "github.com/cometbft/cometbft/types"

	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

type Options struct {
	Out           string
	NetworkID     string
	BasePort      int // host ports: p2p=base+10*i, rpc=base+10*i+1
	Docker        bool
	TimeoutCommit time.Duration
	// ProxyP2P maps node index -> p2p port peers should dial (used by the partition test harness).
	PeerPortOverride func(from, to int) int
}

type NodeInfo struct {
	Name    string `json:"name"`
	Org     string `json:"org"`
	Role    string `json:"role"`
	NodeID  string `json:"node_id"`
	P2PPort int    `json:"p2p_port"`
	RPCPort int    `json:"rpc_port"`
	Home    string `json:"home"`
	PubKey  string `json:"consensus_pubkey_b64"`
	P2PAddr string `json:"p2p_addr"`
	RPCURL  string `json:"rpc_url"`
}

type Network struct {
	NetworkID string     `json:"network_id"`
	Nodes     []NodeInfo `json:"nodes"`
	Genesis   string     `json:"genesis"`
	KeysDir   string     `json:"identity_keys_dir"`
}

type KeyFile struct {
	Identity string `json:"identity"`
	KeyID    string `json:"key_id"`
	SeedHex  string `json:"seed_hex"`
	PubB64   string `json:"pub_b64"`
}

func Generate(o Options) (*Network, error) {
	if o.TimeoutCommit == 0 {
		o.TimeoutCommit = time.Second
	}
	if o.BasePort == 0 {
		o.BasePort = 26600
	}
	n := &Network{NetworkID: o.NetworkID, KeysDir: filepath.Join(o.Out, "keys")}
	os.MkdirAll(n.KeysDir, 0o700)

	// identity keys (synthetic demo identities; random, stored in plain files — NOT a production key store)
	pubs := map[string]ed25519.PublicKey{}
	for _, s := range demo.Roster() {
		seed := make([]byte, 32)
		rand.Read(seed)
		k := ed25519.NewKeyFromSeed(seed)
		pubs[s.ID] = k.Public().(ed25519.PublicKey)
		kf := KeyFile{Identity: s.ID, KeyID: "k1", SeedHex: hex.EncodeToString(seed), PubB64: base64.StdEncoding.EncodeToString(pubs[s.ID])}
		b, _ := json.MarshalIndent(kf, "", "  ")
		if err := os.WriteFile(filepath.Join(n.KeysDir, s.ID+".json"), b, 0o600); err != nil {
			return nil, err
		}
	}

	var members []core.Member
	var gvals []cmttypes.GenesisValidator
	for i, v := range demo.Validators {
		home := filepath.Join(o.Out, "nodes", v.ID)
		ni, pv, err := initHome(home, v.ID, o, i)
		if err != nil {
			return nil, err
		}
		ni.Org, ni.Role = v.Org, v.Role
		pk, _ := pv.GetPubKey()
		ni.PubKey = base64.StdEncoding.EncodeToString(pk.Bytes())
		n.Nodes = append(n.Nodes, *ni)
		members = append(members, core.Member{ID: v.ID, Org: v.Org, Kind: "VALIDATOR", Role: v.Role, PubKey: ni.PubKey, NodeID: ni.NodeID, Power: 10})
		gvals = append(gvals, cmttypes.GenesisValidator{Address: pk.Address(), PubKey: pk, Power: 10, Name: v.ID})
	}
	g := demo.BuildGenesis(o.NetworkID, members, pubs)
	appState, _ := json.Marshal(g)
	cp := cmttypes.DefaultConsensusParams()
	cp.Block.MaxBytes = 4 << 20
	cp.Block.MaxGas = -1
	cp.Version.App = 1
	gd := cmttypes.GenesisDoc{ChainID: o.NetworkID, GenesisTime: time.Now().UTC(), InitialHeight: 1, ConsensusParams: cp, Validators: gvals, AppState: appState}
	if err := gd.ValidateAndComplete(); err != nil {
		return nil, err
	}
	for i := range n.Nodes {
		if err := gd.SaveAs(filepath.Join(n.Nodes[i].Home, "config", "genesis.json")); err != nil {
			return nil, err
		}
	}
	n.Genesis = filepath.Join(o.Out, "genesis.json")
	gd.SaveAs(n.Genesis)
	// wire persistent peers (all-to-all among registered validators)
	for i := range n.Nodes {
		var peers []string
		for j := range n.Nodes {
			if i != j {
				peers = append(peers, fmt.Sprintf("%s@%s", n.Nodes[j].NodeID, peerAddr(o, n, j, i)))
			}
		}
		if err := writeConfig(&n.Nodes[i], o, peers); err != nil {
			return nil, err
		}
	}
	b, _ := json.MarshalIndent(n, "", "  ")
	return n, os.WriteFile(filepath.Join(o.Out, "network.json"), b, 0o644)
}

func peerAddr(o Options, n *Network, to, from int) string {
	if o.Docker {
		return fmt.Sprintf("%s:26656", n.Nodes[to].Name)
	}
	port := n.Nodes[to].P2PPort
	if o.PeerPortOverride != nil {
		port = o.PeerPortOverride(from, to)
	}
	return fmt.Sprintf("127.0.0.1:%d", port)
}

func initHome(home, name string, o Options, idx int) (*NodeInfo, *privval.FilePV, error) {
	for _, d := range []string{"config", "data"} {
		if err := os.MkdirAll(filepath.Join(home, d), 0o700); err != nil {
			return nil, nil, err
		}
	}
	cfg := cmtcfg.DefaultConfig()
	cfg.SetRoot(home)
	nk, err := p2p.LoadOrGenNodeKey(cfg.NodeKeyFile())
	if err != nil {
		return nil, nil, err
	}
	pv := privval.GenFilePV(cfg.PrivValidatorKeyFile(), cfg.PrivValidatorStateFile())
	pv.Save()
	ni := &NodeInfo{Name: name, NodeID: string(nk.ID()), Home: home, P2PPort: o.BasePort + 10*idx, RPCPort: o.BasePort + 10*idx + 1}
	if o.Docker {
		ni.P2PPort, ni.RPCPort = 26656, 26657
	}
	return ni, pv, nil
}

func writeConfig(ni *NodeInfo, o Options, peers []string) error {
	cfg := cmtcfg.DefaultConfig()
	cfg.SetRoot(ni.Home)
	cfg.Moniker = ni.Name
	cfg.FilterPeers = true // admission is decided by on-chain membership (ABCI /p2p/filter/id)
	cfg.P2P.PexReactor = false
	cfg.P2P.AddrBookStrict = false
	cfg.P2P.AllowDuplicateIP = true
	cfg.P2P.PersistentPeers = join(peers)
	cfg.P2P.ListenAddress = fmt.Sprintf("tcp://0.0.0.0:%d", ni.P2PPort)
	host := "127.0.0.1"
	if o.Docker {
		host = "0.0.0.0"
	}
	cfg.RPC.ListenAddress = fmt.Sprintf("tcp://%s:%d", host, ni.RPCPort)
	cfg.RPC.CORSAllowedOrigins = []string{"*"}
	cfg.Consensus.TimeoutCommit = o.TimeoutCommit
	cfg.Consensus.CreateEmptyBlocks = true
	cfg.Mempool.MaxTxBytes = 1 << 20
	cfg.Mempool.Size = 20000
	cfg.Mempool.MaxTxsBytes = 256 << 20
	cfg.TxIndex.Indexer = "kv"
	cfg.Instrumentation.Prometheus = false
	cfg.LogLevel = "main:info,state:info,*:error"
	cmtcfg.WriteConfigFile(filepath.Join(ni.Home, "config", "config.toml"), cfg)
	if o.Docker {
		ni.P2PAddr, ni.RPCURL = fmt.Sprintf("%s:26656", ni.Name), fmt.Sprintf("http://%s:26657", ni.Name)
	} else {
		ni.P2PAddr, ni.RPCURL = fmt.Sprintf("127.0.0.1:%d", ni.P2PPort), fmt.Sprintf("http://127.0.0.1:%d", ni.RPCPort)
	}
	return nil
}

func join(s []string) string {
	out := ""
	for i, x := range s {
		if i > 0 {
			out += ","
		}
		out += x
	}
	return out
}

var _ = cmtjson.Marshal
var _ = cmtos.Exit

type NewNodeOptions struct {
	Name          string
	Mode          string // "observer" (fresh identity, needs governance admission) | "replace" (restore a validator's keys from a backup)
	P2PPort       int
	RPCPort       int
	RestoreFrom   string // directory containing config/node_key.json + config/priv_validator_key.json (replace mode)
	Home          string
	TimeoutCommit time.Duration
}

// NewNode creates an empty-data node home that joins an existing network by replaying the
// chain from genesis (block sync). "replace" restores a validator identity from a key backup
// into a NEW data directory; the old process must be permanently stopped (double-signing risk).
func NewNode(netDir string, o NewNodeOptions) (*NodeInfo, error) {
	b, err := os.ReadFile(filepath.Join(netDir, "network.json"))
	if err != nil {
		return nil, err
	}
	var n Network
	if err := json.Unmarshal(b, &n); err != nil {
		return nil, err
	}
	home := o.Home
	if home == "" {
		home = filepath.Join(netDir, "nodes", o.Name)
	}
	for _, d := range []string{"config", "data"} {
		if err := os.MkdirAll(filepath.Join(home, d), 0o700); err != nil {
			return nil, err
		}
	}
	cfg := cmtcfg.DefaultConfig()
	cfg.SetRoot(home)
	genesis, err := os.ReadFile(n.Genesis)
	if err != nil {
		return nil, err
	}
	if err := os.WriteFile(cfg.GenesisFile(), genesis, 0o644); err != nil {
		return nil, err
	}
	switch o.Mode {
	case "replace":
		for _, f := range []string{"node_key.json", "priv_validator_key.json"} {
			src, err := os.ReadFile(filepath.Join(o.RestoreFrom, "config", f))
			if err != nil {
				return nil, fmt.Errorf("key backup incomplete: %w", err)
			}
			if err := os.WriteFile(filepath.Join(home, "config", f), src, 0o600); err != nil {
				return nil, err
			}
		}
		// fresh signing state: safe ONLY because the old instance is permanently retired
		if err := os.WriteFile(cfg.PrivValidatorStateFile(), []byte(`{"height":"0","round":0,"step":0}`), 0o600); err != nil {
			return nil, err
		}
	default:
		if _, err := p2p.LoadOrGenNodeKey(cfg.NodeKeyFile()); err != nil {
			return nil, err
		}
		pv := privval.GenFilePV(cfg.PrivValidatorKeyFile(), cfg.PrivValidatorStateFile())
		pv.Save()
	}
	nk, err := p2p.LoadNodeKey(cfg.NodeKeyFile())
	if err != nil {
		return nil, err
	}
	ni := &NodeInfo{Name: o.Name, NodeID: string(nk.ID()), Home: home, P2PPort: o.P2PPort, RPCPort: o.RPCPort}
	var peers []string
	for _, v := range n.Nodes {
		if v.NodeID != ni.NodeID {
			peers = append(peers, fmt.Sprintf("%s@%s", v.NodeID, v.P2PAddr))
		}
	}
	opt := Options{TimeoutCommit: o.TimeoutCommit}
	if opt.TimeoutCommit == 0 {
		opt.TimeoutCommit = time.Second
	}
	if err := writeConfig(ni, opt, peers); err != nil {
		return nil, err
	}
	return ni, nil
}
