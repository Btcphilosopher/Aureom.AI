package app_test

import (
	"context"
	"crypto/ed25519"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	abci "github.com/cometbft/cometbft/abci/types"
	ics23 "github.com/cosmos/ics23/go"

	"github.com/aureom/chainbase/internal/app"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

const net = "aureom-app-test"

var t0 = time.Unix(1_790_000_000, 0).UTC()

type rig struct {
	t    *testing.T
	keys map[string]ed25519.PrivateKey
	gen  []byte
	n    int
}

func newRig(t *testing.T) *rig {
	g, keys := demo.TestGenesis(net)
	b, _ := json.Marshal(g)
	return &rig{t: t, keys: keys, gen: b}
}

func (r *rig) tx(signer, typ string, payload any) []byte {
	r.n++
	raw, _ := json.Marshal(payload)
	return core.SignTx(net, core.Body{TxID: fmt.Sprintf("tx-%06d", r.n), Type: typ, Signer: signer, KeyID: "k1", Idempotency: fmt.Sprintf("i-%06d", r.n), Payload: raw}, r.keys[signer])
}

func (r *rig) init(a *app.App) {
	_, err := a.InitChain(context.Background(), &abci.RequestInitChain{ChainId: net, AppStateBytes: r.gen, Time: t0, InitialHeight: 1})
	if err != nil {
		r.t.Fatal(err)
	}
}

type blockSpec struct{ txs [][]byte }

func fin(t *testing.T, a *app.App, h int64, txs [][]byte) []byte {
	resp, err := a.FinalizeBlock(context.Background(), &abci.RequestFinalizeBlock{Height: h, Time: t0.Add(time.Duration(h) * time.Second), Txs: txs})
	if err != nil {
		t.Fatal(err)
	}
	return resp.AppHash
}

func commit(t *testing.T, a *app.App) {
	if _, err := a.Commit(context.Background(), &abci.RequestCommit{}); err != nil {
		t.Fatal(err)
	}
}

func (r *rig) script() []blockSpec {
	m := func(kv ...any) map[string]any {
		out := map[string]any{}
		for i := 0; i < len(kv); i += 2 {
			out[kv[i].(string)] = kv[i+1]
		}
		return out
	}
	return []blockSpec{
		{nil},
		{[][]byte{r.tx("catalog-mgr", "CreateProduct", m("product_id", "P-1", "name", "Oat", "variants", []any{m("sku_id", "SKU-A", "unit", "EA")}))}},
		{[][]byte{r.tx("hq-iam-admin", "CreateSupplier", m("supplier_id", "SUP-1", "name", "S"))}},
		{[][]byte{r.tx("catalog-mgr", "UpdateProduct", m("product_id", "P-1", "name", "Oat Drink"))}},
		{nil},
	}
}

func openFresh(t *testing.T) (*app.App, string) {
	dir := t.TempDir()
	a, err := app.New(dir, net)
	if err != nil {
		t.Fatal(err)
	}
	return a, dir
}

// Restart & recovery: a node that is stopped and reopened continues with identical state, and its
// roots equal those of a node that never stopped.
func TestRestartRecovery(t *testing.T) {
	r := newRig(t)
	script := r.script()
	ref, _ := openFresh(t)
	defer ref.Close()
	r.init(ref)
	var refHashes [][]byte
	for i, b := range script {
		refHashes = append(refHashes, fin(t, ref, int64(i+1), b.txs))
		commit(t, ref)
	}

	a, dir := openFresh(t)
	r.init(a)
	for i := 0; i < 3; i++ {
		if h := fin(t, a, int64(i+1), script[i].txs); string(h) != string(refHashes[i]) {
			t.Fatalf("block %d hash mismatch", i+1)
		}
		commit(t, a)
	}
	a.Close()
	a2, err := app.New(dir, net)
	if err != nil {
		t.Fatal(err)
	}
	defer a2.Close()
	info, _ := a2.Info(context.Background(), &abci.RequestInfo{})
	if info.LastBlockHeight != 3 || string(info.LastBlockAppHash) != string(refHashes[2]) {
		t.Fatalf("recovered height %d hash %x", info.LastBlockHeight, info.LastBlockAppHash)
	}
	for i := 3; i < len(script); i++ {
		if h := fin(t, a2, int64(i+1), script[i].txs); string(h) != string(refHashes[i]) {
			t.Fatalf("post-restart block %d diverged", i+1)
		}
		commit(t, a2)
	}
}

// Crash between FinalizeBlock and Commit: nothing is persisted; CometBFT replays the block and the
// application reproduces exactly the same app hash.
func TestCrashBeforeCommitReplaysIdentically(t *testing.T) {
	r := newRig(t)
	script := r.script()
	a, dir := openFresh(t)
	r.init(a)
	var hashes [][]byte
	for i := 0; i < 3; i++ {
		hashes = append(hashes, fin(t, a, int64(i+1), script[i].txs))
		commit(t, a)
	}
	crashed := fin(t, a, 4, script[3].txs) // executed but never committed
	a.Close()                              // "crash"
	a2, _ := app.New(dir, net)
	defer a2.Close()
	info, _ := a2.Info(context.Background(), &abci.RequestInfo{})
	if info.LastBlockHeight != 3 {
		t.Fatalf("uncommitted block must not be persisted: %d", info.LastBlockHeight)
	}
	if again := fin(t, a2, 4, script[3].txs); string(again) != string(crashed) {
		t.Fatal("replayed block produced a different app hash")
	}
	commit(t, a2)
}

// Historical state queries and Merkle proofs (membership, non-membership, tamper detection).
func TestHistoricalQueryAndProofs(t *testing.T) {
	r := newRig(t)
	script := r.script()
	a, _ := openFresh(t)
	defer a.Close()
	r.init(a)
	var hashes [][]byte
	for i, b := range script {
		hashes = append(hashes, fin(t, a, int64(i+1), b.txs))
		commit(t, a)
	}
	q := func(path string, key string, h int64, prove bool) *abci.ResponseQuery {
		resp, err := a.Query(context.Background(), &abci.RequestQuery{Path: path, Data: []byte(key), Height: h, Prove: prove})
		if err != nil {
			t.Fatal(err)
		}
		return resp
	}
	name := func(h int64) string {
		resp := q("/key", "product/P-1", h, false)
		var p core.Product
		json.Unmarshal(resp.Value, &p)
		return p.Name
	}
	// state at an earlier finalised height differs from the current state
	if name(3) != "Oat" || name(4) != "Oat Drink" || name(5) != "Oat Drink" {
		t.Fatalf("time travel: h3=%q h4=%q h5=%q", name(3), name(4), name(5))
	}
	if q("/key", "product/P-1", 1, false).Value != nil {
		t.Fatal("product must not exist at height 1")
	}
	// membership proof verifies against the app hash at the SAME height (committed in header h+1 on a real chain)
	resp := q("/key", "product/P-1", 4, true)
	var cp ics23.CommitmentProof
	if err := cp.Unmarshal(resp.ProofOps.Ops[0].Data); err != nil {
		t.Fatal(err)
	}
	if !ics23.VerifyMembership(ics23.IavlSpec, hashes[3], &cp, []byte("product/P-1"), resp.Value) {
		t.Fatal("membership proof failed")
	}
	// a tampered value must NOT verify
	tampered := append([]byte(nil), resp.Value...)
	tampered[10] ^= 1
	if ics23.VerifyMembership(ics23.IavlSpec, hashes[3], &cp, []byte("product/P-1"), tampered) {
		t.Fatal("tampered value verified")
	}
	// proof against another height's root fails
	if ics23.VerifyMembership(ics23.IavlSpec, hashes[1], &cp, []byte("product/P-1"), resp.Value) {
		t.Fatal("proof verified against the wrong root")
	}
	// non-membership proof for a missing record
	nm := q("/key", "product/NOPE", 5, true)
	if nm.Value != nil {
		t.Fatal("should be absent")
	}
	var np ics23.CommitmentProof
	np.Unmarshal(nm.ProofOps.Ops[0].Data)
	if !ics23.VerifyNonMembership(ics23.IavlSpec, hashes[4], &np, []byte("product/NOPE")) {
		t.Fatal("non-membership proof failed")
	}
	// digest of full state is stable and changes with state
	d4, d5 := q("/digest", "", 4, false).Value, q("/digest", "", 5, false).Value
	if string(d4) == string(d5) {
		t.Fatal("digest should differ between heights")
	}
}

// The permissioned network admits only peers registered in on-chain membership.
func TestPeerAllowListFromChainState(t *testing.T) {
	r := newRig(t)
	a, _ := openFresh(t)
	defer a.Close()
	r.init(a)
	g, _ := demo.TestGenesis(net)
	good := g.Members[0].NodeID
	resp, _ := a.Query(context.Background(), &abci.RequestQuery{Path: "/p2p/filter/id/" + good})
	if resp.Code != 0 {
		t.Fatal("registered peer rejected")
	}
	resp, _ = a.Query(context.Background(), &abci.RequestQuery{Path: "/p2p/filter/id/" + "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"})
	if resp.Code == 0 {
		t.Fatal("unregistered peer admitted")
	}
}

func TestCheckTxStagesAndProposalLimits(t *testing.T) {
	r := newRig(t)
	a, _ := openFresh(t)
	defer a.Close()
	r.init(a)
	fin(t, a, 1, nil)
	commit(t, a)
	ok := r.tx("catalog-mgr", "CreateProduct", map[string]any{"product_id": "P-1", "name": "X", "variants": []any{map[string]any{"sku_id": "S1", "unit": "EA"}}})
	res, _ := a.CheckTx(context.Background(), &abci.RequestCheckTx{Tx: ok})
	if res.Code != 0 {
		t.Fatalf("valid tx rejected at admission: %s", res.Log)
	}
	denied := r.tx("cashier-n01", "PublishPrice", map[string]any{"price_id": "p", "sku": "S1", "location_id": "*", "currency": "GBP", "unit_minor": 1, "effective_from_ms": 1})
	res, _ = a.CheckTx(context.Background(), &abci.RequestCheckTx{Tx: denied})
	if res.Code != core.CodeUnauthorized {
		t.Fatalf("authorisation must be enforced at admission too: %d", res.Code)
	}
	res, _ = a.CheckTx(context.Background(), &abci.RequestCheckTx{Tx: []byte("garbage")})
	if res.Code != core.CodeMalformed {
		t.Fatalf("%d", res.Code)
	}
	pp, _ := a.ProcessProposal(context.Background(), &abci.RequestProcessProposal{Txs: [][]byte{make([]byte, 2<<20)}})
	if pp.Status != abci.ResponseProcessProposal_REJECT {
		t.Fatal("oversized tx must be rejected in proposals")
	}
}
