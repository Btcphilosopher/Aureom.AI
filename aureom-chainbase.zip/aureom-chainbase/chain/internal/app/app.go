// Package app adapts the deterministic core state machine to CometBFT via ABCI 2.0.
//
// CometBFT (v0.38) provides: validator networking over authenticated encrypted
// connections, a mempool, Tendermint BFT consensus with instant finality, and block storage.
// This package provides: the application state (IAVL versioned Merkle tree on an embedded
// LevelDB), the state transition (core.ExecuteBlock), proofs, and the peer allow-list.
package app

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"time"

	"cosmossdk.io/log"
	abci "github.com/cometbft/cometbft/abci/types"
	cmtcrypto "github.com/cometbft/cometbft/proto/tendermint/crypto"
	cmtproto "github.com/cometbft/cometbft/proto/tendermint/types"
	"github.com/cosmos/iavl"
	idb "github.com/cosmos/iavl/db"
	ics23 "github.com/cosmos/ics23/go"

	"github.com/aureom/chainbase/internal/core"
)

const (
	ProofOpType = "ics23:iavl"
	MaxLogLen   = 200
)

type App struct {
	abci.BaseApplication
	mu      sync.Mutex
	db      idb.DB
	tree    *iavl.MutableTree
	kv      *treeKV
	chainID string

	lastHeight  int64
	lastTimeMs  int64
	pendingHash []byte
	started     time.Time
}

type treeKV struct{ t *iavl.MutableTree }

func (k *treeKV) Get(key string) ([]byte, bool) {
	v, err := k.t.Get([]byte(key))
	if err != nil {
		panic(fmt.Sprintf("state read %s: %v", key, err))
	}
	return v, v != nil
}
func (k *treeKV) Set(key string, v []byte) {
	if _, err := k.t.Set([]byte(key), v); err != nil {
		panic(err)
	}
}
func (k *treeKV) Delete(key string) {
	if _, _, err := k.t.Remove([]byte(key)); err != nil {
		panic(err)
	}
}

// New opens (or creates) the application database under dir.
func New(dir, chainID string) (*App, error) {
	db, err := idb.NewGoLevelDB("aureom_state", dir)
	if err != nil {
		return nil, err
	}
	return NewWithDB(db, chainID)
}

func NewWithDB(db idb.DB, chainID string) (*App, error) {
	tree := iavl.NewMutableTree(db, 20000, false, log.NewNopLogger())
	v, err := tree.Load()
	if err != nil {
		return nil, err
	}
	a := &App{db: db, tree: tree, kv: &treeKV{tree}, chainID: chainID, lastHeight: v, started: time.Now()}
	if v > 0 {
		var bt int64
		a.mu.Lock()
		if raw, ok := a.kv.Get(core.KMeta + "last_block_time_ms"); ok {
			json.Unmarshal(raw, &bt)
		}
		a.mu.Unlock()
		a.lastTimeMs = bt
	}
	return a, nil
}

func (a *App) Close() error { return a.db.Close() }

func (a *App) rulesAndParams() (core.Params, bool) {
	p := core.LoadParams(a.kv)
	return p, true
}

func (a *App) Info(_ context.Context, _ *abci.RequestInfo) (*abci.ResponseInfo, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	ver := uint64(0)
	if a.lastHeight > 0 {
		ver = currentVer(a.kv)
	} else {
		ver = 1
	}
	return &abci.ResponseInfo{
		Data:             "aureom-chainbase",
		Version:          "0.1.0",
		AppVersion:       ver,
		LastBlockHeight:  a.lastHeight,
		LastBlockAppHash: a.tree.Hash(),
	}, nil
}

func currentVer(kv core.KV) uint64 {
	var v uint64 = 1
	if raw, ok := kv.Get(core.KMeta + "appver"); ok {
		json.Unmarshal(raw, &v)
	}
	return v
}

func (a *App) InitChain(_ context.Context, req *abci.RequestInitChain) (*abci.ResponseInitChain, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	g, err := core.ParseGenesis(req.AppStateBytes)
	if err != nil {
		return nil, fmt.Errorf("genesis app_state: %w", err)
	}
	if g.NetworkID != req.ChainId {
		return nil, fmt.Errorf("genesis network_id %q != chain_id %q", g.NetworkID, req.ChainId)
	}
	vals, terr := core.ApplyGenesis(a.kv, g)
	if terr != nil {
		return nil, terr
	}
	// the consensus validator set (genesis.json) must equal the on-chain membership registry
	if len(req.Validators) > 0 {
		want := map[string]int64{}
		for _, v := range vals {
			raw, _ := base64.StdEncoding.DecodeString(v.PubKeyB64)
			want[string(raw)] = v.Power
		}
		if len(want) != len(req.Validators) {
			return nil, fmt.Errorf("genesis validators (%d) differ from app_state members (%d)", len(req.Validators), len(want))
		}
		for _, rv := range req.Validators {
			if want[string(rv.PubKey.GetEd25519())] != rv.Power {
				return nil, fmt.Errorf("genesis validator set does not match app_state membership")
			}
		}
	}
	ver := g.AppVersion
	if ver == 0 {
		ver = 1
	}
	resp := &abci.ResponseInitChain{ConsensusParams: &cmtproto.ConsensusParams{Version: &cmtproto.VersionParams{App: ver}}}
	if len(req.Validators) == 0 {
		resp.Validators = toValUpdates(vals)
	}
	return resp, nil
}

func toValUpdates(vs []core.ValUpdate) []abci.ValidatorUpdate {
	idx := map[string]int{}
	var out []abci.ValidatorUpdate
	for _, v := range vs {
		raw, err := base64.StdEncoding.DecodeString(v.PubKeyB64)
		if err != nil {
			panic(err)
		}
		u := abci.ValidatorUpdate{PubKey: cmtcrypto.PublicKey{Sum: &cmtcrypto.PublicKey_Ed25519{Ed25519: raw}}, Power: v.Power}
		if i, ok := idx[v.PubKeyB64]; ok {
			out[i] = u // last update for a key wins; CometBFT rejects duplicates
			continue
		}
		idx[v.PubKeyB64] = len(out)
		out = append(out, u)
	}
	return out
}

func (a *App) CheckTx(_ context.Context, req *abci.RequestCheckTx) (*abci.ResponseCheckTx, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	params := core.LoadParams(a.kv)
	rules, ok := core.RulesFor(currentVer(a.kv))
	if !ok {
		return &abci.ResponseCheckTx{Code: core.CodeInternal, Log: "unsupported state machine version"}, nil
	}
	c := &core.Ctx{ChainID: a.chainID, Height: a.lastHeight + 1, BlockTimeMs: a.lastTimeMs, Rules: rules, Params: params, Out: &core.BlockOut{}}
	o := core.Process(a.kv, c, req.Tx, false)
	return &abci.ResponseCheckTx{Code: o.Code, Log: trunc(o.Log), Codespace: "aureom"}, nil
}

func trunc(s string) string {
	if len(s) > MaxLogLen {
		return s[:MaxLogLen]
	}
	return s
}

func (a *App) PrepareProposal(_ context.Context, req *abci.RequestPrepareProposal) (*abci.ResponsePrepareProposal, error) {
	var txs [][]byte
	var total int64
	for _, tx := range req.Txs {
		total += int64(len(tx))
		if total > req.MaxTxBytes || len(txs) >= 5000 {
			break
		}
		txs = append(txs, tx)
	}
	return &abci.ResponsePrepareProposal{Txs: txs}, nil
}

func (a *App) ProcessProposal(_ context.Context, req *abci.RequestProcessProposal) (*abci.ResponseProcessProposal, error) {
	if len(req.Txs) > 5000 {
		return &abci.ResponseProcessProposal{Status: abci.ResponseProcessProposal_REJECT}, nil
	}
	for _, tx := range req.Txs {
		if len(tx) == 0 || len(tx) > 1<<20 {
			return &abci.ResponseProcessProposal{Status: abci.ResponseProcessProposal_REJECT}, nil
		}
	}
	return &abci.ResponseProcessProposal{Status: abci.ResponseProcessProposal_ACCEPT}, nil
}

func (a *App) FinalizeBlock(_ context.Context, req *abci.RequestFinalizeBlock) (*abci.ResponseFinalizeBlock, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if req.Height != a.lastHeight+1 {
		panic(fmt.Sprintf("non-contiguous block: have %d got %d", a.lastHeight, req.Height))
	}
	ms := req.Time.UnixMilli()
	br, err := core.ExecuteBlock(a.kv, a.chainID, req.Height, ms, req.Txs)
	if err != nil {
		// Fail closed: halting is the only safe response to an unsupported/incompatible state machine.
		panic(fmt.Sprintf("HALT at height %d: %v", req.Height, err))
	}
	resp := &abci.ResponseFinalizeBlock{}
	for i, o := range br.Results {
		r := &abci.ExecTxResult{Code: o.Code, Data: o.Data, Log: trunc(o.Log), Codespace: "aureom"}
		r.Events = append(r.Events, abci.Event{Type: "aureom.tx", Attributes: []abci.EventAttribute{
			{Key: "tx_id", Value: o.TxID, Index: true}, {Key: "type", Value: o.Type, Index: true}, {Key: "signer", Value: o.Signer, Index: true},
			{Key: "code", Value: fmt.Sprint(o.Code), Index: false}, {Key: "authenticated", Value: fmt.Sprint(o.Authenticated), Index: false},
		}})
		r.Events = append(r.Events, writeEvents(o.Writes)...)
		_ = i
		resp.TxResults = append(resp.TxResults, r)
	}
	resp.Events = append(resp.Events, writeEvents(br.StartWrites)...)
	resp.Events = append(resp.Events, writeEvents(br.EndWrites)...)
	resp.ValidatorUpdates = toValUpdates(br.Out.ValUpdates)
	if br.Out.NewAppVer != 0 {
		resp.ConsensusParamUpdates = &cmtproto.ConsensusParams{Version: &cmtproto.VersionParams{App: br.Out.NewAppVer}}
	}
	a.pendingHash = a.tree.WorkingHash()
	resp.AppHash = a.pendingHash
	a.lastTimeMs = ms
	return resp, nil
}

// writeEvents publishes every state write as an event so that disposable projections can
// be rebuilt from block results alone. Events are NOT part of consensus; the authoritative
// check on a projection is its digest against the committed state.
func writeEvents(ws []core.Write) []abci.Event {
	evs := make([]abci.Event, 0, len(ws))
	for _, w := range ws {
		if w.Del {
			evs = append(evs, abci.Event{Type: "aureom.d", Attributes: []abci.EventAttribute{{Key: "key", Value: w.Key}}})
		} else {
			evs = append(evs, abci.Event{Type: "aureom.w", Attributes: []abci.EventAttribute{{Key: "key", Value: w.Key}, {Key: "value", Value: string(w.Value)}}})
		}
	}
	return evs
}

func (a *App) Commit(_ context.Context, _ *abci.RequestCommit) (*abci.ResponseCommit, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	hash, ver, err := a.tree.SaveVersion()
	if err != nil {
		panic(fmt.Sprintf("commit: %v", err))
	}
	if a.pendingHash != nil && string(hash) != string(a.pendingHash) {
		panic("commit hash differs from finalize hash: non-deterministic state machine")
	}
	a.lastHeight = ver
	a.pendingHash = nil
	return &abci.ResponseCommit{}, nil
}

// ---- Query ------------------------------------------------------------------

type PrefixQuery struct {
	Prefix string `json:"prefix"`
	After  string `json:"after"`
	Limit  int    `json:"limit"`
}
type KVPair struct {
	Key   string          `json:"key"`
	Value json.RawMessage `json:"value"`
}

func (a *App) immutable(h int64) (*iavl.ImmutableTree, int64, error) {
	if h == 0 {
		h = a.lastHeight
	}
	if h == 0 {
		return nil, 0, fmt.Errorf("no committed state yet")
	}
	t, err := a.tree.GetImmutable(h)
	return t, h, err
}

func (a *App) Query(_ context.Context, req *abci.RequestQuery) (*abci.ResponseQuery, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	switch {
	case strings.HasPrefix(req.Path, "/p2p/filter/id/"):
		// permissioned network: a peer is admitted only if its node id is registered on-chain
		id := strings.TrimPrefix(req.Path, "/p2p/filter/id/")
		if _, ok := a.kv.Get(core.KNode + id); ok {
			return &abci.ResponseQuery{Code: 0}, nil
		}
		return &abci.ResponseQuery{Code: 1, Log: "node id not registered in on-chain membership"}, nil
	case strings.HasPrefix(req.Path, "/p2p/filter/addr/"):
		return &abci.ResponseQuery{Code: 0}, nil
	}
	t, h, err := a.immutable(req.Height)
	if err != nil {
		return &abci.ResponseQuery{Code: 2, Log: err.Error()}, nil
	}
	switch req.Path {
	case "/key":
		resp := &abci.ResponseQuery{Key: req.Data, Height: h}
		v, err := t.Get(req.Data)
		if err != nil {
			return &abci.ResponseQuery{Code: 3, Log: err.Error()}, nil
		}
		resp.Value = v
		if req.Prove {
			var cp *ics23.CommitmentProof
			if v != nil {
				cp, err = t.GetMembershipProof(req.Data)
			} else {
				cp, err = t.GetNonMembershipProof(req.Data)
			}
			if err != nil {
				return &abci.ResponseQuery{Code: 3, Log: err.Error()}, nil
			}
			bz, err := cp.Marshal()
			if err != nil {
				return &abci.ResponseQuery{Code: 3, Log: err.Error()}, nil
			}
			resp.ProofOps = &cmtcrypto.ProofOps{Ops: []cmtcrypto.ProofOp{{Type: ProofOpType, Key: req.Data, Data: bz}}}
		}
		return resp, nil
	case "/prefix":
		var q PrefixQuery
		if err := json.Unmarshal(req.Data, &q); err != nil {
			return &abci.ResponseQuery{Code: 4, Log: err.Error()}, nil
		}
		if q.Limit <= 0 || q.Limit > 1000 {
			q.Limit = 200
		}
		start := []byte(q.Prefix)
		if q.After != "" {
			start = append([]byte(q.After), 0)
		}
		end := prefixEnd([]byte(q.Prefix))
		var out []KVPair
		t.IterateRange(start, end, true, func(k, v []byte) bool {
			out = append(out, KVPair{Key: string(k), Value: json.RawMessage(v)})
			return len(out) >= q.Limit
		})
		bz, _ := json.Marshal(out)
		return &abci.ResponseQuery{Value: bz, Height: h}, nil
	case "/digest":
		d := core.NewDigest()
		t.Iterate(func(k, v []byte) bool { d.Add(k, v); return false })
		bz, _ := json.Marshal(map[string]any{"height": h, "app_hash": hex.EncodeToString(t.Hash()), "digest": hex.EncodeToString(d.Sum()), "entries": d.N})
		return &abci.ResponseQuery{Value: bz, Height: h}, nil
	case "/info":
		bz, _ := json.Marshal(map[string]any{"height": h, "app_hash": hex.EncodeToString(t.Hash()), "app_version": currentVer(a.kv),
			"chain_id": a.chainID, "max_supported_version": core.MaxSupportedVersion, "available_versions": len(a.tree.AvailableVersions())})
		return &abci.ResponseQuery{Value: bz, Height: h}, nil
	}
	return &abci.ResponseQuery{Code: 5, Log: "unknown query path"}, nil
}

func prefixEnd(p []byte) []byte {
	e := append([]byte(nil), p...)
	for i := len(e) - 1; i >= 0; i-- {
		e[i]++
		if e[i] != 0 {
			return e[:i+1]
		}
	}
	return nil
}

// ---- Helpers for tools ----

func TxHash(tx []byte) string {
	h := sha256.Sum256(tx)
	return strings.ToUpper(hex.EncodeToString(h[:]))
}

// Tree exposes the IAVL tree for offline tools (snapshot export / verification).
func (a *App) Tree() *iavl.MutableTree { return a.tree }
