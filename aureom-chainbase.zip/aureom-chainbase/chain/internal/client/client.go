// Package client is the Go client used by tools, tests and the benchmark: sign, submit,
// wait for finality and query authoritative state over CometBFT RPC.
package client

import (
	"context"
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"github.com/cometbft/cometbft/crypto/tmhash"
	"github.com/cometbft/cometbft/rpc/client"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	coretypes "github.com/cometbft/cometbft/rpc/core/types"

	"github.com/aureom/chainbase/internal/core"
)

type Client struct {
	RPC       *rpchttp.HTTP
	NetworkID string
	seq       atomic.Int64
	prefix    string
}

func New(rpcURL, networkID string) (*Client, error) {
	c, err := rpchttp.New(rpcURL, "/websocket")
	if err != nil {
		return nil, err
	}
	return &Client{RPC: c, NetworkID: networkID, prefix: fmt.Sprintf("%x", time.Now().UnixNano()%0xffffffff)}, nil
}

// Key files written by netgen.
type KeyFile struct {
	Identity string `json:"identity"`
	KeyID    string `json:"key_id"`
	SeedHex  string `json:"seed_hex"`
	PubB64   string `json:"pub_b64"`
}

func LoadKey(dir, id string) (ed25519.PrivateKey, string, error) {
	b, err := os.ReadFile(filepath.Join(dir, id+".json"))
	if err != nil {
		return nil, "", err
	}
	var kf KeyFile
	if err := json.Unmarshal(b, &kf); err != nil {
		return nil, "", err
	}
	seed, err := hex.DecodeString(kf.SeedHex)
	if err != nil {
		return nil, "", err
	}
	return ed25519.NewKeyFromSeed(seed), kf.KeyID, nil
}

// NewBody builds a body with a fresh unique tx_id and idempotency reference.
func (c *Client) NewBody(signer, keyID, typ string, payload any) core.Body {
	n := c.seq.Add(1)
	raw, _ := json.Marshal(payload)
	return core.Body{TxID: fmt.Sprintf("tx-%s-%08d", c.prefix, n), Type: typ, Signer: signer, KeyID: keyID,
		Idempotency: fmt.Sprintf("idem-%s-%08d", c.prefix, n), ClientTimeMs: time.Now().UnixMilli(), Payload: raw}
}

func (c *Client) Sign(b core.Body, k ed25519.PrivateKey) []byte {
	return core.SignTx(c.NetworkID, b, k)
}

type SubmitResult struct {
	Hash      string
	CheckCode uint32
	Log       string
}

// Submit relays a signed tx (broadcast_tx_sync: returns after CheckTx, NOT after finality).
func (c *Client) Submit(ctx context.Context, wire []byte) (*SubmitResult, error) {
	r, err := c.RPC.BroadcastTxSync(ctx, wire)
	if err != nil {
		return nil, err
	}
	return &SubmitResult{Hash: strings.ToUpper(hex.EncodeToString(r.Hash)), CheckCode: r.Code, Log: r.Log}, nil
}

func TxHash(wire []byte) []byte { return tmhash.Sum(wire) }

// WaitFinal polls until the tx is in a committed block (CometBFT finality is immediate on commit).
func (c *Client) WaitFinal(ctx context.Context, wire []byte, timeout time.Duration) (*coretypes.ResultTx, error) {
	h := TxHash(wire)
	deadline := time.Now().Add(timeout)
	for {
		r, err := c.RPC.Tx(ctx, h, false)
		if err == nil {
			return r, nil
		}
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("tx not finalised within %s", timeout)
		}
		time.Sleep(100 * time.Millisecond)
	}
}

// Do signs, submits and waits. Returns the finalised result.
func (c *Client) Do(ctx context.Context, k ed25519.PrivateKey, signer, keyID, typ string, payload any) (*coretypes.ResultTx, *core.Body, error) {
	b := c.NewBody(signer, keyID, typ, payload)
	wire := c.Sign(b, k)
	sr, err := c.Submit(ctx, wire)
	if err != nil {
		return nil, &b, err
	}
	if sr.CheckCode != 0 {
		return nil, &b, fmt.Errorf("rejected at admission: %s %s", core.CodeName(sr.CheckCode), sr.Log)
	}
	r, err := c.WaitFinal(ctx, wire, 30*time.Second)
	return r, &b, err
}

func (c *Client) ABCIQuery(ctx context.Context, path string, data []byte, height int64, prove bool) (*coretypes.ResultABCIQuery, error) {
	return c.RPC.ABCIQueryWithOptions(ctx, path, data, client.ABCIQueryOptions{Height: height, Prove: prove})
}

// GetRecord reads one authoritative state record (optionally with an ICS23 proof).
func (c *Client) GetRecord(ctx context.Context, key string, height int64) ([]byte, int64, error) {
	r, err := c.ABCIQuery(ctx, "/key", []byte(key), height, false)
	if err != nil {
		return nil, 0, err
	}
	if r.Response.Code != 0 {
		return nil, 0, fmt.Errorf("query: %s", r.Response.Log)
	}
	return r.Response.Value, r.Response.Height, nil
}
