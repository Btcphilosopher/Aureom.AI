//go:build integration

package itest

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	rpchttp "github.com/cometbft/cometbft/rpc/client/http"

	"github.com/aureom/chainbase/internal/netgen"
)

func removeAll(dir string, keep string) error {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return err
	}
	for _, e := range ents {
		if e.Name() == keep {
			continue
		}
		if err := os.RemoveAll(filepath.Join(dir, e.Name())); err != nil {
			return err
		}
	}
	return nil
}

func (n *Net) peerIDs(i int) map[string]bool {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	out := map[string]bool{}
	ni, err := n.RPC[i].NetInfo(ctx)
	if err != nil {
		return out
	}
	for _, p := range ni.Peers {
		out[string(p.NodeInfo.ID())] = true
	}
	return out
}

type intruder struct {
	cmd    *exec.Cmd
	nodeID string
	rpc    *rpchttp.HTTP
	home   string
	bin    string
	logf   string
}

func (i *intruder) start() error {
	cmd := exec.Command(filepath.Join(i.bin, "chaind"), "start", "--home", i.home, "--log-level", "main:info,*:error")
	f, _ := os.OpenFile(i.logf, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	cmd.Stdout, cmd.Stderr = f, f
	if err := cmd.Start(); err != nil {
		return err
	}
	i.cmd = cmd
	return nil
}

// restart: CometBFT gives up redialling a persistent peer that rejected it, so a node admitted by
// governance is (re)started after the activation height — this is the documented onboarding step.
func (i *intruder) restart() error {
	i.stop()
	return i.start()
}

// newIntruder starts a node with the right genesis but a fresh, unregistered node key.
func newIntruder(n *Net, base int) (*intruder, error) {
	ni, err := netgen.NewNode(n.Dir, netgen.NewNodeOptions{Name: "intruder", Mode: "observer", P2PPort: base, RPCPort: base + 1, TimeoutCommit: 500 * time.Millisecond})
	if err != nil {
		return nil, err
	}
	// dial validators directly (not via proxies): they must refuse the connection on identity grounds
	c, _ := rpchttp.NewWithTimeout(ni.RPCURL, "/websocket", 3)
	in := &intruder{nodeID: ni.NodeID, rpc: c, home: ni.Home, bin: n.Bin, logf: filepath.Join(n.Dir, "intruder.log")}
	if err := in.start(); err != nil {
		return nil, err
	}
	return in, nil
}

func (i *intruder) log(n *Net) string {
	b, _ := os.ReadFile(filepath.Join(n.Dir, "intruder.log"))
	return string(b)
}

func (i *intruder) stop() {
	if i.cmd != nil {
		i.cmd.Process.Kill()
		i.cmd.Wait()
		i.cmd = nil
	}
}
func (i *intruder) height() int64 {
	st, err := i.rpc.Status(context.Background())
	if err != nil {
		return -1
	}
	return st.SyncInfo.LatestBlockHeight
}

var _ = fmt.Sprint
var _ = strings.ToUpper
