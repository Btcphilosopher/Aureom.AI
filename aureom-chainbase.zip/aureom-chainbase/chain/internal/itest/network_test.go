//go:build integration

package itest

import (
	"context"
	"encoding/base64"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/cometbft/cometbft/privval"
	"github.com/cometbft/cometbft/types"

	"github.com/aureom/chainbase/internal/core"
)

type M = map[string]any

func product(id, name string) M {
	return M{"product_id": id, "name": name, "variants": []M{{"sku_id": "SKU-" + id, "unit": "EA"}}}
}

func agree(t *testing.T, n *Net, nodes []int, h int64) {
	t.Helper()
	var want string
	for k, i := range nodes {
		got := n.AppHashAt(i, h)
		if got == "" {
			t.Fatalf("node %d has no header %d", i, h+1)
		}
		if k == 0 {
			want = got
		} else if got != want {
			t.Fatalf("nodes disagree on state after block %d: node %d=%s want %s", h, i, got, want)
		}
	}
}

// Agreement on finalised state across independently executing validators + failure tolerance (f=1)
// + recovery by replaying the chain on a brand-new data directory.
func TestAgreementToleranceAndRebuild(t *testing.T) {
	n := Start(t, 31000)
	n.WaitAllUp(3, 30*time.Second)
	for i, id := range []string{"A", "B", "C", "D"} {
		w := n.Tx("catalog-mgr", "CreateProduct", product(id, "Product "+id))
		if _, err := n.Submit(i%4, w); err != nil { // spread across validators' mempools
			t.Fatal(err)
		}
		if f, code, _ := n.WaitFinal(w, 15*time.Second); !f || code != 0 {
			t.Fatalf("tx %s not finalised ok: found=%v code=%d", id, f, code)
		}
	}
	h := n.View(0).Height
	n.WaitAllUp(h, 10*time.Second)
	agree(t, n, []int{0, 1, 2, 3}, h-1)

	// f=1: stop one validator, the chain keeps finalising with 3 of 4
	n.KillNode(3)
	before := n.View(0).Height
	w := n.Tx("catalog-mgr", "CreateProduct", product("E", "Product E"))
	n.Submit(0, w)
	if f, code, _ := n.WaitFinal(w, 20*time.Second); !f || code != 0 {
		t.Fatalf("chain must tolerate one stopped validator: found=%v code=%d heights=%v", f, code, n.Heights())
	}
	if n.View(0).Height <= before {
		t.Fatal("no progress with 3/4")
	}
	// rebuild: restart the validator with its keys but a NEW empty data directory => it replays the whole chain
	dataDir := n.Info.Nodes[3].Home + "/data"
	if err := removeAll(dataDir, "priv_validator_state.json"); err != nil {
		t.Fatal(err)
	}
	n.StartNode(3)
	if !n.WaitHeight(3, n.View(0).Height-1, 60*time.Second) {
		t.Fatalf("rebuilt node did not catch up: %v", n.Heights())
	}
	h = n.View(3).Height - 2
	agree(t, n, []int{0, 1, 2, 3}, h)
	if d0, d3 := n.Digest(0), n.Digest(3); d0[:20] != d3[:20] && n.View(0).Height == n.View(3).Height {
		t.Logf("digests (height skew possible) %s %s", d0, d3)
	}
}

// Quorum loss: with only 2 of 4 validators nothing can be finalised (no fork, no progress); transactions wait
// and finalise once quorum returns.
func TestQuorumLossHaltsThenRecovers(t *testing.T) {
	n := Start(t, 31100)
	n.WaitAllUp(3, 30*time.Second)
	n.KillNode(2)
	n.KillNode(3)
	time.Sleep(2 * time.Second)
	h0 := n.View(0).Height
	w := n.Tx("catalog-mgr", "CreateProduct", product("Q", "During outage"))
	if _, err := n.Submit(0, w); err != nil {
		t.Fatal(err)
	}
	time.Sleep(8 * time.Second)
	if f, _, _ := n.Final(w); f {
		t.Fatal("a transaction was finalised without quorum")
	}
	if h1 := n.View(0).Height; h1 > h0+1 {
		t.Fatalf("chain advanced without quorum: %d -> %d", h0, h1)
	}
	// restore one validator: 3/4 = quorum => the pending tx finalises
	n.StartNode(2)
	if f, code, _ := n.WaitFinal(w, 40*time.Second); !f || code != 0 {
		t.Fatalf("pending tx not finalised after quorum returned: found=%v code=%d heights=%v", f, code, n.Heights())
	}
	n.StartNode(3)
	n.WaitAllUp(n.View(0).Height, 40*time.Second)
}

// Network partitions: a 2|2 split has no side with quorum (nothing finalises on either side, so no fork);
// a 3|1 split lets the majority continue while the minority stalls, and the minority converges after healing.
func TestNetworkPartitions(t *testing.T) {
	n := Start(t, 31200)
	n.WaitAllUp(3, 30*time.Second)

	// 2|2
	n.Partition([]int{0, 1}, []int{2, 3})
	time.Sleep(3 * time.Second)
	hs := n.Heights()
	wa := n.Tx("catalog-mgr", "CreateProduct", product("SPLIT", "Side A"))
	wb := n.Tx("catalog-mgr", "CreateProduct", product("SPLIT", "Side B"))
	n.Submit(0, wa)
	n.Submit(2, wb)
	time.Sleep(8 * time.Second)
	now := n.Heights()
	for i := range hs {
		if now[i] > hs[i]+1 {
			t.Fatalf("a minority partition advanced (fork risk): before=%v after=%v", hs, now)
		}
	}
	if fa, _, _ := n.Final(wa); fa {
		t.Fatal("tx finalised on a 2-validator side")
	}
	if fb, _, _ := n.Final(wb); fb {
		t.Fatal("tx finalised on a 2-validator side")
	}
	n.Heal()
	// both conflicting creations are eventually ordered: exactly one succeeds, the other is rejected deterministically
	fa, ca, _ := n.WaitFinal(wa, 60*time.Second)
	fb, cb, _ := n.WaitFinal(wb, 60*time.Second)
	if !fa || !fb || (ca == 0) == (cb == 0) {
		t.Fatalf("after healing exactly one of the conflicting txs must succeed: a=%v/%d b=%v/%d", fa, ca, fb, cb)
	}
	if ca != 0 && ca != core.CodeExists || cb != 0 && cb != core.CodeExists {
		t.Fatalf("losing tx must be rejected as ALREADY_EXISTS: %d %d", ca, cb)
	}
	n.WaitAllUp(n.View(0).Height, 40*time.Second)

	// 3|1
	n.Partition([]int{0, 1, 2}, []int{3})
	time.Sleep(2 * time.Second)
	w := n.Tx("catalog-mgr", "CreateProduct", product("MAJ", "Majority side"))
	n.Submit(0, w)
	if f, code, _ := n.WaitFinal(w, 20*time.Second); !f || code != 0 {
		t.Fatalf("majority partition must keep finalising: %v %d", f, code)
	}
	if n.View(3).Height >= n.View(0).Height {
		t.Fatal("isolated validator should be behind")
	}
	n.Heal()
	if !n.WaitHeight(3, n.View(0).Height, 60*time.Second) {
		t.Fatalf("isolated validator did not converge: %v", n.Heights())
	}
	h := n.View(3).Height - 2
	agree(t, n, []int{0, 1, 2, 3}, h)
}

// Crash (SIGKILL) of every validator at once, then restart: state and height are recovered from disk.
func TestAllValidatorsCrashAndRecover(t *testing.T) {
	n := Start(t, 31300)
	n.WaitAllUp(3, 30*time.Second)
	w := n.Tx("catalog-mgr", "CreateProduct", product("PERSIST", "Survives crashes"))
	n.Submit(1, w)
	if f, code, _ := n.WaitFinal(w, 20*time.Second); !f || code != 0 {
		t.Fatal("tx")
	}
	h := n.View(0).Height
	for i := range n.Procs {
		n.KillNode(i)
	}
	for i := range n.Procs {
		n.StartNode(i)
	}
	n.WaitAllUp(h+3, 60*time.Second)
	if f, code, _ := n.Final(w); !f || code != 0 {
		t.Fatal("finalised tx lost across crash")
	}
	agree(t, n, []int{0, 1, 2, 3}, h)
	// replaying a finalised transaction after restart is still refused
	n.Submit(0, w)
	w2 := n.Tx("catalog-mgr", "CreateProduct", product("PERSIST2", "after crash"))
	n.Submit(0, w2)
	if f, code, _ := n.WaitFinal(w2, 20*time.Second); !f || code != 0 {
		t.Fatal("chain not live after crash recovery")
	}
}

// Permissioned membership: a node whose id is not registered on-chain cannot connect to validators.
func TestUnregisteredNodeCannotJoin(t *testing.T) {
	n := Start(t, 31400)
	n.WaitAllUp(3, 30*time.Second)
	info, err := newIntruder(n, 31450)
	if err != nil {
		t.Fatal(err)
	}
	defer info.stop()
	time.Sleep(10 * time.Second)
	for i := range n.RPC {
		peers := n.peerIDs(i)
		if peers[info.nodeID] {
			t.Fatalf("validator %d accepted an unregistered peer", i)
		}
	}
	if info.height() < 0 {
		t.Fatal("test invalid: the unregistered node is not running")
	}
	if info.height() > 1 {
		t.Fatalf("unregistered node synced the chain (height %d)", info.height())
	}
}

// Positive control + governance: an observer node is admitted ONLY after >2/3 of validator voting power
// approves an on-chain proposal, and only from its activation height; it then replays the chain from genesis.
func TestObserverAdmissionViaGovernance(t *testing.T) {
	n := Start(t, 31500)
	n.WaitAllUp(3, 30*time.Second)
	in, err := newIntruder(n, 31550)
	if err != nil {
		t.Fatal(err)
	}
	defer in.stop()
	time.Sleep(6 * time.Second)
	if in.height() > 1 {
		t.Fatalf("node synced before being admitted (height %d)", in.height())
	}
	act := n.View(0).Height + 14
	prop := n.Tx("hq-org-admin", "ProposeGovernance", M{"proposal_id": "GOV-OBS", "kind": "ADD_OBSERVER", "activation_height": act,
		"payload": M{"member_id": "obs-audit", "org": "org-audit", "node_id": in.nodeID}})
	n.Submit(0, prop)
	if f, c, _ := n.WaitFinal(prop, 20*time.Second); !f || c != 0 {
		t.Fatalf("proposal: %v %d", f, c)
	}
	for _, who := range []string{"hq-org-admin", "dist-org-admin", "north-org-admin"} {
		w := n.Tx(who, "ApproveGovernance", M{"proposal_id": "GOV-OBS"})
		n.Submit(1, w)
		if f, c, _ := n.WaitFinal(w, 20*time.Second); !f || c != 0 {
			t.Fatalf("approval by %s: %v %d", who, f, c)
		}
	}
	if !n.WaitHeight(0, act+1, 60*time.Second) {
		t.Fatal("activation height not reached")
	}
	// once registered (and the node is started/restarted) it is admitted and replays the whole chain
	if err := in.restart(); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(90 * time.Second)
	for in.height() < act+1 && time.Now().Before(deadline) {
		time.Sleep(time.Second)
	}
	if in.height() < act+1 {
		t.Fatalf("admitted observer did not sync (height %d, want >= %d)\n%s", in.height(), act+1, in.log(n))
	}
	h := in.height() - 2
	nh := h + 1
	ib, err := in.rpc.Block(context.Background(), &nh)
	if err != nil {
		t.Fatal(err)
	}
	if got := strings.ToUpper(fmt.Sprintf("%x", ib.Block.AppHash)); got != n.AppHashAt(0, h) {
		t.Fatalf("observer replay disagrees with validators at %d", h)
	}
}

func approveAll(t *testing.T, n *Net, id string, who ...string) {
	t.Helper()
	for _, w := range who {
		tx := n.Tx(w, "ApproveGovernance", M{"proposal_id": id})
		n.Submit(0, tx)
		if f, c, _ := n.WaitFinal(tx, 20*time.Second); !f || c != 0 {
			t.Fatalf("approve %s by %s: %v %d", id, w, f, c)
		}
	}
}

func validatorCount(t *testing.T, n *Net, h int64) (int, int64) {
	t.Helper()
	vs, err := n.RPC[0].Validators(context.Background(), &h, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	var total int64
	for _, v := range vs.Validators {
		total += v.VotingPower
	}
	return len(vs.Validators), total
}

// Controlled validator addition and removal on the live network: a 5th validator joins only after an on-chain
// vote and activation height, signs blocks, and is later removed by another vote.
func TestAddAndRemoveValidatorByGovernance(t *testing.T) {
	n := Start(t, 31700)
	n.WaitAllUp(3, 30*time.Second)
	in, err := newIntruder(n, 31750)
	if err != nil {
		t.Fatal(err)
	}
	defer in.stop()
	in.stop() // start it only after admission
	pv := privval.LoadFilePV(filepath.Join(in.home, "config", "priv_validator_key.json"), filepath.Join(in.home, "data", "priv_validator_state.json"))
	pk, _ := pv.GetPubKey()
	pub := base64.StdEncoding.EncodeToString(pk.Bytes())

	act := n.View(0).Height + 14
	p := n.Tx("hq-org-admin", "ProposeGovernance", M{"proposal_id": "GOV-ADDV", "kind": "ADD_VALIDATOR", "activation_height": act,
		"payload": M{"member_id": "val-extra", "org": "org-extra", "role": "REGIONAL", "pubkey_b64": pub, "node_id": in.nodeID, "power": 10}})
	n.Submit(0, p)
	if f, c, _ := n.WaitFinal(p, 20*time.Second); !f || c != 0 {
		t.Fatal("proposal")
	}
	approveAll(t, n, "GOV-ADDV", "hq-org-admin", "dist-org-admin", "north-org-admin")
	if !n.WaitHeight(0, act+1, 60*time.Second) {
		t.Fatal("activation height not reached")
	}
	if cnt, _ := validatorCount(t, n, act-1); cnt != 4 {
		t.Fatalf("validator set changed before activation: %d", cnt)
	}
	if err := in.start(); err != nil {
		t.Fatal(err)
	}
	if !n.WaitHeight(0, act+8, 60*time.Second) {
		t.Fatal("no progress")
	}
	// consensus effect two blocks after the block that returned the update
	cnt, total := validatorCount(t, n, act+3)
	if cnt != 5 || total != 50 {
		t.Fatalf("validator set after activation: %d validators power %d", cnt, total)
	}
	// the new validator has caught up and is signing
	deadline := time.Now().Add(60 * time.Second)
	signed := false
	for time.Now().Before(deadline) && !signed {
		h := n.View(0).Height - 1
		cm, err := n.RPC[0].Commit(context.Background(), &h)
		if err == nil {
			for _, s := range cm.Commit.Signatures {
				if string(s.ValidatorAddress) == string(pk.Address()) && s.BlockIDFlag == types.BlockIDFlagCommit {
					signed = true
				}
			}
		}
		time.Sleep(500 * time.Millisecond)
	}
	if !signed {
		t.Fatalf("the added validator never signed a block (observer height %d)", in.height())
	}
	// with 5 validators (power 50) a block needs > 33.3 => 4 validators: stopping one regular validator is still fine
	n.KillNode(3)
	w := n.Tx("catalog-mgr", "CreateProduct", product("V5", "five validators"))
	n.Submit(0, w)
	if f, c, _ := n.WaitFinal(w, 20*time.Second); !f || c != 0 {
		t.Fatal("chain must tolerate one failure with 5 validators")
	}
	n.StartNode(3)

	// removal needs > 2/3 of the current power (50): 4 organisations (40) approve
	act2 := n.View(0).Height + 14
	rp := n.Tx("hq-org-admin", "ProposeGovernance", M{"proposal_id": "GOV-RMV", "kind": "REMOVE_VALIDATOR", "activation_height": act2, "payload": M{"member_id": "val-extra"}})
	n.Submit(0, rp)
	if f, c, _ := n.WaitFinal(rp, 20*time.Second); !f || c != 0 {
		t.Fatal("removal proposal")
	}
	approveAll(t, n, "GOV-RMV", "hq-org-admin", "dist-org-admin", "north-org-admin", "south-org-admin")
	if !n.WaitHeight(0, act2+4, 90*time.Second) {
		t.Fatal("removal activation not reached")
	}
	if cnt, total := validatorCount(t, n, act2+3); cnt != 4 || total != 40 {
		t.Fatalf("after removal: %d validators power %d", cnt, total)
	}
}
