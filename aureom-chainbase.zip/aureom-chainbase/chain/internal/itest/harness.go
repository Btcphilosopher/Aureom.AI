//go:build integration

package itest

import (
	"context"
	"crypto/ed25519"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	rpchttp "github.com/cometbft/cometbft/rpc/client/http"

	"github.com/aureom/chainbase/internal/client"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/netgen"
)

const NetID = "aureom-itest-1"

// ---- a TCP proxy per directed peer link so that real network partitions can be created ----

type Proxy struct {
	ln     net.Listener
	target string
	mu     sync.Mutex
	up     bool
	conns  map[net.Conn]struct{}
}

func NewProxy(listen, target string) (*Proxy, error) {
	ln, err := net.Listen("tcp", listen)
	if err != nil {
		return nil, err
	}
	p := &Proxy{ln: ln, target: target, up: true, conns: map[net.Conn]struct{}{}}
	go p.loop()
	return p, nil
}

func (p *Proxy) loop() {
	for {
		c, err := p.ln.Accept()
		if err != nil {
			return
		}
		p.mu.Lock()
		up := p.up
		p.mu.Unlock()
		if !up {
			c.Close()
			continue
		}
		d, err := net.DialTimeout("tcp", p.target, 2*time.Second)
		if err != nil {
			c.Close()
			continue
		}
		p.mu.Lock()
		p.conns[c], p.conns[d] = struct{}{}, struct{}{}
		p.mu.Unlock()
		go func() { io.Copy(d, c); d.Close(); c.Close() }()
		go func() { io.Copy(c, d); d.Close(); c.Close() }()
	}
}

func (p *Proxy) SetUp(up bool) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.up = up
	if !up {
		for c := range p.conns {
			c.Close()
		}
		p.conns = map[net.Conn]struct{}{}
	}
}

func (p *Proxy) Close() { p.ln.Close(); p.SetUp(false) }

// ---- the network ----

type Net struct {
	T       *testing.T
	Dir     string
	Bin     string
	Info    *netgen.Network
	Procs   []*exec.Cmd
	RPC     []*rpchttp.HTTP
	proxies map[[2]int]*Proxy
	Keys    string
	Base    int
}

func binDir() string {
	if v := os.Getenv("CHAINBASE_BIN"); v != "" {
		return v
	}
	wd, _ := os.Getwd()
	return filepath.Join(wd, "..", "..", "..", "bin")
}

// Start generates and launches a 4-validator network. Peers dial each other through proxies.
func Start(t *testing.T, base int) *Net {
	t.Helper()
	dir := t.TempDir()
	if d := os.Getenv("ITEST_DIR"); d != "" {
		dir = filepath.Join(d, t.Name())
		os.MkdirAll(dir, 0o755)
	}
	n := &Net{T: t, Dir: dir, Bin: binDir(), proxies: map[[2]int]*Proxy{}, Base: base}
	if _, err := os.Stat(filepath.Join(n.Bin, "chaind")); err != nil {
		t.Fatalf("chaind binary not found in %s (run `make build`)", n.Bin)
	}
	info, err := netgen.Generate(netgen.Options{Out: n.Dir, NetworkID: NetID, BasePort: base, TimeoutCommit: 500 * time.Millisecond,
		PeerPortOverride: func(from, to int) int { return base + 500 + from*10 + to }})
	if err != nil {
		t.Fatal(err)
	}
	n.Info, n.Keys = info, filepath.Join(n.Dir, "keys")
	for from := range info.Nodes {
		for to := range info.Nodes {
			if from == to {
				continue
			}
			p, err := NewProxy(fmt.Sprintf("127.0.0.1:%d", base+500+from*10+to), fmt.Sprintf("127.0.0.1:%d", info.Nodes[to].P2PPort))
			if err != nil {
				t.Fatal(err)
			}
			n.proxies[[2]int{from, to}] = p
		}
	}
	for i := range info.Nodes {
		c, err := rpchttp.NewWithTimeout(info.Nodes[i].RPCURL, "/websocket", 5)
		if err != nil {
			t.Fatal(err)
		}
		n.RPC = append(n.RPC, c)
	}
	n.Procs = make([]*exec.Cmd, len(info.Nodes))
	for i := range info.Nodes {
		n.StartNode(i)
	}
	t.Cleanup(n.Stop)
	return n
}

func (n *Net) StartNode(i int) {
	if n.Procs[i] != nil {
		return
	}
	logf, _ := os.OpenFile(filepath.Join(n.Dir, n.Info.Nodes[i].Name+".log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	lvl := os.Getenv("ITEST_LOGLEVEL")
	if lvl == "" {
		lvl = "main:info,*:error"
	}
	cmd := exec.Command(filepath.Join(n.Bin, "chaind"), "start", "--home", n.Info.Nodes[i].Home, "--log-level", lvl)
	cmd.Stdout, cmd.Stderr = logf, logf
	if err := cmd.Start(); err != nil {
		n.T.Fatal(err)
	}
	n.Procs[i] = cmd
}

func (n *Net) KillNode(i int) {
	if n.Procs[i] == nil {
		return
	}
	n.Procs[i].Process.Kill()
	n.Procs[i].Wait()
	n.Procs[i] = nil
}

func (n *Net) Stop() {
	for i := range n.Procs {
		n.KillNode(i)
	}
	for _, p := range n.proxies {
		p.Close()
	}
}

// Partition cuts every link between the two groups (in both directions) and drops live connections.
func (n *Net) Partition(a, b []int) {
	for _, x := range a {
		for _, y := range b {
			n.proxies[[2]int{x, y}].SetUp(false)
			n.proxies[[2]int{y, x}].SetUp(false)
		}
	}
}

func (n *Net) Heal() {
	for _, p := range n.proxies {
		p.SetUp(true)
	}
}

type View struct {
	Up      bool
	Height  int64
	AppHash string
}

func (n *Net) View(i int) View {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	st, err := n.RPC[i].Status(ctx)
	if err != nil {
		return View{}
	}
	return View{Up: true, Height: st.SyncInfo.LatestBlockHeight, AppHash: strings.ToUpper(fmt.Sprintf("%x", st.SyncInfo.LatestAppHash))}
}

func (n *Net) Heights() []int64 {
	out := make([]int64, len(n.RPC))
	for i := range n.RPC {
		out[i] = n.View(i).Height
	}
	return out
}

func (n *Net) WaitHeight(i int, h int64, d time.Duration) bool {
	end := time.Now().Add(d)
	for time.Now().Before(end) {
		if n.View(i).Height >= h {
			return true
		}
		time.Sleep(200 * time.Millisecond)
	}
	return false
}

func (n *Net) WaitAllUp(minHeight int64, d time.Duration) {
	n.T.Helper()
	for i := range n.RPC {
		if n.Procs[i] != nil && !n.WaitHeight(i, minHeight, d) {
			n.T.Fatalf("node %d did not reach height %d: heights=%v", i, minHeight, n.Heights())
		}
	}
}

func (n *Net) Key(id string) (ed25519.PrivateKey, string) {
	k, kid, err := client.LoadKey(n.Keys, id)
	if err != nil {
		n.T.Fatal(err)
	}
	return k, kid
}

// Tx builds + signs a transaction (not yet submitted).
func (n *Net) Tx(signer, typ string, payload any) []byte {
	k, kid := n.Key(signer)
	c, _ := client.New(n.Info.Nodes[0].RPCURL, NetID)
	return c.Sign(c.NewBody(signer, kid, typ, payload), k)
}

func (n *Net) Submit(node int, wire []byte) (core.Outcome, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	r, err := n.RPC[node].BroadcastTxSync(ctx, wire)
	if err != nil {
		return core.Outcome{}, err
	}
	return core.Outcome{Code: r.Code, Log: r.Log}, nil
}

// Final returns the finalised result of wire if committed (checking any live node).
func (n *Net) Final(wire []byte) (found bool, code uint32, height int64) {
	h := client.TxHash(wire)
	for i := range n.RPC {
		if n.Procs[i] == nil {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		r, err := n.RPC[i].Tx(ctx, h, false)
		cancel()
		if err == nil {
			return true, r.TxResult.Code, r.Height
		}
	}
	return false, 0, 0
}

func (n *Net) WaitFinal(wire []byte, d time.Duration) (bool, uint32, int64) {
	end := time.Now().Add(d)
	for time.Now().Before(end) {
		if f, c, h := n.Final(wire); f {
			return true, c, h
		}
		time.Sleep(200 * time.Millisecond)
	}
	return false, 0, 0
}

// AppHashAt reads the app hash committed for height h (from header h+1) on node i.
func (n *Net) AppHashAt(i int, h int64) string {
	nh := h + 1
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	b, err := n.RPC[i].Block(ctx, &nh)
	if err != nil {
		return ""
	}
	return strings.ToUpper(fmt.Sprintf("%x", b.Block.AppHash))
}

func (n *Net) Digest(i int) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	r, err := n.RPC[i].ABCIQuery(ctx, "/digest", nil)
	if err != nil {
		return ""
	}
	var d map[string]any
	json.Unmarshal(r.Response.Value, &d)
	return fmt.Sprintf("%v@%v", d["digest"], d["height"])
}
