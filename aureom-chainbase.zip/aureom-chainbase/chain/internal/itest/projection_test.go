//go:build integration

package itest

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/aureom/chainbase/internal/gateway"
)

func getJSON(t *testing.T, url string, v any) {
	t.Helper()
	r, err := http.Get(url)
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		t.Fatal(err)
	}
}

func startGateway(t *testing.T, n *Net, dbPath string) (*gateway.Gateway, *httptest.Server, context.CancelFunc) {
	g, err := gateway.New(gateway.Config{NetworkPath: filepath.Join(n.Dir, "network.json"), ProjectionPath: dbPath, Listen: "127.0.0.1:0"})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	g.Start(ctx)
	srv := httptest.NewServer(g.Handler())
	return g, srv, func() { cancel(); srv.Close() }
}

type projStatus struct {
	State   string `json:"state"`
	Indexed int64  `json:"indexed_height"`
	Head    int64  `json:"chain_head"`
	Lag     int64  `json:"lag_blocks"`
	Digest  string `json:"digest"`
	Entries int64  `json:"entries"`
}

func waitProj(t *testing.T, url string, atLeast int64, d time.Duration) projStatus {
	t.Helper()
	end := time.Now().Add(d)
	var st projStatus
	for time.Now().Before(end) {
		getJSON(t, url+"/api/v1/projection/status", &st)
		if st.State == "OK" && st.Indexed >= atLeast && st.Lag <= 1 {
			return st
		}
		time.Sleep(300 * time.Millisecond)
	}
	t.Fatalf("projection did not reach height %d: %+v", atLeast, st)
	return st
}

// The projection is disposable: deleting it (via API, or by deleting the file and starting a new gateway)
// and re-ingesting from genesis yields a projection whose digest equals the chain's state digest, and the
// same query answers; authoritative information is never lost because it was never only in the projection.
func TestProjectionDeleteAndRebuildFromChain(t *testing.T) {
	n := Start(t, 31600)
	n.WaitAllUp(3, 30*time.Second)
	db := filepath.Join(n.Dir, "proj1.sqlite")
	_, srv, stop := startGateway(t, n, db)
	defer stop()

	// write through the gateway with read-after-write
	for i := 0; i < 6; i++ {
		w := n.Tx("catalog-mgr", "CreateProduct", product(fmt.Sprintf("PJ%d", i), fmt.Sprintf("Projected %d", i)))
		body, _ := json.Marshal(map[string]any{"tx": json.RawMessage(w), "wait": "indexed", "timeout_ms": 20000})
		r, err := http.Post(srv.URL+"/api/v1/tx/submit", "application/json", bytes.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		var out map[string]any
		json.NewDecoder(r.Body).Decode(&out)
		r.Body.Close()
		if out["indexed"] != true {
			t.Fatalf("read-after-write: tx not indexed: %v", out)
		}
		// immediately visible in the projection (no polling needed)
		var list struct{ Total int }
		getJSON(t, fmt.Sprintf("%s/api/v1/q/products?q=Projected", srv.URL), &list)
		if list.Total != i+1 {
			t.Fatalf("after write %d the projection shows %d products", i+1, list.Total)
		}
	}
	before := waitProj(t, srv.URL, 8, 30*time.Second)
	if before.Entries == 0 || before.Digest == "" {
		t.Fatalf("%+v", before)
	}
	var v1 map[string]any
	getJSON(t, srv.URL+"/api/v1/projection/verify?proofs=8", &v1)
	if v1["match"] != true || v1["proofs_checked"].(float64) != v1["proofs_valid"].(float64) || v1["proofs_checked"].(float64) < 8 {
		t.Fatalf("projection must verify against the chain: %v", v1)
	}

	// 1) delete + rebuild through the API
	r, _ := http.Post(srv.URL+"/api/v1/projection/rebuild", "application/json", nil)
	r.Body.Close()
	time.Sleep(500 * time.Millisecond)
	after := waitProj(t, srv.URL, before.Head, 60*time.Second)
	var v2 map[string]any
	getJSON(t, srv.URL+"/api/v1/projection/verify?proofs=8", &v2)
	if v2["match"] != true {
		t.Fatalf("rebuilt projection does not match the chain: %v", v2)
	}
	var list struct{ Total int }
	getJSON(t, srv.URL+"/api/v1/q/products?q=Projected", &list)
	if list.Total != 6 {
		t.Fatalf("authoritative information lost after rebuild: %d products", list.Total)
	}
	_ = after

	// 2) delete the database FILE and let a brand-new gateway rebuild it purely from the chain
	stop()
	for _, suf := range []string{"", "-wal", "-shm"} {
		os.Remove(db + suf)
	}
	_, srv2, stop2 := startGateway(t, n, db)
	defer stop2()
	st2 := waitProj(t, srv2.URL, before.Head, 90*time.Second)
	var v3 map[string]any
	getJSON(t, srv2.URL+"/api/v1/projection/verify?proofs=8", &v3)
	if v3["match"] != true {
		t.Fatalf("%v", v3)
	}
	var list2 struct{ Total int }
	getJSON(t, srv2.URL+"/api/v1/q/products?q=Projected", &list2)
	if list2.Total != 6 || st2.Entries < before.Entries {
		t.Fatalf("rebuilt-from-nothing projection: products=%d entries=%d (was %d)", list2.Total, st2.Entries, before.Entries)
	}
	// authoritative read with a light-client-verified proof, served by the chain (not the projection)
	var rec struct {
		Found        bool `json:"found"`
		Verification struct {
			ProofValid     bool `json:"proof_valid"`
			HeaderVerified bool `json:"header_verified"`
		} `json:"verification"`
	}
	getJSON(t, srv2.URL+"/api/v1/chain/records/product/PJ3?prove=1", &rec)
	if !rec.Found || !rec.Verification.ProofValid || !rec.Verification.HeaderVerified {
		t.Fatalf("%+v", rec)
	}
	// a finalised-but-rejected tx (duplicate product: passes admission, fails business validation) is visible with its reason
	w := n.Tx("catalog-mgr", "CreateProduct", product("PJ1", "duplicate of an existing product"))
	body, _ := json.Marshal(map[string]any{"tx": json.RawMessage(w), "wait": "indexed"})
	rr, _ := http.Post(srv2.URL+"/api/v1/tx/submit", "application/json", bytes.NewReader(body))
	rr.Body.Close()
	var txs struct{ Items []map[string]any }
	getJSON(t, srv2.URL+"/api/v1/q/transactions?status=REJECTED", &txs)
	if len(txs.Items) != 1 || txs.Items[0]["code_name"] != "ALREADY_EXISTS" {
		t.Fatalf("rejected transactions must be visible with their reason: %v", txs.Items)
	}
}
