// Package nodeutil loads CometBFT configuration the same way the cometbft CLI does.
package nodeutil

import (
	"fmt"
	"path/filepath"

	cmtcfg "github.com/cometbft/cometbft/config"
	"github.com/spf13/viper"
)

func LoadConfig(home string) (*cmtcfg.Config, error) {
	cfg := cmtcfg.DefaultConfig()
	v := viper.New()
	v.SetConfigFile(filepath.Join(home, "config", "config.toml"))
	if err := v.ReadInConfig(); err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	if err := v.Unmarshal(cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	cfg.SetRoot(home)
	if err := cfg.ValidateBasic(); err != nil {
		return nil, fmt.Errorf("invalid config: %w", err)
	}
	return cfg, nil
}
