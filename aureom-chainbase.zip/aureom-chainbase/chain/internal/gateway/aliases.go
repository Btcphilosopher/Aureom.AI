package gateway

import (
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	coretypes "github.com/cometbft/cometbft/rpc/core/types"
)

type (
	coretypesBlock        = coretypes.ResultBlock
	coretypesCommit       = coretypes.ResultCommit
	coretypesBlockResults = coretypes.ResultBlockResults
	coretypesValidators   = coretypes.ResultValidators
	coretypesTx           = coretypes.ResultTx
	coretypesGenesis      = coretypes.ResultGenesis
)

type rpcClient = rpchttp.HTTP
