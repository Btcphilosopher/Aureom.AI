package gateway

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	dbm "github.com/cometbft/cometbft-db"
	"github.com/cometbft/cometbft/light"
	"github.com/cometbft/cometbft/light/provider"
	lighthttp "github.com/cometbft/cometbft/light/provider/http"
	lightdb "github.com/cometbft/cometbft/light/store/db"
	cmtcrypto "github.com/cometbft/cometbft/proto/tendermint/crypto"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	"github.com/cometbft/cometbft/types"
	"github.com/cosmos/ics23/go"

	"github.com/aureom/chainbase/internal/core"
)

// kindPrefix maps API kinds to state key prefixes.
var kindPrefix = map[string]string{
	"product": core.KProduct, "sku": core.KSKU, "location": core.KLocation, "supplier": core.KSupplier, "po": core.KPO,
	"receipt": core.KReceipt, "reservation": core.KReserve, "sale": core.KSale, "return": core.KReturn, "refund": core.KRefund,
	"price": core.KPrice, "promotion": core.KPromo, "loyalty": core.KLoyalty, "loyalty-entry": core.KLoyEntry,
	"adjustment": core.KAdjust, "transfer": core.KTransfer, "exception": core.KException, "identity": core.KIdentity,
	"grants": core.KGrants, "tx": core.KTx, "member": core.KMember, "proposal": core.KProposal,
}

// ---- Light client (finality verification) ----
//
// Trust root: the genesis document. At start the gateway fetches the signed block 1 from a
// validator, checks that its validator set hash equals the hash of the genesis validator set
// the operator configured, and then uses the CometBFT light client (with witnesses = the other
// validators) to verify any later header: +2/3 of the trusted validator power must have signed it.

type Light struct {
	mu              sync.Mutex
	c               *light.Client
	chainID         string
	ready           bool
	err             error
	genesisValsHash []byte
}

func (g *Gateway) initLight(ctx context.Context) {
	l := &Light{chainID: g.Net.NetworkID}
	g.light = l
	go func() {
		for i := 0; i < 120; i++ {
			if err := l.setup(ctx, g); err == nil {
				return
			} else {
				l.mu.Lock()
				l.err = err
				l.mu.Unlock()
			}
			time.Sleep(2 * time.Second)
		}
	}()
}

func (l *Light) setup(ctx context.Context, g *Gateway) error {
	var providers []provider.Provider
	for _, n := range g.Net.Nodes {
		p, err := lighthttp.New(g.Net.NetworkID, n.RPCURL)
		if err != nil {
			return err
		}
		providers = append(providers, p)
	}
	// anchor on genesis validators
	var gen *coretypesGenesis
	var err error
	for i := range g.Net.Nodes {
		if gen, err = g.Pool.Client(i).Genesis(ctx); err == nil {
			break
		}
	}
	if err != nil {
		return err
	}
	vs := make([]*types.Validator, 0, len(gen.Genesis.Validators))
	for _, v := range gen.Genesis.Validators {
		vs = append(vs, types.NewValidator(v.PubKey, v.Power))
	}
	genHash := types.NewValidatorSet(vs).Hash()
	var lb *types.LightBlock
	for _, p := range providers {
		if b, err := p.LightBlock(ctx, 1); err == nil {
			lb = b
			break
		}
	}
	if lb == nil {
		return fmt.Errorf("block 1 not available yet")
	}
	if hex.EncodeToString(lb.ValidatorSet.Hash()) != hex.EncodeToString(genHash) {
		return fmt.Errorf("SECURITY: block 1 validator set does not match the genesis validator set")
	}
	c, err := light.NewClient(ctx, g.Net.NetworkID, light.TrustOptions{Period: 10 * 365 * 24 * time.Hour, Height: 1, Hash: lb.Hash()},
		providers[0], providers[1:], lightdb.New(dbm.NewMemDB(), "light"), light.SkippingVerification(light.DefaultTrustLevel))
	if err != nil {
		return err
	}
	l.mu.Lock()
	l.c, l.ready, l.err, l.genesisValsHash = c, true, nil, genHash
	l.mu.Unlock()
	return nil
}

func (l *Light) Verify(ctx context.Context, h int64) (*types.LightBlock, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if !l.ready {
		return nil, fmt.Errorf("light client not ready: %v", l.err)
	}
	return l.c.VerifyLightBlockAtHeight(ctx, h, time.Now())
}

// ---- Chain record + proof ----

type ProofInfo struct {
	Type          string `json:"type"`
	ProofB64      string `json:"proof_b64"`
	AppHashHeight int64  `json:"app_hash_height"`
	AppHash       string `json:"app_hash"`
}
type Verification struct {
	ProofValid     bool   `json:"proof_valid"`
	HeaderVerified bool   `json:"header_verified"`
	Statement      string `json:"statement"`
	Error          string `json:"error,omitempty"`
}
type RecordResp struct {
	Key          string          `json:"key"`
	Found        bool            `json:"found"`
	Value        json.RawMessage `json:"value,omitempty"`
	ValueB64     string          `json:"value_b64,omitempty"` // exact stored bytes
	Height       int64           `json:"height"`
	Proof        *ProofInfo      `json:"proof,omitempty"`
	Verification *Verification   `json:"verification,omitempty"`
}

const proofStatement = "The key/value is committed in the application state whose root hash is in a header signed by +2/3 of validator power. This alone does not establish business correctness or the completeness of any list or search result."

func (g *Gateway) getRecord(ctx context.Context, key string, height int64, prove bool) (*RecordResp, error) {
	r, err := g.Pool.Query(ctx, "/key", []byte(key), height, prove)
	if err != nil {
		return nil, err
	}
	resp := &RecordResp{Key: key, Height: r.Response.Height, Found: len(r.Response.Value) > 0}
	if resp.Found {
		resp.Value = json.RawMessage(r.Response.Value)
		resp.ValueB64 = base64.StdEncoding.EncodeToString(r.Response.Value)
	}
	if prove && r.Response.ProofOps != nil && len(r.Response.ProofOps.Ops) > 0 {
		op := r.Response.ProofOps.Ops[0]
		resp.Proof = &ProofInfo{Type: op.Type, ProofB64: base64.StdEncoding.EncodeToString(op.Data), AppHashHeight: r.Response.Height + 1}
		resp.Verification = g.verifyProof(ctx, key, r.Response.Value, op, r.Response.Height, resp.Proof)
	}
	return resp, nil
}

func (g *Gateway) verifyProof(ctx context.Context, key string, value []byte, op cmtcrypto.ProofOp, h int64, pi *ProofInfo) *Verification {
	v := &Verification{Statement: proofStatement}
	// the root for state at height h is the app hash in header h+1; wait briefly for it
	var lb *types.LightBlock
	var err error
	for i := 0; i < 40; i++ {
		lb, err = g.light.Verify(ctx, h+1)
		if err == nil {
			break
		}
		time.Sleep(250 * time.Millisecond)
	}
	if err != nil {
		v.Error = "header not verified: " + err.Error()
		return v
	}
	v.HeaderVerified = true
	root := []byte(lb.SignedHeader.AppHash)
	pi.AppHash = strings.ToUpper(hex.EncodeToString(root))
	var cp ics23.CommitmentProof
	if err := cp.Unmarshal(op.Data); err != nil {
		v.Error = "bad proof encoding: " + err.Error()
		return v
	}
	if len(value) > 0 {
		v.ProofValid = ics23.VerifyMembership(ics23.IavlSpec, root, &cp, []byte(key), value)
	} else {
		v.ProofValid = ics23.VerifyNonMembership(ics23.IavlSpec, root, &cp, []byte(key))
	}
	if !v.ProofValid {
		v.Error = "proof does not verify against the verified app hash"
	}
	return v
}

type KVItem struct {
	Key   string          `json:"key"`
	Value json.RawMessage `json:"value"`
}

func (g *Gateway) scan(ctx context.Context, prefix, after string, limit int, height int64) ([]KVItem, int64, error) {
	q, _ := json.Marshal(map[string]any{"prefix": prefix, "after": after, "limit": limit})
	r, err := g.Pool.Query(ctx, "/prefix", q, height, false)
	if err != nil {
		return nil, 0, err
	}
	var items []KVItem
	if err := json.Unmarshal(r.Response.Value, &items); err != nil {
		return nil, 0, err
	}
	return items, r.Response.Height, nil
}

func (g *Gateway) hRecord(w http.ResponseWriter, r *http.Request) {
	key := r.URL.Query().Get("key")
	if key == "" {
		fail(w, 400, "key required")
		return
	}
	h, _ := strconv.ParseInt(r.URL.Query().Get("height"), 10, 64)
	resp, err := g.getRecord(r.Context(), key, h, r.URL.Query().Get("prove") == "1")
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	ok(w, resp)
}

func (g *Gateway) hRecordKind(w http.ResponseWriter, r *http.Request) {
	pfx, found := kindPrefix[r.PathValue("kind")]
	if !found {
		fail(w, 404, "unknown kind")
		return
	}
	h, _ := strconv.ParseInt(r.URL.Query().Get("height"), 10, 64)
	resp, err := g.getRecord(r.Context(), pfx+r.PathValue("id"), h, r.URL.Query().Get("prove") == "1")
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	ok(w, resp)
}

func (g *Gateway) hScan(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	limit, _ := strconv.Atoi(q.Get("limit"))
	if limit <= 0 || limit > 1000 {
		limit = 200
	}
	h, _ := strconv.ParseInt(q.Get("height"), 10, 64)
	items, height, err := g.scan(r.Context(), q.Get("prefix"), q.Get("after"), limit, h)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	next := ""
	if len(items) == limit {
		next = items[len(items)-1].Key
	}
	ok(w, map[string]any{"height": height, "items": items, "next_after": next})
}

func (g *Gateway) hChainInventory(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	sku, loc := q.Get("sku"), q.Get("location")
	h, _ := strconv.ParseInt(q.Get("height"), 10, 64)
	prefix := core.KBalance
	if sku != "" {
		prefix += sku + "/"
	}
	var rows, transit []map[string]any
	after := ""
	var height int64
	for page := 0; page < 20; page++ {
		items, hh, err := g.scan(r.Context(), prefix, after, 500, h)
		if err != nil {
			fail(w, 502, err.Error())
			return
		}
		height = hh
		h = hh // pin subsequent pages to the same finalised height
		for _, it := range items {
			var b core.Balance
			json.Unmarshal(it.Value, &b)
			row := map[string]any{"sku": b.SKU, "loc": b.Loc, "available": b.Available, "reserved": b.Reserved, "quarantined": b.Quarantined,
				"damaged": b.Damaged, "on_hand": b.OnHand(), "version": b.Version}
			switch {
			case strings.HasPrefix(b.Loc, "EXT:"):
			case strings.HasPrefix(b.Loc, core.TransitPfx):
				if b.OnHand() != 0 {
					transit = append(transit, row)
				}
			default:
				if loc == "" || b.Loc == loc {
					rows = append(rows, row)
				}
			}
			after = it.Key
		}
		if len(items) < 500 {
			break
		}
	}
	ok(w, map[string]any{"height": height, "balances": rows, "in_transit": transit})
}

func (g *Gateway) hDigest(w http.ResponseWriter, r *http.Request) {
	h, _ := strconv.ParseInt(r.URL.Query().Get("height"), 10, 64)
	d, err := g.chainDigest(r.Context(), h)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	ok(w, d)
}

type Digest struct {
	Height  int64  `json:"height"`
	AppHash string `json:"app_hash"`
	Digest  string `json:"digest"`
	Entries int64  `json:"entries"`
}

func (g *Gateway) chainDigest(ctx context.Context, h int64) (*Digest, error) {
	r, err := g.Pool.Query(ctx, "/digest", nil, h, false)
	if err != nil {
		return nil, err
	}
	var d Digest
	json.Unmarshal(r.Response.Value, &d)
	return &d, nil
}

func (g *Gateway) hChainInfo(w http.ResponseWriter, r *http.Request) {
	q, err := g.Pool.Query(r.Context(), "/info", nil, 0, false)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(q.Response.Value)
}

func (g *Gateway) hChainMigration(w http.ResponseWriter, r *http.Request) {
	resp, err := g.getRecord(r.Context(), core.KMigState, 0, false)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	ok(w, resp)
}

// ---- Network ----

type ValidatorView struct {
	Name           string `json:"name"`
	Org            string `json:"org"`
	Role           string `json:"role"`
	NodeID         string `json:"node_id"`
	RPCURL         string `json:"rpc_url"`
	Reachable      bool   `json:"reachable"`
	Height         int64  `json:"height"`
	CatchingUp     bool   `json:"catching_up"`
	Peers          int    `json:"peers"`
	LatencyMs      int64  `json:"latency_ms"`
	VotingPower    int64  `json:"voting_power"`
	PubKey         string `json:"consensus_pubkey"`
	AppHash        string `json:"app_hash"`
	Agrees         bool   `json:"agrees_with_majority"`
	LastSigned     int64  `json:"last_signed_height"`
	InValidatorSet bool   `json:"in_validator_set"`
}

func (g *Gateway) networkView(ctx context.Context) map[string]any {
	views := make([]ValidatorView, len(g.Net.Nodes))
	var wg sync.WaitGroup
	for i, n := range g.Net.Nodes {
		views[i] = ValidatorView{Name: n.Name, Org: n.Org, Role: n.Role, NodeID: n.NodeID, RPCURL: n.RPCURL, PubKey: n.PubKey}
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			c := g.Pool.Client(i)
			cx, cancel := context.WithTimeout(ctx, 3*time.Second)
			defer cancel()
			t0 := time.Now()
			st, err := c.Status(cx)
			if err != nil {
				return
			}
			v := &views[i]
			v.Reachable, v.LatencyMs = true, time.Since(t0).Milliseconds()
			v.Height, v.CatchingUp = st.SyncInfo.LatestBlockHeight, st.SyncInfo.CatchingUp
			v.AppHash = strings.ToUpper(hex.EncodeToString(st.SyncInfo.LatestAppHash))
			v.VotingPower = st.ValidatorInfo.VotingPower
			v.InValidatorSet = st.ValidatorInfo.VotingPower > 0
			if ni, err := c.NetInfo(cx); err == nil {
				v.Peers = ni.NPeers
			}
		}(i)
	}
	wg.Wait()
	// head & majority
	var head int64
	hashes := map[string]int{}
	for _, v := range views {
		if v.Reachable && v.Height > head {
			head = v.Height
		}
	}
	for _, v := range views {
		if v.Reachable && v.Height == head {
			hashes[v.AppHash]++
		}
	}
	maj, best := "", 0
	for h, c := range hashes {
		if c > best || (c == best && h < maj) {
			maj, best = h, c
		}
	}
	// validator set at head from any reachable node
	var total int64
	powers := map[string]int64{}
	for i := range views {
		if views[i].Reachable {
			cx, cancel := context.WithTimeout(ctx, 3*time.Second)
			vs, err := g.Pool.Client(i).Validators(cx, nil, nil, nil)
			cancel()
			if err == nil {
				for _, v := range vs.Validators {
					powers[base64.StdEncoding.EncodeToString(v.PubKey.Bytes())] = v.VotingPower
					total += v.VotingPower
				}
				break
			}
		}
	}
	var online int64
	nVals := 0
	for i := range views {
		v := &views[i]
		v.Agrees = v.Reachable && v.Height == head && v.AppHash == maj
		if p, okp := powers[v.PubKey]; okp {
			v.VotingPower, v.InValidatorSet = p, true
			nVals++
			if v.Reachable && !v.CatchingUp && head-v.Height <= 2 {
				online += p
			}
		}
	}
	// last signed height (from latest commit)
	if head > 0 {
		for i := range views {
			if views[i].Reachable {
				if cm, err := g.Pool.Client(i).Commit(ctx, &head); err == nil {
					signed := map[string]bool{}
					for _, s := range cm.Commit.Signatures {
						if s.BlockIDFlag == types.BlockIDFlagCommit {
							signed[strings.ToUpper(hex.EncodeToString(s.ValidatorAddress))] = true
						}
					}
					for j := range views {
						if pk, err := base64.StdEncoding.DecodeString(views[j].PubKey); err == nil && len(pk) == 32 {
							addr := strings.ToUpper(hex.EncodeToString(addressOf(pk)))
							if signed[addr] {
								views[j].LastSigned = head
							}
						}
					}
					break
				}
			}
		}
	}
	f := (nVals - 1) / 3
	need := total*2/3 + 1
	status, expl := "HEALTHY", "All validators are online and agree on the finalised state."
	switch {
	case total == 0 || online*3 <= total*2:
		status, expl = "HALTED", fmt.Sprintf("Online voting power %d of %d is not more than 2/3: no new block can be finalised. Transactions wait in mempools; nothing forks. Restoring a validator resumes the chain.", online, total)
	case online < total:
		status, expl = "DEGRADED", fmt.Sprintf("%d of %d voting power online (needs > 2/3 = %d). The chain still finalises; one more failure may halt it.", online, total, need)
	}
	app := map[string]any{}
	if q, err := g.Pool.Query(ctx, "/info", nil, 0, false); err == nil {
		json.Unmarshal(q.Response.Value, &app)
	}
	mem := 0
	for i := range views {
		if views[i].Reachable {
			if u, err := g.Pool.Client(i).NumUnconfirmedTxs(ctx); err == nil {
				mem = u.Total
			}
			break
		}
	}
	chain := map[string]any{"latest_height": head, "latest_app_hash": maj}
	if g.Proj != nil {
		var first, last, cnt int64
		row := g.Proj.db.QueryRow(`SELECT MIN(time_ms), MAX(time_ms), COUNT(*) FROM (SELECT time_ms FROM blocks ORDER BY height DESC LIMIT 20)`)
		if row.Scan(&first, &last, &cnt) == nil && cnt > 1 {
			chain["block_interval_ms_avg"] = (last - first) / (cnt - 1)
		}
	}
	if st, err := g.Pool.Status(ctx); err == nil {
		chain["latest_block_time"] = st.SyncInfo.LatestBlockTime
	}
	members := []core.Member{}
	if items, _, err := g.scan(ctx, core.KMember, "", 100, 0); err == nil {
		for _, it := range items {
			var m core.Member
			json.Unmarshal(it.Value, &m)
			members = append(members, m)
		}
	}
	return map[string]any{
		"network_id": g.Net.NetworkID, "app_version": app["app_version"], "chain": chain,
		"bft": map[string]any{"validators": nVals, "voting_power_total": total, "f": f, "quorum_power_required": need, "online_power": online,
			"online_validators": countOnline(views), "status": status, "explanation": expl,
			"tolerance": fmt.Sprintf("n=%d validators tolerate f=%d Byzantine/failed (n >= 3f+1). Finality needs > 2/3 of voting power.", nVals, f)},
		"validators": views, "members": members, "mempool": map[string]any{"unconfirmed_txs": mem}, "queried_at": time.Now().UTC(),
	}
}

func countOnline(v []ValidatorView) int {
	n := 0
	for _, x := range v {
		if x.Reachable && !x.CatchingUp {
			n++
		}
	}
	return n
}

func addressOf(pub []byte) []byte {
	h := sha256.Sum256(pub)
	return h[:20]
}

func (g *Gateway) hNetwork(w http.ResponseWriter, r *http.Request) { ok(w, g.networkView(r.Context())) }

// ---- Explorer ----

func (g *Gateway) valNames(ctx context.Context) map[string]string {
	out := map[string]string{}
	for _, n := range g.Net.Nodes {
		pk, err := base64.StdEncoding.DecodeString(n.PubKey)
		if err == nil && len(pk) == 32 {
			out[strings.ToUpper(hex.EncodeToString(addressOf(pk)))] = n.Name
		}
	}
	return out
}

func (g *Gateway) hBlock(w http.ResponseWriter, r *http.Request) {
	h, err := strconv.ParseInt(r.PathValue("height"), 10, 64)
	if err != nil || h < 1 {
		fail(w, 400, "bad height")
		return
	}
	ctx := r.Context()
	var blk *coretypesBlock
	var cm *coretypesCommit
	err = g.Pool.Do(func(c *rpchttp.HTTP) error {
		b, e := c.Block(ctx, &h)
		if e != nil {
			return e
		}
		blk = b
		cc, e := c.Commit(ctx, &h)
		if e != nil {
			return e
		}
		cm = cc
		return nil
	})
	if err != nil {
		fail(w, 404, err.Error())
		return
	}
	var br *coretypesBlockResults
	g.Pool.Do(func(c *rpchttp.HTTP) (e error) { br, e = c.BlockResults(ctx, &h); return })
	names := g.valNames(ctx)
	var txs []map[string]any
	for i, raw := range blk.Block.Data.Txs {
		t := map[string]any{"index": i, "hash": strings.ToUpper(hex.EncodeToString(types.Tx(raw).Hash())), "size": len(raw)}
		if d, e := core.DecodeStateless(raw, g.Net.NetworkID, core.DefaultParams()); e == nil {
			t["tx_id"], t["type"], t["signer"] = d.Body.TxID, d.Body.Type, d.Body.Signer
		} else {
			t["decode_error"] = e.Error()
		}
		if br != nil && i < len(br.TxsResults) {
			rs := br.TxsResults[i]
			t["code"], t["code_name"], t["log"] = rs.Code, core.CodeName(rs.Code), rs.Log
		}
		txs = append(txs, t)
	}
	var sigs []map[string]any
	var signedPower, totalPower int64
	valpow := map[string]int64{}
	if vs, e := g.valsAt(ctx, h); e == nil {
		for _, v := range vs {
			valpow[strings.ToUpper(hex.EncodeToString(v.Address))] = v.VotingPower
			totalPower += v.VotingPower
		}
	}
	for _, s := range cm.Commit.Signatures {
		addr := strings.ToUpper(hex.EncodeToString(s.ValidatorAddress))
		signed := s.BlockIDFlag == types.BlockIDFlagCommit
		if signed {
			signedPower += valpow[addr]
		}
		if len(s.ValidatorAddress) == 0 {
			continue
		}
		sigs = append(sigs, map[string]any{"validator": addr, "validator_name": names[addr], "signed": signed, "power": valpow[addr]})
	}
	vf := false
	if _, e := g.light.Verify(ctx, h); e == nil {
		vf = true
	}
	appHash := ""
	if br != nil {
		appHash = strings.ToUpper(hex.EncodeToString(br.AppHash))
	}
	ok(w, map[string]any{
		"height": h, "time": blk.Block.Time, "hash": strings.ToUpper(hex.EncodeToString(blk.BlockID.Hash)), "chain_id": blk.Block.ChainID,
		"proposer": names[strings.ToUpper(hex.EncodeToString(blk.Block.ProposerAddress))], "proposer_address": strings.ToUpper(hex.EncodeToString(blk.Block.ProposerAddress)),
		"header_app_hash": strings.ToUpper(hex.EncodeToString(blk.Block.AppHash)), "state_app_hash_after_block": appHash,
		"validators_hash": strings.ToUpper(hex.EncodeToString(blk.Block.ValidatorsHash)), "data_hash": strings.ToUpper(hex.EncodeToString(blk.Block.DataHash)),
		"app_version": blk.Block.Version.App, "txs": txs,
		"commit": map[string]any{"round": cm.Commit.Round, "signatures": sigs, "signed_power": signedPower, "total_power": totalPower, "finality_verified": vf},
	})
}

func (g *Gateway) valsAt(ctx context.Context, h int64) ([]*types.Validator, error) {
	var vs *coretypesValidators
	err := g.Pool.Do(func(c *rpchttp.HTTP) (e error) { vs, e = c.Validators(ctx, &h, nil, nil); return })
	if err != nil {
		return nil, err
	}
	return vs.Validators, nil
}

func (g *Gateway) hVerifyFinality(w http.ResponseWriter, r *http.Request) {
	h, err := strconv.ParseInt(r.URL.Query().Get("height"), 10, 64)
	if err != nil || h < 1 {
		fail(w, 400, "height required")
		return
	}
	ctx := r.Context()
	lb, err := g.light.Verify(ctx, h)
	res := map[string]any{"height": h, "method": "CometBFT light client (skipping verification), trust root = genesis validator set hash; witnesses = the other validators"}
	if err != nil {
		res["verified"], res["error"] = false, err.Error()
		ok(w, res)
		return
	}
	names := g.valNames(ctx)
	var signed []string
	var signedPower int64
	powers := map[string]int64{}
	for _, v := range lb.ValidatorSet.Validators {
		powers[strings.ToUpper(hex.EncodeToString(v.Address))] = v.VotingPower
	}
	for _, s := range lb.SignedHeader.Commit.Signatures {
		if s.BlockIDFlag == types.BlockIDFlagCommit {
			a := strings.ToUpper(hex.EncodeToString(s.ValidatorAddress))
			signed = append(signed, names[a])
			signedPower += powers[a]
		}
	}
	sort.Strings(signed)
	total := lb.ValidatorSet.TotalVotingPower()
	res["verified"] = true
	res["signed_power"], res["total_power"], res["quorum_required"] = signedPower, total, total*2/3+1
	res["validators_signed"] = signed
	res["block_hash"] = strings.ToUpper(hex.EncodeToString(lb.Hash()))
	res["header_app_hash"] = strings.ToUpper(hex.EncodeToString(lb.SignedHeader.AppHash))
	res["note"] = "header_app_hash at height H commits the state produced by block H-1; a Merkle proof for state at height H-1 verifies against it."
	ok(w, res)
}

func (g *Gateway) hExplorerProof(w http.ResponseWriter, r *http.Request) {
	key := r.URL.Query().Get("key")
	h, _ := strconv.ParseInt(r.URL.Query().Get("height"), 10, 64)
	resp, err := g.getRecord(r.Context(), key, h, true)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	steps := []string{
		fmt.Sprintf("1. A validator returned the value of %q in the application state committed at height %d, with an ICS23 (IAVL) Merkle proof.", key, resp.Height),
		fmt.Sprintf("2. The root of that state is the app_hash in block header %d (state after block N appears in header N+1).", resp.Height+1),
		"3. The gateway verified header " + strconv.FormatInt(resp.Height+1, 10) + " with the CometBFT light client: more than 2/3 of validator voting power signed it, starting from the genesis validator set.",
		"4. The proof was checked against that root: the leaf (key, value) hashes up to the root through the proof path.",
		"5. What this establishes: this exact key/value is part of the finalised state. What it does NOT establish: that the business fact is true in the real world, or that any list/search result is complete (absence is only proven by an explicit non-membership proof).",
	}
	ok(w, map[string]any{"record": resp, "explanation": steps})
}

func (g *Gateway) hExplorerTx(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	ctx := r.Context()
	out := map[string]any{}
	var hash []byte
	if b, err := hex.DecodeString(id); err == nil && len(b) == 32 {
		hash = b
	} else {
		rec, err := g.getRecord(ctx, core.KTx+id, 0, false)
		if err != nil || !rec.Found {
			fail(w, 404, "transaction not found")
			return
		}
		var tr core.TxRecord
		json.Unmarshal(rec.Value, &tr)
		out["record"] = tr
		// locate raw tx in block
		var blk *coretypesBlock
		g.Pool.Do(func(c *rpchttp.HTTP) (e error) { blk, e = c.Block(ctx, &tr.Height); return })
		if blk != nil && tr.Index < len(blk.Block.Data.Txs) {
			hash = types.Tx(blk.Block.Data.Txs[tr.Index]).Hash()
		}
	}
	if hash != nil {
		var tx *coretypesTx
		prove := r.URL.Query().Get("include_proof") == "1"
		if err := g.Pool.Do(func(c *rpchttp.HTTP) (e error) { tx, e = c.Tx(ctx, hash, prove); return }); err != nil {
			fail(w, 404, "transaction not found")
			return
		}
		out["hash"] = strings.ToUpper(hex.EncodeToString(hash))
		out["height"], out["index"] = tx.Height, tx.Index
		out["result"] = map[string]any{"code": tx.TxResult.Code, "code_name": core.CodeName(tx.TxResult.Code), "log": tx.TxResult.Log, "data": json.RawMessage(nonEmpty(tx.TxResult.Data))}
		if d, e := core.DecodeStateless(tx.Tx, g.Net.NetworkID, core.DefaultParams()); e == nil {
			var payload any
			json.Unmarshal(d.Body.Payload, &payload)
			b := d.Body
			out["body"] = map[string]any{"tx_id": b.TxID, "network_id": b.NetworkID, "type": b.Type, "schema_version": b.SchemaVersion, "signer": b.Signer, "key_id": b.KeyID,
				"idempotency_ref": b.Idempotency, "expected_version": b.ExpectedVersion, "client_time_ms": b.ClientTimeMs, "payload": payload}
			out["signature_check"] = map[string]any{"valid": true, "public_key": d.Env.Pub, "note": "cryptographic validity only; authorisation is a separate on-chain check"}
		}
		var events []map[string]string
		for _, ev := range tx.TxResult.Events {
			if ev.Type == "aureom.w" || ev.Type == "aureom.d" {
				m := map[string]string{"op": map[string]string{"aureom.w": "write", "aureom.d": "delete"}[ev.Type]}
				for _, a := range ev.Attributes {
					if a.Key == "key" {
						m["key"] = a.Value
					}
				}
				events = append(events, m)
			}
		}
		out["records_changed"] = events
		if prove && tx.Proof.Proof.Total > 0 {
			out["inclusion_proof"] = map[string]any{"root_hash": strings.ToUpper(hex.EncodeToString(tx.Proof.RootHash)), "total": tx.Proof.Proof.Total, "index": tx.Proof.Proof.Index,
				"note": "Merkle proof that the tx is in the block whose header data_hash equals root_hash"}
		}
	}
	ok(w, out)
}

func nonEmpty(b []byte) []byte {
	if len(b) == 0 {
		return []byte("null")
	}
	return b
}

func (g *Gateway) hSearch(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	res := []map[string]any{}
	if h, err := strconv.ParseInt(q, 10, 64); err == nil {
		res = append(res, map[string]any{"type": "block", "ref": h})
	}
	if strings.Contains(q, "/") {
		res = append(res, map[string]any{"type": "record", "ref": q})
	}
	if strings.HasPrefix(q, "tx-") || len(q) == 64 {
		res = append(res, map[string]any{"type": "tx", "ref": q})
	}
	ok(w, map[string]any{"query": q, "results": res})
}

func hexUp(b []byte) string { return strings.ToUpper(hex.EncodeToString(b)) }
