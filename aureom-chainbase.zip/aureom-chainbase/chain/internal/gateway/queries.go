package gateway

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/aureom/chainbase/internal/core"
)

// ---- helpers ----

type where struct {
	cl   []string
	args []any
}

func (w *where) add(cond string, args ...any) {
	w.cl = append(w.cl, cond)
	w.args = append(w.args, args...)
}
func (w *where) sql() string {
	if len(w.cl) == 0 {
		return ""
	}
	return " WHERE " + strings.Join(w.cl, " AND ")
}

func pageOf(r *http.Request) (int, int) {
	l, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	o, _ := strconv.Atoi(r.URL.Query().Get("offset"))
	if l <= 0 {
		l = 50
	}
	if l > 500 {
		l = 500
	}
	if o < 0 {
		o = 0
	}
	return l, o
}

// pq wraps a projection handler with read-after-write (min_height / wait_ms).
func (g *Gateway) pq(h func(w http.ResponseWriter, r *http.Request)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if mh, _ := strconv.ParseInt(r.URL.Query().Get("min_height"), 10, 64); mh > 0 {
			wm, _ := strconv.Atoi(r.URL.Query().Get("wait_ms"))
			if wm <= 0 || wm > 30000 {
				wm = 5000
			}
			ctx, cancel := context.WithTimeout(r.Context(), time.Duration(wm)*time.Millisecond)
			g.Proj.WaitFor(ctx, mh)
			cancel()
		}
		h(w, r)
	}
}

func (g *Gateway) list(w http.ResponseWriter, items any, total int) {
	ok(w, map[string]any{"meta": g.Proj.Meta(), "items": items, "total": total})
}
func (g *Gateway) one(w http.ResponseWriter, item any) {
	ok(w, map[string]any{"meta": g.Proj.Meta(), "item": item})
}

// jsonRows runs a query whose first column is a JSON document; extra columns are merged in as fields.
func (p *Projection) jsonRows(ctx context.Context, q string, args ...any) ([]map[string]any, error) {
	rows, err := p.db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	cols, _ := rows.Columns()
	out := []map[string]any{}
	for rows.Next() {
		vals := make([]any, len(cols))
		ptrs := make([]any, len(cols))
		for i := range vals {
			ptrs[i] = &vals[i]
		}
		if err := rows.Scan(ptrs...); err != nil {
			return nil, err
		}
		item := map[string]any{}
		for i, c := range cols {
			v := vals[i]
			if b, isB := v.([]byte); isB {
				v = string(b)
			}
			if c == "json" {
				if s, isS := v.(string); isS {
					var m map[string]any
					if json.Unmarshal([]byte(s), &m) == nil {
						for k, x := range m {
							item[k] = x
						}
					}
				}
				continue
			}
			item[c] = v
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func (p *Projection) count(ctx context.Context, q string, args ...any) int {
	var n int
	p.db.QueryRowContext(ctx, q, args...).Scan(&n)
	return n
}

func (g *Gateway) dberr(w http.ResponseWriter, err error) bool {
	if err != nil {
		fail(w, 500, err.Error())
		return true
	}
	return false
}

// recList serves a rec-kind listing with simple JSON-field filters.
func (g *Gateway) recList(kind string, filters map[string]string, order string) http.HandlerFunc {
	return g.pq(func(w http.ResponseWriter, r *http.Request) {
		wh := &where{}
		wh.add("kind=?", kind)
		for param, path := range filters {
			v := r.URL.Query().Get(param)
			if v == "" {
				continue
			}
			switch {
			case path == "$.scarce": // JSON booleans are 1/0 in SQLite
				b := 0
				if v == "true" || v == "1" {
					b = 1
				}
				wh.add("json_extract(json,'$.scarce')=?", b)
			case strings.HasPrefix(path, "lines[]."): // any line of the record matches (po, receipt, transfer lines)
				wh.add("EXISTS (SELECT 1 FROM json_each(rec.json,'$.lines') WHERE json_extract(value,'$."+strings.TrimPrefix(path, "lines[].")+"')=?)", v)
			default:
				wh.add("json_extract(json,'"+path+"')=?", v)
			}
		}
		l, o := pageOf(r)
		items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec`+wh.sql()+` ORDER BY `+order+` LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
		if g.dberr(w, err) {
			return
		}
		g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM rec`+wh.sql(), wh.args...))
	})
}

func (g *Gateway) registerQueries(mux *http.ServeMux) {
	q := "/api/v1/q/"
	mux.HandleFunc("GET "+q+"products", g.pq(g.qProducts))
	mux.HandleFunc("GET "+q+"products/{id}", g.pq(g.qProduct))
	mux.HandleFunc("GET "+q+"skus", g.recList("sku", map[string]string{"product": "$.product_id", "scarce": "$.scarce"}, "id"))
	mux.HandleFunc("GET "+q+"locations", g.recList("location", map[string]string{"kind": "$.kind", "region": "$.region"}, "id"))
	mux.HandleFunc("GET "+q+"suppliers", g.recList("supplier", map[string]string{}, "id"))
	mux.HandleFunc("GET "+q+"inventory", g.pq(g.qInventory))
	mux.HandleFunc("GET "+q+"inventory/exceptions", g.pq(g.qInvExceptions))
	mux.HandleFunc("GET "+q+"movements", g.pq(g.qMovements))
	mux.HandleFunc("GET "+q+"purchase-orders", g.recList("po", map[string]string{"status": "$.status", "supplier": "$.supplier_id", "location": "$.location_id", "sku": "lines[].sku"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"receipts", g.recList("receipt", map[string]string{"location": "$.location_id", "po": "$.po_id", "supplier": "$.supplier_id", "sku": "lines[].sku"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"transfers", g.recList("transfer", map[string]string{"status": "$.status", "from": "$.from", "to": "$.to", "sku": "lines[].sku"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"adjustments", g.recList("adjustment", map[string]string{"status": "$.status", "location": "$.loc", "sku": "$.sku"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"reservations", g.recList("reservation", map[string]string{"status": "$.status", "location": "$.loc", "sku": "$.sku"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"returns", g.recList("return", map[string]string{"status": "$.status", "sale": "$.sale_id"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"refunds", g.recList("refund", map[string]string{"status": "$.status", "sale": "$.sale_id"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"prices", g.recList("price", map[string]string{"sku": "$.sku", "location": "$.loc"}, "json_extract(json,'$.effective_from_ms') DESC, id"))
	mux.HandleFunc("GET "+q+"promotions", g.recList("promotion", map[string]string{"status": "$.status"}, "json_extract(json,'$.priority'), id"))
	mux.HandleFunc("GET "+q+"exceptions", g.recList("exception", map[string]string{"status": "$.status", "kind": "$.kind"}, "updated_h DESC, id"))
	mux.HandleFunc("GET "+q+"sales", g.pq(g.qSales))
	mux.HandleFunc("GET "+q+"sales/summary", g.pq(g.qSalesSummary))
	mux.HandleFunc("GET "+q+"sales/{id}", g.pq(g.qSale))
	mux.HandleFunc("GET "+q+"loyalty/accounts", g.pq(g.qLoyaltyAccounts))
	mux.HandleFunc("GET "+q+"loyalty/accounts/{id}", g.pq(g.qLoyaltyAccount))
	mux.HandleFunc("GET "+q+"transactions", g.pq(g.qTransactions))
	mux.HandleFunc("GET "+q+"history", g.pq(g.qHistory))
	mux.HandleFunc("GET "+q+"identities", g.pq(g.qIdentities))
	mux.HandleFunc("GET "+q+"governance", g.pq(g.qGovernance))
	mux.HandleFunc("GET "+q+"migration", g.pq(g.qMigration))
	mux.HandleFunc("GET "+q+"stats", g.pq(g.qStats))
}

// ---- products ----

func (g *Gateway) qProducts(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	wh.add("kind='product'")
	qs := r.URL.Query()
	if v := qs.Get("q"); v != "" {
		like := "%" + v + "%"
		wh.add(`(json_extract(json,'$.name') LIKE ? OR json_extract(json,'$.brand') LIKE ? OR id LIKE ? OR EXISTS (SELECT 1 FROM rec s WHERE s.kind='sku' AND json_extract(s.json,'$.product_id')=rec.id AND (s.id LIKE ? OR json_extract(s.json,'$.barcode') LIKE ?)))`, like, like, like, like, like)
	}
	if v := qs.Get("category"); v != "" {
		wh.add("json_extract(json,'$.category')=?", v)
	}
	if v := qs.Get("status"); v != "" {
		wh.add("json_extract(json,'$.status')=?", v)
	}
	l, o := pageOf(r)
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec`+wh.sql()+` ORDER BY json_extract(json,'$.name'), id LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	for _, it := range items {
		skus, _ := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='sku' AND json_extract(json,'$.product_id')=? ORDER BY id`, it["id"])
		it["sku_details"] = skus
	}
	g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM rec`+wh.sql(), wh.args...))
}

func (g *Gateway) qProduct(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='product' AND id=?`, id)
	if g.dberr(w, err) {
		return
	}
	if len(items) == 0 {
		fail(w, 404, "product not found")
		return
	}
	it := items[0]
	it["sku_details"], _ = g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='sku' AND json_extract(json,'$.product_id')=? ORDER BY id`, id)
	it["price_history"], _ = g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='price' AND json_extract(json,'$.sku') IN (SELECT id FROM rec WHERE kind='sku' AND json_extract(json,'$.product_id')=?) ORDER BY json_extract(json,'$.effective_from_ms') DESC, id`, id)
	it["versions"] = g.history(r.Context(), core.KProduct+id)
	g.one(w, it)
}

// ---- inventory ----

func (g *Gateway) qInventory(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	wh.add("b.loc NOT LIKE 'EXT:%' AND b.loc NOT LIKE 'TRANSIT:%'")
	qs := r.URL.Query()
	if v := qs.Get("sku"); v != "" {
		wh.add("b.sku=?", v)
	}
	if v := qs.Get("location"); v != "" {
		wh.add("b.loc=?", v)
	}
	if v := qs.Get("low_stock"); v != "" {
		n, _ := strconv.Atoi(v)
		wh.add("b.available <= ?", n)
	}
	transit := func(side string) string {
		return `COALESCE((SELECT SUM(t.available) FROM bal t JOIN rec x ON x.kind='transfer' AND x.id=substr(t.loc,9) WHERE t.sku=b.sku AND t.loc LIKE 'TRANSIT:%' AND json_extract(x.json,'$.` + side + `')=b.loc AND json_extract(x.json,'$.status')!='RECEIVED'),0)`
	}
	l, o := pageOf(r)
	base := ` FROM bal b LEFT JOIN rec sk ON sk.kind='sku' AND sk.id=b.sku LEFT JOIN rec pr ON pr.kind='product' AND pr.id=json_extract(sk.json,'$.product_id') LEFT JOIN rec lc ON lc.kind='location' AND lc.id=b.loc`
	q := `SELECT b.sku AS sku, b.loc AS loc, b.available AS available, b.reserved AS reserved, b.quarantined AS quarantined, b.damaged AS damaged,
	  (b.available+b.reserved+b.quarantined+b.damaged) AS on_hand, b.version AS version, json_extract(sk.json,'$.product_id') AS product_id,
	  json_extract(pr.json,'$.name') AS product_name, json_extract(sk.json,'$.unit') AS unit, json_extract(sk.json,'$.scarce') AS scarce,
	  json_extract(lc.json,'$.name') AS location_name, ` + transit("to") + ` AS in_transit_in, ` + transit("from") + ` AS in_transit_out` + base + wh.sql() + ` ORDER BY b.sku, b.loc LIMIT ? OFFSET ?`
	items, err := g.Proj.jsonRows(r.Context(), q, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*)`+base+wh.sql(), wh.args...))
}

func (g *Gateway) qInvExceptions(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	out := []map[string]any{}
	add := func(kind, sev, ref, detail, loc, sku string) {
		out = append(out, map[string]any{"kind": kind, "severity": sev, "ref": ref, "detail": detail, "location": loc, "sku": sku})
	}
	excs, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='exception' AND json_extract(json,'$.status')='OPEN' ORDER BY updated_h DESC LIMIT 200`)
	for _, e := range excs {
		sev := "MEDIUM"
		k, _ := e["kind"].(string)
		if strings.Contains(k, "DISCREPANCY") || strings.Contains(k, "SHORTFALL") || strings.Contains(k, "FAILED") {
			sev = "HIGH"
		}
		add(k, sev, fmt.Sprint(e["id"]), fmt.Sprint(e["detail"]), "", "")
	}
	xf, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='transfer' AND json_extract(json,'$.status')='RECEIVED_WITH_DISCREPANCY'`)
	for _, t := range xf {
		add("TRANSFER_DISCREPANCY", "HIGH", fmt.Sprint(t["id"]), "units still in transit after receipt: needs approved adjustment (write-off) or recount", fmt.Sprint(t["to"]), "")
	}
	adj, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='adjustment' AND json_extract(json,'$.status')='PENDING'`)
	for _, a := range adj {
		add("ADJUSTMENT_AWAITING_APPROVAL", "LOW", fmt.Sprint(a["id"]), fmt.Sprintf("count differs from system by %v units", a["delta"]), fmt.Sprint(a["loc"]), fmt.Sprint(a["sku"]))
	}
	var lastMs int64
	g.Proj.db.QueryRow(`SELECT time_ms FROM blocks ORDER BY height DESC LIMIT 1`).Scan(&lastMs)
	res, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='reservation' AND json_extract(json,'$.status')='ACTIVE' AND json_extract(json,'$.expires_at_ms') < ?`, lastMs)
	for _, a := range res {
		add("RESERVATION_EXPIRED_NOT_RELEASED", "MEDIUM", fmt.Sprint(a["id"]), "reservation passed its expiry (block time) and is still holding stock; submit ReleaseReservation(EXPIRED)", fmt.Sprint(a["loc"]), fmt.Sprint(a["sku"]))
	}
	g.list(w, out, len(out))
}

func (g *Gateway) qMovements(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	qs := r.URL.Query()
	if v := qs.Get("sku"); v != "" {
		wh.add("sku=?", v)
	}
	if v := qs.Get("location"); v != "" {
		wh.add("(from_loc=? OR to_loc=?)", v, v)
	}
	if v := qs.Get("reason"); v != "" {
		wh.add("reason=?", v)
	}
	if v := qs.Get("ref_id"); v != "" {
		wh.add("ref_id=?", v)
	}
	l, o := pageOf(r)
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM mov`+wh.sql()+` ORDER BY seq DESC LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM mov`+wh.sql(), wh.args...))
}

// ---- sales ----

func (g *Gateway) qSales(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	qs := r.URL.Query()
	if v := qs.Get("from"); v != "" {
		wh.add("eff_ms >= ?", v)
	}
	if v := qs.Get("to"); v != "" {
		wh.add("eff_ms < ?", v)
	}
	for param, col := range map[string]string{"location": "loc", "payment_status": "pay_status", "customer": "customer", "channel": "channel", "origin": "origin"} {
		if v := qs.Get(param); v != "" {
			wh.add(col+"=?", v)
		}
	}
	l, o := pageOf(r)
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM sale`+wh.sql()+` ORDER BY eff_ms DESC, id LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM sale`+wh.sql(), wh.args...))
}

func (g *Gateway) qSale(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	ctx := r.Context()
	items, err := g.Proj.jsonRows(ctx, `SELECT json FROM sale WHERE id=?`, id)
	if g.dberr(w, err) {
		return
	}
	if len(items) == 0 {
		fail(w, 404, "sale not found")
		return
	}
	it := items[0]
	it["returns"], _ = g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='return' AND json_extract(json,'$.sale_id')=? ORDER BY id`, id)
	it["refunds"], _ = g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='refund' AND json_extract(json,'$.sale_id')=? ORDER BY id`, id)
	it["loyalty_entries"], _ = g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='loyalty_entry' AND json_extract(json,'$.sale_id')=? ORDER BY created_h, id`, id)
	it["movements"], _ = g.Proj.jsonRows(ctx, `SELECT json FROM mov WHERE ref_id=? ORDER BY seq`, id)
	g.one(w, it)
}

func (g *Gateway) qSalesSummary(w http.ResponseWriter, r *http.Request) {
	qs := r.URL.Query()
	wh := &where{}
	if v := qs.Get("from"); v != "" {
		wh.add("eff_ms >= ?", v)
	}
	if v := qs.Get("to"); v != "" {
		wh.add("eff_ms < ?", v)
	}
	bucket := `strftime('%Y-%m-%d', eff_ms/1000, 'unixepoch')`
	switch qs.Get("group") {
	case "location":
		bucket = "loc"
	case "channel":
		bucket = "channel"
	}
	rows, err := g.Proj.jsonRows(r.Context(), `SELECT `+bucket+` AS bucket, COUNT(*) AS sales, SUM(gross) AS gross_minor, SUM(discount) AS discount_minor, SUM(net) AS net_minor, SUM(paid) AS paid_minor, SUM(refund_conf) AS refunded_minor, SUM(refund_instr) AS refund_instructed_minor FROM sale`+wh.sql()+` GROUP BY bucket ORDER BY bucket`, wh.args...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, rows, len(rows))
}

// ---- loyalty ----

func (g *Gateway) qLoyaltyAccounts(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	wh.add("kind='loyalty'")
	if v := r.URL.Query().Get("q"); v != "" {
		wh.add("id LIKE ?", "%"+v+"%")
	}
	l, o := pageOf(r)
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec`+wh.sql()+` ORDER BY id LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, items, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM rec`+wh.sql(), wh.args...))
}

func (g *Gateway) qLoyaltyAccount(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	items, err := g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='loyalty' AND id=?`, id)
	if g.dberr(w, err) {
		return
	}
	if len(items) == 0 {
		fail(w, 404, "account not found")
		return
	}
	it := items[0]
	it["entries"], _ = g.Proj.jsonRows(r.Context(), `SELECT json FROM rec WHERE kind='loyalty_entry' AND json_extract(json,'$.account')=? ORDER BY created_h, id`, id)
	g.one(w, it)
}

// ---- transactions & audit ----

func (g *Gateway) qTransactions(w http.ResponseWriter, r *http.Request) {
	wh := &where{}
	qs := r.URL.Query()
	for param, col := range map[string]string{"type": "type", "signer": "signer", "status": "status", "code": "code", "tx_id": "tx_id"} {
		if v := qs.Get(param); v != "" {
			wh.add(col+"=?", v)
		}
	}
	if v := qs.Get("from_height"); v != "" {
		wh.add("height >= ?", v)
	}
	l, o := pageOf(r)
	rows, err := g.Proj.jsonRows(r.Context(), `SELECT height, idx AS index_in_block, tx_id, type, signer, status, code, code_name, reason, hash, block_time_ms, client_time_ms, authenticated FROM txlog`+wh.sql()+` ORDER BY height DESC, idx DESC LIMIT ? OFFSET ?`, append(wh.args, l, o)...)
	if g.dberr(w, err) {
		return
	}
	g.list(w, rows, g.Proj.count(r.Context(), `SELECT COUNT(*) FROM txlog`+wh.sql(), wh.args...))
}

func (g *Gateway) history(ctx context.Context, key string) []map[string]any {
	rows, err := g.Proj.db.QueryContext(ctx, `SELECT h.height, h.seq, h.tx_id, h.value, h.deleted, t.type, t.signer, t.block_time_ms FROM kv_hist h LEFT JOIN txlog t ON t.tx_id=h.tx_id AND t.height=h.height WHERE h.key=? ORDER BY h.height, h.seq`, key)
	out := []map[string]any{}
	if err != nil {
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var h, seq, del int64
		var txid, typ, signer sql.NullString
		var val []byte
		var bt sql.NullInt64
		rows.Scan(&h, &seq, &txid, &val, &del, &typ, &signer, &bt)
		it := map[string]any{"height": h, "tx_id": txid.String, "tx_type": typ.String, "signer": signer.String, "block_time_ms": bt.Int64, "deleted": del == 1}
		if txid.String == "genesis" {
			it["tx_type"] = "GENESIS"
		} else if txid.String == "block" {
			it["tx_type"] = "BLOCK_EXECUTION"
		}
		if len(val) > 0 {
			var v map[string]any
			if json.Unmarshal(val, &v) == nil {
				it["value"] = v
				it["version"] = v["version"]
			} else {
				it["value"] = string(val)
			}
		}
		out = append(out, it)
	}
	return out
}

func (g *Gateway) qHistory(w http.ResponseWriter, r *http.Request) {
	key := r.URL.Query().Get("key")
	if key == "" {
		if pfx, found := kindPrefix[r.URL.Query().Get("kind")]; found && r.URL.Query().Get("id") != "" {
			key = pfx + r.URL.Query().Get("id")
		}
	}
	if key == "" {
		fail(w, 400, "key or kind+id required")
		return
	}
	h := g.history(r.Context(), key)
	g.list(w, h, len(h))
}

// ---- administration ----

func (g *Gateway) qIdentities(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	ids, err := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='identity' ORDER BY id`)
	if g.dberr(w, err) {
		return
	}
	for _, it := range ids {
		gr, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='grants' AND id=?`, it["id"])
		if len(gr) > 0 {
			it["grants"] = gr[0]["grants"]
		} else {
			it["grants"] = []any{}
		}
	}
	g.list(w, ids, len(ids))
}

func (g *Gateway) qGovernance(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	members, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='member' ORDER BY id`)
	props, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='proposal' ORDER BY created_h DESC`)
	ups, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='upgrade' ORDER BY id`)
	var params json.RawMessage
	var pv []byte
	if g.Proj.db.QueryRow(`SELECT value FROM kv WHERE key=?`, core.KParams).Scan(&pv) == nil {
		params = pv
	}
	var appver string
	var av []byte
	if g.Proj.db.QueryRow(`SELECT value FROM kv WHERE key='meta/appver'`).Scan(&av) == nil {
		appver = string(av)
	}
	// time-ordered membership / key / role events from the audit history
	rows, err := g.Proj.db.QueryContext(ctx, `SELECT h.key, h.height, h.tx_id, h.value, t.signer, t.type, t.block_time_ms FROM kv_hist h LEFT JOIN txlog t ON t.tx_id=h.tx_id AND t.height=h.height WHERE h.height>0 AND (h.key LIKE 'gov/member/%' OR h.key LIKE 'gov/prop/%' OR h.key LIKE 'iam/id/%' OR h.key LIKE 'iam/grants/%' OR h.key LIKE 'gov/upgrade/%') ORDER BY h.height, h.seq`)
	events := []map[string]any{}
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var key, txid string
			var h int64
			var val []byte
			var signer, typ sql.NullString
			var bt sql.NullInt64
			rows.Scan(&key, &h, &txid, &val, &signer, &typ, &bt)
			events = append(events, map[string]any{"height": h, "tx_id": txid, "tx_type": typ.String, "signer": signer.String, "block_time_ms": bt.Int64, "key": key, "summary": govSummary(key, val)})
		}
	}
	g.one(w, map[string]any{"members": members, "proposals": props, "upgrades": ups, "params": params, "app_version": appver, "events": events})
}

func govSummary(key string, val []byte) string {
	var m map[string]any
	json.Unmarshal(val, &m)
	switch {
	case strings.HasPrefix(key, "gov/member/"):
		return fmt.Sprintf("member %v (%v) status %v power %v", m["id"], m["kind"], m["status"], m["power"])
	case strings.HasPrefix(key, "gov/prop/"):
		return fmt.Sprintf("proposal %v %v -> %v (activation height %v)", m["id"], m["kind"], m["status"], m["activation_height"])
	case strings.HasPrefix(key, "iam/id/"):
		var ks []string
		if keys, ok := m["keys"].([]any); ok {
			for _, k := range keys {
				if km, ok := k.(map[string]any); ok {
					ks = append(ks, fmt.Sprintf("%v:%v", km["key_id"], km["status"]))
				}
			}
		}
		return fmt.Sprintf("identity %v keys [%s]", m["id"], strings.Join(ks, ", "))
	case strings.HasPrefix(key, "iam/grants/"):
		return fmt.Sprintf("role grants of %v changed (%d grants)", m["identity"], len(asSlice(m["grants"])))
	case strings.HasPrefix(key, "gov/upgrade/"):
		return fmt.Sprintf("state machine v%v %v at height %v", m["version"], m["status"], m["activation_height"])
	}
	return key
}

func asSlice(v any) []any { s, _ := v.([]any); return s }

func (g *Gateway) qMigration(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	var st json.RawMessage
	var b []byte
	if g.Proj.db.QueryRow(`SELECT value FROM kv WHERE key=?`, core.KMigState).Scan(&b) == nil {
		st = b
	}
	batches, _ := g.Proj.jsonRows(ctx, `SELECT json FROM rec WHERE kind='migration_batch' ORDER BY updated_h, id`)
	g.one(w, map[string]any{"state": st, "batches": batches})
}

func (g *Gateway) qStats(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	p := g.Proj
	s := map[string]any{}
	s["products"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='product'`)
	s["skus"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='sku'`)
	s["locations"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='location'`)
	s["suppliers"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='supplier'`)
	s["sales_total"] = p.count(ctx, `SELECT COUNT(*) FROM sale`)
	s["sales_native"] = p.count(ctx, `SELECT COUNT(*) FROM sale WHERE origin='NATIVE'`)
	s["open_exceptions"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='exception' AND json_extract(json,'$.status')='OPEN'`)
	s["transactions_total"] = p.count(ctx, `SELECT COUNT(*) FROM txlog`)
	s["transactions_rejected"] = p.count(ctx, `SELECT COUNT(*) FROM txlog WHERE status='REJECTED'`)
	var lastMs int64
	p.db.QueryRow(`SELECT time_ms FROM blocks ORDER BY height DESC LIMIT 1`).Scan(&lastMs)
	s["transactions_rejected_24h"] = p.count(ctx, `SELECT COUNT(*) FROM txlog WHERE status='REJECTED' AND block_time_ms >= ?`, lastMs-86400000)
	s["active_reservations"] = p.count(ctx, `SELECT COUNT(*) FROM rec WHERE kind='reservation' AND json_extract(json,'$.status')='ACTIVE'`)
	var pts, units sql.NullInt64
	p.db.QueryRow(`SELECT SUM(json_extract(json,'$.points')) FROM rec WHERE kind='loyalty'`).Scan(&pts)
	p.db.QueryRow(`SELECT SUM(available+reserved+quarantined+damaged) FROM bal WHERE loc NOT LIKE 'EXT:%' AND loc NOT LIKE 'TRANSIT:%'`).Scan(&units)
	s["loyalty_points_outstanding"], s["units_on_hand"] = pts.Int64, units.Int64
	var net, refunded sql.NullInt64
	p.db.QueryRow(`SELECT SUM(net), SUM(refund_conf) FROM sale WHERE eff_ms >= ?`, lastMs-86400000).Scan(&net, &refunded)
	s["sales_net_minor_24h"], s["refunded_minor_24h"] = net.Int64, refunded.Int64
	s["sales_24h"] = p.count(ctx, `SELECT COUNT(*) FROM sale WHERE eff_ms >= ?`, lastMs-86400000)
	g.one(w, s)
}
