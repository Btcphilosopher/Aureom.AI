package gateway

import (
	"context"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	abci "github.com/cometbft/cometbft/abci/types"
	"github.com/cometbft/cometbft/types"
	_ "modernc.org/sqlite"

	"github.com/aureom/chainbase/internal/core"
)

// Projection is a DISPOSABLE read model. It holds no authority: every row is derived from
// finalised blocks (genesis state + per-transaction write events). Deleting the file and
// re-ingesting from height 1 reproduces it; /projection/verify compares it with the chain.

const schema = `
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value BLOB NOT NULL, height INTEGER NOT NULL) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS kv_hist(key TEXT NOT NULL, height INTEGER NOT NULL, seq INTEGER NOT NULL, tx_id TEXT, value BLOB, deleted INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(key,height,seq)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS blocks(height INTEGER PRIMARY KEY, time_ms INTEGER, hash TEXT, app_hash TEXT, proposer TEXT, num_txs INTEGER, num_rejected INTEGER, size INTEGER);
CREATE TABLE IF NOT EXISTS txlog(height INTEGER, idx INTEGER, tx_id TEXT, type TEXT, signer TEXT, status TEXT, code INTEGER, code_name TEXT, reason TEXT, hash TEXT, block_time_ms INTEGER, client_time_ms INTEGER, authenticated INTEGER, PRIMARY KEY(height,idx));
CREATE INDEX IF NOT EXISTS txlog_id ON txlog(tx_id);
CREATE INDEX IF NOT EXISTS txlog_type ON txlog(type);
CREATE INDEX IF NOT EXISTS txlog_signer ON txlog(signer);
CREATE INDEX IF NOT EXISTS txlog_status ON txlog(status);
CREATE TABLE IF NOT EXISTS rec(kind TEXT NOT NULL, id TEXT NOT NULL, key TEXT, json TEXT NOT NULL, created_h INTEGER, updated_h INTEGER, PRIMARY KEY(kind,id)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS sale(id TEXT PRIMARY KEY, loc TEXT, channel TEXT, customer TEXT, eff_ms INTEGER, block_time_ms INTEGER, gross INTEGER, discount INTEGER, net INTEGER, paid INTEGER, refund_instr INTEGER, refund_conf INTEGER, pay_status TEXT, ful_status TEXT, origin TEXT, json TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS sale_eff ON sale(eff_ms);
CREATE INDEX IF NOT EXISTS sale_loc ON sale(loc);
CREATE INDEX IF NOT EXISTS sale_cust ON sale(customer);
CREATE TABLE IF NOT EXISTS bal(sku TEXT, loc TEXT, available INTEGER, reserved INTEGER, quarantined INTEGER, damaged INTEGER, version INTEGER, PRIMARY KEY(sku,loc)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS bal_loc ON bal(loc);
CREATE TABLE IF NOT EXISTS mov(seq INTEGER PRIMARY KEY, sku TEXT, from_loc TEXT, to_loc TEXT, qty INTEGER, reason TEXT, ref_type TEXT, ref_id TEXT, height INTEGER, tx_id TEXT, eff_ms INTEGER, json TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS mov_sku ON mov(sku);
CREATE INDEX IF NOT EXISTS mov_from ON mov(from_loc);
CREATE INDEX IF NOT EXISTS mov_to ON mov(to_loc);
CREATE INDEX IF NOT EXISTS mov_ref ON mov(ref_id);
`

type RebuildInfo struct {
	StartedAt      time.Time  `json:"started_at"`
	FinishedAt     *time.Time `json:"finished_at"`
	BlocksReplayed int64      `json:"blocks_replayed"`
	DurationMs     int64      `json:"duration_ms"`
}

type Projection struct {
	g    *Gateway
	path string
	db   *sql.DB

	mu         sync.RWMutex
	indexed    int64
	head       int64
	state      string
	rebuild    RebuildInfo
	lastTime   int64
	notify     chan struct{}
	rebuildReq chan struct{}
	digestAt   int64
	digestVal  string
	digestN    int64
}

func OpenProjection(path string, g *Gateway) (*Projection, error) {
	p := &Projection{g: g, path: path, state: "EMPTY", notify: make(chan struct{}), rebuildReq: make(chan struct{}, 1)}
	if err := p.open(); err != nil {
		return nil, err
	}
	return p, nil
}

func (p *Projection) open() error {
	dsn := "file:" + p.path + "?_pragma=journal_mode(WAL)&_pragma=busy_timeout(5000)&_pragma=synchronous(OFF)"
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return err
	}
	db.SetMaxOpenConns(8)
	if _, err := db.Exec(schema); err != nil {
		return err
	}
	p.db = db
	var v string
	if err := db.QueryRow(`SELECT v FROM meta WHERE k='indexed_height'`).Scan(&v); err == nil {
		p.indexed, _ = strconv.ParseInt(v, 10, 64)
	} else {
		p.indexed = 0
	}
	if p.indexed > 0 {
		p.state = "OK"
	}
	return nil
}

func (p *Projection) IndexedHeight() int64 { p.mu.RLock(); defer p.mu.RUnlock(); return p.indexed }

func (p *Projection) Meta() map[string]any {
	p.mu.RLock()
	defer p.mu.RUnlock()
	lag := p.head - p.indexed
	if lag < 0 {
		lag = 0
	}
	return map[string]any{"indexed_height": p.indexed, "chain_head": p.head, "lag_blocks": lag, "projection_state": p.state}
}

// WaitFor blocks until the projection has indexed height h (read-after-write).
func (p *Projection) WaitFor(ctx context.Context, h int64) bool {
	for {
		p.mu.RLock()
		done, ch := p.indexed >= h, p.notify
		p.mu.RUnlock()
		if done {
			return true
		}
		select {
		case <-ch:
		case <-ctx.Done():
			return false
		case <-time.After(250 * time.Millisecond):
		}
	}
}

func (p *Projection) Run(ctx context.Context) {
	for ctx.Err() == nil {
		select {
		case <-p.rebuildReq:
			p.doRebuild()
		default:
		}
		st, err := p.g.Pool.Status(ctx)
		if err != nil {
			time.Sleep(time.Second)
			continue
		}
		head := st.SyncInfo.LatestBlockHeight
		p.mu.Lock()
		p.head = head
		if len(st.SyncInfo.LatestBlockTime.String()) > 0 {
			p.lastTime = st.SyncInfo.LatestBlockTime.UnixMilli()
		}
		cur := p.indexed
		p.mu.Unlock()
		if cur == 0 {
			if err := p.loadGenesis(ctx); err != nil {
				log.Printf("projection: genesis: %v", err)
				time.Sleep(time.Second)
				continue
			}
		}
		if cur >= head {
			p.mu.Lock()
			if p.state == "REBUILDING" || p.state == "EMPTY" {
				p.state = "OK"
				if p.rebuild.FinishedAt == nil && !p.rebuild.StartedAt.IsZero() {
					t := time.Now()
					p.rebuild.FinishedAt = &t
					p.rebuild.DurationMs = t.Sub(p.rebuild.StartedAt).Milliseconds()
				}
			}
			p.mu.Unlock()
			time.Sleep(250 * time.Millisecond)
			continue
		}
		upto := head
		if upto > cur+100 {
			upto = cur + 100
		}
		if err := p.ingest(ctx, cur+1, upto); err != nil {
			log.Printf("projection: ingest %d..%d: %v", cur+1, upto, err)
			time.Sleep(time.Second)
		}
	}
}

func (p *Projection) loadGenesis(ctx context.Context) error {
	gen, err := p.g.Pool.Client(0).Genesis(ctx)
	if err != nil {
		for i := 1; i < len(p.g.Net.Nodes) && err != nil; i++ {
			gen, err = p.g.Pool.Client(i).Genesis(ctx)
		}
		if err != nil {
			return err
		}
	}
	gs, err := core.ParseGenesis(gen.Genesis.AppState)
	if err != nil {
		return err
	}
	mem := core.NewMemStore()
	if _, e := core.ApplyGenesis(mem, gs); e != nil {
		return e
	}
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	keys := make([]string, 0, len(mem.M))
	for k := range mem.M {
		keys = append(keys, k)
	}
	sortKeys(keys)
	for i, k := range keys {
		if err := p.applyWrite(tx, k, mem.M[k], false, 0, "genesis", i); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(`INSERT OR REPLACE INTO meta(k,v) VALUES('genesis_loaded','1')`); err != nil {
		return err
	}
	return tx.Commit()
}

func sortKeys(k []string) {
	for i := 1; i < len(k); i++ {
		for j := i; j > 0 && k[j] < k[j-1]; j-- {
			k[j], k[j-1] = k[j-1], k[j]
		}
	}
}

func attr(ev abci.Event, key string) string {
	for _, a := range ev.Attributes {
		if a.Key == key {
			return a.Value
		}
	}
	return ""
}

func (p *Projection) ingest(ctx context.Context, from, to int64) error {
	type blockData struct {
		b  *coretypesBlock
		br *coretypesBlockResults
	}
	var data []blockData
	for h := from; h <= to; h++ {
		hh := h
		var b *coretypesBlock
		var br *coretypesBlockResults
		if err := p.g.Pool.Do(func(c *rpcClient) error {
			var e error
			if b, e = c.Block(ctx, &hh); e != nil {
				return e
			}
			br, e = c.BlockResults(ctx, &hh)
			return e
		}); err != nil {
			return err
		}
		data = append(data, blockData{b, br})
	}
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for _, d := range data {
		if err := p.ingestBlock(tx, d.b, d.br); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(`INSERT OR REPLACE INTO meta(k,v) VALUES('indexed_height',?)`, strconv.FormatInt(to, 10)); err != nil {
		return err
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	p.mu.Lock()
	p.indexed = to
	if p.state == "REBUILDING" {
		p.rebuild.BlocksReplayed = to
	}
	old := p.notify
	p.notify = make(chan struct{})
	p.mu.Unlock()
	close(old)
	return nil
}

func (p *Projection) ingestBlock(tx *sql.Tx, b *coretypesBlock, br *coretypesBlockResults) error {
	h := b.Block.Height
	tms := b.Block.Time.UnixMilli()
	rejected := 0
	seq := 0
	for i, raw := range b.Block.Data.Txs {
		res := br.TxsResults[i]
		var txID, typ, signer, auth string
		for _, ev := range res.Events {
			if ev.Type == "aureom.tx" {
				txID, typ, signer, auth = attr(ev, "tx_id"), attr(ev, "type"), attr(ev, "signer"), attr(ev, "authenticated")
			}
		}
		status := "OK"
		if res.Code != 0 {
			status = "REJECTED"
			rejected++
		}
		if _, err := tx.Exec(`INSERT OR REPLACE INTO txlog(height,idx,tx_id,type,signer,status,code,code_name,reason,hash,block_time_ms,client_time_ms,authenticated) VALUES(?,?,?,?,?,?,?,?,?,?,?,0,?)`,
			h, i, txID, typ, signer, status, res.Code, core.CodeName(res.Code), res.Log, hexUp(types.Tx(raw).Hash()), tms, boolInt(auth == "true")); err != nil {
			return err
		}
		for _, ev := range res.Events {
			switch ev.Type {
			case "aureom.w":
				seq++
				if err := p.applyWrite(tx, attr(ev, "key"), []byte(attr(ev, "value")), false, h, txID, seq); err != nil {
					return err
				}
			case "aureom.d":
				seq++
				if err := p.applyWrite(tx, attr(ev, "key"), nil, true, h, txID, seq); err != nil {
					return err
				}
			}
		}
	}
	for _, ev := range br.FinalizeBlockEvents {
		switch ev.Type {
		case "aureom.w":
			seq++
			if err := p.applyWrite(tx, attr(ev, "key"), []byte(attr(ev, "value")), false, h, "block", seq); err != nil {
				return err
			}
		case "aureom.d":
			seq++
			if err := p.applyWrite(tx, attr(ev, "key"), nil, true, h, "block", seq); err != nil {
				return err
			}
		}
	}
	// block-level meta key written by the app each block (kept in the mirror for digest equality)
	proposer := ""
	for _, n := range p.g.Net.Nodes {
		if pk, err := hex.DecodeString(""); err == nil && len(pk) == 0 {
			_ = n
		}
	}
	names := p.g.valNames(context.Background())
	proposer = names[hexUp(b.Block.ProposerAddress)]
	size := 0
	for _, t := range b.Block.Data.Txs {
		size += len(t)
	}
	_, err := tx.Exec(`INSERT OR REPLACE INTO blocks(height,time_ms,hash,app_hash,proposer,num_txs,num_rejected,size) VALUES(?,?,?,?,?,?,?,?)`,
		h, tms, hexUp(b.BlockID.Hash), hexUp(br.AppHash), proposer, len(b.Block.Data.Txs), rejected, size)
	return err
}

func boolInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

// applyWrite mirrors one state write and updates derived tables.
func (p *Projection) applyWrite(tx *sql.Tx, key string, val []byte, del bool, h int64, txID string, seq int) error {
	if del {
		if _, err := tx.Exec(`DELETE FROM kv WHERE key=?`, key); err != nil {
			return err
		}
	} else {
		if _, err := tx.Exec(`INSERT INTO kv(key,value,height) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, height=excluded.height`, key, val, h); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(`INSERT OR REPLACE INTO kv_hist(key,height,seq,tx_id,value,deleted) VALUES(?,?,?,?,?,?)`, key, h, seq, txID, val, boolInt(del)); err != nil {
		return err
	}
	return p.derive(tx, key, val, del, h)
}

var recKinds = []struct{ prefix, kind string }{
	{core.KProduct, "product"}, {core.KSKU, "sku"}, {core.KLocation, "location"}, {core.KSupplier, "supplier"}, {core.KPO, "po"},
	{core.KReceipt, "receipt"}, {core.KReserve, "reservation"}, {core.KReturn, "return"}, {core.KRefund, "refund"}, {core.KPrice, "price"},
	{core.KPromo, "promotion"}, {core.KLoyEntry, "loyalty_entry"}, {core.KLoyalty, "loyalty"}, {core.KAdjust, "adjustment"}, {core.KTransfer, "transfer"},
	{core.KException, "exception"}, {core.KIdentity, "identity"}, {core.KGrants, "grants"}, {core.KMember, "member"}, {core.KProposal, "proposal"},
	{core.KUpgrade, "upgrade"}, {core.KMigBatch, "migration_batch"}, {core.KPriceBook, "pricebook"}, {core.KReversal, "reversal"},
}

func (p *Projection) derive(tx *sql.Tx, key string, val []byte, del bool, h int64) error {
	switch {
	case strings.HasPrefix(key, core.KSale):
		id := key[len(core.KSale):]
		if del {
			_, err := tx.Exec(`DELETE FROM sale WHERE id=?`, id)
			return err
		}
		var s core.Sale
		if err := json.Unmarshal(val, &s); err != nil {
			return err
		}
		_, err := tx.Exec(`INSERT OR REPLACE INTO sale(id,loc,channel,customer,eff_ms,block_time_ms,gross,discount,net,paid,refund_instr,refund_conf,pay_status,ful_status,origin,json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			s.ID, s.Loc, s.Channel, s.CustomerID, s.EffectiveAt, s.BlockTime, s.Gross, s.Discount, s.Net, s.Paid, s.RefundInstr, s.RefundConf, s.PaymentStatus, s.FulfilmentStatus, s.Prov.Origin, string(val))
		return err
	case strings.HasPrefix(key, core.KBalance):
		var b core.Balance
		if err := json.Unmarshal(val, &b); err != nil {
			return err
		}
		_, err := tx.Exec(`INSERT OR REPLACE INTO bal(sku,loc,available,reserved,quarantined,damaged,version) VALUES(?,?,?,?,?,?,?)`, b.SKU, b.Loc, b.Available, b.Reserved, b.Quarantined, b.Damaged, b.Version)
		return err
	case strings.HasPrefix(key, core.KMovement):
		var m core.Movement
		if err := json.Unmarshal(val, &m); err != nil {
			return err
		}
		_, err := tx.Exec(`INSERT OR REPLACE INTO mov(seq,sku,from_loc,to_loc,qty,reason,ref_type,ref_id,height,tx_id,eff_ms,json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
			m.Seq, m.SKU, m.FromLoc, m.ToLoc, m.Qty, m.Reason, m.RefType, m.RefID, m.Height, m.TxID, m.EffectiveAt, string(val))
		return err
	case strings.HasPrefix(key, core.KTx):
		var tr core.TxRecord
		if json.Unmarshal(val, &tr) == nil {
			_, err := tx.Exec(`UPDATE txlog SET client_time_ms=? WHERE tx_id=?`, tr.ClientTime, tr.ID)
			return err
		}
		return nil
	}
	for _, rk := range recKinds {
		if strings.HasPrefix(key, rk.prefix) {
			id := key[len(rk.prefix):]
			if del {
				_, err := tx.Exec(`DELETE FROM rec WHERE kind=? AND id=?`, rk.kind, id)
				return err
			}
			var m core.Meta
			json.Unmarshal(val, &m)
			_, err := tx.Exec(`INSERT INTO rec(kind,id,key,json,created_h,updated_h) VALUES(?,?,?,?,?,?) ON CONFLICT(kind,id) DO UPDATE SET json=excluded.json, updated_h=excluded.updated_h`,
				rk.kind, id, key, string(val), m.CreatedH, m.UpdatedH)
			return err
		}
	}
	return nil
}

// ---- rebuild / digest / verify ----

func (p *Projection) RequestRebuild() {
	select {
	case p.rebuildReq <- struct{}{}:
	default:
	}
	p.mu.Lock()
	p.state = "REBUILDING"
	p.mu.Unlock()
}

func (p *Projection) doRebuild() {
	p.mu.Lock()
	p.state = "REBUILDING"
	p.indexed = 0
	p.rebuild = RebuildInfo{StartedAt: time.Now()}
	p.digestAt = 0
	p.mu.Unlock()
	p.db.Close()
	for _, suf := range []string{"", "-wal", "-shm"} {
		os.Remove(p.path + suf)
	}
	if err := p.open(); err != nil {
		log.Printf("projection: rebuild open: %v", err)
	}
	p.mu.Lock()
	p.state = "REBUILDING"
	p.indexed = 0
	p.mu.Unlock()
}

func (p *Projection) Digest(ctx context.Context) (string, int64, int64, error) {
	p.mu.RLock()
	h := p.indexed
	if p.digestAt == h && h != 0 {
		v, n := p.digestVal, p.digestN
		p.mu.RUnlock()
		return v, n, h, nil
	}
	p.mu.RUnlock()
	// consistent read: snapshot tx
	tx, err := p.db.BeginTx(ctx, &sql.TxOptions{ReadOnly: true})
	if err != nil {
		return "", 0, 0, err
	}
	defer tx.Rollback()
	var ih string
	if err := tx.QueryRow(`SELECT v FROM meta WHERE k='indexed_height'`).Scan(&ih); err != nil {
		return "", 0, 0, err
	}
	h, _ = strconv.ParseInt(ih, 10, 64)
	rows, err := tx.Query(`SELECT key, value FROM kv ORDER BY key`)
	if err != nil {
		return "", 0, 0, err
	}
	defer rows.Close()
	d := core.NewDigest()
	for rows.Next() {
		var k string
		var v []byte
		if err := rows.Scan(&k, &v); err != nil {
			return "", 0, 0, err
		}
		d.Add([]byte(k), v)
	}
	sum := hex.EncodeToString(d.Sum())
	p.mu.Lock()
	p.digestAt, p.digestVal, p.digestN = h, sum, d.N
	p.mu.Unlock()
	return sum, d.N, h, nil
}

func (g *Gateway) hProjStatus(w http.ResponseWriter, r *http.Request) {
	m := g.Proj.Meta()
	g.Proj.mu.RLock()
	rb := g.Proj.rebuild
	lt := g.Proj.lastTime
	g.Proj.mu.RUnlock()
	st := map[string]any{"state": m["projection_state"], "indexed_height": m["indexed_height"], "chain_head": m["chain_head"], "lag_blocks": m["lag_blocks"], "rebuild": rb}
	var timeMs int64
	g.Proj.db.QueryRow(`SELECT time_ms FROM blocks ORDER BY height DESC LIMIT 1`).Scan(&timeMs)
	if timeMs > 0 {
		st["last_indexed_block_time"] = time.UnixMilli(timeMs).UTC()
		if lt > 0 {
			st["lag_seconds"] = float64(lt-timeMs) / 1000
		}
	}
	if m["indexed_height"].(int64) > 0 && m["lag_blocks"].(int64) < 50 {
		if d, n, h, err := g.Proj.Digest(r.Context()); err == nil {
			st["digest"], st["entries"], st["digest_height"] = d, n, h
		}
	}
	st["storage"] = "SQLite (disposable; rebuildable from the chain)"
	ok(w, st)
}

func (g *Gateway) hProjRebuild(w http.ResponseWriter, r *http.Request) {
	g.Proj.RequestRebuild()
	ok(w, map[string]any{"status": "REBUILDING", "message": "projection dropped; re-ingesting from genesis; poll /api/v1/projection/status"})
}

func (g *Gateway) hProjVerify(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	proofs, _ := strconv.Atoi(r.URL.Query().Get("proofs"))
	if proofs > 200 {
		proofs = 200
	}
	// make the comparison at a height both sides can serve: the projection's own indexed height
	d, n, h, err := g.Proj.Digest(ctx)
	if err != nil || h == 0 {
		fail(w, 409, "projection empty")
		return
	}
	cd, err := g.chainDigest(ctx, h)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	res := map[string]any{"height": h, "projection_digest": d, "chain_digest": cd.Digest, "projection_entries": n, "chain_entries": cd.Entries,
		"match":     d == cd.Digest && n == cd.Entries,
		"statement": "digest = SHA-256 over every (key,value) of the state in key order: equality means the projection mirrors the committed state exactly (completeness + correctness); the chain digest is computed by a validator from the committed IAVL tree at that height"}
	if proofs > 0 {
		rows, err := g.Proj.db.QueryContext(ctx, `SELECT key, value FROM kv ORDER BY random() LIMIT ?`, proofs)
		if err == nil {
			defer rows.Close()
			checked, valid := 0, 0
			var failures []string
			for rows.Next() {
				var k string
				var v []byte
				rows.Scan(&k, &v)
				rec, e := g.getRecord(ctx, k, h, true)
				checked++
				if e == nil && rec.Verification != nil && rec.Verification.ProofValid && string(rec.Value) == string(v) {
					valid++
				} else if len(failures) < 5 {
					failures = append(failures, k)
				}
			}
			res["proofs_checked"], res["proofs_valid"], res["proof_failures"] = checked, valid, failures
		}
	}
	ok(w, res)
}

func (g *Gateway) hBlocks(w http.ResponseWriter, r *http.Request) {
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 200 {
		limit = 20
	}
	before, _ := strconv.ParseInt(r.URL.Query().Get("before"), 10, 64)
	q := `SELECT height,time_ms,hash,app_hash,proposer,num_txs,num_rejected,size FROM blocks`
	var args []any
	if before > 0 {
		q += ` WHERE height < ?`
		args = append(args, before)
	}
	q += ` ORDER BY height DESC LIMIT ?`
	args = append(args, limit)
	rows, err := g.Proj.db.QueryContext(r.Context(), q, args...)
	if err != nil {
		fail(w, 500, err.Error())
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var h, t, nt, nr, sz int64
		var hash, ah, pr string
		rows.Scan(&h, &t, &hash, &ah, &pr, &nt, &nr, &sz)
		out = append(out, map[string]any{"height": h, "time": time.UnixMilli(t).UTC(), "hash": hash, "app_hash": ah, "proposer": pr, "num_txs": nt, "num_rejected": nr, "size_bytes": sz})
	}
	ok(w, out)
}

var _ = fmt.Sprint
