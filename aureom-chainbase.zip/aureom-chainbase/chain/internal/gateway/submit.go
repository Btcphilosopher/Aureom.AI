package gateway

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/cometbft/cometbft/types"

	"github.com/aureom/chainbase/internal/core"
)

type submitReq struct {
	Tx        json.RawMessage `json:"tx"`
	Wait      string          `json:"wait"`
	TimeoutMs int             `json:"timeout_ms"`
}

type Sample struct {
	TxID        string    `json:"tx_id"`
	Type        string    `json:"type"`
	Signer      string    `json:"signer"`
	AdmissionMs int64     `json:"admission_ms"`
	FinalityMs  int64     `json:"finality_ms"`
	IndexedMs   int64     `json:"indexed_ms"`
	Code        uint32    `json:"code"`
	CodeName    string    `json:"code_name"`
	Reason      string    `json:"reason,omitempty"`
	Stage       string    `json:"stage"` // ADMISSION | FINALISED
	At          time.Time `json:"at"`
}

type Latency struct {
	mu       sync.Mutex
	samples  []Sample
	rejected []Sample
}

func NewLatency() *Latency { return &Latency{} }

func (l *Latency) Add(s Sample) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if s.Stage == "FINALISED" && s.Code == 0 {
		l.samples = append(l.samples, s)
		if len(l.samples) > 5000 {
			l.samples = l.samples[len(l.samples)-5000:]
		}
	} else if s.Code != 0 {
		l.rejected = append(l.rejected, s)
		if len(l.rejected) > 200 {
			l.rejected = l.rejected[len(l.rejected)-200:]
		}
	}
}

func pct(v []int64) map[string]int64 {
	if len(v) == 0 {
		return map[string]int64{"p50": 0, "p95": 0, "p99": 0, "max": 0}
	}
	s := append([]int64(nil), v...)
	sort.Slice(s, func(i, j int) bool { return s[i] < s[j] })
	at := func(p float64) int64 { return s[int(float64(len(s)-1)*p)] }
	return map[string]int64{"p50": at(.50), "p95": at(.95), "p99": at(.99), "max": s[len(s)-1]}
}

func (g *Gateway) hLatency(w http.ResponseWriter, r *http.Request) {
	g.Lat.mu.Lock()
	defer g.Lat.mu.Unlock()
	var adm, fin, idx []int64
	for _, s := range g.Lat.samples {
		adm = append(adm, s.AdmissionMs)
		fin = append(fin, s.FinalityMs)
		if s.IndexedMs > 0 {
			idx = append(idx, s.IndexedMs)
		}
	}
	recent := g.Lat.samples
	if len(recent) > 50 {
		recent = recent[len(recent)-50:]
	}
	rej := g.Lat.rejected
	if len(rej) > 50 {
		rej = rej[len(rej)-50:]
	}
	ok(w, map[string]any{"count": len(g.Lat.samples), "admission_ms": pct(adm), "finality_ms": pct(fin), "indexed_ms": pct(idx), "recent": recent, "rejected_recent": rej,
		"note": "measured for transactions submitted through this gateway (client-observed: includes block interval quantisation)"})
}

func (g *Gateway) hSubmit(w http.ResponseWriter, r *http.Request) {
	if okRate, retry := g.RL.Allow(clientIP(r)); !okRate {
		w.Header().Set("Retry-After", strconv.Itoa(int(retry.Seconds())+1))
		fail(w, 429, "rate limit exceeded")
		return
	}
	body, err := io.ReadAll(io.LimitReader(r.Body, 2<<20))
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	var req submitReq
	if err := json.Unmarshal(body, &req); err != nil || len(req.Tx) == 0 {
		fail(w, 400, "body must be {\"tx\": <envelope>, \"wait\": ...}")
		return
	}
	var wire []byte
	if req.Tx[0] == '"' {
		var s string
		json.Unmarshal(req.Tx, &s)
		wire = []byte(s)
	} else {
		var env core.Envelope
		if err := json.Unmarshal(req.Tx, &env); err != nil {
			fail(w, 400, "bad envelope")
			return
		}
		wire = core.MarshalJSON(env)
	}
	if req.TimeoutMs <= 0 || req.TimeoutMs > 60000 {
		req.TimeoutMs = 15000
	}
	ctx, cancel := context.WithTimeout(r.Context(), time.Duration(req.TimeoutMs)*time.Millisecond)
	defer cancel()

	sm := Sample{At: time.Now().UTC()}
	if d, e := core.DecodeStateless(wire, g.Net.NetworkID, core.DefaultParams()); e == nil {
		sm.TxID, sm.Type, sm.Signer = d.Body.TxID, d.Body.Type, d.Body.Signer
	}
	hash := types.Tx(wire).Hash()
	t0 := time.Now()
	var code uint32
	var log string
	err = g.Pool.Do(func(c *rpcClient) error {
		res, e := c.BroadcastTxSync(ctx, wire)
		if e != nil {
			return e
		}
		code, log = res.Code, res.Log
		return nil
	})
	if err != nil && strings.Contains(err.Error(), "already exists in cache") {
		// identical bytes were already submitted: report it as a replay at admission, not as a gateway error
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{"tx_hash": hexUp(hash), "tx_id": sm.TxID, "type": sm.Type, "signer": sm.Signer,
			"admission": map[string]any{"code": core.CodeReplay, "name": core.CodeName(core.CodeReplay), "log": "identical transaction bytes already submitted (mempool cache) or finalised"},
			"duplicate": true})
		return
	}
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	sm.AdmissionMs = time.Since(t0).Milliseconds()
	out := map[string]any{"tx_hash": hexUp(hash), "tx_id": sm.TxID, "type": sm.Type, "signer": sm.Signer,
		"admission": map[string]any{"code": code, "name": core.CodeName(code), "log": log}}
	lat := map[string]any{"admission": sm.AdmissionMs}
	if code != 0 {
		sm.Code, sm.CodeName, sm.Reason, sm.Stage = code, core.CodeName(code), log, "ADMISSION"
		g.Lat.Add(sm)
		out["latency_ms"] = lat
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(out)
		return
	}
	if req.Wait == "final" || req.Wait == "indexed" {
		var height int64
		for {
			var res *coretypesTx
			e := g.Pool.Do(func(c *rpcClient) (x error) { res, x = c.Tx(ctx, hash, false); return })
			if e == nil {
				height = res.Height
				sm.Code, sm.CodeName, sm.Reason = res.TxResult.Code, core.CodeName(res.TxResult.Code), res.TxResult.Log
				sm.FinalityMs, sm.Stage = time.Since(t0).Milliseconds(), "FINALISED"
				var data any
				if len(res.TxResult.Data) > 0 {
					json.Unmarshal(res.TxResult.Data, &data)
				}
				out["finalised"] = map[string]any{"height": res.Height, "index": res.Index, "code": res.TxResult.Code, "code_name": core.CodeName(res.TxResult.Code), "log": res.TxResult.Log, "data": data}
				lat["finality"] = sm.FinalityMs
				break
			}
			if ctx.Err() != nil {
				out["finalised"] = nil
				out["note"] = "timeout waiting for finality; the tx may still be finalised later — poll /api/v1/tx/{id}/status"
				break
			}
			time.Sleep(40 * time.Millisecond)
		}
		if height > 0 && req.Wait == "indexed" {
			indexed := g.Proj.WaitFor(ctx, height)
			out["indexed"] = indexed
			if indexed {
				sm.IndexedMs = time.Since(t0).Milliseconds()
				lat["indexed"] = sm.IndexedMs
			}
		}
		g.Lat.Add(sm)
	}
	out["latency_ms"] = lat
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(out)
}

func (g *Gateway) hTxStatus(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	res := map[string]any{"tx_id": id, "status": "UNKNOWN"}
	rec, err := g.getRecord(r.Context(), core.KTx+id, 0, false)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	if rec.Found {
		var tr core.TxRecord
		json.Unmarshal(rec.Value, &tr)
		res["status"] = map[string]string{"OK": "FINALISED_OK", "REJECTED": "FINALISED_REJECTED"}[tr.Status]
		res["height"], res["index"], res["code"], res["code_name"], res["reason"] = tr.Height, tr.Index, tr.Code, tr.CodeName, tr.Reason
		res["block_time_ms"], res["signer"], res["type"] = tr.BlockTime, tr.Signer, tr.Type
		res["indexed"] = g.Proj.IndexedHeight() >= tr.Height
	} else {
		// pending in a validator mempool?
		for i := range g.Net.Nodes {
			u, e := g.Pool.Client(i).UnconfirmedTxs(r.Context(), intPtr(100))
			if e != nil {
				continue
			}
			for _, raw := range u.Txs {
				if d, e := core.DecodeStateless(raw, g.Net.NetworkID, core.DefaultParams()); e == nil && d.Body.TxID == id {
					res["status"] = "PENDING"
				}
			}
			break
		}
	}
	ok(w, res)
}

func intPtr(i int) *int { return &i }

var _ = hex.EncodeToString
var _ = fmt.Sprint
var _ = strings.ToUpper
