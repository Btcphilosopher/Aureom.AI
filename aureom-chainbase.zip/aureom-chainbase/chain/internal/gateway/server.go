// Package gateway is the HTTP API in front of the validators: authoritative reads with
// proof verification, transaction submission, explorer diagnostics and the disposable
// SQLite query projection.
package gateway

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/aureom/chainbase/internal/core"
)

type Config struct {
	NetworkPath    string
	Listen         string
	ProjectionPath string
	StaticDir      string
	ReportsDir     string
	RateLimit      float64
	RateBurst      float64
}

type Gateway struct {
	Net   *NetCfg
	Pool  *Pool
	light *Light
	Proj  *Projection
	Lat   *Latency
	RL    *RateLimiter
	Cfg   Config
}

func New(cfg Config) (*Gateway, error) {
	nc, err := LoadNetCfg(cfg.NetworkPath)
	if err != nil {
		return nil, err
	}
	pool, err := NewPool(nc)
	if err != nil {
		return nil, err
	}
	if cfg.RateLimit == 0 {
		cfg.RateLimit, cfg.RateBurst = 200, 400
	}
	g := &Gateway{Net: nc, Pool: pool, Cfg: cfg, Lat: NewLatency(), RL: NewRateLimiter(cfg.RateLimit, cfg.RateBurst)}
	g.Proj, err = OpenProjection(cfg.ProjectionPath, g)
	if err != nil {
		return nil, err
	}
	return g, nil
}

func (g *Gateway) Start(ctx context.Context) {
	g.initLight(ctx)
	go g.Proj.Run(ctx)
}

func ok(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, status int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]any{"error": msg, "code": http.StatusText(status)})
}

func cors(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		w.Header().Set("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(204)
			return
		}
		h.ServeHTTP(w, r)
	})
}

func (g *Gateway) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/v1/health", func(w http.ResponseWriter, r *http.Request) {
		ok(w, map[string]any{"status": "ok", "network_id": g.Net.NetworkID})
	})
	// submission
	mux.HandleFunc("POST /api/v1/tx/submit", g.hSubmit)
	mux.HandleFunc("GET /api/v1/tx/{id}/status", g.hTxStatus)
	mux.HandleFunc("GET /api/v1/metrics/latency", g.hLatency)
	// network + chain
	mux.HandleFunc("GET /api/v1/network", g.hNetwork)
	mux.HandleFunc("GET /api/v1/chain/info", g.hChainInfo)
	mux.HandleFunc("GET /api/v1/chain/record", g.hRecord)
	mux.HandleFunc("GET /api/v1/chain/records/{kind}/{id}", g.hRecordKind)
	mux.HandleFunc("GET /api/v1/chain/scan", g.hScan)
	mux.HandleFunc("GET /api/v1/chain/inventory", g.hChainInventory)
	mux.HandleFunc("GET /api/v1/chain/digest", g.hDigest)
	mux.HandleFunc("GET /api/v1/chain/migration", g.hChainMigration)
	// explorer
	mux.HandleFunc("GET /api/v1/explorer/blocks", g.hBlocks)
	mux.HandleFunc("GET /api/v1/explorer/block/{height}", g.hBlock)
	mux.HandleFunc("GET /api/v1/explorer/tx/{id}", g.hExplorerTx)
	mux.HandleFunc("GET /api/v1/explorer/verify-finality", g.hVerifyFinality)
	mux.HandleFunc("GET /api/v1/explorer/proof", g.hExplorerProof)
	mux.HandleFunc("GET /api/v1/explorer/search", g.hSearch)
	// projection
	mux.HandleFunc("GET /api/v1/projection/status", g.hProjStatus)
	mux.HandleFunc("POST /api/v1/projection/rebuild", g.hProjRebuild)
	mux.HandleFunc("GET /api/v1/projection/verify", g.hProjVerify)
	g.registerQueries(mux)
	// migration reports
	mux.HandleFunc("POST /api/v1/migration/reports", g.hReportPost)
	mux.HandleFunc("GET /api/v1/migration/reports", g.hReportList)
	mux.HandleFunc("GET /api/v1/migration/reports/{id}", g.hReportGet)
	mux.HandleFunc("GET /api/v1/", func(w http.ResponseWriter, r *http.Request) { fail(w, 404, "unknown API endpoint") })
	// static dashboard with SPA fallback
	if g.Cfg.StaticDir != "" {
		fs := http.FileServer(http.Dir(g.Cfg.StaticDir))
		mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			p := filepath.Join(g.Cfg.StaticDir, filepath.Clean("/"+r.URL.Path))
			if st, err := os.Stat(p); err == nil && !st.IsDir() {
				fs.ServeHTTP(w, r)
				return
			}
			if _, err := os.Stat(filepath.Join(g.Cfg.StaticDir, "index.html")); err == nil {
				http.ServeFile(w, r, filepath.Join(g.Cfg.StaticDir, "index.html"))
				return
			}
			w.Header().Set("Content-Type", "text/html")
			io.WriteString(w, "<h1>AUREOM CHAINBASE gateway</h1><p>Dashboard not built (dashboard/dist missing). API at /api/v1/.</p>")
		})
	}
	return cors(mux)
}

// ---- rate limiting ----

type RateLimiter struct {
	mu    sync.Mutex
	rate  float64
	burst float64
	b     map[string]*bucket
}
type bucket struct {
	tokens float64
	last   time.Time
}

func NewRateLimiter(rate, burst float64) *RateLimiter {
	return &RateLimiter{rate: rate, burst: burst, b: map[string]*bucket{}}
}

func (rl *RateLimiter) Allow(key string) (bool, time.Duration) {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	t := time.Now()
	b, okb := rl.b[key]
	if !okb {
		b = &bucket{tokens: rl.burst, last: t}
		rl.b[key] = b
	}
	b.tokens += t.Sub(b.last).Seconds() * rl.rate
	if b.tokens > rl.burst {
		b.tokens = rl.burst
	}
	b.last = t
	if b.tokens < 1 {
		return false, time.Duration((1 - b.tokens) / rl.rate * float64(time.Second))
	}
	b.tokens--
	return true, 0
}

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

// ---- migration report store (off-chain files; the chain only carries the report hash) ----

func (g *Gateway) reportsDir() string {
	d := g.Cfg.ReportsDir
	if d == "" {
		d = filepath.Join(filepath.Dir(g.Cfg.ProjectionPath), "migration-reports")
	}
	os.MkdirAll(d, 0o755)
	return d
}

func (g *Gateway) hReportPost(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(io.LimitReader(r.Body, 8<<20))
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	var m map[string]any
	if err := json.Unmarshal(body, &m); err != nil {
		fail(w, 400, "report must be a JSON object")
		return
	}
	sum := sha256.Sum256(body)
	id, _ := m["id"].(string)
	if id == "" {
		id = "rpt-" + time.Now().UTC().Format("20060102T150405.000") + "-" + hex.EncodeToString(sum[:4])
	}
	id = strings.Map(func(r rune) rune {
		if r == '/' || r == '\\' || r == '.' || r == ' ' {
			return '_'
		}
		return r
	}, id)
	if err := os.WriteFile(filepath.Join(g.reportsDir(), id+".json"), body, 0o644); err != nil {
		fail(w, 500, err.Error())
		return
	}
	ok(w, map[string]any{"id": id, "sha256": hex.EncodeToString(sum[:])})
}

func (g *Gateway) hReportList(w http.ResponseWriter, r *http.Request) {
	ents, _ := os.ReadDir(g.reportsDir())
	type item struct {
		ID, Phase, GeneratedAt, Decision, Sha string
		Trial                                 bool
		mod                                   time.Time
	}
	var items []item
	for _, e := range ents {
		if !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		b, _ := os.ReadFile(filepath.Join(g.reportsDir(), e.Name()))
		var m map[string]any
		json.Unmarshal(b, &m)
		sum := sha256.Sum256(b)
		it := item{ID: strings.TrimSuffix(e.Name(), ".json"), Sha: hex.EncodeToString(sum[:])}
		it.Phase, _ = m["phase"].(string)
		it.GeneratedAt, _ = m["generated_at"].(string)
		it.Decision, _ = m["decision"].(string)
		it.Trial, _ = m["trial"].(bool)
		info, _ := e.Info()
		it.mod = info.ModTime()
		items = append(items, it)
	}
	sort.Slice(items, func(i, j int) bool { return items[i].mod.After(items[j].mod) })
	out := []map[string]any{}
	for _, it := range items {
		out = append(out, map[string]any{"id": it.ID, "phase": it.Phase, "trial": it.Trial, "generated_at": it.GeneratedAt, "decision": it.Decision, "sha256": it.Sha})
	}
	ok(w, out)
}

func (g *Gateway) hReportGet(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if id == "latest" {
		ents, _ := os.ReadDir(g.reportsDir())
		var newest os.DirEntry
		var nt time.Time
		for _, e := range ents {
			if strings.HasSuffix(e.Name(), ".json") {
				if info, _ := e.Info(); info.ModTime().After(nt) {
					newest, nt = e, info.ModTime()
				}
			}
		}
		if newest == nil {
			fail(w, 404, "no reports")
			return
		}
		id = strings.TrimSuffix(newest.Name(), ".json")
	}
	if strings.ContainsAny(id, "/\\") {
		fail(w, 400, "bad id")
		return
	}
	b, err := os.ReadFile(filepath.Join(g.reportsDir(), id+".json"))
	if err != nil {
		fail(w, 404, "report not found")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(b)
}

var _ = core.CodeOK
