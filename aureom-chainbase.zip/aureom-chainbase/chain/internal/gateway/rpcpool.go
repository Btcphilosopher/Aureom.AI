package gateway

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/cometbft/cometbft/rpc/client"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	coretypes "github.com/cometbft/cometbft/rpc/core/types"
)

type NodeCfg struct {
	Name   string `json:"name"`
	Org    string `json:"org"`
	Role   string `json:"role"`
	NodeID string `json:"node_id"`
	RPCURL string `json:"rpc_url"`
	PubKey string `json:"consensus_pubkey_b64"`
}

type NetCfg struct {
	NetworkID string    `json:"network_id"`
	Nodes     []NodeCfg `json:"nodes"`
	Genesis   string    `json:"genesis"`
}

func LoadNetCfg(path string) (*NetCfg, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var n NetCfg
	if err := json.Unmarshal(b, &n); err != nil {
		return nil, err
	}
	if len(n.Nodes) == 0 {
		return nil, fmt.Errorf("no nodes in %s", path)
	}
	return &n, nil
}

// Pool talks to the validators. Reads/submissions go to the first reachable node that is
// not catching up; every call falls through to the next node on failure.
type Pool struct {
	Cfg     *NetCfg
	clients []*rpchttp.HTTP
	mu      sync.Mutex
	next    int
}

func NewPool(cfg *NetCfg) (*Pool, error) {
	p := &Pool{Cfg: cfg}
	for _, n := range cfg.Nodes {
		c, err := rpchttp.NewWithTimeout(n.RPCURL, "/websocket", 5)
		if err != nil {
			return nil, err
		}
		p.clients = append(p.clients, c)
	}
	return p, nil
}

func (p *Pool) Client(i int) *rpchttp.HTTP { return p.clients[i] }

// Do runs f against nodes in rotation until one succeeds.
func (p *Pool) Do(f func(c *rpchttp.HTTP) error) error {
	p.mu.Lock()
	start := p.next
	p.next = (p.next + 1) % len(p.clients)
	p.mu.Unlock()
	var last error
	for i := 0; i < len(p.clients); i++ {
		c := p.clients[(start+i)%len(p.clients)]
		if err := f(c); err != nil {
			last = err
			continue
		}
		return nil
	}
	return fmt.Errorf("no validator reachable: %w", last)
}

func (p *Pool) Status(ctx context.Context) (*coretypes.ResultStatus, error) {
	var r *coretypes.ResultStatus
	err := p.Do(func(c *rpchttp.HTTP) (e error) { r, e = c.Status(ctx); return })
	return r, err
}

func (p *Pool) Query(ctx context.Context, path string, data []byte, height int64, prove bool) (*coretypes.ResultABCIQuery, error) {
	var r *coretypes.ResultABCIQuery
	err := p.Do(func(c *rpchttp.HTTP) (e error) {
		r, e = c.ABCIQueryWithOptions(ctx, path, data, client.ABCIQueryOptions{Height: height, Prove: prove})
		if e == nil && r.Response.Code != 0 {
			e = fmt.Errorf("query %s: %s", path, r.Response.Log)
		}
		return
	})
	return r, err
}

func now() time.Time { return time.Now() }
