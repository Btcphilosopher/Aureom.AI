// Package verify holds the independent verification tools: light-client finality checks,
// full replay of the chain through the state machine, and snapshot verification.
package verify

import (
	"context"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"cosmossdk.io/log"
	dbm "github.com/cometbft/cometbft-db"
	abci "github.com/cometbft/cometbft/abci/types"
	"github.com/cometbft/cometbft/light"
	"github.com/cometbft/cometbft/light/provider"
	lighthttp "github.com/cometbft/cometbft/light/provider/http"
	lightdb "github.com/cometbft/cometbft/light/store/db"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	"github.com/cometbft/cometbft/types"
	"github.com/cosmos/iavl"
	idb "github.com/cosmos/iavl/db"

	"github.com/aureom/chainbase/internal/app"
)

// NewLight builds a CometBFT light client anchored on the genesis validator set.
func NewLight(ctx context.Context, chainID string, rpcURLs []string, genesisFile string) (*light.Client, error) {
	gd, err := types.GenesisDocFromFile(genesisFile)
	if err != nil {
		return nil, err
	}
	vs := make([]*types.Validator, 0, len(gd.Validators))
	for _, v := range gd.Validators {
		vs = append(vs, types.NewValidator(v.PubKey, v.Power))
	}
	genHash := types.NewValidatorSet(vs).Hash()
	var provs []provider.Provider
	for _, u := range rpcURLs {
		p, err := lighthttp.New(chainID, u)
		if err != nil {
			return nil, err
		}
		provs = append(provs, p)
	}
	if len(provs) < 2 {
		return nil, fmt.Errorf("need at least 2 RPC endpoints (primary + witness)")
	}
	var lb *types.LightBlock
	for _, p := range provs {
		if b, err := p.LightBlock(ctx, 1); err == nil {
			lb = b
			break
		}
	}
	if lb == nil {
		return nil, fmt.Errorf("block 1 unavailable")
	}
	if hex.EncodeToString(lb.ValidatorSet.Hash()) != hex.EncodeToString(genHash) {
		return nil, fmt.Errorf("SECURITY: block 1 validator set does not match genesis validators")
	}
	return light.NewClient(ctx, chainID, light.TrustOptions{Period: 10 * 365 * 24 * time.Hour, Height: 1, Hash: lb.Hash()}, provs[0], provs[1:],
		lightdb.New(dbm.NewMemDB(), "light"), light.SkippingVerification(light.DefaultTrustLevel))
}

type Finality struct {
	Height      int64
	Verified    bool
	SignedPower int64
	TotalPower  int64
	Signers     int
	AppHash     string
	Err         string
}

func VerifyFinality(ctx context.Context, lc *light.Client, h int64) Finality {
	lb, err := lc.VerifyLightBlockAtHeight(ctx, h, time.Now())
	if err != nil {
		return Finality{Height: h, Err: err.Error()}
	}
	f := Finality{Height: h, Verified: true, TotalPower: lb.ValidatorSet.TotalVotingPower(), AppHash: strings.ToUpper(hex.EncodeToString(lb.AppHash))}
	pw := map[string]int64{}
	for _, v := range lb.ValidatorSet.Validators {
		pw[string(v.Address)] = v.VotingPower
	}
	for _, s := range lb.SignedHeader.Commit.Signatures {
		if s.BlockIDFlag == types.BlockIDFlagCommit {
			f.Signers++
			f.SignedPower += pw[string(s.ValidatorAddress)]
		}
	}
	return f
}

// ---- Full replay ----

type ReplayResult struct {
	Blocks       int64
	Txs          int64
	Rejected     int64
	FirstDiverge int64
	FinalAppHash string
	Err          string
}

// Replay re-executes every block from genesis through a fresh in-memory copy of the ABCI
// application (the same code path validators run) and compares the resulting state root
// after each block with the app_hash committed in the NEXT header on the chain.
func Replay(ctx context.Context, rpcURL string, upTo int64, progress func(h int64)) (*ReplayResult, error) {
	c, err := rpchttp.New(rpcURL, "/websocket")
	if err != nil {
		return nil, err
	}
	gen, err := c.Genesis(ctx)
	if err != nil {
		return nil, err
	}
	a, err := app.NewWithDB(idb.NewMemDB(), gen.Genesis.ChainID)
	if err != nil {
		return nil, err
	}
	defer a.Close()
	var vals []abci.ValidatorUpdate
	_ = vals
	if _, err := a.InitChain(ctx, &abci.RequestInitChain{ChainId: gen.Genesis.ChainID, AppStateBytes: gen.Genesis.AppState, Time: gen.Genesis.GenesisTime, InitialHeight: gen.Genesis.InitialHeight,
		Validators: genesisVals(gen.Genesis)}); err != nil {
		return nil, err
	}
	st, err := c.Status(ctx)
	if err != nil {
		return nil, err
	}
	head := st.SyncInfo.LatestBlockHeight
	if upTo == 0 || upTo > head-1 {
		upTo = head - 1 // the last block's app hash is only committed in the next header
	}
	res := &ReplayResult{}
	for h := int64(1); h <= upTo; h++ {
		hh := h
		blk, err := c.Block(ctx, &hh)
		if err != nil {
			return nil, err
		}
		nxt := h + 1
		nb, err := c.Block(ctx, &nxt)
		if err != nil {
			return nil, err
		}
		txs := make([][]byte, len(blk.Block.Data.Txs))
		for i, t := range blk.Block.Data.Txs {
			txs[i] = t
		}
		fr, err := a.FinalizeBlock(ctx, &abci.RequestFinalizeBlock{Height: h, Time: blk.Block.Time, Txs: txs})
		if err != nil {
			return nil, err
		}
		if _, err := a.Commit(ctx, &abci.RequestCommit{}); err != nil {
			return nil, err
		}
		for _, r := range fr.TxResults {
			res.Txs++
			if r.Code != 0 {
				res.Rejected++
			}
		}
		res.Blocks = h
		res.FinalAppHash = strings.ToUpper(hex.EncodeToString(fr.AppHash))
		if strings.ToUpper(hex.EncodeToString(nb.Block.AppHash)) != res.FinalAppHash {
			res.FirstDiverge = h
			res.Err = fmt.Sprintf("DIVERGENCE at height %d: replay app_hash %s != chain header %d app_hash %s", h, res.FinalAppHash, h+1, strings.ToUpper(hex.EncodeToString(nb.Block.AppHash)))
			return res, nil
		}
		if progress != nil && h%50 == 0 {
			progress(h)
		}
	}
	return res, nil
}

func genesisVals(g *types.GenesisDoc) []abci.ValidatorUpdate {
	var out []abci.ValidatorUpdate
	for _, v := range g.Validators {
		pk, _ := cryptoToProto(v.PubKey.Bytes())
		out = append(out, abci.ValidatorUpdate{PubKey: pk, Power: v.Power})
	}
	return out
}

// ---- Snapshots ----

type SnapshotManifest struct {
	ChainID  string `json:"chain_id"`
	Height   int64  `json:"height"`
	RootHash string `json:"root_hash"`
	Nodes    int64  `json:"nodes"`
	FileSHA  string `json:"-"`
}

type snapNode struct {
	Key     string `json:"k"`
	Value   string `json:"v"`
	Version int64  `json:"ver"`
	Height  int8   `json:"h"`
}

// ExportSnapshot writes the IAVL tree at `height` (0 = latest) from an application database
// directory (node must be stopped) to a JSON-lines file; the first line is the manifest.
func ExportSnapshot(dbDir, chainID string, height int64, out string) (*SnapshotManifest, error) {
	a, err := app.New(dbDir, chainID)
	if err != nil {
		return nil, err
	}
	defer a.Close()
	t := a.Tree()
	if height == 0 {
		height, _ = t.GetLatestVersion()
	}
	imm, err := t.GetImmutable(height)
	if err != nil {
		return nil, err
	}
	exp, err := imm.Export()
	if err != nil {
		return nil, err
	}
	defer exp.Close()
	f, err := os.Create(out)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	m := &SnapshotManifest{ChainID: chainID, Height: height, RootHash: strings.ToUpper(hex.EncodeToString(imm.Hash()))}
	if err := enc.Encode(m); err != nil {
		return nil, err
	}
	for {
		n, err := exp.Next()
		if err == iavl.ErrorExportDone {
			break
		}
		if err != nil {
			return nil, err
		}
		m.Nodes++
		if err := enc.Encode(snapNode{base64.StdEncoding.EncodeToString(n.Key), base64.StdEncoding.EncodeToString(n.Value), n.Version, n.Height}); err != nil {
			return nil, err
		}
	}
	return m, nil
}

// ImportRoot rebuilds an in-memory IAVL tree from a snapshot file and returns its root hash.
func ImportRoot(file string) (*SnapshotManifest, string, error) {
	f, err := os.Open(file)
	if err != nil {
		return nil, "", err
	}
	defer f.Close()
	dec := json.NewDecoder(f)
	var m SnapshotManifest
	if err := dec.Decode(&m); err != nil {
		return nil, "", err
	}
	tree := iavl.NewMutableTree(idb.NewMemDB(), 1000, false, log.NewNopLogger())
	imp, err := tree.Import(m.Height)
	if err != nil {
		return nil, "", err
	}
	defer imp.Close()
	for dec.More() {
		var n snapNode
		if err := dec.Decode(&n); err != nil {
			return nil, "", err
		}
		k, _ := base64.StdEncoding.DecodeString(n.Key)
		v, _ := base64.StdEncoding.DecodeString(n.Value)
		if n.Value == "" {
			v = nil
		}
		if err := imp.Add(&iavl.ExportNode{Key: k, Value: v, Version: n.Version, Height: n.Height}); err != nil {
			return nil, "", err
		}
	}
	if err := imp.Commit(); err != nil {
		return nil, "", err
	}
	if _, err := tree.LoadVersion(m.Height); err != nil {
		return nil, "", err
	}
	return &m, strings.ToUpper(hex.EncodeToString(tree.Hash())), nil
}
