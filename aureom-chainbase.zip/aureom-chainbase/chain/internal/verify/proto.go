package verify

import (
	cmtcrypto "github.com/cometbft/cometbft/proto/tendermint/crypto"
)

func cryptoToProto(ed []byte) (cmtcrypto.PublicKey, error) {
	return cmtcrypto.PublicKey{Sum: &cmtcrypto.PublicKey_Ed25519{Ed25519: ed}}, nil
}
