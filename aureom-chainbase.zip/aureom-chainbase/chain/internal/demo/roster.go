// Package demo defines the fictional retail group used by the prototype, tests and benchmark.
// All data is synthetic. Keys produced by DeterministicKey are for tests ONLY.
package demo

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"

	"github.com/aureom/chainbase/internal/core"
)

const GBP = "GBP"

type RoleScope struct{ Role, Scope string }

type Spec struct {
	ID, Org, Kind, Bound string
	Roles                []RoleScope
}

var Locations = []core.GenesisLocation{
	{ID: "WH-DIST-01", Name: "Distribution Centre Midlands", Kind: "WAREHOUSE", Region: "central", Currency: GBP},
	{ID: "STORE-N-01", Name: "Northgate Superstore", Kind: "STORE", Region: "north", Currency: GBP},
	{ID: "STORE-N-02", Name: "Harbour Street Express", Kind: "STORE", Region: "north", Currency: GBP},
	{ID: "STORE-S-01", Name: "Southcoast Superstore", Kind: "STORE", Region: "south", Currency: GBP},
}

func rs(r, s string) RoleScope { return RoleScope{r, s} }

// Orgs: independent operators of the four validators.
var Orgs = []string{"org-hq", "org-dist", "org-north", "org-south"}

func Roster() []Spec {
	return []Spec{
		{"hq-org-admin", "org-hq", "HUMAN", "", []RoleScope{rs("org-admin", "*"), rs("hq-admin", "*")}},
		{"dist-org-admin", "org-dist", "HUMAN", "", []RoleScope{rs("org-admin", "*")}},
		{"north-org-admin", "org-north", "HUMAN", "", []RoleScope{rs("org-admin", "*")}},
		{"south-org-admin", "org-south", "HUMAN", "", []RoleScope{rs("org-admin", "*")}},
		{"hq-iam-admin", "org-hq", "HUMAN", "", []RoleScope{rs("hq-admin", "*")}},
		{"catalog-mgr", "org-hq", "HUMAN", "", []RoleScope{rs("catalog-manager", "*")}},
		{"buyer-hq", "org-hq", "HUMAN", "", []RoleScope{rs("buyer", "*")}},
		{"po-approver-hq", "org-hq", "HUMAN", "", []RoleScope{rs("purchasing-approver", "*")}},
		{"po-approver-dist", "org-dist", "HUMAN", "", []RoleScope{rs("purchasing-approver", "loc:WH-DIST-01")}},
		{"wh-operator-dist", "org-dist", "HUMAN", "", []RoleScope{rs("warehouse-operator", "loc:WH-DIST-01")}},
		{"wh-manager-dist", "org-dist", "HUMAN", "", []RoleScope{rs("warehouse-manager", "loc:WH-DIST-01")}},
		{"cashier-n01", "org-north", "HUMAN", "", []RoleScope{rs("store-cashier", "loc:STORE-N-01")}},
		{"manager-n01", "org-north", "HUMAN", "", []RoleScope{rs("store-manager", "loc:STORE-N-01")}},
		{"manager2-n01", "org-north", "HUMAN", "", []RoleScope{rs("store-manager", "loc:STORE-N-01")}},
		{"manager2-s01", "org-south", "HUMAN", "", []RoleScope{rs("store-manager", "loc:STORE-S-01")}},
		{"cashier-s01", "org-south", "HUMAN", "", []RoleScope{rs("store-cashier", "loc:STORE-S-01")}},
		{"manager-s01", "org-south", "HUMAN", "", []RoleScope{rs("store-manager", "loc:STORE-S-01")}},
		{"term-n01-1", "org-north", "TERMINAL", "STORE-N-01", []RoleScope{rs("terminal", "loc:STORE-N-01")}},
		{"term-n01-2", "org-north", "TERMINAL", "STORE-N-01", []RoleScope{rs("terminal", "loc:STORE-N-01")}},
		{"pricing-mgr", "org-hq", "HUMAN", "", []RoleScope{rs("pricing-manager", "*")}},
		{"loyalty-op", "org-hq", "HUMAN", "", []RoleScope{rs("loyalty-operator", "*")}},
		{"payment-adapter-1", "org-hq", "SERVICE", "", []RoleScope{rs("payment-adapter", "*")}},
		{"finance-ctrl", "org-hq", "HUMAN", "", []RoleScope{rs("finance-controller", "*")}},
		{"migration-op", "org-hq", "HUMAN", "", []RoleScope{rs("migration-operator", "*")}},
		{"auditor-1", "org-hq", "HUMAN", "", []RoleScope{rs("auditor", "*")}},
	}
}

// Validator roles of the fictional group.
type ValSpec struct {
	ID, Org, Role string
}

var Validators = []ValSpec{
	{"val-hq", "org-hq", "HEADQUARTERS"},
	{"val-dist", "org-dist", "DISTRIBUTION"},
	{"val-north", "org-north", "REGIONAL"},
	{"val-south", "org-south", "REGIONAL"},
}

func DeterministicKey(id string) ed25519.PrivateKey {
	h := sha256.Sum256([]byte("aureom-chainbase-DEMO-ONLY/" + id))
	return ed25519.NewKeyFromSeed(h[:])
}

func Pub64(k ed25519.PrivateKey) string {
	return base64.StdEncoding.EncodeToString(k.Public().(ed25519.PublicKey))
}

// BuildGenesis assembles the genesis app state. pub maps identity id -> public key.
func BuildGenesis(networkID string, members []core.Member, pub map[string]ed25519.PublicKey) *core.Genesis {
	g := &core.Genesis{NetworkID: networkID, AppVersion: 1, Params: core.DefaultParams(), Members: members, Locations: Locations}
	for _, s := range Roster() {
		g.Identities = append(g.Identities, core.GenesisIdentity{ID: s.ID, Org: s.Org, Kind: s.Kind, KeyID: "k1",
			PubB64: base64.StdEncoding.EncodeToString(pub[s.ID]), BoundLoc: s.Bound})
		for _, r := range s.Roles {
			g.Grants = append(g.Grants, core.GenesisGrant{Identity: s.ID, Role: r.Role, Scope: r.Scope})
		}
	}
	return g
}

// TestMembers returns 4 validator members with deterministic consensus keys (tests only).
func TestMembers() []core.Member {
	var ms []core.Member
	for i, v := range Validators {
		k := DeterministicKey("consensus/" + v.ID)
		ms = append(ms, core.Member{ID: v.ID, Org: v.Org, Kind: "VALIDATOR", Role: v.Role, PubKey: Pub64(k),
			NodeID: nodeID(i), Power: 10, Status: "ACTIVE"})
	}
	return ms
}

func nodeID(i int) string {
	h := sha256.Sum256([]byte{byte(i), 'n'})
	const hex = "0123456789abcdef"
	out := make([]byte, 40)
	for j := 0; j < 20; j++ {
		out[2*j], out[2*j+1] = hex[h[j]>>4], hex[h[j]&15]
	}
	return string(out)
}

func TestGenesis(netID string) (*core.Genesis, map[string]ed25519.PrivateKey) {
	keys := map[string]ed25519.PrivateKey{}
	pubs := map[string]ed25519.PublicKey{}
	for _, s := range Roster() {
		k := DeterministicKey(s.ID)
		keys[s.ID] = k
		pubs[s.ID] = k.Public().(ed25519.PublicKey)
	}
	return BuildGenesis(netID, TestMembers(), pubs), keys
}
