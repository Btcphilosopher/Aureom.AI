package core

import (
	"strconv"
)

func init() {
	register("CreateProduct", "catalog.write", false, vCreateProduct, nil, execCreateProduct)
	register("UpdateProduct", "catalog.write", false, vUpdateProduct, nil, execUpdateProduct)
	register("CreateLocation", "location.write", false, vCreateLocation, nil, execCreateLocation)
	register("CreateSupplier", "supplier.write", false, vCreateSupplier, nil, execCreateSupplier)
	register("CreatePurchaseOrder", "po.create", false, vCreatePO, func(c *Ctx, p *CreatePOP) (string, *TxErr) { return p.LocationID, nil }, execCreatePO)
	register("ApprovePurchaseOrder", "po.approve", false, vIDOnly("po_id", func(p *ApprovePOP) string { return p.POID }), locOfPO, execApprovePO)
	register("ReceiveGoods", "goods.receive", false, vReceiveGoods, func(c *Ctx, p *ReceiveGoodsP) (string, *TxErr) { return p.LocationID, nil }, execReceiveGoods)
}

func vIDOnly[P any](name string, get func(*P) string) func(*P) *TxErr {
	return func(p *P) *TxErr {
		if !validID(get(p)) {
			return errf(CodeInvalidField, "%s invalid", name)
		}
		return nil
	}
}

// ---- Products ----

type VariantP struct {
	SKUID      string            `json:"sku_id"`
	Barcode    string            `json:"barcode"`
	Unit       string            `json:"unit"`
	Scarce     bool              `json:"scarce"`
	Attributes map[string]string `json:"attributes"`
}

type CreateProductP struct {
	ProductID  string            `json:"product_id"`
	Name       string            `json:"name"`
	Brand      string            `json:"brand"`
	Category   string            `json:"category"`
	Attributes map[string]string `json:"attributes"`
	Variants   []VariantP        `json:"variants"`
}

func vCreateProduct(p *CreateProductP) *TxErr {
	if !validID(p.ProductID) {
		return errf(CodeInvalidField, "product_id invalid")
	}
	for _, e := range []*TxErr{checkStr("name", p.Name, 120, true), checkStr("brand", p.Brand, 60, false), checkStr("category", p.Category, 60, false), checkAttrs("attributes", p.Attributes)} {
		if e != nil {
			return e
		}
	}
	if len(p.Variants) == 0 || len(p.Variants) > 50 {
		return errf(CodeLimit, "1..50 variants required")
	}
	for _, v := range p.Variants {
		if !validID(v.SKUID) || !validUnit(v.Unit) || len(v.Barcode) > 32 {
			return errf(CodeInvalidField, "variant %q invalid", v.SKUID)
		}
		if e := checkAttrs("variant.attributes", v.Attributes); e != nil {
			return e
		}
	}
	return nil
}

func execCreateProduct(c *Ctx, p *CreateProductP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KProduct + p.ProductID); ok {
		return nil, errf(CodeExists, "product %s exists", p.ProductID)
	}
	prod := Product{ID: p.ProductID, Name: p.Name, Brand: p.Brand, Category: p.Category, Status: "ACTIVE",
		Attributes: p.Attributes, Prov: Provenance{Origin: "NATIVE"}}
	for _, v := range p.Variants {
		if e := createSKU(c, &prod, v, nil, Provenance{Origin: "NATIVE"}); e != nil {
			return nil, e
		}
	}
	c.touch(&prod.Meta)
	putJSON(c.KV, KProduct+prod.ID, prod)
	return &Result{Data: map[string]any{"product_id": prod.ID, "skus": prod.SKUs, "version": prod.Version}}, nil
}

func createSKU(c *Ctx, prod *Product, v VariantP, extras map[string]string, prov Provenance) *TxErr {
	if _, ok := c.KV.Get(KSKU + v.SKUID); ok {
		return errf(CodeExists, "sku %s exists", v.SKUID)
	}
	if v.Barcode != "" {
		if _, ok := c.KV.Get(KBarcode + v.Barcode); ok {
			return errf(CodeExists, "barcode %s already assigned", v.Barcode)
		}
		c.KV.Set(KBarcode+v.Barcode, []byte(v.SKUID))
	}
	s := SKU{ID: v.SKUID, ProductID: prod.ID, Barcode: v.Barcode, Unit: v.Unit, Scarce: v.Scarce, Status: "ACTIVE",
		Attributes: v.Attributes, Extras: extras, Prov: prov}
	c.touch(&s.Meta)
	putJSON(c.KV, KSKU+s.ID, s)
	prod.SKUs = append(prod.SKUs, s.ID)
	return nil
}

type SKUUpdate struct {
	SKUID      string             `json:"sku_id"`
	Status     *string            `json:"status"`
	Scarce     *bool              `json:"scarce"`
	Barcode    *string            `json:"barcode"`
	Attributes *map[string]string `json:"attributes"`
}

type UpdateProductP struct {
	ProductID  string             `json:"product_id"`
	Name       *string            `json:"name"`
	Brand      *string            `json:"brand"`
	Category   *string            `json:"category"`
	Status     *string            `json:"status"`
	Attributes *map[string]string `json:"attributes"`
	SKUUpdates []SKUUpdate        `json:"sku_updates"`
}

func vUpdateProduct(p *UpdateProductP) *TxErr {
	if !validID(p.ProductID) {
		return errf(CodeInvalidField, "product_id invalid")
	}
	if len(p.SKUUpdates) > 50 {
		return errf(CodeLimit, "too many sku updates")
	}
	for _, s := range []*string{p.Name, p.Brand, p.Category} {
		if s != nil {
			if e := checkStr("field", *s, 120, false); e != nil {
				return e
			}
		}
	}
	for _, s := range []*string{p.Status} {
		if s != nil && *s != "ACTIVE" && *s != "DISCONTINUED" {
			return errf(CodeInvalidField, "status must be ACTIVE or DISCONTINUED")
		}
	}
	return nil
}

func execUpdateProduct(c *Ctx, p *UpdateProductP) (*Result, *TxErr) {
	var prod Product
	if ok, _ := getJSON(c.KV, KProduct+p.ProductID, &prod); !ok {
		return nil, errf(CodeNotFound, "product %s not found", p.ProductID)
	}
	if e := c.checkVersion(prod.Version); e != nil {
		return nil, e
	}
	if p.Name != nil {
		prod.Name = *p.Name
	}
	if p.Brand != nil {
		prod.Brand = *p.Brand
	}
	if p.Category != nil {
		prod.Category = *p.Category
	}
	if p.Status != nil {
		prod.Status = *p.Status
	}
	if p.Attributes != nil {
		if e := checkAttrs("attributes", *p.Attributes); e != nil {
			return nil, e
		}
		prod.Attributes = *p.Attributes
	}
	for _, u := range p.SKUUpdates {
		if !contains(prod.SKUs, u.SKUID) {
			return nil, errf(CodeNotFound, "sku %s is not a variant of %s", u.SKUID, prod.ID)
		}
		s, e := c.loadSKU(u.SKUID)
		if e != nil {
			return nil, e
		}
		if u.Status != nil {
			if *u.Status != "ACTIVE" && *u.Status != "DISCONTINUED" {
				return nil, errf(CodeInvalidField, "bad sku status")
			}
			s.Status = *u.Status
		}
		if u.Scarce != nil {
			s.Scarce = *u.Scarce
		}
		if u.Barcode != nil && *u.Barcode != s.Barcode {
			if len(*u.Barcode) > 32 {
				return nil, errf(CodeInvalidField, "barcode too long")
			}
			if *u.Barcode != "" {
				if _, ok := c.KV.Get(KBarcode + *u.Barcode); ok {
					return nil, errf(CodeExists, "barcode already assigned")
				}
				c.KV.Set(KBarcode+*u.Barcode, []byte(s.ID))
			}
			if s.Barcode != "" {
				c.KV.Delete(KBarcode + s.Barcode)
			}
			s.Barcode = *u.Barcode
		}
		if u.Attributes != nil {
			if e := checkAttrs("sku attributes", *u.Attributes); e != nil {
				return nil, e
			}
			s.Attributes = *u.Attributes
		}
		c.touch(&s.Meta)
		putJSON(c.KV, KSKU+s.ID, s)
	}
	c.touch(&prod.Meta)
	putJSON(c.KV, KProduct+prod.ID, prod)
	return &Result{Data: map[string]any{"product_id": prod.ID, "version": prod.Version}}, nil
}

// ---- Locations & suppliers ----

type CreateLocationP struct {
	LocationID string `json:"location_id"`
	Name       string `json:"name"`
	Kind       string `json:"kind"`
	Region     string `json:"region"`
	Currency   string `json:"currency"`
}

func vCreateLocation(p *CreateLocationP) *TxErr {
	if !validID(p.LocationID) || isExt(p.LocationID) || isTransit(p.LocationID) || p.LocationID == "*" {
		return errf(CodeInvalidField, "location_id invalid or reserved")
	}
	if p.Kind != "STORE" && p.Kind != "WAREHOUSE" {
		return errf(CodeInvalidField, "kind must be STORE or WAREHOUSE")
	}
	if !validCcy(p.Currency) {
		return errf(CodeInvalidField, "unknown currency")
	}
	if e := checkStr("name", p.Name, 120, true); e != nil {
		return e
	}
	return checkStr("region", p.Region, 40, true)
}

func execCreateLocation(c *Ctx, p *CreateLocationP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KLocation + p.LocationID); ok {
		return nil, errf(CodeExists, "location exists")
	}
	l := Location{ID: p.LocationID, Name: p.Name, Kind: p.Kind, Region: p.Region, Currency: p.Currency, Status: "ACTIVE", Prov: Provenance{Origin: "NATIVE"}}
	c.touch(&l.Meta)
	putJSON(c.KV, KLocation+l.ID, l)
	return &Result{Data: map[string]any{"location_id": l.ID}}, nil
}

type CreateSupplierP struct {
	SupplierID string `json:"supplier_id"`
	Name       string `json:"name"`
	Terms      string `json:"terms"`
}

func vCreateSupplier(p *CreateSupplierP) *TxErr {
	if !validID(p.SupplierID) {
		return errf(CodeInvalidField, "supplier_id invalid")
	}
	if e := checkStr("name", p.Name, 120, true); e != nil {
		return e
	}
	return checkStr("terms", p.Terms, 120, false)
}

func execCreateSupplier(c *Ctx, p *CreateSupplierP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KSupplier + p.SupplierID); ok {
		return nil, errf(CodeExists, "supplier exists")
	}
	s := Supplier{ID: p.SupplierID, Name: p.Name, Terms: p.Terms, Status: "ACTIVE", Prov: Provenance{Origin: "NATIVE"}}
	c.touch(&s.Meta)
	putJSON(c.KV, KSupplier+s.ID, s)
	return &Result{Data: map[string]any{"supplier_id": s.ID}}, nil
}

// ---- Purchase orders ----

type POLineP struct {
	SKU      string `json:"sku"`
	Qty      Qty    `json:"qty"`
	UnitCost int64  `json:"unit_cost_minor"`
}

type CreatePOP struct {
	POID       string    `json:"po_id"`
	SupplierID string    `json:"supplier_id"`
	LocationID string    `json:"location_id"`
	Currency   string    `json:"currency"`
	OrderedAt  int64     `json:"ordered_at_ms"`
	Lines      []POLineP `json:"lines"`
}

func vCreatePO(p *CreatePOP) *TxErr {
	if !validID(p.POID) || !validID(p.SupplierID) || !validID(p.LocationID) || !validCcy(p.Currency) {
		return errf(CodeInvalidField, "po_id/supplier_id/location_id/currency invalid")
	}
	if len(p.Lines) == 0 {
		return errf(CodeInvalidField, "at least one line required")
	}
	return nil
}

func execCreatePO(c *Ctx, p *CreatePOP) (*Result, *TxErr) {
	if len(p.Lines) > c.Params.MaxLines {
		return nil, errf(CodeLimit, "too many lines")
	}
	if _, ok := c.KV.Get(KPO + p.POID); ok {
		return nil, errf(CodeExists, "po exists")
	}
	var sup Supplier
	if ok, _ := getJSON(c.KV, KSupplier+p.SupplierID, &sup); !ok || sup.Status != "ACTIVE" {
		return nil, errf(CodeNotFound, "active supplier %s not found", p.SupplierID)
	}
	if _, e := c.loadLocation(p.LocationID); e != nil {
		return nil, e
	}
	if e := c.checkEffective(p.OrderedAt); e != nil {
		return nil, e
	}
	po := PurchaseOrder{ID: p.POID, SupplierID: p.SupplierID, LocationID: p.LocationID, Currency: p.Currency, Status: "DRAFT",
		CreatedBy: c.signer(), OrderedAt: p.OrderedAt, Prov: Provenance{Origin: "NATIVE"}}
	for i, l := range p.Lines {
		if _, e := c.qtyFor(l.SKU, l.Qty); e != nil {
			return nil, e
		}
		if l.UnitCost <= 0 || l.UnitCost > MaxMinor/1000 {
			return nil, errf(CodeInvalidField, "unit cost out of range")
		}
		po.Lines = append(po.Lines, POLine{LineNo: i + 1, SKU: l.SKU, Qty: l.Qty, UnitCost: l.UnitCost})
		po.TotalMinor += lineAmount(l.UnitCost, l.Qty)
	}
	if po.TotalMinor > MaxMinor {
		return nil, errf(CodeLimit, "po total out of range")
	}
	c.touch(&po.Meta)
	putJSON(c.KV, KPO+po.ID, po)
	return &Result{Data: map[string]any{"po_id": po.ID, "total_minor": po.TotalMinor, "version": po.Version}}, nil
}

type ApprovePOP struct {
	POID string `json:"po_id"`
}

func locOfPO(c *Ctx, p *ApprovePOP) (string, *TxErr) {
	var po PurchaseOrder
	if ok, _ := getJSON(c.KV, KPO+p.POID, &po); !ok {
		return "", errf(CodeNotFound, "po %s not found", p.POID)
	}
	return po.LocationID, nil
}

func execApprovePO(c *Ctx, p *ApprovePOP) (*Result, *TxErr) {
	var po PurchaseOrder
	getJSON(c.KV, KPO+p.POID, &po)
	if e := c.checkVersion(po.Version); e != nil {
		return nil, e
	}
	if po.Status != "DRAFT" {
		return nil, errf(CodeState, "po is %s", po.Status)
	}
	// approval policy: maker-checker + value limit escalation
	if po.CreatedBy == c.signer() {
		return nil, errf(CodePolicy, "separation of duties: creator cannot approve own purchase order")
	}
	if po.TotalMinor > c.Params.POLocalLimitMinor && !hasGlobalPerm(c.KV, c.signer(), "po.approve") {
		return nil, errf(CodePolicy, "po value %d exceeds local approval limit %d: global-scope approver required", po.TotalMinor, c.Params.POLocalLimitMinor)
	}
	po.Status, po.ApprovedBy = "APPROVED", c.signer()
	c.touch(&po.Meta)
	putJSON(c.KV, KPO+po.ID, po)
	return &Result{Data: map[string]any{"po_id": po.ID, "status": po.Status, "version": po.Version}}, nil
}

// ---- Goods receipt ----

type ReceiveGoodsP struct {
	ReceiptID   string        `json:"receipt_id"`
	LocationID  string        `json:"location_id"`
	POID        string        `json:"po_id"`
	SupplierID  string        `json:"supplier_id"`
	EffectiveAt int64         `json:"effective_at_ms"`
	Lines       []ReceiptLine `json:"lines"`
}

func vReceiveGoods(p *ReceiveGoodsP) *TxErr {
	if !validID(p.ReceiptID) || !validID(p.LocationID) {
		return errf(CodeInvalidField, "receipt_id/location_id invalid")
	}
	if p.POID == "" && !validID(p.SupplierID) {
		return errf(CodeInvalidField, "supplier_id required without a purchase order")
	}
	if len(p.Lines) == 0 {
		return errf(CodeInvalidField, "lines required")
	}
	return nil
}

func execReceiveGoods(c *Ctx, p *ReceiveGoodsP) (*Result, *TxErr) {
	if len(p.Lines) > c.Params.MaxLines {
		return nil, errf(CodeLimit, "too many lines")
	}
	if _, ok := c.KV.Get(KReceipt + p.ReceiptID); ok {
		return nil, errf(CodeExists, "receipt exists")
	}
	if _, e := c.loadLocation(p.LocationID); e != nil {
		return nil, e
	}
	if e := c.checkEffective(p.EffectiveAt); e != nil {
		return nil, e
	}
	var po PurchaseOrder
	hasPO := p.POID != ""
	if hasPO {
		if ok, _ := getJSON(c.KV, KPO+p.POID, &po); !ok {
			return nil, errf(CodeNotFound, "po not found")
		}
		if po.Status != "APPROVED" && po.Status != "PARTIALLY_RECEIVED" {
			return nil, errf(CodeState, "po is %s; only approved orders can be received", po.Status)
		}
		if po.LocationID != p.LocationID {
			return nil, errf(CodeArgument, "po delivers to %s", po.LocationID)
		}
	} else {
		var sup Supplier
		if ok, _ := getJSON(c.KV, KSupplier+p.SupplierID, &sup); !ok {
			return nil, errf(CodeNotFound, "supplier not found")
		}
	}
	rc := GoodsReceipt{ID: p.ReceiptID, POID: p.POID, SupplierID: p.SupplierID, LocationID: p.LocationID,
		Lines: p.Lines, EffectiveAt: p.EffectiveAt, ReceivedBy: c.signer()}
	if hasPO {
		rc.SupplierID = po.SupplierID
	}
	for _, l := range p.Lines {
		if _, e := c.qtyFor(l.SKU, l.Qty); e != nil {
			return nil, e
		}
		if hasPO {
			if l.POLine < 1 || l.POLine > len(po.Lines) || po.Lines[l.POLine-1].SKU != l.SKU {
				return nil, errf(CodeArgument, "po_line %d does not match sku %s", l.POLine, l.SKU)
			}
			pl := &po.Lines[l.POLine-1]
			if pl.ReceivedQty+l.Qty.V > pl.Qty.V {
				return nil, errf(CodeLimit, "receipt of %d exceeds outstanding %d on po line %d", l.Qty.V, pl.Qty.V-pl.ReceivedQty, l.POLine)
			}
			pl.ReceivedQty += l.Qty.V
		}
		if e := c.postMovement(l.SKU, LocSupplier, BAvail, p.LocationID, BAvail, l.Qty.V, "GOODS_RECEIPT", "GOODS_RECEIPT", p.ReceiptID, p.EffectiveAt, "NATIVE"); e != nil {
			return nil, e
		}
	}
	c.touch(&rc.Meta)
	putJSON(c.KV, KReceipt+rc.ID, rc)
	if hasPO {
		done := true
		for _, l := range po.Lines {
			if l.ReceivedQty < l.Qty.V {
				done = false
			}
		}
		po.Status = "PARTIALLY_RECEIVED"
		if done {
			po.Status = "RECEIVED"
		}
		po.Receipts = append(po.Receipts, rc.ID)
		c.touch(&po.Meta)
		putJSON(c.KV, KPO+po.ID, po)
	}
	return &Result{Data: map[string]any{"receipt_id": rc.ID, "lines": strconv.Itoa(len(p.Lines))}}, nil
}
