package core

import (
	"crypto/ed25519"
	"encoding/base64"
)

func init() {
	register("ReverseBusinessEntry", "reverse.entry", false, vReverse, locOfReverse, execReverse)
	register("ResolveException", "exception.resolve", false, vResolve, func(c *Ctx, p *ResolveP) (string, *TxErr) { return p.LocationID, nil }, execResolve)
	register("GrantRole", "iam.grant", false, vGrant, nil, execGrant)
	register("RevokeRole", "iam.grant", false, vGrant, nil, execRevokeRole)
	register("RegisterIdentity", "iam.admin", false, vRegisterIdentity, nil, execRegisterIdentity)
	register("RotateKey", "", false, vRotate, nil, execRotate)
	register("RevokeKey", "", false, vRevokeKey, nil, execRevokeKey)
}

// ---- Compensating transactions ----
//
// Nothing is ever edited in place. A correction is a new, linked entry; the original
// record stays visible (and its state at every earlier height stays queryable).

type ReverseP struct {
	ReversalID string `json:"reversal_id"`
	TargetType string `json:"target_type"` // LOYALTY_ENTRY | STOCK_ADJUSTMENT | GOODS_RECEIPT
	TargetID   string `json:"target_id"`
	Reason     string `json:"reason"`
	Points     int64  `json:"points"`    // LOYALTY_ENTRY: explicit points; 0 = derive from refund_id
	RefundID   string `json:"refund_id"` // LOYALTY_ENTRY: confirmed refund that triggers a proportional reversal
}

func vReverse(p *ReverseP) *TxErr {
	if !validID(p.ReversalID) || !validID(p.TargetID) || p.Points < 0 || (p.RefundID != "" && !validID(p.RefundID)) {
		return errf(CodeInvalidField, "fields invalid")
	}
	switch p.TargetType {
	case "LOYALTY_ENTRY", "STOCK_ADJUSTMENT", "GOODS_RECEIPT":
	default:
		return errf(CodeInvalidField, "unsupported target_type")
	}
	return checkStr("reason", p.Reason, 200, true)
}

func locOfReverse(c *Ctx, p *ReverseP) (string, *TxErr) {
	switch p.TargetType {
	case "LOYALTY_ENTRY":
		var e LoyaltyEntry
		if ok, _ := getJSON(c.KV, KLoyEntry+p.TargetID, &e); !ok {
			return "", errf(CodeNotFound, "loyalty entry not found")
		}
		if e.SaleID != "" {
			var s Sale
			if ok, _ := getJSON(c.KV, KSale+e.SaleID, &s); ok {
				return s.Loc, nil
			}
		}
		return "", nil
	case "STOCK_ADJUSTMENT":
		var a Adjustment
		if ok, _ := getJSON(c.KV, KAdjust+p.TargetID, &a); !ok {
			return "", errf(CodeNotFound, "adjustment not found")
		}
		return scopeLoc(c, a.Loc), nil
	default:
		var r GoodsReceipt
		if ok, _ := getJSON(c.KV, KReceipt+p.TargetID, &r); !ok {
			return "", errf(CodeNotFound, "receipt not found")
		}
		return r.LocationID, nil
	}
}

func execReverse(c *Ctx, p *ReverseP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KReversal + p.ReversalID); ok {
		return nil, errf(CodeExists, "reversal id exists")
	}
	res := map[string]any{"reversal_id": p.ReversalID, "target": p.TargetID}
	switch p.TargetType {
	case "LOYALTY_ENTRY":
		var e LoyaltyEntry
		getJSON(c.KV, KLoyEntry+p.TargetID, &e)
		if e.Type != "EARN" && e.Type != "REDEEM" {
			return nil, errf(CodeState, "only EARN or REDEEM entries can be reversed")
		}
		orig := e.Points
		if orig < 0 {
			orig = -orig
		}
		pts := p.Points
		if pts == 0 {
			if p.RefundID == "" || e.Type != "EARN" {
				return nil, errf(CodeArgument, "points or a confirmed refund_id is required")
			}
			var rf Refund
			if ok, _ := getJSON(c.KV, KRefund+p.RefundID, &rf); !ok || rf.Status != "CONFIRMED" {
				return nil, errf(CodeState, "refund must exist and be CONFIRMED (money actually returned)")
			}
			if rf.SaleID != e.SaleID {
				return nil, errf(CodeArgument, "refund belongs to a different sale")
			}
			var s Sale
			getJSON(c.KV, KSale+e.SaleID, &s)
			// cumulative proportional entitlement over ALL confirmed refunds of the sale
			pts = mulDivFloor(orig, s.RefundConf, s.Net) - e.ReversedPts
			if pts <= 0 {
				return nil, errf(CodeState, "nothing further to reverse for this refund")
			}
		}
		if e.ReversedPts+pts > orig {
			return nil, errf(CodeLimit, "reversal of %d exceeds remaining %d points", pts, orig-e.ReversedPts)
		}
		a, err := loadAccount(c, e.Account, false)
		if err != nil {
			return nil, err
		}
		var entry LoyaltyEntry
		entry.ID, entry.Type, entry.Reverses, entry.SaleID, entry.RefundID = p.ReversalID, "REVERSE", e.ID, e.SaleID, p.RefundID
		entry.EffectiveAt, entry.Rule, entry.Prov = c.BlockTimeMs, "reverse:"+p.Reason, Provenance{Origin: "NATIVE"}
		if e.Type == "EARN" {
			applied := pts
			if a.Points < applied {
				applied = a.Points
				entry.Shortfall = pts - applied
				openException(c, "LOYALTY_SHORTFALL", p.ReversalID, "reversal exceeds current points balance (points already redeemed)")
			}
			entry.Points = -applied
		} else {
			entry.Points = pts // reversing a redemption returns points
		}
		e.ReversedPts += pts
		c.touch(&e.Meta)
		putJSON(c.KV, KLoyEntry+e.ID, e)
		addEntry(c, a, entry)
		res["points_reversed"], res["balance"] = pts, a.Points
	case "STOCK_ADJUSTMENT":
		var a Adjustment
		getJSON(c.KV, KAdjust+p.TargetID, &a)
		if a.Status != "APPROVED" {
			return nil, errf(CodeState, "adjustment is %s", a.Status)
		}
		var e *TxErr
		if a.Delta > 0 {
			e = c.postMovement(a.SKU, a.Loc, a.Bucket, LocAdjust, BAvail, a.Delta, "ADJUSTMENT_REVERSAL", "ADJUSTMENT", a.ID, c.BlockTimeMs, "NATIVE")
		} else {
			e = c.postMovement(a.SKU, LocAdjust, BAvail, a.Loc, a.Bucket, -a.Delta, "ADJUSTMENT_REVERSAL", "ADJUSTMENT", a.ID, c.BlockTimeMs, "NATIVE")
		}
		if e != nil {
			return nil, e
		}
		a.Status = "REVERSED"
		c.touch(&a.Meta)
		putJSON(c.KV, KAdjust+a.ID, a)
	case "GOODS_RECEIPT":
		var r GoodsReceipt
		getJSON(c.KV, KReceipt+p.TargetID, &r)
		if r.Reversed {
			return nil, errf(CodeState, "receipt already reversed")
		}
		var po PurchaseOrder
		hasPO := r.POID != ""
		if hasPO {
			getJSON(c.KV, KPO+r.POID, &po)
		}
		for _, l := range r.Lines {
			if e := c.postMovement(l.SKU, r.LocationID, BAvail, LocSupplier, BAvail, l.Qty.V, "RECEIPT_REVERSAL", "GOODS_RECEIPT", r.ID, c.BlockTimeMs, "NATIVE"); e != nil {
				return nil, e
			}
			if hasPO {
				po.Lines[l.POLine-1].ReceivedQty -= l.Qty.V
			}
		}
		if hasPO {
			any := false
			for _, l := range po.Lines {
				if l.ReceivedQty > 0 {
					any = true
				}
			}
			po.Status = "APPROVED"
			if any {
				po.Status = "PARTIALLY_RECEIVED"
			}
			c.touch(&po.Meta)
			putJSON(c.KV, KPO+po.ID, po)
		}
		r.Reversed = true
		c.touch(&r.Meta)
		putJSON(c.KV, KReceipt+r.ID, r)
	}
	putJSON(c.KV, KReversal+p.ReversalID, map[string]any{"id": p.ReversalID, "target_type": p.TargetType, "target_id": p.TargetID,
		"reason": p.Reason, "by": c.signer(), "height": c.Height, "tx": c.Body.TxID})
	return &Result{Data: res}, nil
}

func mulDivFloor(a, b, d int64) int64 {
	if d == 0 {
		return 0
	}
	return new(bigInt).Div(new(bigInt).Mul(bigFrom(a), bigFrom(b)), bigFrom(d)).Int64()
}

// ---- Exceptions ----

type ResolveP struct {
	ExceptionID string `json:"exception_id"`
	LocationID  string `json:"location_id"`
	Resolution  string `json:"resolution"`
}

func vResolve(p *ResolveP) *TxErr {
	if !validID(p.ExceptionID) || (p.LocationID != "" && !validID(p.LocationID)) {
		return errf(CodeInvalidField, "ids invalid")
	}
	return checkStr("resolution", p.Resolution, 300, true)
}

func execResolve(c *Ctx, p *ResolveP) (*Result, *TxErr) {
	var e Exception
	if ok, _ := getJSON(c.KV, KException+p.ExceptionID, &e); !ok {
		return nil, errf(CodeNotFound, "exception not found")
	}
	if e.Status != "OPEN" {
		return nil, errf(CodeState, "exception is %s", e.Status)
	}
	e.Status, e.Resolution, e.ResolvedBy = "RESOLVED", p.Resolution, c.signer()
	c.touch(&e.Meta)
	putJSON(c.KV, KException+e.ID, e)
	return &Result{Data: map[string]any{"exception_id": e.ID, "status": e.Status}}, nil
}

// ---- Identity, roles, keys ----

type GrantP struct {
	IdentityID string `json:"identity_id"`
	Role       string `json:"role"`
	Scope      string `json:"scope"`
}

func vGrant(p *GrantP) *TxErr {
	if !validID(p.IdentityID) {
		return errf(CodeInvalidField, "identity_id invalid")
	}
	if _, ok := rolePerms[p.Role]; !ok {
		return errf(CodeInvalidField, "unknown role %q", p.Role)
	}
	if p.Scope != "*" && !(len(p.Scope) > 4 && p.Scope[:4] == "loc:" && validID(p.Scope[4:])) && !(len(p.Scope) > 7 && p.Scope[:7] == "region:" && validID(p.Scope[7:])) {
		return errf(CodeInvalidField, "scope must be *, loc:<id> or region:<name>")
	}
	return nil
}

func execGrant(c *Ctx, p *GrantP) (*Result, *TxErr) {
	if PrivilegedRoles[p.Role] {
		return nil, errf(CodePolicy, "role %s is privileged: grant it through a multi-organisation governance proposal", p.Role)
	}
	return grantRole(c, p.IdentityID, p.Role, p.Scope)
}

func grantRole(c *Ctx, id, role, scope string) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KIdentity + id); !ok {
		return nil, errf(CodeNotFound, "identity %s not registered", id)
	}
	if len(scope) > 4 && scope[:4] == "loc:" {
		if _, e := c.loadLocation(scope[4:]); e != nil {
			return nil, e
		}
	}
	g := loadGrants(c.KV, id)
	g.Identity = id
	for _, x := range g.Grants {
		if x.Role == role && x.Scope == scope {
			return nil, errf(CodeExists, "grant already exists")
		}
	}
	if len(g.Grants) >= 32 {
		return nil, errf(CodeLimit, "too many grants")
	}
	g.Grants = append(g.Grants, RoleGrant{Role: role, Scope: scope, GrantedH: c.Height, By: c.signer()})
	c.touch(&g.Meta)
	putJSON(c.KV, KGrants+id, g)
	return &Result{Data: map[string]any{"identity_id": id, "role": role, "scope": scope}}, nil
}

func execRevokeRole(c *Ctx, p *GrantP) (*Result, *TxErr) {
	if PrivilegedRoles[p.Role] {
		return nil, errf(CodePolicy, "role %s is privileged: revoke it through governance", p.Role)
	}
	return revokeRole(c, p.IdentityID, p.Role, p.Scope)
}

func revokeRole(c *Ctx, id, role, scope string) (*Result, *TxErr) {
	g := loadGrants(c.KV, id)
	out := g.Grants[:0:0]
	found := false
	for _, x := range g.Grants {
		if x.Role == role && x.Scope == scope {
			found = true
			continue
		}
		out = append(out, x)
	}
	if !found {
		return nil, errf(CodeNotFound, "grant not found")
	}
	g.Identity, g.Grants = id, out
	c.touch(&g.Meta)
	putJSON(c.KV, KGrants+id, g)
	return &Result{Data: map[string]any{"identity_id": id, "revoked": role}}, nil
}

type RegisterIdentityP struct {
	IdentityID string `json:"identity_id"`
	Org        string `json:"org"`
	Kind       string `json:"kind"`
	KeyID      string `json:"key_id"`
	PubB64     string `json:"pub_b64"`
	BoundLoc   string `json:"bound_location"`
}

func validPub(b64 string) *TxErr {
	b, err := base64.StdEncoding.DecodeString(b64)
	if err != nil || len(b) != ed25519.PublicKeySize {
		return errf(CodeInvalidField, "public key must be base64 ed25519 (32 bytes)")
	}
	return nil
}

func vRegisterIdentity(p *RegisterIdentityP) *TxErr {
	if !validID(p.IdentityID) || !validID(p.Org) || !validID(p.KeyID) || (p.BoundLoc != "" && !validID(p.BoundLoc)) {
		return errf(CodeInvalidField, "ids invalid")
	}
	if p.Kind != "HUMAN" && p.Kind != "SERVICE" && p.Kind != "TERMINAL" {
		return errf(CodeInvalidField, "kind must be HUMAN, SERVICE or TERMINAL")
	}
	return validPub(p.PubB64)
}

func execRegisterIdentity(c *Ctx, p *RegisterIdentityP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KIdentity + p.IdentityID); ok {
		return nil, errf(CodeExists, "identity exists")
	}
	if p.BoundLoc != "" {
		if _, e := c.loadLocation(p.BoundLoc); e != nil {
			return nil, e
		}
	}
	id := Identity{ID: p.IdentityID, Org: p.Org, Kind: p.Kind, Status: "ACTIVE", Location: p.BoundLoc,
		Keys: []KeyRec{{KeyID: p.KeyID, Pub: p.PubB64, Status: "ACTIVE", FromH: c.Height}}}
	c.touch(&id.Meta)
	putJSON(c.KV, KIdentity+id.ID, id)
	return &Result{Data: map[string]any{"identity_id": id.ID}}, nil
}

type RotateP struct {
	IdentityID string `json:"identity_id"`
	NewKeyID   string `json:"new_key_id"`
	NewPubB64  string `json:"new_pub_b64"`
	Reason     string `json:"reason"`
}

func vRotate(p *RotateP) *TxErr {
	if !validID(p.IdentityID) || !validID(p.NewKeyID) {
		return errf(CodeInvalidField, "ids invalid")
	}
	if e := validPub(p.NewPubB64); e != nil {
		return e
	}
	return checkStr("reason", p.Reason, 200, true)
}

// RotateKey: the identity rotates its own key (signed by the key being retired), or an
// iam.admin rotates on its behalf (lost-key recovery).
func execRotate(c *Ctx, p *RotateP) (*Result, *TxErr) {
	self := c.signer() == p.IdentityID
	if !self && authorize(c, c.signer(), "iam.admin", "") != nil {
		return nil, errf(CodeUnauthorized, "only the identity itself or an iam.admin may rotate keys")
	}
	var id Identity
	if ok, _ := getJSON(c.KV, KIdentity+p.IdentityID, &id); !ok {
		return nil, errf(CodeNotFound, "identity not found")
	}
	if len(id.Keys) >= 12 {
		return nil, errf(CodeLimit, "too many historical keys")
	}
	for _, k := range id.Keys {
		if k.KeyID == p.NewKeyID {
			return nil, errf(CodeExists, "key_id already used by this identity")
		}
	}
	for i := range id.Keys {
		if id.Keys[i].Status == "ACTIVE" && (!self || id.Keys[i].KeyID == c.Body.KeyID) {
			id.Keys[i].Status, id.Keys[i].ToH = "ROTATED", c.Height
		}
	}
	id.Keys = append(id.Keys, KeyRec{KeyID: p.NewKeyID, Pub: p.NewPubB64, Status: "ACTIVE", FromH: c.Height})
	c.touch(&id.Meta)
	putJSON(c.KV, KIdentity+id.ID, id)
	return &Result{Data: map[string]any{"identity_id": id.ID, "active_key": p.NewKeyID}}, nil
}

type RevokeKeyP struct {
	IdentityID string `json:"identity_id"`
	KeyID      string `json:"key_id"`
	Reason     string `json:"reason"`
}

func vRevokeKey(p *RevokeKeyP) *TxErr {
	if !validID(p.IdentityID) || !validID(p.KeyID) {
		return errf(CodeInvalidField, "ids invalid")
	}
	return checkStr("reason", p.Reason, 200, true)
}

func execRevokeKey(c *Ctx, p *RevokeKeyP) (*Result, *TxErr) {
	if c.signer() != p.IdentityID && authorize(c, c.signer(), "iam.admin", "") != nil {
		return nil, errf(CodeUnauthorized, "only the identity itself or an iam.admin may revoke keys")
	}
	var id Identity
	if ok, _ := getJSON(c.KV, KIdentity+p.IdentityID, &id); !ok {
		return nil, errf(CodeNotFound, "identity not found")
	}
	found := false
	for i := range id.Keys {
		if id.Keys[i].KeyID == p.KeyID && id.Keys[i].Status == "ACTIVE" {
			id.Keys[i].Status, id.Keys[i].ToH = "REVOKED", c.Height
			found = true
		}
	}
	if !found {
		return nil, errf(CodeNotFound, "active key not found")
	}
	c.touch(&id.Meta)
	putJSON(c.KV, KIdentity+id.ID, id)
	return &Result{Data: map[string]any{"identity_id": id.ID, "revoked_key": p.KeyID}}, nil
}
