package core

import (
	"encoding/json"
)

// Migration import. Imported records are HISTORICAL ASSERTIONS by the source system:
// each carries provenance (source system, source id, batch id, mapping version, snapshot id)
// and Origin=IMPORTED. Importing never fabricates native events (no reservations, payments or
// movements are invented for historical sales); opening balances are explicit OPENING_BALANCE
// movements from the EXT:MIGRATION counter-party. The window is opened and closed on-chain and
// closing requires attested reconciliation totals that match the chain's own counters.

func init() {
	register("ImportBatch", "import.batch", true, vImport, nil, execImport)
	register("MigrationControl", "migration.control", false, vMigControl, nil, execMigControl)
}

type ImportBatchP struct {
	BatchID        string            `json:"batch_id"`
	SourceSystem   string            `json:"source_system"`
	SnapshotID     string            `json:"snapshot_id"`
	MappingVersion string            `json:"mapping_version"`
	Entity         string            `json:"entity"`
	Seq            int               `json:"seq"`
	Records        []json.RawMessage `json:"records"`
}

func vImport(p *ImportBatchP) *TxErr {
	if !validID(p.BatchID) || !validID(p.SourceSystem) || !validID(p.SnapshotID) || !validID(p.MappingVersion) || len(p.Records) == 0 {
		return errf(CodeInvalidField, "batch fields invalid")
	}
	switch p.Entity {
	case "LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "OPENING_BALANCE", "OPEN_PO", "LOYALTY_OPENING", "HISTORICAL_SALE":
		return nil
	}
	return errf(CodeInvalidField, "unknown entity %q", p.Entity)
}

type impVariant struct {
	SourceID   string            `json:"source_id"` // optional: the variant's own source id (else the product's)
	SKUID      string            `json:"sku_id"`
	Barcode    string            `json:"barcode"`
	Unit       string            `json:"unit"`
	Scarce     bool              `json:"scarce"`
	Attributes map[string]string `json:"attributes"`
	Extras     map[string]string `json:"source_extras"`
}
type impProduct struct {
	SourceID   string            `json:"source_id"`
	ID         string            `json:"id"`
	Name       string            `json:"name"`
	Brand      string            `json:"brand"`
	Category   string            `json:"category"`
	Status     string            `json:"status"`
	Attributes map[string]string `json:"attributes"`
	Extras     map[string]string `json:"source_extras"`
	Variants   []impVariant      `json:"variants"`
}
type impLocation struct {
	SourceID string            `json:"source_id"`
	ID       string            `json:"id"`
	Name     string            `json:"name"`
	Kind     string            `json:"kind"`
	Region   string            `json:"region"`
	Currency string            `json:"currency"`
	Extras   map[string]string `json:"source_extras"`
}
type impSupplier struct {
	SourceID string            `json:"source_id"`
	ID       string            `json:"id"`
	Name     string            `json:"name"`
	Terms    string            `json:"terms"`
	Extras   map[string]string `json:"source_extras"`
}
type impPrice struct {
	SourceID string `json:"source_id"`
	ID       string `json:"id"`
	SKU      string `json:"sku"`
	Location string `json:"location"`
	Currency string `json:"currency"`
	Unit     int64  `json:"unit_minor"`
	From     int64  `json:"from_ms"`
	To       int64  `json:"to_ms"`
}
type impBalance struct {
	SourceID string `json:"source_id"`
	SKU      string `json:"sku"`
	Location string `json:"location"`
	Qty      Qty    `json:"qty"`
	Bucket   string `json:"bucket"`
}
type impPOLine struct {
	SKU      string `json:"sku"`
	Qty      Qty    `json:"qty"`
	UnitCost int64  `json:"unit_cost_minor"`
	Received int64  `json:"received_v"`
}
type impPO struct {
	SourceID   string            `json:"source_id"`
	ID         string            `json:"id"`
	SupplierID string            `json:"supplier_id"`
	Location   string            `json:"location"`
	Currency   string            `json:"currency"`
	OrderedAt  int64             `json:"ordered_at_ms"`
	Status     string            `json:"status"`
	Lines      []impPOLine       `json:"lines"`
	Extras     map[string]string `json:"source_extras"`
}
type impLoyalty struct {
	SourceID   string `json:"source_id"`
	CustomerID string `json:"customer_id"`
	Points     int64  `json:"points"`
}
type impSaleLine struct {
	SKU       string `json:"sku"`
	Qty       Qty    `json:"qty"`
	UnitMinor int64  `json:"unit_minor"`
	Gross     int64  `json:"gross_minor"`
	Net       int64  `json:"net_minor"`
}
type impSale struct {
	SourceID    string            `json:"source_id"`
	ID          string            `json:"id"`
	Location    string            `json:"location"`
	Channel     string            `json:"channel"`
	CustomerID  string            `json:"customer_id"`
	Currency    string            `json:"currency"`
	EffectiveAt int64             `json:"effective_at_ms"`
	Lines       []impSaleLine     `json:"lines"`
	PayStatus   string            `json:"payment_status"`
	PaidMinor   int64             `json:"paid_minor"`
	RefundMinor int64             `json:"refunded_minor"`
	Extras      map[string]string `json:"source_extras"`
}

func (c *Ctx) migState() MigrationState {
	var m MigrationState
	getJSON(c.KV, KMigState, &m)
	if m.Counters == nil {
		m.Counters = map[string]int64{}
	}
	return m
}

func execImport(c *Ctx, p *ImportBatchP) (*Result, *TxErr) {
	ms := c.migState()
	if ms.Status != "OPEN" {
		return nil, errf(CodeMigration, "migration window is %s", ms.Status)
	}
	if ms.SourceSystem != p.SourceSystem {
		return nil, errf(CodeMigration, "batch source %q differs from opened source %q", p.SourceSystem, ms.SourceSystem)
	}
	if len(p.Records) > c.Params.MaxImportRecords {
		return nil, errf(CodeLimit, "batch has %d records (max %d)", len(p.Records), c.Params.MaxImportRecords)
	}
	if _, ok := c.KV.Get(KMigBatch + p.BatchID); ok {
		return nil, errf(CodeExists, "batch %s already imported", p.BatchID)
	}
	prov := func(src string) Provenance {
		return Provenance{Origin: "IMPORTED", SourceSystem: p.SourceSystem, SourceID: src, BatchID: p.BatchID, MappingVersion: p.MappingVersion, SnapshotID: p.SnapshotID}
	}
	cnt := ms.Counters
	for _, raw := range p.Records {
		var err *TxErr
		switch p.Entity {
		case "LOCATION":
			var r impLocation
			if err = decRec(raw, &r); err == nil {
				err = importLocation(c, r, prov(r.SourceID))
				cnt["locations"]++
			}
		case "SUPPLIER":
			var r impSupplier
			if err = decRec(raw, &r); err == nil {
				if !validID(r.ID) {
					err = errf(CodeInvalidField, "supplier id")
				} else if _, ok := c.KV.Get(KSupplier + r.ID); ok {
					err = errf(CodeExists, "supplier %s exists", r.ID)
				} else {
					s := Supplier{ID: r.ID, Name: r.Name, Terms: r.Terms, Status: "ACTIVE", Extras: r.Extras, Prov: prov(r.SourceID)}
					c.touch(&s.Meta)
					putJSON(c.KV, KSupplier+s.ID, s)
					cnt["suppliers"]++
				}
			}
		case "PRODUCT":
			var r impProduct
			if err = decRec(raw, &r); err == nil {
				err = importProduct(c, r, prov(r.SourceID), cnt)
			}
		case "PRICE":
			var r impPrice
			if err = decRec(raw, &r); err == nil {
				err = importPrice(c, r, prov(r.SourceID))
				cnt["prices"]++
			}
		case "OPENING_BALANCE":
			var r impBalance
			if err = decRec(raw, &r); err == nil {
				err = importBalance(c, r, p.BatchID)
				cnt["opening_balance_units|"+r.Qty.Unit] += r.Qty.V
				cnt["opening_balance_rows"]++
			}
		case "OPEN_PO":
			var r impPO
			if err = decRec(raw, &r); err == nil {
				err = importPO(c, r, prov(r.SourceID), cnt)
			}
		case "LOYALTY_OPENING":
			var r impLoyalty
			if err = decRec(raw, &r); err == nil {
				err = importLoyalty(c, r, prov(r.SourceID))
				cnt["loyalty_accounts"]++
				cnt["loyalty_points"] += r.Points
			}
		case "HISTORICAL_SALE":
			var r impSale
			if err = decRec(raw, &r); err == nil {
				err = importSale(c, r, prov(r.SourceID), cnt)
			}
		}
		if err != nil {
			return nil, err
		}
	}
	ms.Batches++
	ms.Records += int64(len(p.Records))
	c.touch(&ms.Meta)
	putJSON(c.KV, KMigState, ms)
	putJSON(c.KV, KMigBatch+p.BatchID, map[string]any{"batch_id": p.BatchID, "entity": p.Entity, "seq": p.Seq, "records": len(p.Records),
		"snapshot_id": p.SnapshotID, "mapping_version": p.MappingVersion, "tx": c.Body.TxID, "height": c.Height})
	return &Result{Data: map[string]any{"batch_id": p.BatchID, "records": len(p.Records)}}, nil
}

// qtyForImport validates a quantity against its SKU for IMPORTED records: the SKU must exist and the unit must
// match, but (unlike native operations) a DISCONTINUED SKU is fine — legacy history and stock of discontinued
// products are legitimate assertions.
func (c *Ctx) qtyForImport(sku string, q Qty) *TxErr {
	if e := q.validate(); e != nil {
		return e
	}
	s, e := c.loadSKU(sku)
	if e != nil {
		return e
	}
	if s.Unit != q.Unit {
		return errf(CodeArgument, "sku %s is measured in %s, not %s", sku, s.Unit, q.Unit)
	}
	return nil
}

func decRec(raw json.RawMessage, v any) *TxErr {
	if err := strictJSON(raw, v); err != nil {
		return errf(CodeMalformed, "import record: %v", err)
	}
	return nil
}

func importLocation(c *Ctx, r impLocation, pv Provenance) *TxErr {
	if e := vCreateLocation(&CreateLocationP{LocationID: r.ID, Name: r.Name, Kind: r.Kind, Region: r.Region, Currency: r.Currency}); e != nil {
		return e
	}
	if _, ok := c.KV.Get(KLocation + r.ID); ok {
		return errf(CodeExists, "location %s exists", r.ID)
	}
	l := Location{ID: r.ID, Name: r.Name, Kind: r.Kind, Region: r.Region, Currency: r.Currency, Status: "ACTIVE", Extras: r.Extras, Prov: pv}
	c.touch(&l.Meta)
	putJSON(c.KV, KLocation+l.ID, l)
	return nil
}

func importProduct(c *Ctx, r impProduct, pv Provenance, cnt map[string]int64) *TxErr {
	cp := CreateProductP{ProductID: r.ID, Name: r.Name, Brand: r.Brand, Category: r.Category, Attributes: r.Attributes}
	for _, v := range r.Variants {
		cp.Variants = append(cp.Variants, VariantP{SKUID: v.SKUID, Barcode: v.Barcode, Unit: v.Unit, Scarce: v.Scarce, Attributes: v.Attributes})
	}
	if e := vCreateProduct(&cp); e != nil {
		return e
	}
	if r.Status != "ACTIVE" && r.Status != "DISCONTINUED" {
		return errf(CodeInvalidField, "product status")
	}
	if _, ok := c.KV.Get(KProduct + r.ID); ok {
		return errf(CodeExists, "product %s exists", r.ID)
	}
	prod := Product{ID: r.ID, Name: r.Name, Brand: r.Brand, Category: r.Category, Status: r.Status, Attributes: r.Attributes, Extras: r.Extras, Prov: pv}
	for _, v := range r.Variants {
		vp := pv
		if v.SourceID != "" {
			vp.SourceID = v.SourceID
		}
		if e := createSKU(c, &prod, VariantP{SKUID: v.SKUID, Barcode: v.Barcode, Unit: v.Unit, Scarce: v.Scarce, Attributes: v.Attributes}, v.Extras, vp); e != nil {
			return e
		}
		if r.Status == "DISCONTINUED" { // a discontinued product's variants are not sellable
			sk, _ := c.loadSKU(v.SKUID)
			sk.Status = "DISCONTINUED"
			putJSON(c.KV, KSKU+sk.ID, sk)
		}
		cnt["skus"]++
	}
	c.touch(&prod.Meta)
	putJSON(c.KV, KProduct+prod.ID, prod)
	cnt["products"]++
	return nil
}

func importPrice(c *Ctx, r impPrice, pv Provenance) *TxErr {
	pp := PublishPriceP{PriceID: r.ID, SKU: r.SKU, Location: r.Location, Currency: r.Currency, UnitMinor: r.Unit, From: r.From, To: r.To}
	if e := vPublishPrice(&pp); e != nil {
		return e
	}
	saved := c.Body.ExpectedVersion
	c.Body.ExpectedVersion = nil
	_, e := execPublishPrice(c, &pp)
	c.Body.ExpectedVersion = saved
	if e == nil { // imported prices carry provenance like every other imported record
		var pr Price
		getJSON(c.KV, KPrice+r.ID, &pr)
		pr.Prov = pv
		putJSON(c.KV, KPrice+r.ID, pr)
	}
	return e
}

func importBalance(c *Ctx, r impBalance, batch string) *TxErr {
	if r.Bucket == "" {
		r.Bucket = BAvail
	}
	if r.Bucket != BAvail && r.Bucket != BQuar && r.Bucket != BDamage {
		return errf(CodeInvalidField, "bucket")
	}
	if !validID(r.Location) {
		return errf(CodeInvalidField, "location")
	}
	if _, e := c.loadLocation(r.Location); e != nil {
		return e
	}
	if e := c.qtyForImport(r.SKU, r.Qty); e != nil {
		return e
	}
	return c.postMovement(r.SKU, LocMigration, BAvail, r.Location, r.Bucket, r.Qty.V, "OPENING_BALANCE", "MIGRATION_BATCH", batch, c.BlockTimeMs, "IMPORTED_OPENING")
}

func importPO(c *Ctx, r impPO, pv Provenance, cnt map[string]int64) *TxErr {
	if !validID(r.ID) || !validID(r.SupplierID) || !validCcy(r.Currency) || len(r.Lines) == 0 || len(r.Lines) > c.Params.MaxLines {
		return errf(CodeInvalidField, "po fields")
	}
	switch r.Status {
	case "DRAFT", "APPROVED", "PARTIALLY_RECEIVED":
	default:
		return errf(CodeInvalidField, "only outstanding purchase orders are imported (DRAFT, APPROVED, PARTIALLY_RECEIVED)")
	}
	if _, ok := c.KV.Get(KPO + r.ID); ok {
		return errf(CodeExists, "po exists")
	}
	if _, ok := c.KV.Get(KSupplier + r.SupplierID); !ok {
		return errf(CodeNotFound, "supplier %s", r.SupplierID)
	}
	if _, e := c.loadLocation(r.Location); e != nil {
		return e
	}
	po := PurchaseOrder{ID: r.ID, SupplierID: r.SupplierID, LocationID: r.Location, Currency: r.Currency, Status: r.Status, CreatedBy: "import:" + pv.SourceSystem,
		OrderedAt: r.OrderedAt, Extras: r.Extras, Prov: pv}
	if r.Status != "DRAFT" {
		po.ApprovedBy = "import:" + pv.SourceSystem
	}
	for i, l := range r.Lines {
		if e := c.qtyForImport(l.SKU, l.Qty); e != nil {
			return e
		}
		if l.Received < 0 || l.Received > l.Qty.V || l.UnitCost <= 0 {
			return errf(CodeInvalidField, "po line quantities")
		}
		po.Lines = append(po.Lines, POLine{LineNo: i + 1, SKU: l.SKU, Qty: l.Qty, UnitCost: l.UnitCost, ReceivedQty: l.Received})
		po.TotalMinor += lineAmount(l.UnitCost, l.Qty)
		cnt["po_outstanding_units|"+l.Qty.Unit] += l.Qty.V - l.Received
	}
	c.touch(&po.Meta)
	putJSON(c.KV, KPO+po.ID, po)
	cnt["open_pos"]++
	cnt["open_po_total_minor"] += po.TotalMinor
	return nil
}

func importLoyalty(c *Ctx, r impLoyalty, pv Provenance) *TxErr {
	if !reCustomer.MatchString(r.CustomerID) || r.Points < 0 || r.Points > MaxQty {
		return errf(CodeInvalidField, "customer_id must be synthetic/pseudonymous; points invalid")
	}
	if _, ok := c.KV.Get(KLoyalty + r.CustomerID); ok {
		return errf(CodeExists, "loyalty account exists")
	}
	a := &LoyaltyAccount{ID: r.CustomerID, Status: "ACTIVE", Prov: pv}
	addEntry(c, a, LoyaltyEntry{ID: "LE-OPEN-" + r.CustomerID, Type: "OPENING", Points: r.Points, EffectiveAt: c.BlockTimeMs, Rule: "opening balance imported from " + pv.SourceSystem, Prov: pv})
	return nil
}

func importSale(c *Ctx, r impSale, pv Provenance, cnt map[string]int64) *TxErr {
	if !validID(r.ID) || !validCcy(r.Currency) || len(r.Lines) == 0 || len(r.Lines) > c.Params.MaxLines || (r.Channel != "STORE" && r.Channel != "ECOM") {
		return errf(CodeInvalidField, "sale fields")
	}
	if r.CustomerID != "" && !reCustomer.MatchString(r.CustomerID) {
		return errf(CodeInvalidField, "customer id must be synthetic/pseudonymous")
	}
	if _, ok := c.KV.Get(KSale + r.ID); ok {
		return errf(CodeExists, "sale exists")
	}
	lc, e := c.loadLocation(r.Location)
	if e != nil {
		return e
	}
	if lc.Currency != r.Currency {
		return errf(CodeInvalidField, "sale currency %s differs from location currency %s", r.Currency, lc.Currency)
	}
	s := Sale{ID: r.ID, Loc: r.Location, Channel: r.Channel, CustomerID: r.CustomerID, Currency: r.Currency, EffectiveAt: r.EffectiveAt,
		BlockTime: c.BlockTimeMs, SaleStatus: "COMPLETED", PaymentStatus: r.PayStatus, FulfilmentStatus: "FULFILLED", PaymentMethod: "IMPORTED",
		Paid: r.PaidMinor, RefundConf: r.RefundMinor, Extras: r.Extras, Prov: pv}
	if r.EffectiveAt <= 0 || r.PaidMinor < 0 || r.RefundMinor < 0 {
		return errf(CodeInvalidField, "sale amounts/time")
	}
	for i, l := range r.Lines {
		if e := c.qtyForImport(l.SKU, l.Qty); e != nil { // SKU must exist and the unit must match
			return e
		}
		if l.Net < 0 || l.Gross < l.Net {
			return errf(CodeInvalidField, "sale line amounts")
		}
		s.Lines = append(s.Lines, SaleLine{LineNo: i + 1, SKU: l.SKU, Qty: l.Qty, UnitMinor: l.UnitMinor, Gross: l.Gross, Discount: l.Gross - l.Net, Net: l.Net, Steps: []PricingStep{}})
		s.Gross += l.Gross
		s.Net += l.Net
	}
	s.Discount = s.Gross - s.Net
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	cnt["historical_sales"]++
	cnt["historical_net_minor"] += s.Net
	cnt["historical_refunded_minor"] += s.RefundConf
	return nil
}

// ---- Migration window control ----

type MigControlP struct {
	Action       string           `json:"action"` // OPEN | CLOSE
	SourceSystem string           `json:"source_system"`
	ManifestHash string           `json:"manifest_hash"`
	ReportHash   string           `json:"report_hash"`
	FreezeMarker string           `json:"source_freeze_marker"`
	Totals       map[string]int64 `json:"totals"`
}

func vMigControl(p *MigControlP) *TxErr {
	if (p.Action != "OPEN" && p.Action != "CLOSE") || !validID(p.SourceSystem) {
		return errf(CodeInvalidField, "action/source_system invalid")
	}
	for _, v := range []string{p.ManifestHash, p.ReportHash, p.FreezeMarker} {
		if e := checkStr("hash/marker", v, 200, false); e != nil {
			return e
		}
	}
	return checkAttrsInt(p.Totals)
}

func checkAttrsInt(m map[string]int64) *TxErr {
	if len(m) > 60 {
		return errf(CodeLimit, "too many totals")
	}
	return nil
}

func execMigControl(c *Ctx, p *MigControlP) (*Result, *TxErr) {
	ms := c.migState()
	switch p.Action {
	case "OPEN":
		if ms.Status != "NOT_STARTED" {
			return nil, errf(CodeMigration, "window is %s", ms.Status)
		}
		ms.Status, ms.SourceSystem, ms.OpenedH, ms.OpenManifest = "OPEN", p.SourceSystem, c.Height, p.ManifestHash
	case "CLOSE":
		if ms.Status != "OPEN" || ms.SourceSystem != p.SourceSystem {
			return nil, errf(CodeMigration, "window is %s", ms.Status)
		}
		if p.ReportHash == "" || p.FreezeMarker == "" {
			return nil, errf(CodeMigration, "report_hash and source_freeze_marker are required to close")
		}
		// the attested reconciliation totals must equal the chain's own counters
		// EVERY chain counter must be attested and equal; unknown extra keys are refused too. An empty
		// attestation therefore cannot close the window.
		keys := make([]string, 0, len(ms.Counters)+len(p.Totals))
		seen := map[string]bool{}
		for k := range ms.Counters {
			keys, seen[k] = append(keys, k), true
		}
		for k := range p.Totals {
			if !seen[k] {
				keys = append(keys, k)
			}
		}
		sortStrings(keys)
		for _, k := range keys {
			got, attested := p.Totals[k]
			if !attested {
				return nil, errf(CodeMigration, "counter %s=%d is not attested: every chain counter must be reconciled before close", k, ms.Counters[k])
			}
			if ms.Counters[k] != got {
				return nil, errf(CodeMigration, "attested total %s=%d but chain counted %d", k, got, ms.Counters[k])
			}
		}
		if e := checkStr("report_hash", p.ReportHash, 128, true); e != nil {
			return nil, e
		}
		if e := checkStr("source_freeze_marker", p.FreezeMarker, 200, true); e != nil {
			return nil, e
		}
		ms.Status, ms.ClosedH, ms.ReportHash, ms.Attested, ms.FreezeMarker = "CLOSED", c.Height, p.ReportHash, p.Totals, p.FreezeMarker
	}
	c.touch(&ms.Meta)
	putJSON(c.KV, KMigState, ms)
	return &Result{Data: map[string]any{"status": ms.Status}}, nil
}
