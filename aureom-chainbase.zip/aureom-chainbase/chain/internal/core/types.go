package core

import "encoding/json"

const (
	SchemaVersion = 1
	// Pseudo locations used as the counter-party of every movement so that the
	// ledger conserves quantity (sum over all locations and buckets == 0).
	LocSupplier  = "EXT:SUPPLIER"
	LocCustomer  = "EXT:CUSTOMER"
	LocAdjust    = "EXT:ADJUST"
	LocMigration = "EXT:MIGRATION"
	TransitPfx   = "TRANSIT:"
)

// Bucket names for balances.
const (
	BAvail  = "available"
	BResv   = "reserved"
	BQuar   = "quarantined"
	BDamage = "damaged"
)

// Meta is embedded (flattened) in every versioned record.
type Meta struct {
	Version   int64  `json:"version"`
	Schema    int    `json:"schema_version"`
	CreatedH  int64  `json:"created_height"`
	UpdatedH  int64  `json:"updated_height"`
	CreatedTx string `json:"created_tx"`
	UpdatedTx string `json:"updated_tx"`
}

// Provenance distinguishes natively witnessed records from imported historical assertions.
type Provenance struct {
	Origin         string `json:"origin"` // NATIVE | IMPORTED
	SourceSystem   string `json:"source_system,omitempty"`
	SourceID       string `json:"source_id,omitempty"`
	BatchID        string `json:"batch_id,omitempty"`
	MappingVersion string `json:"mapping_version,omitempty"`
	SnapshotID     string `json:"snapshot_id,omitempty"`
}

type Product struct {
	ID         string            `json:"id"`
	Name       string            `json:"name"`
	Brand      string            `json:"brand,omitempty"`
	Category   string            `json:"category,omitempty"`
	Status     string            `json:"status"` // ACTIVE | DISCONTINUED
	Attributes map[string]string `json:"attributes,omitempty"`
	Extras     map[string]string `json:"source_extras,omitempty"` // unsupported source fields preserved verbatim
	SKUs       []string          `json:"skus"`
	Prov       Provenance        `json:"provenance"`
	Meta
}

type SKU struct {
	ID         string            `json:"id"`
	ProductID  string            `json:"product_id"`
	Barcode    string            `json:"barcode,omitempty"`
	Unit       string            `json:"unit"`
	Scarce     bool              `json:"scarce"` // scarce SKUs: offline sales require a pre-allocated allowance
	Status     string            `json:"status"`
	Attributes map[string]string `json:"attributes,omitempty"`
	Extras     map[string]string `json:"source_extras,omitempty"`
	Prov       Provenance        `json:"provenance"`
	Meta
}

type Location struct {
	ID       string            `json:"id"`
	Name     string            `json:"name"`
	Kind     string            `json:"kind"` // STORE | WAREHOUSE
	Region   string            `json:"region"`
	Currency string            `json:"currency"`
	Status   string            `json:"status"`
	Extras   map[string]string `json:"source_extras,omitempty"`
	Prov     Provenance        `json:"provenance"`
	Meta
}

type Supplier struct {
	ID     string            `json:"id"`
	Name   string            `json:"name"`
	Status string            `json:"status"`
	Terms  string            `json:"terms,omitempty"`
	Extras map[string]string `json:"source_extras,omitempty"`
	Prov   Provenance        `json:"provenance"`
	Meta
}

type POLine struct {
	LineNo      int    `json:"line_no"`
	SKU         string `json:"sku"`
	Qty         Qty    `json:"qty"`
	UnitCost    int64  `json:"unit_cost_minor"`
	ReceivedQty int64  `json:"received_v"`
}

type PurchaseOrder struct {
	ID         string            `json:"id"`
	SupplierID string            `json:"supplier_id"`
	LocationID string            `json:"location_id"` // delivery location
	Currency   string            `json:"currency"`
	Lines      []POLine          `json:"lines"`
	TotalMinor int64             `json:"total_minor"`
	Status     string            `json:"status"` // DRAFT | APPROVED | PARTIALLY_RECEIVED | RECEIVED | CANCELLED
	CreatedBy  string            `json:"created_by"`
	ApprovedBy string            `json:"approved_by,omitempty"`
	OrderedAt  int64             `json:"ordered_at_ms"`
	Receipts   []string          `json:"receipts,omitempty"`
	Extras     map[string]string `json:"source_extras,omitempty"`
	Prov       Provenance        `json:"provenance"`
	Meta
}

type ReceiptLine struct {
	SKU    string `json:"sku"`
	Qty    Qty    `json:"qty"`
	POLine int    `json:"po_line,omitempty"`
}

type GoodsReceipt struct {
	ID          string        `json:"id"`
	POID        string        `json:"po_id,omitempty"`
	SupplierID  string        `json:"supplier_id,omitempty"`
	LocationID  string        `json:"location_id"`
	Lines       []ReceiptLine `json:"lines"`
	EffectiveAt int64         `json:"effective_at_ms"`
	ReceivedBy  string        `json:"received_by"`
	Reversed    bool          `json:"reversed"`
	Meta
}

// Balance is the derived per (sku,location) inventory balance. It is only ever
// changed by applying a Movement.
type Balance struct {
	SKU         string `json:"sku"`
	Loc         string `json:"loc"`
	Available   int64  `json:"available"`
	Reserved    int64  `json:"reserved"`
	Quarantined int64  `json:"quarantined"`
	Damaged     int64  `json:"damaged"`
	LastMov     int64  `json:"last_movement_seq"`
	Meta
}

func (b *Balance) OnHand() int64 { return b.Available + b.Reserved + b.Quarantined + b.Damaged }

type Movement struct {
	Seq         int64  `json:"seq"`
	SKU         string `json:"sku"`
	FromLoc     string `json:"from_loc"`
	FromBucket  string `json:"from_bucket"`
	ToLoc       string `json:"to_loc"`
	ToBucket    string `json:"to_bucket"`
	Qty         int64  `json:"qty"`
	Reason      string `json:"reason"`
	RefType     string `json:"ref_type"`
	RefID       string `json:"ref_id"`
	TxID        string `json:"tx_id"`
	Height      int64  `json:"height"`
	EffectiveAt int64  `json:"effective_at_ms"`
	Origin      string `json:"origin"` // NATIVE | IMPORTED_OPENING
}

type Reservation struct {
	ID        string `json:"id"`
	SKU       string `json:"sku"`
	Loc       string `json:"loc"`
	Qty       int64  `json:"qty"`
	Unit      string `json:"unit"`
	Status    string `json:"status"` // ACTIVE | RELEASED | CONSUMED | EXPIRED
	Allowance bool   `json:"allowance"`
	Holder    string `json:"holder"`
	Terminal  string `json:"terminal_id,omitempty"`
	ExpiresAt int64  `json:"expires_at_ms"` // compared with BLOCK time
	SaleID    string `json:"sale_id,omitempty"`
	Consumed  int64  `json:"consumed_v"`
	Meta
}

type PricingStep struct {
	PromoID      string `json:"promo_id"`
	PromoVersion int64  `json:"promo_version"`
	Type         string `json:"type"`
	Before       int64  `json:"before_minor"`
	Discount     int64  `json:"discount_minor"`
	After        int64  `json:"after_minor"`
	Explain      string `json:"explain"`
}

type SaleLine struct {
	LineNo        int           `json:"line_no"`
	SKU           string        `json:"sku"`
	Qty           Qty           `json:"qty"`
	ReservationID string        `json:"reservation_id,omitempty"`
	PriceID       string        `json:"price_id"`
	PriceVersion  int64         `json:"price_version"`
	UnitMinor     int64         `json:"unit_minor"`
	Gross         int64         `json:"gross_minor"`
	Discount      int64         `json:"discount_minor"`
	Net           int64         `json:"net_minor"`
	Steps         []PricingStep `json:"pricing_steps"`
	ReturnedQty   int64         `json:"returned_v"`  // received back
	ReturningQty  int64         `json:"returning_v"` // requested/approved, not yet received
	RefundCommit  int64         `json:"refund_committed_minor"`
}

type PaymentEvent struct {
	Provider string `json:"provider"`
	EventID  string `json:"event_id"`
	Ref      string `json:"provider_ref"`
	Result   string `json:"result"`
	Amount   int64  `json:"amount_minor"`
	TxID     string `json:"tx_id"`
	Height   int64  `json:"height"`
}

type Sale struct {
	ID               string            `json:"id"`
	Loc              string            `json:"loc"`
	Channel          string            `json:"channel"`
	TerminalID       string            `json:"terminal_id,omitempty"`
	CustomerID       string            `json:"customer_id,omitempty"` // synthetic customer id
	Currency         string            `json:"currency"`
	Lines            []SaleLine        `json:"lines"`
	Gross            int64             `json:"gross_minor"`
	Discount         int64             `json:"discount_minor"`
	Net              int64             `json:"net_minor"`
	EffectiveAt      int64             `json:"effective_at_ms"` // business time claimed by the terminal
	BlockTime        int64             `json:"block_time_ms"`   // inclusion time agreed by validators (NOT the event time)
	RulesVer         uint64            `json:"rules_version"`
	SaleStatus       string            `json:"sale_status"`       // COMPLETED
	PaymentStatus    string            `json:"payment_status"`    // INSTRUCTED | PARTIALLY_PAID | CONFIRMED | FAILED | OVERPAID
	FulfilmentStatus string            `json:"fulfilment_status"` // FULFILLED | PARTIALLY_RETURNED | RETURNED
	PaymentMethod    string            `json:"payment_method"`
	Paid             int64             `json:"paid_minor"`
	RefundInstr      int64             `json:"refund_instructed_minor"`
	RefundConf       int64             `json:"refund_confirmed_minor"`
	PayEvents        []PaymentEvent    `json:"payment_events,omitempty"`
	LoyaltyEntry     string            `json:"loyalty_entry,omitempty"`
	Prov             Provenance        `json:"provenance"`
	Extras           map[string]string `json:"source_extras,omitempty"`
	Meta
}

type ReturnLine struct {
	LineNo      int    `json:"line_no"`
	Qty         int64  `json:"qty_v"`
	Reason      string `json:"reason"`
	Received    int64  `json:"received_v"`
	Inspection  string `json:"inspection,omitempty"` // last inspection outcome
	RefundMinor int64  `json:"refund_minor"`
}

type Return struct {
	ID          string       `json:"id"`
	SaleID      string       `json:"sale_id"`
	Loc         string       `json:"loc"`
	Lines       []ReturnLine `json:"lines"`
	Status      string       `json:"status"` // REQUESTED | APPROVED | REJECTED | PARTIALLY_RECEIVED | RECEIVED
	RequestedBy string       `json:"requested_by"`
	DecidedBy   string       `json:"decided_by,omitempty"`
	Override    string       `json:"override_reason,omitempty"`
	Refunds     []string     `json:"refunds,omitempty"`
	Meta
}

type Refund struct {
	ID       string `json:"id"`
	SaleID   string `json:"sale_id"`
	ReturnID string `json:"return_id"`
	Amount   int64  `json:"amount_minor"`
	Currency string `json:"currency"`
	Status   string `json:"status"` // INSTRUCTED | CONFIRMED | FAILED
	Provider string `json:"provider,omitempty"`
	Ref      string `json:"provider_ref,omitempty"`
	Meta
}

type PriceEntry struct {
	ID   string `json:"id"`
	From int64  `json:"from_ms"`
	To   int64  `json:"to_ms"` // 0 = open ended
	Unit int64  `json:"unit_minor"`
	Ver  int64  `json:"version"`
	Seq  int64  `json:"seq"`
}

type Price struct {
	ID       string     `json:"id"`
	SKU      string     `json:"sku"`
	Loc      string     `json:"loc"` // location id or "*"
	Currency string     `json:"currency"`
	Unit     int64      `json:"unit_minor"` // per whole unit of the SKU's unit
	From     int64      `json:"effective_from_ms"`
	To       int64      `json:"effective_to_ms"`
	Seq      int64      `json:"seq"`
	Prov     Provenance `json:"provenance"`
	Meta
}

type PriceBook struct {
	Version int64        `json:"version"`
	SKU     string       `json:"sku"`
	Loc     string       `json:"loc"`
	Entries []PriceEntry `json:"entries"`
}

type Promotion struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Type        string   `json:"type"` // PERCENT_OFF | AMOUNT_OFF_PER_UNIT | MULTIBUY_FIXED_PRICE
	Bp          int64    `json:"bp,omitempty"`
	OffMinor    int64    `json:"off_minor,omitempty"`
	BuyN        int64    `json:"buy_n,omitempty"`
	BundleMinor int64    `json:"bundle_minor,omitempty"`
	SKUs        []string `json:"skus"`
	Locs        []string `json:"locs"` // ["*"] for all
	From        int64    `json:"from_ms"`
	To          int64    `json:"to_ms"`
	Priority    int      `json:"priority"` // lower number = evaluated first
	Stackable   bool     `json:"stackable"`
	LoyaltyOnly bool     `json:"loyalty_only"`
	Status      string   `json:"status"` // ACTIVE | ENDED
	Currency    string   `json:"currency"`
	Meta
}

type PromoIndex struct {
	IDs []string `json:"ids"`
}

type LoyaltyAccount struct {
	ID      string     `json:"id"` // synthetic customer id, e.g. CUST-000123
	Points  int64      `json:"points"`
	Earned  int64      `json:"lifetime_earned"`
	Entries int64      `json:"entries"`
	Status  string     `json:"status"`
	Prov    Provenance `json:"provenance"`
	Meta
}

type LoyaltyEntry struct {
	ID          string     `json:"id"`
	Account     string     `json:"account"`
	Type        string     `json:"type"`   // EARN | REDEEM | EXPIRE | REVERSE | OPENING
	Points      int64      `json:"points"` // signed effect on balance
	SaleID      string     `json:"sale_id,omitempty"`
	RefundID    string     `json:"refund_id,omitempty"`
	Reverses    string     `json:"reverses,omitempty"`
	ReversedPts int64      `json:"reversed_points"`
	Shortfall   int64      `json:"shortfall_points,omitempty"`
	ValueMinor  int64      `json:"value_minor,omitempty"`
	EffectiveAt int64      `json:"effective_at_ms"`
	Rule        string     `json:"rule"`
	Prov        Provenance `json:"provenance"`
	Meta
}

type Adjustment struct {
	ID         string `json:"id"`
	SKU        string `json:"sku"`
	Loc        string `json:"loc"`
	Bucket     string `json:"bucket"`
	BalVersion int64  `json:"balance_version_at_count"`
	SystemQty  int64  `json:"system_qty"`
	CountedQty int64  `json:"counted_qty"`
	Delta      int64  `json:"delta"`
	Reason     string `json:"reason"`
	Evidence   string `json:"evidence_ref"`
	Status     string `json:"status"` // PENDING | APPROVED | REJECTED | REVERSED
	Proposer   string `json:"proposer"`
	Decider    string `json:"decider,omitempty"`
	Meta
}

type XferLine struct {
	SKU      string `json:"sku"`
	Sent     int64  `json:"sent_v"`
	Received int64  `json:"received_v"`
	Damaged  int64  `json:"damaged_v"`
	Unit     string `json:"unit"`
}

type Transfer struct {
	ID     string     `json:"id"`
	From   string     `json:"from"`
	To     string     `json:"to"`
	Lines  []XferLine `json:"lines"`
	Status string     `json:"status"` // IN_TRANSIT | RECEIVED | RECEIVED_WITH_DISCREPANCY
	Meta
}

type Exception struct {
	ID         string `json:"id"`
	Kind       string `json:"kind"` // PAYMENT_AMOUNT_MISMATCH | PAYMENT_OVERPAID | REFUND_FAILED | LOYALTY_SHORTFALL | TRANSFER_DISCREPANCY | PAYMENT_FAILED
	Ref        string `json:"ref"`
	Detail     string `json:"detail"`
	Status     string `json:"status"` // OPEN | RESOLVED
	Resolution string `json:"resolution,omitempty"`
	ResolvedBy string `json:"resolved_by,omitempty"`
	Meta
}

type KeyRec struct {
	KeyID  string `json:"key_id"`
	Pub    string `json:"pub_b64"`
	Status string `json:"status"` // ACTIVE | REVOKED | ROTATED
	FromH  int64  `json:"from_height"`
	ToH    int64  `json:"to_height"`
}

type Identity struct {
	ID       string   `json:"id"`
	Org      string   `json:"org"`
	Kind     string   `json:"kind"` // HUMAN | SERVICE | TERMINAL
	Keys     []KeyRec `json:"keys"`
	Status   string   `json:"status"` // ACTIVE | SUSPENDED
	Location string   `json:"bound_location,omitempty"`
	Meta
}

type RoleGrant struct {
	Role     string `json:"role"`
	Scope    string `json:"scope"` // "*" | "loc:<id>" | "region:<name>"
	GrantedH int64  `json:"granted_height"`
	By       string `json:"granted_by"`
}

type Grants struct {
	Identity string      `json:"identity"`
	Grants   []RoleGrant `json:"grants"`
	Meta
}

type TxRecord struct {
	ID         string `json:"id"`
	Type       string `json:"type"`
	Signer     string `json:"signer"`
	Status     string `json:"status"` // OK | REJECTED
	Code       uint32 `json:"code"`
	CodeName   string `json:"code_name"`
	Reason     string `json:"reason,omitempty"`
	Height     int64  `json:"height"`
	Index      int    `json:"index"`
	BlockTime  int64  `json:"block_time_ms"`
	ClientTime int64  `json:"client_time_ms"`
	Idem       string `json:"idempotency_ref"`
}

type IdemRecord struct {
	TxID   string `json:"tx_id"`
	Type   string `json:"type"`
	Height int64  `json:"height"`
}

type Member struct {
	ID       string   `json:"id"`
	Org      string   `json:"org"`
	Kind     string   `json:"kind"` // VALIDATOR | OBSERVER
	Role     string   `json:"role"` // HEADQUARTERS | DISTRIBUTION | REGIONAL | OBSERVER
	PubKey   string   `json:"consensus_pubkey_b64,omitempty"`
	NodeID   string   `json:"node_id"`
	Power    int64    `json:"power"`
	Status   string   `json:"status"` // ACTIVE | REMOVED
	AddedH   int64    `json:"added_height"`
	RemovedH int64    `json:"removed_height,omitempty"`
	History  []string `json:"history,omitempty"`
}

type Proposal struct {
	ID         string          `json:"id"`
	Kind       string          `json:"kind"`
	Payload    json.RawMessage `json:"payload"`
	Proposer   string          `json:"proposer"`
	Activation int64           `json:"activation_height"`
	Status     string          `json:"status"`    // PENDING | APPROVED | EXECUTED | EXPIRED | FAILED
	Approvals  []string        `json:"approvals"` // org ids
	ApprovedH  int64           `json:"approved_height"`
	ExecutedH  int64           `json:"executed_height"`
	Result     string          `json:"result,omitempty"`
	Meta
}

type QueueItem struct {
	Height int64  `json:"height"`
	Prop   string `json:"proposal"`
	Step   string `json:"step,omitempty"` // for scheduled follow-up steps
	Arg    string `json:"arg,omitempty"`
}

type Params struct {
	MaxTxBytes            int   `json:"max_tx_bytes"`
	MaxImportTxBytes      int   `json:"max_import_tx_bytes"`
	MaxLines              int   `json:"max_lines"`
	MaxImportRecords      int   `json:"max_import_records"`
	MaxFutureSkewMs       int64 `json:"max_future_skew_ms"`
	MaxBackdateMs         int64 `json:"max_backdate_ms"`
	MinGovDelayBlocks     int64 `json:"min_gov_delay_blocks"`
	MinUpgradeDelayBlocks int64 `json:"min_upgrade_delay_blocks"`
	MinValidators         int   `json:"min_validators"`
	POLocalLimitMinor     int64 `json:"po_local_limit_minor"` // above this a global-scope approver is required
	AdjustSmallUnits      int64 `json:"adjust_small_units"`   // |delta| above this needs global-scope approval
	ReturnLocalLimitMinor int64 `json:"return_local_limit_minor"`
	ReturnWindowMs        int64 `json:"return_window_ms"`
	ReservationMaxTTLMs   int64 `json:"reservation_max_ttl_ms"`
	AllowanceMaxTTLMs     int64 `json:"allowance_max_ttl_ms"`
	PointValueMinor       int64 `json:"loyalty_point_value_minor"` // value of 1 point in minor units of the sale currency (GBP: 1 = 1p)
}

func DefaultParams() Params {
	return Params{
		MaxTxBytes: 32 << 10, MaxImportTxBytes: 900 << 10, MaxLines: 100, MaxImportRecords: 400,
		MaxFutureSkewMs: 5 * 60_000, MaxBackdateMs: 3 * 24 * 3600_000,
		MinGovDelayBlocks: 3, MinUpgradeDelayBlocks: 10, MinValidators: 4,
		POLocalLimitMinor: 2_000_000, AdjustSmallUnits: 10, ReturnLocalLimitMinor: 50_000,
		ReturnWindowMs: 30 * 24 * 3600_000, ReservationMaxTTLMs: 30 * 60_000, AllowanceMaxTTLMs: 7 * 24 * 3600_000,
		PointValueMinor: 1,
	}
}

type MigrationState struct {
	Status       string           `json:"status"` // NOT_STARTED | OPEN | CLOSED
	SourceSystem string           `json:"source_system"`
	OpenedH      int64            `json:"opened_height"`
	ClosedH      int64            `json:"closed_height"`
	Batches      int64            `json:"batches"`
	Records      int64            `json:"records"`
	OpenManifest string           `json:"open_manifest_hash,omitempty"`
	ReportHash   string           `json:"reconciliation_report_hash,omitempty"`
	Counters     map[string]int64 `json:"chain_counters"`
	Attested     map[string]int64 `json:"attested_totals,omitempty"`
	FreezeMarker string           `json:"source_freeze_marker,omitempty"`
	Meta
}
