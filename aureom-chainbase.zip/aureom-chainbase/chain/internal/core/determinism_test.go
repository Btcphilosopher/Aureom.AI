package core_test

import (
	"fmt"
	"math/rand"
	"testing"

	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

// scenario produces a mixed, partly-failing workload (seeded) across many blocks.
func scenario(h *H, seed int64, blocks int, checkEvery bool) {
	rng := rand.New(rand.NewSource(seed))
	h.seedCatalog(60)
	h.mustOK("wh-manager-dist", "ReceiveGoods", m{"receipt_id": "GR-W", "location_id": "WH-DIST-01", "supplier_id": "SUP-1", "effective_at_ms": h.sim.TimeMs, "lines": []m{{"sku": "SKU-B", "qty": qty(50)}}})
	n := 0
	var resvs []string
	var sales []string
	for b := 0; b < blocks; b++ {
		var txs [][]byte
		for k := 0; k < 1+rng.Intn(8); k++ {
			n++
			id := fmt.Sprintf("%d", n)
			sku := []string{"SKU-A", "SKU-B"}[rng.Intn(2)]
			switch rng.Intn(9) {
			case 0, 1, 2:
				txs = append(txs, h.tx("cashier-n01", "ReserveStock", m{"reservation_id": "RS" + id, "location_id": "STORE-N-01", "sku": sku, "qty": qty(int64(1 + rng.Intn(4))), "ttl_ms": 600000}))
				resvs = append(resvs, "RS"+id)
			case 3:
				if len(resvs) > 0 {
					txs = append(txs, h.tx("cashier-n01", "ReleaseReservation", m{"reservation_id": resvs[rng.Intn(len(resvs))], "reason": "CANCELLED"}))
				}
			case 4, 5:
				if len(resvs) > 0 {
					r := resvs[rng.Intn(len(resvs))]
					// quantity guess may mismatch => rejected; fine
					q := int64(1 + rng.Intn(4))
					txs = append(txs, h.tx("cashier-n01", "CompleteSale", m{"sale_id": "S" + id, "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
						"lines": []m{{"sku": sku, "qty": qty(q), "reservation_id": r}}}))
					sales = append(sales, "S"+id)
				}
			case 6:
				txs = append(txs, h.tx("wh-operator-dist", "TransferStock", m{"op": "DISPATCH", "transfer_id": "X" + id, "from_location": "WH-DIST-01", "to_location": "STORE-N-01", "lines": []m{{"sku": "SKU-B", "qty": qty(int64(1 + rng.Intn(5)))}}}))
			case 7:
				txs = append(txs, h.tx("manager-n01", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "A" + id, "location_id": "STORE-N-01", "sku": sku, "bucket": "available", "counted_v": rng.Intn(20), "reason": "count", "evidence_ref": "e"}))
			case 8:
				if len(sales) > 0 {
					txs = append(txs, h.tx("payment-adapter-1", "RecordPaymentResult", m{"sale_id": sales[rng.Intn(len(sales))], "provider": "P", "event_id": "ev" + id, "provider_ref": "r", "result": "CONFIRMED", "amount_minor": 250, "currency": "GBP"}))
				}
			}
		}
		h.block(txs...)
		if checkEvery {
			h.checkInvariants()
		}
	}
}

// Conservation of inventory under a randomised workload with many failing transactions.
func TestInventoryConservationFuzz(t *testing.T) {
	for seed := int64(1); seed <= 5; seed++ {
		h := newH(t)
		scenario(h, seed, 120, true)
		okN, bad := 0, 0
		for _, b := range h.sim.Log {
			for _, c := range b.Codes {
				if c == 0 {
					okN++
				} else {
					bad++
				}
			}
		}
		if okN < 50 || bad < 10 {
			t.Fatalf("workload not exercising both outcomes: ok=%d rejected=%d", okN, bad)
		}
	}
}

// Deterministic replay: feeding the recorded blocks into a fresh state machine yields the same
// result codes per transaction and a byte-identical state digest.
func TestDeterministicReplay(t *testing.T) {
	h := newH(t)
	scenario(h, 42, 150, false)
	want := h.sim.Digest()
	g, _ := demo.TestGenesis(Net)
	fresh, err := core.NewSim(g, T0)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range h.sim.Log {
		fresh.Height, fresh.TimeMs = b.Height-1, b.TimeMs-1000
		br := fresh.Block(1000, b.Txs...)
		for i, r := range br.Results {
			if r.Code != b.Codes[i] {
				t.Fatalf("height %d tx %d: replay code %d != original %d", b.Height, i, r.Code, b.Codes[i])
			}
		}
	}
	if got := fresh.Digest(); got != want {
		t.Fatalf("replayed state digest %s != original %s", got, want)
	}
	if len(h.sim.Log) < 100 {
		t.Fatal("scenario too short")
	}
	t.Logf("replayed %d blocks; state digest %s", len(h.sim.Log), want[:16])
}

// Independent executions of the same blocks (e.g. on four validators) agree.
func TestAgreementAcrossExecutors(t *testing.T) {
	h := newH(t)
	scenario(h, 7, 60, false)
	digests := map[string]int{}
	for i := 0; i < 4; i++ {
		g, _ := demo.TestGenesis(Net)
		s, _ := core.NewSim(g, T0)
		for _, b := range h.sim.Log {
			s.Height, s.TimeMs = b.Height-1, b.TimeMs-1000
			s.Block(1000, b.Txs...)
		}
		digests[s.Digest()]++
	}
	if len(digests) != 1 {
		t.Fatalf("executors diverged: %v", digests)
	}
}
