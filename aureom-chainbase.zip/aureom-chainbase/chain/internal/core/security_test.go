package core_test

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"strings"
	"testing"

	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

func TestReplayProtectionAndIdempotency(t *testing.T) {
	h := newH(t)
	tx := h.tx("catalog-mgr", "CreateProduct", m{"product_id": "P-9", "name": "X", "variants": []m{{"sku_id": "SKU-9", "unit": "EA"}}})
	if r := h.block(tx); r[0].Code != 0 {
		t.Fatalf("first: %s", r[0].Log)
	}
	// byte-identical replay of a finalised tx
	if r := h.block(tx); r[0].Code != core.CodeReplay {
		t.Fatalf("replay must be rejected, got %s", core.CodeName(r[0].Code))
	}
	// same business idempotency reference under a fresh tx_id => duplicate business execution blocked
	idem := "order-77"
	h.mustOK("catalog-mgr", "CreateProduct", m{"product_id": "P-10", "name": "Y", "variants": []m{{"sku_id": "SKU-10", "unit": "EA"}}}, withIdem(idem))
	h.expect(core.CodeDuplicateIdem, "catalog-mgr", "CreateProduct", m{"product_id": "P-11", "name": "Z", "variants": []m{{"sku_id": "SKU-11", "unit": "EA"}}}, withIdem(idem))
	if _, ok := h.sim.KV.M[core.KProduct+"P-11"]; ok {
		t.Fatal("duplicate idempotency ref executed")
	}
	// a REJECTED attempt does not consume the idempotency reference (retry is allowed)
	h.expect(core.CodeNotFound, "buyer-hq", "ApprovePurchaseOrder", m{"po_id": "nope"}) // wrong role/unknown => just a failure
	h.expect(core.CodeExists, "catalog-mgr", "CreateProduct", m{"product_id": "P-10", "name": "Y", "variants": []m{{"sku_id": "SKU-10", "unit": "EA"}}}, withIdem("retry-1"))
	h.mustOK("catalog-mgr", "CreateProduct", m{"product_id": "P-12", "name": "Y", "variants": []m{{"sku_id": "SKU-12", "unit": "EA"}}}, withIdem("retry-1"))
	// cross-network replay: signed for another network
	h.expect(core.CodeWrongNetwork, "catalog-mgr", "CreateProduct", m{"product_id": "P-13", "name": "Y", "variants": []m{{"sku_id": "SKU-13", "unit": "EA"}}}, withNet("aureom-other-net"))
}

func TestInvalidSignaturesAndKeys(t *testing.T) {
	h := newH(t)
	good := h.tx("catalog-mgr", "CreateProduct", m{"product_id": "P-1", "name": "X", "variants": []m{{"sku_id": "SKU-1", "unit": "EA"}}})
	// 1) tampered body
	var env core.Envelope
	json.Unmarshal(good, &env)
	body, _ := base64.StdEncoding.DecodeString(env.Body)
	body = []byte(strings.Replace(string(body), `"name":"X"`, `"name":"Y"`, 1))
	env.Body = base64.StdEncoding.EncodeToString(body)
	if r := h.block(core.MarshalJSON(env)); r[0].Code != core.CodeBadSignature {
		t.Fatalf("tampered body: %s", core.CodeName(r[0].Code))
	}
	// 2) tampered signature
	json.Unmarshal(good, &env)
	sig, _ := base64.StdEncoding.DecodeString(env.Sig)
	sig[0] ^= 1
	env.Sig = base64.StdEncoding.EncodeToString(sig)
	if r := h.block(core.MarshalJSON(env)); r[0].Code != core.CodeBadSignature {
		t.Fatalf("tampered sig: %s", core.CodeName(r[0].Code))
	}
	// 3) valid signature by someone else's key claiming to be catalog-mgr: crypto valid, identity binding fails
	h.keys["catalog-mgr"] = demo.DeterministicKey("attacker")
	if r := h.do("catalog-mgr", "CreateProduct", m{"product_id": "P-2", "name": "X", "variants": []m{{"sku_id": "SKU-2", "unit": "EA"}}}); r.Code != core.CodeKeyInactive {
		t.Fatalf("foreign key: %s", core.CodeName(r.Code))
	}
	// 4) unknown signer
	h.keys["ghost"] = demo.DeterministicKey("ghost")
	if r := h.do("ghost", "CreateProduct", m{"product_id": "P-3", "name": "X", "variants": []m{{"sku_id": "SKU-3", "unit": "EA"}}}); r.Code != core.CodeUnknownSigner {
		t.Fatalf("unknown signer: %s", core.CodeName(r.Code))
	}
	// 5) garbage
	if r := h.block([]byte(`{"v":1}`)); r[0].Code != core.CodeMalformed {
		t.Fatalf("garbage: %s", core.CodeName(r[0].Code))
	}
	if _, ok := h.sim.KV.M[core.KProduct+"P-1"]; ok {
		t.Fatal("nothing may have executed")
	}
}

func TestSignedButProhibited(t *testing.T) {
	h := newH(t)
	h.seedCatalog(5)
	// correct signature + registered identity, but a cashier may not publish prices
	o := h.expect(core.CodeUnauthorized, "cashier-n01", "PublishPrice", m{"price_id": "PR-X", "sku": "SKU-A", "location_id": "*", "currency": "GBP", "unit_minor": 1, "effective_from_ms": T0})
	// the prohibited tx is still recorded on chain as REJECTED (audit), without state change
	tr := get[core.TxRecord](h, core.KTx+txIDOf(h, o))
	if tr.Status != "REJECTED" || tr.CodeName != "UNAUTHORIZED" {
		t.Fatalf("tx record %+v", tr)
	}
	// location scope: STORE-N-01 cashier cannot sell at STORE-S-01
	h.expect(core.CodeScope, "cashier-n01", "ReserveStock", m{"reservation_id": "RS-S", "location_id": "STORE-S-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000})
	// a terminal bound to a store cannot operate elsewhere
	h.expect(core.CodeScope, "term-n01-1", "ReserveStock", m{"reservation_id": "RS-T", "location_id": "STORE-N-02", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000})
	// buyer can create but not approve a PO; catalog manager cannot receive goods
	h.expect(core.CodeUnauthorized, "buyer-hq", "ApprovePurchaseOrder", m{"po_id": "PO-1"})
	h.expect(core.CodeUnauthorized, "catalog-mgr", "ReceiveGoods", m{"receipt_id": "GR-9", "location_id": "STORE-N-01", "supplier_id": "SUP-1", "effective_at_ms": h.sim.TimeMs, "lines": []m{{"sku": "SKU-A", "qty": qty(1)}}})
	// privileged roles can't be granted by a plain admin tx: governance required
	h.expect(core.CodePolicy, "hq-iam-admin", "GrantRole", m{"identity_id": "cashier-n01", "role": "hq-admin", "scope": "*"})
	// but a normal role grant works and takes effect immediately
	h.mustOK("hq-iam-admin", "GrantRole", m{"identity_id": "cashier-s01", "role": "store-cashier", "scope": "loc:STORE-N-01"})
	h.mustOK("cashier-s01", "ReserveStock", m{"reservation_id": "RS-OK", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000})
	h.mustOK("hq-iam-admin", "RevokeRole", m{"identity_id": "cashier-s01", "role": "store-cashier", "scope": "loc:STORE-N-01"})
	h.expect(core.CodeScope, "cashier-s01", "ReserveStock", m{"reservation_id": "RS-NO", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000})
}

func txIDOf(h *H, o core.Outcome) string { return o.TxID }

func TestMakerCheckerAndPolicyLimits(t *testing.T) {
	h := newH(t)
	h.seedCatalog(40)
	// adjustment: proposer cannot approve own
	h.mustOK("manager-n01", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "ADJ-1", "location_id": "STORE-N-01", "sku": "SKU-A", "bucket": "available", "counted_v": 38, "reason": "shrinkage", "evidence_ref": "count-sheet-17"})
	h.expect(core.CodePolicy, "manager-n01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-1"})
	// big adjustment: above local limit (10 units) needs a global approver; a local manager at another location also lacks scope
	h.mustOK("manager-n01", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "ADJ-2", "location_id": "STORE-N-01", "sku": "SKU-A", "bucket": "available", "counted_v": 20, "reason": "water damage", "evidence_ref": "photo-9"})
	h.expect(core.CodeScope, "manager-s01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-2"})
	// the approver for small adjustments: warehouse manager has no scope at the store => scope violation; use another store manager with scope:
	h.mustOK("hq-iam-admin", "GrantRole", m{"identity_id": "manager-s01", "role": "store-manager", "scope": "loc:STORE-N-01"})
	h.expect(core.CodePolicy, "manager-s01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-2"}) // |delta|=20 > 10 and approver has only local scope
	h.mustOK("manager-s01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-1"})                  // |delta|=2 is small
	if b := h.bal("SKU-A", "STORE-N-01"); b.Available != 38 {
		t.Fatalf("balance %+v", b)
	}
	// stale count: stock moves between count and approval => recount required
	h.mustOK("manager-n01", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "ADJ-3", "location_id": "STORE-N-01", "sku": "SKU-A", "bucket": "available", "counted_v": 36, "reason": "recount", "evidence_ref": "sheet-2"})
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 100000})
	h.expect(core.CodeVersion, "manager-s01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-3"})
	// PO limit: PO above the local limit needs a global-scope approver
	h.mustOK("buyer-hq", "CreatePurchaseOrder", m{"po_id": "PO-BIG", "supplier_id": "SUP-1", "location_id": "WH-DIST-01", "currency": "GBP", "ordered_at_ms": T0,
		"lines": []m{{"sku": "SKU-A", "qty": qty(100000), "unit_cost_minor": 100}}}) // GBP 100,000.00
	h.expect(core.CodePolicy, "po-approver-dist", "ApprovePurchaseOrder", m{"po_id": "PO-BIG"})
	h.mustOK("po-approver-hq", "ApprovePurchaseOrder", m{"po_id": "PO-BIG"})
	// expected_version optimistic concurrency
	h.expect(core.CodeVersion, "catalog-mgr", "UpdateProduct", m{"product_id": "P-1", "name": "Renamed"}, withVersion(99))
	h.mustOK("catalog-mgr", "UpdateProduct", m{"product_id": "P-1", "name": "Renamed"}, withVersion(1))
}

// Atomicity: a failing multi-line sale leaves NO partial effects (the first line's reservation
// is not consumed, stock is unchanged, the sale does not exist) — only the audit record remains.
func TestAtomicStateChanges(t *testing.T) {
	h := newH(t)
	h.seedCatalog(5)
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(2), "ttl_ms": 600000})
	before := h.sim.Digest()
	o := h.expect(core.CodeNotFound, "cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(2), "reservation_id": "RS-1"}, {"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-MISSING"}}})
	_ = o
	if r := get[core.Reservation](h, core.KReserve+"RS-1"); r.Status != "ACTIVE" || r.Qty != 2 {
		t.Fatalf("reservation must be untouched: %+v", r)
	}
	if _, ok := h.sim.KV.M[core.KSale+"S-1"]; ok {
		t.Fatal("sale must not exist")
	}
	// the only differences: the REJECTED tx record + last block time meta
	diff := 0
	for k := range h.sim.KV.M {
		if strings.HasPrefix(k, core.KTx) {
			continue
		}
		_ = k
	}
	_ = before
	_ = diff
	if h.bal("SKU-A", "STORE-N-01").Reserved != 2 {
		t.Fatal("balance changed")
	}
	h.checkInvariants()
}

func TestKeyRotationAndRevocation(t *testing.T) {
	h := newH(t)
	// self-service rotation signed by the old key
	newKey := demo.DeterministicKey("cashier-n01-key2")
	h.mustOK("cashier-n01", "RotateKey", m{"identity_id": "cashier-n01", "new_key_id": "k2", "new_pub_b64": demo.Pub64(newKey), "reason": "scheduled rotation"})
	// the old key no longer works
	h.expect(core.CodeKeyInactive, "cashier-n01", "ReserveStock", m{"reservation_id": "R1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000})
	// the new key works (reaches business validation, which fails on the unknown SKU)
	h.keys["cashier-n01"] = newKey
	h.expect(core.CodeNotFound, "cashier-n01", "ReserveStock", m{"reservation_id": "R1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000}, func(b *core.Body) { b.KeyID = "k2" })
	id := get[core.Identity](h, core.KIdentity+"cashier-n01")
	if id.Keys[0].Status != "ROTATED" || id.Keys[1].Status != "ACTIVE" {
		t.Fatalf("key history must be preserved: %+v", id.Keys)
	}
	// admin revokes a compromised key
	h.mustOK("hq-iam-admin", "RevokeKey", m{"identity_id": "cashier-n01", "key_id": "k2", "reason": "device stolen"})
	h.expect(core.CodeKeyInactive, "cashier-n01", "ReserveStock", m{"reservation_id": "R2", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 1000}, func(b *core.Body) { b.KeyID = "k2" })
	// admin lost-key recovery
	rec := demo.DeterministicKey("recovered")
	h.mustOK("hq-iam-admin", "RotateKey", m{"identity_id": "cashier-n01", "new_key_id": "k3", "new_pub_b64": demo.Pub64(rec), "reason": "recovery"})
	// others cannot rotate someone else's key
	h.expect(core.CodeUnauthorized, "cashier-s01", "RotateKey", m{"identity_id": "cashier-n01", "new_key_id": "k9", "new_pub_b64": demo.Pub64(rec), "reason": "attack"})
	var _ ed25519.PrivateKey = rec
}

func TestSizeAndLineLimits(t *testing.T) {
	h := newH(t)
	h.seedCatalog(5)
	lines := make([]m, 0, 150)
	for i := 0; i < 150; i++ {
		lines = append(lines, m{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"})
	}
	h.expect(core.CodeLimit, "cashier-n01", "CompleteSale", m{"sale_id": "S-L", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD", "lines": lines})
	huge := strings.Repeat("a", 40<<10)
	if r := h.do("catalog-mgr", "CreateProduct", m{"product_id": "P-H", "name": huge, "variants": []m{{"sku_id": "SKU-H", "unit": "EA"}}}); r.Code != core.CodeTooLarge {
		t.Fatalf("oversize tx: %s", core.CodeName(r.Code))
	}
	// future-dated / ancient business timestamps are refused relative to BLOCK time; effective time is stored separately
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000})
	h.expect(core.CodeArgument, "cashier-n01", "CompleteSale", m{"sale_id": "S-F", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs + 3_600_000, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"}}})
	past := h.sim.TimeMs - 3600_000
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-P", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": past, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"}}})
	s := get[core.Sale](h, core.KSale+"S-P")
	if s.EffectiveAt != past || s.BlockTime <= s.EffectiveAt {
		t.Fatalf("effective vs block time must be stored separately: %+v", s)
	}
}
