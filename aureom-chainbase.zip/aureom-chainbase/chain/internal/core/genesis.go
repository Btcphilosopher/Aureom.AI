package core

import "encoding/json"

type GenesisIdentity struct {
	ID       string `json:"id"`
	Org      string `json:"org"`
	Kind     string `json:"kind"`
	KeyID    string `json:"key_id"`
	PubB64   string `json:"pub_b64"`
	BoundLoc string `json:"bound_location,omitempty"`
}

type GenesisGrant struct {
	Identity string `json:"identity"`
	Role     string `json:"role"`
	Scope    string `json:"scope"`
}

type GenesisLocation struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Kind     string `json:"kind"`
	Region   string `json:"region"`
	Currency string `json:"currency"`
}

// Genesis is the application state in genesis.json (app_state). It is part of the
// chain: every node and every replay tool starts from exactly these bytes.
type Genesis struct {
	NetworkID  string            `json:"network_id"`
	AppVersion uint64            `json:"app_version"`
	Params     Params            `json:"params"`
	Members    []Member          `json:"members"`
	Identities []GenesisIdentity `json:"identities"`
	Grants     []GenesisGrant    `json:"grants"`
	Locations  []GenesisLocation `json:"locations"`
}

func ParseGenesis(raw []byte) (*Genesis, error) {
	var g Genesis
	if err := json.Unmarshal(raw, &g); err != nil {
		return nil, err
	}
	return &g, nil
}

// ApplyGenesis writes the initial state and returns the initial validator set.
func ApplyGenesis(kv KV, g *Genesis) ([]ValUpdate, *TxErr) {
	c := &Ctx{ChainID: g.NetworkID, Height: 0, KV: kv, Params: g.Params, Body: &Body{TxID: "genesis", Signer: "genesis"}}
	ver := g.AppVersion
	if ver == 0 {
		ver = 1
	}
	if _, ok := RulesFor(ver); !ok {
		return nil, errf(CodeInternal, "genesis app_version %d unsupported by this binary", ver)
	}
	putJSON(kv, KMeta+"appver", ver)
	putJSON(kv, KParams, g.Params)
	putJSON(kv, KMigState, MigrationState{Status: "NOT_STARTED", Counters: map[string]int64{}})
	var vals []ValUpdate
	for _, l := range g.Locations {
		loc := Location{ID: l.ID, Name: l.Name, Kind: l.Kind, Region: l.Region, Currency: l.Currency, Status: "ACTIVE", Prov: Provenance{Origin: "NATIVE"}}
		c.touch(&loc.Meta)
		putJSON(kv, KLocation+l.ID, loc)
	}
	for _, m := range g.Members {
		addMember(c, m)
		if m.Kind == "VALIDATOR" {
			vals = append(vals, ValUpdate{m.PubKey, m.Power})
		}
	}
	for _, gi := range g.Identities {
		id := Identity{ID: gi.ID, Org: gi.Org, Kind: gi.Kind, Status: "ACTIVE", Location: gi.BoundLoc, Keys: []KeyRec{{KeyID: gi.KeyID, Pub: gi.PubB64, Status: "ACTIVE"}}}
		c.touch(&id.Meta)
		putJSON(kv, KIdentity+gi.ID, id)
	}
	byID := map[string]*Grants{}
	var order []string
	for _, gr := range g.Grants {
		x, ok := byID[gr.Identity]
		if !ok {
			x = &Grants{Identity: gr.Identity}
			byID[gr.Identity] = x
			order = append(order, gr.Identity)
		}
		x.Grants = append(x.Grants, RoleGrant{Role: gr.Role, Scope: gr.Scope, By: "genesis"})
	}
	for _, id := range order {
		c.touch(&byID[id].Meta)
		putJSON(kv, KGrants+id, byID[id])
	}
	return vals, nil
}
