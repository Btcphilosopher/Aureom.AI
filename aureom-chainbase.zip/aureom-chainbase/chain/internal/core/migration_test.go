package core_test

import (
	"encoding/json"
	"testing"

	"github.com/aureom/chainbase/internal/core"
)

func TestMigrationWindowImportAndReconciliation(t *testing.T) {
	h := newH(t)
	// nothing can be imported before the window is opened
	batch := func(id, entity string, recs ...m) m {
		return m{"batch_id": id, "source_system": "legacy-erp", "snapshot_id": "snap-1", "mapping_version": "map-v1", "entity": entity, "seq": 1, "records": recs}
	}
	prod := m{"source_id": "42", "id": "P-42", "name": "Imported Kettle", "status": "ACTIVE", "source_extras": m{"loyalty_tier_colour": "teal"},
		"variants": []m{{"sku_id": "KET-1", "unit": "EA", "barcode": "123", "source_extras": m{"legacy_flag": "Y"}}}}
	h.expect(core.CodeMigration, "migration-op", "ImportBatch", batch("B1", "PRODUCT", prod))
	h.mustOK("migration-op", "MigrationControl", m{"action": "OPEN", "source_system": "legacy-erp", "manifest_hash": "abc"})
	h.mustOK("migration-op", "ImportBatch", batch("B1", "PRODUCT", prod))
	// batch ids are unique: re-sending the same batch cannot double-import
	h.expect(core.CodeExists, "migration-op", "ImportBatch", batch("B1", "PRODUCT", prod))
	// only the migration operator may import
	h.expect(core.CodeUnauthorized, "catalog-mgr", "ImportBatch", batch("B2", "PRODUCT", prod))
	p := get[core.Product](h, core.KProduct+"P-42")
	if p.Prov.Origin != "IMPORTED" || p.Prov.SourceID != "42" || p.Prov.BatchID != "B1" || p.Prov.MappingVersion != "map-v1" || p.Extras["loyalty_tier_colour"] != "teal" {
		t.Fatalf("provenance / unsupported fields must be preserved: %+v", p)
	}
	h.mustOK("migration-op", "ImportBatch", batch("B3", "OPENING_BALANCE", m{"source_id": "1", "sku": "KET-1", "location": "STORE-N-01", "qty": qty(5)}, m{"source_id": "2", "sku": "KET-1", "location": "WH-DIST-01", "qty": qty(20)}))
	h.mustOK("migration-op", "ImportBatch", batch("B4", "LOYALTY_OPENING", m{"source_id": "c1", "customer_id": "CUST-000001", "points": 120}))
	h.mustOK("migration-op", "ImportBatch", batch("B5", "HISTORICAL_SALE", m{"source_id": "s1", "id": "HS-1", "location": "STORE-N-01", "channel": "STORE", "customer_id": "CUST-000001", "currency": "GBP",
		"effective_at_ms": T0 - 86400000*40, "payment_status": "CONFIRMED", "paid_minor": 1000, "refunded_minor": 0, "lines": []m{{"sku": "KET-1", "qty": qty(1), "unit_minor": 1000, "gross_minor": 1000, "net_minor": 1000}}}))
	// historical sales invent NO native events: no movement, stock unchanged by the import of history
	if b := h.bal("KET-1", "STORE-N-01"); b.Available != 5 {
		t.Fatalf("history must not touch stock: %+v", b)
	}
	hs := get[core.Sale](h, core.KSale+"HS-1")
	if hs.Prov.Origin != "IMPORTED" || hs.Lines[0].ReservationID != "" || len(hs.PayEvents) != 0 {
		t.Fatalf("imported history is an assertion, not native events: %+v", hs)
	}
	// imported sale cannot be returned natively (no fabricated payment events)
	h.expect(core.CodeState, "cashier-n01", "RequestReturn", m{"return_id": "R-H", "sale_id": "HS-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "x"}}})
	// the opening balance movement is explicitly labelled
	var mov core.Movement
	json.Unmarshal(h.sim.KV.M[core.KMovement+"KET-1/"+"000000000001"], &mov)
	_ = mov
	ms := get[core.MigrationState](h, core.KMigState)
	if ms.Counters["opening_balance_units|EA"] != 25 || ms.Counters["loyalty_points"] != 120 || ms.Counters["historical_net_minor"] != 1000 || ms.Counters["products"] != 1 {
		t.Fatalf("counters %+v", ms.Counters)
	}
	// closing with WRONG attested totals is refused: the chain checks reconciliation itself
	h.expect(core.CodeMigration, "migration-op", "MigrationControl", m{"action": "CLOSE", "source_system": "legacy-erp", "report_hash": "r", "source_freeze_marker": "f", "totals": m{"loyalty_points": 121}})
	// a partial attestation cannot close the window: EVERY chain counter must be reconciled
	h.expect(core.CodeMigration, "migration-op", "MigrationControl", m{"action": "CLOSE", "source_system": "legacy-erp", "report_hash": "r", "source_freeze_marker": "f",
		"totals": m{"loyalty_points": 120, "products": 1, "opening_balance_units|EA": 25}})
	h.expect(core.CodeMigration, "migration-op", "MigrationControl", m{"action": "CLOSE", "source_system": "legacy-erp", "report_hash": "r", "source_freeze_marker": "f", "totals": m{}})
	all := m{}
	for k, v := range ms.Counters {
		all[k] = v
	}
	h.mustOK("migration-op", "MigrationControl", m{"action": "CLOSE", "source_system": "legacy-erp", "report_hash": "r", "source_freeze_marker": "f", "totals": all})
	// after cutover the import window is closed for good
	h.expect(core.CodeMigration, "migration-op", "ImportBatch", batch("B9", "PRODUCT", m{"source_id": "43", "id": "P-43", "name": "Late", "status": "ACTIVE", "variants": []m{{"sku_id": "L-1", "unit": "EA"}}}))
	h.expect(core.CodeMigration, "migration-op", "MigrationControl", m{"action": "OPEN", "source_system": "legacy-erp"})
	h.checkInvariants()
}

func TestMigrationRejectsRealPersonalIdentifiersAndBadRecords(t *testing.T) {
	h := newH(t)
	h.mustOK("migration-op", "MigrationControl", m{"action": "OPEN", "source_system": "legacy-erp"})
	b := func(id, entity string, recs ...m) m {
		return m{"batch_id": id, "source_system": "legacy-erp", "snapshot_id": "s", "mapping_version": "v1", "entity": entity, "seq": 1, "records": recs}
	}
	h.expect(core.CodeInvalidField, "migration-op", "ImportBatch", b("B1", "LOYALTY_OPENING", m{"source_id": "1", "customer_id": "jane.doe@example.com", "points": 5}))
	// atomic batch: one bad record rolls the whole batch back
	h.expect(core.CodeInvalidField, "migration-op", "ImportBatch", b("B2", "SUPPLIER", m{"source_id": "1", "id": "SUP-OK", "name": "A"}, m{"source_id": "2", "id": "bad id with spaces", "name": "B"}))
	if _, ok := h.sim.KV.M[core.KSupplier+"SUP-OK"]; ok {
		t.Fatal("partial batch applied")
	}
	// unknown fields are rejected (never silently dropped)
	h.expect(core.CodeMalformed, "migration-op", "ImportBatch", b("B3", "SUPPLIER", m{"source_id": "1", "id": "SUP-X", "name": "A", "credit_rating": "AAA"}))
}
