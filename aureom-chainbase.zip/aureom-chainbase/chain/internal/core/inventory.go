package core

import "strings"

func isExt(loc string) bool     { return strings.HasPrefix(loc, "EXT:") }
func isTransit(loc string) bool { return strings.HasPrefix(loc, TransitPfx) }

func balKey(sku, loc string) string { return KBalance + sku + "/" + loc }

func getBalance(kv KV, sku, loc string) Balance {
	var b Balance
	if ok, _ := getJSON(kv, balKey(sku, loc), &b); !ok {
		b = Balance{SKU: sku, Loc: loc}
	}
	return b
}

func bucketPtr(b *Balance, name string) *int64 {
	switch name {
	case BAvail:
		return &b.Available
	case BResv:
		return &b.Reserved
	case BQuar:
		return &b.Quarantined
	case BDamage:
		return &b.Damaged
	}
	return nil
}

// postMovement is the ONLY way balances change. It writes one ledger row and
// updates both balances. Physical locations can never go negative; EXT:* counter
// parties may, which is what makes Σ(all balances) == 0 an invariant (conservation).
func (c *Ctx) postMovement(sku, fromLoc, fromB, toLoc, toB string, qty int64, reason, refType, refID string, eff int64, origin string) *TxErr {
	if qty <= 0 {
		return errf(CodeArgument, "movement quantity must be positive")
	}
	from, to := getBalance(c.KV, sku, fromLoc), getBalance(c.KV, sku, toLoc)
	fp, tp := bucketPtr(&from, fromB), bucketPtr(&to, toB)
	if fp == nil || tp == nil {
		return errf(CodeArgument, "unknown bucket")
	}
	if fromLoc == toLoc && fromB == toB {
		return errf(CodeArgument, "movement is a no-op")
	}
	if !isExt(fromLoc) && *fp < qty {
		return errf(CodeInsufficient, "insufficient %s at %s for %s: have %d need %d", fromB, fromLoc, sku, *fp, qty)
	}
	seq := nextSeq(c.KV, "mov")
	m := Movement{Seq: seq, SKU: sku, FromLoc: fromLoc, FromBucket: fromB, ToLoc: toLoc, ToBucket: toB, Qty: qty,
		Reason: reason, RefType: refType, RefID: refID, TxID: c.Body.TxID, Height: c.Height, EffectiveAt: eff, Origin: origin}
	putJSON(c.KV, KMovement+sku+"/"+seq12(seq), m)
	if fromLoc == toLoc { // bucket change within one balance row
		fp = bucketPtr(&from, fromB)
		*fp -= qty
		*bucketPtr(&from, toB) += qty
		from.LastMov = seq
		c.touch(&from.Meta)
		putJSON(c.KV, balKey(sku, fromLoc), from)
		return nil
	}
	*fp -= qty
	*tp += qty
	from.LastMov, to.LastMov = seq, seq
	c.touch(&from.Meta)
	c.touch(&to.Meta)
	putJSON(c.KV, balKey(sku, fromLoc), from)
	putJSON(c.KV, balKey(sku, toLoc), to)
	return nil
}

func (c *Ctx) loadSKU(id string) (*SKU, *TxErr) {
	var s SKU
	if ok, err := getJSON(c.KV, KSKU+id, &s); err != nil {
		return nil, errf(CodeInternal, "%v", err)
	} else if !ok {
		return nil, errf(CodeNotFound, "sku %s not found", id)
	}
	return &s, nil
}

func (c *Ctx) loadLocation(id string) (*Location, *TxErr) {
	var l Location
	if ok, _ := getJSON(c.KV, KLocation+id, &l); !ok {
		return nil, errf(CodeNotFound, "location %s not found", id)
	}
	if l.Status != "ACTIVE" {
		return nil, errf(CodeState, "location %s is %s", id, l.Status)
	}
	return &l, nil
}

// qtyFor validates a Qty against its SKU unit.
func (c *Ctx) qtyFor(sku string, q Qty) (*SKU, *TxErr) {
	if e := q.validate(); e != nil {
		return nil, e
	}
	s, e := c.loadSKU(sku)
	if e != nil {
		return nil, e
	}
	if s.Status != "ACTIVE" {
		return nil, errf(CodeState, "sku %s is %s", sku, s.Status)
	}
	if s.Unit != q.Unit {
		return nil, errf(CodeArgument, "sku %s is measured in %s, not %s", sku, s.Unit, q.Unit)
	}
	return s, nil
}

// checkEffective bounds a business-effective timestamp relative to BLOCK time.
// The block time is only a loose ordering anchor agreed by validators; the effective
// time itself remains an assertion by the signer.
func (c *Ctx) checkEffective(ts int64) *TxErr {
	if ts <= 0 {
		return errf(CodeInvalidField, "effective_at_ms required")
	}
	if ts > c.BlockTimeMs+c.Params.MaxFutureSkewMs {
		return errf(CodeArgument, "effective_at_ms is in the future of block time")
	}
	if ts < c.BlockTimeMs-c.Params.MaxBackdateMs {
		return errf(CodeArgument, "effective_at_ms older than max backdate window")
	}
	return nil
}
