package core

import (
	"math/big"
)

// Currency exponents (minor units per major unit = 10^exp).
var currencyExp = map[string]int{"GBP": 2, "USD": 2, "EUR": 2, "JPY": 0}

// Unit precision: quantities are integers in the unit's smallest step.
// EA: each (scale 0). PK: pack (0). KG: stored in grams (3). L: stored in millilitres (3). M: millimetres (3).
var unitScale = map[string]int{"EA": 0, "PK": 0, "KG": 3, "L": 3, "M": 3}

const (
	MaxMinor int64 = 1_000_000_000_000 // 10^12 minor units: stays far below 2^53 for JS clients
	MaxQty   int64 = 1_000_000_000
)

type Money struct {
	Minor int64  `json:"minor"`
	Ccy   string `json:"ccy"`
}

// Qty carries an explicit unit. V is an integer count of the unit's smallest step.
type Qty struct {
	V    int64  `json:"v"`
	Unit string `json:"unit"`
}

func validCcy(c string) bool  { _, ok := currencyExp[c]; return ok }
func validUnit(u string) bool { _, ok := unitScale[u]; return ok }

func (m Money) validate(allowZero bool) *TxErr {
	if !validCcy(m.Ccy) {
		return errf(CodeInvalidField, "unknown currency %q", m.Ccy)
	}
	if m.Minor < 0 || m.Minor > MaxMinor || (!allowZero && m.Minor == 0) {
		return errf(CodeInvalidField, "money out of range")
	}
	return nil
}

func (q Qty) validate() *TxErr {
	if !validUnit(q.Unit) {
		return errf(CodeInvalidField, "unknown unit %q", q.Unit)
	}
	if q.V <= 0 || q.V > MaxQty {
		return errf(CodeInvalidField, "quantity must be 1..%d", MaxQty)
	}
	return nil
}

func pow10(n int) *big.Int { return new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(n)), nil) }

// mulDivHalfEven computes round_half_even(a*b/d) exactly with big integers.
func mulDivHalfEven(a, b, d int64) int64 {
	num := new(big.Int).Mul(big.NewInt(a), big.NewInt(b))
	return divHalfEven(num, big.NewInt(d))
}

func divHalfEven(num, den *big.Int) int64 {
	q, r := new(big.Int).QuoRem(num, den, new(big.Int))
	twice := new(big.Int).Mul(new(big.Int).Abs(r), big.NewInt(2))
	c := twice.Cmp(new(big.Int).Abs(den))
	if c > 0 || (c == 0 && q.Bit(0) == 1) {
		if num.Sign() >= 0 {
			q.Add(q, big.NewInt(1))
		} else {
			q.Sub(q, big.NewInt(1))
		}
	}
	return q.Int64()
}

// lineAmount = unit price (per whole unit) * quantity (in smallest steps) / 10^scale.
func lineAmount(unitMinor int64, q Qty) int64 {
	return mulDivHalfEven(unitMinor, q.V, pow10(unitScale[q.Unit]).Int64())
}
