package core

import (
	"math/big"
	"sort"
)

func sortStrings(s []string) { sort.Strings(s) }

func contains(s []string, v string) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

func addOnce(s []string, v string) []string {
	if contains(s, v) {
		return s
	}
	return append(s, v)
}

func removeStr(s []string, v string) []string {
	out := s[:0:0]
	for _, x := range s {
		if x != v {
			out = append(out, x)
		}
	}
	return out
}

func checkStr(name, s string, max int, required bool) *TxErr {
	if required && s == "" {
		return errf(CodeInvalidField, "%s is required", name)
	}
	if len(s) > max || !reLabel.MatchString(s) {
		return errf(CodeInvalidField, "%s invalid (printable ASCII, max %d)", name, max)
	}
	return nil
}

func checkAttrs(name string, m map[string]string) *TxErr {
	if len(m) > 20 {
		return errf(CodeLimit, "%s: max 20 entries", name)
	}
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sortStrings(keys)
	for _, k := range keys {
		v := m[k]
		if len(k) == 0 || len(k) > 40 || !reLabel.MatchString(k) || len(v) > 200 || !reLabel.MatchString(v) {
			return errf(CodeInvalidField, "%s: bad entry %q", name, k)
		}
	}
	return nil
}

type bigInt = big.Int

func bigFrom(n int64) *big.Int { return big.NewInt(n) }
