package core

import "fmt"

// Result codes. Families: 1x structure, 1xx crypto, 2xx identity/replay,
// 3xx authorisation, 4xx business. Code 0 is success.
const (
	CodeOK uint32 = 0

	CodeMalformed     uint32 = 1
	CodeTooLarge      uint32 = 2
	CodeWrongNetwork  uint32 = 3
	CodeUnknownType   uint32 = 4
	CodeBadSchema     uint32 = 5
	CodeInvalidField  uint32 = 6
	CodeBadSignature  uint32 = 101 // cryptographic validity
	CodeUnknownSigner uint32 = 201 // identity not registered
	CodeKeyInactive   uint32 = 202 // key unknown / revoked / rotated out
	CodeExpired       uint32 = 203 // valid_until_height passed
	CodeReplay        uint32 = 210 // tx_id already seen
	CodeDuplicateIdem uint32 = 211 // idempotency reference already executed
	CodeUnauthorized  uint32 = 301 // signer lacks permission (valid signature, prohibited action)
	CodeScope         uint32 = 302 // permission held but not for this location
	CodePolicy        uint32 = 303 // approval policy violated (separation of duties, limits)
	CodeNotFound      uint32 = 401
	CodeExists        uint32 = 402
	CodeVersion       uint32 = 403 // optimistic concurrency conflict
	CodeInsufficient  uint32 = 404 // insufficient available stock / points
	CodeState         uint32 = 405 // invalid state transition
	CodeLimit         uint32 = 406 // quantity / refund / size limits
	CodeArgument      uint32 = 407 // semantically invalid argument
	CodeMigration     uint32 = 408
	CodeInternal      uint32 = 500
)

var codeNames = map[uint32]string{
	0: "OK", 1: "MALFORMED", 2: "TOO_LARGE", 3: "WRONG_NETWORK", 4: "UNKNOWN_TYPE", 5: "UNSUPPORTED_SCHEMA",
	6: "INVALID_FIELD", 101: "BAD_SIGNATURE", 201: "UNKNOWN_SIGNER", 202: "KEY_INACTIVE", 203: "EXPIRED",
	210: "REPLAY", 211: "DUPLICATE_IDEMPOTENCY", 301: "UNAUTHORIZED", 302: "SCOPE_VIOLATION", 303: "POLICY_VIOLATION",
	401: "NOT_FOUND", 402: "ALREADY_EXISTS", 403: "VERSION_CONFLICT", 404: "INSUFFICIENT", 405: "INVALID_STATE",
	406: "LIMIT_EXCEEDED", 407: "INVALID_ARGUMENT", 408: "MIGRATION_WINDOW", 500: "INTERNAL",
}

func CodeName(c uint32) string {
	if n, ok := codeNames[c]; ok {
		return n
	}
	return fmt.Sprintf("CODE_%d", c)
}

// TxErr is a deterministic transaction rejection.
type TxErr struct {
	Code uint32
	Msg  string
}

func (e *TxErr) Error() string { return fmt.Sprintf("%s: %s", CodeName(e.Code), e.Msg) }

func errf(code uint32, f string, a ...any) *TxErr {
	return &TxErr{Code: code, Msg: fmt.Sprintf(f, a...)}
}
