package core_test

import (
	"testing"

	"github.com/aureom/chainbase/internal/core"
)

func TestFullLifecycleHappyPath(t *testing.T) {
	h := newH(t)
	h.seedCatalog(10)
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(3), "ttl_ms": 600000})
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "customer_id": "CUST-000001", "effective_at_ms": h.sim.TimeMs,
		"currency": "GBP", "payment_method": "CARD", "lines": []m{{"sku": "SKU-A", "qty": qty(3), "reservation_id": "RS-1"}}})
	// loyalty before payment confirmation is refused: instruction != confirmed payment
	h.expect(core.CodeState, "loyalty-op", "CreditLoyalty", m{"entry_id": "LE-1", "customer_id": "CUST-000001", "sale_id": "S-1"})
	// return before payment confirmation is refused
	h.expect(core.CodeState, "cashier-n01", "RequestReturn", m{"return_id": "R-0", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "x"}}})
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "SIMPAY", "event_id": "e1", "provider_ref": "ch1", "result": "CONFIRMED", "amount_minor": 750, "currency": "GBP"})
	h.mustOK("loyalty-op", "CreditLoyalty", m{"entry_id": "LE-1", "customer_id": "CUST-000001", "sale_id": "S-1"})
	if a := get[core.LoyaltyAccount](h, core.KLoyalty+"CUST-000001"); a.Points != 7 { // floor(7.50) * 1 point
		t.Fatalf("points %d", a.Points)
	}
	// duplicate loyalty credit refused
	h.expect(core.CodeExists, "loyalty-op", "CreditLoyalty", m{"entry_id": "LE-2", "customer_id": "CUST-000001", "sale_id": "S-1"})
	h.mustOK("cashier-n01", "RequestReturn", m{"return_id": "R-1", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "faulty seal"}}})
	// requester cannot approve own request (separation of duties) - cashier lacks permission anyway; manager approves
	h.mustOK("manager-n01", "ApproveReturn", m{"return_id": "R-1", "decision": "APPROVE"})
	o := h.mustOK("manager-n01", "ReceiveReturnedGoods", m{"return_id": "R-1", "lines": []m{{"line_no": 1, "qty_v": 1, "inspection": "RESELLABLE"}}})
	t.Logf("receive: %s", o.Data)
	rf := get[core.Refund](h, core.KRefund+"RF-R-1-001")
	if rf.Amount != 250 || rf.Status != "INSTRUCTED" {
		t.Fatalf("refund %+v", rf)
	}
	if s := get[core.Sale](h, core.KSale+"S-1"); s.RefundConf != 0 || s.RefundInstr != 250 || s.FulfilmentStatus != "PARTIALLY_RETURNED" {
		t.Fatalf("sale after instruction %+v", s)
	}
	// reversal of loyalty needs a CONFIRMED refund (money actually moved), not just an instruction
	h.expect(core.CodeState, "finance-ctrl", "ReverseBusinessEntry", m{"reversal_id": "REV-1", "target_type": "LOYALTY_ENTRY", "target_id": "LE-1", "refund_id": "RF-R-1-001", "reason": "refund"})
	h.mustOK("payment-adapter-1", "RecordRefundResult", m{"refund_id": "RF-R-1-001", "provider": "SIMPAY", "event_id": "rf1", "provider_ref": "re_1", "result": "CONFIRMED", "amount_minor": 250})
	h.mustOK("finance-ctrl", "ReverseBusinessEntry", m{"reversal_id": "REV-1", "target_type": "LOYALTY_ENTRY", "target_id": "LE-1", "refund_id": "RF-R-1-001", "reason": "refund of 1 of 3 units"})
	a := get[core.LoyaltyAccount](h, core.KLoyalty+"CUST-000001")
	// proportional: floor(7 * 250/750) = 2
	if a.Points != 5 {
		t.Fatalf("points after reversal %d", a.Points)
	}
	orig := get[core.LoyaltyEntry](h, core.KLoyEntry+"LE-1")
	if orig.Points != 7 || orig.ReversedPts != 2 {
		t.Fatalf("original entry must be preserved and linked: %+v", orig)
	}
	if b := h.bal("SKU-A", "STORE-N-01"); b.Available != 8 || b.OnHand() != 8 { // 10 -3 sold +1 returned
		t.Fatalf("stock %+v", b)
	}
	h.checkInvariants()
}

func TestRefundLimitsAndRounding(t *testing.T) {
	h := newH(t)
	h.seedCatalog(10)
	// 3 units @ 2.50 with a 10% promo => gross 750, discount 75, net 675; per-unit refund is not an integer
	h.mustOK("pricing-mgr", "ActivatePromotion", m{"promo_id": "PM-1", "name": "10% off", "type": "PERCENT_OFF", "bp": 1000, "skus": []string{"SKU-A"}, "locations": []string{"*"},
		"effective_from_ms": T0 - 1000, "effective_to_ms": 0, "priority": 10, "stackable": false, "status": "ACTIVE", "currency": "GBP"})
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(3), "ttl_ms": 600000})
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(3), "reservation_id": "RS-1"}}})
	s := get[core.Sale](h, core.KSale+"S-1")
	if s.Net != 675 || s.Discount != 75 || len(s.Lines[0].Steps) != 1 || s.Lines[0].Steps[0].PromoID != "PM-1" {
		t.Fatalf("pricing %+v", s)
	}
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "P", "event_id": "e1", "provider_ref": "c", "result": "CONFIRMED", "amount_minor": 675, "currency": "GBP"})
	// cannot request more than sold
	h.expect(core.CodeLimit, "cashier-n01", "RequestReturn", m{"return_id": "R-X", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 4, "reason": "x"}}})
	var total int64
	for i := 1; i <= 3; i++ {
		rid := "R-" + string(rune('0'+i))
		h.mustOK("cashier-n01", "RequestReturn", m{"return_id": rid, "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "changed mind"}}})
		h.mustOK("manager-n01", "ApproveReturn", m{"return_id": rid, "decision": "APPROVE"})
		h.mustOK("manager-n01", "ReceiveReturnedGoods", m{"return_id": rid, "lines": []m{{"line_no": 1, "qty_v": 1, "inspection": "RESELLABLE"}}})
		total += get[core.Refund](h, core.KRefund+"RF-"+rid+"-001").Amount
	}
	if total != 675 { // cumulative pro-rata: the sum of per-return refunds equals the line net EXACTLY
		t.Fatalf("refunds sum %d want 675", total)
	}
	// nothing left to return
	h.expect(core.CodeLimit, "cashier-n01", "RequestReturn", m{"return_id": "R-9", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "again"}}})
	if s := get[core.Sale](h, core.KSale+"S-1"); s.FulfilmentStatus != "RETURNED" || s.RefundInstr != 675 {
		t.Fatalf("sale %+v", s)
	}
	h.checkInvariants()
}

func TestReturnRejectedInspectionAndDamaged(t *testing.T) {
	h := newH(t)
	h.seedCatalog(5)
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(2), "ttl_ms": 600000})
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(2), "reservation_id": "RS-1"}}})
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "P", "event_id": "e1", "provider_ref": "c", "result": "CONFIRMED", "amount_minor": 500, "currency": "GBP"})
	h.mustOK("cashier-n01", "RequestReturn", m{"return_id": "R-1", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 2, "reason": "x"}}})
	h.mustOK("manager-n01", "ApproveReturn", m{"return_id": "R-1", "decision": "APPROVE"})
	h.mustOK("manager-n01", "ReceiveReturnedGoods", m{"return_id": "R-1", "lines": []m{{"line_no": 1, "qty_v": 1, "inspection": "DAMAGED"}}})
	h.mustOK("manager-n01", "ReceiveReturnedGoods", m{"return_id": "R-1", "lines": []m{{"line_no": 1, "qty_v": 1, "inspection": "REJECTED"}}})
	b := h.bal("SKU-A", "STORE-N-01")
	if b.Damaged != 1 || b.Available != 3 || b.OnHand() != 4 {
		t.Fatalf("damaged stock must be segregated and the rejected unit must not re-enter stock: %+v", b)
	}
	if r := get[core.Return](h, core.KReturn+"R-1"); r.Status != "RECEIVED" {
		t.Fatalf("return %+v", r)
	}
	if rf := get[core.Refund](h, core.KRefund+"RF-R-1-001"); rf.Amount != 250 { // only the accepted unit is refunded
		t.Fatalf("refund %+v", rf)
	}
	// a rejected-inspection unit is returnable again by the customer (it went back to them)
	h.mustOK("cashier-n01", "RequestReturn", m{"return_id": "R-2", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 1, "reason": "retry"}}})
	h.checkInvariants()
}
