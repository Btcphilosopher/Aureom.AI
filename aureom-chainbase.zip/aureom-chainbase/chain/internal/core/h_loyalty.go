package core

func init() {
	register("CreditLoyalty", "loyalty.credit", false, vCredit, locOfSale(func(p *CreditP) string { return p.SaleID }), execCredit)
	register("RedeemLoyalty", "loyalty.redeem", false, vRedeem, func(c *Ctx, p *RedeemP) (string, *TxErr) { return p.LocationID, nil }, execRedeem)
	register("ExpireLoyalty", "loyalty.expire", false, vExpire, nil, execExpire)
}

func loadAccount(c *Ctx, id string, create bool) (*LoyaltyAccount, *TxErr) {
	var a LoyaltyAccount
	if ok, _ := getJSON(c.KV, KLoyalty+id, &a); ok {
		return &a, nil
	}
	if !create {
		return nil, errf(CodeNotFound, "loyalty account %s not found", id)
	}
	return &LoyaltyAccount{ID: id, Status: "ACTIVE", Prov: Provenance{Origin: "NATIVE"}}, nil
}

func addEntry(c *Ctx, a *LoyaltyAccount, e LoyaltyEntry) {
	e.Account = a.ID
	c.touch(&e.Meta)
	putJSON(c.KV, KLoyEntry+e.ID, e)
	a.Points += e.Points
	if e.Type == "EARN" || e.Type == "OPENING" {
		a.Earned += e.Points
	}
	a.Entries++
	c.touch(&a.Meta)
	putJSON(c.KV, KLoyalty+a.ID, a)
}

type CreditP struct {
	EntryID    string `json:"entry_id"`
	CustomerID string `json:"customer_id"`
	SaleID     string `json:"sale_id"`
}

func vCredit(p *CreditP) *TxErr {
	if !validID(p.EntryID) || !reCustomer.MatchString(p.CustomerID) || !validID(p.SaleID) {
		return errf(CodeInvalidField, "entry_id/customer_id/sale_id invalid")
	}
	return nil
}

// Earn rule (version-gated): points = floor(net / 10^ccy_exp) * rules.LoyaltyPtsPerUnit.
// Credit requires CONFIRMED payment (not merely an instruction) and happens once per sale.
func execCredit(c *Ctx, p *CreditP) (*Result, *TxErr) {
	var s Sale
	getJSON(c.KV, KSale+p.SaleID, &s)
	if s.CustomerID != p.CustomerID {
		return nil, errf(CodeArgument, "sale belongs to a different customer reference")
	}
	if s.PaymentStatus != "CONFIRMED" {
		return nil, errf(CodeState, "loyalty is credited only on confirmed payment (payment is %s)", s.PaymentStatus)
	}
	if s.LoyaltyEntry != "" {
		return nil, errf(CodeExists, "sale already credited by %s", s.LoyaltyEntry)
	}
	if _, ok := c.KV.Get(KLoyEntry + p.EntryID); ok {
		return nil, errf(CodeExists, "entry id exists")
	}
	a, _ := loadAccount(c, p.CustomerID, true)
	units := s.Net / pow10(currencyExp[s.Currency]).Int64()
	pts := units * c.Rules.LoyaltyPtsPerUnit
	if pts <= 0 {
		return nil, errf(CodeArgument, "sale earns no points")
	}
	addEntry(c, a, LoyaltyEntry{ID: p.EntryID, Type: "EARN", Points: pts, SaleID: s.ID, EffectiveAt: s.EffectiveAt, Rule: "earn.v" + itoa(int64(c.Rules.Version)) + ".per_unit=" + itoa(c.Rules.LoyaltyPtsPerUnit), Prov: Provenance{Origin: "NATIVE"}})
	s.LoyaltyEntry = p.EntryID
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	return &Result{Data: map[string]any{"entry_id": p.EntryID, "points": pts, "balance": a.Points}}, nil
}

type RedeemP struct {
	EntryID       string `json:"entry_id"`
	CustomerID    string `json:"customer_id"`
	LocationID    string `json:"location_id"`
	Points        int64  `json:"points"`
	RedemptionRef string `json:"redemption_ref"` // unique per redemption: a second use is rejected
	SaleID        string `json:"sale_id"`
	EffectiveAt   int64  `json:"effective_at_ms"`
}

func vRedeem(p *RedeemP) *TxErr {
	if !validID(p.EntryID) || !reCustomer.MatchString(p.CustomerID) || !validID(p.LocationID) || !validID(p.RedemptionRef) || p.Points <= 0 || p.Points > MaxQty {
		return errf(CodeInvalidField, "fields invalid")
	}
	return nil
}

func execRedeem(c *Ctx, p *RedeemP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KLoyRef + p.RedemptionRef); ok {
		return nil, errf(CodeExists, "redemption %s already applied (duplicate redemption prevented)", p.RedemptionRef)
	}
	if _, ok := c.KV.Get(KLoyEntry + p.EntryID); ok {
		return nil, errf(CodeExists, "entry id exists")
	}
	if e := c.checkEffective(p.EffectiveAt); e != nil {
		return nil, e
	}
	a, e := loadAccount(c, p.CustomerID, false)
	if e != nil {
		return nil, e
	}
	if a.Points < p.Points {
		return nil, errf(CodeInsufficient, "balance %d < %d points", a.Points, p.Points)
	}
	c.KV.Set(KLoyRef+p.RedemptionRef, []byte(p.EntryID))
	addEntry(c, a, LoyaltyEntry{ID: p.EntryID, Type: "REDEEM", Points: -p.Points, SaleID: p.SaleID, ValueMinor: p.Points * c.Params.PointValueMinor, EffectiveAt: p.EffectiveAt, Rule: "redeem.point_value_minor=" + itoa(c.Params.PointValueMinor), Prov: Provenance{Origin: "NATIVE"}})
	return &Result{Data: map[string]any{"entry_id": p.EntryID, "balance": a.Points, "value_minor": p.Points * c.Params.PointValueMinor}}, nil
}

type ExpireP struct {
	EntryID    string `json:"entry_id"`
	CustomerID string `json:"customer_id"`
	Points     int64  `json:"points"`
	Reason     string `json:"reason"`
}

func vExpire(p *ExpireP) *TxErr {
	if !validID(p.EntryID) || !reCustomer.MatchString(p.CustomerID) || p.Points <= 0 || p.Points > MaxQty {
		return errf(CodeInvalidField, "fields invalid")
	}
	return checkStr("reason", p.Reason, 100, true)
}

func execExpire(c *Ctx, p *ExpireP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KLoyEntry + p.EntryID); ok {
		return nil, errf(CodeExists, "entry id exists")
	}
	a, e := loadAccount(c, p.CustomerID, false)
	if e != nil {
		return nil, e
	}
	if a.Points < p.Points {
		return nil, errf(CodeInsufficient, "cannot expire %d points from balance %d", p.Points, a.Points)
	}
	addEntry(c, a, LoyaltyEntry{ID: p.EntryID, Type: "EXPIRE", Points: -p.Points, EffectiveAt: c.BlockTimeMs, Rule: "expire:" + p.Reason, Prov: Provenance{Origin: "NATIVE"}})
	return &Result{Data: map[string]any{"entry_id": p.EntryID, "balance": a.Points}}, nil
}

func itoa(n int64) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
