package core

import (
	"bytes"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"reflect"
	"regexp"
)

// ---- Wire format -----------------------------------------------------------
//
// A transaction on the wire is a JSON Envelope. `body` is base64 of the exact bytes
// that were signed, so no cross-language JSON canonicalisation is required: every
// validator verifies the signature over the identical byte string and then parses it.
//
//   preimage = "AUREOM-CHAINBASE/TX/v1" 0x00 network_id 0x00 body_bytes
//   tx_id    = Body.tx_id (client chosen, unique per network)
//
// The signed network_id (also inside the body) gives cross-network replay protection.

const SigDomain = "AUREOM-CHAINBASE/TX/v1"

type Envelope struct {
	V    int    `json:"v"`
	Body string `json:"body"` // base64(body bytes)
	Sig  string `json:"sig"`  // base64(ed25519 signature)
	Pub  string `json:"pub"`  // base64(ed25519 public key) used for the signature
}

type Body struct {
	TxID            string          `json:"tx_id"`
	NetworkID       string          `json:"network_id"`
	Type            string          `json:"type"`
	SchemaVersion   int             `json:"schema_version"`
	Signer          string          `json:"signer"`
	KeyID           string          `json:"key_id"`
	Idempotency     string          `json:"idempotency_ref"`
	ExpectedVersion *int64          `json:"expected_version,omitempty"`
	ClientTimeMs    int64           `json:"client_time_ms"` // a claim by the signer; never trusted as event proof
	ValidUntil      int64           `json:"valid_until_height,omitempty"`
	Payload         json.RawMessage `json:"payload"`
}

var (
	reTxID  = regexp.MustCompile(`^[A-Za-z0-9_-]{8,64}$`)
	reID    = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$`)
	reIdem  = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$`)
	reLabel = regexp.MustCompile(`^[\x20-\x7e]{0,200}$`)
)

func validID(s string) bool { return reID.MatchString(s) }

func preimage(networkID string, body []byte) []byte {
	var b bytes.Buffer
	b.WriteString(SigDomain)
	b.WriteByte(0)
	b.WriteString(networkID)
	b.WriteByte(0)
	b.Write(body)
	return b.Bytes()
}

// SignTx builds a signed wire transaction (used by Go clients, tests and the benchmark).
func SignTx(networkID string, b Body, priv ed25519.PrivateKey) []byte {
	b.NetworkID = networkID
	if b.SchemaVersion == 0 {
		b.SchemaVersion = SchemaVersion
	}
	body := MarshalJSON(b)
	sig := ed25519.Sign(priv, preimage(networkID, body))
	env := Envelope{V: 1, Body: base64.StdEncoding.EncodeToString(body),
		Sig: base64.StdEncoding.EncodeToString(sig), Pub: base64.StdEncoding.EncodeToString(priv.Public().(ed25519.PublicKey))}
	return MarshalJSON(env)
}

// Decoded is the result of the stateless structural + cryptographic stages.
type Decoded struct {
	Env     Envelope
	Raw     []byte
	BodyRaw []byte
	Body    Body
	Pub     ed25519.PublicKey
}

// DecodeStateless performs: size limit, structure, network id, schema, type known (stage 1)
// and signature verification (stage 2, cryptographic validity). It touches no state.
func DecodeStateless(raw []byte, chainID string, p Params) (*Decoded, *TxErr) {
	if len(raw) > p.MaxImportTxBytes {
		return nil, errf(CodeTooLarge, "tx %d bytes exceeds hard limit", len(raw))
	}
	var env Envelope
	if err := strictJSON(raw, &env); err != nil || env.V != 1 {
		return nil, errf(CodeMalformed, "bad envelope")
	}
	body, err := base64.StdEncoding.DecodeString(env.Body)
	if err != nil {
		return nil, errf(CodeMalformed, "bad body encoding")
	}
	sig, err1 := base64.StdEncoding.DecodeString(env.Sig)
	pub, err2 := base64.StdEncoding.DecodeString(env.Pub)
	if err1 != nil || err2 != nil || len(sig) != ed25519.SignatureSize || len(pub) != ed25519.PublicKeySize {
		return nil, errf(CodeMalformed, "bad signature or key encoding")
	}
	var b Body
	if err := strictJSON(body, &b); err != nil {
		return nil, errf(CodeMalformed, "bad body: %v", err)
	}
	if b.NetworkID != chainID {
		return nil, errf(CodeWrongNetwork, "network_id %q != %q", b.NetworkID, chainID)
	}
	h, ok := handlers[b.Type]
	if !ok {
		return nil, errf(CodeUnknownType, "unknown tx type %q", b.Type)
	}
	if len(raw) > p.MaxTxBytes && !h.Bulk {
		return nil, errf(CodeTooLarge, "tx %d bytes exceeds limit %d for %s", len(raw), p.MaxTxBytes, b.Type)
	}
	if b.SchemaVersion != SchemaVersion {
		return nil, errf(CodeBadSchema, "unsupported schema_version %d", b.SchemaVersion)
	}
	if !reTxID.MatchString(b.TxID) || !validID(b.Signer) || !validID(b.KeyID) || !reIdem.MatchString(b.Idempotency) {
		return nil, errf(CodeInvalidField, "tx_id/signer/key_id/idempotency_ref malformed")
	}
	if !ed25519.Verify(ed25519.PublicKey(pub), preimage(chainID, body), sig) {
		return nil, errf(CodeBadSignature, "signature does not verify")
	}
	return &Decoded{Env: env, Raw: raw, BodyRaw: body, Body: b, Pub: pub}, nil
}

func strictJSON(b []byte, v any) error {
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if err := d.Decode(v); err != nil {
		return err
	}
	if d.More() {
		return errf(CodeMalformed, "trailing data")
	}
	return nil
}

// ---- Execution context ------------------------------------------------------

type ValUpdate struct {
	PubKeyB64 string
	Power     int64
}

// BlockOut accumulates block-level consensus outputs (validator / version updates).
type BlockOut struct {
	ValUpdates []ValUpdate
	NewAppVer  uint64
}

type Ctx struct {
	ChainID     string
	Height      int64
	BlockTimeMs int64
	Rules       Rules
	Params      Params
	Index       int
	Body        *Body
	KV          KV
	Out         *BlockOut
}

func (c *Ctx) signer() string { return c.Body.Signer }

type Result struct {
	Data  map[string]any
	Dedup bool
}

type Handler struct {
	PType  reflect.Type
	Name   string
	Perm   string
	Bulk   bool
	decode func(raw json.RawMessage) (any, *TxErr)
	loc    func(c *Ctx, p any) (string, *TxErr)
	exec   func(c *Ctx, p any) (*Result, *TxErr)
}

var handlers = map[string]*Handler{}

// register installs a typed handler. v validates the decoded payload statelessly.
func register[P any](name, perm string, bulk bool, v func(p *P) *TxErr,
	loc func(c *Ctx, p *P) (string, *TxErr), exec func(c *Ctx, p *P) (*Result, *TxErr)) {
	handlers[name] = &Handler{PType: reflect.TypeOf((*P)(nil)).Elem(), Name: name, Perm: perm, Bulk: bulk,
		decode: func(raw json.RawMessage) (any, *TxErr) {
			var p P
			if len(raw) == 0 {
				return nil, errf(CodeMalformed, "missing payload")
			}
			if err := strictJSON(raw, &p); err != nil {
				return nil, errf(CodeMalformed, "payload: %v", err)
			}
			if v != nil {
				if e := v(&p); e != nil {
					return nil, e
				}
			}
			return &p, nil
		},
		loc: func(c *Ctx, p any) (string, *TxErr) {
			if loc == nil {
				return "", nil
			}
			return loc(c, p.(*P))
		},
		exec: func(c *Ctx, p any) (*Result, *TxErr) { return exec(c, p.(*P)) }}
}

func TxTypes() []string {
	out := make([]string, 0, len(handlers))
	for k := range handlers {
		out = append(out, k)
	}
	sortStrings(out)
	return out
}

// Outcome is everything the ABCI layer needs after processing one transaction.
type Outcome struct {
	Code          uint32
	Log           string
	Data          []byte
	Writes        []Write
	TxID          string
	Type          string
	Signer        string
	Authenticated bool
}

// Process runs the full pipeline. With deliver=false it stops after authorisation
// (CheckTx). The stages are deliberately separate:
//  1. structure & limits     2. cryptographic validity (signature)
//  3. identity & key status  4. replay / idempotency
//  5. business authorisation (role + scope)   6. business validation & execution
func Process(base KV, c *Ctx, raw []byte, deliver bool) Outcome {
	d, perr := DecodeStateless(raw, c.ChainID, c.Params)
	if perr != nil {
		return Outcome{Code: perr.Code, Log: perr.Msg}
	}
	b := d.Body
	o := Outcome{TxID: b.TxID, Type: b.Type, Signer: b.Signer}
	fail := func(e *TxErr, authed bool) Outcome {
		o.Code, o.Log, o.Authenticated = e.Code, e.Msg, authed
		if authed && deliver {
			ov := NewOverlay(base)
			recordTx(ov, c, &b, "REJECTED", e)
			o.Writes = ov.Writes()
		}
		return o
	}
	// 3. identity & key
	var id Identity
	if ok, _ := getJSON(base, KIdentity+b.Signer, &id); !ok {
		return fail(errf(CodeUnknownSigner, "signer %q not registered", b.Signer), false)
	}
	pubB64 := base64.StdEncoding.EncodeToString(d.Pub)
	active := false
	for _, k := range id.Keys {
		if k.KeyID == b.KeyID && k.Pub == pubB64 && k.Status == "ACTIVE" {
			active = true
		}
	}
	if !active || id.Status != "ACTIVE" {
		return fail(errf(CodeKeyInactive, "key %q is not an active key of %q", b.KeyID, b.Signer), false)
	}
	if b.ValidUntil != 0 && c.Height > b.ValidUntil {
		return fail(errf(CodeExpired, "valid_until_height %d < %d", b.ValidUntil, c.Height), false)
	}
	// 4. replay & idempotency (only authenticated txs reach here, so an attacker cannot burn ids)
	if _, ok := base.Get(KTx + b.TxID); ok {
		return fail(errf(CodeReplay, "tx_id %s already processed", b.TxID), false)
	}
	if raw, ok := base.Get(KIdem + b.Signer + "/" + b.Idempotency); ok {
		var ir IdemRecord
		json.Unmarshal(raw, &ir)
		return fail(errf(CodeDuplicateIdem, "idempotency_ref already executed by tx %s at height %d", ir.TxID, ir.Height), false)
	}
	o.Authenticated = true
	h := handlers[b.Type]
	ov := NewOverlay(base)
	cc := *c
	cc.Body, cc.KV = &b, ov
	payload, perr := h.decode(b.Payload)
	if perr != nil {
		return fail(perr, true)
	}
	// 5. authorisation
	loc, perr := h.loc(&cc, payload)
	if perr != nil {
		return fail(perr, true)
	}
	if h.Perm != "" {
		if perr := authorize(&cc, b.Signer, h.Perm, loc); perr != nil {
			return fail(perr, true)
		}
	}
	if !deliver {
		return o
	}
	// 6. execute atomically on the overlay
	res, perr := h.exec(&cc, payload)
	if perr != nil {
		return fail(perr, true)
	}
	putJSON(ov, KIdem+b.Signer+"/"+b.Idempotency, IdemRecord{TxID: b.TxID, Type: b.Type, Height: c.Height})
	recordTx(ov, c, &b, "OK", nil)
	o.Code = CodeOK
	o.Writes = ov.Writes()
	if res != nil {
		if res.Dedup {
			res.Data["deduplicated"] = true
		}
		o.Data = MarshalJSON(res.Data)
	}
	return o
}

func recordTx(kv KV, c *Ctx, b *Body, status string, e *TxErr) {
	r := TxRecord{ID: b.TxID, Type: b.Type, Signer: b.Signer, Status: status, Height: c.Height, Index: c.Index,
		BlockTime: c.BlockTimeMs, ClientTime: b.ClientTimeMs, Idem: b.Idempotency}
	if e != nil {
		r.Code, r.CodeName, r.Reason = e.Code, CodeName(e.Code), e.Msg
	} else {
		r.CodeName = "OK"
	}
	putJSON(kv, KTx+b.TxID, r)
}

// ---- Authorisation ----------------------------------------------------------

var rolePerms = map[string][]string{
	"hq-admin":            {"iam.grant", "iam.admin", "location.write", "supplier.write", "gov.propose", "exception.resolve"},
	"org-admin":           {"gov.propose", "gov.approve"},
	"catalog-manager":     {"catalog.write"},
	"buyer":               {"po.create", "supplier.write"},
	"purchasing-approver": {"po.approve"},
	"warehouse-operator":  {"goods.receive", "transfer.dispatch", "transfer.receive", "stock.adjust.propose", "stock.reserve", "stock.release"},
	"warehouse-manager":   {"goods.receive", "transfer.dispatch", "transfer.receive", "stock.adjust.propose", "stock.adjust.approve", "stock.reserve", "stock.release", "reverse.entry", "exception.resolve"},
	"store-cashier":       {"stock.reserve", "stock.release", "sale.complete", "return.request", "loyalty.redeem"},
	"store-manager":       {"goods.receive", "transfer.dispatch", "stock.reserve", "stock.release", "sale.complete", "return.request", "loyalty.redeem", "return.approve", "return.receive", "stock.adjust.propose", "stock.adjust.approve", "transfer.receive", "reverse.entry", "exception.resolve", "loyalty.credit"},
	"pricing-manager":     {"price.publish", "promo.manage"},
	"loyalty-operator":    {"loyalty.credit", "loyalty.expire", "loyalty.redeem"},
	"payment-adapter":     {"payment.record", "refund.record"},
	"finance-controller":  {"reverse.entry", "exception.resolve", "return.approve"},
	"migration-operator":  {"import.batch", "migration.control"},
	"terminal":            {"stock.reserve", "stock.release", "sale.complete", "loyalty.redeem"},
	"auditor":             {},
}

// PrivilegedRoles can only be granted or revoked through multi-organisation governance.
var PrivilegedRoles = map[string]bool{"hq-admin": true, "org-admin": true, "migration-operator": true, "finance-controller": true}

func roleHasPerm(role, perm string) bool {
	for _, p := range rolePerms[role] {
		if p == perm {
			return true
		}
	}
	return false
}

func loadGrants(kv KV, id string) Grants {
	var g Grants
	getJSON(kv, KGrants+id, &g)
	return g
}

func scopeMatches(kv KV, scope, loc string) bool {
	if scope == "*" {
		return true
	}
	if loc == "" {
		return false
	}
	if len(scope) > 4 && scope[:4] == "loc:" {
		return scope[4:] == loc
	}
	if len(scope) > 7 && scope[:7] == "region:" {
		var l Location
		if ok, _ := getJSON(kv, KLocation+loc, &l); ok {
			return l.Region == scope[7:]
		}
	}
	return false
}

func authorize(c *Ctx, signer, perm, loc string) *TxErr {
	var id Identity
	if ok, _ := getJSON(c.KV, KIdentity+signer, &id); ok && id.Kind == "TERMINAL" && id.Location != "" && loc != id.Location {
		return errf(CodeScope, "terminal %s is bound to location %s", signer, id.Location)
	}
	g := loadGrants(c.KV, signer)
	held := false
	for _, gr := range g.Grants {
		if roleHasPerm(gr.Role, perm) {
			held = true
			if scopeMatches(c.KV, gr.Scope, loc) {
				return nil
			}
		}
	}
	if held {
		return errf(CodeScope, "%s holds %s but not for location %q", signer, perm, loc)
	}
	return errf(CodeUnauthorized, "%s lacks permission %s", signer, perm)
}

// hasGlobalPerm reports whether signer holds perm with global ("*") scope — used by
// approval policies that escalate large items to headquarters-level approvers.
func hasGlobalPerm(kv KV, signer, perm string) bool {
	for _, gr := range loadGrants(kv, signer).Grants {
		if gr.Scope == "*" && roleHasPerm(gr.Role, perm) {
			return true
		}
	}
	return false
}

func (c *Ctx) checkVersion(cur int64) *TxErr {
	if c.Body.ExpectedVersion != nil && *c.Body.ExpectedVersion != cur {
		return errf(CodeVersion, "expected_version %d but record is at version %d", *c.Body.ExpectedVersion, cur)
	}
	return nil
}

// touch stamps record metadata on write.
func (c *Ctx) touch(m *Meta) {
	if m.Version == 0 {
		m.CreatedH, m.CreatedTx = c.Height, c.Body.TxID
	}
	m.Version++
	m.Schema = SchemaVersion
	m.UpdatedH, m.UpdatedTx = c.Height, c.Body.TxID
}
