package core

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"
)

// Schema introspection: documentation is generated from the same Go types the validators
// decode with, so the transaction reference cannot drift from the state machine.

func example(t reflect.Type, depth int) any {
	if depth > 6 {
		return nil
	}
	switch t.Kind() {
	case reflect.Ptr:
		return example(t.Elem(), depth+1)
	case reflect.Struct:
		m := map[string]any{}
		for i := 0; i < t.NumField(); i++ {
			f := t.Field(i)
			tag := strings.Split(f.Tag.Get("json"), ",")[0]
			if f.Anonymous && tag == "" {
				if sub, ok := example(f.Type, depth+1).(map[string]any); ok {
					for k, v := range sub {
						m[k] = v
					}
				}
				continue
			}
			if tag == "" || tag == "-" {
				continue
			}
			m[tag] = example(f.Type, depth+1)
		}
		return m
	case reflect.Slice:
		if t == reflect.TypeOf(json.RawMessage{}) {
			return map[string]any{}
		}
		return []any{example(t.Elem(), depth+1)}
	case reflect.Map:
		return map[string]any{"key": example(t.Elem(), depth+1)}
	case reflect.String:
		return "string"
	case reflect.Bool:
		return false
	case reflect.Int, reflect.Int32, reflect.Int64, reflect.Uint32, reflect.Uint64:
		return 0
	}
	return nil
}

type TxSchema struct {
	Type       string `json:"type"`
	Permission string `json:"permission"`
	Bulk       bool   `json:"bulk"`
	Payload    any    `json:"payload_example"`
}

func Schemas() []TxSchema {
	var out []TxSchema
	for _, n := range TxTypes() {
		h := handlers[n]
		perm := h.Perm
		if perm == "" {
			perm = "(checked inside handler)"
		}
		out = append(out, TxSchema{Type: n, Permission: perm, Bulk: h.Bulk, Payload: example(h.PType, 0)})
	}
	return out
}

func SchemaMarkdown() string {
	var b strings.Builder
	for _, s := range Schemas() {
		pj, _ := json.MarshalIndent(s.Payload, "", "  ")
		fmt.Fprintf(&b, "### %s\n\nPermission: `%s`%s\n\n```json\n%s\n```\n\n", s.Type, s.Permission, map[bool]string{true: " — bulk (larger size limit)", false: ""}[s.Bulk], pj)
	}
	return b.String()
}

// Permissions returns role -> permissions for documentation.
func RoleCatalogue() map[string][]string { return rolePerms }
