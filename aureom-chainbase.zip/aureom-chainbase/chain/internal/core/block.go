package core

import "fmt"

// BlockResult is the deterministic outcome of executing one block.
type BlockResult struct {
	Results     []Outcome
	StartWrites []Write // governance execution at block start (not attributable to a tx)
	EndWrites   []Write // upgrade activation at block end
	Out         BlockOut
}

func apply(kv KV, ws []Write) {
	for _, w := range ws {
		if w.Del {
			kv.Delete(w.Key)
		} else {
			kv.Set(w.Key, w.Value)
		}
	}
}

// LoadParams / LoadRules read the active parameters and state-machine rules.
func LoadParams(kv KV) Params {
	p := DefaultParams()
	getJSON(kv, KParams, &p)
	return p
}

// ExecuteBlock is the ONE function that defines how a block changes state. The ABCI
// application, the replay verifier and the tests all call it, so there is a single
// definition of the state transition function.
func ExecuteBlock(kv KV, chainID string, height, blockTimeMs int64, txs [][]byte) (*BlockResult, error) {
	ver := currentAppVersion(kv)
	rules, ok := RulesFor(ver)
	if !ok {
		return nil, fmt.Errorf("state machine version %d is active but unsupported by this binary (max %d): refusing to execute", ver, MaxSupportedVersion)
	}
	br := &BlockResult{}
	params := LoadParams(kv)
	br.StartWrites = RunBlockStart(kv, chainID, height, blockTimeMs, rules, params, &br.Out)
	params = LoadParams(kv)
	for i, raw := range txs {
		c := &Ctx{ChainID: chainID, Height: height, BlockTimeMs: blockTimeMs, Rules: rules, Params: params, Index: i, Out: &br.Out}
		o := Process(kv, c, raw, true)
		apply(kv, o.Writes)
		br.Results = append(br.Results, o)
	}
	ew, err := RunBlockEnd(kv, chainID, height, blockTimeMs, rules, params, &br.Out)
	if err != nil {
		return nil, err
	}
	br.EndWrites = ew
	// block time is recorded in state (and therefore in events/digests) so CheckTx and restarts agree
	tw := Write{Key: KMeta + "last_block_time_ms", Value: MarshalJSON(blockTimeMs)}
	kv.Set(tw.Key, tw.Value)
	br.EndWrites = append(br.EndWrites, tw)
	return br, nil
}

// Sim is an in-memory chain used by tests and tools: same state machine, no consensus.
type Sim struct {
	KV      *MemStore
	ChainID string
	Height  int64
	TimeMs  int64
	Vals    []ValUpdate
	Log     []SimBlock // every executed block, for replay tests
}

type SimBlock struct {
	Height int64
	TimeMs int64
	Txs    [][]byte
	Codes  []uint32
}

// Digest returns the state digest of the whole key/value state.
func (s *Sim) Digest() string {
	keys := make([]string, 0, len(s.KV.M))
	for k := range s.KV.M {
		keys = append(keys, k)
	}
	sortStrings(keys)
	d := NewDigest()
	for _, k := range keys {
		d.Add([]byte(k), s.KV.M[k])
	}
	return fmt.Sprintf("%x", d.Sum())
}

func NewSim(g *Genesis, startMs int64) (*Sim, error) {
	kv := NewMemStore()
	vals, e := ApplyGenesis(kv, g)
	if e != nil {
		return nil, e
	}
	return &Sim{KV: kv, ChainID: g.NetworkID, TimeMs: startMs, Vals: vals}, nil
}

// Block executes txs as the next block, advancing block time by dtMs.
func (s *Sim) Block(dtMs int64, txs ...[]byte) *BlockResult {
	s.Height++
	s.TimeMs += dtMs
	br, err := ExecuteBlock(s.KV, s.ChainID, s.Height, s.TimeMs, txs)
	if err != nil {
		panic(err)
	}
	sb := SimBlock{Height: s.Height, TimeMs: s.TimeMs, Txs: txs}
	for _, r := range br.Results {
		sb.Codes = append(sb.Codes, r.Code)
	}
	s.Log = append(s.Log, sb)
	return br
}
