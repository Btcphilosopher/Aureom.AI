package core

import "regexp"

var reCustomer = regexp.MustCompile(`^(CUST|PSN)-[A-Za-z0-9]{4,40}$`)

func init() {
	register("CompleteSale", "sale.complete", false, vSale, func(c *Ctx, p *CompleteSaleP) (string, *TxErr) { return p.LocationID, nil }, execSale)
	register("RecordPaymentResult", "payment.record", false, vPayment, locOfSale(func(p *PaymentP) string { return p.SaleID }), execPayment)
	register("RequestReturn", "return.request", false, vReqReturn, locOfSale(func(p *ReqReturnP) string { return p.SaleID }), execReqReturn)
	register("ApproveReturn", "return.approve", false, vApproveReturn, locOfReturn(func(p *ApproveReturnP) string { return p.ReturnID }), execApproveReturn)
	register("ReceiveReturnedGoods", "return.receive", false, vRecvReturn, locOfReturn(func(p *RecvReturnP) string { return p.ReturnID }), execRecvReturn)
	register("RecordRefundResult", "refund.record", false, vRefundResult, locOfRefund, execRefundResult)
}

func locOfSale[P any](get func(*P) string) func(*Ctx, *P) (string, *TxErr) {
	return func(c *Ctx, p *P) (string, *TxErr) {
		var s Sale
		if ok, _ := getJSON(c.KV, KSale+get(p), &s); !ok {
			return "", errf(CodeNotFound, "sale %s not found", get(p))
		}
		return s.Loc, nil
	}
}

func locOfReturn[P any](get func(*P) string) func(*Ctx, *P) (string, *TxErr) {
	return func(c *Ctx, p *P) (string, *TxErr) {
		var r Return
		if ok, _ := getJSON(c.KV, KReturn+get(p), &r); !ok {
			return "", errf(CodeNotFound, "return %s not found", get(p))
		}
		return r.Loc, nil
	}
}

// ---- CompleteSale ----

type SaleLineP struct {
	SKU           string `json:"sku"`
	Qty           Qty    `json:"qty"`
	ReservationID string `json:"reservation_id"`
}

type CompleteSaleP struct {
	SaleID             string      `json:"sale_id"`
	LocationID         string      `json:"location_id"`
	Channel            string      `json:"channel"` // STORE | ECOM
	TerminalID         string      `json:"terminal_id"`
	CustomerID         string      `json:"customer_id"` // synthetic / pseudonymous reference only
	EffectiveAt        int64       `json:"effective_at_ms"`
	Currency           string      `json:"currency"`
	ExpectedTotalMinor int64       `json:"expected_total_minor"` // 0 = do not check; otherwise sale is rejected if prices moved
	PaymentMethod      string      `json:"payment_method"`
	Lines              []SaleLineP `json:"lines"`
}

func vSale(p *CompleteSaleP) *TxErr {
	if !validID(p.SaleID) || !validID(p.LocationID) || !validCcy(p.Currency) {
		return errf(CodeInvalidField, "sale_id/location_id/currency invalid")
	}
	if p.Channel != "STORE" && p.Channel != "ECOM" {
		return errf(CodeInvalidField, "channel must be STORE or ECOM")
	}
	if p.CustomerID != "" && !reCustomer.MatchString(p.CustomerID) {
		return errf(CodeInvalidField, "customer_id must be a synthetic/pseudonymous reference (CUST-xxxx or PSN-xxxx)")
	}
	if p.TerminalID != "" && !validID(p.TerminalID) {
		return errf(CodeInvalidField, "terminal_id invalid")
	}
	if len(p.Lines) == 0 {
		return errf(CodeInvalidField, "lines required")
	}
	if e := checkStr("payment_method", p.PaymentMethod, 30, true); e != nil {
		return e
	}
	for _, l := range p.Lines {
		if !validID(l.SKU) || !validID(l.ReservationID) {
			return errf(CodeInvalidField, "line ids invalid")
		}
	}
	return nil
}

func execSale(c *Ctx, p *CompleteSaleP) (*Result, *TxErr) {
	if len(p.Lines) > c.Params.MaxLines {
		return nil, errf(CodeLimit, "too many lines")
	}
	if _, ok := c.KV.Get(KSale + p.SaleID); ok {
		return nil, errf(CodeExists, "sale %s exists (duplicate sale prevented)", p.SaleID)
	}
	loc, e := c.loadLocation(p.LocationID)
	if e != nil {
		return nil, e
	}
	if loc.Currency != p.Currency {
		return nil, errf(CodeArgument, "location trades in %s", loc.Currency)
	}
	if e := c.checkEffective(p.EffectiveAt); e != nil {
		return nil, e
	}
	loyal := false
	if p.CustomerID != "" {
		var la LoyaltyAccount
		if ok, _ := getJSON(c.KV, KLoyalty+p.CustomerID, &la); ok && la.Status == "ACTIVE" {
			loyal = true
		}
	}
	s := Sale{ID: p.SaleID, Loc: p.LocationID, Channel: p.Channel, TerminalID: p.TerminalID, CustomerID: p.CustomerID, Currency: p.Currency,
		EffectiveAt: p.EffectiveAt, BlockTime: c.BlockTimeMs, RulesVer: c.Rules.Version, SaleStatus: "COMPLETED", PaymentStatus: "INSTRUCTED",
		FulfilmentStatus: "FULFILLED", PaymentMethod: p.PaymentMethod, Prov: Provenance{Origin: "NATIVE"}}
	for i, lp := range p.Lines {
		sku, e := c.qtyFor(lp.SKU, lp.Qty)
		if e != nil {
			return nil, e
		}
		var r Reservation
		if ok, _ := getJSON(c.KV, KReserve+lp.ReservationID, &r); !ok {
			return nil, errf(CodeNotFound, "reservation %s not found", lp.ReservationID)
		}
		if r.Status != "ACTIVE" {
			return nil, errf(CodeState, "reservation %s is %s", r.ID, r.Status)
		}
		if r.SKU != lp.SKU || r.Loc != p.LocationID {
			return nil, errf(CodeArgument, "reservation %s is for %s@%s", r.ID, r.SKU, r.Loc)
		}
		if c.BlockTimeMs >= r.ExpiresAt {
			return nil, errf(CodeState, "reservation %s expired", r.ID)
		}
		if r.Terminal != "" && r.Terminal != p.TerminalID {
			return nil, errf(CodePolicy, "reservation %s is bound to terminal %s", r.ID, r.Terminal)
		}
		if r.Allowance {
			if lp.Qty.V > r.Qty {
				return nil, errf(CodeInsufficient, "allowance %s has %d left, sale needs %d", r.ID, r.Qty, lp.Qty.V)
			}
		} else if lp.Qty.V != r.Qty {
			return nil, errf(CodeArgument, "sale quantity %d must equal reservation quantity %d", lp.Qty.V, r.Qty)
		}
		line, e := priceLine(c, p.LocationID, p.Currency, sku, lp.Qty, p.EffectiveAt, loyal)
		if e != nil {
			return nil, e
		}
		line.LineNo, line.ReservationID = i+1, r.ID
		s.Lines = append(s.Lines, line)
		s.Gross += line.Gross
		s.Discount += line.Discount
		s.Net += line.Net
		// atomic with the reservation consumption: reserved -> customer
		if e := c.postMovement(lp.SKU, p.LocationID, BResv, LocCustomer, BAvail, lp.Qty.V, "SALE", "SALE", s.ID, p.EffectiveAt, "NATIVE"); e != nil {
			return nil, e
		}
		r.Qty -= lp.Qty.V
		r.Consumed += lp.Qty.V
		r.SaleID = s.ID
		if r.Qty == 0 {
			r.Status = "CONSUMED"
		}
		c.touch(&r.Meta)
		putJSON(c.KV, KReserve+r.ID, r)
	}
	if p.ExpectedTotalMinor != 0 && p.ExpectedTotalMinor != s.Net {
		return nil, errf(CodeArgument, "price changed: expected total %d, computed %d", p.ExpectedTotalMinor, s.Net)
	}
	if s.Net > MaxMinor {
		return nil, errf(CodeLimit, "sale total out of range")
	}
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	return &Result{Data: map[string]any{"sale_id": s.ID, "net_minor": s.Net, "gross_minor": s.Gross, "discount_minor": s.Discount}}, nil
}

// ---- Payments: instruction (on sale) vs confirmed result (adapter-submitted) ----

type PaymentP struct {
	SaleID      string `json:"sale_id"`
	Provider    string `json:"provider"`
	EventID     string `json:"event_id"` // provider's unique event/callback id: duplicates are deduplicated
	ProviderRef string `json:"provider_ref"`
	Result      string `json:"result"` // CONFIRMED | FAILED
	AmountMinor int64  `json:"amount_minor"`
	Currency    string `json:"currency"`
}

func vPayment(p *PaymentP) *TxErr {
	if !validID(p.SaleID) || !validID(p.Provider) || !validID(p.EventID) || !validCcy(p.Currency) {
		return errf(CodeInvalidField, "ids/currency invalid")
	}
	if p.Result != "CONFIRMED" && p.Result != "FAILED" {
		return errf(CodeInvalidField, "result must be CONFIRMED or FAILED")
	}
	if p.AmountMinor < 0 || p.AmountMinor > MaxMinor || (p.Result == "CONFIRMED" && p.AmountMinor == 0) {
		return errf(CodeInvalidField, "amount invalid")
	}
	return checkStr("provider_ref", p.ProviderRef, 80, true)
}

func execPayment(c *Ctx, p *PaymentP) (*Result, *TxErr) {
	evKey := KPayEvent + "pay/" + p.Provider + "/" + p.EventID
	if _, ok := c.KV.Get(evKey); ok {
		return &Result{Data: map[string]any{"sale_id": p.SaleID}, Dedup: true}, nil // duplicate callback: no state change
	}
	var s Sale
	getJSON(c.KV, KSale+p.SaleID, &s)
	if p.Currency != s.Currency {
		return nil, errf(CodeArgument, "currency mismatch")
	}
	if s.Prov.Origin == "IMPORTED" {
		return nil, errf(CodeState, "imported historical sale; payments are not recorded natively")
	}
	if len(s.PayEvents) >= 20 {
		return nil, errf(CodeLimit, "too many payment events on sale")
	}
	c.KV.Set(evKey, []byte(p.SaleID))
	s.PayEvents = append(s.PayEvents, PaymentEvent{Provider: p.Provider, EventID: p.EventID, Ref: p.ProviderRef, Result: p.Result, Amount: p.AmountMinor, TxID: c.Body.TxID, Height: c.Height})
	if p.Result == "FAILED" {
		if s.Paid == 0 {
			s.PaymentStatus = "FAILED"
			openException(c, "PAYMENT_FAILED", s.ID, "provider reported failure: "+p.ProviderRef)
		}
	} else {
		s.Paid += p.AmountMinor
		switch {
		case s.Paid == s.Net:
			s.PaymentStatus = "CONFIRMED"
		case s.Paid < s.Net:
			s.PaymentStatus = "PARTIALLY_PAID"
			if len(s.PayEvents) == 1 {
				openException(c, "PAYMENT_AMOUNT_MISMATCH", s.ID, "confirmed amount below sale net; awaiting remainder or resolution")
			}
		default:
			s.PaymentStatus = "OVERPAID"
			openException(c, "PAYMENT_OVERPAID", s.ID, "confirmed amount exceeds sale net")
		}
	}
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	return &Result{Data: map[string]any{"sale_id": s.ID, "payment_status": s.PaymentStatus, "paid_minor": s.Paid}}, nil
}

// ---- Returns ----

type ReturnLineP struct {
	LineNo int    `json:"line_no"`
	QtyV   int64  `json:"qty_v"`
	Reason string `json:"reason"`
}

type ReqReturnP struct {
	ReturnID       string        `json:"return_id"`
	SaleID         string        `json:"sale_id"`
	OverrideReason string        `json:"override_reason"`
	Lines          []ReturnLineP `json:"lines"`
}

func vReqReturn(p *ReqReturnP) *TxErr {
	if !validID(p.ReturnID) || !validID(p.SaleID) || len(p.Lines) == 0 {
		return errf(CodeInvalidField, "return_id/sale_id/lines invalid")
	}
	return checkStr("override_reason", p.OverrideReason, 200, false)
}

func execReqReturn(c *Ctx, p *ReqReturnP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KReturn + p.ReturnID); ok {
		return nil, errf(CodeExists, "return exists")
	}
	var s Sale
	getJSON(c.KV, KSale+p.SaleID, &s)
	if s.Prov.Origin == "IMPORTED" {
		return nil, errf(CodeState, "imported historical sale cannot be returned natively; use the documented exception process")
	}
	if s.PaymentStatus != "CONFIRMED" {
		return nil, errf(CodeState, "sale payment is %s; only confirmed payments are returnable", s.PaymentStatus)
	}
	if c.BlockTimeMs > s.EffectiveAt+c.Params.ReturnWindowMs && p.OverrideReason == "" {
		return nil, errf(CodePolicy, "outside return window; an override_reason (needs global approver) is required")
	}
	r := Return{ID: p.ReturnID, SaleID: s.ID, Loc: s.Loc, Status: "REQUESTED", RequestedBy: c.signer(), Override: p.OverrideReason}
	seen := map[int]bool{}
	for _, l := range p.Lines {
		if l.LineNo < 1 || l.LineNo > len(s.Lines) || seen[l.LineNo] {
			return nil, errf(CodeArgument, "invalid or duplicate line_no %d", l.LineNo)
		}
		seen[l.LineNo] = true
		sl := &s.Lines[l.LineNo-1]
		if l.QtyV <= 0 || sl.ReturnedQty+sl.ReturningQty+l.QtyV > sl.Qty.V {
			return nil, errf(CodeLimit, "line %d: returnable quantity is %d", l.LineNo, sl.Qty.V-sl.ReturnedQty-sl.ReturningQty)
		}
		if e := checkStr("reason", l.Reason, 100, true); e != nil {
			return nil, e
		}
		sl.ReturningQty += l.QtyV
		r.Lines = append(r.Lines, ReturnLine{LineNo: l.LineNo, Qty: l.QtyV, Reason: l.Reason})
	}
	c.touch(&r.Meta)
	putJSON(c.KV, KReturn+r.ID, r)
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	return &Result{Data: map[string]any{"return_id": r.ID, "status": r.Status}}, nil
}

type ApproveReturnP struct {
	ReturnID string `json:"return_id"`
	Decision string `json:"decision"` // APPROVE | REJECT
}

func vApproveReturn(p *ApproveReturnP) *TxErr {
	if !validID(p.ReturnID) || (p.Decision != "APPROVE" && p.Decision != "REJECT") {
		return errf(CodeInvalidField, "return_id/decision invalid")
	}
	return nil
}

func execApproveReturn(c *Ctx, p *ApproveReturnP) (*Result, *TxErr) {
	var r Return
	getJSON(c.KV, KReturn+p.ReturnID, &r)
	if r.Status != "REQUESTED" {
		return nil, errf(CodeState, "return is %s", r.Status)
	}
	if e := c.checkVersion(r.Version); e != nil {
		return nil, e
	}
	if r.RequestedBy == c.signer() {
		return nil, errf(CodePolicy, "separation of duties: requester cannot decide own return")
	}
	var s Sale
	getJSON(c.KV, KSale+r.SaleID, &s)
	var est int64
	for _, l := range r.Lines {
		sl := s.Lines[l.LineNo-1]
		est += mulDivHalfEven(sl.Net, l.Qty, sl.Qty.V)
	}
	if (r.Override != "" || est > c.Params.ReturnLocalLimitMinor) && !hasGlobalPerm(c.KV, c.signer(), "return.approve") {
		return nil, errf(CodePolicy, "return needs a global-scope approver (override=%v, est refund %d > limit %d)", r.Override != "", est, c.Params.ReturnLocalLimitMinor)
	}
	r.DecidedBy = c.signer()
	if p.Decision == "REJECT" {
		r.Status = "REJECTED"
		for _, l := range r.Lines {
			s.Lines[l.LineNo-1].ReturningQty -= l.Qty
		}
		c.touch(&s.Meta)
		putJSON(c.KV, KSale+s.ID, s)
	} else {
		r.Status = "APPROVED"
	}
	c.touch(&r.Meta)
	putJSON(c.KV, KReturn+r.ID, r)
	return &Result{Data: map[string]any{"return_id": r.ID, "status": r.Status, "estimated_refund_minor": est}}, nil
}

type InspectionLineP struct {
	LineNo     int    `json:"line_no"`
	QtyV       int64  `json:"qty_v"`
	Inspection string `json:"inspection"` // RESELLABLE | DAMAGED | QUARANTINE | REJECTED
}

type RecvReturnP struct {
	ReturnID string            `json:"return_id"`
	Lines    []InspectionLineP `json:"lines"`
}

func vRecvReturn(p *RecvReturnP) *TxErr {
	if !validID(p.ReturnID) || len(p.Lines) == 0 {
		return errf(CodeInvalidField, "return_id/lines invalid")
	}
	for _, l := range p.Lines {
		switch l.Inspection {
		case "RESELLABLE", "DAMAGED", "QUARANTINE", "REJECTED":
		default:
			return errf(CodeInvalidField, "inspection must be RESELLABLE, DAMAGED, QUARANTINE or REJECTED")
		}
	}
	return nil
}

func execRecvReturn(c *Ctx, p *RecvReturnP) (*Result, *TxErr) {
	var r Return
	getJSON(c.KV, KReturn+p.ReturnID, &r)
	if r.Status != "APPROVED" && r.Status != "PARTIALLY_RECEIVED" {
		return nil, errf(CodeState, "return is %s", r.Status)
	}
	var s Sale
	getJSON(c.KV, KSale+r.SaleID, &s)
	var refund int64
	for _, il := range p.Lines {
		var rl *ReturnLine
		for i := range r.Lines {
			if r.Lines[i].LineNo == il.LineNo {
				rl = &r.Lines[i]
			}
		}
		if rl == nil {
			return nil, errf(CodeArgument, "line %d is not part of return", il.LineNo)
		}
		if il.QtyV <= 0 || rl.Received+il.QtyV > rl.Qty {
			return nil, errf(CodeLimit, "line %d: receiving %d exceeds approved %d", il.LineNo, il.QtyV, rl.Qty-rl.Received)
		}
		sl := &s.Lines[il.LineNo-1]
		rl.Received += il.QtyV
		rl.Inspection = il.Inspection
		sl.ReturningQty -= il.QtyV
		if il.Inspection == "REJECTED" {
			continue // goods handed back, no refund, no stock effect
		}
		bucket := map[string]string{"RESELLABLE": BAvail, "DAMAGED": BDamage, "QUARANTINE": BQuar}[il.Inspection]
		if e := c.postMovement(sl.SKU, LocCustomer, BAvail, s.Loc, bucket, il.QtyV, "RETURN_"+il.Inspection, "RETURN", r.ID, c.BlockTimeMs, "NATIVE"); e != nil {
			return nil, e
		}
		sl.ReturnedQty += il.QtyV
		// cumulative pro-rata target guarantees the sum of refunds over all returns == line net exactly
		target := mulDivHalfEven(sl.Net, sl.ReturnedQty, sl.Qty.V)
		amt := target - sl.RefundCommit
		sl.RefundCommit = target
		rl.RefundMinor += amt
		refund += amt
	}
	if s.RefundInstr+refund > s.Paid {
		return nil, errf(CodeLimit, "refund %d would exceed amount paid %d (already instructed %d)", refund, s.Paid, s.RefundInstr)
	}
	done := true
	for _, l := range r.Lines {
		if l.Received < l.Qty {
			done = false
		}
	}
	r.Status = "PARTIALLY_RECEIVED"
	if done {
		r.Status = "RECEIVED"
	}
	allBack := true
	for _, l := range s.Lines {
		if l.ReturnedQty < l.Qty.V {
			allBack = false
		}
	}
	s.FulfilmentStatus = "PARTIALLY_RETURNED"
	if allBack {
		s.FulfilmentStatus = "RETURNED"
	}
	res := map[string]any{"return_id": r.ID, "status": r.Status, "refund_instructed_minor": refund}
	if refund > 0 {
		rid := "RF-" + r.ID + "-" + seq12(int64(len(r.Refunds) + 1))[9:]
		rf := Refund{ID: rid, SaleID: s.ID, ReturnID: r.ID, Amount: refund, Currency: s.Currency, Status: "INSTRUCTED"}
		c.touch(&rf.Meta)
		putJSON(c.KV, KRefund+rid, rf)
		r.Refunds = append(r.Refunds, rid)
		s.RefundInstr += refund
		res["refund_id"] = rid
	}
	c.touch(&r.Meta)
	putJSON(c.KV, KReturn+r.ID, r)
	c.touch(&s.Meta)
	putJSON(c.KV, KSale+s.ID, s)
	return &Result{Data: res}, nil
}

// ---- Refund result (the chain records the instruction; the adapter reports whether money moved) ----

type RefundResultP struct {
	RefundID    string `json:"refund_id"`
	Provider    string `json:"provider"`
	EventID     string `json:"event_id"`
	ProviderRef string `json:"provider_ref"`
	Result      string `json:"result"` // CONFIRMED | FAILED
	AmountMinor int64  `json:"amount_minor"`
}

func vRefundResult(p *RefundResultP) *TxErr {
	if !validID(p.RefundID) || !validID(p.Provider) || !validID(p.EventID) || (p.Result != "CONFIRMED" && p.Result != "FAILED") {
		return errf(CodeInvalidField, "fields invalid")
	}
	if p.AmountMinor < 0 || p.AmountMinor > MaxMinor {
		return errf(CodeInvalidField, "amount invalid")
	}
	return checkStr("provider_ref", p.ProviderRef, 80, true)
}

func locOfRefund(c *Ctx, p *RefundResultP) (string, *TxErr) {
	var rf Refund
	if ok, _ := getJSON(c.KV, KRefund+p.RefundID, &rf); !ok {
		return "", errf(CodeNotFound, "refund %s not found", p.RefundID)
	}
	var s Sale
	getJSON(c.KV, KSale+rf.SaleID, &s)
	return s.Loc, nil
}

func execRefundResult(c *Ctx, p *RefundResultP) (*Result, *TxErr) {
	evKey := KPayEvent + "refund/" + p.Provider + "/" + p.EventID
	if _, ok := c.KV.Get(evKey); ok {
		return &Result{Data: map[string]any{"refund_id": p.RefundID}, Dedup: true}, nil
	}
	var rf Refund
	getJSON(c.KV, KRefund+p.RefundID, &rf)
	var s Sale
	getJSON(c.KV, KSale+rf.SaleID, &s)
	if rf.Status == "CONFIRMED" {
		return nil, errf(CodeState, "refund already confirmed")
	}
	c.KV.Set(evKey, []byte(rf.ID))
	rf.Provider, rf.Ref = p.Provider, p.ProviderRef
	if p.Result == "FAILED" {
		rf.Status = "FAILED"
		openException(c, "REFUND_FAILED", rf.ID, "provider reported refund failure: "+p.ProviderRef)
	} else {
		if p.AmountMinor != rf.Amount {
			// Recorded (not rejected) so the exception survives: a rejected tx would roll back its writes.
			rf.Status = "DISPUTED"
			openException(c, "REFUND_AMOUNT_MISMATCH", rf.ID, "provider confirmed a different amount than instructed")
		} else {
			rf.Status = "CONFIRMED"
			s.RefundConf += rf.Amount
			c.touch(&s.Meta)
			putJSON(c.KV, KSale+s.ID, s)
		}
	}
	c.touch(&rf.Meta)
	putJSON(c.KV, KRefund+rf.ID, rf)
	return &Result{Data: map[string]any{"refund_id": rf.ID, "status": rf.Status}}, nil
}
