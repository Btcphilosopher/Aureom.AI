package core

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"regexp"
)

// Governance: membership changes, privileged role grants, parameter changes and
// state-machine upgrades are on-chain proposals. A proposal needs approvals from
// organisations holding MORE THAN 2/3 of validator voting power (the same threshold
// CometBFT uses for commits), and executes at an explicit activation height.

func init() {
	register("ProposeGovernance", "gov.propose", false, vPropose, nil, execPropose)
	register("ApproveGovernance", "gov.approve", false, vIDOnly("proposal_id", func(p *ApproveGovP) string { return p.ProposalID }), nil, execApprove)
}

var reNodeID = regexp.MustCompile(`^[0-9a-f]{40}$`)

type ProposeGovP struct {
	ProposalID string          `json:"proposal_id"`
	Kind       string          `json:"kind"`
	Payload    json.RawMessage `json:"payload"`
	Activation int64           `json:"activation_height"`
}

type ApproveGovP struct {
	ProposalID string `json:"proposal_id"`
}

type MemberP struct {
	MemberID  string `json:"member_id"`
	Org       string `json:"org"`
	Role      string `json:"role"`
	PubKeyB64 string `json:"pubkey_b64"`
	NodeID    string `json:"node_id"`
	Power     int64  `json:"power"`
}
type MemberIDP struct {
	MemberID string `json:"member_id"`
}
type RotateValP struct {
	MemberID     string `json:"member_id"`
	NewPubKeyB64 string `json:"new_pubkey_b64"`
	NewNodeID    string `json:"new_node_id"`
}
type PrivRoleP struct {
	IdentityID string `json:"identity_id"`
	Role       string `json:"role"`
	Scope      string `json:"scope"`
}
type SetParamsP struct {
	Params Params `json:"params"`
}
type UpgradeP struct {
	Version uint64 `json:"version"`
}

func decodeGov(kind string, raw json.RawMessage) (any, *TxErr) {
	var v any
	switch kind {
	case "ADD_VALIDATOR":
		v = &MemberP{}
	case "ADD_OBSERVER":
		v = &MemberP{}
	case "REMOVE_VALIDATOR", "REMOVE_OBSERVER":
		v = &MemberIDP{}
	case "ROTATE_VALIDATOR_KEY":
		v = &RotateValP{}
	case "GRANT_PRIVILEGED_ROLE", "REVOKE_PRIVILEGED_ROLE":
		v = &PrivRoleP{}
	case "SET_PARAMS":
		v = &SetParamsP{}
	case "SCHEDULE_UPGRADE":
		v = &UpgradeP{}
	default:
		return nil, errf(CodeInvalidField, "unknown governance kind %q", kind)
	}
	if err := strictJSON(raw, v); err != nil {
		return nil, errf(CodeMalformed, "governance payload: %v", err)
	}
	switch x := v.(type) {
	case *MemberP:
		if !validID(x.MemberID) || !validID(x.Org) || !reNodeID.MatchString(x.NodeID) {
			return nil, errf(CodeInvalidField, "member_id/org/node_id invalid")
		}
		if kind == "ADD_VALIDATOR" {
			if e := validPub(x.PubKeyB64); e != nil || x.Power <= 0 || x.Power > 1000 {
				return nil, errf(CodeInvalidField, "pubkey/power invalid")
			}
		}
	case *MemberIDP:
		if !validID(x.MemberID) {
			return nil, errf(CodeInvalidField, "member_id invalid")
		}
	case *RotateValP:
		if !validID(x.MemberID) || validPub(x.NewPubKeyB64) != nil || (x.NewNodeID != "" && !reNodeID.MatchString(x.NewNodeID)) {
			return nil, errf(CodeInvalidField, "rotation fields invalid")
		}
	case *PrivRoleP:
		if !PrivilegedRoles[x.Role] || !validID(x.IdentityID) {
			return nil, errf(CodeInvalidField, "role must be a privileged role")
		}
	case *SetParamsP:
		p := x.Params
		if p.MaxTxBytes < 1024 || p.MaxImportTxBytes < p.MaxTxBytes || p.MaxLines < 1 || p.MinValidators < 4 {
			return nil, errf(CodeInvalidField, "unsafe parameter set")
		}
	case *UpgradeP:
		if _, ok := supportedRules[x.Version]; !ok {
			return nil, errf(CodeInvalidField, "unknown state machine version %d", x.Version)
		}
	}
	return v, nil
}

func vPropose(p *ProposeGovP) *TxErr {
	if !validID(p.ProposalID) || p.Activation <= 0 {
		return errf(CodeInvalidField, "proposal_id/activation_height invalid")
	}
	_, e := decodeGov(p.Kind, p.Payload)
	return e
}

func execPropose(c *Ctx, p *ProposeGovP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KProposal + p.ProposalID); ok {
		return nil, errf(CodeExists, "proposal exists")
	}
	delay := c.Params.MinGovDelayBlocks
	if p.Kind == "SCHEDULE_UPGRADE" {
		delay = c.Params.MinUpgradeDelayBlocks
	}
	if p.Activation < c.Height+delay {
		return nil, errf(CodeArgument, "activation_height must be >= current height + %d", delay)
	}
	if p.Kind == "SCHEDULE_UPGRADE" {
		var u UpgradeP
		json.Unmarshal(p.Payload, &u)
		if cur := currentAppVersion(c.KV); u.Version <= cur {
			return nil, errf(CodeArgument, "upgrade version must exceed current version %d", cur)
		}
	}
	pr := Proposal{ID: p.ProposalID, Kind: p.Kind, Payload: p.Payload, Proposer: c.signer(), Activation: p.Activation, Status: "PENDING", Approvals: []string{}}
	c.touch(&pr.Meta)
	putJSON(c.KV, KProposal+pr.ID, pr)
	return &Result{Data: map[string]any{"proposal_id": pr.ID, "activation_height": pr.Activation}}, nil
}

func currentAppVersion(kv KV) uint64 {
	var v uint64 = 1
	getJSON(kv, KMeta+"appver", &v)
	return v
}

func loadMembers(kv KV) []Member {
	var ids []string
	getJSON(kv, KMembers, &ids)
	out := make([]Member, 0, len(ids))
	for _, id := range ids {
		var m Member
		if ok, _ := getJSON(kv, KMember+id, &m); ok {
			out = append(out, m)
		}
	}
	return out
}

func votingPower(ms []Member) (total int64, byOrg map[string]int64) {
	byOrg = map[string]int64{}
	for _, m := range ms {
		if m.Kind == "VALIDATOR" && m.Status == "ACTIVE" {
			total += m.Power
			byOrg[m.Org] += m.Power
		}
	}
	return
}

func execApprove(c *Ctx, p *ApproveGovP) (*Result, *TxErr) {
	var pr Proposal
	if ok, _ := getJSON(c.KV, KProposal+p.ProposalID, &pr); !ok {
		return nil, errf(CodeNotFound, "proposal not found")
	}
	if pr.Status != "PENDING" {
		return nil, errf(CodeState, "proposal is %s", pr.Status)
	}
	minAhead := int64(1)
	if pr.Kind == "SCHEDULE_UPGRADE" {
		minAhead = c.Params.MinUpgradeDelayBlocks
	}
	if pr.Activation < c.Height+minAhead {
		return nil, errf(CodeState, "activation height %d is too close/passed (need >= %d); re-propose with a later height", pr.Activation, c.Height+minAhead)
	}
	var id Identity
	getJSON(c.KV, KIdentity+c.signer(), &id)
	total, byOrg := votingPower(loadMembers(c.KV))
	if byOrg[id.Org] == 0 {
		return nil, errf(CodePolicy, "organisation %s holds no validator voting power", id.Org)
	}
	if contains(pr.Approvals, id.Org) {
		return nil, errf(CodeExists, "organisation %s already approved", id.Org)
	}
	pr.Approvals = append(pr.Approvals, id.Org)
	var approved int64
	for _, o := range pr.Approvals {
		approved += byOrg[o]
	}
	if approved*3 > total*2 {
		pr.Status, pr.ApprovedH = "APPROVED", c.Height
		var q []QueueItem
		getJSON(c.KV, KGovQueue, &q)
		if len(q) >= 100 {
			return nil, errf(CodeLimit, "governance queue full")
		}
		q = append(q, QueueItem{Height: pr.Activation, Prop: pr.ID})
		for i := len(q) - 1; i > 0 && q[i].Height < q[i-1].Height; i-- {
			q[i], q[i-1] = q[i-1], q[i]
		}
		putJSON(c.KV, KGovQueue, q)
		if pr.Kind == "SCHEDULE_UPGRADE" {
			var u UpgradeP
			json.Unmarshal(pr.Payload, &u)
			putJSON(c.KV, KUpgrade+itoa(int64(u.Version)), map[string]any{"version": u.Version, "activation_height": pr.Activation, "proposal": pr.ID, "status": "SCHEDULED"})
		}
	}
	c.touch(&pr.Meta)
	putJSON(c.KV, KProposal+pr.ID, pr)
	return &Result{Data: map[string]any{"proposal_id": pr.ID, "status": pr.Status, "approving_power": approved, "total_power": total}}, nil
}

// ---- Block-level execution --------------------------------------------------

func blockCtx(base KV, chainID string, h, t int64, rules Rules, p Params, out *BlockOut, tag string) (*Ctx, *Overlay) {
	ov := NewOverlay(base)
	return &Ctx{ChainID: chainID, Height: h, BlockTimeMs: t, Rules: rules, Params: p, KV: ov, Out: out,
		Body: &Body{TxID: "gov-" + tag, Signer: "governance:" + tag}}, ov
}

// RunBlockStart executes approved proposals whose activation height has been reached
// (membership, roles, parameters) and scheduled follow-up steps. It returns the
// state writes in deterministic order.
func RunBlockStart(base KV, chainID string, h, t int64, rules Rules, params Params, out *BlockOut) []Write {
	var q []QueueItem
	getJSON(base, KGovQueue, &q)
	var writes []Write
	var rest []QueueItem
	changed := false
	for _, it := range q {
		var pr Proposal
		getJSON(base, KProposal+it.Prop, &pr)
		if it.Height > h || pr.Kind == "SCHEDULE_UPGRADE" && it.Step == "" {
			rest = append(rest, it)
			continue
		}
		changed = true
		c, ov := blockCtx(base, chainID, h, t, rules, params, out, it.Prop)
		var res string
		var err *TxErr
		if it.Step != "" {
			res, err = execFollowUp(c, it)
		} else {
			res, err = execProposal(c, &pr, &rest)
		}
		if err != nil {
			ov = NewOverlay(base) // discard partial effects
			c.KV = ov
			if it.Step == "" {
				pr.Status, pr.Result, pr.ExecutedH = "FAILED", err.Error(), h
				c.touch(&pr.Meta)
				putJSON(ov, KProposal+pr.ID, pr)
			}
		} else if it.Step == "" {
			pr.Status, pr.Result, pr.ExecutedH = "EXECUTED", res, h
			c.touch(&pr.Meta)
			putJSON(ov, KProposal+pr.ID, pr)
		}
		writes = append(writes, ov.Writes()...)
		ov.Flush()
	}
	if changed {
		c := NewOverlay(base)
		putJSON(c, KGovQueue, rest)
		writes = append(writes, c.Writes()...)
		c.Flush()
	}
	return writes
}

// RunBlockEnd activates a scheduled state-machine version for the NEXT block:
// activation_height A means block A is the first block executed under the new rules.
func RunBlockEnd(base KV, chainID string, h, t int64, rules Rules, params Params, out *BlockOut) ([]Write, error) {
	var q []QueueItem
	getJSON(base, KGovQueue, &q)
	var rest []QueueItem
	var writes []Write
	changed := false
	for _, it := range q {
		var pr Proposal
		getJSON(base, KProposal+it.Prop, &pr)
		if pr.Kind != "SCHEDULE_UPGRADE" || it.Step != "" || it.Height != h+1 {
			rest = append(rest, it)
			continue
		}
		changed = true
		var u UpgradeP
		json.Unmarshal(pr.Payload, &u)
		if _, ok := RulesFor(u.Version); !ok {
			// Fail closed: this binary cannot execute the activated version, so it must not continue.
			return nil, errf(CodeInternal, "state machine version %d activates at height %d but this binary only supports up to %d", u.Version, h+1, MaxSupportedVersion)
		}
		c, ov := blockCtx(base, chainID, h, t, rules, params, out, it.Prop)
		putJSON(ov, KMeta+"appver", u.Version)
		putJSON(ov, KUpgrade+itoa(int64(u.Version)), map[string]any{"version": u.Version, "activation_height": h + 1, "proposal": pr.ID, "status": "ACTIVE"})
		pr.Status, pr.ExecutedH, pr.Result = "EXECUTED", h, "state machine v"+itoa(int64(u.Version))+" active from height "+itoa(h+1)
		c.touch(&pr.Meta)
		putJSON(ov, KProposal+pr.ID, pr)
		out.NewAppVer = u.Version
		writes = append(writes, ov.Writes()...)
		ov.Flush()
	}
	if changed {
		c := NewOverlay(base)
		putJSON(c, KGovQueue, rest)
		writes = append(writes, c.Writes()...)
		c.Flush()
	}
	return writes, nil
}

func addMember(c *Ctx, m Member) {
	m.Status, m.AddedH = "ACTIVE", c.Height
	var ids []string
	getJSON(c.KV, KMembers, &ids)
	ids = addOnce(ids, m.ID)
	putJSON(c.KV, KMembers, ids)
	putJSON(c.KV, KMember+m.ID, m)
	c.KV.Set(KNode+m.NodeID, []byte(m.ID))
}

func uniqueKeys(c *Ctx, pub, node string) *TxErr {
	for _, m := range loadMembers(c.KV) {
		if m.Status == "ACTIVE" && ((pub != "" && m.PubKey == pub) || (node != "" && m.NodeID == node)) {
			return errf(CodeExists, "pubkey or node id already in use by %s", m.ID)
		}
	}
	return nil
}

func execProposal(c *Ctx, pr *Proposal, queue *[]QueueItem) (string, *TxErr) {
	v, e := decodeGov(pr.Kind, pr.Payload)
	if e != nil {
		return "", e
	}
	switch pr.Kind {
	case "ADD_VALIDATOR":
		x := v.(*MemberP)
		if _, ok := c.KV.Get(KMember + x.MemberID); ok {
			return "", errf(CodeExists, "member exists")
		}
		if e := uniqueKeys(c, x.PubKeyB64, x.NodeID); e != nil {
			return "", e
		}
		addMember(c, Member{ID: x.MemberID, Org: x.Org, Kind: "VALIDATOR", Role: x.Role, PubKey: x.PubKeyB64, NodeID: x.NodeID, Power: x.Power})
		c.Out.ValUpdates = append(c.Out.ValUpdates, ValUpdate{x.PubKeyB64, x.Power})
		return "validator added; consensus effect two blocks after activation", nil
	case "REMOVE_VALIDATOR":
		x := v.(*MemberIDP)
		var m Member
		if ok, _ := getJSON(c.KV, KMember+x.MemberID, &m); !ok || m.Kind != "VALIDATOR" || m.Status != "ACTIVE" {
			return "", errf(CodeNotFound, "active validator not found")
		}
		n := 0
		for _, o := range loadMembers(c.KV) {
			if o.Kind == "VALIDATOR" && o.Status == "ACTIVE" {
				n++
			}
		}
		if n-1 < c.Params.MinValidators {
			return "", errf(CodePolicy, "removal would leave %d validators (< minimum %d): BFT tolerance would be lost", n-1, c.Params.MinValidators)
		}
		m.Status, m.RemovedH = "REMOVED", c.Height
		putJSON(c.KV, KMember+m.ID, m)
		c.KV.Delete(KNode + m.NodeID)
		c.Out.ValUpdates = append(c.Out.ValUpdates, ValUpdate{m.PubKey, 0})
		return "validator removed", nil
	case "ADD_OBSERVER":
		x := v.(*MemberP)
		if _, ok := c.KV.Get(KMember + x.MemberID); ok {
			return "", errf(CodeExists, "member exists")
		}
		if e := uniqueKeys(c, "", x.NodeID); e != nil {
			return "", e
		}
		addMember(c, Member{ID: x.MemberID, Org: x.Org, Kind: "OBSERVER", Role: "OBSERVER", NodeID: x.NodeID})
		return "observer node admitted to the permissioned peer set", nil
	case "REMOVE_OBSERVER":
		x := v.(*MemberIDP)
		var m Member
		if ok, _ := getJSON(c.KV, KMember+x.MemberID, &m); !ok || m.Kind != "OBSERVER" || m.Status != "ACTIVE" {
			return "", errf(CodeNotFound, "active observer not found")
		}
		m.Status, m.RemovedH = "REMOVED", c.Height
		putJSON(c.KV, KMember+m.ID, m)
		c.KV.Delete(KNode + m.NodeID)
		return "observer removed", nil
	case "ROTATE_VALIDATOR_KEY":
		x := v.(*RotateValP)
		var m Member
		if ok, _ := getJSON(c.KV, KMember+x.MemberID, &m); !ok || m.Kind != "VALIDATOR" || m.Status != "ACTIVE" {
			return "", errf(CodeNotFound, "active validator not found")
		}
		if e := uniqueKeys(c, x.NewPubKeyB64, x.NewNodeID); e != nil {
			return "", e
		}
		old, oldNode := m.PubKey, m.NodeID
		m.History = append(m.History, "pubkey:"+old+"@h"+itoa(c.Height))
		m.PubKey = x.NewPubKeyB64
		c.Out.ValUpdates = append(c.Out.ValUpdates, ValUpdate{x.NewPubKeyB64, m.Power})
		if x.NewNodeID != "" {
			m.NodeID = x.NewNodeID
			c.KV.Set(KNode+x.NewNodeID, []byte(m.ID))
		}
		putJSON(c.KV, KMember+m.ID, m)
		// two-phase rotation: the old key keeps its power for an overlap window so the
		// operator can restart the node with the new key without ever dropping below quorum
		*queue = append(*queue, QueueItem{Height: c.Height + 20, Prop: pr.ID, Step: "RETIRE_KEY", Arg: old + "|" + oldNode})
		return "new key added; old key retired at height " + itoa(c.Height+20), nil
	case "GRANT_PRIVILEGED_ROLE":
		x := v.(*PrivRoleP)
		_, e := grantRole(c, x.IdentityID, x.Role, x.Scope)
		return "granted " + x.Role, e
	case "REVOKE_PRIVILEGED_ROLE":
		x := v.(*PrivRoleP)
		_, e := revokeRole(c, x.IdentityID, x.Role, x.Scope)
		return "revoked " + x.Role, e
	case "SET_PARAMS":
		x := v.(*SetParamsP)
		putJSON(c.KV, KParams, x.Params)
		return "parameters replaced", nil
	}
	return "", errf(CodeInternal, "unhandled kind")
}

func execFollowUp(c *Ctx, it QueueItem) (string, *TxErr) {
	switch it.Step {
	case "RETIRE_KEY":
		var pub, node string
		for i := 0; i < len(it.Arg); i++ {
			if it.Arg[i] == '|' {
				pub, node = it.Arg[:i], it.Arg[i+1:]
			}
		}
		c.Out.ValUpdates = append(c.Out.ValUpdates, ValUpdate{pub, 0})
		if node != "" {
			if raw, ok := c.KV.Get(KNode + node); ok {
				var m Member
				if ok2, _ := getJSON(c.KV, KMember+string(raw), &m); ok2 && m.NodeID != node {
					c.KV.Delete(KNode + node)
				}
			}
		}
		return "old key retired", nil
	}
	return "", errf(CodeInternal, "unknown follow-up")
}

// ValidatorPubKey decodes a stored consensus key.
func ValidatorPubKey(b64 string) (ed25519.PublicKey, error) {
	b, err := base64.StdEncoding.DecodeString(b64)
	return ed25519.PublicKey(b), err
}
