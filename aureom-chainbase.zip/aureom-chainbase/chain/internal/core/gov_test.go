package core_test

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

func (h *H) advance(n int) {
	for i := 0; i < n; i++ {
		h.sim.Block(1000)
	}
}

func (h *H) propose(by, id, kind string, payload any, activation int64) {
	h.t.Helper()
	h.mustOK(by, "ProposeGovernance", m{"proposal_id": id, "kind": kind, "payload": payload, "activation_height": activation})
}

func nodeHex(c byte) string { return strings.Repeat(string("0123456789abcdef"[c%16]), 40) }

func TestGovernanceQuorumAndObserverAdmission(t *testing.T) {
	h := newH(t)
	act := h.sim.Height + 10
	h.propose("hq-org-admin", "GOV-1", "ADD_OBSERVER", m{"member_id": "obs-1", "org": "org-audit", "node_id": nodeHex(7)}, act)
	// non-governance roles cannot propose
	h.expect(core.CodeUnauthorized, "cashier-n01", "ProposeGovernance", m{"proposal_id": "GOV-X", "kind": "ADD_OBSERVER", "payload": m{"member_id": "o", "org": "o", "node_id": nodeHex(8)}, "activation_height": act})
	// activation too soon is refused
	h.expect(core.CodeArgument, "hq-org-admin", "ProposeGovernance", m{"proposal_id": "GOV-S", "kind": "ADD_OBSERVER", "payload": m{"member_id": "o2", "org": "o", "node_id": nodeHex(9)}, "activation_height": h.sim.Height + 1})
	h.mustOK("hq-org-admin", "ApproveGovernance", m{"proposal_id": "GOV-1"})
	h.mustOK("dist-org-admin", "ApproveGovernance", m{"proposal_id": "GOV-1"})
	// 2 of 4 orgs hold 50% of power: NOT more than 2/3 => still pending
	if p := get[core.Proposal](h, core.KProposal+"GOV-1"); p.Status != "PENDING" {
		t.Fatalf("%+v", p)
	}
	h.expect(core.CodeExists, "hq-org-admin", "ApproveGovernance", m{"proposal_id": "GOV-1"}) // one vote per org
	h.mustOK("north-org-admin", "ApproveGovernance", m{"proposal_id": "GOV-1"})
	if p := get[core.Proposal](h, core.KProposal+"GOV-1"); p.Status != "APPROVED" {
		t.Fatalf("3/4 orgs = 75%% > 2/3 must approve: %+v", p)
	}
	// not active before the activation height
	if _, ok := h.sim.KV.M[core.KNode+nodeHex(7)]; ok {
		t.Fatal("membership change applied early")
	}
	for h.sim.Height < act-1 {
		h.sim.Block(1000)
	}
	if _, ok := h.sim.KV.M[core.KNode+nodeHex(7)]; ok {
		t.Fatal("applied before activation height")
	}
	h.sim.Block(1000) // block == activation height
	if _, ok := h.sim.KV.M[core.KNode+nodeHex(7)]; !ok {
		t.Fatal("observer not admitted to the peer allow-list at the activation height")
	}
	if p := get[core.Proposal](h, core.KProposal+"GOV-1"); p.Status != "EXECUTED" || p.ExecutedH != act {
		t.Fatalf("%+v", p)
	}
}

func TestValidatorAddRemoveRotate(t *testing.T) {
	h := newH(t)
	newKey := demo.DeterministicKey("consensus/val-extra")
	act := h.sim.Height + 10
	approve := func(id string) {
		for _, a := range []string{"hq-org-admin", "dist-org-admin", "north-org-admin"} {
			h.mustOK(a, "ApproveGovernance", m{"proposal_id": id})
		}
	}
	h.propose("hq-org-admin", "G-ADD", "ADD_VALIDATOR", m{"member_id": "val-extra", "org": "org-extra", "role": "REGIONAL", "pubkey_b64": demo.Pub64(newKey), "node_id": nodeHex(3), "power": 10}, act)
	approve("G-ADD")
	var updates []core.ValUpdate
	for h.sim.Height < act {
		br := h.sim.Block(1000)
		updates = append(updates, br.Out.ValUpdates...)
	}
	if len(updates) != 1 || updates[0].Power != 10 || updates[0].PubKeyB64 != demo.Pub64(newKey) {
		t.Fatalf("validator updates %+v proposal %+v", updates, get[core.Proposal](h, core.KProposal+"G-ADD"))
	}
	// removal that would drop below the minimum validator count (4) is refused at execution: FAILED, no update
	act2 := h.sim.Height + 10
	h.propose("hq-org-admin", "G-RM", "REMOVE_VALIDATOR", m{"member_id": "val-hq"}, act2) // 5 -> 4 is allowed
	approve("G-RM")
	h.mustOK("south-org-admin", "ApproveGovernance", m{"proposal_id": "G-RM"}) // with 5 validators 3 of 4 admin orgs hold only 60% of power: a 4th vote is needed
	updates = nil
	for h.sim.Height < act2 {
		updates = append(updates, h.sim.Block(1000).Out.ValUpdates...)
	}
	if len(updates) != 1 || updates[0].Power != 0 {
		t.Fatalf("%+v", updates)
	}
	act3 := h.sim.Height + 10
	h.propose("dist-org-admin", "G-RM2", "REMOVE_VALIDATOR", m{"member_id": "val-dist"}, act3) // 4 -> 3 violates BFT tolerance
	for _, a := range []string{"dist-org-admin", "north-org-admin", "south-org-admin"} {
		h.mustOK(a, "ApproveGovernance", m{"proposal_id": "G-RM2"}) // note: removed org hq no longer votes
	}
	updates = nil
	for h.sim.Height < act3 {
		updates = append(updates, h.sim.Block(1000).Out.ValUpdates...)
	}
	if p := get[core.Proposal](h, core.KProposal+"G-RM2"); p.Status != "FAILED" || len(updates) != 0 {
		t.Fatalf("removal below min validators must fail safely: %+v %v", p, updates)
	}
	// key rotation is two-phase: add new key now, retire old key 20 blocks later
	k2 := demo.DeterministicKey("consensus/val-north-v2")
	act4 := h.sim.Height + 10
	h.propose("north-org-admin", "G-ROT", "ROTATE_VALIDATOR_KEY", m{"member_id": "val-north", "new_pubkey_b64": demo.Pub64(k2)}, act4)
	for _, a := range []string{"dist-org-admin", "north-org-admin", "south-org-admin"} {
		h.mustOK(a, "ApproveGovernance", m{"proposal_id": "G-ROT"})
	}
	var ups []core.ValUpdate
	for h.sim.Height < act4+22 {
		ups = append(ups, h.sim.Block(1000).Out.ValUpdates...)
	}
	if len(ups) != 2 || ups[0].Power != 10 || ups[0].PubKeyB64 != demo.Pub64(k2) || ups[1].Power != 0 {
		t.Fatalf("rotation updates %+v", ups)
	}
}

func TestPrivilegedRoleViaGovernance(t *testing.T) {
	h := newH(t)
	act := h.sim.Height + 6
	h.propose("hq-org-admin", "G-R", "GRANT_PRIVILEGED_ROLE", m{"identity_id": "cashier-n01", "role": "finance-controller", "scope": "*"}, act)
	for _, a := range []string{"hq-org-admin", "dist-org-admin", "south-org-admin"} {
		h.mustOK(a, "ApproveGovernance", m{"proposal_id": "G-R"})
	}
	h.expect(core.CodeUnauthorized, "cashier-n01", "ResolveException", m{"exception_id": "EXC-1", "resolution": "x"}) // not yet
	for h.sim.Height < act {
		h.sim.Block(1000)
	}
	h.expect(core.CodeNotFound, "cashier-n01", "ResolveException", m{"exception_id": "EXC-1", "resolution": "x"}) // now authorised (fails on unknown exception)
}

// Upgrade activation: rules v2 take effect exactly at the activation height; the binary refuses to
// continue (instead of silently diverging) if it cannot execute the activated version.
func TestUpgradeActivationAndFailClosed(t *testing.T) {
	run := func(maxSupported uint64) (earn1, earn2 int64, failed bool) {
		old := core.MaxSupportedVersion
		core.MaxSupportedVersion = maxSupported
		defer func() { core.MaxSupportedVersion = old }()
		h := newH(t)
		h.seedCatalog(30)
		sale := func(id string) {
			h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-" + id, "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(4), "ttl_ms": 600000})
			h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": id, "location_id": "STORE-N-01", "channel": "STORE", "customer_id": "CUST-000777", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
				"lines": []m{{"sku": "SKU-A", "qty": qty(4), "reservation_id": "RS-" + id}}})
			h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": id, "provider": "P", "event_id": "e" + id, "provider_ref": "r", "result": "CONFIRMED", "amount_minor": 1000, "currency": "GBP"})
			h.mustOK("loyalty-op", "CreditLoyalty", m{"entry_id": "LE-" + id, "customer_id": "CUST-000777", "sale_id": id})
		}
		sale("S-1")
		act := h.sim.Height + 25
		h.propose("hq-org-admin", "UP-2", "SCHEDULE_UPGRADE", m{"version": 2}, act)
		for _, a := range []string{"hq-org-admin", "dist-org-admin", "north-org-admin"} {
			h.mustOK(a, "ApproveGovernance", m{"proposal_id": "UP-2"})
		}
		func() {
			defer func() {
				if r := recover(); r != nil {
					failed = true
				}
			}()
			for h.sim.Height < act-1 {
				h.sim.Block(1000)
			}
			if h.sim.Height != act-1 {
				t.Fatal("height")
			}
			br := h.sim.Block(1000)
			_ = br
		}()
		if failed {
			return 0, 0, true
		}
		sale("S-2")
		var e1, e2 core.LoyaltyEntry
		json.Unmarshal(h.sim.KV.M[core.KLoyEntry+"LE-S-1"], &e1)
		json.Unmarshal(h.sim.KV.M[core.KLoyEntry+"LE-S-2"], &e2)
		return e1.Points, e2.Points, false
	}
	e1, e2, failed := run(2)
	if failed || e1 != 10 || e2 != 20 {
		t.Fatalf("v1 earned %d, v2 earned %d (expected 10 then 20), failed=%v", e1, e2, failed)
	}
	// a binary that only supports v1 must halt at the activation height rather than compute different results
	if _, _, failed := run(1); !failed {
		t.Fatal("old binary continued past an activated upgrade it cannot execute")
	}
}
