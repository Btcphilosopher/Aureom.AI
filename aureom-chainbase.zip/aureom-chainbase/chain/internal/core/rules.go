package core

// Rules are the version-gated state-machine rules. Every validator binary lists the
// versions it can execute. A version activates only at an explicit on-chain height
// (see governance.go); a binary that does not support the active version halts
// instead of silently computing different results.
type Rules struct {
	Version           uint64
	LoyaltyPtsPerUnit int64 // loyalty points earned per whole currency unit of net sale value
}

var supportedRules = map[uint64]Rules{
	1: {Version: 1, LoyaltyPtsPerUnit: 1},
	2: {Version: 2, LoyaltyPtsPerUnit: 2}, // demonstration upgrade: double-points rule set
}

// MaxSupportedVersion can be lowered in tests / builds to simulate an old binary.
var MaxSupportedVersion uint64 = 2

func RulesFor(v uint64) (Rules, bool) {
	if v > MaxSupportedVersion {
		return Rules{}, false
	}
	r, ok := supportedRules[v]
	return r, ok
}
