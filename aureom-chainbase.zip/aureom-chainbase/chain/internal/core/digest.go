package core

import (
	"crypto/sha256"
	"encoding/binary"
	"hash"
)

// StateDigest is an order-dependent SHA-256 over (key,value) pairs visited in ascending
// key order. It gives a COMPLETENESS check for projections and snapshots: the IAVL root
// proves individual records, while this digest commits to the whole key set.
type StateDigest struct {
	h hash.Hash
	N int64
}

func NewDigest() *StateDigest { return &StateDigest{h: sha256.New()} }

func (d *StateDigest) Add(key, value []byte) {
	var l [8]byte
	binary.BigEndian.PutUint64(l[:], uint64(len(key)))
	d.h.Write(l[:])
	d.h.Write(key)
	binary.BigEndian.PutUint64(l[:], uint64(len(value)))
	d.h.Write(l[:])
	d.h.Write(value)
	d.N++
}

func (d *StateDigest) Sum() []byte { return d.h.Sum(nil) }
