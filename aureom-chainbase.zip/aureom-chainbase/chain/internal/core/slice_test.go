package core_test

import (
	"testing"

	"github.com/aureom/chainbase/internal/core"
)

// The smallest complete vertical slice: product -> receipt -> competing reservations -> sale -> payment.
func TestVerticalSlice(t *testing.T) {
	h := newH(t)
	h.seedCatalog(1) // exactly ONE unit exists
	if b := h.bal("SKU-A", "STORE-N-01"); b.Available != 1 || b.OnHand() != 1 {
		t.Fatalf("balance after receipt %+v", b)
	}
	// Two terminals race for the last unit in the SAME block: consensus order decides, state machine enforces.
	r1 := h.tx("term-n01-1", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000, "terminal_id": "term-n01-1"})
	r2 := h.tx("term-n01-2", "ReserveStock", m{"reservation_id": "RS-2", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000, "terminal_id": "term-n01-2"})
	res := h.block(r1, r2)
	if res[0].Code != 0 || res[1].Code != core.CodeInsufficient {
		t.Fatalf("want first OK second INSUFFICIENT, got %v/%v: %s", res[0].Code, res[1].Code, res[1].Log)
	}
	if b := h.bal("SKU-A", "STORE-N-01"); b.Available != 0 || b.Reserved != 1 {
		t.Fatalf("balance %+v", b)
	}
	o := h.mustOK("term-n01-1", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "terminal_id": "term-n01-1",
		"customer_id": "CUST-000001", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD", "expected_total_minor": 250,
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"}}})
	t.Logf("sale result %s", o.Data)
	s := get[core.Sale](h, core.KSale+"S-1")
	if s.Net != 250 || s.PaymentStatus != "INSTRUCTED" || s.FulfilmentStatus != "FULFILLED" || s.SaleStatus != "COMPLETED" {
		t.Fatalf("sale %+v", s)
	}
	if b := h.bal("SKU-A", "STORE-N-01"); b.OnHand() != 0 {
		t.Fatalf("stock should be consumed: %+v", b)
	}
	// duplicate sale and double-use of a consumed reservation are both refused
	h.expect(core.CodeExists, "term-n01-1", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"}}})
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "SIMPAY", "event_id": "evt-1", "provider_ref": "ch_1", "result": "CONFIRMED", "amount_minor": 250, "currency": "GBP"})
	if s := get[core.Sale](h, core.KSale+"S-1"); s.PaymentStatus != "CONFIRMED" {
		t.Fatalf("payment %s", s.PaymentStatus)
	}
	h.checkInvariants()
}
