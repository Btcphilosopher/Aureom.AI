package core

func init() {
	register("ReserveStock", "stock.reserve", false, vReserve, func(c *Ctx, p *ReserveP) (string, *TxErr) { return p.LocationID, nil }, execReserve)
	register("ReleaseReservation", "stock.release", false, vIDOnly("reservation_id", func(p *ReleaseP) string { return p.ReservationID }), locOfReservation, execRelease)
	register("TransferStock", "", false, vTransfer, nil, execTransfer) // permission depends on op; checked in handler
	register("AdjustStock", "", false, vAdjust, nil, execAdjust)
}

// ---- Reservations ----------------------------------------------------------
//
// Concurrency control: the validators agree on ONE total order of transactions, and
// the state machine executes them sequentially. A reservation moves units
// available -> reserved only if available >= qty at the moment it executes, so two
// competing reservations for the last unit can never both succeed. Callers may also
// pin the balance record with expected_version for optimistic concurrency.

type ReserveP struct {
	ReservationID string `json:"reservation_id"`
	LocationID    string `json:"location_id"`
	SKU           string `json:"sku"`
	Qty           Qty    `json:"qty"`
	TTLMs         int64  `json:"ttl_ms"`
	TerminalID    string `json:"terminal_id"`
	Allowance     bool   `json:"allowance"` // pre-allocated offline allowance (partial consumption allowed)
}

func vReserve(p *ReserveP) *TxErr {
	if !validID(p.ReservationID) || !validID(p.LocationID) || !validID(p.SKU) {
		return errf(CodeInvalidField, "ids invalid")
	}
	if p.TerminalID != "" && !validID(p.TerminalID) {
		return errf(CodeInvalidField, "terminal_id invalid")
	}
	if p.TTLMs <= 0 {
		return errf(CodeInvalidField, "ttl_ms must be positive")
	}
	return nil
}

func execReserve(c *Ctx, p *ReserveP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KReserve + p.ReservationID); ok {
		return nil, errf(CodeExists, "reservation id exists")
	}
	if _, e := c.loadLocation(p.LocationID); e != nil {
		return nil, e
	}
	if _, e := c.qtyFor(p.SKU, p.Qty); e != nil {
		return nil, e
	}
	max := c.Params.ReservationMaxTTLMs
	if p.Allowance {
		max = c.Params.AllowanceMaxTTLMs
	}
	if p.TTLMs > max {
		return nil, errf(CodeLimit, "ttl_ms exceeds %d", max)
	}
	bal := getBalance(c.KV, p.SKU, p.LocationID)
	if e := c.checkVersion(bal.Version); e != nil {
		return nil, e
	}
	if e := c.postMovement(p.SKU, p.LocationID, BAvail, p.LocationID, BResv, p.Qty.V, "RESERVE", "RESERVATION", p.ReservationID, c.BlockTimeMs, "NATIVE"); e != nil {
		return nil, e
	}
	r := Reservation{ID: p.ReservationID, SKU: p.SKU, Loc: p.LocationID, Qty: p.Qty.V, Unit: p.Qty.Unit, Status: "ACTIVE",
		Allowance: p.Allowance, Holder: c.signer(), Terminal: p.TerminalID, ExpiresAt: c.BlockTimeMs + p.TTLMs}
	c.touch(&r.Meta)
	putJSON(c.KV, KReserve+r.ID, r)
	return &Result{Data: map[string]any{"reservation_id": r.ID, "expires_at_ms": r.ExpiresAt}}, nil
}

type ReleaseP struct {
	ReservationID string `json:"reservation_id"`
	Reason        string `json:"reason"` // CANCELLED | EXPIRED
}

func locOfReservation(c *Ctx, p *ReleaseP) (string, *TxErr) {
	var r Reservation
	if ok, _ := getJSON(c.KV, KReserve+p.ReservationID, &r); !ok {
		return "", errf(CodeNotFound, "reservation not found")
	}
	return r.Loc, nil
}

func execRelease(c *Ctx, p *ReleaseP) (*Result, *TxErr) {
	var r Reservation
	getJSON(c.KV, KReserve+p.ReservationID, &r)
	if r.Status != "ACTIVE" {
		return nil, errf(CodeState, "reservation is %s", r.Status)
	}
	status := "RELEASED"
	switch p.Reason {
	case "CANCELLED": // holder or any signer with stock.release at the location (scope already checked)
	case "EXPIRED":
		if c.BlockTimeMs < r.ExpiresAt {
			return nil, errf(CodeState, "reservation has not expired by block time (%d < %d)", c.BlockTimeMs, r.ExpiresAt)
		}
		status = "EXPIRED"
	default:
		return nil, errf(CodeInvalidField, "reason must be CANCELLED or EXPIRED")
	}
	if e := c.postMovement(r.SKU, r.Loc, BResv, r.Loc, BAvail, r.Qty, "RELEASE", "RESERVATION", r.ID, c.BlockTimeMs, "NATIVE"); e != nil {
		return nil, e
	}
	r.Status = status
	r.Qty = 0
	c.touch(&r.Meta)
	putJSON(c.KV, KReserve+r.ID, r)
	return &Result{Data: map[string]any{"reservation_id": r.ID, "status": status}}, nil
}

// ---- Transfers (dispatch / receipt, with a TRANSIT:<id> holding location) ----

type TransferLineP struct {
	SKU     string `json:"sku"`
	Qty     Qty    `json:"qty"`
	Damaged int64  `json:"damaged_v"` // RECEIVE only: of the received qty, how many are damaged
}

type TransferP struct {
	Op         string          `json:"op"` // DISPATCH | RECEIVE
	TransferID string          `json:"transfer_id"`
	From       string          `json:"from_location"`
	To         string          `json:"to_location"`
	Lines      []TransferLineP `json:"lines"`
}

func vTransfer(p *TransferP) *TxErr {
	if !validID(p.TransferID) || (p.Op != "DISPATCH" && p.Op != "RECEIVE") || len(p.Lines) == 0 {
		return errf(CodeInvalidField, "op/transfer_id/lines invalid")
	}
	if p.Op == "DISPATCH" && (!validID(p.From) || !validID(p.To) || p.From == p.To) {
		return errf(CodeInvalidField, "from_location/to_location invalid")
	}
	return nil
}

func execTransfer(c *Ctx, p *TransferP) (*Result, *TxErr) {
	if len(p.Lines) > c.Params.MaxLines {
		return nil, errf(CodeLimit, "too many lines")
	}
	transit := TransitPfx + p.TransferID
	var x Transfer
	exists, _ := getJSON(c.KV, KTransfer+p.TransferID, &x)
	if p.Op == "DISPATCH" {
		if e := authorize(c, c.signer(), "transfer.dispatch", p.From); e != nil {
			return nil, e
		}
		if exists {
			return nil, errf(CodeExists, "transfer exists")
		}
		if _, e := c.loadLocation(p.From); e != nil {
			return nil, e
		}
		if _, e := c.loadLocation(p.To); e != nil {
			return nil, e
		}
		x = Transfer{ID: p.TransferID, From: p.From, To: p.To, Status: "IN_TRANSIT"}
		for _, l := range p.Lines {
			if _, e := c.qtyFor(l.SKU, l.Qty); e != nil {
				return nil, e
			}
			if e := c.postMovement(l.SKU, p.From, BAvail, transit, BAvail, l.Qty.V, "TRANSFER_DISPATCH", "TRANSFER", x.ID, c.BlockTimeMs, "NATIVE"); e != nil {
				return nil, e
			}
			x.Lines = append(x.Lines, XferLine{SKU: l.SKU, Sent: l.Qty.V, Unit: l.Qty.Unit})
		}
		c.touch(&x.Meta)
		putJSON(c.KV, KTransfer+x.ID, x)
		return &Result{Data: map[string]any{"transfer_id": x.ID, "status": x.Status}}, nil
	}
	// RECEIVE
	if !exists {
		return nil, errf(CodeNotFound, "transfer not found")
	}
	if e := authorize(c, c.signer(), "transfer.receive", x.To); e != nil {
		return nil, e
	}
	if x.Status != "IN_TRANSIT" {
		return nil, errf(CodeState, "transfer is %s", x.Status)
	}
	if e := c.checkVersion(x.Version); e != nil {
		return nil, e
	}
	discrepancy := false
	for _, l := range p.Lines {
		idx := -1
		for i := range x.Lines {
			if x.Lines[i].SKU == l.SKU {
				idx = i
			}
		}
		if idx < 0 {
			return nil, errf(CodeArgument, "sku %s is not on transfer", l.SKU)
		}
		xl := &x.Lines[idx]
		if l.Qty.Unit != xl.Unit || l.Qty.V <= 0 || l.Qty.V > xl.Sent-xl.Received || l.Damaged < 0 || l.Damaged > l.Qty.V {
			return nil, errf(CodeLimit, "received quantity for %s exceeds what is in transit", l.SKU)
		}
		good := l.Qty.V - l.Damaged
		if good > 0 {
			if e := c.postMovement(l.SKU, transit, BAvail, x.To, BAvail, good, "TRANSFER_RECEIPT", "TRANSFER", x.ID, c.BlockTimeMs, "NATIVE"); e != nil {
				return nil, e
			}
		}
		if l.Damaged > 0 {
			if e := c.postMovement(l.SKU, transit, BAvail, x.To, BDamage, l.Damaged, "TRANSFER_RECEIPT_DAMAGED", "TRANSFER", x.ID, c.BlockTimeMs, "NATIVE"); e != nil {
				return nil, e
			}
		}
		xl.Received += l.Qty.V
		xl.Damaged += l.Damaged
	}
	x.Status = "RECEIVED"
	for _, l := range x.Lines {
		if l.Received < l.Sent {
			discrepancy = true
		}
	}
	if discrepancy {
		// A receipt that is short stays "in transit": the chain records what the receiving
		// site ASSERTS it received; it cannot know whether goods are lost or still on a truck.
		x.Status = "RECEIVED_WITH_DISCREPANCY"
		openException(c, "TRANSFER_DISCREPANCY", x.ID, "received quantity below dispatched quantity; remainder still in transit")
	}
	c.touch(&x.Meta)
	putJSON(c.KV, KTransfer+x.ID, x)
	return &Result{Data: map[string]any{"transfer_id": x.ID, "status": x.Status}}, nil
}

func openException(c *Ctx, kind, ref, detail string) string {
	id := "EXC-" + seq12(nextSeq(c.KV, "exc"))
	e := Exception{ID: id, Kind: kind, Ref: ref, Detail: detail, Status: "OPEN"}
	c.touch(&e.Meta)
	putJSON(c.KV, KException+id, e)
	return id
}

// ---- Stock adjustments (maker-checker) ----

type AdjustP struct {
	Op           string `json:"op"` // PROPOSE | APPROVE | REJECT
	AdjustmentID string `json:"adjustment_id"`
	Location     string `json:"location_id"`
	SKU          string `json:"sku"`
	Bucket       string `json:"bucket"`
	CountedV     int64  `json:"counted_v"`
	Reason       string `json:"reason"`
	Evidence     string `json:"evidence_ref"`
}

func vAdjust(p *AdjustP) *TxErr {
	if !validID(p.AdjustmentID) || (p.Op != "PROPOSE" && p.Op != "APPROVE" && p.Op != "REJECT") {
		return errf(CodeInvalidField, "op/adjustment_id invalid")
	}
	if p.Op == "PROPOSE" {
		if !validID(p.Location) && !isTransit(p.Location) || !validID(p.SKU) || p.CountedV < 0 || p.CountedV > MaxQty {
			return errf(CodeInvalidField, "location/sku/counted_v invalid")
		}
		if p.Bucket != BAvail && p.Bucket != BQuar && p.Bucket != BDamage {
			return errf(CodeInvalidField, "bucket must be available, quarantined or damaged")
		}
		if e := checkStr("reason", p.Reason, 200, true); e != nil {
			return e
		}
		return checkStr("evidence_ref", p.Evidence, 120, false)
	}
	return checkStr("reason", p.Reason, 200, false)
}

// scopeLoc maps a TRANSIT pseudo-location back to the dispatching location for authorisation.
func scopeLoc(c *Ctx, loc string) string {
	if isTransit(loc) {
		var x Transfer
		if ok, _ := getJSON(c.KV, KTransfer+loc[len(TransitPfx):], &x); ok {
			return x.From
		}
	}
	return loc
}

func execAdjust(c *Ctx, p *AdjustP) (*Result, *TxErr) {
	var a Adjustment
	exists, _ := getJSON(c.KV, KAdjust+p.AdjustmentID, &a)
	if p.Op == "PROPOSE" {
		if e := authorize(c, c.signer(), "stock.adjust.propose", scopeLoc(c, p.Location)); e != nil {
			return nil, e
		}
		if exists {
			return nil, errf(CodeExists, "adjustment exists")
		}
		if !isTransit(p.Location) {
			if _, e := c.loadLocation(p.Location); e != nil {
				return nil, e
			}
		} else if _, ok := c.KV.Get(KTransfer + p.Location[len(TransitPfx):]); !ok {
			return nil, errf(CodeNotFound, "transfer not found")
		}
		sku, e := c.loadSKU(p.SKU)
		if e != nil {
			return nil, e
		}
		_ = sku
		bal := getBalance(c.KV, p.SKU, p.Location)
		cur := *bucketPtr(&bal, p.Bucket)
		a = Adjustment{ID: p.AdjustmentID, SKU: p.SKU, Loc: p.Location, Bucket: p.Bucket, SystemQty: cur, BalVersion: bal.Version,
			CountedQty: p.CountedV, Delta: p.CountedV - cur, Reason: p.Reason, Evidence: p.Evidence, Status: "PENDING", Proposer: c.signer()}
		if a.Delta == 0 {
			return nil, errf(CodeArgument, "counted quantity equals system quantity; nothing to adjust")
		}
		c.touch(&a.Meta)
		putJSON(c.KV, KAdjust+a.ID, a)
		return &Result{Data: map[string]any{"adjustment_id": a.ID, "delta": a.Delta, "status": a.Status}}, nil
	}
	if !exists {
		return nil, errf(CodeNotFound, "adjustment not found")
	}
	if a.Status != "PENDING" {
		return nil, errf(CodeState, "adjustment is %s", a.Status)
	}
	if e := authorize(c, c.signer(), "stock.adjust.approve", scopeLoc(c, a.Loc)); e != nil {
		return nil, e
	}
	if a.Proposer == c.signer() {
		return nil, errf(CodePolicy, "separation of duties: proposer cannot decide own adjustment")
	}
	if e := c.checkVersion(a.Version); e != nil {
		return nil, e
	}
	abs := a.Delta
	if abs < 0 {
		abs = -abs
	}
	if abs > c.Params.AdjustSmallUnits && !hasGlobalPerm(c.KV, c.signer(), "stock.adjust.approve") {
		return nil, errf(CodePolicy, "adjustment of %d units exceeds local limit %d: global-scope approver required", abs, c.Params.AdjustSmallUnits)
	}
	a.Decider = c.signer()
	if p.Op == "REJECT" {
		a.Status = "REJECTED"
	} else {
		bal := getBalance(c.KV, a.SKU, a.Loc)
		if bal.Version != a.BalVersion {
			return nil, errf(CodeVersion, "stock moved since the count (balance v%d -> v%d): recount required", a.BalVersion, bal.Version)
		}
		var e *TxErr
		if a.Delta > 0 {
			e = c.postMovement(a.SKU, LocAdjust, BAvail, a.Loc, a.Bucket, a.Delta, "ADJUSTMENT_GAIN", "ADJUSTMENT", a.ID, c.BlockTimeMs, "NATIVE")
		} else {
			e = c.postMovement(a.SKU, a.Loc, a.Bucket, LocAdjust, BAvail, -a.Delta, "ADJUSTMENT_LOSS", "ADJUSTMENT", a.ID, c.BlockTimeMs, "NATIVE")
		}
		if e != nil {
			return nil, e
		}
		a.Status = "APPROVED"
	}
	c.touch(&a.Meta)
	putJSON(c.KV, KAdjust+a.ID, a)
	return &Result{Data: map[string]any{"adjustment_id": a.ID, "status": a.Status}}, nil
}
