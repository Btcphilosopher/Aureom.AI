package core

func init() {
	register("PublishPrice", "price.publish", false, vPublishPrice, locOfPrice, execPublishPrice)
	register("ActivatePromotion", "promo.manage", false, vPromo, nil, execPromo)
}

type PublishPriceP struct {
	PriceID   string `json:"price_id"`
	SKU       string `json:"sku"`
	Location  string `json:"location_id"` // location id or "*" for all locations
	Currency  string `json:"currency"`
	UnitMinor int64  `json:"unit_minor"` // price per WHOLE unit of the sku's unit (per each, per kg ...)
	From      int64  `json:"effective_from_ms"`
	To        int64  `json:"effective_to_ms"`
}

func vPublishPrice(p *PublishPriceP) *TxErr {
	if !validID(p.PriceID) || !validID(p.SKU) || (p.Location != "*" && !validID(p.Location)) {
		return errf(CodeInvalidField, "ids invalid")
	}
	if !validCcy(p.Currency) || p.UnitMinor <= 0 || p.UnitMinor > MaxMinor/1000 {
		return errf(CodeInvalidField, "currency/unit_minor invalid")
	}
	if p.From <= 0 || (p.To != 0 && p.To <= p.From) {
		return errf(CodeInvalidField, "effective period invalid")
	}
	return nil
}

func locOfPrice(c *Ctx, p *PublishPriceP) (string, *TxErr) {
	if p.Location == "*" {
		return "", nil // chain-wide prices need a global-scope grant
	}
	return p.Location, nil
}

const maxPriceEntries = 64

func execPublishPrice(c *Ctx, p *PublishPriceP) (*Result, *TxErr) {
	if _, ok := c.KV.Get(KPrice + p.PriceID); ok {
		return nil, errf(CodeExists, "price id exists")
	}
	if _, e := c.loadSKU(p.SKU); e != nil {
		return nil, e
	}
	if p.Location != "*" {
		l, e := c.loadLocation(p.Location)
		if e != nil {
			return nil, e
		}
		if l.Currency != p.Currency {
			return nil, errf(CodeArgument, "location %s trades in %s", l.ID, l.Currency)
		}
	}
	bk := KPriceBook + p.SKU + "/" + p.Location
	var pb PriceBook
	if ok, _ := getJSON(c.KV, bk, &pb); !ok {
		pb = PriceBook{SKU: p.SKU, Loc: p.Location}
	}
	if e := c.checkVersion(pb.Version); e != nil {
		return nil, e
	}
	for _, en := range pb.Entries {
		if en.From == p.From {
			return nil, errf(CodeExists, "a price with effective_from %d already exists for %s@%s", p.From, p.SKU, p.Location)
		}
	}
	pr := Price{ID: p.PriceID, SKU: p.SKU, Loc: p.Location, Currency: p.Currency, Unit: p.UnitMinor, From: p.From, To: p.To, Seq: nextSeq(c.KV, "price"), Prov: Provenance{Origin: "NATIVE"}}
	c.touch(&pr.Meta)
	putJSON(c.KV, KPrice+pr.ID, pr)
	pb.Entries = append(pb.Entries, PriceEntry{ID: pr.ID, From: pr.From, To: pr.To, Unit: pr.Unit, Ver: pr.Version, Seq: pr.Seq})
	// keep ordered by (from, seq); bounded
	for i := len(pb.Entries) - 1; i > 0 && pb.Entries[i].From < pb.Entries[i-1].From; i-- {
		pb.Entries[i], pb.Entries[i-1] = pb.Entries[i-1], pb.Entries[i]
	}
	if len(pb.Entries) > maxPriceEntries {
		pb.Entries = pb.Entries[len(pb.Entries)-maxPriceEntries:]
	}
	pb.Version++
	putJSON(c.KV, bk, pb)
	return &Result{Data: map[string]any{"price_id": pr.ID, "book_version": pb.Version}}, nil
}

// lookupPrice: location-specific book first, then the chain-wide "*" book.
// Entry choice: greatest effective_from <= t that has not ended; ties by publication seq.
func lookupPrice(kv KV, sku, loc string, t int64) (*PriceEntry, string, bool) {
	for _, l := range []string{loc, "*"} {
		var pb PriceBook
		if ok, _ := getJSON(kv, KPriceBook+sku+"/"+l, &pb); !ok {
			continue
		}
		var best *PriceEntry
		for i := range pb.Entries {
			e := &pb.Entries[i]
			if e.From <= t && (e.To == 0 || t < e.To) {
				if best == nil || e.From > best.From || (e.From == best.From && e.Seq > best.Seq) {
					best = e
				}
			}
		}
		if best != nil {
			return best, l, true
		}
	}
	return nil, "", false
}

// ---- Promotions ----

type PromoP struct {
	PromoID     string   `json:"promo_id"`
	Name        string   `json:"name"`
	Type        string   `json:"type"`
	Bp          int64    `json:"bp"`
	OffMinor    int64    `json:"off_minor"`
	BuyN        int64    `json:"buy_n"`
	BundleMinor int64    `json:"bundle_minor"`
	SKUs        []string `json:"skus"`
	Locs        []string `json:"locations"`
	From        int64    `json:"effective_from_ms"`
	To          int64    `json:"effective_to_ms"`
	Priority    int      `json:"priority"`
	Stackable   bool     `json:"stackable"`
	LoyaltyOnly bool     `json:"loyalty_only"`
	Status      string   `json:"status"` // ACTIVE | ENDED
	Currency    string   `json:"currency"`
}

const maxPromosPerSKU = 32

func vPromo(p *PromoP) *TxErr {
	if !validID(p.PromoID) || (p.Status != "ACTIVE" && p.Status != "ENDED") || !validCcy(p.Currency) {
		return errf(CodeInvalidField, "promo_id/status/currency invalid")
	}
	if e := checkStr("name", p.Name, 100, true); e != nil {
		return e
	}
	if len(p.SKUs) == 0 || len(p.SKUs) > 50 || len(p.Locs) == 0 || len(p.Locs) > 50 {
		return errf(CodeLimit, "1..50 skus and locations required")
	}
	for _, s := range p.SKUs {
		if !validID(s) {
			return errf(CodeInvalidField, "bad sku id")
		}
	}
	if p.From <= 0 || (p.To != 0 && p.To <= p.From) || p.Priority < 0 || p.Priority > 1000 {
		return errf(CodeInvalidField, "period/priority invalid")
	}
	switch p.Type {
	case "PERCENT_OFF":
		if p.Bp < 1 || p.Bp > 10000 {
			return errf(CodeInvalidField, "bp must be 1..10000")
		}
	case "AMOUNT_OFF_PER_UNIT":
		if p.OffMinor < 1 || p.OffMinor > MaxMinor/1000 {
			return errf(CodeInvalidField, "off_minor invalid")
		}
	case "MULTIBUY_FIXED_PRICE":
		if p.BuyN < 2 || p.BuyN > 100 || p.BundleMinor < 1 {
			return errf(CodeInvalidField, "buy_n/bundle_minor invalid")
		}
	default:
		return errf(CodeInvalidField, "unknown promotion type")
	}
	return nil
}

func execPromo(c *Ctx, p *PromoP) (*Result, *TxErr) {
	var pr Promotion
	exists, _ := getJSON(c.KV, KPromo+p.PromoID, &pr)
	if exists {
		if e := c.checkVersion(pr.Version); e != nil {
			return nil, e
		}
	}
	for _, s := range p.SKUs {
		if _, e := c.loadSKU(s); e != nil {
			return nil, e
		}
	}
	for _, l := range p.Locs {
		if l != "*" {
			if _, e := c.loadLocation(l); e != nil {
				return nil, e
			}
		}
	}
	old := pr.SKUs
	pr.ID, pr.Name, pr.Type, pr.Bp, pr.OffMinor, pr.BuyN, pr.BundleMinor = p.PromoID, p.Name, p.Type, p.Bp, p.OffMinor, p.BuyN, p.BundleMinor
	pr.SKUs, pr.Locs, pr.From, pr.To, pr.Priority, pr.Stackable, pr.LoyaltyOnly, pr.Status, pr.Currency =
		p.SKUs, p.Locs, p.From, p.To, p.Priority, p.Stackable, p.LoyaltyOnly, p.Status, p.Currency
	// maintain per-SKU promotion index (bounded) so execution never scans
	for _, s := range old {
		if !contains(p.SKUs, s) || p.Status == "ENDED" {
			var ix PromoIndex
			getJSON(c.KV, KPromoIdx+s, &ix)
			ix.IDs = removeStr(ix.IDs, pr.ID)
			putJSON(c.KV, KPromoIdx+s, ix)
		}
	}
	if p.Status == "ACTIVE" {
		for _, s := range p.SKUs {
			var ix PromoIndex
			getJSON(c.KV, KPromoIdx+s, &ix)
			if !contains(ix.IDs, pr.ID) {
				if len(ix.IDs) >= maxPromosPerSKU {
					return nil, errf(CodeLimit, "sku %s already has %d active promotions", s, maxPromosPerSKU)
				}
				ix.IDs = append(ix.IDs, pr.ID)
				putJSON(c.KV, KPromoIdx+s, ix)
			}
		}
	}
	c.touch(&pr.Meta)
	putJSON(c.KV, KPromo+pr.ID, pr)
	return &Result{Data: map[string]any{"promo_id": pr.ID, "status": pr.Status, "version": pr.Version}}, nil
}

// priceLine computes a sale line deterministically and records the exact inputs and
// every promotion step. Promotion precedence:
//  1. candidates = ACTIVE promotions indexed on the SKU, in effect at effective_at, matching location
//     (and loyalty membership if loyalty_only);
//  2. sorted by (priority ASC, promo_id ASC);
//  3. applied sequentially on the running net amount; a non-stackable promotion is skipped if any
//     promotion has already applied, and after a non-stackable promotion applies no further promotions run;
//  4. each discount is capped at the running net amount; rounding is half-even on integer minor units.
func priceLine(c *Ctx, loc string, ccy string, sku *SKU, q Qty, eff int64, loyalCustomer bool) (SaleLine, *TxErr) {
	pe, _, ok := lookupPrice(c.KV, sku.ID, loc, eff)
	if !ok {
		return SaleLine{}, errf(CodeNotFound, "no price for %s at %s effective %d", sku.ID, loc, eff)
	}
	var pr Price
	getJSON(c.KV, KPrice+pe.ID, &pr)
	if pr.Currency != ccy {
		return SaleLine{}, errf(CodeArgument, "price currency %s differs from sale currency %s", pr.Currency, ccy)
	}
	gross := lineAmount(pr.Unit, q)
	l := SaleLine{SKU: sku.ID, Qty: q, PriceID: pr.ID, PriceVersion: pr.Version, UnitMinor: pr.Unit, Gross: gross, Net: gross, Steps: []PricingStep{}}
	var ix PromoIndex
	getJSON(c.KV, KPromoIdx+sku.ID, &ix)
	type cand struct {
		pr Promotion
	}
	var cands []Promotion
	for _, id := range ix.IDs {
		var pm Promotion
		if ok, _ := getJSON(c.KV, KPromo+id, &pm); !ok || pm.Status != "ACTIVE" || pm.Currency != ccy {
			continue
		}
		if pm.From > eff || (pm.To != 0 && eff >= pm.To) || (pm.LoyaltyOnly && !loyalCustomer) {
			continue
		}
		if !contains(pm.Locs, "*") && !contains(pm.Locs, loc) {
			continue
		}
		cands = append(cands, pm)
	}
	// insertion sort by (priority, id): deterministic and bounded (<=32)
	for i := 1; i < len(cands); i++ {
		for j := i; j > 0 && (cands[j].Priority < cands[j-1].Priority || (cands[j].Priority == cands[j-1].Priority && cands[j].ID < cands[j-1].ID)); j-- {
			cands[j], cands[j-1] = cands[j-1], cands[j]
		}
	}
	applied := 0
	for _, pm := range cands {
		if !pm.Stackable && applied > 0 {
			l.Steps = append(l.Steps, PricingStep{PromoID: pm.ID, PromoVersion: pm.Version, Type: pm.Type, Before: l.Net, After: l.Net, Explain: "skipped: non-stackable and another promotion already applied"})
			continue
		}
		var d int64
		var why string
		switch pm.Type {
		case "PERCENT_OFF":
			d = mulDivHalfEven(l.Net, pm.Bp, 10000)
			why = "round_half_even(net x bp/10000)"
		case "AMOUNT_OFF_PER_UNIT":
			d = lineAmount(pm.OffMinor, q)
			why = "off_minor per whole unit x qty"
		case "MULTIBUY_FIXED_PRICE":
			if q.Unit != "EA" && q.Unit != "PK" {
				continue
			}
			groups := q.V / pm.BuyN
			per := pm.BuyN*pr.Unit - pm.BundleMinor
			if groups > 0 && per > 0 {
				d = groups * per
			}
			why = "groups of buy_n at bundle price vs list price"
		}
		if d > l.Net {
			d = l.Net
			why += "; capped at running net"
		}
		if d <= 0 {
			continue
		}
		l.Steps = append(l.Steps, PricingStep{PromoID: pm.ID, PromoVersion: pm.Version, Type: pm.Type, Before: l.Net, Discount: d, After: l.Net - d, Explain: why})
		l.Net -= d
		l.Discount += d
		applied++
		if !pm.Stackable {
			break
		}
	}
	return l, nil
}
