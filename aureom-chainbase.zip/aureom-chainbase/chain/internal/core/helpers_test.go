package core_test

import (
	"crypto/ed25519"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

const T0 = int64(1_790_000_000_000)
const Net = "aureom-test-1"

type H struct {
	t    *testing.T
	sim  *core.Sim
	keys map[string]ed25519.PrivateKey
	n    int
}

func newH(t *testing.T) *H {
	g, keys := demo.TestGenesis(Net)
	sim, err := core.NewSim(g, T0)
	if err != nil {
		t.Fatal(err)
	}
	return &H{t: t, sim: sim, keys: keys}
}

type opt func(*core.Body)

func withVersion(v int64) opt { return func(b *core.Body) { b.ExpectedVersion = &v } }
func withIdem(s string) opt   { return func(b *core.Body) { b.Idempotency = s } }
func withTxID(s string) opt   { return func(b *core.Body) { b.TxID = s } }
func withNet(s string) opt    { return func(b *core.Body) { b.NetworkID = s } }

func (h *H) tx(signer, typ string, payload any, opts ...opt) []byte {
	h.n++
	raw, _ := json.Marshal(payload)
	b := core.Body{TxID: fmt.Sprintf("tx-%06d", h.n), Type: typ, Signer: signer, KeyID: "k1", Idempotency: fmt.Sprintf("idem-%06d", h.n),
		ClientTimeMs: h.sim.TimeMs, Payload: raw}
	for _, o := range opts {
		o(&b)
	}
	net := Net
	if b.NetworkID != "" {
		net = b.NetworkID
	}
	// SignTx overwrites NetworkID with its argument; for wrong-network tests sign for that network.
	return core.SignTx(net, b, h.keys[signer])
}

func (h *H) block(txs ...[]byte) []core.Outcome {
	return h.sim.Block(1000, txs...).Results
}

func (h *H) do(signer, typ string, payload any, opts ...opt) core.Outcome {
	return h.block(h.tx(signer, typ, payload, opts...))[0]
}

func (h *H) mustOK(signer, typ string, payload any, opts ...opt) core.Outcome {
	h.t.Helper()
	o := h.do(signer, typ, payload, opts...)
	if o.Code != 0 {
		h.t.Fatalf("%s by %s failed: %s %s", typ, signer, core.CodeName(o.Code), o.Log)
	}
	return o
}

func (h *H) expect(code uint32, signer, typ string, payload any, opts ...opt) core.Outcome {
	h.t.Helper()
	o := h.do(signer, typ, payload, opts...)
	if o.Code != code {
		h.t.Fatalf("%s by %s: want %s got %s (%s)", typ, signer, core.CodeName(code), core.CodeName(o.Code), o.Log)
	}
	return o
}

func get[T any](h *H, key string) T {
	h.t.Helper()
	var v T
	raw, ok := h.sim.KV.Get(key)
	if !ok {
		h.t.Fatalf("missing key %s", key)
	}
	if err := json.Unmarshal(raw, &v); err != nil {
		h.t.Fatal(err)
	}
	return v
}

func (h *H) bal(sku, loc string) core.Balance {
	raw, ok := h.sim.KV.Get(core.KBalance + sku + "/" + loc)
	var b core.Balance
	if ok {
		json.Unmarshal(raw, &b)
	}
	return b
}

type m = map[string]any

func qty(v int64) m { return m{"v": v, "unit": "EA"} }

// seedCatalog creates a product (2 variants), supplier, price and stocks a store with `units` of SKU-A.
func (h *H) seedCatalog(units int64) {
	h.mustOK("catalog-mgr", "CreateProduct", m{"product_id": "P-1", "name": "Oat Milk 1L", "brand": "Fiction Farms", "category": "dairy-free",
		"variants": []m{{"sku_id": "SKU-A", "barcode": "5000000000011", "unit": "EA"}, {"sku_id": "SKU-B", "barcode": "5000000000028", "unit": "EA", "scarce": true}}})
	h.mustOK("hq-iam-admin", "CreateSupplier", m{"supplier_id": "SUP-1", "name": "Fictional Foods Ltd", "terms": "NET30"})
	for _, sku := range []string{"SKU-A", "SKU-B"} {
		h.mustOK("pricing-mgr", "PublishPrice", m{"price_id": "PR-" + sku, "sku": sku, "location_id": "*", "currency": "GBP", "unit_minor": 250, "effective_from_ms": T0 - 86400000})
	}
	h.mustOK("buyer-hq", "CreatePurchaseOrder", m{"po_id": "PO-1", "supplier_id": "SUP-1", "location_id": "STORE-N-01", "currency": "GBP", "ordered_at_ms": T0,
		"lines": []m{{"sku": "SKU-A", "qty": qty(units), "unit_cost_minor": 100}}})
	h.mustOK("po-approver-hq", "ApprovePurchaseOrder", m{"po_id": "PO-1"})
	h.mustOK("manager-n01", "ReceiveGoods", m{"receipt_id": "GR-1", "location_id": "STORE-N-01", "po_id": "PO-1", "effective_at_ms": h.sim.TimeMs,
		"lines": []m{{"sku": "SKU-A", "qty": qty(units), "po_line": 1}}})
}

// conservation: for every SKU the sum of all balances over all locations (including EXT:* counter-parties) is zero,
// and every physical balance equals the replay of the movement ledger.
func (h *H) checkInvariants() {
	h.t.Helper()
	sums := map[string]int64{}
	derived := map[string]*core.Balance{}
	for k, v := range h.sim.KV.M {
		if strings.HasPrefix(k, core.KBalance) {
			var b core.Balance
			json.Unmarshal(v, &b)
			sums[b.SKU] += b.Available + b.Reserved + b.Quarantined + b.Damaged
			if !strings.HasPrefix(b.Loc, "EXT:") && (b.Available < 0 || b.Reserved < 0 || b.Quarantined < 0 || b.Damaged < 0) {
				h.t.Fatalf("negative physical balance %+v", b)
			}
		}
		if strings.HasPrefix(k, core.KMovement) {
			var mv core.Movement
			json.Unmarshal(v, &mv)
			for _, side := range []struct {
				loc, bucket string
				sign        int64
			}{{mv.FromLoc, mv.FromBucket, -1}, {mv.ToLoc, mv.ToBucket, 1}} {
				dk := mv.SKU + "/" + side.loc
				b := derived[dk]
				if b == nil {
					b = &core.Balance{}
					derived[dk] = b
				}
				switch side.bucket {
				case core.BAvail:
					b.Available += side.sign * mv.Qty
				case core.BResv:
					b.Reserved += side.sign * mv.Qty
				case core.BQuar:
					b.Quarantined += side.sign * mv.Qty
				case core.BDamage:
					b.Damaged += side.sign * mv.Qty
				}
			}
		}
	}
	for sku, s := range sums {
		if s != 0 {
			h.t.Fatalf("conservation violated for %s: net %d", sku, s)
		}
	}
	for k, d := range derived {
		var b core.Balance
		parts := strings.SplitN(k, "/", 2)
		if raw, ok := h.sim.KV.Get(core.KBalance + k); ok {
			json.Unmarshal(raw, &b)
		}
		if b.Available != d.Available || b.Reserved != d.Reserved || b.Quarantined != d.Quarantined || b.Damaged != d.Damaged {
			h.t.Fatalf("balance %s != ledger replay: stored %+v derived %+v", parts, b, d)
		}
	}
}
