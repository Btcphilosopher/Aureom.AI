package core_test

import (
	"testing"

	"github.com/aureom/chainbase/internal/core"
)

func TestPromotionPrecedenceIsDeterministic(t *testing.T) {
	h := newH(t)
	h.seedCatalog(20)
	promo := func(id string, typ string, prio int, stack bool, extra m) {
		p := m{"promo_id": id, "name": id, "type": typ, "skus": []string{"SKU-A"}, "locations": []string{"*"}, "effective_from_ms": T0 - 1000, "effective_to_ms": 0,
			"priority": prio, "stackable": stack, "status": "ACTIVE", "currency": "GBP"}
		for k, v := range extra {
			p[k] = v
		}
		h.mustOK("pricing-mgr", "ActivatePromotion", p)
	}
	promo("A-STACK-10", "PERCENT_OFF", 5, true, m{"bp": 1000})
	promo("B-STACK-50p", "AMOUNT_OFF_PER_UNIT", 6, true, m{"off_minor": 50})
	promo("C-EXCL-30", "PERCENT_OFF", 7, false, m{"bp": 3000})
	promo("D-EXCL-LATE", "PERCENT_OFF", 8, false, m{"bp": 9000})
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(4), "ttl_ms": 600000})
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(4), "reservation_id": "RS-1"}}})
	s := get[core.Sale](h, core.KSale+"S-1")
	l := s.Lines[0]
	// gross 4*250=1000 ; A(stackable,prio5): -10% => 900 ; B(stackable,prio6): -4*50=200 => 700 ;
	// C and D are NON-stackable and a promotion already applied => both skipped (recorded as skipped steps)
	if l.Gross != 1000 || l.Net != 700 || l.Discount != 300 {
		t.Fatalf("line %+v", l)
	}
	if len(l.Steps) != 4 || l.Steps[0].PromoID != "A-STACK-10" || l.Steps[2].PromoID != "C-EXCL-30" || l.Steps[2].Discount != 0 || l.Steps[3].Discount != 0 {
		t.Fatalf("steps %+v", l.Steps)
	}
	if l.PriceID != "PR-SKU-A" || l.PriceVersion != 1 || l.UnitMinor != 250 {
		t.Fatalf("pricing inputs must be preserved: %+v", l)
	}
	// later price publication and promotion changes do not alter the completed sale
	tPub := h.sim.TimeMs
	h.mustOK("pricing-mgr", "PublishPrice", m{"price_id": "PR-NEW", "sku": "SKU-A", "location_id": "*", "currency": "GBP", "unit_minor": 999, "effective_from_ms": tPub})
	if s2 := get[core.Sale](h, core.KSale+"S-1"); s2.Net != 700 {
		t.Fatal("completed sale changed")
	}
	// price lookup is by effective time: a backdated sale still uses the old price
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-2", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000})
	h.mustOK("pricing-mgr", "ActivatePromotion", m{"promo_id": "A-STACK-10", "name": "ended", "type": "PERCENT_OFF", "bp": 1000, "skus": []string{"SKU-A"}, "locations": []string{"*"},
		"effective_from_ms": T0 - 1000, "priority": 5, "stackable": true, "status": "ENDED", "currency": "GBP"}, withVersion(1))
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-2", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": tPub - 1, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-2"}}})
	if s2 := get[core.Sale](h, core.KSale+"S-2"); s2.Lines[0].UnitMinor != 250 {
		t.Fatalf("effective-dated price: %+v", s2.Lines[0])
	}
	// expected_total check: price drift is refused
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-3", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000})
	h.expect(core.CodeArgument, "cashier-n01", "CompleteSale", m{"sale_id": "S-3", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD", "expected_total_minor": 1,
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-3"}}})
}

func TestMultibuyAndWeightedUnits(t *testing.T) {
	h := newH(t)
	h.mustOK("catalog-mgr", "CreateProduct", m{"product_id": "P-C", "name": "Cheddar", "variants": []m{{"sku_id": "CHEESE", "unit": "KG"}}})
	h.mustOK("hq-iam-admin", "CreateSupplier", m{"supplier_id": "SUP-1", "name": "S"})
	h.mustOK("pricing-mgr", "PublishPrice", m{"price_id": "PR-C", "sku": "CHEESE", "location_id": "*", "currency": "GBP", "unit_minor": 1099, "effective_from_ms": T0 - 1})
	h.mustOK("manager-n01", "ReceiveGoods", m{"receipt_id": "GR-1", "location_id": "STORE-N-01", "supplier_id": "SUP-1", "effective_at_ms": h.sim.TimeMs, "lines": []m{{"sku": "CHEESE", "qty": m{"v": 5000, "unit": "KG"}}}})
	// wrong unit is refused: explicit units
	h.expect(core.CodeArgument, "cashier-n01", "ReserveStock", m{"reservation_id": "R0", "location_id": "STORE-N-01", "sku": "CHEESE", "qty": qty(1), "ttl_ms": 1000})
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "R1", "location_id": "STORE-N-01", "sku": "CHEESE", "qty": m{"v": 350, "unit": "KG"}, "ttl_ms": 600000}) // 0.350 kg
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "CHEESE", "qty": m{"v": 350, "unit": "KG"}, "reservation_id": "R1"}}})
	// 10.99/kg * 0.350 = 3.8465 -> half-even rounding to 3.85 (385 minor)
	if s := get[core.Sale](h, core.KSale+"S-1"); s.Net != 385 {
		t.Fatalf("weighted line %d", s.Net)
	}
}

func TestPaymentIdempotencyAndExceptions(t *testing.T) {
	h := newH(t)
	h.seedCatalog(5)
	mk := func(id string) {
		h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-" + id, "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 600000})
		h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": id, "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
			"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-" + id}}})
	}
	mk("S-1")
	pay := func(ev string, amt int64) core.Outcome {
		return h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "SIMPAY", "event_id": ev, "provider_ref": "ch", "result": "CONFIRMED", "amount_minor": amt, "currency": "GBP"})
	}
	pay("evt-1", 100) // partial: mismatch exception
	if s := get[core.Sale](h, core.KSale+"S-1"); s.PaymentStatus != "PARTIALLY_PAID" || s.Paid != 100 {
		t.Fatalf("%+v", s)
	}
	o := pay("evt-1", 100) // duplicate provider callback: deduplicated, no double count
	if string(o.Data) == "" || get[core.Sale](h, core.KSale+"S-1").Paid != 100 {
		t.Fatalf("duplicate callback must not change state: %s", o.Data)
	}
	pay("evt-2", 150)
	if s := get[core.Sale](h, core.KSale+"S-1"); s.PaymentStatus != "CONFIRMED" || s.Paid != 250 {
		t.Fatalf("%+v", s)
	}
	pay("evt-3", 10) // overpayment => exception
	if s := get[core.Sale](h, core.KSale+"S-1"); s.PaymentStatus != "OVERPAID" {
		t.Fatalf("%+v", s)
	}
	exc := 0
	for k := range h.sim.KV.M {
		if len(k) > 4 && k[:4] == "exc/" {
			exc++
		}
	}
	if exc != 2 {
		t.Fatalf("expected 2 reconciliation exceptions, got %d", exc)
	}
	// failed payment
	mk("S-2")
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-2", "provider": "SIMPAY", "event_id": "evt-9", "provider_ref": "dec", "result": "FAILED", "amount_minor": 0, "currency": "GBP"})
	if s := get[core.Sale](h, core.KSale+"S-2"); s.PaymentStatus != "FAILED" || s.SaleStatus != "COMPLETED" {
		t.Fatalf("sale/payment states must be separate: %+v", s)
	}
	// late success after failure
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-2", "provider": "SIMPAY", "event_id": "evt-10", "provider_ref": "retry", "result": "CONFIRMED", "amount_minor": 250, "currency": "GBP"})
	if s := get[core.Sale](h, core.KSale+"S-2"); s.PaymentStatus != "CONFIRMED" {
		t.Fatalf("%+v", s)
	}
	// only the payment adapter role may record results
	h.expect(core.CodeUnauthorized, "cashier-n01", "RecordPaymentResult", m{"sale_id": "S-2", "provider": "X", "event_id": "e", "provider_ref": "r", "result": "CONFIRMED", "amount_minor": 1, "currency": "GBP"})
}

func TestLoyaltyRedeemReverseShortfall(t *testing.T) {
	h := newH(t)
	h.seedCatalog(10)
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "RS-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(4), "ttl_ms": 600000})
	h.mustOK("cashier-n01", "CompleteSale", m{"sale_id": "S-1", "location_id": "STORE-N-01", "channel": "STORE", "customer_id": "CUST-0000AB", "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(4), "reservation_id": "RS-1"}}})
	h.mustOK("payment-adapter-1", "RecordPaymentResult", m{"sale_id": "S-1", "provider": "P", "event_id": "e", "provider_ref": "r", "result": "CONFIRMED", "amount_minor": 1000, "currency": "GBP"})
	h.mustOK("loyalty-op", "CreditLoyalty", m{"entry_id": "LE-1", "customer_id": "CUST-0000AB", "sale_id": "S-1"}) // 10 points
	redeem := func(id, ref string, pts int64) []byte {
		return h.tx("cashier-n01", "RedeemLoyalty", m{"entry_id": id, "customer_id": "CUST-0000AB", "location_id": "STORE-N-01", "points": pts, "redemption_ref": ref, "effective_at_ms": h.sim.TimeMs})
	}
	// two terminals try to redeem the same voucher in one block: only the first succeeds
	r := h.block(redeem("LE-R1", "VOUCHER-1", 8), redeem("LE-R2", "VOUCHER-1", 8))
	if r[0].Code != 0 || r[1].Code != core.CodeExists {
		t.Fatalf("duplicate redemption: %d %d", r[0].Code, r[1].Code)
	}
	// cannot redeem more than the balance
	h.expect(core.CodeInsufficient, "cashier-n01", "RedeemLoyalty", m{"entry_id": "LE-R3", "customer_id": "CUST-0000AB", "location_id": "STORE-N-01", "points": 5, "redemption_ref": "VOUCHER-2", "effective_at_ms": h.sim.TimeMs})
	// full refund after points were redeemed => reversal shortfall flagged, balance floors at zero
	h.mustOK("cashier-n01", "RequestReturn", m{"return_id": "R-1", "sale_id": "S-1", "lines": []m{{"line_no": 1, "qty_v": 4, "reason": "x"}}})
	h.mustOK("manager-n01", "ApproveReturn", m{"return_id": "R-1", "decision": "APPROVE"})
	h.mustOK("manager-n01", "ReceiveReturnedGoods", m{"return_id": "R-1", "lines": []m{{"line_no": 1, "qty_v": 4, "inspection": "RESELLABLE"}}})
	h.mustOK("payment-adapter-1", "RecordRefundResult", m{"refund_id": "RF-R-1-001", "provider": "P", "event_id": "rf", "provider_ref": "x", "result": "CONFIRMED", "amount_minor": 1000})
	h.mustOK("finance-ctrl", "ReverseBusinessEntry", m{"reversal_id": "REV-1", "target_type": "LOYALTY_ENTRY", "target_id": "LE-1", "refund_id": "RF-R-1-001", "reason": "full refund"})
	a := get[core.LoyaltyAccount](h, core.KLoyalty+"CUST-0000AB")
	rev := get[core.LoyaltyEntry](h, core.KLoyEntry+"REV-1")
	if a.Points != 0 || rev.Shortfall != 8 || rev.Points != -2 {
		t.Fatalf("account %+v reversal %+v", a, rev)
	}
	// cannot reverse the same entry twice beyond its points
	h.expect(core.CodeState, "finance-ctrl", "ReverseBusinessEntry", m{"reversal_id": "REV-2", "target_type": "LOYALTY_ENTRY", "target_id": "LE-1", "refund_id": "RF-R-1-001", "reason": "again"})
	// real customer identifiers are refused outright on the replicated ledger
	h.expect(core.CodeInvalidField, "cashier-n01", "CompleteSale", m{"sale_id": "S-X", "location_id": "STORE-N-01", "channel": "STORE", "customer_id": "alice@example.com", "effective_at_ms": h.sim.TimeMs, "currency": "GBP",
		"payment_method": "CARD", "lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "RS-1"}}})
}

func TestTransfersTrackDispatchAndReceipt(t *testing.T) {
	h := newH(t)
	h.seedCatalog(1)
	h.mustOK("wh-manager-dist", "ReceiveGoods", m{"receipt_id": "GR-W", "location_id": "WH-DIST-01", "supplier_id": "SUP-1", "effective_at_ms": h.sim.TimeMs, "lines": []m{{"sku": "SKU-A", "qty": qty(10)}}})
	h.mustOK("wh-operator-dist", "TransferStock", m{"op": "DISPATCH", "transfer_id": "X-1", "from_location": "WH-DIST-01", "to_location": "STORE-N-02", "lines": []m{{"sku": "SKU-A", "qty": qty(6)}}})
	// destination has NOT received anything yet; stock is in transit and not sellable anywhere
	if b := h.bal("SKU-A", "STORE-N-02"); b.OnHand() != 0 {
		t.Fatalf("destination stock appeared at dispatch: %+v", b)
	}
	if b := h.bal("SKU-A", "TRANSIT:X-1"); b.Available != 6 {
		t.Fatalf("transit %+v", b)
	}
	if b := h.bal("SKU-A", "WH-DIST-01"); b.Available != 4 {
		t.Fatalf("source %+v", b)
	}
	// only a receiver at the destination may confirm receipt
	h.expect(core.CodeScope, "manager-n01", "TransferStock", m{"op": "RECEIVE", "transfer_id": "X-1", "lines": []m{{"sku": "SKU-A", "qty": qty(5)}}})
	h.mustOK("hq-iam-admin", "GrantRole", m{"identity_id": "manager-n01", "role": "store-manager", "scope": "loc:STORE-N-02"})
	// partial receipt: 4 good + 1 damaged of 6 sent => 1 unit still in transit => discrepancy exception
	h.mustOK("manager-n01", "TransferStock", m{"op": "RECEIVE", "transfer_id": "X-1", "lines": []m{{"sku": "SKU-A", "qty": qty(5), "damaged_v": 1}}})
	x := get[core.Transfer](h, core.KTransfer+"X-1")
	if x.Status != "RECEIVED_WITH_DISCREPANCY" {
		t.Fatalf("%+v", x)
	}
	if b := h.bal("SKU-A", "STORE-N-02"); b.Available != 4 || b.Damaged != 1 {
		t.Fatalf("%+v", b)
	}
	if b := h.bal("SKU-A", "TRANSIT:X-1"); b.Available != 1 {
		t.Fatalf("missing unit must remain in transit until resolved by an approved adjustment: %+v", b)
	}
	// resolve via maker-checker write-off at the transit location
	h.mustOK("wh-operator-dist", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "ADJ-T", "location_id": "TRANSIT:X-1", "sku": "SKU-A", "bucket": "available", "counted_v": 0, "reason": "lost in transit - carrier claim 77", "evidence_ref": "claim-77"})
	h.mustOK("wh-manager-dist", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-T"})
	if b := h.bal("SKU-A", "TRANSIT:X-1"); b.OnHand() != 0 {
		t.Fatalf("%+v", b)
	}
	h.checkInvariants()
}

func TestReservationExpiryAndAllowance(t *testing.T) {
	h := newH(t)
	h.seedCatalog(10)
	h.mustOK("term-n01-1", "ReserveStock", m{"reservation_id": "ALLOW-1", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(5), "ttl_ms": 86400000, "terminal_id": "term-n01-1", "allowance": true})
	// ordinary reservations are capped at 30 minutes
	h.expect(core.CodeLimit, "term-n01-1", "ReserveStock", m{"reservation_id": "R-LONG", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 86400000})
	// partial consumption of an allowance by its own terminal
	sell := func(id string, q int64, term string) core.Outcome {
		return h.do(term, "CompleteSale", m{"sale_id": id, "location_id": "STORE-N-01", "channel": "STORE", "terminal_id": term, "effective_at_ms": h.sim.TimeMs, "currency": "GBP", "payment_method": "CASH",
			"lines": []m{{"sku": "SKU-A", "qty": qty(q), "reservation_id": "ALLOW-1"}}})
	}
	if o := sell("OFF-1", 2, "term-n01-1"); o.Code != 0 {
		t.Fatalf("%s", o.Log)
	}
	if o := sell("OFF-2", 2, "term-n01-2"); o.Code != core.CodePolicy { // bound to another terminal
		t.Fatalf("allowance bound to terminal: %s", core.CodeName(o.Code))
	}
	if o := sell("OFF-3", 4, "term-n01-1"); o.Code != core.CodeInsufficient { // only 3 left
		t.Fatalf("overselling the allowance: %s", core.CodeName(o.Code))
	}
	if o := sell("OFF-4", 3, "term-n01-1"); o.Code != 0 {
		t.Fatalf("%s", o.Log)
	}
	if r := get[core.Reservation](h, core.KReserve+"ALLOW-1"); r.Status != "CONSUMED" {
		t.Fatalf("%+v", r)
	}
	// expiry uses BLOCK time and is released by an explicit transaction
	h.mustOK("cashier-n01", "ReserveStock", m{"reservation_id": "R-EXP", "location_id": "STORE-N-01", "sku": "SKU-A", "qty": qty(1), "ttl_ms": 60000})
	h.expect(core.CodeState, "cashier-n01", "ReleaseReservation", m{"reservation_id": "R-EXP", "reason": "EXPIRED"})
	h.sim.Block(120_000)
	h.expect(core.CodeState, "cashier-n01", "CompleteSale", m{"sale_id": "S-LATE", "location_id": "STORE-N-01", "channel": "STORE", "effective_at_ms": h.sim.TimeMs - 100_000, "currency": "GBP", "payment_method": "CARD",
		"lines": []m{{"sku": "SKU-A", "qty": qty(1), "reservation_id": "R-EXP"}}})
	h.mustOK("cashier-n01", "ReleaseReservation", m{"reservation_id": "R-EXP", "reason": "EXPIRED"})
	h.checkInvariants()
}

func TestCompensatingReversals(t *testing.T) {
	h := newH(t)
	h.seedCatalog(10)
	// reverse a goods receipt: original preserved, linked reversal recorded, stock removed
	h.mustOK("wh-manager-dist", "ReceiveGoods", m{"receipt_id": "GR-BAD", "location_id": "WH-DIST-01", "supplier_id": "SUP-1", "effective_at_ms": h.sim.TimeMs, "lines": []m{{"sku": "SKU-A", "qty": qty(7)}}})
	h.mustOK("wh-manager-dist", "ReverseBusinessEntry", m{"reversal_id": "REV-GR", "target_type": "GOODS_RECEIPT", "target_id": "GR-BAD", "reason": "supplier delivery note was for another depot"})
	if r := get[core.GoodsReceipt](h, core.KReceipt+"GR-BAD"); !r.Reversed || len(r.Lines) != 1 {
		t.Fatalf("original must remain visible: %+v", r)
	}
	if b := h.bal("SKU-A", "WH-DIST-01"); b.OnHand() != 0 {
		t.Fatalf("%+v", b)
	}
	h.expect(core.CodeState, "wh-manager-dist", "ReverseBusinessEntry", m{"reversal_id": "REV-GR2", "target_type": "GOODS_RECEIPT", "target_id": "GR-BAD", "reason": "again"})
	// reverse an approved adjustment
	h.mustOK("manager-n01", "AdjustStock", m{"op": "PROPOSE", "adjustment_id": "ADJ-1", "location_id": "STORE-N-01", "sku": "SKU-A", "bucket": "available", "counted_v": 8, "reason": "r", "evidence_ref": "e"})
	h.mustOK("hq-iam-admin", "GrantRole", m{"identity_id": "manager-s01", "role": "store-manager", "scope": "loc:STORE-N-01"})
	h.mustOK("manager-s01", "AdjustStock", m{"op": "APPROVE", "adjustment_id": "ADJ-1"})
	h.mustOK("manager-n01", "ReverseBusinessEntry", m{"reversal_id": "REV-ADJ", "target_type": "STOCK_ADJUSTMENT", "target_id": "ADJ-1", "reason": "miscount"})
	if b := h.bal("SKU-A", "STORE-N-01"); b.Available != 10 {
		t.Fatalf("%+v", b)
	}
	if a := get[core.Adjustment](h, core.KAdjust+"ADJ-1"); a.Status != "REVERSED" {
		t.Fatalf("%+v", a)
	}
	h.checkInvariants()
}
