// Package core is the deterministic AUREOM CHAINBASE business state machine.
//
// Determinism rules enforced throughout this package:
//   - no wall-clock, randomness, floats, goroutines or map iteration in execution paths
//   - all time comes from the block header (ctx.BlockTimeMs); client time is only a claim
//   - all amounts are integers (minor units / scaled quantity units)
//   - every execution step is bounded (max lines, max string sizes, no unbounded scans)
//   - no network or filesystem access
package core

import (
	"bytes"
	"encoding/json"
	"fmt"
)

// KV is the minimal state interface used by handlers.
type KV interface {
	Get(key string) ([]byte, bool)
	Set(key string, value []byte)
	Delete(key string)
}

// Write is one recorded state change (value==nil means delete).
type Write struct {
	Key   string
	Value []byte
	Del   bool
}

// Overlay buffers writes over a parent KV so a failed transaction leaves no trace
// (atomic state changes). Write order is the order of first write to each key.
type Overlay struct {
	parent KV
	m      map[string]*Write
	order  []string
}

func NewOverlay(parent KV) *Overlay { return &Overlay{parent: parent, m: map[string]*Write{}} }

func (o *Overlay) Get(key string) ([]byte, bool) {
	if w, ok := o.m[key]; ok {
		if w.Del {
			return nil, false
		}
		return w.Value, true
	}
	return o.parent.Get(key)
}

func (o *Overlay) put(key string, w *Write) {
	if _, ok := o.m[key]; !ok {
		o.order = append(o.order, key)
	}
	o.m[key] = w
}
func (o *Overlay) Set(key string, value []byte) {
	o.put(key, &Write{Key: key, Value: append([]byte(nil), value...)})
}
func (o *Overlay) Delete(key string) { o.put(key, &Write{Key: key, Del: true}) }

// Writes returns the buffered writes in deterministic (first-write) order.
func (o *Overlay) Writes() []Write {
	out := make([]Write, 0, len(o.order))
	for _, k := range o.order {
		out = append(out, *o.m[k])
	}
	return out
}

// Flush applies the buffered writes to the parent in order.
func (o *Overlay) Flush() {
	for _, k := range o.order {
		w := o.m[k]
		if w.Del {
			o.parent.Delete(k)
		} else {
			o.parent.Set(k, w.Value)
		}
	}
}

// MemStore is a trivial in-memory KV (tests, genesis dumps, replay tooling).
type MemStore struct{ M map[string][]byte }

func NewMemStore() *MemStore { return &MemStore{M: map[string][]byte{}} }
func (s *MemStore) Get(k string) ([]byte, bool) {
	v, ok := s.M[k]
	return v, ok
}
func (s *MemStore) Set(k string, v []byte) { s.M[k] = append([]byte(nil), v...) }
func (s *MemStore) Delete(k string)        { delete(s.M, k) }

// JSON helpers. HTML escaping is disabled so stored bytes are human readable and
// identical across languages' naive encoders.
func MarshalJSON(v any) []byte {
	var b bytes.Buffer
	e := json.NewEncoder(&b)
	e.SetEscapeHTML(false)
	if err := e.Encode(v); err != nil {
		panic(fmt.Sprintf("marshal: %v", err))
	}
	return bytes.TrimRight(b.Bytes(), "\n")
}

func getJSON(kv KV, key string, v any) (bool, error) {
	raw, ok := kv.Get(key)
	if !ok {
		return false, nil
	}
	if err := json.Unmarshal(raw, v); err != nil {
		return false, fmt.Errorf("corrupt record %s: %w", key, err)
	}
	return true, nil
}

func putJSON(kv KV, key string, v any) { kv.Set(key, MarshalJSON(v)) }

// Key namespace (all keys are printable ASCII; IDs never contain '/').
const (
	KProduct   = "product/"
	KSKU       = "sku/"
	KBarcode   = "bcode/"
	KLocation  = "loc/"
	KSupplier  = "supplier/"
	KPO        = "po/"
	KReceipt   = "receipt/"
	KBalance   = "bal/" // bal/<sku>/<loc>
	KMovement  = "mov/" // mov/<sku>/<seq12>
	KReserve   = "resv/"
	KSale      = "sale/"
	KReturn    = "return/"
	KRefund    = "refund/"
	KPrice     = "price/"
	KPriceBook = "pbook/" // pbook/<sku>/<loc>
	KPromo     = "promo/"
	KPromoIdx  = "pidx/" // pidx/<sku|*>
	KLoyalty   = "loy/"
	KLoyEntry  = "loye/"
	KLoyRef    = "loyref/"
	KAdjust    = "adjust/"
	KTransfer  = "xfer/"
	KException = "exc/"
	KReversal  = "reversal/"
	KPayEvent  = "payev/"
	KIdentity  = "iam/id/"
	KGrants    = "iam/grants/"
	KTx        = "tx/"
	KIdem      = "idem/"
	KMember    = "gov/member/"
	KMembers   = "gov/members"
	KNode      = "gov/node/"
	KProposal  = "gov/prop/"
	KGovQueue  = "gov/queue"
	KUpgrade   = "gov/upgrade/"
	KParams    = "gov/params"
	KMigState  = "mig/state"
	KMigBatch  = "mig/batch/"
	KSeq       = "meta/seq/"
	KMeta      = "meta/"
)

func seq12(n int64) string { return fmt.Sprintf("%012d", n) }

func nextSeq(kv KV, name string) int64 {
	var n int64
	getJSON(kv, KSeq+name, &n)
	n++
	putJSON(kv, KSeq+name, n)
	return n
}
