// bench measures AUREOM CHAINBASE under a defined retail workload.
//
//	bench net      --network run/net/network.json --keys run/net/keys --workers 8,32,128 --duration 30s
//	bench engine   --baskets 20000          (state machine + IAVL + LevelDB, NO consensus, in-process)
//	bench baseline --baskets 20000          (single-node SQLite, equivalent row writes, NO consensus)
//
// Results are printed as JSON lines + a markdown table. Everything reported is measured on the
// machine it runs on; see docs/BENCHMARK.md for hardware and caveats.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"math/rand"
	"os"
	"os/exec"
	"runtime"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"crypto/ed25519"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	coretypes "github.com/cometbft/cometbft/rpc/core/types"
	"github.com/cometbft/cometbft/types"

	"github.com/aureom/chainbase/internal/client"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/gateway"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("usage: bench net|engine|baseline [flags]")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "net":
		benchNet(os.Args[2:])
	case "engine":
		benchEngine(os.Args[2:])
	case "baseline":
		benchBaseline(os.Args[2:])
	}
}

func hardware() map[string]any {
	h := map[string]any{"go": runtime.Version(), "os": runtime.GOOS + "/" + runtime.GOARCH, "logical_cpus": runtime.NumCPU()}
	if b, err := os.ReadFile("/proc/cpuinfo"); err == nil {
		for _, l := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(l, "model name") {
				h["cpu_model"] = strings.TrimSpace(strings.SplitN(l, ":", 2)[1])
				break
			}
		}
	}
	if b, err := os.ReadFile("/proc/meminfo"); err == nil {
		for _, l := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(l, "MemTotal") {
				h["mem_total"] = strings.TrimSpace(strings.SplitN(l, ":", 2)[1])
			}
		}
	}
	return h
}

func pctl(v []float64, p float64) float64 {
	if len(v) == 0 {
		return 0
	}
	s := append([]float64(nil), v...)
	sort.Float64s(s)
	return s[int(float64(len(s)-1)*p)]
}

// ---------------- network benchmark ----------------

type sample struct {
	typ     string
	size    int
	admitMs float64
	finalMs float64
	code    uint32
	finalAt time.Time
}

type nb struct {
	pool    []*client.Client
	keys    map[string]ed25519.PrivateKey
	kid     map[string]string
	watch   sync.Map // tx hash -> chan time.Time
	rr      atomic.Int64
	mu      sync.Mutex
	samples []sample
	rejects atomic.Int64
	custN   int
}

func (b *nb) key(id string) (ed25519.PrivateKey, string) {
	if k, ok := b.keys[id]; ok {
		return k, b.kid[id]
	}
	return nil, ""
}

// do signs, submits through a validator (round robin), waits for finality via the block feed.
func (b *nb) do(ctx context.Context, signer, typ string, payload any) (json.RawMessage, *sample, error) {
	c := b.pool[int(b.rr.Add(1))%len(b.pool)]
	k, kid := b.key(signer)
	body := c.NewBody(signer, kid, typ, payload)
	wire := c.Sign(body, k)
	h := string(types.Tx(wire).Hash())
	ch := make(chan time.Time, 1)
	b.watch.Store(h, ch)
	defer b.watch.Delete(h)
	t0 := time.Now()
	sr, err := c.Submit(ctx, wire)
	if err != nil {
		return nil, nil, err
	}
	t1 := time.Now()
	s := &sample{typ: typ, size: len(wire), admitMs: float64(t1.Sub(t0).Microseconds()) / 1000}
	if sr.CheckCode != 0 {
		s.code = sr.CheckCode
		b.rejects.Add(1)
		return nil, s, fmt.Errorf("admission %s: %s", core.CodeName(sr.CheckCode), sr.Log)
	}
	select {
	case ft := <-ch:
		s.finalMs = float64(ft.Sub(t0).Microseconds()) / 1000
		s.finalAt = ft
	case <-time.After(60 * time.Second):
		return nil, s, fmt.Errorf("timeout waiting for finality of %s", body.TxID)
	case <-ctx.Done():
		return nil, s, ctx.Err()
	}
	var r *coretypes.ResultTx
	for i := 0; i < 100; i++ { // the tx indexer can trail the block event by a few ms
		if r, err = c.RPC.Tx(ctx, client.TxHash(wire), false); err == nil {
			break
		}
		time.Sleep(30 * time.Millisecond)
	}
	if err != nil {
		return nil, s, err
	}
	s.code = r.TxResult.Code
	b.mu.Lock()
	b.samples = append(b.samples, *s)
	b.mu.Unlock()
	if r.TxResult.Code != 0 {
		b.rejects.Add(1)
		return nil, s, fmt.Errorf("%s: %s", core.CodeName(r.TxResult.Code), r.TxResult.Log)
	}
	return r.TxResult.Data, s, nil
}

func (b *nb) feed(ctx context.Context, c *rpchttp.HTTP) error {
	if err := c.Start(); err != nil {
		return err
	}
	ch, err := c.Subscribe(ctx, "bench", "tm.event='NewBlock'", 1000)
	if err != nil {
		return err
	}
	go func() {
		for ev := range ch {
			now := time.Now()
			if d, ok := ev.Data.(types.EventDataNewBlock); ok {
				for _, tx := range d.Block.Data.Txs {
					if v, ok := b.watch.Load(string(tx.Hash())); ok {
						v.(chan time.Time) <- now
					}
				}
			}
		}
	}()
	return nil
}

func dirSize(path string) int64 {
	out, err := exec.Command("du", "-sb", path).Output()
	if err != nil {
		return 0
	}
	var n int64
	fmt.Sscan(strings.Fields(string(out))[0], &n)
	return n
}

func benchNet(args []string) {
	fs := flag.NewFlagSet("net", flag.ExitOnError)
	netPath := fs.String("network", "run/net/network.json", "")
	keys := fs.String("keys", "run/net/keys", "")
	workersS := fs.String("workers", "8,32,128", "comma separated concurrent POS workers per step")
	dur := fs.Duration("duration", 30*time.Second, "")
	skus := fs.Int("skus", 50, "")
	out := fs.String("out", "", "write JSON results here")
	fs.Parse(args)

	nc, err := gateway.LoadNetCfg(*netPath)
	if err != nil {
		panic(err)
	}
	b := &nb{keys: map[string]ed25519.PrivateKey{}, kid: map[string]string{}}
	for _, id := range []string{"catalog-mgr", "hq-iam-admin", "pricing-mgr", "manager-n01", "manager-s01", "cashier-n01", "cashier-s01", "payment-adapter-1", "loyalty-op"} {
		k, kid, err := client.LoadKey(*keys, id)
		if err != nil {
			panic(err)
		}
		b.keys[id], b.kid[id] = k, kid
	}
	for _, n := range nc.Nodes {
		c, err := client.New(n.RPCURL, nc.NetworkID)
		if err != nil {
			panic(err)
		}
		b.pool = append(b.pool, c)
	}
	ctx := context.Background()
	if err := b.feed(ctx, b.pool[0].RPC); err != nil {
		panic(err)
	}
	// ---- setup (not measured) ----
	run := fmt.Sprintf("%x", time.Now().Unix()%0xffffff)
	skuIDs := make([]string, *skus)
	mustDo := func(signer, typ string, p any) json.RawMessage {
		d, _, err := b.do(ctx, signer, typ, p)
		if err != nil {
			panic(fmt.Sprintf("setup %s: %v", typ, err))
		}
		return d
	}
	var wg sync.WaitGroup
	for i := 0; i < *skus; i++ {
		skuIDs[i] = fmt.Sprintf("BN-%s-%03d", run, i)
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			mustDo("catalog-mgr", "CreateProduct", map[string]any{"product_id": "PB-" + skuIDs[i], "name": "Bench item " + skuIDs[i], "brand": "Fictional", "category": "bench",
				"variants": []any{map[string]any{"sku_id": skuIDs[i], "unit": "EA"}}})
			mustDo("pricing-mgr", "PublishPrice", map[string]any{"price_id": "PRB-" + skuIDs[i], "sku": skuIDs[i], "location_id": "*", "currency": "GBP", "unit_minor": 150 + (i%40)*100, "effective_from_ms": time.Now().UnixMilli() - 86400000})
		}(i)
	}
	wg.Wait()
	mustDo("hq-iam-admin", "CreateSupplier", map[string]any{"supplier_id": "SUP-" + run, "name": "Bench supplier"})
	for _, st := range []struct{ mgr, loc string }{{"manager-n01", "STORE-N-01"}, {"manager-s01", "STORE-S-01"}} {
		lines := []any{}
		for _, s := range skuIDs {
			lines = append(lines, map[string]any{"sku": s, "qty": map[string]any{"v": 100_000_000, "unit": "EA"}})
		}
		mustDo(st.mgr, "ReceiveGoods", map[string]any{"receipt_id": "GRB-" + run + st.loc, "location_id": st.loc, "supplier_id": "SUP-" + run, "effective_at_ms": time.Now().UnixMilli(), "lines": lines})
	}
	b.mu.Lock()
	b.samples = nil
	b.mu.Unlock()
	b.rejects.Store(0)

	type stepResult map[string]any
	var results []stepResult
	var seq atomic.Int64
	for _, ws := range strings.Split(*workersS, ",") {
		var w int
		fmt.Sscan(ws, &w)
		b.mu.Lock()
		b.samples = nil
		b.mu.Unlock()
		b.rejects.Store(0)
		h0 := heightOf(ctx, b.pool[0])
		sz0 := sizes(nc)
		deadline := time.Now().Add(*dur)
		start := time.Now()
		var baskets, bErr atomic.Int64
		var bLat []float64
		var bmu sync.Mutex
		var wg sync.WaitGroup
		for i := 0; i < w; i++ {
			wg.Add(1)
			go func(i int) {
				defer wg.Done()
				rng := rand.New(rand.NewSource(int64(i)*7919 + time.Now().UnixNano()))
				store := []struct{ cashier, mgr, loc string }{{"cashier-n01", "manager-n01", "STORE-N-01"}, {"cashier-s01", "manager-s01", "STORE-S-01"}}[i%2]
				for time.Now().Before(deadline) {
					t0 := time.Now()
					if err := b.basket(ctx, rng, store.cashier, store.mgr, store.loc, skuIDs, &seq, run); err != nil {
						bErr.Add(1)
						if bErr.Load() < 5 {
							fmt.Fprintln(os.Stderr, "basket error:", err)
						}
						continue
					}
					baskets.Add(1)
					bmu.Lock()
					bLat = append(bLat, float64(time.Since(t0).Milliseconds()))
					bmu.Unlock()
				}
			}(i)
		}
		wg.Wait()
		el := time.Since(start).Seconds()
		time.Sleep(2 * time.Second)
		h1 := heightOf(ctx, b.pool[0])
		sz1 := sizes(nc)
		b.mu.Lock()
		ss := append([]sample(nil), b.samples...)
		b.mu.Unlock()
		byType := map[string]*struct {
			n        int
			bytes    int
			maxBytes int
			fin, adm []float64
		}{}
		var fin, adm []float64
		okTx := 0
		var totalBytes int64
		for _, s := range ss {
			t := byType[s.typ]
			if t == nil {
				t = &struct {
					n        int
					bytes    int
					maxBytes int
					fin, adm []float64
				}{}
				byType[s.typ] = t
			}
			t.n++
			t.bytes += s.size
			if s.size > t.maxBytes {
				t.maxBytes = s.size
			}
			t.fin = append(t.fin, s.finalMs)
			t.adm = append(t.adm, s.admitMs)
			fin = append(fin, s.finalMs)
			adm = append(adm, s.admitMs)
			totalBytes += int64(s.size)
			if s.code == 0 {
				okTx++
			}
		}
		mix := map[string]any{}
		types_ := make([]string, 0)
		for k := range byType {
			types_ = append(types_, k)
		}
		sort.Strings(types_)
		for _, k := range types_ {
			t := byType[k]
			mix[k] = map[string]any{"count": t.n, "share_pct": round(100 * float64(t.n) / float64(len(ss))), "avg_wire_bytes": t.bytes / t.n, "max_wire_bytes": t.maxBytes,
				"finality_p50_ms": round(pctl(t.fin, .5)), "finality_p95_ms": round(pctl(t.fin, .95))}
		}
		growth := int64(0)
		for i := range sz1 {
			growth += sz1[i] - sz0[i]
		}
		res := stepResult{
			"workers": w, "duration_s": round(el), "baskets_completed": baskets.Load(), "basket_errors": bErr.Load(), "baskets_per_s": round(float64(baskets.Load()) / el),
			"transactions_finalised": len(ss), "transactions_ok": okTx, "tx_per_s": round(float64(len(ss)) / el), "rejected": b.rejects.Load(),
			"blocks": h1 - h0, "txs_per_block_avg": round(float64(len(ss)) / float64(maxI(1, int(h1-h0)))),
			"admission_ms":         map[string]float64{"p50": round(pctl(adm, .5)), "p95": round(pctl(adm, .95)), "p99": round(pctl(adm, .99))},
			"finality_ms":          map[string]float64{"p50": round(pctl(fin, .5)), "p95": round(pctl(fin, .95)), "p99": round(pctl(fin, .99)), "max": round(pctl(fin, 1))},
			"basket_end_to_end_ms": map[string]float64{"p50": round(pctl(bLat, .5)), "p95": round(pctl(bLat, .95)), "p99": round(pctl(bLat, .99))},
			"mix":                  mix, "wire_bytes_total": totalBytes,
			"storage_growth_bytes_all_validators": growth, "storage_growth_bytes_per_validator": growth / int64(len(sz1)),
			"storage_bytes_per_tx_per_validator": round(float64(growth) / float64(len(sz1)) / float64(maxI(1, len(ss)))),
		}
		results = append(results, res)
		j, _ := json.Marshal(res)
		fmt.Println(string(j))
	}
	final := map[string]any{"hardware": hardware(), "network": map[string]any{"validators": len(nc.Nodes), "network_id": nc.NetworkID}, "steps": results, "skus": *skus,
		"note": "all validators + the load generator share ONE machine; numbers are not representative of a WAN deployment"}
	if *out != "" {
		j, _ := json.MarshalIndent(final, "", "  ")
		os.WriteFile(*out, j, 0o644)
	}
}

func round(f float64) float64 { return float64(int64(f*100+0.5)) / 100 }
func maxI(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func heightOf(ctx context.Context, c *client.Client) int64 {
	st, err := c.RPC.Status(ctx)
	if err != nil {
		return 0
	}
	return st.SyncInfo.LatestBlockHeight
}

func sizes(nc *gateway.NetCfg) []int64 {
	out := make([]int64, len(nc.Nodes))
	for i := range nc.Nodes {
		home := ""
		for _, n := range nc.Nodes {
			_ = n
		}
		home = homeOf(nc, i)
		out[i] = dirSize(home + "/data")
	}
	return out
}

func homeOf(nc *gateway.NetCfg, i int) string {
	// network.json lives at <net>/network.json; node homes at <net>/nodes/<name>
	return strings.TrimSuffix(nc.Genesis, "/genesis.json") + "/nodes/" + nc.Nodes[i].Name
}

// basket is one retail checkout: reserve each line, complete the sale, record the (simulated) payment
// confirmation, credit loyalty for ~60% of customers, and ~6% of baskets are returned and refunded.
func (b *nb) basket(ctx context.Context, rng *rand.Rand, cashier, mgr, loc string, skus []string, seq *atomic.Int64, run string) error {
	id := fmt.Sprintf("%s-%d", run, seq.Add(1))
	type line struct {
		sku, rs string
		q       int
	}
	var lines []line
	used := map[string]bool{}
	for n := 1 + rng.Intn(3); len(lines) < n; {
		s := skus[rng.Intn(len(skus))]
		if used[s] {
			continue
		}
		used[s] = true
		lines = append(lines, line{s, fmt.Sprintf("RS-%s-%d", id, len(lines)), 1 + rng.Intn(2)})
	}
	var wg sync.WaitGroup
	errs := make(chan error, len(lines))
	for _, l := range lines {
		wg.Add(1)
		go func(l line) {
			defer wg.Done()
			_, _, err := b.do(ctx, cashier, "ReserveStock", map[string]any{"reservation_id": l.rs, "location_id": loc, "sku": l.sku, "qty": map[string]any{"v": l.q, "unit": "EA"}, "ttl_ms": 600000})
			errs <- err
		}(l)
	}
	wg.Wait()
	close(errs)
	for e := range errs {
		if e != nil {
			return e
		}
	}
	saleID := "SB-" + id
	customer := ""
	if rng.Intn(100) < 60 {
		customer = fmt.Sprintf("CUST-B%06d", rng.Intn(20000))
	}
	sl := []any{}
	for _, l := range lines {
		sl = append(sl, map[string]any{"sku": l.sku, "qty": map[string]any{"v": l.q, "unit": "EA"}, "reservation_id": l.rs})
	}
	d, _, err := b.do(ctx, cashier, "CompleteSale", map[string]any{"sale_id": saleID, "location_id": loc, "channel": "STORE", "customer_id": customer, "effective_at_ms": time.Now().UnixMilli(),
		"currency": "GBP", "payment_method": "CARD", "lines": sl})
	if err != nil {
		return err
	}
	var sr struct {
		Net int64 `json:"net_minor"`
	}
	json.Unmarshal(d, &sr)
	if _, _, err := b.do(ctx, "payment-adapter-1", "RecordPaymentResult", map[string]any{"sale_id": saleID, "provider": "SIMPAY", "event_id": "ev-" + id, "provider_ref": "ch_" + id, "result": "CONFIRMED", "amount_minor": sr.Net, "currency": "GBP"}); err != nil {
		return err
	}
	if customer != "" {
		if _, _, err := b.do(ctx, "loyalty-op", "CreditLoyalty", map[string]any{"entry_id": "LE-" + id, "customer_id": customer, "sale_id": saleID}); err != nil && !strings.Contains(err.Error(), "no points") {
			// a sale below one currency unit earns no points: not an error for the benchmark
			if !strings.Contains(err.Error(), "INVALID_ARGUMENT") {
				return err
			}
		}
	}
	if rng.Intn(100) < 6 {
		rid := "RT-" + id
		if _, _, err := b.do(ctx, cashier, "RequestReturn", map[string]any{"return_id": rid, "sale_id": saleID, "lines": []any{map[string]any{"line_no": 1, "qty_v": 1, "reason": "changed mind"}}}); err != nil {
			return err
		}
		if _, _, err := b.do(ctx, mgr, "ApproveReturn", map[string]any{"return_id": rid, "decision": "APPROVE"}); err != nil {
			return err
		}
		d, _, err := b.do(ctx, mgr, "ReceiveReturnedGoods", map[string]any{"return_id": rid, "lines": []any{map[string]any{"line_no": 1, "qty_v": 1, "inspection": "RESELLABLE"}}})
		if err != nil {
			return err
		}
		var rr struct {
			RefundID string `json:"refund_id"`
			Amount   int64  `json:"refund_instructed_minor"`
		}
		json.Unmarshal(d, &rr)
		if rr.RefundID != "" {
			if _, _, err := b.do(ctx, "payment-adapter-1", "RecordRefundResult", map[string]any{"refund_id": rr.RefundID, "provider": "SIMPAY", "event_id": "rf-" + id, "provider_ref": "re_" + id, "result": "CONFIRMED", "amount_minor": rr.Amount}); err != nil {
				return err
			}
		}
	}
	return nil
}
