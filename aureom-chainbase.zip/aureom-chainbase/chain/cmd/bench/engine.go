package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"runtime/pprof"
	"time"

	"database/sql"
	abci "github.com/cometbft/cometbft/abci/types"
	_ "modernc.org/sqlite"

	"github.com/aureom/chainbase/internal/app"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/demo"
)

// benchEngine: the deterministic state machine + IAVL + LevelDB persistence driven directly
// through the ABCI interface (no networking, no signatures from remote clients, no consensus).
// Baskets are executed in dependency stages; each stage is one block of up to `batch` txs.
func benchEngine(args []string) {
	fs := flag.NewFlagSet("engine", flag.ExitOnError)
	baskets := fs.Int("baskets", 20000, "")
	batch := fs.Int("batch", 2000, "transactions per block")
	dir := fs.String("dir", "", "db directory (default: temp)")
	prof := fs.String("cpuprofile", "", "write CPU profile of the execution phase")
	fs.Parse(args)
	if *dir == "" {
		*dir, _ = os.MkdirTemp("", "engine-bench")
		defer os.RemoveAll(*dir)
	}
	const net = "aureom-bench-engine"
	g, keys := demo.TestGenesis(net)
	gb, _ := json.Marshal(g)
	a, err := app.New(*dir, net)
	if err != nil {
		panic(err)
	}
	defer a.Close()
	ctx := context.Background()
	t0 := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	a.InitChain(ctx, &abci.RequestInitChain{ChainId: net, AppStateBytes: gb, Time: t0, InitialHeight: 1})
	height := int64(0)
	n := 0
	mk := func(signer, typ string, p any) []byte {
		n++
		raw, _ := json.Marshal(p)
		return core.SignTx(net, core.Body{TxID: fmt.Sprintf("tx-%010d", n), Type: typ, Signer: signer, KeyID: "k1", Idempotency: fmt.Sprintf("i-%010d", n), Payload: raw}, keys[signer])
	}
	var execTime time.Duration
	var txCount, rejected int
	var bytesTotal int64
	run := func(txs [][]byte) {
		for len(txs) > 0 {
			k := *batch
			if k > len(txs) {
				k = len(txs)
			}
			height++
			s := time.Now()
			r, err := a.FinalizeBlock(ctx, &abci.RequestFinalizeBlock{Height: height, Time: t0.Add(time.Duration(height) * time.Second), Txs: txs[:k]})
			if err != nil {
				panic(err)
			}
			a.Commit(ctx, &abci.RequestCommit{})
			execTime += time.Since(s)
			for i, res := range r.TxResults {
				txCount++
				bytesTotal += int64(len(txs[i]))
				if res.Code != 0 {
					rejected++
				}
			}
			txs = txs[k:]
		}
	}
	// setup
	var setup [][]byte
	skus := 50
	for i := 0; i < skus; i++ {
		sk := fmt.Sprintf("BE-%03d", i)
		setup = append(setup, mk("catalog-mgr", "CreateProduct", map[string]any{"product_id": "P" + sk, "name": "x", "variants": []any{map[string]any{"sku_id": sk, "unit": "EA"}}}))
	}
	run(setup)
	setup = nil
	for i := 0; i < skus; i++ {
		sk := fmt.Sprintf("BE-%03d", i)
		setup = append(setup, mk("pricing-mgr", "PublishPrice", map[string]any{"price_id": "PR" + sk, "sku": sk, "location_id": "*", "currency": "GBP", "unit_minor": 250 + i, "effective_from_ms": t0.UnixMilli() - 1000}))
	}
	run(setup)
	setup = nil
	setup = append(setup, mk("hq-iam-admin", "CreateSupplier", map[string]any{"supplier_id": "SUP", "name": "s"}))
	lines := []any{}
	for i := 0; i < skus; i++ {
		lines = append(lines, map[string]any{"sku": fmt.Sprintf("BE-%03d", i), "qty": map[string]any{"v": 100000000, "unit": "EA"}})
	}
	setup = append(setup, mk("manager-n01", "ReceiveGoods", map[string]any{"receipt_id": "GR", "location_id": "STORE-N-01", "supplier_id": "SUP", "effective_at_ms": t0.UnixMilli(), "lines": lines}))
	run(setup)
	execTime, txCount, rejected, bytesTotal = 0, 0, 0, 0
	// measured: stages of the basket pipeline
	start := time.Now()
	var reserve, sale, pay, loyal [][]byte
	for i := 0; i < *baskets; i++ {
		sk := fmt.Sprintf("BE-%03d", i%skus)
		rs := fmt.Sprintf("RS%d", i)
		sid := fmt.Sprintf("S%d", i)
		cust := fmt.Sprintf("CUST-E%06d", i%20000)
		reserve = append(reserve, mk("cashier-n01", "ReserveStock", map[string]any{"reservation_id": rs, "location_id": "STORE-N-01", "sku": sk, "qty": map[string]any{"v": 1, "unit": "EA"}, "ttl_ms": 600000}))
		sale = append(sale, mk("cashier-n01", "CompleteSale", map[string]any{"sale_id": sid, "location_id": "STORE-N-01", "channel": "STORE", "customer_id": cust, "effective_at_ms": t0.UnixMilli() + height*1000,
			"currency": "GBP", "payment_method": "CARD", "lines": []any{map[string]any{"sku": sk, "qty": map[string]any{"v": 1, "unit": "EA"}, "reservation_id": rs}}}))
		pay = append(pay, mk("payment-adapter-1", "RecordPaymentResult", map[string]any{"sale_id": sid, "provider": "P", "event_id": "e" + sid, "provider_ref": "r", "result": "CONFIRMED", "amount_minor": 250 + i%skus, "currency": "GBP"}))
		loyal = append(loyal, mk("loyalty-op", "CreditLoyalty", map[string]any{"entry_id": "LE" + sid, "customer_id": cust, "sale_id": sid}))
	}
	signed := time.Since(start)
	execStart := time.Now()
	execTime = 0
	if *prof != "" {
		pf, _ := os.Create(*prof)
		pprof.StartCPUProfile(pf)
		defer pprof.StopCPUProfile()
	}
	run(reserve)
	run(sale)
	run(pay)
	run(loyal)
	wall := time.Since(execStart)
	res := map[string]any{"mode": "engine (state machine + IAVL + LevelDB, no consensus, no network)", "baskets": *baskets, "transactions": txCount, "rejected": rejected,
		"tx_per_s": round(float64(txCount) / wall.Seconds()), "wall_s": round(wall.Seconds()), "txs_per_block": *batch, "avg_wire_bytes": bytesTotal / int64(maxI(1, txCount)),
		"client_signing_s_excluded": round(signed.Seconds()), "hardware": hardware(), "db_bytes": dirSize(*dir)}
	j, _ := json.MarshalIndent(res, "", "  ")
	fmt.Println(string(j))
}

// benchBaseline: a conventional single-node SQLite doing the equivalent ROW WRITES per basket in one
// transaction (synchronous=FULL, WAL). It provides context only — it has no signatures, no authorisation
// engine, no history/proofs, no replication and no consensus.
func benchBaseline(args []string) {
	fs := flag.NewFlagSet("baseline", flag.ExitOnError)
	baskets := fs.Int("baskets", 20000, "")
	fs.Parse(args)
	dir, _ := os.MkdirTemp("", "baseline")
	defer os.RemoveAll(dir)
	db, err := sql.Open("sqlite", "file:"+dir+"/b.db?_pragma=journal_mode(WAL)&_pragma=synchronous(FULL)")
	if err != nil {
		panic(err)
	}
	db.SetMaxOpenConns(1)
	for _, q := range []string{
		`CREATE TABLE stock(sku TEXT, loc TEXT, available INT, reserved INT, PRIMARY KEY(sku,loc))`,
		`CREATE TABLE reservation(id TEXT PRIMARY KEY, sku TEXT, qty INT, status TEXT)`,
		`CREATE TABLE sale(id TEXT PRIMARY KEY, customer TEXT, net INT, payment_status TEXT)`,
		`CREATE TABLE sale_line(sale TEXT, line INT, sku TEXT, qty INT, net INT)`,
		`CREATE TABLE movement(id INTEGER PRIMARY KEY, sku TEXT, qty INT, ref TEXT)`,
		`CREATE TABLE loyalty(customer TEXT PRIMARY KEY, points INT)`,
		`CREATE TABLE audit(id INTEGER PRIMARY KEY, what TEXT, ref TEXT)`,
	} {
		db.Exec(q)
	}
	for i := 0; i < 50; i++ {
		db.Exec(`INSERT INTO stock VALUES(?,?,?,0)`, fmt.Sprintf("BE-%03d", i), "STORE-N-01", 100000000)
	}
	start := time.Now()
	rows := 0
	for i := 0; i < *baskets; i++ {
		tx, _ := db.Begin()
		sk := fmt.Sprintf("BE-%03d", i%50)
		sid := fmt.Sprintf("S%d", i)
		tx.Exec(`UPDATE stock SET available=available-1, reserved=reserved+1 WHERE sku=? AND loc='STORE-N-01' AND available>=1`, sk)
		tx.Exec(`INSERT INTO reservation VALUES(?,?,1,'ACTIVE')`, "RS"+sid, sk)
		tx.Exec(`INSERT INTO audit(what,ref) VALUES('reserve',?)`, sid)
		tx.Exec(`UPDATE stock SET reserved=reserved-1 WHERE sku=? AND loc='STORE-N-01'`, sk)
		tx.Exec(`UPDATE reservation SET status='CONSUMED' WHERE id=?`, "RS"+sid)
		tx.Exec(`INSERT INTO sale VALUES(?,?,?,'INSTRUCTED')`, sid, "C", 250)
		tx.Exec(`INSERT INTO sale_line VALUES(?,1,?,1,250)`, sid, sk)
		tx.Exec(`INSERT INTO movement(sku,qty,ref) VALUES(?,1,?)`, sk, sid)
		tx.Exec(`INSERT INTO audit(what,ref) VALUES('sale',?)`, sid)
		tx.Exec(`UPDATE sale SET payment_status='CONFIRMED' WHERE id=?`, sid)
		tx.Exec(`INSERT INTO audit(what,ref) VALUES('payment',?)`, sid)
		tx.Exec(`INSERT INTO loyalty VALUES(?,2) ON CONFLICT(customer) DO UPDATE SET points=points+2`, fmt.Sprintf("C%d", i%20000))
		tx.Exec(`INSERT INTO audit(what,ref) VALUES('loyalty',?)`, sid)
		tx.Commit()
		rows += 13
	}
	el := time.Since(start)
	res := map[string]any{"mode": "baseline: single-node SQLite, 1 commit per basket (synchronous=FULL), no consensus/signatures/proofs", "baskets": *baskets,
		"baskets_per_s": round(float64(*baskets) / el.Seconds()), "equivalent_tx_per_s_4_per_basket": round(4 * float64(*baskets) / el.Seconds()), "statements": rows, "db_bytes": dirSize(dir), "hardware": hardware()}
	j, _ := json.MarshalIndent(res, "", "  ")
	fmt.Println(string(j))
}
