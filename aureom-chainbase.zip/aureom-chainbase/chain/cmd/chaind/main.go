// chaind runs one AUREOM CHAINBASE validator (or observer) node: CometBFT consensus
// with the business state machine in-process over ABCI.
package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"

	cmtcfg "github.com/cometbft/cometbft/config"
	cmtflags "github.com/cometbft/cometbft/libs/cli/flags"
	cmtlog "github.com/cometbft/cometbft/libs/log"
	nm "github.com/cometbft/cometbft/node"
	"github.com/cometbft/cometbft/p2p"
	"github.com/cometbft/cometbft/privval"
	"github.com/cometbft/cometbft/proxy"
	cmttypes "github.com/cometbft/cometbft/types"

	"github.com/aureom/chainbase/internal/app"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/nodeutil"
)

const version = "0.1.0 (cometbft v0.38.25, abci 2.0)"

func main() {
	if len(os.Args) < 2 {
		fmt.Println("usage: chaind start --home DIR [--log-level info] | version")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "version":
		fmt.Println(version)
	case "start":
		home, level := "", "info"
		for i := 2; i < len(os.Args)-1; i++ {
			switch os.Args[i] {
			case "--home":
				home = os.Args[i+1]
			case "--log-level":
				level = os.Args[i+1]
			}
		}
		if home == "" {
			fmt.Println("--home is required")
			os.Exit(2)
		}
		if err := run(home, level); err != nil {
			fmt.Fprintln(os.Stderr, "chaind:", err)
			os.Exit(1)
		}
	default:
		fmt.Println("unknown command")
		os.Exit(2)
	}
}

func run(home, level string) error {
	// Test/ops hook: simulate an OLD binary that cannot execute newer state-machine versions. Such a node must halt
	// at an upgrade's activation height instead of silently computing different results.
	if v := os.Getenv("CHAINBASE_MAX_STATE_VERSION"); v != "" {
		var n uint64
		fmt.Sscan(v, &n)
		core.MaxSupportedVersion = n
	}
	cfg, err := nodeutil.LoadConfig(home)
	if err != nil {
		return err
	}
	logger := cmtlog.NewTMLogger(cmtlog.NewSyncWriter(os.Stdout))
	logger, err = cmtflags.ParseLogLevel(level, logger, cmtcfg.DefaultLogLevel)
	if err != nil {
		return err
	}
	gen, err := cmttypes.GenesisDocFromFile(cfg.GenesisFile())
	if err != nil {
		return fmt.Errorf("genesis: %w", err)
	}
	nodeKey, err := p2p.LoadNodeKey(cfg.NodeKeyFile())
	if err != nil {
		return err
	}
	pv := privval.LoadFilePV(cfg.PrivValidatorKeyFile(), cfg.PrivValidatorStateFile())
	application, err := app.New(cfg.DBDir(), gen.ChainID)
	if err != nil {
		return err
	}
	defer application.Close()
	node, err := nm.NewNode(cfg, pv, nodeKey, proxy.NewLocalClientCreator(application), nm.DefaultGenesisDocProviderFunc(cfg),
		cmtcfg.DefaultDBProvider, nm.DefaultMetricsProvider(cfg.Instrumentation), logger)
	if err != nil {
		return err
	}
	if err := node.Start(); err != nil {
		return err
	}
	logger.Info("aureom chaind started", "version", version, "node_id", nodeKey.ID(), "chain_id", gen.ChainID)
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	<-c
	return node.Stop()
}
