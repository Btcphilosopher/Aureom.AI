// chainctl: operator CLI — network generation, submitting transactions, independent
// verification (finality, replay, snapshots), node (re)creation and schema docs.
package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/aureom/chainbase/internal/client"
	"github.com/aureom/chainbase/internal/core"
	"github.com/aureom/chainbase/internal/netgen"
	"github.com/aureom/chainbase/internal/nodeutil"
	"github.com/aureom/chainbase/internal/verify"
	"github.com/cometbft/cometbft/p2p"
	"github.com/cometbft/cometbft/privval"
)

func flags(args []string) map[string]string {
	m := map[string]string{}
	for i := 0; i < len(args); i++ {
		if strings.HasPrefix(args[i], "--") {
			k := args[i][2:]
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "--") {
				m[k] = args[i+1]
				i++
			} else {
				m[k] = "true"
			}
		}
	}
	return m
}

func die(err error) {
	fmt.Fprintln(os.Stderr, "chainctl:", err)
	os.Exit(1)
}

func usage() {
	fmt.Println(`chainctl <command>
  testnet        --out DIR [--network-id ID] [--base-port N] [--block-time 1s] [--docker true]
  newnode        --net DIR --name NAME --mode observer|replace [--restore-from HOME] --p2p-port N --rpc-port N
  keygen         --identity ID --key-id KID --out DIR     create a new identity key file; prints the public key
  show-keys      --home DIR                     print node id + consensus public key (for governance proposals)
  tx             --keys DIR --rpc URL --signer ID --type TYPE --payload JSON [--network-id ID]
  verify-finality --rpc URL1,URL2 --genesis FILE --height H [--network-id ID]
  replay         --rpc URL [--to HEIGHT]        re-execute the whole chain and compare every state root
  snapshot export --home DIR --network-id ID [--height H] --out FILE      (node must be stopped)
  snapshot verify --file FILE --rpc URL1,URL2 --genesis FILE [--network-id ID]
  schema [md|roles]`)
}

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(2)
	}
	f := flags(os.Args[2:])
	netID := f["network-id"]
	if netID == "" {
		netID = "aureom-retail-demo-1"
	}
	ctx := context.Background()
	switch os.Args[1] {
	case "testnet":
		o := netgen.Options{Out: "./testnet", NetworkID: netID, BasePort: 26600, TimeoutCommit: time.Second}
		if v := f["out"]; v != "" {
			o.Out = v
		}
		if v := f["base-port"]; v != "" {
			fmt.Sscan(v, &o.BasePort)
		}
		if v := f["block-time"]; v != "" {
			o.TimeoutCommit, _ = time.ParseDuration(v)
		}
		o.Docker = f["docker"] == "true"
		n, err := netgen.Generate(o)
		if err != nil {
			die(err)
		}
		for _, nd := range n.Nodes {
			fmt.Printf("%-10s %-13s node=%s rpc=%s\n", nd.Name, nd.Role, nd.NodeID, nd.RPCURL)
		}
	case "newnode":
		o := netgen.NewNodeOptions{Name: f["name"], Mode: f["mode"], RestoreFrom: f["restore-from"]}
		fmt.Sscan(f["p2p-port"], &o.P2PPort)
		fmt.Sscan(f["rpc-port"], &o.RPCPort)
		ni, err := netgen.NewNode(f["net"], o)
		if err != nil {
			die(err)
		}
		fmt.Printf("created node %s home=%s node_id=%s rpc=%s\n", ni.Name, ni.Home, ni.NodeID, ni.RPCURL)
	case "keygen":
		// writes a new identity key file {identity,key_id,seed_hex,pub_b64} (demo key storage; use an HSM/KMS in production)
		seed := make([]byte, 32)
		if _, err := rand.Read(seed); err != nil {
			die(err)
		}
		priv := ed25519.NewKeyFromSeed(seed)
		kf := client.KeyFile{Identity: f["identity"], KeyID: f["key-id"], SeedHex: hex.EncodeToString(seed), PubB64: base64.StdEncoding.EncodeToString(priv.Public().(ed25519.PublicKey))}
		b, _ := json.MarshalIndent(kf, "", "  ")
		if err := os.MkdirAll(f["out"], 0o700); err != nil {
			die(err)
		}
		if err := os.WriteFile(f["out"]+"/"+f["identity"]+".json", b, 0o600); err != nil {
			die(err)
		}
		fmt.Println(kf.PubB64)
	case "show-keys":
		cfg, err := nodeutil.LoadConfig(f["home"])
		if err != nil {
			die(err)
		}
		nk, err := p2p.LoadNodeKey(cfg.NodeKeyFile())
		if err != nil {
			die(err)
		}
		pv := privval.LoadFilePV(cfg.PrivValidatorKeyFile(), cfg.PrivValidatorStateFile())
		pk, _ := pv.GetPubKey()
		b, _ := json.MarshalIndent(map[string]string{"node_id": string(nk.ID()), "consensus_pubkey_b64": base64.StdEncoding.EncodeToString(pk.Bytes())}, "", "  ")
		fmt.Println(string(b))
	case "tx":
		cmdTx(f, netID)
	case "verify-finality":
		lc, err := verify.NewLight(ctx, netID, strings.Split(f["rpc"], ","), f["genesis"])
		if err != nil {
			die(err)
		}
		var h int64
		fmt.Sscan(f["height"], &h)
		r := verify.VerifyFinality(ctx, lc, h)
		if !r.Verified {
			fmt.Printf("NOT VERIFIED height=%d: %s\n", h, r.Err)
			os.Exit(1)
		}
		fmt.Printf("VERIFIED height=%d signers=%d signed_power=%d/%d (quorum > 2/3) header_app_hash=%s\n", h, r.Signers, r.SignedPower, r.TotalPower, r.AppHash)
	case "replay":
		var to int64
		fmt.Sscan(f["to"], &to)
		t0 := time.Now()
		res, err := verify.Replay(ctx, strings.Split(f["rpc"], ",")[0], to, func(h int64) { fmt.Fprintf(os.Stderr, "  replayed %d blocks\r", h) })
		if err != nil {
			die(err)
		}
		if res.Err != "" {
			fmt.Println("REPLAY FAILED:", res.Err)
			os.Exit(1)
		}
		fmt.Printf("REPLAY OK: %d blocks, %d txs (%d rejected) re-executed from genesis in %s; every state root equals the app_hash committed on chain; final app_hash=%s\n",
			res.Blocks, res.Txs, res.Rejected, time.Since(t0).Round(time.Millisecond), res.FinalAppHash)
	case "snapshot":
		if len(os.Args) < 3 {
			usage()
			os.Exit(2)
		}
		f = flags(os.Args[3:])
		switch os.Args[2] {
		case "export":
			var h int64
			fmt.Sscan(f["height"], &h)
			m, err := verify.ExportSnapshot(f["home"]+"/data", netID, h, f["out"])
			if err != nil {
				die(err)
			}
			fmt.Printf("snapshot exported: height=%d root=%s nodes=%d -> %s\n", m.Height, m.RootHash, m.Nodes, f["out"])
		case "verify":
			m, root, err := verify.ImportRoot(f["file"])
			if err != nil {
				die(err)
			}
			if root != m.RootHash {
				fmt.Printf("SNAPSHOT INVALID: rebuilt root %s != manifest %s\n", root, m.RootHash)
				os.Exit(1)
			}
			lc, err := verify.NewLight(ctx, netID, strings.Split(f["rpc"], ","), f["genesis"])
			if err != nil {
				die(err)
			}
			// the root for state at height H is in header H+1: wait for it if the exported node was at the chain head
			var fin verify.Finality
			for i := 0; i < 30; i++ {
				fin = verify.VerifyFinality(ctx, lc, m.Height+1)
				if fin.Verified || !strings.Contains(fin.Err, "too high") {
					break
				}
				time.Sleep(time.Second)
			}
			if !fin.Verified || fin.AppHash != root {
				fmt.Printf("SNAPSHOT NOT AUTHENTIC: rebuilt root %s vs light-client-verified app hash %s (%s)\n", root, fin.AppHash, fin.Err)
				os.Exit(1)
			}
			fmt.Printf("SNAPSHOT VERIFIED: height=%d rebuilt IAVL root %s equals the app_hash in header %d signed by %d/%d voting power\n", m.Height, root, m.Height+1, fin.SignedPower, fin.TotalPower)
		}
	case "schema":
		sub := ""
		if len(os.Args) > 2 {
			sub = os.Args[2]
		}
		switch sub {
		case "roles":
			cat := core.RoleCatalogue()
			names := make([]string, 0, len(cat))
			for k := range cat {
				names = append(names, k)
			}
			sort.Strings(names)
			fmt.Println("| role | permissions |\n|---|---|")
			for _, n := range names {
				fmt.Printf("| `%s` | %s |\n", n, strings.Join(cat[n], ", "))
			}
			fmt.Print("\nPrivileged roles (`hq-admin`, `org-admin`, `migration-operator`, `finance-controller`) can only be granted/revoked by multi-organisation governance proposals (or genesis). Scopes: `*`, `loc:<id>`, `region:<name>`.\n\n## Transaction types\n\n")
		case "md":
			fmt.Print(core.SchemaMarkdown())
		default:
			b, _ := json.MarshalIndent(core.Schemas(), "", "  ")
			fmt.Println(string(b))
		}
	default:
		usage()
		os.Exit(2)
	}
}

func cmdTx(f map[string]string, netID string) {
	k, kid, err := client.LoadKey(f["keys"], f["signer"])
	if err != nil {
		die(err)
	}
	c, err := client.New(f["rpc"], netID)
	if err != nil {
		die(err)
	}
	var payload any
	if err := json.Unmarshal([]byte(f["payload"]), &payload); err != nil {
		die(fmt.Errorf("payload: %w", err))
	}
	ctx := context.Background()
	b := c.NewBody(f["signer"], kid, f["type"], payload)
	if v := f["expected-version"]; v != "" {
		var n int64
		fmt.Sscan(v, &n)
		b.ExpectedVersion = &n
	}
	wire := c.Sign(b, k)
	sr, err := c.Submit(ctx, wire)
	if err != nil {
		die(err)
	}
	fmt.Printf("submitted tx_id=%s hash=%s admission=%s %s\n", b.TxID, sr.Hash, core.CodeName(sr.CheckCode), sr.Log)
	if sr.CheckCode != 0 {
		os.Exit(3)
	}
	r, err := c.WaitFinal(ctx, wire, 30*time.Second)
	if err != nil {
		die(err)
	}
	fmt.Printf("finalised height=%d code=%s log=%q data=%s\n", r.Height, core.CodeName(r.TxResult.Code), r.TxResult.Log, string(r.TxResult.Data))
}
