// gateway serves the HTTP API, the disposable query projection and the dashboard.
package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/aureom/chainbase/internal/gateway"
)

func main() {
	cfg := gateway.Config{}
	flag.StringVar(&cfg.NetworkPath, "network", "run/net/network.json", "network.json written by chainctl testnet")
	flag.StringVar(&cfg.Listen, "listen", "127.0.0.1:8080", "listen address")
	flag.StringVar(&cfg.ProjectionPath, "projection", "run/projection.sqlite", "SQLite projection file (disposable)")
	flag.StringVar(&cfg.StaticDir, "static", "", "dashboard build directory to serve")
	flag.StringVar(&cfg.ReportsDir, "reports", "", "migration reports directory")
	flag.Float64Var(&cfg.RateLimit, "rate", 200, "submissions per second per client IP")
	flag.Float64Var(&cfg.RateBurst, "burst", 400, "burst size")
	flag.Parse()
	g, err := gateway.New(cfg)
	if err != nil {
		log.Fatal(err)
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	g.Start(ctx)
	srv := &http.Server{Addr: cfg.Listen, Handler: g.Handler(), ReadHeaderTimeout: 10 * time.Second}
	go func() { <-ctx.Done(); srv.Shutdown(context.Background()) }()
	log.Printf("gateway listening on http://%s (network %s)", cfg.Listen, g.Net.NetworkID)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}
