# Migration report `rpt-trial-b18aa00ce4-20261112T210028Z-004`

* **Decision: ACCEPT**  (phase `trial`, TRIAL)
* network `aureom-trial-1` - source system `legacy-retail-erp` - authoritative system now: **CHAIN**
* generated 2026-11-12T21:00:28Z - chain height 33
* snapshot `snap-b18aa00ce49fc519` (sha256 `b3f538cdaeffc3a8453144010eeaa89d8c8f1606629934999491010488e83222`) - mapping `map-v1` (sha256 `137a5ca8d0fa70810e58cd2ccd8e7cd8d9f4d21f9605bb2b9a87832a30d0ec19`)
* source freeze marker `8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6`

TRIAL ROLL-UP: full rehearsal master -> freeze -> opening -> reconcile -> cutover on a throwaway network; the final (pre-close) report hash was attested by MigrationControl CLOSE.

## Checks

{'PASS': 82}

| status | check | source (expected) | chain | delta | detail |
|---|---|---:|---:|---:|---|
| PASS | migration window status | 1 | 1 | 0 | expected 'CLOSED', chain 'CLOSED'; on-chain mig/state at height 33 |
| PASS | location count (imported) | 2 | 2 | 0 |  |
| PASS | location records | 2 | 2 | 0 | all 2 records identical |
| PASS | supplier count | 14 | 14 | 0 |  |
| PASS | supplier records | 14 | 14 | 0 | all 14 records identical |
| PASS | product count | 152 | 152 | 0 |  |
| PASS | product records | 152 | 152 | 0 | all 152 records identical |
| PASS | SKU count | 413 | 413 | 0 |  |
| PASS | SKU records | 413 | 413 | 0 | all 413 records identical |
| PASS | price count | 433 | 433 | 0 |  |
| PASS | price records | 433 | 433 | 0 | all 433 records identical |
| PASS | promotion count (native ActivatePromotion) | 3 | 3 | 0 |  |
| PASS | promotion records | 3 | 3 | 0 | all 3 records identical |
| PASS | stock balance rows (sku, location, bucket) | 1303 | 1303 | 0 |  |
| PASS | opening stock total, unit EA | 39198 | 39198 | 0 | sum of OPENING_BALANCE movements (smallest unit steps) |
| PASS | opening stock total, unit KG | 2297841 | 2297841 | 0 | sum of OPENING_BALANCE movements (smallest unit steps) |
| PASS | opening stock total, unit L | 1753378 | 1753378 | 0 | sum of OPENING_BALANCE movements (smallest unit steps) |
| PASS | opening stock total, unit M | 508780 | 508780 | 0 | sum of OPENING_BALANCE movements (smallest unit steps) |
| PASS | opening stock total, unit PK | 2247 | 2247 | 0 | sum of OPENING_BALANCE movements (smallest unit steps) |
| PASS | stock balance per (sku, location, bucket) | 1303 | 1303 | 0 | all 1303 records identical |
| PASS | open purchase order count | 14 | 14 | 0 |  |
| PASS | outstanding PO quantity, unit EA | 556 | 556 | 0 |  |
| PASS | outstanding PO value (minor units) | 1044401 | 1044401 | 0 | sum of (ordered - received) x unit cost, half-even per line |
| PASS | open PO ordered value (minor units) | 1084141 | 1084141 | 0 | chain-computed PO totals vs expected (the chain counter open_po_total_minor is checked below) |
| PASS | open purchase order records | 14 | 14 | 0 | all 14 records identical |
| PASS | loyalty account count | 423 | 423 | 0 |  |
| PASS | loyalty opening points total | 408179 | 408179 | 0 |  |
| PASS | loyalty opening balance per customer | 423 | 423 | 0 | all 423 records identical |
| PASS | historical sales count | 1959 | 1959 | 0 |  |
| PASS | historical sales net total (minor units) | 13714664 | 13714664 | 0 |  |
| PASS | historical sales refunded total (minor units) | 251336 | 251336 | 0 |  |
| PASS | historical sale records | 1959 | 1959 | 0 | all 1959 records identical |
| PASS | chain counter historical_net_minor | 13714664 | 13714664 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter historical_refunded_minor | 251336 | 251336 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter historical_sales | 1959 | 1959 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter locations | 2 | 2 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter loyalty_accounts | 423 | 423 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter loyalty_points | 408179 | 408179 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter open_po_total_minor | 1084141 | 1084141 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter open_pos | 14 | 14 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_rows | 1303 | 1303 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_units|EA | 39198 | 39198 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_units|KG | 2297841 | 2297841 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_units|L | 1753378 | 1753378 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_units|M | 508780 | 508780 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter opening_balance_units|PK | 2247 | 2247 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter po_outstanding_units|EA | 556 | 556 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter prices | 433 | 433 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter products | 152 | 152 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter skus | 413 | 413 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | chain counter suppliers | 14 | 14 | 0 | mig/state.chain_counters vs expected totals (attested at CLOSE) |
| PASS | planned batches present on chain (mig/batch) | 20 | 20 | 0 | every planned batch is on chain with the planned record count |
| PASS | no unplanned batches on chain | 0 | 0 | 0 | none |
| PASS | imported records carry provenance of a planned batch | 0 | 0 | 0 | origin=IMPORTED, source system, source id and a planned batch id |
| PASS | attested CLOSE totals equal the expected totals | 19 | 19 | 0 | 19 attested keys |
| PASS | on-chain reconciliation report hash is the final report's hash | 1 | 1 | 0 | expected '83afc35547b37ddcd7fe898e365e4bdeaa47b64647fd533c213754adea0062e8', chain '83afc35547b37ddcd7fe898e365e4bdeaa47b64647fd533c213754adea0062e8'; final report rpt-trial-final-b18aa00ce4-20261112T210024Z-002 |
| PASS | on-chain source freeze marker is the recorded marker | 1 | 1 | 0 | expected '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6', chain '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6' |
| PASS | source snapshot integrity (sha256 of the snapshot file) | 1 | 1 | 0 | expected 'b3f538cdaeffc3a8453144010eeaa89d8c8f1606629934999491010488e83222', chain 'b3f538cdaeffc3a8453144010eeaa89d8c8f1606629934999491010488e83222'; snap-b18aa00ce49fc519: the file hash must be unchanged since it was taken |
| PASS | mapping spec unchanged since the migration started | 1 | 1 | 0 | expected '137a5ca8d0fa70810e58cd2ccd8e7cd8d9f4d21f9605bb2b9a87832a30d0ec19', chain '137a5ca8d0fa70810e58cd2ccd8e7cd8d9f4d21f9605bb2b9a87832a30d0ec19'; map-v1 |
| PASS | exactly one authoritative system | 1 | 1 | 0 | expected 'CHAIN', chain 'CHAIN'; source system_state.authoritative_system=CHAIN frozen=1 archived=1; chain window CLOSED; CONSISTENT |
| PASS | source freeze marker unchanged (no write since the freeze) | 1 | 1 | 0 | expected '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6', chain '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6'; change-log high-water 101 (101 rows) |
| PASS | write-freeze enforced on the source | 1 | 1 | 0 | expected True, chain True; a test write was refused by the source's own triggers |
| PASS | final snapshot was taken at the freeze marker | 1 | 1 | 0 | expected '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6', chain '8a83d223c70c25be08da3bf3fe7e975416578d34db147eee9ff4ed5e260186a6'; snapshot snap-b18aa00ce49fc519 |
| PASS | schema gate: every source column has a declared treatment | 0 | 0 | 0 | no unmapped/missing columns |
| PASS | exception accounting closes: LOCATION | 6 | 6 | 0 | 6 source rows = 2 migrated + 0 excluded (exceptions) + 4 out of scope - every source row is accounted for |
| PASS | exception accounting closes: SUPPLIER | 14 | 14 | 0 | 14 source rows = 14 migrated + 0 excluded (exceptions) + 0 out of scope - every source row is accounted for |
| PASS | exception accounting closes: PRODUCT | 152 | 152 | 0 | 152 source rows = 152 migrated + 0 excluded (exceptions) + 0 out of scope - every source row is accounted for |
| PASS | excluded share: PRODUCT | 7 | 0 | -7 | 0 of 152 excluded (0.00%), limit 5.0% |
| PASS | exception accounting closes: SKU | 418 | 418 | 0 | 418 source rows = 413 migrated + 5 excluded (exceptions) + 0 out of scope - every source row is accounted for |
| PASS | excluded share: SKU | 20 | 5 | -15 | 5 of 418 excluded (1.20%), limit 5.0% |
| PASS | exception accounting closes: PRICE | 553 | 553 | 0 | 553 source rows = 433 migrated + 10 excluded (exceptions) + 110 out of scope - every source row is accounted for |
| PASS | excluded share: PRICE | 22 | 10 | -12 | 10 of 443 excluded (2.26%), limit 5.0% |
| PASS | exception accounting closes: PROMOTION | 5 | 5 | 0 | 5 source rows = 3 migrated + 1 excluded (exceptions) + 1 out of scope - every source row is accounted for |
| PASS | exception accounting closes: HISTORICAL_SALE | 2007 | 2007 | 0 | 2007 source rows = 1959 migrated + 16 excluded (exceptions) + 32 out of scope - every source row is accounted for |
| PASS | excluded share: HISTORICAL_SALE | 39 | 16 | -23 | 16 of 1975 excluded (0.81%), limit 2.0% |
| PASS | exception accounting closes: OPEN_PO | 39 | 39 | 0 | 39 source rows = 14 migrated + 2 excluded (exceptions) + 23 out of scope - every source row is accounted for |
| PASS | excluded share: OPEN_PO | 4 | 2 | -2 | 2 of 16 excluded (12.50%), limit 25.0% |
| PASS | exception accounting closes: LOYALTY_OPENING | 427 | 427 | 0 | 427 source rows = 423 migrated + 4 excluded (exceptions) + 0 out of scope - every source row is accounted for |
| PASS | excluded share: LOYALTY_OPENING | 21 | 4 | -17 | 4 of 427 excluded (0.94%), limit 5.0% |
| PASS | exception accounting closes: OPENING_BALANCE | 1269 | 1269 | 0 | 1269 source rows = 1238 migrated + 14 excluded (exceptions) + 17 out of scope - every source row is accounted for |
| PASS | excluded share: OPENING_BALANCE | 62 | 14 | -48 | 14 of 1252 excluded (1.12%), limit 5.0% |
| PASS | unresolved MANUAL exceptions | 0 | 0 | 0 | 25 MANUAL item(s); 25 acknowledged by trial-runner; must be resolved or acknowledged before cutover |

## Entities

| entity | source rows in scope | migrated | excluded | out of scope |
|---|---:|---:|---:|---|
| LOCATION | 6 | 2 | 0 | 4 x already on chain from genesis (mapped, not imported) |
| SUPPLIER | 14 | 14 | 0 |  |
| PRODUCT | 152 | 152 | 0 |  |
| PRICE | 553 | 433 | 10 | 110 x expired before the snapshot (history, not migrated) |
| PROMOTION | 5 | 3 | 1 | 1 x ended or expired (not migrated) |
| HISTORICAL_SALE | 2007 | 1959 | 16 | 30 x status VOID: not a completed sale (not migrated), 2 x status OPEN: not a completed sale (not migrated) |
| OPENING_BALANCE | 1269 | 1303 | 14 | 17 x zero quantity (nothing to import) |
| OPEN_PO | 39 | 14 | 2 | 12 x status RECEIVED: not outstanding (only outstanding purchase orders are migrated), 6 x status CLOSED: not outstanding (only outstanding purchase orders are migrated), 5 x status CANCELLED: not outstanding (only outstanding purchase orders are migrated) |
| LOYALTY_OPENING | 427 | 423 | 4 |  |
| SKU | 418 | 413 | 5 |  |

## Exceptions

by disposition: {'EXCLUDED': 48, 'FIXED': 32, 'MANUAL': 25, 'PRESERVED_AS_EXTRAS': 39}

by kind: {'AMBIGUOUS_LOCAL_TIME': 2, 'CHANGED_AFTER_MASTER': 2, 'CURRENCY_MISMATCH': 5, 'DUPLICATE_BALANCE_ROW': 2, 'DUPLICATE_BARCODE': 3, 'DUPLICATE_CUSTOMER_ID': 2, 'DUPLICATE_PRICE': 1, 'DUPLICATE_SKU': 3, 'EMPTY_RECORD': 1, 'EXCLUDED_DEPENDENCY': 4, 'FLOAT_PRECISION': 4, 'FRACTIONAL_QUANTITY': 7, 'FUTURE_TIMESTAMP': 1, 'HEADER_TOTAL_MISMATCH': 6, 'INVALID_PRICE': 1, 'INVALID_TIMESTAMP': 3, 'LEGACY_CUSTOMER_ID': 5, 'LINE_TOTAL_MISMATCH': 3, 'NEGATIVE_POINTS': 1, 'NEGATIVE_STOCK': 4, 'NONEXISTENT_LOCAL_TIME': 1, 'NON_ASCII_TEXT': 6, 'ORPHAN_FK': 19, 'PAYMENT_MISMATCH': 10, 'PRICE_PERIOD_INVALID': 1, 'REFUND_EXCEEDS_SALE': 1, 'STALE_PO_CLOSED': 1, 'UNIT_MISMATCH': 3, 'UNKNOWN_CHANNEL': 1, 'UNSUPPORTED_FIELD': 40, 'UNSUPPORTED_PROMO_TYPE': 1}

| kind | source | disposition | detail |
|---|---|---|---|
| AMBIGUOUS_LOCAL_TIME | `sales:290` | FIXED | sold_at '2026-10-25 01:15:00' occurs twice (DST fold); first occurrence used -> 2026-10-25T00:15:00.000Z |
| AMBIGUOUS_LOCAL_TIME | `sales:360` | FIXED | sold_at '2025-10-26 01:30:00' occurs twice (DST fold); first occurrence used -> 2025-10-26T00:30:00.000Z |
| CHANGED_AFTER_MASTER | `products:5` | MANUAL | PRODUCT products:5 changed in the source after the master snapshot; the chain keeps the master-time version (apply a native correction or accept) |
| CHANGED_AFTER_MASTER | `sales:100` | MANUAL | HISTORICAL_SALE sales:100 changed in the source after the master snapshot; the chain keeps the master-time version (apply a native correction or accept) |
| CURRENCY_MISMATCH | `price_list_items:548` | EXCLUDED | price list currency USD but location STORE-S-01 trades in GBP; the chain refuses the price |
| CURRENCY_MISMATCH | `price_list_items:549` | EXCLUDED | price list currency USD but location STORE-S-01 trades in GBP; the chain refuses the price |
| CURRENCY_MISMATCH | `price_list_items:550` | EXCLUDED | price list currency USD but location STORE-S-01 trades in GBP; the chain refuses the price |
| CURRENCY_MISMATCH | `price_list_items:551` | EXCLUDED | price list currency USD but location STORE-S-01 trades in GBP; the chain refuses the price |
| CURRENCY_MISMATCH | `price_list_items:552` | EXCLUDED | price list currency USD but location STORE-S-01 trades in GBP; the chain refuses the price |
| DUPLICATE_BALANCE_ROW | `inventory_balances:1267` | MANUAL | 2 balance rows for SKU-00047 at WH-RET-01 (inventory_balances:140, inventory_balances:1267); the correct count must be decided manually |
| DUPLICATE_BALANCE_ROW | `inventory_balances:140` | MANUAL | 2 balance rows for SKU-00047 at WH-RET-01 (inventory_balances:140, inventory_balances:1267); the correct count must be decided manually |
| DUPLICATE_BARCODE | `product_variants:290` | PRESERVED_AS_EXTRAS | barcode 5060000001396 is already assigned to SKU-00139; cleared here, original preserved in source_extras |
| DUPLICATE_BARCODE | `product_variants:387` | PRESERVED_AS_EXTRAS | barcode 5060000003581 is already assigned to SKU-00358; cleared here, original preserved in source_extras |
| DUPLICATE_BARCODE | `product_variants:79` | PRESERVED_AS_EXTRAS | barcode 5060000000337 is already assigned to SKU-00033; cleared here, original preserved in source_extras |
| DUPLICATE_CUSTOMER_ID | `loyalty_accounts:C0045` | MANUAL | 2 loyalty accounts normalise to CUST-000045 (loyalty_accounts:C0045, loyalty_accounts:CUST-000045); which balance is right must be decided manually |
| DUPLICATE_CUSTOMER_ID | `loyalty_accounts:CUST-000045` | MANUAL | 2 loyalty accounts normalise to CUST-000045 (loyalty_accounts:C0045, loyalty_accounts:CUST-000045); which balance is right must be decided manually |
| DUPLICATE_PRICE | `price_list_items:378` | EXCLUDED | another price for SKU-00300@* has the same effective-from; the later item 544 wins (chain forbids two prices with one effective_from) |
| DUPLICATE_SKU | `product_variants:414` | EXCLUDED | sku identical to variant 240 ('SKU-00240'); the lowest variant_id is kept |
| DUPLICATE_SKU | `product_variants:415` | EXCLUDED | sku equal after normalisation (' sku-00136 ' vs 'SKU-00136') to variant 136 ('SKU-00136'); the lowest variant_id is kept |
| DUPLICATE_SKU | `product_variants:416` | EXCLUDED | sku identical to variant 117 ('SKU-00117'); the lowest variant_id is kept |
| EMPTY_RECORD | `sales:1815` | EXCLUDED | sale has no lines |
| EXCLUDED_DEPENDENCY | `inventory_balances:1040` | EXCLUDED | sku SKU-00343 is not migrated |
| EXCLUDED_DEPENDENCY | `inventory_balances:1041` | EXCLUDED | sku SKU-00343 is not migrated |
| EXCLUDED_DEPENDENCY | `inventory_balances:1042` | EXCLUDED | sku SKU-00343 is not migrated |
| EXCLUDED_DEPENDENCY | `price_list_items:432` | EXCLUDED | sku SKU-00343 is not migrated |
| FLOAT_PRECISION | `price_list_items:108` | FIXED | price 15.995000000000001 carries sub-minor-unit precision; rounded half-even to 1600 minor units |
| FLOAT_PRECISION | `price_list_items:186` | FIXED | price 15.995000000000001 carries sub-minor-unit precision; rounded half-even to 1600 minor units |
| FLOAT_PRECISION | `price_list_items:513` | FIXED | price 8.115 carries sub-minor-unit precision; rounded half-even to 812 minor units |
| FLOAT_PRECISION | `sales:135` | FIXED | line 245 line_total 6.933999999999999 carries sub-minor-unit precision; rounded half-even to 693 minor units |
| FRACTIONAL_QUANTITY | `inventory_balances:450` | FIXED | on_hand 28.5 is fractional for an EA item; rounded half-even to 28 (recount advised) |
| FRACTIONAL_QUANTITY | `inventory_balances:53` | FIXED | on_hand 39.5 is fractional for an EA item; rounded half-even to 40 (recount advised) |
| FRACTIONAL_QUANTITY | `inventory_balances:889` | FIXED | on_hand 19.5 is fractional for an EA item; rounded half-even to 20 (recount advised) |
| FRACTIONAL_QUANTITY | `inventory_balances:925` | FIXED | on_hand 17.5 is fractional for an EA item; rounded half-even to 18 (recount advised) |
| FRACTIONAL_QUANTITY | `sales:1166` | MANUAL | sale line 2197 sells 1.5 of an EA item; not representable |
| FRACTIONAL_QUANTITY | `sales:1755` | MANUAL | sale line 3286 sells 1.5 of an EA item; not representable |
| FRACTIONAL_QUANTITY | `sales:477` | MANUAL | sale line 923 sells 1.5 of an EA item; not representable |
| FUTURE_TIMESTAMP | `sales:269` | MANUAL | sold_at '2027-03-01 12:00:00' is after the snapshot time (2026-11-12T21:00:10.469Z) |
| HEADER_TOTAL_MISMATCH | `sales:1821` | FIXED | header total 970 differs from the sum of line nets 470; the lines are authoritative |
| HEADER_TOTAL_MISMATCH | `sales:1862` | FIXED | header total 14543 differs from the sum of line nets 14843; the lines are authoritative |
| HEADER_TOTAL_MISMATCH | `sales:468` | FIXED | header total 9877 differs from the sum of line nets 9377; the lines are authoritative |
| HEADER_TOTAL_MISMATCH | `sales:577` | FIXED | header total 2781 differs from the sum of line nets 3081; the lines are authoritative |
| HEADER_TOTAL_MISMATCH | `sales:766` | FIXED | header total 5029 differs from the sum of line nets 5329; the lines are authoritative |
| HEADER_TOTAL_MISMATCH | `sales:792` | FIXED | header total 18532 differs from the sum of line nets 18032; the lines are authoritative |
| INVALID_PRICE | `price_list_items:545` | EXCLUDED | price 0.0 is not positive |
| INVALID_TIMESTAMP | `sales:1410` | MANUAL | sold_at: unrecognised timestamp format: 'not-a-date' |
| INVALID_TIMESTAMP | `sales:230` | MANUAL | sold_at: '2025-02-30 10:15:00': day is out of range for month |
| INVALID_TIMESTAMP | `sales:457` | MANUAL | sold_at: '31/13/2025 09:00' (read as DD/MM/YYYY): month must be in 1..12 |
| LEGACY_CUSTOMER_ID | `loyalty_accounts:C0045` | FIXED | customer id 'C0045' does not match the chain's synthetic id format; mapped to CUST-000045 (zero-padded) |
| LEGACY_CUSTOMER_ID | `loyalty_accounts:C0701` | FIXED | customer id 'C0701' does not match the chain's synthetic id format; mapped to CUST-000701 (zero-padded) |
| LEGACY_CUSTOMER_ID | `loyalty_accounts:LEGACY-9001` | FIXED | customer id 'LEGACY-9001' does not match the chain's synthetic id format; mapped to PSN-257B9E9EDCCC48AB (pseudonymised) |
| LEGACY_CUSTOMER_ID | `loyalty_accounts:WEB-GUEST-55` | FIXED | customer id 'WEB-GUEST-55' does not match the chain's synthetic id format; mapped to PSN-FD5E9E7D3987FCC2 (pseudonymised) |
| LEGACY_CUSTOMER_ID | `loyalty_accounts:cust_000702` | FIXED | customer id 'cust_000702' does not match the chain's synthetic id format; mapped to CUST-000702 (zero-padded) |
| LINE_TOTAL_MISMATCH | `sales:1862` | FIXED | line 3489: qty x price - discount = 743 but recorded line_total = 1043; the recorded line_total is kept as net and the discount derived |
| LINE_TOTAL_MISMATCH | `sales:577` | FIXED | line 1116: qty x price - discount = 2781 but recorded line_total = 3081; the recorded line_total is kept as net and the discount derived |
| LINE_TOTAL_MISMATCH | `sales:766` | FIXED | line 1464: qty x price - discount = 862 but recorded line_total = 1162; the recorded line_total is kept as net and the discount derived |
| NEGATIVE_POINTS | `loyalty_accounts:CUST-000099` | MANUAL | points_balance -50 is negative |
| NEGATIVE_STOCK | `inventory_balances:1023` | MANUAL | on_hand is negative (-8.0); a negative physical balance cannot be imported - recount before cutover |
| NEGATIVE_STOCK | `inventory_balances:351` | MANUAL | on_hand is negative (-4.0); a negative physical balance cannot be imported - recount before cutover |
| NEGATIVE_STOCK | `inventory_balances:584` | MANUAL | on_hand is negative (-3.0); a negative physical balance cannot be imported - recount before cutover |
| NEGATIVE_STOCK | `inventory_balances:847` | MANUAL | on_hand is negative (-12.0); a negative physical balance cannot be imported - recount before cutover |
| NONEXISTENT_LOCAL_TIME | `sales:465` | FIXED | sold_at '2025-03-30 01:30:00' does not exist (DST gap); pre-transition offset used -> 2025-03-30T01:30:00.000Z |
| NON_ASCII_TEXT | `products:12` | FIXED | name 'Café Latté Mug 350ml' is not printable ASCII -> 'Cafe Latte Mug 350ml'; original preserved in source_extras |
| NON_ASCII_TEXT | `products:30` | FIXED | name 'Jalapeño Hot Sauce' is not printable ASCII -> 'Jalapeno Hot Sauce'; original preserved in source_extras |
| NON_ASCII_TEXT | `products:48` | FIXED | name 'Crème Brûlée Torch' is not printable ASCII -> 'Creme Brulee Torch'; original preserved in source_extras |
| NON_ASCII_TEXT | `products:64` | FIXED | name '£ Saver Gift Card Holder' is not printable ASCII -> 'GBP Saver Gift Card Holder'; original preserved in source_extras |
| NON_ASCII_TEXT | `promotions:PROMO-002` | FIXED | name 'Coffee 3 for £10' is not printable ASCII -> 'Coffee 3 for GBP 10' |
| NON_ASCII_TEXT | `suppliers:SUP-008` | FIXED | name 'Müller & Söhne Ltd' is not printable ASCII -> 'Muller & Sohne Ltd'; original preserved in source_extras |
| ORPHAN_FK | `inventory_balances:1264` | EXCLUDED | inventory row for unknown location 'XX01' |
| ORPHAN_FK | `inventory_balances:1265` | EXCLUDED | inventory row for unknown location 'STORE-17' |
| ORPHAN_FK | `inventory_balances:1266` | EXCLUDED | inventory row for unknown location 'STORE-17' |
| ORPHAN_FK | `inventory_balances:1268` | EXCLUDED | inventory row for unknown SKU 'SKU-GHOST-1' |
| ORPHAN_FK | `loyalty_accounts:CUST-008888` | MANUAL | loyalty account 'CUST-008888' has no customer record |
| ORPHAN_FK | `payments:2046` | EXCLUDED | payment references missing sale 880000 |
| ORPHAN_FK | `payments:2047` | EXCLUDED | payment references missing sale 880001 |
| ORPHAN_FK | `price_list_items:546` | EXCLUDED | price for unknown sku 'SKU-NOSUCH-9' |
| ORPHAN_FK | `product_variants:417` | EXCLUDED | variant references missing product 99001 |
| ORPHAN_FK | `products:140` | PRESERVED_AS_EXTRAS | product references missing category 88; category left empty, original id preserved in source_extras |
| ORPHAN_FK | `purchase_orders:PO-2037` | EXCLUDED | purchase order references missing supplier 'SUP-999' |
| ORPHAN_FK | `sales:1029` | PRESERVED_AS_EXTRAS | sale customer 'CUST-009999' has no customer record; sale kept anonymous, original id preserved in source_extras |
| ORPHAN_FK | `sales:1060` | EXCLUDED | sale at unknown store 'S077' |
| ORPHAN_FK | `sales:286` | EXCLUDED | sale line 538 references missing variant 990286 |
| ORPHAN_FK | `sales:292` | EXCLUDED | sale line 554 references missing variant 990292 |
| ORPHAN_FK | `sales:414` | EXCLUDED | sale line 793 references missing variant 990414 |
| ORPHAN_FK | `sales:530` | PRESERVED_AS_EXTRAS | sale customer 'CUST-009999' has no customer record; sale kept anonymous, original id preserved in source_extras |
| ORPHAN_FK | `sales:79` | PRESERVED_AS_EXTRAS | sale customer 'CUST-009999' has no customer record; sale kept anonymous, original id preserved in source_extras |
| ORPHAN_FK | `sales:826` | EXCLUDED | sale line 1570 references missing variant 990826 |
| PAYMENT_MISMATCH | `sales:1246` | PRESERVED_AS_EXTRAS | captured payments 21419 vs sale net 21619 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:1276` | PRESERVED_AS_EXTRAS | captured payments 843 vs sale net 1043 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:1334` | PRESERVED_AS_EXTRAS | captured payments 10334 vs sale net 10534 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:1862` | PRESERVED_AS_EXTRAS | captured payments 14543 vs sale net 14843 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:508` | PRESERVED_AS_EXTRAS | captured payments 0 vs sale net 499 -> FAILED; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:577` | PRESERVED_AS_EXTRAS | captured payments 2781 vs sale net 3081 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:717` | PRESERVED_AS_EXTRAS | captured payments 17932 vs sale net 18132 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:766` | PRESERVED_AS_EXTRAS | captured payments 5029 vs sale net 5329 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:863` | PRESERVED_AS_EXTRAS | captured payments 938 vs sale net 1138 -> PARTIALLY_PAID; asserted as recorded, payment breakdown preserved in source_extras |
| PAYMENT_MISMATCH | `sales:994` | PRESERVED_AS_EXTRAS | captured payments 0 vs sale net 8177 -> FAILED; asserted as recorded, payment breakdown preserved in source_extras |
| PRICE_PERIOD_INVALID | `price_list_items:547` | EXCLUDED | valid_to is not after valid_from |
| REFUND_EXCEEDS_SALE | `sales:1705` | MANUAL | refunds 3079 exceed the sale net 579 |
| STALE_PO_CLOSED | `purchase_orders:PO-2036` | EXCLUDED | status APPROVED but every line is fully received and closed_at='2026-07-15 10:00:00'; nothing is outstanding, not migrated |
| UNIT_MISMATCH | `inventory_balances:707` | MANUAL | balance row unit 'KG' (KG) differs from SKU SKU-00233 unit EA |
| UNIT_MISMATCH | `product_variants:343` | MANUAL | unit='EA' (EA) but uom='KG' (KG); the SKU cannot be migrated until the unit of measure is confirmed |
| UNIT_MISMATCH | `sales:1614` | MANUAL | sale line 3019 unit 'KG' differs from SKU SKU-00068 unit EA |
| UNKNOWN_CHANNEL | `sales:1695` | MANUAL | sales channel 'KIOSK' is not mapped (known: ECOM, POS, STORE, WEB) |
| UNSUPPORTED_FIELD | `customers.enrolled_on` | EXCLUDED | 606 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `customers.home_store` | EXCLUDED | 606 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `customers.marketing_opt_in` | EXCLUDED | 606 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `customers.segment` | EXCLUDED | 606 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `inventory_balances.bin_location` | EXCLUDED | 953 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `inventory_balances.counted_at` | EXCLUDED | 829 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `inventory_balances.reserved` | FIXED | 1269 row(s) carry a value; folded into another field (no separate chain field); already inside on_hand; reservations are not importable (no fabricated reservations) and are recreated natively |
| UNSUPPORTED_FIELD | `loyalty_accounts.last_activity_at` | EXCLUDED | 427 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `loyalty_accounts.tier` | EXCLUDED | 427 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `loyalty_accounts.tier_colour` | EXCLUDED | 427 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `price_list_items.notes` | EXCLUDED | 152 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `price_lists.name` | EXCLUDED | 3 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `product_variants.custom_json` | PRESERVED_AS_EXTRAS | 35 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['custom_json'] |
| UNSUPPORTED_FIELD | `product_variants.status` | PRESERVED_AS_EXTRAS | 418 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['source_status'] |
| UNSUPPORTED_FIELD | `products.created_at` | PRESERVED_AS_EXTRAS | 152 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['created_at'] |
| UNSUPPORTED_FIELD | `products.custom_json` | PRESERVED_AS_EXTRAS | 28 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['custom_json'] |
| UNSUPPORTED_FIELD | `products.loyalty_tier_colour` | PRESERVED_AS_EXTRAS | 65 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['loyalty_tier_colour'] |
| UNSUPPORTED_FIELD | `products.supplier_id` | PRESERVED_AS_EXTRAS | 152 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['supplier_id'] |
| UNSUPPORTED_FIELD | `promotions.banner_ref` | EXCLUDED | 3 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `purchase_orders.approved_by` | PRESERVED_AS_EXTRAS | 36 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['approved_by'] |
| UNSUPPORTED_FIELD | `purchase_orders.closed_at` | PRESERVED_AS_EXTRAS | 24 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['closed_at'] |
| UNSUPPORTED_FIELD | `purchase_orders.expected_on` | PRESERVED_AS_EXTRAS | 38 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['expected_on'] |
| UNSUPPORTED_FIELD | `purchase_orders.notes` | PRESERVED_AS_EXTRAS | 24 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['notes'] |
| UNSUPPORTED_FIELD | `returns.reason` | EXCLUDED | 82 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `returns.return_id` | EXCLUDED | 82 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `returns.returned_at` | EXCLUDED | 82 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `returns.sale_id` | EXCLUDED | 82 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `returns.status` | EXCLUDED | 82 row(s) carry a value; dropped with approval; approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| UNSUPPORTED_FIELD | `sales.cashier_ref` | PRESERVED_AS_EXTRAS | 2007 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['cashier_ref'] |
| UNSUPPORTED_FIELD | `sales.discount_total` | PRESERVED_AS_EXTRAS | 2007 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['source_header_discount_minor'] |
| UNSUPPORTED_FIELD | `sales.receipt_no` | PRESERVED_AS_EXTRAS | 2007 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['receipt_no'] |
| UNSUPPORTED_FIELD | `sales.terminal_no` | PRESERVED_AS_EXTRAS | 1715 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['terminal_no'] |
| UNSUPPORTED_FIELD | `sales.total` | PRESERVED_AS_EXTRAS | 2007 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['source_header_total_minor'] |
| UNSUPPORTED_FIELD | `stores.floor_area_sqm` | PRESERVED_AS_EXTRAS | 4 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['floor_area_sqm'] |
| UNSUPPORTED_FIELD | `stores.opened_on` | PRESERVED_AS_EXTRAS | 4 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['opened_on'] |
| UNSUPPORTED_FIELD | `stores.status` | PRESERVED_AS_EXTRAS | 4 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['status'] |
| UNSUPPORTED_FIELD | `suppliers.active` | PRESERVED_AS_EXTRAS | 14 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['active'] |
| UNSUPPORTED_FIELD | `suppliers.credit_rating` | PRESERVED_AS_EXTRAS | 14 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['credit_rating'] |
| UNSUPPORTED_FIELD | `suppliers.currency` | PRESERVED_AS_EXTRAS | 14 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['currency'] |
| UNSUPPORTED_FIELD | `warehouses.status` | PRESERVED_AS_EXTRAS | 2 row(s) carry a value; preserved in source_extras; copied verbatim into source_extras['status'] |
| UNSUPPORTED_PROMO_TYPE | `promotions:PROMO-003` | MANUAL | promotion type 'BOGOF' has no chain equivalent (chain supports PERCENT_OFF, AMOUNT_OFF_PER_UNIT, MULTIBUY_FIXED_PRICE) |

## Unsupported source fields (never silently dropped)

| table | column | rows with a value | treatment | detail |
|---|---|---:|---|---|
| customers | enrolled_on | 606 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| customers | home_store | 606 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| customers | segment | 606 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| customers | marketing_opt_in | 606 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| inventory_balances | reserved | 1269 | folded into another field (no separate chain field) | already inside on_hand; reservations are not importable (no fabricated reservations) and are recreated natively |
| inventory_balances | bin_location | 953 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| inventory_balances | counted_at | 829 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| loyalty_accounts | tier | 427 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| loyalty_accounts | tier_colour | 427 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| loyalty_accounts | last_activity_at | 427 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| price_list_items | notes | 152 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| price_lists | name | 3 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| product_variants | status | 418 | preserved in source_extras | copied verbatim into source_extras['source_status'] |
| product_variants | custom_json | 35 | preserved in source_extras | copied verbatim into source_extras['custom_json'] |
| products | supplier_id | 152 | preserved in source_extras | copied verbatim into source_extras['supplier_id'] |
| products | created_at | 152 | preserved in source_extras | copied verbatim into source_extras['created_at'] |
| products | loyalty_tier_colour | 65 | preserved in source_extras | copied verbatim into source_extras['loyalty_tier_colour'] |
| products | custom_json | 28 | preserved in source_extras | copied verbatim into source_extras['custom_json'] |
| promotions | banner_ref | 3 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| purchase_orders | expected_on | 38 | preserved in source_extras | copied verbatim into source_extras['expected_on'] |
| purchase_orders | closed_at | 24 | preserved in source_extras | copied verbatim into source_extras['closed_at'] |
| purchase_orders | approved_by | 36 | preserved in source_extras | copied verbatim into source_extras['approved_by'] |
| purchase_orders | notes | 24 | preserved in source_extras | copied verbatim into source_extras['notes'] |
| returns | return_id | 82 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| returns | sale_id | 82 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| returns | returned_at | 82 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| returns | reason | 82 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| returns | status | 82 | dropped with approval | approval AP-2026-0147 (Retail Data Owner (synthetic approver), 2026-11-02) |
| sales | receipt_no | 2007 | preserved in source_extras | copied verbatim into source_extras['receipt_no'] |
| sales | terminal_no | 1715 | preserved in source_extras | copied verbatim into source_extras['terminal_no'] |
| sales | cashier_ref | 2007 | preserved in source_extras | copied verbatim into source_extras['cashier_ref'] |
| sales | total | 2007 | preserved in source_extras | copied verbatim into source_extras['source_header_total_minor'] |
| sales | discount_total | 2007 | preserved in source_extras | copied verbatim into source_extras['source_header_discount_minor'] |
| stores | opened_on | 4 | preserved in source_extras | copied verbatim into source_extras['opened_on'] |
| stores | floor_area_sqm | 4 | preserved in source_extras | copied verbatim into source_extras['floor_area_sqm'] |
| stores | status | 4 | preserved in source_extras | copied verbatim into source_extras['status'] |
| suppliers | currency | 14 | preserved in source_extras | copied verbatim into source_extras['currency'] |
| suppliers | credit_rating | 14 | preserved in source_extras | copied verbatim into source_extras['credit_rating'] |
| suppliers | active | 14 | preserved in source_extras | copied verbatim into source_extras['active'] |
| warehouses | status | 2 | preserved in source_extras | copied verbatim into source_extras['status'] |

## Batches

| batch | entity | seq | records | tx | height | status |
|---|---|---:|---:|---|---:|---|
| `B-c8876930c0f6b0bd6c57724fda628173f437386a` | HISTORICAL_SALE | 1 | 400 | `mb-c8876930c0f6b0bd6c57724fda628173-00` | 16 | FINALISED |
| `B-cbc3fd8700b695870f677965bb1cb62135a552d1` | HISTORICAL_SALE | 2 | 400 | `mb-cbc3fd8700b695870f677965bb1cb621-00` | 17 | FINALISED |
| `B-03e0eae9bb7a13672d30fbfe9ca7890c283e04f5` | HISTORICAL_SALE | 3 | 400 | `mb-03e0eae9bb7a13672d30fbfe9ca7890c-00` | 18 | FINALISED |
| `B-723195db0a024316a9c596dc36c4b59b6195d4df` | HISTORICAL_SALE | 4 | 400 | `mb-723195db0a024316a9c596dc36c4b59b-00` | 19 | FINALISED |
| `B-5a988efff390a90d7f12a2524a55de32f5b15450` | HISTORICAL_SALE | 5 | 334 | `mb-5a988efff390a90d7f12a2524a55de32-00` | 20 | FINALISED |
| `B-fa043a719312b8cd8e7ea14dfa9352c67cefe799` | LOCATION | 1 | 2 | `mb-fa043a719312b8cd8e7ea14dfa9352c6-00` | 8 | FINALISED |
| `B-e177081adb4706971c920acbc060fbb0ed6db9c8` | PRICE | 1 | 400 | `mb-e177081adb4706971c920acbc060fbb0-00` | 11 | FINALISED |
| `B-fb3c5a10c74e5b6d1ceb3f88602c3ee5ec5cc23d` | PRICE | 2 | 32 | `mb-fb3c5a10c74e5b6d1ceb3f88602c3ee5-00` | 12 | FINALISED |
| `B-9641baaa8a477ebbe73b813e4f27320f8ee476be` | PRODUCT | 1 | 151 | `mb-9641baaa8a477ebbe73b813e4f27320f-00` | 10 | FINALISED |
| `B-e24f1c69590a5940a808b96661aed8abcc07a3b7` | SUPPLIER | 1 | 14 | `mb-e24f1c69590a5940a808b96661aed8ab-00` | 9 | FINALISED |
| `B-3da2397477a6afee28e072fc28bc931aaa7fefee` | LOYALTY_OPENING | 1 | 400 | `mb-3da2397477a6afee28e072fc28bc931a-00` | 30 | FINALISED |
| `B-31f131aefed9a4be9178488c60dfdf836e5b0759` | LOYALTY_OPENING | 2 | 23 | `mb-31f131aefed9a4be9178488c60dfdf83-00` | 31 | FINALISED |
| `B-b9ed02666d7b3c205bc344bdf35b5b5774870489` | OPENING_BALANCE | 1 | 400 | `mb-b9ed02666d7b3c205bc344bdf35b5b57-00` | 25 | FINALISED |
| `B-32522c66d3106ba86da67fc30facfca02f03f457` | OPENING_BALANCE | 2 | 400 | `mb-32522c66d3106ba86da67fc30facfca0-00` | 26 | FINALISED |
| `B-3249431638fc281bbe3ef36e4fddc75eb85f905f` | OPENING_BALANCE | 3 | 400 | `mb-3249431638fc281bbe3ef36e4fddc75e-00` | 27 | FINALISED |
| `B-13f05440d501b14afa29b561da749fd75be7158b` | OPENING_BALANCE | 4 | 103 | `mb-13f05440d501b14afa29b561da749fd7-00` | 28 | FINALISED |
| `B-97b13ec9042620deec6040dee149447ef87ab591` | OPEN_PO | 1 | 14 | `mb-97b13ec9042620deec6040dee149447e-00` | 29 | FINALISED |
| `B-bb8704acafe1c8d7ea6740ef6291ece68a29d0cb` | HISTORICAL_SALE | 1 | 25 | `mb-bb8704acafe1c8d7ea6740ef6291ece6-00` | 24 | FINALISED |
| `B-bedfb8e521754e5677a3167b8b1c1b5df3552ed9` | PRICE | 1 | 1 | `mb-bedfb8e521754e5677a3167b8b1c1b5d-00` | 23 | FINALISED |
| `B-dc70a162a8dfe9b34c4b1999d377485986a619e3` | PRODUCT | 1 | 1 | `mb-dc70a162a8dfe9b34c4b1999d3774859-00` | 22 | FINALISED |
