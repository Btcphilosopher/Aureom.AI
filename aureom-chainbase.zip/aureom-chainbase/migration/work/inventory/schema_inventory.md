# Source schema inventory

* source: `migration/source/retail_source.sqlite`
* sha256: `bbe51790b356592647bdb4b547c80e080043dee1ad89de926d46b089a4f4fca1`

| table | rows | primary key | foreign keys |
|---|---:|---|---|
| categories | 12 | category_id | parent_id -> categories.category_id |
| change_log | 0 | change_id |  |
| customers | 606 | customer_id |  |
| inventory_balances | 1268 | inv_id |  |
| loyalty_accounts | 427 | customer_id |  |
| payments | 2047 | payment_id | sale_id -> sales.sale_id |
| price_list_items | 552 | item_id | list_id -> price_lists.list_id |
| price_lists | 3 | list_id |  |
| product_variants | 417 | variant_id | product_id -> products.product_id |
| products | 151 | product_id | supplier_id -> suppliers.supplier_id, category_id -> categories.category_id |
| promotion_skus | 17 | promo_id, sku | promo_id -> promotions.promo_id |
| promotions | 5 | promo_id |  |
| purchase_order_lines | 75 | line_id | po_number -> purchase_orders.po_number |
| purchase_orders | 38 | po_number | supplier_id -> suppliers.supplier_id |
| refunds | 81 | refund_id |  |
| returns | 81 | return_id |  |
| sale_lines | 3679 | line_id | sale_id -> sales.sale_id |
| sales | 1982 | sale_id |  |
| stores | 4 | store_code |  |
| suppliers | 14 | supplier_id |  |
| system_state | 1 | id |  |
| warehouses | 2 | wh_code |  |

## categories (12 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| category_id | INTEGER |  | Y | 12 | 12 | integer:12 |
| name | TEXT | Y |  | 12 | 12 | text:12 |
| parent_id | INTEGER |  |  | 9 | 2 | integer:9, null:3 |

## change_log (0 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| change_id | INTEGER |  | Y |  |  |  |
| table_name | TEXT | Y |  |  |  |  |
| pk | TEXT | Y |  |  |  |  |
| op | TEXT | Y |  |  |  |  |
| changed_at | TEXT |  |  |  |  |  |

## customers (606 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| customer_id | TEXT |  | Y | 606 | 606 | text:606 |
| enrolled_on | TEXT |  |  | 606 | 544 | text:606 |
| home_store | TEXT |  |  | 606 | 4 | text:606 |
| segment | TEXT |  |  | 606 | 3 | text:606 |
| marketing_opt_in | INTEGER |  |  | 606 | 2 | integer:606 |

## inventory_balances (1268 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| inv_id | INTEGER |  | Y | 1268 | 1268 | integer:1268 |
| sku | TEXT | Y |  | 1268 | 414 | text:1268 |
| location_code | TEXT | Y |  | 1268 | 8 | text:1268 |
| unit | TEXT |  |  | 381 | 5 | null:887, text:381 |
| on_hand | REAL | Y |  | 1268 | 207 | real:1268 |
| reserved | REAL | Y |  | 1268 | 4 | real:1268 |
| damaged | REAL | Y |  | 1268 | 4 | real:1268 |
| bin_location | TEXT |  |  | 952 | 4 | null:316, text:952 |
| counted_at | TEXT |  |  | 828 | 2 | null:440, text:828 |

## loyalty_accounts (427 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| customer_id | TEXT |  | Y | 427 | 427 | text:427 |
| points_balance | INTEGER | Y |  | 427 | 96 | integer:427 |
| tier | TEXT |  |  | 427 | 3 | text:427 |
| tier_colour | TEXT |  |  | 427 | 3 | text:427 |
| last_activity_at | TEXT |  |  | 427 | 216 | text:427 |

## payments (2047 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| payment_id | INTEGER |  | Y | 2047 | 2047 | integer:2047 |
| sale_id | INTEGER |  |  | 2047 | 1952 | integer:2047 |
| method | TEXT |  |  | 2047 | 3 | text:2047 |
| amount | REAL | Y |  | 2047 | 1617 | real:2047 |
| status | TEXT | Y |  | 2047 | 2 | text:2047 |
| paid_at | TEXT |  |  | 2047 | 1951 | text:2047 |
| provider_ref | TEXT |  |  | 1950 | 1950 | null:97, text:1950 |

## price_list_items (552 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| item_id | INTEGER |  | Y | 552 | 552 | integer:552 |
| list_id | INTEGER | Y |  | 552 | 3 | integer:552 |
| sku | TEXT | Y |  | 552 | 414 | text:552 |
| price | REAL | Y |  | 552 | 255 | real:552 |
| valid_from | TEXT | Y |  | 552 | 8 | text:552 |
| valid_to | TEXT |  |  | 111 | 2 | null:441, text:111 |
| notes | TEXT |  |  | 151 | 7 | null:401, text:151 |

## price_lists (3 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| list_id | INTEGER |  | Y | 3 | 3 | integer:3 |
| name | TEXT | Y |  | 3 | 3 | text:3 |
| currency | TEXT | Y |  | 3 | 2 | text:3 |
| location_code | TEXT |  |  | 2 | 2 | null:1, text:2 |

## product_variants (417 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| variant_id | INTEGER |  | Y | 417 | 417 | integer:417 |
| product_id | INTEGER | Y |  | 417 | 152 | integer:417 |
| sku | TEXT | Y |  | 417 | 415 | text:417 |
| barcode | TEXT |  |  | 417 | 414 | text:417 |
| unit | TEXT | Y |  | 417 | 8 | text:417 |
| uom | TEXT |  |  | 392 | 5 | null:25, text:392 |
| scarce | INTEGER | Y |  | 417 | 2 | integer:417 |
| colour | TEXT |  |  | 212 | 8 | null:205, text:212 |
| size | TEXT |  |  | 295 | 14 | null:122, text:295 |
| weight_g | REAL |  |  | 150 | 147 | null:267, real:150 |
| status | TEXT |  |  | 417 | 1 | text:417 |
| custom_json | TEXT |  |  | 35 | 4 | null:382, text:35 |

## products (151 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| product_id | INTEGER |  | Y | 151 | 151 | integer:151 |
| product_code | TEXT | Y |  | 151 | 151 | text:151 |
| name | TEXT | Y |  | 151 | 151 | text:151 |
| brand | TEXT |  |  | 151 | 8 | text:151 |
| category_id | INTEGER |  |  | 151 | 11 | integer:151 |
| supplier_id | TEXT |  |  | 151 | 14 | text:151 |
| status | TEXT | Y |  | 151 | 2 | text:151 |
| created_at | TEXT |  |  | 151 | 151 | text:151 |
| loyalty_tier_colour | TEXT |  |  | 65 | 3 | null:86, text:65 |
| custom_json | TEXT |  |  | 28 | 28 | null:123, text:28 |

## promotion_skus (17 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| promo_id | TEXT | Y | Y | 17 | 5 | text:17 |
| sku | TEXT | Y | Y | 17 | 15 | text:17 |

## promotions (5 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| promo_id | TEXT |  | Y | 5 | 5 | text:5 |
| name | TEXT | Y |  | 5 | 5 | text:5 |
| promo_type | TEXT | Y |  | 5 | 4 | text:5 |
| pct_off | REAL |  |  | 2 | 2 | null:3, real:2 |
| amount_off | REAL |  |  | 1 | 1 | null:4, real:1 |
| buy_qty | INTEGER |  |  | 1 | 1 | integer:1, null:4 |
| bundle_price | REAL |  |  | 1 | 1 | null:4, real:1 |
| starts_at | TEXT |  |  | 5 | 5 | text:5 |
| ends_at | TEXT |  |  | 4 | 4 | null:1, text:4 |
| priority | INTEGER |  |  | 5 | 3 | integer:5 |
| stackable | INTEGER | Y |  | 5 | 2 | integer:5 |
| loyalty_only | INTEGER | Y |  | 5 | 2 | integer:5 |
| status | TEXT | Y |  | 5 | 2 | text:5 |
| currency | TEXT |  |  | 5 | 1 | text:5 |
| location_scope | TEXT |  |  | 5 | 2 | text:5 |
| banner_ref | TEXT |  |  | 3 | 3 | null:2, text:3 |

## purchase_order_lines (75 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| line_id | INTEGER |  | Y | 75 | 75 | integer:75 |
| po_number | TEXT | Y |  | 75 | 38 | text:75 |
| sku | TEXT | Y |  | 75 | 66 | text:75 |
| qty_ordered | REAL | Y |  | 75 | 42 | real:75 |
| qty_received | REAL | Y |  | 75 | 35 | real:75 |
| unit | TEXT |  |  | 75 | 1 | text:75 |
| unit_cost | REAL | Y |  | 75 | 53 | real:75 |

## purchase_orders (38 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| po_number | TEXT |  | Y | 38 | 38 | text:38 |
| supplier_id | TEXT |  |  | 38 | 14 | text:38 |
| location_code | TEXT | Y |  | 38 | 5 | text:38 |
| status | TEXT | Y |  | 38 | 6 | text:38 |
| currency | TEXT |  |  | 38 | 1 | text:38 |
| ordered_at | TEXT |  |  | 38 | 29 | text:38 |
| expected_on | TEXT |  |  | 38 | 1 | text:38 |
| closed_at | TEXT |  |  | 24 | 3 | null:14, text:24 |
| approved_by | TEXT |  |  | 35 | 1 | null:3, text:35 |
| notes | TEXT |  |  | 24 | 3 | null:14, text:24 |

## refunds (81 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| refund_id | INTEGER |  | Y | 81 | 81 | integer:81 |
| return_id | INTEGER |  |  | 81 | 81 | integer:81 |
| sale_id | INTEGER |  |  | 81 | 81 | integer:81 |
| amount | REAL | Y |  | 81 | 78 | real:81 |
| status | TEXT | Y |  | 81 | 2 | text:81 |
| refunded_at | TEXT |  |  | 81 | 81 | text:81 |

## returns (81 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| return_id | INTEGER |  | Y | 81 | 81 | integer:81 |
| sale_id | INTEGER |  |  | 81 | 81 | integer:81 |
| returned_at | TEXT |  |  | 81 | 81 | text:81 |
| reason | TEXT |  |  | 81 | 3 | text:81 |
| status | TEXT |  |  | 81 | 1 | text:81 |

## sale_lines (3679 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| line_id | INTEGER |  | Y | 3679 | 3679 | integer:3679 |
| sale_id | INTEGER | Y |  | 3679 | 1981 | integer:3679 |
| variant_id | INTEGER |  |  | 3679 | 416 | integer:3679 |
| qty | REAL | Y |  | 3679 | 211 | real:3679 |
| unit | TEXT |  |  | 2239 | 5 | null:1440, text:2239 |
| unit_price | REAL | Y |  | 3679 | 289 | real:3679 |
| discount | REAL | Y |  | 3679 | 211 | real:3679 |
| line_total | REAL | Y |  | 3679 | 1054 | real:3679 |

## sales (1982 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| sale_id | INTEGER |  | Y | 1982 | 1982 | integer:1982 |
| receipt_no | TEXT |  |  | 1982 | 1982 | text:1982 |
| store_code | TEXT |  |  | 1690 | 5 | null:292, text:1690 |
| channel | TEXT | Y |  | 1982 | 4 | text:1982 |
| customer_id | TEXT |  |  | 675 | 339 | null:1307, text:675 |
| sold_at | TEXT | Y |  | 1982 | 1952 | text:1982 |
| currency | TEXT |  |  | 1982 | 1 | text:1982 |
| status | TEXT | Y |  | 1982 | 3 | text:1982 |
| terminal_no | TEXT |  |  | 1690 | 6 | null:292, text:1690 |
| cashier_ref | TEXT |  |  | 1982 | 41 | text:1982 |
| total | REAL |  |  | 1982 | 1508 | real:1982 |
| discount_total | REAL |  |  | 1982 | 216 | real:1982 |

## stores (4 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| store_code | TEXT |  | Y | 4 | 4 | text:4 |
| name | TEXT | Y |  | 4 | 4 | text:4 |
| region | TEXT |  |  | 4 | 3 | text:4 |
| currency | TEXT | Y |  | 4 | 1 | text:4 |
| opened_on | TEXT |  |  | 4 | 4 | text:4 |
| floor_area_sqm | REAL |  |  | 4 | 4 | real:4 |
| status | TEXT |  |  | 4 | 1 | text:4 |

## suppliers (14 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| supplier_id | TEXT |  | Y | 14 | 14 | text:14 |
| name | TEXT | Y |  | 14 | 14 | text:14 |
| payment_terms | TEXT |  |  | 14 | 4 | text:14 |
| currency | TEXT |  |  | 14 | 1 | text:14 |
| credit_rating | TEXT |  |  | 14 | 4 | text:14 |
| active | INTEGER | Y |  | 14 | 2 | integer:14 |

## system_state (1 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| id | INTEGER |  | Y | 1 | 1 | integer:1 |
| system_name | TEXT | Y |  | 1 | 1 | text:1 |
| authoritative_system | TEXT | Y |  | 1 | 1 | text:1 |
| frozen | INTEGER | Y |  | 1 | 1 | integer:1 |
| freeze_marker | TEXT |  |  | 0 | 0 | null:1 |
| frozen_at | TEXT |  |  | 0 | 0 | null:1 |
| archived | INTEGER | Y |  | 1 | 1 | integer:1 |
| data_as_of | TEXT |  |  | 1 | 1 | text:1 |
| note | TEXT |  |  | 1 | 1 | text:1 |

## warehouses (2 rows)

| column | type | not null | pk | with value | distinct | storage types |
|---|---|:-:|:-:|---:|---:|---|
| wh_code | TEXT |  | Y | 2 | 2 | text:2 |
| name | TEXT | Y |  | 2 | 2 | text:2 |
| region | TEXT |  |  | 2 | 1 | text:2 |
| currency | TEXT | Y |  | 2 | 1 | text:2 |
| status | TEXT |  |  | 2 | 1 | text:2 |
