"""Source schema inventory: tables, columns, types, row counts, primary/foreign keys and a value profile.

    python -m aureom_migration inventory --source migration/source/retail_source.sqlite --out migration/work/inventory

The profile (``typeof`` histogram, null/empty counts, distinct counts) is what exposes money stored as REAL, mixed-type
columns and timestamp columns holding several formats - it is the input to the mapping decisions and to the
unsupported-field report (rows with a value in a column the chain has no field for).
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .util import sha256_file, write_json, atomic_write


def _q(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def connect_ro(path: str | Path) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{Path(path).resolve()}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    return con


def inventory(source: str | Path, *, profile: bool = True) -> dict[str, Any]:
    con = connect_ro(source)
    try:
        tables = [r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        out: dict[str, Any] = {"source": str(source), "sha256": sha256_file(source), "tables": {}}
        for t in tables:
            cols = con.execute(f"PRAGMA table_info({_q(t)})").fetchall()
            fks = con.execute(f"PRAGMA foreign_key_list({_q(t)})").fetchall()
            n = con.execute(f"SELECT count(*) FROM {_q(t)}").fetchone()[0]
            pk = [c["name"] for c in sorted((c for c in cols if c["pk"]), key=lambda c: c["pk"])]
            info = {
                "row_count": n, "primary_key": pk,
                "foreign_keys": [{"column": f["from"], "references": f"{f['table']}.{f['to']}"} for f in fks],
                "columns": [],
            }
            for c in cols:
                col = {"name": c["name"], "type": c["type"], "not_null": bool(c["notnull"]), "pk": bool(c["pk"]), "default": c["dflt_value"]}
                if profile and n:
                    cn = _q(c["name"])
                    col["null_or_empty"] = con.execute(f"SELECT count(*) FROM {_q(t)} WHERE {cn} IS NULL OR trim(cast({cn} AS TEXT)) = ''").fetchone()[0]
                    col["with_value"] = n - col["null_or_empty"]
                    col["storage_types"] = {r[0]: r[1] for r in con.execute(f"SELECT typeof({cn}), count(*) FROM {_q(t)} GROUP BY 1 ORDER BY 1")}
                    col["distinct"] = con.execute(f"SELECT count(DISTINCT {cn}) FROM {_q(t)}").fetchone()[0]
                info["columns"].append(col)
            out["tables"][t] = info
        return out
    finally:
        con.close()


def to_markdown(inv: dict[str, Any]) -> str:
    lines = [f"# Source schema inventory", "", f"* source: `{inv['source']}`", f"* sha256: `{inv['sha256']}`", ""]
    lines += ["| table | rows | primary key | foreign keys |", "|---|---:|---|---|"]
    for t, i in inv["tables"].items():
        fks = ", ".join(f"{f['column']} -> {f['references']}" for f in i["foreign_keys"]) or ""
        lines.append(f"| {t} | {i['row_count']} | {', '.join(i['primary_key'])} | {fks} |")
    for t, i in inv["tables"].items():
        lines += ["", f"## {t} ({i['row_count']} rows)", "", "| column | type | not null | pk | with value | distinct | storage types |", "|---|---|:-:|:-:|---:|---:|---|"]
        for c in i["columns"]:
            st = ", ".join(f"{k}:{v}" for k, v in (c.get("storage_types") or {}).items())
            lines.append(f"| {c['name']} | {c['type']} | {'Y' if c['not_null'] else ''} | {'Y' if c['pk'] else ''} | {c.get('with_value', '')} | {c.get('distinct', '')} | {st} |")
    lines.append("")
    return "\n".join(lines)


def write_inventory(source: str | Path, out_dir: str | Path) -> dict[str, Any]:
    inv = inventory(source)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "schema_inventory.json", inv)
    atomic_write(out / "schema_inventory.md", to_markdown(inv))
    return inv
