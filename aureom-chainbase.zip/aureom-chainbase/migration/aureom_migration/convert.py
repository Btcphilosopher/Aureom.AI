"""Pure value conversions: money, quantities, timestamps, ids and text.

Rules (all documented in docs/MIGRATION.md and mapping/map-v1.yaml):

* Money: source floats are converted to INTEGER minor units exactly once, here.  A float is read through its
  shortest round-trip decimal representation (``Decimal(repr(x))``) and rounded HALF-EVEN to the currency exponent.
  After this function no float arithmetic touches money.  A value that is only off by float representation noise
  (<= 1e-6 of a minor unit, e.g. 12.349999999999998 pounds) is *benign* and silent; a value that genuinely carries
  sub-minor-unit precision (4.995 pounds) is reported as FLOAT_PRECISION.
* Quantities: integer count of the unit's smallest step (EA/PK whole units, KG grams, L millilitres, M millimetres),
  rounded half-even.  Fractional EA/PK quantities cannot be represented and are flagged to the caller.
* Timestamps: every accepted format is normalised to UTC epoch milliseconds.  Timestamps without an explicit offset are
  interpreted in the source system's local zone (Europe/London) and flagged when they fall in a DST fold or gap.
* Ids: chain ids match ^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_EVEN, Decimal, InvalidOperation, localcontext
from zoneinfo import ZoneInfo

CURRENCY_EXP = {"GBP": 2, "USD": 2, "EUR": 2, "JPY": 0}
UNIT_SCALE = {"EA": 0, "PK": 0, "KG": 3, "L": 3, "M": 3}
WHOLE_UNITS = ("EA", "PK")
MAX_MINOR = 1_000_000_000_000  # chain: 10^12 minor units
MAX_QTY = 1_000_000_000  # chain: Qty.V <= 10^9
ARTIFACT_TOLERANCE = Decimal("0.000001")  # fraction of ONE minor unit that counts as float noise

CHAIN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")
CHAIN_CUSTOMER_RE = re.compile(r"^(CUST|PSN)-[A-Za-z0-9]{4,40}$")
CHAIN_LABEL_RE = re.compile(r"^[\x20-\x7e]{0,200}$")


class ConversionError(ValueError):
    """A value cannot be converted; ``kind`` is the exception kind the caller should report."""

    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind


# ------------------------------------------------------------------ integers / rounding


def div_half_even(num: int, den: int) -> int:
    """round_half_even(num/den) for integers, den > 0 (matches the chain's divHalfEven)."""
    if den <= 0:
        raise ValueError("denominator must be positive")
    q, r = divmod(abs(num), den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 == 1):
        q += 1
    return q if num >= 0 else -q


def line_amount(unit_minor: int, qty_v: int, unit: str) -> int:
    """unit price (per WHOLE unit) x quantity (smallest steps) / 10^scale, half-even - same as core.lineAmount."""
    return div_half_even(unit_minor * qty_v, 10 ** UNIT_SCALE[unit])


def _to_decimal(value) -> Decimal:
    if value is None or isinstance(value, bool):
        raise ConversionError("INVALID_AMOUNT", f"not a number: {value!r}")
    if isinstance(value, Decimal):
        d = value
    elif isinstance(value, int):
        d = Decimal(value)
    elif isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ConversionError("INVALID_AMOUNT", f"non-finite number: {value!r}")
        d = Decimal(repr(value))
    elif isinstance(value, str):
        s = value.strip().replace("£", "").replace("$", "").replace("€", "").strip()
        if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", s):
            s = s.replace(",", "")
        try:
            d = Decimal(s)
        except InvalidOperation:
            raise ConversionError("INVALID_AMOUNT", f"not a number: {value!r}") from None
        if not d.is_finite():
            raise ConversionError("INVALID_AMOUNT", f"non-finite number: {value!r}")
    else:
        raise ConversionError("INVALID_AMOUNT", f"unsupported type {type(value).__name__}")
    return d


@dataclass(frozen=True)
class Scaled:
    """Result of converting a decimal to an integer count of some step."""

    value: int
    rounded: bool  # the value was not exactly representable
    artifact: bool  # ...but only by binary-float noise (<= 1e-6 of a step)

    @property
    def genuine_rounding(self) -> bool:
        return self.rounded and not self.artifact


def _scale(d: Decimal, exp: int) -> Scaled:
    with localcontext() as ctx:
        ctx.prec = 80
        scaled = d.scaleb(exp)
        q = scaled.quantize(Decimal(1), rounding=ROUND_HALF_EVEN)
        diff = abs(scaled - q)
    return Scaled(int(q), diff != 0, diff != 0 and diff <= ARTIFACT_TOLERANCE)


def to_minor(value, ccy: str = "GBP", *, allow_negative: bool = False) -> Scaled:
    """Money (float/int/str/Decimal major units) -> integer minor units, half-even."""
    if ccy not in CURRENCY_EXP:
        raise ConversionError("INVALID_CURRENCY", f"unknown currency {ccy!r}")
    s = _scale(_to_decimal(value), CURRENCY_EXP[ccy])
    if (s.value < 0 and not allow_negative) or abs(s.value) > MAX_MINOR:
        raise ConversionError("INVALID_AMOUNT", f"amount out of range: {value!r}")
    return s


@dataclass(frozen=True)
class QtyConv:
    v: int
    unit: str
    rounded: bool
    artifact: bool
    fractional_whole_unit: bool  # EA/PK quantity with a real fractional part

    @property
    def genuine_rounding(self) -> bool:
        return self.rounded and not self.artifact


def to_qty(value, unit: str, *, allow_negative: bool = False) -> QtyConv:
    """Quantity in the unit's natural step (units, kg, l, m) -> integer smallest steps (units, g, ml, mm)."""
    if unit not in UNIT_SCALE:
        raise ConversionError("UNKNOWN_UNIT", f"unknown unit {unit!r}")
    try:
        d = _to_decimal(value)
    except ConversionError as e:
        raise ConversionError("INVALID_QUANTITY", str(e)) from None
    s = _scale(d, UNIT_SCALE[unit])
    if (s.value < 0 and not allow_negative) or abs(s.value) > MAX_QTY:
        raise ConversionError("INVALID_QUANTITY", f"quantity out of range: {value!r}")
    frac = unit in WHOLE_UNITS and s.genuine_rounding
    return QtyConv(s.value, unit, s.rounded, s.artifact, frac)


_UNIT_SYNONYMS = {
    "EA": "EA", "EACH": "EA", "PC": "EA", "PCS": "EA", "PIECE": "EA", "PIECES": "EA", "UNIT": "EA", "UNITS": "EA", "ITEM": "EA",
    "PK": "PK", "PACK": "PK", "PKT": "PK", "PACKET": "PK", "BOX": "PK",
    "KG": "KG", "KGS": "KG", "KILO": "KG", "KILOS": "KG", "KILOGRAM": "KG", "KILOGRAMS": "KG",
    "L": "L", "LTR": "L", "LTRS": "L", "LITRE": "L", "LITRES": "L", "LITER": "L", "LITERS": "L",
    "M": "M", "MTR": "M", "MTRS": "M", "METRE": "M", "METRES": "M", "METER": "M", "METERS": "M",
}


def normalise_unit(raw) -> str | None:
    """Legacy unit code -> chain unit (EA PK KG L M); None when empty; raises on an unknown code."""
    if raw is None or str(raw).strip() == "":
        return None
    u = _UNIT_SYNONYMS.get(str(raw).strip().upper())
    if u is None:
        raise ConversionError("UNKNOWN_UNIT", f"unknown unit code {raw!r}")
    return u


# ------------------------------------------------------------------ timestamps

LONDON = ZoneInfo("Europe/London")
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
_MIN_MS = int(datetime(2000, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
_MAX_MS = int(datetime(2100, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)

_ISO_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,6}))?)?)?\s*(Z|[+-]\d{2}:?\d{2})?$"
)
_UK_RE = re.compile(r"^(\d{1,2})/(\d{1,2})/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$")
_EPOCH_RE = re.compile(r"^(\d{10}|\d{13})(?:\.0+)?$")


@dataclass(frozen=True)
class TimeConv:
    ms: int  # UTC epoch milliseconds
    fmt: str  # iso-offset | iso-naive | date-only | uk-slash | epoch-s | epoch-ms
    tz_assumed: bool  # no explicit offset: source-local zone assumed
    dst_ambiguous: bool  # wall-clock time occurs twice (autumn fold); the first occurrence is used
    dst_gap: bool  # wall-clock time does not exist (spring gap); interpreted with the pre-transition offset


def _to_ms(dt_utc: datetime) -> int:
    return (dt_utc - _EPOCH) // timedelta(milliseconds=1)


def normalise_timestamp(raw, tz: ZoneInfo = LONDON) -> TimeConv:
    """Any supported legacy timestamp -> UTC epoch ms.  Raises ConversionError('INVALID_TIMESTAMP')."""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        raise ConversionError("INVALID_TIMESTAMP", "empty timestamp")
    if isinstance(raw, bool):
        raise ConversionError("INVALID_TIMESTAMP", f"not a timestamp: {raw!r}")
    if isinstance(raw, (int, float)):
        raw = str(int(raw)) if float(raw).is_integer() else str(raw)
    s = str(raw).strip()
    m = _EPOCH_RE.match(s)
    if m:
        digits = m.group(1)
        ms = int(digits) * 1000 if len(digits) == 10 else int(digits)
        fmt = "epoch-s" if len(digits) == 10 else "epoch-ms"
        return _bounded(TimeConv(ms, fmt, False, False, False), raw)
    m = _ISO_RE.match(s)
    if m:
        y, mo, d, hh, mi, ss, frac, off = m.groups()
        has_time = hh is not None
        try:
            micro = int((frac or "0").ljust(6, "0")) if frac else 0
            naive = datetime(int(y), int(mo), int(d), int(hh or 0), int(mi or 0), int(ss or 0), micro)
        except ValueError as e:
            raise ConversionError("INVALID_TIMESTAMP", f"{raw!r}: {e}") from None
        if off:
            sign = 1 if off[0] == "+" else -1
            if off == "Z":
                delta = timedelta(0)
            else:
                digits = off[1:].replace(":", "")
                delta = sign * timedelta(hours=int(digits[:2]), minutes=int(digits[2:]))
            aware = naive.replace(tzinfo=timezone(delta))
            return _bounded(TimeConv(_to_ms(aware.astimezone(timezone.utc)), "iso-offset", False, False, False), raw)
        return _bounded(_local(naive, tz, "iso-naive" if has_time else "date-only"), raw)
    m = _UK_RE.match(s)
    if m:
        dd, mo, y, hh, mi, ss = m.groups()
        try:
            naive = datetime(int(y), int(mo), int(dd), int(hh or 0), int(mi or 0), int(ss or 0))
        except ValueError as e:
            raise ConversionError("INVALID_TIMESTAMP", f"{raw!r} (read as DD/MM/YYYY): {e}") from None
        return _bounded(_local(naive, tz, "uk-slash"), raw)
    raise ConversionError("INVALID_TIMESTAMP", f"unrecognised timestamp format: {raw!r}")


def _local(naive: datetime, tz: ZoneInfo, fmt: str) -> TimeConv:
    a = naive.replace(tzinfo=tz, fold=0)
    b = naive.replace(tzinfo=tz, fold=1)
    offsets_differ = a.utcoffset() != b.utcoffset()
    # a wall time that does not survive UTC -> local round trip does not exist (spring-forward gap); one that does but has two
    # valid offsets occurs twice (autumn fold)
    survives = a.astimezone(timezone.utc).astimezone(tz).replace(tzinfo=None) == naive
    ambiguous = offsets_differ and survives
    gap = offsets_differ and not survives
    return TimeConv(_to_ms(a.astimezone(timezone.utc)), fmt, True, ambiguous, gap)


def _bounded(t: TimeConv, raw) -> TimeConv:
    if not (_MIN_MS <= t.ms < _MAX_MS):
        raise ConversionError("INVALID_TIMESTAMP", f"{raw!r} is outside 2000-2100")
    return t


def iso_utc(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


# ------------------------------------------------------------------ text / ids

_ASCII_MAP = {
    "£": "GBP ", "€": "EUR ", "¥": "JPY ", "–": "-", "—": "-", "‘": "'", "’": "'",
    "“": '"', "”": '"', "…": "...", "×": "x", "ß": "ss", "æ": "ae", "Æ": "AE",
    "ø": "o", "Ø": "O", "œ": "oe", "Œ": "OE", "°": " deg", "™": "", "®": "", "©": "",
    " ": " ", "Ð": "D", "ð": "d", "Þ": "TH", "þ": "th", "Ł": "L", "ł": "l",
}


def ascii_label(raw, max_len: int, *, default: str = "") -> tuple[str, bool]:
    """Printable-ASCII label as required by the chain's label rule.  Returns (text, changed).

    Accents are stripped (NFKD), known symbols transliterated, anything else non-printable becomes '?'.  The caller keeps the
    original text in source_extras whenever ``changed`` is True so nothing is lost."""
    if raw is None:
        return default, False
    s = str(raw)
    t = "".join(_ASCII_MAP.get(c, c) for c in s)
    t = unicodedata.normalize("NFKD", t)
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = "".join(c if 0x20 <= ord(c) <= 0x7E else ("?" if not c.isspace() else " ") for c in t)
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > max_len:
        t = t[:max_len].rstrip()
    return (t or default), (t != s)


def sanitize_id(raw, *, upper: bool = False) -> str:
    """Source code -> chain id (^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$).  Returns '' when nothing usable remains."""
    if raw is None:
        return ""
    s = unicodedata.normalize("NFKD", str(raw))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^A-Za-z0-9._:-]+", "-", s.strip())
    s = re.sub(r"^[^A-Za-z0-9]+", "", s)
    s = s[:64].rstrip("-")
    s = s.upper() if upper else s
    return s if CHAIN_ID_RE.match(s) else ""


def map_customer_id(raw, salt: str = "aureom-mig-v1") -> tuple[str, str]:
    """Source customer id -> synthetic chain customer id.  Returns (chain_id, how) with how in
    as-is | zero-padded | pseudonymised.  The chain accepts only ^(CUST|PSN)-[A-Za-z0-9]{4,40}$."""
    if raw is None or not str(raw).strip():
        raise ConversionError("INVALID_ID", "empty customer id")
    s = str(raw).strip()
    if CHAIN_CUSTOMER_RE.match(s):
        return s, "as-is"
    m = re.fullmatch(r"(?i)(?:cust|c)[-_ ]?(\d{1,12})", s)
    if m:
        return f"CUST-{int(m.group(1)):06d}", "zero-padded"
    h = hashlib.sha256(f"{salt}|{s}".encode()).hexdigest()[:16].upper()
    return f"PSN-{h}", "pseudonymised"
