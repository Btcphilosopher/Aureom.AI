"""Deterministic ImportBatch construction.

* Records are batched in source-id order (the plan sorts them) - the same plan always yields the same batches.
* ``batch_id = "B-" + sha256(snapshot_id | mapping_version | entity | seq)[:40]`` - re-running a migration (or resuming it after
  a crash) therefore produces identical batch ids, and the chain's ``mig/batch/<id>`` record tells us what is already imported.
* Size limits: at most ``Params.MaxImportRecords`` (400) records per batch and an ENVELOPE below the chain's
  ``MaxImportTxBytes`` (900 KiB).  The envelope size is estimated from the actual JSON, so splitting is deterministic too.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from .util import MigrationError, canonical_json, sha256_hex

CHAIN_MAX_RECORDS = 400
CHAIN_MAX_IMPORT_TX_BYTES = 900 * 1024
TX_FIXED_BYTES = 420  # tx body fields besides the payload (tx_id, signer, idempotency_ref ...), generous
ENVELOPE_OVERHEAD = 220  # {"v":1,"body":"...","sig":"...","pub":"..."} without the body itself


def batch_id(snapshot_id: str, mapping_version: str, entity: str, seq: int) -> str:
    return "B-" + sha256_hex(f"{snapshot_id}|{mapping_version}|{entity}|{seq}")[:40]


def _json_len(obj: Any) -> int:
    import json

    return len(json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))


def estimate_envelope_bytes(payload_bytes: int) -> int:
    return math.ceil((payload_bytes + TX_FIXED_BYTES) / 3) * 4 + ENVELOPE_OVERHEAD


@dataclass
class Batch:
    batch_id: str
    entity: str
    seq: int
    snapshot_id: str
    mapping_version: str
    source_system: str
    records: list[dict]
    phase: str = ""
    content_sha256: str = ""

    def payload(self) -> dict[str, Any]:
        """The ImportBatch payload (core.ImportBatchP)."""
        return {"batch_id": self.batch_id, "source_system": self.source_system, "snapshot_id": self.snapshot_id,
                "mapping_version": self.mapping_version, "entity": self.entity, "seq": self.seq, "records": self.records}

    def descriptor(self) -> dict[str, Any]:
        return {"batch_id": self.batch_id, "entity": self.entity, "seq": self.seq, "records": len(self.records),
                "snapshot_id": self.snapshot_id, "content_sha256": self.content_sha256, "phase": self.phase}


def make_batches(entity: str, records: list[dict], *, snapshot_id: str, mapping_version: str, source_system: str,
                 max_records: int = CHAIN_MAX_RECORDS, max_envelope_bytes: int = 600 * 1024, phase: str = "") -> list[Batch]:
    if not 1 <= max_records <= CHAIN_MAX_RECORDS:
        raise MigrationError(f"max_records must be 1..{CHAIN_MAX_RECORDS} (chain Params.MaxImportRecords)")
    if max_envelope_bytes > CHAIN_MAX_IMPORT_TX_BYTES:
        raise MigrationError(f"max_envelope_bytes must be <= {CHAIN_MAX_IMPORT_TX_BYTES} (chain Params.MaxImportTxBytes)")
    base = {"batch_id": "B-" + "0" * 40, "source_system": source_system, "snapshot_id": snapshot_id, "mapping_version": mapping_version,
            "entity": entity, "seq": 100000, "records": []}
    overhead = _json_len(base)
    batches: list[Batch] = []
    cur: list[dict] = []
    cur_bytes = overhead

    def flush() -> None:
        nonlocal cur, cur_bytes
        if not cur:
            return
        seq = len(batches) + 1
        b = Batch(batch_id(snapshot_id, mapping_version, entity, seq), entity, seq, snapshot_id, mapping_version, source_system, cur, phase)
        b.content_sha256 = sha256_hex(canonical_json(cur))
        batches.append(b)
        cur, cur_bytes = [], overhead

    for r in records:
        rb = _json_len(r) + 1
        if estimate_envelope_bytes(overhead + rb) > max_envelope_bytes:
            raise MigrationError(f"a single {entity} record ({r.get('source_id')}) is {rb} bytes: larger than the batch envelope limit {max_envelope_bytes}")
        if cur and (len(cur) >= max_records or estimate_envelope_bytes(cur_bytes + rb) > max_envelope_bytes):
            flush()
        cur.append(r)
        cur_bytes += rb
    flush()
    return batches


def manifest(batches: list[Batch]) -> list[dict[str, Any]]:
    return [b.descriptor() for b in batches]


def manifest_hash(batches: list[Batch]) -> str:
    return sha256_hex(canonical_json(manifest(batches)))
