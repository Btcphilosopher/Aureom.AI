"""Start/stop a throwaway local network with scripts/localnet.sh (used by the trial migration and the integration test).

The trial network gets its OWN run directory, network id and ports (e.g. RUN_DIR=run-trial NETWORK_ID=aureom-trial-1 BASE_PORT=28700
GATEWAY_ADDR=127.0.0.1:8092), so it cannot touch the production network."""

from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

import requests

from .util import MigrationError


@dataclass
class LocalNet:
    root: Path  # repository root (contains scripts/localnet.sh)
    run_dir: Path
    network_id: str
    base_port: int
    gateway_addr: str
    block_time: str = "1s"

    @property
    def gateway_url(self) -> str:
        return f"http://{self.gateway_addr}"

    @property
    def keys_dir(self) -> Path:
        return self.run_dir / "net" / "keys"

    def _run(self, *args: str, timeout: int = 180) -> str:
        env = dict(os.environ, RUN_DIR=str(self.run_dir), NETWORK_ID=self.network_id, BASE_PORT=str(self.base_port), GATEWAY_ADDR=self.gateway_addr, BLOCK_TIME=self.block_time)
        r = subprocess.run([str(self.root / "scripts" / "localnet.sh"), *args], env=env, capture_output=True, text=True, timeout=timeout, cwd=str(self.root))
        if r.returncode != 0:
            raise MigrationError(f"localnet.sh {' '.join(args)} failed ({r.returncode}): {r.stdout[-500:]} {r.stderr[-500:]}")
        return r.stdout

    def start(self, wait_s: float = 60.0) -> None:
        self._run("start")
        self._run("gateway", "start")
        deadline = time.time() + wait_s
        while time.time() < deadline:
            try:
                if requests.get(self.gateway_url + "/api/v1/network", timeout=3).ok:
                    return
            except requests.RequestException:
                pass
            time.sleep(0.5)
        raise MigrationError(f"gateway at {self.gateway_url} did not come up")

    def stop(self) -> None:
        try:
            self._run("stop", timeout=60)
        except MigrationError:
            pass

    def __enter__(self) -> "LocalNet":
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.stop()
