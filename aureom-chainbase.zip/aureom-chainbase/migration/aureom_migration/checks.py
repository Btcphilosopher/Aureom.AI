"""Exceptions, dispositions and the schema gate.

Every deviation between the source and what can be put on chain is an *exception* with a disposition:

  EXCLUDED              the record (or value) is not migrated; no further action required
  FIXED                 migrated after a deterministic, documented correction (rounding, id rewrite, transliteration ...)
  PRESERVED_AS_EXTRAS   migrated, and the problematic/unsupported source value is kept verbatim in source_extras
  MANUAL                NOT migrated and needs a human decision; unresolved MANUAL items block the final acceptance until
                        an operator acknowledges them (``cutover --ack-manual``) and are listed in every report

Nothing is silently dropped: the plan builder (plan.py) records an exception for every source record it does not migrate,
and the schema gate fails when a source column has no declared treatment (mapping/map-v1.yaml).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from .mapping import TREATMENT_TEXT, Spec
from .util import sha256_hex

EXCLUDED, FIXED, PRESERVED, MANUAL = "EXCLUDED", "FIXED", "PRESERVED_AS_EXTRAS", "MANUAL"
DISPOSITIONS = (EXCLUDED, FIXED, PRESERVED, MANUAL)


@dataclass(frozen=True)
class Exc:
    kind: str
    source_ref: str  # "table:pk" of the source record whose migration is affected (or "table.column" for column-level findings)
    detail: str
    disposition: str
    entity: str = ""  # chain entity affected (PRODUCT, SKU, HISTORICAL_SALE ...)

    @property
    def id(self) -> str:
        return sha256_hex(f"{self.kind}|{self.source_ref}|{self.detail}")[:16]

    def to_report(self) -> dict[str, str]:
        return {"kind": self.kind, "source_ref": self.source_ref, "detail": self.detail, "disposition": self.disposition, "entity": self.entity, "id": self.id}


class ExceptionLog:
    def __init__(self) -> None:
        self.items: list[Exc] = []
        self.excluded: dict[str, set[str]] = defaultdict(set)  # entity -> source refs that were NOT migrated
        self.out_of_scope: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))  # entity -> reason -> count
        self._seen: set[tuple[str, str, str]] = set()

    def add(self, kind: str, ref: str, detail: str, disposition: str, entity: str = "") -> Exc:
        assert disposition in DISPOSITIONS, disposition
        e = Exc(kind, ref, detail, disposition, entity)
        key = (kind, ref, detail)
        if key not in self._seen:  # one finding per (kind, ref, detail)
            self._seen.add(key)
            self.items.append(e)
        return e

    def exclude(self, entity: str, ref: str) -> None:
        self.excluded[entity].add(ref)

    def skip_scope(self, entity: str, reason: str, n: int = 1) -> None:
        self.out_of_scope[entity][reason] += n

    # ---- queries
    def by_kind(self) -> dict[str, int]:
        c: dict[str, int] = defaultdict(int)
        for e in self.items:
            c[e.kind] += 1
        return dict(sorted(c.items()))

    def manual(self) -> list[Exc]:
        return [e for e in self.items if e.disposition == MANUAL]

    def refs(self, kind: str | None = None, disposition: str | None = None) -> set[tuple[str, str]]:
        return {(e.kind, e.source_ref) for e in self.items if (kind is None or e.kind == kind) and (disposition is None or e.disposition == disposition)}

    def sorted(self) -> list[Exc]:
        return sorted(self.items, key=lambda e: (e.kind, e.source_ref, e.detail))


# ------------------------------------------------------------------ schema gate


@dataclass
class GateResult:
    ok: bool
    exceptions: list[Exc] = field(default_factory=list)
    unsupported_fields: list[dict[str, Any]] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)


def schema_gate(spec: Spec, inv: dict[str, Any]) -> GateResult:
    """Compare the LIVE source schema with the mapping spec.

    * a source table/column with no declared treatment  -> UNMAPPED_TABLE / UNMAPPED_COLUMN (gate FAILS: a column must never vanish silently)
    * a spec column that no longer exists in the source  -> MAPPED_COLUMN_MISSING (gate FAILS for mapped/extras columns: schema drift)
    * every extras/dropped/folded column becomes an entry of unsupported_fields[] with the number of rows carrying a value
    """
    exc: list[Exc] = []
    ok = True
    src_tables = inv["tables"]
    for t, info in src_tables.items():
        spec_cols = spec.tables.get(t)
        if spec_cols is None:
            exc.append(Exc("UNMAPPED_TABLE", t, f"source table {t} ({info['row_count']} rows) has no entry in mapping {spec.version}", MANUAL))
            ok = False
            continue
        for c in info["columns"]:
            if c["name"] not in spec_cols:
                exc.append(Exc("UNMAPPED_COLUMN", f"{t}.{c['name']}", f"source column {t}.{c['name']} ({c['type']}) has no declared treatment in mapping {spec.version}", MANUAL))
                ok = False
    for t, cols in spec.tables.items():
        if t not in src_tables:
            exc.append(Exc("MAPPED_TABLE_MISSING", t, f"mapping {spec.version} declares table {t} which is not in the source", MANUAL))
            ok = False
            continue
        have = {c["name"] for c in src_tables[t]["columns"]}
        for c, tr in cols.items():
            if c not in have:
                exc.append(Exc("MAPPED_COLUMN_MISSING", f"{t}.{c}", f"mapping declares {t}.{c} ({tr['treatment']}) but the source no longer has it (schema drift)", MANUAL))
                ok = False
    unsupported: list[dict[str, Any]] = []
    for t, c, tr in spec.unsupported_columns():
        if t not in src_tables:
            continue
        col = next((x for x in src_tables[t]["columns"] if x["name"] == c), None)
        if col is None:
            continue
        rows = int(col.get("with_value", 0))
        text = TREATMENT_TEXT[tr["treatment"]]
        entry: dict[str, Any] = {"table": t, "column": c, "rows": rows, "treatment": text}
        if tr["treatment"] == "extras":
            entry["detail"] = f"copied verbatim into source_extras['{tr['key']}']"
            disp = PRESERVED
        elif tr["treatment"] == "dropped":
            ap = spec.raw["approvals"][tr["approval"]]
            entry["detail"] = f"approval {tr['approval']} ({ap.get('by', '')}, {ap.get('date', '')})"
            entry["approval"] = tr["approval"]
            disp = EXCLUDED
        else:
            entry["detail"] = tr.get("note", "")
            disp = FIXED
        unsupported.append(entry)
        if rows:
            exc.append(Exc("UNSUPPORTED_FIELD", f"{t}.{c}", f"{rows} row(s) carry a value; {text}; {entry['detail']}", disp))
    return GateResult(ok, exc, unsupported, {"tables": len(src_tables), "unmapped": sum(1 for e in exc if e.kind.startswith("UNMAPPED"))})
