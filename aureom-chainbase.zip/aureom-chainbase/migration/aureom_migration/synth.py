"""Deterministic generator for a SYNTHETIC conventional relational retail database (SQLite).

    python -m aureom_migration.synth --seed 42 --out migration/source/retail_source.sqlite
    python -m aureom_migration.synth activity --db migration/source/retail_source.sqlite --seed 7   # simulate live writes

Everything here is fictional.  Customer ids are synthetic (CUST-000123); there is no personal data.  The database is built
like a typical legacy ERP: integer surrogate keys, text codes, money stored as FLOATs, timestamps in several formats and
time zones, columns the chain has no field for, and - on purpose - data-quality problems the migration tooling must catch.
Every planted problem is recorded in ``<out>.planted.json`` (kind, source_ref, expected disposition) so tests can prove the
checks catch each one.  The same seed always produces the same database content.
"""

from __future__ import annotations

import argparse
import json
import random
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .convert import LONDON

SOURCE_SYSTEM = "legacy-retail-erp"
AS_OF = datetime(2026, 11, 1, tzinfo=timezone.utc)
HISTORY_START = datetime(2025, 1, 1, tzinfo=timezone.utc)

DDL = """
CREATE TABLE system_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  system_name TEXT NOT NULL,
  authoritative_system TEXT NOT NULL,      -- SOURCE | NONE_FROZEN | CHAIN
  frozen INTEGER NOT NULL DEFAULT 0,
  freeze_marker TEXT,
  frozen_at TEXT,
  archived INTEGER NOT NULL DEFAULT 0,
  data_as_of TEXT,
  note TEXT
);
CREATE TABLE change_log (
  change_id INTEGER PRIMARY KEY AUTOINCREMENT,
  table_name TEXT NOT NULL,
  pk TEXT NOT NULL,
  op TEXT NOT NULL,                        -- I | U | D
  changed_at TEXT
);
CREATE TABLE categories (
  category_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  parent_id INTEGER REFERENCES categories(category_id)
);
CREATE TABLE suppliers (
  supplier_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  payment_terms TEXT,
  currency TEXT,
  credit_rating TEXT,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE stores (
  store_code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  region TEXT,
  currency TEXT NOT NULL DEFAULT 'GBP',
  opened_on TEXT,
  floor_area_sqm REAL,
  status TEXT
);
CREATE TABLE warehouses (
  wh_code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  region TEXT,
  currency TEXT NOT NULL DEFAULT 'GBP',
  status TEXT
);
CREATE TABLE products (
  product_id INTEGER PRIMARY KEY,
  product_code TEXT NOT NULL,
  name TEXT NOT NULL,
  brand TEXT,
  category_id INTEGER REFERENCES categories(category_id),
  supplier_id TEXT REFERENCES suppliers(supplier_id),
  status TEXT NOT NULL,
  created_at TEXT,
  loyalty_tier_colour TEXT,
  custom_json TEXT
);
CREATE TABLE product_variants (
  variant_id INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(product_id),
  sku TEXT NOT NULL,
  barcode TEXT,
  unit TEXT NOT NULL,
  uom TEXT,
  scarce INTEGER NOT NULL DEFAULT 0,
  colour TEXT,
  size TEXT,
  weight_g REAL,
  status TEXT,
  custom_json TEXT
);
CREATE TABLE inventory_balances (
  inv_id INTEGER PRIMARY KEY,
  sku TEXT NOT NULL,
  location_code TEXT NOT NULL,
  unit TEXT,
  on_hand REAL NOT NULL,
  reserved REAL NOT NULL DEFAULT 0,
  damaged REAL NOT NULL DEFAULT 0,
  bin_location TEXT,
  counted_at TEXT
);
CREATE TABLE purchase_orders (
  po_number TEXT PRIMARY KEY,
  supplier_id TEXT REFERENCES suppliers(supplier_id),
  location_code TEXT NOT NULL,
  status TEXT NOT NULL,
  currency TEXT,
  ordered_at TEXT,
  expected_on TEXT,
  closed_at TEXT,
  approved_by TEXT,
  notes TEXT
);
CREATE TABLE purchase_order_lines (
  line_id INTEGER PRIMARY KEY,
  po_number TEXT NOT NULL REFERENCES purchase_orders(po_number),
  sku TEXT NOT NULL,
  qty_ordered REAL NOT NULL,
  qty_received REAL NOT NULL DEFAULT 0,
  unit TEXT,
  unit_cost REAL NOT NULL
);
CREATE TABLE price_lists (
  list_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  currency TEXT NOT NULL,
  location_code TEXT                       -- NULL = chain wide
);
CREATE TABLE price_list_items (
  item_id INTEGER PRIMARY KEY,
  list_id INTEGER NOT NULL REFERENCES price_lists(list_id),
  sku TEXT NOT NULL,
  price REAL NOT NULL,
  valid_from TEXT NOT NULL,
  valid_to TEXT,
  notes TEXT
);
CREATE TABLE promotions (
  promo_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  promo_type TEXT NOT NULL,                -- PCT | AMT | MULTI | BOGOF
  pct_off REAL,
  amount_off REAL,
  buy_qty INTEGER,
  bundle_price REAL,
  starts_at TEXT,
  ends_at TEXT,
  priority INTEGER,
  stackable INTEGER NOT NULL DEFAULT 0,
  loyalty_only INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  currency TEXT,
  location_scope TEXT,
  banner_ref TEXT
);
CREATE TABLE promotion_skus (
  promo_id TEXT NOT NULL REFERENCES promotions(promo_id),
  sku TEXT NOT NULL,
  PRIMARY KEY (promo_id, sku)
);
CREATE TABLE customers (
  customer_id TEXT PRIMARY KEY,
  enrolled_on TEXT,
  home_store TEXT,
  segment TEXT,
  marketing_opt_in INTEGER
);
CREATE TABLE loyalty_accounts (
  customer_id TEXT PRIMARY KEY,
  points_balance INTEGER NOT NULL,
  tier TEXT,
  tier_colour TEXT,
  last_activity_at TEXT
);
CREATE TABLE sales (
  sale_id INTEGER PRIMARY KEY,
  receipt_no TEXT,
  store_code TEXT,
  channel TEXT NOT NULL,
  customer_id TEXT,
  sold_at TEXT NOT NULL,
  currency TEXT,
  status TEXT NOT NULL,
  terminal_no TEXT,
  cashier_ref TEXT,
  total REAL,
  discount_total REAL
);
CREATE TABLE sale_lines (
  line_id INTEGER PRIMARY KEY,
  sale_id INTEGER NOT NULL REFERENCES sales(sale_id),
  variant_id INTEGER,
  qty REAL NOT NULL,
  unit TEXT,
  unit_price REAL NOT NULL,
  discount REAL NOT NULL DEFAULT 0,
  line_total REAL NOT NULL
);
CREATE TABLE payments (
  payment_id INTEGER PRIMARY KEY,
  sale_id INTEGER REFERENCES sales(sale_id),
  method TEXT,
  amount REAL NOT NULL,
  status TEXT NOT NULL,
  paid_at TEXT,
  provider_ref TEXT
);
CREATE TABLE returns (
  return_id INTEGER PRIMARY KEY,
  sale_id INTEGER,
  returned_at TEXT,
  reason TEXT,
  status TEXT
);
CREATE TABLE refunds (
  refund_id INTEGER PRIMARY KEY,
  return_id INTEGER,
  sale_id INTEGER,
  amount REAL NOT NULL,
  status TEXT NOT NULL,
  refunded_at TEXT
);
"""

# table -> primary key columns (used to generate change-log triggers)
BUSINESS_TABLES: dict[str, tuple[str, ...]] = {
    "categories": ("category_id",), "suppliers": ("supplier_id",), "stores": ("store_code",), "warehouses": ("wh_code",),
    "products": ("product_id",), "product_variants": ("variant_id",), "inventory_balances": ("inv_id",),
    "purchase_orders": ("po_number",), "purchase_order_lines": ("line_id",), "price_lists": ("list_id",),
    "price_list_items": ("item_id",), "promotions": ("promo_id",), "promotion_skus": ("promo_id", "sku"),
    "customers": ("customer_id",), "loyalty_accounts": ("customer_id",), "sales": ("sale_id",), "sale_lines": ("line_id",),
    "payments": ("payment_id",), "returns": ("return_id",), "refunds": ("refund_id",),
}


def install_triggers(con: sqlite3.Connection) -> None:
    """Write-freeze (BEFORE triggers abort every write while system_state.frozen=1) and change-log (AFTER triggers)."""
    for t, pk in BUSINESS_TABLES.items():
        for ev, ref in (("INSERT", "NEW"), ("UPDATE", "NEW"), ("DELETE", "OLD")):
            con.execute(
                f"CREATE TRIGGER trg_frozen_{t}_{ev.lower()} BEFORE {ev} ON {t} "
                f"WHEN (SELECT frozen FROM system_state WHERE id = 1) = 1 "
                f"BEGIN SELECT RAISE(ABORT, 'SOURCE FROZEN: writes are disabled during cutover'); END"
            )
            key = " || '/' || ".join(f"{ref}.{c}" for c in pk)
            op = {"INSERT": "I", "UPDATE": "U", "DELETE": "D"}[ev]
            con.execute(
                f"CREATE TRIGGER trg_log_{t}_{ev.lower()} AFTER {ev} ON {t} BEGIN "
                f"INSERT INTO change_log(table_name, pk, op, changed_at) "
                f"VALUES ('{t}', {key}, '{op}', strftime('%Y-%m-%dT%H:%M:%SZ','now')); END"
            )


# ------------------------------------------------------------------ vocabulary

CATEGORIES = [
    (1, "Home", None), (2, "Kitchen Appliances", 1), (3, "Cookware", 1), (4, "Tableware", 1), (5, "Home Textiles", 1),
    (6, "Food & Drink", None), (7, "Coffee & Tea", 6), (8, "Pantry", 6), (9, "Snacks", 6), (10, "Beverages", 6),
    (11, "Household", 1), (12, "Stationery", None),
]
NOUNS = {
    2: ["Toaster", "Blender", "Air Fryer", "Slow Cooker", "Food Processor", "Hand Mixer", "Rice Cooker", "Coffee Grinder",
        "Sandwich Press", "Soup Maker", "Juicer", "Egg Boiler", "Milk Frother", "Stand Mixer", "Bread Maker"],
    3: ["Frying Pan", "Saucepan", "Casserole Dish", "Wok", "Roasting Tin", "Stock Pot", "Griddle", "Baking Tray", "Colander",
        "Chef Knife", "Chopping Board", "Whisk", "Ladle", "Tongs", "Peeler"],
    4: ["Dinner Plate", "Side Plate", "Pasta Bowl", "Mug", "Tumbler", "Wine Glass", "Teapot", "Jug", "Serving Platter",
        "Salad Bowl", "Cutlery Set", "Placemat", "Coaster Set", "Butter Dish", "Gravy Boat"],
    5: ["Bath Towel", "Hand Towel", "Tea Towel", "Cushion Cover", "Throw Blanket", "Duvet Cover", "Pillowcase", "Table Runner",
        "Apron", "Oven Glove", "Bath Mat", "Curtain Pair", "Napkin Set", "Fitted Sheet", "Beanbag Cover"],
    7: ["Espresso Beans", "Filter Coffee", "Decaf Coffee", "Breakfast Tea", "Green Tea", "Chai Blend", "Hot Chocolate",
        "Herbal Infusion", "Earl Grey", "Matcha Powder", "Cold Brew Pods", "Coffee Capsules", "Loose Leaf Oolong",
        "Instant Coffee", "Chicory Blend"],
    8: ["Basmati Rice", "Penne Pasta", "Plain Flour", "Caster Sugar", "Olive Oil", "Rapeseed Oil", "Tomato Passata",
        "Chickpeas Tin", "Red Lentils", "Rolled Oats", "Maple Syrup", "Sea Salt", "Black Pepper", "Balsamic Vinegar", "Clear Honey"],
    9: ["Sea Salt Crisps", "Dark Chocolate Bar", "Oat Biscuits", "Mixed Nuts", "Cereal Bar", "Popcorn", "Rice Cakes", "Fruit Gums",
        "Cheese Crackers", "Flapjack", "Shortbread", "Pretzels", "Trail Mix", "Dried Mango", "Seaweed Snack"],
    10: ["Sparkling Water", "Still Water", "Orange Juice", "Apple Juice", "Ginger Beer", "Cola", "Lemonade", "Tonic Water",
         "Oat Drink", "Almond Drink", "Cold Brew Can", "Kombucha", "Elderflower Cordial", "Iced Tea", "Sports Drink"],
    11: ["Dish Soap", "Laundry Liquid", "Surface Spray", "Bin Bags", "Sponge Pack", "Kitchen Roll", "Glass Cleaner",
         "Dishwasher Tablets", "Bleach", "Floor Cleaner", "Air Freshener", "Microfibre Cloths", "Rubber Gloves", "Descaler", "Toilet Cleaner"],
    12: ["Notebook", "Gel Pen Set", "Desk Planner", "Sticky Notes", "Gift Wrap", "Gift Ribbon", "Greeting Card", "Highlighters",
         "Pencil Case", "Stapler", "Envelope Pack", "Label Sheets", "Marker Set", "Sketch Pad", "Paper Clips"],
}
ADJ = ["Classic", "Compact", "Deluxe", "Everyday", "Premium", "Essential", "Artisan", "Eco", "Heritage", "Studio"]
BRANDS = ["Aureom", "Northfield", "Harbourline", "Brightwell", "Oakmere", "Kestrel & Co", "Meadowgate", "Stonebridge"]
UNIT_BY_NOUN = {"Basmati Rice": "KG", "Plain Flour": "KG", "Caster Sugar": "KG", "Red Lentils": "KG", "Rolled Oats": "KG",
                "Olive Oil": "L", "Rapeseed Oil": "L", "Elderflower Cordial": "L", "Gift Ribbon": "M", "Sparkling Water": "PK",
                "Still Water": "PK", "Cola": "PK", "Lemonade": "PK", "Bin Bags": "PK", "Sponge Pack": "PK", "Paper Clips": "PK",
                "Envelope Pack": "PK"}
PRICE_RANGE = {2: (24, 140), 3: (6, 60), 4: (3, 30), 5: (4, 40), 7: (3, 14), 8: (1, 9), 9: (1, 5), 10: (1, 4), 11: (1, 8), 12: (1, 12)}
COLOURS = ["Red", "Black", "White", "Blue", "Green", "Grey", "Cream", "Teal"]
SIZES = {5: ["S", "M", "L"], 4: ["Small", "Large"], 3: ["20cm", "24cm", "28cm"], 12: ["A5", "A4"]}
ASCII_TRAPS = {  # product index -> non-ASCII display name (the chain accepts printable ASCII only)
    11: "Café Latté Mug 350ml", 29: "Jalapeño Hot Sauce", 47: "Crème Brûlée Torch", 63: "£ Saver Gift Card Holder",
}


def ean13(n: int) -> str:
    body = f"5060{n:08d}"
    s = sum(int(c) * (3 if i % 2 else 1) for i, c in enumerate(body))
    return body + str((10 - s % 10) % 10)


def fmt_ts(utc: datetime, style: str) -> str:
    local = utc.astimezone(LONDON)
    if style == "naive":
        return local.strftime("%Y-%m-%d %H:%M:%S")
    if style == "z":
        return utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    if style == "offset":
        off = local.strftime("%z")
        return local.strftime("%Y-%m-%dT%H:%M:%S") + off[:3] + ":" + off[3:]
    if style == "uk":
        return local.strftime("%d/%m/%Y %H:%M")
    if style == "epoch-s":
        return str(int(utc.timestamp()))
    if style == "epoch-ms":
        return str(int(utc.timestamp()) * 1000)
    raise ValueError(style)


class Gen:
    def __init__(self, seed: int, path: Path):
        self.rng = random.Random(seed)
        self.seed = seed
        self.path = path
        self.planted: list[dict] = []

    # ---- helpers
    def plant(self, kind: str, source_ref: str, disposition: str, note: str, table: str = "") -> None:
        self.planted.append({"kind": kind, "source_ref": source_ref, "disposition": disposition, "note": note, "table": table or source_ref.split(":")[0]})

    def r(self) -> random.Random:
        return self.rng

    # ---- build
    def build(self) -> dict:
        if self.path.exists():
            self.path.unlink()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path)
        con.executescript(DDL)
        self.con = con
        self.gen_reference()
        self.gen_catalogue()
        self.gen_prices()
        self.gen_promotions()
        self.gen_customers()
        self.gen_inventory()
        self.gen_purchase_orders()
        self.gen_sales()
        self.gen_system_state()
        con.commit()
        install_triggers(con)
        con.commit()
        counts = {t: con.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in BUSINESS_TABLES}
        con.close()
        manifest = self.demo_manifest(counts)
        Path(str(self.path) + ".planted.json").write_text(json.dumps(sorted(self.planted, key=lambda p: (p["kind"], p["source_ref"])), indent=2) + "\n")
        Path(str(self.path) + ".demo.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        return {"path": str(self.path), "row_counts": counts, "planted": len(self.planted)}

    # ---- reference data
    def gen_reference(self) -> None:
        c, rng = self.con, self.rng
        c.executemany("INSERT INTO categories VALUES (?,?,?)", CATEGORIES)
        suppliers = []
        names = ["Harbourline Housewares", "Northfield Wholesale", "Brightwell Foods", "Oakmere Textiles", "Kestrel Distribution",
                 "Meadowgate Pantry", "Stonebridge Ceramics", "Müller & Söhne Ltd", "Aureom Direct Supply", "Coastal Beverages",
                 "Peak Stationery", "Greenfield Household", "Silverline Appliances", "Riverbend Coffee Co"]
        for i, n in enumerate(names, 1):
            suppliers.append((f"SUP-{i:03d}", n, rng.choice(["NET30", "NET45", "NET60", "2/10 NET30"]), "GBP",
                              rng.choice(["A", "A-", "B+", "B", "C"]), 1 if i != 11 else 0))
        c.executemany("INSERT INTO suppliers VALUES (?,?,?,?,?,?)", suppliers)
        self.plant("NON_ASCII_TEXT", "suppliers:SUP-008", "FIXED", "supplier name with umlauts; original preserved in source_extras", "suppliers")
        c.executemany("INSERT INTO stores VALUES (?,?,?,?,?,?,?)", [
            ("S001", "Northgate Superstore", "North", "GBP", "2012-04-02", 2450.0, "OPEN"),
            ("S002", "Harbour Street Express", "North", "GBP", "2016-09-17", 410.5, "OPEN"),
            ("S003", "Southcoast Superstore", "South", "GBP", "2014-06-01", 2210.0, "OPEN"),
            ("S004", "Eastfield Outlet", "East", "GBP", "2024-11-08", 980.0, "OPEN"),  # not a genesis location: imported as LOCATION
        ])
        c.executemany("INSERT INTO warehouses VALUES (?,?,?,?,?)", [
            ("DC01", "Distribution Centre Midlands", "Central", "GBP", "OPEN"),
            ("DC02", "Returns & Overflow Depot", "Central", "GBP", "OPEN"),  # not a genesis location
        ])

    # ---- catalogue
    def gen_catalogue(self) -> None:
        c, rng = self.con, self.rng
        self.products: list[dict] = []  # python-side mirror used by later generators
        self.variants: list[dict] = []
        pid = vid = 0
        # the demo product first so its ids are stable
        pid += 1
        c.execute("INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?)",
                  (pid, "PRD-KETTLE", "Aureom Barista Kettle", "Aureom", 2, "SUP-009", "A", "2024-03-05 09:30:00", "Gold",
                   json.dumps({"launch": "2024", "voltage": "230V", "warranty_months": 24, "tags": ["scarce", "gift"]}, sort_keys=True)))
        vid += 1
        c.execute("INSERT INTO product_variants VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                  (vid, pid, "KETTLE-RED", ean13(1), "EA", "EA", 1, "Red", "1.7L", 1450.0, "A", json.dumps({"finish": "gloss"})))
        self.products.append({"id": pid, "unit": "EA", "cat": 2, "name": "Aureom Barista Kettle"})
        self.variants.append({"id": vid, "pid": pid, "sku": "KETTLE-RED", "unit": "EA", "cat": 2, "base": 39.99})
        sku_n = 1
        bar_n = 1
        idx = 0
        for cat in (2, 3, 4, 5, 7, 8, 9, 10, 11, 12):
            for noun in NOUNS[cat]:
                idx += 1
                pid += 1
                unit = UNIT_BY_NOUN.get(noun, "EA")
                name = f"{rng.choice(ADJ)} {noun}"
                if idx in ASCII_TRAPS:
                    name = ASCII_TRAPS[idx]
                    self.plant("NON_ASCII_TEXT", f"products:{pid}", "FIXED", f"product name {name!r} is not printable ASCII; original preserved in source_extras", "products")
                brand = rng.choice(BRANDS)
                supplier = f"SUP-{rng.randint(1, 14):03d}"
                status = rng.choices(["A", "A", "A", "D"], [10, 10, 10, 1])[0]
                created = f"{rng.randint(2019, 2025)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d} {rng.randint(8, 17):02d}:{rng.randint(0, 59):02d}:00"
                tier = rng.choice([None, None, None, "Gold", "Silver", "Platinum"])
                custom = None
                if rng.random() < 0.22:
                    custom = json.dumps({"supplier_notes": rng.choice(["fragile", "heavy", "seasonal", "gift-boxed"]),
                                         "pack_dims_mm": [rng.randint(50, 400), rng.randint(50, 400), rng.randint(20, 300)],
                                         "legacy_plu": rng.randint(1000, 9999)}, sort_keys=True)
                c.execute("INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (pid, f"PRD-{pid:05d}", name, brand, cat, supplier, status, created, tier, custom))
                self.products.append({"id": pid, "unit": unit, "cat": cat, "name": name})
                lo, hi = PRICE_RANGE[cat]
                base = round(rng.uniform(lo, hi)) - 0.01
                for k in range(rng.choices([1, 2, 3, 4], [10, 30, 35, 25])[0]):
                    vid += 1
                    sku_n += 1
                    bar_n += 1
                    colour = rng.choice(COLOURS) if cat in (2, 3, 4, 5, 12) else None
                    size = rng.choice(SIZES[cat]) if cat in SIZES else (rng.choice(["250g", "500g", "1kg"]) if cat in (7, 8, 9) else None)
                    wg = round(rng.uniform(50, 2500), 1) if unit == "EA" and rng.random() < 0.4 else None
                    vcustom = json.dumps({"bin_hint": rng.choice(["A", "B", "C"])}) if rng.random() < 0.08 else None
                    c.execute("INSERT INTO product_variants VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                              (vid, pid, f"SKU-{sku_n:05d}", ean13(bar_n), unit, unit, 0, colour, size, wg, "A", vcustom))
                    self.variants.append({"id": vid, "pid": pid, "sku": f"SKU-{sku_n:05d}", "unit": unit, "cat": cat,
                                          "base": round(base * (1 + 0.08 * k), 2)})
        self.next_pid, self.next_vid, self.next_bar = pid + 1, vid + 1, bar_n + 1
        self.plant_catalogue()

    def plant_catalogue(self) -> None:
        c, rng = self.con, self.rng
        base = [v for v in self.variants if v["sku"] != "KETTLE-RED"]
        pick = rng.sample(base, 14)
        vid = self.next_vid
        # duplicate SKUs: exact, case/whitespace variant, and same SKU under a different product
        for kind, src in (("exact", pick[0]), ("case", pick[1]), ("cross-product", pick[2])):
            row = c.execute("SELECT * FROM product_variants WHERE variant_id=?", (src["id"],)).fetchone()
            sku = {"exact": row[2], "case": " " + row[2].lower() + " ", "cross-product": row[2]}[kind]
            pid = row[1] if kind != "cross-product" else self.variants[5]["pid"]
            c.execute("INSERT INTO product_variants VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (vid, pid, sku, ean13(self.next_bar), row[4], row[5], 0, row[7], row[8], row[9], "A", None))
            self.next_bar += 1
            self.plant("DUPLICATE_SKU", f"product_variants:{vid}", "EXCLUDED", f"{kind} duplicate of variant {src['id']} ({src['sku']})", "product_variants")
            vid += 1
        # duplicate barcodes: three variants copy another variant's barcode (the later variant id is the one that loses it)
        for src, dup in ((pick[3], pick[4]), (pick[5], pick[6]), (pick[7], pick[8])):
            first, later = sorted((src["id"], dup["id"]))
            bc = c.execute("SELECT barcode FROM product_variants WHERE variant_id=?", (first,)).fetchone()[0]
            c.execute("UPDATE product_variants SET barcode=? WHERE variant_id=?", (bc, later))
            self.plant("DUPLICATE_BARCODE", f"product_variants:{later}", "PRESERVED_AS_EXTRAS", f"barcode {bc} shared with variant {first}", "product_variants")
        # unit mismatch: unit column and uom column disagree (EA vs KG)
        mm = pick[9]
        c.execute("UPDATE product_variants SET unit='EA', uom='KG' WHERE variant_id=?", (mm["id"],))
        self.unit_mismatch_variant = mm
        self.plant("UNIT_MISMATCH", f"product_variants:{mm['id']}", "MANUAL", "unit=EA but uom=KG", "product_variants")
        # orphan variant: product row missing
        c.execute("INSERT INTO product_variants VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                  (vid, 99001, "SKU-ORPHAN-1", ean13(self.next_bar), "EA", "EA", 0, None, None, None, "A", None))
        self.next_bar += 1
        self.plant("ORPHAN_FK", f"product_variants:{vid}", "EXCLUDED", "variant references missing product 99001", "product_variants")
        vid += 1
        # orphan product category (kept, original id preserved)
        orphan_cat = rng.choice([p for p in self.products if p["id"] > 1])
        c.execute("UPDATE products SET category_id=88 WHERE product_id=?", (orphan_cat["id"],))
        self.plant("ORPHAN_FK", f"products:{orphan_cat['id']}", "PRESERVED_AS_EXTRAS", "product references missing category 88", "products")
        # legacy synonyms for unit codes (normalised silently, counted in the report)
        for v in rng.sample([v for v in base if v["unit"] == "EA" and v["id"] not in {pick[i]["id"] for i in range(10)}], 25):
            c.execute("UPDATE product_variants SET unit=?, uom=NULL WHERE variant_id=?", (rng.choice(["EACH", "PCS", "ea"]), v["id"]))
        self.next_vid = vid

    # ---- prices
    def gen_prices(self) -> None:
        c, rng = self.con, self.rng
        c.executemany("INSERT INTO price_lists VALUES (?,?,?,?)", [
            (1, "GBP Chain Standard", "GBP", None), (2, "Harbour Street Local", "GBP", "S002"), (3, "USD Export Trial", "USD", "S003")])
        item = 0
        self.price_of: dict[str, float] = {}
        rows = []
        vs = sorted(self.variants, key=lambda v: v["id"])
        for v in vs:
            item += 1
            price = 39.99 if v["sku"] == "KETTLE-RED" else v["base"]
            if v["sku"] != "KETTLE-RED" and rng.random() < 0.10:
                price = round(price + 1.3, 2) + 0.1 + 0.2 - 0.3  # classic binary-float artefact (e.g. 14.290000000000001): benign noise
            self.price_of[v["sku"]] = price
            if v["sku"] != "KETTLE-RED" and rng.random() < 0.25:
                rows.append((item, 1, v["sku"], round(price * 0.9, 2), "2025-01-01 00:00:00", "2025-09-30 23:59:59", "old price"))
                item += 1
                rows.append((item, 1, v["sku"], price, "2025-10-01 00:00:00", None, None))
            else:
                rows.append((item, 1, v["sku"], price, rng.choice(["2025-01-01 00:00:00", "2025-01-01T00:00:00Z", "01/01/2025 00:00"]), None,
                             "seasonal" if rng.random() < 0.05 else None))
        # local overrides for Harbour Street
        for v in rng.sample(vs[10:200], 20):
            item += 1
            rows.append((item, 2, v["sku"], round(self.price_of[v["sku"]] * 0.92, 2), "2026-03-01 00:00:00", None, "local promo price"))
        c.executemany("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", rows)
        # ---- planted price problems
        std = [r for r in rows if r[1] == 1 and r[5] is None]
        gen = rng.sample(std, 4)
        for r in gen[:3]:  # genuine sub-penny precision (3 dp)
            newp = float(f"{r[3]:.2f}") + 0.005
            c.execute("UPDATE price_list_items SET price=? WHERE item_id=?", (newp, r[0]))
            self.plant("FLOAT_PRECISION", f"price_list_items:{r[0]}", "FIXED", f"price {newp!r} has sub-penny precision; rounded half-even", "price_list_items")
        d = gen[3]
        item += 1
        c.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 1, d[2], d[3] + 1.0, d[4], None, "duplicate of same valid_from"))
        self.plant("DUPLICATE_PRICE", f"price_list_items:{d[0]}", "EXCLUDED", f"same sku/location/valid_from as item {item}; the later item wins", "price_list_items")
        item += 1
        zero_sku = rng.choice(vs[20:100])["sku"]
        c.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 2, zero_sku, 0.0, "2026-04-01 00:00:00", None, "free?"))
        self.plant("INVALID_PRICE", f"price_list_items:{item}", "EXCLUDED", "zero price", "price_list_items")
        item += 1
        c.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 1, "SKU-NOSUCH-9", 9.99, "2026-01-01 00:00:00", None, None))
        self.plant("ORPHAN_FK", f"price_list_items:{item}", "EXCLUDED", "price for unknown sku", "price_list_items")
        item += 1
        c.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 1, vs[30]["sku"], 3.5, "2026-06-01 00:00:00", "2026-05-01 00:00:00", "ends before it starts"))
        self.plant("PRICE_PERIOD_INVALID", f"price_list_items:{item}", "EXCLUDED", "valid_to before valid_from", "price_list_items")
        for v in vs[40:45]:
            item += 1
            c.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 3, v["sku"], round(v["base"] * 1.27, 2), "2026-01-01 00:00:00", None, "USD list on a GBP store"))
            self.plant("CURRENCY_MISMATCH", f"price_list_items:{item}", "EXCLUDED", "USD price list attached to a store that trades in GBP", "price_list_items")

    # ---- promotions
    def gen_promotions(self) -> None:
        c = self.con
        kitchen = [v["sku"] for v in self.variants if v["cat"] in (3, 4) and v["sku"] != "KETTLE-RED"][:6]
        coffee = [v["sku"] for v in self.variants if v["cat"] == 7][:3]
        snacks = [v["sku"] for v in self.variants if v["cat"] == 9][:4]
        mugs = [v["sku"] for v in self.variants if v["cat"] == 4][:2]
        promos = [
            ("PROMO-001", "Spring Kitchen 15% off", "PCT", 15.0, None, None, None, "2026-10-15 00:00:00", "2027-02-28 23:59:59", 100, 0, 0, "ACTIVE", "GBP", "ALL", "banner-spring-01", kitchen),
            ("PROMO-002", "Coffee 3 for £10", "MULTI", None, None, 3, 10.0, "2026-10-01T00:00:00Z", "2027-01-31T23:59:59Z", 50, 0, 0, "ACTIVE", "GBP", "S001,S002,S003", "banner-coffee-3", coffee),
            ("PROMO-003", "Biscuit BOGOF", "BOGOF", None, None, None, None, "2026-10-20 00:00:00", "2027-01-10 00:00:00", 100, 0, 0, "ACTIVE", "GBP", "ALL", None, snacks),
            ("PROMO-004", "Winter Sale 2025", "PCT", 20.0, None, None, None, "2025-12-01 00:00:00", "2026-01-15 00:00:00", 100, 0, 0, "ENDED", "GBP", "ALL", None, kitchen[:2]),
            ("PROMO-005", "Loyalty GBP 2 off mugs", "AMT", None, 2.0, None, None, "2026-11-01 00:00:00", None, 80, 1, 1, "ACTIVE", "GBP", "ALL", "banner-loyal-mug", mugs),
        ]
        for p in promos:
            c.execute("INSERT INTO promotions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", p[:16])
            for s_ in p[16]:
                c.execute("INSERT INTO promotion_skus VALUES (?,?)", (p[0], s_))
        self.plant("UNSUPPORTED_PROMO_TYPE", "promotions:PROMO-003", "MANUAL", "BOGOF has no chain equivalent (promotion types: percent, amount per unit, multibuy fixed price)", "promotions")

    # ---- customers & loyalty
    def gen_customers(self) -> None:
        c, rng = self.con, self.rng
        custs = [(f"CUST-{i:06d}", f"{rng.randint(2018, 2025)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}", rng.choice(["S001", "S002", "S003", "S004"]),
                  rng.choice(["A", "B", "C"]), rng.randint(0, 1)) for i in range(1, 601)]
        custs.append(("CUST-DEMO01", "2026-10-01", "S001", "A", 1))
        legacy = ["C0701", "cust_000702", "LEGACY-9001", "WEB-GUEST-55", "C0045"]
        custs += [(lid, "2019-05-05", "S003", "C", 0) for lid in legacy]
        c.executemany("INSERT INTO customers VALUES (?,?,?,?,?)", custs)
        loy = []
        for i in range(1, 421):
            pts = rng.choice([0, 0, 10, 50, 120, 340, 800, 1500, 2600, 4800]) + rng.randint(0, 9)
            tier = "BRONZE" if pts < 500 else "SILVER" if pts < 2000 else "GOLD"
            loy.append((f"CUST-{i:06d}", pts, tier, {"BRONZE": "Bronze", "SILVER": "Silver", "GOLD": "Gold"}[tier], f"2026-{rng.randint(1, 10):02d}-{rng.randint(1, 28):02d}"))
        loy.append(("CUST-DEMO01", 120, "BRONZE", "Bronze", "2026-10-30"))
        loy += [("C0701", 75, "BRONZE", "Bronze", "2026-09-01"), ("cust_000702", 410, "BRONZE", "Bronze", "2026-09-02"),
                ("LEGACY-9001", 22, "BRONZE", "Bronze", "2026-08-02"), ("WEB-GUEST-55", 5, "BRONZE", "Bronze", "2026-08-03"),
                ("C0045", 300, "SILVER", "Silver", "2026-07-01"), ("CUST-008888", 64, "BRONZE", "Bronze", "2026-07-01")]
        # CUST-000045 already exists in the first block (collides with legacy C0045 once normalised)
        loy = [(a, (-50 if a == "CUST-000099" else b), c_, d, e) for a, b, c_, d, e in loy]
        c.executemany("INSERT INTO loyalty_accounts VALUES (?,?,?,?,?)", loy)
        self.plant("LEGACY_CUSTOMER_ID", "loyalty_accounts:C0701", "FIXED", "legacy id C0701 -> CUST-000701", "loyalty_accounts")
        self.plant("LEGACY_CUSTOMER_ID", "loyalty_accounts:cust_000702", "FIXED", "legacy id cust_000702 -> CUST-000702", "loyalty_accounts")
        self.plant("LEGACY_CUSTOMER_ID", "loyalty_accounts:LEGACY-9001", "FIXED", "non-conforming id pseudonymised (PSN-...)", "loyalty_accounts")
        self.plant("LEGACY_CUSTOMER_ID", "loyalty_accounts:WEB-GUEST-55", "FIXED", "non-conforming id pseudonymised (PSN-...)", "loyalty_accounts")
        self.plant("DUPLICATE_CUSTOMER_ID", "loyalty_accounts:C0045", "MANUAL", "C0045 normalises to CUST-000045 which already has an account", "loyalty_accounts")
        self.plant("DUPLICATE_CUSTOMER_ID", "loyalty_accounts:CUST-000045", "MANUAL", "colliding legacy account C0045", "loyalty_accounts")
        self.plant("NEGATIVE_POINTS", "loyalty_accounts:CUST-000099", "MANUAL", "negative points balance -50", "loyalty_accounts")
        self.plant("ORPHAN_FK", "loyalty_accounts:CUST-008888", "MANUAL", "loyalty account without a customer record", "loyalty_accounts")

    # ---- inventory
    def gen_inventory(self) -> None:
        c, rng = self.con, self.rng
        rows = []
        inv = 0
        stores = ["S001", "S002", "S003", "S004"]
        by_sku = {v["sku"]: v for v in self.variants}
        for v in sorted(self.variants, key=lambda v: v["id"]):
            if v["sku"] == "KETTLE-RED":
                continue
            locs = ["DC01"] + rng.sample(stores, rng.randint(1, 3)) + (["DC02"] if rng.random() < 0.1 else [])
            for loc in locs:
                inv += 1
                scale = 3 if loc.startswith("DC") else 1
                if v["unit"] in ("KG", "L", "M"):
                    q = round(rng.uniform(2, 60) * scale, 3 if rng.random() < 0.3 else 1)
                else:
                    q = float(rng.randint(0, 40 * scale))
                res = float(min(int(q), rng.randint(0, 3))) if v["unit"] in ("EA", "PK") and rng.random() < 0.15 else 0.0
                dmg = float(rng.randint(1, 3)) if v["unit"] in ("EA", "PK") and rng.random() < 0.05 else 0.0
                rows.append((inv, v["sku"], loc, None if rng.random() < 0.7 else v["unit"], q, res, dmg, rng.choice(["A1", "B3", "C7", None]),
                             rng.choice(["2026-10-31 18:00:00", "2026-10-30T17:45:00Z", None])))
        inv += 1
        rows.append((inv, "KETTLE-RED", "S001", "EA", 2.0, 0.0, 0.0, "KT-01", "2026-10-31 18:00:00"))
        self.kettle_inv = inv
        c.executemany("INSERT INTO inventory_balances VALUES (?,?,?,?,?,?,?,?,?)", rows)
        # planted
        eligible = [r for r in rows if r[1] not in ("KETTLE-RED", self.unit_mismatch_variant["sku"]) and r[6] == 0.0 and r[5] == 0.0 and by_sku[r[1]]["unit"] == "EA" and r[4] > 5]
        pick = rng.sample(eligible, 14)
        for r in pick[:4]:
            c.execute("UPDATE inventory_balances SET on_hand=? WHERE inv_id=?", (-float(rng.randint(1, 12)), r[0]))
            self.plant("NEGATIVE_STOCK", f"inventory_balances:{r[0]}", "MANUAL", "negative on-hand quantity", "inventory_balances")
        for r in pick[4:8]:
            q = float(int(r[4])) + 0.5
            c.execute("UPDATE inventory_balances SET on_hand=? WHERE inv_id=?", (q, r[0]))
            self.plant("FRACTIONAL_QUANTITY", f"inventory_balances:{r[0]}", "FIXED", f"fractional on-hand {q} for an EA item", "inventory_balances")
        for r in pick[8:11]:
            inv += 1
            c.execute("INSERT INTO inventory_balances VALUES (?,?,?,?,?,?,?,?,?)", (inv, r[1], rng.choice(["S099", "XX01", "STORE-17"]), None, 6.0, 0.0, 0.0, None, None))
            self.plant("ORPHAN_FK", f"inventory_balances:{inv}", "EXCLUDED", "inventory row for a location that does not exist", "inventory_balances")
        r = pick[11]
        c.execute("UPDATE inventory_balances SET unit='KG' WHERE inv_id=?", (r[0],))
        self.plant("UNIT_MISMATCH", f"inventory_balances:{r[0]}", "MANUAL", "balance row says KG but the SKU is sold per EA", "inventory_balances")
        r = pick[12]
        inv += 1
        c.execute("INSERT INTO inventory_balances VALUES (?,?,?,?,?,?,?,?,?)", (inv, r[1], r[2], None, 3.0, 0.0, 0.0, None, None))
        self.plant("DUPLICATE_BALANCE_ROW", f"inventory_balances:{r[0]}", "MANUAL", f"two balance rows for {r[1]} at {r[2]}", "inventory_balances")
        self.plant("DUPLICATE_BALANCE_ROW", f"inventory_balances:{inv}", "MANUAL", f"two balance rows for {r[1]} at {r[2]}", "inventory_balances")
        # inventory for a SKU that does not exist
        inv += 1
        c.execute("INSERT INTO inventory_balances VALUES (?,?,?,?,?,?,?,?,?)", (inv, "SKU-GHOST-1", "DC01", None, 11.0, 0.0, 0.0, None, None))
        self.plant("ORPHAN_FK", f"inventory_balances:{inv}", "EXCLUDED", "inventory for an unknown SKU", "inventory_balances")

    # ---- purchase orders
    def gen_purchase_orders(self) -> None:
        c, rng = self.con, self.rng
        vs = [v for v in self.variants if v["sku"] != "KETTLE-RED" and v["unit"] == "EA" and v["id"] != self.unit_mismatch_variant["id"]]
        line_id = 0
        pos, lines = [], []

        def add_po(num, sup, loc, status, ordered, closed=None, nl=None, received_frac=0.0, sku_pool=None):
            nonlocal line_id
            pos.append((num, sup, loc, status, "GBP", ordered, "2026-11-20 00:00:00", closed, "approver-hq" if status != "DRAFT" else None,
                        rng.choice([None, "deliver to dock 2", "urgent"])))
            for _ in range(nl or rng.randint(1, 4)):
                v = rng.choice(sku_pool or vs)
                q = float(rng.randint(5, 60))
                recv = float(int(q * received_frac)) if received_frac < 1 else q
                line_id += 1
                lines.append((line_id, num, v["sku"], q, recv, "EA", round(v["base"] * 0.55, 2) + 0.0))

        # PO-2001: the demo purchase order (1 x KETTLE-RED outstanding, unit cost 18.00)
        pos.append(("PO-2001", "SUP-009", "S001", "APPROVED", "GBP", "2026-10-28T09:00:00Z", "2026-11-20 00:00:00", None, "approver-hq", "demo: scarce kettle restock"))
        line_id += 1
        lines.append((line_id, "PO-2001", "KETTLE-RED", 1.0, 0.0, "EA", 18.0))
        locs = ["S001", "S002", "S003", "S004", "DC01"]
        for n in range(2002, 2013):  # open orders
            st = rng.choice(["APPROVED", "APPROVED", "PART_RECEIVED", "DRAFT"])
            add_po(f"PO-{n}", f"SUP-{rng.randint(1, 14):03d}", rng.choice(locs), st, f"2026-10-{rng.randint(1, 27):02d} 10:00:00",
                   received_frac=0.4 if st == "PART_RECEIVED" else 0.0)
        for n in range(2013, 2031):  # closed orders (not outstanding: out of scope)
            add_po(f"PO-{n}", f"SUP-{rng.randint(1, 14):03d}", rng.choice(locs), rng.choice(["RECEIVED", "CLOSED"]),
                   f"2026-0{rng.randint(5, 9)}-{rng.randint(10, 28)} 10:00:00", closed="2026-10-01 12:00:00", received_frac=1.0)
        for n in range(2031, 2036):
            add_po(f"PO-{n}", f"SUP-{rng.randint(1, 14):03d}", rng.choice(locs), "CANCELLED", "2026-08-02 10:00:00", closed="2026-08-20 10:00:00")
        # stale PO: still APPROVED but every line is fully received and it carries a closed_at stamp
        add_po("PO-2036", "SUP-003", "DC01", "APPROVED", "2026-06-02 10:00:00", closed="2026-07-15 10:00:00", nl=2, received_frac=1.0)
        self.plant("STALE_PO_CLOSED", "purchase_orders:PO-2036", "EXCLUDED", "status APPROVED but fully received and closed_at is set", "purchase_orders")
        add_po("PO-2037", "SUP-999", "S002", "APPROVED", "2026-10-02 10:00:00")
        self.plant("ORPHAN_FK", "purchase_orders:PO-2037", "EXCLUDED", "PO supplier SUP-999 does not exist", "purchase_orders")
        add_po("PO-2038", "SUP-004", "S003", "APPROVED", "02/10/2026 10:00", nl=1)  # UK-format date: fine
        c.executemany("INSERT INTO purchase_orders VALUES (?,?,?,?,?,?,?,?,?,?)", pos)
        c.executemany("INSERT INTO purchase_order_lines VALUES (?,?,?,?,?,?,?)", lines)

    # ---- sales
    def gen_sales(self) -> None:
        c, rng = self.con, self.rng
        london = LONDON
        vs = sorted(self.variants, key=lambda v: v["id"])
        pool = [v for v in vs if v["sku"] != "KETTLE-RED" and v["id"] != self.unit_mismatch_variant["id"]]
        N = 1950
        span_days = (AS_OF - HISTORY_START).days - 1
        instants = sorted(
            (HISTORY_START + timedelta(days=rng.randint(0, span_days), hours=0)).replace(tzinfo=None)
            for _ in range(N)
        )
        styles = ["naive"] * 50 + ["z"] * 18 + ["offset"] * 12 + ["uk"] * 10 + ["epoch-s"] * 6 + ["epoch-ms"] * 4
        stores = ["S001"] * 30 + ["S002"] * 20 + ["S003"] * 25 + ["S004"] * 10
        sale_rows, line_rows, pay_rows, ret_rows, ref_rows = [], [], [], [], []
        lid = pid = rid = fid = 0
        self.sales_meta: dict[int, dict] = {}
        for sid, day in enumerate(instants, 1):
            local = datetime(day.year, day.month, day.day, rng.randint(8, 20), rng.randint(0, 59), rng.randint(0, 59), tzinfo=london)
            utc = local.astimezone(timezone.utc)
            ts = fmt_ts(utc, rng.choice(styles))
            web = rng.random() < 0.15
            store = None if web else rng.choice(stores)
            cust = None
            if rng.random() < 0.35:
                cust = f"CUST-{rng.randint(1, 450):06d}"
            nl = rng.choices([1, 2, 3, 4], [45, 30, 17, 8])[0]
            chosen = rng.sample(pool, nl)
            if rng.random() < 0.012:
                chosen[0] = vs[0]  # kettle
            total = 0.0
            disc_total = 0.0
            lrows = []
            for v in chosen:
                if v["unit"] in ("KG", "L", "M"):
                    qty = round(rng.uniform(0.2, 2.5), 3 if v["unit"] != "M" else 1)
                elif v["unit"] == "PK":
                    qty = float(rng.randint(1, 2))
                else:
                    qty = float(rng.randint(1, 3))
                price = self.price_of[v["sku"]]
                up = round(price, 2) if rng.random() > 0.1 else round(price * 0.95, 2)
                gross = qty * up
                disc = round(gross * rng.choice([0.05, 0.1, 0.15]), 2) if rng.random() < 0.10 else 0.0
                lt = round(gross - disc, 2)
                lid += 1
                lrows.append((lid, sid, v["id"], qty, v["unit"] if rng.random() < 0.6 else None, up, disc, lt))
                total += lt
                disc_total += disc
            sale_rows.append((sid, f"R{sid:07d}", store, "WEB" if web else rng.choice(["POS", "POS", "STORE"]), cust, ts, "GBP", "COMPLETE",
                              None if web else f"T{rng.randint(1, 6)}", f"EMP{rng.randint(100, 140)}", total, disc_total))
            line_rows += lrows
            self.sales_meta[sid] = {"total": total, "utc": utc}
            # payments
            if rng.random() < 0.06 and total > 4:
                cash = round(total * 0.4, 2)
                pid += 1
                pay_rows.append((pid, sid, "CASH", cash, "CAPTURED", ts, None))
                pid += 1
                pay_rows.append((pid, sid, "CARD", total - cash, "CAPTURED", ts, f"ch_{sid:07d}"))
            else:
                pid += 1
                pay_rows.append((pid, sid, rng.choice(["CARD", "CARD", "CARD", "CASH", "VOUCHER"]), total, "CAPTURED", ts, f"ch_{sid:07d}"))
            # returns / refunds
            if rng.random() < 0.04:
                rid += 1
                ret_rows.append((rid, sid, ts, rng.choice(["faulty", "changed mind", "wrong size"]), "COMPLETE"))
                amt = lrows[0][7] if rng.random() < 0.7 else round(lrows[0][7] / 2, 2)
                fid += 1
                ref_rows.append((fid, rid, sid, amt, "DONE" if rng.random() > 0.05 else "PENDING", ts))
        self.max_sale = N
        c.executemany("INSERT INTO sales VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", sale_rows)
        c.executemany("INSERT INTO sale_lines VALUES (?,?,?,?,?,?,?,?)", line_rows)
        c.executemany("INSERT INTO payments VALUES (?,?,?,?,?,?,?)", pay_rows)
        c.executemany("INSERT INTO returns VALUES (?,?,?,?,?)", ret_rows)
        c.executemany("INSERT INTO refunds VALUES (?,?,?,?,?,?)", ref_rows)
        self.ids = {"line": lid, "pay": pid, "ret": rid, "ref": fid}
        self.plant_sales()

    def _sale(self, sid):
        return self.con.execute("SELECT * FROM sales WHERE sale_id=?", (sid,)).fetchone()

    def plant_sales(self) -> None:
        c, rng = self.con, self.rng
        N = self.max_sale
        cand = rng.sample(range(50, N - 50), 80)
        ci = iter(cand)

        def nxt():
            return next(ci)

        ids = self.ids
        # --- orphan variant on a sale line
        for _ in range(4):
            sid = nxt()
            ln = c.execute("SELECT line_id FROM sale_lines WHERE sale_id=? ORDER BY line_id LIMIT 1", (sid,)).fetchone()[0]
            c.execute("UPDATE sale_lines SET variant_id=? WHERE line_id=?", (990000 + sid, ln))
            self.plant("ORPHAN_FK", f"sales:{sid}", "EXCLUDED", f"sale line {ln} references missing variant {990000 + sid}", "sale_lines")
        # --- orphan store
        sid = nxt()
        c.execute("UPDATE sales SET store_code='S077', channel='POS' WHERE sale_id=?", (sid,))
        self.plant("ORPHAN_FK", f"sales:{sid}", "EXCLUDED", "sale at unknown store S077", "sales")
        # --- orphan customer (kept anonymous, original id preserved)
        for _ in range(3):
            sid = nxt()
            c.execute("UPDATE sales SET customer_id='CUST-009999' WHERE sale_id=?", (sid,))
            self.plant("ORPHAN_FK", f"sales:{sid}", "PRESERVED_AS_EXTRAS", "sale customer CUST-009999 has no customer record", "sales")
        # --- legacy customer ids used on sales
        for lid_ in ("C0701", "cust_000702", "LEGACY-9001"):
            sid = nxt()
            c.execute("UPDATE sales SET customer_id=? WHERE sale_id=?", (lid_, sid))
        # --- payments for a sale that does not exist
        for k in range(2):
            ids["pay"] += 1
            c.execute("INSERT INTO payments VALUES (?,?,?,?,?,?,?)", (ids["pay"], 880000 + k, "CARD", 12.5, "CAPTURED", "2026-05-05 10:00:00", None))
            self.plant("ORPHAN_FK", f"payments:{ids['pay']}", "EXCLUDED", "payment references missing sale", "payments")
        # --- fractional EA quantity on a sale line
        for _ in range(3):
            sid = nxt()
            ln = c.execute("SELECT line_id, variant_id FROM sale_lines WHERE sale_id=? ORDER BY line_id LIMIT 1", (sid,)).fetchone()
            if c.execute("SELECT unit FROM product_variants WHERE variant_id=?", (ln[1],)).fetchone()[0] not in ("EA", "EACH", "PCS", "ea"):
                ln2 = c.execute("""SELECT l.line_id FROM sale_lines l JOIN product_variants v ON v.variant_id=l.variant_id
                                   WHERE v.unit IN ('EA','EACH','PCS','ea') AND l.sale_id>? ORDER BY l.line_id LIMIT 1""", (sid,)).fetchone()
                ln, sid = (ln2[0], c.execute("SELECT sale_id FROM sale_lines WHERE line_id=?", (ln2[0],)).fetchone()[0])
            else:
                ln = ln[0]
            c.execute("UPDATE sale_lines SET qty=1.5 WHERE line_id=?", (ln,))
            self.plant("FRACTIONAL_QUANTITY", f"sales:{sid}", "MANUAL", f"sale line {ln} sells 1.5 units of an EA item", "sale_lines")
        # --- unit mismatch on a sale line
        sid = nxt()
        row = c.execute("""SELECT l.line_id FROM sale_lines l JOIN product_variants v ON v.variant_id=l.variant_id
                           WHERE v.unit IN ('EA') AND l.sale_id>=? ORDER BY l.line_id LIMIT 1""", (sid,)).fetchone()
        ln = row[0]
        sid = c.execute("SELECT sale_id FROM sale_lines WHERE line_id=?", (ln,)).fetchone()[0]
        c.execute("UPDATE sale_lines SET unit='KG' WHERE line_id=?", (ln,))
        self.plant("UNIT_MISMATCH", f"sales:{sid}", "MANUAL", f"sale line {ln} unit KG but SKU is EA", "sale_lines")
        # --- line total mismatches (FIXED: recorded net kept, discount derived)
        for _ in range(3):
            sid = nxt()
            ln = c.execute("SELECT line_id, line_total FROM sale_lines WHERE sale_id=? ORDER BY line_id LIMIT 1", (sid,)).fetchone()
            c.execute("UPDATE sale_lines SET line_total=? WHERE line_id=?", (round(ln[1] + 3.0, 2), ln[0]))
            self.plant("LINE_TOTAL_MISMATCH", f"sales:{sid}", "FIXED", f"line {ln[0]} total differs from qty x price - discount", "sale_lines")
        # --- genuine sub-penny precision on a line total
        sid = nxt()
        ln = c.execute("SELECT line_id, line_total FROM sale_lines WHERE sale_id=? ORDER BY line_id LIMIT 1", (sid,)).fetchone()
        c.execute("UPDATE sale_lines SET line_total=? WHERE line_id=?", (ln[1] + 0.004, ln[0]))
        self.plant("FLOAT_PRECISION", f"sales:{sid}", "FIXED", f"line {ln[0]} total {ln[1] + 0.004!r} has sub-penny precision", "sale_lines")
        # --- header total mismatches (header ignored: lines are authoritative)
        for _ in range(3):
            sid = nxt()
            c.execute("UPDATE sales SET total = total + 5.0 WHERE sale_id=?", (sid,))
            self.plant("HEADER_TOTAL_MISMATCH", f"sales:{sid}", "FIXED", "header total differs from the sum of its lines", "sales")
        # --- payment mismatch (short paid) and failed payment
        for _ in range(5):
            sid = nxt()
            pay = c.execute("SELECT payment_id, amount FROM payments WHERE sale_id=? ORDER BY payment_id LIMIT 1", (sid,)).fetchone()
            c.execute("UPDATE payments SET amount=? WHERE payment_id=?", (round(pay[1] - 2.0, 2) if pay[1] > 4 else 0.5, pay[0]))
            self.plant("PAYMENT_MISMATCH", f"sales:{sid}", "PRESERVED_AS_EXTRAS", "captured payments do not cover the sale total", "payments")
        for _ in range(2):
            sid = nxt()
            c.execute("UPDATE payments SET status='FAILED' WHERE sale_id=?", (sid,))
            self.plant("PAYMENT_MISMATCH", f"sales:{sid}", "PRESERVED_AS_EXTRAS", "no captured payment (all attempts FAILED)", "payments")
        # --- timestamps: invalid / future / DST fold / DST gap
        for bad in ("2025-02-30 10:15:00", "31/13/2025 09:00", "not-a-date"):
            sid = nxt()
            c.execute("UPDATE sales SET sold_at=? WHERE sale_id=?", (bad, sid))
            self.plant("INVALID_TIMESTAMP", f"sales:{sid}", "MANUAL", f"unparseable sold_at {bad!r}", "sales")
        sid = nxt()
        c.execute("UPDATE sales SET sold_at='2027-03-01 12:00:00' WHERE sale_id=?", (sid,))
        self.plant("FUTURE_TIMESTAMP", f"sales:{sid}", "MANUAL", "sold_at is in the future", "sales")
        for ts_, kind in (("2025-10-26 01:30:00", "AMBIGUOUS_LOCAL_TIME"), ("2026-10-25 01:15:00", "AMBIGUOUS_LOCAL_TIME"), ("2025-03-30 01:30:00", "NONEXISTENT_LOCAL_TIME")):
            sid = nxt()
            c.execute("UPDATE sales SET sold_at=? WHERE sale_id=?", (ts_, sid))
            self.plant(kind, f"sales:{sid}", "FIXED", f"naive local time {ts_} is a DST {'fold' if kind.startswith('AMB') else 'gap'}", "sales")
        # --- unknown channel, empty sale, refund larger than the sale
        sid = nxt()
        c.execute("UPDATE sales SET channel='KIOSK' WHERE sale_id=?", (sid,))
        self.plant("UNKNOWN_CHANNEL", f"sales:{sid}", "MANUAL", "channel KIOSK is not mapped", "sales")
        sid = nxt()
        c.execute("DELETE FROM sale_lines WHERE sale_id=?", (sid,))
        self.plant("EMPTY_RECORD", f"sales:{sid}", "EXCLUDED", "sale has no lines", "sales")
        sid = nxt()
        tot = c.execute("SELECT total FROM sales WHERE sale_id=?", (sid,)).fetchone()[0]
        ids["ret"] += 1
        ids["ref"] += 1
        c.execute("INSERT INTO returns VALUES (?,?,?,?,?)", (ids["ret"], sid, "2026-09-01 10:00:00", "faulty", "COMPLETE"))
        c.execute("INSERT INTO refunds VALUES (?,?,?,?,?,?)", (ids["ref"], ids["ret"], sid, round(tot + 25.0, 2), "DONE", "2026-09-01 10:00:00"))
        self.plant("REFUND_EXCEEDS_SALE", f"sales:{sid}", "MANUAL", "refunds exceed the sale net", "refunds")
        # --- void / open sales (out of scope, not exceptions)
        sid = self.max_sale
        for k in range(30):
            sid += 1
            c.execute("INSERT INTO sales VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, f"R{sid:07d}", "S001", "POS", None, "2026-03-03 11:00:00", "GBP", "VOID", "T1", "EMP101", 12.0, 0.0))
            ids["line"] += 1
            c.execute("INSERT INTO sale_lines VALUES (?,?,?,?,?,?,?,?)", (ids["line"], sid, 2, 1.0, "EA", 12.0, 0.0, 12.0))
        for k in range(2):
            sid += 1
            c.execute("INSERT INTO sales VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, f"R{sid:07d}", "S002", "POS", None, "2026-10-31 17:50:00", "GBP", "OPEN", "T2", "EMP102", 8.0, 0.0))
            ids["line"] += 1
            c.execute("INSERT INTO sale_lines VALUES (?,?,?,?,?,?,?,?)", (ids["line"], sid, 3, 1.0, "EA", 8.0, 0.0, 8.0))

    def gen_system_state(self) -> None:
        self.con.execute("INSERT INTO system_state VALUES (1, ?, 'SOURCE', 0, NULL, NULL, 0, ?, ?)",
                         (SOURCE_SYSTEM, AS_OF.strftime("%Y-%m-%dT%H:%M:%SZ"), f"synthetic legacy retail ERP (seed={self.seed})"))

    # ---- demo ids for the end-to-end demo
    def demo_manifest(self, counts: dict) -> dict:
        con = sqlite3.connect(self.path)
        stock = con.execute(
            "SELECT sku, location_code, on_hand FROM inventory_balances WHERE on_hand > 20 AND unit IS NULL AND location_code IN ('DC01','S001','S002') "
            "AND sku LIKE 'SKU-%' AND sku IN (SELECT sku FROM product_variants WHERE unit='EA') ORDER BY inv_id LIMIT 12").fetchall()
        con.close()
        return {
            "source_system": SOURCE_SYSTEM, "seed": self.seed, "row_counts": counts,
            "kettle": {"product_id": "PRD-KETTLE", "sku": "KETTLE-RED", "name": "Aureom Barista Kettle", "unit": "EA", "scarce": True,
                       "opening_stock": {"STORE-N-01": 2}, "price_minor": 3999, "currency": "GBP",
                       "open_po": {"po_id": "PO-2001", "supplier_id": "SUP-009", "location": "STORE-N-01", "status": "APPROVED", "outstanding_qty": 1, "unit_cost_minor": 1800}},
            "loyalty": {"customer_id": "CUST-DEMO01", "opening_points": 120},
            "promotions_native": ["PRM-PROMO-001", "PRM-PROMO-002", "PRM-PROMO-005"],
            "ordinary_stock_examples": [{"sku": s, "source_location": l, "on_hand": q} for s, l, q in stock],
            "location_map": {"S001": "STORE-N-01", "S002": "STORE-N-02", "S003": "STORE-S-01", "S004": "STORE-E-01", "DC01": "WH-DIST-01", "DC02": "WH-RET-01"},
        }


def generate(seed: int, out: str | Path) -> dict:
    return Gen(seed, Path(out)).build()


# ------------------------------------------------------------------ live-activity simulation

def simulate_activity(db_path: str | Path, seed: int = 7, n_sales: int = 25) -> dict:
    """Mutate the source like a live system between the master snapshot and the freeze.

    Everything goes through ordinary SQL so the change-log triggers (and, once frozen, the write-freeze triggers) fire."""
    rng = random.Random(seed)
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    out = {"new_sales": 0, "new_products": 0, "changed_products": 0, "refunds_on_old_sales": 0, "new_pos": 0, "loyalty_updates": 0}
    try:
        max_sale = con.execute("SELECT max(sale_id) FROM sales").fetchone()[0]
        max_line = con.execute("SELECT max(line_id) FROM sale_lines").fetchone()[0]
        max_pay = con.execute("SELECT max(payment_id) FROM payments").fetchone()[0]
        variants = con.execute("SELECT v.variant_id, v.sku, v.unit FROM product_variants v WHERE v.sku LIKE 'SKU-%' AND v.unit='EA' AND "
                               "v.sku NOT LIKE '%ORPHAN%' ORDER BY v.variant_id LIMIT 200").fetchall()
        prices = {r["sku"]: r["price"] for r in con.execute("SELECT sku, price FROM price_list_items WHERE list_id=1 AND valid_to IS NULL")}
        sid = max_sale
        for i in range(n_sales):
            sid += 1
            v = rng.choice(variants)
            price = round(prices.get(v["sku"], 9.99), 2)
            qty = float(rng.randint(1, 2))
            total = round(price * qty, 2)
            ts = f"2026-11-{rng.randint(2, 9):02d}T{rng.randint(9, 19):02d}:{rng.randint(0, 59):02d}:00Z"
            con.execute("INSERT INTO sales VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, f"R{sid:07d}", rng.choice(["S001", "S002", "S003"]), "POS", None, ts, "GBP", "COMPLETE", "T1", "EMP101", total, 0.0))
            max_line += 1
            con.execute("INSERT INTO sale_lines VALUES (?,?,?,?,?,?,?,?)", (max_line, sid, v["variant_id"], qty, "EA", price, 0.0, total))
            max_pay += 1
            con.execute("INSERT INTO payments VALUES (?,?,?,?,?,?,?)", (max_pay, sid, "CARD", total, "CAPTURED", ts, f"ch_{sid:07d}"))
            out["new_sales"] += 1
        # a brand-new product + variant + price + stock after the master snapshot
        pid = con.execute("SELECT max(product_id) FROM products").fetchone()[0] + 1
        vid = con.execute("SELECT max(variant_id) FROM product_variants").fetchone()[0] + 1
        con.execute("INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?)", (pid, f"PRD-{pid:05d}", "Aureom Pour-Over Dripper", "Aureom", 7, "SUP-009", "A", "2026-11-03 10:00:00", None, None))
        con.execute("INSERT INTO product_variants VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (vid, pid, "DRIPPER-WHT", ean13(900001), "EA", "EA", 0, "White", None, None, "A", None))
        item = con.execute("SELECT max(item_id) FROM price_list_items").fetchone()[0] + 1
        con.execute("INSERT INTO price_list_items VALUES (?,?,?,?,?,?,?)", (item, 1, "DRIPPER-WHT", 24.5, "2026-11-04 00:00:00", None, "new launch"))
        inv = con.execute("SELECT max(inv_id) FROM inventory_balances").fetchone()[0] + 1
        con.execute("INSERT INTO inventory_balances VALUES (?,?,?,?,?,?,?,?,?)", (inv, "DRIPPER-WHT", "DC01", "EA", 60.0, 0.0, 0.0, "N1", "2026-11-05 09:00:00"))
        out["new_products"] += 1
        # a product renamed after the master import -> cannot be updated through import: reported as CHANGED_AFTER_MASTER
        con.execute("UPDATE products SET name = name || ' (v2)' WHERE product_id=5")
        out["changed_products"] += 1
        # a refund booked against an already-imported old sale
        planted = set()
        pp = Path(str(db_path) + ".planted.json")
        if pp.exists():
            planted = {p["source_ref"] for p in json.loads(pp.read_text())}
        old = None
        for r in con.execute("SELECT sale_id, total FROM sales WHERE status='COMPLETE' AND sale_id BETWEEN 100 AND 900 AND total > 10 "
                             "AND sale_id NOT IN (SELECT sale_id FROM refunds WHERE sale_id IS NOT NULL) ORDER BY sale_id").fetchall():
            if f"sales:{r['sale_id']}" not in planted:
                old = r
                break
        rid = con.execute("SELECT coalesce(max(return_id),0) FROM returns").fetchone()[0] + 1
        fid = con.execute("SELECT coalesce(max(refund_id),0) FROM refunds").fetchone()[0] + 1
        con.execute("INSERT INTO returns VALUES (?,?,?,?,?)", (rid, old["sale_id"], "2026-11-06 12:00:00", "changed mind", "COMPLETE"))
        con.execute("INSERT INTO refunds VALUES (?,?,?,?,?,?)", (fid, rid, old["sale_id"], round(old["total"] / 2, 2), "DONE", "2026-11-06 12:00:00"))
        out["refunds_on_old_sales"] += 1
        # stock movements (volatile; opening balances are taken after the freeze)
        con.execute("UPDATE inventory_balances SET on_hand = on_hand + 5 WHERE inv_id IN (SELECT inv_id FROM inventory_balances WHERE unit IS NULL AND on_hand > 10 ORDER BY inv_id LIMIT 12)")
        # a new open purchase order
        con.execute("INSERT INTO purchase_orders VALUES (?,?,?,?,?,?,?,?,?,?)", ("PO-2050", "SUP-002", "DC01", "APPROVED", "GBP", "2026-11-05T08:00:00Z", None, None, "approver-hq", None))
        ln = con.execute("SELECT max(line_id) FROM purchase_order_lines").fetchone()[0] + 1
        con.execute("INSERT INTO purchase_order_lines VALUES (?,?,?,?,?,?,?)", (ln, "PO-2050", "DRIPPER-WHT", 40.0, 0.0, "EA", 9.0))
        out["new_pos"] += 1
        # loyalty movements
        for r in con.execute("SELECT customer_id FROM loyalty_accounts WHERE customer_id LIKE 'CUST-0001%' ORDER BY customer_id LIMIT 5").fetchall():
            con.execute("UPDATE loyalty_accounts SET points_balance = points_balance + 15 WHERE customer_id=?", (r[0],))
            out["loyalty_updates"] += 1
        con.commit()
    finally:
        con.close()
    return out


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "activity":
        p = argparse.ArgumentParser(prog="aureom_migration.synth activity")
        p.add_argument("--db", required=True)
        p.add_argument("--seed", type=int, default=7)
        p.add_argument("--sales", type=int, default=25)
        a = p.parse_args(argv[1:])
        print(json.dumps(simulate_activity(a.db, a.seed, a.sales), indent=2))
        return 0
    p = argparse.ArgumentParser(prog="aureom_migration.synth", description=__doc__.split("\n\n")[0])
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--out", default="migration/source/retail_source.sqlite")
    a = p.parse_args(argv)
    res = generate(a.seed, a.out)
    print(json.dumps(res, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
