"""Chain client: byte-compatible envelope signing, submission with finality, authoritative reads.

Wire format (docs/TRANSACTIONS.md, core/tx.go):

    envelope  = {"v":1,"body":"<base64 body bytes>","sig":"<base64 ed25519>","pub":"<base64 pubkey>"}
    preimage  = b"AUREOM-CHAINBASE/TX/v1" 0x00 network_id 0x00 body_bytes
    body      = JSON (the signer chooses the bytes; validators verify exactly those bytes - no canonicalisation needed)

Retry safety: every transaction the migration sends carries an idempotency reference derived from its batch id and a tx id
derived the same way.  Before sending we ask the chain whether ``idem/<signer>/<ref>`` already exists (=> already executed)
and which tx ids are already burned; after a timeout we ask ``tx/<id>`` instead of guessing.  A retry can therefore never
execute a batch twice (the chain also rejects a repeated batch_id and a repeated idempotency ref).

Two backends implement the same read/submit surface: ``GatewayBackend`` (the supported path: REST gateway) and
``CometRpcBackend`` (talks to a validator's CometBFT RPC directly; used for smoke tests and as a fallback).
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .util import MigrationError

SIG_DOMAIN = b"AUREOM-CHAINBASE/TX/v1"
MAX_TX_BYTES = 32 << 10  # core.Params.MaxTxBytes (ordinary transactions)
MAX_IMPORT_TX_BYTES = 900 << 10  # core.Params.MaxImportTxBytes (bulk ImportBatch)
BULK_TYPES = {"ImportBatch"}
SCHEMA_VERSION = 1

CODE_NAMES = {
    0: "OK", 1: "MALFORMED", 2: "TOO_LARGE", 3: "WRONG_NETWORK", 4: "UNKNOWN_TYPE", 5: "UNSUPPORTED_SCHEMA", 6: "INVALID_FIELD",
    101: "BAD_SIGNATURE", 201: "UNKNOWN_SIGNER", 202: "KEY_INACTIVE", 203: "EXPIRED", 210: "REPLAY", 211: "DUPLICATE_IDEMPOTENCY",
    301: "UNAUTHORIZED", 302: "SCOPE_VIOLATION", 303: "POLICY_VIOLATION", 401: "NOT_FOUND", 402: "ALREADY_EXISTS", 403: "VERSION_CONFLICT",
    404: "INSUFFICIENT", 405: "INVALID_STATE", 406: "LIMIT_EXCEEDED", 407: "INVALID_ARGUMENT", 408: "MIGRATION_WINDOW", 500: "INTERNAL",
}
CODE_REPLAY, CODE_DUP_IDEM, CODE_EXISTS = 210, 211, 402


# ------------------------------------------------------------------ signing


def encode_json(obj: Any) -> bytes:
    """Compact UTF-8 JSON, key order preserved - identical to Go's encoder for the types we send (no HTML escaping)."""
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def assert_no_floats(obj: Any, path: str = "payload") -> None:
    """Money and quantities are integers on the wire; a float here is a bug in the mapping."""
    if isinstance(obj, float):
        raise MigrationError(f"{path}: floating point number {obj!r} in a transaction payload")
    if isinstance(obj, dict):
        for k, v in obj.items():
            assert_no_floats(v, f"{path}.{k}")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            assert_no_floats(v, f"{path}[{i}]")


def build_body(*, tx_id: str, network_id: str, tx_type: str, signer: str, key_id: str, idempotency_ref: str, client_time_ms: int, payload: Any,
               expected_version: int | None = None, valid_until_height: int = 0, schema_version: int = SCHEMA_VERSION) -> dict[str, Any]:
    """Body fields in core.Body order (optional fields omitted exactly as the Go struct tags do)."""
    body: dict[str, Any] = {"tx_id": tx_id, "network_id": network_id, "type": tx_type, "schema_version": schema_version, "signer": signer,
                            "key_id": key_id, "idempotency_ref": idempotency_ref}
    if expected_version is not None:
        body["expected_version"] = expected_version
    body["client_time_ms"] = client_time_ms
    if valid_until_height:
        body["valid_until_height"] = valid_until_height
    body["payload"] = payload
    return body


def preimage(network_id: str, body_bytes: bytes) -> bytes:
    return SIG_DOMAIN + b"\x00" + network_id.encode("utf-8") + b"\x00" + body_bytes


@dataclass
class Signer:
    identity: str
    key_id: str
    seed: bytes

    def __post_init__(self) -> None:
        self._key = Ed25519PrivateKey.from_private_bytes(self.seed)
        self.pub = self._key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @property
    def pub_b64(self) -> str:
        return base64.b64encode(self.pub).decode()

    def sign(self, message: bytes) -> bytes:
        return self._key.sign(message)  # Ed25519 is deterministic: same bytes -> same signature


def load_signer(keys_dir: str | Path, identity: str) -> Signer:
    """Key files written by chainctl/netgen: {identity,key_id,seed_hex,pub_b64} in <net>/keys/<identity>.json."""
    p = Path(keys_dir) / f"{identity}.json"
    try:
        kf = json.loads(p.read_text())
    except OSError as e:
        raise MigrationError(f"cannot read key file {p}: {e}") from None
    s = Signer(kf.get("identity", identity), kf["key_id"], bytes.fromhex(kf["seed_hex"]))
    if kf.get("pub_b64") and kf["pub_b64"] != s.pub_b64:
        raise MigrationError(f"key file {p}: pub_b64 does not match the seed")
    return s


def sign_envelope(network_id: str, signer: Signer, body_bytes: bytes) -> bytes:
    sig = signer.sign(preimage(network_id, body_bytes))
    env = {"v": 1, "body": base64.b64encode(body_bytes).decode(), "sig": base64.b64encode(sig).decode(), "pub": signer.pub_b64}
    return encode_json(env)


def tx_hash_hex(wire: bytes) -> str:
    return hashlib.sha256(wire).hexdigest().upper()  # CometBFT tx hash = sha256(tx bytes)


# ------------------------------------------------------------------ errors / results


class TransportError(Exception):
    """Network failure, timeout or 5xx: the outcome is unknown - ask the chain before retrying."""


class ChainError(Exception):
    """The gateway/node answered with a definite error."""

    def __init__(self, message: str, status: int | None = None, code: str | None = None):
        super().__init__(message)
        self.status, self.code = status, code


class TxRejected(MigrationError):
    def __init__(self, tx_id: str, code: int, name: str, log: str, stage: str):
        super().__init__(f"transaction {tx_id} rejected at {stage}: {name} ({code}) {log}")
        self.tx_id, self.code, self.name, self.log, self.stage = tx_id, code, name, log, stage


@dataclass
class TxOutcome:
    tx_id: str
    status: str  # OK | ALREADY_DONE
    height: int = 0
    code: int = 0
    log: str = ""
    data: Any = None
    attempts: int = 1


# ------------------------------------------------------------------ backends


class GatewayBackend:
    """REST gateway (docs/API.md)."""

    kind = "gateway"

    def __init__(self, base_url: str, *, timeout: float = 60.0, session: requests.Session | None = None):
        self.base = base_url.rstrip("/")
        self.timeout = timeout
        self.s = session or requests.Session()

    def _req(self, method: str, path: str, **kw) -> Any:
        try:
            r = self.s.request(method, self.base + path, timeout=kw.pop("timeout", self.timeout), **kw)
        except (requests.ConnectionError, requests.Timeout) as e:
            raise TransportError(f"{method} {path}: {e}") from None
        if r.status_code >= 500 or r.status_code == 429:
            raise TransportError(f"{method} {path}: HTTP {r.status_code} {r.text[:200]}")
        try:
            body = r.json()
        except ValueError:
            raise ChainError(f"{method} {path}: HTTP {r.status_code} non-JSON response {r.text[:200]!r}", r.status_code) from None
        if r.status_code >= 400 and not (isinstance(body, dict) and "admission" in body):
            raise ChainError(f"{method} {path}: HTTP {r.status_code} {body.get('error', body) if isinstance(body, dict) else body}", r.status_code,
                             body.get("code") if isinstance(body, dict) else None)
        return body

    # ---- reads
    def network(self) -> dict:
        return self._req("GET", "/api/v1/network")

    def network_id(self) -> str:
        return self.network()["network_id"]

    def info(self) -> dict:
        return self._req("GET", "/api/v1/chain/info")

    def height(self) -> int:
        return int(self.info()["height"])

    def record(self, key: str, height: int | None = None) -> tuple[bool, Any]:
        params: dict[str, Any] = {"key": key}
        if height:
            params["height"] = height
        b = self._req("GET", "/api/v1/chain/record", params=params)
        return bool(b.get("found")), b.get("value")

    def scan(self, prefix: str, height: int | None = None, limit: int = 200) -> Iterator[tuple[str, Any]]:
        after = ""
        while True:
            params: dict[str, Any] = {"prefix": prefix, "limit": limit}
            if after:
                params["after"] = after
            if height:
                params["height"] = height
            b = self._req("GET", "/api/v1/chain/scan", params=params)
            for it in b.get("items") or []:
                yield it["key"], it["value"]
            after = b.get("next_after") or ""
            if not after:
                return

    def migration_state(self, height: int | None = None) -> dict:
        found, v = self.record("mig/state", height)
        if found:
            return v
        b = self._req("GET", "/api/v1/chain/migration")  # {"key","found","value","height"}
        return b.get("value", b) if isinstance(b, dict) else {}

    # ---- writes
    def submit(self, wire: bytes, *, wait: str = "final", timeout_ms: int = 30000) -> dict:
        body = self._req("POST", "/api/v1/tx/submit", json={"tx": json.loads(wire), "wait": wait, "timeout_ms": timeout_ms},
                         timeout=self.timeout + timeout_ms / 1000)
        return normalise_submit(body)

    def post_report(self, report_bytes: bytes) -> dict:
        return self._req("POST", "/api/v1/migration/reports", data=report_bytes, headers={"Content-Type": "application/json"})

    def list_reports(self) -> list[dict]:
        return self._req("GET", "/api/v1/migration/reports")


def normalise_submit(body: dict) -> dict:
    adm = body.get("admission") or {}
    fin = body.get("finalised")
    return {"tx_id": body.get("tx_id"), "tx_hash": body.get("tx_hash"), "admission": {"code": int(adm.get("code", 0)), "name": adm.get("name", ""), "log": adm.get("log", "")},
            "finalised": None if not fin else {"height": int(fin.get("height", 0)), "code": int(fin.get("code", 0)), "name": fin.get("code_name", ""),
                                               "log": fin.get("log", ""), "data": fin.get("data")}}


class CometRpcBackend:
    """Direct CometBFT RPC of one validator (broadcast_tx_sync + tx polling, abci_query /key and /prefix)."""

    kind = "cometbft-rpc"

    def __init__(self, rpc_url: str, *, timeout: float = 30.0, poll_interval: float = 0.25):
        self.base = rpc_url.rstrip("/")
        self.timeout = timeout
        self.poll = poll_interval
        self.s = requests.Session()

    def _rpc(self, path: str, params: dict[str, Any] | None = None) -> dict:
        try:
            r = self.s.get(self.base + path, params=params, timeout=self.timeout)
            j = r.json()
        except (requests.ConnectionError, requests.Timeout) as e:
            raise TransportError(f"GET {path}: {e}") from None
        except ValueError:
            raise TransportError(f"GET {path}: invalid JSON") from None
        if "error" in j:
            raise ChainError(f"{path}: {j['error']}")
        return j["result"]

    def network_id(self) -> str:
        return self._rpc("/status")["node_info"]["network"]

    def height(self) -> int:
        return int(self._rpc("/status")["sync_info"]["latest_block_height"])

    def info(self) -> dict:
        return {"height": self.height(), "chain_id": self.network_id()}

    def _query(self, path: str, data: bytes, height: int | None) -> Any:
        params = {"path": f'"{path}"', "data": "0x" + data.hex(), "prove": "false"}
        if height:
            params["height"] = str(height)
        resp = self._rpc("/abci_query", params)["response"]
        if int(resp.get("code", 0)) != 0:
            raise ChainError(f"abci_query {path}: {resp.get('log')}")
        return resp.get("value")

    def record(self, key: str, height: int | None = None) -> tuple[bool, Any]:
        v = self._query("/key", key.encode(), height)
        if not v:
            return False, None
        return True, json.loads(base64.b64decode(v))

    def scan(self, prefix: str, height: int | None = None, limit: int = 200) -> Iterator[tuple[str, Any]]:
        after = ""
        while True:
            q = json.dumps({"prefix": prefix, "after": after, "limit": limit}).encode()
            v = self._query("/prefix", q, height)
            items = json.loads(base64.b64decode(v)) if v else []
            for it in items or []:
                yield it["key"], it["value"]
            if not items or len(items) < limit:
                return
            after = items[-1]["key"]

    def migration_state(self, height: int | None = None) -> dict:
        return self.record("mig/state", height)[1]

    def submit(self, wire: bytes, *, wait: str = "final", timeout_ms: int = 30000) -> dict:
        res = self._rpc("/broadcast_tx_sync", {"tx": "0x" + wire.hex()})
        adm = {"code": int(res.get("code", 0)), "name": CODE_NAMES.get(int(res.get("code", 0)), ""), "log": res.get("log", "")}
        out = {"tx_id": None, "tx_hash": res.get("hash"), "admission": adm, "finalised": None}
        if adm["code"] != 0 or wait == "none":
            return out
        h = tx_hash_hex(wire)
        deadline = time.time() + timeout_ms / 1000
        while time.time() < deadline:
            try:
                r = self._rpc("/tx", {"hash": "0x" + h})
            except ChainError:
                time.sleep(self.poll)
                continue
            tr = r["tx_result"]
            out["finalised"] = {"height": int(r["height"]), "code": int(tr.get("code", 0)), "name": CODE_NAMES.get(int(tr.get("code", 0)), ""),
                                "log": tr.get("log", ""), "data": json.loads(base64.b64decode(tr["data"])) if tr.get("data") else None}
            return out
        return out

    def post_report(self, report_bytes: bytes) -> dict:
        raise ChainError("the CometBFT RPC backend has no migration report store; use the gateway")


# ------------------------------------------------------------------ high level client


class ChainClient:
    def __init__(self, backend: GatewayBackend | CometRpcBackend, network_id: str, keys_dir: str | Path | None = None, *,
                 clock: Callable[[], float] = time.time, sleep: Callable[[float], None] = time.sleep, wait_timeout_ms: int = 30000, signers: dict[str, Signer] | None = None):
        self.backend = backend
        self.network_id = network_id
        self.keys_dir = keys_dir
        self.clock = clock
        self.sleep = sleep
        self.wait_timeout_ms = wait_timeout_ms
        self._signers: dict[str, Signer] = dict(signers or {})

    def signer(self, identity: str) -> Signer:
        if identity not in self._signers:
            if self.keys_dir is None:
                raise MigrationError(f"no key directory configured; cannot sign as {identity}")
            self._signers[identity] = load_signer(self.keys_dir, identity)
        return self._signers[identity]

    # ---- state lookups used for idempotency
    def idem_record(self, signer: str, ref: str) -> dict | None:
        found, v = self.backend.record(f"idem/{signer}/{ref}")
        return v if found else None

    def tx_record(self, tx_id: str) -> dict | None:
        found, v = self.backend.record(f"tx/{tx_id}")
        return v if found else None

    def batch_record(self, batch_id: str) -> dict | None:
        found, v = self.backend.record(f"mig/batch/{batch_id}")
        return v if found else None

    def fresh_tx_id(self, base: str) -> str:
        """First ``<base>-NN`` not yet burned on chain (a tx REJECTED after stage 3 burns its id)."""
        for n in range(100):
            tid = f"{base}-{n:02d}"
            if self.tx_record(tid) is None:
                return tid
        raise MigrationError(f"too many rejected attempts for {base}")

    # ---- submission
    def build_wire(self, identity: str, tx_type: str, payload: Any, *, tx_id: str, idempotency_ref: str) -> bytes:
        assert_no_floats(payload)
        s = self.signer(identity)
        body = build_body(tx_id=tx_id, network_id=self.network_id, tx_type=tx_type, signer=s.identity, key_id=s.key_id, idempotency_ref=idempotency_ref,
                          client_time_ms=int(self.clock() * 1000), payload=payload)
        wire = sign_envelope(self.network_id, s, encode_json(body))
        limit = MAX_IMPORT_TX_BYTES if tx_type in BULK_TYPES else MAX_TX_BYTES
        if len(wire) > limit:
            raise MigrationError(f"{tx_type} envelope is {len(wire)} bytes, over the chain limit of {limit}")
        return wire

    def send_idempotent(self, identity: str, tx_type: str, payload: Any, *, idem_ref: str, id_base: str, max_attempts: int = 6) -> TxOutcome:
        """Execute a transaction EXACTLY ONCE on chain, however often this is called or retried."""
        s = self.signer(identity)
        prev = self.idem_record(s.identity, idem_ref)
        if prev is not None:
            return TxOutcome(prev.get("tx_id", ""), "ALREADY_DONE", int(prev.get("height", 0)))
        tx_id = self.fresh_tx_id(id_base)
        wire = self.build_wire(identity, tx_type, payload, tx_id=tx_id, idempotency_ref=idem_ref)  # the SAME bytes are re-sent on retry
        last_err: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                res = self.backend.submit(wire, wait="final", timeout_ms=self.wait_timeout_ms)
            except TransportError as e:
                last_err = e
                st = self._settle(tx_id)
                if st is not None:
                    return self._outcome(tx_id, st, attempt)
                self.sleep(min(0.5 * 2 ** (attempt - 1), 8))
                continue
            adm = res["admission"]
            if adm["code"] != 0:
                if adm["code"] in (CODE_REPLAY, CODE_DUP_IDEM):  # a previous attempt of ours already got in
                    st = self._settle(tx_id)
                    if st is not None:
                        return self._outcome(tx_id, st, attempt)
                    prev = self.idem_record(s.identity, idem_ref)
                    if prev is not None:
                        return TxOutcome(prev.get("tx_id", ""), "ALREADY_DONE", int(prev.get("height", 0)), attempts=attempt)
                raise TxRejected(tx_id, adm["code"], adm["name"] or CODE_NAMES.get(adm["code"], ""), adm["log"], "admission (CheckTx)")
            fin = res["finalised"]
            if fin is None:  # still pending: wait on the authoritative record, then (if unknown) resend the identical bytes
                st = self._settle(tx_id, wait_s=self.wait_timeout_ms / 1000)
                if st is not None:
                    return self._outcome(tx_id, st, attempt)
                continue
            if fin["code"] != 0:
                raise TxRejected(tx_id, fin["code"], fin["name"] or CODE_NAMES.get(fin["code"], ""), fin["log"], "execution (finalised, no state change)")
            return TxOutcome(tx_id, "OK", fin["height"], 0, fin["log"], fin.get("data"), attempt)
        raise MigrationError(f"transaction {tx_id} not finalised after {max_attempts} attempts: {last_err}")

    def _settle(self, tx_id: str, wait_s: float = 0.0) -> dict | None:
        deadline = self.clock() + wait_s
        while True:
            try:
                rec = self.tx_record(tx_id)
            except TransportError:
                rec = None
            if rec is not None:
                return rec
            if self.clock() >= deadline:
                return None
            self.sleep(0.5)

    @staticmethod
    def _outcome(tx_id: str, rec: dict, attempts: int) -> TxOutcome:
        if rec.get("status") == "OK":
            return TxOutcome(tx_id, "OK", int(rec.get("height", 0)), 0, "", None, attempts)
        raise TxRejected(tx_id, int(rec.get("code", 0)), rec.get("code_name", ""), rec.get("reason", ""), "execution (finalised, no state change)")

    # ---- migration helpers
    def submit_batch(self, batch) -> TxOutcome:
        """ImportBatch signed by migration-op.  Skips a batch that is already on chain."""
        existing = self.batch_record(batch.batch_id)
        if existing is not None:
            if int(existing.get("records", -1)) != len(batch.records) or existing.get("entity") != batch.entity or int(existing.get("seq", -1)) != batch.seq:
                raise MigrationError(f"batch {batch.batch_id} is on chain with a different shape ({existing}); the batch sizing or the plan changed - refusing to continue")
            return TxOutcome(existing.get("tx", ""), "ALREADY_DONE", int(existing.get("height", 0)))
        return self.send_idempotent("migration-op", "ImportBatch", batch.payload(), idem_ref=f"imp-{batch.batch_id}", id_base=f"mb-{batch.batch_id[2:34]}")

    def migration_control(self, action: str, *, source_system: str, manifest_hash: str = "", report_hash: str = "", freeze_marker: str = "", totals: dict[str, int] | None = None,
                          idem_suffix: str = "") -> TxOutcome:
        payload = {"action": action, "source_system": source_system, "manifest_hash": manifest_hash, "report_hash": report_hash,
                   "source_freeze_marker": freeze_marker, "totals": dict(sorted((totals or {}).items()))}
        key = hashlib.sha256(f"{action}|{source_system}|{manifest_hash}|{report_hash}|{freeze_marker}|{idem_suffix}".encode()).hexdigest()[:24]
        return self.send_idempotent("migration-op", "MigrationControl", payload, idem_ref=f"mig-{action.lower()}-{key}", id_base=f"mc-{action.lower()}-{key}")

    def activate_promotion(self, payload: dict, version_tag: str) -> TxOutcome:
        pid = payload["promo_id"]
        found, _ = self.backend.record(f"promo/{pid}")
        key = hashlib.sha256(f"{pid}|{version_tag}".encode()).hexdigest()[:20]
        if found:
            return TxOutcome("", "ALREADY_DONE")
        return self.send_idempotent("pricing-mgr", "ActivatePromotion", payload, idem_ref=f"promo-{pid}-{key}"[:95], id_base=f"mp-{key}")
