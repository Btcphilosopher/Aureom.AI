"""Controlled cutover: the phased procedure and its state machine.

ONE system is authoritative at every stage - and never two:

    stage          source (system_state)          chain window     authoritative   what is allowed
    SOURCE_LIVE    SOURCE, writable               NOT_STARTED      SOURCE          master
    MASTER_DONE    SOURCE, writable               OPEN             SOURCE          freeze (the chain only holds imported history/master data)
    FROZEN         NONE_FROZEN, writes aborted    OPEN             FROZEN          opening        (nobody may write: a bounded outage)
    OPENING_DONE   NONE_FROZEN                    OPEN             FROZEN          reconcile
    RECONCILED     NONE_FROZEN                    OPEN             FROZEN          cutover (needs a final report with decision ACCEPT)
    CUTOVER_DONE   CHAIN, frozen read-only archive CLOSED          CHAIN           (corrections: compensating chain transactions only)
    ABORTED        SOURCE, writable again         OPEN (orphaned)  SOURCE          (start over on a fresh chain - see docs/MIGRATION.md)

Commands: master | freeze | opening | reconcile | cutover | abort | status.  Every command is resumable and idempotent: batches are
skipped when ``mig/batch/<id>`` is already on chain, transactions carry idempotency refs derived from batch ids.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .batching import Batch, make_batches, manifest, manifest_hash
from .chainclient import ChainClient, TxRejected
from .checks import MANUAL
from .delta import RECORD_ENTITIES, Delta, apply_delta
from .mapping import Spec
from .plan import Plan, build_plan, expected_counters
from .reconcile import FAIL, PASS, WARN, ChainView, Expected, _chk, compare, flag_check, read_chain_view
from .report import build_report, decide, quality_checks, report_bytes, report_sha256, to_markdown
from .snapshot import SnapshotInfo, SourceControl, freeze_marker as compute_marker, take_snapshot, verify_snapshot
from .util import SYSTEM_CLOCK, Clock, MigrationError, atomic_write, iso_now, read_json, sha256_file, write_json

STAGES = ("SOURCE_LIVE", "MASTER_DONE", "FROZEN", "OPENING_DONE", "RECONCILED", "CUTOVER_DONE", "ABORTED")
AUTH_BY_STAGE = {"SOURCE_LIVE": "SOURCE", "MASTER_DONE": "SOURCE", "FROZEN": "FROZEN", "OPENING_DONE": "FROZEN", "RECONCILED": "FROZEN",
                 "CUTOVER_DONE": "CHAIN", "ABORTED": "SOURCE"}
TRANSITIONS: dict[str, dict[str, str]] = {
    "master": {"SOURCE_LIVE": "MASTER_DONE", "MASTER_DONE": "MASTER_DONE"},
    "freeze": {"MASTER_DONE": "FROZEN", "FROZEN": "FROZEN"},
    "opening": {"FROZEN": "OPENING_DONE", "OPENING_DONE": "OPENING_DONE"},
    "reconcile-master": {"MASTER_DONE": "MASTER_DONE"},
    "reconcile-final": {"OPENING_DONE": "RECONCILED", "RECONCILED": "RECONCILED"},
    "cutover": {"RECONCILED": "CUTOVER_DONE"},
    "unfreeze": {"FROZEN": "MASTER_DONE"},  # rollback of the source freeze, only while nothing of the opening phase is on chain
    "abort": {s: "ABORTED" for s in ("SOURCE_LIVE", "MASTER_DONE", "FROZEN", "OPENING_DONE", "RECONCILED")},
}
NEXT_HINT = {"SOURCE_LIVE": "master", "MASTER_DONE": "reconcile --phase master, then freeze", "FROZEN": "opening (or unfreeze to roll the freeze back)", "OPENING_DONE": "reconcile --phase final",
             "RECONCILED": "cutover", "CUTOVER_DONE": "(done) corrections are compensating chain transactions", "ABORTED": "start over on a fresh chain"}


def next_stage(command: str, stage: str) -> str:
    """Pure state-machine step: the stage after ``command`` from ``stage`` or MigrationError when the command is not allowed."""
    t = TRANSITIONS.get(command, {})
    if stage not in t:
        allowed = [c for c, m in TRANSITIONS.items() if stage in m]
        raise MigrationError(f"command {command!r} is not allowed in stage {stage}; allowed now: {', '.join(allowed) or 'none'}")
    return t[stage]


def derive_authority(source_authoritative: str, frozen: int | bool, archived: int | bool, chain_status: str | None) -> tuple[str, str]:
    """Which system is authoritative, judged from the two REAL control records (source system_state + chain mig/state).

    Returns (authoritative_system, consistency note).  consistency starts with CONSISTENT or says what is wrong."""
    cs = chain_status or "UNKNOWN"
    if source_authoritative == "SOURCE" and not frozen:
        if cs in ("NOT_STARTED", "OPEN", "UNKNOWN"):
            return "SOURCE", "CONSISTENT"
        return "SOURCE", f"INCONSISTENT: the chain window is {cs} but the source still says it is authoritative and writable"
    if source_authoritative == "NONE_FROZEN" and frozen:
        if cs == "OPEN":
            return "FROZEN", "CONSISTENT"
        if cs == "CLOSED":
            return "FROZEN", "CUTOVER IN PROGRESS: the chain window is CLOSED but the source flip to CHAIN is pending - re-run `cutover`"
        return "FROZEN", f"INCONSISTENT: the source is frozen but the chain window is {cs}"
    if source_authoritative == "CHAIN" and archived:
        if cs == "CLOSED":
            return "CHAIN", "CONSISTENT"
        return "CHAIN", f"INCONSISTENT: the source says CHAIN but the chain window is {cs}"
    return "UNKNOWN", f"INCONSISTENT: source authoritative_system={source_authoritative!r} frozen={frozen} archived={archived}; chain window {cs}"


@dataclass
class Config:
    workdir: Path
    source_db: Path
    spec: Spec
    network_id: str
    trial: bool = False
    clock: Clock = field(default_factory=lambda: SYSTEM_CLOCK)
    log: Callable[[str], None] = print
    max_records: int | None = None
    max_envelope_bytes: int | None = None
    report_backends: list = field(default_factory=list)  # extra gateways that also receive the reports (trial reports -> production dashboard)


class Migration:
    def __init__(self, cfg: Config, backend, chain: ChainClient):
        self.cfg = cfg
        self.spec = cfg.spec
        self.backend = backend
        self.chain = chain
        self.workdir = Path(cfg.workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.workdir / "state.json"
        self.source = SourceControl(cfg.source_db)
        self.log = cfg.log
        self.state = self._load()
        self._plans: dict[str, Plan] = {}
        self._final_cache: tuple | None = None

    # ================================================================== state
    def _load(self) -> dict[str, Any]:
        if self.state_path.exists():
            return read_json(self.state_path)
        return {"version": 1, "network_id": self.cfg.network_id, "source_system": self.spec.source_system, "source_db": str(self.cfg.source_db), "mapping_version": self.spec.version,
                "mapping_sha256": self.spec.sha256, "stage": "SOURCE_LIVE", "trial": self.cfg.trial, "master_snapshot": None, "final_snapshot": None, "freeze_marker": None,
                "write_freeze_verified": False, "open_manifest_hash": None, "sizing": None, "batches": [], "promotions": [], "reports": [], "final_report": None, "ack": None,
                "history": [], "created_at": iso_now(self.cfg.clock)}

    def _save(self) -> None:
        write_json(self.state_path, self.state)

    def _event(self, what: str, **kw: Any) -> None:
        self.state["history"].append({"at": iso_now(self.cfg.clock), "event": what, **kw})
        self._save()

    def _transition(self, command: str) -> None:
        new = next_stage(command, self.state["stage"])
        if new != self.state["stage"]:
            self._event("stage", **{"from": self.state["stage"], "to": new, "command": command})
            self.state["stage"] = new
            self._save()

    @property
    def stage(self) -> str:
        return self.state["stage"]

    def _guard_identity(self) -> None:
        if self.state["network_id"] != self.cfg.network_id:
            raise MigrationError(f"this work directory belongs to network {self.state['network_id']!r}, not {self.cfg.network_id!r}")
        if self.state["mapping_sha256"] != self.spec.sha256:
            raise MigrationError(f"the mapping spec changed since the migration started (sha256 {self.spec.sha256[:12]} != {self.state['mapping_sha256'][:12]}); a changed mapping needs a new mapping_version "
                                 f"and a fresh migration - see docs/MIGRATION.md 'Re-run after fixing the mapping'")

    # ================================================================== plans / batches
    def _snap(self, which: str) -> SnapshotInfo:
        d = self.state.get(f"{which}_snapshot")
        if not d:
            raise MigrationError(f"no {which} snapshot yet")
        info = SnapshotInfo.from_dict(d)
        verify_snapshot(info)
        return info

    def _plan(self, info: SnapshotInfo) -> Plan:
        if info.snapshot_id not in self._plans:
            self._plans[info.snapshot_id] = build_plan(info.path, self.spec, snapshot_id=info.snapshot_id, reference_ms=info.taken_at_ms)
        return self._plans[info.snapshot_id]

    def _sizing(self) -> dict[str, int]:
        if not self.state["sizing"]:
            b = self.spec.batching
            self.state["sizing"] = {"max_records": int(self.cfg.max_records or b["max_records"]), "max_envelope_bytes": int(self.cfg.max_envelope_bytes or b["max_envelope_bytes"])}
            self._save()
        elif (self.cfg.max_records and self.cfg.max_records != self.state["sizing"]["max_records"]) or (self.cfg.max_envelope_bytes and self.cfg.max_envelope_bytes != self.state["sizing"]["max_envelope_bytes"]):
            raise MigrationError("batch sizing is pinned at the first import (it determines which records share a batch id); refusing to change it mid-migration")
        return self.state["sizing"]

    def _make(self, entity: str, records: list[dict], info: SnapshotInfo, phase: str) -> list[Batch]:
        sz = self._sizing()
        return make_batches(entity, records, snapshot_id=info.snapshot_id, mapping_version=self.spec.version, source_system=self.spec.source_system,
                            max_records=sz["max_records"], max_envelope_bytes=sz["max_envelope_bytes"], phase=phase)

    def master_batches(self, plan: Plan, info: SnapshotInfo) -> list[Batch]:
        out: list[Batch] = []
        for ent in self.spec.phase_entities("master"):
            if ent != "PROMOTION":
                out += self._make(ent, plan.records.get(ent, []), info, "master")
        return out

    def final_batches(self, final: Plan, delta: Delta, info: SnapshotInfo) -> tuple[list[Batch], list[Batch]]:
        delta_b: list[Batch] = []
        for ent in self.spec.phase_entities("master"):
            if ent != "PROMOTION":
                delta_b += self._make(ent, delta.new.get(ent, []), info, "opening-delta")
        open_b: list[Batch] = []
        for ent in self.spec.phase_entities("opening"):
            open_b += self._make(ent, final.records.get(ent, []), info, "opening")
        return delta_b, open_b

    def _final_plan(self) -> tuple[Plan, Delta, SnapshotInfo, SnapshotInfo, Plan]:
        """Final plan with the delta applied (effective chain content).  Deterministic, so it is cached per process (it is read-only after this)."""
        minfo, finfo = self._snap("master"), self._snap("final")
        key = (minfo.snapshot_id, finfo.snapshot_id)
        if self._final_cache is None or self._final_cache[0] != key:
            master = self._plan(minfo)
            final = build_plan(finfo.path, self.spec, snapshot_id=finfo.snapshot_id, reference_ms=finfo.taken_at_ms)
            delta = apply_delta(master, final)
            self._final_cache = (key, final, delta, master)
        _, final, delta, master = self._final_cache
        return final, delta, minfo, finfo, master

    # ================================================================== chain helpers
    def _chain_status(self) -> dict[str, Any]:
        return self.backend.migration_state() or {}

    def _ensure_window_open(self, mh: str) -> None:
        ms = self._chain_status()
        status = ms.get("status")
        if status == "NOT_STARTED":
            out = self.chain.migration_control("OPEN", source_system=self.spec.source_system, manifest_hash=mh)
            self.log(f"migration window OPENED on chain (tx {out.tx_id}, height {out.height})")
            self._event("window-open", tx_id=out.tx_id, height=out.height, manifest_hash=mh)
        elif status == "OPEN":
            if ms.get("source_system") != self.spec.source_system:
                raise MigrationError(f"the chain window is open for source system {ms.get('source_system')!r}, not {self.spec.source_system!r}")
            if ms.get("open_manifest_hash") and ms["open_manifest_hash"] != mh:
                raise MigrationError("the chain window was opened with a different master manifest (different snapshot/mapping/sizing); this work directory cannot continue it - see docs/MIGRATION.md recovery")
            self.log("migration window already OPEN with this manifest (resuming)")
        else:
            raise MigrationError(f"the chain's migration window is {status}; a closed window cannot be reopened (start a fresh network)")

    def _record_batch(self, b: Batch, status: str, tx_id: str = "", height: int | None = None, log: str = "") -> None:
        entry = {**b.descriptor(), "tx_id": tx_id, "height": height, "status": status, "log": log}
        for i, e in enumerate(self.state["batches"]):
            if e["batch_id"] == b.batch_id:
                self.state["batches"][i] = entry
                break
        else:
            self.state["batches"].append(entry)
        self._save()

    def _submit(self, batches: list[Batch], label: str) -> None:
        total = len(batches)
        for i, b in enumerate(batches, 1):
            try:
                out = self.chain.submit_batch(b)
            except TxRejected as e:
                self._record_batch(b, "REJECTED", e.tx_id, None, f"{e.name}: {e.log}")
                raise MigrationError(f"batch {b.batch_id} ({b.entity} #{b.seq}) was REJECTED by the chain: {e.name} - {e.log}") from e
            self._record_batch(b, "FINALISED", out.tx_id, out.height)
            self.log(f"[{label}] {i}/{total} {b.entity} #{b.seq}: {len(b.records)} records -> {'already on chain (skipped)' if out.status == 'ALREADY_DONE' else 'finalised at height %d' % out.height}")

    def _submit_promotions(self, promos: list[dict]) -> None:
        for p in promos:
            payload = {k: v for k, v in p.items() if not k.startswith("_")}
            try:
                out = self.chain.activate_promotion(payload, self.spec.version)
            except TxRejected as e:
                raise MigrationError(f"ActivatePromotion {payload['promo_id']} was REJECTED: {e.name} - {e.log}") from e
            entry = {"promo_id": payload["promo_id"], "tx_id": out.tx_id, "height": out.height, "status": "FINALISED"}
            self.state["promotions"] = [x for x in self.state["promotions"] if x["promo_id"] != payload["promo_id"]] + [entry]
            self._save()
            self.log(f"[promotions] {payload['promo_id']} ({payload['type']}) -> {'already on chain' if out.status == 'ALREADY_DONE' else 'finalised at height %d' % out.height} (signed by pricing-mgr)")

    def _require_gate(self, plan: Plan) -> None:
        if plan.gate and not plan.gate.ok:
            bad = [f"{e.kind} {e.source_ref}" for e in plan.gate.exceptions if e.kind.startswith(("UNMAPPED", "MAPPED_", "SOURCE_SYSTEM"))]
            raise MigrationError("schema gate FAILED - the source schema does not match the mapping spec (a column must never be dropped silently):\n  " + "\n  ".join(bad[:20]))

    # ================================================================== commands
    def master(self) -> dict[str, Any]:
        self._guard_identity()
        next_stage("master", self.stage)
        src = self.source.state()
        if src.get("authoritative_system") != "SOURCE" or src.get("frozen"):
            raise MigrationError(f"master phase needs the live source: authoritative_system={src.get('authoritative_system')} frozen={src.get('frozen')}")
        if not self.state["master_snapshot"]:
            info = take_snapshot(self.cfg.source_db, self.workdir / "snapshots", "master", self.cfg.clock)
            self.state["master_snapshot"] = info.to_dict()
            self._event("master-snapshot", snapshot_id=info.snapshot_id, sha256=info.sha256)
            self.log(f"master snapshot {info.snapshot_id} (sha256 {info.sha256[:16]}...) rows: {sum(info.row_counts.values())}")
        info = self._snap("master")
        plan = self._plan(info)
        self._require_gate(plan)
        batches = self.master_batches(plan, info)
        mh = manifest_hash(batches)
        self._ensure_window_open(mh)
        self.state["open_manifest_hash"] = mh
        self._save()
        for ent in self.spec.phase_entities("master"):
            if ent == "PROMOTION":
                self._submit_promotions(plan.promotions)
            else:
                self._submit([b for b in batches if b.entity == ent], f"master/{ent}")
        self._transition("master")
        self.log(f"master phase complete: {len(batches)} batches + {len(plan.promotions)} promotions; authoritative system is still the SOURCE")
        return {"batches": len(batches), "promotions": len(plan.promotions), "exceptions": plan.exceptions.by_kind()}

    def freeze(self) -> dict[str, Any]:
        self._guard_identity()
        next_stage("freeze", self.stage)
        if self.stage == "MASTER_DONE":
            m = self.source.freeze(self.cfg.clock)
            self.state["freeze_marker"] = m["freeze_marker"]
            self.state["freeze_detail"] = m
            self._transition("freeze")
            self.log(f"source FROZEN (authoritative_system=NONE_FROZEN); freeze marker {m['freeze_marker'][:16]}... (change log high-water {m['high_water']}, {m['rows']} rows)")
        else:
            self.log("source already frozen (resuming)")
        if not self.state["write_freeze_verified"]:
            self.state["write_freeze_verified"] = self.source.verify_write_freeze()
            self._save()
            if not self.state["write_freeze_verified"]:
                raise MigrationError("the source accepted a write while frozen: the write-freeze is NOT enforced - stop and investigate")
            self.log("write-freeze verified: a test write to the source was refused by its own triggers")
        if not self.state["final_snapshot"]:
            info = take_snapshot(self.cfg.source_db, self.workdir / "snapshots", "final", self.cfg.clock)
            marker = compute_marker(self.spec.source_system, info.marker)
            if marker != self.state["freeze_marker"]:
                raise MigrationError("the final snapshot's change-log marker differs from the freeze marker: the source changed between the freeze and the snapshot")
            if not info.system_state.get("frozen"):
                raise MigrationError("the final snapshot was taken from a source that is not frozen")
            self.state["final_snapshot"] = info.to_dict()
            self._event("final-snapshot", snapshot_id=info.snapshot_id, sha256=info.sha256)
            self.log(f"final snapshot {info.snapshot_id} taken from the frozen source (marker matches)")
        return {"freeze_marker": self.state["freeze_marker"], "final_snapshot": self.state["final_snapshot"]["snapshot_id"]}

    def opening(self) -> dict[str, Any]:
        self._guard_identity()
        next_stage("opening", self.stage)
        live = self.source.marker()
        if live["freeze_marker"] != self.state["freeze_marker"]:
            raise MigrationError("the source change log moved since the freeze marker was recorded - refusing to import an opening position from a source that changed")
        final, delta, minfo, finfo, master = self._final_plan()
        self._require_gate(final)
        self._ensure_window_open(self.state["open_manifest_hash"])
        delta_b, open_b = self.final_batches(final, delta, finfo)
        self.log(f"delta since the master snapshot: {delta.summary()}")
        for ent in self.spec.phase_entities("master"):
            if ent == "PROMOTION":
                self._submit_promotions(delta.new_promotions)
            else:
                self._submit([b for b in delta_b if b.entity == ent], f"opening/delta/{ent}")
        for ent in self.spec.phase_entities("opening"):
            self._submit([b for b in open_b if b.entity == ent], f"opening/{ent}")
        self.state["delta_summary"] = delta.summary()
        self._transition("opening")
        self.log(f"opening phase complete: {len(delta_b)} delta batches + {len(open_b)} opening batches")
        return {"delta": delta.summary(), "delta_batches": len(delta_b), "opening_batches": len(open_b)}

    # ------------------------------------------------------------------ reconciliation
    def _expected(self, phase: str) -> tuple[Expected, Plan, SnapshotInfo, list[Batch]]:
        if phase == "master":
            info = self._snap("master")
            plan = self._plan(info)
            batches = self.master_batches(plan, info)
            recs = {e: plan.records.get(e, []) for e in RECORD_ENTITIES}
            return Expected(recs, plan.promotions, [b.descriptor() for b in batches], self.spec.source_system, self.spec.version), plan, info, batches
        final, delta, minfo, finfo, master = self._final_plan()
        mb = self.master_batches(master, minfo)
        db, ob = self.final_batches(final, delta, finfo)
        recs = {e: final.records.get(e, []) for e in (*RECORD_ENTITIES, "OPENING_BALANCE", "OPEN_PO", "LOYALTY_OPENING")}
        batches = mb + db + ob
        return Expected(recs, final.promotions, [b.descriptor() for b in batches], self.spec.source_system, self.spec.version), final, finfo, batches

    def _source_checks(self, phase: str, info: SnapshotInfo, authoritative_expected: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        actual_sha = sha256_file(info.path)
        out.append(flag_check("source snapshot integrity (sha256 of the snapshot file)", info.sha256, actual_sha, f"{info.snapshot_id}: the file hash must be unchanged since it was taken"))
        out.append(flag_check("mapping spec unchanged since the migration started", self.state["mapping_sha256"], self.spec.sha256, self.spec.version))
        src = self.source.state()
        ms = self._chain_status()
        auth, note = derive_authority(src.get("authoritative_system"), src.get("frozen"), src.get("archived"), ms.get("status"))
        out.append(flag_check("exactly one authoritative system", authoritative_expected, auth,
                              f"source system_state.authoritative_system={src.get('authoritative_system')} frozen={src.get('frozen')} archived={src.get('archived')}; chain window {ms.get('status')}; {note}",
                              ok=(auth == authoritative_expected and note == "CONSISTENT")))
        if phase in ("final", "post-cutover"):
            live = self.source.marker()
            fm = self.state.get("freeze_marker") or ""
            out.append(flag_check("source freeze marker unchanged (no write since the freeze)", fm, live["freeze_marker"], f"change-log high-water {live['high_water']} ({live['rows']} rows)", ok=bool(fm) and live["freeze_marker"] == fm))
            out.append(flag_check("write-freeze enforced on the source", True, bool(self.state.get("write_freeze_verified")), "a test write was refused by the source's own triggers"))
            if self.state.get("final_snapshot"):
                fs = self.state["final_snapshot"]
                out.append(flag_check("final snapshot was taken at the freeze marker", fm, compute_marker(self.spec.source_system, fs["marker"]), f"snapshot {fs['snapshot_id']}"))
        return out

    def _batches_for_report(self) -> list[dict[str, Any]]:
        return [{"batch_id": b["batch_id"], "entity": b["entity"], "seq": b["seq"], "records": b["records"], "tx_id": b.get("tx_id", ""), "height": b.get("height"),
                 "status": b.get("status", "")} for b in sorted(self.state["batches"], key=lambda x: (x.get("phase", ""), x["entity"], x["seq"]))]

    def reconcile(self, phase: str | None = None, *, ack: dict[str, Any] | None = None, post: bool = True, authoritative_override: str | None = None, notes: str = "",
                  report_phase_label: str | None = None) -> dict[str, Any]:
        """Compare the chain (authoritative read at a finalised height) with the expected totals; build, store and POST the report."""
        self._guard_identity()
        stage = self.stage
        if phase is None:
            phase = "master" if stage == "MASTER_DONE" else "final"
        if phase not in ("master", "opening", "final", "post-cutover"):
            raise MigrationError(f"unknown phase {phase!r}")
        if phase == "master" and stage not in ("MASTER_DONE", "FROZEN"):
            raise MigrationError("phase master can be reconciled once the master batches are imported (stage MASTER_DONE)")
        if phase in ("opening", "final") and stage not in ("OPENING_DONE", "RECONCILED"):
            raise MigrationError(f"phase {phase} can be reconciled once the opening batches are imported (stage OPENING_DONE); current stage {stage}")
        if phase == "post-cutover" and stage != "CUTOVER_DONE":
            raise MigrationError("post-cutover verification needs stage CUTOVER_DONE")
        if ack is not None:
            self.state["ack"] = ack
            self._save()
        ack = self.state.get("ack")
        data_phase = "master" if phase == "master" else "final"
        exp, plan, info, batches = self._expected(data_phase)
        # finalised height, then every read pinned to it
        height = self.backend.height()
        view = read_chain_view(self.backend, height, self.spec.source_system)
        ph_for_compare = {"master": "master", "opening": "opening", "final": "final", "post-cutover": "post-cutover"}[phase]
        checks = compare(exp, view, self.spec.get("reconciliation", "tolerance", default={}) or {}, ph_for_compare)
        if phase == "post-cutover":
            ms = view.mig_state
            tot = {k: int(v) for k, v in (ms.get("attested_totals") or {}).items()}
            ec = expected_counters(exp.records)
            bad = sorted(k for k in set(tot) | set(ec) if int(tot.get(k, 0)) != int(ec.get(k, 0)))
            checks.append(_chk("attested CLOSE totals equal the expected totals", len(ec), len(ec) - len(bad), status=PASS if not bad and tot else FAIL,
                               detail=f"{len(tot)} attested keys" + (f"; differing: {bad[:6]}" if bad else "")))
            fr = self.state.get("final_report") or {}
            checks.append(flag_check("on-chain reconciliation report hash is the final report's hash", fr.get("hash", ""), str(ms.get("reconciliation_report_hash", "")), f"final report {fr.get('id', '')}",
                                     ok=bool(fr.get("hash")) and ms.get("reconciliation_report_hash") == fr.get("hash")))
            checks.append(flag_check("on-chain source freeze marker is the recorded marker", str(self.state.get("freeze_marker", "")), str(ms.get("source_freeze_marker", ""))))
        auth_expected = authoritative_override or {"master": "SOURCE", "opening": "FROZEN", "final": "FROZEN", "post-cutover": "CHAIN"}[phase]
        checks += self._source_checks(phase, info, auth_expected)
        checks += quality_checks(plan, self.spec, "final" if phase in ("final", "post-cutover") else phase, ack, master_only=(phase == "master"))
        marker = self.state.get("freeze_marker") or ""
        # the contract's report phases are trial|master|opening|final: the post-cutover verification is a FINAL report with authoritative_system CHAIN
        label = report_phase_label or ("final" if phase == "post-cutover" else phase)
        rep = build_report(phase=label, id_tag="postcutover" if phase == "post-cutover" and not report_phase_label else "", seq=len(self.state["reports"]) + 1, trial=self.cfg.trial, network_id=self.cfg.network_id, snapshot=info, spec=self.spec, authoritative_system=auth_expected,
                           checks=checks, plan=plan, batches=self._batches_for_report(), notes=notes or self._default_notes(phase, view), clock=self.cfg.clock, chain_height=height,
                           freeze_marker=marker, ack=ack,
                           extra={"delta_since_master": self.state.get("delta_summary"), "expected_counters": exp.counters, "verification": phase})
        entry = self._store_report(rep, post)
        if phase == "final" and rep["decision"] == "ACCEPT" and stage in ("OPENING_DONE", "RECONCILED"):
            self.state["final_report"] = {"id": rep["id"], "hash": entry["hash"], "sha256_local": entry["sha256_local"], "path": entry["path"], "height": height}
            self._transition("reconcile-final")
        elif phase == "final" and rep["decision"] != "ACCEPT" and self.stage == "RECONCILED":
            self.state["stage"] = "OPENING_DONE"  # a later failing reconciliation withdraws the acceptance
            self._event("stage", **{"from": "RECONCILED", "to": "OPENING_DONE", "reason": "final reconciliation no longer ACCEPT"})
        self._save()
        fails = [c for c in checks if c["status"] == FAIL]
        self.log(f"reconciliation ({phase}) at height {height}: decision {rep['decision']} - {len(checks)} checks, {len(fails)} FAIL, {sum(1 for c in checks if c['status'] == WARN)} WARN")
        for c in fails[:12]:
            self.log(f"   FAIL {c['name']}: expected {c['source']} chain {c['chain']} {c.get('detail', '')[:160]}")
        return {"report": rep, "entry": entry, "decision": rep["decision"]}

    def _default_notes(self, phase: str, view: ChainView) -> str:
        base = {"master": "Master data (locations, suppliers, products, prices, promotions, historical sales) imported while the SOURCE is still authoritative.",
                "opening": "Opening position (balances, open purchase orders, loyalty) and post-master deltas imported from the frozen source.",
                "final": "Final reconciliation from the frozen source snapshot; the hash of this report is attested on chain by MigrationControl CLOSE.",
                "post-cutover": "Post-cutover verification: the migration window is CLOSED and the chain is authoritative."}[phase]
        return base + (" TRIAL RUN on a throwaway network - nothing here touches the production chain." if self.cfg.trial else "") + (
            " Imported history is the legacy system's assertion: it was never witnessed by the validators and importing it does not prove it accurate.")

    def _store_report(self, rep: dict[str, Any], post: bool) -> dict[str, Any]:
        rdir = self.workdir / "reports"
        raw = report_bytes(rep)
        local = report_sha256(rep)
        path = rdir / f"{rep['id']}.json"
        atomic_write(path, raw)
        atomic_write(rdir / f"{rep['id']}.md", to_markdown(rep))
        entry: dict[str, Any] = {"id": rep["id"], "phase": rep["phase"], "verification": rep.get("verification"), "decision": rep["decision"], "path": str(path), "sha256_local": local, "hash": local, "posted": []}
        if post:
            for i, be in enumerate([self.backend, *self.cfg.report_backends]):
                try:
                    res = be.post_report(raw)
                except Exception as e:  # reports are off-chain evidence; a store outage must not hide the result but must be visible
                    entry["posted"].append({"backend": getattr(be, "base", "?"), "error": str(e)})
                    self.log(f"WARNING: could not POST the report to {getattr(be, 'base', '?')}: {e}")
                    continue
                entry["posted"].append({"backend": getattr(be, "base", "?"), "id": res.get("id"), "sha256": res.get("sha256")})
                if i == 0 and res.get("sha256"):
                    if res["sha256"] != local:
                        self.log(f"NOTE: the gateway's sha256 for the report ({res['sha256'][:16]}...) differs from the locally computed one ({local[:16]}...); the gateway's value is used as the on-chain report hash")
                    entry["hash"] = res["sha256"]
                    entry["gateway_id"] = res.get("id")
        self.state["reports"].append({k: entry[k] for k in ("id", "phase", "decision", "path", "hash")})
        self._save()
        return entry

    # ------------------------------------------------------------------ cutover
    def cutover(self) -> dict[str, Any]:
        self._guard_identity()
        resume_close = False
        if self.stage == "CUTOVER_DONE":
            return {"status": "already cut over"}
        next_stage("cutover", self.stage)
        fr = self.state.get("final_report")
        if not fr:
            raise MigrationError("no accepted final reconciliation report; run `reconcile --phase final` first")
        rep = read_json(fr["path"])
        if rep["decision"] != "ACCEPT":
            raise MigrationError("the final reconciliation report is not ACCEPT")
        live = self.source.marker()
        if live["freeze_marker"] != self.state["freeze_marker"]:
            raise MigrationError("the source changed after the freeze marker was recorded: cutover refused")
        ms = self._chain_status()
        if ms.get("status") == "CLOSED":
            resume_close = True
        # re-verify at a fresh height immediately before closing: nobody may have touched the chain since the report
        exp, plan, info, _ = self._expected("final")
        if not resume_close:
            view = read_chain_view(self.backend, self.backend.height(), self.spec.source_system)
            bad = [c for c in compare(exp, view, self.spec.get("reconciliation", "tolerance", default={}) or {}, "final") if c["status"] == FAIL]
            if bad:
                raise MigrationError("the chain no longer matches the accepted report (" + "; ".join(f"{c['name']}: expected {c['source']} chain {c['chain']}" for c in bad[:5]) + ") - re-run reconcile")
        totals = exp.counters
        out = self.chain.migration_control("CLOSE", source_system=self.spec.source_system, manifest_hash=self.state["open_manifest_hash"], report_hash=fr["hash"],
                                           freeze_marker=self.state["freeze_marker"], totals=totals)
        self._event("window-close", tx_id=out.tx_id, height=out.height, report_hash=fr["hash"])
        self.log(f"migration window CLOSED on chain (tx {out.tx_id}, height {out.height}); attested {len(totals)} totals equal to the chain's own counters")
        self.source.archive()
        self.log("source marked read-only ARCHIVE (authoritative_system=CHAIN)")
        self._transition("cutover")
        post = self.reconcile("post-cutover", authoritative_override="CHAIN")
        return {"closed_tx": out.tx_id, "closed_height": out.height, "report_hash": fr["hash"], "post_cutover_decision": post["decision"]}

    def unfreeze(self) -> dict[str, Any]:
        """Roll the source freeze back (stage FROZEN -> MASTER_DONE): the source is live and authoritative again and the migration can be
        resumed later with a new freeze and a new final snapshot.  Only possible while NO opening/delta batch is on the chain (those are
        append-only and bound to the final snapshot); otherwise use `abort` and a fresh network."""
        self._guard_identity()
        next_stage("unfreeze", self.stage)
        final, delta, minfo, finfo, master = self._final_plan()
        delta_b, open_b = self.final_batches(final, delta, finfo)
        on_chain = [b.batch_id for b in delta_b + open_b if self.chain.batch_record(b.batch_id) is not None]
        on_chain += [p["promo_id"] for p in delta.new_promotions if self.backend.record(f"promo/{p['promo_id']}")[0]]
        if on_chain or any(b.get("phase") in ("opening", "opening-delta") for b in self.state["batches"]):
            raise MigrationError(f"{len(on_chain)} opening/delta item(s) are already on the chain: the freeze cannot be rolled back, use `abort` and start over on a fresh network")
        self.source.unfreeze()
        for k in ("final_snapshot", "freeze_marker", "freeze_detail"):
            self.state[k] = None
        self.state["write_freeze_verified"] = False
        self._transition("unfreeze")
        self.log("source UNFROZEN and authoritative again; stage MASTER_DONE. Re-run `freeze` when ready (a new final snapshot will be taken).")
        return {"stage": self.stage}

    def abort(self, reason: str = "") -> dict[str, Any]:
        self._guard_identity()
        next_stage("abort", self.stage)
        was = self.stage
        if self.source.state().get("frozen"):
            self.source.unfreeze()
            self.log("source UNFROZEN: it is the live, writable, authoritative system again")
        self.state["abort_reason"] = reason
        self._transition("abort")
        ms = {}
        try:
            ms = self._chain_status()
        except Exception:
            pass
        self.log(f"migration ABORTED from stage {was}. Chain window: {ms.get('status')}; imported records stay on chain as provenance IMPORTED (append-only). Start over on a FRESH network.")
        return {"aborted_from": was, "chain_window": ms.get("status")}

    # ------------------------------------------------------------------ status
    def status(self) -> dict[str, Any]:
        src = self.source.state()
        chain_status, err = None, ""
        if self.backend is None:
            err = "no chain connection given: source-side view only"
        else:
            try:
                chain_status = (self._chain_status() or {}).get("status")
            except Exception as e:
                err = str(e)
        auth, note = derive_authority(src.get("authoritative_system"), src.get("frozen"), src.get("archived"), chain_status)
        stage = self.stage
        expected = AUTH_BY_STAGE[stage]
        if note != "CONSISTENT":
            consistency = note
        elif auth == expected:
            consistency = "CONSISTENT"
        else:
            consistency = f"INCONSISTENT: local state says {stage} ({expected}) but the control records say {auth}"
        return {"stage": stage, "authoritative_system": auth, "consistency": consistency,
                "source": {"authoritative_system": src.get("authoritative_system"), "frozen": src.get("frozen"), "archived": src.get("archived"), "freeze_marker": src.get("freeze_marker")},
                "chain_window": chain_status, "chain_error": err, "next": NEXT_HINT[stage], "reports": self.state["reports"][-3:], "batches": len(self.state["batches"]),
                "trial": self.state.get("trial")}
