"""Changes between the MASTER snapshot (taken while the source was live) and the FINAL snapshot (taken after the freeze).

Master entities (locations, suppliers, products, prices, promotions, historical sales) were imported from the master snapshot.
Between that snapshot and the freeze the live source kept changing.  The chain is append-only and ImportBatch refuses an
existing id, so:

* NEW records (not in the master plan)       -> imported as delta batches in the opening phase (under the final snapshot id)
* CHANGED records (same source id, other content) -> NOT re-imported: the chain keeps the master-time version and a MANUAL
  exception CHANGED_AFTER_MASTER is raised (apply a native correction, e.g. UpdateProduct, or accept)
* DELETED records (in master, gone in final)  -> stay on chain; MANUAL exception DELETED_AFTER_MASTER
* a new record that depends on something that never reached the chain (e.g. a price for a SKU that was only added as a new variant
  of an already-imported product) is excluded with a MANUAL EXCLUDED_DEPENDENCY exception

Opening entities (balances, open POs, loyalty) are imported only from the final snapshot; they are filtered against the same
effective reference sets so that no batch can be rejected by the chain for a missing parent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .checks import MANUAL
from .plan import Plan
from .util import canonical_json

RECORD_ENTITIES = ("LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "HISTORICAL_SALE")  # master entities imported through ImportBatch


def _h(r: dict) -> bytes:
    return canonical_json(r)


@dataclass
class Delta:
    new: dict[str, list[dict]] = field(default_factory=dict)
    new_promotions: list[dict] = field(default_factory=list)
    changed: list[tuple[str, str]] = field(default_factory=list)
    deleted: list[tuple[str, str]] = field(default_factory=list)
    dependency_excluded: list[tuple[str, str]] = field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        return {"new": {e: len(v) for e, v in self.new.items() if v}, "new_promotions": len(self.new_promotions), "changed_after_master": len(self.changed),
                "deleted_after_master": len(self.deleted), "excluded_dependency": len(self.dependency_excluded)}


def apply_delta(master: Plan, final: Plan) -> Delta:
    """Mutates ``final`` so that final.records/promotions are the EFFECTIVE chain content (master versions + new records) and returns the delta."""
    d = Delta()
    exc = final.exceptions

    def exclude(ent: str, ref: str, detail: str, kind: str = "EXCLUDED_DEPENDENCY") -> None:
        exc.add(kind, ref, detail, MANUAL, ent)
        exc.exclude(ent, ref)
        d.dependency_excluded.append((ent, ref))

    eff: dict[str, list[dict]] = {}
    # ---- master entities: effective = master version for known ids, final version for new ids
    for ent in RECORD_ENTITIES:
        m = {r["source_id"]: r for r in master.records.get(ent, [])}
        f = {r["source_id"]: r for r in final.records.get(ent, [])}
        for sid, r in sorted(f.items()):
            if sid in m and _h(r) != _h(m[sid]):
                d.changed.append((ent, sid))
                exc.add("CHANGED_AFTER_MASTER", sid, f"{ent} {sid} changed in the source after the master snapshot; the chain keeps the master-time version (apply a native correction or accept)", MANUAL, ent)
        for sid in sorted(set(m) - set(f)):
            reason = final.expired.get(ent, {}).get(sid)
            if reason:  # still in the source, merely past its validity now: not a deletion; the imported row stays on chain
                oos = final.exceptions.out_of_scope[ent]
                oos[reason] -= 1  # it is counted as migrated (on chain), not out of scope
                continue
            d.deleted.append((ent, sid))
            exc.add("DELETED_AFTER_MASTER", sid, f"{ent} {sid} no longer exists in the source but was imported at master time; it stays on chain", MANUAL, ent)
            final.in_scope[ent] = final.in_scope.get(ent, 0) + 1
            if ent == "PRODUCT":
                final.in_scope["SKU"] = final.in_scope.get("SKU", 0) + len(m[sid]["variants"])
        new = [r for sid, r in sorted(f.items()) if sid not in m]
        eff[ent] = sorted(list(m.values()) + new, key=lambda r: r["source_id"])
        d.new[ent] = new
    # a changed product that gained variants: the chain cannot add variants through import
    for ent, sid in d.changed:
        if ent != "PRODUCT":
            continue
        mp = next(r for r in master.records["PRODUCT"] if r["source_id"] == sid)
        fp = next(r for r in final.records["PRODUCT"] if r["source_id"] == sid)
        have = {v["sku_id"] for v in mp["variants"]}
        for v in fp["variants"]:
            if v["sku_id"] not in have:
                vref = (v.get("source_extras") or {}).get("source_id", f"{sid}/{v['sku_id']}")
                exclude("SKU", vref, f"variant {v['sku_id']} was added to the already-imported product {sid} after the master snapshot; import cannot add variants (create it natively)", "CHANGED_AFTER_MASTER")
    # ---- dependency filtering of NEW records against what will really be on chain
    eff_skus = {v["sku_id"] for p in eff["PRODUCT"] for v in p["variants"]}
    eff_locs = set(final.location_ids.values())  # genesis locations + every migratable source location
    new_prices, new_sales = [], []
    for r in d.new["PRICE"]:
        if r["sku"] not in eff_skus:
            exclude("PRICE", r["source_id"], f"sku {r['sku']} is not on chain (added after the master snapshot)")
        else:
            new_prices.append(r)
    d.new["PRICE"] = new_prices
    for r in d.new["HISTORICAL_SALE"]:
        bad = [l["sku"] for l in r["lines"] if l["sku"] not in eff_skus]
        if bad:
            exclude("HISTORICAL_SALE", r["source_id"], f"sale line sku {bad[0]} is not on chain")
        else:
            new_sales.append(r)
    d.new["HISTORICAL_SALE"] = new_sales
    for ent in ("PRICE", "HISTORICAL_SALE"):
        excluded_ids = {ref for e, ref in d.dependency_excluded if e == ent}
        eff[ent] = [r for r in eff[ent] if r["source_id"] not in excluded_ids]
    final.records.update(eff)
    # ---- promotions
    mp = {p["promo_id"]: p for p in master.promotions}
    fp = {p["promo_id"]: p for p in final.promotions}
    for pid, p in sorted(fp.items()):
        if pid in mp:
            if _h(p) != _h(mp[pid]):
                d.changed.append(("PROMOTION", p["_source_ref"]))
                exc.add("CHANGED_AFTER_MASTER", p["_source_ref"], f"promotion {pid} changed after the master snapshot; the chain keeps the master-time version", MANUAL, "PROMOTION")
        elif any(s not in eff_skus for s in p["skus"]):
            exclude("PROMOTION", p["_source_ref"], f"promotion {pid} references a SKU that is not on chain")
        else:
            d.new_promotions.append(p)
    for pid in sorted(set(mp) - set(fp)):
        reason = final.expired.get("PROMOTION", {}).get(mp[pid]["_source_ref"])
        if reason:
            final.exceptions.out_of_scope["PROMOTION"][reason] -= 1
            continue
        d.deleted.append(("PROMOTION", mp[pid]["_source_ref"]))
        exc.add("DELETED_AFTER_MASTER", mp[pid]["_source_ref"], f"promotion {pid} is gone from the source but stays on chain", MANUAL, "PROMOTION")
        final.in_scope["PROMOTION"] = final.in_scope.get("PROMOTION", 0) + 1
    final.promotions = sorted([mp[k] for k in mp] + d.new_promotions, key=lambda p: p["promo_id"])
    # ---- opening entities: only valid against the effective reference sets
    eff_suppliers = {r["id"] for r in eff["SUPPLIER"]}
    ob = []
    for r in final.records.get("OPENING_BALANCE", []):
        if r["sku"] not in eff_skus or r["location"] not in eff_locs:
            exclude("OPENING_BALANCE", r["source_id"].split("#")[0], f"opening balance for {r['sku']} at {r['location']} depends on a record that is not on chain")
        else:
            ob.append(r)
    final.records["OPENING_BALANCE"] = ob
    pos = []
    for r in final.records.get("OPEN_PO", []):
        if r["supplier_id"] not in eff_suppliers or r["location"] not in eff_locs or any(l["sku"] not in eff_skus for l in r["lines"]):
            exclude("OPEN_PO", r["source_id"], f"purchase order {r['id']} depends on a supplier/location/SKU that is not on chain")
        else:
            pos.append(r)
    final.records["OPEN_PO"] = pos
    return d
