"""Command line interface:  python -m aureom_migration <command> [options]

  synth | activity                  generate / mutate the synthetic source database
  inventory                         source schema inventory (JSON + markdown)
  snapshot                          consistent snapshot (backup API under a read transaction)
  checks                            integrity checks -> exceptions with dispositions (no chain needed)
  plan                              show the deterministic batch plan (ids, sizes) for the current source
  status                            which system is authoritative right now
  master | freeze | opening | reconcile | cutover | unfreeze | abort | all    the controlled cutover procedure
  trial                             full rehearsal on a throwaway network (never touches production)

Connection options (or environment): --gateway/GATEWAY_URL  --network-id/NETWORK_ID  --keys/KEYS_DIR  --workdir/MIG_WORKDIR  --source/MIG_SOURCE
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from . import synth as synth_mod
from .batching import make_batches, manifest_hash
from .chainclient import ChainClient, CometRpcBackend, GatewayBackend
from .cutover import Config, Migration
from .inventory import write_inventory
from .mapping import load_spec
from .plan import build_plan, expected_counters
from .report import quality_checks
from .snapshot import take_snapshot
from .trial import run_trial
from .util import SYSTEM_CLOCK, MigrationError, atomic_write, iso_now, write_json

DEFAULT_SOURCE = "migration/source/retail_source.sqlite"


def _env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


def add_common(p: argparse.ArgumentParser, chain: bool = True) -> None:
    p.add_argument("--source", default=_env("MIG_SOURCE", DEFAULT_SOURCE), help="source SQLite database")
    p.add_argument("--mapping", default=None, help="mapping spec (default mapping/map-v1.yaml)")
    p.add_argument("--workdir", default=_env("MIG_WORKDIR", "migration/work"), help="state, snapshots and reports")
    if chain:
        p.add_argument("--gateway", default=_env("GATEWAY_URL"), help="gateway base URL, e.g. http://127.0.0.1:8080")
        p.add_argument("--rpc", default=_env("RPC_URL"), help="validator CometBFT RPC URL (smoke tests / fallback instead of the gateway)")
        p.add_argument("--network-id", default=_env("NETWORK_ID", "aureom-retail-demo-1"))
        p.add_argument("--keys", default=_env("KEYS_DIR"), help="identity key directory (<net>/keys)")
        p.add_argument("--report-gateway", action="append", default=[], help="additional gateway that also receives the reports (repeatable)")
        p.add_argument("--max-records", type=int, default=None)
        p.add_argument("--max-envelope-bytes", type=int, default=None)


def connect(a) -> tuple[Any, ChainClient]:
    if a.rpc:
        backend: Any = CometRpcBackend(a.rpc)
    elif a.gateway:
        backend = GatewayBackend(a.gateway)
    else:
        raise MigrationError("give --gateway (or GATEWAY_URL), or --rpc for a direct validator connection")
    actual = backend.network_id()
    if actual != a.network_id:
        raise MigrationError(f"the endpoint is network {actual!r} but --network-id is {a.network_id!r}: refusing to sign for the wrong network")
    keys = a.keys or (os.path.join(os.environ["RUN_DIR"], "net", "keys") if os.environ.get("RUN_DIR") else None)
    return backend, ChainClient(backend, a.network_id, keys)


def make_migration(a, trial: bool = False, need_chain: bool = True) -> Migration:
    spec = load_spec(a.mapping)
    backend, chain = connect(a) if (need_chain or a.gateway or a.rpc) else (None, None)
    cfg = Config(workdir=Path(a.workdir), source_db=Path(a.source), spec=spec, network_id=a.network_id, trial=trial, log=lambda m: print(m, flush=True),
                 report_backends=[GatewayBackend(u) for u in a.report_gateway], max_records=a.max_records, max_envelope_bytes=a.max_envelope_bytes)
    return Migration(cfg, backend, chain)


def _ack(a) -> dict | None:
    if getattr(a, "ack_manual", False):
        if not a.ack_by or not a.ack_reason:
            raise MigrationError("--ack-manual needs --ack-by NAME and --ack-reason TEXT (the acknowledgement is recorded in the report)")
        return {"all": True, "by": a.ack_by, "reason": a.ack_reason, "at": iso_now()}
    return None


# ------------------------------------------------------------------ commands


def cmd_synth(a) -> int:
    print(json.dumps(synth_mod.generate(a.seed, a.out), indent=2))
    return 0


def cmd_activity(a) -> int:
    print(json.dumps(synth_mod.simulate_activity(a.db, a.seed, a.sales), indent=2))
    return 0


def cmd_inventory(a) -> int:
    inv = write_inventory(a.source, a.out)
    print(f"{len(inv['tables'])} tables, {sum(t['row_count'] for t in inv['tables'].values())} rows -> {a.out}/schema_inventory.json + .md")
    return 0


def cmd_snapshot(a) -> int:
    info = take_snapshot(a.source, a.out, a.label)
    print(json.dumps({k: v for k, v in info.to_dict().items() if k != "row_counts"} | {"rows": sum(info.row_counts.values())}, indent=2))
    return 0


def _local_plan(a):
    spec = load_spec(a.mapping)
    info = take_snapshot(a.source, Path(a.workdir) / "checks", "check")
    return spec, info, build_plan(info.path, spec, snapshot_id=info.snapshot_id, reference_ms=info.taken_at_ms)


def cmd_checks(a) -> int:
    spec, info, plan = _local_plan(a)
    ex = plan.exceptions
    print(f"snapshot {info.snapshot_id} - mapping {spec.version} - schema gate {'PASS' if plan.gate.ok else 'FAIL'}")
    disp = Counter(e.disposition for e in ex.items)
    print(f"{len(ex.items)} exceptions: {dict(disp)}")
    for k, n in ex.by_kind().items():
        print(f"  {k:28s} {n}")
    print("\nentity accounting (source rows in scope = migrated + excluded + out of scope):")
    for ent, st in plan.stats().items():
        print(f"  {ent:16s} in scope {st['in_scope']:5d}  migrated {st['migrated']:5d}  excluded {st['excluded']:4d}  out of scope {sum(st['out_of_scope'].values())}")
    q = quality_checks(plan, spec, "master", None)
    bad = [c for c in q if c["status"] == "FAIL"]
    if a.out:
        out = Path(a.out)
        out.mkdir(parents=True, exist_ok=True)
        write_json(out / "exceptions.json", {"snapshot_id": info.snapshot_id, "mapping_version": spec.version, "exceptions": [e.to_report() for e in ex.sorted()],
                                             "unsupported_fields": plan.unsupported_fields, "stats": plan.stats(), "expected_counters": expected_counters(plan.records)})
        print(f"\nwritten: {out}/exceptions.json")
    if a.list:
        for e in ex.sorted():
            if a.list == "all" or e.disposition == a.list or e.kind == a.list:
                print(f"{e.disposition:20s} {e.kind:26s} {e.source_ref:34s} {e.detail[:150]}")
    return 1 if (not plan.gate.ok or bad) else 0


def cmd_plan(a) -> int:
    spec, info, plan = _local_plan(a)
    sz = spec.batching
    total = 0
    for ent in [*spec.phase_entities("master"), *spec.phase_entities("opening")]:
        if ent == "PROMOTION":
            print(f"  {ent:16s} {len(plan.promotions):5d} native ActivatePromotion txs (pricing-mgr)")
            continue
        bs = make_batches(ent, plan.records.get(ent, []), snapshot_id=info.snapshot_id, mapping_version=spec.version, source_system=spec.source_system,
                          max_records=int(sz["max_records"]), max_envelope_bytes=int(sz["max_envelope_bytes"]))
        total += len(bs)
        print(f"  {ent:16s} {sum(len(b.records) for b in bs):5d} records in {len(bs)} batches" + (f"  e.g. {bs[0].batch_id}" if bs else ""))
    print(f"snapshot {info.snapshot_id}; {total} batches; expected chain counters:")
    for k, v in expected_counters(plan.records).items():
        print(f"  {k:32s} {v}")
    return 0


def cmd_status(a) -> int:
    m = make_migration(a, need_chain=False)  # works without a chain connection (source-side view only)
    print(json.dumps(m.status(), indent=2))
    return 0


def _run(a, fn) -> int:
    m = make_migration(a)
    res = fn(m)
    return 0 if (not isinstance(res, dict) or res.get("decision", "ACCEPT") == "ACCEPT") else 2


def cmd_master(a) -> int:
    return _run(a, lambda m: m.master())


def cmd_freeze(a) -> int:
    return _run(a, lambda m: m.freeze())


def cmd_opening(a) -> int:
    return _run(a, lambda m: m.opening())


def cmd_reconcile(a) -> int:
    def go(m: Migration):
        r = m.reconcile(a.phase, ack=_ack(a), post=not a.no_post)
        print(f"report: {r['entry']['path']} (+ .md)  hash {r['entry']['hash']}")
        return r
    return _run(a, go)


def cmd_cutover(a) -> int:
    return _run(a, lambda m: m.cutover())


def cmd_unfreeze(a) -> int:
    return _run(a, lambda m: m.unfreeze())


def cmd_abort(a) -> int:
    return _run(a, lambda m: m.abort(a.reason or ""))


def cmd_all(a) -> int:
    m = make_migration(a)
    ack = _ack(a)
    m.master()
    m.reconcile("master", post=not a.no_post)
    m.freeze()
    m.opening()
    r = m.reconcile("final", ack=ack, post=not a.no_post)
    if r["decision"] != "ACCEPT":
        print("final reconciliation REJECTED - not cutting over", file=sys.stderr)
        return 2
    print(json.dumps(m.cutover(), indent=2))
    return 0


def cmd_trial(a) -> int:
    spec = load_spec(a.mapping)
    backend: Any = GatewayBackend(a.gateway) if a.gateway else None
    if backend is None:
        raise MigrationError("trial needs --gateway of the throwaway network's gateway")
    keys = a.keys or (os.path.join(os.environ["RUN_DIR"], "net", "keys") if os.environ.get("RUN_DIR") else None)
    res = run_trial(source_db=a.source, workdir=a.workdir, spec=spec, backend=backend, network_id=a.network_id, keys_dir=keys, report_backends=[GatewayBackend(u) for u in a.report_gateway],
                    simulate=not a.no_activity, allow_any_network=a.allow_any_network_id, log=lambda m: print(m, flush=True), max_records=a.max_records, max_envelope_bytes=a.max_envelope_bytes)
    print(json.dumps({k: v for k, v in res.items() if k != "steps"}, indent=2))
    return 0 if res["decision"] == "ACCEPT" else 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aureom_migration", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("synth", help="generate the synthetic source database")
    s.add_argument("--seed", type=int, default=42)
    s.add_argument("--out", default=DEFAULT_SOURCE)
    s.set_defaults(fn=cmd_synth)
    s = sub.add_parser("activity", help="simulate live writes on the source (change-log triggers fire)")
    s.add_argument("--db", default=DEFAULT_SOURCE)
    s.add_argument("--seed", type=int, default=7)
    s.add_argument("--sales", type=int, default=25)
    s.set_defaults(fn=cmd_activity)
    s = sub.add_parser("inventory", help="source schema inventory")
    s.add_argument("--source", default=_env("MIG_SOURCE", DEFAULT_SOURCE))
    s.add_argument("--out", default="migration/work/inventory")
    s.set_defaults(fn=cmd_inventory)
    s = sub.add_parser("snapshot", help="take a consistent snapshot")
    s.add_argument("--source", default=_env("MIG_SOURCE", DEFAULT_SOURCE))
    s.add_argument("--out", default="migration/work/snapshots")
    s.add_argument("--label", default="manual")
    s.set_defaults(fn=cmd_snapshot)
    s = sub.add_parser("checks", help="duplicate / referential-integrity / range checks -> exceptions with dispositions")
    add_common(s, chain=False)
    s.add_argument("--out", default=None, help="write exceptions.json here")
    s.add_argument("--list", default=None, help="print exceptions: all | EXCLUDED | FIXED | PRESERVED_AS_EXTRAS | MANUAL | <KIND>")
    s.set_defaults(fn=cmd_checks)
    s = sub.add_parser("plan", help="deterministic batch plan for the current source")
    add_common(s, chain=False)
    s.set_defaults(fn=cmd_plan)
    s = sub.add_parser("status", help="which system is authoritative")
    add_common(s)
    s.set_defaults(fn=cmd_status)
    for name, fn, hlp in (("master", cmd_master, "phase 1: master data + historical sales while the SOURCE is live"), ("freeze", cmd_freeze, "phase 2: write-freeze the source + final snapshot"),
                          ("opening", cmd_opening, "phase 3: deltas + opening balances, open POs, loyalty from the frozen source"),
                          ("cutover", cmd_cutover, "phase 5: MigrationControl CLOSE with attested totals; source becomes a read-only archive")):
        s = sub.add_parser(name, help=hlp)
        add_common(s)
        s.set_defaults(fn=fn)
    s = sub.add_parser("reconcile", help="phase 4: chain-authoritative reconciliation report (POSTed to the gateway)")
    add_common(s)
    s.add_argument("--phase", choices=["master", "opening", "final"], default=None)
    s.add_argument("--no-post", action="store_true")
    s.add_argument("--ack-manual", action="store_true", help="acknowledge the unresolved MANUAL exceptions (needed for the final report; recorded in it)")
    s.add_argument("--ack-by", default=None)
    s.add_argument("--ack-reason", default=None)
    s.set_defaults(fn=cmd_reconcile)
    s = sub.add_parser("unfreeze", help="roll the source freeze back (only before any opening batch is on chain)")
    add_common(s)
    s.set_defaults(fn=cmd_unfreeze)
    s = sub.add_parser("abort", help="abort before cutover: unfreeze the source")
    add_common(s)
    s.add_argument("--reason", default="")
    s.set_defaults(fn=cmd_abort)
    s = sub.add_parser("all", help="master -> freeze -> opening -> reconcile -> cutover in one go")
    add_common(s)
    s.add_argument("--no-post", action="store_true")
    s.add_argument("--ack-manual", action="store_true")
    s.add_argument("--ack-by", default=None)
    s.add_argument("--ack-reason", default=None)
    s.set_defaults(fn=cmd_all)
    s = sub.add_parser("trial", help="full rehearsal on a throwaway network")
    add_common(s)
    s.add_argument("--no-activity", action="store_true", help="do not simulate live source activity between master and freeze")
    s.add_argument("--allow-any-network-id", action="store_true", help="tests only: skip the 'aureom-trial*' network id rule")
    s.set_defaults(fn=cmd_trial)
    return p


def main(argv: list[str] | None = None) -> int:
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a)
    except MigrationError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
