"""Plan builder: source snapshot + mapping spec -> chain-ready records, exceptions and expected totals.

The plan is a PURE FUNCTION of (snapshot content, mapping spec, reference time): building it twice gives byte-identical
records, which is what makes batching deterministic and delta detection (master snapshot vs final snapshot) possible.

Every source record ends up in exactly one of: migrated, excluded (with an exception), or out of scope (documented reason,
e.g. VOID sales, closed purchase orders, expired prices).  Money is converted to integer minor units exactly once
(convert.to_minor); from there on only integer arithmetic is used.
"""

from __future__ import annotations

import json
import re
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable
from zoneinfo import ZoneInfo

from .checks import EXCLUDED, FIXED, MANUAL, PRESERVED, ExceptionLog, GateResult, schema_gate
from .convert import (CHAIN_ID_RE, ConversionError, ascii_label, iso_utc, line_amount, map_customer_id, normalise_timestamp,
                      normalise_unit, sanitize_id, to_minor, to_qty)
from .inventory import connect_ro, inventory
from .mapping import Spec, render_value
from .util import canonical_json, sha256_hex

FUTURE_SKEW_MS = 5 * 60_000
MAX_EXTRAS_VALUE = 4096
MASTER_ENTITIES = ("LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "PROMOTION", "HISTORICAL_SALE")
ENTITY_ORDER = ("LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "PROMOTION", "HISTORICAL_SALE", "OPENING_BALANCE", "OPEN_PO", "LOYALTY_OPENING")
EXPIRED_PRICE = "expired before the snapshot (history, not migrated)"
ENDED_PROMOTION = "ended or expired (not migrated)"
PROMO_INTERNAL_KEYS = ("_source_ref",)  # plan-only annotations, stripped before an ActivatePromotion payload is signed


@dataclass
class Plan:
    mapping_version: str
    mapping_sha256: str
    source_system: str
    snapshot_id: str
    reference_ms: int
    records: dict[str, list[dict]] = field(default_factory=dict)  # import entities -> records sorted by source_id
    promotions: list[dict] = field(default_factory=list)  # ActivatePromotion payloads, sorted by promo_id
    exceptions: ExceptionLog = field(default_factory=ExceptionLog)
    gate: GateResult | None = None
    unsupported_fields: list[dict] = field(default_factory=list)
    source_counts: dict[str, int] = field(default_factory=dict)  # raw source totals, computed by SQL independent of the mapping
    in_scope: dict[str, int] = field(default_factory=dict)  # rows considered per entity (denominator for exclusion ratios)
    normalisations: dict[str, int] = field(default_factory=dict)  # informational conversion counters (unit synonyms, timestamp formats ...)
    sku_units: dict[str, str] = field(default_factory=dict)
    location_ids: dict[str, str] = field(default_factory=dict)  # source code -> chain id (incl. genesis)
    expired: dict[str, dict[str, str]] = field(default_factory=dict)  # entity -> {source ref: out-of-scope reason} for rows skipped only because their validity ended

    # ---- derived
    def record_hashes(self) -> dict[str, dict[str, str]]:
        out: dict[str, dict[str, str]] = {}
        for ent, recs in self.records.items():
            out[ent] = {r["source_id"]: sha256_hex(canonical_json(r)) for r in recs}
        out["PROMOTION"] = {p["promo_id"]: sha256_hex(canonical_json(p)) for p in self.promotions}
        return out

    def stats(self) -> dict[str, dict[str, Any]]:
        out: dict[str, dict[str, Any]] = {}
        for ent in ENTITY_ORDER + ("SKU",):
            if ent == "PROMOTION":
                migrated = len(self.promotions)
            elif ent == "SKU":
                migrated = sum(len(p["variants"]) for p in self.records.get("PRODUCT", []))
            else:
                migrated = len(self.records.get(ent, []))
            exc = len(self.exceptions.excluded.get(ent, ()))
            out[ent] = {"in_scope": self.in_scope.get(ent, 0), "migrated": migrated, "excluded": exc,
                        "out_of_scope": dict(self.exceptions.out_of_scope.get(ent, {}))}
        return out


def expected_counters(records: dict[str, list[dict]]) -> dict[str, int]:
    """The chain's own migration counters (core.execImport) that these records must produce."""
    c: dict[str, int] = defaultdict(int)
    c["locations"] = len(records.get("LOCATION", []))
    c["suppliers"] = len(records.get("SUPPLIER", []))
    c["products"] = len(records.get("PRODUCT", []))
    c["skus"] = sum(len(p["variants"]) for p in records.get("PRODUCT", []))
    c["prices"] = len(records.get("PRICE", []))
    for r in records.get("OPENING_BALANCE", []):
        c[f"opening_balance_units|{r['qty']['unit']}"] += r["qty"]["v"]
        c["opening_balance_rows"] += 1
    for po in records.get("OPEN_PO", []):
        c["open_pos"] += 1
        for ln in po["lines"]:
            c[f"po_outstanding_units|{ln['qty']['unit']}"] += ln["qty"]["v"] - ln["received_v"]
            c["open_po_total_minor"] += line_amount(ln["unit_cost_minor"], ln["qty"]["v"], ln["qty"]["unit"])
    for r in records.get("LOYALTY_OPENING", []):
        c["loyalty_accounts"] += 1
        c["loyalty_points"] += r["points"]
    for s in records.get("HISTORICAL_SALE", []):
        c["historical_sales"] += 1
        c["historical_net_minor"] += sum(ln["net_minor"] for ln in s["lines"])
        c["historical_refunded_minor"] += s["refunded_minor"]
    return dict(sorted(c.items()))


# ====================================================================== builder


class Builder:
    def __init__(self, db_path: str, spec: Spec, snapshot_id: str, reference_ms: int):
        self.spec = spec
        self.snapshot_id = snapshot_id
        self.ref_ms = reference_ms
        self.tz = ZoneInfo(spec.timezone)
        self.con = connect_ro(db_path)
        self.exc = ExceptionLog()
        self.records: dict[str, list[dict]] = {}
        self.promotions: list[dict] = []
        self.cnt: dict[str, int] = defaultdict(int)  # rows considered per entity
        self.norm: dict[str, int] = defaultdict(int)
        self.loc_ids: dict[str, str] = {}
        self.loc_ccy: dict[str, str] = {}
        self.variant_sku: dict[Any, str] = {}  # source variant_id -> normalised sku id (for ALL variants, incl. excluded duplicates)
        self.all_source_skus: set[str] = set()
        self.sku_info: dict[str, dict] = {}  # sku_id -> {unit, product_id}
        self.customers_raw: set[str] = set()
        self.expired: dict[str, dict[str, str]] = defaultdict(dict)
        self._rows_cache: dict[str, list[dict]] = {}
        self.db_path = db_path

    # ---- plumbing
    def rows(self, table: str) -> list[dict]:
        if table not in self._rows_cache:
            self._rows_cache[table] = [dict(r) for r in self.con.execute(f'SELECT * FROM "{table}" ORDER BY rowid')]
        return self._rows_cache[table]

    def extras(self, table: str, r: dict, skip: tuple[str, ...] = ()) -> dict[str, str]:
        out: dict[str, str] = {}
        for col, key in self.spec.extras_columns(table):
            if col in skip:
                continue
            v = r.get(col)
            if v is None or str(v).strip() == "":
                continue
            out[key] = render_value(v)
        return out

    def label(self, raw: Any, max_len: int, *, ref: str, entity: str, field_name: str, extras: dict[str, str] | None, default: str = "") -> str:
        text, changed = ascii_label(raw, max_len, default=default)
        if raw is not None and changed:
            s = str(raw)
            non_ascii = any(ord(c) > 0x7E or (ord(c) < 0x20 and c not in "\t\n\r") for c in s)
            truncated = len(ascii_label(raw, 10 ** 6)[0]) > max_len
            if non_ascii:
                self.exc.add("NON_ASCII_TEXT", ref, f"{field_name} {s!r} is not printable ASCII -> {text!r}" + ("; original preserved in source_extras" if extras is not None else ""), FIXED, entity)
            elif truncated:
                self.exc.add("TEXT_TRUNCATED", ref, f"{field_name} longer than {max_len} characters" + ("; original preserved in source_extras" if extras is not None else ""), FIXED, entity)
            if (non_ascii or truncated) and extras is not None:
                extras[f"{field_name}_original"] = s
        return text

    def put_extras(self, rec: dict, extras: dict[str, str], ref: str, entity: str) -> None:
        for k, v in list(extras.items()):
            if len(v) > MAX_EXTRAS_VALUE:
                self.exc.add("EXTRAS_TOO_LARGE", ref, f"source_extras[{k}] is {len(v)} characters (max {MAX_EXTRAS_VALUE}); value NOT preserved", MANUAL, entity)
                extras[k] = f"<{len(v)} characters; sha256 {sha256_hex(v)}>"
        if extras:
            rec["source_extras"] = dict(sorted(extras.items()))

    def money(self, v: Any, ccy: str, ref: str, entity: str, what: str, *, positive: bool = False, allow_negative: bool = False) -> int | None:
        """Convert; None (with an exception) when the amount is unusable.  Genuine sub-minor-unit rounding is reported FIXED."""
        try:
            s = to_minor(v, ccy, allow_negative=allow_negative)
        except ConversionError as e:
            self.exc.add(e.kind, ref, f"{what}: {e}", MANUAL, entity)
            return None
        if s.genuine_rounding:
            self.exc.add("FLOAT_PRECISION", ref, f"{what} {v!r} carries sub-minor-unit precision; rounded half-even to {s.value} minor units", FIXED, entity)
        elif s.rounded:
            self.norm["money_float_artifacts"] += 1
        return s.value

    def ts(self, raw: Any, ref: str, entity: str, what: str) -> int | None:
        try:
            t = normalise_timestamp(raw, self.tz)
        except ConversionError as e:
            self.exc.add("INVALID_TIMESTAMP", ref, f"{what}: {e}", MANUAL, entity)
            return None
        self.norm[f"timestamp_format|{t.fmt}"] += 1
        if t.dst_ambiguous:
            self.exc.add("AMBIGUOUS_LOCAL_TIME", ref, f"{what} {raw!r} occurs twice (DST fold); first occurrence used -> {iso_utc(t.ms)}", FIXED, entity)
        if t.dst_gap:
            self.exc.add("NONEXISTENT_LOCAL_TIME", ref, f"{what} {raw!r} does not exist (DST gap); pre-transition offset used -> {iso_utc(t.ms)}", FIXED, entity)
        return t.ms

    # ================================================================== LOCATION
    def build_locations(self) -> None:
        recs: list[dict] = []
        seen: dict[str, str] = {}
        gen = self.spec.genesis_locations
        for table, pk, kind in (("stores", "store_code", "STORE"), ("warehouses", "wh_code", "WAREHOUSE")):
            for r in self.rows(table):
                code = str(r[pk]).strip()
                ref = f"{table}:{r[pk]}"
                self.cnt["LOCATION"] += 1
                cid = self.spec.location_chain_id(code) or self.spec.location_fallback_id(code)
                if not CHAIN_ID_RE.match(cid) or cid.startswith(("EXT:", "TRANSIT:")):
                    self.exc.add("INVALID_ID", ref, f"location code {code!r} does not map to a valid chain id", MANUAL, "LOCATION")
                    self.exc.exclude("LOCATION", ref)
                    continue
                if cid in seen:
                    self.exc.add("ID_COLLISION", ref, f"chain id {cid} already derived from {seen[cid]}", MANUAL, "LOCATION")
                    self.exc.exclude("LOCATION", ref)
                    continue
                seen[cid] = ref
                ccy = str(r.get("currency") or self.spec.default_currency).strip().upper()
                if cid in gen:  # already on chain from genesis: verify, never import
                    g = gen[cid]
                    if g["kind"] != kind or g["currency"] != ccy:
                        self.exc.add("LOCATION_MISMATCH", ref, f"maps to genesis location {cid} ({g['kind']}/{g['currency']}) but the source says {kind}/{ccy}", MANUAL, "LOCATION")
                    self.loc_ids[code] = cid
                    self.loc_ccy[cid] = g["currency"]
                    self.exc.skip_scope("LOCATION", "already on chain from genesis (mapped, not imported)")
                    continue
                if ccy not in ("GBP", "USD", "EUR", "JPY"):
                    self.exc.add("INVALID_CURRENCY", ref, f"currency {ccy!r}", MANUAL, "LOCATION")
                    self.exc.exclude("LOCATION", ref)
                    continue
                extras = self.extras(table, r)
                name = self.label(r.get("name"), 120, ref=ref, entity="LOCATION", field_name="name", extras=extras)
                region = self.label((r.get("region") or "").lower(), 40, ref=ref, entity="LOCATION", field_name="region", extras=extras)
                if not name:
                    self.exc.add("INVALID_RECORD", ref, "location name is empty", MANUAL, "LOCATION")
                    self.exc.exclude("LOCATION", ref)
                    continue
                if not region:
                    region = "unassigned"
                    self.exc.add("MISSING_VALUE", ref, "region is empty; 'unassigned' used", FIXED, "LOCATION")
                rec = {"source_id": ref, "id": cid, "name": name, "kind": kind, "region": region, "currency": ccy}
                self.put_extras(rec, extras, ref, "LOCATION")
                recs.append(rec)
                self.loc_ids[code] = cid
                self.loc_ccy[cid] = ccy
        self.records["LOCATION"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== SUPPLIER
    def build_suppliers(self) -> None:
        recs, seen = [], {}
        for r in self.rows("suppliers"):
            ref = f"suppliers:{r['supplier_id']}"
            self.cnt["SUPPLIER"] += 1
            sid = sanitize_id(r["supplier_id"])
            if not sid:
                self.exc.add("INVALID_ID", ref, f"supplier id {r['supplier_id']!r} is not usable", MANUAL, "SUPPLIER")
                self.exc.exclude("SUPPLIER", ref)
                continue
            if sid in seen:
                self.exc.add("ID_COLLISION", ref, f"chain id {sid} already derived from {seen[sid]}", MANUAL, "SUPPLIER")
                self.exc.exclude("SUPPLIER", ref)
                continue
            seen[sid] = ref
            extras = self.extras("suppliers", r)
            name = self.label(r.get("name"), 120, ref=ref, entity="SUPPLIER", field_name="name", extras=extras)
            if not name:
                self.exc.add("INVALID_RECORD", ref, "supplier name is empty", MANUAL, "SUPPLIER")
                self.exc.exclude("SUPPLIER", ref)
                continue
            terms = self.label(r.get("payment_terms"), 100, ref=ref, entity="SUPPLIER", field_name="terms", extras=extras)
            rec = {"source_id": ref, "id": sid, "name": name, "terms": terms}
            self.put_extras(rec, extras, ref, "SUPPLIER")
            recs.append(rec)
        self.records["SUPPLIER"] = sorted(recs, key=lambda x: x["source_id"])
        self.supplier_ids = {r["id"] for r in recs}
        self.supplier_by_source = {str(x["supplier_id"]): sanitize_id(x["supplier_id"]) for x in self.rows("suppliers")}

    # ================================================================== PRODUCT (+ variants/SKUs)
    def build_catalog(self) -> None:
        cats = {c["category_id"]: c for c in self.rows("categories")}

        def cat_path(cid) -> str:
            parts, cur, guard = [], cats.get(cid), 0
            while cur is not None and guard < 10:
                parts.append(str(cur["name"]))
                cur = cats.get(cur["parent_id"]) if cur["parent_id"] is not None else None
                guard += 1
            return " > ".join(reversed(parts))

        products = self.rows("products")
        variants = sorted(self.rows("product_variants"), key=lambda v: v["variant_id"])
        prod_by_id = {p["product_id"]: p for p in products}
        # ---- pass A: SKU identity and duplicates (the lowest variant_id wins every duplicate group)
        groups: dict[str, list[dict]] = defaultdict(list)
        for v in variants:
            self.cnt["SKU"] += 1
            sku_id = sanitize_id(v["sku"], upper=True)
            ref = f"product_variants:{v['variant_id']}"
            if not sku_id:
                self.exc.add("INVALID_ID", ref, f"sku {v['sku']!r} is not usable as a chain id", MANUAL, "SKU")
                self.exc.exclude("SKU", ref)
                continue
            self.variant_sku[v["variant_id"]] = sku_id
            self.all_source_skus.add(sku_id)
            groups[sku_id].append(v)
        survivors: list[tuple[str, dict, str]] = []  # (sku_id, variant row, unit)
        for sku_id in sorted(groups):
            g = groups[sku_id]
            winner = g[0]
            for dup in g[1:]:
                ref = f"product_variants:{dup['variant_id']}"
                how = "identical" if str(dup["sku"]) == str(winner["sku"]) else f"equal after normalisation ({dup['sku']!r} vs {winner['sku']!r})"
                self.exc.add("DUPLICATE_SKU", ref, f"sku {how} to variant {winner['variant_id']} ({winner['sku']!r}); the lowest variant_id is kept", EXCLUDED, "SKU")
                self.exc.exclude("SKU", ref)
            ref = f"product_variants:{winner['variant_id']}"
            try:
                u1, u2 = normalise_unit(winner["unit"]), normalise_unit(winner["uom"])
            except ConversionError as e:
                self.exc.add("UNKNOWN_UNIT", ref, str(e), MANUAL, "SKU")
                self.exc.exclude("SKU", ref)
                continue
            if u1 and u2 and u1 != u2:
                self.exc.add("UNIT_MISMATCH", ref, f"unit={winner['unit']!r} ({u1}) but uom={winner['uom']!r} ({u2}); the SKU cannot be migrated until the unit of measure is confirmed", MANUAL, "SKU")
                self.exc.exclude("SKU", ref)
                continue
            unit = u1 or u2
            if unit is None:
                self.exc.add("UNKNOWN_UNIT", ref, "variant has neither unit nor uom", MANUAL, "SKU")
                self.exc.exclude("SKU", ref)
                continue
            if str(winner["unit"]).strip().upper() != unit:
                self.norm["unit_synonyms_normalised"] += 1
            if winner["product_id"] not in prod_by_id:
                self.exc.add("ORPHAN_FK", ref, f"variant references missing product {winner['product_id']}", EXCLUDED, "SKU")
                self.exc.exclude("SKU", ref)
                continue
            survivors.append((sku_id, winner, unit))
        # ---- pass B: products
        by_product: dict[Any, list[tuple[str, dict, str]]] = defaultdict(list)
        for s in survivors:
            by_product[s[1]["product_id"]].append(s)
        prod_recs: list[dict] = []
        seen_codes: dict[str, str] = {}
        good_products: dict[Any, dict] = {}
        for p in sorted(products, key=lambda p: p["product_id"]):
            ref = f"products:{p['product_id']}"
            self.cnt["PRODUCT"] += 1
            code = sanitize_id(p["product_code"])
            vs = by_product.get(p["product_id"], [])
            fatal = False
            if not code:
                self.exc.add("INVALID_ID", ref, f"product_code {p['product_code']!r} is not usable", MANUAL, "PRODUCT")
                fatal = True
            elif code in seen_codes:
                self.exc.add("ID_COLLISION", ref, f"product code {code} already used by {seen_codes[code]}", MANUAL, "PRODUCT")
                fatal = True
            else:
                seen_codes[code] = ref
            status = self.spec.get("product_status", default={}).get(str(p["status"]).strip().upper())
            if status is None:
                self.exc.add("UNKNOWN_STATUS", ref, f"product status {p['status']!r} is not mapped", MANUAL, "PRODUCT")
                fatal = True
            if not vs:
                self.exc.add("EMPTY_RECORD", ref, "product has no migratable variants", EXCLUDED, "PRODUCT")
                fatal = True
            if len(vs) > 50:
                self.exc.add("LIMIT_EXCEEDED", ref, f"{len(vs)} variants (chain maximum 50 per product)", MANUAL, "PRODUCT")
                fatal = True
            extras = self.extras("products", p)
            name = self.label(p["name"], 120, ref=ref, entity="PRODUCT", field_name="name", extras=extras)
            if not name:
                self.exc.add("INVALID_RECORD", ref, "product name is empty", MANUAL, "PRODUCT")
                fatal = True
            brand = self.label(p.get("brand"), 60, ref=ref, entity="PRODUCT", field_name="brand", extras=extras)
            cid = p.get("category_id")
            category = ""
            if cid is not None:
                if cid in cats:
                    category = self.label(cats[cid]["name"], 60, ref=ref, entity="PRODUCT", field_name="category", extras=extras)
                    path = cat_path(cid)
                    if path and path != str(cats[cid]["name"]):
                        extras["category_path"] = path
                else:
                    self.exc.add("ORPHAN_FK", ref, f"product references missing category {cid}; category left empty, original id preserved in source_extras", PRESERVED, "PRODUCT")
                    extras["category_id_orig"] = str(cid)
            if fatal:
                self.exc.exclude("PRODUCT", ref)
                for sku_id, v, _ in vs:
                    vref = f"product_variants:{v['variant_id']}"
                    self.exc.add("EXCLUDED_DEPENDENCY", vref, f"parent product {ref} is not migrated", EXCLUDED, "SKU")
                    self.exc.exclude("SKU", vref)
                continue
            good_products[p["product_id"]] = {"ref": ref, "code": code, "name": name, "brand": brand, "category": category, "status": status, "extras": extras, "vs": vs}
        # ---- pass C: barcodes (unique on chain; the lowest variant_id keeps it)
        owner: dict[str, str] = {}
        all_surv = sorted((t for gp in good_products.values() for t in gp["vs"]), key=lambda t: t[1]["variant_id"])
        cleared: dict[int, tuple[str, str]] = {}
        for sku_id, v, unit in all_surv:
            bc = str(v["barcode"]).strip() if v.get("barcode") is not None else ""
            if not bc:
                continue
            ref = f"product_variants:{v['variant_id']}"
            if len(bc) > 32:
                self.exc.add("INVALID_BARCODE", ref, f"barcode longer than 32 characters; cleared, original preserved in source_extras", PRESERVED, "SKU")
                cleared[v["variant_id"]] = (bc, "too long")
            elif bc in owner:
                self.exc.add("DUPLICATE_BARCODE", ref, f"barcode {bc} is already assigned to {owner[bc]}; cleared here, original preserved in source_extras", PRESERVED, "SKU")
                cleared[v["variant_id"]] = (bc, f"duplicate of {owner[bc]}")
            else:
                owner[bc] = sku_id
        # ---- pass D: records
        for pid in sorted(good_products):
            gp = good_products[pid]
            vrecs = []
            for sku_id, v, unit in sorted(gp["vs"], key=lambda t: t[0]):
                vref = f"product_variants:{v['variant_id']}"
                vex = self.extras("product_variants", v)
                vex["source_id"] = vref
                if str(v["sku"]) != sku_id:
                    vex["sku_source"] = str(v["sku"])
                attrs: dict[str, str] = {}
                for col in ("colour", "size", "weight_g"):
                    val = v.get(col)
                    if val is None or str(val).strip() == "":
                        continue
                    attrs[col], _ = ascii_label(render_value(val), 200)
                bc = str(v["barcode"]).strip() if v.get("barcode") is not None else ""
                if v["variant_id"] in cleared:
                    vex["barcode_original"], vex["barcode_cleared_reason"] = cleared[v["variant_id"]][0], cleared[v["variant_id"]][1]
                    bc = ""
                vr: dict[str, Any] = {"sku_id": sku_id, "barcode": bc, "unit": unit, "scarce": bool(v.get("scarce")), "attributes": attrs}
                self.put_extras(vr, vex, vref, "SKU")
                vrecs.append(vr)
                self.sku_info[sku_id] = {"unit": unit, "product_id": gp["code"]}
            rec = {"source_id": gp["ref"], "id": gp["code"], "name": gp["name"], "brand": gp["brand"], "category": gp["category"], "status": gp["status"],
                   "attributes": {}, "variants": vrecs}
            self.put_extras(rec, gp["extras"], gp["ref"], "PRODUCT")
            prod_recs.append(rec)
        self.records["PRODUCT"] = sorted(prod_recs, key=lambda x: x["source_id"])

    # ================================================================== PRICE
    def build_prices(self) -> None:
        lists = {l["list_id"]: l for l in self.rows("price_lists")}
        cand: dict[tuple[str, str, int], list[tuple[int, dict]]] = defaultdict(list)
        for it in sorted(self.rows("price_list_items"), key=lambda i: i["item_id"]):
            ref = f"price_list_items:{it['item_id']}"
            self.cnt["PRICE"] += 1
            fatal = False
            sku_id = sanitize_id(it["sku"], upper=True)
            if sku_id not in self.all_source_skus:
                self.exc.add("ORPHAN_FK", ref, f"price for unknown sku {it['sku']!r}", EXCLUDED, "PRICE")
                fatal = True
            elif sku_id not in self.sku_info:
                self.exc.add("EXCLUDED_DEPENDENCY", ref, f"sku {sku_id} is not migrated", EXCLUDED, "PRICE")
                fatal = True
            lst = lists.get(it["list_id"])
            if lst is None:
                self.exc.add("ORPHAN_FK", ref, f"price references missing price list {it['list_id']}", EXCLUDED, "PRICE")
                self.exc.exclude("PRICE", ref)
                continue
            ccy = str(lst["currency"] or self.spec.default_currency).strip().upper()
            code = lst["location_code"]
            if code is None or str(code).strip() == "":
                loc = "*"
            else:
                loc = self.loc_ids.get(str(code).strip())
                if loc is None:
                    self.exc.add("ORPHAN_FK", ref, f"price list {lst['list_id']} targets unknown location {code!r}", EXCLUDED, "PRICE")
                    fatal = True
                elif self.loc_ccy.get(loc) != ccy:
                    self.exc.add("CURRENCY_MISMATCH", ref, f"price list currency {ccy} but location {loc} trades in {self.loc_ccy.get(loc)}; the chain refuses the price", EXCLUDED, "PRICE")
                    fatal = True
            minor = self.money(it["price"], ccy, ref, "PRICE", "price") if ccy in ("GBP", "USD", "EUR", "JPY") else None
            if minor is None:
                fatal = True
            elif minor <= 0:
                self.exc.add("INVALID_PRICE", ref, f"price {it['price']!r} is not positive", EXCLUDED, "PRICE")
                fatal = True
            elif minor > 1_000_000_000:
                self.exc.add("INVALID_PRICE", ref, f"price {minor} minor units exceeds the chain limit", EXCLUDED, "PRICE")
                fatal = True
            from_ms = self.ts(it["valid_from"], ref, "PRICE", "valid_from")
            if from_ms is None:
                fatal = True
            to_ms = 0
            if it["valid_to"] is not None and str(it["valid_to"]).strip() != "":
                to_ms_ = self.ts(it["valid_to"], ref, "PRICE", "valid_to")
                if to_ms_ is None:
                    fatal = True
                else:
                    to_ms = to_ms_
            if not fatal and to_ms and to_ms <= from_ms:
                self.exc.add("PRICE_PERIOD_INVALID", ref, "valid_to is not after valid_from", EXCLUDED, "PRICE")
                fatal = True
            if fatal:
                self.exc.exclude("PRICE", ref)
                continue
            if to_ms and to_ms <= self.ref_ms:
                self.exc.skip_scope("PRICE", EXPIRED_PRICE)
                self.expired["PRICE"][ref] = EXPIRED_PRICE
                continue
            cand[(sku_id, loc, from_ms)].append((it["item_id"], {"source_id": ref, "id": f"{self.spec.get('price_id_prefix', default='PRC-')}{it['item_id']:07d}", "sku": sku_id,
                                                                 "location": loc, "currency": ccy, "unit_minor": minor, "from_ms": from_ms, "to_ms": to_ms}))
        recs = []
        for key in sorted(cand):
            g = sorted(cand[key], key=lambda t: t[0])
            for item_id, rec in g[:-1]:
                self.exc.add("DUPLICATE_PRICE", rec["source_id"], f"another price for {key[0]}@{key[1]} has the same effective-from; the later item {g[-1][0]} wins (chain forbids two prices with one effective_from)", EXCLUDED, "PRICE")
                self.exc.exclude("PRICE", rec["source_id"])
            recs.append(g[-1][1])
        self.records["PRICE"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== PROMOTION (native ActivatePromotion, signed by pricing-mgr)
    def build_promotions(self) -> None:
        types = self.spec.get("promo_types", default={})
        ended = {s.upper() for s in self.spec.get("promo_ended_status", default=[])}
        skus_by: dict[str, list[str]] = defaultdict(list)
        for ps in self.rows("promotion_skus"):
            skus_by[str(ps["promo_id"])].append(str(ps["sku"]))
        out = []
        for p in sorted(self.rows("promotions"), key=lambda p: str(p["promo_id"])):
            ref = f"promotions:{p['promo_id']}"
            self.cnt["PROMOTION"] += 1
            status = str(p["status"]).strip().upper()
            ends = None
            if p["ends_at"] is not None and str(p["ends_at"]).strip():
                try:
                    ends = normalise_timestamp(p["ends_at"], self.tz).ms
                except ConversionError:
                    ends = None
            if status in ended or (ends is not None and ends <= self.ref_ms):
                self.exc.skip_scope("PROMOTION", ENDED_PROMOTION)
                self.expired["PROMOTION"][ref] = ENDED_PROMOTION
                continue
            fatal = False
            ptype = types.get(str(p["promo_type"]).strip().upper())
            payload: dict[str, Any] = {"bp": 0, "off_minor": 0, "buy_n": 0, "bundle_minor": 0}
            ccy = str(p.get("currency") or self.spec.default_currency).strip().upper()
            if ptype is None:
                self.exc.add("UNSUPPORTED_PROMO_TYPE", ref, f"promotion type {p['promo_type']!r} has no chain equivalent (chain supports PERCENT_OFF, AMOUNT_OFF_PER_UNIT, MULTIBUY_FIXED_PRICE)", MANUAL, "PROMOTION")
                fatal = True
            elif ptype == "PERCENT_OFF":
                try:
                    bp = int((Decimal(repr(float(p["pct_off"]))) * 100).quantize(Decimal(1)))
                except Exception:
                    bp = 0
                if not 1 <= bp <= 10000:
                    self.exc.add("INVALID_RECORD", ref, f"pct_off {p['pct_off']!r} out of range", MANUAL, "PROMOTION")
                    fatal = True
                payload["bp"] = bp
            elif ptype == "AMOUNT_OFF_PER_UNIT":
                m = self.money(p["amount_off"], ccy, ref, "PROMOTION", "amount_off")
                if not m or m < 1:
                    self.exc.add("INVALID_RECORD", ref, f"amount_off {p['amount_off']!r} invalid", MANUAL, "PROMOTION")
                    fatal = True
                payload["off_minor"] = m or 0
            elif ptype == "MULTIBUY_FIXED_PRICE":
                m = self.money(p["bundle_price"], ccy, ref, "PROMOTION", "bundle_price")
                n = p["buy_qty"]
                if not m or m < 1 or n is None or not 2 <= int(n) <= 100:
                    self.exc.add("INVALID_RECORD", ref, f"multibuy buy_qty={n!r} bundle_price={p['bundle_price']!r} invalid", MANUAL, "PROMOTION")
                    fatal = True
                payload["bundle_minor"], payload["buy_n"] = m or 0, int(n or 0)
            from_ms = self.ts(p["starts_at"], ref, "PROMOTION", "starts_at") if p["starts_at"] not in (None, "") else None
            if from_ms is None:
                if p["starts_at"] in (None, ""):
                    self.exc.add("INVALID_TIMESTAMP", ref, "promotion has no start date", MANUAL, "PROMOTION")
                fatal = True
            skus = []
            for s in skus_by.get(str(p["promo_id"]), []):
                sid = sanitize_id(s, upper=True)
                if sid in self.sku_info:
                    skus.append(sid)
                else:
                    self.exc.add("ORPHAN_FK", ref, f"promotion sku {s!r} is not migrated; removed from the promotion", FIXED, "PROMOTION")
            skus = sorted(set(skus))
            if not skus:
                self.exc.add("EMPTY_RECORD", ref, "promotion applies to no migrated SKU", EXCLUDED, "PROMOTION")
                fatal = True
            if len(skus) > 50:
                self.exc.add("LIMIT_EXCEEDED", ref, f"{len(skus)} SKUs (chain maximum 50 per promotion)", MANUAL, "PROMOTION")
                fatal = True
            scope = str(p.get("location_scope") or "ALL").strip()
            if scope.upper() in ("ALL", "*", ""):
                locs = ["*"]
            else:
                locs = []
                for code in [c.strip() for c in scope.split(",") if c.strip()]:
                    cid = self.loc_ids.get(code)
                    if cid:
                        locs.append(cid)
                    else:
                        self.exc.add("ORPHAN_FK", ref, f"promotion location {code!r} unknown; removed", FIXED, "PROMOTION")
                locs = sorted(set(locs))
                if not locs:
                    self.exc.add("EMPTY_RECORD", ref, "promotion applies to no known location", EXCLUDED, "PROMOTION")
                    fatal = True
            name = self.label(p["name"], 100, ref=ref, entity="PROMOTION", field_name="name", extras=None)
            if not name:
                fatal = True
            if fatal:
                self.exc.exclude("PROMOTION", ref)
                continue
            payload.update({"promo_id": f"{self.spec.get('promo_id_prefix', default='PRM-')}{sanitize_id(p['promo_id'])}", "name": name, "type": ptype, "skus": skus, "locations": locs,
                            "effective_from_ms": from_ms, "effective_to_ms": ends or 0, "priority": int(p["priority"] if p["priority"] is not None else 100),
                            "stackable": bool(p["stackable"]), "loyalty_only": bool(p["loyalty_only"]), "status": "ACTIVE", "currency": ccy})
            payload["_source_ref"] = ref
            out.append(payload)
        self.promotions = sorted(out, key=lambda x: x["promo_id"])

    # ================================================================== OPENING_BALANCE
    def build_balances(self) -> None:
        pre: list[dict] = []
        for r in sorted(self.rows("inventory_balances"), key=lambda r: r["inv_id"]):
            ref = f"inventory_balances:{r['inv_id']}"
            self.cnt["OPENING_BALANCE"] += 1
            fatal = False
            sku_id = sanitize_id(r["sku"], upper=True)
            loc = self.loc_ids.get(str(r["location_code"]).strip())
            if loc is None:
                self.exc.add("ORPHAN_FK", ref, f"inventory row for unknown location {r['location_code']!r}", EXCLUDED, "OPENING_BALANCE")
                fatal = True
            if sku_id not in self.all_source_skus:
                self.exc.add("ORPHAN_FK", ref, f"inventory row for unknown SKU {r['sku']!r}", EXCLUDED, "OPENING_BALANCE")
                fatal = True
            elif sku_id not in self.sku_info:
                self.exc.add("EXCLUDED_DEPENDENCY", ref, f"sku {sku_id} is not migrated", EXCLUDED, "OPENING_BALANCE")
                fatal = True
            unit = self.sku_info.get(sku_id, {}).get("unit")
            if unit and r.get("unit") not in (None, ""):
                try:
                    ru = normalise_unit(r["unit"])
                except ConversionError as e:
                    self.exc.add("UNKNOWN_UNIT", ref, str(e), MANUAL, "OPENING_BALANCE")
                    ru = unit
                    fatal = True
                if ru != unit:
                    self.exc.add("UNIT_MISMATCH", ref, f"balance row unit {r['unit']!r} ({ru}) differs from SKU {sku_id} unit {unit}", MANUAL, "OPENING_BALANCE")
                    fatal = True
            qtys: dict[str, int] = {}
            for bucket, col in (("available", "on_hand"), ("damaged", "damaged")):
                val = r.get(col)
                if val is None:
                    continue
                try:
                    q = to_qty(val, unit or "EA", allow_negative=True)
                except ConversionError as e:
                    self.exc.add(e.kind, ref, f"{col}: {e}", MANUAL, "OPENING_BALANCE")
                    fatal = True
                    continue
                if q.v < 0:
                    self.exc.add("NEGATIVE_STOCK", ref, f"{col} is negative ({val!r}); a negative physical balance cannot be imported - recount before cutover", MANUAL, "OPENING_BALANCE")
                    fatal = True
                    continue
                if unit and q.fractional_whole_unit:
                    self.exc.add("FRACTIONAL_QUANTITY", ref, f"{col} {val!r} is fractional for an {unit} item; rounded half-even to {q.v} (recount advised)", FIXED, "OPENING_BALANCE")
                elif unit and q.genuine_rounding:
                    self.exc.add("QTY_ROUNDED", ref, f"{col} {val!r} rounded half-even to {q.v} (smallest {unit} step)", FIXED, "OPENING_BALANCE")
                qtys[bucket] = q.v
            if fatal:
                self.exc.exclude("OPENING_BALANCE", ref)
                continue
            pre.append({"ref": ref, "sku": sku_id, "loc": loc, "unit": unit, "qtys": qtys})
        # duplicate (sku, location) rows would double the balance: refuse all of them
        groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
        for p in pre:
            groups[(p["sku"], p["loc"])].append(p)
        recs = []
        for key in sorted(groups):
            g = groups[key]
            if len(g) > 1:
                for p in g:
                    self.exc.add("DUPLICATE_BALANCE_ROW", p["ref"], f"{len(g)} balance rows for {key[0]} at {key[1]} ({', '.join(x['ref'] for x in g)}); the correct count must be decided manually", MANUAL, "OPENING_BALANCE")
                    self.exc.exclude("OPENING_BALANCE", p["ref"])
                continue
            p = g[0]
            made = False
            for bucket in ("available", "damaged"):
                v = p["qtys"].get(bucket, 0)
                if v > 0:
                    recs.append({"source_id": p["ref"] + ("" if bucket == "available" else "#damaged"), "sku": p["sku"], "location": p["loc"],
                                 "qty": {"v": v, "unit": p["unit"]}, "bucket": bucket})
                    made = True
            if not made:
                self.exc.skip_scope("OPENING_BALANCE", "zero quantity (nothing to import)")
        self.records["OPENING_BALANCE"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== OPEN_PO
    def build_open_pos(self) -> None:
        open_map = self.spec.get("po_open_status", default={})
        not_out = {s.upper() for s in self.spec.get("po_not_outstanding", default=[])}
        lines_by: dict[str, list[dict]] = defaultdict(list)
        for l in sorted(self.rows("purchase_order_lines"), key=lambda l: l["line_id"]):
            lines_by[str(l["po_number"])].append(l)
        recs, seen = [], {}
        for po in sorted(self.rows("purchase_orders"), key=lambda p: str(p["po_number"])):
            ref = f"purchase_orders:{po['po_number']}"
            st = str(po["status"]).strip().upper()
            self.cnt["OPEN_PO"] += 1
            if st in not_out:
                self.exc.skip_scope("OPEN_PO", f"status {st}: not outstanding (only outstanding purchase orders are migrated)")
                continue
            status = open_map.get(st)
            fatal = False
            if status is None:
                self.exc.add("UNKNOWN_STATUS", ref, f"purchase order status {po['status']!r} is not mapped", MANUAL, "OPEN_PO")
                fatal = True
            pid = sanitize_id(po["po_number"])
            if not pid:
                self.exc.add("INVALID_ID", ref, f"po_number {po['po_number']!r} is not usable", MANUAL, "OPEN_PO")
                fatal = True
            elif pid in seen:
                self.exc.add("ID_COLLISION", ref, f"chain id {pid} already derived from {seen[pid]}", MANUAL, "OPEN_PO")
                fatal = True
            else:
                seen[pid] = ref
            sup = self.supplier_by_source.get(str(po["supplier_id"])) if po["supplier_id"] is not None else None
            if sup is None or sup not in self.supplier_ids:
                if str(po["supplier_id"]) in self.supplier_by_source:
                    self.exc.add("EXCLUDED_DEPENDENCY", ref, f"supplier {po['supplier_id']} is not migrated", EXCLUDED, "OPEN_PO")
                else:
                    self.exc.add("ORPHAN_FK", ref, f"purchase order references missing supplier {po['supplier_id']!r}", EXCLUDED, "OPEN_PO")
                fatal = True
            loc = self.loc_ids.get(str(po["location_code"]).strip())
            if loc is None:
                self.exc.add("ORPHAN_FK", ref, f"purchase order delivers to unknown location {po['location_code']!r}", EXCLUDED, "OPEN_PO")
                fatal = True
            ccy = str(po.get("currency") or self.spec.default_currency).strip().upper()
            ordered = self.ts(po["ordered_at"], ref, "OPEN_PO", "ordered_at") if po["ordered_at"] not in (None, "") else None
            if ordered is None:
                if po["ordered_at"] in (None, ""):
                    self.exc.add("INVALID_TIMESTAMP", ref, "purchase order has no ordered_at", MANUAL, "OPEN_PO")
                fatal = True
            lines = lines_by.get(str(po["po_number"]), [])
            if not lines or len(lines) > 100:
                self.exc.add("EMPTY_RECORD" if not lines else "LIMIT_EXCEEDED", ref, f"{len(lines)} lines (chain accepts 1..100)", EXCLUDED if not lines else MANUAL, "OPEN_PO")
                fatal = True
            plines = []
            all_received = bool(lines)
            for l in lines:
                sku_id = sanitize_id(l["sku"], upper=True)
                unit = self.sku_info.get(sku_id, {}).get("unit")
                if sku_id not in self.all_source_skus:
                    self.exc.add("ORPHAN_FK", ref, f"line {l['line_id']} references unknown SKU {l['sku']!r}", EXCLUDED, "OPEN_PO")
                    fatal = True
                    continue
                if unit is None:
                    self.exc.add("EXCLUDED_DEPENDENCY", ref, f"line {l['line_id']}: sku {sku_id} is not migrated", EXCLUDED, "OPEN_PO")
                    fatal = True
                    continue
                if l.get("unit") not in (None, ""):
                    try:
                        lu = normalise_unit(l["unit"])
                    except ConversionError:
                        lu = None
                    if lu != unit:
                        self.exc.add("UNIT_MISMATCH", ref, f"line {l['line_id']} unit {l['unit']!r} differs from SKU unit {unit}", MANUAL, "OPEN_PO")
                        fatal = True
                        continue
                try:
                    qo, qr = to_qty(l["qty_ordered"], unit), to_qty(l["qty_received"], unit)
                except ConversionError as e:
                    self.exc.add(e.kind, ref, f"line {l['line_id']}: {e}", MANUAL, "OPEN_PO")
                    fatal = True
                    continue
                if qo.fractional_whole_unit or qr.fractional_whole_unit:
                    self.exc.add("FRACTIONAL_QUANTITY", ref, f"line {l['line_id']} has a fractional EA quantity", MANUAL, "OPEN_PO")
                    fatal = True
                    continue
                if qo.v <= 0:
                    self.exc.add("INVALID_QUANTITY", ref, f"line {l['line_id']} ordered quantity is not positive", MANUAL, "OPEN_PO")
                    fatal = True
                    continue
                recv = qr.v
                if recv > qo.v:
                    self.exc.add("OVER_RECEIPT", ref, f"line {l['line_id']} received {recv} > ordered {qo.v}; clamped to the ordered quantity", FIXED, "OPEN_PO")
                    recv = qo.v
                cost = self.money(l["unit_cost"], ccy, ref, "OPEN_PO", f"line {l['line_id']} unit_cost") if ccy in ("GBP", "USD", "EUR", "JPY") else None
                if cost is None or cost <= 0:
                    if cost is not None:
                        self.exc.add("INVALID_PRICE", ref, f"line {l['line_id']} unit_cost {l['unit_cost']!r} is not positive", MANUAL, "OPEN_PO")
                    fatal = True
                    continue
                if recv < qo.v:
                    all_received = False
                plines.append({"sku": sku_id, "qty": {"v": qo.v, "unit": unit}, "unit_cost_minor": cost, "received_v": recv})
            if not fatal and (all_received or po.get("closed_at") not in (None, "")):
                self.exc.add("STALE_PO_CLOSED", ref, f"status {po['status']} but " + ("every line is fully received" if all_received else "") + (" and " if all_received and po.get("closed_at") else "") +
                             (f"closed_at={po['closed_at']!r}" if po.get("closed_at") else "") + "; nothing is outstanding, not migrated", EXCLUDED, "OPEN_PO")
                fatal = True
            if fatal:
                self.exc.exclude("OPEN_PO", ref)
                continue
            extras = self.extras("purchase_orders", po)
            rec = {"source_id": ref, "id": pid, "supplier_id": sup, "location": loc, "currency": ccy, "ordered_at_ms": ordered, "status": status, "lines": plines}
            self.put_extras(rec, extras, ref, "OPEN_PO")
            recs.append(rec)
        self.records["OPEN_PO"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== LOYALTY_OPENING
    def build_loyalty(self) -> None:
        salt = self.spec.get("ids", "pseudonym_salt", default="aureom-mig-v1")
        self.customers_raw = {str(c["customer_id"]) for c in self.rows("customers")}
        mapped: dict[str, list[tuple[str, dict, str]]] = defaultdict(list)
        for a in sorted(self.rows("loyalty_accounts"), key=lambda a: str(a["customer_id"])):
            ref = f"loyalty_accounts:{a['customer_id']}"
            self.cnt["LOYALTY_OPENING"] += 1
            try:
                cid, how = map_customer_id(a["customer_id"], salt)
            except ConversionError as e:
                self.exc.add("INVALID_ID", ref, str(e), MANUAL, "LOYALTY_OPENING")
                self.exc.exclude("LOYALTY_OPENING", ref)
                continue
            if how != "as-is":
                self.exc.add("LEGACY_CUSTOMER_ID", ref, f"customer id {a['customer_id']!r} does not match the chain's synthetic id format; mapped to {cid} ({how})", FIXED, "LOYALTY_OPENING")
            mapped[cid].append((ref, a, how))
        recs = []
        for cid in sorted(mapped):
            g = mapped[cid]
            if len(g) > 1:
                for ref, a, how in g:
                    self.exc.add("DUPLICATE_CUSTOMER_ID", ref, f"{len(g)} loyalty accounts normalise to {cid} ({', '.join(x[0] for x in g)}); which balance is right must be decided manually", MANUAL, "LOYALTY_OPENING")
                    self.exc.exclude("LOYALTY_OPENING", ref)
                continue
            ref, a, how = g[0]
            fatal = False
            if str(a["customer_id"]) not in self.customers_raw:
                self.exc.add("ORPHAN_FK", ref, f"loyalty account {a['customer_id']!r} has no customer record", MANUAL, "LOYALTY_OPENING")
                fatal = True
            try:
                pts = Decimal(str(a["points_balance"]))
            except Exception:
                self.exc.add("INVALID_AMOUNT", ref, f"points_balance {a['points_balance']!r} is not a number", MANUAL, "LOYALTY_OPENING")
                fatal = True
                pts = Decimal(0)
            if pts < 0:
                self.exc.add("NEGATIVE_POINTS", ref, f"points_balance {a['points_balance']!r} is negative", MANUAL, "LOYALTY_OPENING")
                fatal = True
            elif pts != pts.to_integral_value():
                self.exc.add("POINTS_ROUNDED", ref, f"points_balance {a['points_balance']!r} is fractional; rounded half-even", FIXED, "LOYALTY_OPENING")
            pv = int(pts.quantize(Decimal(1))) if not fatal else 0
            if pv > 1_000_000_000:
                self.exc.add("INVALID_AMOUNT", ref, "points_balance too large", MANUAL, "LOYALTY_OPENING")
                fatal = True
            if fatal:
                self.exc.exclude("LOYALTY_OPENING", ref)
                continue
            recs.append({"source_id": ref, "customer_id": cid, "points": pv})
        self.records["LOYALTY_OPENING"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== HISTORICAL_SALE
    def build_sales(self) -> None:
        spec = self.spec
        channels = {k.upper(): v for k, v in spec.get("channels", default={}).items()}
        migrated_status = {s.upper() for s in spec.get("sale_migrated_status", default=[])}
        captured = {s.upper() for s in spec.get("payment_captured_status", default=[])}
        failed = {s.upper() for s in spec.get("payment_failed_status", default=[])}
        refund_done = {s.upper() for s in spec.get("refund_done_status", default=[])}
        tol = int(spec.get("conversions", "tolerance_line_total_minor", default=1))
        salt = spec.get("ids", "pseudonym_salt", default="aureom-mig-v1")
        lines_by: dict[Any, list[dict]] = defaultdict(list)
        for l in sorted(self.rows("sale_lines"), key=lambda l: l["line_id"]):
            lines_by[l["sale_id"]].append(l)
        pays_by: dict[Any, list[dict]] = defaultdict(list)
        sale_ids = {s["sale_id"] for s in self.rows("sales")}
        for p in sorted(self.rows("payments"), key=lambda p: p["payment_id"]):
            if p["sale_id"] not in sale_ids:
                self.exc.add("ORPHAN_FK", f"payments:{p['payment_id']}", f"payment references missing sale {p['sale_id']!r}", EXCLUDED, "HISTORICAL_SALE")
                continue
            pays_by[p["sale_id"]].append(p)
        refs_by: dict[Any, list[dict]] = defaultdict(list)
        for f in sorted(self.rows("refunds"), key=lambda f: f["refund_id"]):
            if f["sale_id"] in sale_ids:
                refs_by[f["sale_id"]].append(f)
        recs = []
        id_fmt = spec.get("ids", "sale", default="HS-{sale_id:08d}")
        for s in sorted(self.rows("sales"), key=lambda s: s["sale_id"]):
            sid = s["sale_id"]
            ref = f"sales:{sid}"
            st = str(s["status"]).strip().upper()
            self.cnt["HISTORICAL_SALE"] += 1
            if st not in migrated_status:
                self.exc.skip_scope("HISTORICAL_SALE", f"status {st}: not a completed sale (not migrated)")
                continue
            fatal = False
            ccy = str(s.get("currency") or spec.default_currency).strip().upper()
            if ccy not in ("GBP", "USD", "EUR", "JPY"):
                self.exc.add("INVALID_CURRENCY", ref, f"currency {ccy!r}", MANUAL, "HISTORICAL_SALE")
                fatal = True
                ccy = spec.default_currency
            # time
            eff = self.ts(s["sold_at"], ref, "HISTORICAL_SALE", "sold_at")
            if eff is None:
                fatal = True
            elif eff > self.ref_ms + FUTURE_SKEW_MS:
                self.exc.add("FUTURE_TIMESTAMP", ref, f"sold_at {s['sold_at']!r} is after the snapshot time ({iso_utc(self.ref_ms)})", MANUAL, "HISTORICAL_SALE")
                fatal = True
            # channel & location
            channel = channels.get(str(s["channel"]).strip().upper())
            if channel is None:
                self.exc.add("UNKNOWN_CHANNEL", ref, f"sales channel {s['channel']!r} is not mapped (known: {', '.join(sorted(channels))})", MANUAL, "HISTORICAL_SALE")
                fatal = True
            code = s["store_code"]
            if code is None or str(code).strip() == "":
                if channel == "ECOM":
                    loc = spec.get("ecom_fulfilment_location")
                else:
                    loc = None
                    if channel is not None:
                        self.exc.add("ORPHAN_FK", ref, "store sale without a store", EXCLUDED, "HISTORICAL_SALE")
                        fatal = True
            else:
                loc = self.loc_ids.get(str(code).strip())
                if loc is None:
                    self.exc.add("ORPHAN_FK", ref, f"sale at unknown store {code!r}", EXCLUDED, "HISTORICAL_SALE")
                    fatal = True
            # lines
            lrecs = []
            src_lines = lines_by.get(sid, [])
            if not src_lines:
                self.exc.add("EMPTY_RECORD", ref, "sale has no lines", EXCLUDED, "HISTORICAL_SALE")
                fatal = True
            mismatch_notes = []
            for ln in src_lines:
                lref = f"line {ln['line_id']}"
                sku_id = self.variant_sku.get(ln["variant_id"]) if ln["variant_id"] is not None else None
                if sku_id is None:
                    self.exc.add("ORPHAN_FK", ref, f"sale {lref} references missing variant {ln['variant_id']!r}", EXCLUDED, "HISTORICAL_SALE")
                    fatal = True
                    continue
                unit = self.sku_info.get(sku_id, {}).get("unit")
                if unit is None:
                    self.exc.add("EXCLUDED_DEPENDENCY", ref, f"sale {lref}: sku {sku_id} is not migrated", EXCLUDED, "HISTORICAL_SALE")
                    fatal = True
                    continue
                if ln.get("unit") not in (None, ""):
                    try:
                        lu = normalise_unit(ln["unit"])
                    except ConversionError:
                        lu = None
                    if lu != unit:
                        self.exc.add("UNIT_MISMATCH", ref, f"sale {lref} unit {ln['unit']!r} differs from SKU {sku_id} unit {unit}", MANUAL, "HISTORICAL_SALE")
                        fatal = True
                        continue
                try:
                    q = to_qty(ln["qty"], unit)
                except ConversionError as e:
                    self.exc.add(e.kind, ref, f"sale {lref}: {e}", MANUAL, "HISTORICAL_SALE")
                    fatal = True
                    continue
                if q.fractional_whole_unit:
                    self.exc.add("FRACTIONAL_QUANTITY", ref, f"sale {lref} sells {ln['qty']!r} of an {unit} item; not representable", MANUAL, "HISTORICAL_SALE")
                    fatal = True
                    continue
                if q.v <= 0:
                    self.exc.add("INVALID_QUANTITY", ref, f"sale {lref} quantity {ln['qty']!r} is not positive", MANUAL, "HISTORICAL_SALE")
                    fatal = True
                    continue
                unit_minor = self.money(ln["unit_price"], ccy, ref, "HISTORICAL_SALE", f"{lref} unit_price")
                disc = self.money(ln["discount"], ccy, ref, "HISTORICAL_SALE", f"{lref} discount")
                net = self.money(ln["line_total"], ccy, ref, "HISTORICAL_SALE", f"{lref} line_total")
                if unit_minor is None or disc is None or net is None:
                    fatal = True
                    continue
                gross = line_amount(unit_minor, q.v, unit)
                if abs(gross - disc - net) > tol:
                    mismatch_notes.append(f"{lref}: qty x price - discount = {gross - disc} but recorded line_total = {net}")
                if gross < net:
                    gross = net
                lrecs.append({"sku": sku_id, "qty": {"v": q.v, "unit": unit}, "unit_minor": unit_minor, "gross_minor": gross, "net_minor": net})
            if mismatch_notes:
                self.exc.add("LINE_TOTAL_MISMATCH", ref, "; ".join(mismatch_notes) + "; the recorded line_total is kept as net and the discount derived", FIXED, "HISTORICAL_SALE")
            if len(lrecs) > 100:
                self.exc.add("LIMIT_EXCEEDED", ref, f"{len(lrecs)} lines (chain maximum 100)", MANUAL, "HISTORICAL_SALE")
                fatal = True
            net_total = sum(l["net_minor"] for l in lrecs)
            # header cross-check
            extras = self.extras("sales", s, skip=("total", "discount_total"))
            extras["sold_at_raw"] = str(s["sold_at"])
            if s.get("total") is not None:
                try:
                    hm = to_minor(s["total"], ccy, allow_negative=True).value
                    extras["source_header_total_minor"] = str(hm)
                    if lrecs and not fatal and abs(hm - net_total) > tol:
                        self.exc.add("HEADER_TOTAL_MISMATCH", ref, f"header total {hm} differs from the sum of line nets {net_total}; the lines are authoritative", FIXED, "HISTORICAL_SALE")
                except ConversionError:
                    pass
            if s.get("discount_total") is not None:
                try:
                    extras["source_header_discount_minor"] = str(to_minor(s["discount_total"], ccy, allow_negative=True).value)
                except ConversionError:
                    pass
            # customer
            cust = ""
            cs = s.get("customer_id")
            if cs is not None and str(cs).strip() != "":
                if str(cs) not in self.customers_raw:
                    self.exc.add("ORPHAN_FK", ref, f"sale customer {cs!r} has no customer record; sale kept anonymous, original id preserved in source_extras", PRESERVED, "HISTORICAL_SALE")
                    extras["customer_id_source"] = str(cs)
                else:
                    try:
                        cust, how = map_customer_id(cs, salt)
                        if how != "as-is":
                            extras["customer_id_source"] = str(cs)
                    except ConversionError:
                        pass
            # payments / refunds
            pj, paid, any_failed = [], 0, False
            for p in pays_by.get(sid, []):
                amt = self.money(p["amount"], ccy, ref, "HISTORICAL_SALE", f"payment {p['payment_id']} amount", allow_negative=True)
                if amt is None:
                    fatal = True
                    continue
                pst = str(p["status"]).strip().upper()
                if pst in captured:
                    paid += amt
                elif pst in failed:
                    any_failed = True
                pj.append({"id": p["payment_id"], "method": p["method"], "amount_minor": amt, "status": pst, "provider_ref": p["provider_ref"]})
            refunded, rj = 0, []
            for f in refs_by.get(sid, []):
                amt = self.money(f["amount"], ccy, ref, "HISTORICAL_SALE", f"refund {f['refund_id']} amount")
                if amt is None:
                    fatal = True
                    continue
                fst = str(f["status"]).strip().upper()
                if fst in refund_done:
                    refunded += amt
                rj.append({"id": f["refund_id"], "return_id": f["return_id"], "amount_minor": amt, "status": fst, "refunded_at": f["refunded_at"]})
            if pj:
                extras["payments"] = json.dumps(pj, separators=(",", ":"), sort_keys=True)
            if rj:
                extras["refunds"] = json.dumps(rj, separators=(",", ":"), sort_keys=True)
            if lrecs and not fatal and refunded > net_total:
                self.exc.add("REFUND_EXCEEDS_SALE", ref, f"refunds {refunded} exceed the sale net {net_total}", MANUAL, "HISTORICAL_SALE")
                fatal = True
            if paid == 0:
                pstat = "FAILED" if any_failed else "INSTRUCTED"
            elif paid == net_total:
                pstat = "CONFIRMED"
            elif paid < net_total:
                pstat = "PARTIALLY_PAID"
            else:
                pstat = "OVERPAID"
            if lrecs and not fatal and pstat != "CONFIRMED":
                self.exc.add("PAYMENT_MISMATCH", ref, f"captured payments {paid} vs sale net {net_total} -> {pstat}; asserted as recorded, payment breakdown preserved in source_extras", PRESERVED, "HISTORICAL_SALE")
            if fatal:
                self.exc.exclude("HISTORICAL_SALE", ref)
                continue
            cid_part = id_fmt.format(sale_id=sid)
            rec = {"source_id": ref, "id": sanitize_id(cid_part), "location": loc, "channel": channel, "customer_id": cust, "currency": ccy, "effective_at_ms": eff,
                   "lines": lrecs, "payment_status": pstat, "paid_minor": paid, "refunded_minor": refunded}
            self.put_extras(rec, extras, ref, "HISTORICAL_SALE")
            recs.append(rec)
        self.records["HISTORICAL_SALE"] = sorted(recs, key=lambda x: x["source_id"])

    # ================================================================== orchestration
    def source_counts(self) -> dict[str, int]:
        c = self.con
        q = lambda sql: c.execute(sql).fetchone()[0]
        return {
            "locations": q("SELECT count(*) FROM stores") + q("SELECT count(*) FROM warehouses"),
            "suppliers": q("SELECT count(*) FROM suppliers"),
            "products": q("SELECT count(*) FROM products"),
            "skus": q("SELECT count(*) FROM product_variants"),
            "prices": q("SELECT count(*) FROM price_list_items"),
            "promotions": q("SELECT count(*) FROM promotions"),
            "stock_rows": q("SELECT count(*) FROM inventory_balances"),
            "purchase_orders": q("SELECT count(*) FROM purchase_orders"),
            "loyalty_accounts": q("SELECT count(*) FROM loyalty_accounts"),
            "sales": q("SELECT count(*) FROM sales"),
            "completed_sales": q("SELECT count(*) FROM sales WHERE upper(status) = 'COMPLETE'"),
            "sale_lines": q("SELECT count(*) FROM sale_lines"),
            "customers": q("SELECT count(*) FROM customers"),
        }

    def build(self, gate: GateResult | None = None) -> Plan:
        for name, fn in (("locations", self.build_locations), ("suppliers", self.build_suppliers), ("catalog", self.build_catalog),
                         ("prices", self.build_prices), ("promotions", self.build_promotions), ("balances", self.build_balances),
                         ("open_pos", self.build_open_pos), ("loyalty", self.build_loyalty), ("sales", self.build_sales)):
            fn()
        if gate:
            for e in gate.exceptions:
                self.exc.add(e.kind, e.source_ref, e.detail, e.disposition, e.entity)
        plan = Plan(mapping_version=self.spec.version, mapping_sha256=self.spec.sha256, source_system=self.spec.source_system, snapshot_id=self.snapshot_id,
                    reference_ms=self.ref_ms, records=self.records, promotions=self.promotions, exceptions=self.exc, gate=gate,
                    unsupported_fields=gate.unsupported_fields if gate else [], source_counts=self.source_counts(), in_scope=dict(self.cnt),
                    expired={k: dict(v) for k, v in self.expired.items()}, normalisations=dict(sorted(self.norm.items())), sku_units={k: v["unit"] for k, v in self.sku_info.items()}, location_ids=dict(self.loc_ids))
        self.con.close()
        return plan


def build_plan(db_path: str, spec: Spec, *, snapshot_id: str, reference_ms: int) -> Plan:
    """Run the schema gate and build the full plan from one source snapshot."""
    inv = inventory(db_path)
    gate = schema_gate(spec, inv)
    sysname = None
    con = connect_ro(db_path)
    try:
        r = con.execute("SELECT system_name FROM system_state WHERE id=1").fetchone()
        sysname = r[0] if r else None
    finally:
        con.close()
    b = Builder(db_path, spec, snapshot_id, reference_ms)
    if sysname != spec.source_system:
        b.exc.add("SOURCE_SYSTEM_MISMATCH", "system_state.system_name", f"source says {sysname!r} but the mapping is for {spec.source_system!r}", MANUAL, "")
        gate.ok = False
    if not gate.ok:
        # an unmapped schema must not be migrated: still build the plan so the exceptions can be reported
        pass
    return b.build(gate)
