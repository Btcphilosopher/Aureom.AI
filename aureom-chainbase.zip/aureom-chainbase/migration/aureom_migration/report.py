"""Report assembly (shape: docs/API.md "Migration reports") and markdown rendering.

Report JSON (contract fields first; ``summary`` and the ``*_sha256``/marker fields are additive):

    id phase(trial|master|opening|final) trial network_id generated_at snapshot_id snapshot_sha256 mapping_version source_system
    authoritative_system(SOURCE|FROZEN|CHAIN) checks[] exceptions[] unsupported_fields[] batches[] decision(ACCEPT|REJECT) notes
"""

from __future__ import annotations

import math
from collections import Counter
from typing import Any

from .checks import MANUAL
from .plan import Plan
from .reconcile import FAIL, PASS, WARN
from .snapshot import SnapshotInfo
from .util import Clock, SYSTEM_CLOCK, canonical_json, iso_now, sha256_hex

AUTHORITATIVE = {"SOURCE": "SOURCE", "FROZEN": "FROZEN", "CHAIN": "CHAIN"}


def quality_checks(plan: Plan, spec, phase: str, ack: dict[str, Any] | None, *, master_only: bool = False) -> list[dict[str, Any]]:
    """Checks on the PLAN itself (data-quality gate), independent of what is on chain."""
    checks: list[dict[str, Any]] = []
    gate = plan.gate
    unmapped = sum(1 for e in (gate.exceptions if gate else []) if e.kind in ("UNMAPPED_TABLE", "UNMAPPED_COLUMN", "MAPPED_TABLE_MISSING", "MAPPED_COLUMN_MISSING", "SOURCE_SYSTEM_MISMATCH"))
    checks.append({"name": "schema gate: every source column has a declared treatment", "source": 0, "chain": unmapped, "delta": unmapped, "status": PASS if not unmapped else FAIL,
                   "detail": "no unmapped/missing columns" if not unmapped else "; ".join(e.source_ref for e in gate.exceptions if e.kind.startswith(("UNMAPPED", "MAPPED_")))})
    stats = plan.stats()
    ratios = spec.get("reconciliation", "max_excluded_ratio", default={}) or {}
    migrated_rows = {
        "LOCATION": len(plan.records.get("LOCATION", [])), "SUPPLIER": len(plan.records.get("SUPPLIER", [])), "PRODUCT": len(plan.records.get("PRODUCT", [])),
        "SKU": sum(len(p["variants"]) for p in plan.records.get("PRODUCT", [])), "PRICE": len(plan.records.get("PRICE", [])), "PROMOTION": len(plan.promotions),
        "HISTORICAL_SALE": len(plan.records.get("HISTORICAL_SALE", [])), "OPEN_PO": len(plan.records.get("OPEN_PO", [])),
        "LOYALTY_OPENING": len(plan.records.get("LOYALTY_OPENING", [])),
        "OPENING_BALANCE": len({r["source_id"].split("#")[0] for r in plan.records.get("OPENING_BALANCE", [])}),
    }
    for ent, mig in migrated_rows.items():
        if master_only and ent not in ("LOCATION", "SUPPLIER", "PRODUCT", "SKU", "PRICE", "PROMOTION", "HISTORICAL_SALE"):
            continue
        st = stats[ent]
        oos = sum(st["out_of_scope"].values())
        closes = st["in_scope"] == mig + st["excluded"] + oos
        checks.append({"name": f"exception accounting closes: {ent}", "source": st["in_scope"], "chain": mig + st["excluded"] + oos, "delta": mig + st["excluded"] + oos - st["in_scope"],
                       "status": PASS if closes else FAIL,
                       "detail": f"{st['in_scope']} source rows = {mig} migrated + {st['excluded']} excluded (exceptions) + {oos} out of scope" + (" - every source row is accounted for" if closes else " - ROWS UNACCOUNTED FOR")})
        considered = mig + st["excluded"]
        limit = ratios.get(ent)
        if limit is not None and considered:
            allowed = math.floor(float(limit) * considered)
            ok = st["excluded"] <= allowed
            checks.append({"name": f"excluded share: {ent}", "source": allowed, "chain": st["excluded"], "delta": st["excluded"] - allowed, "status": PASS if ok else FAIL,
                           "detail": f"{st['excluded']} of {considered} excluded ({100 * st['excluded'] / considered:.2f}%), limit {100 * float(limit):.1f}%"})
    manual = plan.exceptions.manual()
    ack = ack or {}
    unack = [e for e in manual if e.id not in ack.get("ids", [])] if not ack.get("all") else []
    blocking = phase in ("final", "post-cutover") and unack
    checks.append({"name": "unresolved MANUAL exceptions", "source": 0, "chain": len(unack), "delta": len(unack), "status": FAIL if blocking else (WARN if unack else PASS),
                   "detail": (f"{len(manual)} MANUAL item(s); " + (f"{len(manual) - len(unack)} acknowledged by {ack.get('by', '?')}" if len(manual) != len(unack) else "none acknowledged")
                              + ("; BLOCKS final acceptance until acknowledged (reconcile --phase final --ack-manual --ack-by NAME --ack-reason TEXT)" if blocking else "; must be resolved or acknowledged before cutover")) if manual else "none"})
    return checks


def decide(checks: list[dict[str, Any]]) -> str:
    return "REJECT" if any(c["status"] == FAIL for c in checks) else "ACCEPT"


def build_report(*, phase: str, trial: bool, network_id: str, snapshot: SnapshotInfo, spec, authoritative_system: str, checks: list[dict[str, Any]], plan: Plan,
                 batches: list[dict[str, Any]], notes: str = "", clock: Clock | None = None, chain_height: int | None = None, freeze_marker: str = "",
                 extra: dict[str, Any] | None = None, ack: dict[str, Any] | None = None, id_tag: str = "", seq: int = 0) -> dict[str, Any]:
    clock = clock or SYSTEM_CLOCK
    when = iso_now(clock)
    exceptions = [e.to_report() for e in plan.exceptions.sorted()]
    decision = decide(checks)
    kinds = Counter(e["kind"] for e in exceptions)
    disp = Counter(e["disposition"] for e in exceptions)
    rid = f"rpt-{'trial-' if trial and phase != 'trial' else ''}{phase}{'-' + id_tag if id_tag else ''}-{snapshot.snapshot_id[5:15]}-{when.replace('-', '').replace(':', '')}{'-%03d' % seq if seq else ''}"
    report: dict[str, Any] = {
        "id": rid, "phase": phase, "trial": trial, "network_id": network_id, "generated_at": when,
        "snapshot_id": snapshot.snapshot_id, "snapshot_sha256": snapshot.sha256, "mapping_version": spec.version, "source_system": spec.source_system,
        "authoritative_system": authoritative_system, "checks": checks, "exceptions": exceptions, "unsupported_fields": plan.unsupported_fields, "batches": batches,
        "decision": decision, "notes": notes,
        "mapping_sha256": spec.sha256, "freeze_marker": freeze_marker, "chain_height": chain_height,
        "summary": {"entities": plan.stats(), "source_counts": plan.source_counts, "exceptions_by_kind": dict(sorted(kinds.items())), "exceptions_by_disposition": dict(sorted(disp.items())),
                    "normalisations": plan.normalisations, "checks": dict(Counter(c["status"] for c in checks)), "manual_unresolved": sum(1 for e in plan.exceptions.manual())},
    }
    if ack:
        report["manual_acknowledgement"] = ack
    if extra:
        report.update(extra)
    return report


def report_bytes(report: dict[str, Any]) -> bytes:
    return canonical_json(report)


def report_sha256(report: dict[str, Any]) -> str:
    return sha256_hex(report_bytes(report))


def to_markdown(r: dict[str, Any], *, max_exceptions: int = 400) -> str:
    L: list[str] = []
    L.append(f"# Migration report `{r['id']}`")
    L.append("")
    L.append(f"* **Decision: {r['decision']}**  (phase `{r['phase']}`{', TRIAL' if r.get('trial') else ''})")
    L.append(f"* network `{r['network_id']}` - source system `{r['source_system']}` - authoritative system now: **{r['authoritative_system']}**")
    L.append(f"* generated {r['generated_at']} - chain height {r.get('chain_height')}")
    L.append(f"* snapshot `{r['snapshot_id']}` (sha256 `{r['snapshot_sha256']}`) - mapping `{r['mapping_version']}` (sha256 `{r.get('mapping_sha256', '')}`)")
    if r.get("freeze_marker"):
        L.append(f"* source freeze marker `{r['freeze_marker']}`")
    if r.get("notes"):
        L += ["", r["notes"]]
    s = r["summary"]
    L += ["", "## Checks", "", f"{s['checks']}", "", "| status | check | source (expected) | chain | delta | detail |", "|---|---|---:|---:|---:|---|"]
    for c in r["checks"]:
        L.append(f"| {c['status']} | {c['name']} | {c['source']} | {c['chain']} | {'' if c.get('delta') is None else c['delta']} | {str(c.get('detail', '')).replace('|', '/')[:240]} |")
    L += ["", "## Entities", "", "| entity | source rows in scope | migrated | excluded | out of scope |", "|---|---:|---:|---:|---|"]
    for ent, st in s["entities"].items():
        oos = ", ".join(f"{v} x {k}" for k, v in st["out_of_scope"].items()) or ""
        L.append(f"| {ent} | {st['in_scope']} | {st['migrated']} | {st['excluded']} | {oos} |")
    L += ["", "## Exceptions", "", f"by disposition: {s['exceptions_by_disposition']}", "", f"by kind: {s['exceptions_by_kind']}", "",
          "| kind | source | disposition | detail |", "|---|---|---|---|"]
    for e in r["exceptions"][:max_exceptions]:
        L.append(f"| {e['kind']} | `{e['source_ref']}` | {e['disposition']} | {e['detail'].replace('|', '/')[:200]} |")
    if len(r["exceptions"]) > max_exceptions:
        L.append(f"| ... | | | {len(r['exceptions']) - max_exceptions} more in the JSON report |")
    L += ["", "## Unsupported source fields (never silently dropped)", "", "| table | column | rows with a value | treatment | detail |", "|---|---|---:|---|---|"]
    for u in r["unsupported_fields"]:
        L.append(f"| {u['table']} | {u['column']} | {u['rows']} | {u['treatment']} | {str(u.get('detail', '')).replace('|', '/')[:160]} |")
    L += ["", "## Batches", "", "| batch | entity | seq | records | tx | height | status |", "|---|---|---:|---:|---|---:|---|"]
    for b in r["batches"]:
        L.append(f"| `{b['batch_id']}` | {b['entity']} | {b['seq']} | {b['records']} | `{b.get('tx_id', '')}` | {b.get('height', '')} | {b.get('status', '')} |")
    L.append("")
    return "\n".join(L)
