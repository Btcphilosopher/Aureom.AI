"""Reconciliation: expected values (source after policy) vs CHAIN-AUTHORITATIVE values read at one finalised height.

Chain values come from the gateway's authoritative read API (``/chain/scan``, ``/chain/record`` at ``height=H``) - never from the
disposable SQL projection.  Every comparison has an explicit tolerance (mapping spec ``reconciliation.tolerance``; zero by
default) and yields PASS / WARN / FAIL; one FAIL makes the decision REJECT.

What this proves and what it does not (docs/MIGRATION.md): it proves the chain holds exactly what the migration set out to import
(nothing lost, nothing extra, nothing altered, counters equal to the attested totals).  That the *source* data was right in the first
place is outside its reach: imported history is the legacy system's assertion.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from .convert import line_amount
from .plan import expected_counters

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"
IMPORT_PREFIXES = {"price": "PRC-", "promo": "PRM-"}


@dataclass
class ChainView:
    height: int
    mig_state: dict[str, Any]
    locations: dict[str, dict] = field(default_factory=dict)  # ALL locations (genesis + imported)
    suppliers: dict[str, dict] = field(default_factory=dict)  # imported only (provenance.origin == IMPORTED, our source system)
    products: dict[str, dict] = field(default_factory=dict)
    skus: dict[str, dict] = field(default_factory=dict)
    all_skus: dict[str, dict] = field(default_factory=dict)  # every SKU (unit lookup for movements)
    prices: dict[str, dict] = field(default_factory=dict)
    promos: dict[str, dict] = field(default_factory=dict)
    pos: dict[str, dict] = field(default_factory=dict)
    sales: dict[str, dict] = field(default_factory=dict)
    loyalty: dict[str, dict] = field(default_factory=dict)
    loyalty_opening: dict[str, int] = field(default_factory=dict)  # customer -> OPENING entry points
    opening_moves: dict[tuple[str, str, str], int] = field(default_factory=dict)  # (sku, loc, bucket) -> qty
    batches: dict[str, dict] = field(default_factory=dict)
    foreign_imported: dict[str, int] = field(default_factory=dict)  # imported records of OTHER source systems (informational)


def _ours(rec: dict, source_system: str) -> bool:
    p = rec.get("provenance") or {}
    return p.get("origin") == "IMPORTED" and p.get("source_system") == source_system


def read_chain_view(backend, height: int, source_system: str) -> ChainView:
    """Authoritative reads pinned to ``height`` (a finalised height)."""
    ms = backend.migration_state(height) or {}
    v = ChainView(height=height, mig_state=ms)
    for _, r in backend.scan("loc/", height):
        v.locations[r["id"]] = r
    for _, r in backend.scan("supplier/", height):
        if _ours(r, source_system):
            v.suppliers[r["id"]] = r
    for _, r in backend.scan("product/", height):
        if _ours(r, source_system):
            v.products[r["id"]] = r
    for _, r in backend.scan("sku/", height):
        v.all_skus[r["id"]] = r
        if _ours(r, source_system):
            v.skus[r["id"]] = r
    for _, r in backend.scan("price/", height):
        if r["id"].startswith(IMPORT_PREFIXES["price"]):
            v.prices[r["id"]] = r
    for _, r in backend.scan("promo/", height):
        if r["id"].startswith(IMPORT_PREFIXES["promo"]):
            v.promos[r["id"]] = r
    for _, r in backend.scan("po/", height):
        if _ours(r, source_system):
            v.pos[r["id"]] = r
    for _, r in backend.scan("sale/", height):
        if _ours(r, source_system):
            v.sales[r["id"]] = r
    for _, r in backend.scan("loy/", height):
        if _ours(r, source_system):
            v.loyalty[r["id"]] = r
    for _, r in backend.scan("loye/", height):
        if r.get("type") == "OPENING" and _ours(r, source_system):
            v.loyalty_opening[r["account"]] = v.loyalty_opening.get(r["account"], 0) + int(r["points"])
    for _, r in backend.scan("mov/", height):
        if r.get("reason") == "OPENING_BALANCE" and r.get("ref_type") == "MIGRATION_BATCH":
            k = (r["sku"], r["to_loc"], r["to_bucket"])
            v.opening_moves[k] = v.opening_moves.get(k, 0) + int(r["qty"])
    for k, r in backend.scan("mig/batch/", height):
        v.batches[k[len("mig/batch/"):]] = r
    return v


@dataclass
class Expected:
    """What the chain must hold, derived from the plan(s) for the phase being reconciled."""

    records: dict[str, list[dict]]
    promotions: list[dict]
    batches: list[dict]  # planned batch descriptors (batch_id, entity, seq, records)
    source_system: str
    mapping_version: str

    @property
    def counters(self) -> dict[str, int]:
        return expected_counters(self.records)


def _chk(name: str, source: Any, chain: Any, *, tol: int = 0, detail: str = "", status: str | None = None, **extra: Any) -> dict[str, Any]:
    """One check.  ``source``/``chain``/``delta`` are always NUMBERS (the report contract); for non-numeric comparisons (window status, hashes,
    flags) the check is a 1/0 match flag and the compared values are spelled out in ``detail``."""
    if isinstance(source, int) and isinstance(chain, int) and not isinstance(source, bool) and not isinstance(chain, bool):
        delta = chain - source
        st = PASS if abs(delta) <= tol else FAIL
        c = {"name": name, "source": source, "chain": chain, "delta": delta, "status": status or st, "detail": detail}
    else:
        ok = source == chain
        c = {"name": name, "source": 1, "chain": 1 if ok else 0, "delta": 0 if ok else -1, "status": status or (PASS if ok else FAIL),
             "detail": (f"expected {source!r}, chain {chain!r}" + (f"; {detail}" if detail else ""))}
    c.update(extra)
    return c


def flag_check(name: str, expected: Any, actual: Any, detail: str = "", ok: bool | None = None) -> dict[str, Any]:
    """Equality / boolean check expressed as 1/0 numbers (see _chk)."""
    return _chk(name, expected, actual, detail=detail, status=None if ok is None else (PASS if ok else FAIL))


def _diff(name: str, expected: dict[str, Any], actual: dict[str, Any], limit: int = 8) -> dict[str, Any]:
    """Record-level comparison; the check reports counts and the first few offending keys."""
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    differ = sorted(k for k in set(expected) & set(actual) if expected[k] != actual[k])
    bad = len(missing) + len(extra) + len(differ)
    parts = []
    if missing:
        parts.append(f"{len(missing)} missing on chain (e.g. {missing[:limit]})")
    if extra:
        parts.append(f"{len(extra)} unexpected on chain (e.g. {extra[:limit]})")
    if differ:
        k = differ[0]
        parts.append(f"{len(differ)} differ (e.g. {k}: expected {expected[k]!r} chain {actual[k]!r})")
    return _chk(name, len(expected), len(expected) - bad, detail="; ".join(parts) if parts else f"all {len(expected)} records identical", status=PASS if not bad else FAIL)


# ---- projections used for record-level comparison (only the fields the import sets)
def _p_location(r): return {"name": r["name"], "kind": r["kind"], "region": r["region"], "currency": r["currency"]}
def _p_supplier(r): return {"name": r["name"], "terms": r.get("terms", "")}
def _p_product(r): return {"name": r["name"], "brand": r.get("brand", ""), "category": r.get("category", ""), "status": r["status"], "skus": sorted(r.get("skus") or [])}
def _p_sku(r): return {"product": r["product_id"], "unit": r["unit"], "barcode": r.get("barcode", ""), "scarce": bool(r.get("scarce"))}
def _p_price(r): return {"sku": r["sku"], "loc": r["loc"], "ccy": r["currency"], "minor": r["unit_minor"], "from": r["effective_from_ms"], "to": r["effective_to_ms"]}
def _p_promo(r): return {"type": r["type"], "bp": r.get("bp", 0), "off": r.get("off_minor", 0), "buy_n": r.get("buy_n", 0), "bundle": r.get("bundle_minor", 0),
                         "skus": sorted(r["skus"]), "locs": sorted(r["locs"]), "from": r["from_ms"], "to": r["to_ms"], "prio": r["priority"], "stack": bool(r.get("stackable")),
                         "loyal": bool(r.get("loyalty_only")), "status": r["status"], "ccy": r["currency"]}
def _p_po(r): return {"supplier": r["supplier_id"], "loc": r["location_id"], "ccy": r["currency"], "status": r["status"], "ordered": r["ordered_at_ms"],
                      "lines": [(l["sku"], l["qty"]["v"], l["qty"]["unit"], l["unit_cost_minor"], l["received_v"]) for l in r["lines"]]}
def _p_sale(r): return {"loc": r["loc"], "channel": r["channel"], "cust": r.get("customer_id", ""), "ccy": r["currency"], "eff": r["effective_at_ms"], "pay": r["payment_status"],
                        "paid": r["paid_minor"], "refund": r["refund_confirmed_minor"], "net": r["net_minor"], "gross": r["gross_minor"],
                        "lines": [(l["sku"], l["qty"]["v"], l["qty"]["unit"], l["unit_minor"], l["gross_minor"], l["net_minor"]) for l in r["lines"]]}


def _exp_location(r): return {"name": r["name"], "kind": r["kind"], "region": r["region"], "currency": r["currency"]}
def _exp_supplier(r): return {"name": r["name"], "terms": r.get("terms", "")}
def _exp_product(r): return {"name": r["name"], "brand": r.get("brand", ""), "category": r.get("category", ""), "status": r["status"], "skus": sorted(v["sku_id"] for v in r["variants"])}
def _exp_price(r): return {"sku": r["sku"], "loc": r["location"], "ccy": r["currency"], "minor": r["unit_minor"], "from": r["from_ms"], "to": r["to_ms"]}
def _exp_promo(p): return {"type": p["type"], "bp": p["bp"], "off": p["off_minor"], "buy_n": p["buy_n"], "bundle": p["bundle_minor"], "skus": sorted(p["skus"]), "locs": sorted(p["locations"]),
                           "from": p["effective_from_ms"], "to": p["effective_to_ms"], "prio": p["priority"], "stack": p["stackable"], "loyal": p["loyalty_only"], "status": p["status"], "ccy": p["currency"]}
def _exp_po(r): return {"supplier": r["supplier_id"], "loc": r["location"], "ccy": r["currency"], "status": r["status"], "ordered": r["ordered_at_ms"],
                        "lines": [(l["sku"], l["qty"]["v"], l["qty"]["unit"], l["unit_cost_minor"], l["received_v"]) for l in r["lines"]]}
def _exp_sale(r):
    gross = sum(l["gross_minor"] for l in r["lines"])
    return {"loc": r["location"], "channel": r["channel"], "cust": r.get("customer_id", ""), "ccy": r["currency"], "eff": r["effective_at_ms"], "pay": r["payment_status"],
            "paid": r["paid_minor"], "refund": r["refunded_minor"], "net": sum(l["net_minor"] for l in r["lines"]), "gross": gross,
            "lines": [(l["sku"], l["qty"]["v"], l["qty"]["unit"], l["unit_minor"], l["gross_minor"], l["net_minor"]) for l in r["lines"]]}


def _outstanding_value(po_lines: list[tuple[int, int, str, int]]) -> int:
    return sum(line_amount(cost, qty - rec, unit) for qty, rec, unit, cost in po_lines)


def compare(exp: Expected, view: ChainView, tolerance: dict[str, int], phase: str) -> list[dict[str, Any]]:
    """All chain-vs-expected checks for one phase."""
    tc, tq, tm = int(tolerance.get("count", 0)), int(tolerance.get("quantity", 0)), int(tolerance.get("money_minor", 0))
    checks: list[dict[str, Any]] = []
    add = checks.append
    R = exp.records
    ms = view.mig_state
    counters = exp.counters
    # ---- migration window
    want = "OPEN" if phase in ("master", "opening", "final") else "CLOSED"
    if phase == "post-cutover":
        want = "CLOSED"
    add(_chk("migration window status", want, ms.get("status"), detail=f"on-chain mig/state at height {view.height}"))
    # ---- locations / master data counts
    imported_locs = {i: r for i, r in view.locations.items() if _ours(r, exp.source_system)}
    add(_chk("location count (imported)", len(R.get("LOCATION", [])), len(imported_locs), tol=tc))
    add(_diff("location records", {r["id"]: _exp_location(r) for r in R.get("LOCATION", [])}, {i: _p_location(r) for i, r in imported_locs.items()}))
    add(_chk("supplier count", len(R.get("SUPPLIER", [])), len(view.suppliers), tol=tc))
    add(_diff("supplier records", {r["id"]: _exp_supplier(r) for r in R.get("SUPPLIER", [])}, {i: _p_supplier(r) for i, r in view.suppliers.items()}))
    add(_chk("product count", len(R.get("PRODUCT", [])), len(view.products), tol=tc))
    add(_diff("product records", {r["id"]: _exp_product(r) for r in R.get("PRODUCT", [])}, {i: _p_product(r) for i, r in view.products.items()}))
    exp_skus = {v["sku_id"]: {"product": p["id"], "unit": v["unit"], "barcode": v.get("barcode", ""), "scarce": bool(v.get("scarce"))} for p in R.get("PRODUCT", []) for v in p["variants"]}
    add(_chk("SKU count", len(exp_skus), len(view.skus), tol=tc))
    add(_diff("SKU records", exp_skus, {i: _p_sku(r) for i, r in view.skus.items()}))
    add(_chk("price count", len(R.get("PRICE", [])), len(view.prices), tol=tc))
    add(_diff("price records", {r["id"]: _exp_price(r) for r in R.get("PRICE", [])}, {i: _p_price(r) for i, r in view.prices.items()}))
    add(_chk("promotion count (native ActivatePromotion)", len(exp.promotions), len(view.promos), tol=tc))
    add(_diff("promotion records", {p["promo_id"]: _exp_promo(p) for p in exp.promotions}, {i: _p_promo(r) for i, r in view.promos.items()}))
    # ---- stock
    exp_moves: dict[tuple[str, str, str], int] = defaultdict(int)
    exp_units: dict[str, int] = defaultdict(int)
    for r in R.get("OPENING_BALANCE", []):
        exp_moves[(r["sku"], r["location"], r["bucket"])] += r["qty"]["v"]
        exp_units[r["qty"]["unit"]] += r["qty"]["v"]
    chain_units: dict[str, int] = defaultdict(int)
    for (sku, loc, bucket), q in view.opening_moves.items():
        unit = (view.all_skus.get(sku) or {}).get("unit", "?")
        chain_units[unit] += q
    add(_chk("stock balance rows (sku, location, bucket)", len(exp_moves), len(view.opening_moves), tol=tc))
    for unit in sorted(set(exp_units) | set(chain_units)):
        add(_chk(f"opening stock total, unit {unit}", exp_units.get(unit, 0), chain_units.get(unit, 0), tol=tq, detail="sum of OPENING_BALANCE movements (smallest unit steps)"))
    add(_diff("stock balance per (sku, location, bucket)", {"/".join(k): v for k, v in exp_moves.items()}, {"/".join(k): v for k, v in view.opening_moves.items()}))
    # ---- purchase orders
    exp_pos = {r["id"]: _exp_po(r) for r in R.get("OPEN_PO", [])}
    add(_chk("open purchase order count", len(exp_pos), len(view.pos), tol=tc))
    exp_out: dict[str, int] = defaultdict(int)
    for r in R.get("OPEN_PO", []):
        for l in r["lines"]:
            exp_out[l["qty"]["unit"]] += l["qty"]["v"] - l["received_v"]
    ch_out: dict[str, int] = defaultdict(int)
    for r in view.pos.values():
        for l in r["lines"]:
            ch_out[l["qty"]["unit"]] += l["qty"]["v"] - l["received_v"]
    for unit in sorted(set(exp_out) | set(ch_out)):
        add(_chk(f"outstanding PO quantity, unit {unit}", exp_out.get(unit, 0), ch_out.get(unit, 0), tol=tq))
    exp_val = sum(_outstanding_value([(l["qty"]["v"], l["received_v"], l["qty"]["unit"], l["unit_cost_minor"]) for l in r["lines"]]) for r in R.get("OPEN_PO", []))
    ch_val = sum(_outstanding_value([(l["qty"]["v"], l["received_v"], l["qty"]["unit"], l["unit_cost_minor"]) for l in r["lines"]]) for r in view.pos.values())
    add(_chk("outstanding PO value (minor units)", exp_val, ch_val, tol=tm, detail="sum of (ordered - received) x unit cost, half-even per line"))
    add(_chk("open PO ordered value (minor units)", sum(sum(line_amount(l["unit_cost_minor"], l["qty"]["v"], l["qty"]["unit"]) for l in r["lines"]) for r in R.get("OPEN_PO", [])),
             sum(int(r["total_minor"]) for r in view.pos.values()), tol=tm,
             detail="chain-computed PO totals vs expected (the chain counter open_po_total_minor is checked below)"))
    add(_diff("open purchase order records", exp_pos, {i: _p_po(r) for i, r in view.pos.items()}))
    # ---- loyalty
    exp_loy = {r["customer_id"]: r["points"] for r in R.get("LOYALTY_OPENING", [])}
    add(_chk("loyalty account count", len(exp_loy), len(view.loyalty), tol=tc))
    add(_chk("loyalty opening points total", sum(exp_loy.values()), sum(view.loyalty_opening.values()), tol=tq))
    add(_diff("loyalty opening balance per customer", exp_loy, dict(view.loyalty_opening)))
    # ---- historical sales
    exp_sales = {r["id"]: _exp_sale(r) for r in R.get("HISTORICAL_SALE", [])}
    add(_chk("historical sales count", len(exp_sales), len(view.sales), tol=tc))
    add(_chk("historical sales net total (minor units)", sum(s["net"] for s in exp_sales.values()), sum(int(r["net_minor"]) for r in view.sales.values()), tol=tm))
    add(_chk("historical sales refunded total (minor units)", sum(s["refund"] for s in exp_sales.values()), sum(int(r["refund_confirmed_minor"]) for r in view.sales.values()), tol=tm))
    add(_diff("historical sale records", exp_sales, {i: _p_sale(r) for i, r in view.sales.items()}))
    # ---- chain counters vs expected counters (the values MigrationControl CLOSE attests)
    chain_counters = {k: int(v) for k, v in (ms.get("chain_counters") or {}).items()}
    for k in sorted(set(counters) | set(chain_counters)):
        add(_chk(f"chain counter {k}", int(counters.get(k, 0)), int(chain_counters.get(k, 0)), tol=0, detail="mig/state.chain_counters vs expected totals (attested at CLOSE)"))
    # ---- batches
    planned = {b["batch_id"]: b for b in exp.batches}
    missing = sorted(set(planned) - set(view.batches))
    wrong = [b for b in planned if b in view.batches and int(view.batches[b].get("records", -1)) != int(planned[b]["records"])]
    add(_chk("planned batches present on chain (mig/batch)", len(planned), len(planned) - len(missing) - len(wrong),
             detail=("missing " + ", ".join(m[:12] for m in missing[:5]) if missing else "") + ("; record-count mismatch " + ", ".join(w[:12] for w in wrong[:5]) if wrong else "") or "every planned batch is on chain with the planned record count"))
    unplanned = sorted(set(view.batches) - set(planned))
    add(_chk("no unplanned batches on chain", 0, len(unplanned), detail=f"unplanned batch ids {[u[:12] for u in unplanned[:5]]}" if unplanned else "none",
             status=PASS if not unplanned else FAIL))
    # ---- provenance integrity of everything imported
    pb = set(planned)
    stray = 0
    for coll in (imported_locs, view.suppliers, view.products, view.skus, view.pos, view.sales, view.loyalty):
        for r in coll.values():
            if (r.get("provenance") or {}).get("batch_id") not in pb or not (r.get("provenance") or {}).get("source_id"):
                stray += 1
    add(_chk("imported records carry provenance of a planned batch", 0, stray, detail="origin=IMPORTED, source system, source id and a planned batch id", status=PASS if not stray else FAIL))
    return checks
