"""Trial migration: the FULL pipeline (master -> activity -> freeze -> opening -> reconcile -> cutover) against a THROWAWAY chain.

Safety rails:
* the target network id must look like a trial network (default prefix ``aureom-trial``) and the gateway must report exactly that id;
* the chain's migration window must be NOT_STARTED (a fresh network);
* the source database is COPIED first (backup API) - the production source is never frozen or modified;
* reports are marked ``trial: true``; they may additionally be POSTed to the production gateway's report store (off-chain evidence only).
"""

from __future__ import annotations

import re
import shutil
import sqlite3
from pathlib import Path
from typing import Any, Callable

from .chainclient import ChainClient
from .cutover import Config, Migration
from .mapping import Spec
from .synth import simulate_activity
from .util import Clock, MigrationError, SYSTEM_CLOCK, atomic_write, iso_now, write_json

TRIAL_NETWORK_RE = re.compile(r"^aureom-trial[A-Za-z0-9._-]*$")


def copy_database(src: str | Path, dst: str | Path) -> None:
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    s = sqlite3.connect(f"file:{Path(src).resolve()}?mode=ro", uri=True)
    d = sqlite3.connect(str(dst))
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()


def run_trial(*, source_db: str | Path, workdir: str | Path, spec: Spec, backend, network_id: str, keys_dir: str | Path, report_backends: list | None = None,
              simulate: bool = True, activity_seed: int = 7, allow_any_network: bool = False, clock: Clock = SYSTEM_CLOCK, log: Callable[[str], None] = print,
              chain: ChainClient | None = None, max_records: int | None = None, max_envelope_bytes: int | None = None) -> dict[str, Any]:
    if not allow_any_network and not TRIAL_NETWORK_RE.match(network_id):
        raise MigrationError(f"refusing to run a trial against network {network_id!r}: a trial must target a throwaway network whose id starts with 'aureom-trial' (use --allow-any-network-id only for tests)")
    actual = backend.network_id()
    if actual != network_id:
        raise MigrationError(f"the gateway reports network {actual!r} but --network-id is {network_id!r}")
    ms = backend.migration_state() or {}
    if ms.get("status") != "NOT_STARTED":
        raise MigrationError(f"the trial network's migration window is {ms.get('status')}: a trial needs a FRESH throwaway network (start a new one)")
    wd = Path(workdir)
    wd.mkdir(parents=True, exist_ok=True)
    trial_db = wd / "trial_source.sqlite"
    copy_database(source_db, trial_db)
    log(f"trial: source copied to {trial_db}; the production source is not touched")
    chain = chain or ChainClient(backend, network_id, keys_dir, clock=lambda: clock.now_ms() / 1000)
    cfg = Config(workdir=wd, source_db=trial_db, spec=spec, network_id=network_id, trial=True, clock=clock, log=log, report_backends=list(report_backends or []),
                 max_records=max_records, max_envelope_bytes=max_envelope_bytes)
    mig = Migration(cfg, backend, chain)
    steps: dict[str, Any] = {}
    steps["master"] = mig.master()
    steps["master_reconcile"] = mig.reconcile("master")["decision"]
    if simulate:
        steps["activity"] = simulate_activity(trial_db, activity_seed)
        log(f"trial: simulated live activity on the source between the master import and the freeze: {steps['activity']}")
    steps["freeze"] = mig.freeze()
    steps["opening"] = mig.opening()
    ack = {"all": True, "by": "trial-runner", "reason": "trial run: MANUAL exceptions are the planted data-quality problems and are expected", "at": iso_now(clock)}
    final = mig.reconcile("final", ack=ack)
    steps["final_decision"] = final["decision"]
    if final["decision"] != "ACCEPT":
        raise MigrationError("trial final reconciliation was REJECTED; see " + str(final["entry"]["path"]))
    steps["cutover"] = mig.cutover()
    roll = mig.reconcile("post-cutover", authoritative_override="CHAIN", report_phase_label="trial",
                         notes="TRIAL ROLL-UP: full rehearsal master -> freeze -> opening -> reconcile -> cutover on a throwaway network; the final (pre-close) report hash was attested by MigrationControl CLOSE.")
    steps["trial_report"] = {"id": roll["report"]["id"], "decision": roll["decision"], "path": roll["entry"]["path"]}
    summary = {"network_id": network_id, "decision": roll["decision"], "steps": steps, "status": mig.status(), "workdir": str(wd), "finished_at": iso_now(clock)}
    write_json(wd / "trial-summary.json", summary)
    atomic_write(wd / "trial-report.md", Path(roll["entry"]["path"]).with_suffix(".md").read_text())
    return summary
