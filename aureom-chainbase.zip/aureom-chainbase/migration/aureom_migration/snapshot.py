"""Consistent source snapshots and source-system control (freeze / archive).

A snapshot is taken with the SQLite online-backup API while the source connection holds a READ transaction, so the copy is
a point-in-time consistent image even if writers are active.  Each snapshot carries:

* ``sha256``          hash of the snapshot FILE (integrity: verified before every use)
* ``content_digest``  hash of the logical content (table rows in primary-key order, volatile timestamps excluded); the
                      snapshot id ``snap-<first 16 hex>`` derives from it, so re-snapshotting an unchanged source yields the
                      same id (and therefore the same batch ids) - determinism does not depend on SQLite file bytes
* ``row_counts``      per table
* ``marker``          the source change-log high-water mark and a hash chain over the whole change log; the freeze marker
                      recorded on chain at CLOSE is this value taken at freeze time
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .inventory import _q, connect_ro
from .util import SYSTEM_CLOCK, Clock, MigrationError, canonical_json, iso_now, read_json, sha256_file, sha256_hex, write_json

VOLATILE = {("change_log", "changed_at"), ("system_state", "frozen_at")}


@dataclass
class SnapshotInfo:
    snapshot_id: str
    path: str
    sha256: str
    content_digest: str
    taken_at_ms: int
    label: str
    source_path: str
    row_counts: dict[str, int] = field(default_factory=dict)
    system_state: dict[str, Any] = field(default_factory=dict)
    marker: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "SnapshotInfo":
        return SnapshotInfo(**d)


def content_digest(con: sqlite3.Connection) -> str:
    h = hashlib.sha256()
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    for t in tables:
        cols = [r[1] for r in con.execute(f"PRAGMA table_info({_q(t)})")]
        keep = [c for c in cols if (t, c) not in VOLATILE]
        h.update(f"#{t}|{','.join(keep)}\n".encode())
        sel = ",".join(_q(c) for c in keep)
        for row in con.execute(f"SELECT {sel} FROM {_q(t)} ORDER BY rowid"):
            h.update(json.dumps(list(row), separators=(",", ":"), default=repr).encode("utf-8"))
            h.update(b"\n")
    return h.hexdigest()


def change_log_state(con: sqlite3.Connection) -> dict[str, Any]:
    """High-water mark + hash chain over the change log (id|table|pk|op), excluding wall-clock timestamps."""
    h = hashlib.sha256()
    n = hw = 0
    for cid, t, pk, op in con.execute("SELECT change_id, table_name, pk, op FROM change_log ORDER BY change_id"):
        h.update(f"{cid}|{t}|{pk}|{op}\n".encode())
        n += 1
        hw = cid
    return {"high_water": hw, "rows": n, "chain_hash": h.hexdigest()}


def freeze_marker(system_name: str, cl: dict[str, Any]) -> str:
    return sha256_hex(canonical_json({"system": system_name, "change_log_high_water": cl["high_water"], "change_log_rows": cl["rows"], "change_log_chain_hash": cl["chain_hash"]}))


def _state(con: sqlite3.Connection) -> dict[str, Any]:
    cur = con.execute("SELECT * FROM system_state WHERE id=1")
    r = cur.fetchone()
    return dict(zip([d[0] for d in cur.description], r)) if r else {}


def take_snapshot(source: str | Path, out_dir: str | Path, label: str, clock: Clock | None = None) -> SnapshotInfo:
    """Copy ``source`` with the backup API under a read transaction and describe the copy."""
    clock = clock or SYSTEM_CLOCK
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    tmp = out / f".{label}.{os.getpid()}.tmp.sqlite"
    if tmp.exists():
        tmp.unlink()
    src = sqlite3.connect(f"file:{Path(source).resolve()}?mode=ro", uri=True, isolation_level=None)
    try:
        src.execute("BEGIN")  # read transaction: the backup sees ONE consistent state
        src.execute("SELECT count(*) FROM sqlite_master").fetchone()
        dst = sqlite3.connect(str(tmp))
        try:
            src.backup(dst)  # pages=-1: copied in a single step under the read lock
        finally:
            dst.close()
        src.execute("ROLLBACK")
    finally:
        src.close()
    con = connect_ro(tmp)
    try:
        ok = con.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok":
            raise MigrationError(f"snapshot failed integrity_check: {ok}")
        digest = content_digest(con)
        counts = {r[0]: con.execute(f"SELECT count(*) FROM {_q(r[0])}").fetchone()[0]
                  for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()}
        st = _state(con)
        marker = change_log_state(con)
    finally:
        con.close()
    sid = "snap-" + digest[:16]
    final = out / f"{label}-{sid}.sqlite"
    os.replace(tmp, final)
    info = SnapshotInfo(snapshot_id=sid, path=str(final), sha256=sha256_file(final), content_digest=digest, taken_at_ms=clock.now_ms(), label=label,
                        source_path=str(source), row_counts=counts, system_state=st, marker=marker)
    write_json(str(final) + ".json", info.to_dict())
    return info


def load_snapshot(manifest_or_db: str | Path) -> SnapshotInfo:
    p = Path(manifest_or_db)
    if p.suffix == ".json":
        return SnapshotInfo.from_dict(read_json(p))
    return SnapshotInfo.from_dict(read_json(str(p) + ".json"))


def verify_snapshot(info: SnapshotInfo) -> None:
    """Refuse to use a snapshot file that was modified after it was taken."""
    if not Path(info.path).exists():
        raise MigrationError(f"snapshot file missing: {info.path}")
    actual = sha256_file(info.path)
    if actual != info.sha256:
        raise MigrationError(f"snapshot {info.snapshot_id} was modified after it was taken (sha256 {actual} != recorded {info.sha256})")


# ------------------------------------------------------------------ source system control


class SourceControl:
    """The single place that changes which system is authoritative on the SOURCE side.

    system_state.authoritative_system:  SOURCE (live) -> NONE_FROZEN (write-freeze, nobody writes) -> CHAIN (source is a read-only archive).
    While frozen=1 the source's own triggers abort every write, so the freeze is enforced, not advisory."""

    def __init__(self, db_path: str | Path):
        self.path = str(db_path)

    def _con(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path, isolation_level=None, timeout=30)

    def state(self) -> dict[str, Any]:
        con = self._con()
        try:
            return _state(con)
        finally:
            con.close()

    def marker(self) -> dict[str, Any]:
        con = self._con()
        try:
            st = _state(con)
            cl = change_log_state(con)
            return {"system": st.get("system_name"), **cl, "freeze_marker": freeze_marker(st.get("system_name", ""), cl)}
        finally:
            con.close()

    def freeze(self, clock: Clock | None = None) -> dict[str, Any]:
        """Atomically: take the write lock, compute the marker, set frozen. Returns the marker."""
        clock = clock or SYSTEM_CLOCK
        con = self._con()
        try:
            con.execute("BEGIN IMMEDIATE")  # no writer can slip in between the marker and the flag
            st = _state(con)
            if st.get("frozen") or st.get("authoritative_system") != "SOURCE":
                con.execute("ROLLBACK")
                raise MigrationError(f"cannot freeze: source authoritative_system={st.get('authoritative_system')} frozen={st.get('frozen')}")
            cl = change_log_state(con)
            m = freeze_marker(st["system_name"], cl)
            con.execute("UPDATE system_state SET frozen=1, authoritative_system='NONE_FROZEN', freeze_marker=?, frozen_at=? WHERE id=1", (m, iso_now(clock)))
            con.execute("COMMIT")
            return {"system": st["system_name"], **cl, "freeze_marker": m}
        except sqlite3.Error:
            try:
                con.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
        finally:
            con.close()

    def unfreeze(self) -> None:
        """Roll back a freeze (abort before cutover): the source becomes the live, writable system again."""
        con = self._con()
        try:
            con.execute("BEGIN IMMEDIATE")
            st = _state(con)
            if st.get("authoritative_system") == "CHAIN" or st.get("archived"):
                con.execute("ROLLBACK")
                raise MigrationError("source is already archived (cutover done): cannot unfreeze; corrections after cutover are compensating chain transactions")
            con.execute("UPDATE system_state SET frozen=0, authoritative_system='SOURCE', freeze_marker=NULL, frozen_at=NULL WHERE id=1")
            con.execute("COMMIT")
        finally:
            con.close()

    def archive(self) -> None:
        """Cutover: the chain is authoritative; the source stays frozen as a read-only archive."""
        con = self._con()
        try:
            con.execute("BEGIN IMMEDIATE")
            st = _state(con)
            if not st.get("frozen"):
                con.execute("ROLLBACK")
                raise MigrationError("cannot archive a source that is not frozen")
            con.execute("UPDATE system_state SET authoritative_system='CHAIN', archived=1 WHERE id=1")
            con.execute("COMMIT")
        finally:
            con.close()

    def verify_write_freeze(self) -> bool:
        """Prove the freeze is ENFORCED: a canary write (rolled back anyway) must be refused by the source's own triggers."""
        con = self._con()
        try:
            con.execute("BEGIN IMMEDIATE")
            try:
                con.execute("INSERT INTO categories(category_id, name, parent_id) VALUES (-1, 'write-freeze canary', NULL)")
                refused = False
            except sqlite3.DatabaseError:
                refused = True
            finally:
                con.execute("ROLLBACK")
            return refused
        finally:
            con.close()

    def change_log_since(self, high_water: int) -> list[tuple[int, str, str, str]]:
        con = self._con()
        try:
            return [tuple(r) for r in con.execute("SELECT change_id, table_name, pk, op FROM change_log WHERE change_id > ? ORDER BY change_id", (high_water,))]
        finally:
            con.close()
