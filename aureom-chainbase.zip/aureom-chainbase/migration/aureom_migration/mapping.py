"""Versioned mapping spec: loading, validation and the lookups the plan builder uses."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .convert import CHAIN_ID_RE, sanitize_id
from .util import MigrationError, sha256_file

TREATMENTS = {"mapped", "extras", "folded", "dropped", "system"}
EXTRAS_TABLES = {"suppliers", "stores", "warehouses", "products", "product_variants", "purchase_orders", "sales"}  # chain records with source_extras
ENTITIES = {"LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "PROMOTION", "HISTORICAL_SALE", "OPENING_BALANCE", "OPEN_PO", "LOYALTY_OPENING"}
IMPORT_ENTITIES = ENTITIES - {"PROMOTION"}  # PROMOTION has no import entity: it is a native ActivatePromotion transaction
DEFAULT_SPEC_PATH = Path(__file__).resolve().parent.parent / "mapping" / "map-v1.yaml"

# the treatment text used in the report's unsupported_fields[]
TREATMENT_TEXT = {
    "extras": "preserved in source_extras",
    "dropped": "dropped with approval",
    "folded": "folded into another field (no separate chain field)",
}


@dataclass
class Spec:
    raw: dict[str, Any]
    path: str
    sha256: str
    version: str = ""
    source_system: str = ""
    tables: dict[str, dict[str, dict]] = field(default_factory=dict)

    # ---- simple accessors
    def get(self, *keys, default=None):
        cur: Any = self.raw
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

    @property
    def timezone(self) -> str:
        return self.raw.get("timezone", "Europe/London")

    @property
    def default_currency(self) -> str:
        return self.raw.get("default_currency", "GBP")

    def treatment(self, table: str, column: str) -> dict | None:
        return self.tables.get(table, {}).get(column)

    def extras_columns(self, table: str) -> list[tuple[str, str]]:
        return [(c, t["key"]) for c, t in self.tables.get(table, {}).items() if t["treatment"] == "extras"]

    def unsupported_columns(self) -> list[tuple[str, str, dict]]:
        out = []
        for table in sorted(self.tables):
            for col, t in self.tables[table].items():
                if t["treatment"] in ("extras", "dropped", "folded"):
                    out.append((table, col, t))
        return out

    # ---- id derivation
    def location_chain_id(self, code: str | None) -> str | None:
        if code is None or str(code).strip() == "":
            return None
        code = str(code).strip()
        m = self.raw["ids"]["location_map"]
        if code in m:
            return m[code]
        return None  # an unmapped code is an ORPHAN_FK for transactional tables; locations themselves use location_fallback

    def location_fallback_id(self, code: str) -> str:
        return sanitize_id(self.raw["ids"]["location_fallback"].format(code=sanitize_id(code)))

    @property
    def genesis_locations(self) -> dict[str, dict]:
        return self.raw.get("genesis_locations", {})

    def phase_entities(self, phase: str) -> list[str]:
        return list(self.raw["phases"][phase])

    @property
    def batching(self) -> dict:
        return self.raw.get("batching", {"max_records": 400, "max_envelope_bytes": 614400})


def load_spec(path: str | Path | None = None) -> Spec:
    p = Path(path) if path else DEFAULT_SPEC_PATH
    with open(p, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    spec = Spec(raw=raw, path=str(p), sha256=sha256_file(p), version=str(raw.get("mapping_version", "")), source_system=str(raw.get("source_system", "")))
    tables: dict[str, dict[str, dict]] = {}
    for t, cols in (raw.get("tables") or {}).items():
        tables[t] = {c: dict(v) for c, v in (cols or {}).items()}
    spec.tables = tables
    validate_spec(spec)
    return spec


def validate_spec(spec: Spec) -> None:
    errs: list[str] = []
    raw = spec.raw
    for k in ("mapping_version", "source_system", "ids", "phases", "tables", "approvals", "batching", "reconciliation"):
        if k not in raw:
            errs.append(f"missing top-level key {k!r}")
    if errs:
        raise MigrationError("invalid mapping spec: " + "; ".join(errs))
    if not CHAIN_ID_RE.match(spec.version) or not CHAIN_ID_RE.match(spec.source_system):
        errs.append("mapping_version and source_system must be valid chain ids")
    approvals = raw.get("approvals") or {}
    for t, cols in spec.tables.items():
        for c, tr in cols.items():
            kind = tr.get("treatment")
            if kind not in TREATMENTS:
                errs.append(f"{t}.{c}: unknown treatment {kind!r}")
            elif kind == "dropped" and tr.get("approval") not in approvals:
                errs.append(f"{t}.{c}: dropped requires an approval id from `approvals`")
            elif kind == "extras":
                if not tr.get("key"):
                    errs.append(f"{t}.{c}: extras requires a `key`")
                if t not in EXTRAS_TABLES:
                    errs.append(f"{t}.{c}: the chain record for table {t} has no source_extras; use `dropped` with an approval")
    for ph, ents in raw["phases"].items():
        for e in ents:
            if e not in ENTITIES:
                errs.append(f"phases.{ph}: unknown entity {e}")
    for code, cid in raw["ids"]["location_map"].items():
        if not CHAIN_ID_RE.match(cid):
            errs.append(f"location_map {code}->{cid}: not a valid chain id")
    bt = raw["batching"]
    if not (1 <= int(bt["max_records"]) <= 400):
        errs.append("batching.max_records must be 1..400 (chain Params.MaxImportRecords)")
    if not (1024 <= int(bt["max_envelope_bytes"]) <= 900 * 1024):
        errs.append("batching.max_envelope_bytes must be <= 900 KiB (chain Params.MaxImportTxBytes)")
    if errs:
        raise MigrationError("invalid mapping spec:\n  " + "\n  ".join(errs))


def render_value(v: Any) -> str:
    """Verbatim string form of a source value for source_extras (chain extras are map[string]string)."""
    if isinstance(v, float):
        return repr(v)
    return str(v)
