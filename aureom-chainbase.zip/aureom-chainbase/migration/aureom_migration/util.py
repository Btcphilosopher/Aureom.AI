"""Small shared helpers: canonical JSON, hashing, clocks, atomic file writes."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


def canonical_json(obj: Any) -> bytes:
    """Deterministic JSON bytes: sorted keys, compact separators, UTF-8 (used for hashes and the report body)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def iso_now(clock: "Clock | None" = None) -> str:
    ms = (clock or SYSTEM_CLOCK).now_ms()
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class Clock:
    """Injectable wall clock (tests pin it so reports/ids are reproducible)."""

    fn: Callable[[], float] = time.time

    def now_ms(self) -> int:
        return int(self.fn() * 1000)


SYSTEM_CLOCK = Clock()


def atomic_write(path: str | Path, data: bytes | str) -> None:
    """Write-then-rename so a crash never leaves a half-written state/report file."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode("utf-8")
    fd, tmp = tempfile.mkstemp(prefix=p.name + ".", suffix=".tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, p)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_json(path: str | Path, obj: Any, *, indent: int | None = 2) -> None:
    atomic_write(path, json.dumps(obj, indent=indent, sort_keys=True, ensure_ascii=False) + "\n")


def read_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class MigrationError(Exception):
    """A migration step refused or failed; the message is operator-facing."""
