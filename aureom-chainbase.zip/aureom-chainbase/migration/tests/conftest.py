"""Shared fixtures: deterministic keys, a synthetic source DB (seed 42), snapshot/plan, an in-memory fake chain and a Migration factory."""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from aureom_migration import synth  # noqa: E402
from aureom_migration.chainclient import ChainClient, Signer  # noqa: E402
from aureom_migration.cutover import Config, Migration  # noqa: E402
from aureom_migration.mapping import load_spec  # noqa: E402
from aureom_migration.plan import build_plan  # noqa: E402
from aureom_migration.snapshot import take_snapshot  # noqa: E402
from aureom_migration.util import Clock  # noqa: E402
from fakechain import FakeChain  # noqa: E402

NOW = 1_794_515_000.0  # 2026-11-12: after the synthetic history, before the planted future-dated sale
NET = "aureom-fake-1"


def fixed_clock() -> Clock:
    return Clock(fn=lambda: NOW)


@pytest.fixture(scope="session")
def signers() -> dict[str, Signer]:
    return {i: Signer(i, "k1", hashlib.sha256(f"unit-test-key/{i}".encode()).digest()) for i in ("migration-op", "pricing-mgr")}


@pytest.fixture(scope="session")
def keys_dir(tmp_path_factory, signers) -> Path:
    d = tmp_path_factory.mktemp("keys")
    for i, s in signers.items():
        (d / f"{i}.json").write_text(json.dumps({"identity": i, "key_id": s.key_id, "seed_hex": s.seed.hex(), "pub_b64": s.pub_b64}))
    return d


@pytest.fixture(scope="session")
def synth_db(tmp_path_factory) -> Path:
    p = tmp_path_factory.mktemp("synth") / "retail_source.sqlite"
    synth.generate(42, p)
    return p


@pytest.fixture(scope="session")
def spec():
    return load_spec()


@pytest.fixture(scope="session")
def master_snapshot(synth_db, tmp_path_factory):
    return take_snapshot(synth_db, tmp_path_factory.mktemp("snap"), "master", fixed_clock())


@pytest.fixture(scope="session")
def master_plan(master_snapshot, spec):
    return build_plan(master_snapshot.path, spec, snapshot_id=master_snapshot.snapshot_id, reference_ms=master_snapshot.taken_at_ms)


@pytest.fixture()
def source_copy(synth_db, tmp_path) -> Path:
    dst = tmp_path / "source" / "retail_source.sqlite"
    dst.parent.mkdir()
    shutil.copy(synth_db, dst)
    shutil.copy(str(synth_db) + ".planted.json", str(dst) + ".planted.json")
    return dst


@pytest.fixture()
def fake(signers) -> FakeChain:
    return FakeChain(signers, NET)


def make_chain_client(fake: FakeChain, keys_dir: Path) -> ChainClient:
    return ChainClient(fake, NET, keys_dir, clock=lambda: NOW, sleep=lambda s: None, wait_timeout_ms=10)


@pytest.fixture()
def chain_client(fake, keys_dir) -> ChainClient:
    return make_chain_client(fake, keys_dir)


@pytest.fixture()
def logs() -> list[str]:
    return []


@pytest.fixture()
def make_migration(tmp_path, spec, fake, keys_dir, logs):
    def factory(source: Path, workdir: Path | None = None, *, trial: bool = False, spec_override=None, **kw) -> Migration:
        cfg = Config(workdir=workdir or (tmp_path / "work"), source_db=source, spec=spec_override or spec, network_id=NET, trial=trial, clock=fixed_clock(), log=logs.append, **kw)
        return Migration(cfg, fake, make_chain_client(fake, keys_dir))

    return factory
