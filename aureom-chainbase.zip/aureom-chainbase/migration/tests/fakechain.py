"""An in-memory model of the chain's import/migration semantics for unit tests (NOT the real chain).

It re-implements, from chain/internal/core/{tx,import,h_catalog,h_pricing}.go, exactly the rules the migration tool must satisfy:
envelope + signature verification over the domain-separated preimage, identity/role checks, replay and idempotency, the CheckTx vs
execution split (business rejections are finalised with a code and no state change), the migration window, strict record decoding
(unknown fields are refused), the import* validators and the migration counters.  It also offers failure injection so the tests can
prove retry safety.  The live integration test (test_integration_live.py) is what checks the model against the real chain."""

from __future__ import annotations

import base64
import json
import pickle
import re
from typing import Any, Callable

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from aureom_migration.chainclient import CODE_NAMES, MAX_IMPORT_TX_BYTES, MAX_TX_BYTES, TransportError, preimage

RE_TXID = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
RE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")
RE_IDEM = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$")
RE_LABEL = re.compile(r"^[\x20-\x7e]{0,200}$")
RE_CUSTOMER = re.compile(r"^(CUST|PSN)-[A-Za-z0-9]{4,40}$")
UNIT_SCALE = {"EA": 0, "PK": 0, "KG": 3, "L": 3, "M": 3}
GENESIS_LOCATIONS = [("WH-DIST-01", "Distribution Centre Midlands", "WAREHOUSE", "central"), ("STORE-N-01", "Northgate Superstore", "STORE", "north"),
                     ("STORE-N-02", "Harbour Street Express", "STORE", "north"), ("STORE-S-01", "Southcoast Superstore", "STORE", "south")]
ROLE_PERMS = {"migration-op": {"import.batch", "migration.control"}, "pricing-mgr": {"price.publish", "promo.manage"}}


class Reject(Exception):
    def __init__(self, code: int, msg: str):
        super().__init__(msg)
        self.code, self.msg = code, msg


def div_half_even(num: int, den: int) -> int:
    q, r = divmod(abs(num), den)
    if 2 * r > den or (2 * r == den and q % 2 == 1):
        q += 1
    return q if num >= 0 else -q


def line_amount(unit_minor: int, v: int, unit: str) -> int:
    return div_half_even(unit_minor * v, 10 ** UNIT_SCALE[unit])


def label(name: str, s: Any, mx: int, required: bool) -> None:
    if not isinstance(s, str) or (required and s == "") or len(s) > mx or not RE_LABEL.match(s):
        raise Reject(6, f"{name} invalid (printable ASCII, max {mx})")


def attrs(name: str, m: Any) -> None:
    if m is None:
        return
    if len(m) > 20:
        raise Reject(406, f"{name}: max 20 entries")
    for k, v in m.items():
        if not k or len(k) > 40 or not RE_LABEL.match(k) or not isinstance(v, str) or len(v) > 200 or not RE_LABEL.match(v):
            raise Reject(6, f"{name}: bad entry {k!r}")


class FakeChain:
    kind = "fake"
    base = "fake://chain"

    def __init__(self, signers: dict[str, Any], network_id: str = "aureom-fake-1", block_time_ms: int = 1_794_000_000_000):
        self.net = network_id
        self.signers = signers  # identity -> Signer (public keys registered at "genesis")
        self.kv: dict[str, Any] = {}
        self.h = 10
        self.block_time_ms = block_time_ms
        self.reports: list[dict] = []
        self.seq = 0
        # failure injection: callable(stage, wire) -> may raise TransportError; stage in {"before", "after"}
        self.inject: Callable[[str, bytes], None] | None = None
        self.submits = 0
        self.executed_batches: list[str] = []
        for lid, name, kind, region in GENESIS_LOCATIONS:
            self.kv[f"loc/{lid}"] = {"id": lid, "name": name, "kind": kind, "region": region, "currency": "GBP", "status": "ACTIVE", "provenance": {"origin": "NATIVE"}}
        self.kv["mig/state"] = {"status": "NOT_STARTED", "source_system": "", "opened_height": 0, "closed_height": 0, "batches": 0, "records": 0, "chain_counters": {}}

    # ------------------------------------------------------------ reads (gateway surface)
    def network_id(self) -> str:
        return self.net

    def height(self) -> int:
        return self.h

    def info(self) -> dict:
        return {"height": self.h, "chain_id": self.net}

    def record(self, key: str, height: int | None = None):
        if key in self.kv:
            return True, json.loads(json.dumps(self.kv[key]))
        return False, None

    def scan(self, prefix: str, height: int | None = None, limit: int = 200):
        for k in sorted(self.kv):
            if k.startswith(prefix):
                yield k, json.loads(json.dumps(self.kv[k]))

    def migration_state(self, height: int | None = None) -> dict:
        return json.loads(json.dumps(self.kv["mig/state"]))

    def post_report(self, raw: bytes) -> dict:
        import hashlib

        rep = json.loads(raw)
        self.reports.append(rep)
        return {"id": rep["id"], "sha256": hashlib.sha256(raw).hexdigest()}

    # ------------------------------------------------------------ submit
    def submit(self, wire: bytes, *, wait: str = "final", timeout_ms: int = 30000) -> dict:
        self.submits += 1
        if self.inject:
            self.inject("before", wire)
        res = self._process(wire)
        if self.inject:
            self.inject("after", wire)  # may raise TransportError AFTER the tx executed (response lost)
        return res

    def _adm(self, code: int, log: str = "") -> dict:
        return {"tx_id": None, "tx_hash": None, "admission": {"code": code, "name": CODE_NAMES.get(code, ""), "log": log}, "finalised": None}

    def _process(self, wire: bytes) -> dict:
        try:
            tx = self._check(wire)
        except Reject as e:
            return self._adm(e.code, e.msg)
        body, handler, payload = tx
        # business execution on an overlay (all-or-nothing)
        snapshot = pickle.loads(pickle.dumps(self.kv, protocol=5))  # rollback image (business rejections leave no trace)
        self.h += 1
        try:
            data = handler(body, payload)
        except Reject as e:
            self.kv = snapshot
            self.kv[f"tx/{body['tx_id']}"] = {"id": body["tx_id"], "type": body["type"], "signer": body["signer"], "status": "REJECTED", "code": e.code, "code_name": CODE_NAMES.get(e.code, ""),
                                              "reason": e.msg, "height": self.h, "block_time_ms": self.block_time_ms, "idempotency_ref": body["idempotency_ref"]}
            return {"tx_id": body["tx_id"], "tx_hash": "X", "admission": {"code": 0, "name": "OK", "log": ""},
                    "finalised": {"height": self.h, "code": e.code, "name": CODE_NAMES.get(e.code, ""), "log": e.msg, "data": None}}
        self.kv[f"idem/{body['signer']}/{body['idempotency_ref']}"] = {"tx_id": body["tx_id"], "type": body["type"], "height": self.h}
        self.kv[f"tx/{body['tx_id']}"] = {"id": body["tx_id"], "type": body["type"], "signer": body["signer"], "status": "OK", "code": 0, "code_name": "OK", "height": self.h,
                                          "block_time_ms": self.block_time_ms, "idempotency_ref": body["idempotency_ref"]}
        return {"tx_id": body["tx_id"], "tx_hash": "X", "admission": {"code": 0, "name": "OK", "log": ""},
                "finalised": {"height": self.h, "code": 0, "name": "OK", "log": "", "data": data}}

    def _check(self, wire: bytes):
        if len(wire) > MAX_IMPORT_TX_BYTES:
            raise Reject(2, "tx too large")
        try:
            env = json.loads(wire)
        except ValueError:
            raise Reject(1, "bad envelope")
        if set(env) != {"v", "body", "sig", "pub"} or env["v"] != 1:
            raise Reject(1, "bad envelope")
        try:
            body_bytes = base64.b64decode(env["body"], validate=True)
            sig = base64.b64decode(env["sig"], validate=True)
            pub = base64.b64decode(env["pub"], validate=True)
        except Exception:
            raise Reject(1, "bad body encoding")
        if len(sig) != 64 or len(pub) != 32:
            raise Reject(1, "bad signature or key encoding")
        try:
            body = json.loads(body_bytes)
        except ValueError:
            raise Reject(1, "bad body")
        allowed = {"tx_id", "network_id", "type", "schema_version", "signer", "key_id", "idempotency_ref", "expected_version", "client_time_ms", "valid_until_height", "payload"}
        if set(body) - allowed:
            raise Reject(1, f"unknown body fields {set(body) - allowed}")
        if body.get("network_id") != self.net:
            raise Reject(3, "wrong network")
        handlers = {"ImportBatch": (self._import, True), "MigrationControl": (self._migctl, False), "ActivatePromotion": (self._promo, False)}
        if body.get("type") not in handlers:
            raise Reject(4, "unknown type")
        handler, bulk = handlers[body["type"]]
        if len(wire) > MAX_TX_BYTES and not bulk:
            raise Reject(2, "tx too large for type")
        if body.get("schema_version") != 1:
            raise Reject(5, "schema")
        if not RE_TXID.match(body.get("tx_id", "")) or not RE_ID.match(body.get("signer", "")) or not RE_ID.match(body.get("key_id", "")) or not RE_IDEM.match(body.get("idempotency_ref", "")):
            raise Reject(6, "tx_id/signer/key_id/idempotency_ref malformed")
        try:
            Ed25519PublicKey.from_public_bytes(pub).verify(sig, preimage(self.net, body_bytes))
        except InvalidSignature:
            raise Reject(101, "signature does not verify")
        s = self.signers.get(body["signer"])
        if s is None:
            raise Reject(201, "signer not registered")
        if s.pub != pub or s.key_id != body["key_id"]:
            raise Reject(202, "key not active")
        if f"tx/{body['tx_id']}" in self.kv:
            raise Reject(210, "replay")
        if f"idem/{body['signer']}/{body['idempotency_ref']}" in self.kv:
            raise Reject(211, "duplicate idempotency")
        perm = {"ImportBatch": "import.batch", "MigrationControl": "migration.control", "ActivatePromotion": "promo.manage"}[body["type"]]
        if perm not in ROLE_PERMS.get(body["signer"], set()):
            raise Reject(301, f"{body['signer']} lacks permission {perm}")
        payload = body.get("payload")
        if not isinstance(payload, dict):
            raise Reject(1, "missing payload")
        return body, handler, payload

    # ------------------------------------------------------------ handlers
    @staticmethod
    def _strict(payload: dict, allowed: set[str], what: str) -> None:
        extra = set(payload) - allowed
        if extra:
            raise Reject(1, f"{what}: unknown fields {sorted(extra)}")

    def _migstate(self) -> dict:
        return self.kv["mig/state"]

    def _migctl(self, body: dict, p: dict) -> dict:
        self._strict(p, {"action", "source_system", "manifest_hash", "report_hash", "source_freeze_marker", "totals"}, "MigrationControl")
        if p.get("action") not in ("OPEN", "CLOSE") or not RE_ID.match(p.get("source_system", "")):
            raise Reject(6, "action/source_system invalid")
        ms = self._migstate()
        if p["action"] == "OPEN":
            if ms["status"] != "NOT_STARTED":
                raise Reject(408, f"window is {ms['status']}")
            ms.update(status="OPEN", source_system=p["source_system"], opened_height=self.h, open_manifest_hash=p.get("manifest_hash", ""))
        else:
            if ms["status"] != "OPEN" or ms["source_system"] != p["source_system"]:
                raise Reject(408, f"window is {ms['status']}")
            if not p.get("report_hash") or not p.get("source_freeze_marker"):
                raise Reject(408, "report_hash and source_freeze_marker are required to close")
            for k in sorted(p.get("totals") or {}):
                if ms["chain_counters"].get(k, 0) != p["totals"][k]:
                    raise Reject(408, f"attested total {k}={p['totals'][k]} but chain counted {ms['chain_counters'].get(k, 0)}")
            ms.update(status="CLOSED", closed_height=self.h, reconciliation_report_hash=p["report_hash"], attested_totals=p.get("totals") or {}, source_freeze_marker=p["source_freeze_marker"])
        return {"status": ms["status"]}

    def _promo(self, body: dict, p: dict) -> dict:
        self._strict(p, {"promo_id", "name", "type", "bp", "off_minor", "buy_n", "bundle_minor", "skus", "locations", "effective_from_ms", "effective_to_ms", "priority", "stackable",
                         "loyalty_only", "status", "currency"}, "ActivatePromotion")
        if not RE_ID.match(p.get("promo_id", "")) or p.get("status") not in ("ACTIVE", "ENDED") or p.get("currency") != "GBP":
            raise Reject(6, "promo_id/status/currency invalid")
        label("name", p.get("name"), 100, True)
        if not p["skus"] or len(p["skus"]) > 50 or not p["locations"]:
            raise Reject(406, "1..50 skus and locations required")
        if p["effective_from_ms"] <= 0 or (p["effective_to_ms"] and p["effective_to_ms"] <= p["effective_from_ms"]) or not 0 <= p["priority"] <= 1000:
            raise Reject(6, "period/priority invalid")
        t = p["type"]
        if t == "PERCENT_OFF" and not 1 <= p["bp"] <= 10000 or t == "AMOUNT_OFF_PER_UNIT" and p["off_minor"] < 1 or \
                t == "MULTIBUY_FIXED_PRICE" and (p["buy_n"] < 2 or p["buy_n"] > 100 or p["bundle_minor"] < 1) or t not in ("PERCENT_OFF", "AMOUNT_OFF_PER_UNIT", "MULTIBUY_FIXED_PRICE"):
            raise Reject(6, "promotion terms invalid")
        for s in p["skus"]:
            if f"sku/{s}" not in self.kv:
                raise Reject(401, f"sku {s} not found")
        for loc in p["locations"]:
            if loc != "*" and f"loc/{loc}" not in self.kv:
                raise Reject(401, f"location {loc} not found")
        existing = self.kv.get(f"promo/{p['promo_id']}")
        self.kv[f"promo/{p['promo_id']}"] = {"id": p["promo_id"], "name": p["name"], "type": t, "bp": p["bp"], "off_minor": p["off_minor"], "buy_n": p["buy_n"], "bundle_minor": p["bundle_minor"],
                                             "skus": p["skus"], "locs": p["locations"], "from_ms": p["effective_from_ms"], "to_ms": p["effective_to_ms"], "priority": p["priority"],
                                             "stackable": p["stackable"], "loyalty_only": p["loyalty_only"], "status": p["status"], "currency": p["currency"], "version": (existing or {}).get("version", 0) + 1}
        return {"promo_id": p["promo_id"]}

    def _import(self, body: dict, p: dict) -> dict:
        self._strict(p, {"batch_id", "source_system", "snapshot_id", "mapping_version", "entity", "seq", "records"}, "ImportBatch")
        for f in ("batch_id", "source_system", "snapshot_id", "mapping_version"):
            if not RE_ID.match(p.get(f, "")):
                raise Reject(6, "batch fields invalid")
        if not p.get("records"):
            raise Reject(6, "batch fields invalid")
        if p.get("entity") not in ("LOCATION", "SUPPLIER", "PRODUCT", "PRICE", "OPENING_BALANCE", "OPEN_PO", "LOYALTY_OPENING", "HISTORICAL_SALE"):
            raise Reject(6, f"unknown entity {p.get('entity')!r}")
        ms = self._migstate()
        if ms["status"] != "OPEN":
            raise Reject(408, f"migration window is {ms['status']}")
        if ms["source_system"] != p["source_system"]:
            raise Reject(408, "batch source differs from opened source")
        if len(p["records"]) > 400:
            raise Reject(406, f"batch has {len(p['records'])} records (max 400)")
        if f"mig/batch/{p['batch_id']}" in self.kv:
            raise Reject(402, f"batch {p['batch_id']} already imported")
        prov = lambda src: {"origin": "IMPORTED", "source_system": p["source_system"], "source_id": src, "batch_id": p["batch_id"], "mapping_version": p["mapping_version"], "snapshot_id": p["snapshot_id"]}
        cnt = ms["chain_counters"]
        ent = p["entity"]
        for r in p["records"]:
            getattr(self, "_imp_" + ent.lower())(r, prov, cnt, p)
        ms["batches"] += 1
        ms["records"] += len(p["records"])
        self.kv[f"mig/batch/{p['batch_id']}"] = {"batch_id": p["batch_id"], "entity": ent, "seq": p["seq"], "records": len(p["records"]), "snapshot_id": p["snapshot_id"],
                                                 "mapping_version": p["mapping_version"], "tx": body["tx_id"], "height": self.h}
        self.executed_batches.append(p["batch_id"])
        return {"batch_id": p["batch_id"], "records": len(p["records"])}

    # ---- per entity (mirrors import.go)
    def _imp_location(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "name", "kind", "region", "currency", "source_extras"}, "location")
        if not RE_ID.match(r["id"]) or r["id"].startswith(("EXT:", "TRANSIT:")) or r["id"] == "*":
            raise Reject(6, "location_id invalid or reserved")
        if r["kind"] not in ("STORE", "WAREHOUSE") or r["currency"] not in ("GBP", "USD", "EUR", "JPY"):
            raise Reject(6, "kind/currency")
        label("name", r["name"], 120, True)
        label("region", r["region"], 40, True)
        if f"loc/{r['id']}" in self.kv:
            raise Reject(402, f"location {r['id']} exists")
        self.kv[f"loc/{r['id']}"] = {"id": r["id"], "name": r["name"], "kind": r["kind"], "region": r["region"], "currency": r["currency"], "status": "ACTIVE",
                                     "source_extras": r.get("source_extras"), "provenance": prov(r["source_id"])}
        cnt["locations"] = cnt.get("locations", 0) + 1

    def _imp_supplier(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "name", "terms", "source_extras"}, "supplier")
        if not RE_ID.match(r["id"]):
            raise Reject(6, "supplier id")
        if f"supplier/{r['id']}" in self.kv:
            raise Reject(402, "supplier exists")
        self.kv[f"supplier/{r['id']}"] = {"id": r["id"], "name": r["name"], "terms": r.get("terms", ""), "status": "ACTIVE", "source_extras": r.get("source_extras"), "provenance": prov(r["source_id"])}
        cnt["suppliers"] = cnt.get("suppliers", 0) + 1

    def _imp_product(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "name", "brand", "category", "status", "attributes", "source_extras", "variants"}, "product")
        if not RE_ID.match(r["id"]):
            raise Reject(6, "product_id invalid")
        label("name", r["name"], 120, True)
        label("brand", r.get("brand", ""), 60, False)
        label("category", r.get("category", ""), 60, False)
        attrs("attributes", r.get("attributes"))
        if not r["variants"] or len(r["variants"]) > 50:
            raise Reject(406, "1..50 variants required")
        for v in r["variants"]:
            self._strict(v, {"sku_id", "barcode", "unit", "scarce", "attributes", "source_extras"}, "variant")
            if not RE_ID.match(v["sku_id"]) or v["unit"] not in UNIT_SCALE or len(v.get("barcode", "")) > 32:
                raise Reject(6, f"variant {v['sku_id']!r} invalid")
            attrs("variant.attributes", v.get("attributes"))
        if r["status"] not in ("ACTIVE", "DISCONTINUED"):
            raise Reject(6, "product status")
        if f"product/{r['id']}" in self.kv:
            raise Reject(402, f"product {r['id']} exists")
        skus = []
        for v in r["variants"]:
            if f"sku/{v['sku_id']}" in self.kv:
                raise Reject(402, f"sku {v['sku_id']} exists")
            if v.get("barcode"):
                if f"bcode/{v['barcode']}" in self.kv:
                    raise Reject(402, f"barcode {v['barcode']} already assigned")
                self.kv[f"bcode/{v['barcode']}"] = v["sku_id"]
            self.kv[f"sku/{v['sku_id']}"] = {"id": v["sku_id"], "product_id": r["id"], "barcode": v.get("barcode", ""), "unit": v["unit"], "scarce": v["scarce"], "status": "ACTIVE",
                                             "attributes": v.get("attributes"), "source_extras": v.get("source_extras"), "provenance": prov(r["source_id"])}
            skus.append(v["sku_id"])
            cnt["skus"] = cnt.get("skus", 0) + 1
        self.kv[f"product/{r['id']}"] = {"id": r["id"], "name": r["name"], "brand": r.get("brand", ""), "category": r.get("category", ""), "status": r["status"], "attributes": r.get("attributes"),
                                         "source_extras": r.get("source_extras"), "skus": skus, "provenance": prov(r["source_id"])}
        cnt["products"] = cnt.get("products", 0) + 1

    def _imp_price(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "sku", "location", "currency", "unit_minor", "from_ms", "to_ms"}, "price")
        if not RE_ID.match(r["id"]) or not RE_ID.match(r["sku"]) or (r["location"] != "*" and not RE_ID.match(r["location"])):
            raise Reject(6, "ids invalid")
        if r["currency"] not in ("GBP", "USD", "EUR", "JPY") or r["unit_minor"] <= 0 or r["unit_minor"] > 10 ** 9:
            raise Reject(6, "currency/unit_minor invalid")
        if r["from_ms"] <= 0 or (r["to_ms"] and r["to_ms"] <= r["from_ms"]):
            raise Reject(6, "effective period invalid")
        if f"price/{r['id']}" in self.kv:
            raise Reject(402, "price id exists")
        if f"sku/{r['sku']}" not in self.kv:
            raise Reject(401, f"sku {r['sku']} not found")
        if r["location"] != "*":
            loc = self.kv.get(f"loc/{r['location']}")
            if not loc:
                raise Reject(401, f"location {r['location']} not found")
            if loc["currency"] != r["currency"]:
                raise Reject(407, f"location {r['location']} trades in {loc['currency']}")
        bk = f"pbook/{r['sku']}/{r['location']}"
        pb = self.kv.setdefault(bk, {"version": 0, "sku": r["sku"], "loc": r["location"], "entries": []})
        if any(e["from_ms"] == r["from_ms"] for e in pb["entries"]):
            raise Reject(402, "a price with this effective_from already exists")
        pb["entries"].append({"id": r["id"], "from_ms": r["from_ms"], "to_ms": r["to_ms"], "unit_minor": r["unit_minor"]})
        pb["version"] += 1
        self.kv[f"price/{r['id']}"] = {"id": r["id"], "sku": r["sku"], "loc": r["location"], "currency": r["currency"], "unit_minor": r["unit_minor"],
                                       "effective_from_ms": r["from_ms"], "effective_to_ms": r["to_ms"]}
        cnt["prices"] = cnt.get("prices", 0) + 1

    def _qty_for(self, sku: str, q: dict) -> dict:
        if q["unit"] not in UNIT_SCALE or not 1 <= q["v"] <= 10 ** 9:
            raise Reject(6, "quantity must be 1..1e9 with a known unit")
        s = self.kv.get(f"sku/{sku}")
        if not s:
            raise Reject(401, f"sku {sku} not found")
        if s["unit"] != q["unit"]:
            raise Reject(407, f"sku {sku} is measured in {s['unit']}, not {q['unit']}")
        return s

    def _imp_opening_balance(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "sku", "location", "qty", "bucket"}, "balance")
        bucket = r.get("bucket") or "available"
        if bucket not in ("available", "quarantined", "damaged"):
            raise Reject(6, "bucket")
        if not RE_ID.match(r["location"]) or f"loc/{r['location']}" not in self.kv:
            raise Reject(401, f"location {r['location']} not found")
        self._qty_for(r["sku"], r["qty"])
        k = f"bal/{r['sku']}/{r['location']}"
        b = self.kv.setdefault(k, {"sku": r["sku"], "loc": r["location"], "available": 0, "reserved": 0, "quarantined": 0, "damaged": 0})
        b[bucket] += r["qty"]["v"]
        self.seq += 1
        self.kv[f"mov/{r['sku']}/{self.seq:012d}"] = {"seq": self.seq, "sku": r["sku"], "from_loc": "EXT:MIGRATION", "from_bucket": "available", "to_loc": r["location"], "to_bucket": bucket,
                                                      "qty": r["qty"]["v"], "reason": "OPENING_BALANCE", "ref_type": "MIGRATION_BATCH", "ref_id": p["batch_id"], "origin": "IMPORTED_OPENING"}
        cnt["opening_balance_units|" + r["qty"]["unit"]] = cnt.get("opening_balance_units|" + r["qty"]["unit"], 0) + r["qty"]["v"]
        cnt["opening_balance_rows"] = cnt.get("opening_balance_rows", 0) + 1

    def _imp_open_po(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "supplier_id", "location", "currency", "ordered_at_ms", "status", "lines", "source_extras"}, "po")
        if not RE_ID.match(r["id"]) or not RE_ID.match(r["supplier_id"]) or r["currency"] not in ("GBP", "USD", "EUR", "JPY") or not r["lines"] or len(r["lines"]) > 100:
            raise Reject(6, "po fields")
        if r["status"] not in ("DRAFT", "APPROVED", "PARTIALLY_RECEIVED"):
            raise Reject(6, "only outstanding purchase orders are imported")
        if f"po/{r['id']}" in self.kv:
            raise Reject(402, "po exists")
        if f"supplier/{r['supplier_id']}" not in self.kv:
            raise Reject(401, f"supplier {r['supplier_id']} not found")
        if f"loc/{r['location']}" not in self.kv:
            raise Reject(401, f"location {r['location']} not found")
        total, lines = 0, []
        for i, l in enumerate(r["lines"], 1):
            self._strict(l, {"sku", "qty", "unit_cost_minor", "received_v"}, "po line")
            self._qty_for(l["sku"], l["qty"])
            if l["received_v"] < 0 or l["received_v"] > l["qty"]["v"] or l["unit_cost_minor"] <= 0:
                raise Reject(6, "po line quantities")
            lines.append({"line_no": i, "sku": l["sku"], "qty": l["qty"], "unit_cost_minor": l["unit_cost_minor"], "received_v": l["received_v"]})
            total += line_amount(l["unit_cost_minor"], l["qty"]["v"], l["qty"]["unit"])
            key = "po_outstanding_units|" + l["qty"]["unit"]
            cnt[key] = cnt.get(key, 0) + l["qty"]["v"] - l["received_v"]
        self.kv[f"po/{r['id']}"] = {"id": r["id"], "supplier_id": r["supplier_id"], "location_id": r["location"], "currency": r["currency"], "lines": lines, "total_minor": total, "status": r["status"],
                                    "ordered_at_ms": r["ordered_at_ms"], "source_extras": r.get("source_extras"), "provenance": prov(r["source_id"])}
        cnt["open_pos"] = cnt.get("open_pos", 0) + 1
        cnt["open_po_total_minor"] = cnt.get("open_po_total_minor", 0) + total

    def _imp_loyalty_opening(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "customer_id", "points"}, "loyalty")
        if not RE_CUSTOMER.match(r["customer_id"]) or r["points"] < 0 or r["points"] > 10 ** 9:
            raise Reject(6, "customer_id must be synthetic/pseudonymous; points invalid")
        if f"loy/{r['customer_id']}" in self.kv:
            raise Reject(402, "loyalty account exists")
        pv = prov(r["source_id"])
        self.kv[f"loy/{r['customer_id']}"] = {"id": r["customer_id"], "points": r["points"], "lifetime_earned": r["points"], "entries": 1, "status": "ACTIVE", "provenance": pv}
        self.kv[f"loye/LE-OPEN-{r['customer_id']}"] = {"id": f"LE-OPEN-{r['customer_id']}", "account": r["customer_id"], "type": "OPENING", "points": r["points"], "provenance": pv}
        cnt["loyalty_accounts"] = cnt.get("loyalty_accounts", 0) + 1
        cnt["loyalty_points"] = cnt.get("loyalty_points", 0) + r["points"]

    def _imp_historical_sale(self, r, prov, cnt, p):
        self._strict(r, {"source_id", "id", "location", "channel", "customer_id", "currency", "effective_at_ms", "lines", "payment_status", "paid_minor", "refunded_minor", "source_extras"}, "sale")
        if not RE_ID.match(r["id"]) or r["currency"] not in ("GBP", "USD", "EUR", "JPY") or not r["lines"] or len(r["lines"]) > 100 or r["channel"] not in ("STORE", "ECOM"):
            raise Reject(6, "sale fields")
        if r.get("customer_id") and not RE_CUSTOMER.match(r["customer_id"]):
            raise Reject(6, "customer id must be synthetic/pseudonymous")
        if f"sale/{r['id']}" in self.kv:
            raise Reject(402, "sale exists")
        if f"loc/{r['location']}" not in self.kv:
            raise Reject(401, f"location {r['location']} not found")
        if r["effective_at_ms"] <= 0 or r["paid_minor"] < 0 or r["refunded_minor"] < 0:
            raise Reject(6, "sale amounts/time")
        gross = net = 0
        lines = []
        for i, l in enumerate(r["lines"], 1):
            self._strict(l, {"sku", "qty", "unit_minor", "gross_minor", "net_minor"}, "sale line")
            if l["qty"]["unit"] not in UNIT_SCALE or not 1 <= l["qty"]["v"] <= 10 ** 9:
                raise Reject(6, "quantity")
            if l["net_minor"] < 0 or l["gross_minor"] < l["net_minor"]:
                raise Reject(6, "sale line amounts")
            lines.append({"line_no": i, "sku": l["sku"], "qty": l["qty"], "unit_minor": l["unit_minor"], "gross_minor": l["gross_minor"], "net_minor": l["net_minor"]})
            gross += l["gross_minor"]
            net += l["net_minor"]
        self.kv[f"sale/{r['id']}"] = {"id": r["id"], "loc": r["location"], "channel": r["channel"], "customer_id": r.get("customer_id", ""), "currency": r["currency"], "lines": lines,
                                      "gross_minor": gross, "discount_minor": gross - net, "net_minor": net, "effective_at_ms": r["effective_at_ms"], "payment_status": r["payment_status"],
                                      "paid_minor": r["paid_minor"], "refund_confirmed_minor": r["refunded_minor"], "source_extras": r.get("source_extras"), "provenance": prov(r["source_id"])}
        cnt["historical_sales"] = cnt.get("historical_sales", 0) + 1
        cnt["historical_net_minor"] = cnt.get("historical_net_minor", 0) + net
        cnt["historical_refunded_minor"] = cnt.get("historical_refunded_minor", 0) + r["refunded_minor"]
