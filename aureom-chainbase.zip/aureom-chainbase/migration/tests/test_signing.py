"""Byte-compatibility of envelopes with the Go implementation (golden vectors produced by core.SignTx) and client-side guard rails."""

import base64
import json
from pathlib import Path

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from aureom_migration.chainclient import (ChainClient, MAX_IMPORT_TX_BYTES, MAX_TX_BYTES, Signer, assert_no_floats, build_body, encode_json, load_signer, preimage,
                                          sign_envelope, tx_hash_hex)
from aureom_migration.util import MigrationError

GOLDEN = json.loads((Path(__file__).parent / "golden.json").read_text())


@pytest.mark.parametrize("v", GOLDEN, ids=lambda v: v["name"])
def test_golden_vector_byte_compat(v):
    s = Signer("migration-op", "k1", bytes.fromhex(v["seed_hex"]))
    assert s.pub_b64 == v["pub_b64"]  # same key derivation as Go's ed25519.NewKeyFromSeed
    f = v["fields"]
    payload = json.loads(v["payload_raw"])
    body = build_body(tx_id=f["tx_id"], network_id=v["network_id"], tx_type=f["type"], signer=f["signer"], key_id=f["key_id"], idempotency_ref=f["idempotency_ref"],
                      client_time_ms=f["client_time_ms"], payload=payload, expected_version=f["expected_version"], valid_until_height=f["valid_until_height"])
    body_bytes = encode_json(body)
    assert body_bytes.decode("utf-8") == v["body_text"]  # the Python body encoder produces the very bytes Go's SignTx produced
    assert base64.b64encode(body_bytes).decode() == v["body_b64"]
    assert preimage(v["network_id"], body_bytes).hex() == v["preimage_hex"]
    assert sign_envelope(v["network_id"], s, body_bytes).decode() == v["envelope"]  # identical signature and identical envelope bytes
    env = json.loads(v["envelope"])
    assert base64.b64encode(s.sign(preimage(v["network_id"], body_bytes))).decode() == v["sig_b64"] == env["sig"]
    # and the Go signature verifies with an independent ed25519 implementation over the documented preimage
    Ed25519PublicKey.from_public_bytes(base64.b64decode(v["pub_b64"])).verify(base64.b64decode(v["sig_b64"]), bytes.fromhex(v["preimage_hex"]))


def test_preimage_is_domain_and_network_separated():
    a, b = preimage("net-a", b"{}"), preimage("net-b", b"{}")
    assert a != b and a.startswith(b"AUREOM-CHAINBASE/TX/v1\x00net-a\x00") and a.endswith(b"{}")


def test_optional_body_fields_are_omitted_like_go_omitempty():
    b = build_body(tx_id="tx-0000001", network_id="n", tx_type="ImportBatch", signer="s", key_id="k1", idempotency_ref="i", client_time_ms=1, payload={})
    assert "expected_version" not in b and "valid_until_height" not in b
    assert list(b)[:7] == ["tx_id", "network_id", "type", "schema_version", "signer", "key_id", "idempotency_ref"]


def test_hash_is_sha256_of_the_wire_bytes():
    assert tx_hash_hex(b"abc") == "BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD"


def test_floats_are_refused_in_payloads():
    assert_no_floats({"a": [1, {"b": 2}], "c": "1.5"})
    with pytest.raises(MigrationError, match="floating point"):
        assert_no_floats({"records": [{"unit_minor": 12.5}]})


def test_size_limits_are_enforced_client_side(chain_client):
    big = {"records": [{"x": "y" * 1000}] * 40}  # > 32 KiB
    with pytest.raises(MigrationError, match="over the chain limit"):
        chain_client.build_wire("pricing-mgr", "ActivatePromotion", big, tx_id="tx-sizecheck", idempotency_ref="i-1")
    chain_client.build_wire("migration-op", "ImportBatch", big, tx_id="tx-sizecheck2", idempotency_ref="i-2")  # bulk type: allowed up to 900 KiB
    huge = {"records": [{"x": "y" * 1000}] * 1000}
    assert len(json.dumps(huge)) > MAX_IMPORT_TX_BYTES
    with pytest.raises(MigrationError, match="over the chain limit"):
        chain_client.build_wire("migration-op", "ImportBatch", huge, tx_id="tx-sizecheck3", idempotency_ref="i-3")


def test_load_signer_checks_key_file(tmp_path):
    (tmp_path / "x.json").write_text(json.dumps({"identity": "x", "key_id": "k1", "seed_hex": "01" * 32, "pub_b64": "AAAA"}))
    with pytest.raises(MigrationError, match="does not match the seed"):
        load_signer(tmp_path, "x")
    with pytest.raises(MigrationError, match="cannot read"):
        load_signer(tmp_path, "missing")


def test_fake_chain_accepts_our_envelopes_and_refuses_tampering(fake, chain_client):
    """The fake verifies real signatures over the real preimage, so these also pin the client behaviour."""
    ok = chain_client.send_idempotent("migration-op", "MigrationControl", {"action": "OPEN", "source_system": "legacy-retail-erp", "manifest_hash": "m", "report_hash": "",
                                                                          "source_freeze_marker": "", "totals": {}}, idem_ref="mig-open-1", id_base="mc-open-test1")
    assert ok.status == "OK"
    wire = chain_client.build_wire("migration-op", "MigrationControl", {"action": "OPEN", "source_system": "legacy-retail-erp"}, tx_id="tx-tamper01", idempotency_ref="i-t1")
    env = json.loads(wire)
    body = json.loads(base64.b64decode(env["body"]))
    body["payload"]["source_system"] = "someone-else"
    env["body"] = base64.b64encode(json.dumps(body).encode()).decode()
    assert fake.submit(json.dumps(env).encode())["admission"]["code"] == 101  # BAD_SIGNATURE
    other_net = ChainClient(fake, "other-net", chain_client.keys_dir).build_wire("migration-op", "MigrationControl", {"action": "OPEN", "source_system": "x1"}, tx_id="tx-tamper02", idempotency_ref="i-t2")
    assert fake.submit(other_net)["admission"]["code"] == 3  # WRONG_NETWORK
    wrong_role = chain_client.build_wire("pricing-mgr", "MigrationControl", {"action": "OPEN", "source_system": "x1"}, tx_id="tx-tamper03", idempotency_ref="i-t3")
    assert fake.submit(wrong_role)["admission"]["code"] == 301  # UNAUTHORIZED: pricing-mgr may not control the migration window
