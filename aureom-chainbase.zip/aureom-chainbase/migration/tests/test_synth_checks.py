"""The synthetic source, the schema gate and the integrity checks: every planted problem must be caught, nothing may vanish silently."""

import json
import re
import shutil
import sqlite3
from pathlib import Path

import pytest

from aureom_migration import synth
from aureom_migration.checks import EXCLUDED, FIXED, MANUAL, PRESERVED, schema_gate
from aureom_migration.convert import CHAIN_CUSTOMER_RE, CHAIN_ID_RE, CHAIN_LABEL_RE
from aureom_migration.inventory import inventory
from aureom_migration.mapping import load_spec, validate_spec
from aureom_migration.plan import build_plan, expected_counters
from aureom_migration.report import quality_checks
from aureom_migration.snapshot import content_digest, take_snapshot
from aureom_migration.util import MigrationError
from conftest import fixed_clock


# ------------------------------------------------------------------ the synthetic database
def test_synth_is_deterministic(tmp_path):
    a, b = tmp_path / "a.sqlite", tmp_path / "b.sqlite"
    synth.generate(42, a)
    synth.generate(42, b)
    ca, cb = sqlite3.connect(a), sqlite3.connect(b)
    assert content_digest(ca) == content_digest(cb)
    assert Path(str(a) + ".planted.json").read_text() == Path(str(b) + ".planted.json").read_text()
    c = tmp_path / "c.sqlite"
    synth.generate(43, c)
    assert content_digest(sqlite3.connect(c)) != content_digest(ca)


def test_synth_shape_matches_the_brief(synth_db):
    con = sqlite3.connect(synth_db)
    n = lambda q: con.execute(q).fetchone()[0]
    assert 140 <= n("SELECT count(*) FROM products") <= 160 and 380 <= n("SELECT count(*) FROM product_variants") <= 440
    assert 1900 <= n("SELECT count(*) FROM sales WHERE status='COMPLETE'") <= 2100
    assert n("SELECT count(*) FROM stores") == 4 and n("SELECT count(*) FROM warehouses") == 2
    assert {r[0] for r in con.execute("SELECT store_code FROM stores UNION SELECT wh_code FROM warehouses")} == {"S001", "S002", "S003", "S004", "DC01", "DC02"}
    cols = lambda t: {r[1] for r in con.execute(f"PRAGMA table_info({t})")}
    assert {"loyalty_tier_colour", "custom_json"} <= cols("products") and "credit_rating" in cols("suppliers")
    assert {"system_state", "change_log", "price_lists", "promotions", "loyalty_accounts", "returns", "refunds", "payments"} <= {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    # money is stored as REAL (floats) and timestamps in mixed formats
    assert n("SELECT count(*) FROM sale_lines WHERE typeof(unit_price)='real'") > 3000
    shapes = {re.sub(r"\d", "9", r[0]) for r in con.execute("SELECT sold_at FROM sales")}
    assert len(shapes) >= 6, shapes


def test_demo_ids_exist_exactly(synth_db):
    con = sqlite3.connect(synth_db)
    assert con.execute("SELECT p.name, v.unit, v.scarce FROM product_variants v JOIN products p USING (product_id) WHERE v.sku='KETTLE-RED'").fetchone() == ("Aureom Barista Kettle", "EA", 1)
    assert con.execute("SELECT on_hand, reserved, damaged FROM inventory_balances WHERE sku='KETTLE-RED' AND location_code='S001'").fetchone() == (2.0, 0.0, 0.0)
    assert con.execute("SELECT status, location_code FROM purchase_orders WHERE po_number='PO-2001'").fetchone() == ("APPROVED", "S001")
    assert con.execute("SELECT sku, qty_ordered, qty_received, unit_cost FROM purchase_order_lines WHERE po_number='PO-2001'").fetchone() == ("KETTLE-RED", 1.0, 0.0, 18.0)
    assert con.execute("SELECT price FROM price_list_items WHERE sku='KETTLE-RED'").fetchone() == (39.99,)
    assert con.execute("SELECT points_balance FROM loyalty_accounts WHERE customer_id='CUST-DEMO01'").fetchone() == (120,)
    demo = json.loads(Path(str(synth_db) + ".demo.json").read_text())
    assert demo["kettle"]["open_po"]["po_id"] == "PO-2001" and demo["loyalty"]["customer_id"] == "CUST-DEMO01"


def test_demo_data_lands_correctly_in_the_plan(master_plan):
    r = master_plan.records
    prod = next(p for p in r["PRODUCT"] if p["id"] == "PRD-KETTLE")
    assert prod["name"] == "Aureom Barista Kettle" and [v["sku_id"] for v in prod["variants"]] == ["KETTLE-RED"]
    assert prod["variants"][0]["unit"] == "EA" and prod["variants"][0]["scarce"] is True
    bal = [b for b in r["OPENING_BALANCE"] if b["sku"] == "KETTLE-RED"]
    assert bal == [{"source_id": bal[0]["source_id"], "sku": "KETTLE-RED", "location": "STORE-N-01", "qty": {"v": 2, "unit": "EA"}, "bucket": "available"}]
    po = next(p for p in r["OPEN_PO"] if p["id"] == "PO-2001")
    assert po["status"] == "APPROVED" and po["location"] == "STORE-N-01" and po["lines"] == [{"sku": "KETTLE-RED", "qty": {"v": 1, "unit": "EA"}, "unit_cost_minor": 1800, "received_v": 0}]
    price = [p for p in r["PRICE"] if p["sku"] == "KETTLE-RED"]
    assert len(price) == 1 and price[0]["location"] == "*" and price[0]["unit_minor"] == 3999 and price[0]["currency"] == "GBP"
    assert {"customer_id": "CUST-DEMO01", "points": 120} == {k: v for k, v in next(l for l in r["LOYALTY_OPENING"] if l["customer_id"] == "CUST-DEMO01").items() if k != "source_id"}
    assert [p["promo_id"] for p in master_plan.promotions] == ["PRM-PROMO-001", "PRM-PROMO-002", "PRM-PROMO-005"]
    assert not any("KETTLE-RED" in p["skus"] for p in master_plan.promotions)  # the demo price maths stays untouched by promotions
    assert [l["id"] for l in r["LOCATION"]] == ["STORE-E-01", "WH-RET-01"]  # genesis locations are mapped, never imported
    assert set(master_plan.location_ids.values()) >= {"STORE-N-01", "STORE-N-02", "STORE-S-01", "WH-DIST-01", "STORE-E-01", "WH-RET-01"}


def test_promotion_mapping_values(master_plan):
    p = {x["promo_id"]: x for x in master_plan.promotions}
    assert p["PRM-PROMO-001"]["type"] == "PERCENT_OFF" and p["PRM-PROMO-001"]["bp"] == 1500 and p["PRM-PROMO-001"]["locations"] == ["*"]
    assert p["PRM-PROMO-002"]["type"] == "MULTIBUY_FIXED_PRICE" and p["PRM-PROMO-002"]["buy_n"] == 3 and p["PRM-PROMO-002"]["bundle_minor"] == 1000
    assert p["PRM-PROMO-002"]["locations"] == ["STORE-N-01", "STORE-N-02", "STORE-S-01"] and p["PRM-PROMO-002"]["name"] == "Coffee 3 for GBP 10"
    assert p["PRM-PROMO-005"]["type"] == "AMOUNT_OFF_PER_UNIT" and p["PRM-PROMO-005"]["off_minor"] == 200 and p["PRM-PROMO-005"]["loyalty_only"] and p["PRM-PROMO-005"]["effective_to_ms"] == 0
    assert ("UNSUPPORTED_PROMO_TYPE", "promotions:PROMO-003") in master_plan.exceptions.refs(disposition=MANUAL)
    assert master_plan.exceptions.out_of_scope["PROMOTION"]  # the ended winter sale is out of scope, not an exception


# ------------------------------------------------------------------ every planted problem is caught
def test_every_planted_problem_is_caught_with_the_expected_disposition(master_plan, synth_db):
    planted = json.loads(Path(str(synth_db) + ".planted.json").read_text())
    assert len(planted) >= 80
    have = {(e.kind, e.source_ref): e.disposition for e in master_plan.exceptions.items}
    missing = [p for p in planted if (p["kind"], p["source_ref"]) not in have]
    assert not missing, missing
    wrong = [(p, have[(p["kind"], p["source_ref"])]) for p in planted if have[(p["kind"], p["source_ref"])] != p["disposition"]]
    assert not wrong, wrong


@pytest.mark.parametrize("kind", ["DUPLICATE_SKU", "DUPLICATE_BARCODE", "ORPHAN_FK", "NEGATIVE_STOCK", "FRACTIONAL_QUANTITY", "UNIT_MISMATCH", "STALE_PO_CLOSED", "FLOAT_PRECISION",
                                  "AMBIGUOUS_LOCAL_TIME", "NONEXISTENT_LOCAL_TIME", "INVALID_TIMESTAMP", "NON_ASCII_TEXT", "LEGACY_CUSTOMER_ID", "UNSUPPORTED_FIELD", "CURRENCY_MISMATCH"])
def test_each_brief_category_is_present(master_plan, kind):
    assert master_plan.exceptions.by_kind().get(kind, 0) >= 1


def test_orphans_cover_the_required_relationships(master_plan):
    orph = [e for e in master_plan.exceptions.items if e.kind == "ORPHAN_FK"]
    text = " | ".join(e.detail for e in orph)
    assert "references missing variant" in text  # sale line -> missing variant
    assert "unknown location" in text  # inventory -> unknown store
    assert any(e.source_ref.startswith("purchase_orders:") for e in orph) and any(e.source_ref.startswith("payments:") for e in orph)


def test_duplicate_and_unit_rules(master_plan):
    ex = {(e.kind, e.source_ref): e for e in master_plan.exceptions.items}
    dups = [e for e in master_plan.exceptions.items if e.kind == "DUPLICATE_SKU"]
    assert any("after normalisation" in e.detail for e in dups) and any("identical" in e.detail for e in dups)
    um = [e for e in master_plan.exceptions.items if e.kind == "UNIT_MISMATCH"]
    assert any("uom='KG'" in e.detail for e in um) and any("balance row unit" in e.detail for e in um) and any("sale line" in e.detail for e in um)
    neg = [e for e in master_plan.exceptions.items if e.kind == "NEGATIVE_STOCK"]
    assert len(neg) == 4 and all(e.disposition == MANUAL for e in neg)


# ------------------------------------------------------------------ nothing vanishes silently
def test_no_silent_exclusion_every_excluded_record_has_an_exception(master_plan):
    refs_with_exc = {e.source_ref for e in master_plan.exceptions.items}
    for ent, refs in master_plan.exceptions.excluded.items():
        assert refs <= refs_with_exc, (ent, sorted(refs - refs_with_exc)[:5])
    assert sum(len(v) for v in master_plan.exceptions.excluded.values()) > 40


def test_exception_accounting_closes_for_every_entity(master_plan, spec):
    checks = quality_checks(master_plan, spec, "final", {"all": True, "by": "t"})
    closing = [c for c in checks if c["name"].startswith("exception accounting closes")]
    assert len(closing) == 10 and all(c["status"] == "PASS" for c in closing), [c for c in closing if c["status"] != "PASS"]
    assert all(c["status"] != "FAIL" for c in checks)


def test_unsupported_columns_are_preserved_in_source_extras(master_plan, synth_db):
    uf = {(u["table"], u["column"]): u for u in master_plan.unsupported_fields}
    for key in (("products", "loyalty_tier_colour"), ("products", "custom_json"), ("suppliers", "credit_rating")):
        assert uf[key]["treatment"] == "preserved in source_extras" and uf[key]["rows"] > 0
    assert uf[("loyalty_accounts", "tier_colour")]["treatment"] == "dropped with approval" and uf[("loyalty_accounts", "tier_colour")]["approval"] == "AP-2026-0147"
    assert uf[("inventory_balances", "reserved")]["treatment"].startswith("folded")
    con = sqlite3.connect(synth_db)
    con.row_factory = sqlite3.Row
    by_id = {p["id"]: p for p in master_plan.records["PRODUCT"]}
    n_tier = n_json = 0
    for r in con.execute("SELECT * FROM products"):
        p = by_id.get(r["product_code"])
        if p is None:
            continue
        ex = p.get("source_extras", {})
        if r["loyalty_tier_colour"]:
            n_tier += 1
            assert ex["loyalty_tier_colour"] == r["loyalty_tier_colour"]
        else:
            assert "loyalty_tier_colour" not in ex
        if r["custom_json"]:
            n_json += 1
            assert ex["custom_json"] == r["custom_json"]  # verbatim
    assert n_tier > 30 and n_json > 15
    sup = next(s for s in master_plan.records["SUPPLIER"] if s["id"] == "SUP-001")
    assert sup["source_extras"]["credit_rating"] in ("A", "A-", "B+", "B", "C")
    # report-level: every unsupported column with data is also an exception (so it shows in the exception list)
    assert ("UNSUPPORTED_FIELD", "products.loyalty_tier_colour") in master_plan.exceptions.refs(disposition=PRESERVED)
    assert ("UNSUPPORTED_FIELD", "loyalty_accounts.tier_colour") in master_plan.exceptions.refs(disposition=EXCLUDED)


def test_original_text_is_kept_when_it_is_transliterated(master_plan):
    prod = next(p for p in master_plan.records["PRODUCT"] if p["name"] == "Cafe Latte Mug 350ml")
    assert prod["source_extras"]["name_original"] == "Café Latté Mug 350ml"
    sup = next(s for s in master_plan.records["SUPPLIER"] if s["id"] == "SUP-008")
    assert sup["name"] == "Muller & Sohne Ltd" and sup["source_extras"]["name_original"] == "Müller & Söhne Ltd"


def test_barcode_conflict_is_preserved_not_lost(master_plan):
    cleared = [v for p in master_plan.records["PRODUCT"] for v in p["variants"] if "barcode_original" in v.get("source_extras", {})]
    assert len(cleared) == 3 and all(v["barcode"] == "" and v["source_extras"]["barcode_cleared_reason"].startswith("duplicate of") for v in cleared)
    barcodes = [v["barcode"] for p in master_plan.records["PRODUCT"] for v in p["variants"] if v["barcode"]]
    assert len(barcodes) == len(set(barcodes))  # the chain enforces unique barcodes


# ------------------------------------------------------------------ record-level invariants (what the chain validators would enforce)
def _walk(o):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)
    else:
        yield o


def test_plan_contains_no_floats_and_valid_ids(master_plan):
    for ent, recs in master_plan.records.items():
        for r in recs:
            assert not any(isinstance(x, float) for x in _walk(r)), (ent, r["source_id"])
    for p in master_plan.promotions:
        assert not any(isinstance(x, float) for x in _walk(p))
    r = master_plan.records
    per_entity = {"PRODUCT": [p["id"] for p in r["PRODUCT"]], "SKU": [v["sku_id"] for p in r["PRODUCT"] for v in p["variants"]], "SUPPLIER": [s["id"] for s in r["SUPPLIER"]],
                  "PRICE": [x["id"] for x in r["PRICE"]], "OPEN_PO": [x["id"] for x in r["OPEN_PO"]], "HISTORICAL_SALE": [x["id"] for x in r["HISTORICAL_SALE"]],
                  "LOCATION": [x["id"] for x in r["LOCATION"]]}
    for ent, ids in per_entity.items():
        assert ids and all(CHAIN_ID_RE.match(i) for i in ids), ent
        assert len(ids) == len(set(ids)), f"duplicate chain ids in {ent}"  # the chain would reject the second one
    assert all(CHAIN_CUSTOMER_RE.match(l["customer_id"]) for l in r["LOYALTY_OPENING"])
    assert all(not s["customer_id"] or CHAIN_CUSTOMER_RE.match(s["customer_id"]) for s in r["HISTORICAL_SALE"])
    for p in r["PRODUCT"]:
        assert CHAIN_LABEL_RE.match(p["name"]) and len(p["name"]) <= 120 and len(p["brand"]) <= 60 and len(p["category"]) <= 60
        for v in p["variants"]:
            assert v["unit"] in ("EA", "PK", "KG", "L", "M") and len(v["barcode"]) <= 32
            assert all(isinstance(x, str) for x in v.get("source_extras", {}).values())
    for s in r["HISTORICAL_SALE"]:
        assert s["channel"] in ("STORE", "ECOM") and s["effective_at_ms"] > 0
        for l in s["lines"]:
            assert l["qty"]["v"] >= 1 and 0 <= l["net_minor"] <= l["gross_minor"]


def test_quantities_follow_unit_scales(master_plan):
    units = master_plan.sku_units
    for b in master_plan.records["OPENING_BALANCE"]:
        assert b["qty"]["unit"] == units[b["sku"]] and b["qty"]["v"] > 0 and b["bucket"] in ("available", "damaged")
    kg = [b for b in master_plan.records["OPENING_BALANCE"] if b["qty"]["unit"] == "KG"]
    assert kg and all(isinstance(b["qty"]["v"], int) for b in kg)  # grams


def test_historical_sales_are_labelled_assertions_without_native_events(master_plan):
    s = master_plan.records["HISTORICAL_SALE"][0]
    assert set(s) <= {"source_id", "id", "location", "channel", "customer_id", "currency", "effective_at_ms", "lines", "payment_status", "paid_minor", "refunded_minor", "source_extras"}
    assert s["id"].startswith("HS-") and s["source_id"].startswith("sales:") and "sold_at_raw" in s["source_extras"]
    assert "reservation_id" not in json.dumps(s) and "movement" not in json.dumps(s)


def test_expected_counters_are_integers_and_consistent(master_plan):
    c = expected_counters(master_plan.records)
    assert all(isinstance(v, int) for v in c.values())
    assert c["products"] == len(master_plan.records["PRODUCT"]) and c["skus"] == sum(len(p["variants"]) for p in master_plan.records["PRODUCT"])
    assert c["historical_net_minor"] == sum(l["net_minor"] for s in master_plan.records["HISTORICAL_SALE"] for l in s["lines"])
    assert c["opening_balance_units|EA"] == sum(b["qty"]["v"] for b in master_plan.records["OPENING_BALANCE"] if b["qty"]["unit"] == "EA")


def test_plan_is_a_pure_function_of_the_snapshot(master_snapshot, spec, master_plan):
    again = build_plan(master_snapshot.path, spec, snapshot_id=master_snapshot.snapshot_id, reference_ms=master_snapshot.taken_at_ms)
    assert json.dumps(again.records, sort_keys=True) == json.dumps(master_plan.records, sort_keys=True)
    assert [e.to_report() for e in again.exceptions.sorted()] == [e.to_report() for e in master_plan.exceptions.sorted()]


# ------------------------------------------------------------------ schema gate and spec validation
def test_schema_gate_fails_on_an_unmapped_column(source_copy, spec):
    con = sqlite3.connect(source_copy)
    con.execute("ALTER TABLE products ADD COLUMN eco_score INTEGER")
    con.execute("UPDATE products SET eco_score = 3 WHERE product_id < 10")
    con.commit()
    con.close()
    gate = schema_gate(spec, inventory(source_copy))
    assert not gate.ok
    e = next(e for e in gate.exceptions if e.kind == "UNMAPPED_COLUMN")
    assert e.source_ref == "products.eco_score" and e.disposition == MANUAL


def test_schema_gate_fails_on_unmapped_table_and_missing_column(source_copy, spec):
    con = sqlite3.connect(source_copy)
    con.execute("CREATE TABLE warranty_claims (id INTEGER PRIMARY KEY, note TEXT)")
    con.execute("ALTER TABLE suppliers DROP COLUMN credit_rating")
    con.commit()
    con.close()
    gate = schema_gate(spec, inventory(source_copy))
    kinds = {e.kind for e in gate.exceptions}
    assert not gate.ok and {"UNMAPPED_TABLE", "MAPPED_COLUMN_MISSING"} <= kinds


def test_schema_gate_passes_on_the_synthetic_source(spec, synth_db):
    gate = schema_gate(spec, inventory(synth_db))
    assert gate.ok and len(gate.unsupported_fields) >= 30


def test_migration_refuses_an_unmapped_schema(source_copy, make_migration):
    con = sqlite3.connect(source_copy)
    con.execute("ALTER TABLE sales ADD COLUMN loyalty_bonus REAL")
    con.commit()
    con.close()
    with pytest.raises(MigrationError, match="schema gate FAILED"):
        make_migration(source_copy).master()


def _spec_with(tmp_path, mutate):
    import yaml

    raw = yaml.safe_load(open(load_spec().path))
    mutate(raw)
    p = tmp_path / "m.yaml"
    p.write_text(yaml.safe_dump(raw))
    return p


def test_spec_validation_requires_approval_for_dropped_columns(tmp_path):
    p = _spec_with(tmp_path, lambda r: r["tables"]["loyalty_accounts"]["tier"].pop("approval"))
    with pytest.raises(MigrationError, match="requires an approval"):
        load_spec(p)
    p = _spec_with(tmp_path, lambda r: r["tables"]["inventory_balances"].__setitem__("bin_location", {"treatment": "extras", "key": "bin"}))
    with pytest.raises(MigrationError, match="no source_extras"):
        load_spec(p)
    p = _spec_with(tmp_path, lambda r: r["tables"]["products"].__setitem__("name", {"treatment": "mystery"}))
    with pytest.raises(MigrationError, match="unknown treatment"):
        load_spec(p)
    p = _spec_with(tmp_path, lambda r: r["batching"].__setitem__("max_records", 401))
    with pytest.raises(MigrationError, match="max_records"):
        load_spec(p)


def test_snapshot_is_consistent_and_tamper_evident(source_copy, tmp_path):
    from aureom_migration.snapshot import verify_snapshot

    a = take_snapshot(source_copy, tmp_path / "s", "master", fixed_clock())
    b = take_snapshot(source_copy, tmp_path / "s2", "master", fixed_clock())
    assert a.snapshot_id == b.snapshot_id and a.content_digest == b.content_digest  # same content -> same id (even if file bytes differ)
    assert a.row_counts["sales"] == 1982 and a.system_state["authoritative_system"] == "SOURCE" and a.marker["rows"] == 0
    verify_snapshot(a)
    with open(a.path, "r+b") as f:
        f.seek(5000)
        f.write(b"tampered")
    with pytest.raises(MigrationError, match="modified after it was taken"):
        verify_snapshot(a)
    con = sqlite3.connect(source_copy)
    con.execute("UPDATE products SET name = name || ' x' WHERE product_id = 2")
    con.commit()
    con.close()
    c = take_snapshot(source_copy, tmp_path / "s3", "master", fixed_clock())
    assert c.snapshot_id != a.snapshot_id and c.marker["rows"] == 1  # the change-log trigger fired: high-water mark moved
