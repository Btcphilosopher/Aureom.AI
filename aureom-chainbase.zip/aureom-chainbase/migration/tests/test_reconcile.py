"""Reconciliation math: chain-authoritative values vs expected totals; deliberately corrupted chains must FAIL."""

import copy
import json

import pytest

from aureom_migration.reconcile import FAIL, PASS, _chk, _diff, compare, read_chain_view
from aureom_migration.report import decide, quality_checks

ACK = {"all": True, "by": "test-operator", "reason": "unit test", "at": "2026-11-12T00:00:00Z"}


@pytest.fixture()
def ready(source_copy, make_migration, fake):
    """A migration imported up to OPENING_DONE on the fake chain, plus the Expected for the final phase."""
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    m.opening()
    exp, plan, info, batches = m._expected("final")
    return m, fake, exp


def checks_for(m, fake, exp, backend=None):
    be = backend or fake
    view = read_chain_view(be, be.height(), m.spec.source_system)
    return compare(exp, view, m.spec.get("reconciliation", "tolerance", default={}), "final")


def failing(cs):
    return {c["name"] for c in cs if c["status"] == FAIL}


# ------------------------------------------------------------------ the arithmetic of one check
def test_check_delta_and_tolerance():
    assert _chk("c", 10, 10)["status"] == PASS and _chk("c", 10, 10)["delta"] == 0
    c = _chk("c", 10, 13)
    assert c["status"] == FAIL and c["delta"] == 3
    assert _chk("c", 10, 13, tol=3)["status"] == PASS and _chk("c", 10, 14, tol=3)["status"] == FAIL
    assert _chk("c", 10, 7, tol=3)["delta"] == -3 and _chk("c", 10, 7, tol=3)["status"] == PASS
    w_ok, w_bad = _chk("w", "OPEN", "OPEN"), _chk("w", "OPEN", "CLOSED")
    assert w_ok["status"] == PASS and w_bad["status"] == FAIL
    assert (w_ok["source"], w_ok["chain"], w_ok["delta"]) == (1, 1, 0) and (w_bad["source"], w_bad["chain"], w_bad["delta"]) == (1, 0, -1)  # numbers only
    assert "expected 'OPEN', chain 'CLOSED'" in w_bad["detail"]
    assert _chk("b", True, True)["status"] == PASS  # bool is not an integer count


def test_record_diff_reports_missing_extra_and_changed():
    ok = _diff("d", {"a": 1, "b": 2}, {"a": 1, "b": 2})
    assert ok["status"] == PASS and ok["source"] == ok["chain"] == 2
    bad = _diff("d", {"a": 1, "b": 2, "c": 3}, {"a": 1, "b": 9, "z": 0})
    assert bad["status"] == FAIL and bad["source"] == 3 and bad["chain"] == 3 - 3  # c missing, z unexpected, b differs
    assert "missing on chain" in bad["detail"] and "unexpected on chain" in bad["detail"] and "differ" in bad["detail"]


# ------------------------------------------------------------------ a clean import reconciles exactly
def test_clean_import_passes_every_check(ready):
    m, fake, exp = ready
    cs = checks_for(m, fake, exp)
    assert len(cs) > 45 and failing(cs) == set(), failing(cs)
    by = {c["name"]: c for c in cs}
    assert by["product count"]["source"] == by["product count"]["chain"] == len(exp.records["PRODUCT"])
    assert by["historical sales count"]["source"] == by["historical sales count"]["chain"] > 1900
    assert by["loyalty opening points total"]["chain"] == sum(r["points"] for r in exp.records["LOYALTY_OPENING"])
    assert by["outstanding PO value (minor units)"]["source"] == by["outstanding PO value (minor units)"]["chain"] > 0
    assert by["chain counter skus"]["chain"] == by["SKU count"]["chain"]
    assert by["planned batches present on chain (mig/batch)"]["status"] == PASS
    assert {"opening stock total, unit EA", "opening stock total, unit KG", "outstanding PO quantity, unit EA"} <= set(by)


def test_reads_are_pinned_to_one_finalised_height(ready):
    m, fake, exp = ready
    seen = []
    real_scan, real_rec = fake.scan, fake.record

    def scan(prefix, height=None, limit=200):
        seen.append(height)
        return real_scan(prefix, height, limit)

    fake.scan = scan
    h = fake.height()
    view = read_chain_view(fake, h, "legacy-retail-erp")
    assert view.height == h and seen and set(seen) == {h}  # every authoritative scan carries the same height


def test_chain_authoritative_values_come_from_scans_not_from_the_plan(ready):
    """Expected is built from the plan; the chain view from scans.  Make them disagree and the check must notice - proves they are independent."""
    m, fake, exp = ready
    fake.kv["supplier/SUP-001"]["name"] = "Renamed on chain"
    assert "supplier records" in failing(checks_for(m, fake, exp))


# ------------------------------------------------------------------ deliberately corrupted chain state -> FAIL
@pytest.mark.parametrize("name,corrupt,expect", [
    ("deleted sale", lambda kv: kv.pop(next(k for k in kv if k.startswith("sale/"))), {"historical sales count", "historical sale records", "historical sales net total (minor units)"}),
    ("altered sale amount", lambda kv: kv[next(k for k in kv if k.startswith("sale/"))].__setitem__("net_minor", kv[next(k for k in kv if k.startswith("sale/"))]["net_minor"] + 1),
     {"historical sales net total (minor units)", "historical sale records"}),
    ("altered refund", lambda kv: kv[next(k for k in kv if k.startswith("sale/") and kv[k]["refund_confirmed_minor"] > 0)].__setitem__("refund_confirmed_minor", 1),
     {"historical sales refunded total (minor units)", "historical sale records"}),
    ("price changed", lambda kv: kv["price/PRC-0000001"].__setitem__("unit_minor", 4999), {"price records"}),
    ("price removed", lambda kv: kv.pop("price/PRC-0000001"), {"price count", "price records"}),
    ("rogue imported product", lambda kv: kv.__setitem__("product/ROGUE-1", {"id": "ROGUE-1", "name": "x", "skus": [], "status": "ACTIVE", "provenance": {"origin": "IMPORTED", "source_system": "legacy-retail-erp", "source_id": "x", "batch_id": "B-nope"}}),
     {"product count", "product records", "imported records carry provenance of a planned batch"}),
    ("movement quantity changed", lambda kv: kv[next(k for k in kv if k.startswith("mov/SKU-0000"))].__setitem__("qty", 999999), {"stock balance per (sku, location, bucket)", "opening stock total, unit EA"}),
    ("movement removed", lambda kv: kv.pop(next(k for k in kv if k.startswith("mov/KETTLE-RED"))), {"stock balance rows (sku, location, bucket)", "stock balance per (sku, location, bucket)", "opening stock total, unit EA"}),
    ("loyalty entry removed", lambda kv: kv.pop("loye/LE-OPEN-CUST-DEMO01"), {"loyalty opening points total", "loyalty opening balance per customer"}),
    ("po received changed", lambda kv: kv["po/PO-2001"]["lines"][0].__setitem__("received_v", 1), {"outstanding PO quantity, unit EA", "outstanding PO value (minor units)", "open purchase order records"}),
    ("counter tampered", lambda kv: kv["mig/state"]["chain_counters"].__setitem__("products", 1), {"chain counter products"}),
    ("batch record missing", lambda kv: kv.pop(next(k for k in kv if k.startswith("mig/batch/"))), {"planned batches present on chain (mig/batch)", "imported records carry provenance of a planned batch"} - {"imported records carry provenance of a planned batch"}),
    ("window closed early", lambda kv: kv["mig/state"].__setitem__("status", "CLOSED"), {"migration window status"}),
])
def test_corrupted_chain_state_fails_reconciliation(ready, name, corrupt, expect):
    m, fake, exp = ready
    corrupt(fake.kv)
    cs = checks_for(m, fake, exp)
    bad = failing(cs)
    assert expect <= bad, (name, expect - bad, bad)
    assert decide(cs) == "REJECT"


def test_a_corrupted_scan_response_fails_reconciliation(ready):
    """The gateway (or a man in the middle) returns a scan with one record dropped and one altered; reconciliation must not accept it."""
    m, fake, exp = ready

    class Corrupt:
        base = "corrupt://"

        def __init__(self, inner):
            self.i = inner

        def __getattr__(self, n):
            return getattr(self.i, n)

        def scan(self, prefix, height=None, limit=200):
            items = list(self.i.scan(prefix, height, limit))
            if prefix == "sale/":
                items = items[1:]  # a page silently lost
            if prefix == "product/":
                k, v = items[3]
                v = copy.deepcopy(v)
                v["name"] += "!"
                items[3] = (k, v)
            return iter(items)

    cs = checks_for(m, fake, exp, Corrupt(fake))
    assert {"historical sales count", "historical sale records", "product records"} <= failing(cs)
    assert decide(cs) == "REJECT"


def test_failed_reconciliation_withdraws_acceptance_and_blocks_cutover(ready, fake):
    m, fake, exp = ready
    r = m.reconcile("final", ack=ACK)
    assert r["decision"] == "ACCEPT" and m.stage == "RECONCILED"
    fake.kv["price/PRC-0000001"]["unit_minor"] = 1
    r2 = m.reconcile("final")
    assert r2["decision"] == "REJECT" and m.stage == "OPENING_DONE"  # acceptance withdrawn
    assert any(c["name"] == "price records" and c["status"] == "FAIL" for c in r2["report"]["checks"])
    from aureom_migration.util import MigrationError

    with pytest.raises(MigrationError, match="not allowed"):
        m.cutover()


def test_reports_carry_the_documented_shape(ready):
    m, fake, exp = ready
    rep = m.reconcile("final", ack=ACK)["report"]
    for k in ("id", "phase", "trial", "network_id", "generated_at", "snapshot_id", "snapshot_sha256", "mapping_version", "source_system", "authoritative_system", "checks",
              "exceptions", "unsupported_fields", "batches", "decision", "notes"):
        assert k in rep, k
    assert rep["phase"] == "final" and rep["trial"] is False and rep["authoritative_system"] == "FROZEN" and rep["decision"] == "ACCEPT"
    assert set(rep["checks"][0]) >= {"name", "source", "chain", "delta", "status", "detail"} and {c["status"] for c in rep["checks"]} <= {"PASS", "FAIL", "WARN"}
    assert all(isinstance(c["source"], int) and isinstance(c["chain"], int) and isinstance(c["delta"], int) for c in rep["checks"])  # contract: numeric
    assert set(rep["exceptions"][0]) >= {"kind", "source_ref", "detail", "disposition"} and {e["disposition"] for e in rep["exceptions"]} <= {"EXCLUDED", "FIXED", "PRESERVED_AS_EXTRAS", "MANUAL"}
    assert set(rep["unsupported_fields"][0]) >= {"table", "column", "rows", "treatment"}
    assert set(rep["batches"][0]) >= {"batch_id", "entity", "seq", "records", "tx_id", "height", "status"} and {b["status"] for b in rep["batches"]} == {"FINALISED"}
    assert rep["snapshot_id"] == m.state["final_snapshot"]["snapshot_id"] and rep["snapshot_sha256"] == m.state["final_snapshot"]["sha256"]
    json.dumps(rep)  # serialisable
    md = (m.workdir / "reports" / f"{rep['id']}.md").read_text()
    assert "Decision: ACCEPT" in md and "Unsupported source fields" in md and rep["id"] in md


def test_the_report_hash_posted_to_the_gateway_is_what_cutover_attests(ready, fake):
    m, fake, exp = ready
    m.reconcile("final", ack=ACK)
    posted = fake.reports[-1]
    import hashlib
    from aureom_migration.report import report_bytes

    assert m.state["final_report"]["hash"] == hashlib.sha256(report_bytes(posted)).hexdigest()


# ------------------------------------------------------------------ data-quality gates in the decision
def test_excluded_share_threshold_rejects(master_plan, spec):
    import yaml
    from aureom_migration.mapping import load_spec
    import tempfile, pathlib

    raw = yaml.safe_load(open(spec.path))
    raw["reconciliation"]["max_excluded_ratio"]["HISTORICAL_SALE"] = 0.001
    p = pathlib.Path(tempfile.mkdtemp()) / "m.yaml"
    p.write_text(yaml.safe_dump(raw))
    strict = load_spec(p)
    cs = quality_checks(master_plan, strict, "final", ACK)
    assert any(c["name"] == "excluded share: HISTORICAL_SALE" and c["status"] == "FAIL" for c in cs) and decide(cs) == "REJECT"
    assert decide(quality_checks(master_plan, spec, "final", ACK)) == "ACCEPT"


def test_manual_exceptions_warn_before_final_and_block_at_final(master_plan, spec):
    warn = [c for c in quality_checks(master_plan, spec, "master", None) if c["name"] == "unresolved MANUAL exceptions"][0]
    assert warn["status"] == "WARN" and warn["chain"] > 10
    block = [c for c in quality_checks(master_plan, spec, "final", None) if c["name"] == "unresolved MANUAL exceptions"][0]
    assert block["status"] == "FAIL"
    ok = [c for c in quality_checks(master_plan, spec, "final", ACK) if c["name"] == "unresolved MANUAL exceptions"][0]
    assert ok["status"] == "PASS"
    some = [c for c in quality_checks(master_plan, spec, "final", {"ids": [master_plan.exceptions.manual()[0].id], "by": "x"}) if c["name"] == "unresolved MANUAL exceptions"][0]
    assert some["status"] == "FAIL" and some["chain"] == len(master_plan.exceptions.manual()) - 1


def test_master_phase_report_only_checks_master_entities(master_plan, spec):
    names = [c["name"] for c in quality_checks(master_plan, spec, "master", None, master_only=True)]
    assert "exception accounting closes: HISTORICAL_SALE" in names and "exception accounting closes: OPENING_BALANCE" not in names
