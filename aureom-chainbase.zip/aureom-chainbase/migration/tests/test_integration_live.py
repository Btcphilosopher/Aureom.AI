"""LIVE integration: a full trial migration against a real (throwaway) gateway + chain.

Skipped unless GATEWAY_URL is set.  The target network must be FRESH (migration window NOT_STARTED) and a throwaway: the test opens and
CLOSES the window.  Example:

    cd $ROOT && export RUN_DIR=$ROOT/run-trial NETWORK_ID=aureom-trial-1 BASE_PORT=28700 GATEWAY_ADDR=127.0.0.1:8092
    scripts/localnet.sh start && scripts/localnet.sh gateway start
    GATEWAY_URL=http://127.0.0.1:8092 NETWORK_ID=aureom-trial-1 KEYS_DIR=$RUN_DIR/net/keys pytest migration/tests/test_integration_live.py
    scripts/localnet.sh stop
"""

import os
import shutil

import pytest

from aureom_migration.chainclient import GatewayBackend
from aureom_migration.mapping import load_spec
from aureom_migration.trial import run_trial

GATEWAY = os.environ.get("GATEWAY_URL")
pytestmark = pytest.mark.skipif(not GATEWAY, reason="set GATEWAY_URL (+ NETWORK_ID, KEYS_DIR) to run the live trial migration")


def test_live_trial_migration_end_to_end(synth_db, tmp_path):
    network = os.environ.get("NETWORK_ID", "aureom-trial-1")
    keys = os.environ.get("KEYS_DIR") or os.path.join(os.environ["RUN_DIR"], "net", "keys")
    be = GatewayBackend(GATEWAY)
    if (be.migration_state() or {}).get("status") != "NOT_STARTED":
        pytest.skip("the target network's migration window is not NOT_STARTED: start a fresh throwaway network")
    res = run_trial(source_db=synth_db, workdir=tmp_path / "trial", spec=load_spec(), backend=be, network_id=network, keys_dir=keys,
                    allow_any_network=bool(os.environ.get("ALLOW_ANY_NETWORK_ID")), log=lambda m: None)
    assert res["decision"] == "ACCEPT"
    assert res["status"]["stage"] == "CUTOVER_DONE" and res["status"]["authoritative_system"] == "CHAIN" and res["status"]["consistency"] == "CONSISTENT"
    ms = be.migration_state()
    assert ms["status"] == "CLOSED" and ms["attested_totals"] == ms["chain_counters"] and ms["reconciliation_report_hash"] and ms["source_freeze_marker"]
    # the demo ids land exactly where the end-to-end demo expects them
    found, bal = be.record("bal/KETTLE-RED/STORE-N-01")
    assert found and bal["available"] == 2 and bal["reserved"] == 0
    found, sku = be.record("sku/KETTLE-RED")
    assert found and sku["unit"] == "EA" and sku["scarce"] is True and sku["provenance"]["origin"] == "IMPORTED"
    found, po = be.record("po/PO-2001")
    assert found and po["status"] == "APPROVED" and po["location_id"] == "STORE-N-01" and po["lines"][0]["unit_cost_minor"] == 1800 and po["lines"][0]["received_v"] == 0
    found, book = be.record("pbook/KETTLE-RED/*")
    assert found and book["entries"][0]["unit_minor"] == 3999
    found, loy = be.record("loy/CUST-DEMO01")
    assert found and loy["points"] == 120
    for pid in ("PRM-PROMO-001", "PRM-PROMO-002", "PRM-PROMO-005"):
        assert be.record(f"promo/{pid}")[0]
    # reports reached the gateway's report store
    ids = {r["id"] for r in be.list_reports()}
    assert res["steps"]["trial_report"]["id"] in ids
    shutil.rmtree(tmp_path / "trial", ignore_errors=True)
