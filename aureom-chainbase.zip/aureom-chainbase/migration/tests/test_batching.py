"""Deterministic batching: identical plans give identical batches and ids; sizes respect the chain limits."""

import hashlib
import json

import pytest

from aureom_migration.batching import (CHAIN_MAX_IMPORT_TX_BYTES, CHAIN_MAX_RECORDS, batch_id, estimate_envelope_bytes, make_batches, manifest, manifest_hash)
from aureom_migration.util import MigrationError


def mk(plan, entity, snap="snap-test", ver="map-v1", **kw):
    kw.setdefault("max_records", 400)
    kw.setdefault("max_envelope_bytes", 600 * 1024)
    return make_batches(entity, plan.records[entity], snapshot_id=snap, mapping_version=ver, source_system="legacy-retail-erp", **kw)


def test_batch_id_is_the_documented_hash():
    h = hashlib.sha256(b"snap-1|map-v1|PRODUCT|3").hexdigest()[:40]
    assert batch_id("snap-1", "map-v1", "PRODUCT", 3) == "B-" + h
    ids = {batch_id(s, m, e, q) for s in ("a", "b") for m in ("v1", "v2") for e in ("PRODUCT", "PRICE") for q in (1, 2)}
    assert len(ids) == 16  # every component matters


def test_batches_are_deterministic_and_ordered(master_plan):
    a, b = mk(master_plan, "HISTORICAL_SALE"), mk(master_plan, "HISTORICAL_SALE")
    assert [x.batch_id for x in a] == [x.batch_id for x in b]
    assert [json.dumps(x.payload(), sort_keys=True) for x in a] == [json.dumps(x.payload(), sort_keys=True) for x in b]
    flat = [r["source_id"] for x in a for r in x.records]
    assert flat == sorted(flat) == [r["source_id"] for r in master_plan.records["HISTORICAL_SALE"]]  # sorted by source id, nothing lost, nothing duplicated
    assert [x.seq for x in a] == list(range(1, len(a) + 1))
    assert manifest_hash(a) == manifest_hash(b) and manifest(a)[0]["records"] == len(a[0].records)


def test_changing_snapshot_or_mapping_changes_every_batch_id(master_plan):
    base = {b.batch_id for b in mk(master_plan, "PRODUCT")}
    assert not base & {b.batch_id for b in mk(master_plan, "PRODUCT", snap="snap-other")}
    assert not base & {b.batch_id for b in mk(master_plan, "PRODUCT", ver="map-v2")}
    assert all(i.startswith("B-") and len(i) == 42 for i in base)


def test_record_limit_is_respected(master_plan):
    n = len(master_plan.records["OPENING_BALANCE"])
    bs = mk(master_plan, "OPENING_BALANCE")
    assert all(len(b.records) <= CHAIN_MAX_RECORDS for b in bs) and sum(len(b.records) for b in bs) == n and len(bs) == -(-n // 400)
    small = mk(master_plan, "OPENING_BALANCE", max_records=100)
    assert all(len(b.records) <= 100 for b in small) and len(small) == -(-n // 100)
    with pytest.raises(MigrationError):
        mk(master_plan, "OPENING_BALANCE", max_records=401)
    with pytest.raises(MigrationError):
        mk(master_plan, "OPENING_BALANCE", max_envelope_bytes=CHAIN_MAX_IMPORT_TX_BYTES + 1)


def test_size_limit_is_respected_by_the_real_signed_envelope(master_plan, chain_client):
    limit = 150 * 1024
    bs = mk(master_plan, "HISTORICAL_SALE", max_envelope_bytes=limit)
    assert len(bs) > len(mk(master_plan, "HISTORICAL_SALE"))
    for b in bs:
        wire = chain_client.build_wire("migration-op", "ImportBatch", b.payload(), tx_id="tx-size-" + b.batch_id[2:12], idempotency_ref="imp-" + b.batch_id)
        assert len(wire) <= estimate_envelope_bytes(len(json.dumps(b.payload(), separators=(",", ":"), ensure_ascii=False).encode())) <= limit  # the estimate is conservative
        assert len(wire) <= CHAIN_MAX_IMPORT_TX_BYTES


def test_a_single_oversized_record_is_refused(master_plan):
    with pytest.raises(MigrationError, match="larger than the batch envelope limit"):
        mk(master_plan, "PRODUCT", max_envelope_bytes=2048)


def test_empty_entity_yields_no_batches(master_plan):
    assert make_batches("PRICE", [], snapshot_id="s", mapping_version="m", source_system="x") == []


def test_payload_matches_the_chain_struct(master_plan):
    b = mk(master_plan, "SUPPLIER")[0].payload()
    assert list(b) == ["batch_id", "source_system", "snapshot_id", "mapping_version", "entity", "seq", "records"]
    assert b["entity"] == "SUPPLIER" and b["source_system"] == "legacy-retail-erp"
