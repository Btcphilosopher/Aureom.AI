"""Conversion edge cases: money, quantities, timestamps, ids, text."""

import random
from decimal import Decimal

import pytest

from aureom_migration.convert import (ConversionError, ascii_label, div_half_even, iso_utc, line_amount, map_customer_id, normalise_timestamp,
                                      normalise_unit, sanitize_id, to_minor, to_qty, CHAIN_ID_RE, CHAIN_LABEL_RE)


# ------------------------------------------------------------------ money
def test_money_exact_and_float_noise_is_benign():
    assert to_minor(19.99).value == 1999 and not to_minor(19.99).rounded
    s = to_minor(12.349999999999998)  # binary float noise of 12.35
    assert s.value == 1235 and s.rounded and s.artifact and not s.genuine_rounding
    assert to_minor(0.1 + 0.2).value == 30  # 0.30000000000000004


def test_money_genuine_subpenny_precision_is_flagged_and_half_even():
    for raw, minor in ((4.995, 500), (2.675, 268), (0.125, 12), (0.135, 14), (1.005, 100)):
        s = to_minor(raw)
        assert s.value == minor and s.genuine_rounding, raw  # half-even on the shortest decimal repr: 0.125 -> 12, 0.135 -> 14, 1.005 -> 100


def test_money_no_float_drift_across_a_large_range():
    rng = random.Random(1)
    for _ in range(20000):
        cents = rng.randint(0, 10_000_000)
        assert to_minor(cents / 100).value == cents


def test_money_other_inputs_and_currencies():
    assert to_minor("£1,234.50").value == 123450
    assert to_minor(Decimal("7.10")).value == 710
    assert to_minor(5).value == 500
    assert to_minor(1500, "JPY").value == 1500  # exponent 0
    assert isinstance(to_minor(1.5).value, int)


@pytest.mark.parametrize("bad", [None, True, float("nan"), float("inf"), "abc", -0.01, 1e13, ""])
def test_money_rejects_unusable_values(bad):
    with pytest.raises(ConversionError):
        to_minor(bad)


def test_money_negative_allowed_only_when_asked():
    assert to_minor(-1.25, allow_negative=True).value == -125
    with pytest.raises(ConversionError):
        to_minor(1, "XYZ")


def test_line_amount_matches_the_chain_half_even_rule():
    assert div_half_even(5, 2) == 2 and div_half_even(7, 2) == 4 and div_half_even(-5, 2) == -2 and div_half_even(3, 2) == 2
    assert line_amount(1299, 1500, "KG") == 1948  # 1.5 kg x 12.99 = 19.485 -> 19.48 (1948.5 half-even)
    assert line_amount(1000, 3, "EA") == 3000
    assert line_amount(999, 250, "L") == 250  # 0.25 l x 9.99 = 2.4975 -> 2.50 ... 249.75 -> 250


# ------------------------------------------------------------------ quantities
def test_quantity_units_and_scales():
    assert to_qty(0.75, "KG").v == 750 and to_qty(2.5, "L").v == 2500 and to_qty(1.2, "M").v == 1200 and to_qty(3.0, "EA").v == 3
    assert to_qty(2.0, "PK").v == 2 and not to_qty(2.0, "EA").rounded


def test_fractional_whole_units_are_flagged_and_rounded_half_even():
    q = to_qty(3.5, "EA")
    assert q.fractional_whole_unit and q.v == 4
    assert to_qty(2.5, "EA").v == 2 and to_qty(1.5, "EA").fractional_whole_unit
    assert not to_qty(0.7501, "KG").fractional_whole_unit and to_qty(0.7501, "KG").genuine_rounding  # sub-gram precision is rounding, not fractional-each


def test_quantity_rejects_garbage_and_overflow():
    with pytest.raises(ConversionError):
        to_qty("lots", "EA")
    with pytest.raises(ConversionError):
        to_qty(-1, "EA")
    with pytest.raises(ConversionError):
        to_qty(1, "BARREL")
    assert to_qty(-3, "EA", allow_negative=True).v == -3


def test_unit_synonyms():
    assert [normalise_unit(u) for u in ("EA", "each", "PCS", " ea ", "Ltr", "kgs", "metre", "pack")] == ["EA", "EA", "EA", "EA", "L", "KG", "M", "PK"]
    assert normalise_unit(None) is None and normalise_unit("") is None
    with pytest.raises(ConversionError):
        normalise_unit("BARREL")


# ------------------------------------------------------------------ timestamps
def ms(s):
    return normalise_timestamp(s).ms


def test_all_supported_formats_agree_on_one_instant():
    ref = ms("2025-07-01T11:00:00Z")
    assert ref == 1751367600000
    for s in ("2025-07-01T12:00:00+01:00", "2025-07-01 12:00:00", "2025-07-01T12:00:00+0100", "01/07/2025 12:00", "2025-07-01 12:00", "2025-07-01T10:00:00-01:00",
              "1751367600", "1751367600000"):
        assert ms(s) == ref, s


def test_london_wall_time_follows_dst():
    assert iso_utc(ms("2025-01-15 09:00:00")) == "2025-01-15T09:00:00.000Z"  # GMT
    assert iso_utc(ms("2025-07-15 09:00:00")) == "2025-07-15T08:00:00.000Z"  # BST


def test_uk_day_first_not_us_month_first():
    assert iso_utc(ms("03/04/2025 10:00")) == "2025-04-03T09:00:00.000Z"
    with pytest.raises(ConversionError):
        normalise_timestamp("31/13/2025 09:00")  # no month 13 either way


def test_dst_fold_and_gap_are_flagged():
    fold = normalise_timestamp("2025-10-26 01:30:00")
    assert fold.dst_ambiguous and not fold.dst_gap and iso_utc(fold.ms) == "2025-10-26T00:30:00.000Z"  # first occurrence (BST)
    gap = normalise_timestamp("2025-03-30 01:30:00")
    assert gap.dst_gap and not gap.dst_ambiguous
    assert not normalise_timestamp("2025-06-01 01:30:00").dst_ambiguous
    assert not normalise_timestamp("2025-06-01T01:30:00Z").dst_ambiguous  # explicit offset: nothing assumed


def test_assumed_zone_and_format_flags():
    assert normalise_timestamp("2025-01-01 10:00:00").tz_assumed and not normalise_timestamp("2025-01-01T10:00:00Z").tz_assumed
    assert normalise_timestamp("2025-01-01").fmt == "date-only" and normalise_timestamp("1751367600").fmt == "epoch-s"


@pytest.mark.parametrize("bad", ["2025-02-30 10:15:00", "not-a-date", "", None, "2025-13-01", "12345", "1999-12-31 23:59:59", "2101-01-01 00:00:00", True])
def test_invalid_timestamps(bad):
    with pytest.raises(ConversionError) as e:
        normalise_timestamp(bad)
    assert e.value.kind == "INVALID_TIMESTAMP"


def test_integer_types_from_sqlite_epoch_columns():
    assert ms(1751367600) == 1751367600000 and ms(1751367600000) == 1751367600000


# ------------------------------------------------------------------ ids / text
def test_sanitize_id_and_chain_regex():
    assert sanitize_id(" sku-00210 ", upper=True) == "SKU-00210" == sanitize_id("SKU-00210")
    assert sanitize_id("Café Mug #3") == "Cafe-Mug-3"
    assert sanitize_id("--weird") == "weird" and sanitize_id("###") == "" and sanitize_id(None) == ""
    assert len(sanitize_id("x" * 200)) == 64
    assert all(CHAIN_ID_RE.match(sanitize_id(s)) for s in ("A/B/C", "p.q:r-s", "  lead", "9lives"))


def test_ascii_label():
    assert ascii_label("Café Latté Mug 350ml", 120) == ("Cafe Latte Mug 350ml", True)
    assert ascii_label("£ Saver Gift Card", 120)[0] == "GBP Saver Gift Card"
    assert ascii_label("plain", 120) == ("plain", False)
    assert ascii_label("x" * 300, 120)[0] == "x" * 120
    assert ascii_label("中文", 50)[0] == "??"
    assert CHAIN_LABEL_RE.match(ascii_label("Müller & Söhne — Ltd™", 120)[0])
    assert ascii_label(None, 10, default="n/a") == ("n/a", False)


def test_customer_id_mapping_is_synthetic_and_stable():
    assert map_customer_id("CUST-000123") == ("CUST-000123", "as-is") and map_customer_id("CUST-DEMO01") == ("CUST-DEMO01", "as-is")
    assert map_customer_id("C0701") == ("CUST-000701", "zero-padded") and map_customer_id("cust_000702") == ("CUST-000702", "zero-padded")
    a = map_customer_id("LEGACY-9001")
    assert a[1] == "pseudonymised" and a[0].startswith("PSN-") and a == map_customer_id("LEGACY-9001") and a != map_customer_id("LEGACY-9002")
    assert map_customer_id("LEGACY-9001", salt="other")[0] != a[0]
    with pytest.raises(ConversionError):
        map_customer_id("")
