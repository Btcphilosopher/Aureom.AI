"""The cutover procedure: state machine, single authoritative system, write-freeze, resume, retry safety, abort."""

import json
import sqlite3
from pathlib import Path

import pytest

from aureom_migration.chainclient import TransportError
from aureom_migration.cutover import AUTH_BY_STAGE, STAGES, TRANSITIONS, derive_authority, next_stage
from aureom_migration.snapshot import SourceControl
from aureom_migration.synth import simulate_activity
from aureom_migration.util import MigrationError

ACK = {"all": True, "by": "test-operator", "reason": "unit test", "at": "2026-11-12T00:00:00Z"}


# ------------------------------------------------------------------ pure state machine
def test_transition_table_is_a_line_with_an_abort_exit():
    path = ["SOURCE_LIVE"]
    for cmd in ("master", "freeze", "opening", "reconcile-final", "cutover"):
        path.append(next_stage(cmd, path[-1]))
    assert path == ["SOURCE_LIVE", "MASTER_DONE", "FROZEN", "OPENING_DONE", "RECONCILED", "CUTOVER_DONE"]
    for s in ("SOURCE_LIVE", "MASTER_DONE", "FROZEN", "OPENING_DONE", "RECONCILED"):
        assert next_stage("abort", s) == "ABORTED"
    for s in ("CUTOVER_DONE", "ABORTED"):  # no way back after cutover: corrections are compensating transactions only
        with pytest.raises(MigrationError):
            next_stage("abort", s)


@pytest.mark.parametrize("cmd,stage", [("freeze", "SOURCE_LIVE"), ("opening", "MASTER_DONE"), ("cutover", "OPENING_DONE"), ("cutover", "FROZEN"), ("master", "FROZEN"),
                                       ("master", "CUTOVER_DONE"), ("opening", "SOURCE_LIVE"), ("reconcile-final", "MASTER_DONE"), ("master", "ABORTED")])
def test_illegal_transitions_are_refused(cmd, stage):
    with pytest.raises(MigrationError, match="not allowed"):
        next_stage(cmd, stage)


def test_resumable_commands_are_idempotent_in_place():
    assert next_stage("master", "MASTER_DONE") == "MASTER_DONE" and next_stage("freeze", "FROZEN") == "FROZEN" and next_stage("opening", "OPENING_DONE") == "OPENING_DONE"
    assert set(AUTH_BY_STAGE) == set(STAGES)


def test_exactly_one_authoritative_system_at_every_stage():
    assert AUTH_BY_STAGE == {"SOURCE_LIVE": "SOURCE", "MASTER_DONE": "SOURCE", "FROZEN": "FROZEN", "OPENING_DONE": "FROZEN", "RECONCILED": "FROZEN", "CUTOVER_DONE": "CHAIN", "ABORTED": "SOURCE"}
    # source and chain control records agree -> a single answer
    assert derive_authority("SOURCE", 0, 0, "NOT_STARTED") == ("SOURCE", "CONSISTENT")
    assert derive_authority("SOURCE", 0, 0, "OPEN") == ("SOURCE", "CONSISTENT")
    assert derive_authority("NONE_FROZEN", 1, 0, "OPEN") == ("FROZEN", "CONSISTENT")
    assert derive_authority("CHAIN", 1, 1, "CLOSED") == ("CHAIN", "CONSISTENT")
    assert "CUTOVER IN PROGRESS" in derive_authority("NONE_FROZEN", 1, 0, "CLOSED")[1]
    # two writers / no writer are flagged as inconsistent
    assert derive_authority("SOURCE", 0, 0, "CLOSED")[1].startswith("INCONSISTENT")  # chain closed but source still writable: two authoritative systems
    assert derive_authority("CHAIN", 1, 1, "OPEN")[1].startswith("INCONSISTENT")
    assert derive_authority("NONE_FROZEN", 1, 0, "NOT_STARTED")[1].startswith("INCONSISTENT")
    assert derive_authority("SOURCE", 1, 0, "OPEN")[0] == "UNKNOWN"


# ------------------------------------------------------------------ source freeze is ENFORCED
def test_freeze_blocks_writes_and_unfreeze_restores_them(source_copy):
    src = SourceControl(source_copy)
    assert src.state()["authoritative_system"] == "SOURCE" and not src.verify_write_freeze()  # while live the canary write is NOT refused
    m = src.freeze()
    assert src.state()["authoritative_system"] == "NONE_FROZEN" and src.state()["frozen"] == 1 and len(m["freeze_marker"]) == 64
    con = sqlite3.connect(source_copy)
    for sql in ("INSERT INTO categories VALUES (99, 'x', NULL)", "UPDATE sales SET channel='POS' WHERE sale_id=1", "DELETE FROM sale_lines WHERE line_id=1",
                "UPDATE inventory_balances SET on_hand=0", "UPDATE loyalty_accounts SET points_balance=0", "INSERT INTO payments(sale_id, amount, status) VALUES (1, 1, 'CAPTURED')"):
        with pytest.raises(sqlite3.DatabaseError, match="SOURCE FROZEN"):
            con.execute(sql)
    con.close()
    assert src.verify_write_freeze()
    with pytest.raises(MigrationError, match="cannot freeze"):
        src.freeze()  # not twice
    src.unfreeze()
    con = sqlite3.connect(source_copy)
    con.execute("UPDATE categories SET name = name WHERE category_id = 1")  # writes work again
    con.commit()
    assert src.state()["authoritative_system"] == "SOURCE" and src.state()["freeze_marker"] is None


def test_freeze_marker_tracks_the_change_log(source_copy):
    src = SourceControl(source_copy)
    m0 = src.marker()
    con = sqlite3.connect(source_copy)
    con.execute("UPDATE categories SET name = name || '!' WHERE category_id = 1")
    con.commit()
    con.close()
    m1 = src.marker()
    assert m1["high_water"] == m0["high_water"] + 1 and m1["freeze_marker"] != m0["freeze_marker"]
    assert src.change_log_since(m0["high_water"])[0][1:] == ("categories", "1", "U")


def test_archive_requires_a_frozen_source(source_copy):
    src = SourceControl(source_copy)
    with pytest.raises(MigrationError, match="not frozen"):
        src.archive()
    src.freeze()
    src.archive()
    st = src.state()
    assert (st["authoritative_system"], st["frozen"], st["archived"]) == ("CHAIN", 1, 1)
    with pytest.raises(MigrationError, match="already archived"):
        src.unfreeze()


# ------------------------------------------------------------------ full procedure against the fake chain
def drive_to(m, stage, activity_db=None):
    steps = ["master", "freeze", "opening", "reconcile", "cutover"]
    for i, s in enumerate(steps):
        if s == "master":
            m.master()
        elif s == "freeze":
            if activity_db:
                simulate_activity(activity_db, 7)
            m.freeze()
        elif s == "opening":
            m.opening()
        elif s == "reconcile":
            m.reconcile("final", ack=ACK)
        elif s == "cutover":
            m.cutover()
        if m.stage == stage:
            return


def test_full_procedure_with_one_authoritative_system_throughout(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    seen = []

    def auth():
        s = m.status()
        seen.append((s["stage"], s["authoritative_system"], s["consistency"], s["chain_window"]))

    auth()
    m.master()
    auth()
    assert fake.migration_state()["status"] == "OPEN" and m.stage == "MASTER_DONE"
    assert SourceControl(source_copy).state()["authoritative_system"] == "SOURCE"  # still the live system while master data is imported
    r = m.reconcile("master")
    assert r["decision"] == "ACCEPT" and m.stage == "MASTER_DONE"
    m.freeze()
    auth()
    st = SourceControl(source_copy).state()
    assert (st["authoritative_system"], st["frozen"]) == ("NONE_FROZEN", 1)
    m.opening()
    auth()
    rep = m.reconcile("final", ack=ACK)
    assert rep["decision"] == "ACCEPT" and m.stage == "RECONCILED"
    auth()
    out = m.cutover()
    auth()
    assert out["post_cutover_decision"] == "ACCEPT" and m.stage == "CUTOVER_DONE"
    ms = fake.migration_state()
    assert ms["status"] == "CLOSED" and ms["reconciliation_report_hash"] == m.state["final_report"]["hash"] and ms["source_freeze_marker"] == m.state["freeze_marker"]
    assert ms["attested_totals"] == ms["chain_counters"] and len(ms["attested_totals"]) >= 15  # attested totals equal the chain's own counters
    assert SourceControl(source_copy).state()["authoritative_system"] == "CHAIN" and SourceControl(source_copy).state()["archived"] == 1
    # the single authoritative system at every observed moment
    assert [(s, a) for s, a, c, w in seen] == [("SOURCE_LIVE", "SOURCE"), ("MASTER_DONE", "SOURCE"), ("FROZEN", "FROZEN"), ("OPENING_DONE", "FROZEN"), ("RECONCILED", "FROZEN"), ("CUTOVER_DONE", "CHAIN")]
    assert all(c == "CONSISTENT" for s, a, c, w in seen), seen
    assert [w for s, a, c, w in seen] == ["NOT_STARTED", "OPEN", "OPEN", "OPEN", "OPEN", "CLOSED"]
    # everything is signed by the right identities and every batch executed exactly once
    assert len(fake.executed_batches) == len(set(fake.executed_batches)) >= 14
    types = {(v["type"], v["signer"]) for k, v in fake.kv.items() if k.startswith("tx/")}
    assert types == {("MigrationControl", "migration-op"), ("ImportBatch", "migration-op"), ("ActivatePromotion", "pricing-mgr")}
    # reports: one per reconcile, posted to the gateway store, phases as documented
    assert [r["phase"] for r in fake.reports] == ["master", "final", "final"]  # the post-cutover verification is a FINAL report with authoritative_system CHAIN
    assert [r["verification"] for r in fake.reports] == ["master", "final", "post-cutover"] and "postcutover" in fake.reports[-1]["id"]
    assert all(r["decision"] == "ACCEPT" for r in fake.reports) and fake.reports[-1]["authoritative_system"] == "CHAIN" and fake.reports[1]["authoritative_system"] == "FROZEN"


def test_cutover_is_idempotent_and_the_procedure_cannot_restart(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    drive_to(m, "CUTOVER_DONE")
    assert m.cutover()["status"] == "already cut over"
    for fn in (m.master, m.freeze, m.opening):
        with pytest.raises(MigrationError, match="not allowed"):
            fn()
    with pytest.raises(MigrationError, match="not allowed"):
        m.abort("too late")
    assert fake.migration_state()["status"] == "CLOSED"


def test_cutover_refused_without_an_accepted_final_report(source_copy, make_migration):
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    m.opening()
    with pytest.raises(MigrationError, match="not allowed"):
        m.cutover()  # OPENING_DONE, no reconcile yet
    # unresolved MANUAL exceptions block acceptance until acknowledged
    r = m.reconcile("final")
    assert r["decision"] == "REJECT" and m.stage == "OPENING_DONE"
    assert any(c["name"] == "unresolved MANUAL exceptions" and c["status"] == "FAIL" for c in r["report"]["checks"])
    with pytest.raises(MigrationError, match="not allowed"):
        m.cutover()
    r = m.reconcile("final", ack=ACK)
    assert r["decision"] == "ACCEPT" and m.stage == "RECONCILED" and r["report"]["manual_acknowledgement"]["by"] == "test-operator"


def test_cutover_refused_if_the_source_changed_after_the_freeze(source_copy, make_migration):
    m = make_migration(source_copy)
    drive_to(m, "RECONCILED")
    assert m.stage == "RECONCILED"
    con = sqlite3.connect(source_copy)
    con.execute("INSERT INTO change_log(table_name, pk, op, changed_at) VALUES ('sales', '999999', 'I', 'x')")  # tampering with the audit trail of the frozen source
    con.commit()
    with pytest.raises(MigrationError, match="source changed after the freeze"):
        m.cutover()


def test_opening_refuses_a_source_that_moved_since_the_freeze(source_copy, make_migration):
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    con = sqlite3.connect(source_copy)
    con.execute("INSERT INTO change_log(table_name, pk, op, changed_at) VALUES ('sales', '999999', 'I', 'x')")
    con.commit()
    with pytest.raises(MigrationError, match="change log moved"):
        m.opening()


def test_cutover_refused_if_the_chain_was_touched_after_the_report(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    drive_to(m, "RECONCILED")
    fake.kv["price/PRC-0000001"]["unit_minor"] = 1  # somebody altered the chain after the report
    with pytest.raises(MigrationError, match="no longer matches the accepted report"):
        m.cutover()
    assert fake.migration_state()["status"] == "OPEN"


def test_unfreeze_rolls_back_the_freeze_before_opening_and_the_migration_resumes(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    first_marker = m.state["freeze_marker"]
    assert m.unfreeze() == {"stage": "MASTER_DONE"}
    st = SourceControl(source_copy).state()
    assert (st["authoritative_system"], st["frozen"]) == ("SOURCE", 0) and m.state["final_snapshot"] is None
    assert m.status()["authoritative_system"] == "SOURCE" and m.status()["consistency"] == "CONSISTENT"
    simulate_activity(source_copy, 11, n_sales=3)  # the source is live again and keeps changing
    m.freeze()
    assert m.state["freeze_marker"] != first_marker  # a new freeze, a new final snapshot
    m.opening()
    assert m.reconcile("final", ack=ACK)["decision"] == "ACCEPT"
    m.cutover()
    assert fake.migration_state()["status"] == "CLOSED"


def test_unfreeze_is_refused_once_opening_data_is_on_chain(source_copy, make_migration):
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    m.opening()
    with pytest.raises(MigrationError, match="not allowed"):
        m.unfreeze()  # stage OPENING_DONE
    m.state["stage"] = "FROZEN"  # even if local state were rolled back, the chain says opening batches exist
    with pytest.raises(MigrationError, match="already on the chain"):
        m.unfreeze()


def test_abort_restores_the_source_as_authoritative(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    m.master()
    m.freeze()
    out = m.abort("trial didn't reconcile")
    assert out["aborted_from"] == "FROZEN" and m.stage == "ABORTED"
    st = SourceControl(source_copy).state()
    assert (st["authoritative_system"], st["frozen"]) == ("SOURCE", 0)
    con = sqlite3.connect(source_copy)
    con.execute("UPDATE categories SET name = name WHERE category_id = 1")  # the source accepts writes again
    con.commit()
    assert m.status()["authoritative_system"] == "SOURCE" and fake.migration_state()["status"] == "OPEN"  # chain window stays open: imported data is orphaned provenance
    with pytest.raises(MigrationError, match="not allowed"):
        m.master()


def test_mapping_change_mid_migration_is_refused(source_copy, make_migration, spec, tmp_path):
    import yaml

    m = make_migration(source_copy)
    m.master()
    raw = yaml.safe_load(open(spec.path))
    raw["conversions"]["tolerance_line_total_minor"] = 5
    p = tmp_path / "changed.yaml"
    p.write_text(yaml.safe_dump(raw))
    from aureom_migration.mapping import load_spec

    m2 = make_migration(source_copy, spec_override=load_spec(p))
    with pytest.raises(MigrationError, match="mapping spec changed"):
        m2.freeze()


def test_wrong_network_work_directory_is_refused(source_copy, make_migration):
    m = make_migration(source_copy)
    m.master()
    m.state["network_id"] = "some-other-network"
    with pytest.raises(MigrationError, match="belongs to network"):
        m.freeze()


# ------------------------------------------------------------------ delta between the master snapshot and the freeze
def test_delta_since_master_is_imported_and_changes_are_reported(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    m.master()
    master_sales = sum(1 for k in fake.kv if k.startswith("sale/"))
    act = simulate_activity(source_copy, 7, n_sales=25)  # live writes between the master import and the freeze
    assert act["new_sales"] == 25 and SourceControl(source_copy).marker()["rows"] > 25
    m.freeze()
    out = m.opening()
    d = out["delta"]
    assert d["new"]["HISTORICAL_SALE"] == 25 and d["new"]["PRODUCT"] == 1 and d["new"]["PRICE"] == 1
    assert d["changed_after_master"] == 2  # product 5 renamed, an old sale refunded
    assert sum(1 for k in fake.kv if k.startswith("sale/")) == master_sales + 25
    rep = m.reconcile("final", ack=ACK)
    assert rep["decision"] == "ACCEPT"
    changed = {e["source_ref"] for e in rep["report"]["exceptions"] if e["kind"] == "CHANGED_AFTER_MASTER"}
    assert "products:5" in changed and len(changed) == 2
    assert all(e["disposition"] == "MANUAL" for e in rep["report"]["exceptions"] if e["kind"] == "CHANGED_AFTER_MASTER")
    # the chain keeps the master-time version (import cannot update); the report says so instead of hiding it
    prod5 = next(v for k, v in fake.kv.items() if k.startswith("product/") and v["provenance"]["source_id"] == "products:5")
    assert not prod5["name"].endswith("(v2)")
    assert any(c["name"] == "exception accounting closes: HISTORICAL_SALE" and c["status"] == "PASS" for c in rep["report"]["checks"])
    assert rep["report"]["delta_since_master"]["new"]["HISTORICAL_SALE"] == 25
    # delta batches carry the FINAL snapshot id, master batches the master snapshot id
    snaps = {b["phase"]: b["snapshot_id"] for b in m.state["batches"]}
    assert snaps["master"] == m.state["master_snapshot"]["snapshot_id"] and snaps["opening-delta"] == snaps["opening"] == m.state["final_snapshot"]["snapshot_id"] != snaps["master"]


# ------------------------------------------------------------------ resume and retry safety
class Boom(Exception):
    pass


def test_resume_after_partial_failure_skips_what_is_on_chain(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    calls = {"n": 0}

    def inject(stage, wire):
        if stage == "before":
            calls["n"] += 1
            if calls["n"] > 6:
                raise TransportError("network down")  # the gateway disappears after a few batches

    fake.inject = inject
    with pytest.raises(MigrationError, match="not finalised after"):
        m.master()
    done = list(fake.executed_batches)
    assert 0 < len(done) < 10 and m.stage == "SOURCE_LIVE"
    assert fake.migration_state()["status"] == "OPEN"
    fake.inject = None
    # a brand-new process (fresh Migration object, same work dir) resumes
    m2 = make_migration(source_copy)
    m2.master()
    assert m2.stage == "MASTER_DONE"
    assert fake.executed_batches[: len(done)] == done and len(fake.executed_batches) == len(set(fake.executed_batches))  # nothing executed twice, nothing re-sent
    assert m2.reconcile("master")["decision"] == "ACCEPT"


def test_a_lost_response_after_execution_does_not_double_execute(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    lost = {"n": 0}

    def inject(stage, wire):
        if stage == "after":
            lost["n"] += 1
            if lost["n"] in (2, 5, 9):
                raise TransportError("response lost after the tx was executed")

    fake.inject = inject
    m.master()
    assert lost["n"] >= 9
    assert len(fake.executed_batches) == len(set(fake.executed_batches))
    assert m.reconcile("master")["decision"] == "ACCEPT"


def test_a_rejected_batch_is_recorded_and_stops_the_run(source_copy, make_migration, fake, synth_db):
    m = make_migration(source_copy)
    fake.kv["supplier/SUP-001"] = {"id": "SUP-001"}  # a colliding record already on chain -> ALREADY_EXISTS inside the batch
    with pytest.raises(MigrationError, match="REJECTED by the chain: ALREADY_EXISTS"):
        m.master()
    rejected = [b for b in m.state["batches"] if b["status"] == "REJECTED"]
    assert len(rejected) == 1 and rejected[0]["entity"] == "SUPPLIER" and "supplier exists" in rejected[0]["log"]
    assert fake.migration_state()["batches"] == 1  # only the LOCATION batch got in; the rejected batch left no trace (all-or-nothing)
    assert fake.kv[f"tx/{rejected[0]['tx_id']}"]["status"] == "REJECTED"


def test_rerunning_master_with_a_different_manifest_is_refused(source_copy, make_migration, fake, tmp_path):
    m = make_migration(source_copy)
    m.master()
    m2 = make_migration(source_copy, workdir=tmp_path / "other-work")  # a different work dir takes its own master snapshot (new content -> new ids)
    con = sqlite3.connect(source_copy)
    con.execute("UPDATE categories SET name = name || ' (renamed)' WHERE category_id = 1")
    con.commit()
    con.close()
    with pytest.raises(MigrationError, match="different master manifest"):
        m2.master()


def test_batch_sizing_is_pinned_after_the_first_import(source_copy, make_migration):
    m = make_migration(source_copy, max_records=100)
    m.master()
    assert m.state["sizing"]["max_records"] == 100
    m2 = make_migration(source_copy, max_records=200)
    with pytest.raises(MigrationError, match="pinned"):
        m2.master()


def test_chain_batch_with_a_different_shape_is_refused(source_copy, make_migration, fake):
    m = make_migration(source_copy)
    m.master()
    bid = next(b["batch_id"] for b in m.state["batches"] if b["entity"] == "PRODUCT")
    fake.kv[f"mig/batch/{bid}"]["records"] += 1
    m2 = make_migration(source_copy)
    m2.state["stage"] = "SOURCE_LIVE"
    with pytest.raises(MigrationError, match="different shape"):
        m2.master()
