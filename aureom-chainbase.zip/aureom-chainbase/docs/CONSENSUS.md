# Consensus: choice, assumptions, finality, failure model

## Choice
**CometBFT v0.38.25** (Tendermint-family BFT consensus) with the business logic as an **ABCI 2.0** application, written in Go.

Why: it is a mature, widely deployed BFT engine for *permissioned* validator sets; it provides authenticated encrypted peer connections, a mempool,
block storage, light-client verification and a clear application interface (ABCI) with documented determinism requirements. It has no mining, no
staking economics and no transaction fees in the way we use it: validators have equal fixed voting power set by governance, and there is no token.
We did **not** invent a consensus algorithm or call a hash-linked log a blockchain.

Documentation verification: the sandbox could not reach `docs.cometbft.com` (DNS blocked). The official repository files were read instead
(from `github.com/cometbft/cometbft`, tag `v0.38.25`): `README.md` ("Supported Versions: v0.38.x — CometBFT v0.38 introduces ABCI 2.0"),
`spec/abci/abci++_basic_concepts.md` and `abci++_app_requirements.md` (the state machine MUST be deterministic; `ProcessProposal`/`PrepareProposal` requirements),
`spec/consensus/consensus.md` (+2/3 prevotes/precommits) and `spec/light-client/README.md` (light-client trust assumptions: Cosmos failure model, +2/3 correct
validators for the trusting period). The Go module versions were checked against `proxy.golang.org` (v0.38.25 released 2026-07-27, patch line of the supported v0.38.x series;
newer majors exist but are not the line the project README lists as supported). `go.mod` pins `github.com/cometbft/cometbft v0.38.25`, `github.com/cosmos/iavl v1.3.6`,
`github.com/cosmos/ics23/go v0.11.0`, `modernc.org/sqlite v1.62.0`.

## Assumptions (what must hold for the guarantees)
* **Failure model:** Byzantine faults with *less than 1/3 of total voting power* faulty (arbitrary behaviour, collusion included). Partially synchronous network (liveness).
* **Safety (no two conflicting finalised blocks)** holds while < 1/3 of voting power is Byzantine — regardless of network delays/partitions.
* **Liveness (new blocks)** needs > 2/3 of voting power online and connected, and eventual message delivery.
* **Quorum arithmetic:** `n >= 3f+1`. The demonstration runs **n = 4 validators of equal power 10 (total 40), f = 1**. A block needs more than 2/3 of 40 = **at least 27 → 3 validators**.
  * 1 validator crashed / partitioned / Byzantine: chain continues, state stays consistent (tested).
  * 2 validators down or a 2|2 partition: **no side has quorum → the chain halts; nothing is finalised and nothing forks**; pending transactions wait in mempools and finalise after quorum returns (tested).
  * ≥ 2 colluding Byzantine validators (≥ 1/3 of power) can break safety (e.g. finalise conflicting histories) — outside the supported failure model. ≥ 2/3 colluding can finalise anything the state machine permits, censor, and approve governance.
* Crypto: ed25519 signatures (validators, node identities, business identities), SHA-256, RFC-6962-style/IAVL Merkle trees, ICS23 proofs.
* Honest-but-faulty *application code*: a deterministic bug in the state machine is "Byzantine at all validators at once". Mitigations: single state-transition function (`core.ExecuteBlock`), replay verification, fuzz/determinism tests, `Commit` panic on hash mismatch, version-gated upgrades that halt instead of diverging.
* Light client: initialised from a trusted root. Ours is the **genesis validator set** (`NewLight`/gateway check that block 1's validator-set hash equals the genesis validators); trusting period set to 10 years in the demo — a deployment must choose a trusting period shorter than the unbonding-equivalent period for its validator-set change policy and keep witnesses independent.

## Finality rule
A block is **final when it is committed**: more than 2/3 of voting power precommitted it. There is no probabilistic confirmation count and no reorganisation under the failure model.
Application consequences:
* `broadcast_tx_sync` / `/tx/submit` returning `admission OK` means *admitted to a mempool* — not final.
* A transaction is **finalised** when it appears in a committed block; its result code says whether it succeeded. A finalised transaction can still be *rejected* (e.g. insufficient stock): the order is final, the state change did not happen.
* Verifying finality independently: `chainctl verify-finality --height H` (or `GET /api/v1/explorer/verify-finality`) uses the CometBFT light client to check that header H is signed by > 2/3 of the (genesis-anchored) validator set.
* State at height H is proven against `app_hash` in header **H+1**.

## Identities, connections, membership
* **Validator identity:** ed25519 consensus key per validator (`priv_validator_key.json`); listed in genesis and in the on-chain member registry (`gov/member/*`). `InitChain` refuses to start if genesis.json validators differ from `app_state` members.
* **Authenticated connections:** CometBFT p2p uses an encrypted, mutually authenticated handshake keyed by each node's node key; the node id (hash of the node public key) is checked against the peer allow-list. `pex=false`, `persistent_peers` only, and `filter_peers=true`: every inbound/outbound peer id is checked by an ABCI query (`/p2p/filter/id/<id>`) against **on-chain membership** (`gov/node/<id>`), so unregistered nodes cannot connect (tested: `TestUnregisteredNodeCannotJoin`).
  A node admitted by governance after it first tried to connect must be (re)started after the activation height (observed in the integration tests: a node that was rejected before admission did not connect after admission until it was restarted) — tested in `TestObserverAdmissionViaGovernance`.
* **Network identifiers & replay protection:** chain id `aureom-retail-demo-1` appears in the genesis, the p2p handshake, and — inside every business transaction — as `network_id` and in the signature preimage; plus per-transaction `tx_id` uniqueness, per-signer `idempotency_ref`, optional `valid_until_height`.
* **Membership / key rotation / validator add & removal:** governance proposals (see `docs/GOVERNANCE.md`).

## Parameters used
`timeout_commit` 1 s (benchmark: see `docs/BENCHMARK.md`), empty blocks enabled (liveness heartbeat; each block also records block time in state), max block 4 MiB, mempool max tx 1 MiB with application limits of 32 KiB per ordinary tx and ~900 KiB for bulk imports, `max_lines` 100, validator updates take effect two blocks after the block that returns them (CometBFT rule).

## What CometBFT does not give us (and what we did about it)
* No state sync snapshots are wired (new nodes block-sync = replay from genesis; offline `chainctl snapshot export/verify` provides verified state snapshots for audit/disaster recovery but nodes do not bootstrap from them).
* Consensus-level evidence of double signing is handled by CometBFT; there is no slashing (no tokens): remedies are governance actions (remove validator).
* Application state pruning is not enabled: full history is retained (needed for time-travel queries and proofs at old heights).
