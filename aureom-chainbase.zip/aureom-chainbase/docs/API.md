# Gateway API (contract)

`gateway` is a stateless-ish HTTP service in front of the validators. It has two clearly separated halves:

* **Authoritative chain reads / submission** (`/api/v1/chain/*`, `/api/v1/tx/*`, `/api/v1/explorer/*`): forwarded to validators over CometBFT RPC. Reads come from the validator's committed state (ABCI query), can be pinned to a finalised `height`, and can be returned with an ICS23 Merkle proof checked against a **light-client-verified** header.
* **Disposable query projection** (`/api/v1/q/*`, `/api/v1/projection/*`): a SQLite database built purely from finalised blocks. It can be deleted and rebuilt at any time. Every projection response carries `meta` with `indexed_height`, `chain_head`, `lag_blocks` so callers can see staleness. Add `?min_height=H&wait_ms=5000` to any projection GET for read-after-write (blocks until `indexed_height >= H`).

All responses are JSON. Errors: HTTP 4xx/5xx with `{"error": "...", "code": "..."}`. CORS is open for the demo. Base URL in the local demo: `http://127.0.0.1:8080`.

Projection list responses have the shape `{"meta": {...}, "items": [...], "total": N}`; single-record responses `{"meta": {...}, "item": {...}}`. `meta = {"indexed_height": 120, "chain_head": 121, "lag_blocks": 1, "projection_state": "OK"}`.
Record bodies are exactly the JSON stored on-chain (see `chain/internal/core/types.go`): every record has `version`, `schema_version`, `created_height`, `updated_height`, `created_tx`, `updated_tx`.

## Submission

`POST /api/v1/tx/submit`
```json
{ "tx": { "v":1, "body":"...", "sig":"...", "pub":"..." }, "wait": "none|final|indexed", "timeout_ms": 15000 }
```
`tx` may be the envelope object or the envelope JSON as a string. Response:
```json
{ "tx_hash":"HEX", "tx_id":"...", "type":"CreateProduct", "signer":"...",
  "admission": {"code":0,"name":"OK","log":""},
  "finalised": {"height":27,"index":0,"code":0,"code_name":"OK","log":"","data":{...}},
  "indexed": true,
  "latency_ms": {"admission": 4, "finality": 1180, "indexed": 1230} }
```
`admission` is CheckTx (mempool entry) — **not finality**. Resubmitting byte-identical transaction bytes returns `admission.code 210 (REPLAY)` with `"duplicate": true` (the mempool cache refuses them). Note that CheckTx also runs the authorisation stage, which looks records up: e.g. a payment for an unknown sale is refused at admission with `NOT_FOUND` and leaves no trace on chain; only transactions that reach a block are recorded (`OK` or `REJECTED`). `finalised` appears when `wait` is `final` or `indexed` and the tx was committed (a committed tx may still have `code != 0`: it is ordered but rejected, with no state change). `wait=indexed` additionally waits for the projection (read-after-write).

`GET /api/v1/tx/{tx_id}/status` → `{"tx_id", "status": "UNKNOWN|PENDING|FINALISED_OK|FINALISED_REJECTED", "height", "index", "code", "code_name", "reason", "block_time_ms", "signer", "type", "indexed": bool}` (authoritative: reads `tx/<id>` from chain state; `PENDING` if in a validator mempool).

`GET /api/v1/metrics/latency` → submission/finalisation latency of txs submitted through this gateway: `{"count", "admission_ms": {"p50","p95","p99","max"}, "finality_ms": {...}, "recent": [{"tx_id","type","admission_ms","finality_ms","code","at"}]}` and `rejected_recent`: recent finalised-but-rejected or admission-rejected txs with reasons.

Rate limiting: per-client-IP token bucket on `/tx/submit` (default 50 req/s burst 100); HTTP 429 with `Retry-After`.

## Network & consensus

`GET /api/v1/network`
```json
{ "network_id":"aureom-retail-demo-1", "app_version":1,
  "chain": {"latest_height":120,"latest_block_time":"...","latest_app_hash":"HEX","block_interval_ms_avg":1003},
  "bft": {"validators":4,"voting_power_total":40,"f":1,"quorum_power_required":27,"online_power":40,"online_validators":4,"status":"HEALTHY|DEGRADED|HALTED",
          "explanation":"..."},
  "validators":[{"name":"val-hq","org":"org-hq","role":"HEADQUARTERS","node_id":"..","rpc_url":"..","reachable":true,"height":120,"catching_up":false,
                  "peers":3,"latency_ms":3,"voting_power":10,"consensus_pubkey":"b64","app_hash":"HEX","agrees_with_majority":true,"last_signed_height":120}],
  "members":[...on-chain members from state...], "mempool":{"unconfirmed_txs":0}, "queried_at":"..." }
```
`GET /api/v1/chain/info` → raw app info `{height, app_hash, app_version, chain_id, max_supported_version}`.

## Authoritative reads

`GET /api/v1/chain/record?key=<state key>[&height=H][&prove=1]`
```json
{ "key":"sale/S-1", "found":true, "value":{...}, "value_b64":"<exact stored bytes, base64>", "height":88,
  "proof": { "type":"ics23:iavl", "proof_b64":"..", "app_hash_height":89, "app_hash":"HEX" },
  "verification": { "proof_valid":true, "header_verified":true, "statement":"key/value is committed in the state whose root is in a +2/3-signed header; this alone does not establish business correctness or search completeness" } }
```
Absent keys return `found:false` with a **non-membership** proof when `prove=1`.

`GET /api/v1/chain/records/{kind}/{id}[?height=H&prove=1]` — convenience; kinds: `product sku location supplier po receipt reservation sale return refund price promotion loyalty loyalty-entry adjustment transfer exception identity grants tx member proposal`.
`GET /api/v1/chain/scan?prefix=sale/&after=<key>&limit=200[&height=H]` → `{"height","items":[{"key","value"}], "next_after"}` (authoritative, paginated; no proofs).
`GET /api/v1/chain/inventory?sku=SKU-A[&location=STORE-N-01][&height=H]` → authoritative balances: `[{"sku","loc","available","reserved","quarantined","damaged","on_hand","in_transit_out"?,"version"}]` plus `in_transit` rows (locations `TRANSIT:<transfer>`).
`GET /api/v1/chain/digest[?height=H]` → `{"height","app_hash","digest","entries"}`.
`GET /api/v1/chain/migration` → on-chain migration state (`mig/state`).

## Explorer (blockchain diagnostics)

* `GET /api/v1/explorer/blocks?limit=20&before=<height>` → `[{"height","time","hash","app_hash","proposer","num_txs","num_rejected","size_bytes"}]`
* `GET /api/v1/explorer/block/{height}` → header + txs (`tx_id,type,signer,code,code_name,log,hash`) + `commit`: `{"round","signatures":[{"validator","validator_name","signed":true,"power"}], "signed_power", "total_power", "finality_verified":bool}`
* `GET /api/v1/explorer/tx/{id_or_hash}` → tx body (decoded), signature check, result, inclusion `{height,index}`, merkle inclusion proof of the tx in the block's `data_hash` (`include_proof=1`), and the records it changed (from block events).
* `GET /api/v1/explorer/verify-finality?height=H` → `{"height","verified","method":"cometbft light client, trusted root = genesis validator set","trusted_height","signed_power","total_power","quorum_required","validators_signed":[...], "header_app_hash"}`
* `GET /api/v1/explorer/proof?key=...&height=H` → same as `chain/record?prove=1`, plus a step-by-step `explanation` list suitable for display.
* `GET /api/v1/explorer/search?q=` → matches tx id/hash, block height, record key.

## Projection

* `GET /api/v1/projection/status` → `{"state":"OK|REBUILDING|EMPTY","indexed_height","chain_head","lag_blocks","lag_seconds","entries","digest","last_block_time","rebuild":{"started_at","finished_at","blocks_replayed","duration_ms"}}`
* `POST /api/v1/projection/rebuild` → drops the projection database and re-ingests from height 1 (genesis state is read from the chain's genesis document). Returns immediately; poll `status`.
* `GET /api/v1/projection/verify[?proofs=20]` → compares projection digest/entry count against the chain's `digest` at the projection's indexed height and spot-verifies `proofs` random records with ICS23 proofs: `{"height","projection_digest","chain_digest","match":true,"entries","proofs_checked","proofs_valid"}`.

## Query endpoints (projection)

All support `limit` (default 50, max 500), `offset`, `min_height`, `wait_ms`.

| endpoint | filters | notes |
|---|---|---|
| `GET /api/v1/q/products` | `q` (name/brand/sku/barcode), `category`, `status` | each item embeds its SKUs as `sku_details` (the `skus` field remains the list of SKU ids) |
| `GET /api/v1/q/products/{id}` | | + `price_history`, `versions` (product record versions over time) |
| `GET /api/v1/q/skus` | `product`, `q`, `scarce` | |
| `GET /api/v1/q/locations`, `/suppliers` | `kind`, `region` | |
| `GET /api/v1/q/inventory` | `sku`, `location`, `low_stock` (available <= N) | rows: `sku, loc, product_name, available, reserved, quarantined, damaged, on_hand, in_transit_in, in_transit_out, version`; excludes `EXT:*` and `TRANSIT:*` rows |
| `GET /api/v1/q/inventory/exceptions` | | open exceptions + discrepancies + stuck in-transit + expiring reservations: `[{"kind","severity","ref","detail","location","sku"}]` |
| `GET /api/v1/q/movements` | `sku`, `location`, `reason`, `ref_id` | ledger rows, newest first |
| `GET /api/v1/q/purchase-orders` | `status`, `supplier`, `location`, `sku` (any line) | |
| `GET /api/v1/q/receipts` | `location`, `po`, `supplier`, `sku` (any line) | |
| `GET /api/v1/q/transfers` | `status`, `from`, `to`, `sku` (any line) | |
| `GET /api/v1/q/adjustments`, `/reservations` | `status`, `location`, `sku` | |
| `GET /api/v1/q/sales` | `from`, `to` (epoch ms, **effective** time), `location`, `payment_status`, `customer` | sale records incl. lines and pricing steps |
| `GET /api/v1/q/sales/{id}` | | + related returns, refunds, loyalty entries, payment events |
| `GET /api/v1/q/sales/summary` | `from`,`to`,`group=day|location|channel` | `[{"bucket","sales","gross_minor","discount_minor","net_minor","paid_minor","refunded_minor"}]` |
| `GET /api/v1/q/returns`, `/refunds` | `status`, `sale` | |
| `GET /api/v1/q/prices` | `sku`, `location` | full publication history |
| `GET /api/v1/q/promotions` | `status` | |
| `GET /api/v1/q/loyalty/accounts` | `q` | |
| `GET /api/v1/q/loyalty/accounts/{id}` | | account + entries |
| `GET /api/v1/q/exceptions` | `status`, `kind` | |
| `GET /api/v1/q/transactions` | `type`, `signer`, `status` (`OK|REJECTED`), `code`, `from_height` | tx log incl. rejected with `code_name` + `reason`, `height`, `block_time_ms`, `client_time_ms` |
| `GET /api/v1/q/history` | `key` (exact state key) or `kind`+`id` | audit history: every version of the record: `[{"height","tx_id","tx_type","signer","block_time_ms","version","value","deleted"}]` |
| `GET /api/v1/q/identities` | | identities with keys (status ACTIVE/REVOKED/ROTATED) and role grants — key/rotation history for the Administration screen |
| `GET /api/v1/q/governance` | | `{"members":[...],"proposals":[...],"upgrades":[...],"params":{...},"events":[...key & membership events in time order]}` |
| `GET /api/v1/q/migration` | | `{"state":{...}, "batches":[...]}` |
| `GET /api/v1/q/stats` | | headline counters for the overview: products, skus, locations, sales (today/total), open exceptions, rejected tx (24h), tx total, active reservations, loyalty points outstanding |

Money in JSON is integer minor units (`*_minor`); quantities integer in the SKU unit's smallest step (`*_v`, `qty`).

## State key reference

| key | record | key | record |
|---|---|---|---|
| `product/<id>` | Product | `sku/<id>` | SKU |
| `loc/<id>` | Location | `supplier/<id>` | Supplier |
| `po/<id>` | PurchaseOrder | `receipt/<id>` | GoodsReceipt |
| `bal/<sku>/<loc>` | Balance | `mov/<sku>/<seq12>` | Movement |
| `resv/<id>` | Reservation | `sale/<id>` | Sale (lines, pricing steps, payment/fulfilment status) |
| `return/<id>` | Return | `refund/<id>` | Refund |
| `price/<id>` | Price | `pbook/<sku>/<loc|*>` | PriceBook |
| `promo/<id>` | Promotion | `loy/<customer>` | LoyaltyAccount |
| `loye/<id>` | LoyaltyEntry | `adjust/<id>` | Adjustment |
| `xfer/<id>` | Transfer | `exc/<id>` | Exception |
| `iam/id/<id>` | Identity (+keys) | `iam/grants/<id>` | role grants |
| `tx/<tx_id>` | TxRecord (OK/REJECTED + reason) | `idem/<signer>/<ref>` | idempotency record |
| `gov/member/<id>` | Member | `gov/prop/<id>` | Proposal |
| `gov/params` | Params | `gov/upgrade/<v>` | upgrade schedule/activation |
| `mig/state`, `mig/batch/<id>` | migration state/batches | `meta/appver` | active state-machine version |

## Migration reports (off-chain, produced by the Python tool)

* `POST /api/v1/migration/reports` — body is a reconciliation/migration report JSON (stored verbatim by the gateway in its data dir; the on-chain `MigrationControl CLOSE` carries the report hash). Returns `{"id","sha256"}`.
* `GET /api/v1/migration/reports` → `[{"id","phase","trial","generated_at","decision","sha256"}]`; `GET /api/v1/migration/reports/{id}` → the report; `GET /api/v1/migration/reports/latest`.

Report shape (produced by `migration/`, rendered by the dashboard):
```json
{ "id":"rpt-...", "phase":"trial|master|opening|final", "trial":true, "network_id":"...", "generated_at":"ISO",
  "snapshot_id":"snap-...", "snapshot_sha256":"..", "mapping_version":"map-v1", "source_system":"legacy-retail-erp",
  "authoritative_system":"SOURCE|FROZEN|CHAIN",
  "checks":[{"name":"product count","source":120,"chain":120,"delta":0,"status":"PASS|FAIL|WARN","detail":""}],
  "exceptions":[{"kind":"DUPLICATE_SKU|ORPHAN_FK|NEGATIVE_STOCK|UNSUPPORTED_FIELD|...","source_ref":"table:id","detail":"","disposition":"EXCLUDED|FIXED|PRESERVED_AS_EXTRAS|MANUAL"}],
  "unsupported_fields":[{"table":"","column":"","rows":0,"treatment":"preserved in source_extras|dropped with approval"}],
  "batches":[{"batch_id":"","entity":"","seq":0,"records":0,"tx_id":"","height":0,"status":"FINALISED|REJECTED"}],
  "decision":"ACCEPT|REJECT", "notes":"" }
```

## Local ports (convention)

validators: p2p `BASE+10*i`, rpc `BASE+10*i+1` (i = 0..3 for val-hq, val-dist, val-north, val-south; default BASE 26600); gateway `127.0.0.1:8080`.

## Notes on the exact response shapes (as implemented; supersede the sketches above where they differ)

* `GET /explorer/block/{h}`: `{height,time,hash,chain_id,proposer,proposer_address,header_app_hash,state_app_hash_after_block,validators_hash,data_hash,app_version,txs[{index,hash,size,tx_id,type,signer,code,code_name,log}],commit{round,signatures[{validator,validator_name,signed,power}],signed_power,total_power,finality_verified}}`.
* `GET /explorer/blocks`: `[{height,time,hash,app_hash,proposer,num_txs,num_rejected,size_bytes}]` (from the projection).
* `GET /explorer/proof`: `{record: <same as /chain/record?prove=1>, explanation: [numbered steps]}`.
* `GET /explorer/tx/{id}`: `{record?, hash, height, index, result{code,code_name,log,data}, body{tx_id,network_id,type,schema_version,signer,key_id,idempotency_ref,expected_version,client_time_ms,payload}, signature_check{valid,public_key,note}, records_changed[{op,key}], inclusion_proof?}`.
* `GET /explorer/verify-finality`: `{height,verified,method,signed_power,total_power,quorum_required,validators_signed[],block_hash,header_app_hash,note}` (or `{verified:false,error}`).
* `GET /explorer/search`: `{query, results:[{type:"block|record|tx", ref}]}`.
* `GET /network`: `chain.block_interval_ms_avg` is the average of the last 20 indexed blocks; `validators[].last_signed_height` is the head height only if that validator signed the head commit (otherwise 0 — it can lag by one block while healthy).
* `q/*` single-record and aggregate endpoints (`stats`, `governance`, `migration`, `products/{id}`, `sales/{id}`, `loyalty/accounts/{id}`) return `{meta, item}`; `q/stats` keys: `products, skus, locations, suppliers, sales_total, sales_native, sales_24h, sales_net_minor_24h, refunded_minor_24h, open_exceptions, transactions_total, transactions_rejected, transactions_rejected_24h, active_reservations, loyalty_points_outstanding, units_on_hand`.
* `q/transactions` rows: `{height,index_in_block,tx_id,type,signer,status,code,code_name,reason,hash,block_time_ms,client_time_ms,authenticated}`; `q/loyalty/accounts/{id}` returns `item.entries` as an array of ledger entries.
* `q/sales?to=` is exclusive. `projection/status` includes `last_indexed_block_time`; `projection/verify` includes `projection_entries` and `chain_entries`.
