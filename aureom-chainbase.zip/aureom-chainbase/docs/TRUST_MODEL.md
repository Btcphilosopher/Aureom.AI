# Trust model, deployments and what a blockchain does *not* establish

## Two things that must not be confused

| | **Single-node prototype** | **Multi-validator network** (the demonstration) |
|---|---|---|
| What it is | `core.Sim` — the same state machine executed in-process, no consensus, no p2p, memory store. Used for the unit tests, determinism tests, fuzzing and the "engine" benchmark. | 4 real `chaind` processes (CometBFT consensus over authenticated TCP, own keys, own data directories, own mempools) started by `scripts/localnet.sh` or Docker Compose; 4 validators = `3f+1` with `f=1`. |
| Guarantees | deterministic state transitions, atomicity, conservation, authorisation logic | additionally: agreement on one order, finality, tolerance of 1 faulty validator, halt-without-fork under quorum loss, crash recovery, replay by new nodes |
| Not provided | any fault tolerance or independent trust | independent *administration* — in the sandbox one person runs all four on one machine |

## Independently administered vs. multiple validators of one organisation
Validators controlled by **one organisation** give *availability and crash/partition resilience* and a replicated audit trail, but they do not give
separation of control: whoever holds ≥ 2/3 of the keys can finalise any history the state machine allows, rewrite the future (new genesis / forked chain),
censor, and read everything. They protect against hardware loss, a buggy node, or a single compromised host — not against that organisation.
Validators run by **independent organisations** (here: Headquarters, Distribution, Regional North, Regional South — in the demo they are *named* as such but run
by us on one host) mean no single organisation can finalise, rewrite, or silently change rules; any 2 of 4 can block (halt) the chain; 3 of 4 are needed to change
membership, grant privileged roles, change parameters or activate a new state-machine version. This only has value if the organisations really hold their own keys,
run their own infrastructure, and pin the same genesis. Real separation needs: separate cloud accounts/data centres, separate key custody (HSM or remote signer), separate
operators and change control, a verifier (auditor/regulator) who runs a light client with its own trust root.

## Who can read the data
Every validator executes every transaction and therefore holds **all plaintext business records** (in the strict profile: everything). API permissions in the
gateway/dashboard (which in this prototype are open read-only) and on-chain role permissions control **who may change state** — they do **not** hide
data from validator operators or from anyone who can read a validator's disk, block store, mempool or RPC. Confidentiality needs the privacy-conscious profile
(`docs/PRIVACY.md`), which changes *what is stored*, not who may be shown it.

## Component trust map
| Component | Trusted for | Not trusted for |
|---|---|---|
| Validators (≥ 2/3 power honest) | ordering, finality, state transitions | secrecy of data |
| Gateway | convenience: relaying, projection, proof/finality checks | authority. It cannot forge a block; a client can re-verify with `chainctl verify-finality`, proofs and `chainctl replay`. |
| Projection (SQLite) | speed of search/reporting | anything — disposable, verified by digest + proofs |
| SDK signing keys (HSM/KMS/file) | authorising a business actor's transactions | — keys must never leave the device; compromise = revoke key, see GOVERNANCE |
| External adapters (payment, ERP, WMS) | telling the chain what happened outside | *money movement is outside the chain*: a recorded payment/refund instruction is not a payment; only an authenticated adapter result confirms it |
| Dashboard | display | cannot sign or write |

## What integrity of the chain does *not* establish
* That goods physically arrived, were counted correctly, or are not damaged: the ledger records what authorised users **assert**. Discrepancies are fixed by approved adjustments (maker-checker) — which are themselves assertions.
* That a payment network moved money, or that a refund reached a customer: the chain records instructions and adapter-reported results; reconciliation exceptions exist for mismatches/duplicates/late results.
* The real-world time of an event: `effective_at_ms` is a claim of the signer; block time is the validators' agreed clock, which only brackets plausibility.
* The accuracy of **imported history**: it is the legacy system's assertion, now immutable and attributed (`provenance.origin = IMPORTED`, with source id, batch id, mapping version, snapshot id). Importing old records does not retrospectively prove them.
* Completeness of a search result, or business correctness, from a Merkle inclusion proof: a proof shows a key/value is in committed state only.
* Privacy: see above.
* Protection from an authorised insider acting within their permissions (e.g. a store manager approving a bogus adjustment): controls are maker-checker, limits, audit history, anomaly review — not cryptography.

## Residual limitations of this prototype (summary — full list in `docs/GUARANTEES.md`)
Single machine; random plaintext key files for demo identities (no HSM); open read-only gateway (no SSO); light-client trusting period unrealistically long; no pruning; no
state-sync bootstrap; one-time-key validator rotation requires a node restart; Docker artefacts not executed in the build sandbox.
