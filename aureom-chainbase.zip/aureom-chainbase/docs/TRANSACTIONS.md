# Transaction reference

Generated from the Go payload types by `chainctl schema md` — it cannot drift from the validators.

## Wire format

A transaction on the wire is one JSON object (the "envelope"):

```json
{ "v": 1, "body": "<base64 of the exact body bytes that were signed>", "sig": "<base64 ed25519>", "pub": "<base64 ed25519 public key>" }
```

* `body` is JSON (any key order/whitespace; the signer chooses the bytes, validators verify exactly those bytes — no canonicalisation needed across languages).
* Signature preimage (bytes): `"AUREOM-CHAINBASE/TX/v1" 0x00 <network_id> 0x00 <body bytes>`.
* The body (all fields required unless noted):

| field | meaning |
|---|---|
| `tx_id` | unique id, `^[A-Za-z0-9_-]{8,64}$`. A second tx with the same id is rejected (`REPLAY`). |
| `network_id` | must equal the chain id (cross-network replay protection; also in the signed preimage). |
| `type` | one of the types below. |
| `schema_version` | currently `1`. |
| `signer` | registered identity id. |
| `key_id` | which of the identity's keys signed (must be ACTIVE and match `pub`). |
| `idempotency_ref` | business-level dedupe key, unique per signer: a second tx with the same ref is rejected (`DUPLICATE_IDEMPOTENCY`) once the first has *succeeded*. Retries after a rejection may reuse it. |
| `expected_version` | optional integer. Optimistic concurrency check against the record the transaction primarily changes (product, PO, price book, balance for reservations, adjustment, return, promotion, transfer ...). |
| `client_time_ms` | the signer's claim of local time. Never trusted as proof of when something happened. |
| `valid_until_height` | optional; tx is rejected after this height (bounds replay windows for queued/offline requests). |
| `payload` | type specific object (below). Unknown fields are rejected. |

Processing stages and result codes (`code` in the tx result; 0 = success):

1. structure/limits: `MALFORMED 1`, `TOO_LARGE 2`, `WRONG_NETWORK 3`, `UNKNOWN_TYPE 4`, `UNSUPPORTED_SCHEMA 5`, `INVALID_FIELD 6`
2. cryptographic validity: `BAD_SIGNATURE 101`
3. identity: `UNKNOWN_SIGNER 201`, `KEY_INACTIVE 202`, `EXPIRED 203`
4. replay: `REPLAY 210`, `DUPLICATE_IDEMPOTENCY 211`
5. business authorisation (valid signature but prohibited): `UNAUTHORIZED 301`, `SCOPE_VIOLATION 302`, `POLICY_VIOLATION 303`
6. business validation: `NOT_FOUND 401`, `ALREADY_EXISTS 402`, `VERSION_CONFLICT 403`, `INSUFFICIENT 404`, `INVALID_STATE 405`, `LIMIT_EXCEEDED 406`, `INVALID_ARGUMENT 407`, `MIGRATION_WINDOW 408`

Transactions that fail at stage 1-3 leave no state trace (the id is not burned). CheckTx (mempool admission) also runs stage 5 against committed state, so a transaction that is already prohibited or refers to a record that does not exist yet (e.g. a payment for an unknown sale) is refused at admission and never reaches a block; submitters must be prepared to retry such requests (the SDK's integration runner does). Transactions that pass stage 3 but fail later are *included in the block* and recorded as `tx/<tx_id>` with status `REJECTED` and the reason, but make no other state change (all-or-nothing).

## Units

* Money: `{"minor": <int>, "ccy": "GBP"}` or bare `*_minor` integers with an implied currency. GBP/USD/EUR exponent 2, JPY 0. Max 10^12 minor units.
* Quantities: `{"v": <int>, "unit": "EA"}` — `v` is an integer in the unit's smallest step: `EA`,`PK` whole units; `KG` in grams, `L` in millilitres, `M` in millimetres. The unit must equal the SKU's unit. Prices are per *whole* unit.
* Times: `*_ms` are Unix epoch milliseconds. `effective_at_ms` is a business-effective claim; the block time is stored separately (`block_time_ms`).

## Roles (permission catalogue)

| role | permissions |
|---|---|
| `auditor` |  |
| `buyer` | po.create, supplier.write |
| `catalog-manager` | catalog.write |
| `finance-controller` | reverse.entry, exception.resolve, return.approve |
| `hq-admin` | iam.grant, iam.admin, location.write, supplier.write, gov.propose, exception.resolve |
| `loyalty-operator` | loyalty.credit, loyalty.expire, loyalty.redeem |
| `migration-operator` | import.batch, migration.control |
| `org-admin` | gov.propose, gov.approve |
| `payment-adapter` | payment.record, refund.record |
| `pricing-manager` | price.publish, promo.manage |
| `purchasing-approver` | po.approve |
| `store-cashier` | stock.reserve, stock.release, sale.complete, return.request, loyalty.redeem |
| `store-manager` | goods.receive, transfer.dispatch, stock.reserve, stock.release, sale.complete, return.request, loyalty.redeem, return.approve, return.receive, stock.adjust.propose, stock.adjust.approve, transfer.receive, reverse.entry, exception.resolve, loyalty.credit |
| `terminal` | stock.reserve, stock.release, sale.complete, loyalty.redeem |
| `warehouse-manager` | goods.receive, transfer.dispatch, transfer.receive, stock.adjust.propose, stock.adjust.approve, stock.reserve, stock.release, reverse.entry, exception.resolve |
| `warehouse-operator` | goods.receive, transfer.dispatch, transfer.receive, stock.adjust.propose, stock.reserve, stock.release |

Privileged roles (`hq-admin`, `org-admin`, `migration-operator`, `finance-controller`) can only be granted/revoked by multi-organisation governance proposals (or genesis). Scopes: `*`, `loc:<id>`, `region:<name>`.

## Transaction types

### ActivatePromotion

Permission: `promo.manage`

```json
{
  "bp": 0,
  "bundle_minor": 0,
  "buy_n": 0,
  "currency": "string",
  "effective_from_ms": 0,
  "effective_to_ms": 0,
  "locations": [
    "string"
  ],
  "loyalty_only": false,
  "name": "string",
  "off_minor": 0,
  "priority": 0,
  "promo_id": "string",
  "skus": [
    "string"
  ],
  "stackable": false,
  "status": "string",
  "type": "string"
}
```

### AdjustStock

Permission: `(checked inside handler)`

```json
{
  "adjustment_id": "string",
  "bucket": "string",
  "counted_v": 0,
  "evidence_ref": "string",
  "location_id": "string",
  "op": "string",
  "reason": "string",
  "sku": "string"
}
```

### ApproveGovernance

Permission: `gov.approve`

```json
{
  "proposal_id": "string"
}
```

### ApprovePurchaseOrder

Permission: `po.approve`

```json
{
  "po_id": "string"
}
```

### ApproveReturn

Permission: `return.approve`

```json
{
  "decision": "string",
  "return_id": "string"
}
```

### CompleteSale

Permission: `sale.complete`

```json
{
  "channel": "string",
  "currency": "string",
  "customer_id": "string",
  "effective_at_ms": 0,
  "expected_total_minor": 0,
  "lines": [
    {
      "qty": {
        "unit": "string",
        "v": 0
      },
      "reservation_id": "string",
      "sku": "string"
    }
  ],
  "location_id": "string",
  "payment_method": "string",
  "sale_id": "string",
  "terminal_id": "string"
}
```

### CreateLocation

Permission: `location.write`

```json
{
  "currency": "string",
  "kind": "string",
  "location_id": "string",
  "name": "string",
  "region": "string"
}
```

### CreateProduct

Permission: `catalog.write`

```json
{
  "attributes": {
    "key": "string"
  },
  "brand": "string",
  "category": "string",
  "name": "string",
  "product_id": "string",
  "variants": [
    {
      "attributes": {
        "key": "string"
      },
      "barcode": "string",
      "scarce": false,
      "sku_id": "string",
      "unit": "string"
    }
  ]
}
```

### CreatePurchaseOrder

Permission: `po.create`

```json
{
  "currency": "string",
  "lines": [
    {
      "qty": {
        "unit": "string",
        "v": 0
      },
      "sku": "string",
      "unit_cost_minor": 0
    }
  ],
  "location_id": "string",
  "ordered_at_ms": 0,
  "po_id": "string",
  "supplier_id": "string"
}
```

### CreateSupplier

Permission: `supplier.write`

```json
{
  "name": "string",
  "supplier_id": "string",
  "terms": "string"
}
```

### CreditLoyalty

Permission: `loyalty.credit`

```json
{
  "customer_id": "string",
  "entry_id": "string",
  "sale_id": "string"
}
```

### ExpireLoyalty

Permission: `loyalty.expire`

```json
{
  "customer_id": "string",
  "entry_id": "string",
  "points": 0,
  "reason": "string"
}
```

### GrantRole

Permission: `iam.grant`

```json
{
  "identity_id": "string",
  "role": "string",
  "scope": "string"
}
```

### ImportBatch

Permission: `import.batch` — bulk (larger size limit)

```json
{
  "batch_id": "string",
  "entity": "string",
  "mapping_version": "string",
  "records": [
    {}
  ],
  "seq": 0,
  "snapshot_id": "string",
  "source_system": "string"
}
```

### MigrationControl

Permission: `migration.control`

```json
{
  "action": "string",
  "manifest_hash": "string",
  "report_hash": "string",
  "source_freeze_marker": "string",
  "source_system": "string",
  "totals": {
    "key": 0
  }
}
```

### ProposeGovernance

Permission: `gov.propose`

```json
{
  "activation_height": 0,
  "kind": "string",
  "payload": {},
  "proposal_id": "string"
}
```

### PublishPrice

Permission: `price.publish`

```json
{
  "currency": "string",
  "effective_from_ms": 0,
  "effective_to_ms": 0,
  "location_id": "string",
  "price_id": "string",
  "sku": "string",
  "unit_minor": 0
}
```

### ReceiveGoods

Permission: `goods.receive`

```json
{
  "effective_at_ms": 0,
  "lines": [
    {
      "po_line": 0,
      "qty": {
        "unit": "string",
        "v": 0
      },
      "sku": "string"
    }
  ],
  "location_id": "string",
  "po_id": "string",
  "receipt_id": "string",
  "supplier_id": "string"
}
```

### ReceiveReturnedGoods

Permission: `return.receive`

```json
{
  "lines": [
    {
      "inspection": "string",
      "line_no": 0,
      "qty_v": 0
    }
  ],
  "return_id": "string"
}
```

### RecordPaymentResult

Permission: `payment.record`

```json
{
  "amount_minor": 0,
  "currency": "string",
  "event_id": "string",
  "provider": "string",
  "provider_ref": "string",
  "result": "string",
  "sale_id": "string"
}
```

### RecordRefundResult

Permission: `refund.record`

```json
{
  "amount_minor": 0,
  "event_id": "string",
  "provider": "string",
  "provider_ref": "string",
  "refund_id": "string",
  "result": "string"
}
```

### RedeemLoyalty

Permission: `loyalty.redeem`

```json
{
  "customer_id": "string",
  "effective_at_ms": 0,
  "entry_id": "string",
  "location_id": "string",
  "points": 0,
  "redemption_ref": "string",
  "sale_id": "string"
}
```

### RegisterIdentity

Permission: `iam.admin`

```json
{
  "bound_location": "string",
  "identity_id": "string",
  "key_id": "string",
  "kind": "string",
  "org": "string",
  "pub_b64": "string"
}
```

### ReleaseReservation

Permission: `stock.release`

```json
{
  "reason": "string",
  "reservation_id": "string"
}
```

### RequestReturn

Permission: `return.request`

```json
{
  "lines": [
    {
      "line_no": 0,
      "qty_v": 0,
      "reason": "string"
    }
  ],
  "override_reason": "string",
  "return_id": "string",
  "sale_id": "string"
}
```

### ReserveStock

Permission: `stock.reserve`

```json
{
  "allowance": false,
  "location_id": "string",
  "qty": {
    "unit": "string",
    "v": 0
  },
  "reservation_id": "string",
  "sku": "string",
  "terminal_id": "string",
  "ttl_ms": 0
}
```

### ResolveException

Permission: `exception.resolve`

```json
{
  "exception_id": "string",
  "location_id": "string",
  "resolution": "string"
}
```

### ReverseBusinessEntry

Permission: `reverse.entry`

```json
{
  "points": 0,
  "reason": "string",
  "refund_id": "string",
  "reversal_id": "string",
  "target_id": "string",
  "target_type": "string"
}
```

### RevokeKey

Permission: `(checked inside handler)`

```json
{
  "identity_id": "string",
  "key_id": "string",
  "reason": "string"
}
```

### RevokeRole

Permission: `iam.grant`

```json
{
  "identity_id": "string",
  "role": "string",
  "scope": "string"
}
```

### RotateKey

Permission: `(checked inside handler)`

```json
{
  "identity_id": "string",
  "new_key_id": "string",
  "new_pub_b64": "string",
  "reason": "string"
}
```

### TransferStock

Permission: `(checked inside handler)`

```json
{
  "from_location": "string",
  "lines": [
    {
      "damaged_v": 0,
      "qty": {
        "unit": "string",
        "v": 0
      },
      "sku": "string"
    }
  ],
  "op": "string",
  "to_location": "string",
  "transfer_id": "string"
}
```

### UpdateProduct

Permission: `catalog.write`

```json
{
  "attributes": {
    "key": "string"
  },
  "brand": "string",
  "category": "string",
  "name": "string",
  "product_id": "string",
  "sku_updates": [
    {
      "attributes": {
        "key": "string"
      },
      "barcode": "string",
      "scarce": false,
      "sku_id": "string",
      "status": "string"
    }
  ],
  "status": "string"
}
```

