# The complete demonstration (13 steps)

`scripts/demo.sh` builds, starts a **fresh 4-validator network + gateway/projection/dashboard**, and runs the whole sequence below with narration. A captured run from the build
environment is in `docs/demo-run-output.log` (ANSI colours stripped; ids differ per run). Prerequisites: Go ≥ 1.26, Node ≥ 22, Python ≥ 3.11 (a venv with the pinned `migration/requirements.txt` is created automatically), `curl`.

```bash
scripts/demo.sh                       # everything (≈ 6–8 minutes, most of it the trial + real migration and block times)
SKIP_TRIAL=1 scripts/demo.sh          # skip the throw-away trial network
SKIP_START=1 STEP=3 scripts/demo.sh   # run a single step on an already running network (steps 2–10 need step 1 first)
scripts/demo-governance.sh            # extra: key rotation, observer admission by vote, upgrade activation, old-binary halt
```
Open the dashboard at `http://127.0.0.1:8080` during/after the run (Overview, Network, Inventory, Sales, Migration, Explorer …).

| # | Step | What runs | What it demonstrates / what to look for |
|---|---|---|---|
| 0 | Start | `scripts/localnet.sh start` + gateway | 4 independent validators (HQ, Distribution, Regional North/South), `n=4, f=1`, quorum > 2/3 = ≥ 27 of 40 voting power |
| 1 | Migrate products, locations, opening inventory | `python -m aureom_migration trial …` on a **throw-away network (`aureom-trial-1`)**, then `… all` on the real one | trial → master data (while the legacy system is authoritative) → **write freeze** (triggers prove the source refuses writes) → final snapshot → opening balances/open POs/loyalty → reconciliation (79 checks) → **on-chain CLOSE with attested totals equal to the chain's own counters** → source archived; post-cutover reconciliation (82 checks, 0 FAIL) |
| 2 | Receive additional stock | SDK `step2-receive` | goods receipt against migrated open PO-2001: `available 2 → 3` |
| 3 | Competing reservations for the last unit | `step3-compete` | all but one unit reserved, then two terminals race, signed concurrently, landing in the same block |
| 4 | Valid finalised, conflicting rejected | `step4-outcome` | winner `OK`; loser finalised in the block as `INSUFFICIENT` (ordered, no state change) |
| 5 | Complete a sale | `step5-sale` | atomic reservation→sale; price + promotion calculation with exact inputs and rule versions recorded |
| 6 | Payment confirmation | `step6-payment` | the adapter's authenticated result (a recorded instruction is not confirmed payment); duplicate callback deduplicated |
| 7 | Loyalty credit | `step7-loyalty` | credited only after confirmed payment |
| 8 | Return + inspection | `step8-return` | request → approval (different person) → inspection RESELLABLE → refund *instructed* |
| 9 | Refund confirmation | `step9-refund` | instruction and confirmation are separate events |
| 10 | Reverse loyalty | `step10-loyalty-reverse` | linked compensating entry; original preserved; proportional to the confirmed refund |
| 11 | Stop one validator | `localnet.sh stop-node` | status `DEGRADED`, business tx still finalises (3/4); stop a **second** → chain halts, nothing finalises, nothing forks; restore → pending tx finalises |
| 12 | Rebuild a node and the projection | `chainctl newnode --mode replace`, `POST /projection/rebuild` | node with empty data dir replays the chain; projection deleted and re-ingested from genesis |
| 13 | Verify against the finalised chain | `verify-finality`, `replay`, `projection/verify`, proofs, `snapshot` | (a) all 4 validators agree on the app hash; (b) light-client finality; (c) **full replay re-executes every block and matches every state root**; (d) projection digest = chain digest + 25/25 Merkle proofs; (e) proofs for the sale, refund, loyalty entries; (f) offline snapshot (taken from the *rebuilt* node) verifies against a signed header |

Everything uses synthetic data. See `docs/GUARANTEES.md` for what these demonstrate and what they do not.
