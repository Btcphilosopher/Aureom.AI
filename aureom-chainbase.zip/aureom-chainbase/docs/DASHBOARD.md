# Operations dashboard

`dashboard/` is the read-only operations console for AUREOM CHAINBASE: a single-page app (Vite + React 18 + TypeScript strict,
React Router, TanStack Query, hand-written CSS design system, no UI kit). It talks only to the gateway REST API
([API.md](API.md)). It holds no keys, signs nothing and cannot change business state: signing happens in the SDK / signing service.
The only "write" it can trigger is `POST /projection/rebuild` (drops and re-creates the disposable query index), behind a confirm dialog.

## Run, build, test

```bash
cd dashboard
npm install                 # exact-pinned dependencies, all >= 2 weeks old at the time of writing
npm run build               # tsc --noEmit (strict) + vite build  ->  dashboard/dist  (route-split, ~165 kB react chunk, pages 5-25 kB each)
npm test                    # vitest + jsdom + Testing Library (82 tests)
npm run typecheck           # app + mock/vite config
npm run mock                # mock gateway on http://127.0.0.1:8083 (serves dist/ too, with SPA fallback)
npm run dev                 # Vite dev server on :5173, proxies /api to http://127.0.0.1:8083 (override with VITE_PROXY_TARGET)
npm run shots               # screenshot every page, light + dark (see below)
node scripts/interactions.cjs   # click-through checks of the interactive flows (theme, search, finality, proofs, projection verify/rebuild, keyboard)
```

* **Production**: the gateway serves `dashboard/dist` at `/` with SPA fallback (`--static`), and the app calls the API on the same origin at `/api/v1/...`.
  Override with `VITE_API_BASE` at build time (for example `http://127.0.0.1:8080/api/v1`).
* **Real stack**: `make build && scripts/localnet.sh start && scripts/localnet.sh gateway start`, then open the gateway address (default <http://127.0.0.1:8080>).
* **Mock gateway** (`dashboard/mock/server.ts`, plain `node:http`): implements every endpoint the UI uses with rich, fully synthetic, deterministic data
  (4 validators, ~150 blocks and growing live, 24 products / 33 SKUs, 94 sales with promotion steps, returns and refunds in every state, loyalty ledgers with
  reversal and shortfall, 18 rejected transactions, exceptions, governance proposals, a key rotation and revocation, 4 migration reports including a
  trial with a FAIL check). Response shapes follow the real gateway. Switch the failure scenarios while it runs:
  `curl -X POST localhost:8083/__mock/scenario -d '{"name":"degraded"}'` with `normal | degraded | halted | lag | lagbad | rebuilding | empty | down`.
* **Screenshots**: `BASE_URL=http://127.0.0.1:8083 SCALE=2 OUT=screenshots node scripts/screenshots.cjs [name... | =exact-name]` uses the globally installed Playwright
  and Chromium, shows each page in both colour schemes, fails on any console error / page error / failed API call, and (against the mock) also captures the degraded,
  halted, lagging, rebuilding, empty and unreachable states. `EXTRA="name=/path,..."` adds pages.

## Screens and the endpoints behind them

Every page is routed lazily. Tabs, filters and drawers are kept in the URL (`?tab=`, `?id=`, `?row=` ...) so any view is a shareable link.
Projection-backed tables show `as of block N · lag` (from `meta`) discreetly in their footer.

| Screen (route) | Endpoints |
|---|---|
| **Every page** (top bar + footer strip) | `GET /network` and `GET /projection/status`, polled every 3 s: finalised height, indexed height, lag chip (green <= 2, amber 3-10, red > 10 blocks), health chip (`bft.status`), unreachable-gateway banner, halted / degraded / rebuilding / lagging banners |
| **Overview** `/` | `/q/stats`, `/network`, `/q/transactions?status=OK` and `?status=REJECTED`, `/q/inventory/exceptions`, `/q/exceptions?status=OPEN`, `/metrics/latency`, `/q/migration`, `/migration/reports` (polled 5 s) |
| **Network** `/network` | `/network` (validators, BFT numbers, mempool), `/explorer/blocks` (block interval is computed from timestamps), `/q/governance` (upgrade schedule) |
| **Products** `/products` | `/q/products` (q, category, status), `/q/products/{id}` (SKUs, `price_history`, `versions`, provenance, `source_extras`), `/q/skus` |
| **Inventory** `/inventory` | `/q/inventory` (sku, location, `low_stock`), `/q/movements`, `/q/reservations`, `/q/transfers`, `/q/adjustments`, `/q/inventory/exceptions`, `/q/skus` + `/q/locations` (units and names) |
| **Sales** `/sales`, `/sales/:id` | `/q/sales` (`from`/`to` on effective time, location, payment_status, customer), `/q/sales/summary` (day / location / channel), `/q/sales/{id}` (lines, `pricing_steps`, payment events, returns, refunds, loyalty entries), `/q/returns`, `/q/refunds` |
| **Suppliers** `/suppliers` | `/q/suppliers`, `/q/purchase-orders`, `/q/receipts` (outstanding quantities are computed from PO lines) |
| **Prices** `/prices` | `/q/prices` (price book = current / previous / scheduled per SKU x location, derived client-side from the publication history), `/q/promotions` |
| **Loyalty** `/loyalty`, `/loyalty/:id` | `/q/loyalty/accounts`, `/q/loyalty/accounts/{id}` (running balance, reversal <-> original links, shortfall flags), `/q/exceptions?kind=LOYALTY_SHORTFALL` |
| **Migration** `/migration`, `/migration/reports/:id` | `/q/migration` (window, counters vs attested totals, batches), `/migration/reports`, `/migration/reports/{id\|latest}` |
| **Explorer** `/explorer`, `/explorer/block/:h`, `/explorer/tx/:id`, `/explorer/record?key=&height=` | `/explorer/blocks` (paged with `before`), `/explorer/block/{h}`, `/explorer/verify-finality`, `/explorer/tx/{id}?include_proof=1`, `/explorer/proof?key=&height=`, `/explorer/search`, `/q/history`, `/q/transactions` |
| **Administration** `/administration` | `/q/governance` (proposals, upgrades, members, parameters, events), `/q/identities` (keys + grants), `/network`, `/projection/status`, `GET /projection/verify?proofs=20`, `POST /projection/rebuild` |

`/chain/*`, `/tx/*` and `POST /tx/submit` are deliberately unused: reads for the Explorer go through `/explorer/proof`, and the console never submits.

## Design notes

* **Audience and language.** Retail screens speak business: *on hand*, *reserved for orders*, *available to sell*, *in transit*, *quarantined / damaged*;
  a sale shows **three separate statuses** (sale / payment / fulfilment); refunds are **instructed** (we asked the provider) versus **confirmed** (the provider
  confirmed). Blockchain vocabulary (blocks, hashes, validators, proofs, finality, app hashes) appears only on **Network** and **Explorer**, plus the footer strip and links
  such as "View on chain".
* **Effective vs recorded time.** Sales filter on the *effective* time (when it happened at the till); the table shows *Recorded in block at* separately, and a tooltip explains that
  they differ for offline tills, queued uploads and imported history.
* **Provenance.** `NATIVE` / `IMPORTED` chips everywhere; imported records show source id, batch, mapping version and snapshot, and every migration surface states that
  *imported history is the legacy system's assertion*. Preserved `source_extras` are listed per product / SKU. Migration reports are labelled TRIAL (amber, "does not change which
  system is authoritative") or PRODUCTION, show the SOURCE -> FROZEN -> CHAIN stage, per-check PASS / WARN / FAIL with source vs ledger deltas, exceptions with dispositions,
  unsupported fields and batches.
* **Proofs.** The record view shows membership / non-membership, the ICS23 proof facts, header verification, the gateway's step-by-step explanation and the fixed caveat:
  *"A proof only establishes inclusion of that key/value in a committed state root, not business correctness or completeness of a search."*
  "State at height" provides record time travel; `/q/history` renders an audit timeline with field-level diffs.
* **States.** Every query has loading, empty and error states (`QueryBoundary`). A polled query that has failed keeps showing its error rather than flickering back to a skeleton.
  Gateway down => red banner + `UNREACHABLE` chip + last-known figures. Halted => red banner explaining halt-not-fork; degraded and rebuilding => amber banners.
* **Tables.** `DataTable`: sortable columns (`aria-sort`), local filter, pagination, keyboard-operable rows, horizontal scroll with edge shadows, server `total` note when more rows exist than were loaded (max 500 per request).
* **Theming and accessibility.** CSS custom properties on `:root`; dark values are declared for `prefers-color-scheme` *and* the manual toggle (`data-theme`, remembered in `localStorage`
  inside try/catch). Focus rings, skip link, ARIA tabs with arrow keys, focus-trapped drawers and dialogs (Esc closes), tooltips on focus, SVG charts with `role="img"` and a hidden data table.
  Chart colours use the validated categorical blue / orange pair; status colours are reserved for status and always carry a label.
* **Responsive.** Full sidebar above 1024 px, icon rail from 1024 down to 761 px (tablet), off-canvas menu below that; two-column grids collapse at 1000 px.
* **Polling.** 3 s for the chain-status context (every page), 5 s on Overview, 3 s for blocks on Network / Explorer; other screens fetch on demand (Refresh buttons, 15 s stale time).
* **Money and quantities.** Integer minor units formatted exactly (no floating point); quantities are formatted from the SKU's smallest step (`KG` grams, `L` ml, `M` mm).
  Unit tests cover `formatMoney`, `formatQty`, times, BFT arithmetic, status mapping and the response normalisers.

## What was verified where

* **Mock gateway** (`npm run mock`): all pages and drawer states in light and dark, spot-checked at tablet width (820 px), and the failure scenarios; zero console errors; 82 unit / smoke tests; click-through script.
* **Real gateway** (4 validators on ports 29600+, gateway on 8083 serving `dashboard/dist`, seeded with the SDK demo steps 2-10 plus synthetic migration reports POSTed to
  `/migration/reports`): every page loads without console errors or failed API calls, deep links resolve through the SPA fallback, the interaction script passes
  (including real light-client finality verification, a real ICS23 proof with time travel, projection verify and a real projection rebuild), and stopping one and then two validators shows
  DEGRADED and then HALTED (and the recovery) correctly. Not exercised on the real chain: a real migration (imported provenance, `source_extras`, imported opening balances) because the Python migration tool
  was out of scope; those screens are covered by the mock.

## Gateway contract notes (found while verifying; `API.md` was not edited)

The UI accepts both the documented shape and what the real gateway returns. Differences worth reconciling in `API.md` or the gateway:

1. `GET /explorer/block/{h}`: no `app_hash`, `num_txs`, `num_rejected`, `size_bytes`; instead `header_app_hash`, `state_app_hash_after_block`, `proposer_address`, and `txs[]` with `index` and `size` (`code` is absent if block results are unavailable).
2. `GET /explorer/proof` returns `{record: {...}, explanation: ["1. ...", ...]}` (not the record at the top level); `explanation` strings are already numbered.
3. `GET /explorer/tx/{id}`: `type` / `signer` / `tx_id` live under `body` (and `record`), height / index are top-level `height` / `index` (no `inclusion` object), `signature_check` (not `signature`), `records_changed` is `[{op, key}]`.
4. `GET /explorer/verify-finality`: no `trusted_height` or `app_hash_next_header`; has `block_hash`, `header_app_hash`, `note`.
5. `GET /explorer/search` returns `{query, results: [{type: "block|record|tx", ref}]}` and only recognises a numeric height, a key containing `/`, or `tx-` / 64-char ids.
6. `GET /network`: `chain.block_interval_ms_avg` is not returned (the UI derives the interval from block times); `validators[].last_signed_height` is `0` for any validator that is not among the signatures of the *latest* commit even when healthy (a commit only needs > 2/3), so it cannot be read as "stopped signing".
7. `GET /q/stats` keys: `sales_24h`, `sales_net_minor_24h`, `transactions_total`, `transactions_rejected_24h`, `units_on_hand`, ... (no `sales_today`, `tx_total`, `rejected_tx_24h`); the body is wrapped in `item`.
8. `GET /q/governance` and `GET /q/migration` wrap their content in `item`. Governance `events[]` are `{height, tx_id, tx_type, signer, block_time_ms, key, summary}` and cover every membership / proposal / identity / grants / upgrade version change (not only key changes).
9. `GET /q/products` and `/q/products/{id}`: SKU records are in `sku_details`; `skus` stays a list of ids. `GET /q/transactions` rows use `tx_id` and `index_in_block`.
10. `GET /q/loyalty/accounts/{id}`: `item.entries` is the entry array and shadows the account's `entries` count.
11. `GET /projection/status`: `last_indexed_block_time` (not `last_block_time`); `rebuild.started_at` is the zero time `0001-01-01T00:00:00Z` when never rebuilt. `GET /projection/verify`: `projection_entries` / `chain_entries` (not `entries`), plus `statement` and `proof_failures`.
12. `GET /q/inventory/exceptions`: `ref` is a plain record id (e.g. `XFER-0002`), not a state key. `GET /q/sales?to=` is exclusive (`eff_ms < to`).

## Layout

```
dashboard/
  index.html  vite.config.ts  tsconfig*.json  package.json (exact pins)  .npmrc
  src/
    main.tsx App.tsx            providers + lazy routes
    api/                        client (fetch, ApiError, normalisers), hooks (useApi), chainStatus (global polling), refdata (units, names), types
    lib/                        format (money, qty, time, BFT math), status (business labels, tones), normalize, labels, hooks
    ui/                         Chip, DataTable, Drawer/ConfirmDialog, Tabs, Tip, Card/KPI/KV, Charts (SVG), States, Stages, Meta (staleness)
    layout/Shell.tsx            sidebar, top bar, footer strip, banners
    pages/                      Overview Network Products Inventory Sales SaleDetail Suppliers Prices Loyalty Migration MigrationReport Explorer Administration
    styles/app.css              tokens, light + dark, components, responsive
    test/                       vitest setup + fetch-stub helpers (tests sit next to the code: *.test.ts[x])
  mock/                         data.ts (synthetic dataset), server.ts (gateway mock + scenarios)
  scripts/                      screenshots.cjs, interactions.cjs
  screenshots/                  final screenshots (mock at 2x; real-gateway/ from the real stack)
```
