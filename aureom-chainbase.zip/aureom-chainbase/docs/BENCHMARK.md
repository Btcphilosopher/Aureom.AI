# Benchmark: defined retail workload (measured) and trade-offs

**Everything in the result tables is measured** by `scripts/benchmark.sh` (raw JSON in `docs/benchmark-results/`). Sections marked *Estimate* are reasoning, not measurements.

## 1. Environment

* Hardware: Intel(R) Xeon(R) Processor @ 2.10GHz, 4 logical CPUs, 15 GB RAM, `linux/amd64`, Go `go1.26.0`; a single virtual machine (shared-tenancy cloud sandbox).
* **All four validators, the load generator and the SQLite baseline ran on this one machine** over loopback TCP. Each validator therefore had roughly one core shared with the others and with the load generator (which also signs every transaction). Results are a floor for this hardware class, **not** a prediction for four separate hosts, and say nothing about WAN latency.
* Validators: 4 × CometBFT v0.38.25 + the Go state machine, equal voting power (n=4, f=1), `timeout_commit` as stated per run, empty blocks enabled, tx indexer `kv`, default mempool, LevelDB for blocks/state/IAVL, persistent state at every height retained (no pruning), ed25519 signature verification in CheckTx **and** again in execution, block max 4 MiB.
* Load generator: `bin/bench net` — closed loop: *W* concurrent POS workers, each running whole baskets sequentially and waiting for **finality** of every step (finality observed via the NewBlock event of validator 0; submissions round-robin across the four validators' RPC).

## 2. Workload (retail basket)

One basket = 1–3 `ReserveStock` (one per line, submitted in parallel, qty 1–2) → `CompleteSale` (consumes the reservations atomically, prices lines, posts movements) → `RecordPaymentResult` (simulated payment confirmation) → `CreditLoyalty` for ~60 % of baskets → for ~6 % of baskets a return flow: `RequestReturn` → `ApproveReturn` → `ReceiveReturnedGoods` (RESELLABLE) → `RecordRefundResult`. Stores alternate between STORE-N-01 and STORE-S-01; 50 SKUs; stock pre-loaded (not measured). Every transaction is signed by the proper role-holding identity and passes the full pipeline (no shortcuts); **0 rejected transactions in all runs**.

| transaction type | share of mix | avg wire bytes | max wire bytes |
|---|---:|---:|---:|
| ReserveStock | 41.6 % | 639 | 639 |
| CompleteSale | 20.8 % | 936 | 1059 |
| RecordPaymentResult | 20.8 % | 705 | 707 |
| CreditLoyalty | 12.3 % | 581 | 583 |
| ApproveReturn | 1.1 % | 538 | 539 |
| ReceiveReturnedGoods | 1.1 % | 599 | 599 |
| RecordRefundResult | 1.1 % | 694 | 695 |
| RequestReturn | 1.1 % | 622 | 623 |

Wire bytes = the whole JSON envelope including the base64 body, 64-byte signature and public key. (Average over the mix ≈ 700 bytes.)

## 3. Network results (4 validators)

Finality latency = client submit → block containing the tx observed committed (includes mempool admission, proposal, two voting rounds and the `timeout_commit` wait; quantised by the block interval). Throughput counts finalised transactions per second over the whole step (including the tail while the last baskets drain).

| block interval | workers | tx/s | baskets/s | finality p50 | p95 | p99 | max (ms) | admission p50 / p99 (ms) | txs/block | rejected |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 s | 16 | 13 | 2.7 | 1298 | 1312 | 1315 | 1317 | 2 / 11 | 16 | 0 |
| 1 s | 64 | 52 | 10.6 | 1278 | 1330 | 1349 | 1367 | 4 / 42 | 65 | 0 |
| 1 s | 256 | 209 | 43.5 | 1162 | 1388 | 1473 | 2091 | 14 / 206 | 259 | 0 |
| 1 s | 512 | 239 | 49.8 | 2208 | 2553 | 2646 | 2741 | 21 / 430 | 301 | 0 |
| 1 s | 1024 | 321 | 66.2 | 2886 | 3957 | 4988 | 5148 | 164 / 997 | 416 | 0 |
| 1 s | 2048 | 330 | 68.5 | 6650 | 8702 | 9045 | 9414 | 437 / 1423 | 582 | 0 |
| 500 ms | 16 | 22 | 4.6 | 798 | 825 | 887 | 891 | 2 / 11 | 17 | 0 |
| 500 ms | 64 | 88 | 18.1 | 774 | 843 | 1274 | 1278 | 4 / 41 | 67 | 0 |
| 500 ms | 256 | 189 | 39.6 | 1446 | 1740 | 1788 | 1801 | 11 / 203 | 147 | 0 |

**Reading it.** Under light load finality is ≈ 0.8 s (500 ms blocks) or ≈ 1.3 s (1 s blocks). Throughput rises with offered concurrency until the machine saturates at roughly **330 finalised tx/s (≈ 55–70 baskets/s)** at block interval 1 s; beyond that extra workers only add queueing (latency grows, throughput stays flat: 1024 → 2048 workers 321 → 330 tx/s). The plateau is consistent with CPU saturation of a shared 4-vCPU VM (every validator verifies and executes every transaction, plus gossip, mempool re-checks and indexing, and the load generator signs on the same cores); CPU was not profiled per process, so treat that as the likely, not proven, cause.

## 4. Storage growth (measured with `du -sb` of each validator's `data/` before/after each step)

| run | workers | tx finalised | growth / validator | bytes per tx per validator |
|---|---:|---:|---:|---:|
| 1 s | 16 | 497 | 9.1 MB | 18380 |
| 1 s | 64 | 2087 | 13.4 MB | 6440 |
| 1 s | 256 | 8275 | 47.0 MB | 5674 |
| 1 s | 512 | 9938 | 58.5 MB | 5887 |
| 1 s | 1024 | 14146 | 76.6 MB | 5414 |
| 1 s | 2048 | 18056 | 96.0 MB | 5317 |
| 500 ms | 16 | 797 | 8.6 MB | 10730 |
| 500 ms | 64 | 3137 | 22.2 MB | 7082 |
| 500 ms | 256 | 6900 | 43.3 MB | 6269 |

At load the cost converges to **≈ 5.3–5.9 KB per transaction per validator** against ≈ 0.7 KB of wire data (≈ 8×): block store (tx + commit signatures), CometBFT's saved block results (which here include one event per state write so projections can be rebuilt), the tx index, and the IAVL tree with **every version retained** (copy-on-write path nodes). Low-load rows are inflated by empty blocks (one per block interval, each recording block time) and LevelDB write-ahead-log preallocation. The engine-only run (state tree only, no block store/results) used 85 MB for 80000 tx ≈ 1058 bytes/tx.

## 5. Engine-only and conventional-database baselines (measured, same machine, no consensus)

| run | result |
|---|---|
| State machine + IAVL + LevelDB through the ABCI interface (`bench engine`, 20000 baskets in dependency stages, 2000 tx/block, includes signature verification and every authorisation check, 0 rejected) | **1688 tx/s** single-threaded execution |
| Single-node SQLite, one commit per basket, `synchronous=FULL`, WAL, equivalent row writes (13 statements/basket; **no signatures, no authorisation engine, no history/proofs, no replication**) | 2229 baskets/s ≈ 8914 tx-equivalents/s |

The engine number is the ceiling a validator can sustain per core when it only executes; the network result (≈ 330 tx/s) is lower because four validators share four cores with the load generator and because consensus, gossip, mempool re-checks and indexing sit on top. The SQLite figure is context for *what is being paid for* — it is not a like-for-like comparison.

## 6. Trade-offs relative to a conventional database

**Throughput.** A replicated deterministic state machine executes one agreed total order **sequentially on every validator** (no parallel speed-up from adding validators; more validators only add messages). Each transaction is also verified (signature, identity, authorisation) before execution. Measured: ~1.7 k tx/s executing alone (1.6-1.8 k across runs), ~330 tx/s with four validators on four shared cores, vs ≈ 8.9 k statement-equivalent tx/s for a single SQLite writer doing the same row work without any of those properties. A conventional replicated SQL cluster with one writer would sit in between; a conventional DB scales reads with replicas, a chain scales reads with projection/observer nodes but not writes. For a retail group the *business* load (peak few hundred POS tx/s across all stores, most of which can be batched/pre-allocated) is within what a well-provisioned 4–7 validator network on dedicated hosts can serve; very high-volume event streams (every scan, every price-tag read) should stay off-chain.

**Latency.** Finality is never below the block interval; expect ≈ interval + 1–2 s. A conventional DB commit is milliseconds. Interactive POS flows should therefore use pre-allocated reservations/allowances and treat the chain as the system of record that finalises within ~1–3 s, not as a per-keystroke store (the offline-terminal design assumes this).

**Storage.** ≈ 5–6 KB per transaction per validator (measured) with full history and proofs, replicated N times (N=4 here) and retained forever unless pruning/archival is designed — versus ≈ 0.5–1 KB per equivalent transaction in a normalised SQL schema (SQLite baseline above: ≈ 470 B per basket of 4 tx, incl. indexes). *Estimate:* 100 M transactions/year → ≈ 0.55 TB/year per validator at this amplification; plan pruning of block results / event data (not the IAVL history needed for proofs) and archive tiers.

**Privacy.** Every validator holds all plaintext records and the full history; a conventional DB can restrict by row/column and delete. See `docs/PRIVACY.md`: the privacy-conscious profile keeps identifying data off-chain, at the cost of more moving parts and weaker joins.

**What you buy:** one agreed history across organisations that do not trust one another's databases, finality, tamper-evidence (Merkle commitments verified by a light client), deterministic replay/rebuild of every index, and enforced business rules shared by all parties.

## 7. Estimates (not measured)

* Dedicated hosts (1 validator per 4+ cores) should raise sustainable throughput toward the engine-bound ~1–1.8 k tx/s per validator minus consensus/gossip overhead — *not measured here*.
* Cross-region validators add network RTT to every consensus round: *estimate* finality ≈ block interval + 3–4 × inter-validator RTT (e.g. ≈ 1.5–2.5 s at 150 ms RTT) — *not measured*.
* Larger validator sets (7, 10) reduce fault-domain risk but increase vote/gossip cost — *not measured*.

## 8. Reproduce
```bash
scripts/benchmark.sh 30s 16,64,256 1s        # also: 30s 512,1024,2048 1s ; 30s 16,64,256 500ms
python3 scripts/benchmark_report.py          # regenerates this file from docs/benchmark-results/*.json
```
