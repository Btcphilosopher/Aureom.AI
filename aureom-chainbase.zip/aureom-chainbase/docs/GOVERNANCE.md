# Governance: membership, keys, privileged roles, parameters and upgrades

All governance actions are **on-chain proposals**, recorded forever with proposer, approvals, approval height, activation height, execution height and result.

## Rules
* `ProposeGovernance` needs permission `gov.propose` (roles `org-admin`, `hq-admin`); `ApproveGovernance` needs `gov.approve` (`org-admin`).
* One vote per **organisation**; an organisation's weight is the sum of the voting power of its active validators. A proposal is APPROVED when approving organisations hold **more than 2/3** of total validator power (3 of 4 equal validators).
* Every proposal carries an explicit **`activation_height`**. Minimum lead: `min_gov_delay_blocks` (3) for membership/roles/params; `min_upgrade_delay_blocks` (10) for upgrades. An approval that arrives when the activation height is too close is refused (re-propose later) — nothing activates late or early.
* Execution happens at the **start of block `activation_height`** (before that block's transactions) in `RunBlockStart`; failures (e.g. removal that would leave fewer than `min_validators`) mark the proposal `FAILED` with the reason and change nothing.
* Kinds: `ADD_VALIDATOR`, `REMOVE_VALIDATOR`, `ROTATE_VALIDATOR_KEY`, `ADD_OBSERVER`, `REMOVE_OBSERVER`, `GRANT_PRIVILEGED_ROLE`, `REVOKE_PRIVILEGED_ROLE`, `SET_PARAMS`, `SCHEDULE_UPGRADE`.
* Privileged roles (`hq-admin`, `org-admin`, `migration-operator`, `finance-controller`) can **only** be granted/revoked this way (a plain `GrantRole` is refused with `POLICY_VIOLATION`). Ordinary roles (cashier, manager, buyer, ...) are granted by `hq-admin` with `GrantRole` + scope (`*`, `loc:<id>`, `region:<name>`).

## Validator and node procedures
**Add an observer node** (non-voting, replays the chain, can serve reads):
```bash
bin/chainctl newnode --net run/net --name obs1 --mode observer --p2p-port 26700 --rpc-port 26701     # prints node_id
# propose + approve ADD_OBSERVER {member_id, org, node_id} with activation height >= head+3 (3 org admins)
# after the activation height, START (or restart) the node: scripts/localnet.sh start-node obs1  (NODE_HOME=... )
```
**Add a validator:** the new organisation generates its keys *itself* (`chainctl newnode --mode observer` creates `priv_validator_key.json`/`node_key.json`; `chainctl show-keys --home H` prints `node_id` + `consensus_pubkey_b64`),
sends only those two public values; existing organisations propose `ADD_VALIDATOR {member_id, org, role, pubkey_b64, node_id, power}`. At the activation height the node id enters the peer allow-list and a validator update is returned;
the new validator **joins consensus two blocks later**. It must already be running and caught up (start it right after activation; it block-syncs the chain).
**Remove a validator:** `REMOVE_VALIDATOR {member_id}`; refused at execution if fewer than `min_validators` (4) would remain — three validators cannot tolerate any fault (`n >= 3f+1`, `f = 1`).
Powers/changes are applied one proposal per block-start; keep each change ≤ 1/3 of total power (CometBFT light-client assumption) — the rotation procedure below respects this.
**Rotate a validator consensus key** (two-phase, never drops below quorum): `ROTATE_VALIDATOR_KEY {member_id, new_pubkey_b64, new_node_id?}`. At activation the new key is **added** (same power) and the old key is **retired 20 blocks later** automatically.
In the overlap window the operator swaps `priv_validator_key.json` and restarts. Until the swap the validator signs with the old (still valid) key. Caveat: in the overlap, total power is higher, so one extra failure is less tolerable.

## Business identity keys
* `RegisterIdentity` (`iam.admin`) creates an identity with its first key; `RotateKey` — by the identity itself (signed with the key being retired) or by an `iam.admin` for lost-key recovery; `RevokeKey` — identity or admin. Key history (ACTIVE / ROTATED / REVOKED with heights) is preserved in the `iam/id/<id>` record and visible in the dashboard Administration page and in `/api/v1/q/history`.
* Effective immediately in block order: a revoked key signs nothing after the block that finalises the revocation (`TestKeyRotationAndRevocation`).
* Terminal identities (`kind=TERMINAL`) are bound to one location; a terminal key stolen from a store cannot sell elsewhere.

## Software upgrades (state-machine versions)
* The binary lists the versions it can execute (`core.supportedRules`: 1 and 2; v2 = demonstration rule set that doubles loyalty earn). The active version is in state (`meta/appver`) and in each block header (`Version.App`).
* `SCHEDULE_UPGRADE {version}` with `activation_height` A (≥ head + 10): after approval it is recorded in `gov/upgrade/<v>`; at the end of block **A−1** the app switches the version and reports it to CometBFT; **block A is the first executed under the new rules**.
* **Incompatible binaries cannot silently diverge:** at the end of block A−1 a binary that does not support the version returns an error and **halts** (`FinalizeBlock` panics: "HALT"). The same check runs at every block start, so restarting an old binary after the upgrade also refuses to execute. (`TestUpgradeActivationAndFailClosed`; simulate an old binary with `CHAINBASE_MAX_STATE_VERSION=1`.) With ≥ 3 of 4 upgraded the chain continues; the old node stops until upgraded and then replays.
* Procedure: (1) ship the new binary to all organisations; (2) agree an activation height with margin for deployment; (3) propose, approve; (4) every organisation deploys *before* A; (5) verify `chain/info.app_version` after A; (6) in-flight transactions are unaffected because rules are selected per block.
* Data-schema changes: `schema_version` is checked per transaction (currently 1); a new schema version needs a state-machine version that accepts it.
