# Privacy, retention and the two operating profiles

> A replicated, append-only ledger is the wrong place for personal data. The prototype therefore uses **synthetic data only**, enforces synthetic/pseudonymous
> customer references in validation, and documents a design that keeps identifying data off-chain.

## Who can read replicated data
All validators (and their operators, backup holders, cloud providers, anyone with RPC access to a validator, and every full/observer node) hold **plaintext** state and
every transaction ever submitted. Gateway/dashboard permissions and on-chain roles do not hide anything from them. Once a record is finalised it is replicated to
every validator and every backup; it cannot be recalled.

## Profile A — Strict on-chain demonstration (implemented)
* Every structured business record and every change is on-chain, in plaintext.
* Customer identifiers must match `CUST-xxxx` or `PSN-xxxx` (letters/digits). Values such as e-mail addresses, phone numbers or names are rejected by validation (`TestLoyaltyRedeemReverseShortfall`, `TestMigrationRejectsRealPersonalIdentifiersAndBadRecords`).
  This is a **guard rail for the prototype**, not a privacy proof: a free-text field (`reason`, `evidence_ref`, attributes) could still carry personal data; those fields are length-limited printable ASCII and must be policy-controlled.
* Appropriate only for synthetic data, or for data that is already shared among all validators' organisations and has no erasure/retention obligations (e.g. product, price, stock and store transaction facts that contain no personal data).

## Profile B — Privacy-conscious deployment (design; implemented pieces: references, evidence refs, pseudonymous ids, adapters outside the chain)
| Data | Where it lives | What goes on the ledger |
|---|---|---|
| Customer identity, contact details, addresses, payment instrument details | CRM / identity vault under the retailer's data-protection regime | a **pseudonymous reference** (random id, not derived from the person) and loyalty points |
| Large documents: invoices, delivery notes, photos, signed PDFs | object store / DMS with retention and access control | document id + **salted hash commitment** (`evidence_ref`) proving the document existed in that form |
| Card/payment data | payment provider (PCI scope stays there) | provider reference (`provider_ref`) and result only |
| Employee data | HR system | signing identity ids (pseudonymous) + roles |
| Business facts: SKU, quantities, prices, location, timestamps, statuses | chain | everything |

Design rules:
1. **Minimise** — put only what the multi-party process needs to agree on. Anything that could identify a natural person stays off-chain.
2. **Pseudonymous references must be random**, not derived from personal data. A hash of a *predictable* value (phone number, e-mail, name+postcode) is **not anonymous**: it can be reversed by enumerating candidates, and it remains linkable across records. Where a commitment to personal data is unavoidable use a **per-record random salt held off-chain** (and accept that the commitment itself is personal data if the holder can re-identify).
3. **Erasure/right-to-be-forgotten:** deleting the off-chain record and the salt breaks the link from the pseudonym to a person *for those who only have the chain*; the on-chain pseudonymous history (purchases at a store, points) remains. Whether that satisfies erasure obligations is a legal question for the specific deployment — obtain advice **before** proposing immutable storage of any data derived from individuals.
4. **Retention:** on-chain data has *infinite* retention by design; therefore no data whose retention must be limited may be placed on the chain.
5. **Encryption on-chain** (e.g. per-field encryption with keys held by one party) is possible but **deleting a key does not guarantee removal of previously disclosed information**: ciphertext is replicated and may be copied; plaintext may already have been decrypted, cached or observed; future cryptanalysis or key leakage could expose it. Treat key deletion as a reduction of future exposure, never as a deletion guarantee.
6. **Selective disclosure** to auditors: share Merkle proofs + the off-chain documents whose salted hashes match; remember a proof shows only inclusion.
7. **Access to the chain itself** is itself a privilege: restrict RPC, run validators in controlled environments, and consider channel/segregated-chain designs if different participants must not see each other's data.

## Retention and operational notes
* Backups of validators contain everything. Treat them as production data.
* The SQLite projection and gateway logs contain the same plaintext as the chain: same handling.
* The migration tool must **not** import real customer identity: map customers to pseudonymous references before import; the importer validates `CUST-`/`PSN-` patterns and preserves unsupported source fields only as explicit `source_extras` (which must be reviewed for personal data before import — the migration report lists them).
