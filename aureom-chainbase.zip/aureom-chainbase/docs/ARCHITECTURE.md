# Architecture

## 1. What "pure blockchain database" means here

AUREOM CHAINBASE is a *replicated state machine*. The blockchain is the **authority** for business state; every
other component is a projection of it or a client of it.

| Principle | How it is implemented |
|---|---|
| Business mutations are signed transactions | `chain/internal/core/tx.go`: ed25519-signed envelopes; 33 typed transactions (`docs/TRANSACTIONS.md`). No other write path exists: there is no admin SQL, no back door in the gateway. |
| Validators agree on ordering | **CometBFT v0.38.25** (Tendermint BFT) orders transactions; blocks are final when committed by > 2/3 of voting power. We did not write a consensus algorithm. |
| A deterministic state machine validates and applies | `core.ExecuteBlock` is the single definition of the state transition. It is used by the validators (through ABCI), by the offline replay verifier, by the tests and by the benchmark. |
| Finalised blocks carry history and state commitments | Blocks contain the transactions; each header `app_hash` is the root of an IAVL Merkle tree over the whole business state (the root for the state produced by block *N* is in header *N+1*). |
| Current state is derived from finalised transactions | `app` keeps state in an IAVL tree; nothing is written that is not the result of executing a finalised block. `chainctl replay` re-executes the whole chain from genesis on a fresh in-memory node and compares every root. |
| Nodes recover by replaying | A node with an empty data directory block-syncs from peers, re-executing every block (tested: `TestAgreementToleranceAndRebuild`). |
| Indexes and caches are disposable | The SQLite query projection is built only from finalised blocks, can be deleted at any time and is rebuilt from genesis (`POST /api/v1/projection/rebuild`), and is verified against the chain by digest and Merkle proofs (`GET /api/v1/projection/verify`). |

**What we deliberately did not do:** keep a conventional database as the real authority and anchor hashes on a
chain. There is no relational store that validators write business facts to. Physical storage still exists —
LevelDB holds CometBFT's blocks and our IAVL state on each validator, SQLite holds the *disposable* projection —
but the difference is **who has authority, how agreement is reached and how state transitions are defined**:
authority is the agreed, signed, ordered transaction history; storage engines merely persist it.

## 2. Components

```
  POS / ERP / WMS / e-commerce / payment adapters  (sdk/, Python migration tool)
        │ signed tx (JSON envelope, ed25519)                      ▲ authenticated external results
        ▼                                                          │  become NEW signed transactions
  ┌──────────── gateway (Go) ─────────────┐  rate limit, size limit, relays; reads + ICS23 proof checks;
  │  /tx/submit  /chain/*  /explorer/*    │  light-client (finality) verification; migration reports
  │  /q/* (projection)   dashboard (React)│
  └───────┬───────────────────────┬───────┘
          │ CometBFT RPC          │ ingests finalised blocks (events) ── SQLite projection (disposable)
          ▼
  ┌──────── validator node (chaind) ───────────────────────────────────────────────┐
  │ CometBFT: p2p (authenticated, encrypted, allow-listed), mempool, consensus, blockstore (LevelDB)
  │   ▲ ABCI 2.0 (in-process): CheckTx / PrepareProposal / ProcessProposal / FinalizeBlock / Commit / Query
  │ app: core state machine + IAVL tree on LevelDB  (state at EVERY height retained → time travel, proofs)
  └──────────────────────────────────────────────────────────────────────────────────┘
  ×4 independently configured validators: HQ, Distribution, Regional North, Regional South
```

### Transaction lifecycle
1. Client builds a body (`tx_id`, `network_id`, `type`, `signer`, `key_id`, `idempotency_ref`, `expected_version`, payload ...) and signs
   `"AUREOM-CHAINBASE/TX/v1" 0x00 network_id 0x00 body`.
2. `CheckTx` (mempool admission) runs stages 1–5 (below) against committed state. `broadcast_tx_sync` returning OK means *admitted*, **not final**.
3. The proposer includes it in a block; all validators execute it with `core.ExecuteBlock` in the same order.
4. >2/3 of voting power commits the block. Finality is immediate (no probabilistic confirmations, no reorgs).
5. The result code and the tx outcome record (`tx/<id>`) are part of state / block results.

### Validation stages (cryptographic validity is separate from authorisation)
1. structure, size, network id, schema, known type — `MALFORMED / TOO_LARGE / WRONG_NETWORK / UNKNOWN_TYPE / UNSUPPORTED_SCHEMA`
2. **cryptographic validity** — ed25519 signature over the exact signed bytes — `BAD_SIGNATURE`
3. **identity** — signer registered, key id active and equal to the presented public key, not expired — `UNKNOWN_SIGNER / KEY_INACTIVE / EXPIRED`
4. **replay** — `tx_id` never seen; `idempotency_ref` not already executed by this signer — `REPLAY / DUPLICATE_IDEMPOTENCY`
5. **business authorisation** — role + location scope (+ terminal binding) for the permission the transaction type requires — `UNAUTHORIZED / SCOPE_VIOLATION`; approval policies (maker-checker, value limits) — `POLICY_VIOLATION`
6. business validation and atomic execution on a write overlay — `NOT_FOUND / INSUFFICIENT / VERSION_CONFLICT / INVALID_STATE / LIMIT_EXCEEDED ...`

A correctly signed transaction can therefore still be prohibited (stage 5/6): it is *included in the block* and recorded as `REJECTED` with the reason
(audit), but changes no business state. Stage 1–3 failures leave no trace in state (so an attacker cannot burn someone's `tx_id`).

### Determinism rules (why four validators agree)
The state machine uses no wall clock (only block-header time), no randomness, no floats (integer minor units / integer scaled quantities, half-even rounding
with big integers), no goroutines, no map iteration on execution paths (all iteration is over slices / sorted keys), no network or file access, and bounded
work per transaction (line limits, string limits, bounded promotion lists, no unbounded scans — lists are explicit bounded records). The balance/movement
code path is the only way quantities change. `Commit` panics if the committed IAVL hash differs from the hash returned by `FinalizeBlock`. Tests:
`TestDeterministicReplay`, `TestAgreementAcrossExecutors`, `TestRestartRecovery`, `TestCrashBeforeCommitReplaysIdentically`, and the multi-process agreement test.

### Concurrency control (inventory)
All validators agree one total order; the state machine executes it sequentially. A reservation moves units `available → reserved` only if
`available >= qty` *at that point of the order*, so two competing reservations for the last unit cannot both succeed (the loser is finalised in the block as
`INSUFFICIENT`). `expected_version` provides optimistic concurrency on records (e.g. pin a balance version; adjustments are bound to the balance version at count time).
Reservation → sale is one atomic transaction (`CompleteSale` consumes reservations, prices lines, posts movements and writes the sale or does nothing).

## 3. Data model (chain-native entities)
Products + SKU variants, locations (stores / warehouses), suppliers, purchase orders, goods receipts, inventory **movements** (an append-only ledger; balances are derived
only by applying movements), balances (`available`, `reserved`, `quarantined`, `damaged`, plus per-transfer `TRANSIT:<id>` holding locations for in-transit stock),
reservations, sales with lines (sale / payment / fulfilment statuses kept separate), payments (instruction vs adapter-confirmed events), returns with inspection outcomes,
refund instructions and confirmations, prices (location × currency × effective period) and promotions (deterministic precedence), loyalty accounts and entries,
stock adjustments (maker-checker), transfers (dispatch / receipt), exceptions, identities / keys / role grants, governance members / proposals / upgrades, migration state.
All records carry `version`, `schema_version`, created/updated height and transaction ids. Money is integer minor units with an explicit currency table;
quantities are integers in the unit's smallest step with an explicit unit (`EA`, `PK`, `KG` = grams, `L` = ml, `M` = mm).
Business-effective time (`effective_at_ms`) is stored separately from block time (`block_time_ms`); block time only bounds plausibility
(`MaxFutureSkewMs`, `MaxBackdateMs`) and is **not** proof of when the real-world event happened.

Inventory conservation: every movement has two sides (a real or pseudo location such as `EXT:SUPPLIER`, `EXT:CUSTOMER`, `EXT:ADJUST`, `EXT:MIGRATION`,
`TRANSIT:<id>`), so the sum of all balances over all locations is zero for every SKU, and every physical balance equals the replay of the movement ledger
(`checkInvariants` runs after every block of the fuzz tests). Physical locations can never go negative.
**The chain records what authorised parties assert. It cannot know whether a warehouse really received the goods** — physical discrepancies are
recorded as approved adjustments, and a short transfer receipt leaves the remainder "in transit" until an approved write-off.

## 4. Operating profiles

| | **Strict on-chain demonstration** (implemented) | **Privacy-conscious deployment design** (design + guard rails) |
|---|---|---|
| Records on the ledger | all structured synthetic business records and every change | business facts and commitments only |
| Customer data | synthetic ids only (`CUST-…`/`PSN-…`); real-looking ids such as e-mail addresses are rejected by validation | pseudonymous references; identifying data stays in an off-chain system of record (CRM / identity vault) under normal retention and erasure processes |
| Large documents (invoices, delivery notes, photos) | not stored | stored off-chain; chain holds a reference id and a **salted** hash/commitment (`evidence_ref`, `provider_ref`) |
| Who can read | every validator holds plaintext | validators hold only pseudonymous facts; API-level permissions control the dashboard, **not** validator operators |
| Erasure | impossible (append-only, replicated) | possible only for the off-chain data; on-chain pseudonyms and salted commitments remain |
| Hashes | n/a | never described as anonymous: a hash of a predictable value (phone number, e-mail, postcode+name) can be reversed by guessing; use per-record random salts kept off-chain |

Deleting an encryption key does **not** guarantee removal of previously disclosed information: ciphertext that was already replicated may be
copied, the plaintext may have been seen by validators/operators or cached, and key deletion does nothing about what was decrypted earlier. Treat
crypto-shredding as one control that reduces future exposure, not as a deletion guarantee. See `docs/PRIVACY.md`.

## 5. Query & read paths
* **Authoritative**: ABCI queries on a validator: `/key` (value + ICS23 proof, any retained height), `/prefix` (paginated scan), `/digest`, `/info`.
  `GET /api/v1/chain/record?key=…&height=…&prove=1` returns the value and verifies the proof against the app hash in a header that the gateway has verified
  with the CometBFT **light client** (trust root = genesis validator set; witnesses = the other validators).
  A verified inclusion proof establishes that this key/value is in the finalised state — **not** that the business fact is true, and not that a *list or
  search result* is complete (absence is shown only by a non-membership proof for a specific key).
* **Projection** (disposable SQLite): search/filter/report endpoints, with `indexed_height`, `chain_head`, `lag_blocks` on every response and
  `?min_height=H&wait_ms=…` / `wait: "indexed"` for read-after-write. Completeness is checked by `projection/verify`: SHA-256 digest over *every* (key,value) in
  key order compared with the validator's digest of the committed tree at the same height, plus random ICS23 spot checks.
* **History**: IAVL keeps every version, so state at any finalised height can be queried (`height=`); the projection additionally stores every
  record version with its transaction (`/q/history`). (Pruning is not configured; a production deployment must decide a retention policy — see `docs/OPERATIONS.md`.)

## 6. Source layout
```
chain/internal/core      state machine: types, tx pipeline, handlers (h_*.go), governance, import, rules, genesis, tests
chain/internal/app       ABCI 2.0 application (IAVL, proofs, peer allow-list, queries)
chain/internal/gateway   HTTP API, light client, SQLite projection, explorer, rate limiting
chain/internal/verify    light-client finality, full replay, snapshot export/verify
chain/internal/netgen    permissioned testnet generator (homes, genesis, node keys, peers), node (re)creation
chain/internal/itest     multi-process integration tests (partitions, quorum loss, crash, rebuild, admission)
chain/cmd/{chaind,chainctl,gateway,bench}
sdk/  TypeScript SDK, offline terminal simulator, integration adapters, demo steps
migration/  Python migration + reconciliation tooling and the synthetic legacy database
dashboard/  React operations dashboard
deploy/  Dockerfile + docker-compose.yml     scripts/  localnet.sh, demo.sh      docs/
```
