# Guarantees, test evidence and deployment limitations

Legend: **[T]** automated test exists and passed in the build environment · **[D]** exercised by the demonstration scripts · **[Doc]** documented procedure/design only · **[Not done]**.

## A. Chain guarantees implemented
| # | Guarantee | Enforcement | Evidence |
|---|---|---|---|
| 1 | Blockchain is the authority: no other write path | state changes only via `core.ExecuteBlock`; gateway/projection are read-only on business data | architecture; [T] `TestProjectionDeleteAndRebuildFromChain` |
| 2 | BFT agreement and instant finality (n=4, f=1) | CometBFT v0.38.25 | [T] `TestAgreementToleranceAndRebuild`, [D] step 11/13 |
| 3 | Safety under partitions; halt (no fork) without quorum | CometBFT; tested with real TCP partitions | [T] `TestQuorumLossHaltsThenRecovers`, `TestNetworkPartitions` (2\|2 and 3\|1) |
| 4 | Deterministic execution; same blocks → same state | one transition function; no clock/random/float/map-order | [T] `TestDeterministicReplay`, `TestAgreementAcrossExecutors`, multi-process app-hash agreement |
| 5 | Recovery by replay; crash safety | IAVL versions; replay on empty data dir; uncommitted block replays identically | [T] `TestRestartRecovery`, `TestCrashBeforeCommitReplaysIdentically`, `TestAllValidatorsCrashAndRecover`, rebuild test; [D] `chainctl replay`, step 12 |
| 6 | Signed transactions; cryptographic validity separate from authorisation | stages 1–6 (ARCHITECTURE §2) | [T] `TestInvalidSignaturesAndKeys`, `TestSignedButProhibited` |
| 7 | Replay & duplicate-execution protection; network binding | `tx_id` uniqueness, per-signer `idempotency_ref`, `network_id` in body+preimage, `valid_until_height` | [T] `TestReplayProtectionAndIdempotency` |
| 8 | Role + location-scoped permissions, terminal binding, privileged roles via governance only | `authorize`, `PrivilegedRoles` | [T] `TestSignedButProhibited`, `TestPrivilegedRoleViaGovernance` |
| 9 | Approval policies: maker-checker, value/quantity limits, global-scope escalation | PO / adjustment / return handlers, `gov/params` | [T] `TestMakerCheckerAndPolicyLimits` |
| 10 | Atomic state changes | per-transaction write overlay flushed only on success | [T] `TestAtomicStateChanges` |
| 11 | Inventory conservation; no negative physical stock; balances = ledger replay | two-sided movements; `postMovement` is the only writer | [T] `TestInventoryConservationFuzz` (5 seeds × 120 blocks, ~50% failing txs, invariants checked after every block) |
| 12 | No double reservation of the last unit; no duplicate sale; no duplicate redemption | sequential execution on agreed order + checks | [T] `TestVerticalSlice`, `TestLoyaltyRedeemReverseShortfall`; [D] steps 3–4 |
| 13 | Transfers tracked through dispatch/receipt; discrepancies explicit | `TRANSIT:<id>` holding location, exceptions, approved write-off | [T] `TestTransfersTrackDispatchAndReceipt` |
| 14 | Sale / payment / fulfilment separate; payment instruction ≠ confirmation; duplicate callbacks deduplicated; reconciliation exceptions | status fields, `payev/` event ids, `exc/` records | [T] `TestPaymentIdempotencyAndExceptions`, `TestFullLifecycleHappyPath` |
| 15 | Returns reference eligible lines; quantity & refund limits; inspection outcomes; instruction vs confirmed refund; sum of refunds = net exactly | cumulative pro-rata, caps against paid | [T] `TestRefundLimitsAndRounding`, `TestReturnRejectedInspectionAndDamaged` |
| 16 | Compensating corrections, originals preserved and linked | `ReverseBusinessEntry`, reversal records | [T] `TestCompensatingReversals`, lifecycle test |
| 17 | Deterministic pricing/promotion precedence with per-line explanation; exact inputs + rule version preserved | `priceLine`, `SaleLine.Steps`, `rules_version` | [T] `TestPromotionPrecedenceIsDeterministic`, `TestMultibuyAndWeightedUnits` |
| 18 | Loyalty earn/redeem/expire/reverse; reversal on refund proportional, shortfall flagged | `h_loyalty.go`, `h_admin.go` | [T] lifecycle + loyalty tests |
| 19 | Effective time separate from block time; bounded plausibility | `checkEffective` | [T] `TestSizeAndLineLimits` |
| 20 | Transaction/payload limits | per-type size limits, line limits, string/attr limits | [T] `TestSizeAndLineLimits`, `TestCheckTxStagesAndProposalLimits` |
| 21 | Historical state at any finalised height; Merkle membership/non-membership proofs; tamper detection | IAVL versions; ICS23 | [T] `TestHistoricalQueryAndProofs`; [D] step 13e |
| 22 | Light-client finality verification, genesis-anchored | CometBFT light client | [D] `chainctl verify-finality`, `/explorer/verify-finality` |
| 23 | Disposable projection with lag display, read-after-write, rebuild and verification | SQLite + digest + proofs | [T] `TestProjectionDeleteAndRebuildFromChain` |
| 24 | Permissioned membership; authenticated connections; unregistered peers refused | `filter_peers` + on-chain `gov/node/*` | [T] `TestUnregisteredNodeCannotJoin`, `TestObserverAdmissionViaGovernance` |
| 25 | Governance with >2/3 organisation approval and explicit activation heights; validator add/remove; key rotation | `governance.go` | [T] `TestGovernanceQuorumAndObserverAdmission`, `TestValidatorAddRemoveRotate`, `TestAddAndRemoveValidatorByGovernance` (live 4→5→4 validators) |
| 26 | Incompatible state-machine versions cannot silently diverge | version-gated rules; halt at activation if unsupported | [T] `TestUpgradeActivationAndFailClosed`; [D] `scripts/demo-governance.sh` (old binary halts live; replays and rejoins) |
| 27 | Key rotation/revocation (business identities) with preserved history | `RotateKey`, `RevokeKey` | [T] `TestKeyRotationAndRevocation`; [D] governance demo |
| 28 | Migration import: provenance, window control, on-chain reconciliation check at close, no fabricated native events | `import.go` | [T] `TestMigrationWindowImportAndReconciliation`, `TestMigrationRejectsRealPersonalIdentifiersAndBadRecords`; Python suite (see MIGRATION.md) |
| 29 | Snapshot export + verification against light-client-verified app hash | `chainctl snapshot` | [D] demo step 13f |
| 30 | API rate limiting | gateway token bucket | implemented; no dedicated automated test |

## B. Test inventory (final run in the build environment)
| Suite | Result | Notes |
|---|---|---|
| Go `chain/internal/core` + `chain/internal/app` (`make test`) | **32 tests passed** | state machine, determinism/replay/agreement, conservation fuzz, atomicity, authz, replay protection, signatures, pricing, payments, returns/refunds, loyalty, transfers, adjustments, governance & upgrade fail-closed, migration import; ABCI restart/crash/proofs/peer filter/CheckTx |
| Go integration `chain/internal/itest` (`make itest`, real `chaind` processes + TCP proxies) | **8 tests passed** (≈ 2.7 min) | agreement + f=1 tolerance + rebuild from empty data dir; quorum loss; 2\|2 and 3\|1 partitions; all-validator crash; unregistered peer refused; observer admission by vote; validator add/remove 4→5→4; projection delete/rebuild/verify |
| SDK `npm test` | **169 passed, 6 skipped** (live suite needs `GATEWAY_URL`; it passed 6/6 against a live network when run by its author) | signing byte-compatibility with Go golden vectors, ICS23 proofs, key stores, client, offline terminal, integration layer |
| Migration `pytest` | **150 passed, 1 skipped** (live test needs `GATEWAY_URL`) | deterministic batching, conversions, planted-problem catalogue (90 problems), reconciliation incl. corrupted chain data, cutover state machine |
| Dashboard `npm test` | **82 passed** (+ Playwright screenshot/interaction scripts against the mock and the real gateway) | |
| `scripts/demo.sh` (13 steps) | **ran to completion** | output captured in `docs/demo-run-output.log` |
| `scripts/demo-governance.sh` | **ran to completion** | key rotation/revocation, observer admission, upgrade v1→v2 at an explicit height, old binary halts and later replays |
| Benchmark | measured, `docs/BENCHMARK.md` | |
Run: `make test`, `make itest`, `(cd sdk && npm test)`, `(cd migration && PYTHONPATH=. .venv/bin/python -m pytest)`, `(cd dashboard && npm test)`.

Not covered by automated tests: gateway API rate limiting (implemented), the Docker artefacts, behaviour at production data volumes, browsers other than Chromium, real payment/ERP/WMS integrations (simulated adapters only).

## C. Measured vs estimated
Only `docs/BENCHMARK.md` numbers labelled *measured* come from runs of `scripts/benchmark.sh` in the build environment (shared 4-vCPU VM; all validators, the load generator and the gateway on one machine; loopback networking). Everything about WAN deployments, hardware scaling and production storage sizing is an **estimate** and labelled so.

## D. Remaining limitations (not solved by this prototype)
1. **Trust:** all four validators run on one host under one operator. This proves fault tolerance mechanics, not independence of control. See TRUST_MODEL.md.
2. **Confidentiality:** every validator sees plaintext business records; API/role permissions do not hide data from validator operators. Personal data must not go on a replicated ledger; only synthetic data was used. The privacy-conscious profile is a **design** (PRIVACY.md) with guard rails (pseudonymous id patterns, evidence refs), not a built confidentiality layer.
3. **Key custody:** demo identity keys are plain files; validator keys are CometBFT file keys. No HSM/remote signer was integrated ([Doc] only). The SDK has an `ExternalSignerKeyStore` interface.
4. **Docker:** Dockerfile/Compose written, **not executed** (no Docker daemon in the build environment).
5. **Gateway security:** the read API is unauthenticated (demo); no SSO/TLS; rate limiting is per IP only; no per-signer on-chain quotas (an authorised key can still fill state with rejected txs until revoked; rejected authenticated txs are stored as `tx/` records).
6. **Storage growth / retention:** unbounded by design (no pruning; `tx/`, `idem/` records, events kept). Full-history replay time grows with chain length; no state-sync bootstrap.
7. **Light client trust root:** genesis validator set with a 10-year trusting period (demo). Production needs a realistic trusting period, pinned checkpoints and independent witnesses.
8. **Validator key rotation** needs a node restart in an overlap window and temporarily lowers fault tolerance; node-id rotation likewise.
9. **Throughput** is bounded by single-threaded deterministic execution per validator (≈1.6–1.8k tx/s in the engine-only benchmark and ≈330 tx/s with four validators on this shared VM) and by block time/consensus latency; see BENCHMARK.md. There is no sharding or parallel execution.
10. **External world:** the chain cannot confirm goods arrived, money moved, or that imported history was accurate; adapters and reconciliation processes are required (INTEGRATION in SDK.md).
11. **Business scope:** tax/VAT, multi-currency conversion, bundles beyond the three promotion types, supplier invoicing/3-way match, ECOM fulfilment/shipping states and customer-facing refunds workflows beyond those modelled are not implemented.
12. **Offline operation** cannot prevent overselling across disconnected stores except via pre-allocated allowances (scarce items) — non-scarce offline sales are accepted at risk and surfaced as exceptions on reconnect (SDK.md).
