# Deployment, operations, backup and recovery

## Run it locally (native, no Docker)
```bash
make build                       # Go binaries -> bin/      (needs Go >= 1.26 (go.mod pins `go 1.26.0`; with GOTOOLCHAIN=auto an older Go downloads it))
scripts/localnet.sh init         # generate 4 validator homes, genesis, node keys, identity keys -> run/net
scripts/localnet.sh start        # 4 chaind processes (p2p 26600+10i, rpc 26601+10i)
scripts/localnet.sh gateway start    # API + projection + dashboard on http://127.0.0.1:8080
scripts/localnet.sh status
scripts/localnet.sh stop-node val-south ; scripts/localnet.sh start-node val-south
scripts/localnet.sh stop         # or: clean (deletes run/)
```
`BLOCK_TIME=500ms`, `BASE_PORT`, `RUN_DIR`, `NETWORK_ID`, `GATEWAY_ADDR` environment variables adjust the layout (parallel networks for trials use different `RUN_DIR`/`BASE_PORT`).

## Docker Compose
`docker compose -f deploy/docker-compose.yml up --build` — init job + 4 validators + gateway (serving the dashboard). **Written but not executed in the build sandbox** (no Docker daemon); the same binaries and topology are exercised natively. The compose file shares one volume only to generate the demo network; in a real deployment each organisation holds only its own directory.

## Onboarding an organisation as a validator (production shape)
1. Org generates keys on its own infrastructure (`chainctl newnode --mode observer`, or a remote signer/HSM: CometBFT `priv_validator_laddr`), keeps `priv_validator_key.json` private.
2. Org sends `node_id` and consensus public key to the consortium. Everyone pins the same `genesis.json` (compare SHA-256 out of band).
3. Governance `ADD_VALIDATOR` (see GOVERNANCE.md). 4. Org starts the node after activation; it block-syncs from genesis and begins signing two blocks after activation.

## What to back up
| Asset | Criticality | Notes |
|---|---|---|
| `config/priv_validator_key.json` | **critical secret** | losing it = losing the validator seat (recover via governance rotation); leaking it = anyone can sign as the validator. Keep in HSM/remote signer where possible. |
| `data/priv_validator_state.json` | critical for safety | records the last signed height/round/step. **Never run two instances with the same validator key**; never restore an *older* state file on a key whose newer signatures were seen — that risks double-signing (a safety fault). |
| `config/node_key.json`, `config/config.toml`, `genesis.json` | important | node identity / allow-listed id |
| `data/` (blockstore, state, `aureom_state.db`, tx_index) | reproducible | can be rebuilt by replay but slowly; backups make recovery faster |
| Business identity keys | critical (per actor) | SDK `KeyStore` (encrypted file / external signer). Loss → `RotateKey` by admin; compromise → `RevokeKey`. |
| Projection DB | none | disposable |

## Recovery runbook
| Situation | Procedure | Verified by |
|---|---|---|
| One validator crashed / host lost | restart; or rebuild on a new host: `chainctl newnode --mode replace --restore-from <backup of its config dir> --name … --p2p-port … --rpc-port …`, start it; it block-syncs the full history (re-executing every block). Use `replace` only after the old instance is **permanently stopped**: the signing-state file is reset to height 0 in the new home. | `TestAgreementToleranceAndRebuild` (data dir deleted, node replays, agrees on app hash) |
| Data directory corrupted | stop node, move `data/` aside, keep `priv_validator_state.json`, restart → replay | same |
| Chain halted (≥ 2 of 4 validators down) | restore validators until > 2/3 power is online; pending txs finalise; nothing was lost or forked | `TestQuorumLossHaltsThenRecovers`, `TestNetworkPartitions` |
| All validators crashed | restart all; each recovers from its LevelDB (uncommitted block is replayed identically) | `TestAllValidatorsCrashAndRecover`, `TestCrashBeforeCommitReplaysIdentically` |
| Suspected state corruption / divergence | `chainctl replay --rpc <node>`: re-executes from genesis in a fresh in-memory app and compares every app hash with the on-chain headers | demo step 13 |
| Need an audit/disaster snapshot | stop one validator → `chainctl snapshot export --home <home> --network-id <id> --out snap.jsonl` → anywhere: `chainctl snapshot verify --file snap.jsonl --rpc <urls> --genesis genesis.json` rebuilds the IAVL tree and checks the root equals the `app_hash` in a light-client-verified header | `snapshot verify` output in the demo |
| Projection stale/corrupt | `POST /api/v1/projection/rebuild`; confirm `GET /api/v1/projection/verify` shows `match: true` | demo step 12 |
| Lost business key | admin `RotateKey`; compromised key | `RevokeKey` | `TestKeyRotationAndRevocation` |
| Loss of ≥ 2/3 of validator keys and data | the chain cannot continue without them. Disaster recovery = restore from backups of enough validators (keys + data). If keys are irrecoverable the consortium must agree a **new chain** seeded from a verified snapshot (new genesis with a state import; history before that is preserved only as the archived snapshot + old blocks). Plan key escrow / HSM backups before go-live. | — |

State sync (bootstrapping from a snapshot) is **not implemented**; replay is the supported recovery path and is fast enough at demo scale (≈0.1 s for 80 blocks). At production scale plan block-store backups.

## Operational limits and settings (generated `config.toml` + `gov/params`)
Rate limiting: gateway per-IP token bucket on `/tx/submit` (default 200/s, burst 400). Size limits: 32 KiB per ordinary tx, 900 KiB for bulk imports, 100 lines per tx, 400 records per import batch, block ≤ 4 MiB. Prometheus can be enabled in `config.toml` (`instrumentation.prometheus`).
Retention: **no pruning** (full history is needed for historical queries/proofs). Plan disk growth from `docs/BENCHMARK.md`.

## Hardening checklist before any real deployment
HSM/remote-signer validators; separate organisations & networks; TLS + SSO in front of the gateway; restrict RPC to the gateway; rotate/escrow keys; pin the light-client root (genesis hash) in verifiers with a realistic trusting period; run the replay verifier on a schedule from an independent party; privacy review (docs/PRIVACY.md); penetration test; load test on the real network topology.
