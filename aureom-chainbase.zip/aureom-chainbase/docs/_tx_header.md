# Transaction reference

Generated from the Go payload types by `chainctl schema md` — it cannot drift from the validators.

## Wire format

A transaction on the wire is one JSON object (the "envelope"):

```json
{ "v": 1, "body": "<base64 of the exact body bytes that were signed>", "sig": "<base64 ed25519>", "pub": "<base64 ed25519 public key>" }
```

* `body` is JSON (any key order/whitespace; the signer chooses the bytes, validators verify exactly those bytes — no canonicalisation needed across languages).
* Signature preimage (bytes): `"AUREOM-CHAINBASE/TX/v1" 0x00 <network_id> 0x00 <body bytes>`.
* The body (all fields required unless noted):

| field | meaning |
|---|---|
| `tx_id` | unique id, `^[A-Za-z0-9_-]{8,64}$`. A second tx with the same id is rejected (`REPLAY`). |
| `network_id` | must equal the chain id (cross-network replay protection; also in the signed preimage). |
| `type` | one of the types below. |
| `schema_version` | currently `1`. |
| `signer` | registered identity id. |
| `key_id` | which of the identity's keys signed (must be ACTIVE and match `pub`). |
| `idempotency_ref` | business-level dedupe key, unique per signer: a second tx with the same ref is rejected (`DUPLICATE_IDEMPOTENCY`) once the first has *succeeded*. Retries after a rejection may reuse it. |
| `expected_version` | optional integer. Optimistic concurrency check against the record the transaction primarily changes (product, PO, price book, balance for reservations, adjustment, return, promotion, transfer ...). |
| `client_time_ms` | the signer's claim of local time. Never trusted as proof of when something happened. |
| `valid_until_height` | optional; tx is rejected after this height (bounds replay windows for queued/offline requests). |
| `payload` | type specific object (below). Unknown fields are rejected. |

Processing stages and result codes (`code` in the tx result; 0 = success):

1. structure/limits: `MALFORMED 1`, `TOO_LARGE 2`, `WRONG_NETWORK 3`, `UNKNOWN_TYPE 4`, `UNSUPPORTED_SCHEMA 5`, `INVALID_FIELD 6`
2. cryptographic validity: `BAD_SIGNATURE 101`
3. identity: `UNKNOWN_SIGNER 201`, `KEY_INACTIVE 202`, `EXPIRED 203`
4. replay: `REPLAY 210`, `DUPLICATE_IDEMPOTENCY 211`
5. business authorisation (valid signature but prohibited): `UNAUTHORIZED 301`, `SCOPE_VIOLATION 302`, `POLICY_VIOLATION 303`
6. business validation: `NOT_FOUND 401`, `ALREADY_EXISTS 402`, `VERSION_CONFLICT 403`, `INSUFFICIENT 404`, `INVALID_STATE 405`, `LIMIT_EXCEEDED 406`, `INVALID_ARGUMENT 407`, `MIGRATION_WINDOW 408`

Transactions that fail at stage 1-3 leave no state trace (the id is not burned). CheckTx (mempool admission) also runs stage 5 against committed state, so a transaction that is already prohibited or refers to a record that does not exist yet (e.g. a payment for an unknown sale) is refused at admission and never reaches a block; submitters must be prepared to retry such requests (the SDK's integration runner does). Transactions that pass stage 3 but fail later are *included in the block* and recorded as `tx/<tx_id>` with status `REJECTED` and the reason, but make no other state change (all-or-nothing).

## Units

* Money: `{"minor": <int>, "ccy": "GBP"}` or bare `*_minor` integers with an implied currency. GBP/USD/EUR exponent 2, JPY 0. Max 10^12 minor units.
* Quantities: `{"v": <int>, "unit": "EA"}` — `v` is an integer in the unit's smallest step: `EA`,`PK` whole units; `KG` in grams, `L` in millilitres, `M` in millimetres. The unit must equal the SKU's unit. Prices are per *whole* unit.
* Times: `*_ms` are Unix epoch milliseconds. `effective_at_ms` is a business-effective claim; the block time is stored separately (`block_time_ms`).

## Roles (permission catalogue)

