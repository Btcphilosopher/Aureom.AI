# Migration and reconciliation

How a conventional relational retail system (the **legacy ERP**) is migrated onto AUREOM CHAINBASE, how the result is proven complete,
and how the cutover is controlled so that exactly one system is authoritative at every moment.

Everything lives in `migration/` (Python >= 3.11, pinned dependencies in `migration/requirements.txt`). The wire format, the
`ImportBatch` / `MigrationControl` semantics and the report endpoints are defined by `docs/TRANSACTIONS.md`, `docs/API.md` and
`chain/internal/core/import.go`; this document describes the tooling and the procedure around them.

> **Trust statement.** Imported history is **the legacy system's assertion**. The chain proves *what was imported, when, by whom, and that
> it was not altered afterwards*. It does **not** prove that the legacy data was correct, and importing old records does not
> retrospectively make them accurate. Imported records carry `provenance.origin = IMPORTED` and are never mixed up with natively witnessed
> ones. See [Trust limits](#trust-limits).

---

## 1. Quick start

```bash
cd $ROOT                                              # repository root
python3 -m venv migration/.venv && migration/.venv/bin/pip install -r migration/requirements.txt
source migration/.venv/bin/activate
export PYTHONPATH=$PWD/migration                      # or:  pip install -e migration   (then `python -m aureom_migration` works anywhere)

python -m aureom_migration.synth --seed 42 --out migration/source/retail_source.sqlite   # synthetic legacy DB (deterministic)
python -m aureom_migration inventory --source migration/source/retail_source.sqlite --out migration/work/inventory
python -m aureom_migration checks    --source migration/source/retail_source.sqlite --workdir migration/work/checks --out migration/work/checks --list MANUAL
python -m aureom_migration plan      --source migration/source/retail_source.sqlite --workdir migration/work/checks
pytest migration/tests                                # unit tests (the live test is skipped without GATEWAY_URL)
```

### Trial migration (throwaway chain, never touches production)

```bash
export RUN_DIR=$PWD/run-trial NETWORK_ID=aureom-trial-1 BASE_PORT=28700 GATEWAY_ADDR=127.0.0.1:8092
scripts/localnet.sh start && scripts/localnet.sh gateway start
python -m aureom_migration trial --source migration/source/retail_source.sqlite --workdir migration/work/trial \
    --gateway http://127.0.0.1:8092 --network-id aureom-trial-1 --keys $RUN_DIR/net/keys \
    --report-gateway http://127.0.0.1:8080          # optional: also show the trial reports on the production dashboard (reports are off-chain)
scripts/localnet.sh stop
```

The trial refuses to run unless the network id starts with `aureom-trial`, the gateway reports exactly that id and the chain's migration
window is `NOT_STARTED`; it works on a **copy** of the source (the production source is never frozen by a trial) and simulates live writes
between the master import and the freeze so the delta logic is exercised.

### Controlled cutover (production procedure)

```bash
C="--source migration/source/retail_source.sqlite --workdir migration/work/prod --gateway http://127.0.0.1:8080 \
   --network-id aureom-retail-demo-1 --keys $RUN_DIR/net/keys"     # RUN_DIR of the production network
python -m aureom_migration status    $C                 # which system is authoritative right now (works without --gateway: source-side view)
python -m aureom_migration master    $C                 # phase 1: OPEN the window; master data + promotions + historical sales (source still live)
python -m aureom_migration reconcile $C --phase master  # report #1
python -m aureom_migration freeze    $C                 # phase 2: write-freeze the source, freeze marker, final snapshot
python -m aureom_migration opening   $C                 # phase 3: deltas since the master snapshot + opening balances, open POs, loyalty
python -m aureom_migration reconcile $C --phase final \
    --ack-manual --ack-by "<name>" --ack-reason "<why the MANUAL items are acceptable>"   # phase 4: the attested report (POSTed to the gateway)
python -m aureom_migration cutover   $C                 # phase 5: MigrationControl CLOSE (attested totals), source -> read-only archive
python -m aureom_migration all       $C --ack-manual --ack-by ... --ack-reason ...   # all of the above in one go
```

`unfreeze` (roll the freeze back) and `abort` are the recovery commands, see [Recovery](#8-recovery). Environment fallbacks:
`GATEWAY_URL`, `RPC_URL` (validator CometBFT RPC instead of the gateway: smoke tests), `NETWORK_ID`, `KEYS_DIR` (or `RUN_DIR`),
`MIG_WORKDIR`, `MIG_SOURCE`. Exit codes: `0` ok, `1` refused/failed (message on stderr), `2` reconciliation decision REJECT.

The tool signs as `migration-op` (ImportBatch, MigrationControl) and `pricing-mgr` (ActivatePromotion) using the key files
`<net>/keys/<identity>.json` (`{identity,key_id,seed_hex,pub_b64}`); it refuses to sign for a network id that differs from the one the
endpoint reports.

---

## 2. What is in `migration/`

| path | purpose |
|---|---|
| `aureom_migration/synth.py` | deterministic generator of the synthetic legacy database + `activity` (simulated live writes) |
| `aureom_migration/inventory.py` | schema inventory: tables, columns, types, PK/FK, row counts, value profile -> JSON + markdown |
| `mapping/map-v1.yaml`, `mapping.py` | the **versioned mapping spec** (ids, value maps, conversions, per-column treatment) and its validator |
| `convert.py` | money (float -> integer minor units), quantities, timestamps (-> UTC epoch ms), ids, ASCII labels, customer ids |
| `checks.py` | exceptions + dispositions, the schema gate |
| `plan.py`, `delta.py` | source snapshot + spec -> chain-ready records, exceptions, expected counters; master-vs-final delta |
| `snapshot.py` | consistent snapshots (SQLite backup API under a read transaction), freeze marker, `SourceControl` (freeze / unfreeze / archive) |
| `batching.py` | deterministic batches, ids, size limits |
| `chainclient.py` | envelope signing (byte-compatible with Go), gateway + CometBFT RPC backends, retry-safe submission |
| `reconcile.py`, `report.py` | chain-authoritative reconciliation, report JSON + markdown |
| `cutover.py` | the phased procedure and its state machine |
| `trial.py`, `localnet.py` | trial migration orchestration; start/stop of a throwaway local network |
| `cli.py` | `python -m aureom_migration <command>` |
| `tests/` | pytest suite, `golden.json` (signing vectors produced by `core.SignTx`), an in-memory chain model (`fakechain.py`), live integration test |

Generated at run time under `migration/work/<dir>`: `state.json` (cutover state machine + batch log), `snapshots/`, `reports/*.json|.md`.
`migration/work/sample-reports/` holds a master report and a trial roll-up report from a real run (shape reference for the dashboard).
The production source `migration/source/retail_source.sqlite` is never modified by `trial`, `checks`, `plan`, `inventory` or `snapshot`; `master` only snapshots it, but `freeze`/`cutover` change it
(and are irreversible once archived) - copy it per demo run, or regenerate it (`synth` is deterministic).

---

## 3. The source system and its data-quality findings

`synth.py` builds a SQLite database shaped like a typical legacy ERP: integer surrogate keys, text codes, money stored as `REAL`,
timestamps in mixed formats/zones, columns the chain has no field for, and a `system_state` + `change_log` pair that implement the
source side of the cutover (the freeze is **enforced by triggers**, the change log is filled by triggers).

151 products / 417 variants (SKUs), 6 locations (S001..S004 stores, DC01/DC02 warehouses), 1 982 sale rows (1 950 completed, 30 void, 2 open),
427 loyalty accounts, 38 purchase orders, 3 price lists / 552 price rows, 5 promotions (11 462 rows in 22 tables). The demo ids the end-to-end demo relies on are exact (see
`migration/source/retail_source.sqlite.demo.json`):

* `PRD-KETTLE` *Aureom Barista Kettle*, SKU `KETTLE-RED` (EA, scarce), opening stock **2** at `STORE-N-01`, chain-wide price **GBP 39.99** (3999 minor)
* approved open purchase order **`PO-2001`** (supplier `SUP-009`) delivering **1 x KETTLE-RED** to `STORE-N-01` at 1800 minor unit cost
* loyalty account **`CUST-DEMO01`** with **120** opening points
* promotions `PROMO-001/002/005` migrated natively (the kettle is deliberately in none of them, so its price maths stay 3999)

Location mapping: `S001/S002/S003/DC01` -> the four genesis locations (`STORE-N-01`, `STORE-N-02`, `STORE-S-01`, `WH-DIST-01`; verified, never
imported); `S004` -> `STORE-E-01` and `DC02` -> `WH-RET-01` are imported as `LOCATION` records.

**Planted problems** (all recorded in `retail_source.sqlite.planted.json`; `test_every_planted_problem_is_caught_...` asserts that each one
produces the expected exception kind, source reference and disposition). Results of `checks` on the master snapshot:

| problem planted | exception kind | disposition | what the tool does |
|---|---|---|---|
| duplicate SKUs (exact, case/whitespace variant, same SKU under another product) | `DUPLICATE_SKU` x3 | EXCLUDED | lowest `variant_id` wins, the others are not migrated |
| barcodes shared by two variants | `DUPLICATE_BARCODE` x3 | PRESERVED_AS_EXTRAS | chain barcodes are unique: cleared on the later variant, original kept in `source_extras.barcode_original` |
| sale line -> missing variant | `ORPHAN_FK` | EXCLUDED | the whole sale is not migrated (a sale with an unknown line cannot be asserted) |
| inventory -> unknown store / unknown SKU, PO -> missing supplier, payment -> missing sale, price -> unknown SKU, variant -> missing product | `ORPHAN_FK` (19 in total) | EXCLUDED | not migrated |
| product -> missing category, sale -> missing customer | `ORPHAN_FK` | PRESERVED_AS_EXTRAS | migrated with the field empty, the original id kept in `source_extras` |
| negative stock | `NEGATIVE_STOCK` x4 | MANUAL | a negative physical balance cannot be imported: recount, then re-run before the freeze |
| fractional quantity for an EA item | `FRACTIONAL_QUANTITY` x7 | FIXED (stock rows: rounded half-even, recount advised) / MANUAL (sale lines: sale excluded) | |
| unit mismatch (variant `unit`/`uom` disagree; balance row or sale line in a different unit than the SKU) | `UNIT_MISMATCH` x3 | MANUAL | not migrated until the unit of measure is confirmed |
| `products.loyalty_tier_colour`, `products.custom_json`, `suppliers.credit_rating`, and 37 more unsupported columns | `UNSUPPORTED_FIELD` x40 | PRESERVED_AS_EXTRAS / EXCLUDED (dropped *with approval* `AP-2026-0147`) | listed in the report's `unsupported_fields[]` with the number of rows carrying a value |
| money as floats | `FLOAT_PRECISION` x4 (genuine sub-penny values); 332 harmless binary-float artefacts counted | FIXED | integer minor units, half-even |
| timestamps in 6 formats (naive local, `Z`, offset, UK `DD/MM/YYYY`, epoch s, epoch ms) | normalisation counters; `INVALID_TIMESTAMP` x3, `FUTURE_TIMESTAMP`, `AMBIGUOUS_LOCAL_TIME` (DST fold) x3, `NONEXISTENT_LOCAL_TIME` (DST gap) | MANUAL / FIXED | UTC epoch ms; fold -> first occurrence, gap -> pre-transition offset |
| stale PO (status APPROVED but fully received and closed) | `STALE_PO_CLOSED` | EXCLUDED | nothing outstanding, not migrated |
| non-ASCII names (`Café Latté Mug`, `Müller & Söhne`, `£ Saver ...`) | `NON_ASCII_TEXT` x6 | FIXED | the chain accepts printable ASCII only: transliterated, original kept in `source_extras.name_original` |
| legacy / non-conforming customer ids | `LEGACY_CUSTOMER_ID` x5 | FIXED | `C0701` -> `CUST-000701`; others -> stable pseudonym `PSN-<hash>` |
| two accounts that normalise to one customer, negative points, account without customer | `DUPLICATE_CUSTOMER_ID` x2, `NEGATIVE_POINTS`, `ORPHAN_FK` | MANUAL | not migrated |
| duplicate price (same SKU/location/effective-from), zero price, ends-before-starts, USD list on a GBP store | `DUPLICATE_PRICE`, `INVALID_PRICE`, `PRICE_PERIOD_INVALID`, `CURRENCY_MISMATCH` x5 | EXCLUDED | the chain would reject them |
| BOGOF promotion | `UNSUPPORTED_PROMO_TYPE` | MANUAL | no chain equivalent |
| line total != qty x price - discount, header total != sum of lines | `LINE_TOTAL_MISMATCH` x3, `HEADER_TOTAL_MISMATCH` x6 | FIXED | the recorded line total is kept as the net, lines are authoritative |
| captured payments do not cover the sale | `PAYMENT_MISMATCH` x10 | PRESERVED_AS_EXTRAS | asserted as recorded (`PARTIALLY_PAID` ...), breakdown kept in `source_extras.payments` |
| refund larger than the sale, unknown channel, empty sale | `REFUND_EXCEEDS_SALE`, `UNKNOWN_CHANNEL`, `EMPTY_RECORD` | MANUAL / MANUAL / EXCLUDED | |

Final totals on the synthetic source: 142 exceptions on the master snapshot (EXCLUDED 48, FIXED 32, PRESERVED_AS_EXTRAS 39, MANUAL 23),
144 on the final snapshot (MANUAL 25 after the post-master changes). Excluded rows: 5 of 417 SKUs, 16 of 1 975 completed sales, 14 of
1 252 stock rows, 2 of 16 purchase orders, 4 of 427 loyalty accounts.

**Disposition semantics.** `EXCLUDED` not migrated, no action needed; `FIXED` migrated after a deterministic documented correction;
`PRESERVED_AS_EXTRAS` migrated and the original value kept verbatim in `source_extras`; `MANUAL` not migrated and needs a human decision
(unresolved MANUAL items are listed in every report, are a WARN before the final phase and **block the final acceptance** until they are
acknowledged with `reconcile --phase final --ack-manual --ack-by --ack-reason`; the acknowledgement is recorded in the report).

**No silent loss** is enforced three ways: (1) the *schema gate* fails the whole migration when a source table/column has no declared
treatment in the mapping (or a declared one disappeared: schema drift) - tests add a column to a copy of the source and expect the
refusal; (2) every record that is not migrated has an exception (`test_no_silent_exclusion_...`); (3) every report carries
*exception accounting*: for each entity `source rows in scope = migrated + excluded + out of scope`, and a check FAILS if a row is
unaccounted for. Out-of-scope rows are only: genesis locations (mapped), VOID/OPEN sales, closed/cancelled POs, expired prices,
ended promotions, zero-quantity stock rows.

---

## 4. Mapping (`mapping/map-v1.yaml`)

The spec is data with a version; its sha256 is recorded in every report and pinned in the work directory - the tool refuses to continue
a migration whose spec changed. Highlights:

**Entities**

| source | chain | notes |
|---|---|---|
| `stores`, `warehouses` | `LOCATION` import (non-genesis only) | ids via `ids.location_map` |
| `suppliers` | `SUPPLIER` | id = sanitised `supplier_id` |
| `products` + `product_variants` + `categories` | `PRODUCT` with `variants[]` (= SKUs) | product id = `product_code`; SKU id = trimmed, upper-cased, sanitised `sku` |
| `price_list_items` + `price_lists` | `PRICE` | id `PRC-<item_id>`; NULL location -> `*` (chain-wide, global scope) |
| `promotions` + `promotion_skus` | **native `ActivatePromotion`** signed by `pricing-mgr` | id `PRM-<promo_id>` |
| `inventory_balances` | `OPENING_BALANCE` | `available = on_hand`, `damaged = damaged` |
| `purchase_orders` + lines | `OPEN_PO` | only outstanding POs (DRAFT/APPROVED/PARTIALLY_RECEIVED) |
| `loyalty_accounts` (+ `customers` for existence) | `LOYALTY_OPENING` | |
| `sales` + `sale_lines` + `payments` + `refunds` | `HISTORICAL_SALE` | id `HS-<sale_id>`; COMPLETE sales only |
| `returns`, `customers.*` tiers/segments, ... | not migrated (dropped *with approval* `AP-2026-0147`) | refund **amounts** are migrated into `refunded_minor` |
| `system_state`, `change_log` | not migrated (`system`) | they drive the freeze marker and delta detection; archived with the source |

**Decision: promotions are migrated natively.** The chain has no promotion import entity (`ImportBatch` entities are LOCATION, SUPPLIER,
PRODUCT, PRICE, OPENING_BALANCE, OPEN_PO, LOYALTY_OPENING, HISTORICAL_SALE). Active promotions are therefore issued as ordinary
`ActivatePromotion` transactions signed by `pricing-mgr` (the only role with `promo.manage`) in the master phase, after the SKUs exist.
Consequences, stated plainly: they carry no `IMPORTED` provenance and no `source_extras`, they are not part of the chain's migration
counters, and they are recognised by the `PRM-` id prefix (reconciliation compares them field by field). Ended/expired promotions are not
migrated (history only). `BOGOF` has no equivalent -> `MANUAL`. `banner_ref` is dropped with approval.

**Conversions** (`convert.py`, tested at the edges):

* *Money.* The float is read through its shortest round-trip decimal form (`Decimal(repr(x))`) and rounded **half-even** to the currency
  exponent. Noise below 1e-6 of a minor unit (`12.349999999999998`) is silent; real sub-minor precision (`4.995` -> 500, `2.675` -> 268,
  `0.125` -> 12) is reported `FLOAT_PRECISION`. After this step only integers exist: the payload builder refuses any float, and the chain-side
  line arithmetic (`unit price x qty / 10^scale`, half-even) is mirrored with integers (`line_amount`).
* *Quantities.* EA/PK whole units; KG grams, L millilitres, M millimetres (x1000), half-even. The unit must equal the SKU's unit (the chain
  checks it for balances/POs; the tool checks it for sales too, which the chain's `importSale` does not).
* *Timestamps.* ISO with `Z`/offset, naive `YYYY-MM-DD HH:MM[:SS]`, UK `DD/MM/YYYY HH:MM`, 10-digit epoch seconds, 13-digit epoch ms ->
  **UTC epoch milliseconds**. Naive times are `Europe/London` wall time; the raw text is always kept (`source_extras.sold_at_raw`).
* *Ids.* Chain ids match `^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$`; derivation rules are in the spec, collisions are `ID_COLLISION`
  exceptions, and the **source id is preserved** in `provenance.source_id` as `table:pk` (variants: `source_extras.source_id`).
  Customer ids must be synthetic: `CUST-...` kept, legacy `C123`/`cust_123` -> `CUST-000123`, anything else -> `PSN-` + 16 hex of
  `sha256(salt|id)` (a stable pseudonym, **not** strong anonymisation: the salt is not secret).

**Unsupported fields** are never dropped silently. Each source column has exactly one treatment: `mapped`, `extras` (kept verbatim in
`source_extras`, only available on products/SKUs/locations/suppliers/POs/sales - the chain records that have the slot), `folded`
(`inventory_balances.reserved`), `dropped` (requires an approval id in the spec), `system`. The report's `unsupported_fields[]` lists every
`extras`/`dropped`/`folded` column with the number of rows carrying a value, and each one with data is also an `UNSUPPORTED_FIELD`
exception so it shows up in the exception list.

---

## 5. Strategy

### Opening balances

Opening stock is imported **from the post-freeze snapshot only**, as explicit `OPENING_BALANCE` movements from the counter-party
`EXT:MIGRATION` (the chain's ledger conserves quantity: the movement's `origin` is `IMPORTED_OPENING`, `reason` `OPENING_BALANCE`). Source
`on_hand` includes reserved units (they are still on the shelf) and `damaged` is separate, so the chain gets `available = on_hand` and
`damaged = damaged`. **Reservations are not migrated** - they are ephemeral, and importing them would fabricate native events; they are
re-created natively after cutover (`inventory_balances.reserved` is listed as `folded`). Open purchase orders keep their ordered/received
quantities and unit costs (`received_v`), their source status, and are attributed to `import:<source system>`; supplier approval history is
in `source_extras`. Loyalty: one `OPENING` entry per account (`LE-OPEN-<customer>`).

### Historical data

Completed sales are imported as **clearly labelled imported historical assertions**: `provenance.origin = IMPORTED`, source system/id,
batch id, mapping version and snapshot id on every record, `payment_method = IMPORTED`, `source_extras` with the raw timestamp, receipt
number, terminal, cashier reference, header totals, the payment and refund breakdown. **No reservations, payments, payment events or
stock movements are fabricated** - the chain only receives the sale record (lines with integer minor-unit amounts, `paid_minor`,
`refunded_minor`, a payment status derived from the recorded captured payments). Their stock effect is already inside the opening
balances. `effective_at_ms` is the source's claim; validators never witnessed it. Importing history does not retrospectively prove it.

### Master phase, freeze, opening phase, deltas

1. **Master** (source still live and authoritative): master snapshot -> `MigrationControl OPEN` (manifest hash of the master batch plan) ->
   locations, suppliers, products, prices, promotions, historical sales.
2. **Freeze**: `system_state` -> `frozen=1, authoritative_system='NONE_FROZEN'` inside a `BEGIN IMMEDIATE` transaction together with the
   **freeze marker** = `sha256(system | change_log high-water mark | row count | hash chain over the whole change log)`. The tool then
   proves the freeze is enforced (a canary write is refused by the source's own triggers) and takes the **final snapshot**, whose own
   change-log marker must equal the freeze marker.
3. **Opening**: *deltas first* - records created in the source after the master snapshot are imported under the final snapshot id; then
   balances, open POs, loyalty. Records **changed** after the master import cannot be updated through import (the chain refuses an
   existing id): the chain keeps the master-time version and `CHANGED_AFTER_MASTER` (MANUAL) is raised; **deleted** ones stay on chain
   (`DELETED_AFTER_MASTER`); new records depending on something that never reached the chain are excluded as `EXCLUDED_DEPENDENCY`.
   Rows that merely expired between the two snapshots are not "deleted". The live run showed exactly this: 25 new sales, 1 new product +
   price, and 2 post-master changes (a renamed product, a refund booked on an old sale) classified correctly.

### Determinism, resume, retry safety

* The plan is a pure function of (snapshot, spec, reference time); records are sorted by source id; the snapshot id is
  `snap-<16 hex of the content digest>` so re-snapshotting unchanged data gives the same id.
* `batch_id = "B-" + sha256(snapshot_id | mapping_version | entity | seq)[:40]`; batches hold <= `Params.MaxImportRecords` (400) records and
  the signed envelope is kept below 600 KiB (the chain hard limit is 900 KiB; real batches are 20-400 KB). Batch sizing is pinned at the first
  import because it decides which records share an id.
* **Resumable**: before sending a batch the tool reads `mig/batch/<id>` (present -> skipped; present with a different record count/entity/seq ->
  refused). A crash between the chain's commit and the local state write is therefore harmless - exactly this happened in the live run.
* **Retry-safe**: every transaction has an idempotency reference derived from its batch id (`imp-<batch id>`) and tx ids
  `mb-<hash>-NN`. Before sending, the tool asks for `idem/<signer>/<ref>`; after a timeout it asks `tx/<id>` instead of guessing and re-sends
  the *identical bytes*; `REPLAY`/`DUPLICATE_IDEMPOTENCY` answers are resolved against chain state. A batch can never execute twice (tests
  inject lost responses and network failures). A `REJECTED` finalised transaction burns its id, so the next attempt uses `-01`, `-02`...

---

## 6. Reconciliation

`reconcile` reads the **chain-authoritative** state through the gateway (`/api/v1/chain/scan`, `/chain/record`, never the SQL
projection), all pinned to **one finalised height** (`height=H` from `/chain/info`), and compares it with the *expected* values (source after
policy, i.e. what the migration set out to import). Every comparison has an explicit tolerance (`reconciliation.tolerance` in the mapping,
zero by default).

| area | checks |
|---|---|
| window | `mig/state.status` is OPEN (master/final) or CLOSED (post-cutover); at CLOSE: attested totals == counters, report hash, freeze marker |
| counts | locations (imported), suppliers, products, SKUs, prices, promotions, open POs, loyalty accounts, historical sales, stock rows |
| quantities | opening stock per unit and **per (sku, location, bucket)**; outstanding PO quantity per unit |
| money | outstanding PO value (sum of (ordered - received) x cost), PO ordered value, historical net and refunded totals (minor units) |
| loyalty | points total and **balance per customer** |
| records | field-by-field comparison of every location, supplier, product, SKU, price, promotion, PO, sale (missing / unexpected / different) |
| counters | every key of `mig/state.chain_counters` against the expected totals (these are what CLOSE attests) |
| provenance | every imported record carries `IMPORTED`, the source system, a source id and a **planned** batch id; no unplanned batches |
| source | snapshot file hash, mapping hash, freeze marker unchanged, write-freeze enforced, **exactly one authoritative system** |
| data quality | schema gate, exception accounting per entity, **excluded share** per entity vs `max_excluded_ratio`, unresolved MANUAL items |

Decision: **ACCEPT** iff no check is FAIL. The report (shape in `docs/API.md`; see below for additions) is stored in
`<workdir>/reports/<id>.json|.md` and POSTed to `POST /api/v1/migration/reports`; the gateway answers with `{id, sha256}` (sha256 of the
posted bytes - the tool sends canonical JSON so the hash is reproducible) and that hash is what `MigrationControl CLOSE` attests as
`report_hash`. All `source`/`chain`/`delta` fields are numbers; non-numeric comparisons (window status, hashes) are 1/0 match flags with the
compared values spelled out in `detail`. Additive fields beyond the contract: `mapping_sha256`, `freeze_marker`, `chain_height`,
`summary`, `manual_acknowledgement`, `delta_since_master`, `expected_counters`, `verification`, exceptions' `id`/`entity`, unsupported
fields' `detail`/`approval`, and a third `treatment` text for the folded column.

**Live numbers** (final report of a complete run, chain height 624, 82 checks, 0 FAIL):

| check | expected (source after policy) | chain |
|---|---:|---:|
| products / SKUs / suppliers / imported locations / prices / promotions | 152 / 413 / 14 / 2 / 433 / 3 | 152 / 413 / 14 / 2 / 433 / 3 |
| stock rows (sku, location, bucket) | 1 303 | 1 303 |
| opening stock EA / KG(g) / L(ml) / M(mm) / PK | 39 198 / 2 297 841 / 1 753 378 / 508 780 / 2 247 | identical |
| open POs / outstanding EA / outstanding value / ordered value | 14 / 556 / 1 044 401 / 1 084 141 | identical |
| loyalty accounts / points | 423 / 408 179 | identical |
| historical sales / net / refunded (minor units) | 1 959 / 13 714 664 / 251 336 | identical |

---

## 7. Controlled cutover: one authoritative system at every stage

| stage | source `system_state` | chain window | **authoritative** | next |
|---|---|---|---|---|
| `SOURCE_LIVE` | `SOURCE`, writable | `NOT_STARTED` | **SOURCE** | `master` |
| `MASTER_DONE` | `SOURCE`, writable | `OPEN` | **SOURCE** | `reconcile --phase master`, `freeze` |
| `FROZEN` | `NONE_FROZEN`, writes aborted by triggers | `OPEN` | **FROZEN** (nobody writes; a bounded outage) | `opening` (or `unfreeze`) |
| `OPENING_DONE` | `NONE_FROZEN` | `OPEN` | **FROZEN** | `reconcile --phase final` |
| `RECONCILED` | `NONE_FROZEN` | `OPEN` | **FROZEN** | `cutover` |
| `CUTOVER_DONE` | `CHAIN`, frozen read-only archive | `CLOSED` | **CHAIN** | corrections = compensating transactions |
| `ABORTED` | `SOURCE`, writable again | `OPEN` (orphaned) | **SOURCE** | start over on a fresh chain |

There is never a moment with two writers: the source stops accepting writes *before* the chain's opening position is imported, and the chain
only becomes authoritative when the window is closed - and the source is flipped to `CHAIN` right after. `status` derives the answer from
the two **real** control records (the source's `system_state` and the chain's `mig/state`) and flags any combination that is not one of the
rows above as `INCONSISTENT` (e.g. window CLOSED while the source still says SOURCE: two authoritative systems), or `CUTOVER IN PROGRESS` if
the process died between the chain CLOSE and the source flip (re-run `cutover`: both steps are idempotent).

State machine (`cutover.py`): `master -> freeze -> opening -> reconcile(final, ACCEPT) -> cutover`, each command resumable in place; any
other order is refused with the list of what is allowed. `cutover` re-verifies at a fresh height right before closing (the chain must still
match the accepted report) and that the source marker has not moved; it then sends `MigrationControl CLOSE` with `totals` = **all** expected
counters (the chain compares them to its own), `report_hash`, `source_freeze_marker`, `manifest_hash`; archives the source; and produces a
post-cutover verification report (a `final` report with `authoritative_system: CHAIN`).

---

## 8. Recovery

The chain is append-only: imported records cannot be deleted, only superseded by native compensating transactions. The recovery options
follow from that.

1. **Abort before cutover.**
   * *Source freeze only* - `unfreeze` (stage `FROZEN` -> `MASTER_DONE`): the source is live and authoritative again, the final snapshot is discarded and
     a later `freeze` takes a new one. Allowed only while **no opening/delta batch is on the chain** (the tool checks the chain, not just
     its own state). Nothing on the chain needs undoing: it holds only master data.
   * *Anything else* - `abort`: unfreezes the source and marks the work directory `ABORTED` (terminal). What is already on the chain stays there
     as `IMPORTED` provenance; the window stays OPEN. For a rehearsal, staging or pre-go-live network the answer is to **discard the network
     and start a fresh one** (the realistic recommendation: run `trial` first, and only point the production network at a procedure that has
     reconciled on a throwaway one). Never reuse a chain that holds a half-finished import for a different snapshot.
   * After `CLOSE` there is no abort.
2. **Re-run after fixing the mapping.** A mapping change is a new `mapping_version` (copy `map-v1.yaml` -> `map-v2.yaml`, change the
   version). Batch ids derive from the version and snapshot, so the new plan can never be confused with the old, but entity ids collide
   (`ALREADY_EXISTS`) on a chain that already holds the old import: run it in a new work directory on a **fresh network** (a trial first). The tool
   refuses to continue a work directory whose spec hash changed. Fixing *source data* is different: opening entities (balances, POs, loyalty)
   are read from the final snapshot, so a recount/correction made before the freeze is fully effective; for master entities already imported it
   shows up as `CHANGED_AFTER_MASTER`.
3. **Partial failure / resume.** Re-run the same command (`master`, `opening`, `cutover`). Batches already on the chain are skipped; a lost
   response is resolved from `tx/<id>`; a transaction in the mempool is not duplicated. A batch the chain **rejects** (all-or-nothing) leaves no
   state; it is recorded as `REJECTED` with the chain's reason, the run stops, and after fixing the cause the same command continues
   with a fresh tx id. A batch whose id exists on chain with a different shape stops the run (sizing/plan changed).
4. **Post-cutover corrections** are **compensating native transactions only** - the window is closed and `ImportBatch` is refused
   (`MIGRATION_WINDOW`). A wrong opening balance: `AdjustStock` (propose + approve with evidence); a wrong price: `PublishPrice` with a later
   effective-from; product data: `UpdateProduct`; loyalty: `CreditLoyalty` / `ExpireLoyalty` / `ReverseBusinessEntry`; a wrong imported
   sale is not edited - the correction is a native entry referencing it, the imported record stays as the legacy assertion. The archived source
   (read-only, `authoritative_system = CHAIN`) remains the evidence for what the legacy system said.
5. **Process crash between the chain CLOSE and the source flip**: `status` says `CUTOVER IN PROGRESS`; re-run `cutover`.
6. **Gateway/validators down**: submissions fail as transport errors and are retried with the same bytes; reads fail loudly; nothing is
   guessed. If the network is `HALTED` the tool waits/retries then stops without side effects.

---

## 9. Trust limits

* **What the chain adds:** every imported record is ordered, signed by `migration-op` (a privileged role that can only be granted by
  multi-organisation governance), validated by the deterministic state machine on every validator, time-stamped by block time and bound
  to its batch/snapshot/mapping version; the migration window and its closing attestation are on chain; later tampering is detectable.
* **What it does not add:** the validators never saw the legacy events. `effective_at_ms` of a historical sale, an opening quantity, a
  loyalty balance are the legacy system's claims. Reconciliation proves *the load* (nothing lost, extra or altered; counters equal the
  attested totals); it cannot prove the source was right. The exception list and the human acknowledgement of MANUAL items are the quality
  gate, not the chain.
* **The attestation is the operator's.** `CLOSE` carries `report_hash`, `source_freeze_marker` and `totals`; the chain checks the totals the
  operator *lists* against its own counters (this tool lists every counter), but does not verify the report or the marker. A different
  tool/operator could close the window with an empty `totals` map. The report hash is only as meaningful as the report store that holds the
  report. Treat `migration-operator` as a four-eyes role in a real deployment.
* **Single-machine prototype:** the local network is process isolation on one machine; the signing keys are plain files in the demo key
  directory. The freeze is enforced inside the *synthetic* source by triggers; a real ERP needs its own enforcement (read-only mode,
  connection drain) - the tool's canary-write verification is the hook for that.
* **Privacy:** only synthetic ids exist here. Consent/segmentation flags were dropped *with approval* and remain only in the archived
  source; pseudonymised ids (`PSN-...`) use a non-secret salt and are not anonymisation.
* **Promotions and prices** have no provenance on chain (no import entity / record slot); they are identified by id prefix (`PRM-`, `PRC-`).

---

## 10. Verification status

| | verified how |
|---|---|
| Signing, envelope bytes, preimage | `golden.json` produced by `core.SignTx` (temporary Go program, deleted) - Python reproduces body bytes, signature and envelope exactly; **live** (real validators accepted every tx) |
| ImportBatch / MigrationControl / ActivatePromotion semantics, counters, CLOSE attestation | **live** against 4 validators + gateway (trial network and a second network driven command by command), and unit-tested against `tests/fakechain.py` (a model of the Go rules; the live test is what keeps the model honest) |
| Master -> freeze -> opening -> reconcile -> cutover, delta, status, resume after a killed process, report POST | **live** (resume demonstrated by killing `master` mid-run and re-running; the trial run and the stepwise run both ended ACCEPT with identical numbers) |
| Read path through `/chain/scan`, `/chain/record` at a pinned height, `/chain/info`, `/migration/reports` | **live** through the gateway; the direct CometBFT RPC backend was exercised live for the first master batches only |
| Retry safety, lost responses, failure injection, rejected batch, abort/unfreeze, mapping change refusal, corrupted-chain FAIL cases, schema gate, planted-problem detection, conversions, determinism | unit tests (no live equivalent) |
| Behaviour of a real legacy ERP, DST edge cases beyond Europe/London, very large volumes | not verified (synthetic data only) |

Run the live test against a **fresh** throwaway network: see the header of `migration/tests/test_integration_live.py`
(`GATEWAY_URL=... NETWORK_ID=... KEYS_DIR=... pytest migration/tests/test_integration_live.py`).

---
## Lead's notes: chain-side changes made after the first live runs
Findings from the migration build were fed back into the state machine (`chain/internal/core/import.go`), and the demonstration re-ran trial + cutover afterwards (`docs/demo-run-output.log`):
* `MigrationControl CLOSE` now requires **every** chain counter to be attested and equal (an empty or partial `totals` map is refused; extra unknown keys are refused); `report_hash` and `source_freeze_marker` are required, printable and length-bounded.
* `HISTORICAL_SALE` import validates that each SKU exists, its unit matches, and the sale currency equals the location's currency. (Legacy inconsistencies such as refunded > paid are **not** rejected — imported history is an assertion — they are the reconciliation tool's job to flag.) `OPENING_BALANCE` / `OPEN_PO` / `HISTORICAL_SALE` accept DISCONTINUED SKUs.
* Imported `PRICE` records carry `provenance`; variants may carry their own `source_id`; variants of a DISCONTINUED product are imported as DISCONTINUED.
* Known gaps (unchanged): counters `open_po_total_minor` (ordered value) and `po_outstanding_units` (includes DRAFT) are coarse, there is no promotion counter, per-(sku,location,bucket) reconciliation needs a scan of the movement ledger, `GET /chain/migration` returns the record wrapper (`value` holds `mig/state`), and the gateway report store keys reports by caller-chosen `id` (a repeat overwrites; `sha256` is over the raw posted bytes).
