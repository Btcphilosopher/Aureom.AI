#!/usr/bin/env bash
# Governance, key-rotation and upgrade-activation demonstration on a RUNNING network (scripts/localnet.sh start).
# 1) business key rotation/revocation  2) observer admission by >2/3 organisation vote  3) scheduled state-machine
# upgrade with an explicit activation height, and an OLD binary that halts instead of diverging.
set -uo pipefail
. "$(dirname "$0")/lib.sh"
KEYS2="$RUN/keys-rotated"; rm -rf "$KEYS2"
approve3() { for w in hq-org-admin dist-org-admin north-org-admin; do tx "$w" ApproveGovernance "{\"proposal_id\":\"$1\"}" | tail -1; done; }

say "1. Business key rotation and revocation (identity cashier-n01)"
NEWPUB=$("$BIN/chainctl" keygen --identity cashier-n01 --key-id k2 --out "$KEYS2")
tx cashier-n01 RotateKey "{\"identity_id\":\"cashier-n01\",\"new_key_id\":\"k2\",\"new_pub_b64\":\"$NEWPUB\",\"reason\":\"scheduled rotation\"}" | tail -1
note "old key must now be refused (admission code KEY_INACTIVE):"
tx cashier-n01 ReleaseReservation '{"reservation_id":"none","reason":"CANCELLED"}' | head -1
note "new key is accepted (reaches business validation and fails there with NOT_FOUND — proving authentication + authorisation passed):"
tx cashier-n01 ReleaseReservation '{"reservation_id":"none","reason":"CANCELLED"}' "$KEYS2" | tail -1
tx hq-iam-admin RevokeKey '{"identity_id":"cashier-n01","key_id":"k2","reason":"demo: device reported lost"}' | tail -1
note "revoked key is refused:"
tx cashier-n01 ReleaseReservation '{"reservation_id":"none","reason":"CANCELLED"}' "$KEYS2" | head -1
curl -s "$GW/api/v1/q/history?kind=identity&id=cashier-n01&min_height=$(chain_head)" | jget "[ (i['height'], i['tx_type'], [ (k['key_id'],k['status']) for k in i['value']['keys']]) for i in d['items']]"

say "2. Admitting an observer node by governance (needs approvals worth > 2/3 of voting power)"
"$BIN/chainctl" newnode --net "$NET" --name obs1 --mode observer --p2p-port 26700 --rpc-port 26701 | tee "$RUN/obs1.out"
OBS=$(sed -n 's/.*node_id=\([0-9a-f]*\).*/\1/p' "$RUN/obs1.out")
H=$(chain_head); ACT=$((H+14))
tx hq-org-admin ProposeGovernance "{\"proposal_id\":\"GOV-OBS-$H\",\"kind\":\"ADD_OBSERVER\",\"activation_height\":$ACT,\"payload\":{\"member_id\":\"obs-audit-$H\",\"org\":\"org-audit\",\"node_id\":\"$OBS\"}}" | tail -1
note "two approvals (50% of power) are NOT enough; the third (75%) approves:"
for w in hq-org-admin dist-org-admin north-org-admin; do tx "$w" ApproveGovernance "{\"proposal_id\":\"GOV-OBS-$H\"}" | tail -1 | cut -c1-160; done
note "an unregistered node is refused by validators; wait for activation height $ACT, then start it:"
wait_height $((ACT+1)) 90 && ok "activation height reached"
NODE_HOME="$NET/nodes/obs1" "$ROOT/scripts/localnet.sh" start-node obs1
sleep 12
curl -s localhost:26701/status | jget "'observer height=%s catching_up=%s'%(d['result']['sync_info']['latest_block_height'], d['result']['sync_info']['catching_up'])"
curl -s "$GW/api/v1/q/governance" | jget "[(p['id'],p['kind'],p['status'],p['activation_height'],p['executed_height']) for p in d['item']['proposals']]"

say "3. Scheduled state-machine upgrade v1 -> v2 with an explicit activation height"
curl -s "$GW/api/v1/chain/info" | jget "'active state machine version before: %s'%d['app_version']"
H=$(chain_head); ACT=$((H+30))
note "restarting val-south as an OLD binary that only supports state-machine v1 (CHAINBASE_MAX_STATE_VERSION=1)"
"$ROOT/scripts/localnet.sh" stop-node val-south; CHAINBASE_MAX_STATE_VERSION=1 "$ROOT/scripts/localnet.sh" start-node val-south
tx hq-org-admin ProposeGovernance "{\"proposal_id\":\"UP-V2-$H\",\"kind\":\"SCHEDULE_UPGRADE\",\"activation_height\":$ACT,\"payload\":{\"version\":2}}" | tail -1
approve3 "UP-V2-$H" | cut -c1-140
note "upgrade scheduled for height $ACT; v1 rules apply to every block before it"
wait_height $((ACT+2)) 120 && ok "past activation height"
curl -s "$GW/api/v1/chain/info" | jget "'active state machine version after: %s'%d['app_version']"
sleep 2
if grep -q "HALT" "$RUN/logs/val-south.log" 2>/dev/null; then ok "the OLD binary (val-south) halted instead of silently computing different results:"; grep "HALT" "$RUN/logs/val-south.log" | tail -1 | cut -c1-220; else bad "no HALT line found"; fi
note "the other three validators (75% of power) keep finalising:"; "$ROOT/scripts/localnet.sh" status
note "upgrade val-south (normal binary) — it replays the whole chain, applying v2 at the same height as everyone else:"
"$ROOT/scripts/localnet.sh" stop-node val-south; "$ROOT/scripts/localnet.sh" start-node val-south
sleep 15; "$ROOT/scripts/localnet.sh" status
