#!/usr/bin/env bash
# The complete 13-step demonstration on a freshly generated 4-validator network.
#   scripts/demo.sh            run everything (starts the network + gateway itself)
#   SKIP_START=1 scripts/demo.sh   reuse an already running network (RUN_DIR / GATEWAY_URL honoured)
set -uo pipefail
. "$(dirname "$0")/lib.sh"
cd "$ROOT"
STEP="${STEP:-}"            # run a single step number, e.g. STEP=3
want() { [ -z "$STEP" ] || [ "$STEP" = "$1" ]; }
export GATEWAY_URL="$GW" NETWORK_ID KEYS_DIR="$NET/keys" RUN_DIR="$RUN"
SDK=(npm --prefix sdk run --silent demo --)
MIGPY="$ROOT/migration/.venv/bin/python"
[ -x "$MIGPY" ] || { python3 -m venv "$ROOT/migration/.venv" && "$ROOT/migration/.venv/bin/pip" install -q -r "$ROOT/migration/requirements.txt"; }
export PYTHONPATH="$ROOT/migration"
MIG=("$MIGPY" -m aureom_migration)

if [ -z "${SKIP_START:-}" ]; then
  say "0. Start a fresh network: 4 independent validators (HQ, Distribution, Regional North, Regional South) + gateway/projection/dashboard"
  scripts/localnet.sh clean >/dev/null 2>&1 || true
  make build >/dev/null || exit 1
  (cd sdk && [ -d node_modules ] || npm ci --silent) >/dev/null 2>&1
  [ -d dashboard/dist ] || (cd dashboard && { [ -d node_modules ] || npm ci --silent; } && npm run build --silent) >/dev/null 2>&1
  scripts/localnet.sh start && scripts/localnet.sh gateway start
  RPC="$(rpc_of val-hq)"; sleep 3
fi
curl -s "$GW/api/v1/network" | jget "'network %s: %d validators, f=%d, quorum needs power > 2/3 (>= %d of %d); status %s'%(d['network_id'], d['bft']['validators'], d['bft']['f'], d['bft']['quorum_power_required'], d['bft']['voting_power_total'], d['bft']['status'])"

if want 1; then
  say "1. Migrate products, locations and opening inventory from the legacy retail database"
  DEMO_SRC="$RUN/migration/source.sqlite"; mkdir -p "$RUN/migration"
  [ -f migration/source/retail_source.sqlite ] || "${MIG[@]}" synth --seed 42 --out migration/source/retail_source.sqlite
  # freeze/cutover modify (archive) the source, so every demo run works on a fresh copy of the synthetic database
  cp migration/source/retail_source.sqlite "$DEMO_SRC"; cp migration/source/retail_source.sqlite.demo.json "$DEMO_SRC.demo.json" 2>/dev/null || true
  note "stage before migration: $("${MIG[@]}" status --source "$DEMO_SRC" --workdir "$RUN/migration/prod" --gateway "$GW" --network-id "$NETWORK_ID" --keys "$NET/keys" 2>/dev/null | jget "'%s — authoritative system: %s (next phase: %s)'%(d['stage'], d['authoritative_system'], d['next'])")"
  if [ -z "${SKIP_TRIAL:-}" ]; then
    note "1a. TRIAL migration on a THROWAWAY network (different network id and ports; production untouched)"
    TR_RUN="$ROOT/run-trial"; rm -rf "$TR_RUN"
    TRENV=(RUN_DIR="$TR_RUN" NETWORK_ID=aureom-trial-1 BASE_PORT=28700 GATEWAY_ADDR=127.0.0.1:8092)
    env "${TRENV[@]}" scripts/localnet.sh start >/dev/null && env "${TRENV[@]}" scripts/localnet.sh gateway start >/dev/null; sleep 3
    "${MIG[@]}" trial --source "$DEMO_SRC" --workdir "$RUN/migration/trial" --gateway http://127.0.0.1:8092 --network-id aureom-trial-1 --keys "$TR_RUN/net/keys" --report-gateway "$GW" 2>&1 | tail -25
    env "${TRENV[@]}" scripts/localnet.sh stop >/dev/null 2>&1; rm -rf "$TR_RUN"
    note "trial finished and thrown away; now the real migration (master data -> write freeze -> opening balances -> reconcile -> cutover)"
  fi
  "${MIG[@]}" all --source "$DEMO_SRC" --workdir "$RUN/migration/prod" --gateway "$GW" --network-id "$NETWORK_ID" --keys "$NET/keys" \
      --ack-manual --ack-by "demo-operator" --ack-reason "demo: MANUAL exceptions reviewed; none affect the demonstration SKUs" 2>&1 | tail -40 || { bad "migration failed"; exit 1; }
  note "stage after migration: $("${MIG[@]}" status --source "$DEMO_SRC" --workdir "$RUN/migration/prod" --gateway "$GW" --network-id "$NETWORK_ID" --keys "$NET/keys" 2>/dev/null | jget "'%s — authoritative system: %s'%(d['stage'], d['authoritative_system'])")"
  curl -s "$GW/api/v1/chain/migration" | jget "'on-chain migration window: %s (closed at height %s), %s batches, %s records'%(d['value']['status'], d['value']['closed_height'], d['value']['batches'], d['value']['records'])"
fi

want 2  && { say "2. Receive additional stock (goods receipt against the migrated open purchase order)"; "${SDK[@]}" step2-receive; }
want 3  && { say "3. Submit competing reservations for the last available unit"; "${SDK[@]}" step3-compete; }
want 4  && { say "4. The valid reservation is finalised; the conflicting request is rejected"; "${SDK[@]}" step4-outcome; }
want 5  && { say "5. Complete a sale (price + promotion calculation recorded on chain)"; "${SDK[@]}" step5-sale; }
want 6  && { say "6. Record a simulated payment confirmation (a payment adapter's authenticated result)"; "${SDK[@]}" step6-payment; }
want 7  && { say "7. Apply loyalty credit"; "${SDK[@]}" step7-loyalty; }
want 8  && { say "8. Return the item and record its inspection"; "${SDK[@]}" step8-return; }
want 9  && { say "9. Record a simulated refund confirmation (instruction and confirmation are separate events)"; "${SDK[@]}" step9-refund; }
want 10 && { say "10. Reverse the appropriate loyalty credit (compensating transaction; the original stays visible)"; "${SDK[@]}" step10-loyalty-reverse; }

if want 11; then
  say "11. Stop one validator and demonstrate the documented failure tolerance (n=4, f=1)"
  scripts/localnet.sh stop-node val-south
  sleep 3
  curl -s "$GW/api/v1/network" | jget "'status=%s — %s'%(d['bft']['status'], d['bft']['explanation'])"
  note "business transactions still finalise with 3 of 4 validators (75% of voting power > 2/3):"
  tx catalog-mgr CreateProduct '{"product_id":"P-DURING-OUTAGE","name":"Created while one validator was down","variants":[{"sku_id":"SKU-DURING-OUTAGE","unit":"EA"}]}' | tail -1
  note "now stop a SECOND validator: only 50% of power is online -> the chain must halt (no fork, no finality):"
  scripts/localnet.sh stop-node val-north
  sleep 3
  H0=$(chain_head)
  "$BIN/chainctl" tx --keys "$NET/keys" --rpc "$RPC" --network-id "$NETWORK_ID" --signer catalog-mgr --type CreateProduct --payload '{"product_id":"P-DURING-HALT","name":"Submitted during halt","variants":[{"sku_id":"SKU-DURING-HALT","unit":"EA"}]}' > "$RUN/halt-tx.out" 2>&1 &
  TXPID=$!
  sleep 8; H1=$(chain_head)
  [ "$H1" -le $((H0+1)) ] && ok "chain height stayed at $H1 (was $H0): no block was finalised without quorum" || bad "chain advanced without quorum?!"
  grep -q finalised "$RUN/halt-tx.out" && bad "tx finalised without quorum" || ok "the transaction is admitted but waiting: not finalised"
  note "restore one validator: quorum (3 of 4) returns and the pending transaction finalises:"
  scripts/localnet.sh start-node val-north
  wait $TXPID; tail -1 "$RUN/halt-tx.out"
fi

if want 12; then
  say "12. Rebuild a new node (from its backed-up keys, EMPTY data directory) and rebuild the query projection"
  scripts/localnet.sh stop-node val-south >/dev/null 2>&1
  OLDHOME="$NET/nodes/val-south"; NEWHOME="$NET/nodes/val-south-rebuilt"; rm -rf "$NEWHOME"
  P2P=$(python3 -c "import json;print([n['p2p_port'] for n in json.load(open('$NET/network.json'))['nodes'] if n['name']=='val-south'][0])")
  RPCP=$(python3 -c "import json;print([n['rpc_port'] for n in json.load(open('$NET/network.json'))['nodes'] if n['name']=='val-south'][0])")
  "$BIN/chainctl" newnode --net "$NET" --name val-south-rebuilt --mode replace --restore-from "$OLDHOME" --p2p-port "$P2P" --rpc-port "$RPCP"
  NODE_HOME="$NEWHOME" scripts/localnet.sh start-node val-south
  note "the new node holds no blocks and no state; it replays the chain from genesis through the state machine:"
  for _ in $(seq 1 90); do
    H=$(chain_head); R=$(curl -s "localhost:$RPCP/status" | jget "d['result']['sync_info']['latest_block_height']" 2>/dev/null || echo 0)
    [ "${R:-0}" -ge $((H-1)) ] && break; sleep 1
  done
  ok "rebuilt node at height $R (network head $H)"
  note "rebuild the query projection: delete it and re-ingest from genesis"
  curl -s -X POST "$GW/api/v1/projection/rebuild" | jget "d['status']"
  for _ in $(seq 1 90); do
    curl -s "$GW/api/v1/projection/status" | jget "d['state']+' '+str(d['indexed_height'])+'/'+str(d['chain_head'])" | tee "$RUN/proj.out" | grep -q '^OK' && [ "$(awk '{split($2,a,"/"); print (a[2]-a[1]<=1)}' "$RUN/proj.out")" = 1 ] && break; sleep 1
  done
  cat "$RUN/proj.out"
fi

if want 13; then
  say "13. Verify the resulting state against the finalised chain"
  H=$(chain_head); V=$((H-3))
  note "a) every validator, including the rebuilt one, reports the same state root at height $V:"
  "$ROOT/scripts/localnet.sh" status
  python3 - "$NET/network.json" "$V" <<'PY'
import json,sys,urllib.request
n=json.load(open(sys.argv[1])); h=int(sys.argv[2])+1
roots={}
for x in n["nodes"]:
    try:
        r=json.load(urllib.request.urlopen("%s/block?height=%d"%(x["rpc_url"],h),timeout=5))["result"]["block"]["header"]["app_hash"]
        roots.setdefault(r,[]).append(x["name"])
    except Exception as e: roots.setdefault("unreachable",[]).append(x["name"])
for k,v in roots.items(): print("   app_hash(header %d) = %s  <- %s"%(h,k[:24]+"…",", ".join(v)))
print("   AGREEMENT" if len(roots)==1 else "   DISAGREEMENT")
PY
  note "b) finality verified by an independent CometBFT light client anchored on the genesis validator set:"
  "$BIN/chainctl" verify-finality --rpc "$(rpc_urls)" --genesis "$NET/genesis.json" --network-id "$NETWORK_ID" --height "$V"
  note "c) full replay: re-execute EVERY block from genesis in a fresh in-memory state machine and compare each state root with the chain:"
  "$BIN/chainctl" replay --rpc "$RPC"
  note "d) the projection equals the chain: digest over every key/value + random Merkle-proof spot checks:"
  curl -s "$GW/api/v1/projection/verify?proofs=25" | jget "'match=%s  projection_digest=%s…  chain_digest=%s…  entries=%s  proofs valid %s/%s'%(d['match'], d['projection_digest'][:16], d['chain_digest'][:16], d['chain_entries'], d['proofs_valid'], d['proofs_checked'])"
  note "e) Merkle proofs for the demo records, checked against a light-client-verified header:"
  STATE="$RUN/demo-state.json"
  if [ -f "$STATE" ]; then
    for k in $(python3 -c "
import json
i=json.load(open('$STATE'))['ids']
ks=[]
if i.get('sale_id'): ks.append('sale/'+i['sale_id'])
if i.get('refund_id'): ks.append('refund/'+i['refund_id'])
if i.get('loyalty_entry_id'): ks.append('loye/'+i['loyalty_entry_id'])
if i.get('reversal_id'): ks.append('loye/'+i['reversal_id'])
if i.get('sale_id'): ks.append('loy/CUST-DEMO01')
print(' '.join(ks))"); do
      curl -s "$GW/api/v1/chain/record?key=$k&prove=1" | jget "'%s found=%s proof_valid=%s header_verified=%s'%(d['key'], d['found'], d['verification']['proof_valid'], d['verification']['header_verified'])"
    done
  fi
  note "f) audit/disaster snapshot: export a validator's state offline and verify it against the chain:"
  scripts/localnet.sh stop-node val-south >/dev/null 2>&1
  "$BIN/chainctl" snapshot export --home "$NET/nodes/val-south-rebuilt" --network-id "$NETWORK_ID" --out "$RUN/snapshot.jsonl" 2>/dev/null || "$BIN/chainctl" snapshot export --home "$NET/nodes/val-south" --network-id "$NETWORK_ID" --out "$RUN/snapshot.jsonl"
  "$BIN/chainctl" snapshot verify --file "$RUN/snapshot.jsonl" --rpc "$(rpc_urls)" --genesis "$NET/genesis.json" --network-id "$NETWORK_ID"
  NODE_HOME="$NET/nodes/val-south-rebuilt" scripts/localnet.sh start-node val-south >/dev/null 2>&1
fi
say "demonstration complete — open the dashboard at $GW"
