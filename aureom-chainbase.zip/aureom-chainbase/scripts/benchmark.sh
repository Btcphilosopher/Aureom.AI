#!/usr/bin/env bash
# Reproducible benchmark: engine-only, conventional-DB baseline, and the live 4-validator network.
# Usage: scripts/benchmark.sh [duration=30s] [workers=8,32,128] [block_time=1s]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DUR="${1:-30s}"; WORKERS="${2:-8,32,128}"; BT="${3:-1s}"
export RUN_DIR="$ROOT/run-bench" BASE_PORT=32000 BLOCK_TIME="$BT" NETWORK_ID=aureom-bench-1 GATEWAY_ADDR=127.0.0.1:8099
OUT="$ROOT/docs/benchmark-results"; mkdir -p "$OUT"
cd "$ROOT" && make build >/dev/null
echo "== engine (state machine + IAVL + LevelDB, no consensus)"
"$ROOT/bin/bench" engine --baskets 20000 | tee "$OUT/engine.json" | python3 -c "import sys,json; d=json.load(sys.stdin); print({k:d[k] for k in ('transactions','tx_per_s','avg_wire_bytes','rejected')})"
echo "== baseline (single-node SQLite, 1 commit/basket)"
"$ROOT/bin/bench" baseline --baskets 20000 | tee "$OUT/baseline.json" | python3 -c "import sys,json; d=json.load(sys.stdin); print({k:d[k] for k in ('baskets_per_s','equivalent_tx_per_s_4_per_basket')})"
echo "== network: 4 validators, block time $BT"
scripts/localnet.sh clean >/dev/null 2>&1 || true
scripts/localnet.sh start
trap 'scripts/localnet.sh stop >/dev/null 2>&1 || true' EXIT
"$ROOT/bin/bench" net --network "$RUN_DIR/net/network.json" --keys "$RUN_DIR/net/keys" --workers "$WORKERS" --duration "$DUR" --out "$OUT/network-$BT.json"
echo "results in $OUT"
