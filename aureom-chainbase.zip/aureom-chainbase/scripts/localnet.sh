#!/usr/bin/env bash
# Local multi-validator network: 4 independent chaind processes (HQ, Distribution, Regional North/South).
# SINGLE MACHINE: process isolation only. See docs/TRUST_MODEL.md for what that does and does not prove.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="${BIN_DIR:-$ROOT/bin}"
RUN="${RUN_DIR:-$ROOT/run}"
NET="$RUN/net"
NETWORK_ID="${NETWORK_ID:-aureom-retail-demo-1}"
BLOCK_TIME="${BLOCK_TIME:-1s}"
BASE_PORT="${BASE_PORT:-26600}"
GATEWAY_ADDR="${GATEWAY_ADDR:-127.0.0.1:8080}"
VALS=(val-hq val-dist val-north val-south)

ensure_bins() { [ -x "$BIN/chaind" ] || (cd "$ROOT" && make build); }

rpc_port() { # name -> rpc port from network.json
  python3 - "$NET/network.json" "$1" <<'PY'
import json,sys
n=json.load(open(sys.argv[1]))
print([x["rpc_port"] for x in n["nodes"] if x["name"]==sys.argv[2]][0])
PY
}

cmd_init() {
  ensure_bins
  [ -d "$NET" ] && { echo "network already initialised at $NET (use: $0 clean)"; return 0; }
  mkdir -p "$RUN"
  "$BIN/chainctl" testnet --out "$NET" --network-id "$NETWORK_ID" --base-port "$BASE_PORT" --block-time "$BLOCK_TIME"
}

start_node() {
  local n="$1"; mkdir -p "$RUN/logs" "$RUN/pids"
  if [ -f "$RUN/pids/$n.pid" ] && kill -0 "$(cat "$RUN/pids/$n.pid")" 2>/dev/null; then echo "$n already running"; return; fi
  nohup "$BIN/chaind" start --home "${NODE_HOME:-$NET/nodes/$n}" --log-level "${LOG_LEVEL:-main:info,state:info,*:error}" >>"$RUN/logs/$n.log" 2>&1 &
  echo $! >"$RUN/pids/$n.pid"; echo "started $n (pid $!)"
}
stop_node() {
  local n="$1"
  if [ -f "$RUN/pids/$n.pid" ]; then
    local pid; pid="$(cat "$RUN/pids/$n.pid")"
    kill "$pid" 2>/dev/null || true
    for _ in $(seq 1 50); do kill -0 "$pid" 2>/dev/null || break; sleep 0.1; done
    kill -9 "$pid" 2>/dev/null || true
    rm -f "$RUN/pids/$n.pid"; echo "stopped $n"
  else echo "$n not running"; fi
}

cmd_start() {
  ensure_bins; [ -d "$NET" ] || cmd_init
  for n in "${VALS[@]}"; do start_node "$n"; done
  echo -n "waiting for finalised blocks"
  for _ in $(seq 1 60); do
    h=$(curl -s "localhost:$(rpc_port val-hq)/status" 2>/dev/null | python3 -c "import sys,json;print(json.load(sys.stdin)['result']['sync_info']['latest_block_height'])" 2>/dev/null || echo 0)
    [ "${h:-0}" -ge 3 ] && { echo " height=$h"; return 0; }; echo -n "."; sleep 1
  done; echo " TIMEOUT"; return 1
}
cmd_stop() { for n in "${VALS[@]}" "${EXTRA_NODES[@]:-}"; do [ -n "$n" ] && stop_node "$n" || true; done; cmd_gateway_stop; }

cmd_status() {
  for n in "${VALS[@]}"; do
    p=$(rpc_port "$n")
    curl -s -m 2 "localhost:$p/status" 2>/dev/null | python3 -c "
import sys,json
try:
  r=json.load(sys.stdin)['result']; s=r['sync_info']
  print('%-10s height=%-6s app_hash=%s catching_up=%s'%('$n',s['latest_block_height'],s['latest_app_hash'][:16],s['catching_up']))
except Exception: print('%-10s DOWN'%'$n')
" || echo "$n DOWN"
  done
}

cmd_gateway_start() {
  ensure_bins; mkdir -p "$RUN/logs" "$RUN/pids"
  nohup "$BIN/gateway" --network "$NET/network.json" --listen "$GATEWAY_ADDR" --projection "$RUN/projection.sqlite" \
     --static "$ROOT/dashboard/dist" >>"$RUN/logs/gateway.log" 2>&1 &
  echo $! >"$RUN/pids/gateway.pid"; echo "gateway on http://$GATEWAY_ADDR (pid $!)"
}
cmd_gateway_stop() { stop_node gateway >/dev/null 2>&1 || true; }

cmd_clean() { cmd_stop || true; rm -rf "$RUN"; echo "cleaned"; }

case "${1:-}" in
  init) cmd_init;; start) cmd_start;; stop) cmd_stop;; status) cmd_status;; clean) cmd_clean;;
  start-node) start_node "$2";; stop-node) stop_node "$2";;
  gateway) shift; case "${1:-start}" in start) cmd_gateway_start;; stop) cmd_gateway_stop;; esac;;
  *) echo "usage: $0 init|start|stop|status|clean|start-node NAME|stop-node NAME|gateway [start|stop]"; exit 2;;
esac
