#!/usr/bin/env bash
# Regenerates docs/TRANSACTIONS.md from the Go payload types.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/chain"
{ cat "$ROOT/docs/_tx_header.md"; go run ./cmd/chainctl schema roles; go run ./cmd/chainctl schema md; } > "$ROOT/docs/TRANSACTIONS.md"
echo "wrote docs/TRANSACTIONS.md"
