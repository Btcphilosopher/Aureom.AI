#!/usr/bin/env bash
# shared helpers for the demo scripts
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="${BIN_DIR:-$ROOT/bin}"
RUN="${RUN_DIR:-$ROOT/run}"
NET="$RUN/net"
GW="${GATEWAY_URL:-http://${GATEWAY_ADDR:-127.0.0.1:8080}}"
NETWORK_ID="${NETWORK_ID:-aureom-retail-demo-1}"

say()  { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
note() { printf '\033[0;33m   %s\033[0m\n' "$*"; }
ok()   { printf '\033[0;32m   ✔ %s\033[0m\n' "$*"; }
bad()  { printf '\033[0;31m   ✘ %s\033[0m\n' "$*"; }

rpc_of() { python3 - "$NET/network.json" "$1" <<'PY'
import json,sys
n=json.load(open(sys.argv[1]))
print([x["rpc_url"] for x in n["nodes"] if x["name"]==sys.argv[2]][0])
PY
}
RPC="${RPC:-$(rpc_of val-hq 2>/dev/null || true)}"
rpc_urls() { python3 - "$NET/network.json" <<'PY'
import json,sys
n=json.load(open(sys.argv[1])); print(",".join(x["rpc_url"] for x in n["nodes"]))
PY
}
chain_head() { curl -s "$RPC/status" | python3 -c "import sys,json;print(json.load(sys.stdin)['result']['sync_info']['latest_block_height'])"; }
wait_height() { local h="$1" t=${2:-120}; for _ in $(seq 1 "$t"); do [ "$(chain_head 2>/dev/null || echo 0)" -ge "$h" ] && return 0; sleep 1; done; return 1; }
jget() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)"; }

# tx SIGNER TYPE PAYLOAD_JSON [keys_dir]
tx() { "$BIN/chainctl" tx --keys "${4:-$NET/keys}" --rpc "$RPC" --network-id "$NETWORK_ID" --signer "$1" --type "$2" --payload "$3"; }
