#!/usr/bin/env python3
"""Renders docs/BENCHMARK.md from docs/benchmark-results/*.json (all numbers in the tables are measured)."""
import json, glob, os
R = os.path.join(os.path.dirname(__file__), "..", "docs", "benchmark-results")
L = lambda f: json.load(open(os.path.join(R, f)))
eng, base = L("engine.json"), L("baseline.json")
hw = eng["hardware"]
runs = [("1 s", "network-1s-w16-64-256.json"), ("1 s", "network-1s-w512-1024-2048.json"), ("500 ms", "network-500ms.json")]
out = []
w = out.append
w("# Benchmark: defined retail workload (measured) and trade-offs\n")
w("**Everything in the result tables is measured** by `scripts/benchmark.sh` (raw JSON in `docs/benchmark-results/`). Sections marked *Estimate* are reasoning, not measurements.\n")
w("## 1. Environment\n")
w(f"* Hardware: {hw['cpu_model']}, {hw['logical_cpus']} logical CPUs, {int(hw['mem_total'].split()[0])//1024//1024} GB RAM, `{hw['os']}`, Go `{hw['go']}`; a single virtual machine (shared-tenancy cloud sandbox).")
w("* **All four validators, the load generator and the SQLite baseline ran on this one machine** over loopback TCP. Each validator therefore had roughly one core shared with the others and with the load generator (which also signs every transaction). Results are a floor for this hardware class, **not** a prediction for four separate hosts, and say nothing about WAN latency.")
w("* Validators: 4 × CometBFT v0.38.25 + the Go state machine, equal voting power (n=4, f=1), `timeout_commit` as stated per run, empty blocks enabled, tx indexer `kv`, default mempool, LevelDB for blocks/state/IAVL, persistent state at every height retained (no pruning), ed25519 signature verification in CheckTx **and** again in execution, block max 4 MiB.")
w("* Load generator: `bin/bench net` — closed loop: *W* concurrent POS workers, each running whole baskets sequentially and waiting for **finality** of every step (finality observed via the NewBlock event of validator 0; submissions round-robin across the four validators' RPC).\n")
w("## 2. Workload (retail basket)\n")
w("One basket = 1–3 `ReserveStock` (one per line, submitted in parallel, qty 1–2) → `CompleteSale` (consumes the reservations atomically, prices lines, posts movements) → `RecordPaymentResult` (simulated payment confirmation) → `CreditLoyalty` for ~60 % of baskets → for ~6 % of baskets a return flow: `RequestReturn` → `ApproveReturn` → `ReceiveReturnedGoods` (RESELLABLE) → `RecordRefundResult`. Stores alternate between STORE-N-01 and STORE-S-01; 50 SKUs; stock pre-loaded (not measured). Every transaction is signed by the proper role-holding identity and passes the full pipeline (no shortcuts); **0 rejected transactions in all runs**.\n")
last = L("network-1s-w16-64-256.json")["steps"][-1]["mix"]
w("| transaction type | share of mix | avg wire bytes | max wire bytes |\n|---|---:|---:|---:|")
for k, v in sorted(last.items(), key=lambda kv: -kv[1]["share_pct"]):
    w(f"| {k} | {v['share_pct']:.1f} % | {v['avg_wire_bytes']} | {v['max_wire_bytes']} |")
w("\nWire bytes = the whole JSON envelope including the base64 body, 64-byte signature and public key. (Average over the mix ≈ 700 bytes.)\n")
w("## 3. Network results (4 validators)\n")
w("Finality latency = client submit → block containing the tx observed committed (includes mempool admission, proposal, two voting rounds and the `timeout_commit` wait; quantised by the block interval). Throughput counts finalised transactions per second over the whole step (including the tail while the last baskets drain).\n")
w("| block interval | workers | tx/s | baskets/s | finality p50 | p95 | p99 | max (ms) | admission p50 / p99 (ms) | txs/block | rejected |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
for bt, f in runs:
    for s in L(f)["steps"]:
        fm, am = s["finality_ms"], s["admission_ms"]
        w(f"| {bt} | {s['workers']} | {s['tx_per_s']:.0f} | {s['baskets_per_s']:.1f} | {fm['p50']:.0f} | {fm['p95']:.0f} | {fm['p99']:.0f} | {fm['max']:.0f} | {am['p50']:.0f} / {am['p99']:.0f} | {s['txs_per_block_avg']:.0f} | {s['rejected']} |")
w("\n**Reading it.** Under light load finality is ≈ 0.8 s (500 ms blocks) or ≈ 1.3 s (1 s blocks). Throughput rises with offered concurrency until the machine saturates at roughly **330 finalised tx/s (≈ 55–70 baskets/s)** at block interval 1 s; beyond that extra workers only add queueing (latency grows, throughput stays flat: 1024 → 2048 workers 321 → 330 tx/s). The plateau is consistent with CPU saturation of a shared 4-vCPU VM (every validator verifies and executes every transaction, plus gossip, mempool re-checks and indexing, and the load generator signs on the same cores); CPU was not profiled per process, so treat that as the likely, not proven, cause.\n")
w("## 4. Storage growth (measured with `du -sb` of each validator's `data/` before/after each step)\n")
w("| run | workers | tx finalised | growth / validator | bytes per tx per validator |\n|---|---:|---:|---:|---:|")
for bt, f in runs:
    for s in L(f)["steps"]:
        w(f"| {bt} | {s['workers']} | {s['transactions_finalised']} | {s['storage_growth_bytes_per_validator']/1e6:.1f} MB | {s['storage_bytes_per_tx_per_validator']:.0f} |")
w(f"\nAt load the cost converges to **≈ 5.3–5.9 KB per transaction per validator** against ≈ 0.7 KB of wire data (≈ 8×): block store (tx + commit signatures), CometBFT's saved block results (which here include one event per state write so projections can be rebuilt), the tx index, and the IAVL tree with **every version retained** (copy-on-write path nodes). Low-load rows are inflated by empty blocks (one per block interval, each recording block time) and LevelDB write-ahead-log preallocation. The engine-only run (state tree only, no block store/results) used {eng['db_bytes']/1e6:.0f} MB for {eng['transactions']} tx ≈ {eng['db_bytes']/eng['transactions']:.0f} bytes/tx.\n")
w("## 5. Engine-only and conventional-database baselines (measured, same machine, no consensus)\n")
w("| run | result |\n|---|---|")
w(f"| State machine + IAVL + LevelDB through the ABCI interface (`bench engine`, {eng['baskets']} baskets in dependency stages, 2000 tx/block, includes signature verification and every authorisation check, 0 rejected) | **{eng['tx_per_s']:.0f} tx/s** single-threaded execution |")
w(f"| Single-node SQLite, one commit per basket, `synchronous=FULL`, WAL, equivalent row writes ({base['statements']//base['baskets']} statements/basket; **no signatures, no authorisation engine, no history/proofs, no replication**) | {base['baskets_per_s']:.0f} baskets/s ≈ {base['equivalent_tx_per_s_4_per_basket']:.0f} tx-equivalents/s |")
w("\nThe engine number is the ceiling a validator can sustain per core when it only executes; the network result (≈ 330 tx/s) is lower because four validators share four cores with the load generator and because consensus, gossip, mempool re-checks and indexing sit on top. The SQLite figure is context for *what is being paid for* — it is not a like-for-like comparison.\n")
w("## 6. Trade-offs relative to a conventional database\n")
w("**Throughput.** A replicated deterministic state machine executes one agreed total order **sequentially on every validator** (no parallel speed-up from adding validators; more validators only add messages). Each transaction is also verified (signature, identity, authorisation) before execution. Measured: ~1.7 k tx/s executing alone (1.6-1.8 k across runs), ~330 tx/s with four validators on four shared cores, vs ≈ 8.9 k statement-equivalent tx/s for a single SQLite writer doing the same row work without any of those properties. A conventional replicated SQL cluster with one writer would sit in between; a conventional DB scales reads with replicas, a chain scales reads with projection/observer nodes but not writes. For a retail group the *business* load (peak few hundred POS tx/s across all stores, most of which can be batched/pre-allocated) is within what a well-provisioned 4–7 validator network on dedicated hosts can serve; very high-volume event streams (every scan, every price-tag read) should stay off-chain.\n")
w("**Latency.** Finality is never below the block interval; expect ≈ interval + 1–2 s. A conventional DB commit is milliseconds. Interactive POS flows should therefore use pre-allocated reservations/allowances and treat the chain as the system of record that finalises within ~1–3 s, not as a per-keystroke store (the offline-terminal design assumes this).\n")
w("**Storage.** ≈ 5–6 KB per transaction per validator (measured) with full history and proofs, replicated N times (N=4 here) and retained forever unless pruning/archival is designed — versus ≈ 0.5–1 KB per equivalent transaction in a normalised SQL schema (SQLite baseline above: ≈ 470 B per basket of 4 tx, incl. indexes). *Estimate:* 100 M transactions/year → ≈ 0.55 TB/year per validator at this amplification; plan pruning of block results / event data (not the IAVL history needed for proofs) and archive tiers.\n")
w("**Privacy.** Every validator holds all plaintext records and the full history; a conventional DB can restrict by row/column and delete. See `docs/PRIVACY.md`: the privacy-conscious profile keeps identifying data off-chain, at the cost of more moving parts and weaker joins.\n")
w("**What you buy:** one agreed history across organisations that do not trust one another's databases, finality, tamper-evidence (Merkle commitments verified by a light client), deterministic replay/rebuild of every index, and enforced business rules shared by all parties.\n")
w("## 7. Estimates (not measured)\n")
w("* Dedicated hosts (1 validator per 4+ cores) should raise sustainable throughput toward the engine-bound ~1–1.8 k tx/s per validator minus consensus/gossip overhead — *not measured here*.\n* Cross-region validators add network RTT to every consensus round: *estimate* finality ≈ block interval + 3–4 × inter-validator RTT (e.g. ≈ 1.5–2.5 s at 150 ms RTT) — *not measured*.\n* Larger validator sets (7, 10) reduce fault-domain risk but increase vote/gossip cost — *not measured*.\n")
w("## 8. Reproduce\n```bash\nscripts/benchmark.sh 30s 16,64,256 1s        # also: 30s 512,1024,2048 1s ; 30s 16,64,256 500ms\npython3 scripts/benchmark_report.py          # regenerates this file from docs/benchmark-results/*.json\n```")
open(os.path.join(os.path.dirname(__file__), "..", "docs", "BENCHMARK.md"), "w").write("\n".join(out) + "\n")
print("wrote docs/BENCHMARK.md")
